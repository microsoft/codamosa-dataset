

# Generated at 2022-06-12 08:31:09.190093
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5', version="v1")
    bp6 = Blueprint('bp6', url_prefix='/bp6', version="v1")
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    bpg2 = BlueprintGroup()
    bpg2.append(bp3)
    bpg2.append(bp4)

    bpg3 = BlueprintGroup()

# Generated at 2022-06-12 08:31:19.068945
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    app.blueprint(bp1)
    app.blueprint(bp2)

    bp1.middleware(bp1_middleware, "request")
    bp2.middleware(bp2_middleware, "request")

    @bp1.route('/test_middleware1')
    async def test_middleware1(request):
        return text('test_middleware1')

    @bp2.route('/test_middleware2')
    async def test_middleware2(request):
        return text('test_middleware2')

    request, response = app.test_client.get('/bp1/test_middleware1')
    assert response.status

# Generated at 2022-06-12 08:31:28.205939
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    mock_blueprint1 = mock.Mock(spec=sanic.Blueprint)
    mock_blueprint2 = mock.Mock(spec=sanic.Blueprint)
    mock_blueprint3 = mock.Mock(spec=sanic.Blueprint)

    blueprint_group = BlueprintGroup()
    blueprint_group.blueprints.extend(
        [mock_blueprint1, mock_blueprint2, mock_blueprint3]
    )

    @blueprint_group.middleware("request")
    async def middleware1(request):
        return "middleware1"

    async def middleware2(request):
        return "middleware2"

    @blueprint_group.middleware("request")
    async def middleware3(request):
        return "middleware3"


# Generated at 2022-06-12 08:31:28.680246
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    pass

# Generated at 2022-06-12 08:31:39.098579
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = sanic.Blueprint("blueprint-2")
    bp2 = sanic.Blueprint("blueprint-2")
    bpg = BlueprintGroup()

    bpg.append(bp1)
    bpg.append(bp2)

    def print_middleware(request):
        print("Applied across entire blueprint group")
        return request

    bpg.middleware(print_middleware)
    assert bp1.middlewares[0].handler is print_middleware
    assert bp2.middlewares[0].handler is print_middleware
# End Function test_BlueprintGroup_middleware
#

# Generated at 2022-06-12 08:31:41.521440
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @BlueprintGroup.middleware()
    async def middleware(request):
        pass

    assert middleware.__name__ == "middleware"


# Generated at 2022-06-12 08:31:44.500632
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @BlueprintGroup.middleware()
    def test_middleware(request: Request):
        return text('bp1')

    assert test_middleware.__name__ == 'test_middleware'

# Generated at 2022-06-12 08:31:49.939633
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class TestRequest(object):
        pass
    class TestResponse(object):
        pass
    class TestSanic(object):
        def __init__(self):
            self.error_handler = {}
        def add_route(self,handler,uri,methods = ["GET"]):
            pass
    class TestBlueprint(object):
        def __init__(self):
            self.error_handler = {}
            self.request_middleware = [None]
            self.response_middleware = [None]
    bp = TestBlueprint()
    bp1 = BlueprintGroup()
    @bp1.middleware('request')
    async def test_middleware(request):
        return TestResponse()
    bp1.append(bp)
    request = TestRequest()
    request.app = TestSanic()

# Generated at 2022-06-12 08:31:58.509865
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Test that decorator are correctly called on all blueprints
    """
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")

    bp4 = Blueprint("bp4", url_prefix="/bp4")
    bp5 = Blueprint("bp5", url_prefix="/bp5")

    @bp3.middleware('request')
    def bp3_only_middleware(request):
        assert False

    @bp4.middleware('request')
    def bp4_only_middleware(request):
        assert False

    # Create a nested blueprint group

# Generated at 2022-06-12 08:32:08.732743
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware('request')
    async def group_middleware(request):
        pass

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        pass

    @bp2.middleware('request')
    async def bp2_only_middleware(request):
        pass

    assert bpg.middleware == bp1.middleware == bp2.middleware

# Generated at 2022-06-12 08:32:22.418102
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')

    bp3 = sanic.Blueprint('bp3', url_prefix='/bp3')
    bp4 = sanic.Blueprint('bp4', url_prefix='/bp4')

    bp4 = sanic.Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    assert bpg.version == "v1"
    assert bpg.strict_slashes is None
    assert bpg.url_prefix == "/api"
    assert len(bpg) == 2


# Generated at 2022-06-12 08:32:25.518976
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp = BlueprintGroup()
    assert bp.blueprints == []
    assert bp.version is None
    assert bp.url_prefix is None
    assert bp.strict_slashes is None
    assert len(bp) == 0



# Generated at 2022-06-12 08:32:30.759753
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.insert(0,bp1)
    assert len(bpg) == 1
    assert bpg[0] == bp1

    bpg.insert(0,bp2)
    assert len(bpg) == 2
    assert bpg[0] == bp2
    assert bpg[1] == bp1


# Generated at 2022-06-12 08:32:40.827999
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint("bp1", url_prefix="bp1")
    bp2 = Blueprint("bp2", url_prefix="bp2")
    #  Create Blueprint Group
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    # Iteration is supported on Blueprints as expected
    assert bp1 in bpg
    assert bp2 in bpg
    assert len(bpg) == 2
    # Delete an item from blueprint group
    del bpg[1]
    assert len(bpg) == 1
    assert bp1 in bpg
    assert bp2 not in bpg



# Generated at 2022-06-12 08:32:45.489192
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    iterator = iter(bpg)
    assert next(iterator) == bp1
    assert next(iterator) == bp2


# Generated at 2022-06-12 08:32:54.267876
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    # Arrange
    class MockBlueprint:
        def middleware(self, fn, *args, **kwargs):
            return fn

    class MockBlueprintGroup(BlueprintGroup):
        def __init__(self):
            super().__init__()
            self._blueprints = [MockBlueprint(), MockBlueprint()]

    bg = MockBlueprintGroup()
    def fn(x):
        print(x)

    # Act
    bg.middleware(fn,'123')

    # Assert
    assert bg.__dict__.get('_blueprints') == [fn, fn]

# Generated at 2022-06-12 08:33:04.644441
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    """
    Test the BlueprintGroup class insert method
    """
    bpg = BlueprintGroup(url_prefix="/abc", version="v1", strict_slashes=True)
    assert bpg.url_prefix == "/abc"
    assert bpg.version == "v1"
    assert bpg.strict_slashes == True

    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bpg.insert(0, bp1)
    assert bpg.url_prefix == "/abc"
    assert bpg[0].url_prefix == "/abc/bp1"

    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bpg.insert(0, bp2)
    assert bpg.url_prefix == "/abc"

# Generated at 2022-06-12 08:33:07.719846
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    """
    Test the BlueprintGroup.__iter__ method
    :return: None
    """
    bpg = BlueprintGroup()
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bpg.append(bp1)
    bpg.append(bp2)

    # check if the iterator can be used as a list/tuple
    lim = len(bpg)
    cnt = 0
    for item in bpg:
        cnt += 1
    assert lim == cnt


# Generated at 2022-06-12 08:33:15.700602
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")

    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)
    group.append(bp3)
    group.append(bp4)

    assert bp1 in group
    assert bp2 in group
    assert bp3 in group
    assert bp4 in group
    assert group[0] is bp1
    assert group[1] is bp2
    assert group[2] is bp3
    assert group[3] is bp4



# Generated at 2022-06-12 08:33:19.468028
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bpg = BlueprintGroup(url_prefix="/api", version=0.1, strict_slashes=True)
    assert isinstance(bpg, BlueprintGroup)


# Generated at 2022-06-12 08:33:28.046676
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()

    assert len(bpg) == 0
    bpg.append(bp1)
    assert len(bpg) == 1
    bpg.append(bp2)
    assert len(bpg) == 2


# Generated at 2022-06-12 08:33:39.732910
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    bpg.__delitem__(0)
    assert bpg.__len__() == 3
    assert bpg[0] == bp2
    assert bpg[1] == bp3
    assert bpg[2] == bp4


# Generated at 2022-06-12 08:33:46.206026
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    """
    Unit test for method insert of class BlueprintGroup
    """
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.insert(1, bp1)
    assert bpg[0] == bp1
    assert bpg[1] == bp1
    assert len(bpg) == 3


# Generated at 2022-06-12 08:33:54.301293
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    # Given
    url_prefix = None
    version = 1
    strict_slashes = None
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix=url_prefix, version=version, strict_slashes=strict_slashes)
    bpg.append(bp1)
    bpg.append(bp2)
    # When
    del bpg[0]
    # Then
    assert len(bpg) == 1
    assert bpg[0] == bp2


# Generated at 2022-06-12 08:34:01.156958
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    """
    Unit test to ensure Blueprint Group is constructed correctly
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    assert set(bpg.blueprints) == set([bp3, bp4])
    assert bpg.url_prefix == '/api'
    assert bpg.version == 'v1'
    assert bpg.strict_slashes is None


# Generated at 2022-06-12 08:34:10.297167
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-12 08:34:19.994454
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    # Define a Mock callable class for testing
    class MockCallable:
        pass

    # Define a Mock Blueprint class for testing
    class MockBlueprint:
        def __init__(self, name):
            self.name = name

    # Define a blueprint_group
    blueprint_group = BlueprintGroup("/test", "v1", True)

    # Define three blueprints
    blueprint1 = MockBlueprint("bp1")
    blueprint2 = MockBlueprint("bp2")
    blueprint3 = MockBlueprint("bp3")

    # Inject the blueprints into the BlueprintGroup
    blueprint_group.append(blueprint1)
    blueprint_group.append(blueprint2)
    blueprint_group.append(blueprint3)

    # Apply the del item operation
    del blueprint_group[1]

    # Assert the

# Generated at 2022-06-12 08:34:25.407149
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    app = sanic.Sanic('test_BlueprintGroup_insert')
    bp1 = Blueprint('bp1', 'bp1', url_prefix='bp1')
    bp2 = Blueprint('bp2', 'bp2', url_prefix='bp2')

    bpg = BlueprintGroup(None)
    bpg.append(bp1)
    bpg.insert(0, bp2)
    assert bpg[0] == bp2
    assert bpg[1] == bp1


# Generated at 2022-06-12 08:34:30.083256
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    blueprint_group = BlueprintGroup()
    blueprint = Blueprint(name="name", url_prefix="url")
    blueprint_group.append(blueprint)

    assert blueprint_group.blueprints == [blueprint]
    assert blueprint_group._url_prefix == None
    assert blueprint_group._version == None
    assert blueprint_group._strict_slashes == None


# Generated at 2022-06-12 08:34:38.239729
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()

    @app.middleware('request')
    async def add_prefix_middleware(request):
        request.headers['X-Blueprint-Middleware'] = 'from global middleware'

    @app.middleware('response')
    async def add_suffix_middleware(request, response):
        response.headers['X-Blueprint-Middleware'] = 'from global middleware'

    bp1 = Blueprint('bp1', url_prefix='/bp1')

    @bp1.middleware('request')
    async def add_prefix_middleware_bp1(request):
        request.headers['X-Blueprint-Middleware-BP1'] = 'from bp1 middleware'


# Generated at 2022-06-12 08:34:53.314016
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    app = sanic.Sanic()
    bp1= Blueprint('bp1', url_prefix='/bp1')
    bp2= Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    assert len(bpg) == 0
    bpg.append(bp1)
    assert len(bpg) == 1
    bpg.append(bp2)
    assert len(bpg) == 2

# Generated at 2022-06-12 08:34:54.029145
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    pass

# Generated at 2022-06-12 08:35:04.289407
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1=Sanic('test_blueprint')
    bp2=Sanic('test_blueprint')
    bp3=Sanic('test_blueprint')
    bp4=Sanic('test_blueprint')
    bp5=Sanic('test_blueprint')
    bp_group = BlueprintGroup()
    bp_group._blueprints.append(bp1)
    bp_group._blueprints.append(bp2)
    bp_group._blueprints.append(bp3)
    bp_group._blueprints.append(bp4)
    bp_group._blueprints.append(bp5)
    bp_group.__setitem__(2, 34)
    assert bp_group._blueprints[2] == 34


# Generated at 2022-06-12 08:35:09.429210
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)

    assert group[0].name == bp1.name
    assert group[1].name == bp2.name


# Generated at 2022-06-12 08:35:13.471401
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bpg = BlueprintGroup(bp1, Blueprint('bp2', url_prefix='/bp2'))
    del bpg[0]
    assert len(bpg.blueprints) == 1



# Generated at 2022-06-12 08:35:22.584733
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware('response')
    async def bp_group_middleware(request, response):
        """
        A test case for checking if the middleware function applied
        on the Blueprint Group is working properly.
        """
        assert response is not None

    @bpg.middleware('response')
    async def bp_group_middleware_with_args(request, response, agrs):
        """
        A test case for checking if the middleware function applied
        on the Blueprint Group is working properly.
        """
        assert response is not None


# Generated at 2022-06-12 08:35:31.667118
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    """
    Unit test for method insert of class BlueprintGroup
    """

    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bp3 = Blueprint("bp3")

    bg = BlueprintGroup()
    bg.insert(0, bp1)
    bg.insert(0, bp2)
    assert bg[0].name == "bp2"
    assert bg[1].name == "bp1"
    bg.insert(0, bp3)
    assert bg[0].name == "bp3"
    assert bg[1].name == "bp2"
    assert bg[2].name == "bp1"
    assert len(bg) == 3
    bg.insert(5, bp3)

# Generated at 2022-06-12 08:35:36.342049
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    """
    Testing the BlueprintGroup.__len__() method for different scenarios.
    """
    bpg = BlueprintGroup()

    # checking the length of an empty Blueprint Group
    assert len(bpg) == 0

    # checking the length of a non-empty Blueprint Group
    bpg = BlueprintGroup(url_prefix='/api', version=1)
    bpg.append(Blueprint('bp1', url_prefix='/bp1'))
    bpg.append(Blueprint('bp2', url_prefix='/bp2'))
    assert len(bpg) == 2


# Generated at 2022-06-12 08:35:45.902850
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)



# Generated at 2022-06-12 08:35:55.486957
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint

    bp1 = Blueprint('bp1', url_prefix='/bp1')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    bp2 = Blueprint('bp2', url_prefix='/bp2')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    group = Blueprint.group(bp1, bp2)

    app = Sanic('test_BlueprintGroup___delitem__')
    app.blueprint(group)

    assert len(group) == 2
    assert str(group) == "<BlueprintGroup: bp1, bp2>"

# Generated at 2022-06-12 08:36:17.851583
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bg = BlueprintGroup()
    assert len(bg) == 0
    bg.append(Blueprint("test1"))
    assert len(bg) == 1
    bg.append(Blueprint("test2"))
    assert len(bg) == 2


# Generated at 2022-06-12 08:36:25.283703
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint("bp1", url_prefix="bp1")
    bp2 = Blueprint("bp2", url_prefix="bp2")
    bp3 = Blueprint("bp3", url_prefix="bp3")
    bp4 = Blueprint("bp4", url_prefix="bp4")

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    bp1.append(bp2)
    bp1.append(bpg)

    switch = False

    for bp in bp1:
        if switch:
            assert isinstance(bp, Blueprint)
            assert bp.name == "bp2"
        else:
            assert isinstance(bp, BlueprintGroup)
            assert bp.url_prefix == "/api"

# Generated at 2022-06-12 08:36:29.652103
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bpg = BlueprintGroup(bp1)
    assert len(bpg) == 1



# Generated at 2022-06-12 08:36:38.446289
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    .. versionadded:: 0.2.0

    .. versionchanged:: 0.2.8

    BlueprintGroup.middleware()

    """

    async def act_middleware(request):
        pass

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')


# Generated at 2022-06-12 08:36:46.691269
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    import asyncio
    from sanic import Sanic
    from sanic.blueprints import Blueprint

    class FakeBlueprint(Blueprint):
        def __init__(self):
            self.middleware_functions = []

        def middleware(self, fn, *args, **kwargs):
            self.middleware_functions.append((fn, args, kwargs))

    bp1 = FakeBlueprint()
    bp2 = FakeBlueprint()
    bp3 = FakeBlueprint()
    bp4 = FakeBlueprint()
    bpg = BlueprintGroup(bp3, bp4)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')


# Generated at 2022-06-12 08:36:57.712906
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint("bp1", url_prefix="bp1")
    bp2 = Blueprint("bp2", url_prefix="bp2")
    bp3 = Blueprint("bp3", url_prefix="bp3")

    bpg = BlueprintGroup()

    bpg.insert(0, bp1)
    bpg.insert(0, bp2)

    assert bpg[0] is bp2
    assert bpg[1] is bp1

    bpg.insert(1, bp3)

    assert bpg[0] is bp2
    assert bpg[1] is bp3
    assert bpg[2] is bp1

    bpg.insert(10, bp1)

    assert bpg[0] is bp2
    assert bpg[1] is bp3
   

# Generated at 2022-06-12 08:37:04.809047
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp_group = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    assert len(bp_group) == 2
    del bp_group[1]
    assert len(bp_group) == 1
    del bp_group[0]
    assert len(bp_group) == 0



# Generated at 2022-06-12 08:37:16.264864
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    group = BlueprintGroup(bp1, bp2)
    app = sanic.Sanic()
    app.blueprint(group)
    app.config.KEEP_ALIVE = False
    app.config.KEEP_ALIVE_TIMEOUT = 1

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-12 08:37:27.332567
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    del bpg[0]
    assert len(bpg) == 3
    assert isinstance(bpg[0], Blueprint)
    assert bpg[0].name == 'bp2'
    assert bpg[0].url_prefix == '/bp2'
    assert b

# Generated at 2022-06-12 08:37:37.283209
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    group = Blueprint.group(bp1, bp2)
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    for bp in group:
        assert bp in [bp1, bp2]

    for bp in bpg:
        assert bp in [bp3, bp4]



# Generated at 2022-06-12 08:38:14.194203
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blue_group = BlueprintGroup(url_prefix='/api')
    assert len(blue_group) == 0
    blue_group.append(Blueprint('bp1', url_prefix='/bp1'))
    assert len(blue_group) == 1
    blue_group.append(Blueprint('bp2', url_prefix='/bp2'))
    assert len(blue_group) == 2


# Generated at 2022-06-12 08:38:24.642832
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    from sanic.blueprints import Blueprint
    from sanic.app import Sanic
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-12 08:38:27.262820
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    assert BlueprintGroup()
    assert BlueprintGroup(url_prefix="api")
    assert BlueprintGroup(version="v1")
    assert BlueprintGroup(strict_slashes=False)

# Generated at 2022-06-12 08:38:36.032508
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp = Blueprint('blueprint',url_prefix='/blueprint')
    bp1 = Blueprint('blueprint1',url_prefix='/blueprint1')
    bp2 = Blueprint('blueprint2',url_prefix='/blueprint2')
    bp3 = Blueprint('blueprint3',url_prefix='/blueprint3')
    group = BlueprintGroup(url_prefix='')
    group.blueprints = [bp,bp1,bp2,bp3]
    del group[2]
    assert group.blueprints == [bp,bp1,bp3]

# Generated at 2022-06-12 08:38:40.628764
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    import sanic.blueprints
    blueprint_group = BlueprintGroup(url_prefix="foo/bar")

    blueprint = sanic.Blueprint("my_blueprint", url_prefix="blueprint")

    blueprint_group.insert(0, blueprint)

    assert blueprint_group[0].url_prefix == "foo/bar/blueprint"


# Generated at 2022-06-12 08:38:51.326269
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    
    # testcase 1, insert a blueprint object into blueprint group object
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.insert(0, bp1)
    bpg.insert(1, bp2)

    assert(bpg[0] is bp1 and bpg[1] is bp2)
    assert(bpg.version == "v1" and bpg.url_prefix == "/api" and bpg.strict_slashes == None)
    
    # testcase 2, insert a non-blueprint object into blueprint group object
    bpg.insert(0, 1)

# Generated at 2022-06-12 08:38:53.660454
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprints = [sanic.Blueprint("bp1", url_prefix="bp1"), sanic.Blueprint("bp2", url_prefix="bp2")]
    bpg = BlueprintGroup()
    bpg._blueprints = blueprints
    assert len(bpg) == 2

# Unit Test for Blueprint Group Methods to turn it into an iterable object

# Generated at 2022-06-12 08:38:58.912791
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bpGroup = BlueprintGroup(url_prefix='/api')
    bpGroup.append(bp1)
    bpGroup.append(bp2)
    bpGroup[1] = bp3
    assert bpGroup[1] == bp3
    assert bpGroup[0] == bp1
    assert bpGroup[2] != bp3


# Generated at 2022-06-12 08:39:04.542866
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    url_prefix = "/users"
    version = "v1"
    strict_slashes = True

    bpg = BlueprintGroup(
        url_prefix=url_prefix, version=version, strict_slashes=strict_slashes
    )

    assert bpg.url_prefix == url_prefix
    assert bpg.version == "v1"
    assert bpg.strict_slashes == strict_slashes



# Generated at 2022-06-12 08:39:12.851069
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')

    bpg = BlueprintGroup()
    bpg.append(bp1)

    # Assert if the bp1 is attached to the group
    assert bpg[0] == bp1
    assert len(bpg) == 1

    # Assert if we can update the item with new item
    bpg[0] = bp2
    assert bpg[0] == bp2
    assert len(bpg) == 1

    # Assert if we can update the item with new item
    bpg[0] = bp3
    assert bpg[0] == bp3
    assert len

# Generated at 2022-06-12 08:40:25.323148
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    """
    Test for Method `append` of BlueprintGroup class
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    assert len(bpg.blueprints) == 1
    assert bpg.blueprints[0] == bp1
    bpg.append(bp2)
    assert len(bpg.blueprints) == 2
    assert bpg.blueprints[1] == bp2


# Generated at 2022-06-12 08:40:33.705695
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    b1 = Blueprint("b1", url_prefix="/b1")
    b2 = Blueprint("b2", url_prefix="/b2")

    bg = BlueprintGroup(
        url_prefix="/url_prefix", version="v1", strict_slashes=True
    )

    bg.append(b1)
    bg.append(b2)

    # Iteration over Blueprint Group
    bg_iterator = iter(bg)

    assert next(bg_iterator) == b1
    assert next(bg_iterator) == b2

    try:
        next(bg_iterator)
    except StopIteration:
        pass
    else:
        raise



# Generated at 2022-06-12 08:40:42.762064
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    """
    Unit test case for BlueprintGroup class's __len__ method.
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    assert len(bpg) == 0
    bpg.append(bp1)
    assert len(bpg) == 1
    bpg.append(bp2)
    assert len(bpg) == 2
    bpg.append(bp3)
    assert len(bpg) == 3
    bpg.append(bp4)
    assert len

# Generated at 2022-06-12 08:40:47.003573
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    group = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    assert group.url_prefix == "/api"
    assert group.version == "v1"

# Generated at 2022-06-12 08:40:56.204727
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup('bpg', url_prefix='/bpg')

    bpg.append(bp1)
    bpg.append(bp2)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        assert True

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')
