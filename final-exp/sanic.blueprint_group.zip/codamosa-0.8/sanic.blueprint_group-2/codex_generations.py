

# Generated at 2022-06-12 08:31:08.515893
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    """
    Test case for method BlueprintGroup.__setitem__
    """
    blueprint_group = BlueprintGroup()
    blueprint = Blueprint('bp1', url_prefix='/bp1')
    blueprint_group.__setitem__(0, blueprint)
    assert blueprint_group[0] == blueprint



# Generated at 2022-06-12 08:31:18.832425
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    import random
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup()
    blueprint_list = [bp1, bp2, bp3, bp4]
    bpg._blueprints = blueprint_list
    assert len(bpg) == len(blueprint_list)
    rnd_i = random.randint(0, len(blueprint_list) - 1)
    rnd_bp = blueprint_list[rnd_i]
    assert bpg[rnd_i] == rnd_bp

# Generated at 2022-06-12 08:31:24.454852
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    group = BlueprintGroup()
    group.append(bp3)
    group[0] = bp4
    assert group[0] == bp4


# Generated at 2022-06-12 08:31:33.920475
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    # If a Blueprint is created with out a prefix or version,
    # the blueprint group should be able to set those values.
    bp1 = Blueprint('bp1')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)

    assert bp1.url_prefix == "/api/bp1"
    assert bp1.version == "v1"
    assert bp1.strict_slashes is None

    # If the blueprint has a version in it, it should be untouched by the
    # blueprint group.
    bp2 = Blueprint('bp2', url_prefix="/bp2", version="v2")
    bpg.append(bp2)

    assert bp2.url_prefix == "/api/bp2"
    assert bp2.version == "v2"

# Generated at 2022-06-12 08:31:46.766011
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)

    bpg.insert(0,bp3)
    assert bpg[0].name == "bp3"
    assert bpg[1].name == "bp1"

    bpg.insert(1,bp4)
    assert bpg[1].name == "bp4"

    # Test insert at end of list

# Generated at 2022-06-12 08:31:57.357463
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    group = BlueprintGroup('/api')

    group.extend([bp1, bp2])
    group.insert(2, bp3)
    group.insert(1, bp4)

    assert len(group) == 4

    assert group[0].url_prefix == '/api/bp1'
    assert group[1].url_prefix == '/api/bp4'
    assert group[2].url_prefix == '/api/bp3'

# Generated at 2022-06-12 08:32:08.173296
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')
    bp7 = Blueprint('bp7', url_prefix='/bp7')
    bp_group = BlueprintGroup()
    bp_group.append(bp1)
    bp_group.append(bp2)
    assert bp_group[0] == bp1
    assert bp_group[1] == bp2
    bp_

# Generated at 2022-06-12 08:32:15.376991
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg[0]
    del bpg[0]
    print(bpg)
    assert len(bpg) == 1 and bpg[0] == bp2

# Generated at 2022-06-12 08:32:21.409110
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    bp_list = [bp3, bp4]
    i = 0

# Generated at 2022-06-12 08:32:29.693206
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    group = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    group.insert(1, bp2)
    group.insert(0, bp1)
    assert group.blueprints[0].url_prefix == "/api/bp1"
    assert group.blueprints[1].url_prefix == "/api/bp2"
    assert group.blueprints[2].url_prefix == "/api/bp3"

# Generated at 2022-06-12 08:32:42.586038
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()

    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert bpg.index(bp1) == 0
    assert bpg.index(bp2) == 1
    bpg.insert(0, bp2)
    assert bp2 == bpg[0]
    assert bpg.index(bp2) == 0
    assert bpg.index(bp1) == 1


# Generated at 2022-06-12 08:32:47.822956
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    """
    Test the __delitem__ of Blueprint Group
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2)
    del bpg[1]

    assert len(bpg.blueprints) == 1


# Generated at 2022-06-12 08:32:53.803352
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    
    bpg = BlueprintGroup()

    bpg.append(bp1)
    bpg.append(bp2)

    bpg[0] = bp2

    assert bpg[0].name == 'bp2'


# Generated at 2022-06-12 08:33:01.886677
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bp3 = sanic.Blueprint('bp3', url_prefix='/bp4')
    group = BlueprintGroup(bp3, url_prefix="/api", version="v1")


    assert len(group) == 1
    group.insert(0,bp1)
    assert len(group) == 2


# Generated at 2022-06-12 08:33:07.600319
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    from sanic.blueprints import Blueprint

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bpg) == 2
    del bpg[0]
    assert len(bpg) == 1



# Generated at 2022-06-12 08:33:11.013360
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    obj = BlueprintGroup()
    try:
        obj.__delitem__(0)
    except IndexError:
        pass
    else:
        assert False, 'Unexpected behavior'


# Generated at 2022-06-12 08:33:16.899341
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-12 08:33:26.633123
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    """
    Unit test for `BlueprintGroup.__iter__` method.
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2, url_prefix="/api")

    assert group._url_prefix is not None, "URL prefix is not set"
    assert len(list(group)) == 2, "Blueprint Group length is incorrect"
    assert bp1 in list(group), "Blueprint1 is not a part of the group"
    assert bp2 in list(group), "Blueprint2 is not a part of the group"


# Generated at 2022-06-12 08:33:34.697745
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    """
    Unit test for method insert of class BlueprintGroup
    """
    # create the app
    app = sanic.Sanic()

    # Blueprint Group
    bp = Blueprint("bp1", url_prefix="/bp1", version="1.0")
    bpg = BlueprintGroup("/bpg", version="1.1")

    # Register the Blueprint Group
    app.blueprint(bpg)

    # Perform the test
    bpg.insert(0, bp)

    # Verify the results
    assert bpg == [bp], "Incorrect Blueprint Group result"

# Generated at 2022-06-12 08:33:41.918667
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)
    assert next(iter(group)) == bp1
    assert next(iter(group)) == bp2
    assert list(iter(group)) == [bp1, bp2]


# Generated at 2022-06-12 08:33:51.692397
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg[0] == bp1
    assert bpg[1] == bp2


# Generated at 2022-06-12 08:34:01.647441
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bp3 = sanic.Blueprint('bp3', url_prefix='/bp4')

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)


# Generated at 2022-06-12 08:34:05.555019
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    # Create Blueprint 1
    bp1 = Blueprint('bp1', url_prefix='/bp1')

    # Create Blueprint 2
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    # Create Blueprint Group
    bpg = BlueprintGroup(url_prefix='/api', version='v1')

    # Create blueprint group dynamically and add blueprint 1
    bpg.append(bp1)

    # Assert that blueprint 1 is present inside blueprint group
    assert bp1 in bpg.blueprints

    # Create blueprint group dynamically and add blueprint 2
    bpg.append(bp2)

    # Assert that blueprint 2 is present inside blueprint group
    assert bp2 in bpg.blueprints


# Generated at 2022-06-12 08:34:16.155110
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = sanic.Blueprint('bp1')
    bp2 = sanic.Blueprint('bp2')

    bpg = BlueprintGroup()
    assert bpg._url_prefix is None
    assert bpg._version is None
    assert bpg._strict_slashes is None
    assert bpg._blueprints == []
    assert bpg.blueprints == []

    bpg = BlueprintGroup(url_prefix='/api')
    assert bpg._url_prefix == '/api'
    assert bpg._version is None
    assert bpg._strict_slashes is None
    assert bpg._blueprints == []
    assert bpg.blueprints == []

    bpg = BlueprintGroup(url_prefix='/api', version='v1')
    assert bpg._url_prefix == '/api'
    assert bpg._

# Generated at 2022-06-12 08:34:26.052003
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    @sanic.blueprint(url_prefix="/v1")
    def bp1(request):
        pass

    @sanic.blueprint(url_prefix="/v2")
    def bp2(request):
        pass

    bpg = BlueprintGroup(url_prefix="/top_blueprint")

    assert bpg == [(bp1, bp2)]

    bpg.insert(0, bp2)

    assert bpg == [(bp2, bp1, bp2)]

    bpg.insert(100, bp1)

    assert bpg == [(bp2, bp1, bp2, bp1)]

    bpg.insert(-100, bp2)

    assert bpg == [(bp2, bp2, bp1, bp2, bp1)]


# Generated at 2022-06-12 08:34:29.638433
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    # Arrange
    blueprint_group = BlueprintGroup()

    # Act
    blueprint_group[0] = Blueprint('bp1')

    # Assert
    assert len(blueprint_group) == 1
    assert isinstance(blueprint_group[0], Blueprint)


# Generated at 2022-06-12 08:34:36.994059
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    bpg.__delitem__(1)
    assert bpg._blueprints == [bp1, bp3, bp4], "test_BlueprintGroup___delitem__"


# Generated at 2022-06-12 08:34:46.032683
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup('/api', version="v1")
    bpg.extend([bp3, bp4])
    assert bpg._blueprints == [bp3, bp4]
    for _bp in bpg:
        if _bp in [bp3, bp4]:
            assert _bp.url_prefix == f'/api/{_bp.name}'


# Generated at 2022-06-12 08:34:56.597174
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bp3 = sanic.Blueprint('bp3', url_prefix='/bp3')
    bp4 = sanic.Blueprint('bp4', url_prefix='/bp4')

    bp = BlueprintGroup()
    bp.append(bp1)
    bp.append(bp2)
    bp.append(bp3)
    bp.append(bp4)

    assert bp[1] != bp[0]
    assert bp[1] == bp2
    assert bp[1:] == bp[1:][0:3]

# Generated at 2022-06-12 08:35:02.890629
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = BlueprintGroup()

    group.append(bp1)
    group.append(bp2)

    result = next(iter(group))
    assert result == bp1

    result = next(iter(group))
    assert result == bp2


# Generated at 2022-06-12 08:35:22.269784
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    # test it can insert value correctly
    temp_blueprint = Blueprint("bp")
    bpg = BlueprintGroup("/api/v1")
    bpg.insert(0, temp_blueprint)
    assert bpg[0] == temp_blueprint

    # test if it can insert multiple values correctly
    bpg_1 = BlueprintGroup("/api/v1")
    bpg_1.insert(0, temp_blueprint)
    bpg_1.insert(1, temp_blueprint)
    assert bpg_1[0] == temp_blueprint
    assert bpg_1[1] == temp_blueprint



# Generated at 2022-06-12 08:35:29.807333
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)
    class TestMiddleware():
        def __init__(self):
            self.applied = False
        def __call__(self, request):
            self.applied = True

    middleware = TestMiddleware()
    group.middleware(middleware)

    assert middleware.applied is False
    assert len(bp1.middlewares['request']) == 1
    assert len(bp2.middlewares['request']) == 1

# Generated at 2022-06-12 08:35:37.504230
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    app = sanic.Sanic(__name__)
    app.config.from_object(__name__)
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    g1 = BlueprintGroup()
    g1.insert(0, bp1)
    g1.insert(0, bp2)
    assert g1[0] == bp2
    assert g1[1] == bp1
    assert len(g1) == 2



# Generated at 2022-06-12 08:35:42.588813
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bp3 = Blueprint('bp3')
    bpg[1] = bp3
    assert bpg[1] is bp3


# Generated at 2022-06-12 08:35:49.494932
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')

    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix = "/api", version = "v1")
    bpg.append(bp1)
    bpg.append(bp2)

    bpg2 = BlueprintGroup(url_prefix = "/api", version = "v1")
    bpg2.append(bp3)
    bpg2.append(bp4)
    bpg2.append(bpg)

    assert bpg2[0].url_prefix == "/api/bp4"

# Generated at 2022-06-12 08:35:52.813915
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    try:
        group = BlueprintGroup()
        group.__delitem__(0)
    except Exception as e:
        assert False, "Exception {}".format(e)
    assert True, "Pass"


# Generated at 2022-06-12 08:36:04.021998
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    from sanic.blueprints import Blueprint

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    
    # indexing
    assert bpg[0] == bp3
    assert bpg[1] == bp4

    # insert
    bpg.insert(0, bp1)
   

# Generated at 2022-06-12 08:36:14.667770
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Sanic is built on asyncio, so you need to use the new-style coroutines.
    This means prefixing your coroutine definitions with ``async def`` instead of
    @asyncio.coroutine.
    """
    def middleware_one(request):
        pass

    def middleware_two(request):
        pass

    def middleware_three(request):
        pass

    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bp3 = Blueprint('bp3')
    bp4 = Blueprint('bp4')

    bpg = BlueprintGroup(bp1, bp2)
    bpg2 = BlueprintGroup(bp3, bpg)

    # Apply middleware on BlueprintGroups
    bpg.middleware(middleware_one)
    bpg.middleware

# Generated at 2022-06-12 08:36:24.517113
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp_test1 = Blueprint("test1", url_prefix="/test1")
    bp_test2 = Blueprint("test2", url_prefix="/test2")
    grp1 = BlueprintGroup("/api", version="v1")
    grp2 = BlueprintGroup("/api", version="v1", strict_slashes=True)
    grp3 = BlueprintGroup("/api", version="v1", strict_slashes=False)
    grp4 = BlueprintGroup("/api", version="v1", strict_slashes=False)

    for bp in [bp_test1, bp_test2]:
        grp1.append(bp)

    for bp in [bp_test1, bp_test2]:
        grp2.append(bp)


# Generated at 2022-06-12 08:36:36.648386
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """ This class is actually a mock for BlueprintGroup class and we need to
    test that the middleware method of this class works.
    """
    # This class is actually a mock for BlueprintGroup class and we need to
    # test that the middleware method of this class works.
    class MockBlueprintGroup(BlueprintGroup):
        def __init__(self):
            super().__init__()
            self.middlewares = []

        def append(self, value: "sanic.Blueprint") -> None:
            self.blueprints.append(value)

        def middleware(self, *args, **kwargs):
            def register_middleware_for_blueprints(fn):
                self.middlewares.append((fn, args, kwargs))