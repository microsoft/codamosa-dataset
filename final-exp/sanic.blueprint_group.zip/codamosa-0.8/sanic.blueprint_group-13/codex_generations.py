

# Generated at 2022-06-12 08:31:10.067210
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic("test_BlueprintGroup_middleware")
    
    bp1 = Blueprint("test_BlueprintGroup_middleware", url_prefix="/bp1")
    bp2 = Blueprint("test_BlueprintGroup_middleware", url_prefix="/bp2")
    
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware("request")
    def test(request):
        pass

    assert bp1.middlewares["request"] == [test]
    assert bp2.middlewares["request"] == [test]


# Generated at 2022-06-12 08:31:19.596774
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # pylint: disable=C0111
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)
    # pylint: disable=W0212
    assert not bp1.middlewares._registrations['request']
    assert not bp2.middlewares._registrations['request']
    @group.middleware('request')
    def request_middleware(request):
        pass
    assert len(bp1.middlewares._registrations['request']) == 1
    assert len(bp2.middlewares._registrations['request']) == 1
    assert request_middleware in bp1.middlewares._registrations['request']

# Generated at 2022-06-12 08:31:27.106149
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp = Blueprint('bp')

    # Test for BlueprintGroup.middleware
    # with no callable passed to it and no @
    assert bp.middleware('request')(lambda x: x) in bp.handlers['request']
    assert bp.middleware('request')(lambda x: x) in bp.handlers['request']

    # Test for BlueprintGroup.middleware
    # with no callable passed to it
    # and with @ at the beginning
    assert bp.middleware('request')(lambda x: x) in bp.handlers['request']
    assert bp.middleware('request')(lambda x: x) in bp.handlers['request']

# Generated at 2022-06-12 08:31:34.752644
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg.blueprints) == 2
    assert len(bpg.blueprints[0].middlewares) == 0
    assert len(bpg.blueprints[1].middlewares) == 0

    # Test if a method of class BlueprintGroup can be used as a decorator
    @bpg.middleware
    async def middleware(request):
        pass
    assert len(bpg.blueprints[0].middlewares) == 1
    assert len(bpg.blueprints[1].middlewares) == 1
    assert bpg.blue

# Generated at 2022-06-12 08:31:47.140115
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/bpg")

    # Create a Simple Middleware for the BlueprintGroup
    @bpg.middleware('request')
    async def bpg_middleware(request):
        print('applied on Blueprint Group : bpg')

    assert len([*bpg.blueprints[0].middlewares['request']]) == 1

    # Create a middleware without @middleware

# Generated at 2022-06-12 08:31:57.391468
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class WrapTest(sanic.response.HTTPResponse):
        pass
    class WrapTestMiddleware:
        @staticmethod
        async def handle_request(request):
            return WrapTest(text="test")
    class Blueprint1(sanic.Blueprint):
        pass
    bp1 = Blueprint1("test1")
    @bp1.route("/test1")
    async def test1(request):
        return text("test1")
    class Blueprint2(sanic.Blueprint):
        pass
    bp2 = Blueprint2("test2")
    @bp2.route("/test2")
    async def test2(request):
        return text("test2")
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

# Generated at 2022-06-12 08:32:08.211689
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class TestApp(sanic.Sanic):
        def __init__(self):
            super().__init__()
            self.blueprints = []

        def register_blueprint(self, bluprint, **options):
            self.blueprints.append(bluprint)

    blueprints = [sanic.Blueprint("test1", url_prefix="/test1"),
                  sanic.Blueprint("test2", url_prefix="/test1")]

    group = BlueprintGroup("/test2/test3")
    for blueprint in blueprints:
        group.append(blueprint)

    @group.middleware("request")
    async def simple_middleware(request):
        print("ok")

    app = TestApp()
    app.blueprint(group)


# Generated at 2022-06-12 08:32:19.409879
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class TestMiddleware:

        def __init__(self, app: "sanic.Sanic", *args, **kwargs):
            pass

        def __call__(self, request):
            return sanic.response.text("Middleware Test")

    bp1 = Blueprint("TestBP1", "/test1")
    bp2 = Blueprint("TestBP2", "/test2")
    bp3 = Blueprint("TestBP3", "/test3")

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware
    def test_middleware(request):
        return sanic.response.text("Middleware Test")


# Generated at 2022-06-12 08:32:26.065803
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic('blueprint_group')
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    class TestMiddleware(BaseHTTPMiddleware):
        def __call__(self, request, call_next):
            request['bp_name'] = 'dummy'
            return call_next(request)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        pass

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        pass



# Generated at 2022-06-12 08:32:33.400896
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix='/api', version='v1')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    @bp3.route('/')
    async def bp3_route(request):
        return text('bp3')


# Generated at 2022-06-12 08:32:45.660669
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")

    group = Blueprint.group(bp1, bp2)

    @group.middleware("request")
    def test_middleware_group():
        pass

    assert len(bp1.middlewares["request"]) == 1
    assert len(bp2.middlewares["request"]) == 1
    assert len(group.middlewares["request"]) == 0

    # If BlueprintGroup has a middleware, it should
    # not be added to the blueprints in the group but
    # to the group itself
    @group.middleware("request")
    def test_middleware_blueprint_group():
        pass

    assert len(group.middlewares["request"]) == 1



# Generated at 2022-06-12 08:32:56.754284
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic("test_BlueprintGroup_middleware")
    bp1 = sanic.Blueprint("bp1")
    bp2 = sanic.Blueprint("bp2")

    bp_group = sanic.blueprints.BlueprintGroup()
    bp_group.append(bp1)
    bp_group.append(bp2)

    @bp1.listener("after_server_start")
    async def bp1_after_server_start(app, loop):
        print("bp1_after_server_start")

    @bp2.listener("after_server_stop")
    async def bp2_after_server_stop(app, loop):
        print("bp2_after_server_stop")


# Generated at 2022-06-12 08:33:04.035512
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # start the sanic server
    app = sanic.Sanic('sanic-BlueprintGroup')
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    group = BlueprintGroup()

    group.append(bp1)
    group.append(bp2)

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/')
    async def bp2_route(request):
        return text('bp2')


# Generated at 2022-06-12 08:33:04.616656
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    pass

# Generated at 2022-06-12 08:33:09.613225
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()
    bpg.extend([bp1, bp2])
    bpg.middleware(lambda x: x, 'request')

    assert bp1.middlewares['request'][0] == bp2.middlewares['request'][0]


# Generated at 2022-06-12 08:33:14.788581
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware('request')
    async def group_middleware(request):
        pass

    assert len(bp1.request_middleware) == 1
    assert len(bp2.request_middleware) == 1

# Generated at 2022-06-12 08:33:26.368611
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    bpg2 = BlueprintGroup(bpg, bp2, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        request['bp1_only'] = True
        assert 'bp1_only' in request


# Generated at 2022-06-12 08:33:32.347957
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class App(sanic.Sanic):
        pass
    app = App()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpGroup1 = BlueprintGroup(bp1,bp2,url_prefix='/bpgroup1')
    bpGroup2 = BlueprintGroup(bp3,bp4,url_prefix='/bpgroup2')
    bpGroup = BlueprintGroup(bpGroup1,bpGroup2,url_prefix='/bpgroup')
    

# Generated at 2022-06-12 08:33:44.037465
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    bp1 = Blueprint("testgroup_bp1", url_prefix="/testgroup_bp1")
    bp2 = Blueprint("testgroup_bp2", url_prefix="/testgroup_bp2")

    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)

    is_middleware_applied = False

    @group.middleware("request")
    async def test_group_middleware(request):
        nonlocal is_middleware_applied
        is_middleware_applied = True

    @bp1.route("/")
    async def test1(request):
        return text("bp1")

    @bp2.route("/")
    async def test2(request):
        return text("bp2")


# Generated at 2022-06-12 08:33:53.881564
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic.blueprints import Blueprint
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp1, bp2, bp3, bp4)

    @bpg.middleware('request')
    async def request_middleware(request):
        print('request_middleware applied for all blueprints')

    @bpg.middleware('response')
    async def response_middleware(request, response):
        print('response_middleware applied for all blueprints')


# Generated at 2022-06-12 08:34:07.809427
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    async def fn1(request):

        return text(1, status=200)

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup('bpg', url_prefix='/bpg')
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware('request')
    async def middleware_for_bp_group_1(request):

        request['data'] = 'middleware_for_bp_group_1'
        return await fn1(request)

    assert len(bp1.middlewares.get('request')) == 1
    assert len(bp2.middlewares.get('request')) == 1
    assert bp1.middlew

# Generated at 2022-06-12 08:34:17.825368
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic('test_BlueprintGroup_middleware')
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    # each middleware is once that means only one time will be called
    middleware_called = [0, 0, 0]

    @bpg.middleware
    async def test_middleware(request):
        middleware_called[0] += 1

    @bp1.middleware
    async def bp1_middleware(request):
        middleware_called[1] += 1

    @bp2.middleware
    async def bp2_middleware(request):
        middleware_called[2] += 1


# Generated at 2022-06-12 08:34:26.727660
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @chorder.middleware("request")
    async def test_blueprint_middleware(request):
        print("Request middleware applied on chorder blueprint")

    @chorder.middleware("response")
    async def test_blueprint_response(request, response):
        print("Response middleware applied on chorder blueprint")

    app.blueprint(chorder)

    client = app.test_client

    @app.route('/', methods=['GET'])
    async def test_blueprint_middleware(request):
        return json(dict())

    response = client.get('/chorder/test/')
    assert response.status == 200

    @app.websocket('/chorder/test/ws')
    async def test_blueprint_ws_middleware(request, ws):
        ws.send('test')

# Generated at 2022-06-12 08:34:35.253573
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    @bpg.middleware('request')
    async def new_middleware_test(request):
        print('common middleware applied for both bp1 and bp2')


    assert bp3.middlewares['request'][0].__name__ == 'new_middleware_test'

# Generated at 2022-06-12 08:34:35.765200
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    pass

# Generated at 2022-06-12 08:34:45.745340
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """Test Middleware decorator of BlueprintGroup class"""
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)

    @group.middleware('request')
    async def test_middleware(request):
        bp1.middlewares[request]['request'].append('test_middleware')

    @bp1.route('/')
    async def index(request):
        return text('index')

    @bp2.route('/')
    async def index(request):
        return text('index')

    request, response = sanic.app.test_client.get(bp1.url_for('index'))

    assert(response.text == 'index')
   

# Generated at 2022-06-12 08:34:56.401529
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Given
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    def _middleware_callback(request):
        return text('middleware_callback')
    # When
    bpg.middleware(_middleware_callback)

    # Then
    assert len(bpg.blueprints) == 2
    assert len(bpg.blueprints[0].middlewares) == 1
    assert len(bpg.blueprints[1].middlewares) == 1
    assert _middleware_callback in bpg.blueprints[0].middlewares.keys()
    assert _middleware

# Generated at 2022-06-12 08:35:00.583511
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @sanic.blueprint.Blueprint.middleware('request')
    async def test_middleware(request):
        print('test middleware on BlueprintGroup')
    assert hasattr(sanic.blueprint.Blueprint, 'middleware')


# Generated at 2022-06-12 08:35:10.894932
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    test_app = sanic.Sanic()
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bp3 = Blueprint("bp3", url_prefix="/sub")
    bpg = BlueprintGroup("/api", 2)
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)

    @bp1.middleware("request")
    async def bp1_middleware(request):
        print("bp1")

    @bp2.middleware("request")
    async def bp2_middleware(request):
        print("bp2")

    @bp3.middleware("request")
    async def bp3_middleware(request):
        print("bp3")


# Generated at 2022-06-12 08:35:20.747304
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        pass

    @bp2.middleware('request')
    async def bp2_only_middleware(request):
        pass

    @bpg.middleware('request')
    async def bp_group_middleware(request):
        pass

    assert len(bp1.middlewares['request']) == 2
    assert len(bp2.middlewares['request']) == 2


# Generated at 2022-06-12 08:35:37.779082
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class MockMiddleware:
        def __init__(self):
            self.args = []
            self.kwargs = []

        def __call__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    @sanic.blueprints.Blueprint("bp1")
    def bp1():
        pass

    @sanic.blueprints.Blueprint("bp2")
    def bp2():
        pass

    mock_middleware = MockMiddleware()

    bpg = BlueprintGroup("bpg")
    bpg.append(bp1)
    bpg.append(bp2)

    bp1.middleware(mock_middleware)
    bp2.middleware(mock_middleware)

    assert bp1.middlewares[0].args

# Generated at 2022-06-12 08:35:42.849134
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()

    @app.middleware('request')
    async def app_middleware(request):
        # Common middleware applied to each blueprint
        pass

    @app.middleware('response')
    async def app_after_middleware(request, response):
        # Common middleware applied to each blueprint
        pass

    @app.route('/')
    async def hello(request):
        pass

    with app.test_client() as client:
        resp = client.get('/')
        assert resp.status == 200

    # Create the Blueprint Groups
    bpg1 = BlueprintGroup(url_prefix='/bpg1', version='v1')
    bpg2 = BlueprintGroup(url_prefix='/bpg2', version='v2')

    # Create the Blueprint inside the Blueprint Group
    bp1

# Generated at 2022-06-12 08:35:50.477305
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp = Blueprint("bp", url_prefix="/api")
    bp1 = Blueprint("bp1", url_prefix="/blueprint1")
    bp2 = Blueprint("bp2", url_prefix="/blueprint2")
    bpg = BlueprintGroup(bp1, bp2)
    bpg.middleware(sanic.request_middleware)
    assert len(bp1.middlewares) == 1
    assert len(bp2.middlewares) == 1
    assert bp1.middlewares[0][0] == sanic.request_middleware
    assert bp2.middlewares[0][0] == sanic.request_middleware

# Generated at 2022-06-12 08:36:00.922637
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    # Create dummy app instance and blueprint object
    bp = Blueprint("dummy_bp", url_prefix="")
    dummy_app = sanic.Sanic()
    
    # Create Blueprint Group and register dummy Blueprint
    dummy_blueprint_group = BlueprintGroup()
    dummy_blueprint_group.append(bp)

    # Method middleware does not modify the BlueprintGroup object
    assert not hasattr(dummy_blueprint_group, "middleware")

    # Check Blueprint middleware method has been invoked
    # and a new middleware has been registered
    assert not hasattr(bp, "middleware")
    dummy_blueprint_group.middleware(dummy_app)(dummy_app.response)
    assert hasattr(bp, "middleware")
    assert len(bp.middlewares["request"]) == 1

# Generated at 2022-06-12 08:36:08.829813
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """Unit test for method middleware of class BlueprintGroup."""
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bp3 = Blueprint('bp3')
    bp4 = Blueprint('bp4')
    bp5 = Blueprint('bp5')

    bp_group = BlueprintGroup()
    bp_group.append(bp1)
    bp_group.append(bp2)
    bp_group.append(BlueprintGroup(bp3, bp4))
    bp_group.append(bp5)

    @bp_group.middleware('request')
    async def test_request_middleware(request):
        pass

    @bp_group.middleware('response')
    async def test_response_middleware(request, response):
        pass


# Generated at 2022-06-12 08:36:17.303462
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Arrange
    bp1 = sanic.Blueprint("bp1", url_prefix="bp1")
    bp2 = sanic.Blueprint("bp2", url_prefix="bp2")
    group = BlueprintGroup(bp1, bp2)

    @bp1.middleware("request")
    async def bp1_middleware(request):
        pass

    @bp2.middleware("request")
    async def bp2_middleware(request):
        pass

    @group.middleware("request")
    async def bp3_middleware(request):
        pass

    # Act
    list(group.blueprints[0].middleware["request"])
    list(group.blueprints[1].middleware["request"])

    # Assert

# Generated at 2022-06-12 08:36:23.888181
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    bp1 = sanic.Blueprint("bp1", url_prefix="bp1")
    bp2 = sanic.Blueprint("bp2", url_prefix="bp2")

    bpg = BlueprintGroup(url_prefix="api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)

    # Default Middleware
    @bpg.middleware("request")
    def test_middleware(request):
        return text("Hello")

    assert len(bp1.middlewares.get("request")) == 1
    assert len(bp2.middlewares.get("request")) == 1



# Generated at 2022-06-12 08:36:34.777692
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    group = BlueprintGroup.group(bp1, bp2)
    subgroup = BlueprintGroup.group(bp3, bp4)
    group.append(subgroup)
    @group.middleware('request')
    async def test_middleware(request):
        pass
    assert bp1.middleware_stack == [test_middleware]


# Generated at 2022-06-12 08:36:45.803555
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    assert BlueprintGroup.middleware.__module__ == \
           'sanic.blueprints'
    assert BlueprintGroup.middleware.__name__ == 'middleware'
    assert BlueprintGroup.middleware.__qualname__ == \
           'BlueprintGroup.middleware'

# Generated at 2022-06-12 08:36:56.133963
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group = BlueprintGroup(url_prefix='/v1')
    blueprint_group.append(Blueprint('/b1'))
    blueprint_group.append(Blueprint('/b2'))

    @blueprint_group.middleware('request')
    async def bp_middleware(request):
        return text('bp_middleware')

    assert len(blueprint_group.blueprints) == 2
    for blueprint in blueprint_group.blueprints:
        assert len(blueprint.middlewares) == 1
        assert blueprint.middlewares[0][0] == bp_middleware
        assert blueprint.middlewares[0][1] == 'request'
        assert blueprint.middlewares[0][2] == {}


# Generated at 2022-06-12 08:37:16.303559
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @middleware_class()
    class MiddleWareClass:
        pass

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)
    
    # Test the middleware decorator with a function
    def function_middle_ware():
        pass
    register_middleware_for_blueprints = group.middleware(function_middle_ware)
    assert bp1.middleware_functions[0] == function_middle_ware

    # Test the middleware decorator with a function and without arguments
    def function_middle_ware_without_arguments():
        pass

# Generated at 2022-06-12 08:37:27.365895
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    from sanic.app import Sanic
    from sanic.blueprints import Blueprint

    # Create an application object
    app = Sanic()

    # Create a Blueprint group
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)

    # Apply a simple middleware that uses the "request" to
    # print wheter they are applied on the Blueprint or BluePrint Group
    @group.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    # Make sure to apply the middleware on the Blueprint and not Blueprint
    # Group to ensure that the middleware above must be applied on all
    # of

# Generated at 2022-06-12 08:37:38.491715
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Test case for method middleware of class BlueprintGroup.
    """
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")

    group = BlueprintGroup()
    group.append(bp3)
    group.append(bp4)

    @bp1.middleware("request")
    async def bp1_only_middleware(request):
        """
        Mock Middleware to be registered with Blueprint
        """
        print("applied on Blueprint : bp1 Only")


# Generated at 2022-06-12 08:37:49.550562
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Unit test for method middleware of class BlueprintGroup
    :return: assertion failure or success
    """
    # create an instance of BlueprintGroup
    bpg = BlueprintGroup()
    # create an instance of Blueprint
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    # add blueprints in blueprint group
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    # assign middleware

# Generated at 2022-06-12 08:37:58.614795
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic(__name__)
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2,url_prefix='/api', version='v1')
    @bpg.middleware('request')
    async def bpg_request_middleware(request):
        print('i am a bpg request middleware')

    assert len(bp1.middleware) == 1
    assert len(bp2.middleware) == 1
    assert len(bpg.middleware) == 0


# Generated at 2022-06-12 08:38:08.974051
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Testing the correctness of the middleware method of the BlueprintGroup class.
    This method has been abstracted to simplify the testing of the
    blueprint group.
    """
    blueprint = Blueprint('bp1', url_prefix='/bp1')
    blueprint_group = BlueprintGroup()
    blueprint_group.append(blueprint)

    @blueprint_group.middleware('request')
    async def middleware(request):
        return

    # Test for the correct type of the returned value.
    assert isinstance(middleware, partial)
    # Test for the correct number of stored middlewares.
    assert len(blueprint_group.blueprints[0]._middlewares) == 1
    # Test for the correct type of stored middlewares.

# Generated at 2022-06-12 08:38:17.694482
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    group = BlueprintGroup(bp1, bp2, url_prefix='/')

    @group.middleware('request')
    async def test_middleware(request):
        pass

    assert 'test_middleware_request' in [
        (m.name, m.version) for m in bp1.middlewares
    ]
    assert 'test_middleware_request' in [
        (m.name, m.version) for m in bp2.middlewares
    ]

# Generated at 2022-06-12 08:38:27.418787
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    group = Blueprint.group(bp1, bp2, url_prefix="/api")

    # create a new middleware
    @bp1.middleware("request")
    async def test_middleware(request):
        pass

    @group.middleware("request")
    async def test_middleware(request):
        pass

    assert test_middleware in group.blueprints[0].middlewares["request"]
    assert test_middleware in group.blueprints[1].middlewares["request"]
    assert test_middleware not in bp1.middlewares["request"]
    assert test_middleware not in bp2.middlewares["request"]



# Generated at 2022-06-12 08:38:39.258107
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Tests the middleware method of class `BlueprintGroup`
    """
    # Create a Basic Blueprint with a route
    bp1 = Blueprint('bp1', url_prefix='/bp1', strict_slashes=True)
    bp2 = Blueprint('bp2', url_prefix='/bp2', strict_slashes=True)
    bp3 = Blueprint('bp3', url_prefix='/bp3', strict_slashes=True)
    bp4 = Blueprint('bp4', url_prefix='/bp4', strict_slashes=True)

    bp5 = Blueprint('bp5', url_prefix='/bp5', strict_slashes=True)
    bp6 = Blueprint('bp6', url_prefix='/bp6', strict_slashes=True)


# Generated at 2022-06-12 08:38:49.866343
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic.blueprints import Blueprint

    b1 = Blueprint('b1')
    b2 = Blueprint('b2')
    b3 = Blueprint('b3')
    bg = BlueprintGroup()
    bg.append(b1)
    bg.append(b2)
    bg.append(b3)

    @bg.middleware
    async def b1_only_middleware(request):
        print('applied on Blueprint : b1 Only')

    @b2.middleware
    async def b2_only_middleware(request):
        print('applied on Blueprint : b2 Only')

    # Check that a middleware is applied to all the blueprints in the group
    assert len(b1.middlewares) == 2
    assert len(b2.middlewares) == 2