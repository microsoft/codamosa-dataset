

# Generated at 2022-06-12 08:31:00.897741
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = BlueprintGroup(bp1, bp2)

    @group.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')


# Generated at 2022-06-12 08:31:09.802557
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    import sanic.blueprints
    app = sanic.Sanic()
    b_1 = sanic.blueprints.Blueprint('b_1')
    b_2 = sanic.blueprints.Blueprint('b_2')
    bp_group = BlueprintGroup()
    bp_group.append(b_1)
    bp_group.append(b_2)
    bp_group.middleware(lambda request: None)()

    assert len(b_1.middlewares['request']) == 1
    assert len(b_2.middlewares['request']) == 1
    assert b_1.middlewares['request'][0].__name__ == '<lambda>'
    assert b_2.middlewares['request'][0].__name__ == '<lambda>'


# Generated at 2022-06-12 08:31:19.425132
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp1')
    bp4 = Blueprint('bp4', url_prefix='/bp2')

    bpgroup1 = BlueprintGroup(url_prefix='/bp')
    bpgroup1.append(bp1)
    bpgroup1.append(bp3)

    bpgroup2 = BlueprintGroup(url_prefix='/a')
    bpgroup2.append(bp2)
    bpgroup2.append(bp4)
    bpgroup2.append(bpgroup1)


# Generated at 2022-06-12 08:31:24.988700
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()

    b1 = Blueprint('b1')

    @b1.middleware('request')
    async def b1_only_middleware(request):
        print('applied on Blueprint : b1 Only')

    @b1.route('/')
    async def b1_route(request):
        return text('b1')

    b2 = Blueprint('b2')

    @b2.middleware('request')
    async def b2_only_middleware(request):
        print('applied on Blueprint : b2 Only')

    @b2.route('/')
    async def b2_route(request):
        return text('b2')

    group = Blueprint.group(b1, b2)


# Generated at 2022-06-12 08:31:30.612493
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic('Test App')
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    assert len(bpg) == 2
    assert bp1.blueprint_group == bpg
    assert bp2.blueprint_group == bpg
    assert bpg.blueprints[0] == bp1
    assert bpg.blueprints[1] == bp2
    assert bpg.version == 'v1'
    assert bpg.url_prefix == '/api'

# Generated at 2022-06-12 08:31:39.008549
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic(__name__)
    bp = Blueprint("Foo", url_prefix="/foo")
    bp2 = Blueprint("Bar", url_prefix="/bar")

    bpg = BlueprintGroup(bp, bp2)

    @bp.route("/")
    async def foo(request):
        return text("foo")

    @bp2.route("/")
    async def bar(request):
        return text("bar")

    @bpg.middleware("request")
    async def hello(request):
        print("hello")

    app.blueprint(bpg)
    request, response = app.test_client.get("/foo")
    assert response.status == 200

    request, response = app.test_client.get("/bar")
    assert response.status == 200

# Generated at 2022-06-12 08:31:49.196986
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # using this to test blueprintGroup.middleware()
    app = sanic.Sanic(name=__name__)

    bp1 = Blueprint('bp1', url_prefix='/bp1')

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    bp2 = Blueprint('bp2', url_prefix='/bp2')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    bp3 = Blueprint('bp3', url_prefix='/bp3')

# Generated at 2022-06-12 08:31:57.485538
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class CustomMiddleware:
        pass

    group = BlueprintGroup()

    blueprint = Blueprint("test_blueprint1", url_prefix="/test1")
    blueprint2 = Blueprint("test_blueprint2", url_prefix="/test2")

    group.append(blueprint)
    group.append(blueprint2)

    @group.middleware()
    def test_middleware():
        pass

    blueprint_middleware_fn = blueprint.middleware_functions[0]
    blueprint2_middleware_fn = blueprint2.middleware_functions[0]

    assert blueprint_middleware_fn.name == "test_middleware"
    assert blueprint2_middleware_fn.name == "test_middleware"

# Generated at 2022-06-12 08:32:08.282797
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Test case to show how to apply middleware to the Blueprint Group
    application. This is a test case to demonstrate how to apply middleware
    on a Blueprint Group
    """

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')


# Generated at 2022-06-12 08:32:19.133405
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Run unit test for BlueprintGroup.middleware method
    """

    @BlueprintGroup.middleware()
    async def bpg_middleware(request):
        assert request == 'request'

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    mw_list = bpg._blueprints[0].middleware_functions['request']
    assert callable(mw_list[0])

# Generated at 2022-06-12 08:32:27.354712
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # mocking empty blueprint object
    class Blueprint:
        def __init__(self):
            pass
        def middleware(self, fn, *args, **kwargs):
            pass

    # mocking blueprint group
    blueprint_group = BlueprintGroup()

    # mocking blueprint
    blueprint = Blueprint()
    blueprint_group.append(blueprint)

    # mocking mocked middleware function
    function = lambda request: True
    assert blueprint.middleware(function) == None
    assert blueprint_group.middleware(function) == function


# Generated at 2022-06-12 08:32:34.453026
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic("test_BlueprintGroup_middleware")
    blueprint1 = Blueprint("test_BlueprintGroup_middleware_bp1", url_prefix="/bp1")
    blueprint2 = Blueprint("test_BlueprintGroup_middleware_bp2", url_prefix="/bp2")

    @blueprint1.middleware("request")
    async def mw1(request):
        pass

    @blueprint1.middleware("request")
    async def mw2(request):
        pass

    @blueprint2.middleware("request")
    async def mw3(request):
        pass

    async def mw4(request):
        pass

    bp_group = BlueprintGroup()
    bp_group.append(blueprint1)
    bp_group.append(blueprint2)


# Generated at 2022-06-12 08:32:42.000245
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')

    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)

    @group.middleware('request')
    def group_middleware(request):
        pass

    assert bp1.middlewares['request']
    assert bp1.middlewares['request'] is bp2.middlewares['request']
    assert bp1.middlewares['request'] == [group_middleware]

# Generated at 2022-06-12 08:32:49.709742
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = sanic.Blueprint("bp1", url_prefix="/bp1")

    @bp1.middleware("request")
    async def middleware(request):
        print("applied on Blueprint : bp1 Only")

    group = BlueprintGroup()
    group.append(bp1)

    @group.middleware("request")
    async def group_middleware(request):
        print("common middleware applied for both bp1")

    bp1.middlewares  # list of middleware
    group.middlewares  # middlewares

# Generated at 2022-06-12 08:32:59.242534
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    def bp1_func(request):
        return text('bp1')

    def bp2_func(request):
        return text('bp2')

    bp1.add_route(bp1_func, '/')
    bp2.add_route(bp2_func, '/')

    @bp1.middleware('request')
    def bp1_only_middleware(request):
        print('bp1 only middleware')

    @bp2.middleware('request')
    def bp2_only_middleware(request):
        print('bp2 only middleware')


# Generated at 2022-06-12 08:33:05.651088
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')

    # Register a middleware on the Blueprint
    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')

    bpg1 = BlueprintGroup()
    bpg2 = BlueprintGroup()

    bpg2.append(bp1)
    bpg2.append(bp3)

    bpg1.append(bp2)
    bpg1.append(bpg2)

    # Register a middleware on the Blueprint Group

# Generated at 2022-06-12 08:33:14.643427
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)

    # We can use a decorator to add a middleware to the Blueprint Group
    @group.middleware('request')
    async def bp_group_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    # The middleware is now a part of all the blueprints
    assert bp1.middlewares['request'][0] == bp_group_middleware
    assert bp2.middlewares['request'][0] == bp_group_middleware


# Generated at 2022-06-12 08:33:26.250545
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    from unittest import TestCase
    from unittest.mock import patch
    from sanic import Blueprint
    from sanic.response import json

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    class TestBlueprintGroup(TestCase):

        @bp1.middleware('request')
        async def bp1_only_middleware(request):
            return json({'bp1_only_middleware': True})


# Generated at 2022-06-12 08:33:31.346890
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Sample Blueprint
    bp1 = Blueprint('bp1')
    bp1.middleware_list = []

    bpg = BlueprintGroup()
    bpg.append(bp1)

    @bpg.middleware('request')
    def group_middleware_handler(request):
        return True

    assert group_middleware_handler in bpg.blueprints[0].middleware_list

# Generated at 2022-06-12 08:33:43.303257
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic(__name__)

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    group = Blueprint.group(bp1, bp2)
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @group.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')


# Generated at 2022-06-12 08:33:55.484355
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Test method middleware of class BlueprintGroup
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix='/bpg')

    # Test when args[0] is callable
    @bpg.middleware()
    async def middleware():
        pass

    for blueprint in [bp1, bp2, bp3, bp4]:
        assert blueprint.middleware_functions == [middleware]

    # Test when args[0] is not callable

# Generated at 2022-06-12 08:34:07.509001
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')

    bpg1 = BlueprintGroup(bp3, bp4, url_prefix="/api/v1")
    bpg2 = BlueprintGroup(bp5, bp6, url_prefix="/api/v2")
    bpg = BlueprintGroup(bpg1, bpg2, url_prefix="/api")


# Generated at 2022-06-12 08:34:13.706234
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    def middleware(request):
        pass

    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.middleware(middleware)

    assert middleware in bp1.middlewares
    assert middleware in bp2.middlewares



# Generated at 2022-06-12 08:34:24.441323
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Blueprint Group object
    bpg = BlueprintGroup()

    # Blueprint object
    bp = Blueprint('bp', url_prefix='/bp1')
    bp.middleware('request', 'bp1_only_middleware')
    bpg.append(bp)
    bp = Blueprint('bp', url_prefix='/bp2')
    bpg.append(bp)

    # bp3 Blueprint object
    bp = Blueprint('bp3', url_prefix='/bp3')
    bp.blueprints = bpg
    bp.middleware('request', 'bp3_only_middleware')

    # register middleware for Blueprint Group
    @bpg.middleware('request')
    def bpg_middleware(request):
        print('bpg_middleware')
    # register middleware for Blueprint

# Generated at 2022-06-12 08:34:33.721469
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp2.middleware('request')
    async def bp2_only_middleware(request):
        print('applied on Blueprint : bp2 Only')

    group = Blueprint.group(bp1, bp2)

    @group.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    assert len(bp1.middlewares) == 2
    assert len(bp2.middlewares) == 2

# Generated at 2022-06-12 08:34:37.137211
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp = Blueprint('bp', url_prefix='/bp')
    bpg = BlueprintGroup()
    bpg.append(bp)

    @bpg.middleware
    def middleware(request):
        pass

    assert len(bp.middlewares['request']) == 1


# Generated at 2022-06-12 08:34:44.267277
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware('request')
    async def bp_middleware(request):
        print("Middleware for Blueprint")

    assert len(bp1.middlewares.get("request")) == 1
    assert len(bp2.middlewares.get("request")) == 1

# Generated at 2022-06-12 08:34:55.294707
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp2.middleware('request')
    async def bp2_only_middleware(request):
        print('applied on Blueprint : bp2 Only')


# Generated at 2022-06-12 08:35:05.187756
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = sanic.Blueprint('test_bp1')
    bp2 = sanic.Blueprint('test_bp2')
    bp3 = sanic.Blueprint('test_bp3')
    bp4 = sanic.Blueprint('test_bp4')

    bp5 = sanic.Blueprint('test_bp5')
    bp6 = sanic.Blueprint('test_bp6')
    bp7 = sanic.Blueprint('test_bp7')
    bp8 = sanic.Blueprint('test_bp8')
    
    bpg = BlueprintGroup(bp1, bp2, bp3, bp4)
    bpg2 = BlueprintGroup(bp5, bp6, bp7, bp8)

# Generated at 2022-06-12 08:35:15.731187
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic("test_BlueprintGroup_middleware")

    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    @bp1.route("/")
    async def test_middleware(request):
        return text("bp1")

    @bp2.route("/")
    async def test_middleware(request):
        return text("bp2")

    @bp1.middleware("request")
    async def bp1_middleware(request):
        print("bp1 middleware")

    @bp2.middleware("request")
    async def bp2_middleware(request):
        print("bp2 middleware")

    group = BlueprintGroup()
    group.append(bp1)
    group.append

# Generated at 2022-06-12 08:35:30.934864
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Arrange
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2)

    # Act
    @bpg.middleware('request')
    async def common_middleware(request):
        return

    # Assert
    assert bp1.middlewares['request'][0] == common_middleware
    assert bp2.middlewares['request'][0] == common_middleware


# Generated at 2022-06-12 08:35:36.029667
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic(__name__)
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = BlueprintGroup(bp1, bp2)
    @group.middleware('response')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')
    assert callable(group_middleware)

# Generated at 2022-06-12 08:35:42.462532
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2)

    @group.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    assert group.middleware
    assert bp1.middlewares
    assert bp2.middlewares



# Generated at 2022-06-12 08:35:48.873856
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp1 = Blueprint("bp1", url_prefix="/bp1")

    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    def foo():
        pass

    bpg.middleware(foo)

    assert bp1.middlewares["request"] == [foo]
    assert bp2.middlewares["request"] == [foo]



# Generated at 2022-06-12 08:35:57.744387
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')
    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')
    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)
    group = Blueprint.group(bp1, bp2)

    @group.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')
    assert len

# Generated at 2022-06-12 08:36:07.012475
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api")
    # This is the test
    @bpg.middleware('request')
    async def test(request):
        return 'working'

    # This is a test to see if the partials are working
    @bp1.middleware('request')
    async def test(request):
        return 'working'

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-12 08:36:16.204261
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    group = Blueprint.group(bp1, bp2)

    @group.middleware('request')
    async def group_middleware(request):
        request['bp_group'] = "run"


# Generated at 2022-06-12 08:36:20.490831
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    def _test_middleware(request):
        print('hello')

    bpg = BlueprintGroup()
    bpg.append(sanic.Blueprint('bp1'))
    bpg.middleware(_test_middleware)

    # __name__ is set to '__main__' when the script is compiled, otherwise
    # it is set to the name of the module
    if __name__ == '__main__':
        # bpg is a BlueprintGroup object and bp is a Blueprint object
        assert bpg.blueprints[0]._middleware[0][0].__qualname__ == 'test_BlueprintGroup_middleware.<locals>._test_middleware'
        assert bpg.blueprints[0]._middleware[0][1] == []
        
        # __name__ is set to '__main__' when the script

# Generated at 2022-06-12 08:36:25.808643
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Unit test to check if BlueprintGroup.middleware method can
    be executed without internal exceptions to be thrown.
    """
    def dummy_middleware(request):
        pass

    BlueprintGroup().middleware(dummy_middleware)

if __name__ == "__main__":
    test_BlueprintGroup_middleware()

# Generated at 2022-06-12 08:36:37.055488
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    app = sanic.Sanic()
    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')
    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')