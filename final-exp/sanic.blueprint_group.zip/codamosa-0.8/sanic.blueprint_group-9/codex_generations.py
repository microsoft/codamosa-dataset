

# Generated at 2022-06-12 08:31:12.800993
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic('test_BlueprintGroup_middleware')
    bp1 = Blueprint('name',url_prefix='/test')
    bp2 = Blueprint('name',url_prefix='/test')
    bp3 = Blueprint('name',url_prefix='/test')
    group = Blueprint.group(bp1, bp2)
    bp3.blueprints.append(group)
    @bp1.route('/b1')
    async def test(request):
        return text('OK')
    @bp2.route('/b2')
    async def test(request):
        return text('OK')
    @bp3.route('/b3')
    async def test(request):
        return text('OK')

# Generated at 2022-06-12 08:31:21.604271
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)

    @group.middleware
    async def common_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    assert len(bp1.middlewares['request']) == 1
    assert len(bp2.middlewares['request']) == 1

    assert bp1.middlewares['request'][0] == common_middleware
    assert bp2.middlewares['request'][0] == common_middleware


# Generated at 2022-06-12 08:31:31.608250
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    middleware_calls = 0
    @bpg.middleware('request')
    async def group_middleware(request):
        nonlocal middleware_calls
        middleware_calls += 1
    
    assert len(bp1.middlewares['request']) == 1
    assert len(bp2.middlewares['request']) == 1
    assert hasattr(bp1.middlewares['request'][0], '__closure__')

# Generated at 2022-06-12 08:31:41.456903
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup('/api', version="v1")
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware
    async def middleware():
        pass

    assert bp1._middlewares == [middleware]
    assert bp2._middlewares == [middleware]



# Generated at 2022-06-12 08:31:51.055588
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    async def test_middleware(request):
        return True

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api")

    #apply middleware
    bpg.middleware(test_middleware)

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api")
    # apply middleware as a decorator
    @bpg.middleware()
    async def test_middleware_decorator(request):
        return True


# Generated at 2022-06-12 08:32:00.286540
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp1.version='v1'
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')

    group1 = BlueprintGroup(bp1, bp2, url_prefix='/group1')
    group2 = BlueprintGroup(bp3, bp4, url_prefix='/group2')
    group3 = BlueprintGroup(bp5, bp6, url_prefix='/group3', version='v2')



# Generated at 2022-06-12 08:32:08.173972
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    group = Blueprint.group(bp1, bp2)
    @group.middleware('request')
    async def group_middleware(request):
        request.ctx.setdefault('blueprint_group_middleware', []).append(1)

    request = sanic.request.Request('POST', '/bp1/')
    response = await bp1.handle_request(request)
    
    assert request.ctx.get('blueprint_group_middleware') == [1]
    assert response.status == 404

# Generated at 2022-06-12 08:32:19.409853
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic import Blueprint, Sanic
    from sanic.testing import HOST, PORT
    from sanic.response import text
    from sanic.log import log
    import asyncio
    import pytest

    # Test for using the middleware as decorator
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert bpg.url_prefix is None

    @bpg.middleware
    async def bp1_only_middleware(request):
        print('applied on Blueprint : {}'.format(request.blueprint))
        #assert request.blueprint == 'bp1'


# Generated at 2022-06-12 08:32:21.923604
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bpg = BlueprintGroup()

    @bpg.middleware
    def middleware(request):
        pass

    assert hasattr(bpg, 'middleware')
    assert isinstance(middleware, partial)



# Generated at 2022-06-12 08:32:30.037050
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-12 08:32:47.587682
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    from sanic import Blueprint
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    assert len(bpg) == 2
    bpg.append(bp1)
    assert len(bpg) == 3
    bpg.append(bp2)
    assert len(bpg) == 4


# Generated at 2022-06-12 08:32:52.095266
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    # setup a blueprint group
    bp = BlueprintGroup()
    bp.append(Blueprint('bp1', url_prefix='/bp1'))
    # test that a blueprint is added to the group
    assert bp.blueprints[0].name == 'bp1'



# Generated at 2022-06-12 08:33:00.941209
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    # Given
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix='/api', version='v1')
    # When/Then
    assert len(bpg.blueprints) == 0
    bpg.append(bp1)
    assert len(bpg.blueprints) == 1
    bpg.append(bp2)
    assert len(bpg.blueprints) == 2
    bpg.append(bp3)
    assert len(bpg.blueprints) == 3
    bpg.append(bp4)
   

# Generated at 2022-06-12 08:33:10.292504
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group = BlueprintGroup()
    blueprint_group.append(sanic.Blueprint('bp1', url_prefix='/bp1'))
    blueprint_group.append(sanic.Blueprint('bp2', url_prefix='/bp2'))
    blueprint_group.append(sanic.Blueprint('bp3', url_prefix='/bp2'))
    blueprint_group.append(sanic.Blueprint('bp4', url_prefix='/bp2'))
    assert len(blueprint_group) == 4


# Generated at 2022-06-12 08:33:15.509070
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp2)
    bpg[0] = bp1
    assert bpg[0] == bp1


# Generated at 2022-06-12 08:33:26.633564
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    """
    Test BlueprintGroup Class parameter constructor and default values
    """
    bpg = BlueprintGroup(url_prefix="/bp_group")
    assert bpg._url_prefix == "/bp_group"
    assert bpg._version is None
    assert bpg._strict_slashes is None
    # test object attribute assignment
    bpg = BlueprintGroup(url_prefix="/bp_group/v1", version=1)
    assert bpg.url_prefix == "/bp_group/v1"
    assert bpg.version == 1
    # test object attribute assignment
    bpg = BlueprintGroup(url_prefix="/bp_group/v2", version="2")
    assert bpg.url_prefix == "/bp_group/v2"
    assert bpg.version == "2"
    # test object attribute assignment
    bpg = BlueprintGroup

# Generated at 2022-06-12 08:33:37.738125
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bp1.route('/')(lambda request: text(''))
    bp2.route('/')(lambda request: text(''))
    assert len(bpg) == 2
    del bpg[0]
    assert len(bpg) == 1
    del bpg[0]
    assert len(bpg) == 0
    bpg.append(bp1)
    assert len(bpg) == 1
    del bpg[0]
    assert len(bpg) == 0


# Generated at 2022-06-12 08:33:40.712110
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bg = BlueprintGroup()
    bp = Blueprint("test", url_prefix="/test")
    bg.append(bp)
    assert bp.name == bg[0].name

# Generated at 2022-06-12 08:33:48.482651
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup()

    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    del bpg[0] 
    assert len(bpg) == 3
    assert bpg[0] == bp2
    assert bpg[1] == bp3
    assert bpg[2] == bp4



# Generated at 2022-06-12 08:33:53.010906
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint=Blueprint('a',url_prefix='/a')
    blueprintGroup = BlueprintGroup()
    blueprintGroup.append(blueprint)
    test_blueprint = Blueprint('a',url_prefix='/a')
    blueprintGroup[0]=test_blueprint
    assert blueprintGroup[0].__class__.__name__=='Blueprint'


# Generated at 2022-06-12 08:34:11.242823
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = BlueprintGroup(url_prefix='/api', version="v1")

    group.append(bp1)
    group.append(bp2)

    assert bp1.url_prefix == '/api/bp1'
    assert bp2.url_prefix == '/api/bp2'

    assert bp1.version == "v1"
    assert bp2.version == "v1"


# Generated at 2022-06-12 08:34:20.249064
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    # Given
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")
    bp5 = Blueprint("bp5", url_prefix="/bp5")

    bpg1 = BlueprintGroup("/api1", version="v1", strict_slashes=False)
    bpg2 = BlueprintGroup("/api2", version="v2", strict_slashes=True)

    bp1.append(bp2)
    bp1.append(bp3)

    bpg2.append(bp4)

    # When
    bpg1.append(bp1)

    # Then

# Generated at 2022-06-12 08:34:26.992415
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bp3 = Blueprint("bp3") 
    bp4 = Blueprint("bp4")

    bpg = BlueprintGroup(bp3, bp4)

    assert isinstance(bpg, Iterable)
    assert len(list(bpg)) == 2

    bpg = BlueprintGroup()
    assert len(list(bpg)) == 0



# Generated at 2022-06-12 08:34:33.593221
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()
    bp = Blueprint('bp', url_prefix='/bp')

    bpg = BlueprintGroup(bp, url_prefix="/api", version="v1")

    @bp.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bpg.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    bpg.register_middleware(app)

    assert len(app.blueprints)==1
    assert app.blueprints['bp']._middleware["request"] == [bp1_only_middleware]

# Generated at 2022-06-12 08:34:40.596971
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    class Test(unittest.TestCase):
        def setUp(self):
            self.app = sanic.Sanic("test_BlueprintGroup")

        def test_constructor(self):
            bp1 = Blueprint("bp1")
            bp2 = Blueprint("bp2")
            bp3 = Blueprint("bp3")

            bpg = BlueprintGroup(bp1, bp2, bp3)

            self.assertEqual(len(bpg), 3)
            self.assertListEqual(
                bpg.blueprints, [Blueprint("bp1"), Blueprint("bp2"), Blueprint("bp3")]
            )
            self.assertIsNotNone(bpg.url_prefix)
            self.assertIsNotNone(bpg.version)

# Generated at 2022-06-12 08:34:47.181097
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    my_bp_group = BlueprintGroup(url_prefix="api",version="v1")
    my_bp_group.append( Blueprint("bp1") )
    my_bp_group.__setitem__(0,Blueprint("bp2"))
    assert isinstance(my_bp_group,BlueprintGroup)
    assert isinstance(my_bp_group[0],Blueprint)
    assert my_bp_group[0].name == "bp2"


# Generated at 2022-06-12 08:34:55.253065
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp5')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)

    bpg[0] = bp2

    assert bpg.blueprints[0] == bp2



# Generated at 2022-06-12 08:35:05.188627
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    # Given
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')


    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    # When
    # Then
    assert list(bpg)
    assert not bpg[0]
    assert not bpg[1]
    with pytest.raises(IndexError):
        bpg[100]

    # When
    bpg.append(bp1)
    bpg.append(bp2)

    # Then
    assert list(bpg)

# Generated at 2022-06-12 08:35:12.748911
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    """
    Purpose:
        Test Blueprint Group __len__ method to ensure that the Blueprint group
        length is called correctly.

    :Unit Test Precondition:
        BlueprintGroup class should be instantiated

    :Unit Test Arrangements:
        - Create Mock of Blueprint class
        - Create instance of BlueprintGroup class

    :Unit Test Name:
        - Blueprint Group __len__ method returns correct length of Group

    :Unit Test Return Value:
        - allure.step.Step > BlueprintGroup __len__ method should return the
        correct length of the blueprint group.
    """
    blueprint = sanic.Blueprint(name="test_bp")
    blueprint_group = BlueprintGroup(
        url_prefix='/api', version=None, strict_slashes=None
    )
    blueprint_group.append(blueprint)
    assert len(blueprint_group)

# Generated at 2022-06-12 08:35:22.115556
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    group = BlueprintGroup("/api", version="v1", strict_slashes=True)

    assert group.url_prefix == "/api"
    assert group.version == "v1"
    assert group.strict_slashes

    group = BlueprintGroup("/api", strict_slashes=False)

    assert group.url_prefix == "/api"
    assert not group.strict_slashes

    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2", strict_slashes=True)

    group = BlueprintGroup("/api", version="v1", strict_slashes=True)

    group.append(bp1)
    group.append(bp2)

    assert group[0].url_prefix == "/api/bp1"
    assert group[0].version == "v1"

# Generated at 2022-06-12 08:35:56.573770
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    
    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    counter = 0
    for blueprint in bpg:
        blueprint = blueprint
        counter += 1
    assert counter == 4



# Generated at 2022-06-12 08:36:01.967276
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg) == 2


# Generated at 2022-06-12 08:36:07.604420
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    assert group.url_prefix == "/api"
    assert group.version == "v1"
    assert len(group) == 2
    assert group[0] == bp1
    assert group[1] == bp2
    assert issubclass(group.__class__, MutableSequence)


# Generated at 2022-06-12 08:36:13.692642
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bp_group = BlueprintGroup()
    bp_group.extend([bp1, bp2])
    assert len(bp_group) == 2
    bp_group.append(Blueprint("bp3"))
    assert len(bp_group) == 3
    bp_group.insert(0, Blueprint("bp4"))
    assert len(bp_group) == 4



# Generated at 2022-06-12 08:36:22.805086
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')

    test_bp_group = BlueprintGroup()
    test_bp_group.append(bp1)
    test_bp_group.append(bp2)
    test_bp_group.append(bp3)

    # test for return of single blueprint
    assert test_bp_group[0] is bp1

    # test for return of blueprint list
    assert test_bp_group[0:2] == [bp1,bp2]



# Generated at 2022-06-12 08:36:29.236494
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg.__getitem__(0) == bp1
    assert bpg.__getitem__(-1) == bp2

# Generated at 2022-06-12 08:36:38.261795
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    
    bpg = BlueprintGroup()
    
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    
    if bp1 not in bpg._blueprints or bp2 not in bpg._blueprints or bp3 not in bpg._blueprints or bp4 not in bpg._blueprints:
        assert False, "BlueprintGroup item appending failed. Expected True, but got False."


# Generated at 2022-06-12 08:36:45.934875
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    """Unit tests for method __delitem__ of class BlueprintGroup"""

    # Construct the Blueprint objects
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    # Create a Blueprint Group
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    # deleting a item from a list using index
    del bpg[0]

    # If middleware exists in blueprint, it will raise an error
    with pytest.raises(Exception) as e_info:
        bp1.middleware('request')

# Generated at 2022-06-12 08:36:49.649223
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp = BlueprintGroup()
    bp.append(1)
    bp.append(2)
    bp.append(3)
    assert 1 in bp
    bp.__delitem__(0)
    assert 1 not in bp


# Generated at 2022-06-12 08:36:59.485031
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bps = BlueprintGroup('/api', version='v1')
    bps.append(bp1)
    bps.append(bp2)
    bps.append(bp3)
    bps.append(bp4)
    del bps[0]
    assert bp1 not in bps._blueprints, "Unit test for method __delitem__ of class BlueprintGroup failed"
    try:
        bps[0]
    except IndexError:
        assert True
