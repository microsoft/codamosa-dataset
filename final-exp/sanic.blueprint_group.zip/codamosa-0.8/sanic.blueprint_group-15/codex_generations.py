

# Generated at 2022-06-12 08:31:16.744404
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic('test_BlueprintGroup_middleware')
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')

    bp3 = Blueprint('bp3')
    bp4 = Blueprint('bp4')

    bg1 = BlueprintGroup(bp1, bp2)
    bg2 = BlueprintGroup(bp3, bg1)

    @bg2.middleware('request')
    def middleware1(request):
        pass

    @bp1.middleware('request')
    def middleware2(request):
        pass

    @bp2.middleware('request')
    def middleware3(request):
        pass

    @bp3.middleware('request')
    def middleware4(request):
        pass


# Generated at 2022-06-12 08:31:28.751878
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bp1.middlewares) == 0
    assert len(bp2.middlewares) == 0

    @bpg.middleware
    async def test_middleware(request):
        pass

    assert len(bp1.middlewares) == 1
    assert len(bp2.middlewares) == 1

    @bpg.middleware('request')
    async def test_request_middleware(request):
        pass

    assert len(bp1.middlewares) == 2
    assert len(bp2.middlewares) == 2


# Generated at 2022-06-12 08:31:41.315462
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic(__name__)
    bp = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')

    @bp.middleware('request')
    async def bp_middleware(request):
        request['bp_middleware_aggregate'] = True

    @bp.middleware('response')
    async def bp_middleware_response(request, response):
        response['bp_middleware_aggregate'] = True


# Generated at 2022-06-12 08:31:50.988434
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    env = mock.Mock()
    env.app = mock.Mock()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware
    async def test(request):
        return 'hi'

    assert len(bp1.middlewares) == 1
    assert len(bp2.middlewares) == 1
    bp1.middlewares[0](env)
    bp2.middlewares[0](env)
    assert bp1.middlewares[0] == bp2.middlewares[0]

# Generated at 2022-06-12 08:31:59.096837
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bpg = BlueprintGroup(url_prefix='/api')
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)

    @bp1.middleware('response')
    async def bp1_middleware(request, response):
        response.headers['X-Test'] = 'bp1'

    @bp2.middleware('request')
    async def bp2_middleware(request):
        pass

    async def test_middleware(request):
        pass

    bpg.middle

# Generated at 2022-06-12 08:32:06.367347
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)

    async def middleware_fn(request):
        pass

    group.middleware(middleware_fn)

    assert bp1.middlewares == [middleware_fn]
    assert bp2.middlewares == [middleware_fn]

# Generated at 2022-06-12 08:32:10.793755
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = BlueprintGroup(bp1, bp2)
    group.middleware("request")(lambda req:req)


# Generated at 2022-06-12 08:32:21.044642
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware("request")
    async def bp1_only_middleware(request):
        print("applied on Blueprint : bp1 only")

    @bp1.route("/")
    async def bp1_route(request):
        return text("bp1")


# Generated at 2022-06-12 08:32:28.860064
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    GIVEN `BlueprintGroup` and middleware function
    WHEN the middleware decorator is called
    THEN middleware function is applied on all blueprints
    """
    test_middleware = MagicMock()
    bp1 = Blueprint('blueprint1', url_prefix='/bp1')
    bp2 = Blueprint('blueprint2', url_prefix='/bp2')
    bp_group = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    bp_group.middleware(test_middleware)
    assert bp1.middlewares[0] == test_middleware
    assert bp2.middlewares[0] == test_middleware


# Generated at 2022-06-12 08:32:35.630596
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # We need to import the Blueprint class here
    # as the sanic.blueprints.Blueprint is not accessible
    # outside this module
    from sanic.blueprints import Blueprint

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    # create BlueprintGroup with two Blueprints
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    print(bpg.url_prefix)

    # create a dummy middleware function
    @bpg.middleware('request')
    async def test_middleware(request):
        # dummy function
        pass

    # verify the middleware is attached to the blueprints
    assert bpg.middleware.count('request') == 2

# Unit test

# Generated at 2022-06-12 08:32:52.484370
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic.blueprints import Blueprint
    from sanic import Sanic

    app = Sanic()

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2)

    @group.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    assert len(bp1.middleware) == 1
    assert len(bp2.middleware) == 1

    # Register Blueprint group under the app
    with pytest.raises(AssertionError):
        app.blueprint(group)


# Generated at 2022-06-12 08:33:01.199675
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class BlueprintClass(Blueprint):
        def middleware(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            return super().middleware(*args, **kwargs)

    def dummy_middleware_function(*args, **kwargs):
        pass

    bp1 = BlueprintClass('bp1', url_prefix='/bp1')
    bp2 = BlueprintClass('bp2', url_prefix='/bp2')
    bp3 = BlueprintClass('bp3', url_prefix='/bp3')

    blueprint_group = BlueprintGroup()
    blueprint_group.extend([bp1, bp2, bp3])

    @blueprint_group.middleware()
    def middleware_function(*args, **kwargs):
        pass


# Generated at 2022-06-12 08:33:10.630382
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    bp = Blueprint('bp', url_prefix='/bp')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp_group = BlueprintGroup(bp, bp2)

    # Create a dummy middleware for testing the Blueprint Group
    @bp_group.middleware('request')
    async def dummy_middleware(request):
        print("dummy bp_group middleware")

    assert dummy_middleware in bp._request_middleware
    assert dummy_middleware in bp2._request_middleware


# Generated at 2022-06-12 08:33:22.722158
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    my_blueprint = Blueprint.group(bp1, bp2)

    @my_blueprint.middleware('request')
    async def bp1_and_bp2_middleware(request):
        print('applied on Blueprint : bp1 and bp2')


# Generated at 2022-06-12 08:33:30.583776
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class Extension:
        """
        Test Extension class to test the middleware method of class BlueprintGroup
        """

        def __init__(self, app: "sanic.Sanic", *args, **kwargs):
            """
            Initialize the instance of extension class and add a middleware
            to the Sanic app
            :param app: Sanic app instance
            :param args: Optional positional arguments for the middleware
            :param kwargs: Optional Keyword arguments for the middleware
            """
            @app.middleware
            async def printing_middleware(request):
                print('middleware_called')


# Generated at 2022-06-12 08:33:39.145178
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    async def test_middleware(request):
        return sanic.response.text('test')

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    # Register middleware for the Blueprints
    bpg = Blueprint.group(bp1, bp2)
    bpg.middleware(test_middleware)

    assert len(bp1.middlewares) == 1
    assert len(bp2.middlewares) == 1

# Generated at 2022-06-12 08:33:48.014197
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Unit test for method middleware of class BlueprintGroup
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    group = Blueprint.group(bp1, bp2)


# Generated at 2022-06-12 08:33:55.903263
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp2.middleware('request')
    async def bp2_only_middleware(request):
        print('applied on Blueprint : bp2 Only')

    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)

    @group.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    assert len(group.blueprints[0].middleware['request']) == 2

# Generated at 2022-06-12 08:34:07.584527
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic("test_BlueprintGroup_middleware")

    bp_group = BlueprintGroup(url_prefix="/api",version="v1")
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp_group.append(bp1)
    bp_group.append(bp2)

    request_middleware_calls = []
    response_middleware_calls = []
    error_middleware_calls = []

    @bp_group.middleware('request')
    async def request_middleware(request):
        request_middleware_calls.append(1)

    @bp_group.middleware('response')
    async def response_middleware(request, response):
        response

# Generated at 2022-06-12 08:34:13.271758
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1')

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('bp1_only_middleware')

    @bp1.route('/test')
    def bp_test(r):
        return text('test')

    bp2 = Blueprint('bp2')

    @bp2.middleware('request')
    async def bp2_only_middleware(request):
        print('bp2_only_middleware')

    @bp2.route('/test')
    def bp_test(r):
        return text('test')

    group = Blueprint.group(bp1, bp2)

    @group.middleware('request')
    async def group_middleware(request):
        print('group_middleware')



# Generated at 2022-06-12 08:34:27.538364
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic(__name__)
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg1 = BlueprintGroup(url_prefix='/api')
    bpg2 = BlueprintGroup(url_prefix='/bp1')
    bp1.group = bpg1
    bp2.group = bpg2
    bp3.group = bpg2
    bpg2.append(bp1)
    bpg2.append(bp2)
    bpg2.append(bp3)
    bpg1.append(bp4)

# Generated at 2022-06-12 08:34:35.870453
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    assert len(bp1.middleware_stack) == 0
    assert len(bp2.middleware_stack) == 0

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp2.middleware('request')
    async def bp2_only_middleware(request):
        print('applied on Blueprint : bp2 Only')

    assert len(bp1.middleware_stack) == 1
    assert len(bp2.middleware_stack) == 1

    group = Blueprint.group(bp1, bp2)


# Generated at 2022-06-12 08:34:41.609057
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()
    bp1 = Blueprint('bp1', url_prefix='/bp1', strict_slashes=False)
    bp2 = Blueprint('bp2', url_prefix='/bp2', strict_slashes=True)
    bp3 = Blueprint('bp3', url_prefix='/bp3', version='v1')
    bp4 = Blueprint('bp4', url_prefix='/bp4', version='v2')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')


# Generated at 2022-06-12 08:34:49.051151
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = sanic.Blueprint("bp1")
    bp2 = sanic.Blueprint("bp2")
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware('request')
    async def bp1_only_middleware(request):
        assert bp1.name == "bp1"
        assert bp2.name == "bp2"




# Generated at 2022-06-12 08:34:57.562963
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic(__name__)

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    group = BlueprintGroup(url_prefix="/api", version="v1")
    group.append(bp1)
    group.append(bp2)

    bpg = BlueprintGroup(url_prefix="/api", version="v2")
    bpg.append(bp3)
    bpg.append(bp4)

    @group.middleware('request')
    async def group_middleware(request):
        pass

# Generated at 2022-06-12 08:35:06.189946
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)

    middleware_called = []
    @group.middleware('request')
    async def group_middleware(request):
        middleware_called.append('middleware')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    app = Sanic(__name__)
    app.blueprint(group)

    request, response = app.test_client.get('/bp1')
    assert response

# Generated at 2022-06-12 08:35:10.193520
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @BlueprintGroup.middleware('request')
    def dummy_middleware(request):
        return sanic.response.text('Test')

    assert issubclass(BlueprintGroup, sanic.blueprints.Blueprint)
    assert BlueprintGroup._middlewares == {
        'request': [dummy_middleware],
        'response': []
    }

# Generated at 2022-06-12 08:35:20.367456
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-12 08:35:22.803817
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @BlueprintGroup.middleware()
    def middleware(request):
        print("Hello, world")

    @middleware
    def another_middleware(request):
        print("Hello again")

# Generated at 2022-06-12 08:35:31.842344
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    app = sanic.Sanic(__name__)

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    group = Blueprint.group(bp1, bp2)

    @group.middleware('request')
    async def group_mw(request):
        return text('group_mw')

    @bp1.middleware('request')
    async def bp1_mw(request):
        return text('bp1_mw')


# Generated at 2022-06-12 08:35:51.864121
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(bp1, bp2, url_prefix = '/api', version = 'v1')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    @bpg.middleware('request')
    async def group_middleware(request):
        return text('common middleware applied for both bp1 and bp2')


# Generated at 2022-06-12 08:36:03.520959
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    bp1 = Blueprint('bp1', url_prefix='/bp1/api', version=1)
    bp2 = Blueprint('bp2', url_prefix='/bp2/api', version=2)

    bp3 = Blueprint('bp3', url_prefix='/bp3/api', version=3)
    bp4 = Blueprint('bp4', url_prefix='/bp4/api', version=4)

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version=5)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-12 08:36:14.173570
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # given: A blueprint group with some blueprints
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp2', url_prefix='/bp3')
    bp4 = Blueprint('bp4')
    group = BlueprintGroup(bp1, bp2, bp3, bp4)
    # when: creating a middleware function and adding it to the group
    def test_middleware(request):
        pass

    group.middleware(test_middleware)

    # then: the middleware is added to all blueprints in the group
    for blueprint in group.blueprints:
        assert test_middleware in blueprint.middlewares['request']

# Generated at 2022-06-12 08:36:20.326282
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @middleware_obj.middleware('response')
    async def response_middleware(request, response):
        assert request
        assert response
        assert isinstance(response, sanic.response.HTTPResponse)
        response.headers["X-TEST"] = "unit-test-pass"


# Generated at 2022-06-12 08:36:27.145615
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @sanic.expose("/")
    async def handler(request):
        return sanic.response.text("OK")

    blueprint = Blueprint("test_blueprint")
    blueprint.add_route(handler, uri='/')
    bg = BlueprintGroup()
    bg.append(blueprint)

    @bg.middleware('request')
    async def bg_middleware(request):
        request.test = True

    assert blueprint.middlewares['request'][0][0] == bg_middleware



# Generated at 2022-06-12 08:36:37.345703
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
        app = sanic.Sanic()
        a = Blueprint('a', url_prefix='/a')
        b = Blueprint('b', url_prefix='/b')

        @a.middleware('request')
        async def a_only_middleware(request):
            print('applied on Blueprint : a Only')

        @b.middleware('request')
        async def b_only_middleware(request):
            print('applied on Blueprint : b Only')

        @a.route('/')
        async def a_route(request):
            return text('bp1')

        @b.route('/<param>')
        async def b_route(request, param):
            return text(param)

        group = Blueprint.group(a, b)


# Generated at 2022-06-12 08:36:46.477354
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = BlueprintGroup(bp1, bp2)

    @group.middleware('response')
    async def group_middleware(request, response):
        response.text = 'group_middleware'

    app = sanic.Sanic('test_BlueprintGroup_middleware')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/')
    async def bp2_route(request):
        return text('bp2')

    app.blueprint(group)

    request, response = app.test_client.get('/bp1/')
    assert response.status

# Generated at 2022-06-12 08:36:57.542075
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')

    bp7 = Blueprint('bp7', url_prefix='/bp7')
    bp8 = Blueprint('bp8', url_prefix='/bp8')

    bpg1 = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

# Generated at 2022-06-12 08:37:06.640868
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    def middleware_handler(request):
        pass

    # Middleware will be applied to the
    test_sg = BlueprintGroup()
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    test_sg.append(bp1)
    test_sg.append(bp2)
    test_sg.append(Blueprint("bp3"))
    test_sg.middleware(middleware_handler)

    assert middleware_handler in bp1.middlewares["request"]
    assert middleware_handler in bp2.middlewares["request"]
    assert middleware_handler in test_sg[2].middlewares["request"]

# Generated at 2022-06-12 08:37:17.429689
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class TestMiddleware:
        def __call__(self, request: sanic.request):
            return request

    bp = Blueprint('test_bp')
    bpg = BlueprintGroup()

    @bpg.middleware('request')
    def test_middleware(request):
        return request

    @bp.middleware('request')
    async def async_test_middleware(request):
        return request

    bpg.append(bp)
    assert hasattr(bp, 'middlewares')
    assert len(bp.middlewares) == 2
    assert len(bp.middlewares['request']) == 2
    assert type(bp.middlewares['request'][0]) is TestMiddleware
    assert async_test_middleware.__name__ in bp.middlewares['request'][1]