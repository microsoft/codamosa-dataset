

# Generated at 2022-06-12 08:31:05.477237
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint("bp1", url_prefix="", version=None, strict_slashes=None)
    bp2 = Blueprint("bp2", url_prefix="", version=None, strict_slashes=None)
    bpg = BlueprintGroup("api", url_prefix="/api", version="v1", strict_slashes=True)
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware("request")
    def middleware(request):
        return request

    assert len(bpg.blueprints[0].middlewares) == 1
    assert len(bpg.blueprints[1].middlewares) == 1

# Generated at 2022-06-12 08:31:11.998879
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Initialize sanic application
    app = sanic.Sanic()

    # Create a Blueprint
    bp1 = Blueprint('bp1', url_prefix='/bp1')

    # Create a Blueprint Group
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)

    # Assign a middleware to the Blueprint Group
    @bpg.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    # Register the Blueprint Group to the Sanic Application with
    # the
    app.blueprint(bpg)

# Generated at 2022-06-12 08:31:17.948135
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    def dummy_middleware(request):
        return request
        
    bp = Blueprint("bp")
    bp.middleware(dummy_middleware, 'request')
    bp_group = BlueprintGroup()
    bp_group.append(bp)
    bp_group.middleware(dummy_middleware, 'request')
    assert dummy_middleware in bp.middlewares['request']

# Generated at 2022-06-12 08:31:29.819981
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class _DummyBluePrint(sanic.Blueprint):
        __slots__ = (
            'middleware_functions',
        )
        middleware_functions = {}

    def test_fn(request, *args, **kwargs):
        print('test_fn')
        return True

    bp1 = _DummyBluePrint(url_prefix='/bp1')
    bp2 = _DummyBluePrint(url_prefix='/bp2')

    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    @bpg.middleware('request')
    def middleware(request):
        print('common middleware applied for both bp1 and bp2')

    assert middleware in bp1.middleware_functions['request']
    assert middleware in b

# Generated at 2022-06-12 08:31:42.176008
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    a = Blueprint('a')
    b = Blueprint('b')
    bg = BlueprintGroup()
    bg.append(a)
    bg.append(b)

    @bg.middleware('request')
    def bp_middleware(request):
        pass

    assert a.middlewares['request'][0] == bp_middleware
    assert b.middlewares['request'][0] == bp_middleware
    assert a.middlewares['request'][0] == b.middlewares['request'][0]
    assert len(a.middlewares['request']) == 1
    assert len(b.middlewares['request']) == 1

    @bg.middleware('request', attach_to=('response',))
    def bp_middleware2(request):
        pass


# Generated at 2022-06-12 08:31:48.906232
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    class TestBluePrint(Blueprint):
        pass

    @TestBluePrint.middleware('request')
    def test_middleware_fn(request):
        pass

    bp1 = Blueprint('test1')
    bp2 = Blueprint('test2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware('request')
    def test_middleware_fn_bpg(request):
        pass

    assert 'test_middleware_fn_bpg' in bpg.blueprints[0].request_middleware
    assert 'test_middleware_fn_bpg' in bpg.blueprints[1].request_middleware

    bpg._sanitize_blueprint(TestBluePrint)

# Generated at 2022-06-12 08:31:58.019352
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    class TestingMiddleware:
        @staticmethod
        def apply_to(app: "sanic.Sanic") -> None:
            pass

    @bp1.middleware('request')
    @bp2.middleware('request')
    def test_response_middleware(request):
        pass

    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)

    # Register middleware at group level
    group.middleware(TestingMiddleware)

    # Ensure that all the blueprints are registered with a middleware.
    assert bp1._middleware["request"]
    assert bp2._middleware["request"]

# Generated at 2022-06-12 08:32:08.599221
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """Test the middleware method on BlueprintGroup
    """
    bp = Blueprint("test")
    group = BlueprintGroup()
    group.append(bp)

    @bp.middleware("request")
    async def bp_middleware(request):
        request["bp_middleware_executed"] = True

    @group.middleware("request")
    async def group_middleware(request):
        request["group_middleware_executed"] = True

    app = sanic.Sanic()
    app.blueprint(bp)

    @app.route("/test")
    async def test(request):
        return text("It works.")

    _, response = app.test_client.get("/test")
    assert response.status == 200
    assert response.json.get("group_middleware_executed") is True
   

# Generated at 2022-06-12 08:32:19.749595
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    verifyList = []
    verifyList_shortcut = []
    def fn_middleware_shortcut(*args, **kwargs):
        verifyList_shortcut.append((args, kwargs))

    def fn_middleware_method(*args, **kwargs):
        verifyList.append((args, kwargs))

    class MockBlueprint:
        def __init__(self, name):
            self.name = name
            self.middleware_list = list()

        def middleware(self, fn, *args, **kwargs):
            self.middleware_list.append((fn, args, kwargs))

    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)



# Generated at 2022-06-12 08:32:28.274502
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()

    class BlueprintGroupTest(BlueprintGroup):
        pass

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroupTest()
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware('request')
    async def bpg_middleware(request):
        print('bpg_middleware')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    app.blueprint(bpg)
   

# Generated at 2022-06-12 08:32:39.258430
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic import Blueprint
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware
    async def bpg_middleware(request):
        pass

    assert (
        len([mw for mw in bp1.middlewares['request']]) == 1
    )
    assert (
        len([mw for mw in bp2.middlewares['request']]) == 1
    )

# Generated at 2022-06-12 08:32:47.947494
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')

    bp1.middleware('request')(sanic.request)
    bp2.middleware('request')(sanic.request)
    bp3.middleware('request')(sanic.request)
    bp4.middleware('request')(sanic.request)
    bp5.middleware('request')(sanic.request)


# Generated at 2022-06-12 08:32:58.262602
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic.blueprints import Blueprint

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup('bpg')
    bpg.append(bp3)
    bpg.append(bp4)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        return text('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-12 08:33:04.978403
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)

    @group.middleware()
    async def test_middleware1(request):
        request['bp_group_middleware_invoked'] = True

    @bp1.middleware()
    async def test_middleware2(request):
        request['bp1_middleware_invoked'] = True

    @bp2.middleware()
    async def test_middleware3(request):
        request['bp2_middleware_invoked'] = True

    app = sanic.Sanic()
    app.blueprint(group)


# Generated at 2022-06-12 08:33:10.775051
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp_group = BlueprintGroup()
    bp_group.append(Blueprint("bp1"))
    bp_group.append(Blueprint("bp2"))

    @bp_group.middleware('request')
    async def bp_group_request_middleware(request: sanic.request):
        print('applied on Blueprint Group')


# Generated at 2022-06-12 08:33:22.925066
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    We should be able to implement a BlueprintGroup object and then decorate
    a method with a middleware decorator. When registered, that middleware
    should be applied to all the respective blueprints.
    """
    app = sanic.Sanic('test_BlueprintGroup_middleware')
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)


# Generated at 2022-06-12 08:33:30.714378
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware('request')
    async def bpg_middleware(request):
        pass

    assert len(bp1.middlewares['request']) == 1
    assert len(bp2.middlewares['request']) == 1

    @bpg.middleware('request')
    async def bpg_middleware(request):
        pass

    assert len(bp1.middlewares['request']) == 2
    assert len(bp2.middlewares['request']) == 2

# Generated at 2022-06-12 08:33:38.451781
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @sanic.blueprint.Blueprint.middleware(name="middle")
    async def blueprint_middleware_function(request):
        pass

    assert blueprint_middleware_function.name == "middle"

    blueprint = sanic.Blueprint(name="blueprint")
    blueprint.middleware(blueprint_middleware_function)

    for _, middleware_function in blueprint.middlewares["request"]:
        assert middleware_function.name == "middle"

# Generated at 2022-06-12 08:33:47.498323
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    @bp1.middleware('request')
    async def existing_request_middleware(request):
        raise Exception('should not be called')

    @bp1.middleware('response')
    async def existing_response_middleware(request):
        raise Exception('should not be called')

    @bp2.middleware('request')
    async def existing_request_middleware_bp2(request):
        raise Exception('should not be called')

    @bp2.middleware('response')
    async def existing_response_middleware_bp2(request):
        raise Exception('should not be called')


# Generated at 2022-06-12 08:33:55.805753
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bpg = BlueprintGroup()
    bpg.append(Blueprint('blueprint1'))
    bpg.append(Blueprint('blueprint2'))
    bpg.middleware(lambda: None)
    assert len(bpg.blueprints[0].middlewares['request']) == 1
    assert len(bpg.blueprints[1].middlewares['request']) == 1

    bpg = BlueprintGroup()
    bpg.append(Blueprint('blueprint1'))
    bpg.append(Blueprint('blueprint2'))
    bpg.middleware(lambda: None, attach_to="response")
    assert len(bpg.blueprints[0].middlewares['response']) == 1
    assert len(bpg.blueprints[1].middlewares['response']) == 1

# Generated at 2022-06-12 08:34:06.644967
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    @bpg.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    def test():
        return bp1_only_middleware

# Generated at 2022-06-12 08:34:17.335564
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg1 = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    bpg2 = BlueprintGroup(bpg1, url_prefix="/root", version="v2")

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)


# Generated at 2022-06-12 08:34:26.549813
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic("TestBlueprintGroup")

    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.middleware("request")
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    async def bp2_only_middleware(request):
        print('applied on Blueprint : bp2 Only')

    @bp2.middleware("request")
    async def bp2_only_middleware(request):
        print('applied on Blueprint : bp2 Only')


# Generated at 2022-06-12 08:34:35.145997
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    class App(sanic.Sanic):
        """
        This is a test class that inherits Sanic and is used to test
        the Blueprint group middleware
        """

    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/bpg")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bpg1 = BlueprintGroup(bp3, url_prefix="/bpg1")
    bpg.append(bpg1)

    @bp1.middleware("request")
    async def bp1_route_middleware(request):
        """
        Middleware that is scoped to bp1 only
        """
        request["bp1"]

# Generated at 2022-06-12 08:34:44.970430
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Test of method middleware of class BlueprintGroup
    """

    def create_dummy_blueprint():
        """
        Creates a dummy blueprint with dummy middleware
        """
        dummy_bp = Blueprint('dummy_bp')
        dummy_bp.middleware_stack = []
        dummy_bp.add_route = MagicMock(return_value=None)
        return dummy_bp

    @contextmanager
    def fake_blueprints():
        """
        Generator for mocking the blueprints
        """
        dummy_bp1 = create_dummy_blueprint()
        dummy_bp2 = create_dummy_blueprint()
        dummy_bp3 = create_dummy_blueprint()
        yield dummy_bp1, dummy_bp2, dummy_bp3


# Generated at 2022-06-12 08:34:55.855016
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-12 08:35:05.481268
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    This method tests the behaviour of BlueprintGroup.middleware
    """
    test_bp = BlueprintGroup()
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    test_bp.extend((bp1, bp2))

    @test_bp.middleware("request")
    async def bp_group_middleware1(request):
        return

    @test_bp.middleware("request", attach_to="url")
    async def bp_group_middleware2(request):
        return

    assert bp_group_middleware1 in bp1.request_middleware
    assert bp_group_middleware1 in bp2.request_middleware

    assert bp_group_middleware2 in bp

# Generated at 2022-06-12 08:35:12.898031
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # create app and blueprint
    app = sanic.Sanic('test_BlueprintGroup middleware')
    bp1 = Blueprint('test_bp1')
    bp2 = Blueprint('test_bp2')

    # create a middleware
    @bp1.middleware('response')
    async def bp1_middleware(request, response):
        response.text += 'bp1'

    # create a middleware for bp1 and bp2
    @Blueprint.group(bp1, bp2).middleware('response')
    async def bp_middleware(request, response):
        response.text += 'bp'

    # add a route to bp1
    @bp1.route('/')
    async def bp1_handler(request):
        return text('test_bp1')

    # register blueprint


# Generated at 2022-06-12 08:35:22.209011
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware('request')
    async def bp1_only_middleware(request):

        assert(request.method == 'GET')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    app = Sanic('test_BlueprintGroup_middleware')
    app.blueprint(bpg)

    request, response = app

# Generated at 2022-06-12 08:35:31.236419
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)


# Generated at 2022-06-12 08:35:41.505221
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    obj = BlueprintGroup()
    obj._blueprints = [
        sanic.Blueprint("name", "url_prefix", 1, True),
        sanic.Blueprint("name", "url_prefix", 1, True),
        BlueprintGroup(),
    ]
    # Fake Blueprints
    obj._blueprints[0]._middlewares = {}
    obj._blueprints[1]._middlewares = {}
    # Fake BlueprintGroup
    obj._blueprints[2]._blueprints = [
        sanic.Blueprint("name", "url_prefix", None, None),
        sanic.Blueprint("name", "url_prefix", 1, True),
    ]
    obj._blueprints[2]._blueprints[0]._middlewares = {}
    obj._blueprints[2]._blueprints[1]._middlewares = {}

# Generated at 2022-06-12 08:35:43.809295
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp_g = BlueprintGroup()
    @bp_g.middleware
    def middleware(request):
        pass
    bp_g.register_middleware = Mock()
    bp_g.middleware(bp_g)
    bp_g.register_middleware.assert_called_with(bp_g)


# Generated at 2022-06-12 08:35:52.571155
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Unit test for method middleware of class BlueprintGroup
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup("/api")
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware('request')
    async def bp_only_middleware(request):
        """
        A test middleware for unit test
        """

    test_handler = bp1._middleware.get("request")[0]
    assert test_handler == bp_only_middleware

    test_handler = bp2._middleware.get("request")[0]
    assert test_handler == bp_only_middleware

# Unit test

# Generated at 2022-06-12 08:36:03.740819
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bpg1 = BlueprintGroup()
    bpg1.append(bp1)
    bpg1.append(bp2)
    bpg1.append(bp3)
    bp4.append(bp5)
    bpg2 = BlueprintGroup()
    bpg2.append(bpg1)
    bpg2.append(bp4)


# Generated at 2022-06-12 08:36:14.632160
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    def bp1_middleware(request):
        print("applied on Blueprint : bp1 only")
        
    def group_middleware(request):
        print("common middleware applied for both bp1 and bp2")

    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    group = BlueprintGroup(bp1, bp2)

    @bp1.middleware("request")
    def bp1_only_middleware(request):
        print("applied on Blueprint : bp1 only")

    @group.middleware("request")
    def group_middleware(request):
        print("common middleware applied for both bp1 and bp2")


# Generated at 2022-06-12 08:36:22.397146
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    :return: None
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    @group.middleware('request')
    async def group_middleware(request):
        pass

    assert 1 == len(bp1.middlewares)
    assert 1 == len(bp2.middlewares)



# Generated at 2022-06-12 08:36:29.585007
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    method_middleware_sanity_check = False
    method_middleware_check_1 = False
    method_middleware_check_2 = False

    @BlueprintGroup.middleware('request')
    async def group_middleware(request):
        nonlocal method_middleware_sanity_check

        if not method_middleware_sanity_check:
            method_middleware_sanity_check = True
        else:
            method_middleware_sanity_check = False

    bp1 = Blueprint('bp1', url_prefix='/bp1')

    @bp1.route('/1')
    async def bp1_route_1(request):
        return text('bp1_route_1')


# Generated at 2022-06-12 08:36:38.420896
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1', version=1)
    bp2 = Blueprint('bp2', url_prefix='/bp2', version=2)
    bp3 = Blueprint('bp3', url_prefix='/bp3', version=3)
    bp4 = Blueprint('bp4', url_prefix='/bp4', version=4)

    # In the current implementation, the middleware is applied only
    # to the blueprints that are direct children of the current group
    # rather than all the leaf-node blueprints.
    bpg = BlueprintGroup('bp_group', '/', 1)
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(BlueprintGroup('bp_sub_group', '/sub', 1))

# Generated at 2022-06-12 08:36:46.176043
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    group = Blueprint.group(bp1, bp2)

    @group.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    # Create

# Generated at 2022-06-12 08:36:57.317321
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic import Blueprint
    from sanic.router import RouteExists
    from sanic.testing import HOST, PORT

    bp = Blueprint("test", url_prefix="/test")
    bpg = BlueprintGroup()
    bpg.append(bp)

    event_handler = Mock()

    request, response = Mock(), Mock()

    @bpg.middleware
    def middleware1(request):
        return await event_handler(request)

    @bp.route("/test1")
    async def test1(request):
        return response

    @bp.route("/test2")
    async def test2(request):
        return response

    app = Sanic("test_BlueprintGroup_middleware")
    app.blueprint(bpg)

    client = app.test_client


# Generated at 2022-06-12 08:37:04.842432
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    class Middleware(object):
        pass


# Generated at 2022-06-12 08:37:15.651544
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    group = Blueprint.group(bp1, bp2)

    @group.middleware('response')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    assert group.middleware
    assert bpg.middleware


# Generated at 2022-06-12 08:37:27.231795
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)

    @group.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    app.blueprint(group)


# Generated at 2022-06-12 08:37:38.433462
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = sanic.Blueprint("bp1", url_prefix="/bp1")
    bp2 = sanic.Blueprint("bp2", url_prefix="/bp2")
    bpg = BlueprintGroup("/bp_grp")
    bpg.append(bp1)
    bpg.append(bp2)

    @bp1.middleware("request")
    @bp2.middleware("request")
    async def test_middleware(request):
        pass

    assert len(bp1.middlewares["request"]) == 1
    assert bp1.middlewares["request"][0] == test_middleware
    assert len(bp2.middlewares["request"]) == 1
    assert bp2.middlewares["request"][0] == test_middleware

    bpg.middleware("request")

# Generated at 2022-06-12 08:37:49.515323
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """Test the BlueprintGroup's middleware decorator"""
    app = sanic.Sanic()

    blueprint1 = Blueprint('test_bp1', url_prefix='/test_bp1')
    blueprint2 = Blueprint('test_bp2', url_prefix='/test_bp2')
    blueprint3 = Blueprint('test_bp3', url_prefix='/test_bp3')

    @blueprint1.middleware('request', attach_to='all')
    def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    group = BlueprintGroup()

    group.append(blueprint1)
    group.append(blueprint2)

    group2 = BlueprintGroup()
    group2.append(group)
    group2.append(blueprint3)


# Generated at 2022-06-12 08:37:59.471067
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @sanic.blueprint()
    def bp1():
        return Blueprint("bp1", url_prefix="/bp1")

    @sanic.blueprint()
    def bp2():
        return Blueprint("bp2", url_prefix="/bp2")

    bp1 = bp1()
    bp2 = bp2()

    @bp1.middleware
    def bp1_only_middleware(request):
        print("bp1 middleware")

    @bp2.middleware
    def bp2_only_middleware(request):
        print("bp2 middleware")

    group = BlueprintGroup(bp1, bp2)

    @group.middleware
    def group_middleware(request):
        print("group middleware")


# Generated at 2022-06-12 08:38:09.471935
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2, url_prefix='/api', version='v1')

    # Use the bp1 and bp2 blueprints to create test app
    @bp1.route('/test')
    async def test_bp1(request):
        return text('test')

    @bp2.route('/test')
    async def test_bp2(request):
        return text('test')

    async def registration_middleware(request, handler):
        print("Middleware registered")
        return await handler(request)

    bpg.middleware(registration_middleware)

    app = Sanic(__name__)
    app.blue

# Generated at 2022-06-12 08:38:19.830304
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bpg = BlueprintGroup()

    @bpg.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    assert len(bpg.blueprints) == 0

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    assert len(bpg.blueprints) == 2
    assert bp1.middlewares
    assert bp2.middlewares

    assert bpg.url_prefix == "/api"
    assert bpg.version == "v1"
    assert bp1.url_prefix == "/api/bp1"

# Generated at 2022-06-12 08:38:26.964240
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    def custom_middleware(*args, **kwargs):
        pass

    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")
    bpg = BlueprintGroup(bp1, bp2, bp3, bp4, url_prefix="/api", version="v1")

    bpg.middleware(custom_middleware)
    assert bp1.middleware_stack == [custom_middleware]
    assert bp2.middleware_stack == [custom_middleware]
    assert bp3.middleware_stack == [custom_middleware]
    assert bp4.middleware_

# Generated at 2022-06-12 08:38:38.767771
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    from sanic import Blueprint

    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bp3 = Blueprint("bp3")
    bp4 = Blueprint("bp4")

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)
