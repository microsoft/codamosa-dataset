

# Generated at 2022-06-12 08:31:09.381761
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    # Group of Blueprints
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    # Blueprint that is not in the group
    bp3 = Blueprint('bp3', url_prefix='/bp3')

    # Register the blueprint group under the app
    app.blueprint(Blueprint.group(bp1, bp2))

    # Create a middleware that is applied across all the blueprints
    middleware_calls = []

    @app.middleware('request')
    async def common_middleware(request):
        middleware_calls.append("common_middleware")

    # Create a middleware specific for the group of blueprints

# Generated at 2022-06-12 08:31:19.187762
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    def middle(request):
        """
        Middleware function used in tests.
        """
        return

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    @bpg.middleware('request')
    def middleware_func(request):
        pass

    bp1.middleware('request')(middle)
    bp2.middleware('request')(middle)
    assert any(middle.__name__ == x.__name__ for x in bp1.middlewares['request']), \
        'middleware of bpg has not been applied to bp1'

# Generated at 2022-06-12 08:31:28.208349
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    async def append_bp1_middleware_text(request):
        assert request
        request["bp1"] = "bp1_middleware"
        return request

    async def append_bp2_middleware_text(request):
        assert request
        request["bp2"] = "bp2_middleware"
        return request

    bp1.middleware(append_bp1_middleware_text)
    bp2.middleware(append_bp2_middleware_text)

    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)

    async def append_bp1_middleware_text(request):
        assert request


# Generated at 2022-06-12 08:31:36.489959
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic("test_BlueprintGroup")
    bp = Blueprint("bp")
    bpg = BlueprintGroup()
    bpg.append(bp)

    @bp.middleware("request")
    async def method_on_bp(request):
        pass

    @bpg.middleware("request")
    async def method_on_bpg(request):
        pass

    assert method_on_bp in bp.middleware["request"]
    assert method_on_bpg in bp.middleware["request"]

# Generated at 2022-06-12 08:31:46.809195
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic import Blueprint

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    group = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    group2 = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    bp1 = Blueprint('bp1', url_prefix='/')
    bp2 = Blueprint('bp2', url_prefix='/')

    group3 = BlueprintGroup(bp1, group2, bp2, url_prefix="/api", version="v1")


# Generated at 2022-06-12 08:31:54.053407
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic("test_BlueprintGroup_middleware")
    bp1 = Blueprint("test_bp", url_prefix="/test_bp")
    bp2 = Blueprint("test_bp", url_prefix="/test_bp2")
    bp_group = BlueprintGroup(bp1, bp2, url_prefix="/test_bp_group")
    
    @bp_group.middleware("request")
    async def request_middleware(request):
        request["test_bp_group"] = "applied"
    
    @bp1.middleware("request")
    async def request_middleware(request):
        request["test_bp"] = "applied"

    @bp2.middleware("request")
    async def request_middleware(request):
        request["test_bp2"] = "applied"

# Generated at 2022-06-12 08:32:05.392582
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic.blueprints import Blueprint
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix='/api', version='v1')
    bpg.append(bp1)
    bpg.append(bp2)

    # decorate all the blueprints in the group
    @bpg.middleware('request')
    async def bp_group_middleware(request):
        print('Middleware group worked')
        return text('bp_group_middleware')

    # decorate specific blueprint
    @bp2.middleware('request')
    async def bp2_middleware(request):
        print('bp2_middleware worked')
        return text('bp2_middleware')



# Generated at 2022-06-12 08:32:10.110267
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group = BlueprintGroup()
    blueprint_1 = Blueprint('bp1')
    blueprint_2 = Blueprint('bp2')
    blueprint_group.append(blueprint_1)
    blueprint_group.append(blueprint_2)

    @blueprint_group.middleware
    async def test_middleware(request):
        pass

    assert blueprint_1.websocket_middleware == [test_middleware]
    assert blueprint_2.websocket_middleware == [test_middleware]

# Generated at 2022-06-12 08:32:16.536302
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    @bp3.route('/')
    async def bp3_route(request):
        return text('bp3')

    group = Blueprint.group(bp1, bp2)

    @group.middleware('request')
    async def group_middleware(request):
        print

# Generated at 2022-06-12 08:32:21.375849
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
  def middleware_test(args):
    print(args)
  bp1 = Blueprint('bp1', url_prefix='/bp1')
  bp2 = Blueprint('bp2', url_prefix='/bp2')
  bpg = BlueprintGroup()
  bpg.append(bp1)
  bpg.append(bp2)
  bpg.middleware(middleware_test, "mse")
  assert True



# Generated at 2022-06-12 08:32:32.527923
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp1')
    bp4 = Blueprint('bp4', url_prefix='/bp2')

    # Blueprint Group
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    middleware_param = "param"

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-12 08:32:42.150491
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic.blueprints import Blueprint

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api")
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware('request')
    async def bp_only_middleware(request):
        print('applied on Blueprint : bp1 Only')


    assert bp1.middlewares['request'] == [bp_only_middleware]
    assert bp2.middlewares['request'] == [bp_only_middleware]


# Generated at 2022-06-12 08:32:53.107185
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    b1 = sanic.Blueprint('first_blueprint')
    b2 = sanic.Blueprint('second_blueprint')
    bg = BlueprintGroup()
    bg.append(b1)
    bg.append(b2)

    def dummy_handler(request):
        return text('OK')

    def dummy_middleware(request):
        pass

    bg.middleware(dummy_middleware)

    assert len(b1.middlewares['request']) == 1
    assert b1.middlewares['request'][0] == dummy_middleware

    assert len(b2.middlewares['request']) == 1
    assert b2.middlewares['request'][0] == dummy_middleware

    assert len(bg.middlewares['request']) == 0

    bg.middleware

# Generated at 2022-06-12 08:33:01.662816
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp3)
    bpg.append(bp4)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-12 08:33:09.882530
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic('test_BlueprintGroup')
    bp = Blueprint.group('bp1', url_prefix='/bp1', version="v1")
    
    @bp.middleware('request')
    def bp_request_middleware(request):
        pass

    assert len(bp.blueprints[0].middlewares) == 1
    assert bp.blueprints[0].middlewares['request'][0].callback == bp_request_middleware
    
    

# Generated at 2022-06-12 08:33:21.857589
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Test case for method middleware of class BlueprintGroup
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpGroup = BlueprintGroup(url_prefix="/api", version="v1")
    bpGroup.append(bp3)
    bpGroup.append(bp4)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')


# Generated at 2022-06-12 08:33:30.142397
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic("test_BlueprintGroup_middleware")
    bp1 = Blueprint("bp1", url_prefix="bp1")
    bp2 = Blueprint("bp2", url_prefix="bp2")
    bp3 = Blueprint("bp3", url_prefix="bp3")
    bpg = BlueprintGroup(bp1, bp2, url_prefix="bpg", version="v1")
    bpg2 = BlueprintGroup(bp3, bp1, url_prefix="bpg2", version="v2")
    app.blueprint(bpg2)

    applied_middlewares = set()

    @bpg.middleware("response")
    async def bpg_middleware1(request):
        applied_middlewares.add("bpg_middleware1")


# Generated at 2022-06-12 08:33:42.263228
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic import Blueprint
    from sanic.request import Request

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp5')

    # Create Blueprint group
    bpg = BlueprintGroup()

    # Add the blueprints to group
    bpg.append(bp1)
    bpg.append(bp2)

    # Create a nested blueprint group
    bpg2 = BlueprintGroup()
    bpg2.append(bp3)
    bpg2.append(bp4)

    # Create a nested blueprint group
    bpg.append(bpg2)

    # Create a test Middle

# Generated at 2022-06-12 08:33:50.250712
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp = Blueprint('bp', url_prefix='/bp')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp_group = BlueprintGroup()
    bp_group.append(bp)
    bp_group.append(bp2)

    @bp_group.middleware
    def middleware_function(request):
        pass

    assert middleware_function in bp.middlewares['request']
    assert middleware_function in bp2.middlewares['request']

    @bp_group.middleware(name = "bob")
    def middleware_function2(request):
        pass

    assert middleware_function2 in bp.middlewares['bob']
    assert middleware_function2 in bp2.middlewares['bob']


# Generated at 2022-06-12 08:34:00.243852
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    group = BlueprintGroup(bp1, bp2, url_prefix="/api")
    app.blueprint(group)

    @group.middleware('request')
    async def group_middleware(request):
        request['foo'] = 'bar'

    # Mock a request

# Generated at 2022-06-12 08:34:10.398156
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    pass


# Generated at 2022-06-12 08:34:16.154685
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert bpg[0] == bp1
    assert bpg[1] == bp2


# Generated at 2022-06-12 08:34:21.611444
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp_group = BlueprintGroup()
    bp_group.append(bp1)
    bp_group.append(bp2)
    assert len(bp_group) == 2


# Generated at 2022-06-12 08:34:32.216789
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    group = BlueprintGroup(bp1, bp2)
    group2 = BlueprintGroup(bp3, bp4)

    group.middleware(bp1._middleware_stack)
    group.middleware(bp2._middleware_stack)

    group2.middleware(bp3._middleware_stack)
    group2.middleware(bp4._middleware_stack)

    assert len(bp1._middleware_stack) == 1
    assert len(bp2._middleware_stack) == 1


# Generated at 2022-06-12 08:34:39.740212
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    # Method for testing BlueprintGroup.__iter__()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup()
    bpg.blueprints = (bp1, bp2, bp3, bp4)

    assert bp1 in bpg
    assert bp2 in bpg
    assert bp3 in bpg
    assert bp4 in bpg

    assert list(bpg) == [bp1, bp2, bp3, bp4]


# Generated at 2022-06-12 08:34:51.558191
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    # Arrange
    bp1 = Blueprint('bp1',url_prefix='/bp1')
    bp2 = Blueprint('bp2',url_prefix='/bp2')
    bp3 = Blueprint('bp3',url_prefix='/bp3')
    bp4 = Blueprint('bp4',url_prefix='/bp4')
    bp5 = Blueprint('bp5',url_prefix='/bp5')

    bpg = BlueprintGroup()
    bpg._blueprints.append(bp1)
    bpg._blueprints.append(bp2)
    bpg._blueprints.append(bp3)
    bpg._blueprints.append(bp4)
    bpg._blueprints.append(bp5)

    # Act
    bp = bpg[2]

    # Assert
    assert bp3 == b

# Generated at 2022-06-12 08:34:57.024587
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp = Blueprint('test')
    bp2 = Blueprint('test2')
    bp_g = BlueprintGroup()
    bp_g.append(bp)
    bp_g.append(bp2)

    assert iter(bp_g) == iter(bp_g._blueprints)


# Generated at 2022-06-12 08:35:04.145396
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group = BlueprintGroup()
    blueprint_group._blueprints = list(map(Blueprint, ['one', 'two', 'three']))

    iterator = blueprint_group.__iter__()
    blueprint = next(iterator)
    assert blueprint.name == 'one'
    blueprint = next(iterator)
    assert blueprint.name == 'two'
    blueprint = next(iterator)
    assert blueprint.name == 'three'
    try:
        blueprint = next(iterator)
        assert False
    except StopIteration:
        pass


# Generated at 2022-06-12 08:35:06.299135
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    # Setup Blueprint Group
    BlueprintGroup.___delitem__(["index"])
    # Assertion
    assert True


# Generated at 2022-06-12 08:35:15.133320
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    from sanic.blueprints import Blueprint
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg._blueprints.extend([bp3, bp4])
    assert bpg[0] is bp3
    assert bpg[1] is bp4


# Generated at 2022-06-12 08:35:27.328693
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprints = [sanic.Blueprint("bp{}".format(i), url_prefix="/bp{}".format(i)) for i in range(10)]
    bpg = BlueprintGroup(url_prefix="/api/v1")
    for bp in blueprints:
        bpg.append(bp)

    assert (isinstance(bpg, BlueprintGroup))
    assert (all(isinstance(bp, sanic.Blueprint) for bp in bpg))
    for bp in blueprints:
        assert (bp in bpg)


# Generated at 2022-06-12 08:35:35.614000
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp_group = BlueprintGroup(url_prefix="/prefix")
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bp_group.append(bp1)
    bp_group.append(bp2)
    bp_group.append(bp3)
    bp_group.append(bp4)

    bp1_len = len(bp_group)
    assert bp1_len == 4

    del bp_group[2]
    bp2_len = len(bp_group)
    assert bp1_len == bp2

# Generated at 2022-06-12 08:35:41.631877
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    # Calling iter() on the Blueprint Group object should return an iterator
    # with the blueprints inside it
    assert list(bpg) == [bp1, bp2]


# Generated at 2022-06-12 08:35:48.779859
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")

    bp5 = Blueprint("bp5", url_prefix="/bp5")

    bpg = BlueprintGroup()
    bpg.extend([bp3, bp4])
    bpg1 = BlueprintGroup()
    bpg1.extend([bp5, bp1, bp2])

    bpg.extend([bpg1, bp5])

    for blueprint in bpg:
        assert blueprint in (bp1, bp2, bp3, bp4, bp5)

# Generated at 2022-06-12 08:35:53.576864
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    assert bpg._url_prefix == "/api"
    assert bpg._version == "v1"
    assert len(bpg._blueprints) == 0
    assert not bpg._strict_slashes



# Generated at 2022-06-12 08:36:04.859506
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    @bpg.middleware('request')
    async def bpg_only_middleware(request):
        print('applied on BlueprintGroup')
    assert bp1._request_middleware == [bpg_only_middleware]

# Generated at 2022-06-12 08:36:08.465416
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    # noinspection PyUnusedLocal
    @sanic.Blueprint.group(
        url_prefix="/api", version=1.1, strict_slashes=True,
    )
    async def default_group():
        pass



# Generated at 2022-06-12 08:36:16.651779
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp2", url_prefix="/bp3")
    bg = BlueprintGroup("/api", "v1")
    assert len(bg) == 0
    bg.append(bp1)
    assert len(bg) == 1
    bg.append(bp2)
    assert len(bg) == 2
    bg.append(bp3)
    assert len(bg) == 3
    assert bg[0] == bp1
    assert bg[1] == bp2
    assert bg[2] == bp3


# Generated at 2022-06-12 08:36:24.749489
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    import pytest
    from conftest import sanic_app, create_routes, BaseTestSanic

    @sanic_app.route("/user/<name>")
    async def test(request, name):
        return text(name)

    @sanic_app.route("/group")
    async def test2(request):
        return text("bar")

    class TestApp(BaseTestSanic):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def test_get_item(self):
            # Create a blueprint Group
            bp_group = Blueprint.group(url_prefix="/api", version="v1")

            # Create a blueprint versioned with group version
            bp = Blueprint("test2", url_prefix="/group")

           

# Generated at 2022-06-12 08:36:33.776132
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    assert bpg.url_prefix == "/api"
    assert bpg.version == "v1"
    assert bp1 in bpg.blueprints
    assert bp2 in bpg.blueprints
