

# Generated at 2022-06-12 08:31:10.611856
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bpg.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-12 08:31:17.564660
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Set up an app, app1 and bp holding app1
    app = sanic.Sanic(__name__)
    app1 = sanic.Blueprint(__name__, url_prefix="test")
    bp = BlueprintGroup(app1)

    # Set up a middleware and register it to the bp
    @bp.middleware()
    def middleware1(request):
        pass

    # Check that the middleware exists in app1
    assert "middleware1" in app1.middlewares["request"]

# Generated at 2022-06-12 08:31:29.115754
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    group = BlueprintGroup()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group_bp = BlueprintGroup(bp1, bp2)

    @group.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @group_bp.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    assert len(bp1.middlewares)==1
    assert len(bp2.middlewares)==1
    assert len(group_bp.middlewares) == 2

# Generated at 2022-06-12 08:31:41.978221
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = sanic.Blueprint("bp1", url_prefix="/bp1")
    bp2 = sanic.Blueprint("bp2", url_prefix="/bp2")

    # Create a Blueprint Group with the two blueprints
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    # Register a simple dummy middleware using decorator
    @bpg.middleware("request")
    def dummy_middleware(request):
        pass

    # Assert the middleware is registered with all blueprints
    assert bp1.middleware_stack
    assert bp2.middleware_stack

    # Clear the blueprints
    bp1.middleware_stack = []
    bp2.middleware_stack = []

    # Register dummy middleware using __init__
   

# Generated at 2022-06-12 08:31:51.445128
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Initialize app, blueprint and BlueprintGroup
    app = sanic.Sanic()
    bp = Blueprint('bp', url_prefix='/bp')
    bpg = BlueprintGroup(bp, url_prefix='/bpg')

    @bpg.middleware('request')
    def middleware(request):
        # Only bp should have get_middleware
        assert bp.get_middleware('request') == [middleware]
        pass

    @bp.route('/')
    async def bp_route(request):
        pass

    bpg_mw_length = len(bpg.middleware)
    bpg_mw_type = type(bpg.middleware)

    app.blueprint(bpg)
    app.run()

    # Test that middleware method is added to BlueprintGroup.middleware
   

# Generated at 2022-06-12 08:31:59.313861
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class fake_Blueprint:
        def __init__(self, name):
            self.name = name
    
    class fake_middleware:
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
    
    def register_middleware(fn):
        return fn
    
    bp1 = fake_Blueprint('bp1')
    bp2 = fake_Blueprint('bp2')
    blueprint_and_middleware = [
        (bp1, fake_middleware(1, 2, 3, 4, 5)),
        (bp2, fake_middleware(1, 2, 3, 4, 5))
    ]
    blueprint_group = BlueprintGroup()
    blueprint_group.append(bp1)

# Generated at 2022-06-12 08:32:09.251816
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bp3 = Blueprint("bp3")
    bp4 = Blueprint("bp4")

    bpg1 = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    bpg2 = BlueprintGroup(bpg1, bp2, url_prefix="/api", version="v1")
    bpg3 = BlueprintGroup(bpg2, bp1, url_prefix="/api", version="v1")

    bpg3_all = bpg3.blueprints + bpg2.blueprints + bpg1.blueprints

    def bpg3_middleware(request):
        print("Middleware Applied on Blueprint Group bpg3")


# Generated at 2022-06-12 08:32:20.291709
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    import asyncio
    from sanic import Sanic
    from sanic.response import text
    app = Sanic(__name__)

    @app.middleware('response')
    async def print_on_request(request):
        print("Middleware applied")

    bp = Blueprint('bp', url_prefix='/bp')

    @bp.route('/')
    async def bp_route(request):
        return text('bp')

    bpg = BlueprintGroup()

    bpg.append(bp)

    bpg.middleware('response')(print_on_request)

    app.blueprint(bpg)

    _, response = app.test_client.get('/bp/')

    assert response.status == 200
    assert response.text == "bp"

    # Add some dependency to fix Mock test failure
    loop

# Generated at 2022-06-12 08:32:28.753909
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp = Blueprint('bp')
    bp2 = Blueprint('bp2')
    bpg = BlueprintGroup()
    bpg.append(bp)
    bpg.append(bp2)

    # Test for Middleware applied on a single blueprint
    @bp.middleware('request')
    async def bp_only_middleware(request):
        print('applied on Blueprint : bp Only')

    # Test for Middleware applied on the Blueprint Group
    @bpg.middleware('request')
    async def bpg_only_middleware(request):
        print('applied on Blueprint : bpg Only')

    # Ensure that the middleware is applied to each of the available
    # blueprints
    assert len(bp._middleware['request']) == 1
    assert len(bp2._middleware['request']) == 1

# Generated at 2022-06-12 08:32:35.561864
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # pylint: disable=unused-argument
    """
    Unit test for method middleware of class BlueprintGroup
    """
    app = sanic.Sanic()

    # pylint: disable=redefined-outer-name,invalid-name
    @app.blueprint.middleware('request')
    async def bp_middleware(request):
        """
        Middleware for bp
        """
        # pylint: disable=unused-variable
        _ = request

    app.blueprint(BlueprintGroup(Blueprint('bp1', url_prefix='/bp1'), Blueprint('bp2', url_prefix='/bp2')))


# Generated at 2022-06-12 08:32:47.032811
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    @bp3.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-12 08:32:57.573560
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bg1 = BlueprintGroup(bp1,bp2, url_prefix="/bg1")
    bg2 = BlueprintGroup(bp3,bp4, url_prefix="/bg2")

    bg3 = BlueprintGroup(bg1,bg2, url_prefix="/bg3")

    @bg3.middleware('request')
    async def bg3_middleware(request):
        request['test'] = 'test'

    assert bp1.middlewares['request'][0] == bg3_middleware


# Generated at 2022-06-12 08:33:04.600844
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class TestBlueprint(sanic.Blueprint):
        _middleware = []

        @property
        def middleware(self):
            return self._middleware

        @middleware.setter
        def middleware(self, fn: "sanic.middleware.Middleware"):
            self._middleware.append(fn)

    app = sanic.Sanic()
    bp1 = TestBlueprint('bp1', url_prefix='/bp1')
    bp2 = TestBlueprint('bp2', url_prefix='/bp2')

    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)

    @group.middleware('request')
    async def group_middleware(request):
        pass

    assert len(bp1.middleware) == 1

# Generated at 2022-06-12 08:33:12.053003
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # method decorator
    blueprint = BlueprintGroup()
    @blueprint.middleware
    async def middleware(request):
        pass

    for blueprint in blueprint.blueprints:
        assert middleware == blueprint.middlewares[-1]

    # param decorator
    blueprint = BlueprintGroup()
    @blueprint.middleware('request')
    async def middleware(request):
        pass

    for blueprint in blueprint.blueprints:
        assert middleware == blueprint.middlewares['request'][-1]

# Generated at 2022-06-12 08:33:24.205115
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Test Case: Sucess Case
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bp3 = sanic.Blueprint('bp3', url_prefix='/bp3')
    bp4 = sanic.Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp3.route('/')
    async def bp3_route(request):
        return text('bp3')

    @bp4.route('/<param>')
    async def bp4_route(request, param):
        return text(param)


# Generated at 2022-06-12 08:33:29.872858
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bpg) == 2

    @bpg.middleware('request')
    async def bp1_only_middleware(request):
        pass

# Class BlueprintMethodView is not defined in the file
# bp_method_view = BlueprintMethodView


# Generated at 2022-06-12 08:33:41.961889
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class Middleware(sanic.BaseHTTPMiddleware):
        def __init__(self, request, *args, **kwargs):
            super().__init__(request, *args, **kwargs)
            self.errors = []

    @Middleware.middleware
    async def middleware_func(request):
        request['is_group_middleware'] = True
        self.errors.append(request['is_group_middleware'])
        return await self.get_response(request)

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    class MyApp(sanic.Sanic):
        def get_middleware(self):
            return []

    app = MyApp()


# Generated at 2022-06-12 08:33:52.669443
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic(__name__)
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')


# Generated at 2022-06-12 08:34:00.309584
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic import Blueprint
    from sanic import Sanic

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix='/api', version='v1')
    bpg.append(bp1)
    bpg.append(bp2)

    bpg2 = BlueprintGroup(url_prefix='/api2', version='v2')
    bpg2.append(bp3)
    bpg2.append(bp4)

    # Register Blueprint group under the app
    app = Sanic()

# Generated at 2022-06-12 08:34:08.105128
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)

    @group.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')
    assert len(bp1.middlewares['request']) == 1
    assert len(bp2.middlewares['request']) == 1

# Generated at 2022-06-12 08:34:16.965444
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp = blueprint = Blueprint("bp", url_prefix="/bp")
    bp_group = BlueprintGroup(bp, url_prefix="/group")

    def middleware(request):
        return text("")

    with pytest.raises(TypeError):
        bp_group.middleware(middleware)

    bp_group.middleware(middleware, attach_to="request")

    assert middleware in bp.middleware("request")

# Generated at 2022-06-12 08:34:26.520057
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api/v1")

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    @bpg.middleware('request')
    async def bpg_middleware(request):
        request['data'] = 'hello'

    assert 'middleware' in bp1.handler_functions
    assert 'middleware' in bp2.handler_functions

    app = sanic.Sanic

# Generated at 2022-06-12 08:34:35.109934
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    from sanic import Blueprint

    bp = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bp3 = Blueprint("bp3")

    # Instantiate the blueprint group
    blueprint_group = BlueprintGroup()
    blueprint_group.append(bp)
    blueprint_group.append(bp2)
    blueprint_group.append(bp3)

    @blueprint_group.middleware("request")
    async def print_middleware(request):
        pass

    def check_that_middleware_is_applied():
        # Check that the middleware is applied to all the blueprints in the group
        for bp in blueprint_group.blueprints:
            assert bp.middlewares["request"][0] == print_middleware
            # Should be the only middleware

# Generated at 2022-06-12 08:34:44.920326
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic('test_BlueprintGroup_middleware')
    bp = Blueprint('test_BlueprintGroup_middleware')

    @bp.middleware('request')
    async def blueprint_middleware(request):
        print('Middleware on blueprint')

    @bp.group('/test_BlueprintGroup_middleware', strict_slashes=True)
    def test_BlueprintGroup_middleware_group(bp):
        pass

    @test_BlueprintGroup_middleware_group.middleware('request')
    async def group_middleware(request):
        print('Middleware on group')

    @test_BlueprintGroup_middleware_group.middleware('request')
    async def group_middleware2(request):
        print('Middleware on group2')


# Generated at 2022-06-12 08:34:55.816730
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3', version='v1')
    bp4 = Blueprint('bp4', url_prefix='/bp4', version='v1')
    bpg = BlueprintGroup(bp3, bp4, url_prefix='/api', version='v1')

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-12 08:35:05.487907
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Unit test for method middleware of class BlueprintGroup
    """
    bp1 = Blueprint("bp1", url_prefix="bp1")
    bp2 = Blueprint("bp2", url_prefix="bp2")

    group = BlueprintGroup("/api", "v1")
    group.append(bp1)
    group.append(bp2)

    @group.middleware("request")
    def test_middleware(request):
        request["test"] = True

    @bp1.route("/")
    async def index(request):
        return text("bp1")

    @bp2.route("/<param>")
    async def index(request, param):
        return text(param)

    app = sanic.Sanic("test_BlueprintGroup_middleware")
    app.blueprint(group)

   

# Generated at 2022-06-12 08:35:16.298330
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic(__name__)
    bp1 = Blueprint('bp1', '1.0', url_prefix='/bp1', strict_slashes=True)
    bp2 = Blueprint('bp2', '1.0', url_prefix='/bp2', strict_slashes=True)
    bp3 = Blueprint('bp3', '1.0', url_prefix='/bp3', strict_slashes=True)
    bp4 = Blueprint('bp4', '1.0', url_prefix='/bp4', strict_slashes=True)
    bpg = BlueprintGroup(url_prefix='/api', version='v1')
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
  

# Generated at 2022-06-12 08:35:23.395280
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Unit test to test the Blueprint.middleware method
    """
    def test_middleware_fn(request):
        pass
    bp = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = BlueprintGroup()
    group.append(bp)
    group.append(bp2)

    # Check generated Function
    f = group.middleware(test_middleware_fn)
    assert isinstance(f, partial)
    # check the call
    f()
    assert test_middleware_fn in bp.middlewares['request']
    assert test_middleware_fn in bp2.middlewares['request']

# Generated at 2022-06-12 08:35:32.422321
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix='/api/')
    bpg.append(bp3)
    bpg.append(bp4)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-12 08:35:40.321686
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bpg = BlueprintGroup(url_prefix="/api", version=1, strict_slashes=True)
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware("request")
    async def test_middleware(request):
        print("test_middleware")

    assert bp1.middlewares.get("request")[0] == (test_middleware, {})
    assert bp2.middlewares.get("request")[0] == (test_middleware, {})

    bpg.middleware(lambda req: None)(lambda req: None)
    assert bp1.middlewares.get("request")[1] == (lambda req: None, {})

# Generated at 2022-06-12 08:35:52.571134
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Create a BlueprintGroup instance
    bp_group = BlueprintGroup()
    # Create three blueprints
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')

    # Append the three blueprints in BlueprintGroup
    bp_group.append(bp1)
    bp_group.append(bp2)
    bp_group.append(bp3)

    # Define a dummy middleware
    @bp_group.middleware()
    async def bp_middleware(request):
        pass

    # Assert the dummy middleware is attached to all blueprints
    assert len(bp1.middlewares) == 1

# Generated at 2022-06-12 08:36:03.740692
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')
    bp7 = Blueprint('bp7', url_prefix='/bp7')
    bp8 = Blueprint('bp8', url_prefix='/bp8')
    bpg1 = BlueprintGroup(bp1, bp2)
    bpg2 = BlueprintGroup(bp3, bp4, bpg1)

# Generated at 2022-06-12 08:36:13.031672
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group = BlueprintGroup()
    blueprint_group.append(sanic.Blueprint("bp1", url_prefix="/bp1"))
    blueprint_group.append(sanic.Blueprint("bp2", url_prefix="/bp2"))

    @blueprint_group.middleware('request')
    async def request_middleware(request: sanic.request.Request):
        pass

    for blueprint in blueprint_group.blueprints:
        assert blueprint.url_for("request_middleware") == '/bp1/request_middleware'
        assert blueprint.middlewares['request'][0].__name__ == 'request_middleware'


# Generated at 2022-06-12 08:36:23.437380
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp = Blueprint("bp")
    bp.middleware(lambda x: x)
    bp1 = Blueprint("bp1")

    bpg = BlueprintGroup()
    bpg.append(bp)
    bpg.append(bp1)

    assert len(bpg.blueprints) == 2

    @bp.middleware("request")
    async def test_middleware(request) -> None:
        pass

    @bp1.middleware("request")
    async def test_middleware(request) -> None:
        pass

    @bpg.middleware("request")
    async def test_middleware(request) -> None:
        pass

    assert len(bp.middlewares["request"]) == 1
    assert len(bp1.middlewares["request"]) == 1
    assert len(bpg.blueprints)

# Generated at 2022-06-12 08:36:35.488031
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)

    assert bpg.middleware.__name__ == 'register_middleware_for_blueprints'

    @bp1.middleware("response")
    def bp1_request_middleware(request, handler):
        return handler(request)

    @bp2.middleware("response")
    def bp2_request_middleware(request, handler):
        return handler(request)


# Generated at 2022-06-12 08:36:46.045792
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic("test_BlueprintGroup_middleware")
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg1 = BlueprintGroup()
    bpg2 = BlueprintGroup()

    bpg1.append(bp1)
    bpg1.append(bp2)

    bpg2.append(bp3)
    bpg2.append(bp4)

    bpg2.append(bpg1)

    @bp1.listener('after_server_start')
    async def finish_startup(app, loop):
        app

# Generated at 2022-06-12 08:36:57.162587
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    try:
        Blueprint.middleware
        Blueprint.middlewares
        BlueprintGroup.middleware
    except AttributeError:
        raise AssertionError("middleware method not found on Blueprint")

    import traceback
    from sanic import Sanic, Blueprint
    from unittest import TestCase

    class BlueprintGroupMiddlewareTest(TestCase):
        def test_BlueprintGroup_middleware_valid(self):
            app = Sanic("Blueprint - Group  Middleware Test")
            bp1 = Blueprint("bp1", url_prefix="bp1")
            bp2 = Blueprint("bp2", url_prefix="bp2")

            bp1.middleware("request")(lambda x: None)
            bp1.middleware("response")(lambda x: None)

# Generated at 2022-06-12 08:37:07.627444
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp1')
    bp4 = Blueprint('bp4', url_prefix='/bp2')

    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')

    bp7 = Blueprint('bp7', url_prefix='/bp7')
    bp8 = Blueprint('bp8', url_prefix='/bp8')

    bpg1 = BlueprintGroup(url_prefix="/api", version="v1")

    bpg1.append(bp5)
    bpg1.append(bp6)


# Generated at 2022-06-12 08:37:17.830860
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp2.middleware('request')
    async def bp2_only_middleware(request):
        print('applied on Blueprint : bp2 Only')
    
    @bpg.middleware('request')
    async def group_middleware(request):
        print('applied on BlueprintGroup : bpg')

# Generated at 2022-06-12 08:37:25.818254
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_1 = sanic.Blueprint('test_blueprint_1', url_prefix='/test_blueprint')
    blueprint_group = BlueprintGroup(url_prefix="test_api")
    blueprint_group.append(blueprint_1)

    @blueprint_group.middleware('request')
    async def test_middleware_1(request):
        print('test_middleware_1')

    @blueprint_1.middleware('request')
    async def test_middleware_2(request):
        print('test_middleware_2')

# Generated at 2022-06-12 08:37:41.638141
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Create a Blueprint
    bp = Blueprint('bp')
    # Create a BlueprintGroup
    bpg = BlueprintGroup()
    # Add Blueprint to BlueprintGroup
    bpg.append(bp)
    
    @bp.middleware('request')
    async def bp_req_handler(request):
        """
        Add a middleware to the blueprint
        """
        pass

    # Create a mock function
    async def request_handler(req):
        """
        A simple request handler
        """
        pass

    @bpg.middleware('request')
    def bpg_req_handler(req):
        """
        Add a middleware to BlueprintGroup
        """
        pass

    # Assert that bpg_req_handler is one of the request middlewares of
    # Blueprint bp

# Generated at 2022-06-12 08:37:49.901933
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Create a mock app
    app = Mock(spec=sanic.Sanic)

    # Create a mock blueprint
    bp = Mock(spec=sanic.Blueprint)

    # Create BlueprintGroup with blueprint
    blueprint_group = BlueprintGroup()
    blueprint_group.blueprints = [bp]

    # Create a dummy middleware
    @blueprint_group.middleware("request")
    async def group_middleware(request):
        pass

    # Check if middleware is registered on blueprint
    bp.middleware.assert_called_once_with(group_middleware, "request")

# Generated at 2022-06-12 08:37:57.987830
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    assert bp1.has_middleware('request') is True
    assert bp2.has_middleware('request') is True


# Generated at 2022-06-12 08:38:08.871550
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """Unit test for method middleware of class BlueprintGroup"""
    @sanic.blueprint.BlueprintGroup.middleware('request')
    async def test_middleware():
        return

    @sanic.blueprint.BlueprintGroup.middleware('request')
    async def test_middleware_with_args(request):
        return

    assert isinstance(sanic.blueprint.BlueprintGroup.middleware,
                      functools.partial)
    assert sanic.blueprint.BlueprintGroup.middleware.func is BlueprintGroup.middleware
    assert isinstance(sanic.blueprint.BlueprintGroup.middleware_with_args,
                      functools.partial)
    assert sanic.blueprint.BlueprintGroup.middleware_with_args.func is BlueprintGroup.middleware

    bp_group = sanic.blueprint

# Generated at 2022-06-12 08:38:19.101203
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = Mock()
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware("request")
    def test_middleware():
        return "test"

    bpg.middleware(test_middleware, "response")

    bp1_middleware = dict(bp1.middleware_stack)
    bp2_middleware = dict(bp2.middleware_stack)

    assert bp1_middleware["request"] == [test_middleware]
    assert bp1_middleware["response"] == [test_middleware]
    assert bp2_middleware["request"] == [test_middleware]
    assert bp2_middle

# Generated at 2022-06-12 08:38:25.923123
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(bp1, bp2)
    # Calling middleware with function and middleware name as positional
    # parameter.
    @bpg.middleware("response")
    def bpg_middleware(request):
        assert True # just want to know if this code is called
    # Calling middleware with function as only parameter
    @bpg.middleware
    def request_middleware(request):
        assert True
    # Calling middleware with function as only parameter
    @bpg.middleware("request")
    def response_middleware(request):
        assert True

    # Asserting the middleware is applied on all the blueprints in the
    # bpg

# Generated at 2022-06-12 08:38:33.679298
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    @bp3.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp4.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    # common middleware

# Generated at 2022-06-12 08:38:45.151760
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    def middleware_fn1(request):
        return request

    def middleware_fn2(request):
        return request

    app = sanic.Sanic()
    bp1 = Blueprint(app=app, name='bp1', url_prefix='/bp1')
    bp2 = Blueprint(app=app, name='bp2', url_prefix='/bp2')

    group = BlueprintGroup(url_prefix="/api", version="v1")
    group.append(bp1)
    group.append(bp2)

    @group.middleware
    def middleware_fn1(request):
        return request

    @group.middleware('request')
    def middleware_fn2(request):
        return request


# Generated at 2022-06-12 08:38:54.526180
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    @bp1.middleware('request')
    def middleware_one(request):
        return True

    @bp2.middleware('request')
    def middleware_two(request):
        return True

    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)

    @group.middleware('request')
    def group_middleware(request):
        return True

    assert group_middleware in bp1.request_middleware
    assert group_middleware in bp2.request_middleware

    assert not callable(group_middleware)
    assert not callable(group_middleware())



# Generated at 2022-06-12 08:39:05.339568
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bp3 = Blueprint("bp3")
    bp4 = Blueprint("bp4")
    bp5 = Blueprint("bp5")
    bp6 = Blueprint("bp6")

    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")
    bp5 = Blueprint("bp5", url_prefix="/bp5")
    bp6 = Blueprint("bp6", url_prefix="/bp6")

    bpg1 = BlueprintGroup(bp1, bp2, version="v1")
    bpg2

# Generated at 2022-06-12 08:39:28.206020
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    app = sanic.Sanic("sanic_test")
    bp1 = Blueprint("test_bp1", url_prefix="/bp1")
    bp2 = Blueprint("test_bp2", url_prefix="/bp2")
    bp3 = Blueprint("test_bp3", url_prefix="/bp3")
    bp4 = Blueprint("test_bp4", url_prefix="/bp4")

    group = BlueprintGroup(url_prefix="/grp1")
    group.insert(0, bp1)
    group.insert(1, bp2)
    group.insert(2, bp3)
    group.insert(3, bp4)
    assert len(group) == 4
    assert group[0].url_prefix == "/grp1/bp1"

# Generated at 2022-06-12 08:39:35.409347
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    app = sanic.Sanic("test_BlueprintGroup_append")
    bp3 = Blueprint("bp3", url_prefix="/bp4")
    bp4 = Blueprint("bp4", url_prefix="/bp4")
    
    bpg_bad = BlueprintGroup("/api", "v1")
    bpg_good = BlueprintGroup("/api", "v1")

    @bp3.route("/")
    async def bp1_route(request):
        return html("bp1")

    @bp4.route("/<param>")
    async def bp2_route(request, param):
        return html(param)
    
    bpg_bad.append(bp3)
    bpg_good.append(bp4)
    app.blueprint(bpg_bad)

# Generated at 2022-06-12 08:39:42.880479
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(bp1)

    @bp2.middleware('request')
    async def bp2_only_middleware(request):
        print('applied on Blueprint : bp2 Only')

    @bp1.middleware('response')
    async def bp1_only_middleware(request, response):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp1.route('/<param>')
    async def bp2_route(request, param):
        return text(param)


# Generated at 2022-06-12 08:39:50.659497
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint("bp1", url_prefix="bp1")
    bp2 = Blueprint("bp2", url_prefix="bp2")
    bpg = BlueprintGroup(bp1, bp2, url_prefix="bpg")
    # when BlueprintGroup is not empty
    del bpg[0]
    assert len(bpg) == 1
    assert bpg is not None
    assert bpg[0] == bp2
    # when BlueprintGroup is empty
    try:
        bpg.__delitem__(0)
    except IndexError:
        assert bpg is not None


# Generated at 2022-06-12 08:39:53.650605
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group = BlueprintGroup()
    blueprint_group._blueprints = [0, 1, 2]
    blueprint_group.__setitem__(0, 3)
    assert blueprint_group._blueprints == [3, 1, 2]


# Generated at 2022-06-12 08:39:59.332527
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic(__name__)

    @sanic.blueprint
    @sanic.response.json
    @sanic.exception(sanic.exceptions.NotFound)
    def bp(request):
        pass

    bpg = BlueprintGroup()
    bpg.append(bp)
    # Unit test for middleware of class BlueprintGroup
    @bpg.middleware('request')
    def middleware(request):
        pass
    response = app.request('GET', '/', port=8000)

    assert response.status == 404

# Generated at 2022-06-12 08:40:02.817820
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bpg = BlueprintGroup(bp1, bp2)
    assert bpg[0] == bp1
    assert bpg[1] == bp2


# Generated at 2022-06-12 08:40:09.776638
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api")
    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg[0] is not None
    assert bpg[1] is not None

    del bpg[0]

    assert bpg[0] is bp2

    del bpg[0]

    assert len(bpg) == 0


# Generated at 2022-06-12 08:40:18.137789
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    __sanitize_blueprint_original = BlueprintGroup._sanitize_blueprint
    BlueprintGroup._sanitize_blueprint = lambda self, bp: bp

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    blueprint_group = BlueprintGroup(url_prefix="api", version="v1")

    blueprint_group.append(bp1)
    blueprint_group.append(bp2)

    assert blueprint_group[0] == bp1
    assert blueprint_group[1] == bp2

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    blueprint_group.insert(1, bp3)

    assert blueprint_group[0] == bp1

# Generated at 2022-06-12 08:40:29.029935
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    assert bp1.blueprint_group == None
    assert bp2.blueprint_group == None

    bpg = BlueprintGroup(url_prefix='/api')
    bpg.append(bp1)
    bpg.append(bp2)

    assert bp1.blueprint_group == bpg
    assert bp2.blueprint_group == bpg
    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert bpg[2] == None
    assert bpg[-1] == bp2
    assert bpg[-2] == bp1
    bpg[0] = bp2
   

# Generated at 2022-06-12 08:40:57.065595
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    """
    This test ensures that we can iterate over each of blueprints
    after we have our BlueprintGroup object initialized.

    The test also ensures that each of the Blueprint object has the
    modified prefix and version applied.
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')


# Generated at 2022-06-12 08:41:04.393101
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2)

    @group.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    assert len(bp1.middlewares.get('request')) == 1
    assert len(bp2.middlewares.get('request')) == 1

    assert bp1.middlewares.get('request') == bp2.middlewares.get('request')

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

   