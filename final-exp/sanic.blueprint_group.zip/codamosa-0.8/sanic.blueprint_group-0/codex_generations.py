

# Generated at 2022-06-12 08:31:07.210855
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic("test_BlueprintGroup_middleware")
    blueprint = Blueprint("test_BlueprintGroup_middleware")
    blueprint_group = BlueprintGroup()
    blueprint.add_route(lambda x : None, None)
    blueprint_group.append(blueprint)
    
    @blueprint_group.middleware('request')
    async def test(request):
        return True

    assert id(test) == id(blueprint.middleware('request')(test))
    assert id(test) == id(blueprint_group.middleware('request')(test))


# Generated at 2022-06-12 08:31:13.756972
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    This method is used for test BlueprintGroup class
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)


# Generated at 2022-06-12 08:31:21.170453
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Unit test for method middleware of class BlueprintGroup
    """
    URLS = [
        "/bp1/",
        "/bp2/",
        "/api/v1/bp3/",
        "/api/v1/bp4/",
        "/api/v1/bp3/first",
    ]
    app = sanic.Sanic("test_BlueprintGroup_middleware")

    # Testing blueprint group having blueprints without middleware
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bp3 = Blueprint("bp3")
    bp4 = Blueprint("bp4")

    @bp1.route("/")
    async def bp1_route(request):
        return text("bp1")


# Generated at 2022-06-12 08:31:31.282114
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg1 = BlueprintGroup()
    bpg1.append(bp1)
    bpg1.append(bp2)

    bpg2 = BlueprintGroup()
    bpg2.append(bp3)
    bpg2.append(bp4)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')


# Generated at 2022-06-12 08:31:45.369467
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp_G = BlueprintGroup()
    blueprint = Blueprint("4_K_9s_4_MIL", url_prefix="/pets")

    @bp_G.middleware('request')
    def request_handler():
        pass

    @bp_G.middleware('response')
    def response_handler():
        pass

    @bp_G.middleware
    def request_handler2():
        pass

    @bp_G.middleware('request')
    def response_handler2():
        pass

    bp_G.append(bp_G)
    bp_G.append(blueprint)

    assert len(bp_G.blueprints) == 2
    assert len(blueprint.middlewares['request']) == 3
    assert len(blueprint.middlewares['response']) == 2



# Generated at 2022-06-12 08:31:57.323855
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bp3 = Blueprint("bp3")
    bp4 = Blueprint("bp4")
    bpg = BlueprintGroup(bp3, bp4)
    bpgrp_bpgrp = BlueprintGroup(bp1, bp2, bpg)

    class X:
        pass
    x = X()
    x.bp_list = []

    def x_middleware(request):
        x.bp_list.append(request.blueprint)

    bpgrp_bpgrp.middleware(x_middleware)

    # Test middleware execution in BlueprintGroup of BlueprintGroup
    @bp1.route("/bp1")
    async def bp1_handler(request):
        return text("bp1")


# Generated at 2022-06-12 08:32:06.512795
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")

    bp3 = Blueprint("bp3")
    bp4 = Blueprint("bp4")

    bpg = BlueprintGroup()
    bpg.extend([bp3, bp4])

    def middleware(request):
        return request

    bpg.middleware(middleware)

    assert len(bp3.middlewares) == 1
    assert len(bp4.middlewares) == 1

    assert bp3.middlewares == bp4.middlewares

    assert bp3.middlewares[0].middleware == middleware



# Generated at 2022-06-12 08:32:14.587073
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class TestApp(sanic.Sanic):
        pass

    @BlueprintGroup.middleware('request')
    async def test_middleware(request):
        return text('test_middleware')

    app = TestApp()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)

    app.blueprint(group)

    assert all(app.middlewares['request'])



# Generated at 2022-06-12 08:32:22.838819
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    def wrapper(func):
        def wrapped(*args, **kwargs):
            return func(*args, **kwargs)

        return wrapped

    bp: BlueprintGroup = BlueprintGroup()
    bp.append(Blueprint('bp1'))
    bp.append(Blueprint('bp2'))

    @bp.middleware('request')
    def test_middleware(request):
        """Some Test Middleware"""

    assert 'test_middleware' in [
        m.__name__ for b in bp.blueprints for m in b.middlewares
    ]

    # Re-attach the middleware for the same blueprint again
    @bp.middleware('request')
    def test_middleware_endpoint(request):
        """Some Test Endpoint Middleware"""


# Generated at 2022-06-12 08:32:30.625959
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bp3 = sanic.Blueprint('bp3', url_prefix='/bp3')
    bp4 = sanic.Blueprint('bp4', url_prefix='/bp4')
    bp5 = sanic.Blueprint('bp5', url_prefix='/bp5')

    bpg1 = BlueprintGroup(bp1, bp2)
    bpg2 = BlueprintGroup(bp3, bpg1, bp5)


# Generated at 2022-06-12 08:32:43.206131
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Creating Blueprint
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")

    # Creating BlueprintGroup
    group = BlueprintGroup()
    group.append(bp1)

    # Registering middleware to the group
    @group.middleware("request")
    async def common_middleware(request):
        print("Middleware applied to all blueprints of group")

    # Registering middleware to the group with decorator
    @group.middleware("request")
    async def common_middleware_with_decorator(request):
        print("Middleware with decorator applied to all blueprints of group")

    # Registering middleware to the group with decorator

# Generated at 2022-06-12 08:32:53.894087
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')
    bp7 = Blueprint('bp7', url_prefix='/bp7')
    bp8 = Blueprint('bp8', url_prefix='/bp8')
    bpg1 = BlueprintGroup('bpg1', url_prefix="/bpg1")
    bpg1.append(bp1)
    bpg1.append(bp2)
    bpg2

# Generated at 2022-06-12 08:33:01.729908
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Test BlueprintGroup.middleware decorator
    from sanic import Blueprint, Sanic

    blueprint = Blueprint("bp")
    blueprint.middleware(None)  # noqa
    blueprint.middleware(lambda request: None, attach_to="request")  # noqa
    blueprint.middleware(lambda request: None, attach_to="response")  # noqa
    blueprint.middleware(lambda request: None, attach_to="both")  # noqa
    blueprint.middleware(lambda request: None, attach_to="after_server")  # noqa
    blueprint.middleware(lambda request: None, attach_to="before_server")  # noqa

    app = Sanic(__name__)
    app.blueprint(blueprint)



# Generated at 2022-06-12 08:33:07.245462
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic import Blueprint
    from sanic.response import text

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)


# Generated at 2022-06-12 08:33:16.699460
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('Not applied sometimes')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    group = Blueprint.group(bp1, bp2)

    @group.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    # Test Middleware Common for both


# Generated at 2022-06-12 08:33:27.431151
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @sanic.blueprints.Blueprint.middleware
    def bp_middleware(request):
        print("bp_middleware called")
    @sanic.blueprints.Blueprint.middleware(name='response_middleware')
    def response_middleware(request, response):
        print("response_middleware called")
    @sanic.blueprints.Blueprint.middleware(name='error_middleware')
    def error_middleware(request, exception):
        print("error_middleware called")
    bp1 = sanic.blueprints.Blueprint('bp1')
    bp2 = sanic.blueprints.Blueprint('bp2')
    bp_group = sanic.blueprints.BlueprintGroup()
    bp_group.append(bp1)
    bp_group.append(bp2)

# Generated at 2022-06-12 08:33:38.999435
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    group = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    @bp1.route("/")
    async def bp1_route(request):
        return text("bp1")

    @bp2.route("/<param>")
    async def bp2_route(request, param):
        return text(param)

    @group.middleware("request")
    async def group_middleware(request):
        request["group_middleware"] = "true"

    mock_app = sanic.Sanic("test_BlueprintGroup_middleware")
    mock_app.blueprint(group)
    mock_app.add_task

# Generated at 2022-06-12 08:33:47.916943
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from unittest.mock import patch
    from sanic import Sanic, Blueprint

    app = Sanic('test_BlueprintGroup_middleware')

    # Construct the Blueprint Group
    group = BlueprintGroup()

    # Create a new Blueprint
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')

    # Add blueprints to Blueprint group
    group.append(bp1)
    group.append(bp2)

    # Wrap the blueprints with Mock
    with patch.multiple(bp1, middleware=lambda *args, **kwargs: None) as bp1_mock, \
            patch.multiple(bp2, middleware=lambda *args, **kwargs: None) as bp2_mock:

        @group.middleware
        def middleware(request):
            return

        # Ass

# Generated at 2022-06-12 08:33:55.903790
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic.response import text
    from sanic.blueprints import Blueprint

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bp_g1 = Blueprint.group(bp1, bp2)
    bp_g2 = Blueprint.group(bp3, bp4)
    bp_g3 = Blueprint.group(bp_g1, bp_g2)

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-12 08:34:07.584979
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic import Blueprint
    from sanic.views import HTTPMethodView
    from sanic.response import json

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp3 = Blueprint('bp3', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")


    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')


# Generated at 2022-06-12 08:34:16.888871
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic.blueprints import Blueprint
    # Create blueprint
    blueprint = Blueprint('blueprint', url_prefix='test')
    # Create blueprint group
    blueprintgroup = BlueprintGroup('testgroup')
    blueprintgroup.append(blueprint)
    # Middleware
    @blueprintgroup.middleware()
    def middleware():
        """
        Modify the request
        """
        pass
    # Verify if middleware is set
    assert blueprint.middlewares[0] == middleware



# Generated at 2022-06-12 08:34:23.950603
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    assert bp1.has_middleware
    assert bp2.has_middleware


# Generated at 2022-06-12 08:34:33.386723
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    from sanic.blueprints import Blueprint

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)

    bpg2 = BlueprintGroup(url_prefix="/api2", version="v2")
    bpg2.append(bp4)
    bpg.append(bpg2)


# Generated at 2022-06-12 08:34:40.491204
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp = Blueprint("bp")
    bp.middleware("request")(print)
    assert len(bp.middlewares["request"]) == 1

    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")

    bpg = BlueprintGroup(url_prefix="/bpg")
    bpg.middleware("request")(print)
    assert len(bpg.middlewares["request"]) == 1
    bpg += [bp1, bp2]
    assert len(bp1.middlewares["request"]) == 2
    assert len(bp2.middlewares["request"])

# Generated at 2022-06-12 08:34:52.249775
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Setup
    app = sanic.Sanic("test_BlueprintGroup_middleware")
    bp = Blueprint("test_bp")
    bg = BlueprintGroup()

    bg.append(bp)

    # Test without args
    @bg.middleware
    async def mw1(request):
        pass

    @bp.route("/mw1")
    async def handler(request):
        pass

    request, response = app.test_client.get("/mw1")

    assert response.status == 200

    # Test with args
    @bg.middleware("request")
    async def mw2(request):
        pass

    @bp.route("/mw2")
    async def handler(request):
        pass

    request, response = app.test_client.get("/mw2")

   

# Generated at 2022-06-12 08:35:03.779761
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Blueprints instances 
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    
    # Instantiate BlueprintGroup class
    bpg = BlueprintGroup()
    # Add blueprints instances to the BlueprintGroup class
    bpg.append(bp1)
    bpg.append(bp2)
    
    # Define a function
    def fn(request):
        print('Function - fn')
    # Register the middleware for BlueprintGroup
    bpg.middleware(fn)

    # Apply the middleware for all the blueprints under the BlueprintGroup
    for blueprint in bpg.blueprints:
        for middleware in blueprint.middlewares['request']:
            if middleware.__name__ == 'fn':
                return True
   

# Generated at 2022-06-12 08:35:11.952399
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp = Blueprint("bp", url_prefix="/bp")
    bpg = BlueprintGroup()
    bpg.append(bp)
    @bp.middleware("request")
    async def test_middleware(request):
        pass
    assert len(bp.request_middleware) == 1
    assert len(bp.response_middleware) == 0
    @bpg.middleware("request")
    async def test_middleware(request):
        pass
    assert len(bp.request_middleware) == 2
    assert len(bp.response_middleware) == 0
    @bpg.middleware("response")
    async def test_middleware(request):
        pass
    assert len(bp.request_middleware) == 2
    assert len(bp.response_middleware) == 1

# Generated at 2022-06-12 08:35:21.480114
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic("test_BlueprintGroup_middleware")

    @sanic.response.json
    async def bp1_handler(request):
        return {"hello": "bp1"}

    @sanic.response.json
    async def bp2_handler(request):
        return {"hello": "bp2"}

    bp1 = sanic.Blueprint("bp1")
    bp1.add_route(bp1_handler, "/")

    bp2 = sanic.Blueprint("bp2")
    bp2.add_route(bp2_handler, "/")

    @bp1.middleware("request")
    async def bp1_mw(request):
        """
        Dummy middleware function for bp1
        """
        request["bp1_mw"] = True

   

# Generated at 2022-06-12 08:35:29.336895
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    async def middleware1(request):
        pass

    async def middleware2(request):
        pass

    async def middleware3(request):
        pass

    app = sanic.Sanic()
    bp = Blueprint("my_bp", url_prefix="/bp")

    # Test simple middleware decorator
    bp_group = Blueprint.group(bp, url_prefix="/group")
    bp_group.middleware(middleware1)
    assert hasattr(bp_group, "middleware_handler")
    assert callable(bp_group.middleware_handler)

    # Test multiple middleware decorators
    bp_group.middleware(middleware2, middleware3)
    assert bp_group.middleware_handler.middleware[0] == middleware1
    assert bp_group.middleware_handler

# Generated at 2022-06-12 08:35:36.275821
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)

    @group.middleware('request')
    async def group_middleware(request):
        pass

    # verify that the method have added middleware to both the blueprints
    assert group.blueprints[0].middleware_stack['request'][0] == group_middleware
    assert group.blueprints[1].middleware_stack['request'][0] == group_middleware


# Generated at 2022-06-12 08:35:47.417534
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')
    bp7 = Blueprint('bp7', url_prefix='/bp7')
    bp8 = Blueprint('bp8', url_prefix='/bp8')

    bpg1 = BlueprintGroup(bp1, bp2)
    bpg1.append(bp3)
    bpg2 = BlueprintGroup(bp4, bp5, bpg1)


# Generated at 2022-06-12 08:35:56.804410
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")
    bp5 = Blueprint("bp5", url_prefix="/bp5")

    bp6 = Blueprint("bp6", url_prefix="/bp6")
    bp7 = Blueprint("bp7", url_prefix="/bp7")
    bp8 = Blueprint("bp8", url_prefix="/bp8")
    bp9 = Blueprint("bp9", url_prefix="/bp9")
    bp10 = Blueprint("bp10", url_prefix="/bp10")

    bpg1 = BlueprintGroup()
    bpg1.append(bp1)

# Generated at 2022-06-12 08:36:04.177603
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bpg = BlueprintGroup()

    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware(arg1=1)
    def bpg_middleware(request):
        return text("Middleware applied to Blueprint")

    assert len(bp1.middlewares["request"]) == 1
    assert len(bp2.middlewares["request"]) == 1



# Generated at 2022-06-12 08:36:09.975164
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic(__name__)
    bp = Blueprint('bp1', url_prefix='/bp1')
    bp = Blueprint('bp2', url_prefix='/bp2')
    bp = Blueprint('bp3', url_prefix='/bp4')
    bp = Blueprint('bp3', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        pass
    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

# Generated at 2022-06-12 08:36:17.765406
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic(__name__)
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    group = Blueprint.group(bp1, bp2)
    group2 = Blueprint.group(bp3, bp4)
    group_of_group = Blueprint.group(group, group2)
    @group_of_group.middleware('request')
    async def group_of_group_middleware(request):
        print('common middleware applied for group group')


# Generated at 2022-06-12 08:36:25.240861
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Create BlueprintGroup
    class MyBlueprint(sanic.Blueprint):
        def middleware(self, fn, *args, **kwargs):
            return fn

    bp1 = MyBlueprint('bp1', url_prefix='/bp1')
    bp2 = MyBlueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    @bpg.middleware
    async def bpg_middleware(request):
        pass

    @bpg.middleware('request')
    async def bpg_middleware_extra(request):
        pass

    # Register Blueprint group under the app
    assert bp1.middlewares
    assert bp2.middlewares

    assert bp1.middlewares == b

# Generated at 2022-06-12 08:36:36.992481
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    import unittest
    from unittest.mock import MagicMock

    class TestBlueprintGroup(unittest.TestCase):
        def test_middleware_blueprint_group(self):
            bp1 = Blueprint("bp1", url_prefix="/bp1")
            bp2 = Blueprint("bp2", url_prefix="/bp2")
            bpg = BlueprintGroup(bp1, bp2)

            mock_func = MagicMock()

            @bpg.middleware("request")
            def bp_group_middleware(request):
                mock_func()

            self.assertEqual(bp1.middlewares["request"], [bp_group_middleware])
            self.assertEqual(bp2.middlewares["request"], [bp_group_middleware])


# Generated at 2022-06-12 08:36:46.338493
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class AsyncMock:
        async def __call__(self, request):
            return True

    async_mock = AsyncMock()
    async_mock2 = AsyncMock()

    b1 = Blueprint("b1", "b1")

    b2 = Blueprint("b2", "b2")
    b3 = Blueprint("b3", "b3")
    b3.middleware(async_mock)

    bg = BlueprintGroup()

    bg.append(b2)
    bg.append(b3)

    @bg.middleware("request")
    async def middleware(request):
        return True

    assert b1.middlewares["request"][0] is None
    assert b2.middlewares["request"][0] is middleware
    assert b3.middlewares

# Generated at 2022-06-12 08:36:57.431385
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic('test_BlueprintGroup_middleware')
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    group1 = BlueprintGroup()
    group2 = BlueprintGroup()
    group3 = BlueprintGroup(url_prefix='/api', version='v1')
    group1.append(bp1)
    group2.append(bp2)
    group1.append(bp3)
    group2.append(bp4)
    group3.append(group1)
    group3.append(group2)


# Generated at 2022-06-12 08:37:07.963080
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    b1 = sanic.Blueprint('test_BlueprintGroup_middleware_b1')
    b2 = sanic.Blueprint('test_BlueprintGroup_middleware_b2')
    bg = BlueprintGroup()

    mw = []

    @b1.middleware('request')
    async def b1_only_middleware(request):
        mw.append('b1')

    @b2.middleware('request')
    async def b2_only_middleware(request):
        mw.append('b2')

    bg.append(b1)
    bg.append(b2)

    @bg.middleware('request')
    async def group_middleware(request):
        mw.append('group')


# Generated at 2022-06-12 08:37:21.003764
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class App(sanic.Sanic):
        pass

    app = App()

    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")

    bpg = BlueprintGroup("/api", "v1")
    bpg.append(bp3)
    bpg.append(bp4)

    app.blueprint(bpg)

    @bp1.middleware("request")
    async def bp1_only_middleware(request):
        print("applied on Blueprint : bp1 Only")


# Generated at 2022-06-12 08:37:29.680898
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic(__name__)
    app.config.REQUEST_MAX_SIZE = 10 * 1024 * 1024
    app.config.REQUEST_TIMEOUT = 60

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

# Generated at 2022-06-12 08:37:35.825069
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
            pass

    @bp1.route('/')
    async def bp1_route1(request):
        pass

    @bp1.route('/')
    async def bp1_route2(request):
        pass

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        pass

    group = Blueprint.group(bp1, bp2, url_prefix="/group")


# Generated at 2022-06-12 08:37:47.096480
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    app = sanic.Sanic('test_BlueprintGroup_middleware')
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')



# Generated at 2022-06-12 08:37:58.545168
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api")

    @bpg.middleware
    async def bpg_middleware(request):
        assert True

    @bpg.middleware('request')
    async def bpg_request_middleware(request):
        assert True

    @bpg.middleware('response')
    async def bpg_response_middleware(request, response):
        assert True

    @bp1.middleware
    async def bp1_middleware(request):
        assert True

    @bp2.middleware('request')
    async def bp2_request_middleware(request):
        assert True

   

# Generated at 2022-06-12 08:38:08.940769
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-12 08:38:19.220018
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # create three Blueprint instances
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')

    # create BlueprintGroup and add the three Blueprint instances to it
    bpg = BlueprintGroup()
    bpg.extend([bp1, bp2, bp3])

    # check if the BlueprintGroup contains 3 different Blueprint instances
    assert len(bpg) == 3

    # create BlueprintGroup and add the three Blueprint instances to it
    bpg = BlueprintGroup()
    bpg.extend([bp1, bp2, bp3])

    # check if the BlueprintGroup contains 3 different Blueprint instances
    assert len(bpg) == 3

    # set the BlueprintGroup's

# Generated at 2022-06-12 08:38:23.604697
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @sanic.blueprint.middleware('request')
    def registered_middleware(request):
        pass

    @sanic.blueprint.middleware('response')
    def registered_middleware(request):
        pass

    @sanic.blueprint.middleware('request', ['POST', 'GET'])
    def registered_middleware(request):
        pass

    group = sanic.blueprint.BlueprintGroup()
    group.middleware(registered_middleware)

# Generated at 2022-06-12 08:38:32.454276
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    class App(sanic.Sanic):
        pass

    app = App()

    @app.route('/')
    async def test(request):
        return text('OK')

    @app.blueprint('/test')
    async def test_blueprint_group(request):
        return text('OK')

    @app.middleware('request')
    async def add_header(request):
        request.headers['x-test'] = '1'

    app.blueprint.middleware(
        lambda f: f,
        add_header,
    )

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.headers.get('x-test') == '1'

    request, response = app.test_client.get('/test')

# Generated at 2022-06-12 08:38:43.635841
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    A test function to test the functionality by using method middleware of BlueprintGroup
    """
    from sanic import Sanic
    from sanic.response import text
    from sanic.blueprints import Blueprint

    app = Sanic()

    bp1 = Blueprint('bp1', url_prefix='/bp1')

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    bpg = BlueprintGroup(bp1, url_prefix="/api", version="v1")


# Generated at 2022-06-12 08:38:57.169154
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # type: () -> None
    """
    Test the method :meth:`~BlueprintGroup.middleware` of class
    `BlueprintGroup`
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    @bp1.route('/1')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/2')
    async def bp2_route(request):
        return text('bp2')


# Generated at 2022-06-12 08:39:07.041462
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bp3 = sanic.Blueprint('bp3', url_prefix='/bp3')
    bp4 = sanic.Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix='/api', version='v1')
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    @bpg.middleware('request')
    def middleware(request):
        pass

    assert bp1.middleware_stack
    assert bp2.middleware_stack
    assert b

# Generated at 2022-06-12 08:39:14.119389
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic.blueprints import Blueprint
    from sanic.app import Sanic
    from sanic.response import text

    def create_bp():
        bp = Blueprint("test")
        @bp.route("/")
        async def bp_route(request):
            return text("")
        return bp

    bp1 = create_bp()
    bp2 = create_bp()

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    called = False
    @bpg.middleware
    async def test(request):
        nonlocal called
        called = True

    @bp1.middleware
    async def test1(request):
        nonlocal called
        called = True

    app = Sanic("test_BlueprintGroup_middleware")
   

# Generated at 2022-06-12 08:39:22.301216
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware('request')
    async def bp1_only_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    assert bpg.blueprints[0].middleware_stack['request'] == [bp1_only_middleware]
    assert bpg.blueprints[1].middleware_stack['request'] == [bp1_only_middleware]

# Generated at 2022-06-12 08:39:27.827836
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    def mw(request):
        pass

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    
    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bpg) == 2
    assert len(bp1.middlewares) == 0
    assert len(bp2.middlewares) == 0

    bpg.middleware(mw, attach_to='request')
    
    assert len(bp1.middlewares) == 1
    assert len(bp2.middlewares) == 1

# Generated at 2022-06-12 08:39:36.961084
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Test BlueprintGroup.middleware decorator with no parameter
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware
    async def request_middleware(request):
        pass

    assert "request_middleware" in bp1.middlewares['request'] + \
           bp2.middlewares['request']
    assert "request_middleware" not in bp1.middlewares['response'] + \
           bp2.middlewares['response']

    # Test BlueprintGroup.middleware decorator with parameters

# Generated at 2022-06-12 08:39:43.851897
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware('request')
    async def bpg_group_middleware(request):
        request['group_middleware_applied'] = True

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        request['blueprint1_middleware_applied'] = True

    @bp2.middleware('request')
    async def bp2_only_middleware(request):
        request['blueprint2_middleware_applied'] = True

# Generated at 2022-06-12 08:39:51.366233
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    bpg.middleware(bp1.middleware('request'))
    bpg.middleware(bp2.middleware('response'))

# Generated at 2022-06-12 08:39:59.192499
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # simple function for reuse
    def simple_middleware(request):
        pass
    pbpg = BlueprintGroup()
    pb1 = Blueprint('pb1')
    pb2 = Blueprint('pb2')
    pbpg.append(pb1)
    pbpg.append(pb2)
    assert not pb1.middlewares
    assert not pb2.middlewares
    pbpg.middleware(simple_middleware)
    assert pb1.middlewares
    assert pb2.middlewares
    pbpg.middleware(simple_middleware, 'request')
    assert pb1.middlewares['request']
    assert pb2.middlewares['request']



# Generated at 2022-06-12 08:40:05.012906
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    @BluprintGroup.middleware('request')
    async def group_middleware(request):
        print('middleware applied for all blueprints in the group')

    assert len(BluprintGroup.middlewares['request']) == 1


    @BluprintGroup.middleware('request', attach_to_all=False)
    async def group_middleware(request):
        print('middleware applied for only this blueprint')

    assert len(BluprintGroup.middlewares['request']) == 2

# Generated at 2022-06-12 08:40:15.738462
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic("test_BlueprintGroup_middleware")
    blueprint = Blueprint("blueprint")
    blueprint.middleware(lambda x: True,"*","*")
    blueprint_group = BlueprintGroup()
    blueprint_group.append(blueprint)
    blueprint_group.middleware(lambda x: True,"*","*")
    assert blueprint.middlewares[0][0].__name__ == "<lambda>"


# Generated at 2022-06-12 08:40:25.446487
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprints = [
        Blueprint("test1", url_prefix="/test1"),
        Blueprint("test2", url_prefix="/test2"),
        Blueprint("test3", url_prefix="/test3"),
    ]

    bpg = BlueprintGroup(url_prefix="/test")
    bpg.extend(blueprints)

    def middleware_callable(request):
        pass

    bpg.middleware(middleware_callable, 'request')

    for blueprint in blueprints:
        assert middleware_callable in blueprint.middlewares["request"]

    @bpg.middleware('request')
    def middleware_decorator(request):
        pass

    for blueprint in blueprints:
        assert middleware_decorator in blueprint.middlewares["request"]



# Generated at 2022-06-12 08:40:35.010206
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic('test_BlueprintGroup_middleware')

    # create a Blueprint
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    # create a Blueprint group
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    # register the blueprint group in the Sanic app
    app.blueprint(bpg)


# Generated at 2022-06-12 08:40:40.426488
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp = Blueprint("bp")
    bp.middleware("request")(lambda x: x)
    bpg = BlueprintGroup()
    bpg.append(bp)
    bpg.middleware("request")(lambda x: x)
    bp_middleware = bp.registered_middleware["request"]
    assert 2 == len(bp_middleware)
    assert bp_middleware[1] == bpg.middleware("request")(lambda x: x)

# Generated at 2022-06-12 08:40:49.857614
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)

    counter = 0

    @group.middleware('request')
    async def group_middleware(request):
        nonlocal counter
        counter += 1

    assert len(bp1.middlewares["request"]) == 1
    assert len(bp2.middlewares["request"]) == 1
    assert counter == 0

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        nonlocal counter
        counter += 1

    assert len(bp1.middlewares["request"]) == 2

# Generated at 2022-06-12 08:40:57.016484
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic.blueprints import Blueprint

    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')

    bpg = BlueprintGroup()     # using BlueprintGroup
    bpg.append(bp1)
    bpg.append(bp2)

    # defining a middleware
    @bpg.middleware('request')
    async def bp1_only_middleware(request):
        pass

    assert bp1 in bpg
    assert bp2 in bpg
    assert len(bp1.middleware_stack) == 1
    assert len(bp2.middleware_stack) == 1

