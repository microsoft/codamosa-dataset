

# Generated at 2022-06-21 22:28:54.652787
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    # Initializing the BlueprintGroup object
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bpg1 = BlueprintGroup()

    # Append Blueprint into BlueprintGroup
    bpg1.append(bp1)
    bpg1.append(bp2)
    bpg1.append(bp3)

    # Verifying the contents of BlueprintGroup using __iter__
    bp_names = [bp.name for bp in bpg1]
    assert "bp1" in bp_names
    assert "bp2" in bp_names
    assert "bp3" in bp_names


# Generated at 2022-06-21 22:29:05.601068
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    assert bp1.url_prefix == "/bp1"
    assert bp2.url_prefix == "/bp2"
    assert bp3.url_prefix == "/bp4"
    assert bp4.url_prefix == "/bp4"
    assert bpg.url_prefix == "/api"
    assert bp1 == bpg[0]
    assert bp2 == bpg[1]


# Generated at 2022-06-21 22:29:11.839855
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    from sanic.blueprints import Blueprint
    BlueprintGroup(url_prefix="/api", version="v1", strict_slashes=False)
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bp3 = Blueprint("bp3")
    bp4 = Blueprint("bp4")
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    bp1.middleware('request')(lambda:0)
    bp1.route('/')(lambda:0)
    bp2.route('/<param:int>')(lambda p:0)
    bp3.route('/')(lambda:0)
    bp4.route('/<param:int>')(lambda p:0)

# Generated at 2022-06-21 22:29:25.286830
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    # Create a Blueprint Group
    bpg = BlueprintGroup()

    # Create a Sanic Application
    app = sanic.Sanic()

    # Make sure that the BlueprintGroup is iterable
    from collections.abc import Iterable
    assert issubclass(BlueprintGroup, Iterable)

    # Ensure that a Blueprint Group can be converted into a list
    assert list(bpg) == []

    # Add a Blueprint to the Blueprint group
    bp1 = Blueprint("bp1")

    # Insert the Blueprint into the Blueprint Group
    bpg.append(bp1)

    # Ensure that the Blueprint has been successfully inserted
    assert len(bpg) == 1

    # Ensure that the Blueprint can be iterated
    assert list(bpg) == [bp1]

    # Add a second blueprint to the blueprint group
    bp2 = Blueprint("bp2")

# Generated at 2022-06-21 22:29:29.458892
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    assert len(bpg) == 0
    bpg.extend([bp1, bp2])
    assert len(bpg) == 2



# Generated at 2022-06-21 22:29:37.260258
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    """
    Unit test for method __setitem__ of class BlueprintGroup
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    bpg[0] = bp1
    bpg[1] = bp2
    assert tuple(bpg) == (bp1, bp2)


# Generated at 2022-06-21 22:29:47.897460
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    assert(bpg._blueprints == [bp1,bp2,bp3,bp4])
    bpg.insert(1,bp5)

# Generated at 2022-06-21 22:29:54.341780
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    # initialization
    blueprint_group = BlueprintGroup("/test/prefix/123")
    
    assert len(blueprint_group) == 0

    blueprint_group.append(Blueprint("bp1", url_prefix="/bp1"))
    blueprint_group.append(Blueprint("bp2", url_prefix="/bp2"))

    assert len(blueprint_group) == 2


# Generated at 2022-06-21 22:30:01.328133
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    # arrange
    bp1=sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2=sanic.Blueprint('bp2', url_prefix='/bp2')
    bpGroup=BlueprintGroup()

    # act
    bpGroup.append(bp1)
    bpGroup.insert(0, bp2)

    # assert
    assert bpGroup._blueprints[0] == bp2


# Generated at 2022-06-21 22:30:13.489182
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    # Test case when there are not blueprints in the group
    bpg = BlueprintGroup()
    with pytest.raises(IndexError):
        del bpg[0]
    # Test case when there are blueprints in the group
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    with pytest.raises(IndexError):
        del bpg[4]
    del bpg[-2]

# Generated at 2022-06-21 22:30:31.951082
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')

    bpg = BlueprintGroup(url_prefix='/api', version='v1')
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    bpg.append(bp5)

    assert bpg[0] == bpg.blueprints[0]
    assert bpg[1] == bpg.blueprints[1]


# Generated at 2022-06-21 22:30:43.002553
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bpg1 = BlueprintGroup(url_prefix="/api", version="v1")
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bpg1.append(bp1)

    assert isinstance(bpg1, MutableSequence)
    assert bpg1.url_prefix == "/api"
    assert bpg1.blueprints == [bp1]
    assert bpg1.version == "v1"
    assert bpg1.strict_slashes is None
    assert bpg1[0].version == "v1"
    assert bpg1[0].url_prefix == "/api/bp1"
    assert bpg1[0].strict_slashes is None

# Generated at 2022-06-21 22:30:50.326677
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    app = sanic.Sanic("test_BlueprintGroup_append")
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")
    bp5 = Blueprint("bp5", url_prefix="/bp5")
    bp6 = Blueprint("bp6", url_prefix="/bp6")
    bp7 = Blueprint("bp7", url_prefix="/bp7")
    bp8 = Blueprint("bp8", url_prefix="/bp8")
    bp9 = Blueprint("bp9", url_prefix="/bp9")
    bp10 = Blueprint("bp10", url_prefix="/bp10")
   

# Generated at 2022-06-21 22:31:00.085822
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg1 = BlueprintGroup(url_prefix="/api", version="v1")
    bpg2 = BlueprintGroup(url_prefix="/api", version="v1")

    bpg1.insert(0, bp1)
    bpg1.insert(0, bp3)

    bpg2.insert(0, bpg1)
    bpg2.insert(0, bp4)

    bpg2.insert(1, bp2)

    assert bpg1.url_prefix == '/api'

# Generated at 2022-06-21 22:31:13.048324
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = BlueprintGroup()
    bp3.append(bp1)
    bp4 = BlueprintGroup()
    bp4.append(bp2)
    assert bp3[0] == bp1
    bp3[0] = bp2
    assert bp3[0] == bp2
    bp3[0] = bp4
    assert bp3[0] == bp4[0]
    assert bp3[0] == bp2
    assert bp3[0] != bp1

    # Test for Boundary conditions

# Generated at 2022-06-21 22:31:21.824384
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class TestBlueprint(sanic.Blueprint):
        pass

    bp1 = TestBlueprint('bp1', url_prefix='/bp1')
    bp2 = TestBlueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.extend([bp1, bp2])

    @bpg.middleware('request')
    def bp1_only_middleware(request):
        pass

    assert len(bp1.middlewares['request']) == 1
    assert len(bp2.middlewares['request']) == 1

# Generated at 2022-06-21 22:31:25.972189
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bl = list(bpg)
    assert bp1 in bl and bp2 in bl



# Generated at 2022-06-21 22:31:29.638253
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    """
    Test Blueprint Group instantiation with parameters
    """
    bp_group = BlueprintGroup(url_prefix="/test", version="1.1", strict_slashes=True)
    assert bp_group.url_prefix == "/test"
    assert bp_group.version == "1.1"
    assert bp_group.strict_slashes is True



# Generated at 2022-06-21 22:31:41.354323
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic("test_BlueprintGroup_middleware")
    bp = Blueprint("test_bp")
    bp_group = BlueprintGroup("test_bp_group")

    bp_group.append(bp)

    @bp_group.middleware("request")
    async def bp_group_middleware(request):
        pass

    @bp.middleware("request")
    async def bp_middleware(request):
        pass

    assert bp.middlewares[0]["type"] == "request"
    assert bp.middlewares[0]["fn"] == bp_middleware

    assert bp_group.blueprints[0].middlewares[0]["type"] == "request"

# Generated at 2022-06-21 22:31:52.307251
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api")

    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    assert bpg[1] == bp2
    assert bpg[1] == bp2

    # Test IndexError for invalid index