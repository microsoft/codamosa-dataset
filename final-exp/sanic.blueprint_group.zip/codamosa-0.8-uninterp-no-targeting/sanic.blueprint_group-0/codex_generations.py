

# Generated at 2022-06-21 22:28:47.446808
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    # This method is not supported
    with pytest.raises(NotImplementedError):
        BlueprintGroup.__setitem__(0, 0)


# Generated at 2022-06-21 22:28:56.493772
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint(name="bp1")
    bp2 = Blueprint(name="bp2")
    bp3 = Blueprint(name="bp3")
    bp4 = Blueprint(name="bp4")
    bpg = BlueprintGroup()

    bpg.insert(0, bp1)
    bpg.insert(0, bp2)
    bpg.insert(0, bp3)
    bpg.insert(0, bp4)

    assert bp1 == bpg[0]
    assert bp2 == bpg[1]
    assert bp3 == bpg[2]
    assert bp4 == bpg[3]
    assert len(bpg) == 4


# Generated at 2022-06-21 22:29:05.379837
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bpg = BlueprintGroup(bp1, bp2, bp3, bp4, bp5)
    assert len(list(bpg)) == 5


# Generated at 2022-06-21 22:29:15.703685
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    # Initialize a new BlueprintGroup object
    bpg = BlueprintGroup(url_prefix="/api", version=1.0)
    bpg.append(Blueprint("bp1", url_prefix="/bp1"))
    bpg.append(Blueprint("bp2", url_prefix="/bp2"))
    assert bpg[0].url_prefix == '/api/bp1'
    assert bpg[1].url_prefix == '/api/bp2'
    # Assign the new value using `__setitem__`
    bpg[0] = Blueprint("bp3", url_prefix="/bp3")
    assert bpg[0].url_prefix == '/api/bp3'
    assert bpg[1].url_prefix == '/api/bp2'


# Generated at 2022-06-21 22:29:21.904601
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')

    group = BlueprintGroup(url_prefix='/group')
    group._blueprints.append(bp1)
    group._blueprints.append(bp2)
    group._blueprints.append(bp3)
    group[1] = bp2

    blueprint_list = [bp1, bp2, bp3]

    assert group.blueprints == blueprint_list

# Generated at 2022-06-21 22:29:32.805152
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix='/api', version='v1')
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    del bpg[0]
    del bpg[0]

    assert bpg[0].url_prefix == '/bp3'
    assert bpg[1].url_prefix == '/bp4'
    assert len(bpg) == 2

# Generated at 2022-06-21 22:29:37.540087
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    test_app = sanic.Sanic("test_BlueprintGroup___setitem__")
    test_bp = Blueprint("test_BlueprintGroup___setitem__")
    test_bpg = BlueprintGroup(url_prefix="/test_BlueprintGroup")
    test_bpg[1] = test_bp
    assert test_bpg[1].url_prefix == "/test_BlueprintGroup/test_BlueprintGroup___setitem__"


# Generated at 2022-06-21 22:29:40.384060
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    """
    test the return of  __len__ method for class BlueprintGroup
    """
    bp = BlueprintGroup()
    assert len(bp) == 0



# Generated at 2022-06-21 22:29:43.939520
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp = Blueprint('bp1', url_prefix='/bp1')
    bpg = BlueprintGroup()
    
    bpg.append(bp)
    del bpg[0]
    assert not bpg._blueprints


# Generated at 2022-06-21 22:29:51.611372
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    bpg.append(bp1)
    bpg.append(bp2)

    assert (bp1 == bpg[0])
    assert (bp2 == bpg[1])


# Generated at 2022-06-21 22:30:04.180281
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    class Blueprint(sanic.Blueprint):
        pass

    # Crete a Blueprint group with empty blueprints.
    group = BlueprintGroup()
    assert len(group) == 0
    # Create a new blueprint and append it to the group
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    group.append(bp1)
    assert len(group) == 1

    # Create another blueprint and insert it to the group at 0th index
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group.insert(0, bp2)
    assert len(group) == 2
    assert group[0].name == 'bp2'



# Generated at 2022-06-21 22:30:07.444948
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp = BlueprintGroup()
    bp.append(1)
    bp.append(2)
    assert list(bp) == [1, 2]


# Generated at 2022-06-21 22:30:10.539291
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    """
    Method to perform unit test for:BlueprintGroup.__getitem__
    """
    assert BlueprintGroup.__getitem__.__doc__ is not None


# Generated at 2022-06-21 22:30:21.346395
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware("request")
    async def func_1(request):
        pass

    @bpg.middleware("request", 1, 2, 3)
    async def func_2(request):
        pass

    @bpg.middleware(4, 5, 6, foo="foo")
    async def func_3(request):
        pass

    @bpg.middleware("request")
    async def func_4(request):
        pass

    assert bpg.blueprints[0].middleware["request"] == [func_1, func_2, func_3, func_4]

# Generated at 2022-06-21 22:30:32.244315
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp_app = sanic.Sanic("test_BlueprintGroup_append")
    bpg = BlueprintGroup("/api", "v1")

    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp1.route("/", methods=["GET"])(lambda r: r)
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp2.route("/", methods=["GET"])(lambda r: r)
    bpg.append(bp1)
    bpg.append(bp2)

    bp_app.blueprint(bpg)
    for vpath, vbp in bp_app.blueprints["/api"]["v1"]["/bp1"].items():
        assert vbp.name == "bp1"
        assert vbp.url

# Generated at 2022-06-21 22:30:44.569603
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    # Test Case 1:
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")

    # Test Case 1:
    blueprints = [bp1, bp2, bp3]
    bp_group = BlueprintGroup()
    bp_group._blueprints.extend(blueprints)
    assert len(bp_group) == len(bp_group._blueprints)

    # Test Case 2:
    blueprints = [bp1]
    bp_group = BlueprintGroup()
    bp_group._blueprints.extend(blueprints)
    assert len(bp_group) == len(bp_group._blueprints)


# Generated at 2022-06-21 22:30:55.995590
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg1 = BlueprintGroup.group(bp3, bp4, url_prefix='/api')

    @bp1.middleware('request')
    async def bp1_middleware(request):
        print('applied bp1 middleware')

    @bp2.middleware('request')
    async def bp2_middleware(request):
        print('applied bp2 middleware')

    @bp3.middleware('request')
    async def bp3_middleware(request):
        print

# Generated at 2022-06-21 22:31:00.320615
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg) == 2
    assert list(bpg) == [bp1, bp2]


# Generated at 2022-06-21 22:31:13.448061
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    # Test for the append call
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg) == 2
    assert bpg[0] == bp1
    assert bpg[1] == bp2
    # Test for the append call with API Version
    bpg = BlueprintGroup(version="v2")
    bpg.append(bp3)
    bpg.append(bp4)
    assert len(bpg) == 2

# Generated at 2022-06-21 22:31:17.877786
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bp3 = Blueprint('bp3')
    bp4 = Blueprint('bp4')

    bpg = BlueprintGroup(bp3, bp4)
    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bpg._blueprints) == 4
    assert bpg._blueprints[3] == bp2


# Generated at 2022-06-21 22:31:27.425987
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")

    bpg = BlueprintGroup("/api", "v1")
    bpg.append(bp3)
    bpg.append(bp4)
    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg.version == "v1"
    assert bpg.blueprints == [bp3, bp4, bp1, bp2]
    assert bpg.url_prefix == "/api"

# Generated at 2022-06-21 22:31:38.050805
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    # Create a Blueprint List
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp_list = [bp1, bp2]

    # Create a Blueprint Group
    bpg = BlueprintGroup(url_prefix='/bpg')
    assert bpg.url_prefix == '/bpg'
    assert bpg.blueprints == []
    assert bpg.version is None
    assert bpg.strict_slashes is None

    # Check the usage of Blueprint Group as a list
    bpg.append(bp1)
    bpg.append(bp2)
    assert bpg.url_prefix == '/bpg'
    assert bpg.blueprints == bp_list
    assert bpg.version is None

# Generated at 2022-06-21 22:31:49.912216
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')

    bp1.route('/bp1')(lambda request: text('bp1'))
    bp2.route('/bp2')(lambda request: text('bp2'))
    bp3.route('/bp3')(lambda request: text('bp3'))

    bpg = BlueprintGroup(url_prefix='/api')
    bpg.insert(0, bp1)
    bpg.insert(1, bp2)
    bpg.insert(2, bp3)
    bpg.insert(1, bp2)
    
    assert len(bpg)

# Generated at 2022-06-21 22:31:56.956889
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")
    bpg1 = BlueprintGroup(bp1, bp2)
    bpg2 = BlueprintGroup(bp3, bp4, url_prefix="/api/v1")
    assert bpg1.blueprints[0] == bp1
    assert bpg1.blueprints[1] == bp2
    assert bpg2.blueprints[0] == bp3
    assert bpg2.blueprints[1] == bp4
    assert bpg2.url_prefix == "/api/v1"
    assert bpg1

# Generated at 2022-06-21 22:32:04.740371
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix="/api", version="v1", strict_slashes=True)

    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bpg) == 2
    assert bpg[0] == bp1

    bpg._sanitize_blueprint(bp1)

# Generated at 2022-06-21 22:32:11.259468
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    # Define a Blueprint instance
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    # Create a new Blueprint Group
    bpg = BlueprintGroup()

    # Append the blueprints inside the Blueprint Group
    bpg.append(bp1)
    bpg.append(bp2)

    # Test if the Blueprint Group has the Blueprints added
    assert len(bpg.blueprints) == 2

    # Test if we can delete BP2 which is at index 1 successfully
    del bpg[1]

    # Test if the blueprint group instance has just one blueprint
    assert len(bpg.blueprints) == 1

    # Test if the only blueprint that is remaining is BP1

# Generated at 2022-06-21 22:32:14.625862
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bpg = BlueprintGroup()
    bp=Blueprint('bp',url_prefix='/bp')
    bpg.append(bp)
    del bpg[0]
    assert bpg.blueprints == []


# Generated at 2022-06-21 22:32:21.050038
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup()
    bpg.insert(0, bp1)
    bpg.insert(0, bp2)
    bpg.insert(2, bp3)
    bpg.insert(3, bp3)
    bpg.insert(3, bp4)

    assert bpg[0] == bpg.blueprints[0]
    assert bpg[1] == bpg.blueprints[1]
    assert bpg[2] == bpg.blueprints[2]

# Generated at 2022-06-21 22:32:25.223508
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint = Blueprint(__name__, url_prefix='/api', version='v1')
    bpg = BlueprintGroup(blueprint, url_prefix="/api", version="v1")
    del bpg[0]
    assert len(bpg.blueprints) == 0


# Generated at 2022-06-21 22:32:33.890490
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg.insert(1, bp1) is None
    assert bp1 == bpg[1]
    assert bpg[0] != bpg[1]
    assert bp2 == bpg[2]
    assert len(bpg) == 3

# Generated at 2022-06-21 22:32:47.350964
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    del bpg[0]

    assert len(bpg) == 3


# Generated at 2022-06-21 22:32:55.440428
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    """
    Testcase to test the Blueprint group __len__ method.

    This unit test case will check the expected number of blueprint
    registered under blueprint group is equal to the length of
    blueprint group object.
    """
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp2")
    bp4 = Blueprint("bp4", url_prefix="/bp2")

    bpg = BlueprintGroup(url_prefix="/api")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    assert(len(bpg) == len(bpg.blueprints))


# Unit test

# Generated at 2022-06-21 22:33:04.461013
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.extend([bp3, bp4])

    assert len(bpg) == 2
    bpg.append(bp2)
    assert len(bpg) == 3



# Generated at 2022-06-21 22:33:08.104374
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    assert bpg[0] == bp1
    bpg[0] = bp2
    assert bpg[0] == bp2

# Generated at 2022-06-21 22:33:17.254905
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    # Test assertion for sorting the list by index.
    assert 'bp1' == bpg[0].name

    bp3 = Blueprint('bp3', url_prefix='/bp2')
    bpg.insert(1, bp3)
    # Test assertion for sorting the list by index.
    assert 'bp3' == bpg[1].name

    # Test assertion for Blueprint prefix override.
    assert bp3.url_prefix == '/bp2'


# Generated at 2022-06-21 22:33:22.310882
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    """
    Unit test to verify the parameters that are used.

    :return: None
    """
    group = BlueprintGroup(url_prefix="/api", version="v1")
    assert isinstance(group, BlueprintGroup)
    assert group.url_prefix == "/api"
    assert group.version == "v1"


# Unit test BlueprintGroup Insert

# Generated at 2022-06-21 22:33:26.112552
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    """
    Unit test for the creation of new blueprint object.
    """
    bpg = BlueprintGroup(url_prefix="", version=2.0)
    assert isinstance(bpg, BlueprintGroup)
    assert bpg.url_prefix == ""
    assert bpg.version == 2.0


# Generated at 2022-06-21 22:33:33.671307
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2)
    bpg_len = len(bpg)
    del bpg[0]
    assert len(bpg) == bpg_len - 1

# Generated at 2022-06-21 22:33:36.529894
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp3 = Blueprint('bp3', url_prefix='/bp4')

    bpg = BlueprintGroup()

    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bpg) == 2
# End of Unit test for method __len__ of class BlueprintGroup


# Generated at 2022-06-21 22:33:40.402112
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    group = BlueprintGroup(url_prefix="/api")
    assert group.url_prefix == "/api"
    assert group.version is None
    assert group.strict_slashes is None
    assert len(group) == 0
    assert group.blueprints == []
