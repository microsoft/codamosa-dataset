

# Generated at 2022-06-21 22:28:49.444933
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp)
    bpg.append(bp2)
    assert len(bpg) == 2
    assert type(bpg) is BlueprintGroup
    assert type(bpg[1]) is Blueprint
    assert bpg._blueprints == [bp, bp2]
    # need to be fixed
    # assert bpg.url_prefix is None
    assert bpg.blueprints == [bp, bp2]
    # need to be fixed
    # assert bpg.version is None
    # need to be fixed
    # assert bpg.strict_slashes is None


# Generated at 2022-06-21 22:28:59.945505
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    
    bpg1 = BlueprintGroup(bp3, bp4, url_prefix='/bpg1')
    bpg2 = BlueprintGroup(bp5, url_prefix='/bpg2')
    bpg3 = BlueprintGroup(bp1, bpg1, bpg2, bp2)

    assert bpg3[0] == bp1
    assert bpg3[1] == bpg1

# Generated at 2022-06-21 22:29:08.120924
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.extend([bp1, bp2])
    bpg.append(bp3)

    assert len(bpg) is 3

# Generated at 2022-06-21 22:29:13.616889
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.insert(0, bp1)
    bpg.insert(1, bp2)

    assert bpg.url_prefix == "/api"
    assert bpg.version == "v1"

    assert bpg.blueprints[0] == bp1
    assert bpg.blueprints[1] == bp2

    assert bp1.url_prefix == "/api/bp1"

# Generated at 2022-06-21 22:29:15.290300
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bpg = BlueprintGroup()
    bpg[0] = Blueprint("bp1")



# Generated at 2022-06-21 22:29:20.095050
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bpg = BlueprintGroup()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg.append(bp1)
    bpg.append(bp2)

    assert(bpg[0] == bp1)
    assert(bpg[1] == bp2)


# Generated at 2022-06-21 22:29:23.517390
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bg = BlueprintGroup()
    bp = Blueprint('bp_test', url_prefix='/bp_test')
    bg.append(bp)

    iterator = iter(bg)
    assert iterator == iter(bg._blueprints)

    bg2 = BlueprintGroup('/another/test')
    bg2.append(bp)
    iterator = iter(bg2)
    assert iterator == iter(bg2._blueprints)


# Generated at 2022-06-21 22:29:28.689600
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic(__name__)
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, url_prefix="/api", version="v1")

    async def test_middleware_that_receives_an_app_as_a_param(app):
        print(app)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-21 22:29:37.876121
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    class TestBlueprint(sanic.Blueprint):
        _url_prefix = None
        _strict_slashes = False
        _version = None

    bp1 = TestBlueprint('bp1', url_prefix='/bp1')
    bp2 = TestBlueprint('bp2', url_prefix='/bp2')
    bp3 = TestBlueprint('bp3', url_prefix='/bp3')
    bp4 = TestBlueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp3)
    bpg.append(bp4)
    assert bpg._blueprints == [bp3, bp4]
    assert bpg.url_prefix == "/api"

# Generated at 2022-06-21 22:29:39.007890
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    pass


# Generated at 2022-06-21 22:29:50.586606
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    """
    This unit test is created to test the method __iter__ of class
    BlueprintGroup. The actual method is a common function/method for
    making any object into an iterable.

    The class implements this so that the Blueprint Group can be used
    as a list/tuple object inside any other existing implementation
    without causing any sort of backward compatibility issues.

    The test case uses a BlueprintGroup object and iterates into the
    Blueprints to create a list of blueprint names.
    """


    # Given a blueprint with single blueprint
    blueprint = Blueprint(name="TestBlueprint")

    # When we create an instance of BlueprintGroup with single blueprint
    blueprint_group = BlueprintGroup()
    blueprint_group.append(blueprint)

    # Then we should be able to iterate over the group to create a
    # list of blueprint names.
    blueprint_name_

# Generated at 2022-06-21 22:30:03.521945
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    _bp__bpg_iter = [bp for bp in bpg]
    assert len(_bp__bpg_iter) == 2
    assert _bp__bpg_iter[0] == bp1
    assert _bp__bpg_iter[1] == bp2

    bpg = BlueprintGroup()
    bpg.append(bp3)
    bpg.append(bp4)



# Generated at 2022-06-21 22:30:06.706225
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg.blueprints) == 2


# Generated at 2022-06-21 22:30:17.322256
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    # Preparing the test data and context
    bp1 = sanic.Blueprint('bp1')
    bp2 = sanic.Blueprint('bp2')
    bp3 = sanic.Blueprint('bp3')
    bp4 = sanic.Blueprint('bp4')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    # Setup the test context
    assert bpg[0] == bp1 and bpg[1] == bp2 and bpg[2] == bp3 and bpg[3] == bp4
    # Wrap the test context

# Generated at 2022-06-21 22:30:29.379981
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp5')
    
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    
    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')
        
    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')
        

# Generated at 2022-06-21 22:30:35.276316
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprints = [
        sanic.Blueprint("blueprint1"),
        sanic.Blueprint("blueprint2")
    ]

    blueprintGroup = BlueprintGroup()
    blueprintGroup._blueprints = blueprints

    assert len(blueprintGroup) == 2


# Generated at 2022-06-21 22:30:45.921838
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    
    from sanic import Sanic, Blueprint
    
    app = Sanic('test_BlueprintGroup_middleware')
    
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware('request')
    async def bp1_only_middleware(request):
        return text('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-21 22:30:57.186606
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    """
    Unit test to verify the functionality of __getitem__ method defined
    under the BlueprintGroup class.

    :return: None
    """
    from sanic.blueprints import Blueprint

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    assert bpg[0] is bp1
    assert bpg[1]

# Generated at 2022-06-21 22:31:08.095350
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp3 = sanic.Blueprint('bp3', url_prefix='/bp3')
    bp4 = sanic.Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    idx = 0
    item = sanic.Blueprint('bp1', url_prefix='/bp1')
    bpg.__setitem__(idx, item)
    assert bpg.blueprints[idx].url_prefix == '/bp1'
    assert bpg.blueprints[idx].name == 'bp1'
    assert bpg.version == 'v1'
    assert bpg.url_prefix == '/api'

# Generated at 2022-06-21 22:31:13.916995
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    from sanic.blueprints import Blueprint
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    assert bpg._blueprints == [bp3 , bp4]
    bpg._blueprints = [bp1, bp2]
    assert bpg._blueprints == [bp1, bp2]

# Generated at 2022-06-21 22:31:22.140117
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)
    bps = [x for x in group]
    assert bp1 in bps
    assert bp2 in bps



# Generated at 2022-06-21 22:31:24.967785
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    """
    Unit test for constructor of class `BlueprintGroup`
    """
    blueprint_group = BlueprintGroup(url_prefix="/mygroup")
    assert blueprint_group.url_prefix == "/mygroup"
    assert len(blueprint_group.blueprints) == 0



# Generated at 2022-06-21 22:31:28.374003
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint = Blueprint('test', url_prefix='/test')
    blueprintgroup = BlueprintGroup()
    blueprintgroup.append(blueprint)
    blueprintgroup.append(blueprint)
    del blueprintgroup[0]
    assert len(blueprintgroup) == 1


# Generated at 2022-06-21 22:31:39.112771
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @Blueprint.register_middleware(name='middleware', attach_to='request')
    def registered_middleware(request):
        pass

    @Blueprint.register_middleware(name='middleware')
    def registered_middleware_with_default(request):
        pass

    app = sanic.Sanic('sanic-blueprint-middleware')

    bp_a = Blueprint('bp1', url_prefix='/bp1')
    bp_b = Blueprint('bp2', url_prefix='/bp1')
    bp_c = Blueprint('bp3', url_prefix='/bp2')
    bp_d = Blueprint('bp4', url_prefix='/bp2')
    bp_e = Blueprint('bp5', url_prefix='/bp3')

# Generated at 2022-06-21 22:31:47.024032
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
  # Check the deletion of an item in BlueprintGroup
  bp1 = Blueprint('bp1', url_prefix='/bp1')
  bp2 = Blueprint('bp2', url_prefix='/bp2')
  bp3 = Blueprint('bp3', url_prefix='/bp3')
  bp4 = Blueprint('bp4', url_prefix='/bp4')
  bpg = BlueprintGroup(bp1, bp2)

  bpg.append(bp3)
  del bpg[1]
  assert bpg[0] == bp1
  assert len(bpg) == 2

  bpg[1] = bp4
  assert bpg[1] == bp4
  assert len(bpg) == 2


# Generated at 2022-06-21 22:31:53.065279
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    @bpg.middleware('request')
    async def middleware(request):
        return None

    assert bp1.middleware_stack
    assert bp2.middleware_stack


# Generated at 2022-06-21 22:32:02.057110
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    assert len(bpg) == 4


# Generated at 2022-06-21 22:32:10.285605
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")
    bp5 = Blueprint("bp5", url_prefix="/bp5")
    bp6 = Blueprint("bp6", url_prefix="/bp6")
    bp7 = Blueprint("bp7", url_prefix="/bp7")
    bp8 = Blueprint("bp8", url_prefix="/bp8")
    bp9 = Blueprint("bp9", url_prefix="/bp9")
    bp10 = Blueprint("bp10", url_prefix="/bp10")

    bpg = BlueprintGroup()
    bpg.append(bp1)
   

# Generated at 2022-06-21 22:32:17.175439
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    """
    Unit test to check if the __len__ method on  BlueprintGroup
    is working as expected.
    """

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)

    assert len(bpg) == 3


# Generated at 2022-06-21 22:32:25.638898
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    app = Sanic('test_BlueprintGroup___setitem__')
    blue1 = Blueprint('test_blueprint', url_prefix='/test')
    blue1_group = BlueprintGroup(url_prefix = '/group')
    blue1_group.append(blue1)
    blue2 = Blueprint('test_blueprint', url_prefix='/test2')
    blue1_group[0] = blue2
    assert blue1_group[0] == blue2 and blue1_group[0] != blue1



# Generated at 2022-06-21 22:32:38.367380
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api")
    bpg.append(bp1)
    bpg.append(bp2)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)


# Generated at 2022-06-21 22:32:45.386776
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    from sanic import Blueprint

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = BlueprintGroup('/api', version=1)
    group.append(bp1)
    group.append(bp2)

    assert group[0] is bp1
    assert group[1] is bp2



# Generated at 2022-06-21 22:32:54.334404
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bp3 = sanic.Blueprint('bp3', url_prefix='/bp3')
    bp4 = sanic.Blueprint('bp4', url_prefix='/bp4')

    # Init BlueprintGroup
    bp_group = BlueprintGroup()

    # Append blueprints to BlueprintGroup
    bp_group.append(bp1)
    bp_group.append(bp2)
    bp_group.append(bp3)
    bp_group.append(bp4)

    # Assert that __getitem__ returns the appropriate blueprint
    assert bp_group.__getitem__(0) == bp1


# Generated at 2022-06-21 22:33:01.930259
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    del bpg[0]
    assert len(bpg) == 1
    assert bp1 not in bpg.blueprints



# Generated at 2022-06-21 22:33:07.316678
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    from sanic import Blueprint
    bp1 = Blueprint("blueprint_1")
    bp2 = Blueprint("blueprint_2")
    bp_grp = BlueprintGroup("/api")
    bp_grp.append(bp1)
    assert bp_grp[0] == bp1
    bp_grp.__setitem__(0, bp2)
    assert bp_grp[0] == bp2


# Generated at 2022-06-21 22:33:12.084127
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup()

    bpg.append(bp3)
    bpg.append(bp4)
    assert bpg[0] == bp3
    assert bpg[1] == bp4

# Generated at 2022-06-21 22:33:15.467473
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    # Given a blueprint group
    group = BlueprintGroup()
    group.append(Blueprint("test", url_prefix="/test"))

    # When a blueprint is deleted from group
    del group[0]

    # Then group should be empty
    assert len(group) == 0


# Generated at 2022-06-21 22:33:25.971963
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    """
    Test the append method of the class BlueprintGroup.

    This test is directly calling the append method of the class
    BlueprintGroup. The purpose of this test is to test how the
    class is using the default List object and how it is using the
    implemented append method to create a BluePrint Group.
    """
    app = sanic.Sanic()
    bp1 = Blueprint('bp1', url_prefix='/bp1', version="v1")
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    # In this test we are directly calling the append method.
    # The purpose of this test is to check how the BlueprintGroup
    # class is using the default List object and how it is using
    # the implemented __append__ method to create a BlueprintGroup.
    bpg = BlueprintGroup()

# Generated at 2022-06-21 22:33:33.669861
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    assert isinstance(BlueprintGroup(url_prefix='/test'), BlueprintGroup)
    assert isinstance(BlueprintGroup(version='v1'), BlueprintGroup)
    assert isinstance(BlueprintGroup(strict_slashes=False), BlueprintGroup)
    assert isinstance(BlueprintGroup(), BlueprintGroup)


# Unit test to ensure that BlueprintGroup is a subclass of abstract MutableSequence

# Generated at 2022-06-21 22:33:39.946714
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    """
    This test is to verify that BlueprintGroup is an Iterable class
    """
    bg = BlueprintGroup(url_prefix="/version")
    bg.append(sanic.Blueprint("test_bp", url_prefix="/bp"))
    bg[0].route("/")(lambda x: x)
    route = list(bg)[0]._routes["GET"][0]
    assert route.uri == "/version/bp/"
    assert route.rule == "/"


# Unit Test for method __getitem__ of class BlueprintGroup