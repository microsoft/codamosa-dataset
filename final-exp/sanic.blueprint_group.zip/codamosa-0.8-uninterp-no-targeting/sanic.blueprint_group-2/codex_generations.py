

# Generated at 2022-06-21 22:28:52.301112
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    """
    Unit test for method __getitem__ of class BlueprintGroup
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert bpg[0] == bp1
    assert bpg[1] == bp2


# Generated at 2022-06-21 22:29:00.820877
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    test for method middleware of class BlueprintGroup
    """
    class BlueprintStub(Blueprint):
        """
        Stub class for Blueprint class
        """

        def __init__(self, url_prefix=None, *args, **kwargs):
            self.middlewares = []
            self.url_prefix = url_prefix
            self.version = None
            self.strict_slashes = None

        def middleware(self, fn, *args, **kwargs):
            if args or kwargs:
                self.middlewares.append(fn)
            else:
                self.middlewares.append(kwargs)

    bp1 = BlueprintStub(url_prefix='/bp1')
    bp2 = BlueprintStub(url_prefix='/bp2')


# Generated at 2022-06-21 22:29:11.489962
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp1', url_prefix='/bp2')
    bp4 = Blueprint('bp1', url_prefix='/bp2')
    bp5 = Blueprint('bp1', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix='/api', version='v1')
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)

    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert bpg[2] == bp3

    bpg[0] = bp4

# Generated at 2022-06-21 22:29:19.362041
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = BlueprintGroup(url_prefix='/api')
    group.append(bp1)
    group.append(bp2)

    assert group is not None


# Generated at 2022-06-21 22:29:29.400219
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group = BlueprintGroup(url_prefix=None, version=None, strict_slashes=None)
    blueprint_group.append(sanic.Blueprint('bp1'))
    blueprint_group.append(sanic.Blueprint('bp2'))
    blueprint_group.append(sanic.Blueprint('bp3'))
    blueprint_group.append(sanic.Blueprint('bp4'))
    del(blueprint_group[2])
    assert len(blueprint_group) == 3
    assert blueprint_group[2].name == 'bp4'
    del(blueprint_group[1:])
    assert len(blueprint_group) == 1
    assert blueprint_group[0].name == 'bp1'


# Generated at 2022-06-21 22:29:35.609878
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    """
    Unit Test for the class `BlueprintGroup`
    """

    @sanic.blueprint
    def bp1(self):
        pass

    @sanic.blueprint
    def bp2(self):
        pass

    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    assert bpg.blueprints == [bp1, bp2]
    assert bpg.url_prefix == "/api"
    assert bpg.version == "v1"

# Generated at 2022-06-21 22:29:46.786517
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    import pytest
    import sanic.blueprints

    def test_middleware(request):
        return "Middleware"

    @sanic.blueprints.Blueprint.middleware(test_middleware, "test")
    def bp1_route(request):
        return "bp1"

    @sanic.blueprints.Blueprint.middleware(test_middleware, "test2")
    def bp2_route(request):
        return "bp2"

    bp1 = sanic.blueprints.Blueprint("bp1", url_prefix="/bp1")
    bp1.add_route(bp1_route, "/")

    bp2 = sanic.blueprints.Blueprint("bp2", url_prefix="/bp2")
    bp2.add_route(bp2_route, "/")

    group

# Generated at 2022-06-21 22:29:54.847960
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)

    bpg_iter_loop = 0
    for bp in bpg:
        bpg_iter_loop += 1

    assert (bpg_iter_loop == 2)
    assert (bp1 in bpg)
    assert (bp2 in bpg)


# Generated at 2022-06-21 22:30:00.470174
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    assert [bp1, bp2] == [i for i in bpg]


# Generated at 2022-06-21 22:30:01.580387
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    pass


# Generated at 2022-06-21 22:30:07.293811
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    """
    Test for the BlueprintGroup constructor
    """
    group1 = BlueprintGroup(url_prefix="/api", version="v1")
    assert group1._url_prefix == "/api"
    assert group1._version == "v1"



# Generated at 2022-06-21 22:30:18.386604
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # pylint: disable=C0116
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp2.middleware('request')
    async def bp2_only_middleware(request):
        print('applied on Blueprint : bp2 Only')

    group = Blueprint.group(bp1, bp2)

    @group.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    assert len(bp1.middlewares['request']) == 2


# Generated at 2022-06-21 22:30:29.594289
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp3)
    bpg.append(bp4)

    assert(bp3.url_prefix == "/api/bp4")
    assert(bp4.url_prefix == "/api/bp4")

    assert(bp3.version == "v1")
    assert(bp4.version == "v1")


# Generated at 2022-06-21 22:30:40.265008
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    import unittest
    class BlueGroup(sanic.Blueprint):
        pass

    class BluePrintGroupTests(unittest.TestCase):
        def test__setitem__(self):
            # Prior to Fix
            a = BlueprintGroup()
            b = BlueGroup()
            b1 = BlueGroup()
            b.append(b1)
            a.append(b)

            b2 = BlueGroup()
            b3 = BlueGroup()
            b2.append(b3)

            a[0] = b2

            assert a[0] == b2
            assert a[0][0] == b3



# Generated at 2022-06-21 22:30:48.943972
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    length_bpg = len(bpg)
    length_bpg_expected = 2
    assert length_bpg == length_bpg_expected
    bpg.append(bp1)
    bpg.append(bp2)
    length_bpg = len(bpg)
    length_bpg_expected = 4
    assert length_bpg == length_bpg_expected


# Generated at 2022-06-21 22:30:59.175406
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    app = Sanic("test_BlueprintGroup___iter__")
    bp1 = Blueprint("bp1", url_prefix='/bp1', version='v1')
    bp2 = Blueprint("bp2", url_prefix='/bp2', version='v2')
    bp3 = Blueprint("bp3", url_prefix='/bp3', version='v3')
    bp4 = Blueprint("bp4", url_prefix='/bp4', version='v4')
    bpg = BlueprintGroup(url_prefix='/api', version='v1')
    bpg.append(bp3)
    bpg.append(bp4)

    app.blueprint(bpg)
    assert isinstance(list(bpg), list)


# Generated at 2022-06-21 22:31:08.095338
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bpg = BlueprintGroup(bp1, bp2, bp3, url_prefix="/api", version="v1")
    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert bpg[2] == bp3

# Generated at 2022-06-21 22:31:16.115390
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bpg = BlueprintGroup()
    assert bpg.url_prefix is None
    assert bpg.blueprints == []
    assert bpg.version is None
    assert bpg.strict_slashes is None

    bpg = BlueprintGroup(url_prefix="api", version="v1", strict_slashes=True)
    assert bpg.url_prefix == "api"
    assert bpg.blueprints == []
    assert bpg.version == "v1"
    assert bpg.strict_slashes is True



# Generated at 2022-06-21 22:31:24.594820
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    assert len(bpg) == 2

    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    assert len(bpg) == 2



# Generated at 2022-06-21 22:31:29.149984
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert bpg[0] == bp1
    assert bpg[-1] == bp2


# Generated at 2022-06-21 22:31:43.623128
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.insert(0, bp1)
    bpg.insert(1, bp2)

    assert bpg.url_prefix == "/api"
    assert bpg.version == "v1"
    assert bpg[0].url_prefix == "/api/bp1"
    assert bpg[1].url_prefix == "/api/bp2"
    assert bpg[0].version == "v1"
    assert b

# Generated at 2022-06-21 22:31:52.946666
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
            
    bpg.__delitem__(1)
    assert len(bpg.blueprints) == 1
    assert bpg[0] == bp3
    bpg.__delitem__(0)
    assert len(bpg.blueprints) == 0
    

# Generated at 2022-06-21 22:32:00.702617
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    test_BlueprintGroup = BlueprintGroup("/test", version=1, strict_slashes=None)
    assert len(test_BlueprintGroup) == 0
    test_Blueprint = Blueprint("test", url_prefix="test")
    test_BlueprintGroup.append(test_Blueprint)
    assert len(test_BlueprintGroup) == 1
    del test_BlueprintGroup[0]
    assert len(test_BlueprintGroup) == 0


# Generated at 2022-06-21 22:32:05.777597
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bpg = BlueprintGroup()

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bpg) == 2


# Generated at 2022-06-21 22:32:11.634005
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp1.strict_slashes = True
    bp2.strict_slashes = True
    bp1.version = "1"
    bp2.version = "2"
    bpg = BlueprintGroup("/api", "v1")
    bpg.append(bp1)
    bpg.append(bp2)
    assert bp1.strict_slashes
    assert bp2.strict_slashes
    assert bp1.version == "1"
    assert bp2.version == "2"
    assert bpg.strict_slashes is None
    assert bpg.version == "v1"

# Generated at 2022-06-21 22:32:16.679780
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    """
    This method is used to run the unit test for the `append` method
    of the `BlueprintGroup` class.
    """
    bp = BlueprintGroup()
    assert len(bp) is 0
    bp.append(Blueprint(url_prefix="/bp1"))
    assert len(bp) is 1
    bp.append(Blueprint(url_prefix="/bp2"))
    assert len(bp) is 2


# Generated at 2022-06-21 22:32:25.223323
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    from sanic.blueprints import BlueprintGroup

    bp1 = Blueprint("bp1", url_prefix='/bp1')
    bp2 = Blueprint("bp2", url_prefix='/bp2')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    bpg_iterator = bpg.__iter__()
    assert next(bpg_iterator) is bp1
    assert next(bpg_iterator) is bp2

# Generated at 2022-06-21 22:32:28.529510
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp = Blueprint("foo", url_prefix="/foo")
    bp_grp = BlueprintGroup("/bar")
    bp_grp.append(bp)
    assert len(bp_grp) == 1


# Generated at 2022-06-21 22:32:35.612532
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg.blueprints) == 2 and 'bp1' in [bp.name for bp in bpg.blueprints] and 'bp2' in [bp.name for bp in bpg.blueprints]


# Generated at 2022-06-21 22:32:47.557629
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bp5 = Blueprint('bp5', url_prefix='/bp1')
    bp6 = Blueprint('bp6', url_prefix='/bp2')
    bp7 = Blueprint('bp7', url_prefix='/bp3')
    bp8 = Blueprint('bp8', url_prefix='/bp4')

    bpg1 = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1", strict_slashes=True)

# Generated at 2022-06-21 22:33:02.367985
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert bpg[2] == bp3
    assert bpg[3] == bp4



# Generated at 2022-06-21 22:33:06.813547
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bpg = BlueprintGroup()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    
    print("\n--- Running test_BlueprintGroup___setitem__ ---")
    
    print("Blueprint before set: " + str(bpg[0]))
    bpg[0] = bp1
    print("Blueprint after set: " + str(bpg[0]))
    


# Generated at 2022-06-21 22:33:10.928962
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    for bp in bpg:
        assert bp in [bp1, bp2]


# Generated at 2022-06-21 22:33:16.030010
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprintGroup = BlueprintGroup()
    blueprint1 = Blueprint('bp1', url_prefix='/bp1')
    blueprint2 = Blueprint('bp2', url_prefix='/bp2')
    blueprint3 = Blueprint('bp3', url_prefix='/bp3')
    blueprintGroup.append(blueprint1)
    blueprintGroup.append(blueprint2)
    blueprintGroup.append(blueprint3)
    assert len(blueprintGroup) == 3


# Generated at 2022-06-21 22:33:25.863239
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    assert len(bpg)==4
    assert bpg[0].url_prefix=="/api/bp1"
    assert bpg[3].url_prefix=="/api/bp4"

# Generated at 2022-06-21 22:33:38.213787
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class MockBlueprint(sanic.Blueprint):
        def middleware(self, *args, **kwargs):
            pass
    bp1 = MockBlueprint()
    bp2 = MockBlueprint()
    bp3 = MockBlueprint()
    bpg = BlueprintGroup('/v1', 1.0, False)
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)

    @bpg.middleware('request')
    def request_middleware(request):
        pass
    assert len(bp1.middlewares['request']) == 1
    assert len(bp2.middlewares['request']) == 1
    assert len(bp3.middlewares['request']) == 1

# Generated at 2022-06-21 22:33:42.512391
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bpg = BlueprintGroup(url_prefix="test", version="1", strict_slashes=True)
    assert bpg.url_prefix == "test"
    assert bpg.version == "1"
    assert bpg.strict_slashes == True
    assert bpg.blueprints == []

# Generated at 2022-06-21 22:33:53.174107
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
  bp1 = Blueprint('bp1', url_prefix='/bp1')
  bp2 = Blueprint('bp2', url_prefix='/bp2')

  bp3 = Blueprint('bp3', url_prefix='/bp4')
  bp4 = Blueprint('bp4', url_prefix='/bp4')

  bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

  @bp1.route('/')
  async def bp1_route(request):
      return text('bp1')

  @bp2.route('/<param>')
  async def bp2_route(request, param):
      return text(param)

  @bp3.route('/')
  async def bp3_route(request):
      return text('bp3')


# Generated at 2022-06-21 22:33:58.203063
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    app = sanic.Sanic("api")
    bp1 = Blueprint("bp1", url_prefix='/bp1')
    bp2 = Blueprint("bp2", url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg) == 2

# Generated at 2022-06-21 22:34:10.665599
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    # init
    bpg = BlueprintGroup(url_prefix='/bpg')
    # assert
    assert bpg._url_prefix == '/bpg'
    assert not bpg._blueprints
    assert bpg._version is None
    assert bpg._strict_slashes  is None
    # append
    bpg.append(bp1)
    # assert
    assert bpg._blueprints[0].name == 'bp1'
    assert bpg._blueprints[0].url_prefix == '/bp1'
    # append
    bpg.append(bp2)
    # assert
    assert bpg._blueprints[1].name == 'bp2'

# Generated at 2022-06-21 22:34:28.127867
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    class BlueprintStub(sanic.Blueprint):
        """
        Stub class to provide a simple `Blueprint` class for testing
        """

        def __init__(self, name, url_prefix=None):
            self.name = name
            self.url_prefix = url_prefix

    bg = BlueprintGroup()
    b1 = BlueprintStub(name='blueprint1')
    b2 = BlueprintStub(name='blueprint2')
    bg[0] = b1
    assert bg[0].name == 'blueprint1'
    bg[1] = b2
    assert bg[1].name == 'blueprint2'
    assert bg[0].name == 'blueprint1'
    bg[0] = b2
    assert bg[0].name == 'blueprint2'

#

# Generated at 2022-06-21 22:34:32.932900
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)
    assert isinstance(group, BlueprintGroup)
    for i in range(len(group)):
        assert group[i] in [bp1, bp2]


# Generated at 2022-06-21 22:34:36.489413
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bpg = BlueprintGroup()
    bpg.append(Blueprint("bp1", url_prefix="/bp1"))
    bpg.append(Blueprint("bp2", url_prefix="/bp2"))
    bpg.append(Blueprint("bp3", url_prefix="/bp3"))
    assert len(bpg) == 3


# Generated at 2022-06-21 22:34:43.078314
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bpg = BlueprintGroup(bp3, url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    assert 2 == len(bpg)
    del bpg[1]
    assert 1 == len(bpg)
    assert _blueprints[0] is bp3

# Generated at 2022-06-21 22:34:53.729482
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    """
    Test the append method of BlueprintGroup

    :return: None
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp3)
    bpg.append(bp4)

    assert(bp3 in bpg.blueprints)
    assert(bp4 in bpg.blueprints)
    assert(bp1 not in bpg.blueprints)
    assert(bp2 not in bpg.blueprints)

# Generated at 2022-06-21 22:35:02.179815
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert bpg.__getitem__(0) == bp1
    assert bpg.__getitem__(1) == bp2
    # Test length
    assert bpg.__len__() == 2, "Blueprint length is not 2"
    # Test Iteration
    counter = 0
    for _ in bpg:
        counter += 1
    assert counter == 2, f"Iterator did not loop twice, counter: {counter}"
    # Test Slice
    bp_slice = bpg[0:2]

# Generated at 2022-06-21 22:35:03.003208
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    assert BlueprintGroup()



# Generated at 2022-06-21 22:35:08.999592
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    """
    Test `BlueprintGroup.__getitem__` method
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup()
    bpg.append(bp3)
    bpg.append(bp4)

    # Test the __getitem__ method of BlueprintGroup
    assert bpg[0] == bp3
    assert bpg[1] == bp4
    # Raise index error
    try:
        bpg[3]
    except IndexError:
        pass


# Generated at 2022-06-21 22:35:19.241355
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/api/bp3')
    bp4 = Blueprint('bp4', url_prefix='/api/bp4')

    bpg = BlueprintGroup(url_prefix='/api')

    bpg.append(bp3)
    bpg.append(bp4)

    blueprints = []
    for blueprint in bpg:
        blueprints.append(blueprint)

    assert blueprints[0] == bp3
    assert blueprints[1] == bp4


# Generated at 2022-06-21 22:35:20.176619
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    assert BlueprintGroup().__iter__()



# Generated at 2022-06-21 22:35:40.508891
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup()

    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    assert bp1 in bpg
    assert bp2 in bpg
    assert bp3 in bpg
    assert bp4 in bpg


# Generated at 2022-06-21 22:35:44.122448
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)
    group[0] = bp1
    assert group[0] == bp1


# Generated at 2022-06-21 22:35:50.965685
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp3)
    bpg.append(bp4)

    bpg___iter__ = bpg.__iter__()

    assert isinstance(bpg___iter__, Iterator)

    bpg___iter___next_0 = next(bpg___iter__)

    assert bpg___iter___next_0 == bp1
    assert bpg[0] == bp1

    bpg___iter

# Generated at 2022-06-21 22:35:59.779844
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="api", version='v1', strict_slashes=False)

    bpg.append(bp1)
    bpg.append(bp2)

    assert bp1 in bpg._blueprints
    assert bp2 in bpg._blueprints
    assert bp1.url_prefix == "/api/bp1"
    assert bp2.url_prefix == "/api/bp2"
    assert bp1.version == "v1"
    assert bp2.version == "v1"
    assert bp1.strict_slashes == False
    assert bp2.strict_slashes == False


# Unit

# Generated at 2022-06-21 22:36:10.966268
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    """
    Unit Test for BlueprintGroup.__iter__()
    """
    bp1_1 = Blueprint('bp1_1', url_prefix='/bp1')
    bp1_2 = Blueprint('bp1_2', url_prefix='/bp2')
    bp2_1 = Blueprint('bp2_1', url_prefix='/bp1')
    bp2_2 = Blueprint('bp2_2', url_prefix='/bp2')

    bp1 = BlueprintGroup(url_prefix="/api", version="v1")
    bp1.append(bp1_1)
    bp1.append(bp1_2)
    bp2 = BlueprintGroup(url_prefix="/api", version="v2")
    bp2.append(bp2_1)

# Generated at 2022-06-21 22:36:15.873666
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    # Given
    blueprint_group = BlueprintGroup()
    blueprint_group.append(Blueprint("foo"))
    blueprint_group.append(Blueprint("baa"))

    # When
    blueprint_iter = iter(blueprint_group)
    blueprint_list = list(blueprint_iter)

    # Then
    assert len(blueprint_list) == 2
    assert blueprint_list[0].name == "foo"
    assert blueprint_list[1].name == "baa"



# Generated at 2022-06-21 22:36:20.836432
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp = Blueprint('bp')

    def bp_middleware(request):
        pass

    bpg = BlueprintGroup()
    bpg.blueprints = [bp]
    assert bpg.blueprints == [bp]
    bpg.middleware(bp_middleware)
    assert bp.middlewares == [bp_middleware]



# Generated at 2022-06-21 22:36:29.560424
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg1 = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    @bpg1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp2.middleware('request')
    async def bp2_only_middleware(request):
        print('applied on Blueprint : bp2 Only')

# Generated at 2022-06-21 22:36:35.561360
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')

    blueprints = BlueprintGroup()
    assert blueprints == []
    assert blueprints == []
    assert blueprints.url_prefix == None
    assert blueprints.strict_slashes == None
    assert blueprints.version == None
    blueprints.append(bp1)
    assert blueprints.blueprints == [bp1]

# Generated at 2022-06-21 22:36:39.312217
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bg = BlueprintGroup(url_prefix="/api", version="v1")
    bp1 = Blueprint(name="bp1", url_prefix="/bp1")
    bp2 = Blueprint(name="bp2", url_prefix="/bp2")
    bp3 = Blueprint(name="bp3", url_prefix="/bp3")
    bg.append(bp1)
    bg.append(bp2)
    bg.append(bp3)
    del bg[0]
    assert len(bg) == 2
    # Test for negative index
    del bg[-1]
    assert len(bg) == 1
    # Test for index out of range
    with pytest.raises(IndexError):
        del bg[3]


# Generated at 2022-06-21 22:37:09.342403
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bpg = BlueprintGroup(url_prefix='/api', version='v1', strict_slashes=False)
    assert bpg.url_prefix == '/api'
    assert bpg.version == 'v1'
    assert bpg.strict_slashes is False
    assert bpg._blueprints == []

# Unit test loading a blueprint into group

# Generated at 2022-06-21 22:37:14.775821
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    assert not isinstance(BlueprintGroup.__iter__, abc.abstractmethod)
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert bpg.__iter__().__next__() == bp1


# Generated at 2022-06-21 22:37:21.789904
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bg = BlueprintGroup()
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bg.append(bp1)
    bg.append(bp2)
    assert bg[0] == bp1
    assert bg[1] == bp2
    assert bg[0] is not bp1
    assert bg[1] is not bp2



# Generated at 2022-06-21 22:37:29.973926
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bps = [bp1, bp2, bp3, bp4]

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    bpg = bps

    assert len(bpg) == len(bps)
    del bpg[1]
    assert len(bpg) == len(bps)-1


# Generated at 2022-06-21 22:37:34.925503
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix='/api')
    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert bpg[-1] == bp2


# Generated at 2022-06-21 22:37:41.450761
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    """
    GIVEN a BlueprintGroup object with blueprints
    WHEN iterating over the BlueprintGroup object
    THEN check if the iterator returns the blueprints as expected
    """
    bp_group = BlueprintGroup()
    bp_group.append(Blueprint("bp1", url_prefix='/bp1'))
    bp_group.append(Blueprint("bp2", url_prefix='/bp2'))
    bp_group.append(Blueprint("bp3", url_prefix='/bp3'))
    bp_group.append(Blueprint("bp4", url_prefix='/bp4'))

# Generated at 2022-06-21 22:37:44.620497
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    assert BlueprintGroup().__len__() == 0
    assert BlueprintGroup(Blueprint("Test__len__")).__len__() == 1


# Generated at 2022-06-21 22:37:53.423659
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-21 22:37:57.774813
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    group = BlueprintGroup()
    group.extend([bp1, bp2, bp3, bp4])
    assert len(group) == 4


# Generated at 2022-06-21 22:38:08.127860
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bpg = BlueprintGroup( bp1, url_prefix='/bpg', version='v1')
    assert len(bpg) == 1
    bpg.insert(0, bp3)
    assert len(bpg) == 2
    assert bpg[0].url_prefix == '/bp3'
    assert bpg[1].url_prefix == '/bp1'
    bpg.insert(-2, bp2)
    assert len(bpg) == 3
    assert bpg[0].url_prefix == '/bp3'