

# Generated at 2022-06-21 22:28:55.125377
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic('test_BlueprintGroup_middleware')
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')
    bp7 = Blueprint('bp7', url_prefix='/bp7')
    bp8 = Blueprint('bp8', url_prefix='/bp8')
    bp9 = Blueprint('bp9', url_prefix='/bp9')

# Generated at 2022-06-21 22:29:01.965152
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    # test for default constructor
    assert BlueprintGroup().url_prefix is None
    assert BlueprintGroup().version is None
    assert BlueprintGroup().strict_slashes is None
    assert BlueprintGroup().blueprints == []

    # test for custom constructor
    assert BlueprintGroup("/api", "v1").url_prefix == "/api"
    assert BlueprintGroup("/api", "v1").version == "v1"
    assert BlueprintGroup("/api", "v1").strict_slashes is None
    assert BlueprintGroup("/api", "v1").blueprints == []
    assert BlueprintGroup("/api", strict_slashes=True).url_prefix == "/api"
    assert BlueprintGroup("/api", strict_slashes=True).version is None
    assert BlueprintGroup("/api", strict_slashes=True).strict_slashes is True
   

# Generated at 2022-06-21 22:29:06.151140
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = BlueprintGroup('/api/v1/')
    

# Generated at 2022-06-21 22:29:09.678019
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    expected = BlueprintGroup()
    expected.append(Sanic(__name__))
    expected.append(Sanic(__name__))
    expected.append(Sanic(__name__))
    actual = [x for x in expected]
    assert actual == expected.blueprints


# Generated at 2022-06-21 22:29:19.509759
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    bpg2 = BlueprintGroup()
    bpg2.append(bp3)
    bpg2.append(bp4)

    assert len(bpg) == 2
    assert bpg[0].name == 'bp1'

    assert len(bpg2) == 2
    assert bpg2[1].name == 'bp4'


# Generated at 2022-06-21 22:29:30.583107
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    class MockBlueprint:
        def __init__(self,url_prefix=None, version=None, strict_slashes=None):
            self.url_prefix=url_prefix
            self.version=version
            self.strict_slashes=strict_slashes

    bp_group=BlueprintGroup(url_prefix="/api", version="v1")
    bp=MockBlueprint()
    bp_group.append(bp)
    assert(bp_group.url_prefix == "/api")
    assert(bp_group.version == "v1")
    assert(bp.url_prefix=="/api")
    assert(bp.version=="v1")
    bp=MockBlueprint(url_prefix="/api2")
    bp_group.insert(0, bp)

# Generated at 2022-06-21 22:29:42.313126
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    assert bpg.blueprints == []
    bpg.append(bp1)
    bpg.append(bp2)
    assert bpg.blueprints == [bp1, bp2]
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bpg[1] = bp3
    assert bpg.blueprints == [bp1, bp3]
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg[0] = bp4
    assert bpg.blueprints == [bp4, bp3]

# Generated at 2022-06-21 22:29:49.166616
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp2)
    bpg.append(bp3)
    assert bpg[0] == bp2


# Generated at 2022-06-21 22:29:53.060481
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    # check the url_prefix property
    bpg = BlueprintGroup(url_prefix="/api/v1")
    assert bpg.url_prefix == "/api/v1"

    # check the version property
    bpg = BlueprintGroup(version="v1")
    assert bpg.version == "v1"

    # check the strict_slash property
    bpg = BlueprintGroup(strict_slashes=True)
    assert bpg.strict_slashes


# Generated at 2022-06-21 22:30:05.744276
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint(name="test_bp_group", url_prefix="/test_bp_group")
    bp2 = Blueprint(name="test_bp_group", url_prefix="/test_bp_group")

    bpg = BlueprintGroup(url_prefix="/test_bp_group")
    assert issubclass(type(bpg), MutableSequence)

    bpg = BlueprintGroup(bp1, bp2, url_prefix="/test_bp_group")
    assert len(bpg) == 2

    bpg.append(bp1)
    assert len(bpg) == 3

    bpg[0] = bp2
    assert bpg[0].name == "test_bp_group"

    del bpg[0]
    assert len(bpg) == 2
# End of Unit test for constructor of class BlueprintGroup

# Generated at 2022-06-21 22:30:16.337821
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    assert bpg[0] == bp3 and bpg[1] == bp4
    with pytest.raises(IndexError):
        bpg[2]


# Generated at 2022-06-21 22:30:28.500581
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():

    # Blueprint Group Constructor with no argument
    bpg = BlueprintGroup()

    assert len(bpg) == 0
    assert bpg.url_prefix is None
    assert bpg.version is None
    assert bpg.strict_slashes is None

    # Blueprint Group Constructor with argument
    bpg = BlueprintGroup(url_prefix='/bp_group')

    assert len(bpg) == 0
    assert bpg.url_prefix == '/bp_group'
    assert bpg.version is None
    assert bpg.strict_slashes is None

    bpg = BlueprintGroup(url_prefix='/bp_group', version='v1')

    assert len(bpg) == 0
    assert bpg.url_prefix == '/bp_group'
    assert bpg.version == 'v1'
    assert bpg.st

# Generated at 2022-06-21 22:30:42.178445
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)
    bpg.append(bp2)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-21 22:30:49.973233
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg) == 2
    assert bpg[0] is bp1
    assert bpg[1] is bp2
    assert bpg[0].url_prefix == "/api/bp1"
    assert bpg[1].url_prefix == "/api/bp2"

    bpg.append(bp2)

# Generated at 2022-06-21 22:30:59.950911
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic import Blueprint, Sanic

    app = Sanic('test_BlueprintGroup_middleware')

    bp1 = Blueprint('bp1', url_prefix='/bp1')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    bp2 = Blueprint('bp2', url_prefix='/bp2')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    group = Blueprint.group(bp1, bp2)

    @group.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    app.blueprint(group)

    _, response = app.test

# Generated at 2022-06-21 22:31:09.940606
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    from sanic.blueprints import Blueprint
    from unittest.mock import Mock

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix='/bpg')
    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg.blueprints == [bp1, bp2]
    bpg[0] = Mock()
    assert bpg.blueprints == [Mock(), bp2]



# Generated at 2022-06-21 22:31:14.070908
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    """
    Test Function to check that append functionality is working
    """
    group = BlueprintGroup()
    group.append(Blueprint('name', url_prefix='/path'))
    assert len(group) == 1


# Generated at 2022-06-21 22:31:22.853843
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    url_prefix = "/api"
    version = "v1"
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    bpg = BlueprintGroup(url_prefix=url_prefix, version=version)
    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg[1].url_prefix == "/api/bp2"
    assert bpg[1].version == "v1"
    assert bpg[1].name == "bp2"


# Generated at 2022-06-21 22:31:24.296792
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    # Test No.1
    assert False, "Test Not Implemented"


# Generated at 2022-06-21 22:31:28.884886
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint = Blueprint("test_BlueprintGroup", url_prefix="/test")

    bg = BlueprintGroup()
    bg.append(blueprint)

    @bg.middleware("request")
    def bgMiddleware(request):
        return True

    assert 1 == len(bg)

    assert 1 == len(blueprint.middleware["request"])
    assert blueprint.middleware["request"][0] == bgMiddleware

# Generated at 2022-06-21 22:31:35.572263
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp = Blueprint("bp_name", url_prefix="/v1/bp")
    group = BlueprintGroup("/v1", strict_slashes=True)
    group[0] = bp
    # Assert BlueprintGroup instance is mutable
    assert list(group) == [bp]


# Generated at 2022-06-21 22:31:46.033700
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    # Scenario 1:
    bp = Blueprint('bp1', url_prefix='/bp1')
    bp = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(bp1, bp2)
    bpg.__setitem__(0,bp)
    assert(bpg[0] == bp)

    # Scenario 2:
    bp = Blueprint('bp3', url_prefix='/bp3')
    bp = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4)
    bpg.__setitem__(0,bp)
    assert(bpg[0] == bp)



# Generated at 2022-06-21 22:31:55.018054
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic('test_BlueprintGroup_middleware')
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bp3 = Blueprint('bp3')
    bp4 = Blueprint('bp4')
    bp5 = Blueprint('bp5')

    bpg = BlueprintGroup(bp1, bp2, bp3, strict_slashes=False)
    bpg2 = BlueprintGroup(bp4, bp5, strict_slashes=False)

    @bp3.middleware('request')
    def bp_middleware(request):
        pass

    assert bp1._middlewares['request'][0] == bp_middleware
    assert bp2._middlewares['request'][0] == bp_middleware
    assert bp3._middle

# Generated at 2022-06-21 22:32:06.766804
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    async def bp1_middleware(request):
        assert 'middleware' in request.app.config
        assert request.app.config['middleware'] == True
    async def bp2_middleware(request):
        assert 'middleware' in request.app.config
        assert request.app.config['middleware'] == True
    app = sanic.Sanic("test_BlueprintGroup_middleware")
    app.config['middleware'] = True

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp1.middleware(bp1_middleware)
    bp2.middleware(bp2_middleware)

    group = BlueprintGroup()
    group.append(bp1)

# Generated at 2022-06-21 22:32:07.730538
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    pass


# Generated at 2022-06-21 22:32:16.183921
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    assert bp1 in bpg
    assert bp2 in bpg
    assert bp3 in bpg
    assert bp4 in bpg


# Generated at 2022-06-21 22:32:27.507988
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp1, bp2, bp3, bp4)

    bp_list = [bp1, bp2, bp3, bp4]
    for bp, bp_list_item in zip(bpg, bp_list):
        assert bp == bp_list_item



# Generated at 2022-06-21 22:32:31.454478
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    # Create a new Blueprint Group
    _blueprint_group = BlueprintGroup()

    # Iterate over the Blueprint Group
    for _blueprint in _blueprint_group:
        print(_blueprint)


# Generated at 2022-06-21 22:32:37.408363
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    assert bpg._blueprints == [bp3, bp4]


# Generated at 2022-06-21 22:32:45.282964
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = BlueprintGroup(url_prefix='/api', version='v1.0')
    group.append(bp1)
    assert len(group.blueprints) == 1
    group[0] = bp2
    assert len(group.blueprints) == 1
    assert group[0] == bp2
