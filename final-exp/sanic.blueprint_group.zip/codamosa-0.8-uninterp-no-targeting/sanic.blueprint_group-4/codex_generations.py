

# Generated at 2022-06-21 22:28:50.314549
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp3', url_prefix='/bp4')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)

    assert len(bpg) == 3, "Expected length of Blueprint Group"

    del bpg[2]
    assert len(bpg) == 2, "Expected length of Blueprint Group"

    del bpg[1]
    assert len(bpg) == 1, "Expected length of Blueprint Group"

    del bpg[0]

# Generated at 2022-06-21 22:29:00.371292
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bp1.strict_slashes = True
    bp2.strict_slashes = True
    bp3.strict_slashes = True

    bpg = BlueprintGroup(url_prefix='/api')
    bpg.insert(0, bp1)
    bpg.insert(0, bp2)
    bpg.insert(0, bp3)

# Generated at 2022-06-21 22:29:11.143686
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api")

    global stack
    stack = []

    @bpg.middleware('request')
    async def bpg_middleware(request):
        stack.append('bpg')

    @bp1.middleware('request')
    async def bp1_middleware(request):
        stack.append('bp1')

    @bp2.middleware('request')
    async def bp2_middleware(request):
        stack.append('bp2')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-21 22:29:21.095018
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)
    bp1_in_group = group[0]
    bp2_in_group = group[1]
    assert bp1_in_group == bp1
    assert bp2_in_group == bp2


# Generated at 2022-06-21 22:29:32.214663
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bp5 = Blueprint('bp5', url_prefix='/bp5')

    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1", strict_slashes=True)

    assert bpg.blueprints == [bp1, bp2]
    assert bpg.url_prefix == '/api'
    assert bpg.version == "v1"
    assert bpg.strict_slashes is True

    bpg[0] = bp3
    bpg.append

# Generated at 2022-06-21 22:29:42.115536
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup()

    assert len(bpg) == 0
    bpg.append(bp1)
    bpg.insert(1, bp2)
    assert len(bpg) == 2
    bpg.insert(2, bp3)
    bpg.insert(3, bp4)
    assert len(bpg) == 4

# Generated at 2022-06-21 22:29:49.908556
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint(__name__, url_prefix='/bp1')
    bp2 = Blueprint(__name__, url_prefix='/bp2')
    bp3 = Blueprint(__name__, url_prefix='/bp3')
    bp4 = Blueprint(__name__, url_prefix='/bp4')
    bpg = BlueprintGroup()

    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    for blueprint in bpg:
        assert isinstance(blueprint, Blueprint)



# Generated at 2022-06-21 22:30:01.930037
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    assert bpg.url_prefix == "/api"
    assert bpg.blueprints == []
    assert bpg.version == "v1"

    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)

    assert len(bpg) == 3
    assert bpg[0] == bp1
    assert bpg[1] == bp2

# Generated at 2022-06-21 22:30:10.108119
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')

    bpg = BlueprintGroup(bp1, bp2, bp3)

    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert bpg[2] == bp3



# Generated at 2022-06-21 22:30:20.854451
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    # BlueprintGroup instance
    bpg = BlueprintGroup(url_prefix='/v1')
    bpg.append(bp1)
    bpg.append(bp2)

    result = {}

    @bpg.middleware('request')
    async def middleware_for_bpg(request):
        result['bpg'] = True

    assert result == {'bpg': True}
    assert result['bpg'] is True
    assert bp1.middlewares == {'request': [middleware_for_bpg]}
    assert bp2.middlewares == {'request': [middleware_for_bpg]}

    # Reset
    result = {}
   

# Generated at 2022-06-21 22:30:26.914263
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/group", version=1)

    assert len(bpg) == 2


# Generated at 2022-06-21 22:30:33.868234
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    def str_in_blueprint(bp):
        return str(bp) in str(bpg)

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()
    assert not any(str_in_blueprint(b) for b in [bp1, bp2])
    bpg.append(bp1)
    assert all(str_in_blueprint(b) for b in [bp1])
    bpg.append(bp2)
    assert all(str_in_blueprint(b) for b in [bp1, bp2])

# Unit Test for method extend of class BlueprintGroup

# Generated at 2022-06-21 22:30:45.571554
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    """
    Ensure that the insert operation inside a Blueprint Group work as expected
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    assert bp1.url_prefix == "/bp1"
    assert bp2.url_prefix == "/bp2"

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)

    assert len(bpg) == 1
    assert bpg[0] == bp1
    assert bpg.blueprints[0] == bp1
    assert bpg.url_prefix == "/api"
    assert bp1.url_prefix == "/api/bp1"

    assert bp1 in bpg

# Generated at 2022-06-21 22:30:52.015056
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    """
    Test case to check the length of the `BlueprintGroup` class.

    :return: None
    """
    bg = BlueprintGroup()
    assert len(bg) == 0
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bg = BlueprintGroup(bp1, bp2)
    assert len(bg) == 2


# Generated at 2022-06-21 22:30:57.714791
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint = Blueprint("test_BlueprintGroup___delitem__", url_prefix='/test')
    bpg = BlueprintGroup()

    bpg.append(blueprint)
    assert len(bpg) == 1
    assert bpg[0] == blueprint
    del bpg[0]
    assert len(bpg) == 0
    with pytest.raises(IndexError):
        bpg[0]


# Generated at 2022-06-21 22:31:03.550708
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    assert bp1 in bpg._blueprints
    assert bp2 in bpg._blueprints
    assert bp1.url_prefix == '/api/bp1'
    assert bp2.url_prefix == '/api/bp2'
    assert bp1.version == 'v1'
    assert bp2.version == 'v1'
    assert bp1.strict_slashes == None
    assert bp2.strict_slashes == None

# Generated at 2022-06-21 22:31:10.045596
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp = BlueprintGroup()
    assert len(bp) == 0
    bp.append(Blueprint('bp1', url_prefix='/bp1'))
    bp.append(Blueprint('bp2', url_prefix='/bp2'))
    assert len(bp) == 2


# Generated at 2022-06-21 22:31:16.782183
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    # Blueprints
    bp1 = Blueprint('test_bp1', url_prefix='/test_bp1')
    bp2 = Blueprint('test_bp2', url_prefix='/test_bp2')

    # Blueprint group
    group = Blueprint.group(bp1, bp2)

    # Iterate over the group
    for blueprint in group:
        assert blueprint.name in ['test_bp1', 'test_bp2']


# Generated at 2022-06-21 22:31:21.584760
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2)
    assert len(bpg) == 2


# Generated at 2022-06-21 22:31:27.708960
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    assert bpg[0] == bp3
    assert bpg[1] == bp4
    assert bpg[2] == None


# Generated at 2022-06-21 22:31:46.242067
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    
    bpg = BlueprintGroup()
    bpg.extend([bp1, bp2, bp3, bp4])
    assert bpg[0].name == 'bp1'
    assert bpg[0].url_prefix == '/bp1'
    assert bpg[3].name == 'bp4'
    assert bpg[3].url_prefix == '/bp4'
    
    bpg2 = BlueprintGroup()

# Generated at 2022-06-21 22:31:55.162430
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    # Test #1
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    group = BlueprintGroup(bp1, bp2, bp3, bp4, url_prefix="/api", version="v1")
    assert len(group) == 4
    assert isinstance(group._blueprints, list)
    assert list(group) == group._blueprints
    # Test #2 - invalid type

# Generated at 2022-06-21 22:32:06.808032
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp3)
    bpg.append(bp4)

    @bp3.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp4.route('/<param>')
    async def bp2_route(request, param):
        return text(param)
    # test BlueprintGroup.__iter__()

# Generated at 2022-06-21 22:32:13.267350
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp1.version = "v1"
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp2.version = "v2"
    bpg = BlueprintGroup(url_prefix="/api")
    bpg.append(bp1)
    bpg.append(bp2)
    assert bpg[0] == bp1
    assert bpg[1] == bp2


# Generated at 2022-06-21 22:32:18.108119
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp', url_prefix='/bp1')
    bp2 = Blueprint('bp', url_prefix='/bp2')
    bpg = BlueprintGroup('/api')
    bpg.insert(0, bp1)
    assert bpg[0] == bp1
    bpg.insert(0, bp2)
    assert bpg[0] == bp2
    assert bpg[1] == bp1


# Generated at 2022-06-21 22:32:21.474794
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp_group = BlueprintGroup()
    bp1 = Blueprint(name='bp1', url_prefix='/bp1')
    bp2 = Blueprint(name='bp2', url_prefix='/bp2')

    bp_group.insert(0, bp1)
    bp_group.insert(0, bp2)

    assert bp1.url_prefix == '/bp1'
    assert bp2.url_prefix == '/bp2'

# Generated at 2022-06-21 22:32:25.583498
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bp1.route('/test1', methods=['GET'])(lambda x: x)
    bp2.route('/test2', methods=['GET'])(lambda x: x)
    bp3.route('/test3', methods=['GET'])(lambda x: x)
    bp4.route('/test4', methods=['GET'])(lambda x: x)

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    b

# Generated at 2022-06-21 22:32:36.520527
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp3)
    bpg.append(bp4)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-21 22:32:37.484680
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    BlueprintGroup()


# Generated at 2022-06-21 22:32:47.995461
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    #  create an instance of class BlueprintGroup
    bpg = BlueprintGroup()
    #  create two instances of class Blueprint
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    #  add them in to the instance of class BlueprintGroup
    bpg.append(bp1)
    bpg.append(bp2)
    #  delete the item
    del bpg[1]
    #  check the lenght of bp1
    assert 1 == len(bpg)
    #  check if bp2 is still within the instance
    assert bp2 not in bpg


# Generated at 2022-06-21 22:33:08.657709
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    assert len(bpg) == 0
    bpg.append(bp1)
    assert len(bpg) == 1
    bpg.append(bp2)
    assert len(bpg) == 2
    del bpg._blueprints[0]
    assert len(bpg) == 1
    del bpg._blueprints[0]
    assert len(bpg) == 0



# Generated at 2022-06-21 22:33:15.265133
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    assert bpg[0] == bp3
    assert bpg[1] == bp4


# Generated at 2022-06-21 22:33:20.822110
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)
    result = group[0]
    assert(result.name == bp1.name)


# Generated at 2022-06-21 22:33:28.776593
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")
    bp5 = Blueprint("bp5", url_prefix="/bp5")
    bpg = BlueprintGroup("/api", version="v1")

    # Make Sure that the Initializes are working
    assert bpg.url_prefix is not None
    assert bpg.version is not None
    assert len(bpg._blueprints) == 0

    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)

    # Test insert at 1

# Generated at 2022-06-21 22:33:32.552091
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp = BlueprintGroup()

    assert bp._blueprints == []
    assert bp._url_prefix == None
    assert bp._version == None
    assert bp._strict_slashes == None



# Generated at 2022-06-21 22:33:36.746658
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)
    assert len(group) == 2


# Generated at 2022-06-21 22:33:47.374182
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix='/api', version='v1')
    assert bpg.version == 'v1'

    bpg.extend([bp1, bp2])
    assert len(bpg) == 2
    assert bpg.blueprints == [bp1, bp2]

    assert bpg[0].url_prefix == '/api/bp1'
    assert bpg[0].version == 'v1'
    bpg[0].append_url_prefix('/v2')


# Generated at 2022-06-21 22:33:54.427311
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    """
    GIVEN an empty BlueprintGroup
    WHEN a new Blueprint is added to the BlueprintGroup
    THEN We are able to fetch the blueprint using __getitem__
    """
    bp_group = BlueprintGroup()
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp_group.append(bp1)
    bp_group.append(bp2)
    assert bp_group[0] == bp1
    assert bp_group[1] == bp2


# Generated at 2022-06-21 22:34:00.285466
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    # Test 1
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2)

    # Test 2
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2)

    # Test 3
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2)

    # Test 4
    bp1 = Blueprint('bp1', url_prefix='/bp1')
   

# Generated at 2022-06-21 22:34:13.110605
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    from sanic.blueprints import Blueprint
    from sanic.views import CompositionView

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    class TestView(CompositionView):

        def __init__(self, *args, **kwargs):
            methods = ["get", ]
            routes = ['/',]
            super().__init__(methods, routes, *args, **kwargs)

        async def get(self, request, *args, **kwargs):
            return text("Hi")

    bp1.add_route(TestView.as_view(), "/")
    bp2.add_route(TestView.as_view(), "/<param>")
