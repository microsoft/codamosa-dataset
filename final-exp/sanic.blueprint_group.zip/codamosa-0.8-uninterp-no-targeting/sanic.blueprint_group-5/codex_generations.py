

# Generated at 2022-06-21 22:28:54.692589
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp3)
    bpg.append(bp4)

    assert bpg[0] == bp3
    assert bpg[1] == bp4
    assert bpg.version == "v1"
    assert bpg.url_prefix == "/api"
    assert bpg.blueprints == [bp3, bp4]


# Generated at 2022-06-21 22:29:05.643529
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bpg = BlueprintGroup(bp1, bp2, url_prefix='/api', version='v1')
    bpg[0] = bp3
    bpg.append(bp4)
    bpg[1] = bp5
    assert bpg[0] is bp3
    assert bpg[1] is bp5
    assert bpg[2] is bp4
    assert len(bpg) == 3

# Generated at 2022-06-21 22:29:11.642259
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    group = BlueprintGroup("/api", version="v1")
    group.append(bp1)
    group.append(bp2)
    assert group.url_prefix == "/api"
    assert group.version == "v1"
    assert group.strict_slashes is None



# Generated at 2022-06-21 22:29:24.057408
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    """
    Test to ensure that the __iter__ method of the class `BlueprintGroup`
    is returning an Iterable object.
    """
    bp = BlueprintGroup()

    assert hasattr(bp, "__iter__")
    assert callable(bp.__iter__)

    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    bp.append(bp1)
    bp.append(bp2)

    index = 0
    for item in bp.__iter__():
        assert item is bp[index]
        index += 1

    assert index == len(bp)



# Generated at 2022-06-21 22:29:34.921823
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic('test_BlueprintGroup_middleware')
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp_group = BlueprintGroup(bp1, bp2, url_prefix='/group')
    bp_group.append(bp3)
    bp_group.append(bp4)

    @bp_group.middleware
    async def blueprint_group_middleware1(request, call_next):
        assert None is not request
        assert callable(call_next)
        response = await call_next(request)
       

# Generated at 2022-06-21 22:29:45.925553
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.insert(0, bp1)
    bpg.insert(1, bp2)
    bpg.insert(0, bp3)

    assert all(
        [
            bp.url_prefix == f"/api/{bpn}"
            for bp, bpn in zip(bpg.blueprints, ["/bp3", "/bp1", "/bp2"])
        ]
    )

    assert bpg.blueprints[0].version == "v1"
    assert bpg.blueprints

# Generated at 2022-06-21 22:29:53.198973
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic import Sanic
    from sanic.response import text

    def bp_middleware_one(*args, **kwargs):
        pass

    def bp_middleware_two(*args, **kwargs):
        pass

    def bp_middleware_three(*args, **kwargs):
        pass

    app = Sanic()

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup()
    bpg.append(bp3)
    bpg.append(bp4)


# Generated at 2022-06-21 22:29:58.310043
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    bp = Blueprint('bp')

    class BpG(BlueprintGroup):
        def __init__(self):
            super().__init__()
            self.append(bp)

    BpG().middleware('request')(lambda x:None)
    assert bp.middlewares['request']


# Generated at 2022-06-21 22:30:10.720010
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class Middleware():
        def __init__(self):
            self.call_count = 0

        def __call__(self, request):
            self.call_count += 1
            return request

    app = sanic.Sanic("sanic-test-app")
    bp = Blueprint("bp", url_prefix="/")

    @bp.middleware("request")
    async def bp_middleware(request):
        return request

    bpg = BlueprintGroup(bp)

    # Register middleware to blueprint group
    middleware = Middleware()
    bpg.middleware(middleware)

    url = "/"
    request, response = app.test_client.get(url)

    # Verify middleware has been called
    assert middleware.call_count > 0


# Generated at 2022-06-21 22:30:15.784587
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bpg = BlueprintGroup(url_prefix="api", version="v1")
    assert bpg.__class__.__name__ == "BlueprintGroup"
    assert isinstance(bpg, MutableSequence)
    assert bpg.url_prefix == "api"
    assert bpg.version == "v1"


# Generated at 2022-06-21 22:30:23.129461
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpt = BlueprintGroup('/api')
    bpt._blueprints = [bp1, bp2]

    assert list(bpt) == [bp1, bp2]


# Generated at 2022-06-21 22:30:31.509381
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp3', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    for bp in bpg:
        assert isinstance(bp, Blueprint)


# Generated at 2022-06-21 22:30:43.891688
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    """
    Unit Test for the BlueprintGroup append method to
    ensure it leverages the _sanitize_blueprint method
    """
    bp = sanic.Blueprint("test", url_prefix="/test")
    bpg = BlueprintGroup()
    bpg.append(bp)
    assert bpg.url_prefix is None
    assert bpg.version is None
    assert bpg.strict_slashes is None
    assert bpg.blueprints[0].url_prefix == "test"
    assert bpg.blueprints[0].version == bp.version
    assert bpg.blueprints[0].strict_slashes == bp.strict_slashes

    bp1 = sanic.Blueprint("test1", url_prefix="/test1", version=1)

# Generated at 2022-06-21 22:30:49.321303
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1', version='v5')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert bpg[0] == bp1
    assert bpg[1] == bp2
    bpg.append(2)
    assert bpg[2] == 2
    assert len(bpg) == 3
    assert bpg.version == bp1.version


# Generated at 2022-06-21 22:30:53.793263
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')

    group = BlueprintGroup(bp1, bp2)

    assert group[0] == bp1
    assert group[1] == bp2

# Generated at 2022-06-21 22:30:54.879755
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    BlueprintGroup(url_prefix='/test')

# Generated at 2022-06-21 22:30:58.534243
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert bpg.__len__() == 2


# Generated at 2022-06-21 22:31:02.978290
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bpg = BlueprintGroup(url_prefix='/api', version='v1', strict_slashes=False)
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg.__setitem__(0, bp1)
    bpg.__setitem__(1, bp2)
    assert bpg.__getitem__(0) == bp1
    assert bpg.__getitem__(1) == bp2


# Generated at 2022-06-21 22:31:10.320527
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    bpg[1] = bp1

    assert bp1 in bpg._blueprints


# Generated at 2022-06-21 22:31:22.379909
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    from sanic import Blueprint
    from sanic.url_route import UrlRoute
    from sanic.blueprints import BlueprintGroup
    from sanic.constants import HTTP_METHODS

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    urls = UrlRoute()

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-21 22:31:31.113404
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    group = Blueprint.group(bp1, bp2)
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    assert len(group) == 2
    assert len(bpg) == 4


# Generated at 2022-06-21 22:31:42.833411
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bp3 = sanic.Blueprint('bp3', url_prefix='/bp3')
    bp4 = sanic.Blueprint('bp4', url_prefix='/bp4')
    
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-21 22:31:53.289995
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Create blueprint group

    blueprint = Blueprint(__name__)

    blueprint_group = BlueprintGroup(url_prefix='/bpg')
    blueprint_group.append(blueprint)

    # middleware1
    def middleware1(request):
        return text('applied on BlueprintGroup')

    blueprint_group.middleware(middleware1)

    # middleware2
    def middleware2(request):
        return text('applied on Blueprint')

    blueprint_group.middleware(middleware2)

    # Apply middleware
    @blueprint.middleware('request')
    async def middleware3(request):
        return text('applied on Blueprint')

    @blueprint_group.middleware('request')
    async def middleware4(request):
        return text('applied on BlueprintGroup')


# Generated at 2022-06-21 22:31:59.567292
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)

    assert group[1] == bp2, "Group item didn't match"


# Generated at 2022-06-21 22:32:04.240197
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    _bp = Blueprint("bp1")
    _bp1 = Blueprint("bp2")
    bpg = BlueprintGroup()
    bpg.append(_bp)
    assert bpg[0] == _bp
    bpg.append(_bp1)
    assert bpg[1] == _bp1



# Generated at 2022-06-21 22:32:10.428457
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    print('bp1',bp1)
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    assert len(bpg) == 0
    bpg.append(bp1)
    assert len(bpg) == 1
    bpg.append(bp2)
    assert len(bpg) == 2
    bpg[0] = bp2
    assert len(bpg) == 2
    assert bpg[0] == bp2
    assert bpg[1] == bp2


# Generated at 2022-06-21 22:32:16.754412
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    class TestBlueprint(sanic.Blueprint):
        pass
    blueprint_group = BlueprintGroup(url_prefix='/urlPrefix', version='v2')
    item = TestBlueprint(name='test', url_prefix='/urlPrefix1')
    blueprint_group.append(item)
    blueprint_group[0] = item
    blueprint_group[1] = item
    blueprint_group[2] = item
    blueprint_group[3] = item
    blueprint_group[-1] = item


# Generated at 2022-06-21 22:32:27.981289
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')

    bpg = BlueprintGroup()
    bpg[0] = bp1
    bpg[1] = bp2

    assert(bp1 == bpg._blueprints[0])
    assert(bp2 == bpg._blueprints[1])

    # AttributeError: 'BlueprintGroup' object does not support item assignment
    with pytest.raises(AttributeError) as e_info:
        bpg[2] = bp3


# Generated at 2022-06-21 22:32:35.113689
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    def sample_middleware(request):
        return request

    blueprint_group = BlueprintGroup(url_prefix='/v1')
    blueprint_group.append(Blueprint(name='bp1'))
    blueprint_group.append(Blueprint(name='bp2'))

    blueprint_group.middleware(sample_middleware)

    for blueprint in blueprint_group.blueprints:
        assert sample_middleware in blueprint.registered_middleware['request']



# Generated at 2022-06-21 22:32:46.327277
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    assert bpg.url_prefix == "/api"
    assert bpg.version == "v1"
    assert bp3.url_prefix == "/api/bp4"
    assert bp4.url_prefix == "/api/bp4"
    assert bpg.blueprints == [bp3, bp4]


# Generated at 2022-06-21 22:32:53.688873
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    group = BlueprintGroup()
    bp = Blueprint(url_prefix='/bp1')
    group.append(bp)
    bp_new = Blueprint(url_prefix='/bp1/bp2')
    group[0] = bp_new
    assert group[0].url_prefix == '/bp1/bp2'

# Generated at 2022-06-21 22:32:56.269652
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    # Sanity test to check that BlueprintGroup() throws no error
    BlueprintGroup()

# Generated at 2022-06-21 22:33:02.024760
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    a_list = []
    a_list.append(1)
    assert a_list == [1]
    a_list.append(2)
    assert a_list == [1, 2]
    a_list.append(3)
    assert a_list == [1, 2, 3]



# Generated at 2022-06-21 22:33:11.485365
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic import Blueprint
    from sanic_openapi import doc
    from sanic.response import json
    from sanic.exceptions import abort
    from sanic.exceptions import InvalidUsage
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    counter = 0
    @doc.produce({"x": "string"})
    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')


# Generated at 2022-06-21 22:33:16.232297
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    '''
    Test __len__ method of class BlueprintGroup
    '''
    blueprint_group = BlueprintGroup()
    blueprint_group.append("test_BlueprintGroup___len__")
    blueprint_group.append("test_BlueprintGroup___len__")
    blueprint_group.append("test_BlueprintGroup___len__")
    assert len(blueprint_group) == 3


# Generated at 2022-06-21 22:33:23.795436
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix='/bpg')
    bpg.append(bp1)
    bpg.append(bp2)
    assert bpg[0] == bp1
    assert bpg[1] == bp2
    for bp in bpg:
        assert bp in [bp1, bp2]


# Generated at 2022-06-21 22:33:27.042902
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = BlueprintGroup()

    group.append(bp1)
    group.append(bp2)

    assert group[0] is bp1



# Generated at 2022-06-21 22:33:35.712585
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp1_group = BlueprintGroup()
    bp1_group.append(bp1)
    bp1_group.append(bp2)
    assert len(bp1_group._blueprints) == 2
    assert bp1_group._blueprints[0] == bp1
    assert bp1_group._blueprints[1] == bp2


# Generated at 2022-06-21 22:33:42.356442
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    #insert bp2 in a Blueprint Group list
    bps = [bp1, bp3, bp4]
    bpgrp = BlueprintGroup(bps[0],bps[1],bps[2],url_prefix="/api", version="v1")
    bpgrp.insert(1,bp2)
    assert bpgrp[1]==bp2
    bpgrp.insert(0,bp5)
   

# Generated at 2022-06-21 22:33:48.082864
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    # Setup
    blueprint = Blueprint('testing_group')
    blueprint_group = BlueprintGroup()

    blueprint_group.append(blueprint)
    
    # Exercise
    blueprint_group_iterator = blueprint_group.__iter__()

    # Verify
    blueprint_iterator = blueprint.__iter__()
    assert blueprint_iterator == blueprint_group_iterator


# Generated at 2022-06-21 22:33:59.232680
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")

    bpg = BlueprintGroup()

    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bpg) == 2



# Generated at 2022-06-21 22:34:12.297077
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1', version="v1")
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bpg = BlueprintGroup(url_prefix='/api', version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    bpg.insert(1, bp5)
    assert bp5 == bpg[1]

# Generated at 2022-06-21 22:34:14.024015
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    sanic.app.blueprint(test_BlueprintGroup___iter__)



# Generated at 2022-06-21 22:34:20.771487
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    # Create a new BlueprintGroup
    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    # create a list of blueprints
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    # Add the blueprints to the BlueprintGroup
    bpg.append(bp3)
    bpg.append(bp4)

    # Check if we can iterate over the BlueprintGroup
    for bp in bpg:
        assert isinstance(bp, Blueprint)



# Generated at 2022-06-21 22:34:29.636343
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @sanic.blueprint(url_prefix="/bp1")
    def bp1():
        pass

    @sanic.blueprint(url_prefix="/bp2")
    def bp2():
        pass

    blueprint_group = BlueprintGroup()
    blueprint_group.append(bp1)
    blueprint_group.append(bp2)

    @blueprint_group.middleware()
    def bpgroup_middleware(request):
        return "bpgroup_middleware"

    assert bp1.middleware_stack[0] == bpgroup_middleware
    assert bp2.middleware_stack[0] == bpgroup_middleware

# Generated at 2022-06-21 22:34:35.654442
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix='/api')
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)

    assert len(bpg) == 3
    bpg.__delitem__(1)
    assert len(bpg) == 2

# Generated at 2022-06-21 22:34:42.488153
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')

    group = Blueprint.group(bp1, bp2)

    group.insert(0, bp3)

    assert bp3 == group[0]
    assert bp1 == group[1]
    assert bp2 == group[2]
    assert len(group) == 3


# Generated at 2022-06-21 22:34:44.833062
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    index = 0
    item = Blueprint('bp1', url_prefix='/bp1')
    bp = BlueprintGroup(url_prefix='/api/v1')
    bp.__setitem__(index, item)
    assert bp[0].name == 'bp1'


# Generated at 2022-06-21 22:34:50.416558
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    from sanic.blueprints import Blueprint
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert bpg[0] == bp1
    assert bpg[1] == bp2


# Generated at 2022-06-21 22:34:56.836303
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    assert isinstance(bpg[0], Blueprint)
    assert isinstance(bpg[1], Blueprint)

    assert bpg[0] == bp1
    assert bpg[1] == bp2



# Generated at 2022-06-21 22:35:18.834737
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    from sanic import Blueprint
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    assert 0 == len(bpg)
    bpg.append(bp1)
    assert 1 == len(bpg)
    bpg.append(bp2)
    assert 2 == len(bpg)



# Generated at 2022-06-21 22:35:22.548473
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp = Blueprint("bp", url_prefix="bp_url")
    bpg = BlueprintGroup("bpg_url")
    bpg.append(bp)
    assert bpg[0] == bp


# Generated at 2022-06-21 22:35:31.202717
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    """
    Unit test case to test the functionality of `BlueprintGroup.insert` method.

    :return: None
    """
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")
    bp5 = Blueprint("bp5", url_prefix="/bp5")
    bp6 = Blueprint("bp6", url_prefix="/bp6")

    bpg = BlueprintGroup(bp1)
    bpg.append(bp2)
    bpg.append(bp3)

    bpg.insert(1, bp4)
    bpg.insert(3, bp5)
    bpg

# Generated at 2022-06-21 22:35:35.162451
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    assert isinstance(bpg, BlueprintGroup)
    bpg.append(bp1)
    bpg.append(bp2)
    assert bpg[0] == bp1
    assert bpg[1] == bp2


# Generated at 2022-06-21 22:35:41.381042
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    from sanic import Blueprint
    bpg = BlueprintGroup()
    bpg.insert(0, Blueprint('bp1', url_prefix='/bp1'))
    bp1 = Blueprint('bp1', url_prefix='/bp2')
    bpg.insert(1, bp1)
    assert bpg.blueprints == [Blueprint('bp1', url_prefix='/bp1'), bp1], 'blueprints should be [bp, bp1]'


# Generated at 2022-06-21 22:35:45.952905
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bpg = BlueprintGroup(url_prefix="/api", version=1, strict_slashes=False)
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg[0] is bp1
    assert bpg[1] is bp2



# Generated at 2022-06-21 22:35:55.701916
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="1.0.0")
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp2.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp2 Only')

    run_sanic_app(app=sanic.Sanic(), blueprint=bpg)

# Generated at 2022-06-21 22:36:05.496387
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg1 = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    bpg2 = BlueprintGroup('/api/v2', url_prefix="/api")

    assert bpg1.blueprints == [bp3, bp4]
    assert bpg2.blueprints == ['api/v2']
    assert bpg1.url_prefix == '/api'
    assert bpg1._version == 'v1'
    assert bpg1._strict_slashes is None


# Generated at 2022-06-21 22:36:10.652466
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert next(iter(bpg)) == bp1



# Generated at 2022-06-21 22:36:13.989023
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    # Check the initial value of class attribute
    bg = BlueprintGroup(url_prefix="/api", version="v1", strict_slashes=True)
    assert bg.url_prefix == "/api"
    assert bg.version == "v1"
    assert bg.strict_slashes == True


# Generated at 2022-06-21 22:36:54.088070
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(bp1, bp2)

    assert len(bpg) == 2
    assert len(bpg._blueprints) == 2

    bpg.append(bp1)
    assert len(bpg) == 3

    bpg.append(bp2)
    assert len(bpg) == 4



# Generated at 2022-06-21 22:36:54.929643
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    BlueprintGroup.__delitem__()


# Generated at 2022-06-21 22:36:59.238164
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    param = sanic.Blueprint(__name__)

    @param.route('/')
    async def bp1_route(request):
        return text('test')

    bpg = BlueprintGroup()
    bpg.append(param)
    del bpg[0]



# Generated at 2022-06-21 22:37:06.804985
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    # Test with a Blueprint Group
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    # Test with a List/Tuple
    list_test = [bp1, bp2]
    tuple_test = (bp1, bp2)

    for test_item in [bpg, list_test, tuple_test]:
        for _bp in test_item:
            assert _bp in [bp1, bp2, bp3, bp4]


# Generated at 2022-06-21 22:37:08.101762
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    """
    Test for method __setitem__ of class BlueprintGroup
    """
    pass



# Generated at 2022-06-21 22:37:14.148923
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    assert bpg._url_prefix == "/api"
    assert bpg._version == "v1"

    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg) == 2
    assert bpg[0] == bp1
    assert bpg[1] == bp2

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg.insert(0, bp3)
    bpg.insert(1, bp4)

# Generated at 2022-06-21 22:37:21.444385
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp = Blueprint("version", url_prefix="/v1")

    bpg = BlueprintGroup("blueprint_group", url_prefix="/bp", version="v1", strict_slashes=True)
    bpg.append(bp)
    assert bpg.url_prefix == "/bp"
    assert bpg.version == "v1"
    assert bpg.strict_slashes is True
    assert bp.url_prefix == "/bp/v1"



# Generated at 2022-06-21 22:37:27.080513
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")



# Generated at 2022-06-21 22:37:32.345632
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    assert [bp3,bp4] == bpg


# Generated at 2022-06-21 22:37:36.193940
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    app = sanic.Sanic(name=__name__)

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2)
    group[0] = bp2
    group[1] = bp1


# Generated at 2022-06-21 22:38:20.057909
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    assert bp1.url_prefix == '/bp1'
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    assert bp2.url_prefix == '/bp2'

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    prefix = "/api"
    version = "v1"
    bpg = BlueprintGroup(bp3, bp4, url_prefix=prefix, version=version)
    assert bpg.url_prefix == prefix
    assert bpg.blueprints == [bp3, bp4]
    assert bpg.version == version


# Generated at 2022-06-21 22:38:23.249782
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix='/api')
    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg[0] is bp1
    assert bpg[1] is bp2


# Generated at 2022-06-21 22:38:23.639302
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    pass



# Generated at 2022-06-21 22:38:29.110979
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)
    bpg.append(bp2)
    assert bpg._blueprints == [bp1, bp2]

    bp3.url_prefix = '/bp3'
    bpg.append(bp3)
    assert bpg._blueprints == [bp1, bp2, bp3]

    bpg

# Generated at 2022-06-21 22:38:36.899984
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bp3 = sanic.Blueprint('bp3', url_prefix='/bp3')
    bp4 = sanic.Blueprint('bp4', url_prefix='/bp4')
    group = BlueprintGroup(bp1, bp2)
    assert len(group) == 2
    group.append(bp3)
    group.append(bp4)
    assert len(group) == 4
    group.insert(2, bp3)
    assert len(group) == 5

# Generated at 2022-06-21 22:38:42.575284
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bp3 = sanic.Blueprint('bp3', url_prefix='/bp3')
    bp4 = sanic.Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix='/api', version='v1')
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    assert len(bpg) == 4
    assert len(bpg.blueprints) == 4
    assert bpg.version == 'v1'
    assert bpg.url_prefix == 'api'