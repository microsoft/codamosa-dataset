

# Generated at 2022-06-21 22:28:46.351635
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bg = BlueprintGroup()
    bg.append(bp1)
    bg.append(bp2)
    bg.append(bp3)
    bg.append(bp4)

    for bp in bg:
        assert isinstance(bp, Blueprint)


# Generated at 2022-06-21 22:28:56.628738
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg.blueprints == [bp1, bp2]

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg[0] = bp3
    bpg[1] = bp4
    assert bpg.blueprints == [bp3, bp4]

    bpg[1]
    assert bpg.blueprints[1] == bp4

    bpg[0]
    assert bpg.blueprints[0]

# Generated at 2022-06-21 22:29:05.556983
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    assert bpg[0].name == bp3.name
    assert bpg[1].name == bp4.name


# Generated at 2022-06-21 22:29:10.393648
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    app = sanic.Sanic(__name__)
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bpg) == 2
    assert bpg[0] == bp1
    assert bpg[1] == bp2


# Generated at 2022-06-21 22:29:20.296433
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    
    print(bpg.blueprints)


if __name__ == "__main__":
    test_BlueprintGroup_append()

# Generated at 2022-06-21 22:29:28.238562
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    # Patch Blueprint Group append method to avoid recursive call to
    # method insert
    with mock.patch(
        "sanic.blueprints.BlueprintGroup.append",
        side_effect=BlueprintGroup.append,
        autospec=True,
    ):
        # Create a Blueprint Group
        bpg = BlueprintGroup()
        # Create a sample Blueprint
        bp = sanic.Blueprint("bp")

        # Append a Blueprint to a Group
        bpg.insert(0, bp)

        # Ensure that the Blueprint is present in
        assert bp in bpg



# Generated at 2022-06-21 22:29:37.574573
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')
    bp7 = Blueprint('bp7', url_prefix='/bp7')
    bp8 = Blueprint('bp8', url_prefix='/bp8')
    bp9 = Blueprint('bp9', url_prefix='/bp9')
    bp10 = Blueprint('bp10', url_prefix='/bp10')

# Generated at 2022-06-21 22:29:48.114175
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
  test_blueprint_group = BlueprintGroup(
    url_prefix=r"/api/v1",
    version="v1",
    strict_slashes=True
  )
  test_blueprint1 = Blueprint("test_blueprint1", url_prefix=r"/test_blueprint1")
  test_blueprint2 = Blueprint("test_blueprint2", url_prefix=r"/test_blueprint2")
  test_blueprint_group.append(test_blueprint1)
  test_blueprint_group.append(test_blueprint2)
  # TODO What if there are two blueprints with the same name?
  assert str([str(item) for item in test_blueprint_group]) == str(["test_blueprint1", "test_blueprint2"])


# Generated at 2022-06-21 22:30:00.575587
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    # code to test the BlueprintGroup.__setitem__ method.
    # create some dummy blueprints to add in the group
    bp_1 = Blueprint("bp1", url_prefix="/bp1")
    bp_2 = Blueprint("bp2", url_prefix="/bp2")
    bp_3 = Blueprint("bp3", url_prefix="/bp3")
    bp_group = BlueprintGroup(url_prefix="/api")
    # Append all three Blueprints to the group
    bp_group.append(bp_1)
    bp_group.append(bp_2)
    # override a blueprint with another blueprint
    bp_group[1] = bp_3
    assert len(bp_group) == 2
    assert bp_group[0] == bp_1

# Generated at 2022-06-21 22:30:09.602432
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg.url_prefix is None
    assert bpg.version is None
    assert bpg.strict_slashes is None

    assert len(bpg) == 2
    assert bp1 in bpg
    assert bp2 in bpg



# Generated at 2022-06-21 22:30:23.078943
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-21 22:30:29.593876
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    @bpg.middleware('request')
    async def group_middleware(request):
        assert True, 'Middleware must be added'


# Generated at 2022-06-21 22:30:42.333339
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    group = Blueprint.group()

    @group.middleware('request')
    def test_middleware1(request):
        return request

    @group.middleware('request')
    def test_middleware2(request):
        return request

    assert len(group.blueprints) == 0

    bp1 = Blueprint('test_bp1')
    group.append(bp1)

    assert len(group.blueprints) == 1

    bp2 = Blueprint('test_bp2')
    group.append(bp2)

    assert len(group.blueprints) == 2

    assert len(bp1.request_middleware) == 2
    assert len(bp2.request_middleware) == 2

    bpg = Blueprint.group()

    bpg.append(bp1)
    bpg.append(bp2)


# Generated at 2022-06-21 22:30:46.538984
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg) == 2


# Generated at 2022-06-21 22:30:51.529103
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprints = [sanic.Blueprint(name) for name in ["bp1", "bp2", "bp3"]]
    bp_group = BlueprintGroup()
    for blueprint in blueprints:
        bp_group.append(blueprint)
    assert len(bp_group) == 3



# Generated at 2022-06-21 22:30:52.919823
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    BlueprintGroup.__delitem__(0)
    return True


# Generated at 2022-06-21 22:31:01.627119
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp = Blueprint("bp", url_prefix="/bp")
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")
    bp5 = Blueprint("bp5", url_prefix="/bp5")

    bpg = BlueprintGroup(url_prefix="/")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.insert(1, bp4)
    assert bpg.blueprints == [bp1, bp4, bp2, bp3]

    bpg.insert(-1, bp5)


# Generated at 2022-06-21 22:31:10.154968
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')

    bp_group = BlueprintGroup()
    bp_group.append(bp1)
    bp_group.append(bp2)

    for bp in bp_group:
        assert isinstance(bp, Blueprint)


# Generated at 2022-06-21 22:31:22.270500
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Sanic Blueprint Group Method middleware
    """

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg1 = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    bpg2 = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v2")

    app = sanic.Sanic()


# Generated at 2022-06-21 22:31:29.710254
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    assert group is not None
    assert group.blueprints == [bp1, bp2]
    assert group[0] == bp1
    assert group[1] == bp2
    assert len(group) == 2
    assert isinstance(group, MutableSequence)
    assert str(group) == "BlueprintGroup(bp1, bp2)"
    assert repr(group) == "<BlueprintGroup Object ['bp1', 'bp2']>"



# Generated at 2022-06-21 22:31:42.829970
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bpg = BlueprintGroup()

    @bpg.middleware("request")
    async def bpg_middleware(request):
        print("Request middleware for the Blueprint Group")

    @bpg.middleware("response")
    async def bpg_middleware(request, response):
        print("Response middleware for the Blueprint Group")

    assert bpg.middleware("request", bpg_middleware) is bpg_middleware
    assert bpg.middleware.__func__ is not None
    assert bpg.middleware.__code__ is not None
    assert bpg.middleware.__defaults__ is not None
    assert bpg.middleware.__kwdefaults__ is None

    bpg.append(bp1)
    b

# Generated at 2022-06-21 22:31:47.488432
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprints = BlueprintGroup()
    blueprint = Blueprint('Test Blueprint', url_prefix='/test')
    blueprints[0] = blueprint
    blueprint2 = blueprints[0]
    assert blueprint.name == blueprint2.name
    assert blueprint.url_prefix == blueprint2.url_prefix


# Generated at 2022-06-21 22:31:55.923981
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-21 22:32:06.890909
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp3)
    bpg.append(bp4)
    assert bpg[0].name == 'bp3'
    assert bpg[1].name == 'bp4'
    bpg[0] = bp1
    bpg[1] = bp2
    assert bpg[0].name == 'bp1'
    assert bpg[1].name == 'bp2'
    bpg[0]

# Generated at 2022-06-21 22:32:09.254708
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    BlueprintGroup = BlueprintGroup()
    BlueprintGroup._blueprints = ["blue"]
    result = BlueprintGroup.__getitem__(0)
    assert result == "blue"


# Generated at 2022-06-21 22:32:17.411064
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1', strict_slashes=None)
    bp2 = Blueprint('bp2', url_prefix='/bp2', strict_slashes=None)
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", strict_slashes=True)
    assert bpg[0].url_prefix == "/api/bp1"
    assert bpg[1].url_prefix == "/api/bp2"
    assert bpg.strict_slashes == True
    bpg.insert(2, Blueprint('bp3', url_prefix='/bp3'))
    assert bpg[2].url_prefix == "/api/bp3"

# Generated at 2022-06-21 22:32:29.024153
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    # NOTE: use the following line to check this test
    # bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return

# Generated at 2022-06-21 22:32:38.224342
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Given

    @BlueprintGroup.middleware('request')
    async def group_request_middleware(request):
        request['middleware'].append('group_request_middleware')

    @BlueprintGroup.middleware('response')
    async def group_response_middleware(request, response):
        response['middleware'].append('group_response_middleware')

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp1.middleware('request')(lambda request: 'bp1')
    bp2.middleware('request')(lambda request: 'bp2')
    bp1.middleware('response')(lambda request, response: 'bp1')

# Generated at 2022-06-21 22:32:47.304759
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    # Parameters
    index = 0
    item = sanic.Blueprint('bp1', url_prefix='/bp1')
    # Return value
    return_value = None

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = BlueprintGroup()

    bp3.append(bp1)

    bp3[index] = item

    assert bp3[index] == item
    assert bp3.blueprints[index] == item


# Generated at 2022-06-21 22:32:52.324911
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    url_prefix = "/api"
    version = "v1"
    strict_slashes = True
    bpg = BlueprintGroup(
        url_prefix=url_prefix, version=version, strict_slashes=strict_slashes
    )

    assert bpg.url_prefix == url_prefix
    assert bpg.version == version
    assert bpg.strict_slashes == strict_slashes



# Generated at 2022-06-21 22:33:06.520719
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')

    bp3 = sanic.Blueprint('bp3', url_prefix='/bp4')
    bp4 = sanic.Blueprint('bp4', url_prefix='/bp4')

    bpg = sanic.blueprints.BlueprintGroup(bp3, bp4, url_prefix="/api")
    bpg_with_version = sanic.blueprints.BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    assert bpg.url_prefix == '/api'
    assert bpg.version == None
    assert bpg.strict_slashes == None
    assert bpg.blueprints

# Generated at 2022-06-21 22:33:12.114027
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    for _idx, _bp in enumerate([bp1, bp2], start=1):
        assert _bp == bpg[_idx - 1]


# Generated at 2022-06-21 22:33:21.545839
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    @sanic.blueprint.group(url_prefix='/group')
    class TestBlueprintGroup:
        pass

    test_blueprint_group = TestBlueprintGroup()

    test_blueprint_group.append(Blueprint('bp1', url_prefix='/bp1'))
    test_blueprint_group.append(Blueprint('bp2', url_prefix='/bp2'))

    assert len(test_blueprint_group) == 2
    assert test_blueprint_group._url_prefix == '/group'

    del test_blueprint_group[0]
    assert len(test_blueprint_group) == 1
    assert test_blueprint_group._url_prefix == '/group'


# Generated at 2022-06-21 22:33:26.596512
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bpg = BlueprintGroup()
    bpg.append(bp)
    bpg.append(bp2)
    @bpg.middleware('request')
    def test_middleware(request):
        return

    assert test_middleware in bp.middlewares['request']
    assert test_middleware in bp2.middlewares['request']


# Generated at 2022-06-21 22:33:36.506970
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    """
    Creating a new instance of `BlueprintGroup` object
    """

    url_prefix = "/api/v1"
    version = "v1"
    strict_slashes = True
    bp_group = BlueprintGroup(
        url_prefix=url_prefix, version=version, strict_slashes=strict_slashes
    )

    assert bp_group.url_prefix == url_prefix
    assert bp_group.version == version
    assert bp_group.strict_slashes == strict_slashes
    assert len(bp_group.blueprints) == 0



# Generated at 2022-06-21 22:33:41.747863
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    """
    Test the __setitem__ method of the BlueprintGroup Class
    """

    bp = BlueprintGroup()
    bp.append(sanic.Blueprint(__name__))

    # This should not throw any exception
    bp[0] = sanic.Blueprint(__name__)

    # This should also not throw any exception
    bp[1:] = bp[:1]
    


# Generated at 2022-06-21 22:33:50.959209
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    """
    Test the behavior of constructor of `BlueprintGroup`
    """
    # Test case 1
    bg1 = BlueprintGroup()
    assert bg1.url_prefix is None
    assert bg1.version is None
    assert bg1.strict_slashes is None
    assert bg1._blueprints == []

    # Test case 2
    bg2 = BlueprintGroup(url_prefix="test", version="test", strict_slashes=True)
    assert bg2.url_prefix == "test"
    assert bg2.version == "test"
    assert bg2.strict_slashes is True
    assert bg2._blueprints == []



# Generated at 2022-06-21 22:33:57.383774
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2)
    assert len(group) == 2

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    group.append(bp3)
    group.append(bp4)
    assert len(group) == 4
    assert bp1 in group
    assert bp2 in group
    assert bp3 in group
    assert bp4 in group



# Generated at 2022-06-21 22:34:00.850530
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    """
    GIVEN a blueprint group
    WHEN __iter__ is called
    THEN check if the blueprint group is iterable
    """
    blueprint_group = BlueprintGroup()
    blueprint_1 = Blueprint("test__iter__")
    blueprint_2 = Blueprint("test__iter__")
    blueprint_group.append(blueprint_1)
    blueprint_group.append(blueprint_2)
    assert set([
        blueprint for blueprint in blueprint_group
    ]) == set([blueprint_1, blueprint_2])


# Generated at 2022-06-21 22:34:09.987376
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1', strict_slashes=True)
    bp2 = Blueprint('bp2')
    bp3 = Blueprint('bp3')
    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)
    assert group[0] is bp1
    assert group[1] is bp2

    group[0] = bp3
    assert group[0] is bp3
    assert group[1] is bp2


# Generated at 2022-06-21 22:34:24.498617
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)
    bpg.append(bp2)

    for _bp in bpg:
        assert isinstance(_bp, Blueprint)



# Generated at 2022-06-21 22:34:33.757405
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-21 22:34:39.597512
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    assert len(BlueprintGroup()) == 0
    assert len(BlueprintGroup(url_prefix='/api/v1')) == 0

    assert len(BlueprintGroup(url_prefix='/api/v1', version="v1")) == 0
    assert len(BlueprintGroup(url_prefix='/api/v1', version="v1.0")) == 0
    assert len(BlueprintGroup(url_prefix='/api/v1', version=1)) == 0
    assert len(BlueprintGroup(url_prefix='/api/v1', version=1.0)) == 0
    assert len(BlueprintGroup(url_prefix='/api/v1', version=True)) == 0
    assert len(BlueprintGroup(url_prefix='/api/v1', version=False)) == 0


# Generated at 2022-06-21 22:34:49.116817
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint

    class FakeRequest:
        def __init__(self):
            self.method = None

    app = Sanic('test_BlueprintGroup_middleware')
    bp = Blueprint('test_BlueprintGroup_middleware')
    bp_group = BlueprintGroup()
    bp_group.append(bp)

    @bp.middleware('request')
    async def test_middleware(request):
        request.method = 'middleware'

    @bp.route('/test')
    async def test_handler(request):
        assert request.method == 'middleware'
        return text('OK')

    @bp_group.middleware('request')
    async def test_middleware2(request):
        request.method = 'middleware2'



# Generated at 2022-06-21 22:34:58.881456
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    group = BlueprintGroup(url_prefix='/api', version='v1')
    group.append(bp1)
    group.append(bp2)
    bpg = BlueprintGroup(url_prefix='/bpg', version='v2')
    bpg.append(bp3)
    bpg.append(bp4)

    assert group[0] == bp1
    assert group[1] == bp2
    assert bpg[0] == bp3
    assert bpg[1] == bp4

# Generated at 2022-06-21 22:35:06.184470
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup('/api', 'v1')
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert bpg[2] == bp3
    assert bpg[3] == bp4


# Generated at 2022-06-21 22:35:19.202663
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    # bp3 = Blueprint('bp3', url_prefix='/bp4')
    # bp3 = Blueprint('bp3', url_prefix='/bp4')

    # bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    # Build a Blueprint group out of two blueprint objects
    group = BlueprintGroup(bp1, bp2)

    @group.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    assert bp1.middlewares[0] == group_middleware

# Generated at 2022-06-21 22:35:26.749619
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    from sanic.blueprints import Blueprint
    bp = Blueprint('bp1', url_prefix='/bp1')
    bp1 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp)
    bpg.insert(0, bp1)
    assert len(bpg) == 2
    assert bpg[0] == bp1, "bp1 should be the first item"
    assert bpg[1] == bp, "bp should be the second item"


# Generated at 2022-06-21 22:35:31.465516
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    from sanic import Blueprint, Sanic
    app = Sanic("test_BlueprintGroup___delitem__")
    bp = Blueprint("test_BlueprintGroup___delitem__")

    @bp.route("/")
    async def handler(request):
        pass

    bpg = BlueprintGroup()
    bpg.append(bp)
    assert len(bpg) == 1

    del bpg[0]
    assert len(bpg) == 0


# Generated at 2022-06-21 22:35:35.958738
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    group = Blueprint.group(bp1, bp2)
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    assert len(group) == 2
    assert len(bpg) == 2

# Generated at 2022-06-21 22:35:51.092851
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    test_bp = BlueprintGroup()
    assert len(test_bp) == 0
    test_bp.append(Blueprint("test", url_prefix="/test"))
    assert len(test_bp) == 1


# Generated at 2022-06-21 22:35:57.641953
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp_group = BlueprintGroup(url_prefix="/api")

    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")

    bp_group.extend([bp1, bp2, bp3])

    it = iter(bp_group)

    assert next(it) == bp1
    assert next(it) == bp2
    assert next(it) == bp3



# Generated at 2022-06-21 22:35:58.403918
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    pass

# Generated at 2022-06-21 22:36:03.155424
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bpc1 = Blueprint("bp1", url_prefix="/bp1")
    bpc2 = Blueprint("bp2", url_prefix="/bp2")

    bpg = BlueprintGroup(bpc1, bpc2)

    assert bpg[0] == bpc1
    assert bpg[1] == bpc2


# Generated at 2022-06-21 22:36:11.927185
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    assert bpg.url_prefix == '/api'
    assert bpg.version == 'v1'
    assert bpg.strict_slashes is None
    assert bpg.blueprints == [bp3, bp4]


# Generated at 2022-06-21 22:36:16.140071
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bgp = BlueprintGroup()

    bp1 = Blueprint(__name__)
    bp2 = Blueprint("bp2")

    bgp.append(bp1)
    bgp.append(bp2)

    res = []
    for bp in bgp:
        res.append(bp)

    assert len(res) == 2
    assert res[0] is bp1
    assert res[1] is bp2


# Generated at 2022-06-21 22:36:27.048943
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")

    bpg = BlueprintGroup(url_prefix="/api", version="v1", strict_slashes=False)
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)

    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert bpg[2] == bp3
    assert len(bpg) == 3

    bpg[0] = bp3
    bpg[1] = bp2
    bpg[2] = bp1

    assert bpg[0] == bp

# Generated at 2022-06-21 22:36:36.976562
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')

    bp7 = Blueprint('bp7', url_prefix='/bp7')
    bp8 = Blueprint('bp8', url_prefix='/bp8')

    bpg = BlueprintGroup(bp7, bp8, url_prefix="/api1", version="v2")

# Generated at 2022-06-21 22:36:43.439375
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg = BlueprintGroup(url_prefix="/api")
    bpg = BlueprintGroup(version="v1")
    bpg = BlueprintGroup()


# Generated at 2022-06-21 22:36:53.649994
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')
