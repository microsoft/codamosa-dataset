

# Generated at 2022-06-21 22:28:50.688134
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bpg = BlueprintGroup()
    bp = Blueprint('bp', url_prefix='/bp')
    bpg[0] = bp
    assert bpg[0] == bp



# Generated at 2022-06-21 22:28:53.986157
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp = BlueprintGroup(url_prefix='/api/v1')
    group = Blueprint.group(bp)
    assert len(group) == 1
    del group[0]
    assert len(group) == 0


# Generated at 2022-06-21 22:28:56.869714
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp = Blueprint('bp', url_prefix='/bp')
    group = BlueprintGroup(bp, url_prefix="/api", version="v1")
    try:
        del group[0]
        assert True
    except:
        assert False


# Generated at 2022-06-21 22:29:08.502017
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')
    bp7 = Blueprint('bp7', url_prefix='/bp7')
    bp8 = Blueprint('bp8', url_prefix='/bp8')

    bpg = BlueprintGroup(url_prefix='/bpg')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

   

# Generated at 2022-06-21 22:29:13.107050
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    from sanic.blueprints import Blueprint
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp3', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.extend([bp3,bp4])

    assert bpg[0] is bp3
    assert bpg[1] is bp4

    del bpg[0]
    assert bpg[0] is bp4


# Generated at 2022-06-21 22:29:20.095312
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bpg.append(bp1)
    iterator = bpg.__iter__()
    # Python 2 and 3 returns different object type for the iterator
    # Don't want to force user to install all the extra requirements
    # for development environment. So checking for both possibilities
    assert (
        isinstance(iterator, types.GeneratorType)
        or isinstance(iterator, types.GeneratorType)
    )


# Generated at 2022-06-21 22:29:31.210967
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group = BlueprintGroup()
    blueprint_instance = Blueprint('bp1', url_prefix='/bp1')
    blueprint_group.insert(0, blueprint_instance)
    assert blueprint_group[0] == blueprint_instance
    blueprint_group.insert(-1, blueprint_instance)
    assert blueprint_group[-1] == blueprint_instance
    blueprint_group.insert(len(blueprint_group), blueprint_instance)
    assert blueprint_group[-1] == blueprint_instance
    blueprint_group.insert(len(blueprint_group), blueprint_instance)
    assert blueprint_group[-1] == blueprint_instance
    blueprint_group.insert(len(blueprint_group), blueprint_instance)
    assert blueprint_group[-1] == blueprint_instance
    assert len(blueprint_group) == 4

# Generated at 2022-06-21 22:29:43.220972
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp3)
    bpg.append(bp4)

    bp1.route('/')(text('bp1'))
    bp2.route('/<param>')(text)

    bp3.route('/')(text('bp1'))
    bp4.route('/<param>')(text)

    group = Blueprint.group(bp1, bp2)

# Generated at 2022-06-21 22:29:51.934555
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp4', url_prefix='/bp4')
    bp6 = Blueprint('bp4', url_prefix='/bp4')
    bp7 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.extend([bp1, bp2, bp3, bp4])
    # make sure the iterator is iterable

# Generated at 2022-06-21 22:30:04.859919
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    # Scenario 00: Normal operation with Blueprint group
    app = sanic.Sanic("Blueprint group test")
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)
    assert group[0] is bp1
    assert group[1] is bp2

    # Scenario 01: Normal operation with Blueprint group
    app = sanic.Sanic("Blueprint group test")
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')

# Generated at 2022-06-21 22:30:18.152861
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg.url_prefix == "/api"
    assert bpg.version == "v1"
    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert len(bpg) == 2
    assert isinstance(bpg, MutableSequence)



# Generated at 2022-06-21 22:30:19.750935
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)
    for blueprint in group:
        assert blueprint in [bp1, bp2]


# Generated at 2022-06-21 22:30:31.115142
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    # Instantiate a BlueprintGroup Instance
    bpg = BlueprintGroup()
    bpg.append(
        Blueprint(
            "bp_group_test",
            url_prefix="/group_test",
            strict_slashes=True,
            version="1.0",
        )
    )
    assert bpg.url_prefix is None
    assert bpg.version is None
    assert bpg.strict_slashes is None
    assert bpg.blueprints[0].url_prefix == "/group_test"
    assert bpg.blueprints[0].strict_slashes is True
    assert bpg.blueprints[0].version == "1.0"

    # Instantiate a BlueprintGroup Instance
    bpg = BlueprintGroup(url_prefix="/bp_test", version="2.0", strict_slashes=True)


# Generated at 2022-06-21 22:30:38.247763
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    group = BlueprintGroup()
    group.insert(0, Blueprint("bp1", url_prefix="/bp1"))
    group.insert(1, Blueprint("bp2", url_prefix="/bp2"))

    assert len(group) == 2
    assert group.blueprints[0].url_prefix == "/bp1"
    assert group.blueprints[1].url_prefix == "/bp2"


# Generated at 2022-06-21 22:30:42.250446
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    # arrange
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp1')

    # act
    bpg = BlueprintGroup(bp1, bp2)
    bpg.insert(0, bp3)

    # assert
    assert bpg[0].url_prefix == '/bp1/bp1'
    assert bpg[1].url_prefix == '/bp1/bp2'
    assert bpg[2].url_prefix == '/bp2'



# Generated at 2022-06-21 22:30:45.610361
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprintGroup = BlueprintGroup()
    blueprintGroup.append(sanic.Blueprint(__name__))
    blueprintGroup.append(sanic.Blueprint(__name__))
    assert len(blueprintGroup) == 2


# Generated at 2022-06-21 22:30:55.803116
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bp3 = sanic.Blueprint('bp3', url_prefix='/bp4')
    bp4 = sanic.Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    assert bpg[0] == bp3
    assert bpg[1] == bp4
    with pytest.raises(IndexError) as e:
        print(bpg[3])


# Generated at 2022-06-21 22:30:59.078869
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)
    assert(group[0] == bp1)
    assert(group[1] == bp2)


# Generated at 2022-06-21 22:31:00.057921
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    pass

# Generated at 2022-06-21 22:31:12.995754
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # test blueprint_group.middleware(middleware, **kwargs)
    app = sanic.Sanic()
    bp_group = BlueprintGroup("test_group")
    my_middleware = lambda request: None

    bp_group.middleware(my_middleware)
    assert bp_group.blueprints == []
    assert len(app.middleware_stack) == 0

    bp = Blueprint("test_blueprint")
    bp_group.append(bp)
    assert len(bp_group.blueprints) == 1
    assert len(bp.middleware_stack) == 0

    bp_group.blueprints[0].middleware(my_middleware)
    assert len(bp.middleware_stack) == 1
    assert bp_group.blueprints[0].middleware_stack[0].name

# Generated at 2022-06-21 22:31:24.285605
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix='/my_bgp')
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.__delitem__(1)
    assert bpg.blueprints[0] == bp1, 'Unit test failed!'


# Generated at 2022-06-21 22:31:28.336702
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    """Unit test for method __len__ of class BlueprintGroup"""

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = Blueprint.group(bp1, bp2)
    assert len(bpg) == 2



# Generated at 2022-06-21 22:31:33.003366
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    """
    This method tests the append operation of `BlueprintGroup` class
    to verify the success or failure of operation.

    :return: None
    """
    bp_group = BlueprintGroup()

    assert bp_group.blueprints == []

    bp1 = Blueprint("bp1")
    bp_group.append(bp1)

    assert len(bp_group) == 1
    assert bp_group.blueprints == [bp1]

    bp2 = Blueprint("bp2")
    bp_group.append(bp2)

    assert len(bp_group) == 2
    assert bp_group.blueprints == [bp1, bp2]



# Generated at 2022-06-21 22:31:44.270678
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    error = False
    try:
        Blueprint.group(Blueprint('bp1', url_prefix='/bp1')).__delitem__(0)
    except TypeError:
        error = True
    assert error

    class TestGroup(BlueprintGroup):

        def __init__(self, bps=None):
            super().__init__()
            self._blueprints = bps or []

    bp1 = Blueprint('bp1', url_prefix='bp1')
    bp2 = Blueprint('bp2', url_prefix='bp2')
    bg = TestGroup([bp1, bp2])

    assert bp1 in bg
    assert bp2 in bg

    bg.__delitem__(0)

    assert bp1 not in bg
    assert bp2 in bg


# Generated at 2022-06-21 22:31:54.277676
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    """
    This test case is used to test if the BlueprintGroup class works well
    as an iterator. The BlueprintGroup class implements the __iter__ method
    which is one of the mandatory method to implement for a class to be
    used as an Iterable class.
    """
    # Create a Blueprint group.
    bp_group = BlueprintGroup()
    bp1 = Blueprint("bp_1")
    bp2 = Blueprint("bp_2")
    bp3 = Blueprint("bp_3")

    # Add the Blueprint to this group.
    bp_group.append(bp1)
    bp_group.append(bp2)
    bp_group.append(bp3)

    # Ensure that the class could be used as an iterable
    for bp in bp_group:
        assert bp in bp_group.blue

# Generated at 2022-06-21 22:31:59.103460
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    from sanic.blueprints import Blueprint

    blueprint_group=BlueprintGroup()
    blueprint_group.append(Blueprint("test"))
    blueprint=blueprint_group[0]
    assert blueprint._name=="test"


# Generated at 2022-06-21 22:31:59.724185
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    BlueprintGroup()

# Generated at 2022-06-21 22:32:06.318646
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    assert len(bpg) == 2

# Generated at 2022-06-21 22:32:16.225096
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    # Testing function BlueprintGroup.__delitem__

    # Instatiation of the Flask class
    class FlaskApp(object):
        def __init__(self):
            # Blueprint
            self.blueprints = []
            # List of url_map(s)
            self.url_map = {}
            # List of endpoint(s)
            self.endpoints = []

    # Object of Flask class
    app = FlaskApp()
    bp = Blueprint('bp', url_prefix='/bp')

    # Object of BlueprintGroup class
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp)
    # Del blueprint from blueprint group
    del bpg[0]
    assert len(bpg._blueprints) == 0

    # del blueprint from blueprint group
    bpg.append(bp)

# Generated at 2022-06-21 22:32:19.164145
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    pass


# Generated at 2022-06-21 22:32:32.791886
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
   bp3= Blueprint('bp3', url_prefix='/bp3')
   bp4= Blueprint('bp4', url_prefix='/bp4')
   group1= BlueprintGroup(bp3, bp4)
   assert len(group1) == 2


# Generated at 2022-06-21 22:32:38.621599
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    assert len(bpg) == 4


# Generated at 2022-06-21 22:32:47.598230
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    """
    Test the method insert of class BlueprintGroup
    """
    blueprint_group = BlueprintGroup()
    blueprint_group.insert(0, Blueprint)
    assert blueprint_group[0].name == Blueprint.__name__
    blueprint_group.insert(1, Blueprint)
    assert blueprint_group[1].name == Blueprint.__name__
    blueprint_group.insert(1, Blueprint)
    assert blueprint_group[1].name == Blueprint.__name__
    blueprint_group.insert(10, Blueprint)
    assert blueprint_group[10].name == Blueprint.__name__


# Generated at 2022-06-21 22:32:48.160997
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    pass

# Generated at 2022-06-21 22:32:54.182629
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    # Create BlueprintGroup Instance
    bpg = BlueprintGroup()

    # Create Blueprint Instance
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    # Append Blueprint Instance to BlueprintGroup
    bpg.append(bp1)
    bpg.append(bp2)

    # Call method __delitem__ of class BlueprintGroup
    del bpg[0]

    # Assert for expected result
    assert bpg[0] == bp2

# Generated at 2022-06-21 22:33:01.930368
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bpg = BlueprintGroup()
    bpg.append(Blueprint('bp1', url_prefix='/bp1'))
    bpg.append(Blueprint('bp2', url_prefix='/bp2'))
    bpg.append(Blueprint('bp3', url_prefix='/bp3'))

    for item in bpg:
        assert item.url_prefix != None


# Generated at 2022-06-21 22:33:08.960267
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    blueprint_group = BlueprintGroup("/a")

    blueprint_1 = Blueprint("b")
    blueprint_2 = Blueprint("c")

    blueprint_group.append(blueprint_1)
    blueprint_group.append(blueprint_2)

    @blueprint_group.middleware("bp_middleware_1")
    async def bp_middleware_1(request):
        pass

    @blueprint_group.middleware("bp_middleware_2")
    async def bp_middleware_2(request):
        pass

    assert len(blueprint_group.blueprints) == 2

    assert "bp_middleware_1" in blueprint_group.blueprints[0].middlewares
    assert blueprint_group.blueprints[0].middlewares["bp_middleware_1"] == bp_middleware_1  #

# Generated at 2022-06-21 22:33:19.776255
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp5.url_prefix = '/test'
    bpg1 = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    assert(bp3.url_prefix == "/api/bp3" and bp4.url_prefix == "/api/bp4" and
           bp4.version == "v1" and bp4.strict_slashes is None)
    bpg2 = Blueprint

# Generated at 2022-06-21 22:33:28.104164
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    # Test for '__delitem__' of class 'BlueprintGroup'
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg._blueprints = [bp1, bp2, bp3, bp4]

    del bpg[1]
    assert len(bpg._blueprints) == 3
    assert bpg._blueprints[0] == bp1
    assert bpg._blueprints[1] == bp3

# Generated at 2022-06-21 22:33:38.615534
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp_grp = BlueprintGroup()
    assert len(bp_grp) == 0

    bp_grp = BlueprintGroup("/api", "v1", True)
    assert len(bp_grp) == 0
    assert bp_grp.url_prefix == "/api"
    assert bp_grp.version == "v1"
    assert bp_grp.strict_slashes is True

    bp_grp1 = BlueprintGroup("/api", "v2")
    bp_grp2 = BlueprintGroup("/api", "v2", True)
    assert len(bp_grp1) == 0
    assert len(bp_grp2) == 0
    assert bp_grp.url_prefix == bp_grp1.url_prefix == bp_grp2.url