

# Generated at 2022-06-21 22:28:53.697364
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    # Example for method __iter__ of class BlueprintGroup
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp3 = Blueprint('bp3', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-21 22:28:57.080893
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2)
    assert len(bpg) == 2


# Generated at 2022-06-21 22:29:02.137088
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bg = BlueprintGroup()
    bg.append(bp1)
    bg.append(bp2)
    bg.append(bp3)
    bg.append(bp4)
    del bg[0]
    assert bg._blueprints == [bp2, bp3, bp4]


# Generated at 2022-06-21 22:29:13.660355
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():

    url_prefix = "/api/v1"
    group_bp1 = Blueprint("group_bp1", url_prefix='/group_bp1')
    group_bp2 = Blueprint("group_bp2", url_prefix='/group_bp2')
    group_bp3 = Blueprint("group_bp3", url_prefix='/group_bp3')
    group_bp4 = Blueprint("group_bp4", url_prefix='/group_bp4')

    group = BlueprintGroup(url_prefix=url_prefix)

    assert len(group) == 0

    assert group_bp1.url_prefix == '/group_bp1'
    assert group_bp2.url_prefix == '/group_bp2'
    assert group_bp3.url_prefix == '/group_bp3'

# Generated at 2022-06-21 22:29:26.192379
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    assert(len(bpg) == 2)
    bpg.insert(1,bp3)
    assert(len(bpg) == 3)
    bpg.insert(4,bp4)
    assert(len(bpg) == 4)

# Generated at 2022-06-21 22:29:36.062241
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    from .blueprint import Blueprint
    from .router import RouteExists
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    bpg[0] = bp1
    
    assert bpg[0] == bp1
    bpg[1] = bp2
    assert bpg[1] == bp2
    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert bpg.blueprints

# Generated at 2022-06-21 22:29:47.328524
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")

    bpg = BlueprintGroup(bp1, bp2, bp3, bp4)

    assert len(bpg) == 4

    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert bpg[2] == bp3
    assert bpg[3] == bp4

    bp_list = [bp1, bp2, bp3, bp4]

    for index, bp in enumerate(bpg):
        assert bp == bp_list

# Generated at 2022-06-21 22:29:54.736981
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    assert bp1.url_prefix == '/api/bp1'
    assert bp2.url_prefix == '/api/bp2'



# Generated at 2022-06-21 22:29:58.938696
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)

    assert len(group) == 2


# Generated at 2022-06-21 22:30:11.331661
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    """
    Test BlueprintGroup insert
    """
    app = sanic.Sanic()

    message = "Hello World"

    @app.route('/')
    async def handler(request):
        return text(message)

    bp1 = Blueprint('bp1', url_prefix='/api/v1')
    bp2 = Blueprint('bp2', url_prefix='/api/v2')
    bp3 = Blueprint('bp3', url_prefix='/api/v3')
    bp4 = Blueprint('bp4', url_prefix='/api/v4')
    bp5 = Blueprint('bp5', url_prefix='/api/v5')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-21 22:30:28.914134
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bpg = BlueprintGroup()
    assert len(bpg) == 0

    # add some blueprints to the BP Group
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")

    bpg.append(bp1)
    assert len(bpg) == 1
    bpg.append(bp2)
    assert len(bpg) == 2
    bpg.append(bp3)
    assert len(bpg) == 3

    # Append some BP Groups
    bpg2 = BlueprintGroup(url_prefix="/bp4")
    bpg2.append(Blueprint("bp4"))
    bpg.append(bpg2)
    assert len(bpg) == 4

    # Will skip

# Generated at 2022-06-21 22:30:42.178626
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    assert bp1.url_prefix == "/bp1"
    assert bp1.version is None
    assert bp1.strict_slashes is None

    bp2 = Blueprint('bp2', url_prefix='/bp2')
    assert bp2.url_prefix == "/bp2"
    assert bp2.version is None
    assert bp2.strict_slashes is None

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    assert bp3.url_prefix == "/bp4"
    assert bp3.version is None
    assert bp3.strict_slashes is None

    bp4 = Blueprint('bp4', url_prefix='/bp4')

# Generated at 2022-06-21 22:30:49.538597
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')

    bp3 = sanic.Blueprint('bp3', url_prefix='/bp4')
    bp4 = sanic.Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp3)
    bpg.append(bp4)

    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)

    assert len(bpg) == 2
    assert len(group) == 2


# Generated at 2022-06-21 22:30:59.918281
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """Test BlueprintGroup and it's method middleware"""
    import pytest

    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bp3 = Blueprint("bp3")

    @bp1.middleware("request")
    async def bp1_middleware(request):
        pass

    @bp2.route("/")
    async def bp2_route(request):
        pass

    @bp3.route("/<param>")
    async def bp3_route(request, param):
        pass

    @bp1.middleware("request")
    async def bp1_middleware(request):
        pass

    @bp2.middleware("request")
    async def bp2_middleware(request):
        pass


# Generated at 2022-06-21 22:31:09.889361
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    # Record of blueprint
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    # Generate blueprint group instance
    bpg = BlueprintGroup()

    # Insert blueprint
    bpg.append(bp1)
    bpg.append(bp2)

    # delete blueprint using index
    bpg.__delitem__(0)

    # Assertion
    assert bpg.__len__() == 1
    assert bpg.__getitem__(0) == bp2


# Generated at 2022-06-21 22:31:17.500346
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    # Initializing object of class BlueprintGroup
    bp = BlueprintGroup()
    # Creating two Blueprints for testing
    b1 = Blueprint('bp1', url_prefix='/bp1')
    b2 = Blueprint('bp2', url_prefix='/bp2')
    # Testing __setitem__ method of class BlueprintGroup
    bp[0] = b1
    bp[1] = b2
    assert bp[0] == b1 and bp[1] == b2


# Generated at 2022-06-21 22:31:20.443748
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    assert BlueprintGroup(url_prefix='/test') == BlueprintGroup(url_prefix='/test')
    # TODO Need more unit test


# Generated at 2022-06-21 22:31:28.886335
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    orig_fn = lambda x: x
    bp = Blueprint('bp')
    bpg = BlueprintGroup()

    bpg.append(bp)
    bpg.middleware(orig_fn)
    assert bp.middleware is not None
    assert bp.middleware[0]["func"] == orig_fn

    bpg.middleware(orig_fn, True)
    assert bp.middleware is not None
    assert bp.middleware[0]["func"] == orig_fn
    assert bp.middleware[0]["args"] == tuple([True])
    assert bp.middleware[0]["kwargs"] == {}

    bpg.middleware(orig_fn, 1, 2, foo=3, bar=4)
    assert bp.middleware is not None

# Generated at 2022-06-21 22:31:36.870964
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    """
    This function performs a basic unit test to create a BlueprintGroup Object
    """
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")

    bp_group = BlueprintGroup(url_prefix="/bp1", version="v1")
    bp_group.append(bp1)
    bp_group.append(bp2)
    assert len(bp_group.blueprints) == 2
    assert bp_group.url_prefix == "/bp1"
    assert bp_group.version == "v1"


# Generated at 2022-06-21 22:31:43.035717
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)

    # Register Blueprint group under the app
    @bpg.middleware('request')
    async def group_middleware(request):
        request['group_middleware_name'] = 'group_middleware_name'

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        request['bp1_only_middleware_name'] = 'bp1_only_middleware_name'


# Generated at 2022-06-21 22:31:54.344777
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    # __setitem__(self, index, item)
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg[0] = bp1
    bpg[1] = bp2

    assert bp1 in bpg._blueprints
    assert bp2 in bpg._blueprints


# Generated at 2022-06-21 22:31:58.557410
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp = BlueprintGroup()
    bp.append(Blueprint("bp_test", url_prefix="bp_test"))
    assert bp.blueprints[0].name == "bp_test"

# Generated at 2022-06-21 22:32:01.630699
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    # Create a Blueprint Group with no blueprints
    bpg = BlueprintGroup()
    # check the __len__ method returns 0
    assert len(bpg) == 0, "Length of Blueprint Group should be 0"


# Generated at 2022-06-21 22:32:07.615558
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2)
    assert len(group) == 2

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    group.append(bp3)
    assert len(group) == 3



# Generated at 2022-06-21 22:32:13.357000
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    blueprint1 = Blueprint('bp1', url_prefix='/bp1')
    blueprint2 = Blueprint('bp2', url_prefix='/bp2')
    blueprint_group = BlueprintGroup()

    blueprint_group.append(blueprint1)
    blueprint_group.append(blueprint2)
    actual_output = blueprint_group[0]
    expected_output = blueprint1

    assert actual_output == expected_output


# Generated at 2022-06-21 22:32:14.774815
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    # Test BlueprintGroup
    bp = Blueprint('bp')
    bg = BlueprintGroup()
    bg.append(bp)

    # Test BlueprintGroup.__getitem__()
    assert bg[0] == bp


# Generated at 2022-06-21 22:32:18.692336
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bp3 = Blueprint('bp3')
    bp4 = Blueprint('bp4')
    bp5 = Blueprint('bp5')
    bpg1 = BlueprintGroup()
    bpg2 = BlueprintGroup()

    @bpg2.middleware('request')
    def bp1_only_middleware():
        return text('applied on Blueprint : bp1 Only')

    @bp1.middleware('request')
    def bp1_only_middleware():
        return text('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-21 22:32:26.938690
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    app = sanic.Sanic(__name__)
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    assert bp3 == bpg[0]
    assert bp4 == bpg[1]

# Generated at 2022-06-21 22:32:33.890651
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group = BlueprintGroup(url_prefix='/api', version='1.0')
    assert blueprint_group.__len__() == 0
    blueprint_group.append(Blueprint('bp1', url_prefix='/bp1'))
    blueprint_group.append(Blueprint('bp2', url_prefix='/bp2'))
    assert blueprint_group.__len__() == 2


# Generated at 2022-06-21 22:32:42.563481
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp_group = BlueprintGroup("/v1")
    bp_group.append(bp1)
    bp_group.append(bp2)
    assert bp_group.version == "v1"
    assert bp_group[0].url_prefix == "/v1/bp1"
    assert bp_group[1].url_prefix == "/v1/bp2"

# Generated at 2022-06-21 22:33:03.945824
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2)

    @bpg.middleware('request')
    async def common_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    assert bp1._middlewares[('request',)] == [common_middleware]
    assert bp2._middlewares[('request',)] == [common_middleware]

# Generated at 2022-06-21 22:33:10.139565
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4)
    assert isinstance(bpg.__iter__(), type(iter(bp1)))

    bpg = BlueprintGroup()
    assert isinstance(bpg.__iter__(), type(iter(bp1)))


# Generated at 2022-06-21 22:33:17.770581
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    @sanic.blueprint(url_prefix='/test_url')
    def blueprint():
        pass
    
    bg = BlueprintGroup()
    bg.append(blueprint)
    assert bg._blueprints[0].url_prefix == '/test_url'
    
    new_blueprint = sanic.blueprint(url_prefix='/new_url')(blueprint)
    bg.insert(0, new_blueprint)
    assert bg._blueprints[0].url_prefix == '/new_url'
    assert bg._blueprints[1].url_prefix == '/test_url'


# Generated at 2022-06-21 22:33:26.253060
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    url_prefix = "/testing"
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp1")
    bp4 = Blueprint("bp4", url_prefix="/bp2")
    bpg = BlueprintGroup(url_prefix=url_prefix)
    
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    assert isinstance(bpg[2], Blueprint)
    
    

# Generated at 2022-06-21 22:33:36.002074
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp = Blueprint("bp", url_prefix="bp")
    bp1 = Blueprint("bp1", url_prefix="bp1")
    bp2 = Blueprint("bp2", url_prefix="bp2")

    bpg = BlueprintGroup(bp, url_prefix="g")
    bpg[1] = bp1
    assert bpg[1].url_prefix == "/g/bp1"

    bpg[1] = bp2
    assert bpg[1].url_prefix == "/g/bp2"
    assert len(bpg) == 2


# Generated at 2022-06-21 22:33:40.618216
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(bp1, bp2)

    assert bpg[0] == bp1
    assert bpg[1] == bp2
    with pytest.raises(IndexError) as e:
        bpg[2]


# Generated at 2022-06-21 22:33:41.535360
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint_group = BlueprintGroup()

# Generated at 2022-06-21 22:33:46.723471
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()

    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bpg) == 2


# Generated at 2022-06-21 22:33:51.918841
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2)
    group.insert(0, bp2)
    assert group.blueprints[0] == bp2
    assert group.blueprints[1] == bp1


# Generated at 2022-06-21 22:33:58.847693
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    url_prefix = "/api"
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bpg = BlueprintGroup(bp1, bp2, url_prefix=url_prefix)

    # Test if we can use the index to fetch the Blueprint under the group
    assert bpg[0].name == bp1.name
    assert bpg[1].name == bp2.name

    # Test the correct Index Error exception is raised
    with pytest.raises(IndexError):
        bpg[2]

    # Test if we can use the slice operator to fetch multiple Blueprints
    assert len(bpg[0:1]) == 1
    assert len(bpg[0:2]) == 2

# Generated at 2022-06-21 22:34:28.711496
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix='/api', version='v1')
    bpg.append(bp1)
    bpg.append(bp2)

    assert isinstance(bpg[0], Blueprint)
    assert isinstance(bpg[1], Blueprint)
    assert bpg[0] == bp1
    assert bpg[1] == bp2


# Generated at 2022-06-21 22:34:37.020352
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    app = Sanic('test_BlueprintGroup_append')

    @app.route('/')
    async def index(request):
        return text('Hello World!')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)


# Generated at 2022-06-21 22:34:46.152803
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    """
    Unit test to assert the functioning of the method insert of
    class BlueprintGroup
    """
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bp3 = sanic.Blueprint('bp3', url_prefix='/bp3')

    bpg = BlueprintGroup()

    bpg.append(bp1)
    bpg.append(bp2)
    bpg.insert(1, bp3)

    assert bpg[0] == bp1
    assert bpg[1] == bp3
    assert bpg[2] == bp2

    assert bpg.blueprints == [bp1, bp3, bp2]

    assert bpg[0].url

# Generated at 2022-06-21 22:34:51.036183
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    assert bpg[0] == bp1
    assert bpg[1] == bp2


# Generated at 2022-06-21 22:35:00.359295
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    """
    To test the `__getitem__` method of class `BlueprintGroup`
    """
    bp1 = sanic.Blueprint('bp1', url_prefix='/bpg1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bpg2')
    bp3 = sanic.Blueprint('bp3', url_prefix='/bpg3')
    bp4 = sanic.Blueprint('bp4', url_prefix='/bpg4')
    bpg = BlueprintGroup(url_prefix="/api")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    assert bpg[0] == bp1

# Generated at 2022-06-21 22:35:07.402376
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = sanic.Blueprint("bp1", url_prefix="/bp1")
    bp2 = sanic.Blueprint("bp2", url_prefix="/bp2")
    bg = BlueprintGroup("/api", "v1")
    assert bg._url_prefix == "/api"
    assert bg._version == "v1"
    bg.append(bp1)
    assert isinstance(bg[0], sanic.Blueprint)
    assert bg[0] is bp1
    assert len(bg) == 1
    bg.insert(0, bp2)
    assert isinstance(bg[0], sanic.Blueprint)
    assert bg[0] is bp2
    assert isinstance(bg[1], sanic.Blueprint)
    assert bg[1] is bp1

# Generated at 2022-06-21 22:35:16.938997
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bpg) == 2


# Generated at 2022-06-21 22:35:27.259855
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup()

    assert 0 == len(bpg)

    bpg.append(bp1)
    assert 1 == len(bpg)

    bpg.append(bp2)
    assert 2 == len(bpg)

    bpg.append(bp3)
    assert 3 == len(bpg)

    bpg.append(bp4)
    assert 4 == len(bpg)

    del bpg[3]
    assert 3 == len(bpg)


# Generated at 2022-06-21 22:35:30.277415
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2)

    assert(len(group) is 2)


# Generated at 2022-06-21 22:35:37.257359
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Test Method middleware of class Blueprint
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')

    group = Blueprint.group(bp1, bp2)

    middleware_called_times = 0

    @group.middleware('request')
    async def group_middleware(request):
        nonlocal middleware_called_times
        middleware_called_times += 1

    # Register Blueprint group under the app
    app = sanic.Sanic()
    app.blueprint(group)



# Generated at 2022-06-21 22:36:34.807617
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    """
    Unit test for method __iter__ of class BlueprintGroup
    """
    result = iter(BlueprintGroup())
    assert isinstance(result, collections.abc.Iterator)



# Generated at 2022-06-21 22:36:42.076747
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    import sanic
    from sanic.testing import HOST, PORT
    from sanic.log import logger

    logger.level = "DEBUG"

    bp1 = sanic.Blueprint("bp1", url_prefix="/bp1")
    bp2 = sanic.Blueprint("bp2", url_prefix="/bp2")

    bp3 = sanic.Blueprint("bp3", url_prefix="/bp3")
    bp4 = sanic.Blueprint("bp4", url_prefix="/bp4")

    bpg = BlueprintGroup(url_prefix="/api", version="v2", strict_slashes=True)
    bpg.insert(0, bp1)

    @bp1.route("/bp1")
    def bp1_route(request):
        return text("bp1")


# Generated at 2022-06-21 22:36:45.376488
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    assert bpg._blueprints == [bp1]
    bpg.append(bp2)
    assert bpg._blueprints == [bp1, bp2]


# Generated at 2022-06-21 22:36:49.702299
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    blueprint1 = Blueprint('blueprint1')
    blueprint2 = Blueprint('blueprint2')

    bp_group = BlueprintGroup()
    bp_group.append(blueprint1)
    bp_group.append(blueprint2)

    assert bp_group[0] == blueprint1
    assert bp_group[1] == blueprint2


# Generated at 2022-06-21 22:37:00.091478
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    # create blueprint group
    bpg = BlueprintGroup("/api", version="v1")
    assert bpg is not None
    assert bpg.url_prefix == "/api"
    assert bpg.version == "v1"
    assert bpg.blueprints is not None
    assert len(bpg.blueprints) == 0

    # create blueprint group
    bpg = BlueprintGroup("/api/v1")
    assert bpg is not None
    assert bpg.url_prefix == "/api/v1"
    assert bpg.version is None
    assert bpg.blueprints is not None
    assert len(bpg.blueprints) == 0

    # create blueprint group
    bpg = BlueprintGroup("/api/v1", strict_slashes=True)
    assert bpg is not None
    assert bpg.url_prefix

# Generated at 2022-06-21 22:37:05.583378
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    assert len([bp for bp in bpg]) == 2
    bpg.append(bp2)
    assert len([bp for bp in bpg]) == 3

# Generated at 2022-06-21 22:37:09.643970
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bg = BlueprintGroup(url_prefix="/api/v1")
    bp1 = Blueprint("bp1, url_prefix='/bp1'")
    bp2 = Blueprint("bp2, url_prefix='/bp2'")
    bg.append(bp1)
    bg.append(bp2)
    bg[0] = bp1
    assert bg[0] == bp1


# Generated at 2022-06-21 22:37:11.044429
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bpg = BlueprintGroup()
    bpg.insert(0, "test")
    assert bpg._blueprints == ["test"]


# Generated at 2022-06-21 22:37:19.330383
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    """
    Test for Blueprint Group append method implementation
    :return: None
    """
    bp1 = Blueprint("bp1", url_prefix="/test")
    bp2 = Blueprint("bp2", url_prefix="/test")
    bp3 = Blueprint("bp3", url_prefix="/test")
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    # Asserting if all of the blueprints have been appended to the group
    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert bpg[2] == bp3



# Generated at 2022-06-21 22:37:26.322632
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = sanic.Blueprint("bp1")
    bp2 = sanic.Blueprint("bp2")
    bp3 = BlueprintGroup("bpg")
    bp3.append(bp1)
    bp3.append(bp2)
    @bp3.middleware("request")
    async def middleware(request):
        pass
    assert len(bp1._middleware["request"]) == 1
    assert len(bp2._middleware["request"]) == 1


# Generated at 2022-06-21 22:38:40.150010
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    from sanic import Blueprint
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    group = Blueprint.group(bp1, bp2)
    assert (group[0] == bp1)
    assert (group[1] == bp2)
    assert (bpg[0] == bp3)
    assert (bpg[1] == bp4)
