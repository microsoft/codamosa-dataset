

# Generated at 2022-06-21 22:28:51.553389
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    # Arrange
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    blueprintGroup = Blueprint.group(bp1, bp2)

    # Act
    blueprintGroup.__delitem__(0)

    # Assert
    assert blueprintGroup._blueprints == [bp2]


# Generated at 2022-06-21 22:28:57.356657
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    # Blueprint group object
    test_group = BlueprintGroup(url_prefix="/api")
    # list of blueprints
    bp_list = [Blueprint("bp1", url_prefix="/bp1"), Blueprint("bp2", url_prefix="/bp2")]
    # iterate through list and append the blueprints to the group object
    for bp in bp_list:
        test_group.append(bp)
    # assert if the list and the group are equal
    assert test_group.blueprints == bp_list


# Generated at 2022-06-21 22:29:09.068877
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    BlueprintGroup._blueprints = []
    BlueprintGroup._url_prefix = "test_url_prefix"
    BlueprintGroup._version = "test_version"
    BlueprintGroup._strict_slashes = "test_strict_slashes"
    blueprint = Blueprint('test_name', url_prefix='test_url_prefix')
    blueprint_group = BlueprintGroup('test_url_prefix', 'test_version', 'test_strict_slashes')
    blueprint_group.insert(0, blueprint)
    assert blueprint_group._blueprints[0].url_prefix == 'test_url_prefix'
    assert blueprint_group._blueprints[0].version == 'test_version'
    assert blueprint_group._blueprints[0].strict_slashes == 'test_strict_slashes'
    assert blueprint_group._blueprints[0].name

# Generated at 2022-06-21 22:29:13.659032
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    for bp in bpg:
        print(bp)


# Generated at 2022-06-21 22:29:20.491508
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    def middleware_function(request):
        pass
    app = sanic.Sanic()
    bp1 = Blueprint('bp1', url_prefix='/api')
    bp2 = Blueprint('bp2', url_prefix='/api')

    bp_group = BlueprintGroup(url_prefix='/api')
    bp_group.append(bp1)
    bp_group.append(bp2)

    bp_group.middleware(middleware_function)

    assert middleware_function in bp1.registered_middleware
    assert middleware_function in bp2.registered_middleware

# Generated at 2022-06-21 22:29:23.667970
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprints_group = BlueprintGroup()
    blueprint = Blueprint('bp1', url_prefix='/bp1')
    blueprints_group.append(blueprint)
    del blueprints_group[0]



# Generated at 2022-06-21 22:29:27.045172
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_group = BlueprintGroup()
    blueprint = Blueprint("test_blueprint_group")
    blueprint_group.append(blueprint)
    assert blueprint_group.__getitem__(0) == blueprint


# Generated at 2022-06-21 22:29:36.103351
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp3)
    bpg.append(bp4)
    assert(len(bpg) ==2)
    bpg[1] = bp2
    assert(len(bpg) ==2)
    assert(bpg[1].url_prefix == bp2.url_prefix)


# Generated at 2022-06-21 22:29:38.718601
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    # TODO: implement test_BlueprintGroup___getitem__
    assert True # TODO: may be replace or remove this line

# Generated at 2022-06-21 22:29:48.965177
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    from sanic.blueprints import Blueprint
    import sanic

    bp1 = Blueprint('bp1', url_prefix='/bp1', version="v1")
    bp2 = Blueprint('bp2', url_prefix='/bp2', version="v2")
    bp3 = Blueprint('bp3', url_prefix='/bp3', version="v3")
    bp4 = Blueprint('bp4', url_prefix='/bp4', version="v4")

    group = BlueprintGroup(url_prefix='/bp_group', version="v0")

    group.append(bp1)
    group.append(bp2)
    group.append(bp3)
    group.append(bp4)

    app = sanic.Sanic()

    app.blueprint(group)


# Generated at 2022-06-21 22:29:58.323182
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp_group = BlueprintGroup()
    bp_group.append(bp1)
    bp_group.append(bp2)
    assert bp1 == bp_group[0] and bp2 == bp_group[1]


# Generated at 2022-06-21 22:30:04.753319
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    url_prefix = "/api"
    version = "v1"

    bp = BlueprintGroup(
        url_prefix=url_prefix,
        version=version,
        strict_slashes=False
    )
    assert bp._url_prefix == url_prefix
    assert bp._version == version
    assert not bp._strict_slashes



# Generated at 2022-06-21 22:30:06.541170
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    print("TestBlueprintGroup append = "+BlueprintGroup().append("BlueprintGroup"))


# Generated at 2022-06-21 22:30:17.932646
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    assert bpg.url_prefix == "/api"
    assert bpg.version == "v1"

    # Group Addition
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.insert(0, bp1)
    bpg.insert(0, bp2)

    assert len(bpg) == 6



# Generated at 2022-06-21 22:30:29.930113
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    """
    Test the instanciation of Blueprint Group class.
    """
    bpg = BlueprintGroup("/api", version="v1")
    assert bpg.blueprints == []
    assert bpg.url_prefix == "/api"
    assert bpg.version == "v1"
    assert bpg.strict_slashes is None


bp1 = Blueprint("bp1", url_prefix="/bp1")
bp2 = Blueprint("bp2", url_prefix="/bp2")


@bp1.middleware("request")
async def bp1_only_middleware(request: "sanic.request.Request") -> None:
    """
    Test method to implement a middleware on the blueprint
    """
    print("applied on Blueprint : bp1 Only")



# Generated at 2022-06-21 22:30:41.236981
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup()
    bpg.append(bp3)
    bpg.append(bp4)
    assert bpg.blueprints == [bp3, bp4]
    bpg.__delitem__(1)
    assert bpg.blueprints == [bp3]
    bpg.__delitem__(0)
    assert bpg.blueprints == []

# Generated at 2022-06-21 22:30:46.408417
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    """
    Unit test for method __delitem__ of class BlueprintGroup
    """
    bp_group = BlueprintGroup()
    blueprint = Blueprint('bpg', url_prefix='/bp1')
    bp_group.append(blueprint)
    assert blueprint in bp_group.blueprints
    del bp_group[0]
    assert blueprint not in bp_group.blueprints


# Generated at 2022-06-21 22:30:57.675120
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():

    # Testing the insert method and the implementation of exception handling

    # Initializing the BlueprintGroup object with the mock URL prefix and version
    blue_p = BlueprintGroup(url_prefix = "/api", version = "2")

    # Initializing the mock Blueprint object
    bp = Blueprint('bp1', url_prefix='/bp1')

    # Assert the initial length of the blue_p object
    assert len(blue_p) == 0
    assert blue_p.url_prefix == '/api'
    assert blue_p.version == '2'
    assert blue_p.blueprints == []


    # Testing the insert method
    blue_p.insert(0, bp)

    # Assert the new length of the blue_p object
    assert len(blue_p) == 1

    # Assert the modified uri of the blueprint object
   

# Generated at 2022-06-21 22:31:00.320062
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    group = BlueprintGroup(url_prefix="/api")
    group.append(Blueprint("bp1"))
    group.append(Blueprint("bp2"))
    assert len(group) == 2



# Generated at 2022-06-21 22:31:09.076021
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
  from unittest.mock import MagicMock
  bg = BlueprintGroup()
  bp1 = MagicMock(name='bp1', spec=sanic.Blueprint)
  bp2 = MagicMock(name='bp2', spec=sanic.Blueprint)
  bg.append(bp1)
  bg.append(bp2)
  del bg[0]
  assert bg._blueprints.pop() == bp2
  assert len(bg._blueprints) == 0

# Generated at 2022-06-21 22:31:21.872670
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp1")

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    assert bp1 == bpg[0]
    assert bp2 == bpg[1]
    assert bp1 == bpg[-2]
    assert bp2 == bpg[-1]



# Generated at 2022-06-21 22:31:29.055425
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')

    bp3 = sanic.Blueprint('bp3', url_prefix='/bp3')
    bp4 = sanic.Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup()
    bpg._blueprints = [bp1, bp2, bp3, bp4]

    assert len(bpg) == 4, 'length of bpg should be 4'
    for bp in bpg:
        assert isinstance(bp, sanic.Blueprint)


# Generated at 2022-06-21 22:31:35.469908
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint("bp1")

    bpg = BlueprintGroup()

    assert len(bpg) == 0

    bpg.append(bp1)

    assert len(bpg) == 1

    bp2 = Blueprint("bp2")

    bpg[0] = bp2

    assert len(bpg) == 1
    assert bp1 not in bpg.blueprints
    assert bp2 in bpg.blueprints


# Generated at 2022-06-21 22:31:40.823929
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    bpg.__delitem__(0)
    assert bpg.blueprints == [bp2]

# Generated at 2022-06-21 22:31:52.055915
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    '''
    Test that middleware is added to blueprints in the group
    '''
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    bpg.middleware(None)
    assert len(bp1.middlewares['request']) == 1
    assert len(bp2.middlewares['request']) == 1

# Generated at 2022-06-21 22:32:03.911346
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    print("Testing test_BlueprintGroup___iter__")
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bp3 = Blueprint("bp3")
    bp4 = Blueprint("bp4")
    bp5 = Blueprint("bp5")
    bp6 = Blueprint("bp6")
    bp7 = Blueprint("bp7")
    bp8 = Blueprint("bp8")
    bp9 = Blueprint("bp9")
    bp10 = Blueprint("bp10")
    bp11 = Blueprint("bp11")
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    bpg.append(bp5)

# Generated at 2022-06-21 22:32:08.050708
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2)
    assert bp1 == bpg[0]
    assert bp2 == bpg[1]


# Generated at 2022-06-21 22:32:17.309372
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    # Setup
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup('/api', 'v1')
    bpg.append(bp1)
    bpg.append(bp2)

    # Exercise
    bpg.__setitem__(1,bp3)

    # Verify
    assert bpg[0].name == 'bp1'
    assert bpg[1].name == 'bp3'
    assert bpg[2].name == 'bp2'
    assert len(bpg) == 3


# Generated at 2022-06-21 22:32:24.804373
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()

    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg.__getitem__(0) == bp1
    assert bpg.__getitem__(1) == bp2


# Generated at 2022-06-21 22:32:31.722518
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp_gp = BlueprintGroup('/test/group', 'v1')
    assert bp_gp.url_prefix == '/test/group'
    assert bp_gp.version == 'v1'
    assert bp_gp.strict_slashes is None
    assert bp_gp.blueprints == []

    bp_gp = BlueprintGroup('/test/group', 'v2', True)
    assert bp_gp.url_prefix == '/test/group'
    assert bp_gp.version == 'v2'
    assert bp_gp.strict_slashes is True
    assert bp_gp.blueprints == []


# Test units for the append method.

# Generated at 2022-06-21 22:32:53.891082
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    """
    This unit test validates the implementation of the insert method
    """
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")

    group = BlueprintGroup(url_prefix="/api", version="v1")
    group.append(bp1)
    group.append(bp2)

    # Inserting Item at the end should change the length of the list
    len_of_blueprints = len(group)
    group.insert(len_of_blueprints, bp3)
    assert len(group) == len_of_blueprints + 1

    # Validate that newly inserted item is at

# Generated at 2022-06-21 22:33:06.229445
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bg = BlueprintGroup()
    bg.append(bp1)
    bg.append(bp2)
    bg.append(bp3)
    bg.append(bp4)
    
    assert len(bg) == 4

    bg = BlueprintGroup(url_prefix='/foo')
    bg.append(bp1)
    bg.append(bp2)
    bg.append(bp3)
    bg.append(bp4)
    

# Generated at 2022-06-21 22:33:12.529180
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup()
    bpg[2] = bp3
    bpg.append(bp4)
    bpg[0] = bp1
    bpg.insert(1, bp2)
    assert bpg[0].name == 'bp1'
    assert bpg[1].name == 'bp2'
    assert bpg[2].name == 'bp3'
    assert bpg[3].name == 'bp4'


# Generated at 2022-06-21 22:33:22.932287
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')
    bp7 = Blueprint('bp7', url_prefix='/bp7')
    bp8 = Blueprint('bp8', url_prefix='/bp8')
    bp9 = Blueprint('bp9', url_prefix='/bp9')
    bp10 = Blueprint('bp10', url_prefix='/bp10')

# Generated at 2022-06-21 22:33:25.057704
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp = BlueprintGroup()
    bp.append(Blueprint("testBp"))
    assert len(bp) == 1


# Generated at 2022-06-21 22:33:30.633722
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp3)
    bpg.append(bp4)
    for i in bpg:
        assert isinstance(i, Blueprint)
    assert bpg[0] == bp3
    assert bpg[1] == bp4
    assert bpg[-1] == bp4



# Generated at 2022-06-21 22:33:37.926466
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp3)
    bpg[0] = bp4

    assert bpg.blueprints[0] == bp4



# Generated at 2022-06-21 22:33:42.856681
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    assert BlueprintGroup() is not None
    bpg = BlueprintGroup("/api", "v1", True)
    assert bpg.url_prefix == "/api"
    assert bpg.version == "v1"
    assert bpg.strict_slashes is True
    assert len(bpg) == 0
    assert bpg.blueprints == []



# Generated at 2022-06-21 22:33:51.407943
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()

    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bpg) == 2
    assert bp1 in bpg
    assert bp2 in bpg

    del bpg[0]
    del bpg[-1]

    assert len(bpg) == 0
    assert bp1 not in bpg
    assert bp2 not in bpg


# Generated at 2022-06-21 22:33:56.717887
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.extend([bp1, bp2])
    bpg_it = iter(bpg)
    assert next(bpg_it) == bp1, f"Got {bp1}, expected {bp1}"
    assert next(bpg_it) == bp2, f"Got {bp2}, expected {bp2}"


# Generated at 2022-06-21 22:34:19.595500
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp3 = Blueprint('bp3', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    assert(bp1 == bpg[0])
    assert(bp2 == bpg[1])
    assert(bp3 == bpg[2])
    assert(bp4 == bpg[3])


# Generated at 2022-06-21 22:34:26.747299
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprints = []
    blueprints.append(Blueprint('bp1', url_prefix='/bp1'))
    blueprints.append(Blueprint('bp2', url_prefix='/bp2'))

    bpg = BlueprintGroup()
    bpg._blueprints = blueprints

    assert bpg[0] == blueprints[0]
    assert bpg[1] == blueprints[1]
    assert bpg[-1] == blueprints[-1]


# Generated at 2022-06-21 22:34:32.734528
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(bp1, bp2)

    assert bp1 in bpg
    assert bp2 in bpg
    assert len(bpg) == 2

    del bpg[1]

    assert bp1 in bpg
    assert bp2 not in bpg
    assert len(bpg) == 1


# Generated at 2022-06-21 22:34:35.768580
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg[0] = bp1 # this line should not raise an exception


# Generated at 2022-06-21 22:34:45.642583
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-21 22:34:53.846208
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.insert(0, bp1)
    bpg.insert(1, bp2)
    assert bp1 == bpg[0]
    assert bp2 == bpg[1]
    assert bp1.url_prefix == bp2.url_prefix == "/bp1"
    assert None == bpg.version 
    assert bpg.strict_slashes == None


# Generated at 2022-06-21 22:35:01.109008
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix='/api')
    assert len(bpg) == 0
    bpg.append(bp1)
    assert len(bpg) == 1
    bpg.insert(0, bp2)
    assert len(bpg) == 2
    del bpg[0]
    assert len(bpg) == 1


# Generated at 2022-06-21 22:35:06.475391
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")

    # Create a blueprint group with the above blueprints
    group = BlueprintGroup(bp3, bp4)

    # Check if the blueprint group __getitem__ method is working as expected
    assert group[0] == bp3
    assert group[1] == bp4


# Generated at 2022-06-21 22:35:19.241867
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    """
    Perform unit test for instantiating the Blueprint Group
    """
    
    bpg = BlueprintGroup()
    assert bpg.url_prefix is None
    assert bpg.blueprints == []
    assert bpg.version is None
    assert bpg.strict_slashes is None
    assert bpg.middleware is None

    bpg = BlueprintGroup(url_prefix=1234, version=2.3)
    assert bpg.url_prefix == "1234"
    assert bpg.version == 2.3

    # Test adding blueprints to the group
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg.blueprints) == 2

    # Test the internal middleware for

# Generated at 2022-06-21 22:35:23.598816
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    from test_unit_blueprints_group import BlueprintGroup
    bg = BlueprintGroup()
    bp = sanic.Blueprint("bp")
    assert len(bg) == 0
    bg.insert(0, bp)
    assert len(bg) == 1