

# Generated at 2022-06-21 22:28:53.543929
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp3 = Blueprint('bp3', url_prefix='/bp4')

    group = BlueprintGroup(url_prefix="/api", version="v1")
    group.append(bp1)
    group.append(bp2)
    
    assert group[0] == bp1
    assert group[1] == bp2


# Generated at 2022-06-21 22:29:01.182977
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    app = sanic.Sanic('test_BlueprintGroup_insert')
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    assert len(bpg) == 0
    bpg.append(bp1)
    assert len(bpg) == 1
    bpg.insert(0, bp2)
    assert len(bpg) == 2
    assert bpg[0] == bp2
    bpg.insert(1, bp3)
    assert len(bpg) == 3
    assert bpg[1] == bp3

# Generated at 2022-06-21 22:29:11.963422
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic.app import Sanic
    app = Sanic(__name__)

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    @bp3.route('/')
    async def bp1_route(request):
        return text('bp1')

    bp_group = BlueprintGroup(bp1, bp2)


# Generated at 2022-06-21 22:29:20.248574
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bpg = BlueprintGroup()
    assert bpg.url_prefix is None
    assert bpg.version is None
    assert bpg.strict_slashes is None
    assert len(bpg) == 0
    assert bpg.blueprints == []
    with pytest.raises(IndexError):
        bpg[0]

# Unit test to test the append operation on a Blueprint group

# Generated at 2022-06-21 22:29:23.412707
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    assert len(BlueprintGroup()) == 0
    bg = BlueprintGroup()
    bg.append(Blueprint("a", url_prefix="/"))
    assert len(bg) == 1


# Generated at 2022-06-21 22:29:28.395415
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bp3 = Blueprint('bp3')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    assert len(bpg) == 3

# Generated at 2022-06-21 22:29:35.886848
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    assert(bpg[0] == bp1)
    assert(bpg[1] == bp2)

    bp2_new = Blueprint('bp2', url_prefix='/bp2')
    bpg[0] = bp2_new
    assert(bpg[0] == bp2_new)


# Generated at 2022-06-21 22:29:42.607924
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    # Create a new Blueprint Group
    bpg = BlueprintGroup()
    # Create a blueprint and append to blueprint group
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg.append(bp1)
    bpg.append(bp2)
    # Assert Length of blueprint group
    assert len(bpg) == 2


# Generated at 2022-06-21 22:29:51.580667
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__(): 
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()

    assert len(bpg) is 0
    bpg._blueprints.append(bp1)
    assert len(bpg) is 1
    bpg._blueprints.append(bp2)
    assert len(bpg) is 2

    bpg[0] = bp1
    assert len(bpg) is 2
    bpg[1] = bp1
    assert len(bpg) is 2
    bpg[2] = bp2
    assert len(bpg) is 3
    bpg[3] = bp2
    assert len(bpg) is 4
    bpg[0] = bp2
   

# Generated at 2022-06-21 22:30:04.279776
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    assert bpg._blueprints == []
    assert bpg._url_prefix == None
    assert bpg._version == None
    assert bpg._strict_slashes == None
    assert bpg.append(bp1) == None
    assert bpg.append(bp2) == None
    assert len(bpg) == 2
    bpg.append(bp1)
    bpg.append(bp2)
    assert bpg.blueprints == [bp1,bp2]
    bpg.insert(0, bp1)
    assert bpg.version == None 
    assert bpg.strict_slashes == None

# Generated at 2022-06-21 22:30:24.742006
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    # Insert
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp_group = BlueprintGroup()
    bp_group.insert(0, bp1)
    bp_group.append(bp2)

    assert len(bp_group) == 2
    assert isinstance(bp_group, MutableSequence)
    assert isinstance(bp_group, BlueprintGroup)
    assert bp_group[0] == bp1
    assert bp_group[1] == bp2


# Generated at 2022-06-21 22:30:30.960242
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    '''
    This function will test the method __delitem__ of the BlueprintGroup class
    '''
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)
    assert len(group) == 2
    del group[0]
    assert len(group) == 1


# Generated at 2022-06-21 22:30:39.165292
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2)

    new_bp = Blueprint('bp3', url_prefix='/bp3')

    group.insert(0, new_bp)

    assert new_bp in group.blueprints
    assert new_bp.url_prefix == '/bp3'


# Generated at 2022-06-21 22:30:43.581969
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1', version='v1')
    bp2 = Blueprint('bp2', url_prefix='/bp2', version='v2')
    bpg = Blueprint.group(bp1, bp2)
    assert len(bpg) == 2



# Generated at 2022-06-21 22:30:50.522045
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    class test_BlueprintGroup___len__():
        def __init__():
            class test_Blueprint:
                def __init__():
                    print("Init")
            self.common_blueprint = test_Blueprint()
            # Blueprint Group with no Blueprints
            self.BlueprintGroup_no_blueprints = BlueprintGroup()
            # Blueprint Group with single blueprint
            self.BlueprintGroup_single_blueprint = BlueprintGroup(self.common_blueprint)
            # Blueprint Group with multiple blueprints
            self.BlueprintGroup_multiple_blueprints = BlueprintGroup(self.common_blueprint, self.common_blueprint, self.common_blueprint)
            self.expected_len_no_blueprints = 0
            self.expected_len_single_blueprint = 1
            self.expected_len_multiple_blueprints = 3
       

# Generated at 2022-06-21 22:31:00.216245
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Fix for pytest-sanic to not throw an error due to unexpected arguments
    # https://github.com/channelcat/sanic/pull/1635
    from sanic.blueprints import Blueprint
    app = sanic.Sanic("test_BlueprintGroup_middleware")
    bp1 = Blueprint("bp1", url_prefix="/")
    bp2 = Blueprint("bp2", url_prefix="/")
    bpg = BlueprintGroup(url_prefix="/api")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.middleware(bp1_only_middleware, 'request')
    bpg.middleware(group_middleware, 'request')

    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')


# Generated at 2022-06-21 22:31:09.020253
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    a = BlueprintGroup()
    b = Blueprint('test', url_prefix='/test')
    b.route('list')(lambda x: x)
    a.append(b)
    assert a[0] == b
    a[0] = b
    assert a[0] == b
    b1 = Blueprint('1', url_prefix='/1')
    b1.route('list')(lambda x: x)
    a[0] = b1
    assert a[0] == b1

# Generated at 2022-06-21 22:31:16.569086
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    bpg = BlueprintGroup(url_prefix="/api", strict_slashes=False)
    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bpg) == 2
    assert bpg._blueprints[0] is bp1
    assert bpg._blueprints[1] is bp2



# Generated at 2022-06-21 22:31:22.498160
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert bpg[0] == bp1
    assert bpg[1] == bp2



# Generated at 2022-06-21 22:31:26.828367
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    from sanic import Blueprint
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bg = BlueprintGroup(bp1, bp2)
    bg.__delitem__(0)
    assert bg[0] == bp2
    assert len(bg) == 1

# Generated at 2022-06-21 22:31:41.255383
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group = BlueprintGroup()
    blueprint1 = Blueprint('bp1', url_prefix='/bp1')
    blueprint2 = Blueprint('bp2', url_prefix='/bp2')
    blueprint3 = Blueprint('bp3', url_prefix='/bp3')
    blueprint_group.append(blueprint1)
    blueprint_group.append(blueprint2)
    blueprint_group.append(blueprint3)
    i = 0
    for _ in blueprint_group:
        i += 1
    assert i == 3


# Generated at 2022-06-21 22:31:46.287871
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    """
    Test the `BlueprintGroup` constructor
    """
    group = BlueprintGroup("/bp1", version=1, strict_slashes=True)
    assert group.url_prefix == "/bp1"
    assert group.version == 1
    assert group.strict_slashes is True



# Generated at 2022-06-21 22:31:53.065111
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1', version='v1')
    bp2 = Blueprint('bp2', url_prefix='/bp2', version='v2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bpg) == 2

    del bpg[0]

    assert len(bpg) == 1
    assert bpg[0] is bp2


# Generated at 2022-06-21 22:32:02.713002
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    group = Blueprint.group(bp1, bp2)
    assert group[0] == bp1
    assert group[0] == bp2


# Generated at 2022-06-21 22:32:10.517476
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    app = sanic.Sanic('test_BlueprintGroup___getitem__')
    bp1 = sanic.Blueprint('test_BlueprintGroup___getitem___bp1')
    bp2 = sanic.Blueprint('test_BlueprintGroup___getitem___bp2')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg[0].__class__.__name__ == 'Blueprint'
    assert bpg[-1].__class__.__name__ == 'Blueprint'
    assert bpg[0].name == 'test_BlueprintGroup___getitem___bp1'
    assert bpg[-1].name == 'test_BlueprintGroup___getitem___bp2'


# Generated at 2022-06-21 22:32:14.921822
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint = Blueprint('bp_group_bp')
    blueprint.route('/')(lambda x: x)
    blueprint_group = BlueprintGroup()
    blueprint_group.append(blueprint)
    assert iter(blueprint_group) == iter(blueprint_group.blueprints)


# Generated at 2022-06-21 22:32:21.211978
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    assert bpg[0] == None
    assert bpg[1] == None
    assert bpg[2] == None
    assert bpg[3] == None
    bpg.append(bp1)
    bpg.append(bp2)
    bpg[0] == bp1
    bpg[1] == bp2
    bpg[2] == None
    bpg[3] == None

# Unit test

# Generated at 2022-06-21 22:32:29.677804
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")

    bpg = BlueprintGroup("/group1")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)

    assert bpg._blueprints[1] == bp2

    bpg._blueprints[1] = bp1

    assert bpg._blueprints[1] == bp1

    with pytest.raises(IndexError):
        bpg._blueprints[4] = bp1

# Generated at 2022-06-21 22:32:33.133030
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    group = BlueprintGroup()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    group[0] = bp1
    assert group[0] == bp1



# Generated at 2022-06-21 22:32:40.078370
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bps = [bp1, bp2, bp3]
    bpg = BlueprintGroup(url_prefix='/api')
    bps.extend(bpg)
    assert len(bpg) == len(bps)
    bpg[2] = bp4
    assert len(bpg) == len(bps)
    assert len(bpg) == 3
    assert bpg[2] == bp4
    assert bpg[1] == bp2

# Generated at 2022-06-21 22:33:02.976978
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    assert bpg.url_prefix is None
    assert bpg.version is None
    assert bpg[0] is bp1
    bpg.insert(0, bp2)
    assert bpg[0] is bp2
    assert bpg[1] is bp1


# Generated at 2022-06-21 22:33:12.319854
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    app = sanic.Sanic('test_BlueprintGroup_append')
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpGroup = BlueprintGroup(url_prefix='/api', version='v1')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    bpGroup.append(bp1)
    bpGroup.append(bp2)

    app.blueprint(bpGroup)
    request, response = app.test_client.get('/api/v1/bp1')
    assert response

# Generated at 2022-06-21 22:33:13.205833
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    assert BlueprintGroup



# Generated at 2022-06-21 22:33:15.948174
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprints = [Blueprint("abc"), Blueprint("pqr"), Blueprint("xyz")]
    group = BlueprintGroup()
    group._blueprints = blueprints
    assert len(group) == 3


# Generated at 2022-06-21 22:33:26.357366
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    bpg_deep = BlueprintGroup(bp5, bpg, bp6, url_prefix="/api", version="v1")
    bpg_2 = BlueprintGroup(bp1, bp2)

    assert bpg_deep[0].url_

# Generated at 2022-06-21 22:33:28.545012
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint("bp1")
    bpg = BlueprintGroup("bpg")
    bpg.append(bp1)
    assert bpg[0] == bp1
    assert len(bpg) == 1


# Generated at 2022-06-21 22:33:37.836719
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    """
    Test Case to test the append function of class BlueprintGroup.
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup('/api', version='v1')
    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bpg) == 2
    assert bp1.url_prefix == '/api/bp1'
    assert bp2.url_prefix == '/api/bp2'

    assert bp1.version == 'v1'
    assert bp2.version == 'v1'


# Generated at 2022-06-21 22:33:48.774919
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint_group = BlueprintGroup('/api/v1/')
    assert blueprint_group.url_prefix == '/api/v1/'
    assert blueprint_group.version is None
    assert blueprint_group.strict_slashes is None
    assert blueprint_group.blueprints == []

    blueprint_group = BlueprintGroup('/api/v1/', version='v2')
    assert blueprint_group.url_prefix == '/api/v1/'
    assert blueprint_group.version == 'v2'
    assert blueprint_group.strict_slashes is None
    assert blueprint_group.blueprints == []

    blueprint_group = BlueprintGroup('/api/v1/', version='v2', strict_slashes=False)
    assert blueprint_group.url_prefix == '/api/v1/'
    assert blueprint_group.version

# Generated at 2022-06-21 22:33:56.220657
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert bpg[2] == bp3
    assert bpg[3] == bp4


# Generated at 2022-06-21 22:34:08.299208
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint("bp1", url_prefix="/bp1", strict_slashes=True)
    bp2 = Blueprint("bp2", url_prefix="/bp2", version="v1")
    bp3 = Blueprint("bp3", url_prefix="/bp3", strict_slashes=True)
    bp4 = Blueprint("bp4", url_prefix="/bp4", version="v1")

    group = Blueprint.group(bp1, bp2, url_prefix="/api", version="v2")
    group.append(bp3)
    group.insert(0, bp4)
    assert group.url_prefix == "/api"
    assert len(group) == 3
    assert [b.version for b in group] == ["v2", "v1", "v2"]

# Generated at 2022-06-21 22:34:42.020182
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    from sanic.blueprints import Blueprint

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    assert len(bpg.blueprints) == 0
    bpg.append(bp1)
    assert len(bpg.blueprints) == 1
    bpg.append(bp2)
    assert len(bpg.blueprints) == 2


# Generated at 2022-06-21 22:34:46.889192
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    # passing empty list
    blueprint_group_empty = BlueprintGroup()
    assert blueprint_group_empty.url_prefix is None
    assert blueprint_group_empty.version is None
    assert blueprint_group_empty.strict_slashes is None
    assert len(blueprint_group_empty) == 0
    # passing a value with url_prefix
    blueprint_group_url_prefix = BlueprintGroup(url_prefix='/prefix')
    assert blueprint_group_url_prefix.url_prefix == '/prefix'
    assert blueprint_group_url_prefix.version is None
    assert blueprint_group_url_prefix.strict_slashes is None
    assert len(blueprint_group_url_prefix) == 0
    # passing a value with version
    blueprint_group_version = BlueprintGroup(version='/version')
    assert blueprint_group_

# Generated at 2022-06-21 22:34:56.934416
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    app = sanic.Sanic()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    for bp in [bp1, bp2, bp3, bp4]:
        @bp.route('/')
        async def index(request):
            return text('OK')

    group1 = Blueprint.group(bp1, bp2)
    group2 = Blueprint.group(bp3, bp4)

    app.blueprint(group1)
    app.blueprint(group2)


# Generated at 2022-06-21 22:35:01.501379
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg._blueprints = [bp1, bp2]
    # bpg._blueprints = [bp1, bp2, bp4]
    bpg.__delitem__(1)
    
    del bpg[1]



# Generated at 2022-06-21 22:35:06.042970
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert list(bpg) == [bp1, bp2]
    assert bpg[0] == bp1
    assert bpg[1] == bp2


# Generated at 2022-06-21 22:35:19.125848
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    # Initialize a BlueprintGroup Object
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)

    bpg2 = BlueprintGroup(url_prefix="/api", version="v1")
    bpg2.append(bp3)
    bpg2.append(bp4)

    bpg.append(bpg2)


# Generated at 2022-06-21 22:35:24.161654
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg) == 2



# Generated at 2022-06-21 22:35:28.107444
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint_group = BlueprintGroup(url_prefix="bp_prefix", version="v1", strict_slashes=True)
    assert blueprint_group._url_prefix == "bp_prefix"
    assert blueprint_group._version == "v1"
    assert blueprint_group._strict_slashes is True


# Generated at 2022-06-21 22:35:33.434474
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = sanic.Blueprint("bp1", url_prefix="/bp1")
    bp2 = sanic.Blueprint("bp2", url_prefix="/bp2")

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    
    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg[0] is bp1
    assert bpg[1] is bp2
    
    assert bpg[-1] is bp2
    assert bpg[-2] is bp1


# Generated at 2022-06-21 22:35:39.221829
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp_test_insert', url_prefix='/bp1')
    bp2 = Blueprint('bp_test_insert', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.insert(0, bp1)
    bpg.insert(1, bp2)

    assert len(bpg._blueprints) == 2
    assert bpg[0] == bp1
    assert bpg[1] == bp2