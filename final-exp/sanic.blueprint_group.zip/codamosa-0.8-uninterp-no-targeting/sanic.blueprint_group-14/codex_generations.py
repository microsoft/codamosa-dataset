

# Generated at 2022-06-21 22:28:53.351501
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp_group = BlueprintGroup('/api', version="v1")
    bp_group.append(bp1)
    bp_group.append(bp2)
    assert len(bp_group) == 2

# Generated at 2022-06-21 22:28:59.147466
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    import pytest
    bp = Blueprint("test", url_prefix="/test")
    bpg = BlueprintGroup(url_prefix="/test_group")
    bpg.insert(0, bp)
    assert len(bpg) == 1
    with pytest.raises(TypeError):
        bpg.insert("test", bp)
    with pytest.raises(TypeError):
        bpg.insert(0, "test")
    with pytest.raises(TypeError):
        bpg.insert(100, bp)


# Generated at 2022-06-21 22:29:07.313483
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    
    assert bpg.blueprints == []
    
    bpg[0] = bp1
    bpg[1] = bp2
    
    assert bpg.blueprints == [bp1, bp2]



# Generated at 2022-06-21 22:29:17.505348
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group = BlueprintGroup('/test')

    blueprint_one = Blueprint('test_blueprint_one')
    blueprint_two = Blueprint('test_blueprint_two')
    blueprint_three = Blueprint('test_blueprint_three')

    blueprint_group.append(blueprint_one)
    blueprint_group.append(blueprint_two)
    blueprint_group.append(blueprint_three)

    blueprint_group.__delitem__(1)

    assert blueprint_group.blueprints[0].name == 'test_blueprint_one'
    assert blueprint_group.blueprints[1].name == 'test_blueprint_three'

    blueprint_group.__delitem__(0)

    assert blueprint_group.blueprints[0].name == 'test_blueprint_three'


# Generated at 2022-06-21 22:29:21.151478
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @BlueprintGroup.middleware
    def group_middleware(request):
        assert type(request) is sanic.request.Request
    pass

# Generated at 2022-06-21 22:29:32.295718
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Ensure that the BlueprintGroup can be used to apply middleware for a
    Blueprint or a group of Blueprints recursively.

    :param func: Unit Test function to test the BlueprintGroup behavior
    :return:
    """

    @sanic.blueprints.Blueprint.middleware('request')
    async def common_middleware(request):
        if request.blueprint:
            request['blueprint_middleware'] = request.blueprint.name

    @common_middleware
    async def common_middleware_applied_for_group_only(request):
        request['group_middleware'] = request.blueprint.name


# Generated at 2022-06-21 22:29:34.334533
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    BlueprintGroup('/prefix', version='v2', strict_slashes=True)

# Generated at 2022-06-21 22:29:37.653209
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp = BlueprintGroup('/api', version="1")
    assert bp.url_prefix == "/api"
    assert bp.version == "1"

# # Unit test for blueprint group sanitization

# Generated at 2022-06-21 22:29:44.277127
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    test_url_prefix = 'test'
    test_version = 'test'
    test_strict_slash = False
    test_blueprint = Blueprint('test', url_prefix='test')

    Blueprint_Group = BlueprintGroup(url_prefix=test_url_prefix, version=test_version, strict_slashes=test_strict_slash)
    Blueprint_Group[0] = test_blueprint
    assert Blueprint_Group[0] == test_blueprint


# Generated at 2022-06-21 22:29:52.454668
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic("test_BlueprintGroup_middleware")
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    @bp1.route('/')
    async def handler(request):
        return text("OK")

    @bp2.route('/')
    async def handler(request):
        return text("OK")

    @bp3.route('/')
    async def handler(request):
        return text("OK")

    @bp4.route('/')
    async def handler(request):
        return text("OK")

    group = Blueprint

# Generated at 2022-06-21 22:30:07.744965
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup('/api', 'v1')

    # Check if default Blueprint Group is created as intended
    assert len(bpg) == 0
    assert bpg.url_prefix == '/api'
    assert bpg.version == 'v1'
    assert bpg.strict_slashes is None

    # Append a blueprint and check if it's configured properly
    bpg.append(bp1)
    assert len(bpg) == 1
    assert bpg[0] == bp1
    assert bp1.url_prefix == '/api/bp1'
    assert bp1.version == 'v1'
    assert bp1.strict_sl

# Generated at 2022-06-21 22:30:12.511289
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)
    assert len(group) == 2


# Generated at 2022-06-21 22:30:22.939936
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
  # Initialize app
  app = sanic.Sanic("test1")
  # BlueprintGroup object
  bpg = BlueprintGroup("/api", version="v1", strict_slashes=True)

  # Blueprint object
  bp1 = Blueprint("bp1")
  bp2 = Blueprint("bp2")
  bp3 = Blueprint("bp3")

  # Add Blueprint object to BlueprintGroup object
  bpg.append(bp1)
  bpg.append(bp2)
  bpg.append(bp3)
  bpg[1] = bp3
  
  for i in range(0, len(bpg.blueprints)):
    assert(bp3.name == bpg.blueprints[i].name)

# Generated at 2022-06-21 22:30:32.873938
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    app.clear_blueprints()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp_group = BlueprintGroup()
    bp_group.append(bp1)
    bp_group.append(bp2)
    bp_group.__setitem__(0, bp3)
    bp_group.__setitem__(1, bp4)
    assert bp_group[0].name == 'bp3'
    assert bp_group[1].name == 'bp4'


# Generated at 2022-06-21 22:30:38.847268
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    """
    Test Case: BlueprintGroup.__init__
    """
    blueprint_group = BlueprintGroup("/api", "v1", True)
    assert blueprint_group.url_prefix == "/api"
    assert blueprint_group.version == "v1"
    assert blueprint_group.strict_slashes



# Generated at 2022-06-21 22:30:41.852612
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    assert list(bpg) == bpg.blueprints
    assert bpg[0] is bp1
    assert bpg[1] is bp2


# Generated at 2022-06-21 22:30:45.612995
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    from sanic.blueprints import Blueprint

    bp = Blueprint("test_bp")

    bpg = BlueprintGroup()
    bpg.append(bp)
    del bpg[0]

    assert 0 == len(bpg._blueprints)


# Generated at 2022-06-21 22:30:51.251616
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
  bp1 = Blueprint('bp1', url_prefix='/bp1')
  bp2 = Blueprint('bp2', url_prefix='/bp2')
  bpg = BlueprintGroup()
  assert bpg.__len__() == 1, "failed to get the length of BlueprintGroup"


if __name__ == "__main__":
    test_BlueprintGroup___len__()

# Generated at 2022-06-21 22:31:00.613763
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bp3 = Blueprint("bp3")
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert bp1 in bpg
    assert bp2 in bpg
    assert not bp3 in bpg
    assert len(bpg) == 2
    i = iter(bpg)
    assert next(i) == bp1
    assert next(i) == bp2
    assert list(bpg) == [bp1, bp2]
    with pytest.raises(IndexError):
        bpg.insert(3, bp3)
    assert len(bpg) == 2
    bpg.insert(0, bp3)

# Generated at 2022-06-21 22:31:07.991181
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_1 = BlueprintGroup("/api/v1")
    blueprint_group_1.append(Blueprint("/products", url_prefix="/products"))
    blueprint_group_1[0] = Blueprint("/users", url_prefix="/users")

@blueprint.middleware('request')
async def middleware_blueprint_group():
    return text("")


# Generated at 2022-06-21 22:31:24.691694
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp3", url_prefix="/bp4")

    group = Blueprint.group(bp1, bp2, bpg1=Blueprint.group(bp3, bp4))

    assert len(group) == 2

    assert len(bp1) == 0
    assert len(bp2) == 0
    assert len(bp3) == 0
    assert len(bp4) == 0

    assert len(group.blueprints) == 2
    assert len(group.blueprints[0]) == 0
    assert len(group.blueprints[1]) == 2

# Generated at 2022-06-21 22:31:28.131959
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp = Blueprint('test_bp')
    bp_group = BlueprintGroup()
    bp_group.append(bp)
    bp_group[0] = bp
    assert bp_group.blueprints[0] == bp


# Generated at 2022-06-21 22:31:33.468485
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix="/bp1", version='v1')
    bp2 = Blueprint('bp2', url_prefix="/bp2", version='v1')

    bpg = BlueprintGroup(url_prefix='/api', version='v2', strict_slashes=True)
    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bpg) == 2
    assert bpg.url_prefix == '/api'
    assert bpg.version == 'v2'
    assert bpg.strict_slashes is True

    assert bp1.url_prefix == '/api/bp1'
    assert bp1.version == 'v1'

    assert bp2.url_prefix == '/api/bp2'

# Generated at 2022-06-21 22:31:39.688485
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    url_prefix = "/users"
    version = "v1"
    bp1 = Blueprint("bp1", url_prefix=f"/{url_prefix}")
    bpg = BlueprintGroup(url_prefix=url_prefix, version=version)
    bpg.append(bp1)
    assert bpg[0].url_prefix == f"/{url_prefix}/{url_prefix}" and bpg[0].version == version

# Generated at 2022-06-21 22:31:51.211515
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    # Initialize mock Blueprint object
    Blueprint = namedtuple("Blueprint", ["url_prefix", "version", "strict_slashes"])
    mock_bp1 = Blueprint(
        url_prefix="/bp1",
        version=None,
        strict_slashes=None
    )
    mock_bp2 = Blueprint(
        url_prefix="/bp2",
        version=None,
        strict_slashes=None
    )
    mock_bp3 = Blueprint(
        url_prefix="/bp3",
        version=None,
        strict_slashes=None
    )

    # Initialize a Blueprint group and push mock blueprints in the queue
    bpg = BlueprintGroup(
        url_prefix="/api",
        version="v1",
        strict_slashes=True
    )

# Generated at 2022-06-21 22:31:59.924251
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    #[]
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg_iterator = bpg.__iter__()
    assert bpg_iterator.__next__() == bp1
    assert bpg_iterator.__next__() == bp2
    
    
    
    
# test for method __getitem__ of class BlueprintGroup

# Generated at 2022-06-21 22:32:05.390912
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix='/api')
    bpg.append(bp1)
    bpg.append(bp2)

    assert isinstance(bpg[1], Blueprint)


# Generated at 2022-06-21 22:32:10.405467
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    blueprint_group = BlueprintGroup(bp1, bp2)
    blueprint_group.append(bp1)
    blueprint_group.insert(0, bp2)
    assert blueprint_group._blueprints[0] == bp2
    assert blueprint_group._blueprints[1] == bp1
    del blueprint_group[0]
    assert blueprint_group._blueprints[0] == bp1


# Generated at 2022-06-21 22:32:18.984344
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp1_support_methods = ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS']

    assert not hasattr(bp1, "middleware_list")

    @bp1.middleware
    def bp1_middleware(request, response):
        pass

    assert len(bp1.middleware_list) == 1
    assert bp1.middleware_list[0]['middleware'] == bp1_middleware
    assert bp1.middleware_list[0]['methods'] == bp1_support_methods
    assert bp1.middleware_list[0]['args'] == tuple()

# Generated at 2022-06-21 22:32:29.602040
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    class TestClass:
        pass

    bp = Blueprint('test')
    bp.url_prefix = 'test/'
    bp.strict_slashes = True
    bp.version = 1
    tc = TestClass()
    tc.name = 'test'
    tc.description = 'test'
    bp.add_route(tc.name, tc.description)

    bpg = BlueprintGroup('bp')
    bpg.insert(0, bp)
    assert id(bp) == id(bpg[0])

    bpg.insert(1, bp)
    assert id(bp) == id(bpg[0])
    assert id(bp) == id(bpg[1])

    bpg.insert(-1, bp)
    assert id(bp) == id(bpg[0])


# Generated at 2022-06-21 22:33:05.007806
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    # Initialize the blueprint group object and also add a blueprint as
    # part of initialization
    bpg = BlueprintGroup(url_prefix="prefix1", version="v1", strict_slashes=False)
    bp1 = Blueprint("bp1", url_prefix="prefix1/bp1")
    bpg.append(bp1)
    assert len(bpg) == 1
    bp2 = Blueprint("bp2", url_prefix="prefix1/bp2")
    bpg[0] = bp2
    assert len(bpg) == 1
    assert bpg[0].url_prefix == "prefix1/bp2"
    assert bpg._blueprints[0] is bp2


# Generated at 2022-06-21 22:33:14.210928
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    """
    Test case for testing the implementation of the `public` BlueprintGroup
    :method:`~sanic.blueprints.BlueprintGroup.append` method.

    :return: None
    """
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)
    assert bpg[0] == bp1

    bpg.append(bp2)
    assert bpg[1] == bp2

    assert bpg[0].url_prefix == "/api/bp1"

# Generated at 2022-06-21 22:33:24.944259
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    import unittest
    import unittest.mock as mock
    from sanic import Blueprint
    from sanic import Sanic
    app = Sanic()

    # Test cases for this method should cover the following cases
    # 1. Blueprint Group with a single Blueprint
    # 2. Blueprint Group with multiple Blueprint

    # Test case for single blueprint
    class TestBlueprintGroup_middleware(unittest.TestCase):
        def setUp(self):
            self.app = Sanic()
            self.bp = Blueprint("test", url_prefix="/")
            self.bp_group = BlueprintGroup(url_prefix="/")
            self.bp_group.append(self.bp)


# Generated at 2022-06-21 22:33:31.142320
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # create a simple app
    app = sanic.Sanic()

    # create a BlueprintGroup
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    group = Blueprint.group(bp1, bp2, bp3, bp4)


    # register a middleware to the BlueprintGroup
    @group.middleware()
    async def group_middleware(request):
        pass

    assert bp1.has_middleware
    assert bp2.has_middleware
    assert bp3.has_middleware
    assert bp4.has_middle

# Generated at 2022-06-21 22:33:39.266277
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    """
    Verify if __iter__ method is working as expected
    """
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bp3 = Blueprint('bp3')
    
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)

    assert(len(bpg) == 3)

    bpi = bpg.__iter__()
    counter = 0
    while True:
        try:
            next(bpi)
            counter += 1
        except StopIteration:
            break

    assert(counter == 3)



# Generated at 2022-06-21 22:33:50.519567
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup('/api/v1')
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    bpg.insert(2, bp3)
    assert len(bpg) == 5
    assert bpg.url_prefix == '/api/v1'
    bpg[2] == bp3
    bpg[0] == bp1
    bpg[1] == b

# Generated at 2022-06-21 22:33:58.022329
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp1')
    bp4 = Blueprint('bp4', url_prefix='/bp2')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    @bp3.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-21 22:34:10.425493
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    # assert that BlueprintGroup can be used as a list like object.
    bp1 = Blueprint(name="bp1", url_prefix="/bp1")
    bp2 = Blueprint(name="bp2", url_prefix="/bp2")
    bp3 = Blueprint(name="bp3", url_prefix="/bp3")

    bpg1 = BlueprintGroup()
    bpg1.append(bp1)
    bpg1.insert(0, bp2)
    bpg1.append(bp3)

    assert len(bpg1) == 3
    assert bpg1[0] == bp2
    assert bpg1[1] == bp1
    assert bpg1[2] == bp3

    bpg2 = BlueprintGroup(bp2, bp1, bp3)
    assert len(bpg2)

# Generated at 2022-06-21 22:34:20.259433
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    # GIVEN a Blueprint blueprint1
    blueprint1 = Blueprint('bp1')
    # GIVEN a BlueprintGroup blueprint_group1
    blueprint_group1 = BlueprintGroup()

    # WHEN calling append() on the blueprint_group1
    blueprint_group1.append(blueprint1)

    # THEN the blueprint_group1 should contain 1 blueprint
    assert len(blueprint_group1) == 1

    # GIVEN a Blueprint blueprint2
    blueprint2 = Blueprint('bp2')
    # GIVEN a BlueprintGroup blueprint_group2
    blueprint_group2 = BlueprintGroup()

    # WHEN calling append() on the blueprint_group2
    blueprint_group2.append(blueprint2)

    # THEN the blueprint_group2 should contain 1 blueprint
    assert len(blueprint_group2) == 1

    # GIVEN a BlueprintGroup blueprint

# Generated at 2022-06-21 22:34:28.246656
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    class _LibraryGroup(BlueprintGroup):
        def __init__(self, *args, **kwargs):
            super(_LibraryGroup, self).__init__(*args, **kwargs)
            self._blueprints = [sanic.Blueprint(__name__) for _ in range(3)]

    bpg = _LibraryGroup()
    for idx, bp in enumerate(bpg):
        assert isinstance(bp, sanic.Blueprint)
        assert bp.name == __name__
        assert idx < 3


# Generated at 2022-06-21 22:35:01.698995
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bg = BlueprintGroup();
    bg.append(bp1)
    assert len(bg) == 1
    bp = Blueprint('bp3')
    bg.insert(0, bp)
    assert len(bg) == 2
    assert bg[0].name == 'bp3'
    assert isinstance(bg, MutableSequence)
    bp_group = BlueprintGroup()
    bg.insert(0, bp_group)
    assert len(bg) == 3
    assert isinstance(bg[0], BlueprintGroup)
    assert bg[0] == bp_group
    bp_group.append(bp1)
    assert bg[0][0] == bp1

# Generated at 2022-06-21 22:35:05.174151
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert list(bpg) == bpg.blueprints



# Generated at 2022-06-21 22:35:10.155918
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bpg = BlueprintGroup()
    assert len(bpg) == 0
    bpg.append(bp1)
    assert len(bpg) == 1
    bpg.append(bp2)
    assert len(bpg) == 2
    bpg.append(bp3)
    assert len(bpg) == 3
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    assert len(bpg) == 6
    bpg.insert(3, bp3)
    assert len(bpg) == 7
   

# Generated at 2022-06-21 22:35:20.558377
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    app = sanic.Sanic()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp3)
    bpg.append(bp4)

# Generated at 2022-06-21 22:35:30.067664
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Test BlueprintGroup.middleware
    """
    from sanic.blueprints import Blueprint

    class Middleware:
        def __init__(self):
            self.registered_middleware = []

        async def __call__(self, request):
            return
        
        def register_middleware(self, middleware, middleware_name):
            self.registered_middleware.append((middleware, middleware_name))

    def middleware(request):
        pass
    
    app = sanic.Sanic("Test BlueprintGroup")
    bp1 = Blueprint("bp1", url_prefix="/bp1")

    @app.middleware("request")
    async def app_middleware(request):
        pass

    mw1 = Middleware()
    mw2 = Middleware()

# Generated at 2022-06-21 22:35:34.285443
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp3)

    assert len(bpg) == 1
    del bpg[0]
    assert len(bpg) == 0



# Generated at 2022-06-21 22:35:37.744042
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bpg = BlueprintGroup(url_prefix="/bpg")
    bpg.append(bp1)
    assert bp1.url_prefix == "/bp1"



# Generated at 2022-06-21 22:35:46.206641
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    # Create an empty Blueprint group
    group = BlueprintGroup()

    # Assert the length of group to be zero
    assert len(group) == 0

    # Create a new Blueprint
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    # Assert the length of group to be zero
    assert len(group) == 0

    # Add the blueprint to the group
    group.append(bp1)
    # Assert the length of group to be one
    assert len(group) == 1

    # Create a new Blueprint
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    # Assert the length of group to be one
    assert len(group) == 1

    # Add the blueprint to the group
    group.append(bp2)
    # Assert the length of group to be two


# Generated at 2022-06-21 22:35:54.299751
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)
    @group.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')
    assert bp1.middlewares.get('request')
    assert bp2.middlewares.get('request')
    assert len(bp1.middlewares.get('request')) == 1
    assert len(bp2.middlewares.get('request')) == 1



# Generated at 2022-06-21 22:35:59.648860
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = sanic.Blueprint("bp1", url_prefix="/bp1")
    bp2 = sanic.Blueprint("bp2", url_prefix="/bp2")
    assert bp1 == BlueprintGroup.__getitem__(BlueprintGroup(bp1, bp2), 0)
    assert bp1 != BlueprintGroup.__getitem__(BlueprintGroup(bp1, bp2), 0)
    assert "bp1" == BlueprintGroup.__getitem__(BlueprintGroup(bp1, bp2), 0).name
    assert "bp2" == BlueprintGroup.__getitem__(BlueprintGroup(bp1, bp2), 1).name
    assert "bp1" != BlueprintGroup.__getitem__(BlueprintGroup(bp1, bp2), 1).name
    assert "/bp1" == BlueprintGroup

# Generated at 2022-06-21 22:36:49.394109
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    """
    Unit test for the Blueprint Group constructor
    """
    assert BlueprintGroup(url_prefix='/test', version='v1')

# Generated at 2022-06-21 22:36:54.780852
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():

    with pytest.raises(TypeError):
       BlueprintGroup.__setitem__()

    blueprintgroup_instance = BlueprintGroup()
    blueprint_instance = Blueprint('name', url_prefix='url_prefix')
    blueprintgroup_instance.__setitem__(0, blueprint_instance)
    assert blueprintgroup_instance._blueprints[0] == blueprint_instance



# Generated at 2022-06-21 22:37:01.106509
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class BpGroup(BlueprintGroup):
        pass
    app = BpGroup()
    assert app.blueprints == []
    @app.middleware
    def bp_middleware(request):
        pass
    @app.middleware('request')
    def specific_bp_middleware(request):
        pass
    @app.middleware('request','response')
    def specific_bp_middleware_2(request, response):
      pass
    assert len(app.blueprints) == 0

# Generated at 2022-06-21 22:37:06.857781
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()

    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg[0] == bp1
    assert bpg[1] == bp2
    bpg.insert(1, bp1)
    assert bpg[0] == bp1
    assert bpg[1] == bp1
    assert bpg[2] == bp2



# Generated at 2022-06-21 22:37:12.848734
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint("bp1",url_prefix="/bp1")

    # Create a blueprint group
    bpg = BlueprintGroup()

    # Test inserting blueprint
    bpg.insert(0, bp1)
    assert bpg[0] == bp1
    assert len(bpg) == 1

    # Test inserting another blueprint
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bpg.insert(0, bp2)
    assert bpg[0] == bp2
    assert bpg[1] == bp1
    assert len(bpg) == 2


# Generated at 2022-06-21 22:37:18.824607
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api")
    bpg.append(bp1)
    bpg.append(bp2)

    bpg[0] = bp1
    assert bpg[0] == bp1


# Generated at 2022-06-21 22:37:22.464617
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp = Blueprint("bp")
    bpg = BlueprintGroup()
    bpg.append(bp)
    assert bpg.blueprints[0].url_prefix == "/bp"
    assert len(bpg.blueprints) == 1


# Generated at 2022-06-21 22:37:31.678228
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    @bp1.middleware("request")
    def bp1_only_middleware(request):
        assert request is not None

    @bp2.middleware("request")
    def bp2_only_middleware(request):
        assert request is not None

    # register middleware on all blueprints
    @bpg.middleware("request")
    def group_middleware(request):
        assert request is not None

    # register middleware on all blueprints
    @bpg.middleware("request")
    def group_middleware2(request):
        assert request

# Generated at 2022-06-21 22:37:39.217109
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp = Blueprint("bp", url_prefix="/blueprint")
    bp2 = Blueprint("bp2", url_prefix="/second")
    g = BlueprintGroup()
    g.append(bp)
    g.append(bp2)
    del g[0]
    assert g.blueprints == [bp2]

    bp = Blueprint("bp", url_prefix="/blueprint")
    bp2 = Blueprint("bp2", url_prefix="/second")
    g = BlueprintGroup()
    g.append(bp)
    g.append(bp2)
    del g[-1]
    assert g.blueprints == [bp]

    bp = Blueprint("bp", url_prefix="/blueprint")
    bp2 = Blueprint("bp2", url_prefix="/second")
    g = BlueprintGroup()
    g.append(bp)

# Generated at 2022-06-21 22:37:44.085283
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group = BlueprintGroup()
    blueprint = Blueprint('test')
    blueprint_group.append(blueprint)

    blueprint_group.insert(0, blueprint)
    assert blueprint_group[0] == blueprint
    assert blueprint_group[1] == blueprint
