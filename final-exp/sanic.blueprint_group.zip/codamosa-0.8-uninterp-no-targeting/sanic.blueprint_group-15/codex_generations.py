

# Generated at 2022-06-21 22:28:56.595924
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    # Any Blueprint group must be instantiated with 1 or more blueprints
    # passed in the constructor
    bp1_1 = Blueprint("bp1_1", url_prefix="/bp1_1")
    bp1_2 = Blueprint("bp1_2", url_prefix="/bp1_2")
    bp1_3 = Blueprint("bp1_3", url_prefix="/bp1_3")
    bp1_4 = Blueprint("bp1_4", url_prefix="/bp1_4")
    bp1_5 = Blueprint("bp1_5", url_prefix="/bp1_5")

    grp1 = BlueprintGroup()
    grp1.append(bp1_1)
    grp1.append(bp1_2)
    grp1.append(bp1_3)

# Generated at 2022-06-21 22:29:06.256731
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    """
    Unit test for method append of class BlueprintGroup

    :return: None
    """
    blueprint_group = BlueprintGroup()
    blueprint_group.append(sanic.Blueprint("blueprint_1"))
    blueprint_group.append(sanic.Blueprint("blueprint_2"))
    blueprint_group.append(sanic.Blueprint("blueprint_3"))
    assert len(blueprint_group) == 3
    assert blueprint_group[0].name == "blueprint_1"
    assert blueprint_group[1].name == "blueprint_2"
    assert blueprint_group[2].name == "blueprint_3"


# Generated at 2022-06-21 22:29:11.896501
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    # def __init__(self, url_prefix=None, version=None, strict_slashes=None):
    bpg = BlueprintGroup()
    bpg.append(Blueprint('bp1', url_prefix='/bp1'))
    bpg.append(Blueprint('bp2', url_prefix='/bp2'))
    for blueprint in bpg:
        assert blueprint.name in ['bp1','bp2']


# Generated at 2022-06-21 22:29:25.286413
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bpg = BlueprintGroup()

    # This is to make sure sythax error is not thrown due
    # to lack of the below method
    bpg.insert(0, bp2)

    # Adding items to the Blueprint with index
    bpg.insert(0, bp1)
    bpg.insert(2, bp3)

    # Blueprint group should be a list like object and
    # support indexing and slicing
    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert bpg[2] == bp3

# Generated at 2022-06-21 22:29:27.709726
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    """
    To test that number of blueprints added to blueprint_group matches its length
    """
    blueprint_group1 = BlueprintGroup()
    blueprint_group1.append("bp1")
    blueprint_group1.append("bp2")
    blueprint_group1.append("bp3")
    assert len(blueprint_group1) == 3


# Generated at 2022-06-21 22:29:32.651013
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    # 1. Blueprint Group Creation
    bp1, bp2 = Blueprint('bp1'), Blueprint('bp2')
    bpg = BlueprintGroup(bp1, bp2)
    # 2. Test Blueprint group __getitem__
    assert bpg[0] == bp1 and bpg[1] == bp2



# Generated at 2022-06-21 22:29:37.940375
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    app = sanic.Sanic('test_BlueprintGroup___delitem__')

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2)

    del group[1]

    # The following assertion will fail if the method __delitem__
    # of class BlueprintGroup does not work as expected.
    assert group[0] == bp1



# Generated at 2022-06-21 22:29:48.410569
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    # Testing Blueprint Group Creation
    bpg1 = BlueprintGroup(url_prefix='/api', version='v1')
    bpg2 = BlueprintGroup(url_prefix='/api', version='v1')
    assert bpg1.url_prefix == '/api'
    assert bpg1.version == 'v1'
    assert bpg1.blueprints == []
    assert bpg2.url_prefix == '/api'
    assert bpg2.version == 'v1'

# Generated at 2022-06-21 22:29:56.379695
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bpg = BlueprintGroup()
    assert len(bpg) == 0
    bp = Blueprint("test", url_prefix="/test")
    bpg.append(bp)
    assert len(bpg) == 1
    bpg[0] = bp
    assert len(bpg) == 1
    bp1 = Blueprint("test1", url_prefix="/test1")
    bpg[0] = bp1
    assert len(bpg) == 1


# Generated at 2022-06-21 22:30:09.098346
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    """
    Test the Blueprint Group Class
    """
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    (bp1_obj, bp2_obj) = bpg.blueprints
    assert bp1_obj == bp1
    assert bp2_obj == bp2
    assert bpg.url_prefix == "/api"
    assert bpg.version == "v1"
    # check if each Blueprint prefix got modified
    assert bp1_obj.url_prefix == "/api/bp1"
    assert bp2_obj.url_prefix == "/api/bp2"
    assert bp1_obj

# Generated at 2022-06-21 22:30:25.493023
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint("bp1", url_prefix="/api1")
    bp2 = Blueprint("bp2", url_prefix="/api2")
    bpg1 = BlueprintGroup("/parentapi", version="v1")
    bpg1.append(bp1)
    bpg1.append(bp2)
    assert bpg1.url_prefix == "/parentapi"
    assert len(bpg1.blueprints) == 2
    assert bpg1.version == "v1"
    bpg2 = BlueprintGroup("/parentapi2", version="v2", strict_slashes=True)
    bpg2.append(bpg1)
    assert bpg2.url_prefix == "/parentapi2"
    assert len(bpg2.blueprints) == 1
    assert bpg2.version == "v2"


# Generated at 2022-06-21 22:30:33.609203
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    test_app = sanic.Sanic("test_BlueprintGroup_delitem_app")

    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    group = BlueprintGroup()

    @bp1.route("/test")
    async def test_bp1(request):
        return text("test_bp1")

    @bp2.route("/test")
    async def test_bp2(request):
        return text("test_bp2")

    group.append(bp1)
    group.append(bp2)

    test_app.blueprint(group)

    assert len(group) == 2
    group.__delitem__(1)
    assert len(group) == 1

# Generated at 2022-06-21 22:30:41.440657
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    del bpg[1]
    assert len(bpg) == 1
    assert isinstance(bpg[0], sanic.Blueprint)


# Generated at 2022-06-21 22:30:49.616261
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    from unittest.mock import MagicMock
    from sanic.blueprints import Blueprint
    from sanic.exceptions import InvalidUsage

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bg = BlueprintGroup(bp1)
    assert len(bg) == 1
    bg[0] = bp2
    assert len(bg) == 1
    assert bg[0] == bp2

    bg.append(bp1)
    assert bg[1] == bp1

    class BrokenBluePrint(Blueprint):
        def __len__(self):
            return 0

    with pytest.raises(InvalidUsage):
        bg[1] = BrokenBluePrint(name="broken")


#

# Generated at 2022-06-21 22:30:50.218283
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    assert BlueprintGroup()


# Generated at 2022-06-21 22:30:59.211384
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint("blueprint1", url_prefix="/", strict_slashes=True)
    
    bp2 = Blueprint("blueprint2", url_prefix="/")
    bp2.middleware(print)(bp2)
    
    bp3 = Blueprint("blueprint3", url_prefix="/")
    bp3.middleware(print)(bp3)
    
    bp4 = Blueprint("blueprint4", url_prefix="/")
    bp4.middleware(print)(bp4)
    
    bpGroup = BlueprintGroup("url_prefix", "v1", bp1, bp2, bp3, bp4)
    bpGroup.middleware(bp1.middleware(print))

# Generated at 2022-06-21 22:31:06.831507
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    try:
        bp1 = Blueprint('bp1', url_prefix='/bp1')
        bp2 = Blueprint('bp2', url_prefix='/bp2')

        group = BlueprintGroup(bp1, bp2)

        @group.middleware('request')
        async def group_middleware(request):
            pass
    except Exception as e:
        assert(False)


# Generated at 2022-06-21 22:31:16.676255
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bp3 = sanic.Blueprint('bp3', url_prefix='/bp3')
    bp4 = sanic.Blueprint('bp4', url_prefix='/bp4')
    bg = BlueprintGroup(url_prefix="/api", version="v1")
    bg.append(bp1)
    bg.append(bp2)
    bg.append(bp3)
    bg.append(bp4)
    assert len(bg) == 4


# Generated at 2022-06-21 22:31:25.593920
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    """
    Unit Test for method __setitem__.
    """
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")

    bpg = BlueprintGroup(url_prefix="/bpg", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)

    bpg[0] = bp3

    assert bpg[0].name == "bp3"
    assert bpg[1].name == "bp2"
    assert len(bpg) == 2


# Generated at 2022-06-21 22:31:32.426379
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('test_bp1', url_prefix='/bp1')
    bp2 = Blueprint('test_bp2', url_prefix='/bp2')
    bp3 = Blueprint('test_bp3', url_prefix='/bp3')

    g = BlueprintGroup()

    g.append(bp1)
    g.append(bp2)
    g.append(bp3)

    assert g.blueprints == [bp1, bp2, bp3]
    assert g.url_prefix is None

