

# Generated at 2022-06-21 22:28:39.630564
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp = BlueprintGroup()
    bp.append(1)
    assert len(bp) == 1
    del bp[0]
    assert len(bp) == 0


# Generated at 2022-06-21 22:28:41.490125
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    url_prefix = '/v1/api'
    bpg = BlueprintGroup(url_prefix)
    assert bpg.url_prefix == url_prefix
    assert bpg.blueprints == []
    assert bpg.version is None


# Generated at 2022-06-21 22:28:47.915962
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2)

    assert bp1 == group[0]
    assert bp2 == group[1]


# Generated at 2022-06-21 22:28:52.443109
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)
    assert len(group) == 2


# Generated at 2022-06-21 22:29:02.294577
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic import Sanic
    from sanic.router import NamedRoute

    app = Sanic(__name__)
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = BlueprintGroup(bp1, bp2)

    @group.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-21 22:29:09.109480
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg) == 2
    for index, blueprint in enumerate([bp1, bp2]):
        assert blueprint == bpg[index]

# Generated at 2022-06-21 22:29:13.731051
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp = Blueprint("name")
    bg = BlueprintGroup("/prefix/", version='v1')
    bg.append(bp)
    assert len(bg) == 1
    del bg[0]
    assert len(bg) == 0


# Generated at 2022-06-21 22:29:22.009715
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    class SanicMock(object):
        def __init__(self, *args, **kwargs):
            self.url_prefix = kwargs.get("url_prefix", None)
            self.version = kwargs.get("version", None)
            self.strict_slashes = kwargs.get("strict_slashes", None)

        def middleware(self, fn, *args, **kwargs):
            return None

    blueprint = SanicMock(url_prefix="bp1", version="v1")
    blueprint_group = BlueprintGroup(url_prefix="bg1")
    blueprint_group.append(blueprint)
    blueprint_group[0] = blueprint
    assert blueprint_group[0].url_prefix == "/bg1/bp1"
    assert blueprint_group[0].version == "v1"

# Generated at 2022-06-21 22:29:32.920370
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    class App(sanic.Sanic):
        @property
        def blueprints(self):
            return self._blueprints

    app = App()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp5')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    group = Blueprint.group(bp1, bp2)
    group.append(bpg)
    app.blueprint(group)
    assert app.blueprints.get(
        '/bp1/bp2/api/bp4/<param>').end

# Generated at 2022-06-21 22:29:39.805604
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1', version='v1')
    bp2 = Blueprint('bp2', url_prefix='/bp2', version='v1')
    bp3 = Blueprint('bp3', url_prefix='/bp3', version='v1')
    bp4 = Blueprint('bp4', url_prefix='/bp4', version='v1')

    # ensure empty Blueprint Group is able to be created
    bp_g1 = BlueprintGroup()

    bp_g2 = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    assert bp_g2.blueprints == [bp1, bp2]
    assert bp_g2.url_prefix == "/api"


# Generated at 2022-06-21 22:29:51.734739
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    assert bpg[0] == bp1


# Generated at 2022-06-21 22:30:03.574232
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    for bp in [bp1, bp2, bp3, bp4]:
        bpg.append(bp)
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bpg[3] = bp5
    assert(bpg.blueprints[3] == bp5)


# Generated at 2022-06-21 22:30:15.424553
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    assert len(BlueprintGroup()) == 0, 'length of BlueprintGroup should be 0 when initialized without args'
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    group = Blueprint.group(bp1, bp2)
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    assert len(group) == 2, 'length of BlueprintGroup should be 2 after adding 2 blueprints'
    assert len(bpg) == 2, 'length of BlueprintGroup should be 2 after adding 2 blueprints'



# Generated at 2022-06-21 22:30:27.476437
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp1.static('/static', 'tests/static')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    group = Blueprint.group(bp1, bp2)

    @group.middleware('request')
    async def group_middleware(request):
        request['group_middleware_applied'] = True


# Generated at 2022-06-21 22:30:31.189553
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp = BlueprintGroup('/api', version='v1', strict_slashes=True)
    assert bp is not None
    assert bp.url_prefix == '/api'
    assert bp.version == 'v1'
    assert bp.strict_slashes == True



# Generated at 2022-06-21 22:30:37.484955
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp = Blueprint("bp")

    bpg = BlueprintGroup(url_prefix="blue")
    bpg.append(bp)

    new_bp = Blueprint("new_bp")

    assert bpg[0] == bp
    bpg[0] = new_bp

    assert bpg[0] == new_bp



# Generated at 2022-06-21 22:30:47.313183
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Unit test for middleware method of class BlueprintGroup
    """
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')

    class bp1_middleware:
        """
        Dummy class for bp1_middleware
        """
        pass

    class bp2_middleware:
        """
        Dummy class for bp2_middleware
        """
        pass

    bpg = BlueprintGroup(bp1, bp2)
    arg1 = 'url_prefix'
    arg2 = 'url_prefix'
    karg1 = {'name': 'bp1_middleware', 'host': 'host'}

# Generated at 2022-06-21 22:30:54.383465
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    # Create BlueprintGroup
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)

    # Execute method __delitem__
    del bpg[0]

    # Check length and elements
    pass

# Generated at 2022-06-21 22:31:02.232813
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    assert bpg.url_prefix == "/api"
    assert len(bpg.blueprints) == 2
    assert bpg.blueprints[0].name == "bp3"
    assert bpg.blueprints[1].name == "bp4"
    assert bpg.blueprints[0].url_prefix == "/api/bp4"

# Generated at 2022-06-21 22:31:12.528979
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    assert bp1 == bpg[0]
    assert bp2 == bpg[1]
    assert bp3 == bpg[2]


# Generated at 2022-06-21 22:31:26.558658
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    """
    Unit test for testing the constructor of the BlueprintGroup
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    assert bpg.url_prefix == "/api"
    assert bpg.version == "v1"
    assert bpg.blueprints[0].url_prefix == "/api/bp1"
    assert bpg.blueprints[0].version == "v1"
    assert bpg.blueprints[1].url_prefix == "/api/bp2"
    assert bpg.blueprints[1].version == "v1"


# Generated at 2022-06-21 22:31:37.117407
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    group = BlueprintGroup(url_prefix="/group")
    group.append(bp1)
    group.append(bp2)

    assert len(group) == 2
    assert group[0] == bp1
    assert group[1] == bp2

    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")

    group[1] = bp3
    group.insert(1, bp4)

    assert len(group) == 3
    assert group[0] == bp1
    assert group[1] == bp4
    assert group[2] == bp3



# Generated at 2022-06-21 22:31:43.397869
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix='/api', version='v1')
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg.blueprints) == 2


# Generated at 2022-06-21 22:31:53.712221
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    group = Blueprint.group(bp1, bp2)


# Generated at 2022-06-21 22:31:54.833443
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    pass

# Generated at 2022-06-21 22:32:06.594234
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    group = Blueprint.group(bp1, bp2)

    app = webtest.TestApp(sanic.Sanic('test_BlueprintGroup___delitem__'))
    app.blueprint(group)
    app.blueprint(bpg)

    assert len(group) == 2
    assert len(group.blueprints) == 2

    assert len(bpg) == 2

# Generated at 2022-06-21 22:32:13.631394
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprints = BlueprintGroup()

    blueprint1 = Blueprint('blueprint1', url_prefix='/blueprint1')
    blueprint2 = Blueprint('blueprint2', url_prefix='/blueprint2')
    blueprint3 = Blueprint('blueprint3', url_prefix='/blueprint3')

    blueprints.append(blueprint1)
    blueprints.append(blueprint2)
    blueprints.append(blueprint3)

    del blueprints[1]

    assert blueprints._blueprints[1].name == 'blueprint3'



# Generated at 2022-06-21 22:32:17.071718
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    # Arrange
    bp = Blueprint("bp", url_prefix="/bp")
    bpGroup = BlueprintGroup(url_prefix="/bpGroup")
    # Act
    bpGroup.append(bp)
    # Assert
    assert bpGroup.url_prefix == "/bpGroup"
    assert bpGroup.version == None
    assert bpGroup.strict_slashes == None
    assert len(bpGroup) == 1
    assert bpGroup._blueprints[0].url_prefix == "/bpGroup/bp"
    assert bpGroup._blueprints[0].version == None
    assert bpGroup._blueprints[0].strict_slashes == None


# Generated at 2022-06-21 22:32:26.044127
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    assert BlueprintGroup().url_prefix is None
    assert BlueprintGroup().version is None
    assert BlueprintGroup().blueprints == []
    assert BlueprintGroup().strict_slashes is None

    url_prefix = "/v1"
    version = 1.1
    strict_slashes = True

    assert BlueprintGroup(url_prefix=url_prefix).url_prefix == url_prefix
    assert BlueprintGroup(version=version).version == version
    assert BlueprintGroup(strict_slashes=strict_slashes).strict_slashes == strict_slashes


# Generated at 2022-06-21 22:32:36.696870
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp2 = Blueprint('bp1', url_prefix='/bp2')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(None, None, None)
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp1)
    assert bpg._blueprints == [bp1, bp2, bp1]
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg[1] = bp3