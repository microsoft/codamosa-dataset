

# Generated at 2022-06-24 03:24:58.779864
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    iter_bpg = iter(bpg)

    # Test first item
    assert next(iter_bpg) is bp3

    # Test second item
    assert next(iter_bpg) is bp4

    # Test StopIteration
    with pytest.raises(StopIteration):
        next(iter_bpg)


# Generated at 2022-06-24 03:25:09.448679
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    """
    Test the append method of the `BlueprintGroup` class.
    """
    app = sanic.Sanic("test_BlueprintGroup_append")
    bp1 = Blueprint("test", url_prefix="/test")

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)

    assert len(bpg) == 1
    assert isinstance(bpg[0], Blueprint)
    assert bpg[0] == bp1

    # Sanity check on the Version
    assert bp1.version == "v1"
    bpg.version = 2
    bpg.append(bp1)
    assert bp1.version == 2

    # Sanity check on the Url Prefix
    assert bp1.url_prefix == "/api/test"
    b

# Generated at 2022-06-24 03:25:17.019983
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-24 03:25:27.981514
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-24 03:25:33.959774
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bpg = BlueprintGroup("/api")
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg) == 2
    bpg.insert(1, bp1)
    assert len(bpg) == 3
    assert bpg[1] == bp1


# Generated at 2022-06-24 03:25:43.172667
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bp3 = Blueprint("bp3")
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    @bp3.middleware("request")
    async def bp3_middleware(request):
        pass

    @bpg.middleware("request")
    async def bpg_middleware(request):
        pass

    bpg.append(bp3)
    assert len(bp1.middlewares["request"]) == 1
    assert len(bp2.middlewares["request"]) == 1
    assert len(bp3.middlewares["request"]) == 2

    # Test nested group
    bpg2 = BlueprintGroup()

# Generated at 2022-06-24 03:25:49.485333
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp = Blueprint("bp", url_prefix='/bp')
    bpg = BlueprintGroup(bp, url_prefix='/bpg')
    bp.middleware(bp)
    bpg.middleware(bp)

    # This assert will fail if not change middleware method
    assert bp._middlewares == []
    assert bpg._middlewares == [bp]

if __name__ == '__main__':
    test_BlueprintGroup_middleware()

# Generated at 2022-06-24 03:25:55.871294
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api")

    bp1.middleware('request')
    bp2.middleware('request')

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp2.middleware('request')
    async def bp2_only_middleware(request):
        print('applied on Blueprint : bp2 Only')



# Generated at 2022-06-24 03:26:02.098769
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp_group = BlueprintGroup(url_prefix="v1", strict_slashes=True)
    assert bp_group.url_prefix == "v1"
    assert bp_group.strict_slashes is True
    assert bp_group.version is None
    assert bp_group.blueprints == []



# Generated at 2022-06-24 03:26:08.511465
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bp3 = Blueprint('bp3')
    bp4 = Blueprint('bp4')
    bp5 = Blueprint('bp5')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)

    bpg.insert(1, bp4)

    assert bpg.blueprints[0] == bp1
    assert bpg.blueprints[1] == bp4
    assert bpg.blueprints[2] == bp2
    assert bpg.blueprints[3] == bp3


# Generated at 2022-06-24 03:26:10.985428
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)
    assert group[0] == bp1
    assert group[1] == bp2


# Generated at 2022-06-24 03:26:20.180851
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    from sanic.blueprints import Blueprint
    from sanic.response import text
    from sanic import Sanic
    from sanic.request import Request
    from sanic.websocket import ConnectionClosed, WebSocketProtocol

    app = Sanic('sanic-blueprint')
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp_group = BlueprintGroup()
    bp_group.append(bp1)
    bp_group.append(bp2)
    bp_group.append(bp3)

    assert len(bp_group) == 3

# Generated at 2022-06-24 03:26:30.342069
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    from sanic.exceptions import ServerError
    from sanic.request import Request
    from sanic.response import BaseHTTPResponse
    from sanic.blueprints import Blueprint

    blueprint1 = Blueprint('bp1', url_prefix='/bp1')
    blueprint2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup('bpg', url_prefix='/bpg')

    @blueprint1.route('/bp1')
    async def bp1(request):
        return text('bp1')

    @blueprint2.route('/bp2')
    async def bp2(request):
        return text('bp2')

    bpg.append(blueprint1)
    bpg.append(blueprint2)

    assert blueprint1 == bpg[0]

# Generated at 2022-06-24 03:26:37.765871
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    app = sanic.Sanic(__name__)
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")
    bp5 = Blueprint("bp5", url_prefix="/bp5")
    bp6 = Blueprint("bp6", url_prefix="/bp6")
    bpg = BlueprintGroup()
    bpg.insert(0, bp1)
    bpg.insert(0, bp2)
    bpg.insert(0, bp3)
    bpg.insert(0, bp4)
    bpg.insert(0, bp5)

# Generated at 2022-06-24 03:26:42.015352
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_name = 'bp1'
    blueprint_url_prefix = '/api'
    blueprint = Blueprint(blueprint_name, url_prefix=blueprint_url_prefix)

    blueprint_group = BlueprintGroup()
    blueprint_group.append(blueprint)

    assert blueprint == blueprint_group[0]

# Generated at 2022-06-24 03:26:52.995501
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():

    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bp1_route_count = len(bp1.routes)
    bp2_route_count = len(bp2.routes)

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    bp3 = Blueprint('bp3')
    bp4 = Blueprint('bp4')

    bpg[0] = bp3
    bpg[1] = bp4
    bp3_route_count = len(bp3.routes)
    bp4_route_count = len(bp4.routes)

    assert bpg.blueprints == [bp3, bp4]
    assert bpg[0].routes == b

# Generated at 2022-06-24 03:26:53.848969
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    pass


# Generated at 2022-06-24 03:26:57.985233
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = BlueprintGroup()

    group.append(bp1)
    group.append(bp2)

    assert len(group)==2

    del group[0]

    assert len(group)==1




# Generated at 2022-06-24 03:27:06.766064
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic('test_BlueprintGroup_middleware')
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix='/group')
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')


# Generated at 2022-06-24 03:27:14.889921
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp5')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    assert bpg[0] == bp3 and bpg[1] == bp4


# Unit test of the method '_sanitize_blueprint' of class BlueprintGroup

# Generated at 2022-06-24 03:27:23.080166
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp = Blueprint("bp", url_prefix="/bp")
    bp2 = Blueprint("bp", url_prefix="/bp2")
    bp3 = Blueprint("bp", url_prefix="/bp3")

    bpg = BlueprintGroup("/bpg", "v1")
    bpg.insert(0, bp)
    assert bpg._blueprints[0].url_prefix == "/bpg/bp"
    bpg.insert(0, bp2)
    assert bpg._blueprints[0].url_prefix == "/bpg/bp2"
    bpg.insert(2, bp3)
    assert bpg._blueprints[2].url_prefix == "/bpg/bp3"


# Generated at 2022-06-24 03:27:26.506933
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp = Blueprint('bp')
    bpg = BlueprintGroup()
    bpg.append(bp)
    bp1 = Blueprint('bp1')
    bpg[0] = bp1
    assert bpg[0].name == bp1.name


# Generated at 2022-06-24 03:27:33.946461
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2)

    assert group[0] == bp1
    assert group[1] == bp2
    assert group[-1] == bp2
    assert group[-2] == bp1
    with pytest.raises(IndexError):
        group[-3]
    with pytest.raises(IndexError):
        group[3]


# Generated at 2022-06-24 03:27:38.011844
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)
    assert group[0] == bp1
    assert group[1] == bp2


# Generated at 2022-06-24 03:27:45.667896
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    assert len(bpg) == 2
    assert bp3 in bpg
    assert bp4 in bpg
    assert bp1 not in bpg
    assert bp2 not in bpg
    assert bpg.url_prefix == "/api"
    assert bpg.version == "v1"
    assert bpg.strict_slashes is None


# Generated at 2022-06-24 03:27:51.392826
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    def __getitem__(self, item):
        """
        This method returns a blueprint inside the group specified by
        an index value. This will enable indexing, splice and slicing
        of the blueprint group like we can do with regular list/tuple.

        This method is provided to ensure backward compatibility with
        any of the pre-existing usage that might break.

        :param item: Index of the Blueprint item in the group
        :return: Blueprint object
        """
        return self._blueprints[item]
    pass


# Generated at 2022-06-24 03:28:02.300908
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1", strict_slashes=False)

    bpg.append(bp1)
    assert len(bpg) == 1
    assert bpg[0].url_prefix == '/api/bp1'
    assert bpg[0].version == 'v1'
    assert bpg[0].strict_slashes == False

    bpg.append(bp2)
    assert len(bpg) == 2
    assert bpg[1].url_prefix

# Generated at 2022-06-24 03:28:11.624961
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(url_prefix="/api", version="v1")
    group.append(bp1)
    group.append(bp2)

    assert group.blueprints[0].url_prefix == "/api/bp1"
    assert group.blueprints[1].url_prefix == "/api/bp2"
    assert group[0].url_prefix == "/api/bp1"
    assert group[1].url_prefix == "/api/bp2"
    assert group.version == "v1"



# Generated at 2022-06-24 03:28:22.013263
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    # Test case 1
    bg = BlueprintGroup()
    bg.insert(0, Blueprint("test_bp_0"))
    assert len(bg) == 1
    assert bg[0].name == "test_bp_0"
    # Test case 2
    bg = BlueprintGroup()
    bg.insert(0, Blueprint("test_bp_0"))
    bg.insert(0, Blueprint("test_bp_1"))
    assert len(bg) == 2
    assert bg[0].name == "test_bp_1"
    assert bg[1].name == "test_bp_0"
    # Test case 3
    bg = BlueprintGroup()
    bg.insert(0, Blueprint("test_bp_0"))
    bg.insert(1, Blueprint("test_bp_1"))
    assert len

# Generated at 2022-06-24 03:28:30.883741
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    """
    Test the insert method of class BlueprintGroup
    """
    bp_grp = BlueprintGroup()
    bp_grp.insert(0, Blueprint("bp1", url_prefix='/v1'))
    bp_grp.insert(0, Blueprint("bp2", url_prefix='/v2'))
    bp_grp.insert(0, Blueprint("bp3", url_prefix='/v3'))
    bp_grp.insert(0, Blueprint("bp4", url_prefix='/v4'))
    
    assert len(bp_grp) == 4
    assert bp_grp[0].name == "bp4"
    assert bp_grp[0].url_prefix == "/v4"
    assert bp_grp[1].name == "bp3"
   

# Generated at 2022-06-24 03:28:36.459207
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2)
    for bp in group:
        assert isinstance(bp, Blueprint)
    for _bp in group.blueprints:
        assert isinstance(_bp, Blueprint)


# Unit Test for method __getitem__ of class BlueprintGroup

# Generated at 2022-06-24 03:28:42.570187
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    group = BlueprintGroup()
    group.append(Blueprint("test_bp_1"))
    group.append(Blueprint("test_bp_2"))
    len_before_del = len(group)
    del group[-1]
    len_after_del = len(group)
    assert len_before_del - 1 == len_after_del


# Generated at 2022-06-24 03:28:47.627292
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')

    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)
    del group[1]
    assert len(group) == 1


# Generated at 2022-06-24 03:28:52.560482
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    """
    :return: None
    """
    # Create a Sample Blueprint
    bp = sanic.Blueprint("bp", url_prefix="/bp")

    # Create a Blueprint Group
    bpg = BlueprintGroup(bp, url_prefix="/bpg")

    # Insert a new blueprint into the same blueprint group using insert
    bpg.insert(0, bp)

    # Assert
    assert len(bpg) == 2



# Generated at 2022-06-24 03:29:02.042132
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bp3 = sanic.Blueprint('bp3', url_prefix='/bp3')
    bp4 = sanic.Blueprint('bp4', url_prefix='/bp4')
    bp5 = sanic.Blueprint('bp5', url_prefix='/bp5')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    bpg.append(bp5)
    assert len(bpg) == 5

# Generated at 2022-06-24 03:29:08.976639
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    # Given
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bp3 = Blueprint("bp3")
    bp4 = Blueprint("bp4")

    bpg = BlueprintGroup(bp1, bp2)

    # When
    bpg.append(bp3)

    # Then
    assert len(bpg) == 3
    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert bpg[2] == bp3


# Generated at 2022-06-24 03:29:17.605925
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1', version="v1")
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    group = Blueprint.group(bp1, bp2, version="v1", strict_slashes=False)
    group2 = Blueprint.group(group, bp3, bp4, version="v2")
    assert bp1 == group[0]
    assert bp2 == group[1]
    assert group == group2[0]
    assert bp3 == group2[1]
    assert bp4 == group2[2]
    assert "v1" == group.version


# Generated at 2022-06-24 03:29:22.298382
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp = BlueprintGroup()
    for i in range(4):
        assert len(bp) == i
        bp.append(i)
    assert len(bp) == 4
    bp[2] = 'a'
    assert bp[2] == 'a'
    assert len(bp) == 4
    del bp[3]
    assert len(bp) == 3


# Generated at 2022-06-24 03:29:33.768815
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():

    bpg = BlueprintGroup(url_prefix="/api/v1/", version="v1")
    assert bpg.url_prefix == "/api/v1/"
    assert bpg.version == "v1"

    bp1 = Blueprint("bp1")
    bp1.url_prefix = "/bp1"
    bp2 = Blueprint("bp2")
    bp2.url_prefix = "/bp2"
    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bpg) == 2
    assert bp1.url_prefix == "/api/v1/bp1"
    assert bp2._strict_slashes is None
    assert bp1._strict_slashes is None

    bpg.insert(0, bp2)
    assert bp2.url

# Generated at 2022-06-24 03:29:39.919015
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    assert bpg.blueprints == [bp1]
    assert bp1.url_prefix == '/api/bp1'


# Generated at 2022-06-24 03:29:44.365813
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")

    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)

    del group[0]
    assert len(group._blueprints) == 1
    assert group.blueprints[0] == bp2


# Generated at 2022-06-24 03:29:51.734686
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    
    assert(bp1.url_prefix == "/bp1")
    assert(bp2.url_prefix == "/bp2")
    assert(bp3.url_prefix == "/api/bp4")

# Generated at 2022-06-24 03:29:58.411300
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    # Create a new BlueprintGroup Object
    bpg = BlueprintGroup()
    # Assert the initial Length
    assert len(bpg) == 0
    # Append a new Blueprint
    bpg.append(Blueprint("A"))
    # Assert the Length
    assert len(bpg) == 1
    # Delete the Blueprint at Position 0
    del bpg[0]
    # Assert the length
    assert len(bpg) == 0


# Generated at 2022-06-24 03:30:06.571026
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    assert list(iter(bpg)) == [bp1, bp2]
    assert bpg == [bp1, bp2]

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    assert list(bpg) == [bp1, bp2]
    assert list(iter(bpg)) == [bp1, bp2]
    assert bpg == [bp1, bp2]



# Generated at 2022-06-24 03:30:15.682097
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    from sanic.blueprints import Blueprint
    from sanic.testing import HOST, PORT
    from sanic.views import CompositionView
    from sanic.websocket import WebSocketProtocol
    app = sanic.Sanic(__name__)

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        pass

    @bp1.route('/')
    async def bp1_route(request):
        pass

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        pass


# Generated at 2022-06-24 03:30:26.880692
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bpg = BlueprintGroup(url_prefix="/users", version="v1")

    assert bpg._url_prefix == "/users"
    assert bpg._version == "v1"
    assert bpg._strict_slashes == None


bp1 = Blueprint('bp1', url_prefix='/bp1')
bp2 = Blueprint('bp2', url_prefix='/bp2')


@bp1.route('/')
async def bp1_route(request):
    return text('bp1')


@bp2.route('/<param>')
async def bp2_route(request, param):
    return text(param)


group = Blueprint.group(bp1, bp2)



# Generated at 2022-06-24 03:30:35.029839
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class TestSanic(sanic.Sanic):
        pass
    app = TestSanic()

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bp1.middleware_registered = []
    bp2.middleware_registered = []
    bp3.middleware_registered = []
    bp4.middleware_registered = []

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        bp1.middleware_registered += [1]


# Generated at 2022-06-24 03:30:45.529245
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    from sanic.blueprints import Blueprint
    bp1 = Blueprint("test1", url_prefix = "/test1")
    bp2 = Blueprint("test2", url_prefix = "/test2")
    bp3 = Blueprint("test3", url_prefix = "/test3")
    bp4 = Blueprint("test4", url_prefix = "/test4")

    bpg = BlueprintGroup(bp1, bp2, bp3, bp4)

    assert(bpg[0] == bp1)
    assert(bpg[1] == bp2)
    assert(bpg[2] == bp3)
    assert(bpg[3] == bp4)
    try:
        assert(bpg[4] == bp4)
    except IndexError:
        assert(True)

# Unit test

# Generated at 2022-06-24 03:30:56.688176
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    my_test = BlueprintGroup()
    my_test.insert(0, bp1)
    my_test.insert(0, bp2)
    assert len(my_test) == 2
    assert my_test[0] == bp2
    assert my_test[1] == bp1
    my_test.insert(0, bp3)
    assert len(my_test) == 3
    assert my_test[0] == bp3
    assert my_test[1] == bp

# Generated at 2022-06-24 03:31:01.628850
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    assert bpg[0] == bp3
    assert bpg[1] == bp4


# Generated at 2022-06-24 03:31:09.566955
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix="/api", version="v1", strict_slashes=False)
    bpg.append(bp1)
    bpg.append(bp2)
    assert bpg.url_prefix == '/api'
    assert bpg.version == 'v1'
    assert bpg.strict_slashes == False


# Generated at 2022-06-24 03:31:18.905972
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic.blueprints import Blueprint

    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')

    bp3 = Blueprint('bp3')
    bp4 = Blueprint('bp4')

    bpg = BlueprintGroup()

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.middleware('request', methods=['POST'])
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.middleware('request', uri_bans=['/banned'])
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

# Generated at 2022-06-24 03:31:29.349118
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('Test_BP1', url_prefix='/bp1')
    bp2 = Blueprint('Test_BP2', url_prefix='/bp2')
    bp3 = Blueprint('Test_BP3', url_prefix='/bp4')
    bp4 = Blueprint('Test_BP4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    assert isinstance(bpg, BlueprintGroup)
    assert isinstance(bpg[0], Blueprint)
    assert isinstance(bpg[1], Blueprint)
    # Assert negative indexing
    assert isinstance(bpg[-1], Blueprint)
    # Assert index error
    try:
        bpg[2]
    except IndexError:
        assert True

   

# Generated at 2022-06-24 03:31:38.535783
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bp5 = Blueprint('bp5', url_prefix='/bp4')
    bp6 = Blueprint('bp6', url_prefix='/bp4')

    bpg1 = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    bpg2 = BlueprintGroup(bp5, bp6, url_prefix="/api", version="v1")


# Generated at 2022-06-24 03:31:48.818201
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp1.route("/")(lambda req: text("bp1"))

    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp2.route("/<param>")(lambda req, param: text(param))
    
    group = Blueprint.group(bp1, bp2)

    group[0] = Blueprint("bp3", url_prefix="/bp3")
    
    app = Sanic("test_BlueprintGroup___setitem__")
    app.blueprint(group)

    request, response = app.test_client.get("/bp3")
    assert response.text == "bp3"
    
    request, response = app.test_client.get("/bp2/test")

# Generated at 2022-06-24 03:31:59.105425
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    from sanic.blueprints import Blueprint

    url_prefix = "/test/" # type: str
    bp1 = Blueprint('bp1', url_prefix=url_prefix)
    bp2 = Blueprint('bp2', url_prefix=url_prefix)

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    assert bp1.url_prefix == bp2.url_prefix
    assert bp1.url_prefix == url_prefix
    assert bp2.url_prefix == url_prefix

    assert len(bpg) == 0

    bpg.append(bp1)
    assert bpg[0].url_prefix == url_prefix + "v1/test/"

    bpg.append(bp2)
    assert bpg[0].url_prefix == url_prefix + "v1/test/"

# Generated at 2022-06-24 03:32:03.875558
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bg = BlueprintGroup()

    bg.append(sanic.Blueprint("testbp1"))
    bg.append(sanic.Blueprint("testbp2"))

    del bg[0]
    assert len(bg) == 1
    assert bg._blueprints[0].name == "testbp2"



# Generated at 2022-06-24 03:32:09.809795
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = sanic.Blueprint("bp1")
    bp1.name = "bp1"
    bp2 = sanic.Blueprint("bp2")
    bp2.name = "bp2"
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg) == 2


# Generated at 2022-06-24 03:32:16.126670
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint = Blueprint('test', url_prefix='/test')
    blueprint_group = BlueprintGroup()
    blueprint_group._blueprints = [blueprint]
    blueprint_group_iter = blueprint_group.__iter__()
    assert type(blueprint_group_iter) == BlueprintGroupIterator
    next_blueprint = next(blueprint_group_iter)
    assert next_blueprint == blueprint


# Generated at 2022-06-24 03:32:25.820828
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    @bp3.route('/')
    async def bp1_route(request):
        return text('bp1')

   

# Generated at 2022-06-24 03:32:34.772437
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    # Test for the __iter__ method
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)
    bpg.append(bp2)

    # Create Iterator object
    iter1 = iter(bpg)
    iter2 = iter(bpg)

    # Check the iterator output
    assert next(iter1) == bp1
    assert next(iter1) == bp2

    # Test if iteration is over
    with pytest.raises(StopIteration):
        next(iter1)

    # Test if iterator pointer is reset to beginning
    assert next(iter2) == bp1


# Unit

# Generated at 2022-06-24 03:32:44.608067
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp3)
    bpg.append(bp4)
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.__delitem__(1)
    assert len(bpg._blueprints) == 3


# Generated at 2022-06-24 03:32:54.854560
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Test case to validate the Blueprint method middleware
    """
    app = sanic.Sanic("Test_Middleware_Blueprint")
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)

    @group.middleware("request")
    async def group_middleware(request):
        print("common middleware applied for both bp1 and bp2")

    @bp1.route("/")
    async def bp1_route(request):
        return text("bp1")

    @bp2.route("/<param>")
    async def bp2_route(request, param):
        return text(param)



# Generated at 2022-06-24 03:33:01.554434
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    # create a Blueprint object
    b1 = Blueprint('bp1', url_prefix='/bp1')
    bpg = BlueprintGroup()
    # append blueprints to blueprint group
    bpg.append(b1)
    # test if appended blueprint is present in blueprint group
    assert b1 == bpg[0]

    # create a Blueprint object
    b2 = Blueprint('bp2', url_prefix='/bp2')
    bpg.append(b2)
    # test if appended blueprint is present in blueprint group
    assert b2 == bpg[1]
    # test if length of blueprint group is 2
    assert len(bpg) == 2


# Generated at 2022-06-24 03:33:10.534552
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix='/api', version='v1')
    bpg.append(bp3)
    bpg.append(bp4)
    counter = 0
    for bp in bpg:
        assert bp.url_prefix != '/api'
        counter += 1
    assert counter == bpg.__len__()



# Generated at 2022-06-24 03:33:16.566600
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert bpg[2] == bp3
    assert bpg[3] == bp4


# Generated at 2022-06-24 03:33:23.871546
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    bp3 = BlueprintGroup(bp1, bp2, url_prefix="/api", version=1)
    assert bp3.blueprints == [bp1, bp2]
    assert bp3.url_prefix == "/api"
    assert bp3.version == 1
    assert len(bp3) == 2



# Generated at 2022-06-24 03:33:33.903419
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    """
     Unit test for method __len__ of class BlueprintGroup
    """
    # Create a BlueprintGroup object with 3 empty blueprints
    bpg = BlueprintGroup("/api", "v1")
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bpg.append(bp1)
    bpg.append(bp2)
    # Create a blueprint outside the blueprint group
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    # Check if the length of the blueprint group is equal to 3
    assert len(bpg) == 2
    # Check if the length of an empty blueprint group is equal to 0
    assert len(BlueprintGroup("/api", "v1")) == 0
    # Check if the length of the blueprint

# Generated at 2022-06-24 03:33:42.808181
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Given some blueprints and a blueprint group
    bp1 = sanic.Blueprint('bp1')
    bp2 = sanic.Blueprint('bp2')
    bp3 = sanic.Blueprint('bp3')
    bp4 = sanic.Blueprint('bp4')
    bp5 = sanic.Blueprint('bp5')
    bpg1 = BlueprintGroup()
    bpg2 = BlueprintGroup()
    bpg1.append(bp1)
    bpg1.append(bp2)
    bpg1.append(bpg2)
    bpg2.append(bp3)
    bpg2.append(bp4)
    bpg2.append(bp5)
    # And some middleware, both as a function and as a decorated function

# Generated at 2022-06-24 03:33:50.502356
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    assert isinstance(group, BlueprintGroup)
    assert group.url_prefix == '/api'
    assert group.version == 'v1'
    assert group.strict_slashes is None
    assert len(group.blueprints) == 2
    assert group.blueprints[0] is bp1
    assert group.blueprints[1] is bp2


# Generated at 2022-06-24 03:33:57.147469
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    """
    Test that BlueprintGroup.__setitem__ works properly.
    """

    blueprint_group = BlueprintGroup()
    blueprint1 = Blueprint("test", url_prefix="/prefix")
    blueprint2 = Blueprint("test2", url_prefix="/prefix2")

    blueprint_group.append(blueprint1)
    blueprint_group.append(blueprint2)
    blueprint_group[0] = blueprint2
    blueprint_group[1] = blueprint1

    assert blueprint_group.blueprints[0] == blueprint2
    assert blueprint_group.blueprints[1] == blueprint1
    blueprint_group[0] = blueprint1
    blueprint_group[1] = blueprint2


# Generated at 2022-06-24 03:34:02.995534
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp = Blueprint('test_BlueprintGroup___setitem__')

    bp1 = BlueprintGroup()
    bp2 = BlueprintGroup()
    bp3 = BlueprintGroup()

    bp1.append(bp)
    bp2.append(bp)
    bp3.append(bp)

    bp1[0] = bp2
    bp1[1] = bp3

    assert bp1[0] is bp2
    assert bp1[1] is bp3
    # assert bp1[0].group is None
    # assert bp1[1].group is None


# Generated at 2022-06-24 03:34:11.307475
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)


# Generated at 2022-06-24 03:34:22.165022
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class A(sanic.Blueprint):
        def __init__(self, *args, **kwargs):
            kwargs.setdefault("strict_slashes", True)
            super().__init__(*args, **kwargs)
        def init_for_test(self):
            self.middlewares = {}
    class App(sanic.Sanic):
        def __init__(self, *args, **kwargs):
            for blueprint in kwargs.pop("blueprints", []):
                self.blueprint(blueprint)
            super().__init__(*args, **kwargs)
            for blueprint in self._blueprints.values():
                blueprint.init_for_test()


# Generated at 2022-06-24 03:34:32.487144
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    """
    Unit test for method __getitem__ of class BlueprintGroup
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    app = sanic.Sanic("test_sanic_Blueprint_Group")

    bpG = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')


# Generated at 2022-06-24 03:34:43.020093
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    group1 = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    group2 = BlueprintGroup(bp3, Blueprint("bp4"), url_prefix="/api", version="v1")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp3", url_prefix="/bp3")
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    assert len(group1) == 2
    assert len(group2) == 2
    assert len(bpg) == 2


# Generated at 2022-06-24 03:34:50.113764
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bp3 = Blueprint('bp3')
    bp4 = Blueprint('bp4')

    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)

    assert len(group) == 2

    group.append(bp3)
    group.append(bp4)

    assert len(group) == 4

