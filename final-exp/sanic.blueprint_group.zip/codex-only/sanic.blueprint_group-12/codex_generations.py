

# Generated at 2022-06-24 03:24:57.888025
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2)
    bpg = bpg.__getitem__(1)
    assert bpg.url_prefix == '/bp2'


# Generated at 2022-06-24 03:25:00.957432
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp = BlueprintGroup(url_prefix='/api', version='v1')
    assert bp.url_prefix == '/api'
    assert bp.version == 'v1'


# Generated at 2022-06-24 03:25:11.314405
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp4')
    bp6 = Blueprint('bp6', url_prefix='/bp4')
    # Add bp1 and bp2 to bp_group1 using append
    bp_group1 = BlueprintGroup()
    bp_group1.append(bp1)
    bp_group1.append(bp2)
    assert len(bp_group1.blueprints) == 2
    assert bp_group1.blueprints[0].url

# Generated at 2022-06-24 03:25:19.010502
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    from sanic.blueprints import Blueprint
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    assert all(map(lambda item: item in [bp1, bp2], bpg))


# Unit test to validate the Blueprint Group object implements
# indexing and slicing operation

# Generated at 2022-06-24 03:25:23.605322
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group = BlueprintGroup(url_prefix='/test')
    blueprint_group.append(Blueprint('dummy'))
    assert len(blueprint_group) == 1


# Generated at 2022-06-24 03:25:33.326558
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    # arrange
    bpg = BlueprintGroup()
    bpg.append(sanic.Blueprint('bp1', url_prefix='/bp1'))
    bpg.append(sanic.Blueprint('bp2', url_prefix='/bp2'))

    # act
    bp_iter = iter(bpg)
    bp1 = bp_iter.__next__()
    bp2 = bp_iter.__next__()

    # assert
    assert len(bpg.blueprints) == 2
    assert isinstance(bp1, sanic.Blueprint)
    assert bp1.name == 'bp1'
    assert bp1.url_prefix == '/bp1'

    assert isinstance(bp2, sanic.Blueprint)
    assert bp2.name == 'bp2'
    assert b

# Generated at 2022-06-24 03:25:40.508659
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group = BlueprintGroup(url_prefix="/api", version="v1")
    blueprint_group.append(Blueprint("bp1", url_prefix="/bp1"))
    blueprint_group.append(Blueprint("bp2", url_prefix="/bp2"))
    blueprint_group.append(Blueprint("bp3", url_prefix="/bp3"))
    blueprint_group.append(Blueprint("bp4", url_prefix="/bp4"))
    blueprint_group.append(Blueprint("bp5", url_prefix="/bp5"))

    for bp in blueprint_group:
        assert type(bp) == Blueprint


# Generated at 2022-06-24 03:25:49.804481
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    class BP(sanic.Blueprint):
        name = "bp"

    bpg = BlueprintGroup(url_prefix="/api", version="v1", strict_slashes=False)
    bp = BP("bp", url_prefix="/bp", version="v2", strict_slashes=True)
    bpg.append(bp)

    assert bpg.url_prefix == "/api"
    assert bpg.version == "v1"
    assert bpg.strict_slashes is False

    assert bp.version == "v2"
    assert bp.strict_slashes is True
    assert bp.url_prefix == "/api/bp"



# Generated at 2022-06-24 03:25:58.407491
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')

    bp3 = sanic.Blueprint('bp3', url_prefix='/bp3')
    bp4 = sanic.Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    assert bpg
    assert bpg.blueprints[0] == bp3
    assert bpg.blueprints[1] == bp4
    assert bpg.url_prefix == "/api"
    assert bpg.version == "v1"


# Generated at 2022-06-24 03:26:03.199112
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)

    bpg.__delitem__(1)
    assert len(bpg.blueprints) == 1


# Generated at 2022-06-24 03:26:09.012135
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    assert(bpg.__len__() == 2)
    del bpg[0]
    assert(bpg.__len__() == 1)


# Generated at 2022-06-24 03:26:17.356094
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    assert len(bpg) == 2


# Generated at 2022-06-24 03:26:27.856763
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # create a blueprint
    bp1 = sanic.Blueprint("test_bp1", url_prefix="/bp1")
    bp2 = sanic.Blueprint("test_bp2", url_prefix="/bp2")
    bp3 = sanic.Blueprint("test_bp3", url_prefix="/bp3")
    bp4 = sanic.Blueprint("test_bp4", url_prefix="/bp4")
    bp5 = sanic.Blueprint("test_bp5", url_prefix="/bp5")
    group = BlueprintGroup(bp1, bp2, bp3, bp4)
    group2 = BlueprintGroup(bp5, bp4, bp3, bp2)
    group3 = BlueprintGroup(group, group2)

# Generated at 2022-06-24 03:26:38.895322
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.insert(0,bp3)
    bpg.insert(0,bp4)

    assert(bpg[0]==bp3)

    bpg.insert(1,bp1)

    assert(bpg[1]==bp1)

    bpg.insert(2,bp2)

    assert(bpg[1]==bp1)
    assert(bpg[2]==bp2)


# Unit test

# Generated at 2022-06-24 03:26:48.524842
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()
    bp = Blueprint('bp', url_prefix='/bp')
    bp1 = bp.group({bp})
    bpg = BlueprintGroup()
    bpg.append(bp)
    bpg.append(bp1)

    @bpg.middleware('request')
    async def bp_group_middleware(request):
        print('applied on BlueGroup: bpg')

    assert len(bp.middlewares['request']) == 1
    assert len(bp1.middlewares['request']) == 1
    assert bp1.middlewares['request'][0] == bpg.middlewares['request'][0]



# Generated at 2022-06-24 03:26:57.422605
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    # Given
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp1.strict_slashes = False
    bp2.strict_slashes = False

    # When
    bpg = BlueprintGroup(bp1, bp2)
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp3.strict_slashes = False
    bpg.append(bp3)
    del bpg[1]

    # Then
    assert len(bpg) == 2
    assert bpg[0] == bp1
    assert bpg[1] == bp3



# Generated at 2022-06-24 03:27:03.644417
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    assert len(bpg) == 2


# Generated at 2022-06-24 03:27:09.559151
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bpg = BlueprintGroup()
    bpg.append(sanic.Blueprint('bp1', url_prefix='/bp1'))
    del bpg[0]
    assert len(bpg) == 0, "excepted: 0, actual: {}".format(len(bpg))


# Generated at 2022-06-24 03:27:20.872959
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    class BlueprintGroupWithMiddleware(BlueprintGroup):
        def __init__(self, url_prefix=None, version=None, strict_slashes=None):
            super().__init__(url_prefix, version, strict_slashes)
            self._middleware_list = []

        @property
        def middleware_list(self):
            return self._middleware_list

        def middleware(self, *args, **kwargs):
            def middleware_wrapper(fn):
                self._middleware_list.append((fn, args, kwargs))
                return fn
            if args and callable(args[0]):
                fn = args[0]
                args = list(args)[1:]
                return middleware_wrapper(fn)
            return middleware_wrapper


# Generated at 2022-06-24 03:27:28.571403
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    # Create a Blueprint Group Object
    bpg = BlueprintGroup()

    # Create two blueprints and add them to the blueprint group
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg.append(bp1)
    bpg.append(bp2)

    # Len of the BlueprintGroup should be 2
    assert len(bpg) == 2

    # Append the same Blueprints once again and the length should be 4
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg) == 4

# Generated at 2022-06-24 03:27:36.331082
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    def dummy_middleware(request): pass

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp3)
    bpg.append(bp4)

    bpg.middleware(dummy_middleware)

    assert bp3.middlewares
    assert bp4.middlewares



# Generated at 2022-06-24 03:27:42.212120
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint("bp1", url_prefix='/bp1')
    bp2 = Blueprint("bp2", url_prefix='/bp2')
    bp3 = Blueprint("bp3", url_prefix='/bp4')
    bp4 = Blueprint("bp4", url_prefix='/bp4')

    assert len(BlueprintGroup(bp1, bp2)) == 2
    assert len(BlueprintGroup(bp1, bp2, bp3, bp4)) == 4


# Generated at 2022-06-24 03:27:53.096443
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    """
    This method tests the BlueprintGroup class specificity of
    implementing the __getitem__ method
    """

    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    
    assert isinstance(bpg[0], sanic.Blueprint)
    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert bpg["url_prefix"] == "/api"
    assert bpg["version"] == "v1"

# Generated at 2022-06-24 03:28:00.200071
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint1 = Blueprint(name = "blueprint1", url_prefix = "/blueprint1")
    blueprint2 = Blueprint(name = "blueprint2", url_prefix = "/blueprint2")
    blueprint_group = BlueprintGroup()
    blueprint_group.append(blueprint1)
    blueprint_group.append(blueprint2)
    blueprint_group.__delitem__(1)
    assert blueprint_group._blueprints[0] == blueprint1
    assert len(blueprint_group._blueprints) == 1


# Generated at 2022-06-24 03:28:11.176138
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('one',url_prefix='/one')
    bp2 = Blueprint('two',url_prefix='/two')
    bp3 = Blueprint('three',url_prefix='/three')
    bp4 = Blueprint('four',url_prefix='/four')

    bp5 = Blueprint('five',url_prefix='/five')
    bp6 = Blueprint('six',url_prefix='/six')

    group1 = BlueprintGroup(bp1,bp2,url_prefix='/g1')
    group2 = BlueprintGroup(bp3,bp4,url_prefix='/g2')

    group = BlueprintGroup(group1,group2,bp5,bp6,url_prefix='/g')

    group.__delitem__(0)
    assert group[0] == group2
    assert group[1]

# Generated at 2022-06-24 03:28:13.542115
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    assert False, "Tests are not implemented yet."


# Generated at 2022-06-24 03:28:23.998793
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    """
    Unit test for method append of class BlueprintGroup
    """
    from sanic.blueprints import Blueprint

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()

    with pytest.raises(AttributeError, match=r".*url_prefix.*"):
        bpg.append(bp1)

    bpg._url_prefix = "/api"
    bpg.append(bp1)
    assert bpg._blueprints == [bp1]
    assert bp1._url_prefix == "/api/bp1"

    bp1.append(bp2)
    assert bp1._blueprints == [bp2]

# Generated at 2022-06-24 03:28:30.898953
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    group = BlueprintGroup(url_prefix='/api')
    group.append(bp1)
    group.append(bp2)
    assert group[0] == bp1
    assert group[1] == bp2

# Generated at 2022-06-24 03:28:38.307616
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    # Create multiple blueprint instances
    bp1 = sanic.Blueprint("bp1")
    bp2 = sanic.Blueprint("bp2")
    bp3 = sanic.Blueprint("bp3")

    # Create new BlueprintGroup instance
    bpg = BlueprintGroup()
    assert len(bpg) == 0

    # Insert multiple Blueprint instances into BlueprintGroup
    bpg.append(bp1)
    assert len(bpg) == 1
    bpg.append(bp2)
    assert len(bpg) == 2
    bpg.append(bp3)
    assert len(bpg) == 3


# Generated at 2022-06-24 03:28:48.879829
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    m = Blueprint()
    m.route('/a')(lambda x: x)

    o = Blueprint()
    o.route('/b')(lambda x: x)
    o.route('/c')(lambda x: x)

    bg = BlueprintGroup(url_prefix='/api', version='v1')
    bg.append(m)

    assert str(bg[0]) == str(m)

    bg.insert(0, o)
    assert str(bg[0]) == str(o)
    assert str(bg[1]) == str(m)
    assert bg[0].version == 'v1'
    assert bg[1].version == 'v1'
    assert bg[0].url_prefix == '/api/o'

# Generated at 2022-06-24 03:28:56.633820
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bpg = BlueprintGroup(url_prefix="/api")
    assert len(bpg) == 0
    bpg.append(bp1)
    assert len(bpg) == 1
    bpg.append(bp1)
    assert len(bpg) == 2
    bpg.append(bp2)
    assert len(bpg) == 3


# Generated at 2022-06-24 03:29:04.469186
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")
    bp5 = Blueprint("bp5", url_prefix="/bp5")

    bpg = BlueprintGroup("/api/v1", version="v1", strict_slashes=False)
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    bpg[1] = bp5
    del bpg[3]

    assert len(bpg) == 4
    assert bpg[0] == bp1

# Generated at 2022-06-24 03:29:15.950957
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-24 03:29:24.956447
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint(name='bp1', url_prefix='/bp1')
    bp2 = Blueprint(name='bp2', url_prefix='/bp2')
    bp_group = BlueprintGroup()
    bp_group.append(bp1)
    bp_group.append(bp2)
    assert bp_group.url_prefix is None
    assert bp_group.blueprints == [bp1, bp2]
    assert bp_group.version is None
    assert bp_group.strict_slashes is None
    url_prefix = '/group1'
    version = '1.0'
    strict_slashes = True
    bp_group = BlueprintGroup(url_prefix, version, strict_slashes)
    assert bp_group.url_prefix == url_prefix

# Generated at 2022-06-24 03:29:36.144043
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    from sanic.blueprints import Blueprint
    from sanic.request import Request
    from sanic.response import HTTPResponse

    requests = []

    def request_fn(request: Request):
        requests.append(request)
        return HTTPResponse(status=200)

    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    @bp1.route("/")
    def bp1_route(request):
        return request_fn(request)

    @bp2.route("/")
    def bp2_route(request):
        return request_fn(request)

    bpg = BlueprintGroup(url_prefix="g1")
    bpg[0] = bp1
    bpg[1] = b

# Generated at 2022-06-24 03:29:47.223426
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    """
    Test Description: Test BlueprintGroup class's method __delitem__
    """
    import os
    from sanic import Sanic, response

    os.environ["BLUEPRINT_GROUP_UNIT_TEST"] = "1"

    sanic_app = Sanic("test_blueprintgroup_delitem")

    blueprint1 = Blueprint("test_blueprintgroup_delitem_bp1")

    @blueprint1.route("/test")
    def test_handler(request):
        return response.text("test_handler")

    blueprint2 = Blueprint("test_blueprintgroup_delitem_bp2")

    @blueprint2.route("/test")
    def test_handler(request):
        return response.text("test_handler")

    bpg = BlueprintGroup()

    bpg.append(blueprint1)


# Generated at 2022-06-24 03:29:51.895492
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg[0] = bp1
    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert bpg.blueprints == [bp1, bp2]



# Generated at 2022-06-24 03:29:58.787175
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    """
    Test method insert of class BlueprintGroup with good inputs
    """
    bp_group = BlueprintGroup()
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bp_group.insert(1, bp2)
    bp_group.insert(0, bp1)
    assert bp_group[1] == bp2
    assert bp_group[0] == bp1
    assert len(bp_group) == 2

# Generated at 2022-06-24 03:30:05.623730
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    group = BlueprintGroup("/api", "v1")
    group.append(bp1)
    group.append(bp2)
    group.append(bp3)
    group[2] = bp4
    assert group._blueprints == [bp1, bp2, bp4]


# Generated at 2022-06-24 03:30:14.845514
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    # Given: Sanic App, Blueprint and BlueprintGroup
    app = sanic.Sanic('test')
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    # Given: Route
    @bp1.route('/', methods=['GET'])
    async def test(request):
        pass

    # Given: Sanic app with blueprintgroup
    app.blueprint(bp1)

    # When: BlueprintGroup instance is added as list item
    bpg[0] = app.blueprints[0]

    # Then: BlueprintGroup has blueprint
    assert bpg[0] == app.blueprints[0]
    assert b

# Generated at 2022-06-24 03:30:21.908285
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    result = [bp for bp in bpg]
    assert(bp1 in result)
    assert(bp2 in result)


# Generated at 2022-06-24 03:30:26.838715
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    assert len(bpg) == 2


# Generated at 2022-06-24 03:30:32.966131
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bps = [
        Blueprint("blueprint1", url_prefix="/bp1"),
        Blueprint("blueprint2", url_prefix="/bp2")
    ]
    bp_group = BlueprintGroup(url_prefix="v1", version=1)
    bp_group[0] = bps[0]
    bp_group[1] = bps[1]
    assert bp_group[0].name == "blueprint1"
    assert bp_group[1].name == "blueprint2"


# Generated at 2022-06-24 03:30:40.591034
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    app = sanic.Sanic('test_BlueprintGroup___delitem__')
    bp1 = Blueprint('test_BlueprintGroup___delitem__', url_prefix='/bp1')
    bp2 = Blueprint('test_BlueprintGroup___delitem__', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert str(bpg) == str([bp1, bp2])
    bpg.__delitem__(0)
    assert str(bpg) == str([bp2])


# Generated at 2022-06-24 03:30:45.260643
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bp3 = Blueprint("bp3")
    bp4 = Blueprint("bp4")

    assert len(BlueprintGroup(bp1, bp2)) == 2
    assert len(BlueprintGroup(bp1, bp2, bp3)) == 3
    assert len(BlueprintGroup(bp1, bp2, bp3, bp4)) == 4



# Generated at 2022-06-24 03:30:56.295195
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    """
    Test if BlueprintGroup can be used as a list and also can be indexed.
    After that test if it can be spliced and finally sliced.
    """
    from sanic.blueprints import Blueprint

    bp = Blueprint("test", __name__)
    group = BlueprintGroup(bp)

    assert bp == group[0], \
        "BlueprintGroup item should be return the same value as it's blueprint."

    assert bp == group[:][0], \
        "BlueprintGroup item should return the same value after slicing."

    assert bp == group[0:][0], \
        "BlueprintGroup item should return the same value after slicing with " \
        "lower bound."


# Generated at 2022-06-24 03:31:04.305310
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.extend([bp3, bp4])
    assert [bp3, bp4] == list(bpg.__iter__())
    assert isinstance(bpg.__iter__(), list)
    assert isinstance(bpg.__iter__(), type(bpg))


# Generated at 2022-06-24 03:31:14.195587
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    assert([bp for bp in bpg] == [bp1, bp2, bp3, bp4])

# Generated at 2022-06-24 03:31:15.738418
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    pass


# Generated at 2022-06-24 03:31:21.457239
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    # Arrange
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix='/api')

    # Act
    bpg.append(bp1)
    bpg.append(bp2)

    # Assert
    assert bpg[0] == bp1
    assert bpg[1] == bp2


# Generated at 2022-06-24 03:31:27.960395
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.insert(0, bp2)

    assert bpg.blueprints[0] == bp2
    assert bpg.blueprints[1] == bp1


# Generated at 2022-06-24 03:31:32.428779
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    from sanic import Blueprint
    bp = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp)
    bpg[0] = bp2
    assert bpg[0] == bp2


# Generated at 2022-06-24 03:31:39.057544
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    @sanic.blueprint(url_prefix="/bp1")
    def bp1():
        pass

    @sanic.blueprint(url_prefix="/bp2")
    def bp2():
        pass

    bpg = BlueprintGroup(url_prefix="/bp3")
    bpg.append(bp1)

    assert len(bpg) == 1
    assert next(iter(bpg)) == bp1
    bpg.append(bp2)
    assert len(bpg) == 2
    assert [item for item in bpg][1] == bp2



# Generated at 2022-06-24 03:31:43.131784
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bpg) == 2
    bpg.__delitem__(0)
    assert len(bpg) == 1

# Generated at 2022-06-24 03:31:53.497951
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2, url_prefix='/bp', version='1.0')
    assert bpg._blueprints == [bp1, bp2]
    assert bpg._url_prefix == '/bp'
    assert bpg._version == '1.0'
    bpg = BlueprintGroup(bp1, bp2, version='1.0')
    assert bpg._blueprints == [bp1, bp2]
    assert bpg._url_prefix is None
    assert bpg._version == '1.0'
    bpg = BlueprintGroup(bp1, bp2, url_prefix='/bp')
    assert bpg._blue

# Generated at 2022-06-24 03:32:03.335365
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    def foo(request):
        pass

    class SanicMock(object):
        def __init__(self):
            self.blueprints = []

    app = SanicMock()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.middleware(foo)
    assert len(bpg) == 2
    assert len(bp1.middlewares) == 1
    assert len(bp2.middlewares) == 1

# Generated at 2022-06-24 03:32:12.873352
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix='/api', version='v1')
    bpg.append(bp1)
    assert bpg[0] == bp1
    bpg.insert(1, bp2)
    assert bpg[1] == bp2
    bpg[1] = bp3
    assert bpg[1] == bp3
    bpg.append(bp4)
    assert bpg[-1] == bp4
    assert bpg[2] == bp

# Generated at 2022-06-24 03:32:22.434409
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp3.version = "v1"
    bp3.strict_slashes = True
    bp4 = Blueprint("bp4", url_prefix="/bp4")
    bpg = BlueprintGroup(url_prefix="/api", version="v1", strict_slashes=True)
    bpg.append(bp1)
    bpg.append(bp2)
    bpg[0] = bp3
    bpg[1] = bp4
    assert bpg.url_prefix == "/api"
    assert bpg.version == "v1"
    assert bpg.strict_sl

# Generated at 2022-06-24 03:32:30.558139
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    app = sanic.Sanic()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix="/api")
    bpg.insert(0, bp2)
    bpg.insert(1, bp1)
    assert bpg.blueprints[0].url_prefix == '/api/bp2'
    assert bpg.blueprints[1].url_prefix == '/api/bp1'
    assert bpg.url_prefix == '/api'


# Generated at 2022-06-24 03:32:36.864533
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    group = BlueprintGroup("/api", version="v1")
    group.extend([bp1, bp2])

    @group.middleware("request")
    async def bp1_only_middleware(request):
        print("applied on Blueprint Group")

    print(len(bp1.middlewares))
    assert len(bp1.middlewares) == 1

    print(len(bp2.middlewares))
    assert len(bp2.middlewares) == 1

# Generated at 2022-06-24 03:32:48.451718
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')

    bg1 = BlueprintGroup()
    bg2 = BlueprintGroup()

    bg1.append(bp1)
    bg1.insert(0, bp2)

    bg2.append(bp1)
    bg2.insert(0, bp2)
    bg2.insert(1, bp3)

    assert len(bg1) == 2
    assert type(bg1[0]) == Blueprint
    assert type(bg1[1]) == Blueprint
    assert bg1[0].url_prefix == '/bp2'
    assert bg1[1].url

# Generated at 2022-06-24 03:32:54.867820
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint1 = Blueprint(__name__, url_prefix="/blueprint1")
    blueprint2 = Blueprint(__name__, url_prefix="/blueprint2")
    blueprint3 = Blueprint(__name__, url_prefix="/blueprint3")
    blueprint_group = BlueprintGroup(url_prefix="/bp_group")
    blueprint_group.extend([blueprint1, blueprint2, blueprint3])
    blueprint_group_iterator = blueprint_group.__iter__()
    assert blueprint1 is next(blueprint_group_iterator)
    assert blueprint2 is next(blueprint_group_iterator)
    assert blueprint3 is next(blueprint_group_iterator)



# Generated at 2022-06-24 03:33:02.463330
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(None, version='v1')
    assert len(bpg) == 0
    bpg.append(bp1)
    assert len(bpg) == 1
    assert bpg[0].url_prefix == '/bp1'
    assert bpg[0].version == 'v1'
    bpg.append(bp2)
    assert len(bpg) == 2
    assert bpg[1].url_prefix == '/bp2'

# Generated at 2022-06-24 03:33:12.992411
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)



# Generated at 2022-06-24 03:33:18.763631
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bp = BlueprintGroup(bp1, bp2)

    @bp.middleware("request")
    async def middleware(request):
        pass

    assert("REQUEST" in bp1.middlewares)
    assert("REQUEST" in bp2.middlewares)


# Generated at 2022-06-24 03:33:22.349661
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    BlueprintGroup()
    BlueprintGroup("/test")
    BlueprintGroup("/test", "v1")
    BlueprintGroup("/test", "v1", True)
    BlueprintGroup("/test", "v1", False)


# Generated at 2022-06-24 03:33:30.779762
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix='/')
    assert bpg.append(bp1) == None
    assert bpg.append(bp2) == None
    assert bpg[0] == bp1
    assert bpg[1] == bp2


# Generated at 2022-06-24 03:33:37.026414
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp1.url_prefix = '/bp1'
    bp2.url_prefix = '/bp2'
    bpg1 = BlueprintGroup(url_prefix='/bpg1')
    bpg1.append(bp1)
    bpg1.append(bp2)
    assert bpg1[0] == bp1
    assert bpg1[1] == bp2


# Generated at 2022-06-24 03:33:48.192153
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    assert(BlueprintGroup(None).__class__.__name__=='BlueprintGroup')
    assert(BlueprintGroup(None)._blueprints==[])
    assert(BlueprintGroup(None)._url_prefix==None)
    assert(BlueprintGroup(None)._version==None)
    assert(BlueprintGroup(None)._strict_slashes==None)
    assert(BlueprintGroup('a', '1', True)._url_prefix=='a')
    assert(BlueprintGroup('a', '1')._version=='1')
    assert(BlueprintGroup('a', '1')._strict_slashes==None)
    assert(BlueprintGroup('a', '1', True)._strict_slashes==True)
    assert(BlueprintGroup()._url_prefix==None)

# Generated at 2022-06-24 03:33:53.185150
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    # pylint: disable=W0212
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    assert bg._blueprints == [bp1, bp2]
    assert bg.url_prefix == "/api"
    assert bg.version == "v1"
    assert bg.strict_slashes is None


# Generated at 2022-06-24 03:34:02.787065
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    app = sanic.Sanic("test_BlueprintGroup_insert")
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.insert(0, bp1)
    bpg.insert(0, bp2)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-24 03:34:10.778498
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp1_b = Blueprint('bp1', url_prefix='/bp1')
    bp2_b = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    assert bpg.blueprints == [bp1, bp2]
    bpg.append(bp1_b)
    bpg.append(bp2_b)
    assert bpg.blueprints == [bp1, bp2, bp1_b, bp2_b]


# Generated at 2022-06-24 03:34:12.356808
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    assert BlueprintGroup()


# Unit Test for Property : url_prefix

# Generated at 2022-06-24 03:34:23.020161
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    items = [1, 2, 3, 4, 5]
    bpg_middleware_flag = False

    @bp1.middleware('response')
    async def bp1_middleware(request):
        items.append(6)
        return None

    @bp2.middleware('response')
    async def bp2_middleware(request):
        items.append(7)
        return None

    @sanic.response.json
    async def bp1_handler(request):
        return {'items': items}


# Generated at 2022-06-24 03:34:29.361772
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    assert list(bpg) == [bp1, bp2]



# Generated at 2022-06-24 03:34:39.006808
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg[0] == bp1 and bpg[1] == bp2
    assert len(bpg) == 2

    bpg[0] = bp3
    assert bpg[0] == bp3
    assert len(bpg) == 2


# Generated at 2022-06-24 03:34:47.447023
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    """
        Unit test for method __len__ of class BlueprintGroup
    """
    bpg = BlueprintGroup()
    assert len(bpg) == 0

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg) == 2

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg.append(bp3)
    bpg.append(bp4)
    assert len(bpg) == 4

    bpg.pop()
    assert len(bpg) == 3


# Generated at 2022-06-24 03:34:54.644885
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint = Blueprint('test_blueprint', url_prefix='/test')
    blueprint_group = BlueprintGroup(url_prefix='/test_group')
    blueprint_group.append(blueprint)
    blueprint_group.append(blueprint)
    blueprint_group.append(blueprint)
    blueprint_group.append(blueprint)
    assert len(blueprint_group) == 4, "test_BlueprintGroup___len__() failed"
