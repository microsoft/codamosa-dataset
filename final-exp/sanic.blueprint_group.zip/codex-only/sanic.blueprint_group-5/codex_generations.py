

# Generated at 2022-06-24 03:25:00.232853
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    # Arrange
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    # Act
    actual = bpg[0]

    # Assert
    assert actual is bp3


# Generated at 2022-06-24 03:25:07.408226
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    Blueprint(url_prefix='/bp1')
    Blueprint(url_prefix='/bp2')
    Blueprint(url_prefix='/bp3')
    Blueprint(url_prefix='/bp4')

    bpg = BlueprintGroup()

    bpg._blueprints = [Blueprint(url_prefix='/bp1'), Blueprint(url_prefix='/bp1')]

    del bpg[0]
    assert bpg._blueprints == [Blueprint(url_prefix='/bp1')]


# Generated at 2022-06-24 03:25:15.748897
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    app = sanic.Sanic()

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp3)
    bpg.insert(0, bp1)
    bpg.append(bp2)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')


# Generated at 2022-06-24 03:25:21.475183
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix='/api', version=1.0)
    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg[0] == bp1
    assert bpg[1] == bp2



# Generated at 2022-06-24 03:25:28.565125
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    """
    test_BlueprintGroup___delitem__
    """

    bp = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp)
    bp.route('/')(lambda r: text('OK'))

    @bp2.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    bp2.route('/')(lambda r: text('OK'))
    group.append(bp2)
    assert len(group) == 2
    del group[0]
    assert len(group) == 1
    del group[0]
    assert len(group) == 0



# Generated at 2022-06-24 03:25:32.378213
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprintgroup = BlueprintGroup(url_prefix='/bp1', version='v1')
    assert blueprintgroup.url_prefix == '/bp1'
    assert blueprintgroup.version == 'v1'


# Generated at 2022-06-24 03:25:36.210186
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group = BlueprintGroup()
    blueprint_group.append(sanic.Blueprint("test"))
    blueprint_group.append(sanic.Blueprint("test1"))
    blueprint_group.append(sanic.Blueprint("test2"))
    assert len(blueprint_group) == 3


# Generated at 2022-06-24 03:25:44.931228
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    group = Blueprint.group(bp1, bp2)

    assert group[0] == group.blueprints[0]
    assert group[1] == group.blueprints[1]
    assert bpg[0] == bpg.blueprints[0]
    assert bpg[1] == bpg.blueprints[1]
    assert bpg[0] == bp3

# Generated at 2022-06-24 03:25:54.426244
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix='/api', version='v1')
    bpg.append(bp3)
    bpg.append(bp4)
    bpg1 = BlueprintGroup(bp1, bp2)
    bpg1.append(bpg)
    assert bpg1[0] == bp1
    assert bpg1[1] == bp2
    assert bpg1[2] == bpg
    assert bpg1[2][0] == bp3
    assert b

# Generated at 2022-06-24 03:25:57.991702
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    app = sanic.Sanic()
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    for i, bp in enumerate(bpg):
        assert bp == bpg[i]

# Generated at 2022-06-24 03:26:03.734157
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1', version="v1")
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2', version="v2")
    bp3 = sanic.Blueprint('bp3', url_prefix='/bp3', version="v3")
    bp4 = sanic.Blueprint('bp4', url_prefix='/bp4', version="v4")

    BlueprintGroup()



# Generated at 2022-06-24 03:26:10.110354
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    bp3 = Blueprint('bp3', url_prefix='/bp3')

    bpg[2] = bp3
    assert bpg[2] == bp3


# Generated at 2022-06-24 03:26:15.917037
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bpg) == 2
    assert bp1 in bpg.blueprints
    assert bp2 in bpg.blueprints



# Generated at 2022-06-24 03:26:19.249487
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")

    bpg = BlueprintGroup()
    bpg.append(bp1)

    bpg.insert(1, bp2)
    assert bpg._blueprints[1] == bp2

# Generated at 2022-06-24 03:26:29.454445
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    test_url_prefix = "test"
    test_strict_slashes = True
    test_version = "1.0"
    bpg = BlueprintGroup(
        url_prefix=test_url_prefix,
        version=test_version,
        strict_slashes=test_strict_slashes
    )
    bp1 = sanic.blueprints.Blueprint("bp1", url_prefix="/bp1", version=None)
    bp2 = sanic.blueprints.Blueprint("bp2", url_prefix="/bp2", version=None)

    bpg.append(bp1)
    assert len(bpg) == 1
    assert bpg[0] == bp1

    bpg[0] = bp2
    assert len(bpg) == 1
    assert bpg[0] == bp

# Generated at 2022-06-24 03:26:36.368808
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    """
    Unit test for method __len__ of class BlueprintGroup
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bpg) == 2


# Generated at 2022-06-24 03:26:38.894498
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    group = BlueprintGroup()
    group.append(Blueprint("bp1"))
    group.append(Blueprint("bp2"))
    assert len(group) == 2


# Generated at 2022-06-24 03:26:43.579452
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    """
    This unit test case is dedicated to test the functionality of the
    BlueprintGroup constructor.
    """
    bpg = BlueprintGroup(url_prefix="/prefix", version="v1")
    assert bpg.url_prefix == "/prefix", f"Invalid URL Prefix : {bpg.url_prefix}"
    assert bpg.version == "v1", f"Invalid Version : {bpg.version}"



# Generated at 2022-06-24 03:26:53.690225
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)
    bpg.append(bp3)
    bpg.append(bp2)

    # Let's add the blueprint in the middle
    bpg.insert(1, bp4)

    assert list(bpg.blueprints) == [bp1, bp4, bp3, bp2]


# Generated at 2022-06-24 03:26:56.163792
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    group = BlueprintGroup()
    group.append(Blueprint("bp1"))
    assert len(group) == 1
    assert group[0].name == "bp1"
    assert group[0].url_prefix is None


# Generated at 2022-06-24 03:27:03.916983
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup('/api', 'v1',strict_slashes=False)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text

# Generated at 2022-06-24 03:27:14.259321
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")
    bpg = BlueprintGroup("/api")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    assert len(bpg) == 4
    del bpg[0]
    assert len(bpg) == 3
    assert bpg[0] == bp2


# Generated at 2022-06-24 03:27:24.267823
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    app = sanic.Sanic('test_BlueprintGroup_insert')
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    try:
        bpg.append(bp3)
        bpg.insert(1, bp4)
    except:
        assert False
    assert bpg[1].url_prefix == '/bp4'
    assert bpg[2].url_prefix == '/bp2'


# Generated at 2022-06-24 03:27:28.089449
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bpg = BlueprintGroup(url_prefix='/bp1')
    assert bpg.url_prefix == '/bp1'



# Generated at 2022-06-24 03:27:34.788809
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix='/api')
    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg[0] == bp1
    assert bpg[1] == bp2


# Generated at 2022-06-24 03:27:43.669709
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    @BlueprintGroup.middleware('request')
    async def bpg_middleware(request):
        print('apply on Blueprint Group')

    bpg = BlueprintGroup(url_prefix='/group',version='v1')

    for i in range(5):
        bp = Blueprint('bp_%s' % i, url_prefix='/bp_%s' % i)
        @bp.middleware('request')
        async def bp_middleware(request):
            print('applied for bp %s' % i)

        @bp.route('/')
        async def bp_route(request, param):
            return text(param)
        bpg.append(bp)

    # Register Blueprint group under the app
    app.blueprint(bpg)
    test_client = app.test_client

    # middleware

# Generated at 2022-06-24 03:27:48.178043
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():

    # Mock a blueprint instance for testing.
    blueprint = Blueprint(__name__, url_prefix='/bp1')
    blueprint_group = BlueprintGroup()
    blueprint_group.append(blueprint)

    assert blueprint == blueprint_group[0]
    assert type(blueprint_group[0]) is Blueprint

# Generated at 2022-06-24 03:27:49.700722
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    BlueprintGroup().__delitem__(0)


# Generated at 2022-06-24 03:27:59.663400
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version=None, strict_slashes=None)
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    assert len(bpg) == 4
    bpg.insert(2, bp1)
    assert len(bpg) == 5


# Generated at 2022-06-24 03:28:03.399249
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_instance = BlueprintGroup('', '', False)

    blueprint_instance = Blueprint('bp1', url_prefix='/bp1')

    blueprint_group_instance[:] = [blueprint_instance]
    assert blueprint_group_instance.blueprints == [blueprint_instance]



# Generated at 2022-06-24 03:28:10.264831
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    """
    Test for method __iter__ of class BlueprintGroup
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert list(bpg.__iter__()) == [bp1, bp2]


# Generated at 2022-06-24 03:28:20.695977
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()

    class CustomMiddleware:
        def __init__(self):
            self.applied = False

        async def __call__(self, request):
            self.applied = True

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)


# Generated at 2022-06-24 03:28:26.796584
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group = BlueprintGroup()
    blueprint1 = Blueprint('bp1', url_prefix='/bp1')
    blueprint2 = Blueprint('bp2', url_prefix='/bp2')
    blueprint3 = Blueprint('bp3', url_prefix='/bp3')

    blueprint_group.append(blueprint1)
    blueprint_group.append(blueprint2)
    blueprint_group.append(blueprint3)

    assert len(blueprint_group) == 3


# Generated at 2022-06-24 03:28:32.071906
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    group = Blueprint.group(bp1, bp2)
    group.append(bp3)
    group.append(bp4)
    assert len(group) == 4


# Generated at 2022-06-24 03:28:38.697617
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    @sanic.Blueprint.group(url_prefix='/test')
    def test_blueprint_group():
        pass

    bp1 = sanic.Blueprint('bp1')
    bp2 = sanic.Blueprint('bp2')

    test_blueprint_group.append(bp1)
    test_blueprint_group.append(bp2)

    assert test_blueprint_group.url_prefix == '/test'
    assert test_blueprint_group.blueprints[0] == bp1
    assert test_blueprint_group.blueprints[1] == bp2


# Generated at 2022-06-24 03:28:46.460927
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg_1 = BlueprintGroup.group(bp3, bp4)
    bpg_2 = BlueprintGroup.group(bp1, bp2, bpg_1)
    @bpg_2.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')
    assert len(bp1.request_middleware) == 1
    assert len(bp2.request_middleware) == 1

# Generated at 2022-06-24 03:28:58.089807
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic(__name__)

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)


# Generated at 2022-06-24 03:29:09.264374
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    assert bpg.url_prefix == "/api"
    assert bpg.version == "v1"
    assert bpg.strict_slashes is None
    assert bp1.url_prefix == "/api/bp1"
    assert bp2.url_prefix == "/api/bp2"
    assert bp1.version == "v1"
    assert bp2.version == "v1"
    assert bp1.strict_slashes is None
    assert bp2.strict_slashes is None


# Generated at 2022-06-24 03:29:16.901751
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp_group = BlueprintGroup()
    test_bp = Blueprint("test", url_prefix="/test_bp")

    bp_group.append(test_bp)

    assert isinstance(bp_group, BlueprintGroup)
    assert isinstance(bp_group[0], Blueprint)
    assert bp_group[0].name == "test"
    assert bp_group[0].url_prefix == "/test_bp"


# Generated at 2022-06-24 03:29:25.474604
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic import Blueprint
    from functools import partial
    from sanic.response import HTTPResponse

    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bp3 = Blueprint('bp3')
    bp4 = Blueprint('bp4')

    bpg = BlueprintGroup(bp3, bp4, "url_prefix", "v1")

    middleware_fn_list = []

    @bp3.middleware("response")
    def bp3_response_middleware(request, response: HTTPResponse):
        middleware_fn_list.append("bp3_response_middleware")


# Generated at 2022-06-24 03:29:31.253227
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    
    assert len(bp1) == 0
    assert len(bp2) == 0
    
    bp1.append(bp2)
    assert len(bp1) == 1
    assert len(bp2) == 0
    
    

# Generated at 2022-06-24 03:29:36.789897
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()
    bpg.append(bp2)
    bpg.append(bp1)

    assert len(bpg) == 2

    group_blueprints = bpg.blueprints

    assert group_blueprints[0] == bp2
    assert group_blueprints[1] == bp1



# Generated at 2022-06-24 03:29:47.280407
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg1 = BlueprintGroup(bp1, bp2, url_prefix="api", version="v1")
    bpg2 = BlueprintGroup(bp3, bp4, url_prefix="api", version="v2")

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)


# Generated at 2022-06-24 03:29:50.876896
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    group = BlueprintGroup(url_prefix="api/v1", version="v1", strict_slashes=False)
    assert group.url_prefix == "api/v1"
    assert group._version == "v1"
    assert group._strict_slashes == False
    assert group._blueprints == []

# Unit test to check the append method of class BlueprintGroup

# Generated at 2022-06-24 03:29:59.023919
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    
    # Test Blueprint.group
    group = Blueprint.group(bp1, bp2, url_prefix="/api", version="v1")
    
    assert len(group) == 2
    


# Generated at 2022-06-24 03:30:03.626569
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    # Simple constructor test
    bpg = BlueprintGroup(url_prefix="/api", version="v1", strict_slashes=True)
    assert bpg.url_prefix == "/api"
    assert bpg.version == "v1"
    assert bpg.strict_slashes is True
    assert len(bpg.blueprints) == 0

# Unit test to test the append method

# Generated at 2022-06-24 03:30:11.816701
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/test1')
    bp2 = Blueprint('bp2')

    group = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    assert len(group.blueprints) == 2
    assert group.url_prefix == "/api"
    assert group.version == "v1"
    assert bp1.url_prefix == "/api/test1"
    assert bp2.url_prefix == "/api/bp2"
    assert bp1.version == "v1"
    assert bp2.version == "v1"


# Generated at 2022-06-24 03:30:20.372693
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-24 03:30:26.302536
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = sanic.Blueprint("bp1")
    bp2 = sanic.Blueprint("bp2")
    bp3 = sanic.Blueprint("bp3")
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    assert list(bpg) == [bp1, bp2, bp3]


# Generated at 2022-06-24 03:30:34.603387
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bpGroup = BlueprintGroup("/", 1, False)

    # Comparing the len of bpGroup and the list of blueprints
    assert len(bpGroup) == len(bpGroup.blueprints)

    # Before appending the blueprints, len of bpGroup is 0
    assert len(bpGroup) == 0

    # Appending bp1
    bpGroup.append(bp1)

    # After appending the bp1, len of bpGroup should be 1
    assert len(bpGroup) == 1

    # Appending bp2
    bpGroup.append(bp2)

    # After appending the bp2, len of bpGroup should be 2
   

# Generated at 2022-06-24 03:30:44.680727
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
   # Setup
   bp1 = Blueprint('bp1', url_prefix='/bp1')
   bp2 = Blueprint('bp2', url_prefix='/bp2')
   bp3 = Blueprint('bp3', url_prefix='/bp3')
   bp4 = Blueprint('bp4', url_prefix='/bp4')
   bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
   # Test
   bpg[0] = bp3
   bpg[1] = bp4
   # Verify
   assert bpg[0].url_prefix == '/api/bp3'
   assert bpg[1].url_prefix == '/api/bp4'


# Generated at 2022-06-24 03:30:55.491878
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    assert bp1.url_prefix == '/bp1'
    assert bp2.url_prefix == '/bp2'
    assert bp3.url_prefix == '/bp3'

    bpg = BlueprintGroup(url_prefix='/api', version=1)
    assert bpg.url_prefix == '/api'
    assert bpg.version == 1
    bpg.append(bp2)
    bpg.append(bp1)

    assert bp1 in bpg
    assert bp2 in bpg
    assert bp3 not in bpg

# Generated at 2022-06-24 03:31:04.591842
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    # Instanciation of class BlueprintGroup
    return_value_BlueprintGroup___init__ = BlueprintGroup(
        url_prefix=None, version=None, strict_slashes=None
    )
    # intialization of variable 'item'
    item = None

    # Call method __delitem__ of class BlueprintGroup
    return_value___delitem__ = object.__delitem__(
        return_value_BlueprintGroup___init__, item
    )
    return_value_vr___delitem__ = return_value___delitem__
    assert (
        return_value_vr___delitem__ == return_value___delitem__
    ), f"{'return_value_vr___delitem__'} != {'return_value___delitem__'}"
    # Unit test for method __getitem__ of class BlueprintGroup

# Generated at 2022-06-24 03:31:07.134399
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bpg = BlueprintGroup()
    bpg.append(None)
    assert list(bpg) == [None]


# Generated at 2022-06-24 03:31:17.462154
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg1 = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    bpg2 = BlueprintGroup(bp2, url_prefix="/api", version="v1")
    bpg3 = BlueprintGroup(bp1, url_prefix="/api", version="v1")

    bpg1.insert(0, bpg2)
    bpg1.insert(0, bpg3)
    bpg1.insert(1, bp1)


# Generated at 2022-06-24 03:31:27.710203
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    bpg.append(bp5)

    assert(len(bpg) == 5)
    del bpg[0]
    assert(len(bpg) == 4)
    del bpg[0]

# Generated at 2022-06-24 03:31:36.049298
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    b = BlueprintGroup('bp1', url_prefix='/bp1')
    b.append(Blueprint(name='v1', url_prefix='/v1'))
    b.append(Blueprint(name='v2', url_prefix='/v2'))
    b.__setitem__(1, Blueprint(name='v3', url_prefix='/v3'))
    assert len(b.blueprints) == 2
    assert b.blueprints[1].name == 'v3'


# Generated at 2022-06-24 03:31:41.572548
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    class test:
        _blueprints = []
        _url_prefix = None
        _version = None
        _strict_slashes = None
    bg = BlueprintGroup
    bg._blueprints = []
    t = sanic.Blueprint("test")
    bg.append(t)
    assert bg._blueprints[0] == t

# Generated at 2022-06-24 03:31:45.916228
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    """
    This test is created to ensure that creating an instance of `BlueprintGroup`
    doesn't throw any validation error.
    """
    # Test to ensure that BlueprintGroup is not throwing any error
    BlueprintGroup()
    BlueprintGroup(url_prefix='/api', version="v1", strict_slashes=True)

# Generated at 2022-06-24 03:31:48.828909
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    test_object = BlueprintGroup(None)
    test_object.append(2)
    del test_object[0]
    assert test_object._blueprints == []


# Generated at 2022-06-24 03:31:56.032099
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix='/api', version='v1')

    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg[0] is bp1
    assert bpg[1] is bp2

    bpg[1] = bp3
    assert bpg[1] is bp3

    bpg[0] = bp4
    assert bpg[0] is bp4

    bpg[0:2] = bp4


# Generated at 2022-06-24 03:32:06.313092
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    @sanic.blueprint.group()
    def _g():
        @sanic.blueprint.Blueprint.group()
        def _g1():
            return [Blueprint('bp5', url_prefix='/bp5'), Blueprint('bp6', url_prefix='/bp6')]
        return [Blueprint.group(Blueprint('bp1', url_prefix='/bp1'), Blueprint('bp2', url_prefix='/bp2')), Blueprint('bp3', url_prefix='/bp3'), _g1(), Blueprint('bp4', url_prefix='/bp4')]

    bp = _g()
    assert(bp[0] == bp[0][0])
    assert(bp[0] == bp[0][1])
    assert(bp[1] == bp[1])

# Generated at 2022-06-24 03:32:15.409602
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from unittest.mock import MagicMock
    from sanic.response import text, json
    from .base import SanicTestClient

    app = sanic.Sanic(__name__) # pylint: disable=invalid-name
    blueprint = Blueprint("test_blueprint_group_middleware", url_prefix="/test") # pylint: disable=invalid-name
    blueprint_group = BlueprintGroup(blueprint) # pylint: disable=invalid-name

    @blueprint.route("/")
    async def handler(request): # pylint: disable=unused-variable
        return text("OK")

    assert blueprint_group.middleware(MagicMock)() is None

    app.blueprint(blueprint_group)

    request, response = SanicTestClient.get(app, "/test/")



# Generated at 2022-06-24 03:32:21.787156
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp3 = Blueprint('bp3', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-24 03:32:29.581316
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.insert(0,bp2)
    assert bpg[0].url_prefix == '/bp2'
    assert bpg[1].url_prefix == '/bp1'
    assert bpg[2].url_prefix == '/bp2'
    assert len(bpg) == 3

# Generated at 2022-06-24 03:32:37.210854
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    class MockBlueprint:
        def __init__(self):
            self.url_prefix = "v1"
            self.version = "1.0"
            self.strict_slashes = True

    bp1 = MockBlueprint()
    bp2 = MockBlueprint()
    bp3 = MockBlueprint()

    bpg = BlueprintGroup("/api", version="1.0", strict_slashes=True)
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)

    assert bp1 in bpg
    assert bp2 in bpg
    assert bp3 in bpg


# Generated at 2022-06-24 03:32:43.011615
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__(): # noqa: E501
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)
    
    assert group[0] == bp1
    assert group[1] == bp2


# Generated at 2022-06-24 03:32:50.252897
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="")

    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bpg) == 2
    assert bpg[0] == bp1
    assert bpg[1] == bp2


#Unit test for method __setitem__ of class BlueprintGroup

# Generated at 2022-06-24 03:32:55.613848
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
	"""
	test __setitem__ method of class BlueprintGroup
	"""
	blueprint_group = BlueprintGroup()
	app = sanic.Sanic(__name__)
	blueprint_group.append(app)
	assert blueprint_group[0] == app

	blueprint_group[0] = "test_setitem_str"
	assert blueprint_group[0] == "test_setitem_str"

# Generated at 2022-06-24 03:32:56.494272
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    pass


# Generated at 2022-06-24 03:32:57.238733
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    pass

# Generated at 2022-06-24 03:33:07.595133
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    App = sanic.Sanic()
    bp1 = Blueprint('bp1', url_prefix='/bp1', version=1.0)
    bp2 = Blueprint('bp2', url_prefix='/bp2', version=1.0)
    bp3 = Blueprint('bp3', url_prefix='/bp3', version=1.0)
    bp4 = Blueprint('bp4', url_prefix='/bp4', version=1.0)
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')


# Generated at 2022-06-24 03:33:12.227171
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bps = BlueprintGroup()
    bps.append(bp1)
    bps.insert(0, bp2)
    assert bps[0] == bp2

# Generated at 2022-06-24 03:33:24.450464
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic(__name__)
    bp = Blueprint('bp', url_prefix='/bp')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = BlueprintGroup()
    group.append(bp)
    group.append(bp2)

    counter = 0

    @group.middleware
    async def testmiddleware(request):
        nonlocal counter
        counter += 1

    @bp.route('/test1')
    async def test1(request):
        return text('OK')

    @bp2.route('/test2')
    async def test2(request):
        return text('OK')

    request, response = app.test_client.get('/bp/test1')
    assert response.status == 200
    assert counter == 1


# Generated at 2022-06-24 03:33:32.836309
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)
    bpg.append(bp2)

    bpg[0] = bp2
    bpg[1] = bp1

    assert( bpg[0] == bp2 )
    assert( bpg[1] == bp1 )

# Generated at 2022-06-24 03:33:42.589931
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    def _test_assert(group, index, expected_value):
        value = group[index]
        assert value.name == expected_value

    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bp3 = Blueprint("bp3")
    bp4 = Blueprint("bp4")
    bp5 = Blueprint("bp5")
    bp6 = Blueprint("bp6")
    bp7 = Blueprint("bp7")
    bp8 = Blueprint("bp8")

    bp_list = [bp1, bp2, bp3, bp4, bp5, bp6, bp7, bp8]
    for bp in bp_list:
        group = BlueprintGroup(bp)
        _test_assert(group, 0, bp.name)

    group

# Generated at 2022-06-24 03:33:50.934487
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = sanic.blueprints.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.blueprints.Blueprint('bp2', url_prefix='/bp2')
    bp3 = sanic.blueprints.Blueprint('bp3', url_prefix='/bp3')
    bp4 = sanic.blueprints.Blueprint('bp4', url_prefix='/bp4')
    bp_group = BlueprintGroup()
    bp_group.append(bp1)
    assert bp_group.blueprints == [bp1], "Error: Method __setitem__ has failed"
    bp_group.append(bp2)
    assert bp_group.blueprints == [bp1, bp2], "Error: Method __setitem__ has failed"
    bp_group

# Generated at 2022-06-24 03:33:57.801285
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bpg = BlueprintGroup()
    bpg.append(Blueprint('test1', url_prefix='/test1'))
    bpg.append(Blueprint('test2', url_prefix='/test2'))
    bpg.append(Blueprint('test3', url_prefix='/test3'))
    assert len(bpg) == 3
    assert bpg[2].name == 'test3'
    del bpg[2]
    assert len(bpg) == 2
    assert bpg[1].name == 'test2'



# Generated at 2022-06-24 03:34:00.138548
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bg = BlueprintGroup(url_prefix="/api", version="v1", strict_slashes=True)
    assert bg.url_prefix == "/api"
    assert bg.version == "v1"
    assert bg.strict_slashes is True



# Generated at 2022-06-24 03:34:05.420226
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp = Blueprint(name="test")

    assert len(bp) == 0, f"BlueprintGroup length is {len(bp)}. Expected is 0"

    bp.add_route(lambda a: a, uri="/", methods=["GET"])
    assert len(bp) == 1, f"BlueprintGroup length is {len(bp)}. Expected is 1"

    bp.add_route(lambda a: a, uri="/", methods=["POST"])
    assert len(bp) == 2, f"BlueprintGroup length is {len(bp)}. Expected is 2"


# Generated at 2022-06-24 03:34:16.364525
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bg = BlueprintGroup()
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bp3 = Blueprint("bp3")
    bp4 = Blueprint("bp4")
    assert len(bg) == 0
    bg.append(bp1)
    bg.append(bp2)
    bg.append(bp3)
    bg.append(bp4)
    assert len(bg) == 4
    assert bg[0] == bp1
    assert bg[1] == bp2
    assert bg[2] == bp3
    assert bg[3] == bp4
    assert bg.blueprints == [bp1, bp2, bp3, bp4]



# Generated at 2022-06-24 03:34:24.473489
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert len(bpg) == 2
    assert bpg.url_prefix == "/api"
    assert bpg.version == "v1"
    assert bpg.strict_slashes is None


# Generated at 2022-06-24 03:34:32.629020
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class _Middleware:
        def __init__(self):
            self.applied_middleware_count = 0
            self.matched_blueprint_name = None

        async def __call__(self, request):
            self.matched_blueprint_name = request.blueprint_name
            self.applied_middleware_count += 1

    middleware = _Middleware()

    app = sanic.Sanic(__name__)

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')


# Generated at 2022-06-24 03:34:43.093483
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint("bp1", url_prefix="/bp1", strict_slashes=False)

    bp1.version = "v1"

    bp2 = Blueprint("bp2", url_prefix="/bp2", strict_slashes=False)
    bp2.version = "v1"

    bp3 = Blueprint("bp3", url_prefix="/bp3", strict_slashes=False)
    bp3.version = "v1"

    bg = BlueprintGroup(url_prefix="/api")

    bg.insert(0, bp1)
    bg.insert(1, bp2)
    bg.insert(2, bp3)

    assert bg[2] == bp3


# Generated at 2022-06-24 03:34:49.185097
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    """
    This test will verify the delitem method of BlueprintGroup class.
    """
    blueprint_group = BlueprintGroup()
    blueprint = Blueprint("bp1", url_prefix="/bp1")
    blueprint_group.append(blueprint)
    del blueprint_group[0]
    assert len(blueprint_group) == 0


# Generated at 2022-06-24 03:34:55.297401
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class TestBlueprints():
        def __init__(self):
            self.called = 0
            self.bp = Blueprint('bp', url_prefix='/')
            self.bp_group = BlueprintGroup(self.bp, url_prefix='/')

        @self.bp_group.middleware('response')
        async def middleware(request):
            self.called = 1

    bp = TestBlueprints()
    assert bp.bp.middleware_stack[0] == bp.middleware
    assert bp.called == 0

