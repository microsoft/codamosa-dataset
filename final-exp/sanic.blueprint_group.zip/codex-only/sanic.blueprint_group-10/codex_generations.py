

# Generated at 2022-06-24 03:24:52.823724
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group = BlueprintGroup()
    blueprint = Blueprint('test_blueprint', url_prefix='/test')
    blueprint_group.append(blueprint)

    @blueprint_group.middleware('request')
    async def test_middleware(request):
        pass

    assert test_middleware in blueprint.middlewares['request']



# Generated at 2022-06-24 03:25:00.745942
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    del bpg[0]
    assert bp1 not in bpg
    assert bp2 in bpg

    del bpg[0]
    assert bp2 not in bpg


# Generated at 2022-06-24 03:25:11.155884
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')

    bpg1 = BlueprintGroup()
    bpg1.append(bp1)
    bpg1.append(bp2)

    bpg2 = BlueprintGroup()
    bpg2.append(bp1)
    bpg2.append(bp2)

    bpg12 = BlueprintGroup()
    bpg12.append(bpg1)
    bpg12.append(bpg2)

    @bpg12.middleware
    async def middleware1(request):
        request.registry["middleware1"] = True

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-24 03:25:15.734535
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    class TestBlueprint(sanic.Blueprint):
        pass

    test_bp = TestBlueprint('test_bp', url_prefix="/test_bp")
    test_bp.version = 1.0
    test_bp.strict_slashes = False

    test_bpg = BlueprintGroup(test_bp)

    assert test_bpg.url_prefix == "/test_bp"
    assert test_bp.version == 1.0
    assert test_bp.strict_slashes is False

# Generated at 2022-06-24 03:25:21.712081
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)
    iterator = group.__iter__()
    assert next(iterator) == bp1
    assert next(iterator) == bp2


# Generated at 2022-06-24 03:25:27.902023
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg.blueprints) == 2
    assert len(bpg) == 2
    assert bpg[0] == bp1
    assert bpg[1] == bp2



# Generated at 2022-06-24 03:25:38.262383
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    """
        Testcase to validate the method `BlueprintGroup.__setitem__` to
        insert a new Blueprint at a desired index location
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    assert len(bpg) == 0
    bpg.append(bp1)
    assert len(bpg) == 1
    assert bpg[0] == bp1
    bpg.append(bp2)
    assert len(bpg) == 2
    assert bpg[1] == bp2
    bpg.__setitem__(index=1, item=bp1)
    assert bpg[1] == bp1



# Generated at 2022-06-24 03:25:45.733596
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bp3 = Blueprint('bp3')
    bpg = BlueprintGroup()

    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)

    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert bpg[2] == bp3

    assert bpg[-1] == bp3
    assert bpg[-2] == bp2
    assert bpg[-3] == bp1


# Generated at 2022-06-24 03:25:53.112421
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    
    
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    return (len(bpg) == 3, "BlueprintGroup.__len__() failed.")
    
    


# Generated at 2022-06-24 03:26:02.603589
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    assert isinstance(bpg, BlueprintGroup)
    assert isinstance(bpg, MutableSequence)
    assert isinstance(bpg, list)

    assert isinstance(bpg[0], Blueprint)
    assert isinstance(bpg[1], Blueprint)

    # The index to access the individual blueprint is
    # relative to the index position of the blueprint in
    # the original list, NOT the index relative to

# Generated at 2022-06-24 03:26:08.719569
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2)
    assert isinstance(group, BlueprintGroup)
    bp_list = [bp1, bp2]

    for bp, bpg in zip(bp_list, group):
        assert bp == bpg


# Generated at 2022-06-24 03:26:13.632006
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg[0] == bp1
    assert bpg[1] == bp2


# Generated at 2022-06-24 03:26:24.809691
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version=1.0, strict_slashes=True)
    assert bpg.blueprints == [bp1, bp2]
    assert bpg.url_prefix == "/api"
    assert bpg.version == 1.0
    assert bpg.strict_slashes == True
    assert list(bpg) == [bp1, bp2]
    assert bpg[1] == bp2
    assert bpg[0] == bp1
    bp3 = Blueprint('bp3', url_prefix='/bp3')

# Generated at 2022-06-24 03:26:33.519219
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    """
    Verifies if the method __iter__ of class BlueprintGroup is working as
    expected by checking the correct objects are returned using the method
    __iter__.
    """
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert bp1 in bpg
    assert bp2 in bpg


# Generated at 2022-06-24 03:26:43.011210
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')

    bp3 = sanic.Blueprint('bp3', url_prefix='/bp4')
    bp4 = sanic.Blueprint('bp4', url_prefix='/bp4')

    bp5 = sanic.Blueprint('bp5', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    group = BlueprintGroup()

    group.append(bp1)
    group.append(bp2)
    group.append(bpg)

    assert list(group) == [bp1, bp2, bpg]


# Generated at 2022-06-24 03:26:53.917142
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    import sanic
    from sanic.response import text
    from sanic.blueprints import Blueprint

    app = sanic.Sanic('test_BlueprintGroup__delitem__')

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')


# Generated at 2022-06-24 03:27:03.730716
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class DummyBP(sanic.Blueprint):
        def middleware(self, fn, *args, **kwargs):
            setattr(self, "middlewares", getattr(self, "middlewares", list()) + [(fn, args, kwargs)])

    dummy_bp = DummyBP("dummy")
    dummy_bp_group = BlueprintGroup()
    dummy_bp_group.append(dummy_bp)
    dummy_bp_group.middleware(lambda request: "dummy middleware")
    dummy_bp_group.middleware(lambda request: "dummy middleware", attach_to="response")
    assert dummy_bp.middlewares == [(
        lambda request: "dummy middleware", (), {}),
        (lambda request: "dummy middleware", (), {"attach_to": "response"})]

# Generated at 2022-06-24 03:27:11.443797
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    class BlueprintMockSanic(sanic.blueprints.Blueprint):
        pass

    bp1 = BlueprintMockSanic('bp1', url_prefix='/bp1')
    bp2 = BlueprintMockSanic('bp2', url_prefix='/bp2')
    blueprint_group = BlueprintGroup()

    blueprint_group.append(bp1)
    blueprint_group.append(bp2)
    assert len(blueprint_group) == 2


# Generated at 2022-06-24 03:27:17.336348
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bpg = BlueprintGroup()
    bpg.append(Blueprint('bp1', url_prefix='/bp1'))
    bpg.append(Blueprint('bp2', url_prefix='/bp2'))

    expected_result = bpg
    expected_result.blueprints.pop(0)
    del bpg[0]

    assert bpg.blueprints == expected_result.blueprints


# Generated at 2022-06-24 03:27:23.333190
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    test_app = sanic.Sanic()
    cur_bp = Blueprint('bp1', url_prefix='/bp1')
    test_bp = Blueprint('bp2', url_prefix='/bp2')
    test_bpg = BlueprintGroup(url_prefix='/api')
    assert len(test_bpg) == 0
    test_bpg.append(cur_bp)
    assert len(test_bpg) == 1
    assert isinstance(test_bpg[0], Blueprint)
    test_bpg.append(test_bp)
    assert len(test_bpg) == 2
    assert isinstance(test_bpg[1], Blueprint)


# Generated at 2022-06-24 03:27:31.121054
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bp_group = BlueprintGroup(bp3, bp4, url_prefix="/api")

    assert bp_group[0].url_prefix == '/bp3'
    assert bp_group[1].url_prefix == '/bp4'

    bp_group[0] = bp1
    assert bp_group[0].url_prefix == '/bp1'
    assert bp_group[1].url_prefix == '/bp4'

    bp_group[1] = bp2

# Generated at 2022-06-24 03:27:37.144066
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    """
    Test case for method _getitem_ of class BlueprintGroup
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp3)
    bpg.append(bp4)
    assert bpg[0] == bp3
    assert bpg[1] == bp4



# Generated at 2022-06-24 03:27:42.796243
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp_obj1 = Blueprint('bp1', url_prefix='/bp1')
    bp_obj2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup('/api', version='v1')
    bpg.append(bp_obj1)
    bpg.append(bp_obj2)

    assert bpg.blueprints[0] == bp_obj1
    assert bpg.blueprints[1] == bp_obj2



# Generated at 2022-06-24 03:27:53.647413
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    import sanic
    from sanic.blueprints import Blueprint
    from sanic.decorators import endpoint
    from sanic.response import text

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    group = Blueprint.group(bp1, bp2)

    @group.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for bp1 and bp2')

    # Start application
    app = san

# Generated at 2022-06-24 03:27:55.932018
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group = BlueprintGroup()
    blueprint_group.append(1)
    del blueprint_group[0]
    assert len(blueprint_group) == 0


# Generated at 2022-06-24 03:28:03.361181
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    bpg = bpg + [bp1, bp2]

    assert len(bpg) == 4


# Generated at 2022-06-24 03:28:13.982493
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup()

    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    assert len(bpg) == 4

    assert isinstance(bpg.blueprints, list)
    assert len(bpg.blueprints) == 4

    del bpg[1]
    del bpg[-1]
    del bpg[-2]

    assert len(bpg) == 1

# Generated at 2022-06-24 03:28:20.059934
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bpg = BlueprintGroup(bp3, url_prefix="/bp4", version="v1")
    del bpg[0]
    assert len(bpg) == 0


# Generated at 2022-06-24 03:28:29.534419
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    """Unit test to verify the BlueprintGroup.insert method."""
    from sanic.blueprints import Blueprint

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup('/api', 'v1')
    for i, bp in enumerate((bp1, bp2, bp3, bp4)):
        bpg.insert(i, bp)

    assert len(bpg) == 4
    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert bpg[2] == bp

# Generated at 2022-06-24 03:28:38.574304
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    bp3 = Blueprint("bp3", url_prefix="/bp4")
    bp4 = Blueprint("bp4", url_prefix="/bp4")

    bpg = BlueprintGroup(url_prefix="/api", version="v1", strict_slashes=True)
    bpg.append(bp3)
    bpg.append(bp4)

    group = Blueprint.group(bp1, bp2)

    assert group[0].name == "bp1"
    assert group[1].name == "bp2"
    assert bpg[0].name == "bp3"
    assert bpg[1].name == "bp4"


# Generated at 2022-06-24 03:28:47.704878
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    assert len(bpg) == 2
    assert len(bpg.blueprints) == 2

    del bpg[0]
    assert len(bpg) == 1
    assert len(bpg.blueprints) == 1



# Generated at 2022-06-24 03:28:54.335431
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    # Set up BlueprintGroup object
    items = [Blueprint('bp1', url_prefix='/bp1', version="v1"), Blueprint('bp2', url_prefix='/bp2', strict_slashes=True)]
    blueprint_group = BlueprintGroup(url_prefix='/bp5')
    blueprint_group.blueprints.extend(items)
    blueprint_group._sanitize_blueprint = Mock()

    # Act
    del blueprint_group[0]

    # Assert
    assert blueprint_group.blueprints == [Blueprint('bp2', url_prefix='/bp2', strict_slashes=True)]


# Generated at 2022-06-24 03:29:03.001933
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")

    bp4 = Blueprint("bp4", url_prefix="/bp4")
    bp5 = Blueprint("bp5", url_prefix="/bp5")
    bp6 = Blueprint("bp6", url_prefix="/bp6")

    group1 = BlueprintGroup(url_prefix="/v1", version="v1")
    group1.append(bp1)
    group1.append(bp2)
    group1.append(bp3)

    group2 = BlueprintGroup(url_prefix="/v2", version="v2")
    group2.append(bp4)
    group2.append(bp5)
   

# Generated at 2022-06-24 03:29:09.167897
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    """
    GIVEN Blueprint Group is being created
    WHEN __setitem__ is called with valid index
    THEN ensure its setting the blueprint to given index
    """
    blueprint_group = BlueprintGroup()
    blueprint_instance = Blueprint('test_blueprint_group', url_prefix='test')
    blueprint_group.append(blueprint_instance)
    blueprint_group.__setitem__(0, blueprint_instance)
    assert blueprint_group[0] == blueprint_instance



# Generated at 2022-06-24 03:29:20.345970
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Unit Test for the method middleware of class BlueprintGroup.
    """
    # Create an Instance of Sanic Server.
    app = sanic.Sanic()
    # Create a new Blueprint Group
    bpg = BlueprintGroup(url_prefix='/test')
    # Create two Blueprint with same names
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    # Add the blueprints to the Blueprint Group
    bpg.append(bp1)
    bpg.append(bp2)
    # Add a middleware to the group
    @bpg.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    # Assert that the

# Generated at 2022-06-24 03:29:25.142794
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    # create BlueprintGroup instance
    bpg_instance = BlueprintGroup(None)
    # create a blueprint
    bp_instance = sanic.Blueprint('test_bpg_append', url_prefix='/test/bpg/append')
    # add blueprint to blueprint group
    bpg_instance.append(bp_instance)
    # ensure blueprint is added to blueprint group
    assert(bpg_instance._blueprints == [bp_instance])


# Generated at 2022-06-24 03:29:32.187685
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    bpg = BlueprintGroup(url_prefix="/bpg")
    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert len(bpg) == 2
    assert bpg.blueprints == [bp1, bp2]



# Generated at 2022-06-24 03:29:40.392261
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = sanic.Blueprint("bp1", url_prefix="/bp1")
    bp2 = sanic.Blueprint("bp2", url_prefix="/bp2")

    bpg1 = BlueprintGroup("/api", version="v1")
    bpg1.append(bp1)
    bpg1.append(bp2)

    bpg2 = BlueprintGroup("api", version="v2")
    bpg2.append(bp1)
    bpg2.append(bp2)

    assert len(bpg1) == 2
    assert len(bpg2) == 2

    # Sanitize Blueprint Method
    bp1.url_prefix = "/bp1"
    bp2.url_prefix = "/bp2"
    bp1.version = None
    bp2.version = None
    b

# Generated at 2022-06-24 03:29:48.339587
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    a = BlueprintGroup()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    a[0] = bp1
    a[1] = bp2
    assert a[0] == bp1
    assert a[1] == bp2
    a = BlueprintGroup()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    a.append(bp1)
    a.append(bp2)
    assert a[0] == bp1
    assert a[1] == bp2


# Generated at 2022-06-24 03:29:55.465660
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix="/bp1")
    bp2 = Blueprint('bp2', url_prefix="/bp2")

    bpg = BlueprintGroup(bp1, bp2)

    assert len(bpg) == 2
    assert len(bpg.blueprints) == 2

    del bpg[0]

    assert len(bpg) == 1
    assert len(bpg.blueprints) == 1


# Generated at 2022-06-24 03:30:00.698345
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    url_prefix = "/api/v1"
    blueprint_group = BlueprintGroup(url_prefix=url_prefix)
    assert blueprint_group.url_prefix == url_prefix
    assert blueprint_group.blueprints == []
    assert blueprint_group.version == None
    assert blueprint_group.strict_slashes == None

# Generated at 2022-06-24 03:30:05.900186
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)

    bp = group[0]
    assert bp is bp1



# Generated at 2022-06-24 03:30:12.596685
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp_group = BlueprintGroup()
    bp_group[0] = bp1 
    bp_group[1] = bp2
    assert len(bp_group._blueprints) == 2
    assert bp_group[0] == bp1 
    assert bp_group[1] == bp2


# Generated at 2022-06-24 03:30:21.126185
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    """
    Test Case to test the constructor of BlueprintGroup
    """
    # Init without arguments
    bp_group = BlueprintGroup()
    assert len(bp_group) == 0
    assert bp_group.url_prefix is None
    assert bp_group.version is None
    assert bp_group.strict_slashes is None

    # Init with URL Prefix
    bp_group = BlueprintGroup(url_prefix="/api")
    assert len(bp_group) == 0
    assert bp_group.url_prefix == "/api"
    assert bp_group.version is None
    assert bp_group.strict_slashes is None

    # Init with URL Prefix
    bp_group = BlueprintGroup(url_prefix="api")
    assert len(bp_group) == 0
    assert bp_

# Generated at 2022-06-24 03:30:26.182545
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")
    bpg = BlueprintGroup()

    with pytest.raises(TypeError):
        bpg.append("hello")
    assert len(bpg) == 0

    bpg.append(bp1)
    assert len(bpg) == 1

    bpg.append(bp1)
    assert len(bpg) == 2

    bpg.append(bp2)
    assert len(bpg) == 3

    bpg.append(bp3)
    assert len(bpg) == 4


# Generated at 2022-06-24 03:30:33.984260
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.__setitem__(0, bp3)
    assert bpg[0] == bp3
    bpg.__setitem__(1, bp4)
    assert bpg[1] == bp4


# Generated at 2022-06-24 03:30:38.804890
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = Blueprint.group(bp1, bp2)

    del bpg[0]

    assert bpg._blueprints[0] == bp2


# Generated at 2022-06-24 03:30:46.922520
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    @bp3.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp4.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    bpg.append(bp3)
    bpg.append(bp4)

    assert bpg[0] == bp3

# Generated at 2022-06-24 03:30:58.154911
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    # GIVEN
    from sanic.blueprints import Blueprint
    from sanic.decorators import blueprint
    from sanic.testing import HOST, PORT, SanicTestClient

    class Sanic(sanic.Sanic):
        def blueprint(self, blueprint, options=None):
            blueprint = blueprint.__sanic_bp__
            if blueprint.name not in self.blueprints:
                self.blueprints[blueprint.name] = blueprint
                self.blueprints_list.append(blueprint)
            if options is not None:
                if 'url_prefix' in options:
                    blueprint.url_prefix = options['url_prefix']
                if 'strict_slashes' in options:
                    blueprint.strict_slashes = options['strict_slashes']
            return blueprint

    # WHEN
    bp1

# Generated at 2022-06-24 03:31:02.155458
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2)

    blueprint = group[0]
    assert blueprint == bp1

    blueprint = group[1]
    assert blueprint == bp2


# Generated at 2022-06-24 03:31:09.059854
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)

    del bpg[1]
    assert bpg.blueprints[0].name == bp1.name


# Generated at 2022-06-24 03:31:16.437869
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    # Given
    bp1 = sanic.Blueprint('opt1')
    bp2 = sanic.Blueprint('opt2')
    bp3 = sanic.Blueprint('opt3')
    # When
    bpg = BlueprintGroup()
    # Then
    assert len(bpg) == 0
    # When
    for bp in (bp1, bp2, bp3):
        bpg.append(bp)
    # Then
    assert len(bpg) == 3


# Generated at 2022-06-24 03:31:19.392033
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp0 = Blueprint('bp0')
    bp1 = Blueprint('bp1')
    
    bpg = BlueprintGroup()
    bpg.append(bp0)
    bpg.append(bp1)
    
    assert len(bpg) == 2



# Generated at 2022-06-24 03:31:29.754232
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    """
    BlueprintGroup class should implement __getitem__ method that can be used
    to retrieve a blueprint inside the group specified by an index value.
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert bpg[2] == bp3
    assert bpg

# Generated at 2022-06-24 03:31:36.239437
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    # Test creation of BlueprintGroup
    bpg = BlueprintGroup()
    assert bpg is not None

    # Test registeration of blueprints
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg) == 2

    # Test accessing blueprints in a group
    assert bpg[0] == bp1



# Generated at 2022-06-24 03:31:46.327146
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    assert bpg.__len__() == 0
    bpg.append(bp3)
    bpg.append(bp4)
    assert bpg.__len__() == 2
    bpg.append(bp3)
    bpg.append(bp3)
    bpg.append(bp3)
    assert bpg.__len__() == 5
    bpg.insert(0,bp3)
    bpg.insert(7,bp3)
    del bpg[1]
    del bpg[4]
    assert bpg.__len__() == 6

# Generated at 2022-06-24 03:31:55.748952
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')
    bp.blueprints.append(bp3)
    bp.blueprints.append(bp2)
    bp.blueprints.append(bp1)
    bp.blueprints.append(bp5)
    bp.blueprints.append(bp6)
    assert(bp.blueprints.__len__() == 5)
    bp.blue

# Generated at 2022-06-24 03:32:02.924247
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    Blueprint.__module__ = 'sanic.blueprints'
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg) == 2
    assert bpg[0] == bp1
    assert bpg[1] == bp2


# Generated at 2022-06-24 03:32:11.418762
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    # Initializing from BlueprintGroup
    from sanic.blueprints import BlueprintGroup
    test_instance = BlueprintGroup(
        url_prefix=None, version=None, strict_slashes=None
    )

    # Initializing from Blueprint
    from sanic.blueprints import Blueprint
    bp = Blueprint('bp1', url_prefix='/bp1')

    # test setitem is working correctly
    test_instance[0] = bp
    assert test_instance[0] == bp

    # test if an invalid index is given
    try:
        test_instance[1] = bp
    except IndexError:
        assert True
    else:
        assert False


# Generated at 2022-06-24 03:32:18.978633
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bp = BlueprintGroup(bp3,bp4, url_prefix="/api", version="v1")

    @bp.middleware('request')
    def hello(request):
        print('Hello ' + request.args.get('name', 'world'))

    @bp.middleware('request')
    def world(request):
        print('world')

    assert len(bp.blueprints) == 2
    assert bp.blueprints[0].middleware_stack[0][1][1] == ('request', hello)

# Generated at 2022-06-24 03:32:28.971470
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    app = Sanic('test_BlueprintGroup___delitem__')
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-24 03:32:33.243952
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bpg = BlueprintGroup(url_prefix="/api", version="v1", strict_slashes=True)
    assert bpg.url_prefix == "/api"
    assert bpg.version == "v1"
    assert bpg.blueprints == []
    assert bpg.strict_slashes == True
    assert len(bpg) == 0


# Generated at 2022-06-24 03:32:44.408401
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup('/api', 'v1')
    bpg.extend([bp1, bp2])

    assert len(bpg) == 2
    assert bpg[0] is bp1
    assert bpg[1] is bp2

    assert bpg.blueprints == [bp1, bp2]
    assert bpg.url_prefix == '/api'
    assert bpg.version == 'v1'

    bpg.append(bp3)

# Generated at 2022-06-24 03:32:49.996618
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert [item for item in bpg] == [bp1, bp2]


# Generated at 2022-06-24 03:32:55.506155
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    """
    Test BlueprintGroup class iter.
    """
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert bp1.name == next(bpg.__iter__()).name
    assert bp2.name == next(bpg.__iter__()).name


# Generated at 2022-06-24 03:33:00.483414
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup('bpg', url_prefix='/bpg')

    bpg.append(bp1)
    bpg.append(bp2)
    for i, bp in enumerate(bpg):
        assert bp.name in ('bp1', 'bp2')
    assert i == 1



# Generated at 2022-06-24 03:33:04.688199
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
  bpg = BlueprintGroup()
  bpg._blueprints = ['a', 'b', 'c']
  assert list(bpg) == ['a', 'b', 'c']


# Generated at 2022-06-24 03:33:14.905256
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup()

    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    assert bp1 in bpg.blueprints
    assert bp2 in bpg.blueprints
    assert bp3 in bpg.blueprints
    assert bp4 in bpg.blueprints

    del bpg[0]
    assert bp1 not in bpg.blueprints


# Generated at 2022-06-24 03:33:19.613303
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    """Unit test for method insert of class BlueprintGroup."""
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.insert(0,bp2)
    assert bpg[0] == bp2
    assert bpg[1] == bp1
    assert len(bpg) == 2


# Generated at 2022-06-24 03:33:23.870271
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg[0] == bp1
    assert bpg[1] == bp2


# Generated at 2022-06-24 03:33:33.266980
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    # Create a sample blueprint
    bp = Blueprint("bp1", url_prefix='/bp1')
    # Create a sample Blueprint Group
    bg = BlueprintGroup(url_prefix='/api')
    # Append the Blueprint to the Group
    bg.append(bp)
    # Assert if the length of the list is one
    assert len(bg) == 1
    # Assert if the newly created blueprint can be retrieved from the list
    assert bg[0] == bp
    # Verify if the operation didn't modify the original blueprint
    assert bp.url_prefix == "/bp1"
    # Verify if the operation modified the blueprint's url_prefix
    assert bp.url_prefix == "/api/bp1"


# Generated at 2022-06-24 03:33:42.617974
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Setup the blueprint
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    group1 = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    group2 = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    group3 = BlueprintGroup(group1, group2, url_prefix="/api", version="v2")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')



# Generated at 2022-06-24 03:33:51.424455
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    app = sanic.Sanic('test_BlueprintGroup_insert')

    @bp3.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp4.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    group = BlueprintGroup('/api', 'v1')


# Generated at 2022-06-24 03:33:59.221137
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Create app
    app = sanic.Sanic("test_BlueprintGroup_middleware")

    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bp3 = Blueprint("bp3")

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)

    d = {}
    @bpg.middleware("request")
    async def test_middleware1(request):
        d["request"] = request

    @bpg.middleware("response")
    async def test_middleware2(request, response):
        d["response"] = response

    @bp1.route("/")
    async def test(request):
        return text("OK")

    app.blueprint(bpg)



# Generated at 2022-06-24 03:34:07.326712
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    from sanic.blueprints import Blueprint

    # Initializing Blueprint
    bp_obj1 = Blueprint("bp1")
    bp_obj2 = Blueprint("bp2")
    # Creating BlueprintGroup with URL Prefix set
    bp_group_obj = BlueprintGroup("/apiv1")
    assert bp_group_obj.url_prefix == "/apiv1"
    # adding blueprint objects to BlueprintGroup
    bp_group_obj.append(bp_obj1)
    bp_group_obj.append(bp_obj2)

    assert len(bp_group_obj) == 2
    assert bp_group_obj[0] == bp_obj1
    assert bp_group_obj[1] == bp_obj2

# Generated at 2022-06-24 03:34:17.286669
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Create a BlueprintGroup
    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    # Create 2 blueprints
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")

    # Create a Spy Middleware
    spy = MagicMock()
    spy = AsyncMock(return_value=spy)

    # Register the Spy Middleware
    bpg.middleware(bp1.middleware)

    # Automatic registration of middleware for each Blueprint
    for bp in [bp1, bp2]:
        assert spy in bp.request_middleware
        assert spy in bp.response_middleware
        assert spy in bp.exception_middleware


# Generated at 2022-06-24 03:34:23.526568
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    """
    This method tests if the length of the `BlueprintGroup` class is getting
    calculated correctly.
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2)

    assert len(group) == 2


# Generated at 2022-06-24 03:34:27.968473
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bpg = BlueprintGroup(url_prefix="/api")
    bpg.append(bp1)
    assert bpg.blueprints[0].url_prefix == "/api/bp1"
    assert bpg.blueprints[0].url_prefix != "/bpi/bp1"


# Generated at 2022-06-24 03:34:31.336997
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)
    bpg.insert(0, bp2)

    assert bpg[0] == bp2
    assert bpg[1] == bp1



# Generated at 2022-06-24 03:34:39.763372
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    """
    Unit test for method append of class BlueprintGroup
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bpg.blueprints) == 2
    assert bpg.blueprints[0].url_prefix == "/api/bp1"


# Generated at 2022-06-24 03:34:44.656772
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert ''.join(str(item) for item in bpg) == 'bp1bp2'



# Generated at 2022-06-24 03:34:55.110678
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    app = sanic.Sanic()

    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    bpg = BlueprintGroup()

    bpg.insert(0, bp1)

    bpg.insert(0, bp2)
