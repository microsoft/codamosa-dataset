

# Generated at 2022-06-24 03:25:00.434933
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    #TODO: more test here
    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')
    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-24 03:25:10.529202
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    # Load a BlueprintGroup using the fixture from conftest.py
    bp_group = sanic.blueprints.Blueprint.group(url_prefix="/api")
    bp_group.append(sanic.Blueprint("bp1"))
    bp_group.append(sanic.Blueprint("bp2"))

    # add a new blueprint to the group
    bp_group.append(sanic.Blueprint("bp3"))

    # Get the length of the group
    length_of_blueprint_group = len(bp_group)

    # Remove an item from the group
    del bp_group[0]

    # Validate length of the group has changed
    assert len(bp_group) == length_of_blueprint_group - 1


# Generated at 2022-06-24 03:25:18.273176
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()

    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    group = Blueprint.group(bp1, bp2)

    group.strict_slashes = True


# Generated at 2022-06-24 03:25:27.535918
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    group = BlueprintGroup("/api", "v1")
    group.append(bp1)
    group.append(bp2)
    assert bp1.url_prefix == "/api/bp1"
    assert bp2.url_prefix == "/api/bp2"
    assert bp1.version == "v1"
    assert bp2.version == "v1"
    assert group.url_prefix == "/api"
    assert group.version == "v1"



# Generated at 2022-06-24 03:25:38.122978
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    Blueprint = sanic.Blueprint
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')
    bp7 = Blueprint('bp7', url_prefix='/bp7')
    bp8 = Blueprint('bp8', url_prefix='/bp8')
    bp9 = Blueprint('bp9', url_prefix='/bp9')
    bp10 = Blueprint('bp10', url_prefix='/bp10')


# Generated at 2022-06-24 03:25:49.032540
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @Blueprint.middleware('request')
    async def common_middleware(request):
        print('common middleware')

    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')

    bp3 = Blueprint('bp3')
    bp3 = Blueprint('bp3')

    bpg = BlueprintGroup(bp3, bp4)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)


# Generated at 2022-06-24 03:25:54.004722
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint = Blueprint('bp1', url_prefix='/bp1')
    blueprint_group = BlueprintGroup(url_prefix="/api", version="v1")
    blueprint_group.append(blueprint)

    blueprint2 = Blueprint('bp2', url_prefix='/bp2')
    blueprint_group.__setitem__(0, blueprint2)
    #assert blueprint_group.__getitem__(0).name == 'bp2'
    assert blueprint_group[0].name == 'bp2'


# Generated at 2022-06-24 03:25:58.195717
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bpg = BlueprintGroup()
    bp1 = Blueprint("Bp1")
    bp2 = Blueprint("Bp2")
    bp3 = Blueprint("Bp3")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg[0] = bp3
    assert bpg[0] == bp3



# Generated at 2022-06-24 03:26:01.796562
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    assert bpg.url_prefix == "/api"
    assert bpg.version == "v1"


# Generated at 2022-06-24 03:26:11.503436
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    # Setup an sample application
    app = sanic.Sanic()
    # Setup a sample Blueprint
    bp = Blueprint('sample_bp', url_prefix='/test_bp')
    # Setup a single Blueprint group
    group1 = BlueprintGroup()
    # Add a blueprint to the group
    group1.append(bp)
    # Iterate the group and assert a Blueprint is returned
    # with each iteration
    for item in group1:
        assert isinstance(item, Blueprint)
    # Add a Blueprint Group to the Blueprint Group
    group2 = BlueprintGroup()
    group2.append(bp)
    group1.append(group2)
    # Iterate the group and assert a Blueprint is returned
    # with each iteration
    for item in group1:
        assert isinstance(item, Blueprint) 
    # Iterate the group nested under

# Generated at 2022-06-24 03:26:16.966790
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    group = BlueprintGroup(url_prefix="/api", version="v1")
    group.append(bp1)
    group.append(bp2)
    assert isinstance(group[0], Blueprint)
    assert isinstance(group[1], Blueprint)

# Generated at 2022-06-24 03:26:27.453916
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
  app = sanic.Sanic()
  bp1 = Blueprint('bp1', url_prefix='/bp1')
  bp2 = Blueprint('bp2', url_prefix='/bp2')
  bp3 = Blueprint('bp3', url_prefix='/bp3')

  @bp1.middleware('request')
  def bp1_middleware(request):
    print('applied on Blueprint : bp1 Only')

  @bp1.route('/')
  async def bp1_route(request):
    return text('bp1')

  @bp2.route('/<param>')
  async def bp2_route(request, param):
    return text(param)

  @bp3.route('/')
  async def bp3_route(request):
    return text('bp3')

 

# Generated at 2022-06-24 03:26:38.337027
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')
    bp7 = Blueprint('bp7', url_prefix='/bp7')
    bp8 = Blueprint('bp8', url_prefix='/bp8')
    bp9 = Blueprint('bp9', url_prefix='/bp9')
    bp10 = Blueprint('bp10', url_prefix='/bp10')

# Generated at 2022-06-24 03:26:45.728942
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    group = BlueprintGroup(url_prefix='/api', version='v1')
    group.append(Blueprint(name='bp1', url_prefix='/bp1'))
    group.append(Blueprint(name='bp2', url_prefix='/bp2'))
    group.append(Blueprint(name='bp3', url_prefix='/bp3'))
    group.append(Blueprint(name='bp4', url_prefix='/bp4'))

    new_blueprint = Blueprint(name='bp5', url_prefix='/bp5')
    group[0] = new_blueprint
    assert group[0].name == 'bp5'


# Generated at 2022-06-24 03:26:54.439453
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    # arrange
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    
    bpg = BlueprintGroup()

    # act
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    # assert
    assert blueprints.__len__ == 4



# Generated at 2022-06-24 03:27:02.551963
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1= Blueprint('bp1', url_prefix='/bp1')
    bp2= Blueprint('bp2', url_prefix='/bp2')

    bp3= Blueprint('bp3', url_prefix='/bp4')
    bp4= Blueprint('bp4', url_prefix='/bp4')

    bpg= BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-24 03:27:09.514395
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    assert len(BlueprintGroup()) == 0
    assert len(BlueprintGroup(None, None, None)) == 0
    assert len(BlueprintGroup("", None, None)) == 0
    assert len(BlueprintGroup(None, "", None)) == 0
    assert len(BlueprintGroup(None, None, True)) == 0
    assert len(BlueprintGroup("/api", "v1", False)) == 0


# Generated at 2022-06-24 03:27:19.784294
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.insert(0, bp1)
    assert bpg[0] == bp1
    assert bpg._blueprints[0] == bp1
    assert len(bpg) == 1

    bpg.insert(1, bp2)
    assert bpg[1] == bp2
    assert bpg._blueprints[1] == bp2
    assert len(bpg) == 2



# Generated at 2022-06-24 03:27:25.691021
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group = BlueprintGroup()
    blueprint_group.append(Blueprint('bp1', url_prefix='/bp1'))
    blueprint_group.append(Blueprint('bp2', url_prefix='/bp2'))
    del blueprint_group[1]
    assert len(blueprint_group) == 1


# Generated at 2022-06-24 03:27:34.243200
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)

    assert(len(bpg) == 3)
    assert(len(bpg._blueprints) == 3)



# Generated at 2022-06-24 03:27:39.977498
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    """
    This test case will test the constructor of the class BlueprintGroup.
    """
    bp = Blueprint("bp", url_prefix="/bp")
    bpg = BlueprintGroup("/apiv1", version=1, strict_slashes=False)

    assert bpg.url_prefix == "/apiv1"
    assert bpg.version == 1
    assert bpg.strict_slashes is False
    assert bpg.blueprints == []


# Generated at 2022-06-24 03:27:47.948319
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    print("\n test_BlueprintGroup___setitem__")
    print("\n before setitem")
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    print(bpg.__getitem__(1))
    print("\n after setitem")
    bpg.__setitem__(1, bp1)
    print(bpg.__getitem__(1))

test_BlueprintGroup___setitem__()

# Generated at 2022-06-24 03:27:58.929124
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    """
    .. code-block:: python

        bp1 = Blueprint('bp1', url_prefix='/bp1')
        bp2 = Blueprint('bp2', url_prefix='/bp2')
        bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

        bpg.append(bp1)

    """
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)

    assert bp1 in bpg._blueprints
    assert bp2 not in bpg._blueprints
    assert bpg._blueprints[0].url_prefix == "/api/bp1"


# Generated at 2022-06-24 03:28:04.885114
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class MyApp(sanic.Sanic):
        def __init__(self):
            super().__init__(__name__)

        @staticmethod
        async def dummy_middleware(*args, **kwargs):
            pass

    app = MyApp()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp1', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    bpg.middleware(app.dummy_middleware, "request")
    assert bp1.middlewares["request"][0] == app.dummy_middleware
    assert bp2.middlewares["request"][0] == app.dummy_middleware


# Generated at 2022-06-24 03:28:09.816588
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    """
    Unit test for `BlueprintGroup.append` method
    """
    blueprint_obj = Blueprint("Blueprint")
    blueprint_group_obj = BlueprintGroup()
    blueprint_group_obj.append(blueprint_obj)

    assert blueprint_obj in blueprint_group_obj._blueprints


# Generated at 2022-06-24 03:28:20.665453
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')

    bpg = BlueprintGroup(url_prefix='/bpg')
    bpg.append(bp3)
    bpg.append(bp4)
    bpg.append(bp1)

    assert bpg[0] is bp3
    assert bpg[1] is bp4
    assert bpg[2] is bp1

    bpg[1] = bp2
    assert bpg[1] is bp2

# Generated at 2022-06-24 03:28:26.121989
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bpg = BlueprintGroup()
    assert len(bpg) == 0

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()
    bpg.append(bp2)
    bpg.append(bp1)

    assert len(bpg) == 2


# Generated at 2022-06-24 03:28:30.884243
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    # Test case where blueprint group is empty
    bg = BlueprintGroup()
    assert list(bg) == []
    assert next(iter(bg)) == StopIteration
    # Test case where blueprint group is non-empty
    bg2 = BlueprintGroup()
    bp = Blueprint('test')
    bg2.append(bp)
    assert list(bg2) == [bp]
    assert next(iter(bg2)) == bp


# Generated at 2022-06-24 03:28:38.814734
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    """
    BlueprintGroup: Len method returns total number of blueprints
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    # Create a Blueprint Group
    bpg = BlueprintGroup()

    # No blueprint in the group
    assert len(bpg) == 0

    # Add a blueprint
    bpg.append(bp1)
    assert len(bpg) == 1

    # Add another one
    bpg.append(bp2)
    assert len(bpg) == 2

    # Add the same again
    bpg.append(bp2)
    assert len(bpg) == 3



# Generated at 2022-06-24 03:28:48.186247
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    from sanic.response import text
    from sanic.blueprints import Blueprint

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    @bp1.route('/bp1')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/bp2')
    async def bp2_route(request):
        return text('bp2')

    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)

    assert tuple((bp for bp in group)) == (bp1, bp2)


# Generated at 2022-06-24 03:28:56.041930
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/bpg1")

    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bpg) == 2
    assert bpg[0] == bp1
    assert bpg[1] == bp2

    bpg[1] = bp3
    assert bpg[1] == bp3

    try:
        bpg[2] = bp4
        assert False
    except IndexError:
        assert True



# Generated at 2022-06-24 03:29:01.743496
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    url_prefix, version, strict_slashes = "/groups", "v1", True
    bp_group = BlueprintGroup(
        url_prefix=url_prefix, version=version, strict_slashes=strict_slashes
    )
    # Sanity check of BlueprintGroup class
    assert bp_group.url_prefix == url_prefix
    assert bp_group.version == version
    assert bp_group.strict_slashes == strict_slashes


# Generated at 2022-06-24 03:29:11.853549
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    # Setup
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    def set_value(index, value):
        bpg[index] = value
    # Exercise
    # Verify
    assertRaises(TypeError, set_value, slice(0, 1, 1), bp1)
    assertRaises(TypeError, set_value, slice(0, 1, 1), bp2)

# Generated at 2022-06-24 03:29:22.601364
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    print("BlueprintGroup_middleware")
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup('/api', 'v1')
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.middleware(None)
    assert bpg.blueprints[0].middlewares['request'] == [None]
    assert bpg.blueprints[1].middlewares['request'] == [None]
    assert bpg.blueprints[0].middlewares['response'] == []
    assert bpg.blueprints[1].middlewares['response'] == []




# Generated at 2022-06-24 03:29:30.556553
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp5')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    assert len(bpg) == 2
    assert len(bpg) == len(bpg.blueprints)


# Generated at 2022-06-24 03:29:39.067359
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    """This function tests the BlueprintGroup class for the __len__ method"""
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup()

    bpg.append(bp3)
    bpg.append(bp4)

    assert isinstance(len(bpg), int) == True
    assert len(bpg) == 2



# Generated at 2022-06-24 03:29:47.339875
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp = BlueprintGroup()
    assert len(bp) == 0

    bp = BlueprintGroup()
    bp.append(sanic.Blueprint("test1"))
    assert len(bp) == 1

    bp = BlueprintGroup()
    bp.append(sanic.Blueprint("test1"))
    bp.append(sanic.Blueprint("test2"))
    assert len(bp) == 2

    bp = BlueprintGroup()
    bp.append(sanic.Blueprint("test1"))
    bp.append(sanic.Blueprint("test2"))
    bp.append(sanic.Blueprint("test3"))
    assert len(bp) == 3


# Generated at 2022-06-24 03:29:56.828503
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class TestSanic(sanic.Sanic):
        def _setup_middlewares(self, middlewares=None):
            self.middlewares = list(middlewares or [])
    app = TestSanic("test")
    bp1 = Blueprint("bp1", url_prefix='/bp1')
    bp2 = Blueprint("bp2", url_prefix='/bp2')
    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)

    @group.middleware("request")
    async def group_middleware(request):
        print("common middleware applied for both bp1 and bp2")

    app.blueprint(group)

    # middleware should be registered to both bp1 and bp2
    assert len(bp1.middlewares["request"])

# Generated at 2022-06-24 03:30:02.961998
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api")
    bpg.append(bp1)
    bpg.append(bp2)

    assert bp1.url_prefix == "/api/bp1"
    assert bp2.url_prefix == "/api/bp2"


# Generated at 2022-06-24 03:30:09.594937
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    app = sanic.Sanic(__name__)
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    # Note : the test should be done with the object of the class BlueprintGroup only
    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert bpg[-1] == bp2



# Generated at 2022-06-24 03:30:13.932842
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint1 = Blueprint("test_blueprint_group1")
    blueprint2 = Blueprint("test_blueprint_group2")
    blueprintGroup = BlueprintGroup()
    blueprintGroup.append(blueprint1)
    blueprintGroup.append(blueprint2)
    assert len(blueprintGroup) == 2


# Generated at 2022-06-24 03:30:22.103677
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    """
    This unit test tries to test the functionality of the
    `BlueprintGroup.__setitem__` method.
    """

    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    bpgrp = BlueprintGroup(url_prefix="/root", version="v1")
    bpgrp.append(bp1)
    bpgrp.append(bp2)

    # Before the __setitem__
    assert bpgrp[0] == bp1
    assert bpgrp[1] == bp2

    # Set the value.
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bpgrp[0] = bp3

    # After setting the value.
    assert b

# Generated at 2022-06-24 03:30:30.624983
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2', version="v2")

    group = BlueprintGroup(url_prefix="/api", version="v1")
    group.append(bp1)
    group.append(bp2)

    assert len(group) == 2
    assert group[0] == bp1
    assert group[1] == bp2
    assert bp1.url_prefix == '/api/bp1'
    assert bp2.url_prefix == '/api/bp2'
    assert bp1.version == 'v1'
    assert bp2.version == 'v2'



# Generated at 2022-06-24 03:30:39.452572
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix='/api', version='v1')
    bpg.insert(0, bp1)
    bpg.insert(1, bp2)

    assert bpg.url_prefix is '/api'
    assert bpg.version == 'v1'
    assert len(bpg._blueprints) == 2
    assert bpg.blueprints[0] == bp1
    assert bpg.blueprints[1] == bp2


# Generated at 2022-06-24 03:30:49.339832
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_obj = Blueprint('bp1', url_prefix='/bp1')
    blueprint_obj1 = Blueprint('bp2', url_prefix='/bp2')
    blueprint_obj2 = Blueprint('bp3', url_prefix='/bp3')
    blueprintgroup_obj = BlueprintGroup('/api',version="v1")
    blueprintgroup_obj.append(blueprint_obj)
    blueprintgroup_obj.append(blueprint_obj1)
    blueprintgroup_obj.append(blueprint_obj2)
    length = len(blueprintgroup_obj)
    assert length == 3
    no_of_elements = 0
    for i in blueprintgroup_obj:
        no_of_elements += 1
    assert no_of_elements == 3

# Generated at 2022-06-24 03:30:58.808278
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = sanic.Blueprint("bp1", url_prefix="/bp1")
    bp2 = sanic.Blueprint("bp2", url_prefix="/bp2")

    bpg = BlueprintGroup(url_prefix="/api/v1")
    bpg.append(bp1)
    bpg.append(bp2)

    for i, bp in enumerate(bpg):
        if i == 0:
            assert bp.url_prefix == "/api/v1/bp1"
        elif i == 1:
            assert bp.url_prefix == "/api/v1/bp2"



# Generated at 2022-06-24 03:31:07.134758
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    @sanic.blueprint('bp1', url_prefix='/bp1')
    def bp1():
        return text('bp1')

    @sanic.blueprint('bp2', url_prefix='/bp2')
    def bp2():
        return text('bp2')

    def bp3():
        return text('bp3')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg) == 2
    bpg.append(bp3)
    assert len(bpg) == 3


# Generated at 2022-06-24 03:31:14.193641
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic.blueprints import Blueprint

    blueprint_group = BlueprintGroup()

    @blueprint_group.middleware
    def hello(request):
        pass

    blueprint_group.blueprints.append(Blueprint(name='test'))
    blueprint_middlewares = blueprint_group.blueprints[0].middlewares['request']

    assert len(blueprint_middlewares) == 1
    assert blueprint_middlewares[0].handler == hello



# Generated at 2022-06-24 03:31:22.098562
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp3', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp3)
    bpg.append(bp4)
    bpg.append(bp3)

    assert bpg[0] == bp3
    assert bpg[1] == bp4
    assert bpg[2] == bp3
    assert bpg.blueprints == [bp3, bp4, bp3]
    assert bpg.url_prefix == "/api"
    assert bpg

# Generated at 2022-06-24 03:31:27.787552
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    class BlueprintMock(sanic.Blueprint):
        def __init__(self, *args, **kwargs):
            pass

    bpg = BlueprintGroup()
    bpg.append(BlueprintMock())
    bp = BlueprintMock()
    bpg.insert(0, bp)
    assert bpg[0] == bp

# Generated at 2022-06-24 03:31:36.822336
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    """
        Ensure that the __getitem__ method is working properly
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup()

    bpg.append(bp3)
    bpg.append(bp4)

    assert bpg[0].name == "bp3"
    assert bpg[1].name == "bp4"



# Generated at 2022-06-24 03:31:45.863940
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)
    group.append(bp3)
    group.append(bp4)

    assert isinstance(group[0], Blueprint)
    assert isinstance(group[1], Blueprint)
    assert isinstance(group[2], Blueprint)
    assert isinstance(group[3], Blueprint)


# Generated at 2022-06-24 03:31:53.731896
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('1_bp1', url_prefix='/1/bp1')
    bp2 = Blueprint('1_bp2', url_prefix='/1/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg) == 2
    assert bpg._blueprints[0] is bp1
    assert bpg._blueprints[1] is bp2


# Generated at 2022-06-24 03:32:00.750466
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp3', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    assert bpg[0] == bp3
    assert bpg[1] == bp4
    assert bpg[-1] == bp4

    assert bpg[0:1] == [bp3]
    assert bpg[-1:-2] == []


# Generated at 2022-06-24 03:32:06.672798
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')

    group = BlueprintGroup()

    group.append(bp1)
    group.append(bp2)
    group.append(bp3)

    assert len(group) == 3



# Generated at 2022-06-24 03:32:14.039457
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    """
    ToDo
    """
    bp1 = Blueprint('bp1', url_prefix='bp1')
    bp2 = Blueprint('bp2', url_prefix='bp2')
    bp3 = Blueprint('bp3', url_prefix='bp3')
    bp4 = Blueprint('bp4', url_prefix='bp4')

    bpg1 = BlueprintGroup(url_prefix='bpg1')
    bpg2 = BlueprintGroup(url_prefix='bpg2')

    bpg1.insert(0, bp1)
    bpg1.insert(0, bp2)
    bpg2.insert(0, bp3)
    bpg2.insert(0, bp4)
    bpg1.insert(0, bpg2)


# Generated at 2022-06-24 03:32:16.253047
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bpg = BlueprintGroup()
    assert len(bpg) == 0

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg.append(bp1)
    assert len(bpg) == 1

    bpg.append(bp2)
    assert len(bpg) == 2


# Generated at 2022-06-24 03:32:25.959166
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    class BlueprintTest:
        __slots__ = ["url_prefix", "version", "strict_slashes"]

        def __init__(self, url_prefix, version, strict_slashes):
            self.url_prefix = url_prefix
            self.version = version
            self.strict_slashes = strict_slashes


    bp1 = Blueprint.group(
        BlueprintTest(url_prefix="/bp1", version="v1", strict_slashes=False),
        BlueprintTest(url_prefix="/bp2", version="v1", strict_slashes=False),
        url_prefix="/api",
    )

    assert bp1[0].url_prefix == "/api/bp1"
    assert bp1[1].url_prefix == "/api/bp2"



# Generated at 2022-06-24 03:32:34.883113
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    assert bpg.url_prefix == '/api'
    assert bpg.version == "v1"
    assert bpg.strict_slashes == None

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    assert bpg.url_prefix == '/api'
    assert bpg.version == "v1"
    assert bpg.strict_slashes == None

#

# Generated at 2022-06-24 03:32:39.605931
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    data_to_append = Blueprint("foo", url_prefix="/foo")
    blueprint_group = BlueprintGroup()

    blueprint_group.append(data_to_append)
    assert blueprint_group.blueprints[0] == data_to_append


# Generated at 2022-06-24 03:32:45.790333
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp = BlueprintGroup()

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp1.url_prefix = '/api'
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp[0] = bp1
    bp[1] = bp2

    bp[0] == bp1
    bp[1] == bp2


# Generated at 2022-06-24 03:32:56.068127
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    group = Blueprint.group(bp1, bp2)

    # Get bp2 route from group
    bp2_route_from_group = group[1]

    assert bp2_route_from_group.name == bp2.name
    assert bp2_route_from_group.url_prefix == bp2.url_prefix


# Generated at 2022-06-24 03:32:57.147330
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    BlueprintGroup()



# Generated at 2022-06-24 03:33:07.555525
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    from sanic import Sanic
    from sanic.blueprints import Blueprint
    app = Sanic()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')
    bp7 = Blueprint('bp7', url_prefix='/bp7')
    bp8 = Blueprint('bp8', url_prefix='/bp8')
    bp9 = Blueprint('bp9', url_prefix='/bp9')
    bpg

# Generated at 2022-06-24 03:33:11.747388
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2)
    for a in group:
        assert isinstance(a, Blueprint)



# Generated at 2022-06-24 03:33:16.186150
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint("name1","url_prefix1")
    bp2 = Blueprint("name2","url_prefix2")
    bp3 = Blueprint("name3","url_prefix3")

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)

    del bpg[2]
    assert len(bpg) == 2


# Generated at 2022-06-24 03:33:25.139935
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    del bpg[1]
    assert len(bpg.blueprints) == 2
    assert bpg[0] == bp1
    assert bpg[1] == bp3

    with pytest.raises(IndexError):
        del bpg[2]


# Generated at 2022-06-24 03:33:29.709306
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    import sanic
    blueprint_group = BlueprintGroup()
    blueprint = Blueprint('bp1', url_prefix='/bp1')
    blueprint_group[0] = blueprint

# Generated at 2022-06-24 03:33:36.706236
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = sanic.Blueprint('test_BlueprintGroup___getitem__1')
    bp2 = sanic.Blueprint('test_BlueprintGroup___getitem__2')

    bpg = BlueprintGroup()
    bpg.append(bp2)
    bpg.append(bp1)

    assert bpg[0] is bp2
    assert bpg[1] is bp1

    assert bpg[0:2] == [bp2, bp1]
    assert bpg[1:1] == []



# Generated at 2022-06-24 03:33:48.191723
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    group = BlueprintGroup(url_prefix="/api", version="v1")
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group.append(bp1)
    group.append(bp2)

    @group.middleware('request')
    def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/')
    async def bp2_route(request):
        return text('bp2')


# Generated at 2022-06-24 03:33:53.534085
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bpg = BlueprintGroup("/api", strict_slashes=True)
    bpg.append(bp1)
    bpg.append(bp2)
    assert bpg[0] == bp1
    assert bpg[1] == bp2
    with pytest.raises(IndexError):
        bpg[3]


# Generated at 2022-06-24 03:33:57.373434
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert list(bpg) == [bp1, bp2]


# Generated at 2022-06-24 03:34:01.897763
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1, bp2, bp3, bp4, bp5 = Blueprint('bp1'),\
                        Blueprint('bp2'),\
                        Blueprint('bp3'),\
                        Blueprint('bp4'),\
                        Blueprint('bp5')
    bpg = BlueprintGroup(bp1, bp2, bp3, bp4)
    assert isinstance(bpg, MutableSequence)
    assert isinstance(bpg, iter(bpg))



# Generated at 2022-06-24 03:34:11.247465
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix='/api', version='v1')

    assert (
        bpg._sanitize_blueprint(bp=bp1).url_prefix == '/api/bp1'
    ), "url prefixes of blueprint group and blueprint(s) must be concatenated"
    assert (
        bpg._sanitize_blueprint(bp=bp2).url_prefix == '/api/bp2'
    ), "url prefixes of blueprint group and blueprint(s) must be concatenated and %s" % bp2.url_prefix

# Generated at 2022-06-24 03:34:22.061812
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1', strict_slashes=True)
    bp2 = Blueprint('bp2', url_prefix='/bp2', strict_slashes=False)
    bp3 = Blueprint('bp3', url_prefix='/bp3', strict_slashes=False)
    bp4 = Blueprint('bp4', url_prefix='/bp4', strict_slashes=False)
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api/v1", version="v1", strict_slashes=False)
    bpg1 = BlueprintGroup(bpg, bp2, url_prefix="/api/v2", strict_slashes=True)

# Generated at 2022-06-24 03:34:32.473026
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp3')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    @bp3.route('/')
    async def bp3_route(request):
        return text('bp3')


# Generated at 2022-06-24 03:34:41.692808
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    url_prefix = 'test_url_prefix'
    version = 1.0
    strict_slashes = False
    bp_group = BlueprintGroup(url_prefix=url_prefix, version=version, strict_slashes=strict_slashes)
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp_group._blueprints = [bp1, bp2]
    # Test iter
    assert [bp1, bp2] == list(bp_group)


# Generated at 2022-06-24 03:34:52.981406
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bp3 = Blueprint("bp3")
    bp4 = Blueprint("bp4")
    bp5 = Blueprint("bp5")
    bp6 = Blueprint("bp6")
    bp7 = Blueprint("bp7")
    bp8 = Blueprint("bp8")
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    bpg.append(bp5)
    bpg.append(bp6)
    bpg.append(bp7)
    bpg.append(bp8)
    del bpg[1]
    del bpg[0]