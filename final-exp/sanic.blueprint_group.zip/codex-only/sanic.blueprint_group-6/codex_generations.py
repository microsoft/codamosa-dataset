

# Generated at 2022-06-24 03:24:51.459620
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    pass


# Generated at 2022-06-24 03:24:59.535421
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2)
    bpg2 = BlueprintGroup()
    count = 0
    for bp in bpg:
        assert bp in [bp1, bp2]
        count += 1
    assert count == 2
    for _ in bpg2:
        count += 1
    assert count == 2


# Generated at 2022-06-24 03:25:10.149709
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-24 03:25:17.733289
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp2.middleware('response')
    async def bp2_only_middleware(request):
        print('applied on Blueprint : bp2 Only')


# Generated at 2022-06-24 03:25:24.996234
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.insert(0,bp1)
    bpg.insert(1,bp2)

    assert bpg.blueprints[0] == bp1
    assert bpg.blueprints[1] == bp2


# Generated at 2022-06-24 03:25:36.028917
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    assert bpg[0].url_prefix == '/bp1'
    assert bpg[1].url_prefix == '/bp2'
    assert bpg[2].url_prefix == '/bp3'
    assert bpg[3].url_prefix == '/bp4'
    assert len(bpg) == 4
   

# Generated at 2022-06-24 03:25:40.003811
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    def example_middleware(request):
        pass

    bp1 = sanic.Blueprint('bp1')
    bpg = BlueprintGroup()
    bpg.append(bp1)

    bpg.middleware(example_middleware)
    assert len(bp1.middlewares) == 1



# Generated at 2022-06-24 03:25:50.035501
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint("bp1", url_prefix='')
    bp2 = Blueprint("bp2", url_prefix='')
    bp3 = Blueprint("bp3", url_prefix='')
    bp4 = Blueprint("bp4", url_prefix='')
    bp_list = BlueprintGroup()
    bp_list.append(bp1)
    bp_list.append(bp2)
    bp_list.append(bp3)
    bp_list.append(bp4)
    assert(bp_list[1] ==  bp2)
    assert(bp_list[-1] == bp4)
    assert(bp_list[2] == bp3)


# Generated at 2022-06-24 03:25:58.607509
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    bp2 = Blueprint('bp2', url_prefix='/bp2')

    @bp2.middleware('request')
    async def bp2_only_middleware(request):
        print('applied on Blueprint : bp2 Only')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)


# Generated at 2022-06-24 03:26:03.790932
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api")
    bpg.append(bp)
    bpg.append(bp2)


    del bpg[0]
    assert len(bpg.blueprints) == 1
    assert bpg.blueprints[0] == bp2

    #Deletion of invalid index
    with pytest.raises(IndexError):
        del bpg[2]



# Generated at 2022-06-24 03:26:10.891363
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bp_group = BlueprintGroup(bp1, bp2)

    assert len(bp_group) == 2

    del bp_group[1]

    assert len(bp_group) == 1


# Generated at 2022-06-24 03:26:20.050776
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    group_1 = BlueprintGroup(url_prefix="/api", version="v1")
    group_1.append(bp1)
    group_1.append(bp2)

    group_2 = BlueprintGroup(url_prefix="/api", version="v2")
    group_2.append(bp3)
    group_2.append(bp4)

    assert bp1.version == "v1"
    assert bp1.url_prefix == "/api/bp1"

# Generated at 2022-06-24 03:26:30.213680
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic(__name__)
    bpg = BlueprintGroup(url_prefix='/api', version='1')
    bpg.append(sanic.Blueprint('bp1', url_prefix='/bp1'))
    bpg.append(sanic.Blueprint('bp2', url_prefix='/bp2'))

    @bpg.middleware('request')
    async def bpg_only_middleware(request):
        print('applied on Blueprint Group')

    @bpg[1].middleware('request')
    async def bp2_only_middleware(request):
        print('applied on Blueprint : bp2 Only')


# Generated at 2022-06-24 03:26:34.852759
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    # GIVEN
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)

    # WHEN
    bpg.insert(0, bp2)

    # THEN
    assert bpg._blueprints[0].name == bp2.name
    assert bpg._blueprints[1] == bp1

# Generated at 2022-06-24 03:26:45.201602
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")

    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    assert 2 == len(bpg)
    assert bpg[0] is bp1
    assert bpg[1] is bp2

    bpg.append(bp3)
    assert bp3 is bpg[2]

    bpg.insert(1, bp3)
    assert bp3 is bpg[1]
    assert bpg[3] is bp3

    bpg.insert(len(bpg), bp3)

# Generated at 2022-06-24 03:26:46.436089
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    assert True



# Generated at 2022-06-24 03:26:54.590932
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    group = Blueprint.group(bp1, bp2)
    assert len(group._blueprints) == 2
    del group[0]
    assert len(group._blueprints) == 1
    assert group._blueprints[0].name == bp2.name


# Generated at 2022-06-24 03:27:01.553899
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)
    bpg.append(bp2)
    bpg[0] = bp3

    assert len(bpg) == 2
    assert bpg[0] == bp3
    assert bpg[1] == bp2


# Generated at 2022-06-24 03:27:12.962589
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    app = sanic.Sanic()
    group = Blueprint.group(bp1, bp2)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-24 03:27:18.015824
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    # Arrange
    from sanic.blueprints import Blueprint
    bpg = BlueprintGroup()
    bpg.append(Blueprint("b1"))
    bpg.append(Blueprint("b2"))
    bpg.append(Blueprint("b3"))
    expected = Blueprint("b2")
    # Act
    actual = bpg[1]
    # Assert
    assert actual == expected


# Generated at 2022-06-24 03:27:20.124740
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
  """
  This function is used to test the function BlueprintGroup.__setitem__()
  """
  pass


# Generated at 2022-06-24 03:27:29.911902
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    # Create a Blueprint Group
    bpg = BlueprintGroup(url_prefix="/api/v1")

    # Create a Blueprint
    bp = Blueprint("bp", url_prefix="/bp")

    # Create a Route
    @bp.route("/")
    async def bp_route(request):
        return text("Hello")

    # Append the blueprint to Blueprint Group
    bpg.append(bp)

    # Verify the length
    assert len(bpg) == 1

    # Create another Blueprint
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    # Create a Route
    @bp2.route("/")
    async def bp2_route(request):
        return text("Hello")

    # Append the second blueprint to Blueprint Group
    bpg.append(bp2)

    # Verify the length


# Generated at 2022-06-24 03:27:35.616969
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    url_prefix='/api'
    version = 1.0
    bp = Blueprint('bp', url_prefix='/bp', version=version)
    bpg = BlueprintGroup(url_prefix=url_prefix, version=version)
    bpg.insert(0, bp)
    assert len(bpg.blueprints) == 1
    assert bpg.blueprints[0] == bp

    assert bp.url_prefix == '/api/bp'
    assert bp.version == version


# Generated at 2022-06-24 03:27:38.962856
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bpg = BlueprintGroup()

    bpg.append(Blueprint('bp1', url_prefix='/bp1'))
    bpg.append(Blueprint('bp2', url_prefix='/bp2'))

    for bp in bpg:
        print(bp.name)

# Generated at 2022-06-24 03:27:47.527671
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')
    bp7 = Blueprint('bp7', url_prefix='/bp7')
    bp8 = Blueprint('bp8', url_prefix='/bp8')
    bp9 = Blueprint('bp9', url_prefix='/bp9')
    bp10 = Blueprint('bp10', url_prefix='/bp10')

# Generated at 2022-06-24 03:27:56.156527
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    """
    Verify that the method `BlueprintGroup.__delitem__` successfully deletes the
    blueprint from the Blueprint group
    """
    bp1 = sanic.Blueprint("bp1")
    bp2 = sanic.Blueprint("bp2")
    bpGroup = BlueprintGroup(url_prefix="/test")
    bpGroup.append(bp1)
    bpGroup.append(bp2)
    assert len(bpGroup) == 2
    del bpGroup[0]
    assert len(bpGroup) == 1
    assert bpGroup[0] == bp2


# Generated at 2022-06-24 03:28:04.400773
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3')
    bp4 = Blueprint('bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")


    bpg2 = BlueprintGroup(url_prefix="api", version="v1")
    bpg2.append(bp1)
    bpg2.append(bp2)

    assert len(bpg) == len(bpg2)



# Generated at 2022-06-24 03:28:09.717993
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)
    assert group[0] == bp1
    assert group[1] == bp2


# Generated at 2022-06-24 03:28:16.527191
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint_group = BlueprintGroup(
        url_prefix="testapi",
        version="v1",
        strict_slashes=False
    )
    assert blueprint_group.url_prefix == "testapi"
    assert blueprint_group.version == "v1"
    assert blueprint_group.strict_slashes == False


# Generated at 2022-06-24 03:28:21.651542
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    test_bp_obj = bpg[0]  
    assert test_bp_obj.name == "bp1"
    assert test_bp_obj.url_prefix == "/bp1"


# Generated at 2022-06-24 03:28:23.061800
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    pass # TODO: Implement test_BlueprintGroup_insert


# Generated at 2022-06-24 03:28:24.097990
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    assert True == True


# Generated at 2022-06-24 03:28:29.594466
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    g = BlueprintGroup(url_prefix='/api', version='v2')
    assert g.url_prefix == '/api'
    assert g.version == 'v2'
    assert g.strict_slashes is None
    assert len(g) == 0


# Generated at 2022-06-24 03:28:38.621884
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    group = BlueprintGroup(url_prefix="/api", version="v1")
    group.append(bp1)
    group.append(bp2)
    group.insert(0, bp2)

    assert group[0].name == "bp2"
    assert group[1].name == "bp1"
    assert group[2].name == "bp2"


# Generated at 2022-06-24 03:28:49.133311
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    # Arrange
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")

    class MockSanic:
        def __init__(self):
            self.blueprints = []

    mock_sanic = MockSanic()

    bp_group = BlueprintGroup()
    bp_group.append(bp1)

    bp_group.append(bp2)

    # Act
    bp_group.insert(0, bp3)

    # Assert
    assert isinstance(bp_group._blueprints[0], Blueprint)

# Generated at 2022-06-24 03:28:58.620634
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    assert len(bpg) == 4
    assert bpg[0] == bp1
    assert bpg[-1] == bp4
    assert bpg[3] == bp4
    bpg.append(bp1)
    assert bpg[4] == bp1


# Generated at 2022-06-24 03:29:03.998533
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    class BlueprintGroup(object):
        def __init__(self):
            self._blueprints = [1, 2, 3, 4]
        def __len__(self):
            return len(self._blueprints)
    bp_group = BlueprintGroup()
    assert len(bp_group) == 4


# Generated at 2022-06-24 03:29:13.705136
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    # Arrange
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)

    # Act
    bpg.insert(0,bp2)

    # Assert
    assert bpg[0].name == bp2.name
    assert bpg[0].version == 'v1'
    assert bpg[0].strict_slashes == True
    assert bpg[1].name == bp1.name
    assert bpg[1].version == 'v1'
    assert bpg[1].strict_slashes == True
    assert bpg.version == 'v1'
    assert bpg.st

# Generated at 2022-06-24 03:29:21.843390
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    """
    Unit test for method __iter__ of class BlueprintGroup
    """
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bp3 = Blueprint('bp3')
    bpGroup = BlueprintGroup()
    bpGroup.append(bp1)
    bpGroup.append(bp2)
    bpGroup.append(bp3)
    bpGroup_iter = iter(bpGroup)
    assert next(bpGroup_iter) == bp1
    assert next(bpGroup_iter) == bp2
    assert next(bpGroup_iter) == bp3


# Generated at 2022-06-24 03:29:27.541232
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    assert len(bpg) == 1
    assert bpg[0] == bp1

# Generated at 2022-06-24 03:29:38.643523
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    class Blueprint(sanic.Blueprint):
        def __init__(self, name, url_prefix=None, subdomain=None, version=None, strict_slashes=None):
            super().__init__(name, url_prefix, subdomain, version, strict_slashes)

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp1)

    assert bpg[0].url_prefix == '/bp1'
    assert bpg.blueprints == [bp1]

    bpg.insert(0, bp3)

# Generated at 2022-06-24 03:29:43.745065
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group = BlueprintGroup()
    blueprint = Blueprint('blueprint1')
    blueprint_group.append(blueprint)
    blueprint_group.append(blueprint)
    blueprint_group.append(blueprint)
    del blueprint_group[1]
    assert len(blueprint_group) == 2


# Generated at 2022-06-24 03:29:50.496491
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bp3 = Blueprint("bp3")

    bpg = BlueprintGroup()

    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    assert bpg.blueprints == [bp1, bp2, bp3]


# Generated at 2022-06-24 03:29:59.760750
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup()

    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    bpg.insert(2, bp4)

    assert bpg._blueprints[2] == bp4


# Generated at 2022-06-24 03:30:06.974884
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')

    bpg = BlueprintGroup(bp3, bp1, bp2, url_prefix="/api", version="v1")

    assert bpg[0] == bp3
    assert bpg[1] == bp1
    assert bpg[2] == bp2


# Generated at 2022-06-24 03:30:14.301530
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp_group = BlueprintGroup()
    bp1 = Blueprint("test1")
    bp2 = Blueprint("test2")
    bp3 = Blueprint("test3")
    bp_group.append(bp1)
    bp_group.append(bp2)
    bp_group.append(bp3)

    assert bp_group[0] == bp1
    assert bp_group[1] == bp2
    assert bp_group[2] == bp3

    for i in bp_group:
        assert i in [bp1, bp2, bp3]


# Generated at 2022-06-24 03:30:25.936216
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp = Blueprint("bp", url_prefix="/bp")

    class Middleware(sanic.BaseHTTPMiddleware):
        def resolve_match(self, request, match):
            for blueprint in match.blueprints:
                if blueprint is bp:
                    return True
            return False

        async def resolve_request(self, request, handler):
            request["request_data"] = {"type": "middleware"}

    bpg = BlueprintGroup(bp, url_prefix="/bpg")

    @bpg.middleware
    def middleware_function(request):
        request["request_data"] = {"type": "middleware"}

    @bp.route("/")
    async def route(request):
        return text(request["request_data"]["type"])

    app = sanic.Sanic()
    app.blueprint

# Generated at 2022-06-24 03:30:35.009577
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    del bpg[0]
    del bpg[1]
    bpg[0]
    assert bpg[0] is bp3
    assert bpg[0] is not bp1
    assert bpg[1] is bp4
    assert bpg[1] is not bp2


#

# Generated at 2022-06-24 03:30:45.528852
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bp3 = sanic.Blueprint('bp3', url_prefix='/bp3')
    bp4 = sanic.Blueprint('bp4', url_prefix='/bp4')
    bp_group_eg1 = BlueprintGroup()
    bp_group_eg2 = BlueprintGroup()
    bp_group_eg2.append(bp1)
    bp_group_eg2.append(bp2)
    bp_group_eg1.append(bp3)
    bp_group_eg1.append(bp4)
    bp_group_eg1.insert(1, bp_group_eg2)

# Generated at 2022-06-24 03:30:50.193567
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    # test of BlueprintGroup __getitem__ - 1
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    group = Blueprint.group(bp1, bp2)

    assert bp1 == group[0]
    assert bp2 == group[1]


# Generated at 2022-06-24 03:30:59.808082
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")

    bpg = BlueprintGroup()

    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)

    assert len(bpg) == 3
    assert bpg[0] is bp1
    with pytest.raises(IndexError):
        bpg[3]
    with pytest.raises(IndexError):
        bpg[-4]


# Generated at 2022-06-24 03:31:03.865663
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    from sanic import Blueprint
    blueprint_group = BlueprintGroup()
    blueprint_group.append(Blueprint('bp1', url_prefix='/bp1'))
    blueprint_group.append(Blueprint('bp2', url_prefix='/bp2'))
    assert len(blueprint_group) == 2


# Generated at 2022-06-24 03:31:06.961276
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bpg = BlueprintGroup()
    bp = Blueprint("bp")
    bpg[0] = bp
    assert bp is bpg[0]


# Generated at 2022-06-24 03:31:14.030417
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    rv = BlueprintGroup(url_prefix='/v1')
    assert len(rv) == 0
    rv = BlueprintGroup('/v1', 'v1.0')
    assert len(rv) == 0
    rv = BlueprintGroup('/v1', 'v1.0', True)
    assert len(rv) == 0
    rv = BlueprintGroup('/v1', 'v1.0', False)
    assert len(rv) == 0


# Generated at 2022-06-24 03:31:18.667534
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg[1] = bp1
    assert bpg[1] == bp1


# Generated at 2022-06-24 03:31:27.101723
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpGrp = BlueprintGroup()
    assert bpGrp.blueprints == []

    bpGrp.append(bp1)
    assert bpGrp.blueprints == [bp1]

    bpGrp.append(bp2)
    assert bpGrp.blueprints == [bp1, bp2]

    bpGrp.append(bp3)
    assert bpGrp.blueprints == [bp1, bp2, bp3]

    # value list of Blueprint will be

# Generated at 2022-06-24 03:31:34.370815
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bp3 = sanic.Blueprint('bp3', url_prefix='/bp3')
    bp4 = sanic.Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix='/api', version='v1')
    items = list(bpg)
    assert len(items) == 2
    assert items == [bp3, bp4]


# Generated at 2022-06-24 03:31:41.137207
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    app = sanic.Sanic()
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert bp1 in bpg
    assert bp2 in bpg


# Generated at 2022-06-24 03:31:47.600650
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bpg = BlueprintGroup()
    assert len(bpg) == 0
    bpg.append(Blueprint("bp1", url_prefix="/bp1"))
    assert len(bpg) == 1
    bpg.append(Blueprint("bp2", url_prefix="/bp2"))
    assert len(bpg) == 2
    bpg.append(Blueprint("bp3", url_prefix="/bp3"))
    assert len(bpg) == 3


# Generated at 2022-06-24 03:31:58.703822
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bpg = BlueprintGroup(url_prefix="/api", version="v1", strict_slashes=False)
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg) == 2
    assert bpg.url_prefix == "/api"
    assert bpg.version == "v1"
    assert bpg.strict_slashes is False
    assert bpg.blueprints[0].url_prefix == "/api/bp1"
    assert bpg.blueprints[1].url_prefix == "/api/bp2"
    assert bpg.blueprints[0].version == "v1"

# Generated at 2022-06-24 03:32:08.574377
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    group = Blueprint.group(bp1, bp2)

    @group.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')


# Generated at 2022-06-24 03:32:17.497926
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    # Create BlueprintGroup object
    bpg = BlueprintGroup()
    # Register 3 Blueprints to the BlueprintGroup
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bp3 = Blueprint("bp3")
    bpg.append(bp1)
    bpg.append(bp2)
    # Inserting a blueprint at position 0
    bpg.insert(0, bp3)
    assert bpg[0].name == "bp3"
    assert bpg[1].name == "bp1"
    assert bpg[2].name == "bp2"


# Generated at 2022-06-24 03:32:21.686019
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    bpg.middleware(sanic.request_middleware)

    assert bp1.middlewares is not None
    assert bp2.middlewares is not None

# Generated at 2022-06-24 03:32:28.331728
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup('bp3', 'bp4', url_prefix="/api", version="v1")
    bpg[0] = bp1
    bpg[1] = bp2
    assert(bpg[0] == bp1)
    assert(bpg[1] == bp2)


# Generated at 2022-06-24 03:32:35.786252
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    # set up for BlueprintGroup
    url_prefix = 'test'
    version = 'v1.0'
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix, version)
    # case 0: Normal set
    bpg.append(bp1)
    bpg._blueprints[0] = bp2
    # check
    assert bpg.blueprints[0] == bp2
    # case 1: set with index too high
    try:
        bpg[2] = bp1
    except IndexError:
        pass
    # case 2: set with index less then 0

# Generated at 2022-06-24 03:32:36.749249
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    pass

# Generated at 2022-06-24 03:32:47.918731
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix='/api', version='v1')
    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg.url_prefix == '/api'
    assert bpg.version == 'v1'

    assert bp1.url_prefix == '/api/bp1'
    assert bp2.url_prefix == '/api/bp2'
    assert bp1.version == 'v1'
    assert bp2.version == 'v1'

# Unit test to check BlueprintGroup appending

# Generated at 2022-06-24 03:32:54.040874
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bpg.insert(1, bp3)
    assert bpg.blueprints == [bp1, bp3, bp2]

# Generated at 2022-06-24 03:33:02.378848
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    # Create a Blueprint Group
    bp_url_prefix = "/api"
    bp_version = "v1"
    bp_strict_slashes = False
    bp_group = BlueprintGroup(url_prefix=bp_url_prefix,
                              version=bp_version,
                              strict_slashes=bp_strict_slashes)

    # Create a Blueprint
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    # Store the blueprint in the group
    bp_group[0] = bp1
    bp_group[1] = bp2

    # Ensure the blueprint group is behaving like a list
    assert len(bp_group) == 2

# Generated at 2022-06-24 03:33:13.057970
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    
@bp1.middleware('request')
async def bp1_only_middleware(request):
    print('applied on Blueprint : bp1 Only')

@bp1.route('/')
async def bp1_route(request):
    return text('bp1')


# Generated at 2022-06-24 03:33:24.503257
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    # Verify that the __iter__ method of BlueprintGroup can be used to iterate
    # through its blueprints list, and the resulting iterator can be consumed
    # by list()
    actual = list(bpg)
    assert actual == [bp1, bp2], "__iter__ method does not work as expected"
    expected = [bp1, bp2]
    for i in bpg:
        actual = i
        expected.remove(actual)
    assert not expected, "__iter__ method does not work as expected"


# Generated at 2022-06-24 03:33:35.164200
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    # Test case with no parameter
    bp_group1 = BlueprintGroup()
    assert bp_group1.url_prefix is None
    assert bp_group1.version is None
    assert bp_group1.strict_slashes is None
    assert len(bp_group1) == 0

    # Test case with specified parameters
    bp_group2 = BlueprintGroup(
        url_prefix="/prefix", version="v1", strict_slashes=False
    )
    assert bp_group2.url_prefix == "/prefix"
    assert bp_group2.version == "v1"
    assert bp_group2.strict_slashes is False
    assert len(bp_group2) == 0



# Generated at 2022-06-24 03:33:41.957200
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    class Blueprint1(sanic.Blueprint):
        ...

    class Blueprint2(sanic.Blueprint):
        ...

    bp1 = Blueprint1(url_prefix='/bp1')
    bp2 = Blueprint2(url_prefix='/bp2')

    bp3 = Blueprint1(url_prefix='/bp1')
    bp4 = Blueprint1(url_prefix='/bp2')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    del bpg[0]
    assert len(bpg) == 1


# Generated at 2022-06-24 03:33:51.381003
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    app = sanic.Sanic()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.insert(0, bp3)
    bpg.insert(2, bp4)
    assert bpg[0] == bp3
    assert bpg[2] == bp4
    assert bpg[1] == bp1
    assert bpg[2] == bp4


# Generated at 2022-06-24 03:34:01.258202
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    # Prepare the test case, declare all the required mocks
    mock_blueprint_1 = MagicMock(spec=sanic.Blueprint)
    mock_blueprint_2 = MagicMock(spec=sanic.Blueprint)
    mock_blueprint_3 = MagicMock(spec=sanic.Blueprint)

    bp_group_object = BlueprintGroup()

    # Perform the test case
    bp_group_object.append(mock_blueprint_1)
    bp_group_object.insert(0, mock_blueprint_2)

    # Verify the test case
    mock_blueprint_1.assert_not_called()
    mock_blueprint_2.assert_not_called()
    mock_blueprint_3.assert_not_called()


# Generated at 2022-06-24 03:34:09.193496
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    """
    This unit test tests the `BlueprintGroup.__iter__()` method to ensure
    that the class can be iterated over.
    """
    bp_group = BlueprintGroup()
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp_group.append(bp1)
    bp_group.append(bp2)
    assert bp_group[0] == bp1
    assert bp_group[1] == bp2


# Generated at 2022-06-24 03:34:20.294768
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix='/api', version='v1')
    bpg.append(bp1)
    
    bpg[0] = bp2
    assert bpg[0] == bp2 and bpg.blueprints[0] == bp2 and bpg.blueprints == [bp2]
    
    bpg[0] = bp3

# Generated at 2022-06-24 03:34:28.705475
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.extend([bp3, bp4])

    assert bp3 == bpg[0]
    assert bp4 == bpg[1]



# Generated at 2022-06-24 03:34:30.369125
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    """"""
    BlueprintGroup().__setitem__(0, sanic.Blueprint('name'))


# Generated at 2022-06-24 03:34:38.125488
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')

    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp3)
    bpg.append(bp2)
    bpg.insert(0, bp1)
    assert bpg.blueprints[0] == bp1

# Generated at 2022-06-24 03:34:47.358633
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp3', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-24 03:34:52.664902
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2)
    assert len([i for i in bpg]) == 2

