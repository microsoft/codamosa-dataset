

# Generated at 2022-06-24 03:24:59.609759
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    """
    Testing BlueprintGroup.append() method
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/prefix")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    assert len(bpg.blueprints) == 4
    assert bpg.blueprints[0].name == bp1.name
    assert bpg.blueprints[0].url_prefix == '/prefix/bp1'


# Generated at 2022-06-24 03:25:07.735460
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    a = BlueprintGroup(bp3, bp4)
    b = BlueprintGroup(a, url_prefix="/api", version="v1")
    # b is a BlueprintGroup, [bp3,bp4] is its blueprints, when middleware is invoked
    # [bp1,bp2,bp3,bp4] is applied to two bp1,bp2's middleware
    c = BlueprintGroup(b, bp1, bp2, url_prefix=None, version=None)


# Generated at 2022-06-24 03:25:15.613451
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    # Create some blueprints
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    # Create a list of blueprints
    blueprints = [bp1, bp2]

    # Create a group from list of blueprints
    group = BlueprintGroup(blueprints, url_prefix="/api", version="v1")

    # Check if __iter__ is implemented.
    for bp in group:
        assert bp

    # Check if __getitem__ is implemented.
    assert group[0] == bp1
    assert group[1] == bp2

    # Check if

# Generated at 2022-06-24 03:25:19.185401
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint = Blueprint('test')
    blueprint_group = BlueprintGroup()
    blueprint_group.append(blueprint)
    blueprint_group.__setitem__(0, blueprint)
    assert blueprint_group[0] == blueprint


# Generated at 2022-06-24 03:25:28.287924
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    assert bpg.__iter__() == [bp3, bp4]
    bpg = BlueprintGroup()
    assert bpg.__iter__() == []
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    assert bpg.__iter__() == [bp1, bp2]


# Generated at 2022-06-24 03:25:38.552863
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Blueprint 1
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    # Blueprint 2
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        raise Exception('applied on Blueprint : bp1 Only')

    @bp2.middleware('request')
    async def bp2_only_middleware(request):
        raise Exception('applied on Blueprint : bp2 Only')

    group = BlueprintGroup

# Generated at 2022-06-24 03:25:42.220663
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = sanic.Blueprint('bp1')
    bp2 = sanic.Blueprint('bp2')

    BlueprintGroup.append(bp1)
    BlueprintGroup.append(bp2)

# Generated at 2022-06-24 03:25:52.485714
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')
    bp7 = Blueprint('bp7', url_prefix='/bp7')
    bp8 = Blueprint('bp8', url_prefix='/bp8')

    bpg = BlueprintGroup()
    assert len(bpg) == 0
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)

# Generated at 2022-06-24 03:25:59.553635
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")

    group = BlueprintGroup("/prefix", "v1", strict_slashes=True)
    group.extend([bp1, bp2, bp3, bp4])
    bp_names = [bp.name for bp in group]
    assert bp_names == ["bp1", "bp2", "bp3", "bp4"]



# Generated at 2022-06-24 03:26:06.189172
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_1 = Blueprint(
        name="Blueprint_1", url_prefix="/v1", strict_slashes=True, version="1.0"
    )
    blueprint_2 = Blueprint(
        name="Blueprint_2", url_prefix="/v2", strict_slashes=True, version="1.1"
    )
    blueprint_group = BlueprintGroup(
        url_prefix="/api", strict_slashes=True, version="1.0"
    )
    blueprint_group.append(blueprint_1)
    blueprint_group.append(blueprint_2)
    for i, bp in enumerate(blueprint_group):
        assert isinstance(bp, Blueprint)
        assert bp.name == f"Blueprint_{i+1}"

# Generated at 2022-06-24 03:26:12.621263
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')

    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')

    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)



# Generated at 2022-06-24 03:26:21.443919
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    from sanic import Blueprint
    bp1 = Blueprint("bp1", version="v1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", version="v2", url_prefix="/bp2")
    bpg = BlueprintGroup()
    bpg.insert(0, bp1)
    bpg.insert(0, bp2)

    assert bpg.blueprints[0].version == "v1"
    assert bpg.blueprints[0].url_prefix == "/bp2"
    assert bpg.blueprints[1].version == "v2"
    assert bpg.blueprints[1].url_prefix == "/bp1"
    bpg.insert(0, bp1)
    assert bpg.blueprints[0].url_prefix == "/bp2"

# Generated at 2022-06-24 03:26:28.608301
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    group = Blueprint.group(bp1, bp2, bp3, bp4)
    assert isinstance(group, BlueprintGroup)
    for bp in group:
        assert isinstance(bp, Blueprint)


# Generated at 2022-06-24 03:26:34.292026
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    assert bp1 in bpg



# Generated at 2022-06-24 03:26:44.190140
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    print("\n\n==========\n")

    print("Create Blueprint")
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    print("Create Blueprint Group")
    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    print("Add bp1 and bp2 to bpg")
    bpg.append(bp1)
    bpg.append(bp2)

    print("Length = ", len(bpg._blueprints))
    print("for loop")
    for bp in bpg:
        print(bp)

    print("bpg[0]:", bpg[0])
    print("bpg[1]:", bpg[1])

# Generated at 2022-06-24 03:26:54.985495
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    """
    Test of method __getitem__ of class BlueprintGroup
    """
    blueprints = [sanic.Blueprint("bp{}".format(i)) for i in range(10)]
    bp_group = BlueprintGroup("/prefix", "v1")
    for bp in blueprints:
        bp_group.append(bp)

    assert bp_group[1].name == blueprints[1].name
    assert bp_group[-1].name == blueprints[-1].name

    try:
        bp_group[10]
    except IndexError:
        pass
    else:
        raise AssertionError

    try:
        bp_group[-11]
    except IndexError:
        pass
    else:
        raise AssertionError


# Generated at 2022-06-24 03:27:01.623200
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.extend((bp1, bp2, bp3, bp4))
    del bpg[0]
    assert len(bpg) == 3
    assert bpg.blueprints == [bp2, bp3, bp4]


# Generated at 2022-06-24 03:27:13.085623
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    old_bp = Blueprint('old_bp')
    new_bp = Blueprint('new_bp')

    old_bp.route('/')(lambda x:x)
    new_bp.route('/')(lambda x:x)

    assert old_bp.url_prefix is None
    assert new_bp.url_prefix is None

    # Unit test add blueprint to blueprint group
    bpg = BlueprintGroup()
    bpg.append(old_bp)
    bpg.append(new_bp)

    assert old_bp in bpg
    assert new_bp in bpg

    # Unit test url_prefix of blueprint group
    bpg = BlueprintGroup('/bpg')
    bpg.append(old_bp)
    bpg.append(new_bp)


# Generated at 2022-06-24 03:27:17.196965
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)
    for bp in group:
        assert isinstance(bp, Blueprint)



# Generated at 2022-06-24 03:27:25.286980
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class TestApp(sanic.Sanic):
        pass

    app = TestApp()

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-24 03:27:36.260106
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup()
    bpg.append(bp4)
    bpg.append(bp3)
    bpg.append(bp2)
    bpg.append(bp1)
    bpg.append(bp3)
    bpg.append(bp2)
    bpg.append(bp1)
    bpg.append(bp3)
    bpg.append(bp2)
    bpg.append(bp1)


# Generated at 2022-06-24 03:27:43.535704
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    """
    Test Blueprint Group constructor
    """
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    group = BlueprintGroup(bp1, bp2, url_prefix="/group", version="v1")
    assert group.url_prefix == "/group"
    assert group.version == "v1"
    assert len(group.blueprints) == 2
    assert group.blueprints[0].url_prefix == "/bp1"
    assert group.blueprints[1].url_prefix == "/bp2"
    assert group.blueprints[0].version == "v1"
    assert group.blueprints[1].version == "v1"


# Generated at 2022-06-24 03:27:48.353776
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    group = BlueprintGroup()
    assert len(group) == 0

    group = BlueprintGroup()
    group._blueprints.append(1)
    assert len(group) == 1

    group = BlueprintGroup()
    group._blueprints.append(1)
    group._blueprints.append(2)
    assert len(group) == 2



# Generated at 2022-06-24 03:27:58.985523
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix='/api', version='v1')

    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    bpg[0] = bp1
    bpg[1] = bp2
    bpg[2] = bp3
    bpg[3] = bp4

    assert bpg.blueprints[0] == bp1
    assert bpg

# Generated at 2022-06-24 03:28:08.759852
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    assert bp1.name == "bp1"
    assert bp2.name == "bp2"

    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")
    assert bp3.name == "bp3"
    assert bp4.name == "bp4"

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    assert bpg.url_prefix == "/api"
    assert bpg.version == "v1"
    assert len(bpg) == 2

    with pytest.raises(RuntimeError):
        Blueprint

# Generated at 2022-06-24 03:28:15.277868
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    """ 
        Unit test for method append of class BlueprintGroup
    """

    from sanic.blueprints import Blueprint

    bp_obj = Blueprint(name="hello", url_prefix="/hello/")
    bp_group = BlueprintGroup()

    bp_group.append(bp_obj)

    assert bp_group[0] == bp_obj
    assert bp_group.url_prefix == None
    assert bp_group.version == None
    assert bp_group.strict_slashes == None



# Generated at 2022-06-24 03:28:16.273985
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    pass


# Generated at 2022-06-24 03:28:22.663576
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    """
    Test for the BlueprintGroup constructor
    """
    bpg = BlueprintGroup(url_prefix="/api")
    assert bpg.url_prefix == "/api"

    bpg = BlueprintGroup(url_prefix=None)
    assert bpg.url_prefix is None

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    assert bpg.version == "v1"

    bpg = BlueprintGroup(url_prefix="/api", strict_slashes=True)
    assert bpg.strict_slashes is True



# Generated at 2022-06-24 03:28:32.346679
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1", strict_slashes=True)
    assert bpg.url_prefix == "/api"
    assert bpg.version == "v1"
    assert bpg.strict_slashes == True
    bpg.insert(0, bp1)
    assert bpg[0] == bp1
    assert bp1.url_prefix == '/api/bp1'
    assert bp1.version == 'v1'
    assert bp

# Generated at 2022-06-24 03:28:34.167023
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    BlueprintGroup._setitem__(None,1,3)
    assert 1 == 1


# Generated at 2022-06-24 03:28:45.276538
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class App(sanic.Sanic):
        def __init__(self):
            super().__init__()
            self.blueprint_group = BlueprintGroup()
            self.request_middleware = []
            self.response_middleware = []

        def register_blueprint(self, blueprint: Blueprint) -> None:
            self.blueprint_group.append(blueprint)

        def log_request_response(self, request, response):
            self.request_middleware.append(request)
            self.response_middleware.append(response)

    app = App()
    url_prefix = '/api'
    version = 1
    blueprint = Blueprint('test_bp', url_prefix=url_prefix)


# Generated at 2022-06-24 03:28:53.920946
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')
    bpg = BlueprintGroup(bp4, bp5, bp6, url_prefix="/api", version="v1")
    assert bpg[0] == bp4
    assert bpg[1] == bp5
    assert bpg[2] == bp6

# Generated at 2022-06-24 03:29:01.618412
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    # Initialize Sanic application
    app = sanic.Sanic(__name__)

    # Create Blueprint
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')

    # Create BlueprintGroup
    bpg = BlueprintGroup()

    # Assert __len__ is equal 0
    assert len(bpg) == 0

    # Append Blueprint to Blueprint Group
    bpg.append(bp1)
    bpg.append(bp2)

    # Assert __len__ is equal 2
    assert len(bpg) == 2


# Generated at 2022-06-24 03:29:11.770523
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    # Create a Blueprint Group object
    bpg1 = BlueprintGroup()

    # create blueprint objects
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bp3 = Blueprint("bp3")

    # Add Blueprint to Blueprint Group
    bpg1.append(bp1)
    bpg1.append(bp2)

    # Try to append Blueprint Group within Blueprint Group
    bpg2 = BlueprintGroup()
    bpg2.append(bp3)

    bpg1.append(bpg2)

    # Assert the same is added in the Blueprint List
    assert len(bpg1) == 3
    assert bpg1[2] is bpg2
    assert len(bpg2) == 1
    assert bpg2[0] is bp3


# Generated at 2022-06-24 03:29:21.183470
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    assert len(bpg) == 0

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    assert len(bpg) == 2


# Generated at 2022-06-24 03:29:32.792821
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp3', url_prefix='/bp4')
    bp5 = Blueprint('bp3', url_prefix='/bp5')
    bp6 = Blueprint('bp3', url_prefix='/bp6')
    bp7 = Blueprint('bp3', url_prefix='/bp7')
    bp8 = Blueprint('bp3', url_prefix='/bp8')
    bp9 = Blueprint('bp3', url_prefix='/bp9')
    bp10 = Blueprint('bp3', url_prefix='/bp10')

# Generated at 2022-06-24 03:29:42.229461
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix='/api')

    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    bp = bpg[2]

    assert bp.url_prefix == '/api/bp3'



# Generated at 2022-06-24 03:29:45.745214
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp = Blueprint("test_bp", url_prefix="/test_bp")
    bpg = BlueprintGroup("/test_bpg")
    bpg.append(bp)
    del bpg[0]
    assert len(bpg.blueprints) == 0


# Generated at 2022-06-24 03:29:55.930190
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    blueprints = BlueprintGroup(url_prefix='/api', version='v1')
    blueprints.insert(0, bp1)
    blueprints.insert(1, bp2)
    blueprints.insert(2, bp3)

    assert blueprints[0] is bp1
    assert blueprints[1] is bp2
    assert blueprints[2] is bp3
    assert len(blueprints) == 3
    blueprints.insert(1, bp4)

# Generated at 2022-06-24 03:30:06.326171
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    class MockBlueprint:
        def __init__(self, prefix):
            self.url_prefix = prefix
    
    class MockApp:
        def __init__(self, blueprints):
            self.blueprints = blueprints
            
    bpg = BlueprintGroup()
    bpg.append(MockBlueprint("/bp1"))
    bpg.append(MockBlueprint("/bp2"))
    
    assert bpg[0].url_prefix == "/bp1"
    assert bpg[1].url_prefix == "/bp2"
    
    app = MockApp(bpg)
    
    assert app.blueprints[0].url_prefix == "/bp1"
    assert app.blueprints[1].url_prefix == "/bp2"
    

# Generated at 2022-06-24 03:30:15.410883
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bp3 = Blueprint('bp3')
    bp4 = Blueprint('bp4')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    bpg[0] = Blueprint('bp1')
    bpg[1] = Blueprint('bp2')
    bpg[2] = Blueprint('bp3')
    bpg[3] = Blueprint('bp4')
    bpg[-1] = Blueprint('bp4')
    bpg[-4] = Blueprint('bp4')
    for i in [1,2,3]:
        bpg[i] = bpg[i-1]


# Generated at 2022-06-24 03:30:23.297779
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    # Verify that all the blueprints are in the group
    [bp1,bp2,bp3,bp4]
    del bpg[0]
    assert len(bpg) == 3
    assert bp1 not in bpg
    assert bp2 in bpg
    assert bp3 in bpg
    assert b

# Generated at 2022-06-24 03:30:27.042951
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bg = BlueprintGroup()
    bg.append(bp1)
    bg.append(bp2)

    assert list(bg) == [bp1, bp2]



# Generated at 2022-06-24 03:30:32.803455
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)

    for bp in bpg:
        assert isinstance(bp, Blueprint)
    assert bp1 in bpg
    assert bp2 in bpg
    assert bp3 in bpg



# Generated at 2022-06-24 03:30:37.837417
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bpg = BlueprintGroup('/api')
    bpg.append(bp1)
    bpg.append(bp2)
    assert list(bpg) == [bp1, bp2]



# Generated at 2022-06-24 03:30:45.848666
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from .utils import MockApplication
    import pytest
    app = MockApplication()
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')

    @bp1.route('/')
    async def bp1_route(request):
        return text(bp1.url_prefix)

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(bp2.url_prefix)

    @bp2.middleware('request')
    async def bp2_only_middleware(request):
        print('applied on Blueprint : bp2 Only')


# Generated at 2022-06-24 03:30:53.065918
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    class A:
        pass

    @bp1.route("/")
    async def bp1_r(r):
        pass

    @bp2.route("/")
    async def bp2_r(r):
        pass

    @bp2.middleware("request")
    async def bp2_m(r):
        pass

    bp_group = BlueprintGroup("/api")
    bp_group.append(bp1)
    bp_group.append(bp2)

    assert bp_group[0].url_prefix == "/api/bp1"
    assert bp_group[1].url_prefix == "/api/bp2"


# Generated at 2022-06-24 03:31:03.228390
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    app = sanic.Sanic()
    bp1 = Blueprint('test_bp1', url_prefix='/test/bp1')
    bp2 = Blueprint('test_bp2', url_prefix='/test/bp2')
    bp3 = Blueprint('test_bp3', url_prefix='/test/bp3')
    bp4 = Blueprint('test_bp4', url_prefix='/test/bp4')

    @bp1.route('/bp1')
    async def bp1_route(request): return text('bp1')

    @bp2.route('/bp2')
    async def bp2_route(request): return text('bp2')

    @bp3.route('/bp3')
    async def bp3_route(request): return text('bp3')


# Generated at 2022-06-24 03:31:14.795473
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1', strict_slashes=True)
    bp2 = Blueprint('bp2', url_prefix='/bp2', strict_slashes=False)

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    assert list(bpg.blueprints) == []
    bpg.append(bp1)
    assert len(bpg) == 1
    assert list(bpg.blueprints) == [bp1]
    assert bpg[0] == bp1
    bpg.insert(0, bp2)
    assert list(bpg.blueprints) == [bp2, bp1]
    assert bpg[0] == bp2
    assert bpg[1] == bp1



# Generated at 2022-06-24 03:31:23.562183
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    # Prepare test data
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg1 = BlueprintGroup(url_prefix="/api", version="v1")
    bpg1._blueprints.append(bp1)
    bpg1._blueprints.append(bp2)
    bpg1.append(bp3)
    bpg1.append(bp4)
    # Perform testing
    assert bpg1[0].name == 'bp1'
    bpg1[0] = bp4
    assert bpg1[0].name == 'bp4'


# Generated at 2022-06-24 03:31:33.910424
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    group = BlueprintGroup()
    group1 = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    group2 = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v2")

    assert group.url_prefix is None
    assert group.version is None
    assert group.strict_slashes is None

    assert group1.url_prefix == '/api'
    assert group1.version == 'v1'
    assert group1.strict_sl

# Generated at 2022-06-24 03:31:35.166517
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    pass


# Generated at 2022-06-24 03:31:43.354296
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    """
    Test to check the implementation of the _len_ method for the Blueprint
    Group class.

    This test is needed to ensure that the Blueprint Groups are still behaving
    like a list when used as a parameter to the registration function as this
    is not a part of the BlueprintGroup class.
    """
    # Create two blueprints
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')

    # Create a list of Blueprints
    bps = [bp1, bp2]

    # Create a Blueprint Group with the existing blueprints
    bpg = BlueprintGroup(*bps, url_prefix='/api', version='v1')

    # Verify that the length of the Blueprint Group is the same as the List
    assert len(bpg) == len(bps)

    # Test the BlueprintGroup in a tuple like context

# Generated at 2022-06-24 03:31:45.289885
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bpg = BlueprintGroup(url_prefix='/api', version='v1')
    assert len(bpg) == 0

# Generated at 2022-06-24 03:31:49.937315
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp = Blueprint("bp", "bp")
    blueprint_group = BlueprintGroup()
    blueprint_group.insert(0, bp)
    assert blueprint_group[0].name == "bp"
    assert blueprint_group[0].url_prefix == "bp"
    assert blueprint_group[0].strict_slashes is None


# Generated at 2022-06-24 03:31:55.876457
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_group = BlueprintGroup()
    blueprint_group.append(0)
    blueprint_group.append(1)
    blueprint_group.append(2)

    assert blueprint_group[0] == 0
    assert blueprint_group[1] == 1
    assert blueprint_group[2] == 2

    assert blueprint_group[-1] == 2
    assert blueprint_group[-2] == 1
    assert blueprint_group[-3] == 0

    with pytest.raises(IndexError, match=r"^list index out of range$"):
        blueprint_group[-4]
    with pytest.raises(IndexError, match=r"^list index out of range$"):
        blueprint_group[3]


# Generated at 2022-06-24 03:31:59.748185
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)
    assert len(group) == 2


# Generated at 2022-06-24 03:32:05.283737
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp1', url_prefix='/bp1')
    bpg = BlueprintGroup()
    assert len(bpg) == 0
    bpg.append(bp1)
    assert len(bpg) == 1
    bpg.append(bp2)
    assert len(bpg) == 2


# Generated at 2022-06-24 03:32:14.627571
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():

    from sanic import Blueprint

    bp1 = Blueprint('bp1', url_prefix='/bp1')

    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')

    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    assert len(bpg) == 4

    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert bpg[2] == bp3
    assert bpg[3] == bp4

# Generated at 2022-06-24 03:32:20.804267
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')  
    bpG = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1") 
    l = BlueprintGroup.__len__(bpG) #Call the method by passing the instance/object as the first argument
    assert l == 2
    print(l)

if __name__ == "__main__":
    test_BlueprintGroup___len__()

# Generated at 2022-06-24 03:32:30.773296
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    bpg.append(bp5)
    assert bpg.blueprints == [bp1, bp2, bp3, bp4, bp5]



# Generated at 2022-06-24 03:32:39.312899
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    b1 = sanic.blueprints.Blueprint(
        "b1", url_prefix="/api/b1", strict_slashes=False
    )
    bp_group = sanic.blueprints.BlueprintGroup(
        url_prefix="/api", strict_slashes=False
    )
    bp_group.append(b1)
    assert len(bp_group) == 1
    del bp_group[0]
    assert len(bp_group) == 0



# Generated at 2022-06-24 03:32:43.897555
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    BlueprintGroup1 = BlueprintGroup()
    BlueprintGroup1.append(sanic.Blueprint('bp1', url_prefix='/bp1'))
    BlueprintGroup1.append(sanic.Blueprint('bp2', url_prefix='/bp2'))
    assert len(BlueprintGroup1) == 2


# Generated at 2022-06-24 03:32:44.994678
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    pass



# Generated at 2022-06-24 03:32:54.340817
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    This method is used to test the 'middleware' method of the class
    BlueprintGroup.
    """
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware("request")
    async def group_middleware(request):
        pass

    # Asserting the test for the presence of middleware for each blueprint
    # that belongs to this blueprint group.
    for blueprint in bpg.blueprints:
        assert blueprint._middleware["request"] == [group_middleware]

# Generated at 2022-06-24 03:32:55.658416
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    pass


# Generated at 2022-06-24 03:33:01.102858
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    from sanic.blueprints import Blueprint
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    bpg.blueprints = [bp1, bp2]

# Generated at 2022-06-24 03:33:08.490396
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    # Initialize Blueprint Group
    bpg = BlueprintGroup()

    # Check for length when empty
    assert len(bpg) == 0

    # Add a new element
    bpg.append(sanic.Blueprint("test"))

    # Assert that the length is now 1
    assert len(bpg) == 1

    # Add a second element
    bpg.append(sanic.Blueprint("test-2"))

    # Assert that the length is now 2
    assert len(bpg) == 2

# Generated at 2022-06-24 03:33:18.135733
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-24 03:33:25.467171
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    #test set by index
    bpg[0] = bp1
    bpg[1] = bp2
    
    assert bpg.blueprints[0] == bp1
    assert bpg.blueprints[1] == bp2


# Generated at 2022-06-24 03:33:30.939181
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg[0].name == 'bp1'
    assert bpg[1].name == 'bp2'



# Generated at 2022-06-24 03:33:38.035887
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = sanic.Blueprint("bp1", url_prefix="/bp1")
    bp2 = sanic.Blueprint("bp2", url_prefix="/bp2")
    group = BlueprintGroup("/api", "v1")
    group.append(bp1)

    assert len(group) == 1
    assert group[0] == bp1
    assert group.blueprints == [bp1]

    group.append(bp2)

    assert len(group) == 2
    assert group[0] == bp1
    assert group[1] == bp2
    assert group.blueprints == [bp1, bp2]


# Generated at 2022-06-24 03:33:43.320991
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    test_blueprint_group = BlueprintGroup()
    test_blueprint_group.append("A")
    test_blueprint_group.insert(0, "B")

    assert test_blueprint_group[0] == "B"
    assert test_blueprint_group[1] == "A"


# Generated at 2022-06-24 03:33:51.528139
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-24 03:33:54.026186
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp = Blueprint("bp1")
    bpg = BlueprintGroup()
    bpg.append(bp)
    assert bpg[0] is bp



# Generated at 2022-06-24 03:33:59.904693
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    from sanic.blueprints import Blueprint

    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)

    bps = list(bpg)
    assert (bp1 == bps[0] and bp2 == bps[1] and bp3 == bps[2]) is True

# Generated at 2022-06-24 03:34:00.616621
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    BlueprintGroup().__len__ == 0



# Generated at 2022-06-24 03:34:04.661254
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bpGroup = BlueprintGroup(bp1, bp2)
    bpGroup[0] = bp3
    assert bpGroup.blueprints[0] == bp3


# Generated at 2022-06-24 03:34:10.197763
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint = Blueprint("test", url_prefix = "/test")
    assert blueprint.name == "test"

    blueprint_group = BlueprintGroup("/v1")
    blueprint_group.append(blueprint)

    for group_item in blueprint_group:
        assert group_item.name == "test"
        assert group_item.url_prefix == "/v1/test"



# Generated at 2022-06-24 03:34:21.162107
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint(url_prefix="bp1")
    bp2 = Blueprint(url_prefix="bp2")
    bp3 = Blueprint(url_prefix="bp3")
    bp4 = Blueprint(url_prefix="bp4")

    bpg = BlueprintGroup(bp3, bp4, version="v1", strict_slashes=True)
    bpg = BlueprintGroup(bp1, bp2, bpg)

    @bpg.middleware
    async def middleware(request):
        """
        Middleware that needs to be applied on all the Blueprints
        """
        pass

    assert len(bp1.middlewares) == 1
    assert len(bp2.middlewares) == 1
    assert len(bp3.middlewares) == 1

# Generated at 2022-06-24 03:34:31.908042
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    class Blueprint:
        def __init__(self):
            self.name = '__init__'

    bp = BlueprintGroup()

    bp.append(Blueprint())
    bp.__setitem__(0, Blueprint())

    bp.append(Blueprint())
    bp.__setitem__(1, Blueprint())

    bp.append(Blueprint())
    bp.__setitem__(2, Blueprint())

    assert len(bp) == 3, "Failed to set item."
    assert bp.__getitem__(0).name == "__init__", "Failed to set item."
    assert bp.__getitem__(1).name == "__init__", "Failed to set item."

# Generated at 2022-06-24 03:34:41.015459
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp3 = Blueprint('bp3', url_prefix='/bp3')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)
    bpg.append(bp2)

    bpg[0] = bp3

    assert bpg[0] == bp3


# Generated at 2022-06-24 03:34:45.682193
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    """
    Unit test for method insert of class BlueprintGroup
    """
    bp = Blueprint("bp", url_prefix="/bp", strict_slashes=True)
    bpg = BlueprintGroup("bp_group")
    bpg.insert(0, bp)
    bpg = bpg.insert(0, bp)
    assert bpg.url_prefix == "/bp_group"


# Generated at 2022-06-24 03:34:54.917693
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    del bpg[1]
    assert bpg.blueprints == [bp1, bp3, bp4]

    del bpg[-1]
    assert bpg.blueprints == [bp1, bp3]
