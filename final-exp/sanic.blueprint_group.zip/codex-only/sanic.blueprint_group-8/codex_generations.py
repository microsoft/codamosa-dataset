

# Generated at 2022-06-24 03:25:03.123699
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bp3 = Blueprint("bp3")
    bp4 = Blueprint("bp4")

    # create Blueprint Group
    bpg = BlueprintGroup("bpg")

    # add blueprints to the group of size 1
    bpg.append(bp1)
    assert len(bpg) == 1

    # set the blueprint at 0 index
    bpg[0] = bp2
    assert len(bpg) == 1

    # set the blueprint at 1 index
    bpg[1] = bp3
    assert len(bpg) == 2

    # set blueprint at -1 index
    bpg[-1] = bp4
    assert len(bpg) == 2

    # set blueprint more than the size of the list

# Generated at 2022-06-24 03:25:11.155489
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    class TestBluePrint(sanic.Blueprint):
        def __init__(self, url_prefix='/'):
            super().__init__(url_prefix=url_prefix)

    bp1 = TestBluePrint('/test')
    bp2 = TestBluePrint('/test2')
    bpg = BlueprintGroup()

    bpg.append(bp1)
    bpg.append(bp2)

    bp3 = TestBluePrint('/test3')
    bpg.insert(0, bp3)

    assert bp3 in bpg.blueprints



# Generated at 2022-06-24 03:25:19.583007
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    # Initialize Blueprint objects for unit test
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg1 = BlueprintGroup(url_prefix="/api", version="v1")
    bpg1.append(bp1)
    bpg1.append(bp2)
    assert len(bpg1) == 2
    # Remove blueprint 1 from blueprint group
    del bpg1[0]
    assert len(bpg1) == 1
    assert bpg1[0] == bp2


# Generated at 2022-06-24 03:25:26.497441
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group = BlueprintGroup()
    blueprint_group.append(sanic.Blueprint('a'))
    blueprint_group.append(sanic.Blueprint('b'))
    blueprint_group.append(sanic.Blueprint('c'))
    blueprint_group.append(sanic.Blueprint('d'))
    blueprint_group.append(sanic.Blueprint('e'))
    assert len(blueprint_group) == 5
    del blueprint_group[0]
    assert len(blueprint_group) == 4
    assert blueprint_group[0].name == 'b'


# Generated at 2022-06-24 03:25:38.123509
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    # Given: BlueprintGroup instance
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    # When: Accessing elements of BlueprintGroup instance as per its index
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    app.blueprint(bpg)
    bp_list = bpg[:]

    # Then: Elements of bpg should be same as bp_list
    assert bp_list == bpg
    assert bp_list[0] == bp3
    assert bp_list[1] == b

# Generated at 2022-06-24 03:25:47.818387
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bpg1 = BlueprintGroup(bp1, bp2, url_prefix="/apiv1/")
    bpg1.insert(1, bp3)
    assert bpg1.blueprints[0].url_prefix == "/apiv1/bp1"
    assert bpg1.blueprints[1].url_prefix == "/apiv1/bp3"
    assert bpg1.blueprints[2].url_prefix == "/apiv1/bp2"


# Generated at 2022-06-24 03:25:51.797943
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    # Given
    blueprint_group = BlueprintGroup()
    blueprint_group.append('blueprint_1')
    blueprint_group.append('blueprint_2')
    blueprint_group.append('blueprint_3')

    # When
    blueprint_result = blueprint_group[1]

    # Then
    assert blueprint_result == 'blueprint_2'



# Generated at 2022-06-24 03:26:02.603156
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')
    bp7 = Blueprint('bp7', url_prefix='/bp7')
    bp8 = Blueprint('bp8', url_prefix='/bp8')
    bp9 = Blueprint('bp9', url_prefix='/bp9')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    b

# Generated at 2022-06-24 03:26:11.557597
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')

    bpg1 = BlueprintGroup()
    bpg2 = BlueprintGroup()
    bpg3 = BlueprintGroup()
    bpg4 = BlueprintGroup()

    assert len(bpg1) == len(bpg2) == len(bpg3) == len(bpg4) == 0

    bpg1.append(bp1)
    bpg1.append(bp2)
    assert len(bpg1) == 2

    bpg2.append(bp1)
    bpg2.append(bp2)
    bpg2.append(bp3)
    assert len(bpg2)

# Generated at 2022-06-24 03:26:20.329180
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    # Test Blueprint Group with 3 blueprints
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2, bp3, url_prefix="/api", version="v1")
    assert len(list(bpg)) == 3
    assert len(list(bpg.__iter__())) == 3

    # Test Blueprint Group with 0 Blueprint
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    assert len(list(bpg)) == 0
    assert len(list(bpg.__iter__())) == 0



# Generated at 2022-06-24 03:26:27.955714
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():

    # create blueprints
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()

    # add blueprints to blue print group
    bpg.append(bp1)
    bpg.append(bp2)

    assert_equal(len(bpg), 2)
    assert_equal(bpg._blueprints[0].name, 'bp1')
    assert_equal(bpg._blueprints[1].name, 'bp2')


# Generated at 2022-06-24 03:26:38.151928
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.insert(1,bp3)
    bpg.insert(2,bp4)
    bpg.insert(0,bp5)




# Generated at 2022-06-24 03:26:44.508039
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    assert_equal(bpg[0], bp1)
    assert_equal(bpg[1], bp2)
    assert_equal(len(bpg), 2)


# Generated at 2022-06-24 03:26:55.248817
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint("bp1", url_prefix="/bp1", version="v1")
    bp2 = Blueprint("bp2", url_prefix="/bp2", version="v1")
    bp3 = Blueprint("bp3", url_prefix="/bp3", version="v1")
    bp4 = Blueprint("bp4", url_prefix="/bp4", version="v1")

    bpg = BlueprintGroup("/api", version="v2")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)

    assert len(bpg) == 3
    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert bpg[2] == bp3

# Unittest for insert method of class BlueprintGroup

# Generated at 2022-06-24 03:27:03.179134
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    @sanic.blueprint.blueprint.middleware('request')
    async def test_middleware(request):
        print('This should not be called')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg.url_prefix == "/api"
    assert bpg.version == "v1"
    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert bpg.url_prefix is not bp1.url_prefix
    assert bp1.version == bpg.version
    assert bp

# Generated at 2022-06-24 03:27:14.610130
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bp3 = Blueprint('bp3')
    bp4 = Blueprint('bp4')

    import copy
    bp4_copy = copy.deepcopy(bp4)

    bp_group = BlueprintGroup()
    bp_group.append(bp1)
    bp_group.append(bp2)

    bp_group[1] = bp3

    assert type(bp_group[1]) is Blueprint
    assert bp_group[1] is bp3

    bp_group[3] = bp4

    assert type(bp_group[3]) is Blueprint
    assert bp_group[3] is bp4

    bp_group_copy = copy.deepcopy(bp_group)
    bp

# Generated at 2022-06-24 03:27:24.294894
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bpg = BlueprintGroup(url_prefix="/api")
    bpg.append(bp1)
    bpg.append(bp2)
    assert bpg[0] == bp1
    assert bpg[1] == bp2
    bpg[0] = bp2
    assert bpg[0] == bp2
    bpg[1] = bp1
    assert bpg[1] == bp1
    bpg[1] = bp2
    assert bpg[1] == bp2
    bpg[1] = bp1
    assert bpg[1]

# Generated at 2022-06-24 03:27:31.729479
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-24 03:27:36.231934
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bpg = BlueprintGroup()
    assert list(bpg) == []

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2)
    assert list(bpg) == [bp1, bp2]


# Generated at 2022-06-24 03:27:44.502319
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    g = BlueprintGroup(url_prefix='/api/v1')
    g.extend([bp1, bp2])
    assert g.url_prefix == '/api/v1'  # url_prefix is set
    assert len(g.blueprints) == 2  # 2 blueprints in the group
    assert g[0] == bp1  # bp1 is accessible by index
    assert g[1] == bp2  # bp2 is accessible by index

    # Duplicate Blueprint - Should not be allowed
    with pytest.raises(ValueError, match="Blueprint already in group"):
        g.append(bp1)

    # Blueprin object cannot

# Generated at 2022-06-24 03:27:53.472615
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():

    blueprint_group = BlueprintGroup()

    blueprint_group.insert(0, Blueprint('bp3', url_prefix='/bp3'))
    blueprint_group.insert(0, Blueprint('bp2', url_prefix='/bp2'))
    blueprint_group.insert(0, Blueprint('bp1', url_prefix='/bp1'))

    # Sanic Blueprints are OrderedDict, so here we cannot strictly predict the order
    # of the Sanic Blueprints, since the order of the dictionary is not guaranteed
    # to be the same as the order it was first added.

    assert len(blueprint_group.blueprints) == 3


# Generated at 2022-06-24 03:27:57.013491
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2)

    assert isinstance(group[0], Blueprint) is True


# Generated at 2022-06-24 03:28:05.473331
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    # Setup the blueprint group
    bp_group = BlueprintGroup()

    # Test passing a non-instance of Blueprint
    try:
        bp_group[0] = 1
        raise AssertionError("Unexpected behavior, expected TypeError")
    except TypeError:
        pass

    # Test passing a Blueprint instance
    try:
        bp = Blueprint('bp', url_prefix='/bp')
        bp_group[0] = bp
        assert bp_group.blueprints[0] is bp
    except Exception as e:
        raise AssertionError(f"Unexpected error occurred, error : {e}")


# Generated at 2022-06-24 03:28:15.730723
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2)

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    group.insert(1, bp3)

    assert len(group) == 3
    assert isinstance(group[0], Blueprint)
    assert isinstance(group[1], Blueprint)
    assert isinstance(group[2], Blueprint)
    assert group[0] == bp1
    assert group[1] == bp3
    assert group[2] == bp2


# Generated at 2022-06-24 03:28:21.687188
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bpg = BlueprintGroup()
    assert 0 == len(bpg)
    bp1 = Blueprint("test_blueprint_1")
    bp2 = Blueprint("test_blueprint_2")
    bpg.append(bp1)
    bpg.append(bp2)
    assert 2 == len(bpg)
    bpg.append(bp1)
    assert 3 == len(bpg)
    del bpg[0]
    assert 2 == len(bpg)


# Generated at 2022-06-24 03:28:29.297910
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    # Check getitem for blueprint group
    bp1 = Blueprint('bp1', url_prefix='/bp1', version="v1")
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3', version="v1")
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert bpg[2] == bp3
    assert bpg[3] == b

# Generated at 2022-06-24 03:28:38.389636
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    # Deleting a blueprint from a group
    bpg1 = BlueprintGroup()
    bpg1.append(bp1)
    del bpg1[0]
    assert len(bpg1.blueprints) == 0
    del bpg1[0]

    # Deleting a blueprint from a group with multiple blueprints
    bpg2 = BlueprintGroup()
    bpg2.append(bp1)
    bpg2.append(bp2)
    del bpg2[0]

# Generated at 2022-06-24 03:28:48.936808
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    app = sanic.Sanic(__name__)

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-24 03:28:56.844438
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    group = Blueprint.group(bp1, bp2)

    assert len(bpg) == 2
    assert len(group) == 2
    assert len(BlueprintGroup()) == 0


# Generated at 2022-06-24 03:28:57.686781
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    pass


# Generated at 2022-06-24 03:29:06.418094
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group = BlueprintGroup(url_prefix='/')
    blueprint1 = sanic.Blueprint("blueprint1", url_prefix='/blueprint1')
    blueprint2 = sanic.Blueprint("blueprint2", url_prefix='/blueprint2')
    blueprint_group._blueprints.append(blueprint1)
    blueprint_group._blueprints.append(blueprint2)
    blueprint_group.__delitem__(0)
    assert len(blueprint_group) == 1
    assert blueprint_group[0] == blueprint2
    #raise Exception("Test Exception")


# Generated at 2022-06-24 03:29:17.529877
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    from sanic import Blueprint
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.insert(0, bp3)
    bpg.insert(1, bp4)
    assert bpg[0] == bp3
    assert bpg[1] == bp4
    assert bpg[2] == bp1
    assert bpg[3] == bp2

# Generated at 2022-06-24 03:29:22.224989
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    """
    Unit test for method append of class BlueprintGroup
    """
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bpg1 = BlueprintGroup()
    bpg1.append(bp1)
    assert bpg1[0] is bp1
    bpg1.append(bp2)
    assert bpg1[1] is bp2


# Generated at 2022-06-24 03:29:30.202938
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bp3 = sanic.Blueprint('bp3', url_prefix='/bp3')
    bp4 = sanic.Blueprint('bp4', url_prefix='/bp4')
    bp5 = sanic.Blueprint('bp5', url_prefix='/bp5')
    bp6 = sanic.Blueprint('bp6', url_prefix='/bp6')
    bp7 = sanic.Blueprint('bp7', url_prefix='/bp7')

    bpg1 = BlueprintGroup(bp1, bp2, bp3)

# Generated at 2022-06-24 03:29:34.899482
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp = Blueprint("bp_test", url_prefix="/test")
    bpg = BlueprintGroup("/test")
    bpg.append(bp)
    assert len(bpg.blueprints) == 1
    assert id(bpg.blueprints[0]) == id(bp)


# Generated at 2022-06-24 03:29:40.408609
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix='/api', version='v1')
    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bpg) == 2


# Generated at 2022-06-24 03:29:48.696712
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    assert len(bpg) == 4
    del bpg[1]
    assert len(bpg) == 3
    del bpg[-1]
    assert len(bpg) == 2



# Generated at 2022-06-24 03:29:58.856441
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    async def middleware_func(request):
        print("Middleware function can be used on Blueprint Group")
        return text("complete")

    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")

    bp_group = BlueprintGroup()
    bp_group.append(bp1)
    bp_group.append(bp2)

    @bp_group.middleware()
    async def middleware_func(request):
        print("Middleware function can be used on Blueprint Group")
        return text("complete")


# Generated at 2022-06-24 03:30:06.158003
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    assert isinstance(bpg, BlueprintGroup)
    assert isinstance(bpg.blueprints, list)
    assert isinstance(bpg.blueprints, list)

    assert len(bpg) == 2
    assert bpg.blueprints[0] == bp1
    assert bpg.blueprints[1] == bp2
    assert bpg.url_prefix == "/api"
    assert bpg.version == "v1"



# Generated at 2022-06-24 03:30:13.762501
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    test_BP_Group = BlueprintGroup()
    assert len(test_BP_Group) == 0
    test_BP_Group[0] = bp1
    assert len(test_BP_Group) == 1
    assert test_BP_Group[0] == bp1
    test_BP_Group[1] = bp2
    assert len(test_BP_Group) == 2
    assert test_BP_Group[1] == bp2


# Generated at 2022-06-24 03:30:21.961179
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    # test normal case
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp1_group = BlueprintGroup(url_prefix="/ds")
    bp1_group.append(bp1)
    bp1_group.append(bp2)
    len_bp1_group = len(bp1_group._blueprints)
    bp1_group[0] = bp2
    assert len(bp1_group._blueprints) == len_bp1_group
    assert bp1_group[0] == bp2
    assert bp1_group[1] == bp2

    # test index error
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp1

# Generated at 2022-06-24 03:30:27.652560
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    # When
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    # Then
    assert bp1 in bpg
    assert bp2 in bpg


# Generated at 2022-06-24 03:30:36.116464
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    # Create BlueprintGroup object
    bp = BlueprintGroup()
    for i in range(10):
        b = Blueprint(f"bp_{i}")
        b.url_prefix = "test-prefix"
        b.version = 1
        bp.append(b)
    assert bp[7].name == "bp_7"
    assert bp[-7].name == "bp_3"
    assert bp[:].__len__() == 10
    assert bp[2:6].__len__() == 4
    assert bp[::2].__len__() == 5
    assert bp[::-1].__len__() == 10
    assert bp[::-3].__len__() == 4
    assert bp[7:-3].__len__() == 2


# Generated at 2022-06-24 03:30:42.745973
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bpg = BlueprintGroup()

    bpg.append(Blueprint('bp1', url_prefix='/bp1'))
    bpg.append(Blueprint('bp2', url_prefix='/bp2'))

    # __iter__ should yield all the available blueprints
    blueprints = [item for item in bpg]
    assert len(blueprints) == 2
    assert all([
        isinstance(item, Blueprint)
        for item in blueprints
    ])


# Generated at 2022-06-24 03:30:46.410937
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bpg = BlueprintGroup(bp1, url_prefix="/api", version="v1")
    bpg.blueprints == [bp1]
    bpg.url_prefix == "/api"
    bpg.version == "v1"

# Generated at 2022-06-24 03:30:53.390138
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    import os
    import sys
    import pytest
    import tempfile
    import contextlib


    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp_group = BlueprintGroup(bp1, bp2)
    assert bp_group[0] == bp1
    assert bp_group[1] == bp2

    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")
    bp5 = Blueprint("bp5", url_prefix="/bp5")

    bpg = BlueprintGroup(bp3, bp4, bp5)
    assert bpg[0] == bp3
    assert bpg[1] == b

# Generated at 2022-06-24 03:30:59.460652
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    _blueprint1 = Blueprint.group("bp1")
    _blueprint2 = Blueprint.group("bp2")

    _blueprintGroup = BlueprintGroup()
    assert len(_blueprintGroup) == 0
    _blueprintGroup.append(_blueprint1)
    assert len(_blueprintGroup) == 1

    _blueprintGroup.append(_blueprint2)
    assert len(_blueprintGroup) == 2


# Generated at 2022-06-24 03:31:08.015327
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    
    group = BlueprintGroup(url_prefix="/api", version="v1")
    group.append(bp1)
    group.append(bp2)
    
    assert len(group) == 2
    assert type(group) == BlueprintGroup
    assert isinstance(group, MutableSequence)
    assert type(group._blueprints) == list
    assert group.url_prefix == '/api'
    
    
test_BlueprintGroup_append()


# Generated at 2022-06-24 03:31:17.146250
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api")

    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    # Write a unit test for iter() method of BlueprintGroup
    assert len([bp for bp in bpg]) == len(bpg.blueprints)

# Generated at 2022-06-24 03:31:22.676208
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    assert BlueprintGroup().url_prefix is None
    assert BlueprintGroup().version is None
    assert BlueprintGroup().strict_slashes is None
    assert BlueprintGroup(url_prefix="/api", version="v1").url_prefix == "/api"
    assert BlueprintGroup(url_prefix="/api").version is None
    assert BlueprintGroup(url_prefix="/api", version="v1").version == "v1"
    assert BlueprintGroup(strict_slashes=True).strict_slashes is True
    assert BlueprintGroup(strict_slashes=False).strict_slashes is False


# Generated at 2022-06-24 03:31:28.809357
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup()
    bpg.extend([bp3, bp4])

    assert bpg[0] == bp3
    assert bpg[1] == bp4



# Generated at 2022-06-24 03:31:33.093233
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp = BlueprintGroup('/api')
    assert bp._url_prefix == '/api'

# Generated at 2022-06-24 03:31:41.929180
# Unit test for method __iter__ of class BlueprintGroup

# Generated at 2022-06-24 03:31:49.937688
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp3)
    bpg.append(bp4)

    assert bpg[0] == bp3
    assert bpg[1] == bp4



# Generated at 2022-06-24 03:31:56.269045
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic("test_BlueprintGroup_middleware", load_env="tests.env")
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bpg = BlueprintGroup(bp1, bp2)
    @bpg.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')
    current_blueprints = bpg.blueprints
    assert len(bpg.blueprints) == 2
    assert len(current_blueprints) == len(bpg.blueprints)
    assert isinstance(current_blueprints, list)
    assert bp1 in current_blueprints
    assert bp2 in current_blueprints

# Generated at 2022-06-24 03:32:06.716247
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # pylint: disable=protected-access
    from sanic import Sanic
    from sanic.blueprints import Blueprint
    app = Sanic("BlueprintGroup_middleware_test")

    class TestMiddleware:
        async def __call__(self, request):
            pass

    mw1 = TestMiddleware()
    mw2 = TestMiddleware()

    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bg = BlueprintGroup("/group")
    bg.append(bp1)
    bg.append(bp2)

    bg.middleware(mw1, attach=True)

    bg._sanitize_blueprint(bg._blueprints[0]).middleware(mw1)


# Generated at 2022-06-24 03:32:11.883902
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    # Test Blueprint BlueprintGroup constructor
    bgp = BlueprintGroup(url_prefix="api", version="v1", strict_slashes=True)
    assert bgp.url_prefix == "api"
    assert bgp.version == "v1"
    assert bgp.strict_slashes

    bgp = BlueprintGroup(url_prefix=None, version=None, strict_slashes=None)
    assert bgp.url_prefix is None
    assert bgp.version is None
    assert bgp.strict_slashes is None


# Generated at 2022-06-24 03:32:20.366875
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')

    bp3 = sanic.Blueprint('bp3', url_prefix='/bp1')
    bp4 = sanic.Blueprint('bp4', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    group = Blueprint.group(bp1, bp2)

    assert isinstance(bp1, sanic.Blueprint)
    assert isinstance(bp2, sanic.Blueprint)

# Generated at 2022-06-24 03:32:29.828941
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group = BlueprintGroup(url_prefix='/api', version='v1')

    blueprint_0 = Blueprint(url_prefix='/url-prefix-0', version='v0')
    blueprint_1 = Blueprint(url_prefix='/url-prefix-1', version='v1')
    blueprint_2 = Blueprint(url_prefix='/url-prefix-2', version='v2')
    blueprint_3 = Blueprint(url_prefix='/url-prefix-3', version='v3')
    blueprint_4 = Blueprint(url_prefix='/url-prefix-4', version='v4')

    blueprint_group.append(blueprint_0)
    blueprint_group.append(blueprint_1)
    blueprint_group.append(blueprint_2)
    blueprint_group.append(blueprint_3)
    blueprint_group.append

# Generated at 2022-06-24 03:32:38.699420
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api")
    bpg.append(bp1)
    bpg.append(bp2)

    assert isinstance(bpg[0], Blueprint), "BlueprintGroup[0] fail"
    assert isinstance(bpg[1], Blueprint), "BlueprintGroup[1] fail"



# Generated at 2022-06-24 03:32:44.554289
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    # Given
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    # When
    result = bpg[0]

    # Then
    assert result is bp1


# Generated at 2022-06-24 03:32:47.596081
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @sanic.blueprint.BlueprintGroup.middleware()
    async def func1(request):
        pass
    assert callable(func1) is True


# Generated at 2022-06-24 03:32:54.509175
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    # Setup a Blueprint Group

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = BlueprintGroup()
    group._blueprints = [bp1, bp2]
    assert isinstance(group, BlueprintGroup)

    # Test the __iter__ method to turn the group into a list
    for index, item in enumerate(group):
        assert group[index] == item
    assert len(group) == 2


# Generated at 2022-06-24 03:33:02.401149
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')
    bp7 = Blueprint('bp7', url_prefix='/bp7')
    bp8 = Blueprint('bp8', url_prefix='/bp8')
    bp9 = Blueprint('bp9', url_prefix='/bp9')
    bp10 = Blueprint('bp10', url_prefix='/bp10')

# Generated at 2022-06-24 03:33:09.177005
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)

    blueprint = group[0]

    assert blueprint == bp1


# Generated at 2022-06-24 03:33:17.505487
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix='/api', version='v1')
    bpg.append(bp1)
    bpg.append(bp2)
    bpg[0] = bp3
    assert bpg[0] == bp3
    assert bpg[0].name == 'bp3'
    assert bpg[1] == bp2
    assert bpg[1].name == 'bp2'
    bpg[3] = bp4
    assert len(bpg) == 4

# Generated at 2022-06-24 03:33:24.796972
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    group = Blueprint.group(bp1, bp2)
    group.append(bp3)
    group.append(bp4)

    assert len(group) == 4
    assert set(group) == {bp1, bp2, bp3, bp4}


# Generated at 2022-06-24 03:33:36.119045
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4)

    assert next(iter(bpg)) == bp3
    assert next(iter(bpg)) == bp4
    bpg.append(bp1)
    bpg.append(bp2)
    assert next(iter(bpg)) == bp1
    assert next(iter(bpg)) == bp2
    bpg.insert(0, bp3)
    assert next(iter(bpg)) == bp3



# Generated at 2022-06-24 03:33:43.475431
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)
    bpg.append(bp2)
    assert bpg.url_prefix == "/api"
    assert bpg[0] == bp1
    assert bpg[1] == bp2

    bpg[1] = bp3
    assert bpg[1] == bp3


# Generated at 2022-06-24 03:33:51.892716
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bp3 = sanic.Blueprint('bp3', url_prefix='/bp3')
    bp4 = sanic.Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp3)
    bpg[0] = bp2
    bpg[1] = bp4
    assert bpg.blueprints[0].name == bp2.name
    assert bpg.blueprints[1].name == bp4.name

# Generated at 2022-06-24 03:34:01.667266
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp_group = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    bp_group.append(bp1)
    bp_group.append(bp2)
    bp_group.append(bp3)
    bp_group.append(bp4)
    blueprint_list = list(bp_group)
    assert len(blueprint_list) == 4
    assert blueprint_list[0] == bp1
    assert blueprint_list[1] == b

# Generated at 2022-06-24 03:34:09.016944
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    """
    This method will test the __getitem__ method of class BlueprintGroup
    """
    app = sanic.Sanic('test_BlueprintGroup___getitem__')
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg) == 2
    assert bpg[0] == bp1


# Generated at 2022-06-24 03:34:15.842777
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    """
    Unit test for method __getitem__ of class BlueprintGroup
    """
    inst = BlueprintGroup()
    bp1 = Blueprint("bp1", url_prefix='/bp1')
    bp2 = Blueprint("bp2", url_prefix='/bp2')
    inst.append(bp1)
    inst.append(bp2)

    assert len(inst) == 2
    assert inst[0] is bp1
    assert inst[1] is bp2


# Generated at 2022-06-24 03:34:25.914185
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')
    bp7 = Blueprint('bp7', url_prefix='/bp7')
    bp8 = Blueprint('bp8', url_prefix='/bp8')
    bp9 = Blueprint('bp9', url_prefix='/bp9')
    bp0 = Blueprint('bp0', url_prefix='/bp0')

# Generated at 2022-06-24 03:34:29.458265
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    # Simple Smoke Test only. Test for any of the other methods
    # in the class are already covered in the Test for
    # Blueprint class
    assert BlueprintGroup()

# Generated at 2022-06-24 03:34:36.384578
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    from sanic.blueprints import Blueprint

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    group = Blueprint.group(bpg)

    for bp in group:
        assert bp.name in ['bp1', 'bp2']



# Generated at 2022-06-24 03:34:43.372503
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bpg.__setitem__(2,bp3)
    assert bpg._blueprints == [bp1, bp2, bp3]


# Generated at 2022-06-24 03:34:52.854080
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    # GIVEN
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    # WHEN
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    # THEN
    assert bpg._blueprints == [bp1, bp2]

