

# Generated at 2022-06-24 03:24:54.297307
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    assert isinstance(BlueprintGroup(), BlueprintGroup)



# Generated at 2022-06-24 03:24:56.695176
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    # Unit Test Description: Test the __len__ method of the BlueprintGroup
    # TODO: Implement
    pass


# Generated at 2022-06-24 03:25:04.103943
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp3)
    bpg.append(bp4)
    group = Blueprint.group(bp1, bp2)
    assert len(group) == 2
    assert len(bpg) == 2



# Generated at 2022-06-24 03:25:12.102959
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    group = BlueprintGroup(url_prefix='/group1')
    group.insert(0, bp1)
    group.insert(1, bp2)
    group.insert(0, bp3)
    group.insert(1, bp4)

    assert group[0].name == 'bp3'
    assert group[1].name == 'bp4'
    assert group[2].name == 'bp1'
    assert group[3].name == 'bp2'



# Generated at 2022-06-24 03:25:16.618481
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bpg = BlueprintGroup()

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg.append(bp1)
    bpg.append(bp2)

    bpg[0] = bp2
    assert bpg[0] is bp2

    bpg[1] = bp1
    assert bpg[1] is bp1


# Generated at 2022-06-24 03:25:21.454795
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group = BlueprintGroup()
    blueprint_group.append(sanic.Blueprint(url_prefix='/test'))
    blueprint_group.append(sanic.Blueprint(url_prefix='/test2'))
    assert len(blueprint_group) == 2
    del blueprint_group[1]
    assert len(blueprint_group) == 1
    assert blueprint_group[0].url_prefix == '/test'


# Generated at 2022-06-24 03:25:22.541365
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    group = BlueprintGroup()
    assert len(group) == 0


# Generated at 2022-06-24 03:25:27.577825
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    group = BlueprintGroup('/')
    group.append(Blueprint('/bp1', url_prefix='/bp1'))
    group[0] = Blueprint('/bp2', url_prefix='/bp2')
    assert group.blueprints[0].name == '/bp2'
    assert group.blueprints[0].url_prefix == '/bp2'


# Generated at 2022-06-24 03:25:31.818784
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bpg = BlueprintGroup()
    bpg.append("bp1")
    assert bpg[0] == "bp1"
    bpg[0] = "bp2"
    assert bpg[0] == "bp2"


# Generated at 2022-06-24 03:25:38.506595
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.insert(0, bp2)
    assert bpg.blueprints == [bp2, bp1, bp2]


# Generated at 2022-06-24 03:25:46.522531
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')
    bp7 = Blueprint('bp7', url_prefix='/bp7')
    bp8 = Blueprint('bp8', url_prefix='/bp8')

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')


# Generated at 2022-06-24 03:25:51.757103
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    test_bp = Blueprint('test_bp', url_prefix='/test_bp')
    test_bg = BlueprintGroup()
    assert len(test_bg) == 0
    test_bg.append(test_bp)
    assert len(test_bg) == 1
    assert isinstance(test_bg[0], Blueprint)
    assert test_bg[0] is test_bp



# Generated at 2022-06-24 03:26:02.538301
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup()

    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert bpg[2] == bp3
    assert bpg[3] == bp4

    bpg = BlueprintGroup()

    assert len(bpg) == 0


# Generated at 2022-06-24 03:26:11.837921
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")
    bpg = BlueprintGroup(url_prefix="/api/v1")
    bpg.insert(0, bp1)
    bpg.insert(1, bp2)
    bpg.insert(2, bp3)
    bpg.insert(3, bp4)
    assert bpg.blueprints == [bp1, bp2, bp3, bp4]


# Generated at 2022-06-24 03:26:18.313958
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint1 = Blueprint('blueprint1', url_prefix='/blueprint1')
    blueprint2 = Blueprint('blueprint2', url_prefix='/blueprint2')
    blueprintGroup = BlueprintGroup(url_prefix='/blueprintGroup')
    blueprintGroup[0] = blueprint1
    blueprintGroup[1] = blueprint2
    assert len(blueprintGroup) == 2
    assert isinstance(blueprintGroup, BlueprintGroup)
    assert isinstance(blueprintGroup[0], Blueprint)
    assert isinstance(blueprintGroup[1], Blueprint)


# Generated at 2022-06-24 03:26:28.375305
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint("test1", url_prefix="/test1")
    bp2 = Blueprint("test2", url_prefix="/test2")
    bp3 = Blueprint("test3", url_prefix="/test3")
    bpg = BlueprintGroup(url_prefix="/test")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    assert bp1 in bpg.blueprints
    assert bp2 in bpg.blueprints
    assert bp3 in bpg.blueprints
    assert bp1.url_prefix == "/test/test1"
    assert bp2.url_prefix == "/test/test2"
    assert bp3.url_prefix == "/test/test3"


# Generated at 2022-06-24 03:26:35.637965
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    assert bpg[0] == bp1
    bpg[0] = bp2
    assert bpg[0] == bp2
    bpg[0] = bp1
    assert bpg[0] == bp1


# Generated at 2022-06-24 03:26:44.774154
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group = BlueprintGroup()
    blueprint = Blueprint("name")
    blueprint_group.append(blueprint)
    blueprint_group[0] = blueprint
    blueprint_group.insert(0, blueprint)
    blueprint_group.__setitem__(0, blueprint)
    # Unit test to check whether TypeError is raised when an invalid parameter is passed as an argument to __setitem__
    with pytest.raises(TypeError):
        blueprint_group.__setitem__('name', blueprint)
    try:
        blueprint_group.__setitem__('name', blueprint)
    except TypeError as e:
        assert "list indices must be integers or slices, not str" in str(e)


# Generated at 2022-06-24 03:26:53.593382
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    This unit test is written to ensure that the middleware decorator
    of the Blueprint Group works as intended.

    Blueprint Group needs to pass down the middleware to each of the
    nested blueprints inside the group.

    :return: None
    """
    @BlueprintGroup.middleware("test")
    async def test_fn(request):
        pass

    group = BlueprintGroup()
    group.append(Blueprint("test"))

    assert len(group.blueprints[0].middlewares["test"]) == 1
    assert group.blueprints[0].middlewares["test"][0][0] == test_fn



# Generated at 2022-06-24 03:27:00.819990
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    assert not bpg._blueprints
    bpg.insert(0, bp1)
    assert bp1 in bpg._blueprints
    bpg.insert(1, bp2)
    assert bp1 in bpg._blueprints
    assert bp2 in bpg._blueprints


# Generated at 2022-06-24 03:27:02.034678
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    BlueprintGroup_obj = BlueprintGroup()
    BlueprintGroup_obj.append("Blueprint_obj")


# Generated at 2022-06-24 03:27:09.418953
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert isinstance(bpg, MutableSequence)
    assert isinstance(bpg.__iter__(), types.GeneratorType)


# Generated at 2022-06-24 03:27:20.065657
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp1_view_func = lambda _: "bp1"
    bp1.add_route(bp1_view_func, "/")

    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp2_view_func = lambda _: "bp2"
    bp2.add_route(bp2_view_func, "/")

    bpg = BlueprintGroup()
    bpg._blueprints.append(bp1)
    bpg._blueprints.append(bp2)
    assert bpg[0]._rules[0].methods["GET"] == bp1_view_func

# Generated at 2022-06-24 03:27:28.815440
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    # Initialize Blueprint instances
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    # Initialize the BlueprintGroup with prefix and version
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    # Insert the blueprints into the BlueprintGroup
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    # Check if the implementation of __iter__ method works fine
    assert(bp1 in bpg)
    assert(bp2 in bpg)


# Generated at 2022-06-24 03:27:37.566862
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bpg = BlueprintGroup()
    # Test: set item at key 0
    bpg[0] = bp1
    assert bpg[0]==bp1
    # Test: set item at key 1
    bpg[1] = bp2
    assert bpg[1]==bp2
    # Test: set item at key 2
    bpg[2] = bp3
    assert bpg[2]==bp3


# Generated at 2022-06-24 03:27:48.900346
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    # Test Blueprint group itself
    assert len(bpg.blueprints) == 2

    # Test Blueprint 1
    assert callable(bp1.middlewares['request'][0])
    assert len(bp1.middlewares['request']) == 1

    # Test Blueprint 2
    assert callable(bp2.middlewares['request'][0])

# Generated at 2022-06-24 03:27:58.508715
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)

    @bpg.middleware('request')
    async def bpg_middleware(request):
        print('Request Middleware applied on BlueprintGroup')


    @bpg.middleware('response')
    async def bpg_response_middleware(request, response):
        print('Response Middleware applied on BlueprintGroup')

    assert bp1._middleware['request'][0] == bpg_middleware
    assert bp2._middleware

# Generated at 2022-06-24 03:28:05.668784
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="")
    bpg.append(bp1)
    bpg.append(bp2)

    ans = []
    for bp in bpg:
        ans.append(bp)
    assert sorted(ans, key=lambda x: x.name) == sorted([bp1, bp2], key=lambda x: x.name)



# Generated at 2022-06-24 03:28:13.247462
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    # Description :
    # Create a BlueprintGroup object and check whether it is iterable
    # after instantiation. After that, create another blueprint and
    # append it to the blueprint group.

    bp1 = Blueprint('bp1', url_prefix='/bp1')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    assert iter(bpg) is not None
    bpg.append(bp1)
    assert iter(bpg) is not None



# Generated at 2022-06-24 03:28:23.650885
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Arrange
    class App(sanic.Sanic):
        def __init__(self):
            super().__init__(__name__)
            self.blueprint_group = BlueprintGroup()
            self.blueprints = []
            for i in range(0, 4):
                bp = Blueprint("bp{}".format(i), url_prefix="/bp{}".format(i))
                self.blueprints.append(bp)

    app = App()
    app.blueprint_group.append(app.blueprints[0])
    app.blueprint_group.append(app.blueprints[1])
    app.blueprint_group.append(app.blueprints[2])
    app.blueprint_group.append(app.blueprints[3])


# Generated at 2022-06-24 03:28:30.360445
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup('/api', version="v1")

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    @bpg.middleware('request')
    async def bpg_middleware(request):
        print('applied on Blueprint Group : bpg')
    
    bpg.append(bp1)
    bpg.append(bp2)
    
    assert bp1.middlewares[0] == bpg_middleware

# Generated at 2022-06-24 03:28:35.397589
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp_group = BlueprintGroup(url_prefix="/api", version="v1")
    assert len(bp_group) == 0
    bp_group.append(sanic.Blueprint("bp1"))
    assert len(bp_group) == 1
    bp_group.append(sanic.Blueprint("bp2"))
    assert len(bp_group) == 2


# Generated at 2022-06-24 03:28:43.771401
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()

    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg[0] == bp1
    assert bpg[1] == bp2

    bpg[0] = bp2
    bpg[1] = bp1

    assert bpg[0] == bp2
    assert bpg[1] == bp1


# Generated at 2022-06-24 03:28:52.634647
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg._blueprints.append(bp1);
    bpg._blueprints.append(bp2);
    bpg._blueprints.append(bp3);
    bpg._blueprints.append(bp4);
    assert(len(bpg)==4);
    del bpg[0]
    assert(len(bpg)==3);


# Generated at 2022-06-24 03:28:59.135695
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp = Blueprint('bp', url_prefix='/bp', version="v1")
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix='/api')
    bpg.append(bp)
    bpg.insert(0, bp1)
    bpg.insert(1, bp2)
    assert bpg[0].name == 'bp1'
    assert bpg[1].name == 'bp2'
    assert bpg[2].name == 'bp'

# Generated at 2022-06-24 03:29:07.364620
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Create a simple app and register a blueprint
    app = sanic.Sanic(__name__)
    bp = Blueprint('bp', url_prefix='/bp')

    bpg = BlueprintGroup('/api', version="v1")
    bpg.append(bp)

    @bpg.middleware('request')
    async def bpg_middleware(request):
        return text('bpg_middleware')

    request, response = app.test_client.get("/api/bp/")
    assert response.status == 200
    assert response.text == 'bpg_middleware'

# Generated at 2022-06-24 03:29:11.168436
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprints = [Blueprint(0), Blueprint(1), Blueprint(2)]
    blueprint_group = BlueprintGroup()
    blueprint_group._blueprints = blueprints

    index = 0
    for blueprint in blueprint_group:
        assert blueprint == blueprints[index]
        index += 1


# Generated at 2022-06-24 03:29:18.338796
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_group = BlueprintGroup()
    blueprint1 = Blueprint('bp1', url_prefix='/bp1')
    blueprint2 = Blueprint('bp2', url_prefix='/bp2')
    blueprint_group.append(blueprint1)
    blueprint_group.append(blueprint2)
    assert blueprint_group[0] == blueprint1
    assert blueprint_group[1] == blueprint2


# Generated at 2022-06-24 03:29:23.943415
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    # Define a BlueprintGroup
    blueprint_group = BlueprintGroup("/api/v1")
    blueprint_group.append(sanic.Blueprint("b1"))
    blueprint_group.append(sanic.Blueprint("b2"))

    # Define a blueprint
    blueprint = sanic.Blueprint("b3")

    # Set the blueprint in the BlueprintGroup
    blueprint_group[2] = blueprint

    assert blueprint_group[2].name == blueprint.name

# Test call BlueprintGroup.__iter__()

# Generated at 2022-06-24 03:29:28.019850
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    with pytest.raises(StopIteration):
        bg = BlueprintGroup()
        next(bg)

# Unit tests for method __getitem__ of class BlueprintGroup

# Generated at 2022-06-24 03:29:30.819322
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp = Blueprint('bp')
    bpg = BlueprintGroup()
    bpg.append(bp)
    assert bpg[0] == bp


# Generated at 2022-06-24 03:29:37.614142
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    # bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp1 = Blueprint('bp1')
    bp = BlueprintGroup()
    bp.append(bp1)
    assert getattr(bp[0], 'name') == 'bp1'
    bp[0] = Blueprint('bp2')
    assert getattr(bp[0], 'name') == 'bp2'
    bp[0] = Blueprint('bp1')



# Generated at 2022-06-24 03:29:47.223190
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    class TestBlueprint(sanic.Blueprint):
        pass

    bp1 = TestBlueprint("bp1", url_prefix="/bp1", version="v1")
    bp2 = TestBlueprint("bp2", url_prefix="/bp2", version="v1")

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bpg) == 2
    assert bp1 in bpg
    assert bp2 in bpg
    assert isinstance(bpg[0], TestBlueprint)
    assert isinstance(bpg[1], TestBlueprint)
    bpg[0] = bp2
    assert bpg[0] == bp2
    del bpg[0]
    assert bp2

# Generated at 2022-06-24 03:29:52.073056
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    # Blueprint Group should contain each of the Blueprint
    assert len(group.blueprints) == 2
    assert all(type(b) == Blueprint for b in group.blueprints)
    assert group.url_prefix == "/api"
    assert group.version == "v1"


# Generated at 2022-06-24 03:29:57.386377
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)
    assert list(group) == [bp1, bp2]
    assert len(group) == 2


# Generated at 2022-06-24 03:30:03.136975
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api")

    bpg.append(bp1)
    bpg.append(bp2)

    # Asserting the expected behaviors
    assert len(bpg) == 2
    bpg.remove(bp2)
    assert len(bpg) == 1



# Generated at 2022-06-24 03:30:06.740797
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    assert BlueprintGroup().url_prefix == None
    assert BlueprintGroup().version == None
    assert BlueprintGroup().blueprints == []
    assert BlueprintGroup().strict_slashes == None

    assert BlueprintGroup(url_prefix="/api").url_prefix == "/api"
    assert BlueprintGroup(version=1).version == 1
    assert BlueprintGroup(strict_slashes=True).strict_slashes == True


# Generated at 2022-06-24 03:30:15.784787
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")
    bp5 = Blueprint("bp5", url_prefix="/bp5")
    bp6 = Blueprint("bp6", url_prefix="/bp6")

    bpg = BlueprintGroup(url_prefix="/bpg")
    bpg.append(bp1)
    bpg.append(bp2)
    assert list(bpg) == [bp1, bp2]
    assert [b.url_prefix for b in bpg] == ["/bpg/bp1", "/bpg/bp2"]
    assert bp1.url_

# Generated at 2022-06-24 03:30:26.880814
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():

    bp1 = sanic.Blueprint("bp1", url_prefix="/bp1")
    bp2 = sanic.Blueprint("bp2", url_prefix="/bp2")
    bp3 = sanic.Blueprint("bp3", url_prefix="/bp3")
    bp4 = sanic.Blueprint("bp4", url_prefix="/bp4")

    bpg = BlueprintGroup()

    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bpg) == 2

    bpg.insert(0, bp3)
    bpg.insert(4, bp4)

    assert len(bpg) == 4

    assert bpg[0].name == "bp3"
    assert bpg[1].name == "bp1"

# Generated at 2022-06-24 03:30:31.882183
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    """Test BlueprintGroup.__iter__()."""
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bpg.append(bp1)
    bpg.append(bp2)
    assert [bpg.__iter__()[0], bpg.__iter__()[1]] == [bp1, bp2]

# Generated at 2022-06-24 03:30:40.309469
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)
    group.append(bp3)
    group.append(bp4)
    assert group[0] == bp1
    assert group[1] == bp2
    assert group[2] == bp3
    assert group[3] == bp4


# Generated at 2022-06-24 03:30:42.953312
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    """
    Unit test for method __len__ of class BlueprintGroup
    """
    blueprint_group = BlueprintGroup()
    blueprint_group.append(sanic.Blueprint("test"))
    assert len(blueprint_group) == 1

# Generated at 2022-06-24 03:30:48.327969
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = BlueprintGroup()

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    group.append(bp1)
    group.append(bp2)

    assert group[0] == bp1
    assert group[1] == bp2


# Generated at 2022-06-24 03:30:59.315554
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.insert(0, bp1)
    bpg.insert(0, bp2)
    assert bpg[0] == bp2
    bp = Blueprint('bp', url_prefix='/bp')
    bpg.insert(1, bp)
    assert bpg[1] == bp
    bpg.insert(5, bp)
    assert bpg[5] == bp
    assert bpg[0] == bp2
    assert bpg[1] == bp
    assert len(bpg) == 6


# Generated at 2022-06-24 03:31:06.823165
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp3 = Blueprint('bp3', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    assert len(bpg) == 2

    del bpg[-1]

    assert len(bpg) == 1



# Generated at 2022-06-24 03:31:17.263839
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", strict_slashes=False)
    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')
    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)
    @bp3.route('/')
    async def bp1_route(request):
        return text('bp1')
   

# Generated at 2022-06-24 03:31:27.676718
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp_obj_1 = Blueprint('bp1', url_prefix='/bp1')
    bp_obj_2 = Blueprint('bp2', url_prefix='/bp2')
    bp_obj_3 = Blueprint('bp3', url_prefix='/bp4')
    bp_obj_4 = Blueprint('bp4', url_prefix='/bp4')
    bp_g_obj = BlueprintGroup(url_prefix="/api")
    bp_g_obj.append(bp_obj_1)
    bp_g_obj.append(bp_obj_2)
    bp_g_obj.append(bp_obj_3)
    bp_g_obj.append(bp_obj_4)
    bp_g_obj.__delitem__(0)

# Generated at 2022-06-24 03:31:35.612030
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    from sanic.blueprints import Blueprint

    b1 = Blueprint(name="bp1", url_prefix="/bp1")
    b2 = Blueprint(name="bp2", url_prefix="/bp2")
    bg = BlueprintGroup(url_prefix="/bg")
    bg.append(b1)
    bg.append(b2)
    assert bg[0] == b1
    assert bg[1] == b2



# Generated at 2022-06-24 03:31:39.448226
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp = Blueprint('bp1', url_prefix='/bp1')
    bpg = BlueprintGroup()
    bpg.append(bp)
    bpg.insert(0, bp)

# Generated at 2022-06-24 03:31:49.711297
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    @bp1.middleware('request')
    def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/bp1')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/bp2/<param>')
    async def bp2_route(request, param):
        return text(param)

    group = Blueprint.group(bp1, bp2, strict_slashes=True)


# Generated at 2022-06-24 03:31:57.983383
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1', strict_slashes=True)
    bp2 = Blueprint('bp2', url_prefix='/bp2', strict_slashes=True)
    bp3 = Blueprint('bp3', url_prefix='/bp3', strict_slashes=True)
    bp4 = Blueprint('bp4', url_prefix='/bp4', strict_slashes=True)
    bp5 = Blueprint('bp5', url_prefix='/bp5', strict_slashes=True)
    bp6 = Blueprint('bp6', url_prefix='/bp6', strict_slashes=True)

    bp1.route('/bp1/<param>')(lambda request, param: text(param))

# Generated at 2022-06-24 03:32:05.523614
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    # GIVEN
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp_group = BlueprintGroup('/api')
    # WHEN
    bp_group.append(bp1)
    bp_group.append(bp2)
    # THEN
    assert len(bp_group.blueprints) == 2
    assert bp_group.blueprints[0] == bp1
    assert bp_group.blueprints[1] == bp2


# Generated at 2022-06-24 03:32:13.436465
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    # Given a blueprint group
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bg = BlueprintGroup()
    
    # When the method __setitem__ is called
    bg[1:3] = [bp3, bp4]
    
    # The list of blueprints should be changed
    assert bg[1:3] == [bp3, bp4]


# Generated at 2022-06-24 03:32:15.745601
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    @BlueprintGroup()
    @Blueprint.middleware()
    async def test_blueprint_group_middleware(request):
        assert request.blueprint_group.middleware
    assert test_blueprint_group_middleware

# Generated at 2022-06-24 03:32:19.939714
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint("name", url_prefix="/1")
    bp2 = Blueprint("name", url_prefix="/2")
    bg = BlueprintGroup()
    bg.append(bp1)
    bg.append(bp2)
    assert bg[0] == bp1
    assert bg[1] == bp2


# Generated at 2022-06-24 03:32:29.407469
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')

    bpg1 = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    bpg2 = BlueprintGroup(bp5, bp6, url_prefix="/api", version="v1")

    bpg = BlueprintGroup(bp1, bp2)

    bpg.append(bpg1)

# Generated at 2022-06-24 03:32:39.860880
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    """
    Ensure that when a new blueprint is added to the
    BlueprintGroup, the BlueprintGroup behaves as a mutable
    sequence list like object
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = BlueprintGroup()
    assert len(group) == 0
    group.append(bp1)

    assert len(group) == 1
    assert group[0] == bp1

    group.append(bp2)
    assert len(group) == 2
    assert group[1] == bp2


# Generated at 2022-06-24 03:32:50.964863
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    assert bpg.url_prefix == "/api"
    assert bpg.blueprints == []
    assert bpg.version == "v1"
    assert bpg.strict_slashes is None

    bpg = BlueprintGroup(url_prefix="api/v1", version=1.0)
    assert bpg.url_prefix == "api/v1"
    assert bpg.blueprints == []
    assert bpg.version == 1.0
    assert bpg.strict_slashes is None

    bpg = BlueprintGroup(url_prefix="api/v1", version=1.0, strict_slashes=True)
    assert bpg.url_prefix == "api/v1"
    assert bpg.blueprints == []
    assert b

# Generated at 2022-06-24 03:32:53.820789
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bpgg = BlueprintGroup(url_prefix='/', version='1.0.0')
    blueprint = Blueprint(url_prefix='/blueprints')
    bpgg.append(blueprint)
    assert bpgg.blueprints in bpgg


# Generated at 2022-06-24 03:32:59.547753
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp3 = Blueprint('bp3', url_prefix='/bp3')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    del bpg[0]
    assert len(bpg) == 1

    del bpg[0]
    assert len(bpg) == 0

# Generated at 2022-06-24 03:33:05.773363
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.insert(0, bp1)
    assert len(bpg) == 1
    assert bpg[0].name == bp1.name


# Generated at 2022-06-24 03:33:07.626063
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    assert 1
    # TODO Write a test that checks the BlueprintGroup middleware method works
    # properly



# Generated at 2022-06-24 03:33:11.658379
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    # Create a new BlueprintGroup Instance
    bpg = BlueprintGroup("/api", "v1", False)

    assert bpg.url_prefix == "/api"
    assert bpg.version == "v1"
    assert bpg.strict_slashes == False



# Generated at 2022-06-24 03:33:17.982830
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bpg = BlueprintGroup()

    assert bpg.blueprints == []
    assert bpg.url_prefix is None
    assert bpg.version is None
    assert bpg.strict_slashes is None

    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    assert bpg.blueprints == [bp1, bp2]
    assert bpg.url_prefix == "/api"
    assert bpg.version == "v1"
    assert bpg.strict_slashes is None


# Generated at 2022-06-24 03:33:25.968258
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1', strict_slashes=False)
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    @bpg.middleware('request')
    async def group_middleware(request):
        print

# Generated at 2022-06-24 03:33:33.166149
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import URLBuildError
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')
    bp7 = Blueprint('bp7', url_prefix='/bp7')
    bp8 = Blueprint('bp8', url_prefix='/bp8')
    bp9 = Blueprint('bp9', url_prefix='/bp9')
    bp10 = Blueprint

# Generated at 2022-06-24 03:33:40.062857
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bp3 = Blueprint("bp3")
    bp4 = Blueprint("bp4")
    bp5 = Blueprint("bp5")
    bpg = BlueprintGroup()
    for _bp in [bp1, bp2, bp3, bp4, bp5]:
        bpg.append(_bp)
    assert len(bpg) == 5
    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert bpg[2] == bp3
    assert bpg[3] == bp4
    assert bpg[4] == bp5


# Generated at 2022-06-24 03:33:49.208727
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    # Create a blueprint denoted by : 'bp1'
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    assert bp1

    # Create a blueprint denoted by : 'bp2'
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    assert bp2

    # Create a blueprint denoted by : 'bp3'
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    assert bp3

    # Create a blueprint denoted by : 'bp4'
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    assert bp4

    # Create a Blueprint Group denoted by : 'group'
    group = Blueprint.group(bp1, bp2, url_prefix="/api", version="v1")
    assert group

# Generated at 2022-06-24 03:33:59.012820
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Given
    class MyBlueprint(sanic.Blueprint):
        pass

    bp1 = MyBlueprint('test1', url_prefix='/bp1')
    bp2 = MyBlueprint('test2', url_prefix='/bp2')
    bp3 = MyBlueprint('test3', url_prefix='/bp4')
    bp4 = MyBlueprint('test4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

# Generated at 2022-06-24 03:34:07.189652
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp = Blueprint(
        "test",
        url_prefix="/test",
        version="v1",
        strict_slashes=True
    )
    bp_group = BlueprintGroup()
    bp_1 = Blueprint("test_1")
    bp_2 = Blueprint("test_2")
    bp_3 = Blueprint("test_3")
    bp_group.append(bp_1)
    bp_group.append(bp_2)
    bp_group.append(bp_3)

    @bp_group.middleware("request")
    async def test_bp_group_method_middleware(request):
        return

    @bp.middleware("request")
    async def test_bp_method_middleware(request):
        return

    # bp_group

# Generated at 2022-06-24 03:34:11.319539
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp = Blueprint('bp', url_prefix='/bp')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    assert len(bpg) == 0
    bpg.append(bp)
    assert len(bpg) == 1


# Generated at 2022-06-24 03:34:18.193755
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp = BlueprintGroup(bp1, bp2)
    assert len(bp) == 2
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp.append(bp3)
    assert len(bp) == 3
    assert bp3 in bp


# Generated at 2022-06-24 03:34:23.542951
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp = Blueprint("bp", url_prefix="/bp")
    bp_item = Blueprint("bp_item", url_prefix="/bp1")
    bpg = BlueprintGroup("/api", version="v1")
    bpg.append(bp)
    assert bpg[0] == bp
    bpg[0] = bp_item
    assert bpg[0] == bp_item



# Generated at 2022-06-24 03:34:31.382028
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    The following unit test asserts Middleware debugging
    information provided by BlueprintGroup
    """

    app = sanic.Sanic()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    # This method is called only for Blueprint group
    @bpg.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    # This method is called only for Blueprint 1

# Generated at 2022-06-24 03:34:42.002306
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    @sanic.blueprint.Blueprint.group(url_prefix='/bp1/')
    class TestGroup(BlueprintGroup):
        pass

    bg1 = TestGroup()
    assert len(bg1) == 0

    bp1 = sanic.blueprint.Blueprint('bp1')
    bp2 = sanic.blueprint.Blueprint('bp2')
    bg2 = TestGroup(bp1, bp2)
    assert len(bg2) == 2

    bp3 = sanic.blueprint.Blueprint('bp3')
    bg2.append(bp3)
    assert len(bg2) == 3

    del bg2[0]
    assert len(bg2) == 2

# Generated at 2022-06-24 03:34:53.022493
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic.blueprints import Blueprint

    class FakeSanicApp:

        def register_middleware(
            self, middleware, attach_to="request", *args, **kwargs
        ):
            return f"FakeSanicApp.register_middleware({middleware}, {attach_to}, {args}, {kwargs})"

    class FakeBlueprint:

        def __init__(self, sanic_app):
            self.sanic_app = sanic_app

    bp1 = FakeBlueprint(FakeSanicApp())
    bp2 = FakeBlueprint(FakeSanicApp())

    bpg = BlueprintGroup()
    bpg.blueprints = [bp1, bp2]

    # Test function that will act as the middleware