

# Generated at 2022-06-24 03:24:59.894979
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    bpg.__delitem__(1)
    assert len(bpg) == 3



# Generated at 2022-06-24 03:25:10.106670
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup('/api')
    bpg.append(bp1)
    bpg.append(bp2)
    len(bpg)
    assert len(bpg) == 2
    del bpg[0]
    assert len(bpg) == 1
    assert bpg[0] == bp2
    bpg.insert(0, bp1)
    assert len(bpg) == 2
    assert bpg[0] == bp1
    del bpg[-1]
    del bpg[-1]
    assert len(bpg) == 0


# Generated at 2022-06-24 03:25:15.829001
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    assert isinstance(bpg, BlueprintGroup)
    assert isinstance(bpg, MutableSequence)

    assert len(bpg) == 2
    assert [bp1, bp2] == bpg



# Generated at 2022-06-24 03:25:22.583734
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():

    # test default parameter
    b = BlueprintGroup()
    assert b._url_prefix is None
    assert b._version is None
    assert b._strict_slashes is None

    # test setter parameter
    b = BlueprintGroup(url_prefix="/api",version=1, strict_slashes=True)
    assert b._url_prefix == "/api"
    assert b._version == 1
    assert b._strict_slashes is True


# Generated at 2022-06-24 03:25:30.468515
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    Blueprint = sanic.Blueprint

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)

    assert bp1 in bpg
    assert bp2 in bpg
    assert len(bpg) == 2
    assert list(bpg) == [bp1, bp2]


# Generated at 2022-06-24 03:25:41.156035
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp3)
    bpg.append(bp4)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-24 03:25:46.860513
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2)
    assert next(iter(bpg)) == bp1
    assert next(iter(bpg.__iter__())) == bp1


# Generated at 2022-06-24 03:25:49.578586
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    blueprint = Blueprint('test_blueprint', url_prefix='/test')
    blueprintGroup = BlueprintGroup()
    blueprintGroup.append(blueprint)
    blueprint2 = blueprintGroup[0]
    assert blueprint is blueprint2


# Generated at 2022-06-24 03:25:59.237804
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bp5 = Blueprint('bp3', url_prefix='/bp5')
    bp6 = Blueprint('bp4', url_prefix='/bp6')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    bpg.extend([bp5,bp6])

    bpg.insert(0,bp3)



# Generated at 2022-06-24 03:26:01.647196
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    obj = BlueprintGroup()
    blueprint = Blueprint("test_blueprint", url_prefix="/")

    obj.append(blueprint)

    list_of_blueprints = [blueprint]

    assert obj.blueprints == list_of_blueprints



# Generated at 2022-06-24 03:26:08.387913
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert bpg.blueprints[0] == bp1
    assert bpg.blueprints[1] == bp2


# Generated at 2022-06-24 03:26:12.848419
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    assert bp1 != bp2
    assert isinstance(bp1, Blueprint)
    assert isinstance(bp2, Blueprint)

    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    assert bpg != bp1
    assert bpg != bp2
    assert isinstance(bpg, BlueprintGroup)


# Generated at 2022-06-24 03:26:24.196120
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Scenario 1: Middleware is being applied to a blueprint that is inside
    #             a blueprint group.
    bp = Blueprint('bp', url_prefix='/api/v1/bp')
    bpg = BlueprintGroup(bp, url_prefix='/api', version='v1')


    # Scenario 2: Middleware is being applied to a nested blueprint group.
    bp1 = Blueprint('bp1', url_prefix='/api/v1/bp1')
    bp2 = Blueprint('bp2', url_prefix='/api/v1/bp2')
    bpg1 = BlueprintGroup(bp1, bp2, url_prefix='/api', version='v1')

    bp3 = Blueprint('bp3', url_prefix='/api/v1/bp3')

# Generated at 2022-06-24 03:26:32.205802
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    """Testing Blueprint Group construction"""
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bpg = BlueprintGroup(bp1, bp2)

    assert bpg.url_prefix is None
    assert bpg.version is None
    assert bpg.strict_slashes is None

    assert bpg.blueprints == [bp1, bp2]

    bpg_1 = BlueprintGroup("/prefix", "v1", True)
    assert bpg_1.url_prefix == "/prefix"
    assert bpg_1.version == "v1"
    assert bpg_1.strict_slashes is True



# Generated at 2022-06-24 03:26:38.693926
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    # Test with an empty BlueprintGroup
    A = BlueprintGroup()
    assert len(A) == 0

    # Test with populated BlueprintGroup
    A: BlueprintGroup = BlueprintGroup(url_prefix="some")
    assert len(A) == 0

    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    A.extend([bp1, bp2])

    assert len(A) == 2



# Generated at 2022-06-24 03:26:40.459605
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    BlueprintGroup.insert(index=0, item=BlueprintGroup)
    assert 0 == len(BlueprintGroup)



# Generated at 2022-06-24 03:26:48.892868
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    def test_function(*args, **kwargs):
        print("test function executed")

    bp1 = Blueprint('test_bp1', url_prefix='/test_bp1')
    bp2 = Blueprint('test_bp2', url_prefix='/test_bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.middleware(test_function)
    assert len(bpg.blueprints[0].middlewares['request']) == 1
    assert len(bpg.blueprints[1].middlewares['request']) == 1

# Generated at 2022-06-24 03:26:57.735519
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    blueprints = BlueprintGroup()
    for bp in [bp1, bp2, bp3, bp4, bp5]:
        blueprints.append(bp)
    for idx, bp in enumerate(blueprints):
        assert isinstance(bp, Blueprint)
        assert blueprints[idx].name == bp.name



# Generated at 2022-06-24 03:27:06.766612
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp = Blueprint('bp')
    bp2 = Blueprint('bp2')
    bp_group = BlueprintGroup()
    bp_group.append(bp)
    bp_group.append(bp2)
    @bp_group.middleware('request')
    async def middleware_function_group(request):
        print('middleware_function_group is called')
        pass
    @bp.middleware('request')
    async def middleware_function_blueprint(request):
        print('middleware_function_blueprint is called')
        pass

    assert len(bp.middlewares['request']) == 1
    assert len(bp2.middlewares['request']) == 1
    assert len(bp_group.blueprints[0].middlewares['request']) == 2

# Generated at 2022-06-24 03:27:10.366124
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    url_prefix = '/url_prefix'
    version = 'v1'
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = BlueprintGroup(url_prefix=url_prefix, version=version)
    group.append(bp1)
    group.append(bp2)
    assert len(group) == 2
    del group[0]
    assert len(group) == 1
    del group[-1]
    assert len(group) == 0


# Generated at 2022-06-24 03:27:20.937345
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic("test_BlueprintGroup_middleware")
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bpg = BlueprintGroup("bpg", url_prefix="/bpg")
    bpg2 = BlueprintGroup("bpg2", url_prefix="/bpg2")
    bpg3 = BlueprintGroup("bpg3", url_prefix="/bpg3")
    bpg4 = BlueprintGroup("bpg4", url_prefix="/bpg4")

    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bpg3)
    bpg.append(bpg4)

    bpg

# Generated at 2022-06-24 03:27:23.053325
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp_group = BlueprintGroup()
    bp_group._blueprints = list(range(100))
    assert list(bp_group) == list(range(100))


# Generated at 2022-06-24 03:27:27.308386
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp = Blueprint("test", url_prefix="/group")
    group = BlueprintGroup("/api", "v1")
    bp2 = Blueprint("test", url_prefix="/group2")
    group[0] = bp
    group[1] = bp2
    assert group[0] == bp
    assert group[1] == bp2



# Generated at 2022-06-24 03:27:37.435704
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic(__name__)

   # Set param1 to 0 and param2 to 1
    @app.middleware('request')
    async def process_request(request):
        print("Request is going to be processed by the middleware")

    # Testing the setup to be compatible with old version of sanic
    # register blueprint
    @bp1.middleware('request')
    async def process_request(request):
        print("Request is going to be processed by the middleware")

    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    # register blueprint
    bp1.middleware(process_request)
    bp2.middleware(process_request)

# Generated at 2022-06-24 03:27:48.861218
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')
    bp7 = Blueprint('bp7', url_prefix='/bp7')
    bp8 = Blueprint('bp8', url_prefix='/bp8')
    bpg = BlueprintGroup()
    bpg.insert(0,bp1)
    bpg.insert(1,bp2)
    bpg.insert(2,bp3)
    bpg

# Generated at 2022-06-24 03:27:59.611127
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = sanic.Blueprint('bp1')
    bp2 = sanic.Blueprint('bp2')
    bp3 = sanic.Blueprint('bp3')
    bp4 = sanic.Blueprint('bp4')
    bp_group = BlueprintGroup(bp1, bp2, bp3, bp4)

    assert bp_group[0] == bp1
    assert bp_group[1] == bp2
    assert bp_group[2] == bp3
    assert bp_group[3] == bp4
    assert bp_group[-1] == bp4
    assert bp_group[-2] == bp3
    assert bp_group[-3] == bp2
    assert bp_group[-4] == bp

# Generated at 2022-06-24 03:28:10.479251
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp_with_version = Blueprint("bp", url_prefix="/bp", version=1)
    bp_with_strict_slash = Blueprint("bp", url_prefix="/bp", strict_slashes=True)
    blueprintGroup = BlueprintGroup("/api", version="v1", strict_slashes=True)

    assert blueprintGroup.url_prefix == "/api"
    assert blueprintGroup.blueprints == []
    assert blueprintGroup.version == "v1"
    assert blueprintGroup.strict_slashes == True

    blueprintGroup.append(bp_with_version)
    blueprintGroup.append(bp_with_strict_slash)
    assert len(blueprintGroup.blueprints) == 2
    assert blueprintGroup[0] == bp_with_version
    assert blueprintGroup[1] == bp_with_strict_

# Generated at 2022-06-24 03:28:20.821020
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    # Initialize a new BlueprintGroup object
    bpg = BlueprintGroup()
    # Append a new Blueprint to BlueprintGroup
    bpg.append(sanic.Blueprint("bpg"))
    # Since we have add a new Blueprint we should have a valid Blueprint with
    # the index equal to 0
    assert bpg[0] is not None
    # Remove the Blueprint from BlueprintGroup
    del bpg[0]
    # Since we have deleted the first item from BlueprintGroup
    # accessing bpg[0] should raise IndexError
    with pytest.raises(IndexError):
        bpg[0]
    # Append a new Blueprint to BlueprintGroup
    bpg.append(sanic.Blueprint("bpg"))
    # Assign the new Blueprint to a different index
    bpg[1] = sanic.Blueprint("bpg")


# Generated at 2022-06-24 03:28:30.182977
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp = BlueprintGroup()
    bp.append(Blueprint('Bp1', url_prefix="/bp1"))
    bp.append(Blueprint('Bp2', url_prefix="/bp2"))
    bp = BlueprintGroup()
    bp.append(Blueprint('Bp3', url_prefix="/bp3"))
    bp.append(Blueprint('Bp4', url_prefix="/bp4"))
    bpg = BlueprintGroup()
    bpg.append(bp)
    bpg.append(bp)
    assert len(bpg) == 2
    assert len(bpg[0]) == 2
    assert len(bpg[0][0]['ROUTES']) == 0
    assert len(bpg[0][0]['WEBSOCKETS']) == 0

# Generated at 2022-06-24 03:28:39.050611
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    # Forcing delete of the item at index 0
    bp_group = BlueprintGroup()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bp_group.append(bp1)
    bp_group.append(bp2)
    bp_group.append(bp3)
    bp_group.append(bp4)

    bp_group.__delitem__(0)
    # Checking if size of the list blueprints is equal to 3
    assert len(bp_group.blueprints) == 3
    # Checking if item at index 0 is b

# Generated at 2022-06-24 03:28:49.377774
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bpg = BlueprintGroup()
    assert bpg.url_prefix is None
    assert bpg.version is None
    assert bpg.blueprints == []
    assert bpg.strict_slashes is None
    assert len(bpg) == 0
    bpg.append(Blueprint("test_bp", url_prefix="/test", version=1))
    bpg.append(Blueprint("test_bp2", url_prefix="/test", version=1))
    assert len(bpg) == 2
    assert bpg.blueprints[0].url_prefix == "/test"
    assert bpg.blueprints[0].version == 1
    assert bpg.blueprints[1].url_prefix == "/test"
    assert bpg.blueprints[1].version == 1

# Generated at 2022-06-24 03:28:55.312554
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp_grp = BlueprintGroup()
    bp_grp.append("bp1")
    bp_grp.append("bp2")
    bp_grp.append("bp3")

    bp_iter = iter(bp_grp)

    assert next(bp_iter) == "bp1"
    assert next(bp_iter) == "bp2"
    assert next(bp_iter) == "bp3"


# Generated at 2022-06-24 03:29:03.635240
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp1.version = 'v1'
    bp2.version = 'v2'
    bp1.strict_slashes = False
    bp2.strict_slashes = False
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp3.version = 'v3'
    bp4.version = 'v4'
    bp3.strict_slashes = False
    bp4.strict_slashes = False

# Generated at 2022-06-24 03:29:04.304636
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    BlueprintGroup()

# Generated at 2022-06-24 03:29:05.700516
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    """Unit test for method __iter__ of class BlueprintGroup"""



# Generated at 2022-06-24 03:29:17.298717
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    
    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    bpg.append(bp1)
    bpg.append(bp2)
    

# Generated at 2022-06-24 03:29:25.810353
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    # BlueprintGroup object initialization
    # This block will run when the test is called via command line
    bp = BlueprintGroup()

    # Blueprint1 creation
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    
    # Blueprint2 creation
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    # Blueprint3 creation
    bp3 = Blueprint('bp3', url_prefix='/bp4')

    # Blueprint4 creation
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    # Blueprint group creation
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    # Blueprint group creation
    group = Blueprint.group(bp1, bp2)

    # Checking the length of BlueprintGroup object

# Generated at 2022-06-24 03:29:32.032870
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.insert(0,bp2)
    assert(bp1 == bpg.blueprints[1])
    assert(bp2 == bpg.blueprints[0])

# Generated at 2022-06-24 03:29:43.030601
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")
    bp5 = Blueprint("bp5", url_prefix="/bp5")
    bp6 = Blueprint("bp6", url_prefix="/bp6")
    bp7 = Blueprint("bp7", url_prefix="/bp7")
    bp8 = Blueprint("bp8", url_prefix="/bp8")

    bpg = BlueprintGroup(bp1, bp2, bp3, bp4, bp5, bp6, bp7, bp8)
    del bpg[0]

# Generated at 2022-06-24 03:29:51.154546
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bp5 = Blueprint('bp5', url_prefix='/bp5')

    group1 = BlueprintGroup()
    group1.append(bp1)
    group1.append(bp2)

    assert bp1 in group1._blueprints
    assert bp2 in group1._blueprints
    assert bp3 not in group1._blueprints
    assert bp4 not in group1._blueprints
    assert bp5 not in group1._blueprints

    group1.append(bp3)
    assert b

# Generated at 2022-06-24 03:29:58.602058
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # given
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix='/api', version='v1')

    # when
    @bpg.middleware
    def middleware(request):
        print('common middleware')

    # then
    assert len(bpg.blueprints) == 0
    assert middleware



# Generated at 2022-06-24 03:30:04.106054
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    # Check the returns of methods __setitem__ and __getitem__
    bp1.group(bp1, bp2).__setitem__(0, bp2)
    assert bp1.group(bp1, bp2).__getitem__(0) is bp2



# Generated at 2022-06-24 03:30:13.583042
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/BP3')
    bp4 = Blueprint('bp4', url_prefix='/BP4')

    bpg = BlueprintGroup(url_prefix="/api")
    bpg.extend([bp1, bp2, bp3, bp4])

    assert len(bpg) == 4
    assert bp1 in bpg
    assert bp2 in bpg
    assert bp3 in bpg
    assert bp4 in bpg

    del bpg[0]
    assert len(bpg) == 3
    assert bp1 not in bpg
    assert bp2 in bpg
    assert b

# Generated at 2022-06-24 03:30:20.719521
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    # expected value
    blueprint_group = BlueprintGroup()
    blueprint_group.append(Blueprint("blueprint1", url_prefix="/blueprint1"))
    blueprint_group.append(Blueprint("blueprint2", url_prefix="/blueprint2"))
    blueprint_group.append(Blueprint("blueprint3", url_prefix="/blueprint3"))
    blueprint_group.append(Blueprint("blueprint4", url_prefix="/blueprint4"))

    # actual value
    actual_value = blueprint_group.__iter__()

    # expected value
    expected_value = iter(blueprint_group.blueprints)

    # assert equal
    assert actual_value == expected_value


# Generated at 2022-06-24 03:30:29.269413
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.insert(0, bp3)
    bpg.insert(0, bp4)
    assert len(bpg._blueprints) == 2
    assert bpg._blueprints[0] == bp4
    assert bpg._blueprints[1] == bp3


# Generated at 2022-06-24 03:30:29.817110
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    BlueprintGroup(None)

# Generated at 2022-06-24 03:30:33.244236
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    _blueprint = Blueprint("bp1")

    # create the blueprintGroup object
    bg = BlueprintGroup()

    bg.append(_blueprint)

    # call the iter function
    it = bg.__iter__()

    # test if the object returned is a sanic Blueprint type
    assert isinstance(next(it), Blueprint)


# Generated at 2022-06-24 03:30:35.916893
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    pass


# Generated at 2022-06-24 03:30:42.883822
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    # Add some blueprints to BlueprintGroup
    bp = Blueprint("bp", url_prefix="/api")
    bp2 = Blueprint("bp2", url_prefix="/bp2", version="v1.0")
    bp3 = Blueprint("bp3", url_prefix="/bp3", version="v2.0", strict_slashes=True)
    bp4 = Blueprint("bp4", url_prefix="/bp4", version="v2.0", strict_slashes=False)
    bpg = BlueprintGroup()
    bpg.append(bp)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    assert len(bpg) == 4



# Generated at 2022-06-24 03:30:45.494599
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():

    bp = Blueprint('test', url_prefix='/test')
    bpg = BlueprintGroup(bp, url_prefix="/api", version="v1")
    del bpg[0]
    assert bpg._blueprints == []
    

# Generated at 2022-06-24 03:30:48.416830
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group = BlueprintGroup()
    blueprint_group.append("blueprint_1")
    blueprint_group.append("blueprint_2")
    assert len(blueprint_group) == 2


# Generated at 2022-06-24 03:30:59.808218
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class dummy1():
        def __init__(self):
            pass

    dummy1 = dummy1()
    dummy1.__name__ = "dummy1"
    dummy2 = dummy1()
    dummy2.__name__ = "dummy1"
    blueprint_group = BlueprintGroup()
    blueprint_group.append(dummy1)
    blueprint_group.append(dummy2)
    blueprint_group.middleware(lambda request: None)
    blueprint_group.middleware(lambda request: None, attach_to="response")
    blueprint_group.middleware(attach_to="response")(lambda request: None)
    blueprint_group.middleware(lambda request: None, attach_to="request")
    blueprint_group.middleware(attach_to="request")(lambda request: None)



# Generated at 2022-06-24 03:31:07.627738
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint = BlueprintGroup()
    blueprint.append(sanic.Blueprint('test_middleware'))
    blueprint.append(sanic.Blueprint('test_middleware_1'))
    blueprint.append(sanic.Blueprint('test_middleware_2'))
    blueprint.middleware(TestMiddleware)

    for blueprint in blueprint.blueprints:
        middleware_chain = blueprint.handle_request.__self__.middleware

        assert len(middleware_chain) == 1
        assert middleware_chain[0][0] == TestMiddleware


# Generated at 2022-06-24 03:31:13.478199
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()

    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg[0] != bp2
    assert bpg[1] != bp1


# Generated at 2022-06-24 03:31:20.830945
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group = BlueprintGroup()
    blueprintGroup = BlueprintGroup()
    blueprintGroup.blueprints = [Blueprint(__name__)]

    def test_middleware(request):
        return True

    blueprintGroup.middleware(test_middleware)
    assert blueprintGroup.blueprints[0].middlewares[0] == (test_middleware, None, {})

    blueprint_group.middleware(test_middleware, args=True)
    assert blueprint_group.blueprints[0].middlewares[0] == (test_middleware, True, {})

    blueprint_group.middleware(test_middleware, kwargs=False)
    assert blueprint_group.blueprints[0].middlewares[0] == (test_middleware, {}, False)


# Generated at 2022-06-24 03:31:26.377755
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp_group = BlueprintGroup('/api', version='v1.0')

    bp_group[0] = bp1
    bp_group[1] = bp2

    assert bp_group.blueprints[0] == bp1
    assert bp_group.blueprints[1] == bp2


# Generated at 2022-06-24 03:31:32.839944
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3, bp4 = [Blueprint(f"bp{i}", url_prefix=f"/bp{i}") for i in [3, 4]]


# Generated at 2022-06-24 03:31:37.209795
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    test_app = sanic.Sanic()
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    test_app.blueprint(bpg)

    del bpg[1]
    assert len(test_app.blueprints) == 1


# Generated at 2022-06-24 03:31:42.465475
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    # Arrange
    blueprint_group = BlueprintGroup()
    blueprint = Blueprint("test_name")
    blueprint_group.append(blueprint)

    # Act
    blueprint_iter = blueprint_group.__iter__()

    # Assert
    expected = "BLUEPRINT NAME '{}'".format(blueprint_group[0].name)
    assert str(next(blueprint_iter)) == expected



# Generated at 2022-06-24 03:31:53.038651
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)

    assert bpg[1] is bp2
    assert bpg[1].url_prefix == "/api/bp2"
    assert bpg[1].version == "v1"
    assert bpg[1].strict_slashes is None
    assert bpg[3] == bp3
    assert b

# Generated at 2022-06-24 03:31:59.137499
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert (bp1 == bpg[0] and bp2 == bpg[1])


# Generated at 2022-06-24 03:32:09.660933
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    """
    Unit test for method __iter__ of class BlueprintGroup
    """

    registry = {}
    url_prefix = None
    version = None
    strict_slashes = None

    bp1 = Blueprint('bp1', url_prefix='/bp1', version='v1', strict_slashes=True)
    bp1.name = '/bp1'
    bp1.url_prefix = '/bp1'
    bp1.host = None
    bp1.subdomain = None
    bp1.version = 'v1'
    bp1.strict_slashes = True
    bp1.deferred = False
    bp1.static_folder = None
    bp1.static_url_path = None
    bp1.template_folder = None
    bp1.handlers = {}

# Generated at 2022-06-24 03:32:19.750680
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    bpg.insert(0, bp1)
    bpg.insert(1, bp2)
    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert bpg[2] == bp3
    assert bpg[3] == bp4

# Generated at 2022-06-24 03:32:24.487299
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)
    assert len(group) == 2
    assert group[0] == bp1
    assert group[1] == bp2


# Generated at 2022-06-24 03:32:34.132946
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    assert bpg.url_prefix == "/api"
    assert bpg.version == "v1"
    assert isinstance(bpg, BlueprintGroup)


# Generated at 2022-06-24 03:32:39.975359
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bpg) == 2


# Generated at 2022-06-24 03:32:51.067193
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg1 = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    bpg2 = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v2")

    assert len(bpg1) == 2
    assert bpg1.url_prefix == "/api"
    assert bpg1.version == "v1"
    assert bpg1.blueprints == [bp1, bp2]

    bpg1.insert(1, bp3)

# Generated at 2022-06-24 03:32:51.960312
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    pass


# Generated at 2022-06-24 03:32:57.590287
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bg = BlueprintGroup(url_prefix='/api', version='v1')
    assert isinstance(bg, BlueprintGroup)
    assert bg.url_prefix == '/api'
    assert bg.version == 'v1'


# Generated at 2022-06-24 03:33:01.029960
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bpg = BlueprintGroup()
    bpg[0] = Blueprint(0)

    assert bpg[0].name == 0


# Generated at 2022-06-24 03:33:12.068359
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bpg.append(bp3)
    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')
    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)
    @bp3.route('/')
    async def bp3_route(request):
        return text('bp3')

    # Test the iter method of BlueprintGroup
    B

# Generated at 2022-06-24 03:33:20.978628
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2') 
    bp3 = Blueprint('bp3', url_prefix='/bp3')

    bpg = BlueprintGroup(url_prefix='/api/v1')
    bpg.insert(0, bp1)
    assert bpg[0] == bp1
    bpg.insert(0, bp2)
    assert bpg[0] == bp2
    assert bpg[1] == bp1
    bpg.insert(1, bp3)
    assert bpg[0] == bp2
    assert bpg[1] == bp3
    assert bpg[2] == bp1


# Generated at 2022-06-24 03:33:26.349144
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')

    bpg = BlueprintGroup(url_prefix='/api', version='v1')
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)

    del bpg[0]
    assert len(bpg) == 2

    del bpg[1]
    assert len(bpg) == 1

    del bpg[0]
    assert len(bpg) == 0


# Generated at 2022-06-24 03:33:30.698410
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprints = [Blueprint(f"bp{i}") for i in range(10)]
    bpg = BlueprintGroup(url_prefix='/api', *blueprints)
    assert len(bpg) == 10
    bpg.append(Blueprint("bp11"))
    assert len(bpg) == 11



# Generated at 2022-06-24 03:33:34.709438
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    @sanic.blueprint(url_prefix="/group")
    def bp1():
        pass

    @sanic.blueprint(url_prefix="/group")
    def bp2():
        pass

    bp1()
    bp2()

    bpg = BlueprintGroup(bp1, bp2)
    assert len(bpg) == 2

# Generated at 2022-06-24 03:33:40.722777
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp_group = BlueprintGroup()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp_group.append(bp1)
    bp_group.append(bp2)
    assert len(bp_group) == 2
    del bp_group[0]
    assert len(bp_group) == 1
    assert bp_group[0] == bp2


# Generated at 2022-06-24 03:33:47.291514
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    """
    Test BlueprintGroup.__iter__

    Test:
        Verify the BlueprintGroup.__iter__ method will return a list of
        Blueprint object using the iteration.

    :return: None
    """
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg) == 2
    assert bpg[0].name == "bp1"
    assert bpg[1].name == "bp2"


# Generated at 2022-06-24 03:33:52.740381
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bg1 = BlueprintGroup()
    b1 = Blueprint('bp1', url_prefix='/bp1')
    b2 = Blueprint('bp2', url_prefix='/bp2')
    bg1.insert(0, b1)
    bg1.insert(1, b2)
    assert bg1.url_prefix is None
    assert len(bg1) == 2
    assert bg1[0] is b1
    assert bg1[1] is b2


# Generated at 2022-06-24 03:34:01.787809
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bp3 = sanic.Blueprint('bp3', url_prefix='/bp3')
    bpg = BlueprintGroup()

    assert len(bpg) == 0
    assert len(bpg) == 0
    bpg.append(bp1)
    assert len(bpg) == 1
    bpg.append(bp2)
    assert len(bpg) == 2
    bpg.append(bp3)
    assert len(bpg) == 3
    bpg.append(bp3)
    assert len(bpg) == 4


# Generated at 2022-06-24 03:34:06.927017
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprintGroup = BlueprintGroup()
    blueprintGroup.append(None)
    blueprintGroup.append(None)
    blueprintGroup.append(None)
    blueprintGroup.append(None)

    # Test with empty blueprint group
    assert len(blueprintGroup) == 4
    
    
BlueprintGroup()

# Generated at 2022-06-24 03:34:18.146209
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp3 = Blueprint('bp3', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-24 03:34:27.764963
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    bpg.append(bp5)
        
    del bpg[2]
    assert bpg.blueprints == [bp1, bp2, bp4, bp5]
    del bpg[:2]


# Generated at 2022-06-24 03:34:31.591593
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix='/api',version='v1')
    bpg.insert(0,bp1)
    bpg.insert(1,bp2)
    assert bpg[0] == bp1
    assert bpg[1] == bp2


# Generated at 2022-06-24 03:34:37.924476
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    assert BlueprintGroup().__len__() == 0
    assert BlueprintGroup(url_prefix="/api").__len__() == 0
    assert BlueprintGroup(version="v2").__len__() == 0
    assert BlueprintGroup(strict_slashes=False).__len__() == 0
    assert BlueprintGroup(url_prefix="/api", version="v1").__len__() == 0


# Generated at 2022-06-24 03:34:47.126415
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1', version='v1')
    bp2 = Blueprint('bp2', url_prefix='/bp2', strict_slashes=True)

    bpg = BlueprintGroup(url_prefix="/api", version="v2")

    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg.version == "v2"
    assert bpg.strict_slashes == None

    assert bpg.blueprints[0].url_prefix == "/api/bp1"
    assert bpg.blueprints[0].version == "v2"
    assert bpg.blueprints[0].strict_slashes == None

    assert bpg.blueprints[1].url_prefix == "/api/bp2"

# Generated at 2022-06-24 03:34:55.594177
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    assert list(bpg) == [bp1, bp2, bp3, bp4]
