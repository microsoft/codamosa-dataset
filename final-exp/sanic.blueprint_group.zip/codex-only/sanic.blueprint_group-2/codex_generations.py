

# Generated at 2022-06-24 03:24:58.555880
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    BlueprintGroup.append(bp1, bp2)
    assert len(BlueprintGroup) == 2
    assert BlueprintGroup[0] == bp1
    assert BlueprintGroup[1] == bp2


# Generated at 2022-06-24 03:25:09.276830
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    group = Blueprint.group(bp1, bp2, url_prefix='/api', version='v1')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    @bp3.route('/')
    async def bp3_route(request):
        return text('bp3')


# Generated at 2022-06-24 03:25:16.941969
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():

    app = sanic.Sanic(__name__)
    app.config.KEEP_ALIVE = False
    app.config.KEEP_ALIVE_TIMEOUT = 5
    bg = BlueprintGroup()

    bp1 = Blueprint('bp1', url_prefix='/bp1')

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    bp2 = Blueprint('bp2', url_prefix='/bp2')
    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

# Generated at 2022-06-24 03:25:27.902023
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix='/api')
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    del bpg[1]
    assert bpg.blueprints == [bp1, bp4]

    del bpg[-1]
    assert bpg.blueprints == [bp1]

    del bpg[-1]
    assert bpg.blueprints == []

#

# Generated at 2022-06-24 03:25:32.329376
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    """
    This test case verifies if class `BlueprintGroup` has correct working
    implementation for method `insert`.
    """
    blueprintGroup = BlueprintGroup()
    blueprint = Blueprint("Test")
    blueprintGroup.insert(0, blueprint)
    assert blueprintGroup[0] == blueprint



# Generated at 2022-06-24 03:25:36.732476
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2)
    assert 2 == bpg.__len__()
    assert 2 == len(bpg)



# Generated at 2022-06-24 03:25:43.907872
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    from unittest.mock import MagicMock
    blueprint = BlueprintGroup()
    blueprint.__len__ = MagicMock(return_value=5)
    blueprint.__len__.__len__ = MagicMock(return_value=5)
    blueprint.__len__.__name__ = 'len'
    blueprint_len = blueprint.__len__()
    blueprint_len_len = blueprint.__len__.__len__()
    blueprint_len_name = blueprint.__len__.__name__
    assert blueprint_len == 5
    assert blueprint_len_len == 5
    assert blueprint_len_name == 'len'


# Generated at 2022-06-24 03:25:53.417240
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix="/bp1")
    bp2 = Blueprint('bp2', url_prefix="/bp2")

    bp3 = Blueprint('bp3', url_prefix="/api/bp3", version="v1")
    bp4 = Blueprint('bp4', url_prefix="/api/bp4", version="v1")

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    assert bp1 is bpg[0]
    assert bp2 is bpg[1]
    assert bp3 is bpg[2]
    assert bp4 is bpg[3]

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v5")
    assert "v5" == bpg.version
   

# Generated at 2022-06-24 03:26:01.829834
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')

    bp3 = sanic.Blueprint('bp3', url_prefix='/bp4')
    bp4 = sanic.Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)
    bpg.append(bp2)
    del bpg[0]

    assert len(bpg._blueprints) == 1
    assert bpg[0] == bp2


# Generated at 2022-06-24 03:26:03.802272
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bpg = BlueprintGroup()
    test = Blueprint('test')
    bpg.append(test)
    del bpg[0]
    assert not bpg._blueprints

# Generated at 2022-06-24 03:26:12.345871
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    # Setup
    console_logger = logging.getLogger("sanic")
    console_logger.setLevel(logging.CRITICAL)
    app = sanic.Sanic("sanic-blueprint-group")

    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    group = BlueprintGroup("/api", "v1")
    group.append(bp1)
    group.append(bp2)
    
    # Exercise
    result = len(group)

    # Verify
    assert result == 2

    # Cleanup - none necessary



# Generated at 2022-06-24 03:26:16.332686
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    p = BlueprintGroup()
    p.append(1)
    p.append(2)
    assert len(p) == 2
    assert p[0] == 1 and p[1] == 2
    assert list(p) == [1, 2]
    assert p == [1, 2]


# Generated at 2022-06-24 03:26:21.146697
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint(name='bp1', url_prefix='/bp1')
    bp2 = Blueprint(name='bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bpg) == 2

    assert bpg[0] is bp1
    assert bpg[1] is bp2



# Generated at 2022-06-24 03:26:31.091841
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp_1 = Blueprint('bp1', url_prefix='/bp1')
    bp_2 = Blueprint('bp2', url_prefix='/bp2')
    bp_3 = Blueprint('bp3', url_prefix='/bp3')
    bp_4 = Blueprint('bp4', url_prefix='/bp4')
    bp_group = BlueprintGroup()
    bp_group.append(bp_1)
    bp_group.append(bp_2)
    bp_group.append(BlueprintGroup())
    bp_group[2].append(bp_3)
    bp_group[2].append(bp_4)

# Generated at 2022-06-24 03:26:39.178567
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()

    bpg.append(bp1)
    bpg.insert(1, bp2)

    assert bpg.blueprints == [bp1, bp2]



# Generated at 2022-06-24 03:26:50.069256
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp1.route("/bp1")(lambda request : "bp1")
    bp2.route("/bp2")(lambda request : "bp2")
    app = sanic.Sanic("test_blueprint_group")
    bg = BlueprintGroup()
    bg.append(bp1)
    bg.append(bp2)
    bg._sanic = app
    assert len(bg) == 2
    del bg[0]
    assert len(bg) == 1
    assert bg[0].name == "bp2"
    assert bg[0].url_prefix == "/bp2"
    bg.append(bp1)
    assert len

# Generated at 2022-06-24 03:26:56.372168
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    assert len(bpg) == 3

# Generated at 2022-06-24 03:27:02.341381
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    from sanic.blueprints import Blueprint

    bp1 = Blueprint('test', url_prefix='/blueprint1')
    bp2 = Blueprint('test2', url_prefix='/blueprint2')

    bpg = BlueprintGroup('/api', version='v1')
    for bp in [bp1, bp2]:
        bpg.append(bp)

    assert len(bpg) == 2

    del bpg[0]
    assert len(bpg) == 1

    del bpg[0]
    assert len(bpg) == 0


# Generated at 2022-06-24 03:27:13.566692
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    app = sanic.Sanic('test_BlueprintGroup_append')
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpGroup = BlueprintGroup()
    bpGroup.append(bp1)
    bpGroup.append(bp2)
    bpGroup.append(bp3)
    bpGroup.append(bp4)

    assert len(bpGroup) == 4
    for bp in bpGroup:
        app.blueprint(bp)
    # TODO: assert request to /bp1, /bp2, /bp3, /bp4

# Generated at 2022-06-24 03:27:18.648001
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    class testclass(BlueprintGroup):
        def __init__(self):
            BlueprintGroup.__init__(self)
            self._item = []
        @property
        def item(self):
            return self._item
    obj = testclass()
    obj.append("blueprint1")
    obj[0] = "blueprint2"
    assert obj.item == ["blueprint2"]


# Generated at 2022-06-24 03:27:28.643544
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bp3 = sanic.Blueprint('bp3', url_prefix='/bp4')
    bp4 = sanic.Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp3)
    bpg.append(bp4)

    assert bpg[0] == bp3
    assert bpg[1] == bp4



# Generated at 2022-06-24 03:27:37.250331
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # type: () -> None
    a = Blueprint("a")
    b = Blueprint("b")
    c = Blueprint("c")
    d = Blueprint("d")
    group = Blueprint.group(a, b, url_prefix="group")
    group2 = Blueprint.group(c, d, url_prefix="group2")
    group3 = Blueprint.group(group, group2)
    @group3.middleware("request")
    def middleware(request):
        pass
    assert middleware.__name__ == "middleware"
    assert len(a._middlewares["request"]) == 1
    assert len(b._middlewares["request"]) == 1
    assert len(c._middlewares["request"]) == 1
    assert len(d._middlewares["request"]) == 1


# Generated at 2022-06-24 03:27:45.511425
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint("bp1", url_prefix='/bp1')
    bp2 = Blueprint("bp2", url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix='/bpg')

    bpg.insert(0, bp1)
    bpg.insert(0, bp2)

    assert bpg.blueprints[0] == bp2
    assert bpg.blueprints[1] == bp1
    assert bpg.url_prefix == "/bpg"


# Generated at 2022-06-24 03:27:52.657737
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    from sanic.blueprints import Blueprint, BlueprintGroup

    bp1 = Blueprint("Blueprint - 1", url_prefix="/bp1")
    bp2 = Blueprint("Blueprint - 2", url_prefix="/bp2")
    bp3 = Blueprint("Blueprint - 3", url_prefix="/bp3")
    bp4 = Blueprint("Blueprint - 4", url_prefix="/bp4")

    bpg = BlueprintGroup("/api", version="v1")

    bpg.insert(1, bp1)
    bpg.insert(2, bp2)

    assert bpg.blueprints == [bp1, bp2]

    bpg.insert(0, bp3)
    assert bpg.blueprints == [bp3, bp1, bp2]

    bpg.insert(3, bp4)


# Generated at 2022-06-24 03:27:59.256034
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    group = BlueprintGroup(url_prefix="/api", version="v1")

    group[0] = bp1
    group[1] = bp2

    assert len(group._blueprints) == 2
    assert group._blueprints[0] is bp1
    assert group._blueprints[1] is bp2


# Generated at 2022-06-24 03:28:09.728595
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    from sanic.blueprints import Blueprint
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix='/api')
    bpg.append(bp1)
    bpg.append(bp2)
    assert bpg[0] == bp1
    assert bpg[1] == bp2


# Generated at 2022-06-24 03:28:19.623426
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint("bp1", url_prefix = "/bp1")
    bp2 = Blueprint("bp2", url_prefix = "/bp2")
    bpg = BlueprintGroup(url_prefix = "/api", version = "v1")
    bpg.insert(0, bp1)
    bpg.insert(1, bp2)
    assert(isinstance(bpg, BlueprintGroup))
    assert (bp1.url_prefix == "/api/bp1")
    assert (bp2.url_prefix == "/api/bp2")
    assert (bp1.version == "v1")
    assert (bp2.version == "v1")


# Generated at 2022-06-24 03:28:24.809460
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    assert bpg.url_prefix == '/api'
    assert bpg.version == "v1"



# Generated at 2022-06-24 03:28:36.185448
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    # BlueprintGroup.insert
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup()

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)


# Generated at 2022-06-24 03:28:41.303994
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2)
    assert len(bpg) == 2
    assert len(BlueprintGroup()) == 0


# Generated at 2022-06-24 03:28:49.173634
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp3 = Blueprint('bp3', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg[0] = bp1
    bpg[1] = bp2

    assert len(bpg) == 2
    assert bpg[0] == bp1
    assert bpg[1] == bp2

# Generated at 2022-06-24 03:28:58.656824
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class MyMiddleware:
        pass

    class MyMiddleware2:
        pass

    bp = Blueprint("test", url_prefix="/test")
    bp2 = Blueprint("test2", url_prefix="/test2")

    # make bp be middleware using BlueprintGroup
    bp_group = BlueprintGroup()
    bp_group.append(bp)
    bp_group.append(bp2)

    @bp_group.middleware("request")
    def test_middleware(request):
        pass

    @bp_group.middleware
    def test_middleware_2(request):
        pass

    @bp_group.middleware("request")
    def test_middleware_3(request):
        pass

    assert len(bp.middlewares["request"]) == 2

# Generated at 2022-06-24 03:29:10.016043
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    print("test_BlueprintGroup")
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp1')
    bp4 = Blueprint('bp4', url_prefix='/bp2')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/')
    async def bp2_route(request):
        return text('bp2')


# Generated at 2022-06-24 03:29:16.114684
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bg = BlueprintGroup()
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bp3 = Blueprint("bp3")
    bg.append(bp1)
    bg.append(bp2)
    bg.append(bp3)
    assert len(bg) == 3

# Generated at 2022-06-24 03:29:25.632219
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-24 03:29:29.706872
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    class blueprint(sanic.Blueprint):
        pass

    bp = blueprint('bp', url_prefix='/bp')

    bpg = BlueprintGroup(url_prefix='/bpg')
    bpg.append(bp)
    assert bpg[0] == bp



# Generated at 2022-06-24 03:29:35.652936
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bpG = BlueprintGroup()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpG.append(bp1)
    bpG.append(bp2)
    for i, bp in enumerate(bpG):
        assert bpG._blueprints[i] == bp


# Generated at 2022-06-24 03:29:41.900505
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bpg = BlueprintGroup("/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)

    # Confirm the actual results
    assert "bp1" in [bp.name for bp in bpg]
    assert "bp2" in [bp.name for bp in bpg]


# Generated at 2022-06-24 03:29:48.874746
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    @sanic.response.json()
    async def new_handler(request, *args, **kwargs):
        return {"b1": {"new_handler": "new_handler"}}

    bp1 = sanic.Blueprint("bp1")
    bp2 = sanic.Blueprint("bp2")
    bp1.add_route(new_handler, "/new-handler")

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bpg) == 2
    assert bpg[0].name == "bp1"
    assert bpg[1].name == "bp2"

    assert bpg[-1].name == "bp2"

    # Iterate over the individual elements in the Blueprint Group

# Generated at 2022-06-24 03:29:52.173260
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group = BlueprintGroup()
    blueprint = Blueprint('bp1', url_prefix='/bp1')
    blueprint_group[0] = blueprint
    assert blueprint == blueprint_group[0]


# Generated at 2022-06-24 03:29:58.411410
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    bpg = BlueprintGroup(bp1, bp2, url_prefix="/heads")

    del bpg[0]

    assert len(bpg) == 1
    assert bpg.blueprints[0] == bp2


# Generated at 2022-06-24 03:30:06.743503
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @sanic.blueprint.Blueprint.middleware('request')
    async def group_middleware(request):
        pass

    bp = sanic.blueprint.Blueprint('test', url_prefix='test')

    @bp.middleware('request')
    async def bp_middleware(request):
        pass

    assert bp.middlewares['request'] == [bp_middleware, group_middleware]

    bpg = BlueprintGroup(url_prefix='/api/v1')
    bpg.append(bp)
    assert bp.middlewares['request'] == [bp_middleware, group_middleware]

# Generated at 2022-06-24 03:30:11.284442
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bpg = BlueprintGroup()
    bpg.append(Blueprint(name="bp1"))
    new_blueprint = Blueprint(name="bp2")
    bpg.insert(0, new_blueprint)
    assert len(bpg._blueprints) == 2
    assert bpg._blueprints[0] == new_blueprint



# Generated at 2022-06-24 03:30:16.335068
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp = BlueprintGroup()
    bp.insert(0, bp1)
    bp.insert(0, bp2)
    assert bp[0].name == 'bp2'
    assert bp[1].name == 'bp1'


# Generated at 2022-06-24 03:30:19.376156
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    BlueprintGroup._blueprints.append(Blueprint)
    BlueprintGroup.__setitem__(BlueprintGroup, 0, Blueprint)
    assert BlueprintGroup._blueprints[0] == Blueprint


# Generated at 2022-06-24 03:30:29.934553
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')

    bpg = BlueprintGroup(bp3, bp4, bp5, bp6, url_prefix="/api", version="v1")



    @bp1.middleware('response')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')


# Generated at 2022-06-24 03:30:40.302754
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')

    bpg = BlueprintGroup(url_prefix="/api")

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    @bp3.route('/')
    async def bp3_route(request):
        return text('bp3')

    bpg.append(bp1)
    bpg.append(bp2)

    bpg.insert(0, bp3)

   

# Generated at 2022-06-24 03:30:50.244181
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint(name="bp1")
    bp2 = Blueprint(name="bp2")
    bp3 = Blueprint(name="bp3")
    bp4 = Blueprint(name="bp4")
    bp5 = Blueprint(name="bp5")
    bp6 = Blueprint(name="bp6")

    bpg = BlueprintGroup(url_prefix="somePrefix")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    bpg.append(bp5)
    bpg.append(bp6)

    assert len(bpg) == 6

    del bpg[0]
    assert len(bpg) == 5
    assert bpg._blueprints[0] == bp2


# Generated at 2022-06-24 03:30:54.396502
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bpn1 = Blueprint(url_prefix='/bp1')
    bpg = BlueprintGroup('/group1')
    bpg.append(bpn1)
    del bpg[0]
    assert len(bpg) == 0


# Generated at 2022-06-24 03:31:05.267608
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()
    test_bp = Blueprint("test_bp", url_prefix="/test")
    test_bp.middleware(test_bp_middleware_function)

    @test_bp.middleware
    def test_bp_recursive_middleware(request):
        pass

    @test_bp.middleware('request')
    def test_bp_recursive_middleware_1(request):
        pass

    @test_bp.middleware('request')
    def test_bp_recursive_middleware_2(request):
        pass

    @test_bp.middleware('request')
    def test_bp_recursive_middleware_3(request):
        pass


# Generated at 2022-06-24 03:31:10.918362
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    group = BlueprintGroup(url_prefix="/api", version="v1")
    print(group.url_prefix)
    print(group.blueprints)
    print(group.version)
    assert group.url_prefix == "/api"
    assert group.blueprints == []
    assert group.version == "v1"


# Generated at 2022-06-24 03:31:20.051073
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg._blueprints) == 2

    bpg[0] = bp3
    assert bpg._blueprints[0] == bp3

    bpg[1] = bp4
    assert bpg._blueprints[1] == bp4


# Generated at 2022-06-24 03:31:29.816515
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")

    bpg = BlueprintGroup(bp3, url_prefix="/api", version="v1")

    @bp1.middleware("request")
    async def bp1_middleware(request):
        pass

    @bp2.middleware("request")
    async def bp2_middleware(request):
        pass

    @bpg.middleware("request")
    async def bpg_middleware(request):
        pass

    assert hasattr(bp1, "middleware")
    assert hasattr(bp2, "middleware")
    assert hasattr(bp3, "middleware")


# Generated at 2022-06-24 03:31:37.432979
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup()
    # Append a blueprint in the blueprint-group
    bpg.append(bp1)
    assert len(bpg.blueprints) == 1
    assert isinstance(bpg.blueprints[0], Blueprint)
    assert bp1 == bpg.blueprints[0]
    assert bpg.blueprints[0].name == "bp1"
    assert bpg.blueprints[0].url_prefix == "/bp1"
    # Insert a blueprint at index 1 in the blueprint-group

# Generated at 2022-06-24 03:31:47.800226
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    """
    Test Method for `BlueprintGroup.insert`
    """
    bp1 = Blueprint("bp1", url_prefix="/bp1", version="v1")
    bp2 = Blueprint("bp2", url_prefix="/bp2", version="v1")
    bp3 = Blueprint("bp3", url_prefix="/bp3", version="v1")
    bp4 = Blueprint("bp4", url_prefix="/bp4", version="v1")

    bp5 = Blueprint("bp5", url_prefix="/bp5", version="v2", strict_slashes=True)
    bp6 = Blueprint("bp6", url_prefix="/bp6", version="v2", strict_slashes=True)

    bpg = BlueprintGroup(url_prefix="/api", version="v2", strict_slashes=True)

    bpg

# Generated at 2022-06-24 03:31:58.138110
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    # Initialize the server
    app = sanic.Sanic('Test BlueprintGroup')
    app.config.KEEP_ALIVE = False
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp1', url_prefix='/bp2')
    bp3 = Blueprint('bp1', url_prefix='/bp3')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)

    assert next(iter(bpg)) == bp1
    assert next(iter(bpg)) == bp2
    assert next(iter(bpg)) == bp3



# Generated at 2022-06-24 03:32:06.355218
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    from sanic import Blueprint, Sanic
    bp = Blueprint(__name__, url_prefix="/api")
    bp1 = Blueprint(__name__ + "1", url_prefix="/api/v1")
    bp2 = Blueprint(__name__ + "2", url_prefix="/api/v2")
    app = Sanic(__name__)
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg[0] = bp
    assert bpg.blueprints[0] == bp



# Generated at 2022-06-24 03:32:09.197716
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = Blueprint.group(bp1, bp2)
    assert bp1 in bpg
    del bpg[0]
    assert bp1 not in bpg
    assert bp2 in bpg
    del bpg[0]
    assert bp2 not in bpg


# Generated at 2022-06-24 03:32:20.333756
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic(__name__)
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)

    @bp1.middleware('request')
    def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    def bp2_route(request, param):
        return text(param)


# Generated at 2022-06-24 03:32:29.787523
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2)

    @bpg.middleware
    async def bpg_middleware(request):
        assert request.get('bpg', False) is True

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        assert request.get('bp1', False) is True

    @bp2.middleware('request')
    async def bp2_only_middleware(request):
        assert request.get('bp2', False) is True

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-24 03:32:41.093245
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1, bp2 = sanic.Blueprint("bp1", url_prefix="/bp1"), sanic.Blueprint("bp2", url_prefix="/bp2")
    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)
    bpg.append(bp1)

    test = BlueprintGroup(url_prefix="/api", version="v1")

    test.append(bp1)
    test.append(bp2)

    bpg[0] = bp2

    # Testing the updated value
    assert bpg[0].name == bp2.name

    # Since we are only updating the value of index, there should be
    # only one change in the length of the container
    assert len(test) == 2 and len(bpg) == 2

# Unit test

# Generated at 2022-06-24 03:32:49.598309
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    """
    Unit test for method __setitem__ of class BlueprintGroup
    """
    # Create a BlueprintGroup object
    bpg = BlueprintGroup()
    # Create a Blueprint object and add it to the 'bpg'
    bp = sanic.Blueprint("bp")
    bpg.append(bp)
    bpg[0].url_prefix = "/api/v1"
    # Assert if the url_prefix is correctly set for the Blueprint object
    assert len(bpg) == 1 and bpg[0].url_prefix == "/api/v1"


# Generated at 2022-06-24 03:32:56.377877
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    # Test 1 : Test empty Blueprint Group
    bpg = BlueprintGroup()
    assert len(bpg) == 0

    # Test 2: Test Blueprint Group with one Blueprint
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bpg = BlueprintGroup()
    bpg.append(bp1)
    assert len(bpg) == 1

    # Test 3: Test Blueprint Group with multiple Blueprints
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bpg.append(bp2)
    bpg.append(bp3)
    assert len(bpg) == 3



# Generated at 2022-06-24 03:33:02.503619
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    assert BlueprintGroup()
    assert BlueprintGroup().url_prefix is None
    assert BlueprintGroup().version is None
    assert BlueprintGroup().strict_slashes is None
    assert BlueprintGroup(url_prefix='/api', version="v1").url_prefix == '/api'
    assert BlueprintGroup(url_prefix='/api', version="v1").version == 'v1'
    assert BlueprintGroup(url_prefix='/api', version="v1").strict_slashes is None
    assert BlueprintGroup(url_prefix='/api', strict_slashes=False).url_prefix == '/api'
    assert BlueprintGroup(url_prefix='/api', strict_slashes=False).strict_slashes is False

# Generated at 2022-06-24 03:33:05.387580
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bg = BlueprintGroup(url_prefix="/api", version="v1")
    assert bg.url_prefix is not None
    assert bg.version is not None
    assert bg.strict_slashes is None
    assert len(bg) == 0



# Generated at 2022-06-24 03:33:11.379411
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    assert len(bpg) == 0
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg.append(bp1)
    assert len(bpg) == 1
    bpg.append(bp2)
    assert len(bpg) == 2

# Generated at 2022-06-24 03:33:14.225479
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    # Given
    blueprint_group = BlueprintGroup()
    blueprint = Blueprint('bp1', url_prefix='/bp1')

    # When
    blueprint_group[0] = blueprint

    # Then
    assert blueprint_group[0] == blueprint


# Generated at 2022-06-24 03:33:21.442905
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    # Test without any parameter
    bpg = BlueprintGroup()
    assert isinstance(bpg, BlueprintGroup)
    assert not bpg.url_prefix
    assert not bpg.version
    assert not bpg.strict_slashes

    # Test with URL Prefix and Version
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    assert isinstance(bpg, BlueprintGroup)
    assert bpg.url_prefix == "/api"
    assert bpg.version == "v1"
    assert not bpg.strict_slashes

    # Test with all arguments
    bpg = BlueprintGroup(url_prefix="/api", version="v1", strict_slashes=True)
    assert isinstance(bpg, BlueprintGroup)
    assert bpg.url_prefix == "/api"
    assert bpg.version

# Generated at 2022-06-24 03:33:31.964117
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    assert isinstance(BlueprintGroup(), BlueprintGroup)
    assert isinstance(BlueprintGroup(url_prefix='/api'), BlueprintGroup)
    assert isinstance(BlueprintGroup(version='v1'), BlueprintGroup)
    assert isinstance(BlueprintGroup(strict_slashes=True), BlueprintGroup)
    assert isinstance(
        BlueprintGroup(url_prefix='/api', version='v1'), BlueprintGroup
    )

# Unit test to verify the append behavior
async def test_BlueprintGroup_append():
    bp = Blueprint("bp", url_prefix="/bp")
    bpg = BlueprintGroup()
    bpg.append(bp)
    assert len(bpg._blueprints) == 1

# Unit test to verify the insert behavior

# Generated at 2022-06-24 03:33:38.129806
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    app = sanic.Sanic("test_BlueprintGroup")
    bp1 = Blueprint("bp1", url_prefix="/bp1", version="v1")
    bp2 = Blueprint("bp2", url_prefix="/bp2", version="v2")
    bpgA = BlueprintGroup("bpgA", url_prefix="/bpgA", version="v3")
    bpgA.append(bp1)
    bpgA.append(bp2)
    bpgA[0] = bp1
    assert bpgA[0] == bp1


# Generated at 2022-06-24 03:33:45.363850
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp_group = BlueprintGroup('/api', version='v1')
    bp_group.append(bp1)
    bp_group.append(bp2)
    bp_group.append(bp3)
    bp_group.append(bp4)
    assert len(bp_group) == 4
    del bp_group[1]
    assert len(bp_group) == 3
    assert bp_group._blueprints[1] == bp4


# Generated at 2022-06-24 03:33:48.728525
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    _bp1 = Blueprint("test-bp1")
    _bp2 = Blueprint("test-bp2")
    bpg = BlueprintGroup("test-bp-group").append(_bp1)
    bpg.__setitem__(0, _bp2)



# Generated at 2022-06-24 03:33:53.604497
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = BlueprintGroup()
    assert len(group) == 0

    group.append(bp1)
    assert len(group) == 1

    group.append(bp2)
    assert len(group) == 2


# Generated at 2022-06-24 03:34:01.205333
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint("bp1", url_prefix="/bp1", strict_slashes=True, version="1.0")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")

    bpg = BlueprintGroup("/api/v1/", version="1.0")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    bp = bpg[0]
    assert bp.url_prefix == "/api/v1/bp1"
    assert bp.version == "1.0"

# Generated at 2022-06-24 03:34:07.634856
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup('/api', 'v1')
    bpg.append(bp3)
    bpg.append(bp4)

    assert bpg[0] == bp3
    assert bpg[1] == bp4


# Generated at 2022-06-24 03:34:18.392174
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprints = [Blueprint("bp1", url_prefix="/bp1"), Blueprint("bp2", url_prefix="/bp2")]
    blueprint_group = BlueprintGroup(url_prefix="/bp-grop")
    blueprint_group.extend(blueprints)

    @blueprint_group.middleware("request")
    def bp_group_middleware(request):
        print("Request Middleware applied across all the blueprints in the group")

    _bp1_middleware = blueprints[0].middlewares["request"][0]
    _bp2_middleware = blueprints[1].middlewares["request"][0]

    assert _bp1_middleware == _bp2_middleware
    assert _bp1_middleware == bp_group_middleware



# Generated at 2022-06-24 03:34:23.358167
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert list(bpg) == [bp1, bp2]


# Generated at 2022-06-24 03:34:29.397849
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    assert bp1 == bpg[0]
    assert bp2 == bpg[1]


# Generated at 2022-06-24 03:34:36.790026
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(bp1, bp2)

    assert bpg.url_prefix is None
    assert bpg.version is None
    assert bpg.strict_slashes is None

    assert len(bpg) is 2
    assert bpg[0] is bp1
    assert bpg[1] is bp2



# Generated at 2022-06-24 03:34:42.684318
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    # sample blueprint group definition
    bp1 = Blueprint(__name__, url_prefix="/api/blueprint_1")
    bp2 = Blueprint(__name__, url_prefix="/api/blueprint_2")
    bpg1 = BlueprintGroup(bp1, bp2)

    # ensure that the blueprint is iterable using __iter__
    assert bpg1 is iter(bpg1)


# Generated at 2022-06-24 03:34:53.467741
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    """
    Test Blueprint Group Object
    """
    assert issubclass(BlueprintGroup, MutableSequence)
    # Construct object of `BlueprintGroup`
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bpg = BlueprintGroup(bp1, bp2)

    assert bpg.url_prefix is None
    assert bpg.version is None
    assert bpg.strict_slashes is None

    assert len(bpg) == 2
    assert bpg[0] == bp1
    assert bpg[-1] == bp2
    assert bp1 in bpg
    assert bp2 not in bpg
    assert bpg.index(bp1) == 0
