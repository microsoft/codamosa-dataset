

# Generated at 2022-06-24 03:24:57.268267
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    group = BlueprintGroup()
    group.append(sanic.Blueprint('a', url_prefix='/a'))
    group.append(sanic.Blueprint('b', url_prefix='/b'))
    group.append(sanic.Blueprint('c', url_prefix='/c'))

    for idx, bp in enumerate(group):
        assert bp.name == chr(ord('a') + idx)


# Generated at 2022-06-24 03:25:06.502154
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    # group = Blueprint.group(bp1, bp2)

    bpg = BlueprintGroup(url_prefix="/api")
    bpg.append(bp1)
    bpg.append(bp2)

    assert type(bpg[0]) == Blueprint
    assert type(bpg[1]) == Blueprint

    assert bpg[0].url_prefix == '/bp1'
    assert bpg[1].url_prefix == '/bp2'



# Generated at 2022-06-24 03:25:13.674574
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    assert bp1.name == 'bp1'
    assert bp2.name == 'bp2'
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg) == 2
    del bpg[0]
    assert bpg[0].name == 'bp2'
    assert len(bpg) == 1
    del bpg[0]
    assert len(bpg) == 0

# Generated at 2022-06-24 03:25:20.848264
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    @sanic.blueprint.group('/test_group', url_prefix='test_url_prefix')
    def test_group(bp):
        pass

    @test_group.route('/test_path', methods=['GET'], strict_slashes=True)
    async def test_path(request):
        return text('test_path')

    bp = test_group(sanic.Blueprint('bp', url_prefix='/bp'))

    assert bp._blueprints == [bp]
    assert bp[0] == bp
    assert list(iter(bp)) == [bp]
    assert list(bp) == [bp]


# Generated at 2022-06-24 03:25:27.487672
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    async def async_foo():
        pass

    blueprint = sanic.Blueprint('foo')
    bp_group = BlueprintGroup()
    bp_group.append(blueprint)

    @bp_group.middleware('request')
    def foo(request):
        pass

    assert blueprint.request_middleware == [foo]

    @bp_group.middleware('request')
    async def async_foo(request):
        pass

    assert blueprint.request_middleware == [foo, async_foo]

    bp_group.middleware(foo, 'request')
    assert blueprint.request_middleware == [foo, async_foo, foo]


# Generated at 2022-06-24 03:25:33.417357
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2)
    assert len(bpg)==2
    assert bpg._blueprints[0]==bp1
    assert bpg._blueprints[1]==bp2




# Generated at 2022-06-24 03:25:42.670096
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    from sanic import Sanic
    from sanic import Blueprint
    from sanic.views import HTTPMethodView
    app = Sanic("sanic-server")

    bp1 = Blueprint("bp_test_1", url_prefix="/test_1")
    bp1.group_version = "v1"

    class TestView(HTTPMethodView):
        # pylint: disable=no-self-use
        def get(self, request):
            return text("OK")

    bp1.add_route(TestView.as_view(), "test")
    bpg = BlueprintGroup(url_prefix="/bpg1", version="v1")
    bp2 = Blueprint("bp_test_2", url_prefix="/test_2")
    bp2.group_version = "v2"
    b

# Generated at 2022-06-24 03:25:52.572437
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app=sanic.Sanic("test_BlueprintGroup_middleware")
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    class TestMiddleware:
        def __init__(self, bp):
            self.bp = bp

        async def __call__(self, request):
            return text("pass")

    # Test normal middleware

# Generated at 2022-06-24 03:26:00.621217
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic(__name__)

    blueprint_group = BlueprintGroup(url_prefix="/api/v1")
    blueprint_group.append(sanic.Blueprint("test_blueprint", url_prefix="/test"))

    @blueprint_group.middleware("request")
    async def test_middleware(request):
        return text("Middleware executed")

    app.blueprint(blueprint_group)
    request, response = app.test_client.get("/api/v1/test")
    assert response.text == "Middleware executed"



# Generated at 2022-06-24 03:26:11.428444
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    assert bp1.url_prefix == "/bp1"
    assert bp2.url_prefix == "/bp2"

    bp_g = BlueprintGroup("/api", version="v1", strict_slashes=False)
    assert bp_g.url_prefix == "/api"
    assert bp_g.version == "v1"
    assert bp_g.strict_slashes is False
    assert bp_g.blueprints == []

    bp_g[0] = bp2
    assert bp_g.url_prefix == "/api"
    assert bp_g.version == "v1"
    assert bp_g.strict_

# Generated at 2022-06-24 03:26:20.509809
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    """
    Test the blueprint group append operation
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bp1.append(bp2)
    bp1.append(bp2)
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg) == 4
    assert bpg[0].url_prefix == "/api/bp1"
    assert bpg[2] == bp2

# Generated at 2022-06-24 03:26:28.851875
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    
    assert isinstance(bp1, Blueprint)
    assert isinstance(bp2, Blueprint)
    bpg = BlueprintGroup('/api', 'v1')
    
    
    bpg.__setitem__(0, bp1)
    bpg.__setitem__(1, bp2)
    
    assert bpg.__getitem__(0) == bp1
    assert bpg.__getitem__(1) == bp2
    

# Generated at 2022-06-24 03:26:33.402374
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bpg = BlueprintGroup()
    bpg.append("bp1")
    bpg.append("bp2")
    del bpg[1]
    del bpg[0]
    assert len(bpg) == 0


# Generated at 2022-06-24 03:26:34.790613
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bpg = BlueprintGroup()
    assert bpg is not None



# Generated at 2022-06-24 03:26:41.786553
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    app = sanic.Sanic(__name__)
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg[0] = bp1
    bpg[1] = bp2
    assert bpg[0] == bp1
    assert bpg[1] == bp2


# Generated at 2022-06-24 03:26:52.738097
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Test if Blueprint.middleware works as expected.

    - Should register the Blueprint.middleware on the Blueprint recursively.
    """
    app = sanic.Sanic(__name__)

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bb4')

    bp5 = Blueprint('bp5', url_prefix='/bp5')

    grp = BlueprintGroup()
    grp.append(bp1)
    grp.append(bp2)

    bpg = BlueprintGroup(version=1, url_prefix='/api')

# Generated at 2022-06-24 03:27:02.974996
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')

    bp3 = sanic.Blueprint('bp3', url_prefix='/bp4')
    bp4 = sanic.Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-24 03:27:08.466326
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    # Assert the property of the Blueprint group
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    assert bpg
    assert bpg.url_prefix == "/api"
    assert bpg.version == "v1"



# Generated at 2022-06-24 03:27:11.314676
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bpg = BlueprintGroup(url_prefix='/api', version='v1')
    assert bpg.url_prefix == '/api'
    assert bpg.version == 'v1'


# Generated at 2022-06-24 03:27:14.731018
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    del bpg[0]



# Generated at 2022-06-24 03:27:21.182490
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    url_prefix = "/api/v1"
    bp1 = sanic.Blueprint('bp1', url_prefix=url_prefix)
    bp2 = sanic.Blueprint('bp2', url_prefix=url_prefix)

    bpg = BlueprintGroup(url_prefix=url_prefix)
    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bpg) == 2


# Generated at 2022-06-24 03:27:26.245285
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    from sanic.blueprints import Blueprint

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')

    bp_group = BlueprintGroup()
    bp_group.append(bp1)
    bp_group.append(bp2)
    bp_group.append(bp3)

    assert bp1 is bp_group[0]
    assert bp2 is bp_group[1]
    assert bp3 is bp_group[2]
# end of __getitem__ unit test



# Generated at 2022-06-24 03:27:36.587273
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    app = sanic.Sanic(__name__)
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    
    class bpg(BlueprintGroup):
        def __init__(self, *args, **kwargs):
            super(bpg, self).__init__(*args, **kwargs)
            
    bpg = bpg()
    bpg.append(bp1)
    bpg.append(bp2)
    
    @bpg.middleware('request')
    def middleware(request):
        pass
        
    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        pass
    

# Generated at 2022-06-24 03:27:43.240478
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')

    bp3 = sanic.Blueprint('bp3', url_prefix='/bp1')
    bp4 = sanic.Blueprint('bp4', url_prefix='/bp2')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    assert bpg[0] == bp3
    assert bpg[1] == bp4


# Generated at 2022-06-24 03:27:48.439591
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp_list = [bp1, bp2]
    bpg = BlueprintGroup()
    bpg._blueprints = bp_list
    assert bp_list == list(bpg)


# Generated at 2022-06-24 03:27:54.462627
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bpg1 = BlueprintGroup()
    bpg2 = BlueprintGroup(url_prefix="/api", version="v1", strict_slashes=True)
    assert isinstance(bpg1, BlueprintGroup)
    assert isinstance(bpg2, BlueprintGroup)
    assert bpg2._url_prefix == "/api"
    assert bpg2._version == "v1"
    assert bpg2._strict_slashes is True


# Generated at 2022-06-24 03:27:57.204155
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bpg = BlueprintGroup('bp3')

    bpg[0] = bp1

    assert bp1 == bpg[0]


# Generated at 2022-06-24 03:28:07.391913
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()

    bp1 = Blueprint('bp1', url_prefix='bp1')

    @bp1.middleware('request')
    async def bp1_middleware_1(request):
        print('applied on Blueprint : bp1')

    bp2 = Blueprint('bp2', url_prefix='bp2')

    @bp2.middleware('request')
    async def bp1_middleware_2(request):
        print('applied on Blueprint : bp2')

    bpg = BlueprintGroup(bp1, bp2, url_prefix='bpg')

    @bpg.middleware('request')
    async def bpg_middleware(request):
        print('applied on Blueprint Group')

    app.blueprint(bpg)


# Generated at 2022-06-24 03:28:16.484946
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic.app import Sanic

    # Create an Sanic application
    app = Sanic('test_BlueprintGroup_middleware')

    # Create a Group of Blueprints
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2)

    @group.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    # Register Blueprint group under the app
    app.blueprint(group)

    assert bp1.middleware_stack.get('request') == [group_middleware]
    assert bp2.middleware_stack.get('request') == [group_middleware]



# Generated at 2022-06-24 03:28:23.456551
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    """
    Test the function append of class Blueprint Group
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    assert len(bpg) == 0
    bpg.append(bp1)
    assert len(bpg) == 1
    bpg.append(bp2)
    assert len(bpg) == 2
    assert len(bpg.blueprints) == 2
    assert bpg.blueprints == [bp1, bp2]


# Generated at 2022-06-24 03:28:32.090592
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2, url_prefix='/api', version='v1')
    assert group.url_prefix == '/api'
    assert group.version == 'v1'
    assert len(group._blueprints) == 2

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')

    bpg = BlueprintGroup(bp3, bp4, url_prefix='/api', version='v1')
    bpg.append(bp5)


# Generated at 2022-06-24 03:28:40.188698
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # type: () -> None
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')

    bp3 = sanic.Blueprint('bp3', url_prefix='/bp1')
    bp4 = sanic.Blueprint('bp4', url_prefix='/bp2')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-24 03:28:49.958737
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    assert len(bpg) == 4
    bpg.append(bp5)
    bpg.insert(0,bp5)
    assert len(bpg) == 6


# Generated at 2022-06-24 03:28:52.829169
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    BlueprintGroup.__init__(url_prefix=None, version=None, strict_slashes=None)
    BlueprintGroup.__delitem__(index)


# Generated at 2022-06-24 03:28:58.598710
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    assert len(bpg) == 0

    bpg.append(bp1)
    assert len(bpg) == 1
    assert bpg[0] == bp1

    bpg.append(bp2)
    assert len(bpg) == 2
    assert bpg[1] == bp2

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bpg.append(bp3)
    assert len(bpg) == 3
    assert bpg[2] == bp3


# Generated at 2022-06-24 03:29:07.812089
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    new_bp = Blueprint("test", url_prefix="/test")
    bpg = BlueprintGroup(url_prefix="/test_group")

    bpg.append(new_bp)
    assert bpg[0].name == "test"
    assert bpg[0].url_prefix == "/test_group/test"

    new_bp = Blueprint("test2", url_prefix="/test2")
    new_bp = Blueprint("test2", url_prefix="/test2")

    bpg[0] = new_bp
    assert bpg[0].name == "test2"
    assert bpg[0].url_prefix == "/test_group/test2"

# Generated at 2022-06-24 03:29:19.193524
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic('test_BlueprintGroup_middleware')
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2)

    @bp1.route('/bp1')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/bp2')
    async def bp2_route(request):
        return text('bp2')


# Generated at 2022-06-24 03:29:24.413203
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')

    group = BlueprintGroup()

    group.append(bp1)
    group.append(bp2)
    group.append(bp3)
    for temp_bp in group:
        assert isinstance(temp_bp, Blueprint)


# Generated at 2022-06-24 03:29:35.600429
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1', version="v1.0", strict_slashes=False)
    bpg = BlueprintGroup(url_prefix='/bpg1', version="v2.0", strict_slashes=True)

    bpg.append(bp1)

    assert bp1.url_prefix == "/bpg1/bp1"
    assert bp1.version == "v2.0"
    assert bp1.strict_slashes is True

    bp1.url_prefix = "/bp1"
    bp1.strict_slashes = False
    bp1.version = "v1.0"
    bpg.append(bp1)

    assert bp1.url_prefix == "/bpg1/bp1"
    assert bp1.version

# Generated at 2022-06-24 03:29:39.820302
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bg = BlueprintGroup()
    bp = Blueprint('bp')
    bg.append(bp)
    bp_mock = MagicMock()
    bg[0] = bp_mock
    assert bg[0] == bp_mock


# Generated at 2022-06-24 03:29:47.072547
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint("bp1", "/bp1/")
    bp2 = Blueprint("bp2", "/bp2/")
    bp3 = Blueprint("bp3", "/bp3/")

    bpg = BlueprintGroup("/bpg/")

    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)

    assert bp1 in bpg
    assert bp2 in bpg
    assert bp3 in bpg
    assert len(bpg) == 3



# Generated at 2022-06-24 03:29:50.392296
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bpg = BlueprintGroup()
    bpg.__setitem__(0, Blueprint('bp1', 'bp1'))
    assert(len(bpg) is 1)
    assert(bpg[0].name == 'bp1')
    assert(bpg[0].url_prefix == 'bp1')



# Generated at 2022-06-24 03:30:00.768021
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix='/bpg', version='v1', strict_slashes=True)

    assert bpg.blueprints == []
    assert bpg.url_prefix == '/bpg'
    assert bpg.version == 'v1'
    assert bpg.strict_slashes == True

    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg.blueprints == [bp1, bp2]

    # TODO: Add more unit test cases to cover all the code cases

# Generated at 2022-06-24 03:30:11.872916
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    # Test the Constructor without prefix
    bpg = BlueprintGroup(bp1, bp2, url_prefix='/api', version="V1")
    assert bpg._url_prefix == "/api"
    assert bpg._version == "V1"
    assert len(bpg._blueprints) == 2
    assert bpg._blueprints[0].url_prefix == '/bp1'
    assert bpg._blueprints[1].url_prefix == '/bp2'
    assert bpg._blueprints[0].version == "V1"
    assert bpg._blueprints[1].version == "V1"


# Generated at 2022-06-24 03:30:17.884918
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('test', url_prefix='/bp1')
    bp2 = Blueprint('test1', url_prefix='/bp2')
    bp3 = Blueprint('test2', url_prefix='/bp3')
    bpg = BlueprintGroup(url_prefix = '/api', version = 1)
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg[0] = bpg
    assert bpg[0] == bpg


# Generated at 2022-06-24 03:30:26.019767
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Unit test for method `middleware` of class `BlueprintGroup`
    """
    # Unit test for method middleware of class BlueprintGroup
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/gp1')
    bp4 = Blueprint('bp4', url_prefix='/gp2')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    args_list = [1, 2]
    kwargs_dict = {'some_key': 'some_value'}


# Generated at 2022-06-24 03:30:34.250723
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    test_Blueprint = Blueprint("test_Blueprint")
    test_Blueprint2 = Blueprint("test_Blueprint2")
    test_Blueprint3 = Blueprint("test_Blueprint3")
    test_Blueprint4 = Blueprint("test_Blueprint4")
    test_BlueprintGroup = BlueprintGroup()
    test_BlueprintGroup.append(test_Blueprint)
    test_BlueprintGroup.append(test_Blueprint2)
    test_BlueprintGroup.append(test_Blueprint3)
    test_BlueprintGroup.append(test_Blueprint4)
    del test_BlueprintGroup[1]
    assert test_BlueprintGroup[1] != test_Blueprint2


# Generated at 2022-06-24 03:30:42.299464
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic(__name__)
    group = BlueprintGroup(
        url_prefix="/api", version=1.0, strict_slashes=True
    )  # type: BlueprintGroup

    @group.middleware("request")
    async def test_middleware(request):
        request["route_from_blueprint_group"] = True

    bp1 = Blueprint("bp1", url_prefix="bp1")
    bp2 = Blueprint("bp2", url_prefix="bp2")
    bp_group = Blueprint.group(bp1, bp2)
    app.blueprint(group)
    app.blueprint(bp_group)

    @bp1.route("/")
    async def test_bp1(request):
        assert request["route_from_blueprint_group"] == True


# Generated at 2022-06-24 03:30:46.921507
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2)
    assert len(bpg) == 2
    assert bp1 in bpg
    assert bp2 in bpg
    assert bpg.blueprints == [bp1, bp2]

# Generated at 2022-06-24 03:30:52.754048
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    assert bpg.__iter__() == iter([bp1, bp2, bp3, bp4])



# Generated at 2022-06-24 03:31:03.050360
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @sanic.blueprints.Blueprint.group(url_prefix='/test_middleware')
    class TestBlueprintGroup(sanic.blueprints.BlueprintGroup):
        pass
    @sanic.blueprints.Blueprint.group(url_prefix='/test_middleware')
    class TestBlueprintGroup_1(sanic.blueprints.BlueprintGroup):
        pass
    @sanic.blueprints.Blueprint('/test_middleware')
    class TestBlueprint(sanic.blueprints.Blueprint):
        pass
    @sanic.blueprints.Blueprint('/test_middleware')
    class TestBlueprint_1(sanic.blueprints.Blueprint):
        pass

    assert(len(TestBlueprintGroup) == 0)
    assert(len(TestBlueprintGroup_1) == 0)
   

# Generated at 2022-06-24 03:31:14.712058
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    @bp1.middleware("request")
    @bp2.middleware("request")
    async def test_mw(request):
        request["test_mw"] = True

    bp_group = BlueprintGroup(bp1, bp2)

    # At this point no middleware should be registered with the blueprint
    assert not bp1.registered_middleware
    assert not bp2.registered_middleware

    # Registering middleware to blueprint group
    @bp_group.middleware("request")
    async def mw2(request):
        request["mw2"] = True

    # Now mw2 should be registered for both the Blueprint

# Generated at 2022-06-24 03:31:22.369879
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    for bp in bpg:
        assert isinstance(bp, sanic.blueprints.Blueprint)


# Generated at 2022-06-24 03:31:25.726047
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)
    assert len(group) == 2


# Generated at 2022-06-24 03:31:36.156328
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    app = sanic.Sanic('BlueprintGroup___getitem__')
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    app.blueprint(bpg)
    request, response = app.test_client.get('/api/bp1')
    assert response.text == 'bp1'
    request, response = app.test_client.get

# Generated at 2022-06-24 03:31:36.704688
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    assert True

# Generated at 2022-06-24 03:31:45.709965
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    bpg[2] = bp4
    assert bpg[2].url_prefix == '/bp4'
    assert bpg[3].url_prefix == '/bp3'



# Generated at 2022-06-24 03:31:50.351720
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    # Create a Blank BlueprintGroup Object
    bpg = BlueprintGroup()
    # Length of the created object should be 0
    assert len(bpg) == 0
    # Append a new Blueprint Object to BlueprintGroup
    bpg.append(Blueprint("bp1"))
    # Assert length as 1
    assert len(bpg) == 1


# Generated at 2022-06-24 03:31:58.403408
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp_group = BlueprintGroup(url_prefix='/api', version=2.0, strict_slashes=True)
    bp1 = Blueprint.group(
        Blueprint('api', url_prefix='/v1/bp1'), Blueprint('api', url_prefix='/v1/bp2')
    )
    bp2 = Blueprint.group(
        Blueprint('api', url_prefix='/v2/bp1'), Blueprint('api', url_prefix='/v2/bp2')
    )
    bp_group.append(bp1)
    bp_group.append(bp2)
    assert bp_group.url_prefix == "/api"
    assert bp_group.version == 2.0
    assert bp_group.strict_slashes == True
    assert len(bp_group) == 2
   

# Generated at 2022-06-24 03:32:02.769218
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg[0] == bp1
    assert bpg[1] == bp2


# Generated at 2022-06-24 03:32:08.651068
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix='/api')
    bpg.append(bp1)
    bpg.append(bp2)
    assert bpg._blueprints == [bp1, bp2]


# Generated at 2022-06-24 03:32:14.964830
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @sanic.blueprints.Blueprint.middleware('request')
    async def test_middleware(request):
        print('applied on Blueprint : bp1 Only')

    for blueprint in sanic.blueprints.BlueprintGroup().middleware(test_middleware)(
    ):
        assert blueprint.middlewares['request'][0].handler() == test_middleware

# Generated at 2022-06-24 03:32:20.803985
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint1 = Blueprint("test1")
    blueprint2 = Blueprint("test2")
    blueprint3 = Blueprint("test3")
    blueprint4 = Blueprint("test4")
    blueprint_group = BlueprintGroup()
    blueprint_group.append(blueprint1)
    blueprint_group.append(blueprint2)
    blueprint_group.append(blueprint3)
    blueprint_group.append(blueprint4)
    assert len(blueprint_group.blueprints) == 4
    del blueprint_group[0]
    assert len(blueprint_group.blueprints) == 3
    del blueprint_group[1:]
    assert len(blueprint_group.blueprints) == 1


# Generated at 2022-06-24 03:32:31.112213
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix='/api', version='v1')
    bpg.append(bp1)
    bpg.append(bp2)

    assert isinstance(bpg, MutableSequence)
    assert bpg.url_prefix == '/api'
    assert bpg.version == 'v1'
    assert bpg.strict_slashes is None
    assert bpg[0] == bp1
    assert bpg[1] == bp2

    bpg.insert(0, bp2)
    assert bpg[0] == bp2
    assert bpg[1] == bp1

# Generated at 2022-06-24 03:32:41.783616
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic import Blueprint

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware('request')
    async def middleware(request):
        assert True
        return

    assert isinstance(middleware, functools.partial)

    event_loop = asyncio.get_event_loop()
    sanic_app = sanic.Sanic(__name__)
    sanic_app.blueprint(bpg)
    sanic_app.add_route(middleware, '/')

# Generated at 2022-06-24 03:32:50.710967
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bp3 = sanic.Blueprint('bp3', url_prefix='/bp3')
    bp4 = sanic.Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    blueprints = [bp1, bp2]
    bpg.blueprints = blueprints
    assert list(bpg) == blueprints



# Generated at 2022-06-24 03:32:58.310982
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')
    bp7 = Blueprint('bp7', url_prefix='/bp7')
    bp8 = Blueprint('bp8', url_prefix='/bp8')
    bp9 = Blueprint('bp9', url_prefix='/bp9')
    bp10 = Blueprint('bp10', url_prefix='/bp10')


# Generated at 2022-06-24 03:33:07.683997
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic import Blueprint
    from sanic.router import Router
    from sanic.request import RequestParameters

    # Mock for class Blueprint
    class Blueprint_mock_with_middleware(Blueprint):
        def __init__(self, name, url_prefix=None, version=None, strict_slashes=None):
            self.name = name
            self.url_prefix = url_prefix
            self.version = version
            self.strict_slashes = strict_slashes
            self.middleware_functions = {
                'request': [],
                'response': [],
                'static': [],
            }

        def middleware(self, fn, *args, **kwargs):
            self.middleware_functions['request'].append(fn)

    # Mock for class Router

# Generated at 2022-06-24 03:33:15.078551
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    group = Blueprint.group(bp1, bp2)

    assert len(bpg) == 2
    assert len(group) == 2



# Generated at 2022-06-24 03:33:21.063018
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    
    bpg = BlueprintGroup(bp2, url_prefix="/prefix", version="v1")
    bpg.insert(1, bp1)
    
    assert bpg.blueprints[1].url_prefix == '/bp1'
    assert bpg.blueprints[1].version == "v1"
    assert bpg.blueprints[1].strict_slashes == None



# Generated at 2022-06-24 03:33:25.293642
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    assert len(bpg) == 0
    bpg.append(bp1)
    assert len(bpg) == 1
    bpg.append(bp2)
    assert len(bpg) == 2
    bpg.append(None)
    assert len(bpg) == 3


# Generated at 2022-06-24 03:33:28.411216
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp = Blueprint(None, None)
    bp1 = BlueprintGroup()
    bp1.insert(0, bp)
    assert bp in bp1


# Generated at 2022-06-24 03:33:37.290206
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.extend([bp3, bp4])
    bp_group = BlueprintGroup(url_prefix="/api", version="v1")
    bp_group.extend([bp1, bp2, bpg])
    # Iterate over the group
    for bp in bp_group:
        # Verify each of the Blueprint
        assert isinstance(bp, Blueprint)



# Generated at 2022-06-24 03:33:48.227348
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-24 03:33:53.938156
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bg = BlueprintGroup()
    bp = Blueprint("bp")
    bg.insert(0, bp)
    assert len(bg) == 1
    assert bp.url_prefix == ""
    assert bp.strict_slashes is None
    assert bp.version is None
    assert bg.url_prefix == ""
    assert bg.strict_slashes is None
    assert bg.version is None
    bp = Blueprint("bp", url_prefix="abc")
    bg.insert(1, bp)
    assert len(bg) == 2
    assert bg[1].url_prefix == "abc"
    bp = Blueprint("bp", url_prefix="/abc/")
    bg.insert(0, bp)
    assert len(bg) == 3

# Generated at 2022-06-24 03:33:58.587263
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    app = sanic.Sanic('test_BlueprintGroup___getitem__')
    bp = Blueprint('test_bp',url_prefix = '/test', version = 2)
    bpg = BlueprintGroup([bp], url_prefix="/api", version='v1')
    assert type(bpg[0]) is Blueprint


# Generated at 2022-06-24 03:34:06.293896
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    # arrange
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp2")
    bp4 = Blueprint("bp4", url_prefix="/bp2")
    bp5 = Blueprint("bp5", url_prefix="/bp2")
    bp6 = Blueprint("bp6", url_prefix="/bp2")
    bpg = BlueprintGroup(bp3, bp4, bp5, bp6, url_prefix="/api", version="v1")
    # assert
    assert bpg[0] == bp3
    assert bpg[2] == bp5


# Generated at 2022-06-24 03:34:12.251664
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group = BlueprintGroup()
    blueprint_group.append(Blueprint('bp3', url_prefix='/bp3'))
    blueprint_group.append(Blueprint('bp4', url_prefix='/bp4'))
    blueprint_group[1] = Blueprint('bp1', url_prefix='/bp1')

    assert blueprint_group[1].url_prefix == '/bp1'


# Generated at 2022-06-24 03:34:20.858468
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
	bp1 = Blueprint('bp1', url_prefix='/bp1')
	bp2 = Blueprint('bp2', url_prefix='/bp2')
	bp3 = Blueprint('bp3', url_prefix='/bp3')
	bp4 = Blueprint('bp4', url_prefix='/bp4')
	bpGroup = BlueprintGroup(url_prefix='/blueprint')
	bpGroup.append(bp1)
	bpGroup.append(bp2)
	assert len(bpGroup) == 2


# Generated at 2022-06-24 03:34:24.485423
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    b1 = sanic.Blueprint("test1")
    b2 = sanic.Blueprint("test2")
    bg = BlueprintGroup()
    assert len(bg) == 0
    bg.append(b1)
    assert len(bg) == 1
    bg.append(b2)
    assert len(bg) == 2



# Generated at 2022-06-24 03:34:31.931570
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    # This is an example from the documentation.
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.insert(0, bp3)
    bpg.insert(0, bp4)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')


# Generated at 2022-06-24 03:34:43.489251
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bp3 = Blueprint('bp3')
    bp4 = Blueprint('bp4')
    bp5 = Blueprint('bp5')
    bp6 = Blueprint('bp6')

    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)
    group.append(bp3)

    group.insert(3, bp4)
    assert len(group) == 4
    assert group[3] == bp4

    group.insert(0, bp5)
    assert len(group) == 5
    assert group[0] == bp5

    group.insert(5, bp6)
    assert len(group) == 6
    assert group[5] == bp6


# Unit

# Generated at 2022-06-24 03:34:49.591619
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    result = bpg.__iter__()
    # The result should be a Iterator object
    assert isinstance(result, Iterator)


# Generated at 2022-06-24 03:34:58.215603
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    # Initialize BlueprintGroup Object
    bp_object = BlueprintGroup()

    # Append a Blueprint Object
    bp_object.append(Blueprint('bp1', url_prefix='/bp1'))

    # Call method __getitem__ with index
    bp_object[0]

    # Assert the object type of returned object
    assert bp_object[0] == Blueprint('bp1', url_prefix='/bp1')
    assert len(bp_object) == 1

    # Append a Blueprint Object
    bp_object.append(Blueprint('bp2', url_prefix='/bp2'))
    assert len(bp_object) == 2

    # Call method __getitem__ with index
    bp_object[1]
    # Assert the object type of returned object
    assert bp_object[1]