

# Generated at 2022-06-24 03:25:02.781559
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bp_group = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    blueprintExpected = [bp1,bp2]
    blueprintResult = []

    for blueprint in bp_group:
        blueprintResult.append(blueprint)

    bp_group.remove(bp1)
    blueprintExpected.remove(bp1)

    assert blueprintExpected == blueprintResult


# Generated at 2022-06-24 03:25:12.864643
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')
    bp7 = Blueprint('bp7', url_prefix='/bp7')
    bp8 = Blueprint('bp8', url_prefix='/bp8')
    bp9 = Blueprint('bp9', url_prefix='/bp9')
    bp10 = Blueprint('bp10', url_prefix='/bp10')

# Generated at 2022-06-24 03:25:20.148709
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    assert bpg.url_prefix == "/api"
    assert bpg.version == "v1"

    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg[0] == bp1
    assert bpg[1] == bp2


# Generated at 2022-06-24 03:25:23.146366
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp = Blueprint(__name__)

    bpg = BlueprintGroup(bp=bp)

    del bpg[0]


# Generated at 2022-06-24 03:25:30.937754
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    # Given
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bps = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-24 03:25:40.549289
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    """
    Test method __len__ of class BlueprintGroup
    """
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bp3 = sanic.Blueprint('bp3', url_prefix='/bp3')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    assert bpg.__len__() == 0
    bpg.append(bp1)
    assert bpg.__len__() == 1
    bpg.append(bp2)
    bpg.append(bp3)
    assert bpg.__len__() == 3


# Generated at 2022-06-24 03:25:45.976102
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp_group = BlueprintGroup()
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bp3 = Blueprint('bp3')

    bp_group.insert(0, bp1)
    bp_group.insert(0, bp2)
    bp_group.insert(1, bp3)

    assert bp_group[0] is bp2
    assert bp_group[1] is bp3
    assert bp_group[2] is bp1


# Generated at 2022-06-24 03:25:49.803822
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2)

    assert len(group) == 2


# Generated at 2022-06-24 03:25:59.033436
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    # Create a blueprint Group to perform unit test
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup()
    bpg.append(bp3)
    bpg.append(bp4)
    bpg.append(bp1)
    bpg.append(bp2)
    for bp, expected in zip(bpg, (bp3, bp4, bp1, bp2)):
        assert bp == expected


# Generated at 2022-06-24 03:26:05.618697
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    class BP(sanic.Blueprint):
        pass

    bp1 = BP('bp1', url_prefix='/bp1', strict_slashes=False)
    bp2 = BP('bp2', url_prefix='/bp2', strict_slashes=False)

    bp3 = BP('bp3', url_prefix='/bp3', strict_slashes=False)
    bp4 = BP('bp4', url_prefix='/bp4', strict_slashes=False)

    bp5 = BP('bp5', url_prefix='/bp5', strict_slashes=False)

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.insert(0, bp1)
    bpg.insert(1, bp2)


# Generated at 2022-06-24 03:26:15.780947
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    """
    Function to test that method insert works as expected
    """
    @BlueprintGroup.middleware('request')
    async def middleware(request):
        print('applied on Blueprint : bp1 Only')

    bp1 = Blueprint('bp1', url_prefix='/bp1', version='v1')
    bp2 = Blueprint('bp2', url_prefix='/bp2', version='v1')

    bp3 = Blueprint('bp3', url_prefix='/bp4', version='v1')
    bp4 = Blueprint('bp4', url_prefix='/bp4', version='v1')

    bpg = BlueprintGroup(url_prefix="api", version="v1")
    bpg.insert(0, bp3)
    bpg.insert(0, bp4)


# Generated at 2022-06-24 03:26:21.588998
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    """ Unit test for method insert of class BlueprintGroup
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpgroup = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bpgroup.insert(0, bp3)

    assert bpgroup.blueprints[0] == bp3

# Generated at 2022-06-24 03:26:31.454448
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    # Creating BlueprintGroup Object
    bpg = BlueprintGroup()
    # Checking if __len__ return 0 items
    assert len(bpg) == 0
    # Inserting 3 Blueprints into the Group
    for i in range(3):
        bpg.append(Blueprint(f"bp{i}"))
    # Checking if __len__ return 3 items
    assert len(bpg) == 3
    # Inserting 3 More Blueprints into the Group
    for i in range(3, 6):
        bpg.append(Blueprint(f"bp{i}"))
    # Checking if __len__ return 6 items
    assert len(bpg) == 6
    # Deleting Index 1 item from the Group
    del bpg[1]
    # Checking if __len__ return 5 items
    assert len(bpg) == 5
    # Deleting

# Generated at 2022-06-24 03:26:32.886817
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    assert BlueprintGroup(url_prefix="/api", version=None, strict_slashes=None)


# Generated at 2022-06-24 03:26:40.775432
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp3)
    bpg.append(bp4)

    assert(len(bpg) == 2)
    assert(bp3 in bpg)
    assert(bp4 in bpg)


# Generated at 2022-06-24 03:26:51.778723
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")
    bpg = BlueprintGroup(url_prefix="/group", version="v1", strict_slashes=False)

    bpg.insert(0, bp1)
    bpg.insert(1, bp2)
    bpg.insert(2, bp3)
    bpg.insert(3, bp4)

    i = 0

# Generated at 2022-06-24 03:26:55.112662
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp = BlueprintGroup(url_prefix="/api", version="v1")
    assert len(bp) == 0
    bp.append(sanic.Blueprint("a"))
    assert len(bp) == 1


# Generated at 2022-06-24 03:27:02.570989
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class FakeBlueprint:

        def middleware(self, fn, *args, **kwargs):
            return fn

    bp1 = FakeBlueprint()
    bp2 = FakeBlueprint()

    bpg = BlueprintGroup()
    assert bpg.middleware(lambda x: x) == bpg.middleware(lambda x: x)
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg) == 2

    def fn1(x):
        return x

    fn2 = bpg.middleware(fn1)

    assert fn1 == fn2
    assert bp1.middleware(fn1) == fn1
    assert bp2.middleware(fn1) == fn1



# Generated at 2022-06-24 03:27:13.686544
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    @sanic.exception(sanic.exceptions.NotFound, methods=["GET"])
    async def custom_exception_handler(request, exception):
        return text(str(exception.status_code))

    def _abc(val):
        return val

    bp1 = sanic.Blueprint("bp1", url_prefix="/bp1")
    bp2 = sanic.Blueprint("bp2", url_prefix="/bp2")

    bp3 = sanic.Blueprint("bp3", url_prefix="/bp3")
    bp4 = sanic.Blueprint("bp4", url_prefix="/bp4")

    bpg = BlueprintGroup(url_prefix="/group")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    b

# Generated at 2022-06-24 03:27:24.233277
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp = Blueprint('bp')

    def foo():
        pass

    def bar():
        pass

    @bp.middleware('request')
    async def bp_mw(request):
        print('In blueprint middleware')

    @bp.middleware('request')
    async def bp_mw(request):
        print('In blueprint middleware!')

    bpg = BlueprintGroup()
    bpg.append(bp)
    print(1)

    @bpg.middleware('request')
    async def bpg_mw(request):
        print('In BlueprintGroup middleware')

    @bpg.middleware('request')
    async def bpg_mw(request):
        print('In BlueprintGroup middleware!')

    assert len(bpg.blueprints[0].middlewares['request']) == 3

# Generated at 2022-06-24 03:27:36.164621
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup()

    bpg._blueprints = [bp1, bp2]
    bpg.__setitem__(0, bp3)
    assert bpg.__getitem__(0) == bp3
    assert bpg._blueprints[0] == bp3

    bpg.__setitem__(1, bp4)
    assert bpg.__getitem__(1) == bp4
    assert bpg._blueprints[1] == bp4

# Unit

# Generated at 2022-06-24 03:27:43.997018
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Unit test for method middleware of class BlueprintGroup
    class FakeBlueprint:
        def __init__(self):
            self.middleware_queue = []

        def middleware(self, fn, *args, **kwargs):
            self.middleware_queue.append(fn)
            return fn

    bp = FakeBlueprint()
    bp_group = BlueprintGroup()
    bp_group.append(bp)

    @bp_group.middleware("request")
    def req_middleware(func):
        return func

    assert len(bp_group.blueprints[0].middleware_queue) == 1
    assert bp_group.blueprints[0].middleware_queue[0] == req_middleware



# Generated at 2022-06-24 03:27:47.703866
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint = Blueprint('test_BlueprintGroup___getitem__', url_prefix='/test_BlueprintGroup___getitem__')
    blueprint_group = BlueprintGroup(blueprint)
    assert blueprint_group[0] == blueprint



# Generated at 2022-06-24 03:27:53.296316
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    assert bpg._blueprints == []
    bpg._blueprints = [bp1, bp2]
    assert list(bpg) == [bp1, bp2]


# Generated at 2022-06-24 03:28:02.879598
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()
    assert len(bpg) == 0

    bpg.append(bp1)
    assert len(bpg) == 1

    bpg.append(bp2)
    assert len(bpg) == 2

    del bpg[0]
    assert len(bpg) == 1

    # Test length with a Blueprint Group that has a URL prefix
    bpg = BlueprintGroup("/api")
    assert len(bpg) == 0

    bpg.append(bp1)
    assert len(bpg) == 1



# Generated at 2022-06-24 03:28:13.476193
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')
    bp_group = BlueprintGroup()
    bp_group.append(bp1)
    bp_group.append(bp2)
    bp_group.append(bp3)
    bp_group.append(bp4)
    bp_group.append(bp5)
    bp_group.append(bp6)
    assert list

# Generated at 2022-06-24 03:28:21.960575
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    """
    Test for the method '__setitem__' of class 'BlueprintGroup'
    """
    bpg = BlueprintGroup()
    bpg.append(sanic.Blueprint('first_bp'))
    # test for when 'item' is of type Blueprint
    bp = sanic.Blueprint('second_bp')
    bpg.__setitem__(0, bp)
    assert bpg[0] is bp
    # test for when 'item' is not of type Blueprint
    with pytest.raises(AssertionError):
        bpg.__setitem__(0, 'a')


# Generated at 2022-06-24 03:28:30.856173
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp_group = BlueprintGroup('/api', version='v1', strict_slashes=False)
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp_group.append(bp1)
    bp_group.append(bp2)
    assert bp1.url_prefix == '/api/bp1'
    assert bp2.url_prefix == '/api/bp2'
    assert bp1.version == 'v1'
    assert bp2.version == 'v1'
    assert bp1.strict_slashes is False


# Generated at 2022-06-24 03:28:39.479460
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="api", version="v1")

    bpg.append(bp1)
    bpg.append(bp2)

    bpg.append(bp3)
    bpg.append(bp4)

    bp1_in_bpg = False
    bp2_in_bpg = False
    bp3_in_bpg = False
    bp4_in_bpg = False


# Generated at 2022-06-24 03:28:47.664876
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    app = sanic.Sanic("Sanic")
    b1 = Blueprint("b1", url_prefix="/b1")
    b2 = Blueprint("b2", url_prefix="/b2")

    bg = BlueprintGroup(url_prefix="/bg")
    bg.append(b1)
    bg.append(b2)

    assert len(bg) == 2
    assert b1 in bg
    assert b2 in bg

    del bg[0]
    assert len(bg) == 1
    assert b1 not in bg
    assert b2 in bg


# Generated at 2022-06-24 03:28:58.206143
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @sanic.Blueprint.middleware('request')
    def req_middleware():
        pass

    @sanic.Blueprint.middleware('response')
    def res_middleware():
        pass

    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')

    group = sanic.Blueprint.group(bp1, bp2)

    assert len(bp1.request_middleware) == 1
    assert len(bp2.request_middleware) == 1
    assert len(bp1.response_middleware) == 1
    assert len(bp2.response_middleware) == 1

    def test_middleware(request):
        pass

    group.middleware(test_middleware)

# Generated at 2022-06-24 03:29:02.715982
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp = Blueprint("BP", url_prefix="/bp")
    bpg = BlueprintGroup(url_prefix="/api")

    assert bpg.append(bp) is None
    assert bpg[0] == bp


# Generated at 2022-06-24 03:29:12.681453
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic import Blueprint, Sanic
    from sanic.response import text

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)


# Generated at 2022-06-24 03:29:23.347280
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    The Middleware implementation should be able to use the partial function
    to apply the middleware plugins to the Blueprint Group.
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)

    @group.middleware('request')
    async def bp1_only_middleware(request):
        pass

    @bp1.middleware('request')
    @bp2.middleware('request')
    async def bp1_and_bp2_middleware(request):
        pass

    assert len(bp1.handlers['request']) == 2
    assert len(bp2.handlers['request']) == 2

# Generated at 2022-06-24 03:29:27.388846
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bg = BlueprintGroup()
    bg.append(Blueprint("bp1"))
    bg.append(Blueprint("bp2"))
    assert len(bg) == 2
    del bg[0]
    assert len(bg) == 1


# Generated at 2022-06-24 03:29:38.490427
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    # define blueprint group bpg
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    # define route
    @bp3.route('/')
    async def bp1_route(request):
        return text('bp1')
    @bp4.route('/<param>')
    async def bp2_route(request, param):
        return text(param)
    # define test case
    # correct setting
    bpg[0] = bp

# Generated at 2022-06-24 03:29:47.133583
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", strict_slashes=True)
    @bpg.middleware('request')
    def bp_group_middleware(request):
        print('bp group middleware')
    assert len(getattr(bp1, 'middlewares')['request']) == 1
    assert len(getattr(bp2, 'middlewares')['request']) == 1
    assert bpg.strict_slashes == True



# Generated at 2022-06-24 03:29:48.535204
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    group=BlueprintGroup()
    group.append([])
    assert group._blueprints == []


# Generated at 2022-06-24 03:29:56.947394
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup()
    bpg.append(bp3)
    bpg.append(bp4)

    group = Blueprint.group(bp1, bp2)

    assert len(bpg) == 2
    assert len(group) == 2


# Generated at 2022-06-24 03:30:03.326723
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    app = sanic.Sanic("BlueprintGroup")
    bp1 = Blueprint("Blueprint1", url_prefix="bp1", strict_slashes=True)
    bp2 = Blueprint("Blueprint2", url_prefix="bp2", strict_slashes=True)
    group = BlueprintGroup(url_prefix="", strict_slashes=True)
    group.append(bp1)
    group.append(bp2)
    del group[0]
    assert group.blueprints[0] == bp2

# Generated at 2022-06-24 03:30:05.000572
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    BlueprintGroup(url_prefix="/api", version="v1", strict_slashes=False)



# Generated at 2022-06-24 03:30:09.317552
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint = Blueprint("test_blueprint", url_prefix="/test")
    blueprint_group = BlueprintGroup(url_prefix="/api", version="v1")
    blueprint_group.append(blueprint)
    blueprint_group[0] = blueprint


# Generated at 2022-06-24 03:30:11.736155
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    result = iter(BlueprintGroup())
    assert iter(result) == result



# Generated at 2022-06-24 03:30:16.125203
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bpg = BlueprintGroup(url_prefix='/url_prefix', version='v1')
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg)


# Generated at 2022-06-24 03:30:25.197574
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()

    bpg.append(bp1)
    bpg.append(bp2)

    bpg[0] = Blueprint('bp3', url_prefix='/bp3')
    bpg[1] = Blueprint('bp4', url_prefix='/bp4')

    assert bpg.blueprints[0].url_prefix == bp3.url_prefix
    assert bpg.blueprints[1].url_prefix == bp4.url_prefix



# Generated at 2022-06-24 03:30:32.786235
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    """
    Unit test to ensure that the element insertion process works
    as expected with respect to BlueprintGroup
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bg = BlueprintGroup()

    bg.append(bp1)
    bg.insert(0, bp2)

    assert bg.blueprints[0] == bp2
    assert bg.blueprints[1] == bp1



# Generated at 2022-06-24 03:30:39.847594
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup()
    bpg.extend([bp1,bp2,bp3,bp4])
    assert bpg[0] == bp1
    assert bpg[3] == bp4



# Generated at 2022-06-24 03:30:50.207978
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    bp1 = sanic.Blueprint('testbp1')
    bp2 = sanic.Blueprint('testbp2')
    bpg = BlueprintGroup()

    @bpg.middleware()
    async def bpg_middleware(request):
        pass

    @bpg.middleware('request')
    async def bpg_middleware1(request):
        pass

    @bpg.middleware('request')
    async def bpg_middleware2(request):
        pass

    @bpg.middleware('request')
    async def bpg_middleware3(request):
        pass

    @bpg.middleware('request')
    async def bpg_middleware4(request):
        pass

    bpg.append(bp1)
    bpg.append(bp2)


# Generated at 2022-06-24 03:30:59.411479
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = sanic.Blueprint("test1",url_prefix="/test1",strict_slashes=True,version="v1")
    bp2 = sanic.Blueprint("test2",url_prefix="/test2",strict_slashes=True,version="v2")
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(list(bpg)) == 2
    assert bpg[0].url_prefix == "/test1"
    assert bpg[1].url_prefix == "/test2"


# Generated at 2022-06-24 03:31:10.505333
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    # create BlueprintGroup
    BlueprintGroup1 = BlueprintGroup()
    # create Blueprint
    app = sanic.Sanic(__name__)

    Blueprint1 = Blueprint("bp1", url_prefix="/")
    Blueprint1.register(app)

    Blueprint2 = Blueprint("bp2", url_prefix="/")
    Blueprint2.register(app)

    BlueprintGroup1.append(Blueprint1)
    BlueprintGroup1.append(Blueprint2)

    @BlueprintGroup1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @Blueprint1.route('/')
    async def bp1_route(request):
        print('bp1')


# Generated at 2022-06-24 03:31:20.440075
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    """
    Test the implementation of `BlueprintGroup.__iter__` method.

    The Test method takes a `BlueprintGroup` object and use it as
    an iterable entity. This test also demonstrates how to perform
    list/tuple like indexing or splicing on the `BlueprintGroup`
    object.

    Method :meth:`~test_BlueprintGroup___iter__`
    """

    # create a blueprint group
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp1.route("/", methods=["GET"])(lambda x: x)

    bp2 = Blueprint("bp2")
    bp2.route("/<param>", methods=["GET"])(lambda x, param: param)

    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp

# Generated at 2022-06-24 03:31:25.331412
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp = Blueprint("test", url_prefix="/test")
    bg = BlueprintGroup()
    bg.append(bp)
    assert next(iter(bg)) == bp

# Generated at 2022-06-24 03:31:31.964413
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    # Test BlueprintGroup.__getitem__ with a valid blueprint item
    assert isinstance(BlueprintGroup()[0], Blueprint)
    # Test BlueprintGroup.__getitem__ with a empty group object
    assert isinstance(BlueprintGroup()[0], Blueprint)
    # Test BlueprintGroup.__getitem__ with a invalid index value
    try:
        BlueprintGroup()[3]
    except IndexError:
        assert True
    else:
        assert False


# Generated at 2022-06-24 03:31:40.937276
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api")
    bpg.version = "v1"

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-24 03:31:48.960577
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    # __len__ of class BlueprintGroup returns length of blueprints
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp1.name = 'bp1'
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp2.name = 'bp2'
    bpg = BlueprintGroup(url_prefix='/api', version='v1')

    assert(len(bpg) == 0)
    
    bpg.append(bp1)
    bpg.append(bp2)
    
    assert(len(bpg) == 2)


# Generated at 2022-06-24 03:31:56.031727
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    class TempApp(sanic.Sanic):
        def __init__(self, *args, **kwargs):
            super(TempApp, self).__init__(*args, **kwargs)
            self.blueprint_groups = []

    app = TempApp()

    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bp3 = Blueprint("bp3")

    bpg = BlueprintGroup("bpg")
    bpg.insert(0, bp1)

    bpg.insert(0, bp2)
    bpg.insert(0, bp3)

    app.blueprint(bpg)

    assert app.blueprint_groups[0].blueprints[0].name == "bp3"

# Generated at 2022-06-24 03:32:03.281908
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp3)
    bpg.append(bp4)
    bpg[1] = bp2


# Generated at 2022-06-24 03:32:11.382624
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg1 = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    assert bpg1.url_prefix == "/api"
    assert bpg1.version == "v1"
    assert bp1.url_prefix == "/api/bp1"
    assert bp2.url_prefix == "/api/bp2"
    assert bp1.version == "v1"
    assert bp2.version == "v1"


# Generated at 2022-06-24 03:32:17.028832
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.insert(0,bp1)
    del bpg[0]
    assert bpg._blueprints == [bp1, bp2]


# Generated at 2022-06-24 03:32:26.660942
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    # Now test for the length of the object
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')
    bp7 = Blueprint('bp7', url_prefix='/bp7')
    bp8 = Blueprint('bp8', url_prefix='/bp8')

    bp_grp1 = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    bp_grp

# Generated at 2022-06-24 03:32:28.722569
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2, url_prefix='/api', version='v1')

    assert(group.url_prefix == '/api')
    assert(group.version == 'v1')



# Generated at 2022-06-24 03:32:32.414856
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group = BlueprintGroup()
    blueprint_group.append(Blueprint('Blueprint1', url_prefix='/bp1'))
    blueprint_group.append(Blueprint('Blueprint2', url_prefix='/bp2'))
    assert len(blueprint_group) == 2


# Generated at 2022-06-24 03:32:36.537882
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp3 = Blueprint('bp3', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    @bp3.route('/')
    async def bp1_route(request):
        return text('bp1')

   

# Generated at 2022-06-24 03:32:48.078838
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    group = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    assert group.url_prefix == '/api'
    assert group.version == "v1"
    assert bpg.url_prefix == '/api'
    assert bpg.version == "v1"
    assert len(group) == 2
    assert len(bpg) == 2

# Generated at 2022-06-24 03:32:53.096810
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg) == 2
    assert bpg[0] == bp1
    assert bpg[1] == bp2


# Generated at 2022-06-24 03:32:59.804883
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    # Setup : Create a Blueprint Group
    bpg = BlueprintGroup()

    # Excercise : Register new blueprints under the Blueprint Group
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bpg.append(bp1)
    bpg.append(bp2)

    # Verify : Blueprint Group length should be 2
    assert len(bpg) == 2


# Generated at 2022-06-24 03:33:11.652842
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    app = sanic.Sanic('test_BlueprintGroup_append')
    bp = Blueprint('test', url_prefix='/test')
    bp.append = 1
    assert bp.append == 1
    bpg = BlueprintGroup(url_prefix='/bpg')
    bpg.append(bp)
    bpg.append(bp)
    assert len(bpg) == 2
    assert bpg[0] == bp
    assert bpg[1] == bp
    app.blueprint(bpg)
    request, response = app.test_client.get('/bpg/test/test')
    assert response.status == 404
    @bp.route('/test')
    async def test(request):
        return text('OK')

# Generated at 2022-06-24 03:33:19.756134
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api")

    # Append Blueprints
    bpg.append(bp1)
    bpg.append(bp2)

    # Assert on number of blueprints
    assert len(bpg) == 2

    # Assert on the url prefix
    assert bpg.url_prefix == "/api"

    # Assert on the Blueprints
    assert bpg.blueprints[0] == bp1
    assert bpg.blueprints[1] == bp2


# Test for BlueprintGroup.__getitem__

# Generated at 2022-06-24 03:33:27.512945
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1',  url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = BlueprintGroup(url_prefix='/api', version="v2")
    group.append(bp1)
    group.append(bp2)

    assert len(group) == 2
    assert group.blueprints == [bp1, bp2]
    assert isinstance(group, BlueprintGroup)



# Generated at 2022-06-24 03:33:30.454592
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp = BlueprintGroup()
    bp.append(bp1)
    assert len(bp) == 1


# Generated at 2022-06-24 03:33:38.410618
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bp_group = BlueprintGroup()
    bp_group.append(bp1)
    bp_group.append(bp2)
    bp_group.append(bp3)
    bp_group.append(bp4)
    
    bp_group.__delitem__(2)
    assert len(bp_group) == 3
    assert bp_group[0] == bp1
    assert bp_group[1] == bp2

# Generated at 2022-06-24 03:33:45.259336
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = sanic.Blueprint('TEST_BPG___len___BP_1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('TEST_BPG___len___BP_2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    assert len(bpg) == 0
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg) == 2


# Generated at 2022-06-24 03:33:47.228622
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    assert BlueprintGroup().version == None
    assert BlueprintGroup().url_prefix == None
    assert BlueprintGroup().strict_slashes == None


# Generated at 2022-06-24 03:33:54.168907
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    # Remove item from the index specified
    # If the index is less than 0, the index will be set to 0 - index
    # index + len(self.blueprints)
    # If the index is greater than len(self.blueprints), index will be set to
    # len(self.blueprints) - index
    # del self.blueprints[index]
    assert BlueprintGroup().__delitem__(0) is None


# Generated at 2022-06-24 03:33:55.794522
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    class TestClass:
        @BlueprintGroup.append
        def method(self):
            pass
    assert hasattr(TestClass, "method")


# Generated at 2022-06-24 03:34:03.802125
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp = Blueprint("Test_BlueprintGroup___iter__")

    bp.route("/", endpoint="index")(lambda request: text("ok"))

    bp2 = Blueprint("Test_BlueprintGroup___iter__2")

    bp2.route("/", endpoint="index2")(lambda request: text("ok"))

    bp_group = BlueprintGroup("/api")
    bp_group.append(bp)
    bp_group.append(bp2)
    assert isinstance(bp_group.__iter__(), bp_group.__iter__().__class__)
    for bp in bp_group.__iter__():
        assert isinstance(bp, Blueprint)


# Generated at 2022-06-24 03:34:11.757233
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp1')
    bp4 = Blueprint('bp4', url_prefix='/bp2')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    assert len(bpg) == 2
    del bpg[0]
    assert len(bpg) == 1


# Generated at 2022-06-24 03:34:21.326703
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api")
    bpg.append(bp1)
    bpg.append(bp2)

    # Check the length of bpg
    assert len(bpg) == 2

    # Check the index of bpg
    assert bpg[0].name == "bp1"
    assert bpg[1].name == "bp2"

    # Check the iteration of bpg
    counter = 1
    for bp in bpg:
        assert bp.name == f"bp{counter}"
        counter += 1



# Generated at 2022-06-24 03:34:31.908276
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    assert bpg.url_prefix == "/api"
    assert bpg.version == "v1"
    assert bpg[0].url_prefix == "/api/bp1"
    assert bpg[1].url_prefix == "/api/bp2"

# Generated at 2022-06-24 03:34:37.875154
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2)

    assert group[0] == bp1
    assert group[1] == bp2


# Generated at 2022-06-24 03:34:46.703251
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    app = sanic.Sanic()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    app.blueprint(bpg)
    request, response = app.test_client.get('/bp1/bp1_route')
    assert response.status == 404
    assert response.text == 'Not Found'
    request, response = app.test_client.get('/bp2/bp2_route')
    assert response.status == 404
    assert response.text == 'Not Found'
    assert request.app == app


# Generated at 2022-06-24 03:34:54.551081
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")

    bpg = BlueprintGroup("/api", version="v1")
    bpg.extend([bp1, bp2, bp3])

    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert bpg[2] == bp3
