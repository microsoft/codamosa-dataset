

# Generated at 2022-06-24 03:25:00.939755
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup()
    bpg.append(bp3)
    bpg.append(bp4)
    assert len(bpg) == 2, "BlueprintGroup size not equal 2"
    assert bpg[0] == bp3, "BlueprintGroup first element not equal to bp3"
    assert bpg[1] == bp4, "BlueprintGroup second element not equal to bp4"

# Generated at 2022-06-24 03:25:11.286000
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()

    @app.middleware("request")
    def common_middleware(request):
        print("common middleware...")

    @app.middleware("response")
    def common_middleware(request, response):
        print("common middleware...")

    bp1 = sanic.Blueprint("bp1")

    @bp1.middleware("request")
    def common_middleware(request):
        print("bp1 middleware...")

    @bp1.middleware("response")
    def common_middleware(request, response):
        print("bp1 middleware...")

    bp2 = sanic.Blueprint("bp2")

    @bp2.middleware("request")
    def common_middleware(request):
        print("bp2 middleware...")


# Generated at 2022-06-24 03:25:19.550096
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    """
    Test case for the method __setitem__ of class BlueprintGroup
    """
    app = sanic.Sanic("app", strict_slashes=True)
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp_list = BlueprintGroup("/api", bp1, bp2)
    bp_list[0] = bp2
    assert bp_list[0] == bp2
    assert bp_list[1] == bp1


# Generated at 2022-06-24 03:25:24.504207
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp = Blueprint('bp', url_prefix='/bp')
    bpGroup = BlueprintGroup(url_prefix='/api', version='v1', strict_slashes=True)

    bpGroup.insert(0, bp)

    assert bpGroup[0] == bp


# Generated at 2022-06-24 03:25:28.221832
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bpg = BlueprintGroup(bp, bp2, bp3, url_prefix="/api", version="v1")
    assert len(bpg) == 3


# Generated at 2022-06-24 03:25:35.201577
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')

    bg = BlueprintGroup(bp1, bp2, bp3)

    assert len(bg) == 3

    bg.pop()

    assert len(bg) == 2

    bg.pop(1)

    assert len(bg) == 1



# Generated at 2022-06-24 03:25:41.936954
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    assert len(bpg) == 4


# Generated at 2022-06-24 03:25:45.294640
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp = Blueprint("bp", url_prefix="/api")
    bp.add_route(lambda x: x, "/")

    bpg = BlueprintGroup(url_prefix="/group")
    bpg.append(bp)
    del bpg[0]
    assert len(bpg) == 0


# Generated at 2022-06-24 03:25:52.101924
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bpg = BlueprintGroup(url_prefix="/bpg")

    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bpg.blueprints) == 2

    # to do:
    # check if the prefix is added to bp1 and bp2
    # check if version and strict_slashes is added to bp1 and bp2



# Generated at 2022-06-24 03:25:59.523741
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)

    assert list(bpg) == [bp1, bp2]


# Generated at 2022-06-24 03:26:04.076478
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1", strict_slashes=True)
    bpg.append(bp1)
    bpg.append(bp2)

    blueprints = list(bpg)
    assert blueprints[0] == bp1
    assert blueprints[1] == bp2


# Generated at 2022-06-24 03:26:14.193953
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    assert bp1._url_prefix == '/bp1'
    assert bp2._url_prefix == '/bp2'
    assert bp3._url_prefix == '/bp4'
    assert bp4._url_prefix == '/bp4'

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    bp1.middleware('request')(lambda x: 1)
    bp2.middleware('request')(lambda x: 1)

    bpg

# Generated at 2022-06-24 03:26:25.372578
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp1._register_view(sanic.websocket.WebSocketProtocol, "/test")
    bp2._register_view(sanic.websocket.WebSocketProtocol, "/test")
    bp1._middlewares = {"websocket": [None]}
    bp2._middlewares = {"websocket": [None]}
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg.blueprints) == 2
    assert bpg.blueprints[0]._url_prefix == "/bp1"

# Generated at 2022-06-24 03:26:35.164696
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1_1 = Blueprint('bp1', url_prefix='/bp1')
    bp1_2 = Blueprint('bp2', url_prefix='/bp2')

    bp2_1 = Blueprint('bp3', url_prefix='/bp1')
    bp2_2 = Blueprint('bp4', url_prefix='/bp2')

    bpg1 = BlueprintGroup()
    bpg2 = BlueprintGroup()

    bpg1.append(bp1_1)
    bpg1.append(bp1_2)
    bpg2.append(bp2_1)
    bpg2.append(bp2_2)

    bp1 = Blueprint('bp5', url_prefix='/bp5')

    bpg1.insert(1, bp1)


# Generated at 2022-06-24 03:26:45.741177
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-24 03:26:50.452836
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint("bp1", url_prefix="bp1")
    bp2 = Blueprint("bp2", url_prefix="bp2")
    bpg = BlueprintGroup("bpg")
    bpg.extend([bp1, bp2])
    assert len(bpg) == 2



# Generated at 2022-06-24 03:26:58.004212
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()

    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bpg) == 2



# Generated at 2022-06-24 03:27:04.402696
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    # Setup a sample Sanic app to which we will attach the blueprint group
    app = sanic.Sanic(log_config=None)

    # Add some sample route
    @app.route('/')
    async def hello(request):
        return text('OK')

    # Create a sample blueprint object
    bp = Blueprint('bp1')

    bp_group = BlueprintGroup()

    # Add the blank blueprint group to the application and then attach
    # the blueprint object to the blueprint group
    #
    # The main reason for using this approach, is because we want to use all
    # the pre-existing behavior from the blueprint registration logic to
    # make sure that we don't break any existing behavior

    bp_group.append(bp)

    app.blueprint(bp_group)

    # Test the serving of the dummy route
    request,

# Generated at 2022-06-24 03:27:15.586982
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bpg = BlueprintGroup("/api", version="v1", strict_slashes=False)
    assert bpg.url_prefix == "/api"
    assert bpg.version == "v1"
    assert bpg.strict_slashes is False

    bpg = BlueprintGroup("/api")
    assert bpg.url_prefix == "/api"
    assert bpg.version is None
    assert bpg.strict_slashes is None

    bpg = BlueprintGroup(url_prefix="/api")
    assert bpg.url_prefix == "/api"
    assert bpg.version is None
    assert bpg.strict_slashes is None

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    assert bpg.url_prefix == "/api"
    assert bpg.version == "v1"

# Generated at 2022-06-24 03:27:21.033763
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = BlueprintGroup()
    bp3[1] = bp1
    bp3[0] = bp2
    assert bp3[0] == bp2
    assert bp3[1] == bp1



# Generated at 2022-06-24 03:27:24.888908
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    ng = BlueprintGroup()
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    ng.insert(0, bp1)
    ng.insert(0, bp2)
    assert isinstance(ng, BlueprintGroup)
    assert isinstance(ng[0], Blueprint)
    assert ng[0].name == 'bp2'
    assert ng[1].name == 'bp1'


# Generated at 2022-06-24 03:27:32.138109
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    # Creation of a new BlueprintGroup with three blueprints
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    # Appending two more blueprints to this group
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    # Assertion with the BlueprintGroup Iterator
    assert(len([bp for bp in bpg]) == 4)

# Generated at 2022-06-24 03:27:36.902130
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint("bp1", url_prefix="/bp1", strict_slashes=True)
    assert bp1.version is None
    assert bp1.strict_slashes is True
    bpg = BlueprintGroup(url_prefix="/v1", strict_slashes=False, version="v1")
    bpg.append(bp1)
    assert len(bpg) == 1
    assert bpg[0] == bp1
    assert bpg[0].version == "v1"
    assert bpg[0].strict_slashes is False


# Generated at 2022-06-24 03:27:47.765983
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint("bp1", url_prefix="/bp1", strict_slashes=True)
    bp2 = Blueprint("bp2", url_prefix="/bp2", version="v2")

    bp_group = BlueprintGroup("/api")
    bp_group.append(bp1)
    bp_group.append(bp2)

    assert bp_group.blueprints[0].url_prefix == "/api/bp1"
    assert bp_group.blueprints[0].version == "v1"

    assert bp_group.blueprints[1].url_prefix == "/api/bp2"
    assert bp_group.blueprints[1].version == "v2"


# Generated at 2022-06-24 03:27:55.483845
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    # arrange
    blueprint1 = Blueprint('blueprint1', url_prefix='/blueprint1')
    blueprint2 = Blueprint('blueprint2', url_prefix='/blueprint2')
    blueprint_group = BlueprintGroup(url_prefix='/blueprintgroup')
    blueprint_group.append(blueprint1)
    blueprint_group.append(blueprint2)
    
    # act
    del blueprint_group[1]

    # assert
    assert len(blueprint_group) == 1
    assert blueprint_group[0] == blueprint1


# Generated at 2022-06-24 03:27:58.470603
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()
    
    bpg.append(bp1)
    bpg.append(bp2)
    
    assert len(bpg) == 2


# Generated at 2022-06-24 03:28:01.311784
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    # BlueprintGroup.__delitem__(0)
    # assert callable(BlueprintGroup.__delitem__)
    assert True # TODO: implement your test here



# Generated at 2022-06-24 03:28:06.189347
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()

    bpg.append(bp1)
    bpg.append(bp2)

    assert list(bpg) == [bp1, bp2]


# Generated at 2022-06-24 03:28:12.525285
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bpg = BlueprintGroup()
    bpg.append(sanic.Blueprint(url_prefix="url_prefix", name="name1"))
    assert len(bpg) == 1
    bpg.insert(0, sanic.Blueprint(url_prefix="url_prefix2", name="name2"))
    assert len(bpg) == 2
    assert bpg[0].name == "name2"
    assert bpg[1].name == "name1"



# Generated at 2022-06-24 03:28:17.859539
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp = Blueprint('bp', url_prefix='/bp')
    bp.add_route(lambda r: HTTPResponse(), '/')
    bpg = BlueprintGroup(bp, url_prefix="/api", version="v1")

    # verify iter(bpg) == bpg
    assert iter(bpg) == bpg
    assert [bp] == list(bpg)


# Generated at 2022-06-24 03:28:24.854682
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    app = sanic.Sanic(__name__)
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4)
    assert len(bpg) == 2


# Generated at 2022-06-24 03:28:36.210336
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():

    # 1. Create an object of class Blueprint and BlueprintGroup
    # 2. add Blueprint under BlueprintGroup
    # 3. Assert the length of BlueprintGroup and BlueprintGroup._blueprints is updated.
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix='/api',version='v1')
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg) == 2
    assert len(bpg._blueprints) == 2

    # 4. Remove all blueprints from BlueprintGroup
    # 5. Assert the length of BlueprintGroup and BlueprintGroup._blueprints is updated.
    bpg.clear()
    assert len(bpg) == 0
    assert len

# Generated at 2022-06-24 03:28:47.573761
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')
    bp7 = Blueprint('bp7', url_prefix='/bp7')
    bp8 = Blueprint('bp8', url_prefix='/bp8')
    bp9 = Blueprint('bp9', url_prefix='/bp9')
    bp10 = Blueprint('bp10', url_prefix='/bp10')

# Generated at 2022-06-24 03:28:53.108405
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bpg = BlueprintGroup("/api")
    bpg.append(bp1)
    bpg.append(bp2)
    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert bpg["bp1"] == bp1
    assert bpg["bp2"] == bp2


# Generated at 2022-06-24 03:28:56.834078
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(bp, bp2, url_prefix="/api", version="v1")

    assert len(bpg) == 2
    del bpg[1]
    assert len(bpg) == 1
    assert bpg[0] == bp
    del bpg[0]
    assert len(bpg) == 0


# Generated at 2022-06-24 03:29:04.190614
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    from sanic.blueprints import Blueprint
    test_blueprint1 = Blueprint('test_bp1', url_prefix='/bp1')
    test_blueprint2 = Blueprint('test_bp2', url_prefix='/bp2')
    bp_group = BlueprintGroup()
    bp_group.append(test_blueprint1)
    bp_group.append(test_blueprint2)
    assert(len(bp_group) == 2)
    bp_group.append(Blueprint('test_bp3', url_prefix='/bp3'))
    assert(len(bp_group) == 3)
    del bp_group[1]
    assert(len(bp_group) == 2)


# Generated at 2022-06-24 03:29:13.823369
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    bp1.url_prefix = '/bp1'
    bp2.url_prefix = '/bp2'
    assert len(bpg.blueprints) == 4
    assert bpg.blueprints[1].url_prefix == '/bp1'
    assert bpg.blueprints[2].url_prefix == '/bp2'
    assert bpg.version == bp1.version == bp2.version == 'v1'

# Generated at 2022-06-24 03:29:23.702658
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()

    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp2.middleware('request')
    async def bp2_only_middleware(request):
        print('applied on Blueprint : bp2 Only')

    @bpg.middleware('request')
    async def bp_group_only_middleware(request):
        print('applied on Blueprint : BP Group Only')


# Generated at 2022-06-24 03:29:34.783347
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg) == 2

    # Pass a list of Blueprints
    bpg = BlueprintGroup([bp1, bp2])
    assert len(bpg) == 2

    # Pass the blueprints as part of the kwargs
    bpg = BlueprintGroup(blueprints=[bp1, bp2])
    assert len(bpg) == 2

    # Test the BlueprintGroup as a list
    assert bpg[0] == bp1

# Generated at 2022-06-24 03:29:42.976965
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    # Initialize a Blueprint Group and a middleware
    bp = Blueprint("test", strict_slashes=True, version="1.0")
    bpg = BlueprintGroup("api", "1.0", strict_slashes=True)
    bpg.append(bp)
    bpg.append(blueprint=bp)

    @bpg.middleware("request")
    async def middleware1(request):
        pass

    # Validate the middleware is applied properly
    for _bp in bpg.blueprints:
        assert len(_bp.middlewares["request"]) == 1



# Generated at 2022-06-24 03:29:49.705129
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    class Blueprint:
        def __init__(self, name, url_prefix):
            self.name = name
            self.url_prefix = url_prefix

    bp1 = Blueprint("bp1", "/bp1")
    bp2 = Blueprint("bp2", "/bp2")

    bpg = BlueprintGroup()
    assert len(bpg) == 0

    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bpg) == 2
    assert bpg[0] == bp1
    assert bpg[1] == bp2


# Generated at 2022-06-24 03:30:01.195141
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint1 = Blueprint("bp1", url_prefix="/bp1")
    blueprint2 = Blueprint("bp2", url_prefix="/bp2")
    blueprint3 = Blueprint("bp3", url_prefix="/bp3")
    blueprint4 = Blueprint("bp4", url_prefix="/bp4")
    blueprint5 = Blueprint("bp5", url_prefix="/bp5")
    blueprint6 = Blueprint("bp6", url_prefix="/bp6")

    bpGroup = BlueprintGroup(blueprint1, blueprint2, 
            url_prefix="api", version=1)

    bpGroup2 = BlueprintGroup(blueprint3, blueprint4, 
            url_prefix="api", version=2)

    bpGroup.insert(0, bpGroup2)

    assert len(bpGroup) == 3
    assert bpGroup[0].version == 2
   

# Generated at 2022-06-24 03:30:08.176622
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bpg = BlueprintGroup(url_prefix="/api", version="v1", strict_slashes=False)

    # assert url_prefix returns expected result
    expected = "/api"
    actual = bpg.url_prefix
    assert expected == actual

    # assert version returns expected result
    expected = "v1"
    actual = bpg.version
    assert expected == actual

    # assert strict_slashes returns expected result
    expected = False
    actual = bpg.strict_slashes
    assert expected == actual



# Generated at 2022-06-24 03:30:10.093320
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    """
    Unit Test of BlueprintGroup built-in implementation
    """
    bpg = BlueprintGroup()
    assert len(bpg) == 0
    assert bpg.url_prefix is None

# Generated at 2022-06-24 03:30:15.287189
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    # Arrange
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()

    # Act
    bpg.append(bp1)
    bpg.append(bp2)

    # Assert
    assert len(bpg) == 2



# Generated at 2022-06-24 03:30:23.834221
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint(__name__, url_prefix='/bp1')
    bp2 = Blueprint(__name__, url_prefix='/bp2')
    bp1.__setattr__('name', 'test_bp1')
    bp2.__setattr__('name', 'test_bp2')
    bpg = BlueprintGroup(url_prefix='/bpg')
    bpg.append(bp1)
    bpg[0] = bp2
    assert bpg[0].name == 'test_bp2'


# Generated at 2022-06-24 03:30:27.600223
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    """Test BlueprintGroup append method."""
    # Create test blueprint
    blueprint = Blueprint("test")

    # Create blueprints group and append blueprint
    group = BlueprintGroup()
    group.append(blueprint)

    # Check if appended blueprint is in group
    index = group.blueprints.index(blueprint)
    assert group[index] == blueprint


# Generated at 2022-06-24 03:30:36.048487
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic(__name__)
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2)

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')


# Generated at 2022-06-24 03:30:42.132654
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix="")
    bpg.append(bp1)
    bpg.append(bp2)
    assert bpg[0] == bp1
    assert bpg[1] == bp2



# Generated at 2022-06-24 03:30:50.441658
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint("test_bp1", url_prefix="/test_bp1")
    bp2 = Blueprint("test_bp2", url_prefix="/test_bp2")
    bp3 = Blueprint("test_bp3", url_prefix="/test_bp3")
    bpg = BlueprintGroup(url_prefix="/test_url", version="/test_version")

    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg[0] == bp1
    assert bpg[1] == bp2

    bpg[0] = bp3

    assert bpg[0] == bp3
    assert bpg[1] == bp2

    bpg[1] = bp3
    assert bpg[1] == bp3


# Generated at 2022-06-24 03:30:57.385614
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    test_data = BlueprintGroup(url_prefix="/test")
    expected = 0
    actual = test_data.__len__()
    assert (
        actual == expected
    ), f"Expected : {expected}, Actual : {actual} - Len of empty BlueprintGroup"

    bp1 = Blueprint("bp1", url_prefix="/bp1")
    test_data = BlueprintGroup(bp1, url_prefix="/test")
    expected = 1
    actual = test_data.__len__()
    assert (
        actual == expected
    ), f"Expected : {expected}, Actual : {actual} - Len of single BlueprintGroup"

    bp2 = Blueprint("bp2", url_prefix="/bp2")
    test_data = BlueprintGroup(bp1, bp2, url_prefix="/test")
    expected = 2
    actual = test_

# Generated at 2022-06-24 03:31:05.845178
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic('BlueprintGroup_middleware')
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="", version="")
    bpg.append(bp1)
    bpg.append(bp2)

    def middleware(request):
        print('middleware worked !!!')

    bpg.middleware(middleware)

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/test')
    async def bp2_route(request):
        return text('bp2')

    app.blueprint(bpg)

    request, response = app.test

# Generated at 2022-06-24 03:31:16.597086
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bp3 = Blueprint("bp3")

    bp_group = BlueprintGroup()
    bp_group.append(bp1)
    bp_group.append(bp2)
    bp_group.append(bp3)

    del bp_group[1]

    assert bp_group[0].name == "bp1"
    assert bp_group[1].name == "bp3"
    assert len(bp_group) == 2
    assert bp_group.url_prefix == None
    assert bp_group._strict_slashes == None
    assert bp_group.version == None

    bp_group1 = BlueprintGroup("/blueprint", version=1)

# Generated at 2022-06-24 03:31:27.642397
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix='/api', version='v1')
    bpg.extend([bp1, bp2, bp3, bp4])
    bpg_iterator = iter(bpg)
    assert bp1 == next(bpg_iterator)
    assert bp2 == next(bpg_iterator)
    assert bp3 == next(bpg_iterator)
    assert bp4 == next(bpg_iterator)

# Generated at 2022-06-24 03:31:35.594862
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """Test case for method middleware of class BlueprintGroup"""
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bpg = BlueprintGroup("group_test", url_prefix="/bp3")
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware("request")
    def common_middleware(request):
        print("common middleware for bp1 and bp2")

    assert bp1.middlewares[0] == common_middleware
    assert bp2.middlewares[0] == common_middleware

# Generated at 2022-06-24 03:31:42.714283
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    """Unit test for method __len__ of class BlueprintGroup."""
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    
    test_bp_group = BlueprintGroup('/api', 'v1', False)

    test_bp_group.append(bp1)
    test_bp_group.append(bp2)

    assert 2 == len(test_bp_group)
    assert 2 == test_bp_group.__len__()


# Generated at 2022-06-24 03:31:51.286617
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3/<param>')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.extend([bp1, bp2])
    bpg.append(bp3)

    bpg[0]
    assert bpg[0] == bp1

    try:
        del bpg[0]
    except Exception as e:
        assert False

    assert bpg[0] == bp2


# Generated at 2022-06-24 03:31:58.926022
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp5')
    bp5 = Blueprint('bp5', url_prefix='/bp6')
    bpg = BlueprintGroup()
    bpg.append(bp3)
    bpg.append(bp4)
    assert len(bpg.blueprints) == 2
    assert bpg[0] == bp3
    assert bpg[1] == bp4
    bpg.append(bp5)
    assert bpg[2] == bp5
    assert len(bpg.blueprints) == 3


# Generated at 2022-06-24 03:32:02.054287
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    # Setup
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    # Act
    # Assert
    assert isinstance(bpg[0], Blueprint)

# Generated at 2022-06-24 03:32:11.238482
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup('/api', 'v1')

    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    del bpg[3]

    assert len(bpg) is 3
    assert bpg[2] is bp3



# Generated at 2022-06-24 03:32:20.305312
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)

    assert len(bpg) == 3
    assert len(bpg.blueprints) == 3
    assert bpg.version == "v1"
    assert bp1 in bpg
    assert bp2 in bpg
    assert bp3 in bpg
    assert bp4 not in bpg

# Generated at 2022-06-24 03:32:27.005984
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Setup
    app = sanic.Sanic()
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    # Target
    @bpg.middleware('request')
    def bp_group_only_middleware(request):
        print('applied on Blueprint Group : bp1 and bp2')

    # Assertion
    assert bpg.middleware




# Generated at 2022-06-24 03:32:30.983272
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    """
    Test that BlueprintGroup.__delitem__() removes the blueprint that
    we want to delete.
    """
    bpg = BlueprintGroup()
    bpg.append(sanic.Blueprint('bp1'))
    del bpg[0]
    assert len(bpg) == 0


# Generated at 2022-06-24 03:32:41.636886
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    """
    Unit test for method __iter__ of class BlueprintGroup
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    assert len(bpg) == 4
    assert hasattr(bpg, "__iter__") is True
    assert isinstance(bpg, MutableSequence) is True

# Generated at 2022-06-24 03:32:52.133752
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('test_bp1', url_prefix='/bp1')
    bp2 = Blueprint('test_bp2', url_prefix='/bp2')
    bp3 = Blueprint('test_bp3', url_prefix='/bp3')
    bp4 = Blueprint('test_bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix='/api', version='v1')

    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bpg) == 2
    assert bpg._url_prefix == '/api'
    assert bpg.version == 'v1'

    bpg.append(bp3)
    bpg.append(bp4)

    assert len(bpg) == 4

# Generated at 2022-06-24 03:33:01.556576
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    from sanic.blueprints import Blueprint, BlueprintGroup
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')

    bpg = BlueprintGroup()
    assert 0 == len(bpg)
    bpg.append(bp1)
    assert 1 == len(bpg)
    bpg.append(bp2)
    assert 2 == len(bpg)
    bpg.append(bp3)
    assert 3 == len(bpg)

    bpg.remove(bp2)
    assert 2 == len(bpg)



# Generated at 2022-06-24 03:33:08.621612
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(bp1,bp2)

    del bpg[0]

    assert len(bpg) == 1



# Generated at 2022-06-24 03:33:16.367835
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    class App(sanic.Sanic):
        pass

    app = App()
    bp1 = Blueprint("bp1", url_prefix="bp1")
    bp2 = Blueprint("bp2", url_prefix="bp2")
    bp3 = Blueprint("bp3", url_prefix="bp3")
    bp4 = Blueprint("bp4", url_prefix="bp4")
    bpg = BlueprintGroup(bp1, bp2)
    bpg[0] = bp3
    bpg.append(bp4)
    assert bpg[0] is bp3
    assert bpg[1] is bp4


# Generated at 2022-06-24 03:33:25.897089
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():  # noqa
    class TestBlueprint(sanic.Blueprint):
        def __len__(self):
            return 0

    bp_grp1 = BlueprintGroup()
    bp_grp2 = BlueprintGroup()

    bp1 = TestBlueprint ("first", url_prefix="/first")
    bp2 = TestBlueprint ("second", url_prefix="/second")
    bp3 = TestBlueprint ("third", url_prefix="/third")

    bp_grp1.append(bp1)
    bp_grp1.append(bp2)

    assert len(bp_grp1) == 2
    assert bp_grp1._blueprints[0] == bp1
    assert bp_grp1._blueprints[1] == bp2

    bp_grp1.__delitem__

# Generated at 2022-06-24 03:33:26.797785
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    BlueprintGroup()


# Generated at 2022-06-24 03:33:36.156172
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint("bp1", url_prefix="/api/v1")
    bp2 = Blueprint("bp2", url_prefix="/api/v1")
    bp3 = Blueprint("bp3", url_prefix="/api/v2")

    group_1 = Blueprint.group(bp1, bp2, url_prefix="/api", version="v1")
    group_2 = Blueprint.group(bp3, url_prefix="/api", version="v2")
    bpg = BlueprintGroup(url_prefix="/api", version="v2")
    bpg.append(group_1)
    bpg.append(group_2)

    assert len(bpg) == 2, "Length of blueprint group object" \
                          "should be 3"



# Generated at 2022-06-24 03:33:44.135101
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():

    # Arrange
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    def test_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    @bp1.middleware('request')
    def bp1_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp2.middleware('request')
    def bp2_middleware(request):
        print('applied on Blueprint : bp2 Only')

    group = Blueprint.group(bp1, bp2, url_prefix='/api', version='v1.1')

    # Act
    for blueprint in group:
        assert blueprint is not None
        assert blueprint.url_prefix

# Generated at 2022-06-24 03:33:46.968954
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(bp1, bp2)
    return bpg


# Generated at 2022-06-24 03:33:54.908067
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    """
    BlueprintGroup class has a method __len__() which is used to find the length
    of the list of the names of blueprints added in the BlueprintGroup.

    The test case checks whether the length is being calculated correctly.
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2)
    assert len(group) == 2


# Generated at 2022-06-24 03:33:59.141197
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)

    bpg.__delitem__(0)
    assert len(bpg.blueprints) == 1
    assert bpg.blueprints[0] == bp2


# Generated at 2022-06-24 03:34:05.874931
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    import unittest
    from unittest.mock import call

    from sanic.app import Sanic

    from sanic.blueprints import Blueprint

    class TestBlueprintGroup(unittest.TestCase):
        def setUp(self):
            self.app = Sanic('test_BlueprintGroup_middleware')

            self.bp1 = Blueprint('bp1')
            self.bp2 = Blueprint('bp2')

            self.bp3 = Blueprint('bp3')
            self.bp4 = Blueprint('bp4')

            self.bpg1 = BlueprintGroup()
            self.bpg2 = BlueprintGroup()

            self.app.blueprint(self.bp1)
            self.app.blueprint(self.bp2)

            self.app.blueprint(self.bp3)

# Generated at 2022-06-24 03:34:15.734276
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp = Blueprint("bp1", url_prefix='/bp1')
    bp2 = Blueprint("bp2", url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix="/api", version="v1", strict_slashes=True)

    bpg.insert(0, bp)
    bpg.insert(1, bp2)

    assert bpg.url_prefix == "/api"
    assert bpg.version == "v1"
    assert bpg.strict_slashes is True

    assert len(bpg.blueprints) == 2
    assert bpg.blueprints[0] is bp
    assert bpg.blueprints[1] is bp2



# Generated at 2022-06-24 03:34:19.391262
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bpg = BlueprintGroup()
    bpg.extend([bp1, bp2])
    assert len(bpg) == 2


# Generated at 2022-06-24 03:34:25.431961
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    assert bpg.url_prefix == '/api'
    assert bpg._version == "v1"
    assert len(bpg) == 2


# Unit Test for BlueprintGroup.append method

# Generated at 2022-06-24 03:34:31.006276
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    """
    Unit test to ensure that the __setitem__ method of the class
     BlueprintGroup is working as expected.
    """

    # Given Blueprint Object
    bp_obj = Blueprint('bp_obj', url_prefix='/bp_obj')

    # Given Blueprint Group
    bpg_obj = BlueprintGroup()

    # Call the method __setitem__ of class BlueprintGroup
    bpg_obj.__setitem__(0, bp_obj)
    assert(bpg_obj._blueprints[0] == bp_obj)



# Generated at 2022-06-24 03:34:42.684768
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    # GIVEN
    #   BlueprintGroup object with Blueprints
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bp_group = BlueprintGroup(bp1, bp2)
    bp_group.append(bp3)
    bp_group.insert(1, bp4)

    # WHEN
    #   BlueprintGroup object is iterated
    blueprints = [b for b in bp_group]

    # THEN
    #   BlueprintGroup object is equal to list of Blueprints

# Generated at 2022-06-24 03:34:51.071613
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bpg) == 2
    assert bpg.blueprints[0].name == 'bp1'
    assert bpg.version == 'v1'
    assert bpg.url_prefix == '/api'


# Unit Test for insert method of class BlueprintGroup