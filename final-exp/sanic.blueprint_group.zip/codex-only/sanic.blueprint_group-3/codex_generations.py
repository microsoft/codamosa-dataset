

# Generated at 2022-06-24 03:25:04.096321
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    class Test(unittest.TestCase):

        def test_single_middleware(self):
            # Initialize
            app = sanic.Sanic("test_middleware")
            bp1 = Blueprint("bp1")

            # Create a test instance and see if the middleware works
            @bp1.middleware("request")
            @bp1.middleware("response")
            def test_middleware(request, response):
                pass

            # Assert that the method has two middlewares
            self.assertEqual(
                len(bp1.middlewares["request"]), 1, "The method should have one middleware"
            )
            self.assertEqual(
                len(bp1.middlewares["response"]), 1, "The method should have one middleware"
            )

            # Create a BlueprintGroup and add

# Generated at 2022-06-24 03:25:13.351294
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp1_middleware_name = 'bp1_middleware'
    bp2_middleware_name = 'bp2_middleware'
    bp3_middleware_name = 'bp3_middleware'
    bp4_middleware_name = 'bp4_middleware'

    @bp1.middleware('request')
    async def bp1_middleware(request):
        setattr(request, bp1_middleware_name, True)

# Generated at 2022-06-24 03:25:15.131531
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    ...  # TODO



# Generated at 2022-06-24 03:25:17.303478
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    print(BlueprintGroup(strict_slashes=True))


# Generated at 2022-06-24 03:25:24.893349
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    app = Sanic(__name__)
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.insert(0, bp1)
    bpg.insert(1, bp2)
    assert bpg.url_prefix == "/api"
    assert bpg.version == "v1"


# Generated at 2022-06-24 03:25:32.017611
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    assert bpg[0] == bp1
    assert bpg[1] == bp2


# Generated at 2022-06-24 03:25:41.734993
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    # Given the BlueprintGroup is initialized
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')

    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')

    bp3 = sanic.Blueprint('bp3', url_prefix='/bp4')
    bp4 = sanic.Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    group = BlueprintGroup()

    group.append(bp1)
    group.append(bp2)

    # When I retrieve a blueprint item in group by index value
    blueprint1 = group[0]

    # Then it should return the blueprint successfully
    assert blueprint1 == bp1


# Generated at 2022-06-24 03:25:46.610548
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint = Blueprint("bp")
    blueprint_group = BlueprintGroup()
    blueprint_group.append(blueprint)
    @blueprint_group.middleware("request")
    async def bp_middleware(request):
        pass
    assert blueprint.middlewares["request"][0] == bp_middleware



# Generated at 2022-06-24 03:25:53.899951
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint("bp1", url_prefix='/bp1')
    bp2 = Blueprint("bp2", url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix='/api', version='v1')

    bp3 = Blueprint("bp3", url_prefix='/bp3')
    bp4 = Blueprint("bp4", url_prefix='/bp4')
    bpg2 = BlueprintGroup(url_prefix='/api', version='v1')

    bpg.extend([bp1, bp2])
    bpg2.extend([bp3, bp4, bpg])

    assert(len(bpg) == 2)
    assert(len(bpg2) == 5)


# Generated at 2022-06-24 03:26:00.938958
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()
    bpg.append(bp1)

    bpg[0] = bp2
    assert bpg[0].name == bp2.name

    bpg[:] = [bp1]
    assert len(bpg) == 1


# Generated at 2022-06-24 03:26:06.134726
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Initialize a Blueprint Group
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix='/bpg')
    bpg.extend([bp1, bp2])

    # Test BlueprintGroup.middleware
    bpg.middleware()(lambda request: None)
    assert len(bp1.middlewares) == 1
    assert len(bp2.middlewares) == 1


# Generated at 2022-06-24 03:26:07.803800
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    #Unit test for method __setitem__ of class BlueprintGroup
    pass


# Generated at 2022-06-24 03:26:12.991156
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    This testcase is aiming at validating the
    :class:`BlueprintGroup.middleware` method correctness
    """

    from ...definitions import Blueprint as SanicBlueprint
    from sanic.response import json
    from sanic.router import RouteExists
    from unittest.mock import patch, Mock
    import functools


    # Mock out the Sanic Blueprint Class to be able to intercept any
    # operation that it's doing internally and use the same for the
    # validation of the intended behavior.
    with patch.object(SanicBlueprint, "middleware") as m:
        bp1 = SanicBlueprint("bp1")
        bp2 = SanicBlueprint("bp2")
        bpg = BlueprintGroup()
        bpg.append(bp1)

# Generated at 2022-06-24 03:26:22.234732
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    import unittest.mock

    # Create a BlueprintGroup object
    bluprint_group_obj = BlueprintGroup()

    # Create a mock object for the Blueprint class
    mock_Blueprint = unittest.mock.MagicMock(name="Blueprint")

    # Store the mocked object in the `blueprints` list
    bluprint_group_obj._blueprints = [mock_Blueprint]

    # Remove an item from the list
    del bluprint_group_obj[0]

    # Ensure that the del operation worked
    assert len(bluprint_group_obj._blueprints) == 0


# Generated at 2022-06-24 03:26:26.449461
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    url_prefix = "/test"
    version = "v1"
    strict_slashes = True
    bp_group = BlueprintGroup(
        url_prefix=url_prefix, version=version, strict_slashes=strict_slashes
    )

    assert bp_group._url_prefix == url_prefix
    assert bp_group._version == version
    assert bp_group._strict_slashes == strict_slashes


# Generated at 2022-06-24 03:26:35.290261
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    """Test if blueprint group is able to return right blueprint by index"""
    bp1 = Blueprint('bp1', '/bp1')
    bp2 = Blueprint('bp2', '/bp2')
    bp3 = Blueprint('bp3', '/bp3')
    bp4 = Blueprint('bp4', '/bp4')
    bpg = BlueprintGroup(bp1, bp2, bp3, bp4)
    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert bpg[2] == bp3
    assert bpg[3] == bp4



# Generated at 2022-06-24 03:26:36.124801
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    pass

# Generated at 2022-06-24 03:26:43.768278
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    app = sanic.Sanic(__name__)
    app.blueprint(BlueprintGroup)
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    del bpg[0]
    assert len(bpg) == 3

# Generated at 2022-06-24 03:26:50.176286
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    # Arrange
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    # Act
    bpg.__delitem__(0)
    # Assert
    assert len(bpg.blueprints) == 1

# Generated at 2022-06-24 03:26:54.010317
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)
    assert len(group) == 2
    assert group.blueprints == [bp1, bp2]


# Generated at 2022-06-24 03:27:03.816286
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    """
    Test for method `__getitem__` of class `BlueprintGroup`
    """
    url_prefix_group = "url_prefix_group"
    url_prefix_blueprint1 = "url_prefix_blueprint1"
    url_prefix_blueprint2 = "url_prefix_blueprint2"
    url_prefix_blueprint3 = "url_prefix_blueprint3"
    bp1 = Blueprint('bp1', url_prefix=url_prefix_blueprint1)
    bp2 = Blueprint('bp2', url_prefix=url_prefix_blueprint2)
    bp3 = Blueprint('bp3', url_prefix=url_prefix_blueprint3)

    bp_group = BlueprintGroup(url_prefix=url_prefix_group)
    bp_group.append(bp1)
    b

# Generated at 2022-06-24 03:27:11.186098
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bpg) == 2
    assert bpg[0] == bp1
    assert bpg[1] == bp2


# Generated at 2022-06-24 03:27:19.020450
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    bpg = BlueprintGroup("/api", "v1", None)
    bpg.append(bp1)
    assert bpg.url_prefix == '/api'
    assert bp1.url_prefix == '/api/bp1'

    bpg.append(bp2)
    assert bpg.url_prefix == '/api'
    assert bp2.url_prefix == '/api/bp2'



# Generated at 2022-06-24 03:27:26.253671
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    assert bpg._url_prefix == "/api"
    assert bpg._version == "v1"
    assert bpg._strict_slashes is None
    bpg = BlueprintGroup()
    assert bpg._url_prefix is None
    assert bpg._version is None
    assert bpg._strict_slashes is None


# Generated at 2022-06-24 03:27:30.529146
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bpg = BlueprintGroup()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg) == 2


# Generated at 2022-06-24 03:27:37.569326
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    class sanic(object):
        class Blueprint:
            def __init__(self, *args, **kwargs):
                self.url_prefix = kwargs.get("url_prefix")
                self._strict_slashes = kwargs.get("strict_slashes")
                self._version = kwargs.get("version")
                self.name = kwargs.get("name")

            @property
            def strict_slashes(self):
                return self._strict_slashes

            @property
            def version(self):
                return self._version

    bp1 = sanic.Blueprint(name="bp1", url_prefix="/bp1")
    bp2 = sanic.Blueprint(name="bp2", url_prefix="/bp2")

# Generated at 2022-06-24 03:27:43.242667
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    """
    test: BlueprintGroup()
    expected: BlueprintGroup.__len__
    """
    bp_group = BlueprintGroup()
    assert len(bp_group) == 0
    bp_group.append(sanic.Blueprint('test_app'))
    assert len(bp_group) == 1


# Generated at 2022-06-24 03:27:51.483469
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', version="v1", url_prefix='/bp1')
    bp2 = Blueprint('bp2', version="v1", url_prefix='/bp2')
    bp3 = Blueprint('bp3', version="v1", url_prefix='/bp3')
    bp4 = Blueprint('bp4', version="v1", url_prefix='/bp4')

    group1 = Blueprint.group(bp1, bp2)
    group2 = Blueprint.group(group1, bp3, bp4)

    assert len(group2) == 4


# Generated at 2022-06-24 03:27:55.217433
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    # Set up Blueprint
    bp = Blueprint('bp', url_prefix='/bp')
    # Set up BlueprintGroup
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    # Set up BlueprintGroup
    bpg2 = BlueprintGroup(bp, url_prefix="/api", version="v1")
    # Assertion
    assert bpg2[0] == bp


# Generated at 2022-06-24 03:27:56.029081
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    pass


# Generated at 2022-06-24 03:28:06.460418
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bp_group_1 = BlueprintGroup(url_prefix='/api/v1')
    bp_group_1.append(bp1)
    bp_group_1.append(bp2)

    bp_group_2 = BlueprintGroup(url_prefix='/api/v2')
    bp_group_2.append(bp3)
    bp_group_2.append(bp4)

    assert bp_group_1[0] == bp1
    assert bp_group_

# Generated at 2022-06-24 03:28:10.799018
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint = Blueprint(__name__, url_prefix='/bp')

    blueprintGroup = BlueprintGroup(url_prefix='/bpGroup')

    blueprintGroup.append(blueprint)

    blueprintGroup.append(blueprint)

    assert len(blueprintGroup) == 2



# Generated at 2022-06-24 03:28:17.497284
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert(bpg[0]==bp1)
    bpg[0] = bp2
    assert(bpg[0]==bp2)


# Generated at 2022-06-24 03:28:26.084970
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    bp1 = Blueprint("bp1", url_prefix="/bp1", strict_slashes=False)
    bp2 = Blueprint("bp2", url_prefix="/bp2", strict_slashes=False)

    group = Blueprint.group(bp1, bp2)

    @group.middleware('request')
    def group_middleware(request):
        request['bp1'] = 'BP1'
        request['bp2'] = 'BP2'

    @bp1.route('/')
    async def test(request):
        return text('bp1')

    @bp2.route('/')
    async def test(request):
        return text('bp2')

    app = sanic.Sanic()

    app.blueprint(bp1)
    app.blueprint(bp2)
    app.blueprint(group)

# Generated at 2022-06-24 03:28:36.632085
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    group = Blueprint.group(bp1, bp2)

    @group.middleware('request')
    async def group_middleware(request):
        return 'common middleware applied for both bp1 and bp2'

    @bpg.middleware('request')
    async def bpg_middleware(request):
        return 'common middleware applied for both bp3 and bp4'


# Generated at 2022-06-24 03:28:47.432839
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    bpg[0] = bp1
    bpg[1] = bp2
    print(bpg.blueprints)
    assert len(bpg.blueprints) == 2
    
    print("Passed test_BlueprintGroup___setitem__")

if __name__=='__main__':
    test_BlueprintGroup___setitem__()

# Generated at 2022-06-24 03:28:55.503108
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    """
    This method is used to test if the append method of BlueprintGroup
    class actually adds the blueprint to the list of Blueprints
    associated with the Blueprint Group.

    :return:
    """
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg._blueprints == [bp1, bp2]
    assert bp1.url_prefix == "/api/bp1"
    assert bp2.url_prefix == "/api/bp2"
    assert bp1.version == "v1"
    assert b

# Generated at 2022-06-24 03:29:03.544463
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    """
    Test method __getitem__(self, item)

    Blueprint Group: Test method __getitem__(self, item)
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    group = Blueprint.group(bp1, bp2)
    bpg = BlueprintGroup(bp3, bp4)
    assert bp1 == group[0]
    assert bp3 == bpg[0]
    try:
        bpg[2]
    except IndexError as e:
        pass


# Generated at 2022-06-24 03:29:10.514837
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    # GIVEN a blueprint group

    # WHEN we create one
    url_prefix = 'test/blueprint'
    version = 1.0
    strict_slashes = True
    bpg = BlueprintGroup(
        url_prefix=url_prefix,
        version=version,
        strict_slashes=strict_slashes
    )

    # THEN the blueprint group instance is created
    assert bpg.url_prefix == url_prefix
    assert bpg.version == version
    assert bpg.strict_slashes == strict_slashes



# Generated at 2022-06-24 03:29:17.279105
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    temp_group = BlueprintGroup()
    assert len(temp_group) == 0

    # assert blueprint group is empty with length 0
    temp_group.insert(0, bp1)
    assert len(temp_group) == 1

    temp_group.insert(0, bp2)
    assert len(temp_group) == 2
    assert temp_group[0].url_prefix == '/bp2'
    assert temp_group[1].url_prefix == '/bp1'



# Generated at 2022-06-24 03:29:20.957583
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2)
    assert len(group) == 2, "Length of blueprint group must be 2"

# Generated at 2022-06-24 03:29:29.500266
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    group = Blueprint.group(bp1, bp2)
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    group[0] = bp3
    group[1] = bp4

    assert group[0].url_prefix == "/api/bp4"
    assert group[0].version == "v1"

    bpg[0] = bp1
    bpg[1] = bp2

    assert bpg[0].url_prefix

# Generated at 2022-06-24 03:29:40.703945
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bp3 = sanic.Blueprint('bp3', url_prefix='/bp3')
    bp4 = sanic.Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix='/bpg')
    bpg_updated = BlueprintGroup(url_prefix='/bpg')
    bpg.append(bp3)
    bpg.append(bp4)
    bpg_updated.append(bp1)
    bpg_updated.append(bp2)

    bpg[0] = bp1
    bpg[1] = bp2
    assert bpg == bpg

# Generated at 2022-06-24 03:29:48.729801
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    app = sanic.Sanic('test_BlueprintGroup_append')
    bp = Blueprint(url_prefix='/v1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = BlueprintGroup(bp, bp2)

    def test_bp_append_function(bp):
        assert isinstance(bp, Blueprint)
        assert bp.url_prefix == '/v1'

    def test_bp2_append_function(bp2):
        assert isinstance(bp2, Blueprint)
        assert bp2.url_prefix == '/bp2'

    @bp.route('/test', methods=['GET'])
    async def test_bp_route(request):
        return text('Success')


# Generated at 2022-06-24 03:29:49.618448
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    assert BlueprintGroup().__len__() == 0

# Generated at 2022-06-24 03:29:57.386422
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    assert bpg.append(bp1) is None
    assert bpg[0] is bp1
    bpg.append(bp2)
    assert bpg[0] is bp1
    assert bpg[1] is bp2
    assert len(bpg) == 2

# Generated at 2022-06-24 03:30:03.511077
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    # Check the length of bpg, it should be 2
    assert len(bpg) == 2, "Length of bpg is not 2"


# Generated at 2022-06-24 03:30:09.221814
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    @bp3.middleware('request')
    async def bp3_only_middleware(request):
        print('applied on Blueprint : bp3 Only')

    @bp4.middleware('request')
    async def bp4_only_middleware(request):
        print('applied on Blueprint : bp4 Only')

    @bpg.middleware('request')
    async def bpg_middleware(request):
        print('applied on Blueprint Group : bpg')
    
    assert len(bp3.middleware_functions) == 2
    assert len(bp4.middleware_functions) == 2

    bpg.middleware(bp1_only_middleware)
    bpg.middleware(bp2_only_middleware)
    assert len(bp3.middleware_functions) == 4
   

# Generated at 2022-06-24 03:30:18.714943
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # GIVEN
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bpg = BlueprintGroup("/group", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)

    # WHEN
    @bpg.middleware("request")
    async def common_middleware(request):
        print("Middleware for Blueprint Group")

    @bp1.middleware("request")
    async def bp1_middleware():
        print("Middleware for Blueprint bp1")
    # THEN
    assert bp2.middlewares["request"][0] == common_middleware
    assert bp1.middlewares["request"][0] == common_middleware
    assert bp1

# Generated at 2022-06-24 03:30:26.674933
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bp3 = sanic.Blueprint('bp3', url_prefix='/bp3')

    @bp3.route('/', methods=['GET'])
    async def bp3_fn(request):
        return sanic.response.text('bp3')
    @bp2.route('/', methods=['GET'])
    async def bp2_fn(request):
        return sanic.response.text('bp2')
    @bp1.route('/', methods=['GET'])
    async def bp1_fn(request):
        return sanic.response.text('bp1')

    # Blueprint Group
    b

# Generated at 2022-06-24 03:30:31.030792
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg) == 2


# Generated at 2022-06-24 03:30:41.439162
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bp3 = Blueprint('bp3')
    bp4 = Blueprint('bp4')

    bpg1 = BlueprintGroup('/api/v1/', version='v1')
    bpg2 = BlueprintGroup('/api/v2/', version='v2')

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg3 = BlueprintGroup(bp3, bp4, url_prefix='/api/v3', version='v3')

    assert bpg1._

# Generated at 2022-06-24 03:30:44.654230
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():

    bp = Blueprint('bp', url_prefix='/bp')
    bg = BlueprintGroup()
    bg.append(bp)

    assert len(bg._blueprints) == 1
    assert bg._blueprints[0] == bp



# Generated at 2022-06-24 03:30:52.201687
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)



# Generated at 2022-06-24 03:30:55.892803
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    assert bpg.blueprints == [bp1]

# Generated at 2022-06-24 03:31:02.382772
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bp3 = Blueprint('bp3')
    bp4 = Blueprint('bp4')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg) == 2
    bpg.append(bp3)
    bpg.append(bp4)
    assert len(bpg) == 4


# Generated at 2022-06-24 03:31:03.008937
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    pass



# Generated at 2022-06-24 03:31:07.522388
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2)
    assert len(bpg) == 2


# Generated at 2022-06-24 03:31:15.834411
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    """Unit test for method __setitem__ of class BlueprintGroup"""
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg[0] = bp2
    bpg[1] = bp1

    assert bpg[0].name == 'bp2'
    assert bpg[1].name == 'bp1'


# Generated at 2022-06-24 03:31:24.376211
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-24 03:31:27.742365
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bpg = BlueprintGroup()
    bpg.extend([sanic.Blueprint("dummy1"), sanic.Blueprint("dummy1")])
    assert list(bpg) == bpg.blueprints
    for item in bpg:
        assert isinstance(item, sanic.Blueprint)



# Generated at 2022-06-24 03:31:37.595301
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
 
    url_prefix = f'/api'

    # Blueprint Creation
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')


    @bp1.route('/')
    async def bp1_route(request):
        return 'bp1'

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return f'bp2 {param}'

    @bp3.route('/')
    async def bp3_route(request):
        return 'bp3'


# Generated at 2022-06-24 03:31:44.989847
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    group = BlueprintGroup() 
    group.append(Blueprint('bp1', url_prefix='/bp1'))
    group.append(Blueprint('bp2', url_prefix='/bp2'))
    assert(len(group) == 2)
    assert(group[1].url_prefix == '/bp2')
    new_bp = Blueprint('bp3', url_prefix='/bp3')
    group[1] = new_bp
    assert(group[1] == new_bp)
    assert(group[1].url_prefix == '/bp3')


# Generated at 2022-06-24 03:31:49.710123
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2)
    assert len(group) == 2

    del group[1]
    assert len(group) == 1


# Generated at 2022-06-24 03:31:56.132026
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp3', url_prefix='/bp4')
    bpg = BlueprintGroup('/api', version='v1', strict_slashes=True)
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    assert bpg.url_prefix == '/api'
    assert bpg.version == 'v1'
    assert bpg.strict_slashes is True
    assert bpg[0].url_prefix == '/api/bp1'
    assert bpg

# Generated at 2022-06-24 03:32:06.584269
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # pylint:disable=unused-argument,unused-variable

    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    bpg = BlueprintGroup(bp1, bp2, url_prefix="/test")

    @bp1.middleware("request")
    def bp1_middleware(request):
        pass

    @bp2.middleware("request")
    def bp2_middleware(request):
        pass

    @bpg.middleware("request")
    def bpg_middleware(request):
        pass

    bp1_middleware_calls = bp1.middlewares["request"].copy()

# Generated at 2022-06-24 03:32:13.973238
# Unit test for method middleware of class BlueprintGroup

# Generated at 2022-06-24 03:32:20.003731
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group = BlueprintGroup()
    blueprint_group.append(
        sanic.Blueprint(
            "test_Blueprint1",
            url_prefix="/test_Blueprint1",
            version="test_Blueprint_v1",
            strict_slashes=True,
        )
    )
    blueprint_group.append(
        sanic.Blueprint(
            "test_Blueprint2",
            url_prefix="/test_Blueprint2",
            version="test_Blueprint_v2",
            strict_slashes=False,
        )
    )
    assert len(blueprint_group) == 2


# Generated at 2022-06-24 03:32:25.324734
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    bpg = BlueprintGroup(bp1, bp2)

    bp_set = set()
    for bp in bpg:
        bp_set.add(bp)

    assert bp_set == set([bp1, bp2])



# Generated at 2022-06-24 03:32:31.889708
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    assert bpg[0] == bp3
    assert bpg[1] == bp4

# Generated at 2022-06-24 03:32:38.514452
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(bp2)
    bpg.append(bp1)

    assert len(bpg.blueprints) == 2



# Generated at 2022-06-24 03:32:48.025979
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bp_group1 = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    bp_group2 = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    assert len(bp_group1) == 2
    assert len(bp_group2) == 2


# Generated at 2022-06-24 03:32:57.448771
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")

    bpg = BlueprintGroup(url_prefix="/test")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)

    assert len(bpg) == 3
    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert bpg[2] == bp3

    bpg[1] = bp4

    assert len(bpg) == 3
    assert bpg[0] == bp1
    assert bpg

# Generated at 2022-06-24 03:33:01.272865
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    @Blueprint.group(url_prefix="/api", version="v1")
    def bp_group():
        pass
    assert isinstance(bp_group(), BlueprintGroup)

# Generated at 2022-06-24 03:33:11.024700
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")

    group = BlueprintGroup(bp1, bp2, bp3, bp4)

    assert isinstance(group[0], Blueprint)
    assert group[0].url_prefix == "/bp1"
    assert group[1].url_prefix == "/bp2"
    assert group[2].url_prefix == "/bp3"
    assert group[3].url_prefix == "/bp4"


# Generated at 2022-06-24 03:33:20.628505
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    assert len(bpg) == 2
    assert bpg[0] == bp3 and bpg[1] == bp4
    assert bpg.url_prefix == "/api"
    assert bpg.version == "v1"


# Generated at 2022-06-24 03:33:31.743492
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(
        url_prefix="/api", version="v1")
    bpg.insert(0, bp1)
    bpg.insert(0, bp2)
    bpg.insert(0, bp3)
    bpg.insert(0, bp4)
    assert bpg[0].url_prefix == '/api/bp4'
    assert bpg[0].version == 'v1'
    assert bpg[0].strict_slashes == None
    assert b

# Generated at 2022-06-24 03:33:37.367914
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    # Create Blueprint group
    bpg = BlueprintGroup(url_prefix="/api")

    # Create Blueprints to add to group
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")

    # Add two Blueprints to Blueprint Group
    bpg.append(bp1)
    bpg.append(bp2)

    # Check if BlueprintGroup.__iter__() returns an iterator
    assert isinstance(bpg.__iter__(), types.GeneratorType)



# Generated at 2022-06-24 03:33:47.330236
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')

    bpg = BlueprintGroup('/api', 'v1')
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)

    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert bpg[2] == bp3
    del bpg[1]

    assert bpg[0] == bp1
    assert bpg[1] == bp3


# Generated at 2022-06-24 03:33:54.734419
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    from unittest import mock
    from . import Blueprint
    Blueprint.group = mock.MagicMock(return_value="Group")
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    # Testing Blueprint Group with Blueprint object
    blueprint_group = BlueprintGroup(bp1, bp2)
    blueprint_group.append(bp3)
    blueprint_group.insert(0, bp4)

    # Ensure that the length of blueprint group is 4
    assert len(blueprint_group) == 4

    # Iterating over the blueprint group

# Generated at 2022-06-24 03:34:04.032269
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix='/api', version='v1')
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg.blueprints) == 2
    assert bpg.blueprints[0] == bp1
    assert bpg.blueprints[1] == bp2
    assert bpg.blueprints[0].url_prefix == '/api/bp1'
    assert bpg.blueprints[1].url_prefix == '/api/bp2'
    assert bpg.blueprints[0].version == 'v1'
    assert bpg.blueprints[1].version == 'v1'

#

# Generated at 2022-06-24 03:34:08.144417
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)

    assert len(bpg) == 1


# Generated at 2022-06-24 03:34:19.240297
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Tests the BlueprintGroup.middleware method
    """
    class TestApp(sanic.Sanic):
        pass

    test_app = TestApp()

    bp1 = Blueprint("test", url_prefix="/test")

    @bp1.middleware("request")
    async def common_blueprint_middleware1(request):
        pass

    @bp1.middleware("request")
    async def common_blueprint_middleware2(request):
        pass

    bpg1 = BlueprintGroup("/api", version="v1")
    bpg1.append(bp1)

    @bpg1.middleware("request")
    async def common_blueprint_group_middleware(request):
        pass

    test_app.blueprint(bpg1)

# Generated at 2022-06-24 03:34:28.667684
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    class App(sanic.Sanic):
        pass

    app = App()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix='/a')
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    assert bpg[1] == bp2
    assert bpg[2] == bp3
    assert bpg[-1] == bp4

# Generated at 2022-06-24 03:34:39.895782
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1', version='v1', strict_slashes=False)
    bp2 = Blueprint('bp2', url_prefix='/bp2', version='v1', strict_slashes=False)

    bp3 = Blueprint('bp3', url_prefix='/bp3', version='v1', strict_slashes=False)
    bp4 = Blueprint('bp4', url_prefix='/bp4', version='v1', strict_slashes=False)

    bpg = BlueprintGroup(url_prefix="/api", version="v1", strict_slashes=False)
    assert bpg.url_prefix == '/api'
    assert bpg.version == 'v1'
    assert bpg.strict_slashes == False

    bpg.append(bp1)
   

# Generated at 2022-06-24 03:34:48.634867
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    @sanic.blueprint.Blueprint.group(url_prefix="/api", version="v1")
    def bpg1():
        pass

    @bpg1.blueprint()
    def bp1():
        pass

    @bpg1.blueprint()
    def bp2():
        pass

    bp3 = sanic.blueprints.Blueprint('bp3')
    bp4 = sanic.blueprints.Blueprint('bp4')
    bpg2 = BlueprintGroup(bp3, bp4, url_prefix="/api/v1")

    assert bp1 in bpg1
    assert bp2 in bpg1
    assert bp3 in bpg2
    assert bp4 in bpg2

    # Ensure we can iterate over it
    assert iter(bpg1) is not None

   

# Generated at 2022-06-24 03:34:56.525018
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    test_app = sanic.Sanic("test_sanic_Blueprint_group")

    @test_app.blueprint.group(url_prefix="/group", version=2)
    def test_blueprint():
        pass

    @test_app.blueprint.route("/test")
    async def test_handler(request):
        return text("This is test handler")

    @test_blueprint.middleware("request")
    async def middleware_method(request):
        pass

    assert len(test_blueprint.blueprints) == 1
    assert test_blueprint.blueprints[0].middlewares["request"][0] == middleware_method
