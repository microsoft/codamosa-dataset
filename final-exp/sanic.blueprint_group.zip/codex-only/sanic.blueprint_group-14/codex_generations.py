

# Generated at 2022-06-24 03:25:02.202938
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    class TempApp(object):
        pass
    temp_app = TempApp()

    blueprint1 = sanic.Blueprint('blueprint1', url_prefix='/bl1')
    blueprint2 = sanic.Blueprint('blueprint2', url_prefix='/bl2')
    blueprint_group = BlueprintGroup(
        url_prefix='/v1',
        strict_slashes=False,
        version=1.0
    )

    blueprint_group.append(blueprint1)
    blueprint_group.append(blueprint2)

    assert blueprint_group[0] == blueprint1
    assert blueprint_group.blueprints[1] == blueprint2


# Generated at 2022-06-24 03:25:10.361571
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bp_group = BlueprintGroup()
    bp_group.append(bp1)
    bp_group.append(bp2)

    @bp_group.middleware('request')
    async def test_middleware(request):
        return True

    # assert if middleware function has been registered in both blueprints
    assert test_middleware.__name__ in bp1.middlewares['request']
    assert test_middleware.__name__ in bp2.middlewares['request']



# Generated at 2022-06-24 03:25:18.205671
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    @bp1.route("/", methods=["PUT"])
    async def bp1_put(request):
        return text("bp1")

    @bp2.route("/", methods=["POST"])
    async def bp2_post(request):
        return text("bp2")

    def test_app(app):
        @app.route("/")
        async def handler(request):
            return text("OK")

        @app.websocket("/ws")
        async def ws(request, ws):
            yield from ws.recv()


# Generated at 2022-06-24 03:25:29.004166
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    def my_middleware(request):
        return None

    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bp3 = Blueprint('bp3')
    bp4 = Blueprint('bp4')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    bpg.middleware(my_middleware)

    assert my_middleware in bp1._middlewares['request']
    assert my_middleware in bp2._middlewares['request']
    assert my_middleware in bp3._middlewares['request']
    assert my_middleware in bp4._middlewares['request']


# Generated at 2022-06-24 03:25:34.224297
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()

    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bpg) == 2


# Generated at 2022-06-24 03:25:43.399006
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint("bp1", url_prefix="")
    bp2 = Blueprint("bp2", url_prefix="")
    bp3 = Blueprint("bp3", url_prefix="")

    blueprints = BlueprintGroup(url_prefix="", version="v1")
    blueprints.append(bp1)
    blueprints.append(bp2)

    assert (blueprints.version == "v1")
    assert (blueprints.strict_slashes is None)

    assert (bp1.version == "v1")
    assert (bp2.version == "v1")
    assert (bp3.version == "v1")

    assert (bp1.strict_slashes is None)
    assert (bp2.strict_slashes is None)
    assert (bp3.strict_slashes is None)

   

# Generated at 2022-06-24 03:25:44.469096
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    pass



# Generated at 2022-06-24 03:25:49.535203
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @sanic.blueprint.middleware('request')
    async def middleware(request):
        pass
    @sanic.blueprint.middleware('response')
    async def middleware(request):
        pass
    @sanic.blueprint.middleware('exception')
    async def middleware(request):
        pass
    assert middleware(None)



# Generated at 2022-06-24 03:25:54.132414
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp3 = sanic.Blueprint('bp3', url_prefix='/bp3')
    bp4 = sanic.Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api")
    bpg.append(bp3)
    bpg.append(bp4)

    assert bpg.blueprints[0] == bp3
    assert bpg.blueprints[1] == bp4


# Generated at 2022-06-24 03:26:01.731078
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    """
    Test method `BlueprintGroup.append` to ensure that
    we can call the `BlueprintGroup` append functionality

    :return: None
    """
    bp = Blueprint('test_BlueprintGroup_append', url_prefix='/path1')
    bp_group = BlueprintGroup(url_prefix='/api')
    bp_group.append(bp)
    assert len(bp_group.blueprints) == 1
    assert bp_group.blueprints == [bp]


# Generated at 2022-06-24 03:26:09.005118
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')

    bpg1 = BlueprintGroup(url_prefix='/api')
    bpg2 = BlueprintGroup(url_prefix='/api')

    assert bpg1.url_prefix == "/api"
    assert bpg2.url_prefix == "/api"

    bpg1.append(bp1)
    bpg1.append(bp2)

    bpg

# Generated at 2022-06-24 03:26:13.582005
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg) is 2

# Generated at 2022-06-24 03:26:22.183621
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    assert len(bpg) == 4

# Generated at 2022-06-24 03:26:31.940917
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    # setup
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    # action
    bpg.append(bp3)
    bpg.append(bp4)
    bpg.append(bp1)
    bpg.append(bp2)

    # assert
    assert len(bpg) == 4

    # action
    del bpg[0]

    # assert
    assert len(bpg) == 3

    # action
    del bpg[2]

    # assert


# Generated at 2022-06-24 03:26:33.675290
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    Blueprint.group(Blueprint('bp1', url_prefix='/bp1'), Blueprint('bp2', url_prefix='/bp2'))


# Generated at 2022-06-24 03:26:43.123869
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_ins = BlueprintGroup(url_prefix='/v1', version='v1', strict_slashes=True)
    blueprint_group_ins._blueprints = [
        Blueprint('test_bp1', url_prefix='/test_bp1'),
        Blueprint('test_bp2', url_prefix='/test_bp2'),
        Blueprint('test_bp3', url_prefix='/test_bp3'),
        Blueprint('test_bp4', url_prefix='/test_bp4'),
    ]

    assert blueprint_group_ins[0].name == 'test_bp1'
    assert blueprint_group_ins[1].name == 'test_bp2'
    assert blueprint_group_ins[2].name == 'test_bp3'
    assert blueprint_group_ins[3].name == 'test_bp4'

   

# Generated at 2022-06-24 03:26:54.009882
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint("bp1", url_prefix="bp1", version="v1")
    bp2 = Blueprint("bp2", url_prefix="bp2")
    bp3 = Blueprint("bp3", url_prefix="bp3", strict_slashes=True)

    # Check if the object creation goes as expected
    bpg = BlueprintGroup("api", "v2", strict_slashes=False)
    assert bpg.url_prefix == "api"
    assert bpg.version == "v2"
    assert bpg.strict_slashes == False

    # Append 3 more blueprints to the Blueprint Group
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)

    # Get the blueprint list from the blueprint group

# Generated at 2022-06-24 03:27:01.900245
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')
    bp7 = Blueprint('bp7', url_prefix='/bp7')
    bp8 = Blueprint('bp8', url_prefix='/bp8')
    bp9 = Blueprint('bp9', url_prefix='/bp9')
    bp0 = Blueprint('bp0', url_prefix='/bp0')


# Generated at 2022-06-24 03:27:13.165348
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    url_prefix1 = "url1"
    url_prefix2 = "url2"
    version = "v1"
    strict_slashes=True

    bp1 = Blueprint("bp1", url_prefix=url_prefix1)
    bp2 = Blueprint("bp2", url_prefix=url_prefix2)

    bp3 = Blueprint("bp3", url_prefix=url_prefix1)
    bp4 = Blueprint("bp4", url_prefix=url_prefix2)

    bpg = BlueprintGroup(url_prefix="url", version=version, strict_slashes=strict_slashes)

    bpg.append(bp1)
    bpg.append(bp2)

    bpg.append(bp3)
    bpg.append(bp4)

    del bpg[0]

    assert bpg

# Generated at 2022-06-24 03:27:17.564772
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()
    assert len(bpg) == 0

    bpg._blueprints = [bp1, bp2]
    assert len(bpg) == 2


# Generated at 2022-06-24 03:27:24.846628
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    from sanic.blueprints import Blueprint

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg) == 4
    assert bpg.url_prefix == "/api"
    assert bpg.version == "v1"
    del bpg[0]
    assert len(bpg) == 3
    assert bpg[0] == bp3

# Generated at 2022-06-24 03:27:32.107876
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    """
    Unit test for testing the implementation of append functionality of
    class BlueprintGroup.
    """
    bp1 = Blueprint(name='bp1', url_prefix='/bp1')
    bp2 = Blueprint(name='bp2', url_prefix='/bp2')
    bp_group = BlueprintGroup(url_prefix='/api', version=1)
    bp_group.append(bp1)
    bp_group.append(bp2)
    assert bp1.url_prefix == '/api/bp1'
    assert bp2.url_prefix == '/api/bp2'
    assert bp1.version == 1
    assert bp2.version == 1
    assert len(bp_group) == 2
    assert bp_group[0].name == 'bp1'

# Generated at 2022-06-24 03:27:41.023546
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bp5 = Blueprint('bp4', url_prefix='/bp4')
    bp6 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    bpg2 = BlueprintGroup(bp5, bp6, url_prefix="/api", version="v1")

    group = BlueprintGroup(bp1, bp2)

# Generated at 2022-06-24 03:27:41.903078
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    pass


# Generated at 2022-06-24 03:27:49.182206
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    # Creating BlueprintGroup
    url_prefix = "url_prefix"
    version = "version"
    strict_slashes = False
    bpGroup = BlueprintGroup(
        url_prefix=url_prefix, version=version, strict_slashes=strict_slashes
    )

    # Adding blueprint to blueprintGroup
    url_prefix = "url_prefix"
    name = "name"
    bp = Blueprint(name=name, url_prefix=url_prefix)
    bpGroup._blueprints.append(bp)

    index = 0
    assert bpGroup[index] == bp

# Generated at 2022-06-24 03:27:59.929495
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    """Test BlueprintGroup.__getitem__

    Test that BlueprintGroup.__getitem__ accepts an index, and
    returns the correct item. Also that an IndexError is raised in
    case of invalid index.
    """

    app = sanic.Sanic("BlueprintGroup__getitem__")
    bp = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")

    bp_group = BlueprintGroup(
        url_prefix="/api", version="v1", strict_slashes=False
    )
    bp_group.append(bp)
    bp_group.append(bp2)


# Generated at 2022-06-24 03:28:04.529997
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    @sanic.blueprint('bp1')
    def bp1(request):
        ...
    @sanic.blueprint('bp2')
    def bp2(request):
        ...
    w = BlueprintGroup()
    w.append(bp1)
    w.append(bp2)
    del w[0]
    assert w[0] == bp2

# Generated at 2022-06-24 03:28:09.862363
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg) == 2

# Generated at 2022-06-24 03:28:11.823936
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    obj = BlueprintGroup(url_prefix='/api/v1')
    assert len(obj) == 0



# Generated at 2022-06-24 03:28:22.259523
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint("bp1", url_prefix="/bp1") 
    bp2 = Blueprint("bp2", url_prefix="/bp2") 
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")
    bp5 = Blueprint("bp5", url_prefix="/bp5") 
    bp6 = Blueprint("bp6", url_prefix="/bp6") 
    bp7 = Blueprint("bp7", url_prefix="/bp7")
    bp8 = Blueprint("bp8", url_prefix="/bp8")

    bp_group = BlueprintGroup(bp_group_url_prefix="/bp_group")

# Generated at 2022-06-24 03:28:26.994955
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp = Blueprint("bp", url_prefix="/anurag")
    bpg = BlueprintGroup("/api", version="v1")
    bpg.append(bp)
    bpg[0] = bp


# Generated at 2022-06-24 03:28:36.732417
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    bp_group = BlueprintGroup("/bpgroup")
    assert len(bp_group) == 0

    assert bp1.url_prefix == "/bp1"
    assert bp2.url_prefix == "/bp2"
    assert bp1.version == None

    # Adding new blueprints to the blueprint group
    bp_group.append(bp1)
    bp_group.append(bp2)

    # Make sure the group length is correct
    assert len(bp_group) == 2
    assert bp_group[0] == bp1
    assert bp_group[1] == bp2

    # Make sure the URL Prefix is modified as per the

# Generated at 2022-06-24 03:28:47.790913
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    """
    Test the blueprint group's append method.
    """
    blueprint1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    blueprint2 = sanic.Blueprint('bp2', url_prefix='/bp2')

    blueprint_group = BlueprintGroup(url_prefix="/api", version="v1")
    assert blueprint_group.blueprints == []
    blueprint_group.append(blueprint1)
    blueprint_group.append(blueprint2)
    assert blueprint_group.blueprints == [blueprint1, blueprint2]
    assert blueprint_group.blueprints[0].url_prefix == '/api/bp1'
    assert blueprint_group.blueprints[0].version == 'v1'
    assert blueprint_group.blueprints[1].url_prefix == '/api/bp2'
    assert blueprint_

# Generated at 2022-06-24 03:28:55.765714
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    # Insert at 0th index
    bpg.insert(0, bp1)
    assert len(bpg) == 1
    assert bpg.blueprints[0] == bp1

    # Insert at 3rd index
    bpg.insert(1, bp2)
    assert len(bpg) == 2
    assert bpg.blueprints[1] == bp2

    # Insert at 3rd index

# Generated at 2022-06-24 03:29:02.729807
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix='/api', version='v1')

    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    del bpg[2]

    assert len(bpg) == 3

    with pytest.raises(IndexError):
        del bpg[3]


# Generated at 2022-06-24 03:29:11.598796
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint("test_bp1", url_prefix="/bp1")
    bp2 = Blueprint("test_bp2", url_prefix="/bp2")
    bp3 = Blueprint("test_bp3", url_prefix="/bp3")
    bp4 = Blueprint("test_bp4", url_prefix="/bp4")
    bpg = BlueprintGroup("/api", strict_slashes=False)
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    assert bp1.url_prefix == "/api/bp1"
    assert bp2.url_prefix == "/api/bp2"
    assert bp3.url_prefix == "/api/bp3"
    assert bpg[0] == bp1

# Generated at 2022-06-24 03:29:12.155534
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    pass

# Generated at 2022-06-24 03:29:23.328176
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    app = Sanic('test_BlueprintGroup___iter__')
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')

    bp1.get('/')(lambda r: text('bp1'))
    bp2.get('/')(lambda r: text('bp2'))

    group = Blueprint.group(bp1, bp2)
    app.blueprint(group)

    # Unit test for method __iter__ of class BlueprintGroup
    @app.middleware('request')
    async def test_middleware(request):
        assert request.app
        assert request.blueprint

    @app.route('/')
    async def test_index(request):
        return text('Index')

    request, response = app.test_client.get('/')

# Generated at 2022-06-24 03:29:34.189199
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")
    bp5 = Blueprint("bp5", url_prefix="/bp5")
    bp6 = Blueprint("bp6", url_prefix="/bp6")
    bp7 = Blueprint("bp7", url_prefix="/bp7")
    bp8 = Blueprint("bp8", url_prefix="/bp8")
    bp9 = Blueprint("bp9", url_prefix="/bp9")

    bpg1 = BlueprintGroup("/apis/v1")
    bpg2 = BlueprintGroup("/apis/v2")

# Generated at 2022-06-24 03:29:37.107277
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    assert len(bp1.url_prefix) > 0
    bp1.append(bp2)
    assert len(bp1) == 2

# Generated at 2022-06-24 03:29:46.908154
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1')
    assert len(bp1._middleware) == 0
    assert bp1.url_prefix == ""
    assert bp1.version is None
    assert bp1.strict_slashes is None

    @bp1.middleware('request')
    async def middleware1(request):
        print('middleware 1')

    @bp1.middleware('request')
    async def middleware2(request):
        print('middleware 2')

    @bp1.route('/')
    async def handler(request):
        return text('OK')

    bp2 = Blueprint('bp2')
    assert len(bp2._middleware) == 0
    assert bp2.url_prefix == ""
    assert bp2.version is None
    assert bp2.strict_sl

# Generated at 2022-06-24 03:29:56.192343
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    # Given: BlueprintGroup instance with two blueprints
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bps = BlueprintGroup()
    bps.append(bp1)
    bps.append(bp2)

    # When: delete blueprint at index 0
    bp_to_be_deleted = bps[0]
    del bps[0]

    # Then: Blueprint group should have single blueprint
    #       Blueprint group should not have bp_to_be_deleted
    assert len(bps) == 1
    assert bp_to_be_de

# Generated at 2022-06-24 03:30:02.845873
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bpg = BlueprintGroup(url_prefix="/api")
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert bp1.url_prefix == "/api/bp1"
    assert bp2.url_prefix == "/api/bp2"


# Generated at 2022-06-24 03:30:13.007722
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    import unittest

    bp1 = sanic.Blueprint("bp1", url_prefix="/bp1")
    bp2 = sanic.Blueprint("bp2", url_prefix="/bp2")

    bp3 = sanic.Blueprint("bp3", url_prefix="/bp3")
    bp4 = sanic.Blueprint("bp4", url_prefix="/bp4")

    bpg = BlueprintGroup(url_prefix="/api", version="v1", strict_slashes=True)

    @bp1.middleware("request")
    async def bp1_only_middleware(request):
        print("applied on Blueprint : bp1 Only")

    @bp1.route("/")
    async def bp1_route(request):
        return text("bp1")


# Generated at 2022-06-24 03:30:16.544283
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    """
    GIVEN a Blueprint Group class
    WHEN the __iter__ method is called
    THEN return an iterable object.
    """
    bpg = BlueprintGroup()
    assert hasattr(bpg.__iter__(), "__next__")



# Generated at 2022-06-24 03:30:25.196255
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    assert bpg.blueprints == [bp1, bp2]
    assert bpg.url_prefix == bp1.url_prefix == bp2.url_prefix == "/api"
    assert bpg.version == bp1.version == bp2.version == "v1"



# Generated at 2022-06-24 03:30:34.939266
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    bp2 = Blueprint('bp2', url_prefix='/bp2')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    bpg = BlueprintGroup(url_prefix='/myprefix', version='v1')
    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg.__getitem__(0) == bp1

# Generated at 2022-06-24 03:30:43.496132
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    # Arrange
    # bp1 = Blueprint('bp1', url_prefix='/bp1')
    # bp2 = Blueprint('bp2', url_prefix='/bp2')
    # bp3 = Blueprint('bp3', url_prefix='/bp3')

    bpg = BlueprintGroup(url_prefix="/api", version=1, strict_slashes=True)
    # bpg._blueprints = [bp1, bp2, bp3]

    # Act
    del bpg[2]

    # Assert
    assert len(bpg) == 2



# Generated at 2022-06-24 03:30:48.860143
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp3 = sanic.Blueprint('bp3', url_prefix='/bp3')
    bp4 = sanic.Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    assert bpg._url_prefix == "/api"
    assert bpg._version == "v1"
    assert bpg._strict_slashes is None
    assert bpg._blueprints == [bp3, bp4]


# Generated at 2022-06-24 03:30:54.766384
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Given
    class App(sanic.Sanic):
        pass

    app = App()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)
    @group.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    # Then
    assert len(group.blueprints) == 2
    assert len(bp1.middlewares['request']) == 2

# Generated at 2022-06-24 03:31:05.303004
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')

    bpg1 = BlueprintGroup()

    bpg1.append(bp1)
    bpg1.append(bp2)

    bpg2 = BlueprintGroup()

    bpg2.append(bp3)
    bpg2.append(bp4)

    bpg3 = BlueprintGroup()
    bpg3.append(bp5)
    bpg

# Generated at 2022-06-24 03:31:13.852030
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @sanic.blueprint.Blueprint.middleware('request')
    def middleware_example(request):
        pass

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    bpg.middleware(middleware_example)

    assert middleware_example in bp1.middlewares
    assert middleware_example in bp2.middlewares

# Generated at 2022-06-24 03:31:22.295707
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    # Create Blueprint object
    bp1 = Blueprint(name='test_bp1', url_prefix='/test_bp1')
    bp2 = Blueprint(name='test_bp2', url_prefix='/test_bp2')
    bp3 = Blueprint(name='test_bp3', url_prefix='/test_bp3')
    # Create Blueprint Group
    bpg = BlueprintGroup(bp1, bp2, bp3, url_prefix="/api", version="v1")
    # Check if item exist in list
    assert bpg[0] == bp1
    # Delete item from list
    del bpg[0]
    # Check if item does not exist in list
    assert bpg[0] != bp1


# Generated at 2022-06-24 03:31:28.823727
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg._blueprints = [bp1, bp2]
    bps = []
    for bp in bpg:
        bps.append(bp)
    assert bps[0] == bp1
    assert bps[1] == bp2


# Generated at 2022-06-24 03:31:35.775290
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    app = sanic.Sanic(__name__)
    bp = Blueprint("bp", url_prefix="/bp")
    bpg = BlueprintGroup("/api", version="v1")

    bpg.insert(0, bp)

    assert bpg.version == "v1"
    assert bp.url_prefix == "/api/bp"
    assert bp.version == "v1"



# Generated at 2022-06-24 03:31:41.262257
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg) == 2
    assert len([bp1, bp2]) == 2


# Generated at 2022-06-24 03:31:44.304466
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint = BlueprintGroup()
    blueprint.append(None)
    assert len(blueprint._blueprints) == 1
    del blueprint[0]
    assert len(blueprint._blueprints) == 0


# Generated at 2022-06-24 03:31:54.358847
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    """ Unit test for method insert of class BlueprintGroup"""
    app = sanic.Sanic()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-24 03:31:59.340411
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)

    assert group[0] == bp1
    assert group[1] == bp2


# Generated at 2022-06-24 03:32:01.245815
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bpg = BlueprintGroup()
    assert isinstance(bpg, BlueprintGroup)


# Generated at 2022-06-24 03:32:03.925406
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bpg = BlueprintGroup()
    bp = Blueprint(__name__)
    bpg[0] = bp
    assert bpg._blueprints == [bp]



# Generated at 2022-06-24 03:32:04.952298
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    assert True



# Generated at 2022-06-24 03:32:10.656626
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprints = [sanic.Blueprint("test_bp_{}".format(i)) for i in range(3)]
    bp_group = BlueprintGroup()
    bp_group._blueprints = blueprints

    count = 0
    for bp in bp_group:
        assert bp.name == "test_bp_{}".format(count)
        count += 1

    assert count == 3



# Generated at 2022-06-24 03:32:20.273392
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    async def test_middleware(request):
        print("Test Middleware")

    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    bp1.middleware(test_middleware)
    bp2.middleware(test_middleware)

    assert bp1 is (bp1[0])
    assert bp2 is (bp1[1])
    assert len(bp1)==2

    bp1.append(bp2)
    assert bp1 is (bp1[0])
    assert bp2 is (bp1[1])
    assert len(bp1)==2

    bp1.insert(0,bp2)
    assert bp2 is (bp1[0])
    assert len(bp1)

# Generated at 2022-06-24 03:32:23.132638
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp_group = BlueprintGroup()
    bp_group.append(Blueprint("test"))
    del bp_group[0]
    assert(len(bp_group) == 0)



# Generated at 2022-06-24 03:32:31.810504
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpGroup = BlueprintGroup()

    # Initial length of blueprint group
    assert len(bpGroup) == 0

    bpGroup.append(bp1)
    # length after append
    assert len(bpGroup) == 1

    # insert bp2 at 0
    bpGroup.insert(0, bp2)
    # length after insert
    assert len(bpGroup) == 2

    # check for order of blueprints
    assert list(bpGroup) == [bp2, bp1]


# Generated at 2022-06-24 03:32:36.514881
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    """
    This test case checks the proper initialization of `BlueprintGroup` class

    :return: None
    """
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    bpg = BlueprintGroup(bp1, bp2)

    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert bpg.blueprints[0] == bp1

# Generated at 2022-06-24 03:32:41.829920
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2)
    assert len(bpg) == 2
    assert bpg.__len__() == 2


# Generated at 2022-06-24 03:32:52.763144
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class TestMiddleware:
        def __init__(self, name, **kwargs):
            self.name = name
            self.args = kwargs

        async def __call__(self, request, **kwargs):
            return

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware('request')
    def middleware(request):
        pass

    @bpg.middleware('response')
    def middleware(request, response):
        pass

    @bpg.middleware('request', name='test')
    def middleware(request):
        pass


# Generated at 2022-06-24 03:32:59.760893
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup("/api")
    with pytest.raises(TypeError):
        bpg.append(bp1)
    bpg.append(bp2)
    print(bpg.__delitem__(0))

test_BlueprintGroup___delitem__()



# Generated at 2022-06-24 03:33:11.238534
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    url_prefix = '/api/v1'
    version = 'v1'
    strict_slashes = False
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix=url_prefix, version=version,
                         strict_slashes=strict_slashes)
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg) == 2
    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert bpg.url_prefix == url_prefix
    assert bpg.version == version
    assert bpg.strict_slashes == strict_slashes

# Generated at 2022-06-24 03:33:16.065556
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg[0] is bp1
    assert bpg[1] is bp2


# Generated at 2022-06-24 03:33:25.897384
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')
    bp7 = Blueprint('bp7', url_prefix='/bp7')
    bp8 = Blueprint('bp8', url_prefix='/bp8')

    bpg1 = BlueprintGroup(url_prefix='api', version=1)
    bpg1.append(bp1)
    bpg1.append(bp2)
    bpg1.append

# Generated at 2022-06-24 03:33:33.166128
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    # Arrange
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    # Act
    bpg.append(bp1)
    bpg.append(bp2)

    # Assert
    assert len(bpg) == 2
    assert bpg[0].url_prefix == "/api/bp1"
    assert bpg[0].version == "v1"
    assert bpg[1].url_prefix == "/api/bp2"
    assert bpg[1].version == "v1"

    # Act
    bpg.append(bp3)
    bp1

# Generated at 2022-06-24 03:33:42.619060
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()

    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    bp_group = BlueprintGroup()

    bp_group.append(bp1)
    bp_group.append(bp2)

    @bp_group.middleware('request')
    async def group_middleware_request(request):
        print(f"applied group middleware on request")


# Generated at 2022-06-24 03:33:51.423784
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp4')

    # Test the BlueprintGroup
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    # Check the blueprint group length
    assert len(bpg) == 2

    # Check member of blueprint group is correct
    assert bpg[0] == bp3
    assert bpg[1] == bp4

    # Check the blueprint group indexing
    bpg[1] = bp5

# Generated at 2022-06-24 03:34:01.300793
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-24 03:34:10.367269
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    group = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    assert group._blueprints == [bp3, bp4]
    assert group._url_prefix == "/api"
    assert group._version == "v1"
    assert group._strict_slashes is None
    assert group.strict_slashes is None


# Generated at 2022-06-24 03:34:11.920956
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    from sanic.blueprints import BlueprintGroup



# Generated at 2022-06-24 03:34:21.922518
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2)
    del bpg[1]
    assert len(bpg) == 1
    assert isinstance(bpg, list)
    assert bpg[0] == bp1
    assert bpg[0] != bp2
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bpg.append(bp3)
    del bpg[1]
    assert len(bpg) == 2
    assert bpg[-1] == bp3
    assert bpg[1] != bp2


# Generated at 2022-06-24 03:34:27.927498
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')


    bpg = BlueprintGroup(url_prefix='/api/v1')
    bpg.append(bp1)
    bpg.append(bp2)
    print(bpg)
    print(bpg.blueprints)
    assert bp1 in bpg.blueprints
    assert bp2 in bpg.blueprints



# Generated at 2022-06-24 03:34:31.024458
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    """
    Test that the BlueprintGroup.__len__() method works correctly
    """

    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert len(bpg) == 2



# Generated at 2022-06-24 03:34:31.663325
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    BlueprintGroup()

# Generated at 2022-06-24 03:34:43.255709
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    app = sanic.Sanic("test_BlueprintGroup___delitem__")

    bp1 = Blueprint('bp1', url_prefix='/bp1')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    bp2 = Blueprint('bp2', url_prefix='/bp2')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    bpg = BlueprintGroup()

    bpg.append(bp1)
    bpg.append(bp2)

    app.blueprint(bpg)

    assert app.is_request_stream is False
    assert len(app.router.routes_all) == 2


# Generated at 2022-06-24 03:34:50.367177
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg[0] == bp1
    assert bpg[1] == bp2


# Generated at 2022-06-24 03:34:58.962685
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup()

    bpg.append(bp3)
    bpg.append(bp4)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return

    @bp2.route('/')
    async def bp2_route(request):
        return
