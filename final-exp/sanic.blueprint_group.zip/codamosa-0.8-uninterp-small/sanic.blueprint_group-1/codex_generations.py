

# Generated at 2022-06-26 03:00:06.785877
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group_0 = BlueprintGroup('/test/<string:param0>', 'test', None)
    blueprint_0 = Blueprint('test', 'test', url_prefix='/test/<param0>')
    blueprint_1 = Blueprint('/test/<param0>/nested/<param1>', 'test', '/test/<param0>')
    blueprint_2 = Blueprint('/test/<param0>/nested/<param1>/deep/<param2>', 'test', '/test/<param0>/nested/<param1>')
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.insert(-1, blueprint_1)
    blueprint_group_0.insert(2, blueprint_2)
    # testing exceptions

# Generated at 2022-06-26 03:00:15.456407
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    # Initialize the BlueprintGroup Object
    blueprint_group_0 = BlueprintGroup()

    # Initialize the Blueprint Object
    blueprint_0 = Blueprint("blueprint_0")

    # Append the Blueprint to the Blueprint Group
    blueprint_group_0.append(blueprint_0)

    # Compare the length of the blueprints inside the Blueprint Group
    assert len(blueprint_group_0.blueprints) == 1


if __name__ == '__main__':
    test_case_0()
    test_BlueprintGroup_append()

# Generated at 2022-06-26 03:00:19.275254
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    from sanic.blueprints import Blueprint
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint(str_0)
    blueprint_group_0.append(blueprint_0)
    blueprint_1 = blueprint_group_0.__iter__()
    assert blueprint_1, "the method __iter__() of class BlueprintGroup failed"



# Generated at 2022-06-26 03:00:23.282838
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    str_1 = '%a, %d-%b-%Y %T GMT'
    blueprint_group_0 = BlueprintGroup(str_1)

    blueprint_0 = Blueprint(str_1)

    blueprint_group_0.append(blueprint_0)


# Generated at 2022-06-26 03:00:27.704830
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    str_0 = '%a, %d-%b-%Y %T GMT'
    blueprint_group_0 = BlueprintGroup(str_0)
    blueprint_group_0.__delitem__(0)


# Generated at 2022-06-26 03:00:32.617305
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    str_0 = '%a, %d-%b-%Y %T GMT'
    blueprint_group_0 = BlueprintGroup(str_0)
    if (blueprint_group_0):
        _ = len(blueprint_group_0)
    else:
        raise RuntimeError


# Generated at 2022-06-26 03:00:43.225482
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    str_0 = '4b7e8a'
    str_1 = '%d-%b-%Y %T GMT'
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint('bp1', str_0, None, True)
    blueprint_group_0._blueprints.append(blueprint_0)
    blueprint_1 = Blueprint('bp2', str_0)
    blueprint_group_0._blueprints.append(blueprint_1)
    # Testing for the default case (1/6)
    # Testing for the default case (2/6)
    # Testing for the default case (3/6)
    try:
        blueprint_group_0.middleware()
    except TypeError:
        pass
    # Testing for the default case (4/6)
    # Testing for the default case (5

# Generated at 2022-06-26 03:00:51.390383
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    str_0 = '%a, %d-%b-%Y %T GMT'
    str_1 = '<%Y>'
    blueprint_group_0 = BlueprintGroup(str_0)
    blueprint_group_0.middleware(str_1)
    blueprint_group_0.middleware(str_1, str_0)
    blueprint_group_0.middleware(str_0, str_1)
    blueprint_group_0.middleware(str_1, str_1)
    blueprint_group_0.middleware(str_0, str_0)


# Generated at 2022-06-26 03:00:58.683852
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    app = sanic.Sanic()
    url_prefix = str(random.random())
    version = str(random.random())
    strict_slashes = random.random() > 0.5
    blueprint_group_0 = BlueprintGroup(url_prefix, version, strict_slashes)
    blueprint_group_0.append(app)
    blueprint_group_0.insert(0, blueprint_group_0)
    blueprint_group_0[0] = blueprint_group_0
    del blueprint_group_0[0]
    blueprint_group_0.middleware()
    blueprint_group_0.middleware(blueprint_group_0)
    len(blueprint_group_0)
    str(blueprint_group_0.url_prefix)
    str(blueprint_group_0.blueprints)

# Generated at 2022-06-26 03:01:06.357957
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    str_0 = '_'
    blueprint_group_0 = BlueprintGroup(str_0)
    blueprint_0 = Blueprint(str_0)
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.append(blueprint_0)

# Generated at 2022-06-26 03:01:15.079428
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0._url_prefix = '{'
    blueprint_group_0._version = 'test'
    blueprint_group_0._strict_slashes = True
    blueprint_group_0._blueprints = [sanic.blueprints.Blueprint(u'a', u'*', url_prefix=u'a')]
    blueprint_group_0.__iter__()


# Generated at 2022-06-26 03:01:17.067952
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group = BlueprintGroup()
    assert len(blueprint_group) == 0



# Generated at 2022-06-26 03:01:20.707191
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group = BlueprintGroup()
    blueprint_group.insert(0,"blueprints")



# Generated at 2022-06-26 03:01:30.847449
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    blueprints_list_0 = blueprint_group_0.blueprints
    blueprint_group_0.append(blueprints_list_0)
    blueprint_group_0.append(blueprints_list_0)
    blueprint_group_0.append(blueprints_list_0)
    blueprint_group_0.append(blueprints_list_0)
    blueprint_group_0.append(blueprints_list_0)
    blueprint_group_0.append(blueprints_list_0)
    blueprint_group_0.append(blueprints_list_0)
    blueprint_group_0.append(blueprints_list_0)
    blueprint_group_0.append(blueprints_list_0)
    blueprint_group_0.append(blueprints_list_0)
   

# Generated at 2022-06-26 03:01:33.691772
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():

    # Constructing and initializing an object of BlueprintGroup
    blueprintGroup = BlueprintGroup()
    assert blueprintGroup._blueprints == []
    assert blueprintGroup._url_prefix == None
    assert blueprintGroup._version == None
    assert blueprintGroup._strict_slashes == None



# Generated at 2022-06-26 03:01:44.162930
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(
        Blueprint('name_0', url_prefix='rtrhqnqzq', version='version_1', strict_slashes=False)
    )
    blueprint_group_0.append(
        Blueprint('name_0', url_prefix='rtrhqnqzq', version='version_1', strict_slashes=False)
    )
    blueprint_group_0.append(
        Blueprint('name_0', url_prefix='rtrhqnqzq', version='version_1', strict_slashes=False)
    )
    blueprint_group_0.append(
        Blueprint('name_0', url_prefix='rtrhqnqzq', version='version_1', strict_slashes=False)
    )


# Generated at 2022-06-26 03:01:49.947921
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    try:
        blueprint_group_0 = BlueprintGroup()
    except Exception as e:
        assert False, "Exception caught" + str(e)
    assert blueprint_group_0._blueprints == []
    assert blueprint_group_0._url_prefix is None
    assert blueprint_group_0._version is None
    assert blueprint_group_0._strict_slashes is None


# Generated at 2022-06-26 03:01:58.353233
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0._blueprints = None
    blueprint_group_0._version = None
    blueprint_group_0._url_prefix = None
    blueprint_group_0._strict_slashes = None
    blueprint_group_0._sanitize_blueprint = None
    blueprint_group_0.blueprints = None
    blueprint_group_0.url_prefix = None
    blueprint_group_0.version = None
    blueprint_group_0.strict_slashes = None
    blueprint_group_0.middleware = None
    sanic.sanic.blueprint = None
    sanic.sanic.request = None
    sanic.sanic.response = None
    sanic.sanic.Stream = None
    sanic.sanic.File = None
    san

# Generated at 2022-06-26 03:02:01.707352
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(Blueprint(url_prefix='/bp1'))
    blueprint_group_0.__delitem__(0)


# Generated at 2022-06-26 03:02:09.071563
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(bp1)
    blueprint_group_0.append(bp2)
    blueprint_group_0.__getitem__(index=-1)
    blueprint_group_0.__getitem__(index=0)
    blueprint_group_0.__getitem__(index=1)
    try:
        blueprint_group_0.__getitem__(index=2)
    except Exception as e:
        pass


# Generated at 2022-06-26 03:02:14.571083
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.__delitem__(0)



# Generated at 2022-06-26 03:02:26.277864
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(sanic.Blueprint('bp0', url_prefix='/bp0'))
    blueprint_group_0.append(sanic.Blueprint('bp1', url_prefix='/bp1'))
    blueprint_group_0.append(sanic.Blueprint('bp2', url_prefix='/bp2'))
    blueprint_group_0.append(sanic.Blueprint('bp3', url_prefix='/bp3'))
    blueprint_group_0.append(sanic.Blueprint('bp4', url_prefix='/bp4'))
    blueprint_group_0.append(sanic.Blueprint('bp5', url_prefix='/bp5'))

# Generated at 2022-06-26 03:02:32.688977
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint(name='blueprint', url_prefix='/api/v1/blueprint')
    blueprint_group_0.append(blueprint_0)
    blueprint_1 = Blueprint(name='blueprint1', url_prefix='/api/v1/blueprint')
    blueprint_group_0.insert(1, blueprint_1)
    assert blueprint_group_0.__getitem__(1) == blueprint_1

# Generated at 2022-06-26 03:02:38.028291
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0 = BlueprintGroup()


# Generated at 2022-06-26 03:02:42.401502
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    # BlueprintGroup class instantiation
    blueprint_group_0 = BlueprintGroup()


    # BlueprintList class instantiation
    blueprint_list_0 = Blueprint.group("blueprint_0")


    # Call the method insert of blueprint_group_0
    blueprint_group_0.insert(0, blueprint_list_0)


# Generated at 2022-06-26 03:02:44.182107
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_1 = BlueprintGroup()
    assert blueprint_group_1.__len__() == 0


# Generated at 2022-06-26 03:02:46.693088
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_0 = BlueprintGroup()

    assert len(blueprint_group_0) == 0

# Generated at 2022-06-26 03:02:54.840528
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    """
    Possible Cases:
    1. The method `BlueprintGroup.__init__` is implemented to take a list
       based initialization of the blueprints. We are already testing the
       error cases in the `test_BlueprintGroup_init`.
    2. The property `BlueprintGroup.blueprints` is used to verify if the
       blueprints are actually appended to the BlueprintGroup object
    """
    blueprint_group = BlueprintGroup()
    blueprint_0 = Blueprint(name="test-0", url_prefix="/test-0")
    blueprint_1 = Blueprint(name="test-1", url_prefix="/test-1")

    blueprint_group.append(blueprint_0)
    blueprint_group.append(blueprint_1)

    assert blueprint_group.blueprints == [blueprint_0, blueprint_1]


# Generated at 2022-06-26 03:02:59.075960
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_0 = BlueprintGroup(None, None, None)
    blueprint_group_0.append(sanic.Blueprint('', url_prefix=None, version=None, \
strict_slashes=None))
    del blueprint_group_0[0]


# Generated at 2022-06-26 03:03:10.393445
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(Blueprint(name='blueprint_group_0[0]'))
    blueprint_group_0.append(Blueprint(name='blueprint_group_0[1]'))
    blueprint_group_0.append(Blueprint(name='blueprint_group_0[2]'))
    blueprint_group_0.append(Blueprint(name='blueprint_group_0[3]'))
    blueprint_group_0.append(Blueprint(name='blueprint_group_0[4]'))
    blueprint_group_0.append(Blueprint(name='blueprint_group_0[5]'))
    blueprint_group_0.append(Blueprint(name='blueprint_group_0[6]'))

# Generated at 2022-06-26 03:03:21.626826
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group = BlueprintGroup()
    blueprint = Blueprint('bp1', url_prefix='/bp1')
    blueprint_group.append(blueprint)
    blueprint_group.insert(0, blueprint)


# Generated at 2022-06-26 03:03:31.918310
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup(
        "iswuy5jgk4",
        version=7064,
        strict_slashes=False)
    blueprint_group_0.append(
        Blueprint(
            "jvfnddkhww",
            url_prefix=None,
            version=None,
            strict_slashes=True))
    blueprint_group_0.append(
        Blueprint(
            "gk5e5p5is5",
            url_prefix=None,
            version=None,
            strict_slashes=False))
    blueprint_group_0.append(
        Blueprint(
            "ui1l9ikl6a",
            url_prefix=None,
            version=None,
            strict_slashes=True))

# Generated at 2022-06-26 03:03:33.563896
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0._blueprints = ['blueprint_group_0._blueprints']
    assert blueprint_group_0.__iter__() == blueprint_group_0._blueprints


# Generated at 2022-06-26 03:03:37.552556
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg._blueprints = [bp1, bp2]
    bpg._url_prefix = '/api'
    bpg._version = 'v1'
    bpg._strict_slashes = True
    assert bpg.__getitem__(1) == bp2


# Generated at 2022-06-26 03:03:42.540961
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup("url_prefix", "version", "strict_slashes")
    assert len(blueprint_group_0) == 0
    assert len(blueprint_group_1) == 0


# Generated at 2022-06-26 03:03:46.558917
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint_group = BlueprintGroup('/api', version="v1", strict_slashes=True)
    assert blueprint_group.url_prefix == '/api'
    assert blueprint_group.version == "v1"
    assert blueprint_group.strict_slashes == True



# Generated at 2022-06-26 03:03:48.809342
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint("bp_0")
    blueprint_group_0.__setitem__(0, blueprint_0)


# Generated at 2022-06-26 03:03:51.239770
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(print)


# Generated at 2022-06-26 03:03:57.980630
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_1 = BlueprintGroup()
    blueprint_1 = Blueprint("blueprint_1")
    blueprint_2 = Blueprint("blueprint_2")
    blueprint_3 = Blueprint("blueprint_3")

    blueprint_group_1._blueprints.append(blueprint_1)
    blueprint_group_1._blueprints.append(blueprint_2)
    blueprint_group_1._blueprints.append(blueprint_3)

    bp_iterator = blueprint_group_1.__iter__()
    assert isinstance(next(bp_iterator), Blueprint)
    assert isinstance(next(bp_iterator), Blueprint)
    assert isinstance(next(bp_iterator), Blueprint)


# Generated at 2022-06-26 03:04:06.319969
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(Blueprint("blueprint"))
    blueprint_group_0.append(Blueprint("blueprint"))
    blueprint_group_0.append(Blueprint("blueprint"))
    blueprint_group_0.append(Blueprint("blueprint"))
    blueprint_group_0.append(Blueprint("blueprint"))
    for _ in blueprint_group_0:
        pass
    for _ in blueprint_group_0:
        pass
    for _ in blueprint_group_0:
        pass



# Generated at 2022-06-26 03:04:26.378135
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    """
    Unit test code for method insert of class BlueprintGroup

    :return: None
    """
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint('sanic.Blueprint', url_prefix='/sanic.Blueprint')
    blueprint_group_0.insert(0, blueprint_0)



# Generated at 2022-06-26 03:04:28.981328
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    assert isinstance(blueprint_group_0.__iter__(), types.GeneratorType) == True

#Unit test for method __getitem__ of class BlueprintGroup

# Generated at 2022-06-26 03:04:31.115175
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = test_case_0()
    iterator_0 = blueprint_group_0.__iter__()
    assert isinstance(iterator_0, type(filter(lambda: False, range(5))))


# Generated at 2022-06-26 03:04:33.479384
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    instance_0 = BlueprintGroup()
    item = Blueprint()
    index = (int) (0)
    instance_0.__setitem__(index, item)


# Generated at 2022-06-26 03:04:42.619684
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    bpg_1 = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')


# Generated at 2022-06-26 03:04:44.777909
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_0 = BlueprintGroup()
    assert len(blueprint_group_0) == 0



# Generated at 2022-06-26 03:04:47.924712
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_0 = BlueprintGroup('')
    blueprint_group_0.append(Blueprint('test_name_1', url_prefix=''))
    blueprint_group_0.append(Blueprint('test_name_2', url_prefix=''))
    blueprint_group_0.__delitem__(0)


# Generated at 2022-06-26 03:04:49.428908
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group = BlueprintGroup()
    blueprint = Blueprint()
    blueprint_group[0] = blueprint


# Generated at 2022-06-26 03:04:53.884663
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint("Test",url_prefix="Test")
    blueprint_group_0.append(blueprint_0)
    # check point 1
    assert len(blueprint_group_0) == 1
    # check point 2
    assert blueprint_group_0[0] == blueprint_0
    # check point 3
    assert blueprint_group_0[-1] == blueprint_0


# Generated at 2022-06-26 03:04:56.686335
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(None)
    blueprint_group_0.append(None)
    blueprint_group_0.insert(0, None)
    blueprint_group_0.insert(0, None)
    # The actual test
    result = len(blueprint_group_0)
    expected_result = 4
    assert result == expected_result



# Generated at 2022-06-26 03:05:30.830887
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(None)
    blueprint_group_0.insert(0, None)



# Generated at 2022-06-26 03:05:34.456787
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():

    blueprint_group = BlueprintGroup()

    assert blueprint_group.url_prefix == None
    assert blueprint_group.blueprints == []
    assert blueprint_group.version == None
    assert blueprint_group.strict_slashes == None




# Generated at 2022-06-26 03:05:42.170585
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp = Blueprint('bp')
    bpg = BlueprintGroup()
    bpg.blueprints = [bp, bp]

    @bpg.middleware('request')
    def req_middleware(request):
        pass

    @bpg.middleware('response')
    def resp_middleware(request, response):
        pass

    assert len(bp.request_middleware) == 1
    assert len(bp.response_middleware) == 1
    assert len(bp.exception_middleware) == 0



# Generated at 2022-06-26 03:05:46.576135
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint(name = 'test_blueprint_0', url_prefix = '/test_blueprint_0')
    blueprint_0.middleware('request', lambda request: None)(lambda request: None)
    blueprint_group_0.append(blueprint_0)


# Generated at 2022-06-26 03:05:50.265701
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_1 = BlueprintGroup()
    blueprint_1 = Blueprint('bp1', url_prefix='/bp1')
    blueprint_group_1[0] = blueprint_1
    assert blueprint_group_1._blueprints[0] == blueprint_1


# Generated at 2022-06-26 03:05:55.882255
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_0 = BlueprintGroup()
    assert(len(blueprint_group_0) == 0)

    blueprint_0 = Blueprint('bp0', url_prefix='/bp0')
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(blueprint_0)
    assert(len(blueprint_group_0) == 1)



# Generated at 2022-06-26 03:06:04.331453
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    """Test BlueprintGroup class's __delitem__ method"""
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_1.append(1)
    blueprint_group_1.append(1)
    blueprint_group_1.append(1)
    blueprint_group_1.append(1)
    blueprint_group_2 = blueprint_group_1.copy()
    blueprint_group_2.__delitem__(3)
    blueprint_group_3 = blueprint_group_1.copy()
    blueprint_group_3.__delitem__(slice(0, 2, 1))
    blueprint_group_4 = blueprint_group_1.copy()
    blueprint_group_4.__delitem__(0)


# Generated at 2022-06-26 03:06:16.372513
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    blueprint_0 = Blueprint('bp0', url_prefix='/bp0')
    blueprint_1 = Blueprint('bp1', url_prefix='/bp1')
    blueprint_2 = Blueprint('bp2', url_prefix='/bp2')
    blueprint_group_0 = BlueprintGroup()

    # Case where the decorator is passed without callable function
    @blueprint_group_0.middleware
    def dummy_middleware(request):
        pass

    # Case where the decorator is passed without callable function
    @blueprint_group_0.middleware('request')
    def dummy_middleware(request):
        pass

    # Case where the middleware decorator is passed with callable function
    @blueprint_group_0.middleware
    def dummy_middleware(request):
        pass

    # Case where the middleware decorator

# Generated at 2022-06-26 03:06:22.424025
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    # Declare a BlueprintGroup object
    blueprint_group_0 = BlueprintGroup()
    # Verify the type of the object
    assert isinstance(blueprint_group_0, BlueprintGroup)
    # Declare an iterator object
    blueprint_group_0_iter_0 = iter(blueprint_group_0)
    assert isinstance(blueprint_group_0_iter_0, iter)
    # Verify the values returned by iter(BlueprintGroup)
    assert next(blueprint_group_0_iter_0) is None


# Generated at 2022-06-26 03:06:27.196032
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_0 = BlueprintGroup(url_prefix='', version=2, strict_slashes=True)
    blueprint_group_0.append(blueprint_group_0)
    blueprint_group_0.insert(0, blueprint_group_0)
    assert len(blueprint_group_0) == 2


# Generated at 2022-06-26 03:07:39.099612
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group_1 = BlueprintGroup(url_prefix='/blueprint_group_1')
    blueprint_group_2 = BlueprintGroup(url_prefix='/blueprint_group_2')
    blueprint_group_3 = BlueprintGroup(url_prefix='/blueprint_group_3')
    
    blueprint_group_2_1 = BlueprintGroup(url_prefix='/blueprint_group_2_1')
    blueprint_group_2_2 = BlueprintGroup(url_prefix='/blueprint_group_2_2')
    blueprint_group_2_3 = BlueprintGroup(url_prefix='/blueprint_group_2_3')

    blueprint_group_3_1 = BlueprintGroup(url_prefix='/blueprint_group_3_1')

# Generated at 2022-06-26 03:07:42.193656
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint('blueprint_0', url_prefix='/blueprint-0')
    blueprint_group_0.append(blueprint_0)
    blueprint_1 = blueprint_group_0[0]
    del blueprint_group_0[0]
    blueprint_group_0.append(blueprint_1)
    del blueprint_group_0[0]


# Generated at 2022-06-26 03:07:45.231476
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    """
    - Sanity checks
    - Negative tests
    """
    assert isinstance(BlueprintGroup(), BlueprintGroup)



# Generated at 2022-06-26 03:07:52.127914
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)
    assert len(bpg) == 4


# Generated at 2022-06-26 03:07:56.031259
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.__delitem__(0)
    blueprint_group_0.__delitem__(0.0)
    blueprint_group_0.__delitem__(0.0)



# Generated at 2022-06-26 03:08:03.877064
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group = BlueprintGroup()
    # Test input type is a tuple of Blueprints
    blueprint_group.append(Blueprint('bp1', url_prefix='/bp1'))
    blueprint_group.append(Blueprint('bp2', url_prefix='/bp2'))

    it = iter(blueprint_group)
    assert isinstance(it, types.GeneratorType)


# Generated at 2022-06-26 03:08:13.283023
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_1 = BlueprintGroup()
    """
    Test Case to ensure, BlueprintGroup Class can be used as a MutableSequence
    to support the assignment operations
    """
    blueprint_1 = Blueprint("bp1", url_prefix="/bp1")
    blueprint_group_1.append(blueprint_1)
    blueprint_2 = Blueprint("bp2", url_prefix="/bp2")
    blueprint_group_1.append(blueprint_2)
    blueprint_3 = Blueprint("bp3", url_prefix="/bp3")
    blueprint_group_1.append(blueprint_3)
    blueprint_4 = Blueprint("bp4", url_prefix="/bp4")
    blueprint_group_1.append(blueprint_4)
    del blueprint_group_1[2]

# Generated at 2022-06-26 03:08:16.064504
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    pass
    # global blueprint_group_0
    # blueprint_group_0 = BlueprintGroup()
    # blueprint_group_0.append(None)
    # blueprint_group_0.__delitem__(None)



# Generated at 2022-06-26 03:08:17.389743
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_group_0 = BlueprintGroup()
    assert blueprint_group_0[:1] == []


# Generated at 2022-06-26 03:08:24.739529
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic import Blueprint
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint('blueprint_0', url_prefix='/api')
    blueprint_1 = Blueprint('blueprint_1', url_prefix='/api')
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.append(blueprint_1)
    blueprint_group_0.middleware(lambda x : x)
    assert len(blueprint_group_0.blueprints) == 2
    assert blueprint_group_0.blueprints[0].middlewares == blueprint_0.middlewares

# Generated at 2022-06-26 03:09:36.436439
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint_group1 = BlueprintGroup('/api', 'v1')
    assert blueprint_group1.url_prefix == '/api'
    assert blueprint_group1.version == 'v1'
    assert blueprint_group1.strict_slashes is None

    blueprint_group2 = BlueprintGroup('/api', version='v2', strict_slashes=False)
    assert blueprint_group2.url_prefix == '/api'
    assert blueprint_group2.version == 'v2'
    assert blueprint_group2.strict_slashes is False
    assert blueprint_group2._blueprints == []

    blueprint_group3 = BlueprintGroup(url_prefix='/api', version='v3', strict_slashes=True)
    assert blueprint_group3.url_prefix == '/api'
    assert blueprint_group3.version == 'v3'

# Generated at 2022-06-26 03:09:43.573793
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0

# Generated at 2022-06-26 03:09:47.312707
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_0 = Blueprint()
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.append(blueprint_0)
    blueprint_1 = blueprint_group_0[0]


# Generated at 2022-06-26 03:09:54.910215
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    """
    Unit test case to test the BlueprintGroup insert method
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp_group = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    bp_group.insert(0, bp1)
    bp_group.insert(1, bp2)

    assert bp_group[0] == bp1
    assert bp_group[1] == bp2
    assert bp_group[2] == bp3
    assert bp_

# Generated at 2022-06-26 03:09:58.536628
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0._blueprints = ['1']
    blueprint_group_0_iter = blueprint_group_0.__iter__()
    assert next(blueprint_group_0_iter) is '1'

