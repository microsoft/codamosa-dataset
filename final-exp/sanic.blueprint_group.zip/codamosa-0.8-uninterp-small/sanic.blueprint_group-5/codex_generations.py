

# Generated at 2022-06-26 03:00:06.486621
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_1 = BlueprintGroup()

    # Test for 0 positional args and 0 keyword args
    @blueprint_group_1.middleware()
    def middleware_1():
        pass

    # Test for 0 positional args and 1 keyword arg
    @blueprint_group_1.middleware(name="middleware_2")
    def middleware_2():
        pass

    # Test for 1 positional args and 0 keyword args
    @blueprint_group_1.middleware("request")
    def middleware_3():
        pass

    # Test for 1 positional args and 1 keyword arg
    @blueprint_group_1.middleware("request", name="middleware_4")
    def middleware_4():
        pass

    # Test for 0 positional args and 0 keyword args

# Generated at 2022-06-26 03:00:10.789739
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Case 0: Blueprint middleware is called without parameters
    blueprint_group_0 = BlueprintGroup()
    @blueprint_group_0.middleware()
    def func():
        pass
    
    

# Generated at 2022-06-26 03:00:13.260600
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(sanic.response_middleware)



# Generated at 2022-06-26 03:00:15.144149
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware()
    blueprint_group_0.middleware(middleware)


# Generated at 2022-06-26 03:00:26.263317
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Test case for passing a single argument, which is a function
    @blueprint_group_0.middleware
    def middleware_fn_0():
        return "middleware_fn_0"
    assert middleware_fn_0() is not None

    # Test case for passing multiple arguments, which includes a function
    @blueprint_group_0.middleware(1, 2)
    def middleware_fn_1():
        return "middleware_fn_1"
    assert middleware_fn_1() is not None

    # Test case for passing multiple arguments and keyword arguments
    @blueprint_group_0.middleware(1, 2, kwarg_0="kwarg_0")
    def middleware_fn_2():
        return "middleware_fn_2"
    assert middleware_fn_2() is not None

# Generated at 2022-06-26 03:00:31.756149
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup("url_prefix_0", "version_0", False)
    def dummy():
        pass
    blueprint_group_0.middleware(dummy)



# Generated at 2022-06-26 03:00:41.681749
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic('test_BlueprintGroup_middleware')

    # create Blueprint
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    # Middleware to be used inside Blueprint

    async def alter_request(request):
        request['bp_middleware'] = True
        return request

    @bp1.middleware('request')
    def bp1_middleware(request):
        request['bp1_middleware'] = True

    @bp2.middleware('request')
    async def bp2_middleware(request):
        request['bp2_middleware'] = True


    blueprint_group = BlueprintGroup(bp1, bp2, url_prefix='/group')

    # Add middleware that will

# Generated at 2022-06-26 03:00:52.565092
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.blueprints = blueprint_group_0.blueprints
    blueprint_group_0.url_prefix = blueprint_group_0.url_prefix
    blueprint_group_0.version = blueprint_group_0.version
    blueprint_group_0.strict_slashes = blueprint_group_0.strict_slashes
    blueprint_group_0._sanitize_blueprint(bp=None)
    blueprint_group_0.append(value=None)
    blueprint_group_0.insert(index=0, item=None)
    blueprint_group_0.middleware(args=0)

# Generated at 2022-06-26 03:00:54.356679
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_1.middleware(middleware_fn=lambda request: 1)


# Generated at 2022-06-26 03:00:58.679361
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(blueprint_group_0)
    blueprint_group_0.middleware('request')
    blueprint_group_0.middleware(blueprint_group_0)



# Generated at 2022-06-26 03:01:08.794790
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprints_0 = Blueprint('blueprints_0', url_prefix='/blueprints')
    blueprint_group_0 = BlueprintGroup(blueprints_0, url_prefix='/blueprints', version='v1')
    assert blueprint_group_0.version is 'v1'
    assert blueprint_group_0._blueprints[0] == blueprints_0
    blueprint_group_0.middleware(lambda r: r)


# Generated at 2022-06-26 03:01:20.400386
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_2 = BlueprintGroup()
    blueprint_group_3 = BlueprintGroup()
    blueprint_group_4 = BlueprintGroup()

    blueprint_group_1.append(blueprint_group_2)
    blueprint_group_2.append(blueprint_group_3)
    blueprint_group_3.append(blueprint_group_4)

    blueprint_group_1.middleware('request')(lambda request: 'ok')
    assert blueprint_group_2.middlewares['request'][0] == blueprint_group_1.middlewares['request'][0]
    assert blueprint_group_3.middlewares['request'][0] == blueprint_group_1.middlewares['request'][0]

# Generated at 2022-06-26 03:01:25.716589
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_1 = BlueprintGroup()
    blueprint_1 = Blueprint('blueprint_1', url_prefix='/blueprint')
    blueprint_1.middleware = Mock()
    blueprint_group_1.append(blueprint_1)


    blueprint_group_1.middleware()
    blueprint_1.middleware.assert_called_once_with()



# Generated at 2022-06-26 03:01:33.975097
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group = BlueprintGroup()
    blueprint_group.middleware(lambda a: a)
    blueprint_group.middleware(lambda a, b: a)
    blueprint_group.middleware(lambda a, b, c: a)
    blueprint_group.middleware(lambda a, b, c, d: a)
    blueprint_group.middleware(lambda a, b, c, d, e: a)
    blueprint_group.middleware(lambda a, b, c, d, e, f: a)
    blueprint_group.middleware(lambda a, b, c, d, e, f, g: a)
    blueprint_group.middleware(lambda a, b, c, d, e, f, g, h: a)

# Generated at 2022-06-26 03:01:37.094695
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware()
    blueprint_group_0.middleware("middleware")
    blueprint_group_0.middleware("middleware", "request", "response")


# Generated at 2022-06-26 03:01:40.181032
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    valid_middleware_func = lambda request: None
    test_blueprint_group = blueprint_group_0
    blueprint_group_0.middleware(valid_middleware_func)

# Generated at 2022-06-26 03:01:42.182318
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_obj = BlueprintGroup()
    blueprint_group_obj.middleware("request")


# Generated at 2022-06-26 03:01:46.372734
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    def middleware_decorator_wrapper_0(fn):
        pass
    middleware_decorator_wrapper_0 = blueprint_group_0.middleware(middleware_decorator_wrapper_0)


# Generated at 2022-06-26 03:01:53.139594
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)

    @group.middleware('request')
    async def group_middleware(request):
        assert True
    @group.middleware('request', 'response')
    async def group_middleware(request, response):
        assert True

    @group.middleware('request')
    def group_middleware(request):
        assert True

    @group.middleware('request', 'response')
    def group_middleware(request, response):
        assert True



# Generated at 2022-06-26 03:01:55.513245
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    def bp_middleware():
        pass
    blueprint_group_0.middleware(bp_middleware)



# Generated at 2022-06-26 03:02:10.068527
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup("url_prefix_0", "version_0", True)
    def fn_with_params_0():
        assert len(blueprint_group_0._middleware) == 1
    assert fn_with_params_0 == blueprint_group_0.middleware(fn_with_params_0)()


# Generated at 2022-06-26 03:02:13.622978
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    def fn(): return 1

    middleware = blueprint_group_0.middleware
    middleware(fn)



# Generated at 2022-06-26 03:02:17.963235
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_1.middleware(lambda f:f)
    blueprint_group_1.middleware('')
    blueprint_group_1.middleware(None)

# Generated at 2022-06-26 03:02:29.414421
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
	app = sanic.Sanic()
	run_order = []

	# Test of middleware

	# Define a middleware
	async def middleware_0(request):
		assert isinstance(request, sanic.request.Request)
		run_order.append(0)

	# Define a middleware
	async def middleware_1(request):
		assert isinstance(request, sanic.request.Request)
		run_order.append(1)

	# Define a middleware
	async def middleware_2(request):
		assert isinstance(request, sanic.request.Request)
		run_order.append(2)

	bp_0 = Blueprint('test_bp_0', url_prefix=None, version=None, strict_slashes=None)
	bp_

# Generated at 2022-06-26 03:02:37.687345
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.blueprint = Blueprint('url_prefix', 'url_prefix')
    blueprint_group_0.blueprint.route = mock.Mock(return_value=mock.Mock())
    blueprint_group_0.blueprint.middleware = mock.Mock()
    blueprint_group_0.middleware = mock.Mock()
    sanic.blueprints.Blueprint = mock.Mock()
    sanic.blueprints.Blueprint.route = mock.Mock(return_value=mock.Mock())
    sanic.blueprints.Blueprint.middleware = mock.Mock()
    blueprint_group_0.middleware()
    blueprint_group_0.blueprint.middleware.assert_called_with()
    blueprint_group_0.middleware

# Generated at 2022-06-26 03:02:41.649529
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(0, 1)
    blueprint_group_0.middleware(0, 1, 2, 3)


if __name__ == "__main__":
    test_case_0()
    test_BlueprintGroup_middleware()

# Generated at 2022-06-26 03:02:43.782015
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_mw_0 = BlueprintGroup()
    assert callable(blueprint_group_mw_0.middleware())


# Generated at 2022-06-26 03:02:49.466283
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    request_0 = sanic.request.Request(
        None, None, None, None, None, None, None, None, None, None
    )

    def foo(request_0):
        pass

    blueprint_group_0.middleware()
    blueprint_group_0.middleware(foo)


# Generated at 2022-06-26 03:02:51.027159
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware()


# Generated at 2022-06-26 03:03:01.679606
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_2 = BlueprintGroup()
    blueprint_group_3 = BlueprintGroup()
    blueprint_group_4 = BlueprintGroup()
    blueprint_group_5 = BlueprintGroup()
    blueprint_group_6 = BlueprintGroup()
    blueprint_group_7 = BlueprintGroup()
    blueprint_group_8 = BlueprintGroup()
    blueprint_group_9 = BlueprintGroup()
    blueprint_group_10 = BlueprintGroup()
    blueprint_group_11 = BlueprintGroup()
    blueprint_group_12 = BlueprintGroup()
    blueprint_group_13 = BlueprintGroup()
    blueprint_group_14 = BlueprintGroup()
    blueprint_group_15 = BlueprintGroup()
    blueprint_group_16 = BlueprintGroup()
    blueprint_group_17 = BlueprintGroup()
   

# Generated at 2022-06-26 03:03:23.403694
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_1 = Blueprint('blueprint_1', url_prefix='/blueprint_1')

    blueprint_group_0.append(blueprint_1)

    async def middleware_0(request):
        pass

    blueprint_group_0.middleware(middleware_0)(middleware_0)

    assert blueprint_group_0._blueprints[0]._middlewares\
        ['request'][0]._handler == middleware_0



# Generated at 2022-06-26 03:03:26.190293
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware("fn")
    blueprint_group_0.middleware("fn", route='/')


# Generated at 2022-06-26 03:03:29.081967
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()

    @blueprint_group_0.middleware
    def some_middleware(request):
        pass
    pass


# Generated at 2022-06-26 03:03:36.967902
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from unittest.mock import MagicMock

    app = sanic.Sanic("test_BlueprintGroup_middleware")
    bp1 = Blueprint("bp1", url_prefix="/test")
    bp2 = Blueprint("bp2", url_prefix="/test")
    app.blueprint(bp1)
    app.blueprint(bp2)

    bpg = BlueprintGroup(bp1, bp2)

    bp1_middleware = MagicMock()
    bp2_middleware = MagicMock()

    @bpg.middleware("request")
    def common_middleware(request):
        bp1_middleware(request)
        bp2_middleware(request)
        return text("middleware")

    assert len(bp1.middlewares["request"]) == 1

# Generated at 2022-06-26 03:03:39.903202
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware() # call without parameter
    blueprint_group_0.middleware(sanic.response.json, attach_to='response')


# Generated at 2022-06-26 03:03:43.994986
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()

    @blueprint_group_0.middleware('request')
    async def bp1_only_middleware(request):
        return text('bp1')


# Generated at 2022-06-26 03:03:52.451657
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('test_bp1')
    bp2 = Blueprint('test_bp2')
    test_bg = BlueprintGroup()
    test_bg.append(bp1)
    test_bg.append(bp2)

    @test_bg.middleware
    async def mock_middleware(request):
        pass

    assert (bp1.middleware_functions['response'][0].__name__ == mock_middleware.__name__)
    assert (bp2.middleware_functions['response'][0].__name__ == mock_middleware.__name__)


# Test for blueprint group argument variants

# Generated at 2022-06-26 03:03:59.372987
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()

    @blueprint_group_0.middleware('request')
    def _arg_0(request):
        print('applied on Blueprint : bp1 Only')

    @blueprint_group_0.middleware('request')
    def _arg_1(request):
        print('applied on Blueprint : bp2 Only')

    app = sanic.Sanic()

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    @bp1.middleware('request')
    def _arg_2(request):
        print('applied on Blueprint : bp1 Only')


# Generated at 2022-06-26 03:04:00.983085
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware()

# Generated at 2022-06-26 03:04:12.417179
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Unit Test for BlueprintGroup.middleware

    BlueprintGroup.middleware(fn, *args, **kwargs)

    :param fn:
    :param *args:
    :param **kwargs:
    :return:
    """
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup("url_prefix_1", 1, True)

    @blueprint_group_1.middleware("middleware_1", "middleware_2")
    @blueprint_group_0.middleware("middleware_2")
    def dec_fn_0(list_a, list_b):
        pass

    assert blueprint_group_0.middleware("middleware_2")
    assert blueprint_group_1.middleware("middleware_1", "middleware_2")


# Generated at 2022-06-26 03:04:42.966902
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp0 = Blueprint("bp0")
    bp1 = Blueprint("bp1")

    group = BlueprintGroup()
    group.append(bp0)
    group.append(bp1)

    @group.middleware("request")
    async def common_middleware(request):
        request["processed"] = "true"

    @bp0.middleware("request")
    async def bp0_middleware(request):
        request["bp0"] = "done"

    @bp1.middleware("request")
    async def bp1_middleware(request):
        request["bp1"] = "done"

    @bp0.route("/")
    async def simple(request):
        return text("Hello")

    @bp1.route("/")
    async def simple(request):
        return text("World")



# Generated at 2022-06-26 03:04:48.016146
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp = Blueprint("bp")
    bp_group = BlueprintGroup()
    bp_group.append(bp)
    assert len(bp_group.blueprints) == 1
    assert (
        str(bp_group.blueprints[0].middleware)
        == "functools.partial(<function add_middleware at 0x7f1d64e2ad08>, <class 'sanic.blueprint.Blueprint'>, 'request')"
    )

# Generated at 2022-06-26 03:04:49.520582
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_1.middleware(sanic.response)


# Generated at 2022-06-26 03:04:57.274038
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic(name="test_sanic")
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2)

    @group.middleware('request')
    async def bp_middleware(request):
        pass
    for bp in group.blueprints:
        assert bp_middleware in bp.middleware_stack['request']

    app = sanic.Sanic(name="test_sanic")
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2)
    group.middle

# Generated at 2022-06-26 03:05:02.207556
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    def handler_fn():
        return "hello!"
    try:
        bp = Blueprint(name="test", version=1)
        bpg = BlueprintGroup()
        bpg.append(bp)
        bpg.middleware(handler_fn)
        assert len(bp.middleware["request"]) == 1
        assert len(bp.middleware["response"]) == 1
    except Exception as e:
        assert False, f"Test case failed: {__file__}"


# Generated at 2022-06-26 03:05:09.054747
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    # test case 0
    blueprint_group_0 = BlueprintGroup()
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    blueprint_group_0.append(bp1)
    blueprint_group_0.append(bp2)
    blueprint_group_0.middleware(bp1.app)
    blueprint_group_0.middleware(bp2.app)
    actual = blueprint_group_0.middleware(bp1.app)
    actual = blueprint_group_0.middleware(bp2.app)
    assert actual is None


# Generated at 2022-06-26 03:05:15.487853
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint("name", "url_prefix", host="host")
    blueprint_1 = Blueprint("name", "url_prefix", host="host")
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.append(blueprint_1)
    blueprint_group_0.middleware("middleware", "middleware")


if __name__ == "__main__":
    test_BlueprintGroup_middleware()

# Generated at 2022-06-26 03:05:18.686480
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_ = BlueprintGroup()
    fn = lambda request: None
    blueprint_group_.middleware(fn)
    blueprint_group_.middleware(fn, attach_to='request', use_args=True)



# Generated at 2022-06-26 03:05:22.214529
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group = BlueprintGroup()
    blueprint_group.middleware(None)
    blueprint_group.middleware(None, None)
    blueprint_group.middleware(None, None, None)
    blueprint_group.middleware()
    blueprint_group.middleware(None)



# Generated at 2022-06-26 03:05:24.141090
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    def unary_(fn):
        return fn
    unary_.__name__ = 'unary_'
    blueprint_group_0.middleware(unary_)



# Generated at 2022-06-26 03:06:20.573132
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_0 = BlueprintGroup('/route', '8.81', True)
    blueprint_0 = Blueprint('/route', '8.81', True)
    blueprint_group_0[0] = blueprint_0
    blueprint_0 = blueprint_group_0[0]
    blueprint_group_0[0] = blueprint_0
    blueprint_group_0[1000] = blueprint_0
    blueprint_group_0[9999] = blueprint_0
    blueprint_group_0[5] = blueprint_0


# Generated at 2022-06-26 03:06:23.973596
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint(url_prefix='/', version=None, strict_slashes=None)
    blueprint_group_0.append(blueprint_0)
    try:
        del blueprint_group_0[0]
    except:
        assert False
    assert True


# Generated at 2022-06-26 03:06:29.839302
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(Blueprint('bp0', url_prefix='/bp0'))
    blueprint_group_0.append(Blueprint('bp1', url_prefix='/bp1'))
    blueprint_group_0.append(Blueprint('bp2', url_prefix='/bp2'))
    blueprint_group_0.__delitem__( 1 )


# Generated at 2022-06-26 03:06:37.459743
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append("https://www.codechef.com/rankings/recipes?sort_by=global_rank")
    blueprint_group_0.append("https://www.codechef.com/rankings/recipes?sort_by=global_rank")
    blueprint_group_0.insert(0, "https://www.codechef.com/rankings/recipes?sort_by=global_rank")
    blueprint_group_0.insert(0, "https://www.codechef.com/rankings/recipes?sort_by=global_rank")
    blueprint_group_0.insert(0, "https://www.codechef.com/rankings/recipes?sort_by=global_rank")
    blueprint_group

# Generated at 2022-06-26 03:06:43.979491
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint('blueprint_0', url_prefix='/blueprint/0')
    blueprint_group_0.append(blueprint_0)
    blueprint_1 = Blueprint('blueprint_1', url_prefix='/blueprint/1')
    blueprint_group_0.append(blueprint_1)
    blueprint_2 = Blueprint('blueprint_2', url_prefix='/blueprint/2')
    blueprint_group_0.append(blueprint_2)
    blueprint_group_0.__setitem__(1, blueprint_1)


# Generated at 2022-06-26 03:06:46.789520
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.__iter__()


# Generated at 2022-06-26 03:06:55.877709
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint('blueprint_0', url_prefix='/blueprint_0')
    blueprint_1 = Blueprint('blueprint_1', url_prefix='/blueprint_1')
    blueprint_2 = Blueprint('blueprint_2', url_prefix='/blueprint_2')
    blueprint_3 = Blueprint('blueprint_3', url_prefix='/blueprint_3')
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.append(blueprint_1)
    blueprint_group_0.append(blueprint_2)
    assert len(blueprint_group_0) == 3
    assert blueprint_group_0[0] == blueprint_0
    assert blueprint_group_0[1] == blueprint_1
    assert blueprint_group_0

# Generated at 2022-06-26 03:06:58.764593
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(blueprint_group_0)
    blueprint_group_0.append(blueprint_group_0)


# Generated at 2022-06-26 03:07:05.442490
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_1 = BlueprintGroup()

    @blueprint_group_1.middleware()
    def middleware_0(request):
        pass
    
    @blueprint_group_1.middleware('request')
    def middleware_1(request):
        pass

    @blueprint_group_1.middleware('request', 'response')
    def middleware_2(request, response):
        pass


# Generated at 2022-06-26 03:07:15.199742
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_0 = BlueprintGroup('vyFxW', 'v', True)
    blueprint_group_1 = BlueprintGroup('Uv', 'dKVuL', 'Pz')
    blueprint_group_2 = BlueprintGroup('rtN')
    blueprint_group_3 = BlueprintGroup('g')
    blueprint_group_4 = BlueprintGroup()
    blueprint_group_5 = BlueprintGroup('A', 'bEqg', 'h')
    blueprint_group_0.append(blueprint_group_1)
    blueprint_group_0.append(blueprint_group_2)
    blueprint_group_0.append(blueprint_group_3)
    blueprint_group_0.append(blueprint_group_4)
    blueprint_group_0.append(blueprint_group_5)