

# Generated at 2022-06-26 03:00:01.749213
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware('request', [])
    blueprint_group_0.middleware('request', [])


# Generated at 2022-06-26 03:00:13.905305
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class SanicMock(object):
        pass
    sanic_mock_obj = SanicMock()
    blueprint_group_obj = BlueprintGroup()
    
    class BlueprintMock(object):
        def _register_middleware(self, fn, *args, **kwargs):
            self.fn = fn
            self.args = args
            self.kwargs = kwargs
    
    blueprint_mock_obj = BlueprintMock()
    blueprint_group_obj.blueprints.append(blueprint_mock_obj)
    
    # Testing for following line
    # 'middlewares': [{
    #     'name': 'middleware_create_user_from_request',
    #     'args': [],
    #     'kwargs': {}
    # }, {
    #     'name': 'middle

# Generated at 2022-06-26 03:00:24.113103
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup()


    @blueprint_group_0.middleware('request')
    def blueprint_group_0_middleware(request):
        print( 'applied on BlueprintGroup : blueprint_group_0_middleware' )

    @blueprint_group_0.route('/')
    async def blueprint_group_0_route(request):
        return text('bp1')

    @blueprint_group_1.middleware('request')
    def blueprint_group_1_middleware(request):
        print( 'applied on BlueprintGroup : blueprint_group_1_middleware' )

    @blueprint_group_1.route('/<param>')
    async def blueprint_group_1_route(request, param):
        return text(param)



# Generated at 2022-06-26 03:00:34.951284
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup(url_prefix='/test_BlueprintGroup_url_prefix_0', version='test_BlueprintGroup_version_0', strict_slashes='test_BlueprintGroup_strict_slashes_0')

    @blueprint_group_1.middleware()
    def middleware_fn_0():
        pass

    @blueprint_group_0.middleware('blueprint_group_1')
    def middleware_fn_1():
        pass

    @blueprint_group_1.middleware()
    def middleware_fn_2():
        pass

    @blueprint_group_0.middleware('blueprint_group_1')
    def middleware_fn_3():
        pass


# Generated at 2022-06-26 03:00:42.978663
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0_middleware_0 = Blueprint.middleware(blueprint_group_0)
    blueprint_group_0_middleware_0(request=None)
    blueprint_group_0_middleware_1 = blueprint_group_0.middleware(request=None)
    blueprint_group_0_middleware_1(request=None)
    blueprint_group_0_middleware_2 = blueprint_group_0.middleware(view=None)
    blueprint_group_0_middleware_2(request=None)


# Generated at 2022-06-26 03:00:46.011004
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware('request')
    blueprint_group_0.middleware('request', 'response')





# Generated at 2022-06-26 03:00:50.799899
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @sanic.blueprint.middleware('REQUEST')
    def test1(request):
        pass
    group = BlueprintGroup('/api/v0.1')
    group.middleware(test1)
    for blueprint in group.blueprints:
        assert blueprint.middlewares['REQUEST'][0] == test1


# Generated at 2022-06-26 03:00:54.178883
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    test_bg = BlueprintGroup(url_prefix="/api/v1", version=1.0)

    @test_bg.middleware('response')
    async def test_middleware(request, response):
        pass

    for bp in test_bg.blueprints:
        assert bp.version == 1.0


# Generated at 2022-06-26 03:01:02.408529
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Setup parameter for the method
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0._blueprints.append(bp1)
    blueprint_group_0._blueprints.append(bp2)
    blueprint_group_0.middleware(bp1, bp2)
    blueprint_group_0.middleware(bp1)
    blueprint_group_0.middleware(bp1)
    blueprint_group_0.middleware(bp2)


# Generated at 2022-06-26 03:01:11.978427
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(bp1)
    blueprint_group_0.append(bp2)
    blueprint_group_0.append(bp3)
    blueprint_group_0.append(bp4)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')


# Generated at 2022-06-26 03:01:27.382496
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Code to test the valid scenario with all the parameters passed
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    # BlueprintGroup.middleware
    @bpg.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    # Blueprint1.middleware
    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    # Blueprint2.middleware

# Generated at 2022-06-26 03:01:30.631388
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint('bp1', url_prefix='/bp1')
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.middleware(blueprint_0.middleware)



# Generated at 2022-06-26 03:01:39.583216
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_1 = BlueprintGroup()

    blueprint_group_1.middleware(True)
    blueprint_group_1.middleware(True, False)
    blueprint_group_1.middleware(False, True, False)
    blueprint_group_1.middleware(True, True, True, True)
    blueprint_group_1.middleware(False, True, True, True, False)
    blueprint_group_1.middleware(True, False, True, True, True, True)
    blueprint_group_1.middleware(True, True, False, True, True, True, True)
    blueprint_group_1.middleware(True, True, True, False, True, True, True, True)
    blueprint_group_1.middleware(True, True, True, True, False, True, True, True, True)

# Generated at 2022-06-26 03:01:45.960874
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()
    bp = Blueprint('bp', url_prefix='/bp')
    bp_group = BlueprintGroup(bp, url_prefix="/api")
    @bp_group.middleware('request')
    async def bp_group_middleware(request):
        pass
    assert bp_group.blueprints[0].middleware['request'][0].__name__ == 'bp_group_middleware'



# Generated at 2022-06-26 03:01:54.191387
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    import random
    import string
    import unittest
    from unittest.mock import MagicMock

    # Create a Sanic App
    sanic_app_0 = MagicMock()
    # Create a Sanic App
    sanic_app_0 = sanic.Sanic()
    # Create a Blueprint Group
    blueprint_group_0 = BlueprintGroup()
    # Register Blueprint Group under the app
    sanic_app_0.blueprint(blueprint_group_0)
    # Create a Blueprint
    blueprint_1 = Blueprint("blueprint_1", url_prefix="/v1/hello")
    # Create a Blueprint
    blueprint_2 = Blueprint("blueprint_2", url_prefix="/v2/hello")

    # Register blueprint with the App
    blueprint_group_0.append(blueprint_1)
    # Register

# Generated at 2022-06-26 03:02:08.566178
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()

    bp0 = Blueprint('bp0', url_prefix='/bp0')
    bp1 = Blueprint('bp1', url_prefix='/bp1')

    @bp0.middleware('request')
    async def middleware_1(request):
        pass
    def middleware_2(request):
        pass

    # testing BlueprintGroup.middleware
    bpg = BlueprintGroup(bp0, bp1)
    bpg.middleware(middleware_2)
    assert len(bp0.middlewares['request']) == 2
    assert middleware_2 in bp0.middlewares['request']
    assert len(bp1.middlewares['request']) == 1
    assert middleware_2 in bp1.middlewares['request']


# Generated at 2022-06-26 03:02:18.646391
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(None, None)
    blueprint_group_0.middleware(None, None, None)
    blueprint_group_0.middleware(None, None, a=1)
    blueprint_group_0.middleware(None)

    @blueprint_group_0.middleware()
    def handler0(request): pass

    @blueprint_group_0.middleware(a=1)
    def handler1(request): pass

    @blueprint_group_0.middleware(a=1, b=2)
    def handler2(request): pass

    @blueprint_group_0.middleware(request=sanic.request('GET', '/'))
    def handler3(request): pass



# Generated at 2022-06-26 03:02:19.468949
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group = BlueprintGroup()
    blueprint_group.middleware(lambda x:x)

# Generated at 2022-06-26 03:02:30.915361
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2)

    counter = 0

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/')
    async def bp2_route(request):
        return text('bp2')

    @group.middleware('request')
    async def group_middleware(request):
        nonlocal counter
        counter += 1

    app.blueprint(group)

    client = app.test_client

    assert client.get('/bp1/').status == 200

# Generated at 2022-06-26 03:02:33.723090
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.blueprints = [Blueprint(url_prefix='/'), Blueprint()]
    blueprint_group_0.middleware(lambda request: None)


# Generated at 2022-06-26 03:02:53.212069
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(Blueprint(url_prefix='/bp1', name='bp1'))
    blueprint_group_0.append(Blueprint(url_prefix='/bp2', name='bp2'))
    blueprint_group_0.append(Blueprint(url_prefix='/bp3', name='bp3'))
    blueprint_group_0.append(Blueprint(url_prefix='/bp4', name='bp4'))
    blueprint_group_0.append(Blueprint(url_prefix='/bp5', name='bp5'))
    blueprint_group_0.append(Blueprint(url_prefix='/bp6', name='bp6'))
    blueprint_group_0.append(Blueprint(url_prefix='/bp7', name='bp7'))

# Generated at 2022-06-26 03:03:00.127438
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append(): 
    expected_call_stack = ['append', 'append', 'append', 'append']
    real_call_stack = []
    class StubMutableSequence:
        def append(self, x):
            real_call_stack.append("append")
    blueprint_group = BlueprintGroup()
    blueprint_group.append = StubMutableSequence().append
    blueprint_group.append("test_value")
    assert real_call_stack == expected_call_stack



# Generated at 2022-06-26 03:03:07.625070
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    test_blueprint_0 = Blueprint('test_blueprint_0', url_prefix='/test_blueprint_0')
    blueprint_group_0 = BlueprintGroup(url_prefix='/blueprint_group_0')
    blueprint_group_0.append(test_blueprint_0)
    blueprint_group_0.insert(0, test_blueprint_0)
    assert blueprint_group_0[0] is test_blueprint_0


# Generated at 2022-06-26 03:03:15.846190
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_2 = BlueprintGroup()
    blueprint_group_3 = BlueprintGroup()
    blueprint_group_4 = BlueprintGroup()
    blueprint_group_5 = BlueprintGroup()
    blueprint_group_6 = BlueprintGroup()
    blueprint_group_7 = BlueprintGroup()
    blueprint_group_8 = BlueprintGroup()
    blueprint_group_9 = BlueprintGroup()
    blueprint_group_10 = BlueprintGroup()
    blueprint_group_11 = BlueprintGroup()
    blueprint_group_12 = BlueprintGroup()
    blueprint_group_13 = BlueprintGroup()
    blueprint_group_14 = BlueprintGroup()
    blueprint_group_15 = BlueprintGroup()
    blueprint_group_16 = BlueprintGroup()
    blueprint_group_17 = BlueprintGroup()
    blueprint_group_18 = BlueprintGroup()
   

# Generated at 2022-06-26 03:03:28.000208
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_0 = BlueprintGroup(version='v1', url_prefix='/api')
    blueprint_group_1 = BlueprintGroup(version='v1', url_prefix='/api')
    blueprint_0 = Blueprint('blueprint_0', url_prefix='/blueprint-0')
    blueprint_1 = Blueprint('blueprint_1', url_prefix='/blueprint-1')
    @blueprint_0.route('/')
    def blueprint_route_0_0(request):
        text('Route 0')
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.append(blueprint_1)
    blueprint_group_0[0] = blueprint_1
    blueprint_group_0[1] = blueprint_0
    blueprint_group_1.append(blueprint_0)
    blueprint

# Generated at 2022-06-26 03:03:33.552118
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_1 = Blueprint("blueprint_1", url_prefix="blueprint_1")
    blueprint_group_0.append(blueprint_1)
    blueprint_2 = Blueprint("blueprint_2", url_prefix="blueprint_2")
    blueprint_group_0.append(blueprint_2)
    blueprint_group_0[0] = blueprint_1
    blueprint_group_0[1] = blueprint_2


# Generated at 2022-06-26 03:03:35.511170
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.insert(0, Blueprint("bp0", url_prefix="/bp0"))


# Generated at 2022-06-26 03:03:38.653454
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint('bp1', url_prefix='/bp1')
    blueprint_group_0.insert(0, blueprint_0)


# Generated at 2022-06-26 03:03:41.409719
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint_group_0 = BlueprintGroup()
    assert (isinstance(blueprint_group_0, BlueprintGroup))



# Generated at 2022-06-26 03:03:45.000468
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group = BlueprintGroup()
    blueprint_instance = blueprint_group.append(sanic.Blueprint('test_name_22'))
    blueprint_group.__setitem__(0, blueprint_instance)



# Generated at 2022-06-26 03:04:02.540700
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    blueprint_group_1 = BlueprintGroup()
    blueprint_1 = Blueprint("bp1", url_prefix="/bp1")
    blueprint_2 = Blueprint("bp2", url_prefix="/bp2")
    blueprint_group_1.append(blueprint_1)
    blueprint_group_1.append(blueprint_2)
    assert blueprint_group_1._blueprints == [blueprint_1, blueprint_2]
    return blueprint_group_1


# Generated at 2022-06-26 03:04:04.448277
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup
    blueprint_group_0.middleware()


# Generated at 2022-06-26 03:04:13.643593
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(Blueprint("bp_0"))
    blueprint_group_0.append(Blueprint("bp_1"))
    blueprint_group_0.append(Blueprint("bp_2"))
    blueprint_group_0.append(Blueprint("bp_3"))
    blueprint_group_0.append(Blueprint("bp_4"))

    assert blueprint_group_0[0].name == "bp_0"
    assert blueprint_group_0[4].name == "bp_4"
    assert blueprint_group_0[2].name == "bp_2"
    assert blueprint_group_0[3].name == "bp_3"
    assert blueprint_group_0[1].name == "bp_1"


# Generated at 2022-06-26 03:04:19.924950
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint.group(blueprint_group_0)
    blueprint_1 = Blueprint.group(blueprint_group_0)
    blueprint_2 = Blueprint.group(blueprint_group_0)

    blueprint_group_0[0] = blueprint_0
    blueprint_group_0[1] = blueprint_1
    blueprint_group_0[2] = blueprint_2



# Generated at 2022-06-26 03:04:21.814345
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_0 = BlueprintGroup()
    assert len(blueprint_group_0) == 0


# Generated at 2022-06-26 03:04:27.590185
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group = BlueprintGroup('/')

    @blueprint_group.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    blueprint_group.append(bp1)
    blueprint_group.append(bp2)

# Generated at 2022-06-26 03:04:35.886497
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_0 = BlueprintGroup()
    assert len(blueprint_group_0) == 0
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_1.append(Blueprint('bp1', url_prefix='/bp1'))
    assert len(blueprint_group_1) == 1
    blueprint_group_2 = BlueprintGroup()
    blueprint_group_2.append(Blueprint('bp1', url_prefix='/bp1'))
    blueprint_group_2.append(Blueprint('bp2', url_prefix='/bp2'))
    assert len(blueprint_group_2) == 2


# Generated at 2022-06-26 03:04:40.282850
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group_0 = BlueprintGroup("/", 1)
    blueprint_0 = Blueprint("/", 1)
    blueprint_1 = Blueprint("/", 1)
    blueprint_group_0.insert(0, blueprint_0)
    blueprint_group_0.insert(1, blueprint_1)
    blueprint_group_0.insert(2, blueprint_0)



# Generated at 2022-06-26 03:04:44.039859
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())

    test_0 = [i for i in blueprint_group_0]
    assert len(test_0) == 3
    assert all([isinstance(i, Blueprint) for i in test_0])


# Generated at 2022-06-26 03:04:50.382812
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(Blueprint(None))
    blueprint_group_0.append(Blueprint(None))
    blueprint_group_0.append(Blueprint(None))
    blueprint_group_0.append(Blueprint(None))
    blueprint_group_0.append(Blueprint(None))
    blueprint_group_0.append(Blueprint(None))
    blueprint_group_0.append(Blueprint(None))
    blueprint_group_0.append(Blueprint(None))
    blueprint_group_0.append(Blueprint(None))
    blueprint_group_0.append(Blueprint(None))
    blueprint_group_0.append(Blueprint(None))
    blueprint_group_0.append(Blueprint(None))
    blueprint_group_0.append

# Generated at 2022-06-26 03:05:20.851313
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group_0 = BlueprintGroup("?J")
    blueprint_0 = Blueprint("0]b\"R","?J", "/[E", parse_body=True)
    blueprint_0._url_prefix = "/[E"
    blueprint_0._version = "?J"
    blueprint_0._strict_slashes = False
    blueprint_group_0.insert(0, blueprint_0)
    blueprint_0 = Blueprint("%R\"z","Or7", "/[E", parse_body=True)
    blueprint_0._url_prefix = "/[E"
    blueprint_0._version = "Or7"
    blueprint_0._strict_slashes = True
    blueprint_group_0.insert(0, blueprint_0)
    value = blueprint_group_0._blueprints[0]._version

# Generated at 2022-06-26 03:05:23.204122
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_instance_0 = Blueprint('blueprint_instance_0', url_prefix='/blueprint_instance_0')
    blueprint_group_0.append(blueprint_instance_0)
    blueprint_group_0.__setitem__(0, blueprint_instance_0)


# Generated at 2022-06-26 03:05:33.446876
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_1.append(1)
    blueprint_group_1.append(2)
    blueprint_group_1.append([3,4])
    blueprint_group_1.append((5,6))
    blueprint_group_1.append([[7,8],(9,10)])
    blueprint_group_1.append('a')
    blueprint_group_1.append('b')
    blueprint_group_1.append("c")
    blueprint_group_1.append("d")
    assert blueprint_group_1 == [1, 2, [3, 4], (5, 6), [[7, 8], (9, 10)], 'a', 'b', 'c', 'd']


# Generated at 2022-06-26 03:05:44.135180
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():

    blueprint_group_1 = BlueprintGroup(strict_slashes=False)
    blueprint_group_1.append(sanic.Blueprint('blueprint_1'))

    # Tests the case where item is an int

    # Test when item is not between 0 and length of list
    try:
        blueprint_group_1.__delitem__(1)
    except IndexError:
        assert True
    else:
        assert False

    # Test when item is negative and not between 0 and length of list
    try:
        blueprint_group_1.__delitem__(-2)
    except IndexError:
        assert True
    else:
        assert False

    # Tests the case where item is a slice

    # Test when start is not between 0 and length of list

# Generated at 2022-06-26 03:05:47.174785
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    # Test case 0: String type index
    with pytest.raises(TypeError):
        test_case_0()

        # Test case 1: Index out of range
        # Test case 2: Valid Index


# Generated at 2022-06-26 03:05:58.295034
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp_1 = Blueprint('bp_1', url_prefix='/bp1')
    bp_2 = Blueprint('bp_2', url_prefix='/bp2')
    bp_3 = Blueprint('bpg_1', url_prefix='/bpg1')
    bp_4 = Blueprint('bpg_2', url_prefix='/bpg2')
    blueprint_group_1 = BlueprintGroup('/bpg', version='v1')
    blueprint_group_1.append(bp_3)
    blueprint_group_1.append(bp_4)
    blueprint_group_2 = BlueprintGroup('/api', version='v2')
    blueprint_group_2.append(bp_1)
    blueprint_group_2.append(bp_2)
    blueprint_group_2.append(blueprint_group_1)

# Generated at 2022-06-26 03:05:59.790083
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware()


# Generated at 2022-06-26 03:06:01.061806
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()


# Generated at 2022-06-26 03:06:05.840194
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint("bp1", url_prefix='/bp1')
    bp2 = Blueprint("bp2", url_prefix='/bp2')
    bp3 = Blueprint("bp3", url_prefix='/bp4')
    
    bpg = BlueprintGroup("/bp4")
    bpg.append(bp3)
    bpg.append(bp4)

    assert bpg[0] == bp3
    assert bpg[1] == bp4


# Generated at 2022-06-26 03:06:08.608923
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint('bp1', url_prefix='/bp1')
    blueprint_group_0.__setitem__(0, blueprint_0)
