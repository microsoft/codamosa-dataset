

# Generated at 2022-06-26 02:59:55.429862
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    var_0 = blueprint_group_0.middleware()


# Generated at 2022-06-26 03:00:01.475935
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_2 = BlueprintGroup()
    blueprint_group_3 = BlueprintGroup()
    blueprint_group_4 = BlueprintGroup()
    blueprint_group_5 = BlueprintGroup()
    blueprint_group_6 = BlueprintGroup()
    blueprint_group_7 = BlueprintGroup()
    blueprint_group_8 = BlueprintGroup()
    blueprint_group_9 = BlueprintGroup()
    blueprint_group_10 = BlueprintGroup()
    blueprint_group_11 = BlueprintGroup()
    blueprint_group_12 = BlueprintGroup()
    blueprint_group_13 = BlueprintGroup()
    blueprint_group_14 = BlueprintGroup()
    blueprint_group_15 = BlueprintGroup()
    blueprint_group_16 = BlueprintGroup()
    blueprint_group_17 = BlueprintGroup()
    blueprint_group_18 = BlueprintGroup()
   

# Generated at 2022-06-26 03:00:03.323024
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    var_0 = blueprint_group_0.middleware(1)

# Generated at 2022-06-26 03:00:05.690775
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    assert blueprint_group_0.middleware()



# Generated at 2022-06-26 03:00:10.745896
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @blueprint_group_0.middleware('request')
    def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')

# Generated at 2022-06-26 03:00:13.216538
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    assert_equal(None, blueprint_group_0.middleware())


# Generated at 2022-06-26 03:00:15.210516
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    var_0 = blueprint_group_0.middleware()


# Generated at 2022-06-26 03:00:18.936734
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint()
    blueprint_group_0.append(blueprint_0)
    blueprint_1 = Blueprint()
    blueprint_group_0.append(blueprint_1)
    var_0 = blueprint_group_0.middleware()


# Generated at 2022-06-26 03:00:22.676310
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Initializing arbitrary variables for test method
    blueprint_group_0 = BlueprintGroup()

    # Calling method to get the partial function
    var_0 = blueprint_group_0.middleware()

    assert(callable(var_0))

# Generated at 2022-06-26 03:00:24.337621
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    var_0 = blueprint_group_0.middleware()

# Generated at 2022-06-26 03:00:28.041681
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    var_0 = blueprint_group_0.middleware()


# Generated at 2022-06-26 03:00:30.733694
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    var_0 = blueprint_group_0.middleware()


# Generated at 2022-06-26 03:00:39.247006
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Create a application instance.
    sanic_app = sanic.Sanic(name=__name__)

    # Create a Blueprint instance.
    blueprint_instance_0 = Blueprint(name="test_Blueprint_0", url_prefix="/test")

    # Create a BlueprintGroup instance.
    blueprint_group_instance_0 = BlueprintGroup(url_prefix="/prefix")

    # Inject a Blueprint instance into a BlueprintGroup instance.
    blueprint_group_instance_0.append(blueprint_instance_0)

    # Wrap in a middleware using the BlueprintGroup instance.
    @blueprint_group_instance_0.middleware
    async def middleware_for_blueprint_group_instance_0(request):
        pass

# Generated at 2022-06-26 03:00:45.667680
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_0 = BlueprintGroup()
    def var_1(blueprint_group_2, *args_1, **kwargs_0):
        blueprint_group_0 = blueprint_group_2
        var_0 = blueprint_group_0.middleware()
    var_0 = blueprint_group_1.middleware(var_1)



# Generated at 2022-06-26 03:00:51.896939
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Test middleware method of class BlueprintGroup
    """
    blueprint_group_0 = BlueprintGroup("http://localhost:5000/api/v1")
    blueprint_group_0.append("http://localhost:5000/api/v1")
    blueprint_group_0.append("http://localhost:5000/api/v1")
    blueprint_group_0.append("http://localhost:5000/api/v1")

    blueprint_group_0.middleware()

# Generated at 2022-06-26 03:00:58.714201
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_2 = BlueprintGroup()
    # Test 1: For Middleware without Positional and Keyword Arguments
    try:
        blueprint_group_1.middleware().__code__.co_argcount == 1
    except AssertionError:
        raise AssertionError(
            "Expected: (1), Actual: ({})".format(
                blueprint_group_1.middleware().__code__.co_argcount
            )
        )
    # Test 2: For Middleware with Positional and Keyword Arguments
    blueprint_group_2.middleware(1, a=1).__code__.co_argcount == 2
    try:
        blueprint_group_2.middleware(1, a=1)
    except AssertionError:
        raise Assertion

# Generated at 2022-06-26 03:01:03.041877
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Unit test for method middleware of class BlueprintGroup
    """
    blueprint_group_0 = BlueprintGroup()
    var_0 = blueprint_group_0.middleware()
    # assert var_0 == <sanic.blueprints.BlueprintGroup object at 0x1014b9f28>


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 03:01:04.688866
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    var_0 = blueprint_group_0.middleware()
test_BlueprintGroup_middleware()

# Generated at 2022-06-26 03:01:12.168329
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    def f(self, request):
        print((request['query']))
    blueprint_group_0.middleware(f)
    blueprints = dict()
    blueprints['bp1'] = Blueprint('bp1', url_prefix='/bp1')
    blueprints['bp2'] = Blueprint('bp2', url_prefix='/bp2')
    blueprint_group_0.blueprints.extend(blueprints.values())
    request_0 = dict()
    request_0['query'] = 'test case'
    blueprints['bp2'].middleware(f)(request_0)

# Generated at 2022-06-26 03:01:20.446960
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    decorator_0 = blueprint_group_0.middleware()
    decorator_1 = blueprint_group_0.middleware(sanic.request_middleware)
    decorator_2 = blueprint_group_0.middleware(sanic.response_middleware)
    decorator_3 = blueprint_group_0.middleware(sanic.middleware.error_handler)
    def function_0(request):
        return None
    function_0 = decorator_0(function_0)


# Generated at 2022-06-26 03:01:31.823713
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_2 = BlueprintGroup()
    blueprint_group_3 = BlueprintGroup()
    blueprint_group_4 = BlueprintGroup()
    blueprint_group_5 = BlueprintGroup()
    blueprint_group_6 = BlueprintGroup()
    blueprint_group_7 = BlueprintGroup()

    blueprint_group_7.append(blueprint_group_6)
    blueprint_group_6.append(blueprint_group_5)
    blueprint_group_5.append(blueprint_group_4)
    blueprint_group_4.append(blueprint_group_3)
    blueprint_group_3.append(blueprint_group_2)
    blueprint_group_2.append(blueprint_group_1)

    blueprint_group_1.append(Blueprint("blueprint_name"))
    blueprint

# Generated at 2022-06-26 03:01:36.556983
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_0 = Blueprint(url_prefix='/', version='v1')
    blueprint_1 = Blueprint(url_prefix='/v2', version='v2')
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.append(blueprint_1)
    var_0 = blueprint_group_0.middleware(None)


# Generated at 2022-06-26 03:01:45.797047
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    # Input Variables
    blueprint_group_0 = BlueprintGroup()
    args_0 = list()
    kwargs_0 = dict()
    fn_0 = object()

    # Add whatever need to the kwargs variable
    kwargs_0 = {}

    # Add whatever need to the args variable
    args_0.append(fn_0)

    # run the test
    # Note : "args" is not a keyword argument
    var_0 = blueprint_group_0.middleware(*args_0, **kwargs_0)

    # check the output
    assert type(var_0) == partial
    assert var_0.func == blueprint_group_0.middleware



# Generated at 2022-06-26 03:01:49.573841
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    var_0 = blueprint_group_0.middleware()


# Generated at 2022-06-26 03:01:51.684222
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    BlueprintGroup_instance_0 = BlueprintGroup()
    BlueprintGroup_instance_0.middleware()


# Generated at 2022-06-26 03:01:57.223577
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_1 = BlueprintGroup(strict_slashes=True, url_prefix='/c', version='/a')
    blueprint_group_1.middleware(True)
    blueprint_group_1.blueprints = [None]
    assert blueprint_group_1.middleware(True)
    assert blueprint_group_1.version == '/a'
    assert not blueprint_group_1.strict_slashes
    assert blueprint_group_1.url_prefix == '/c'



# Generated at 2022-06-26 03:02:09.071585
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_2 = BlueprintGroup()
    blueprint_group_3 = BlueprintGroup()
    blueprint_group_4 = BlueprintGroup()
    blueprint_group_5 = BlueprintGroup()
    blueprint_group_6 = BlueprintGroup()
    blueprint_group_7 = BlueprintGroup()
    blueprint_group_8 = BlueprintGroup()
    blueprint_group_9 = BlueprintGroup()
    blueprint_group_10 = BlueprintGroup()
    blueprint_group_11 = BlueprintGroup()
    var_0 = blueprint_group_0.middleware()
    var_1 = blueprint_group_1.middleware()
    var_2 = blueprint_group_2.middleware()
    var_3 = blueprint_group_3.middleware()
    var_4 = blueprint_

# Generated at 2022-06-26 03:02:16.921699
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_2 = BlueprintGroup()

    blueprint_0 = Blueprint()
    blueprint_1 = Blueprint()
    blueprint_2 = Blueprint()

    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.append(blueprint_1)
    blueprint_group_0.append(blueprint_2)

    blueprint_group_1.append(blueprint_group_0)

    blueprint_group_2.append(blueprint_group_1)



# Generated at 2022-06-26 03:02:21.627785
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Initializing the class
    blueprint_group_0 = BlueprintGroup()
    # Calling the method
    var_0 = blueprint_group_0.middleware()
    # Assert the return type
    assert isinstance(var_0, partial)
    # Assert the return value
    assert var_0(globals()) is None


# Generated at 2022-06-26 03:02:26.986593
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    var_0 = blueprint_group_0.middleware()
    assert var_0 is not None
    assert callable(var_0)
    method0_var_0 = var_0(print)
    assert method0_var_0 is None

# Unit testing for class method group of class Blueprint

# Generated at 2022-06-26 03:02:34.701404
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_group_0 = BlueprintGroup()
    var_1 = blueprint_group_0[0]


# Generated at 2022-06-26 03:02:38.229249
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_0 = BlueprintGroup()
    expect_val_0 = 0
    actual_val_0 = blueprint_group_0.__len__()
    assert actual_val_0 == expect_val_0


# Generated at 2022-06-26 03:02:42.627213
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_group_0 = BlueprintGroup('', None, None)
    blueprint_group_0._blueprints.append(sanic.Blueprint('', '', None, None))
    var_0 = blueprint_group_0.__getitem__(0)
    assert type(var_0) is sanic.Blueprint


# Generated at 2022-06-26 03:02:47.330023
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_group_0 = BlueprintGroup(url_prefix="", version=None, strict_slashes=False)
    blueprint_0 = Blueprint()
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.__getitem__(0)



# Generated at 2022-06-26 03:02:55.100844
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # BlueprintGroup mocked object, with attributes values assigned
    blueprint_group_mocked_obj = Mock()

    # Declaring such attributes will take care of the side effect,
    # of not raising `AttributeError` while instantiating the mock object
    blueprint_group_mocked_obj.middleware = MagicMock(side_effect=[None, None])

    blueprint_group_mocked_obj.url_prefix = 'test_url_prefix'
    blueprint_group_mocked_obj.version = 'test_version'
    blueprint_group_mocked_obj.strict_slashes = False
    blueprint_group_mocked_obj._blueprints = [Mock(), Mock()]

    blueprint_group_mocked_obj.url_prefix = 'test_url_prefix'

# Generated at 2022-06-26 03:03:07.042075
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(sanic.Blueprint('name', 'url_prefix'))
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_0.append(blueprint_group_1)
    blueprint_group_1.append(sanic.Blueprint('name_0', 'url_prefix_0'))
    blueprint_group_1.append(sanic.Blueprint('name_1', 'url_prefix_1'))
    blueprint_group_0[0].name = 'name'
    blueprint_group_0[1].name = 'name_1'
    blueprint_group_0[1].url_prefix = 'url_prefix_1'
    blueprint_group_0[1].url_prefix = 'url_prefix_1'
    blueprint_group_0

# Generated at 2022-06-26 03:03:09.248355
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_group_0 = BlueprintGroup()
    var_0 = blueprint_group_0.__getitem__()


# Generated at 2022-06-26 03:03:10.888504
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0[0, int]


# Generated at 2022-06-26 03:03:17.571153
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint("blueprint_0", url_prefix="/blueprint_0")
    blueprint_group_0.append(blueprint_0)
    blueprint_1 = Blueprint("blueprint_1", url_prefix="/blueprint_1")
    blueprint_group_0.append(blueprint_1)
    blueprint_2 = Blueprint("blueprint_2", url_prefix="/blueprint_2")
    blueprint_group_0.append(blueprint_2)
    blueprint_3 = Blueprint("blueprint_3", url_prefix="/blueprint_3")
    blueprint_group_0.append(blueprint_3)
    blueprint_4 = Blueprint("blueprint_4", url_prefix="/blueprint_4")
    blueprint_group_0.append(blueprint_4)
    blueprint_

# Generated at 2022-06-26 03:03:29.166848
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0

# Generated at 2022-06-26 03:03:38.308785
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    params_0 = BlueprintGroup()
    params_0.__init__(url_prefix="/api", version="v1")
    params_0.__init__(url_prefix="/api/v1/", version="v1")
    assert params_0.__len__() == 0
    assert params_0.__len__() == 0


# Generated at 2022-06-26 03:03:40.161187
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.__delitem__(0)


# Generated at 2022-06-26 03:03:46.086256
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(Blueprint('bp1', url_prefix='/bp1'))
    blueprint_group_0.append(Blueprint('bp2', url_prefix='/bp2'))

    blueprint_0 = blueprint_group_0[0]


# Generated at 2022-06-26 03:03:48.331404
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.__delitem__(0)


# Generated at 2022-06-26 03:03:49.663077
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_group_0 = BlueprintGroup()
    # __getitem__ no exception raised
    blueprint_group_0.__getitem__(0)


# Generated at 2022-06-26 03:03:54.712397
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint('bp')
    blueprint_0.route('/')
    blueprint_group_0.append(blueprint_0)
    try:
        blueprint_group_0.append(blueprint_0)
    except AttributeError:
        return
    assert False, "Expected an AttributeError to be raised"


# Generated at 2022-06-26 03:04:00.559721
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(Blueprint('bp1', url_prefix='/bp1'))
    blueprint_group_0.append(Blueprint('bp2', url_prefix='/bp2'))
    blueprint_group_0.append(Blueprint('bp3', url_prefix='/bp3'))
    blueprint_group_0.append(Blueprint('bp4', url_prefix='/bp4'))
    blueprint_group_0.insert(0, Blueprint('bp5', url_prefix='/bp5'))
    blueprint_group_0.insert(1, Blueprint('bp6', url_prefix='/bp6'))
    blueprint_group_0.insert(2, Blueprint('bp7', url_prefix='/bp7'))

# Generated at 2022-06-26 03:04:04.246666
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    var_0 = BlueprintGroup("str_0", "str_1", "str_2")
    assert not hasattr(var_0, "__dict__")



# Generated at 2022-06-26 03:04:06.495698
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group = BlueprintGroup()

    assert isinstance(blueprint_group, BlueprintGroup)
    assert isinstance(blueprint_group, MutableSequence)
    assert callable(iter(blueprint_group))


# Generated at 2022-06-26 03:04:08.107209
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_0 = BlueprintGroup()

    blueprint_0 = Blueprint("<lambda>", "<lambda>")
    blueprint_group_0.append(blueprint_0)

    blueprint_1 = Blueprint("<lambda>", "<lambda>")
    blueprint_group_0[0] = blueprint_1


# Generated at 2022-06-26 03:04:24.959580
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint_group_1 = BlueprintGroup()
    assert blueprint_group_1.url_prefix is None
    assert blueprint_group_1.version is None
    assert blueprint_group_1.strict_slashes is None

    blueprint_group_2 = BlueprintGroup("/api/v1")
    assert blueprint_group_2.url_prefix == "/api/v1"
    assert blueprint_group_2.version is None
    assert blueprint_group_2.strict_slashes is None

    blueprint_group_3 = BlueprintGroup("/api/v1", "v1", "False")
    assert blueprint_group_3.url_prefix == "/api/v1"
    assert blueprint_group_3.version == "v1"
    assert blueprint_group_3.strict_slashes is False

# Generated at 2022-06-26 03:04:26.686641
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(None)


# Generated at 2022-06-26 03:04:29.498459
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint('bp3', url_prefix='/bp4')
    blueprint_group_0.__setitem__(0, blueprint_0)



# Generated at 2022-06-26 03:04:36.868356
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup()
    blueprint_0 = Blueprint('bp0', url_prefix='/bp0')
    blueprint_1 = Blueprint('bp1', url_prefix='/bp1')
    blueprint_group_1.append(blueprint_0)
    blueprint_group_1.append(blueprint_1)
    blueprint_group_1.append(blueprint_0)
    blueprint_group_0.append(blueprint_group_1)
    blueprint_group_1.append(blueprint_0)


# Generated at 2022-06-26 03:04:39.978739
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_2 = BlueprintGroup()
    blueprint_group_3 = BlueprintGroup(url_prefix='/', version='1.0.0', strict_slashes=False)


# Generated at 2022-06-26 03:04:47.001212
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup(url_prefix="/blueprint_group_0")
    blueprint_group_2 = BlueprintGroup(version=1)
    blueprint_group_3 = BlueprintGroup(strict_slashes=True)
    blueprint_group_4 = BlueprintGroup(
        url_prefix="/blueprint_group_0", version=1, strict_slashes=True
    )
    assert blueprint_group_0.url_prefix is None
    assert blueprint_group_0.version is None
    assert blueprint_group_0.strict_slashes is None
    assert blueprint_group_0.blueprints == []
    assert blueprint_group_1.url_prefix == "/blueprint_group_0"
    assert blueprint_group_1.version is None
    assert blueprint_group_1

# Generated at 2022-06-26 03:04:53.954727
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()

    # Var assignement test
    var_0 = blueprint_group_0.middleware()
    var_0 = blueprint_group_0.middleware(blueprint_0_0)
    var_0 = blueprint_group_0.middleware(blueprint_0_0, blueprint_0_1)
    var_0 = blueprint_group_0.middleware(blueprint_0_0, blueprint_0_1, blueprint_0_2)
    var_0 = blueprint_group_0.middleware(blueprint_0_0, blueprint_0_1, blueprint_0_2, blueprint_0_3)
    assert var_0 is None
    return



# Generated at 2022-06-26 03:04:56.070258
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(blueprint_1)
    blueprint_group_0.append(blueprint_2)
    blueprint_group_0.__delitem__(blueprint_1)
    assert blueprint_group_0.__len__() == 1


# Generated at 2022-06-26 03:05:01.190343
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(value=None)
    blueprint_group_0.insert(index=0, item=None)

    try:
        blueprint_group_0.__delitem__(index=0)
    except TypeError as e:
        pass
    try:
        blueprint_group_0.__delitem__(index=0)
    except IndexError as e:
        pass


# Generated at 2022-06-26 03:05:07.709647
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(sanic.Blueprint("test_bp", url_prefix="/0"))
    blueprint_group_0.append(sanic.Blueprint("test_bp", url_prefix="/1"))
    blueprint_group_0.append(sanic.Blueprint("test_bp", url_prefix="/2"))
    blueprint_group_0.append(sanic.Blueprint("test_bp", url_prefix="/3"))
    blueprint_group_0.append(sanic.Blueprint("test_bp", url_prefix="/4"))
    var_0 = blueprint_group_0.blueprints
    var_1 = blueprint_group_0.blueprints
    blueprint_group_0.__delitem__(0)
    blueprint_group_0.__delitem__(1)


# Generated at 2022-06-26 03:05:38.208131
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(Blueprint(url_prefix = "/prefix/version/v1"))
    blueprint_group_0.append(Blueprint(url_prefix = "/prefix/version/v2"))
    blueprint_group_0.append(Blueprint(url_prefix = "/prefix/version/v3"))
    blueprint_group_0.append(Blueprint(url_prefix = "/prefix/version/v4"))
    blueprint_group_0.append(Blueprint(url_prefix = "/prefix/version/v5"))
    blueprint_group_0.append(Blueprint(url_prefix = "/prefix/version/v6"))
    blueprint_group_0.append(Blueprint(url_prefix = "/prefix/version/v7"))

# Generated at 2022-06-26 03:05:43.065218
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    var_0 = blueprint_group_0.middleware()
    var_1 = blueprint_group_0.__iter__()
    assert isinstance(var_1, type(blueprint_group_0._blueprints.__iter__()))


# Generated at 2022-06-26 03:05:45.497933
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_0 = BlueprintGroup()
    result_0 = blueprint_group_0.__len__()
    assert result_0 == 0


# Generated at 2022-06-26 03:05:53.604919
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    app = sanic.Sanic()
    group = BlueprintGroup()
    bp1 = Blueprint('test_bp1', url_prefix="/api/v1")
    bp2 = Blueprint('test_bp2', url_prefix="/api/v2")
    group.append(bp1)
    group.append(bp2)
    bp3 = Blueprint('test_bp3', url_prefix="/api/v3")
    group.insert(0, bp3)
    assert group[1].name == "test_bp1"
    assert group[0].name == "test_bp3"

# Generated at 2022-06-26 03:05:58.120881
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint = Blueprint('bp1', url_prefix='/bp1')
    blueprint_group = BlueprintGroup()
    blueprint_group.append(blueprint)
    assert blueprint_group[0] == blueprint
    blueprint_group[0] = blueprint # __setitem__
    assert blueprint_group[0] == blueprint


# Generated at 2022-06-26 03:06:02.447366
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_0 = Blueprint('blueprint_0')
    blueprint_1 = Blueprint('blueprint_1')
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.insert(0, blueprint_0)
    blueprint_group_0.insert(1, blueprint_1)
    blueprint_group_0[0] is blueprint_0
    blueprint_group_0[1] is blueprint_1


# Generated at 2022-06-26 03:06:08.106745
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    # Declare local constants for test
    TEST_INDEX = 0
    TEST_UPDATE_INDEX = 1
    TEST_ITEM = Blueprint(name="test_bluprint", url_prefix="/test")
    TEST_UPDATE_ITEM = Blueprint(name="test_bluprint_2", url_prefix="/test/2")

    # Create Blueprint Group instance
    blueprint_group = BlueprintGroup()

    # Insert a new item into it
    blueprint_group.append(TEST_ITEM)
    blueprint_group.insert(TEST_UPDATE_INDEX, TEST_UPDATE_ITEM)

    # Retrieve the Blueprint
    blueprint = blueprint_group[TEST_INDEX]

    # Assert the instance equal
    assert TEST_ITEM == blueprint
    assert blueprint.url_prefix == TEST_UPDATE_ITEM.url_prefix




# Generated at 2022-06-26 03:06:10.841187
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_group_0 = BlueprintGroup()
    var_0 = blueprint_group_0[0:1]


# Generated at 2022-06-26 03:06:21.111692
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    var_0 = blueprint_group_0.middleware
    assert isinstance(var_0, Blueprint.middleware.__class__)

@pytest.mark.asyncio
async def test_case_1():
    blueprint_0 = Blueprint('bp1', url_prefix='/bp1')

    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(blueprint_0)

    @blueprint_group_0.middleware('request')
    async def blueprint_group_0_middleware_0(request):
        return sanic.response.text('Request')
    blueprint_group_0_middleware_0


# Generated at 2022-06-26 03:06:27.297360
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    test_BlueprintGroup___len__.stypy_localization = localization
    test_BlueprintGroup___len__.stypy_type_of_self = None
    test_BlueprintGroup___len__.stypy_type_store = module_type_store
    test_BlueprintGroup___len__.stypy_function_name = 'test_BlueprintGroup___len__'
    test_BlueprintGroup___len__.stypy_param_names_list = []
    test_BlueprintGroup___len__.stypy_varargs_param_name = None
    test_BlueprintGroup___len__.stypy_kwargs_param_name = None
    test_BlueprintGroup___len__.stypy_call_defaults = defaults
    test_BlueprintGroup___len__.stypy_call_

# Generated at 2022-06-26 03:07:13.501592
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    # Test for valid input
    blueprint_group_1 = BlueprintGroup()
    assert blueprint_group_1._url_prefix == None
    assert blueprint_group_1._strict_slashes == None
    assert blueprint_group_1._version == None

    # Test for valid input
    blueprint_group_2 = BlueprintGroup(url_prefix="/api",
                                       version=2,
                                       strict_slashes=True)
    assert blueprint_group_2._url_prefix == "/api"
    assert blueprint_group_2._strict_slashes == True
    assert blueprint_group_2._version == 2


# Generated at 2022-06-26 03:07:15.019335
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint_group_0 = BlueprintGroup()


# Generated at 2022-06-26 03:07:21.611822
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup(url_prefix='/sample_url_prefix')
    blueprint_group_2 = BlueprintGroup(url_prefix='/sample_url_prefix', version='sample_version')
    blueprint_group_3 = BlueprintGroup(url_prefix='/sample_url_prefix', version='sample_version', strict_slashes='sample_strict_slashes')
    assert hasattr(blueprint_group_0, 'url_prefix')
    assert hasattr(blueprint_group_1, 'version')
    assert hasattr(blueprint_group_2, 'blueprints')
    assert hasattr(blueprint_group_3, 'strict_slashes')


# Generated at 2022-06-26 03:07:22.990807
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.insert(0, blueprint_group_0)

# Generated at 2022-06-26 03:07:25.402685
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_0 = BlueprintGroup()
    assert blueprint_group_0.__len__() == 0


# Generated at 2022-06-26 03:07:28.524853
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.insert(0, sanic.Blueprint())


# Generated at 2022-06-26 03:07:33.153832
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group = BlueprintGroup(url_prefix='/api', version='v1')
    blueprint_group.append(sanic.Blueprint('bp1', url_prefix='/bp1'))
    blueprint_group.append(sanic.Blueprint('bp2', url_prefix='/bp2'))

    var_0 = blueprint_group.__delitem__(0)


# Generated at 2022-06-26 03:07:40.300856
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp0 = Blueprint("test_bp0", "/test_bp0")

    bp1 = Blueprint("test_bp1", "/test_bp1")

    bp2 = Blueprint("test_bp2", "/test_bp2")

    bp3 = Blueprint("test_bp3", "/test_bp3")

    blueprint_group_0 = BlueprintGroup("/test_bp_group")

    blueprint_group_0.append(bp0)
    blueprint_group_0.append(bp1)

    blueprint_group_0[1] = bp2
    blueprint_group_0.insert(0, bp3)

    assert blueprint_group_0[0] == bp3
    assert blueprint_group_0[1] == bp2
    assert blueprint_group_0.url_prefix == "/test_bp_group"

# Generated at 2022-06-26 03:07:46.454918
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(sanic.Blueprint(__name__))
    blueprint_group_0.append(sanic.Blueprint(__name__))
    blueprint_group_0.append(sanic.Blueprint(__name__))
    blueprint_group_0.__delitem__(1)


# Generated at 2022-06-26 03:07:50.681941
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    # Instance created through BlueprintGroup
    blueprint_group_0 = BlueprintGroup()
    # variable that keeps the return value of __iter__ method of BlueprintGroup
    var_0 = blueprint_group_0.__iter__()
    # verifying the variable value is MethodType object
    assert_equal(type(var_0), type(blueprint_group_0.__iter__))
