

# Generated at 2022-06-26 03:00:05.991797
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint('bp')
    blueprint_group_0.blueprints.append(blueprint_0)

    @blueprint_group_0.middleware('request')
    def middleware_handler_0(request): pass
    blueprint_0.middleware_stack

    blueprint_1 = Blueprint('bp_0')
    blueprint_group_0.blueprints.append(blueprint_1)
    blueprint_1.middleware_stack

    @blueprint_group_0.middleware('request')
    def middleware_handler_1(request): pass
    blueprint_0.middleware_stack
    blueprint_1.middleware_stack


# Generated at 2022-06-26 03:00:10.699536
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()

    # Testing for the case where
    # - args is defined and is callable
    def fn(request):
        return text('middleware')
    blueprint_group_0.middleware(fn)


# Generated at 2022-06-26 03:00:12.796504
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware()


# Generated at 2022-06-26 03:00:15.495080
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_1.middleware(sanic.response.file('/dev/null'))


# Generated at 2022-06-26 03:00:26.263372
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic('test_blueprint_group_middleware')
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-26 03:00:35.623507
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic(__name__)
    bp = Blueprint('blueprint', url_prefix='/bp')
    bp2 = Blueprint('blueprint2', url_prefix='/bp2')

    group = BlueprintGroup()

    group.append(bp)
    group.append(bp2)

    @group.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp.route('/<param>')
    async def bp2_route(request, param):
        return text(param)


# Generated at 2022-06-26 03:00:41.786514
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.url_prefix = "/api/v2"
    blueprint_group_0.strict_slashes = None
    blueprint_group_0.version = None

    def middleware_for_bp(request, a, b=None):
        return request

    blueprint_group_0.middleware(middleware_for_bp, 1, b=3)
    # TODO: Add More tests here



# Generated at 2022-06-26 03:00:51.355754
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Test middleware of class BlueprintGroup
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    group = Blueprint.group(bp1, bp2)

    # Unit test for method middleware of class BlueprintGroup
    @group.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')
    

# Generated at 2022-06-26 03:00:52.822913
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware()


# Generated at 2022-06-26 03:00:56.005426
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.blueprints.append(bp_0)
    blueprint_group_0.blueprints.append(bp_1)
    blueprint_group_0.blueprints.append(bp_2)
    blueprint_group_0.middleware(None)


# Generated at 2022-06-26 03:01:00.605360
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(blueprint_group_0.blueprints)


# Generated at 2022-06-26 03:01:02.066919
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_1.middleware(middleware=None)



# Generated at 2022-06-26 03:01:05.988251
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_1.middleware('request')
    blueprint_group_1.middleware('request', attach_to='response')
    blueprint_group_1.middleware('request', attach_to='response')
    blueprint_group_1.middleware(attach_to='response')


# Generated at 2022-06-26 03:01:12.426689
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    def register_middleware(fn):
        fn.middleware_name = 'Test'

    app = sanic.Sanic()
    blueprint = Blueprint('blueprint', url_prefix='/blueprint')
    blueprint_group = BlueprintGroup(url_prefix='/bp_group')
    blueprint_group.append(blueprint)

    blueprint_group.middleware(register_middleware)
    for blueprint in blueprint_group.blueprints:
        assert blueprint.middleware_name == 'Test'


# Generated at 2022-06-26 03:01:21.246574
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    fn = asyncio.coroutine(lambda: None)
    # __call__ with optional param args
    blueprint_group_0.middleware(fn, 1, 2, 3, 4)

    # __call__ with optional param kwargs
    blueprint_group_0.middleware(fn, a=1, b=2, c=3)

    # __call__ with all optional params
    blueprint_group_0.middleware(fn, 1, 2, 3, 4, a=1, b=2, c=3)


# Generated at 2022-06-26 03:01:24.160409
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(__name__ + '/test_BlueprintGroup_middleware')


# Generated at 2022-06-26 03:01:31.382436
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    @BlueprintGroup.middleware
    def fn_middleware_1(request):
        return request

    @BlueprintGroup.middleware()
    def fn_middleware_2(request):
        return request

    @BlueprintGroup.middleware('request')
    def fn_middleware_3(request):
        return request

    @BlueprintGroup.middleware('request', False)
    def fn_middleware_4(request):
        return request

    @BlueprintGroup.middleware('request', False)
    def fn_middleware_5(request):
        return request



# Generated at 2022-06-26 03:01:32.714557
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    assert type(blueprint_group_0.middleware) == types.MethodType



# Generated at 2022-06-26 03:01:42.767866
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    @bpg.middleware('request')
    async def middleware(request):
        print('middleware applied for both bp1 and bp2')

    app = sanic.Sanic('sanic-blueprint')
    app.blueprint(bpg)

# Generated at 2022-06-26 03:01:45.692213
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group = BlueprintGroup()

    @blueprint_group.middleware('request')
    def test_blueprint_group_middleware(request):
        pass


# Generated at 2022-06-26 03:01:51.609691
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.__delitem__(0)


# Generated at 2022-06-26 03:01:56.922419
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    blueprint_group_0 = BlueprintGroup()
    blueprint_1 = Blueprint('blueprint_1')
    blueprint_2 = Blueprint('blueprint_2')
    blueprint_3 = Blueprint('blueprint_3')

    blueprint_group_0.append(blueprint_1)
    blueprint_group_0.append(blueprint_2)
    blueprint_group_0.append(blueprint_3)
    assert len(blueprint_group_0) == 3



# Generated at 2022-06-26 03:01:59.645680
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix="/bp1")
    bp2 = Blueprint('bp2', url_prefix="/bp2")

    bpg = BlueprintGroup()
    bpg.append(bp1)
    assert len(bpg._blueprints) == 1
    bpg.append(bp2)
    assert len(bpg._blueprints) == 2


# Generated at 2022-06-26 03:02:10.214182
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group = BlueprintGroup()
    blueprint_group.append(Blueprint('blueprint_0', url_prefix='/blueprint_0'))
    bp1 = Blueprint('blueprint_1', url_prefix='/blueprint_1')
    blueprint_group.insert(0, bp1)
    bp2 = Blueprint('blueprint_2', url_prefix='/blueprint_2')
    blueprint_group.insert(1, bp2)
    blueprint_group[0] = blueprint_group[2]
    blueprint_group[1] = blueprint_group[0]
    blueprint_group.append(Blueprint('blueprint_3', url_prefix='/blueprint_3'))
    blueprint_group.append({})
    blueprint_group[1] = {'test': 'test'}

# Generated at 2022-06-26 03:02:18.698220
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Testing for Expecting TypeError
    # Parameter value not specified
    with pytest.raises(TypeError):
        BlueprintGroup.middleware()
    # Not callable parameter is passed
    with pytest.raises(TypeError):
        BlueprintGroup.middleware(12)
    # No args or kwargs is passed
    with pytest.raises(TypeError):
        BlueprintGroup.middleware(None)
    # Non callable Parameter is passed
    with pytest.raises(TypeError):
        BlueprintGroup.middleware(None, "12", foo=12)
    # Testing for Expecting ValueError
    # Valid callable Parameter is passed
    BlueprintGroup.middleware(lambda: None)
    # Valid callable Parameter is passed
    BlueprintGroup.middleware(lambda: None, "foo")
    # Valid

# Generated at 2022-06-26 03:02:19.903964
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(1, 2, 3, 4)


# Generated at 2022-06-26 03:02:24.870679
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint('blueprint_0', url_prefix='/blueprint_0', version=1.0, strict_slashes=False)

    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.__delitem__(0)

# Generated at 2022-06-26 03:02:34.658924
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Setup
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    blueprint_group = BlueprintGroup(bp1, bp2, url_prefix="/group")

    # Test: Middleware applied for the specified arguments on all the
    # Blueprints.
    @blueprint_group.middleware('request')
    async def group_middleware(request):
        # Test: Middleware gets registered under the required Blueprints
        assert not bp1.has_middleware('request')
        assert not bp2.has_middleware('request')
    # Test: Middleware applied for

# Generated at 2022-06-26 03:02:43.050590
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0[3:3] = [Blueprint(), Blueprint(), Blueprint()]
    assert blueprint_group_0[3] == blueprint_group_0[4]
    assert blueprint_group_0[1] == blueprint_group_0[2]
    assert blueprint_group_0[3] != blueprint_group_0[0]


# Generated at 2022-06-26 03:02:48.068634
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_1 = BlueprintGroup()
    blueprint_2 = Blueprint('blueprint_2', url_prefix='/blueprint_2')
    blueprint_group_1.append(blueprint_2)
    blueprint_group_1.__delitem__(0)
    assert not blueprint_group_1


# Generated at 2022-06-26 03:03:05.278574
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint_group_0 = Blueprint('bp0', url_prefix='/bp0')
    blueprint_group_1 = Blueprint('bp1', url_prefix='/bp1')
    blueprint_group_2 = Blueprint('bp2', url_prefix='/bp2')
    blueprint_group_3 = Blueprint('bp3', url_prefix='/bp3')

    blueprint_group_0 = BlueprintGroup(url_prefix='/bp0')
    blueprint_group_1 = BlueprintGroup(url_prefix='/bp1')
    blueprint_group_2 = BlueprintGroup(url_prefix='/bp2')
    blueprint_group_3 = BlueprintGroup(url_prefix='/bp3')

    blueprint_group_0 = BlueprintGroup(url_prefix='/bp0', version='v1')

# Generated at 2022-06-26 03:03:14.850568
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(Blueprint("bp_0", url_prefix="/v1"))
    blueprint_group_0.append(Blueprint("bp_1", url_prefix="/v2"))
    blueprint_group_0.append(Blueprint("bp_2", url_prefix="/v3"))
    blueprint_group_0.append(Blueprint("bp_3", url_prefix="/v4"))

    blueprint_0 = blueprint_group_0[2]
    url_prefix_0 = blueprint_0.url_prefix
    assert url_prefix_0 == "/v3"

    blueprint_group_1 = BlueprintGroup()
    blueprint_group_1.append(Blueprint("bp_0", url_prefix="/v1"))

# Generated at 2022-06-26 03:03:19.212168
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_1.append(blueprint_group_0)

# class BlueprintGroup

# Generated at 2022-06-26 03:03:21.721244
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(blueprint_group_0)



# Generated at 2022-06-26 03:03:24.173290
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()

    # BlueprintGroup.middleware
    blueprint_group_0.middleware(0)

# Generated at 2022-06-26 03:03:33.866463
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_0 = Blueprint(name='blueprint')
    blueprint_1 = Blueprint(name='blueprint_')
    blueprint_2 = Blueprint(name='blueprint__')
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.insert(index=0, item=blueprint_1)
    blueprint_group_0.insert(index=0, item=blueprint_0)
    blueprint_group_0.insert(index=2, item=blueprint_2)

    # Test with len of Blueprint Group
    assert len(blueprint_group_0) == 3
    # Test insertion at start with index 0
    assert blueprint_group_0[0].name == 'blueprint'
    # Test insertion at middle using index
    assert blueprint_group_0[1].name == 'blueprint_'
    # Test insertion at end with

# Generated at 2022-06-26 03:03:36.710179
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(sanic.Blueprint)
    blueprint_group_0.__delitem__(0)


# Generated at 2022-06-26 03:03:37.648812
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    assert(BlueprintGroup)


# Generated at 2022-06-26 03:03:45.348984
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    blueprint_group_1 = BlueprintGroup()
    blueprint_1 = Blueprint("bp1")
    blueprint_group_1.append(blueprint_1)
    blueprint_2 = Blueprint("bp2")
    blueprint_group_1.append(blueprint_2)
    blueprint_3 = Blueprint("bp3")
    blueprint_group_1.append(blueprint_3)
    blueprint_4 = Blueprint("bp4")
    blueprint_group_1.append(blueprint_4)


# Generated at 2022-06-26 03:03:47.541264
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint('bp1', url_prefix='/bp1')
    blueprint_group_0.append(blueprint_0)



# Generated at 2022-06-26 03:04:10.007367
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(sanic.blueprints.Blueprint('blueprint-1', 'url-prefix-1'))
    blueprint_group_0.append(sanic.blueprints.Blueprint('blueprint-2', 'url-prefix-2'))
    blueprint_group_0.append(sanic.blueprints.Blueprint('blueprint-3', 'url-prefix-3'))
    blueprint_group_0.append(sanic.blueprints.Blueprint('blueprint-4', 'url-prefix-4'))
    blueprint_group_0[0] = sanic.blueprints.Blueprint('blueprint-0', 'url-prefix-0')


# Generated at 2022-06-26 03:04:15.910353
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.append(blueprint_1)
    blueprint_group_0.append(blueprint_2)
    blueprint_group_0.append(blueprint_1)
    blueprint_group_0.append(blueprint_2)
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.append(blueprint_1)
    blueprint_group_0.append(blueprint_2)
    blueprint_group_0__len__0 = blueprint_group_0.__len__()
    # assert blueprint_group_0__len__0 == 8


# Generated at 2022-06-26 03:04:26.975140
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware("test_type_args", *("test_arg0",), **{})
    blueprint_group_1 = BlueprintGroup("test_url_prefix", "test_version")
    blueprint_group_1.middleware("test_type_args", *("test_arg0",), **{"test_keyword_arg": "test_value"})
    blueprint_group_2 = BlueprintGroup(url_prefix="test_url_prefix", version="test_version", strict_slashes="test_strict_slashes")
    blueprint_group_2.middleware("test_type_args", *("test_arg0",), **{"test_keyword_arg": "test_value"})

# Generated at 2022-06-26 03:04:36.908070
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    # Setup
    blueprint_group_01 = BlueprintGroup()
    blueprint_group_02 = BlueprintGroup()
    blueprint_group_03 = BlueprintGroup()
    blueprint_group_04 = BlueprintGroup()
    blueprint_group_05 = BlueprintGroup()
    blueprint_group_06 = BlueprintGroup()
    blueprint_group_07 = BlueprintGroup()
    blueprint_group_08 = BlueprintGroup()
    blueprint_group_09 = BlueprintGroup()
    blueprint_group_10 = BlueprintGroup()
    blueprint_group_11 = BlueprintGroup()
    blueprint_group_12 = BlueprintGroup()
    blueprint_group_13 = BlueprintGroup()
    blueprint_group_14 = BlueprintGroup()
    blueprint_group_15 = BlueprintGroup()
    blueprint_group_16 = BlueprintGroup()
    blueprint_group_17 = BlueprintGroup()
    blueprint_group_18 = Blueprint

# Generated at 2022-06-26 03:04:43.448983
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_url_prefix = blueprint_group_0.url_prefix
    blueprint_group_version = blueprint_group_0.version
    blueprint_group_strict_slashes = blueprint_group_0.strict_slashes

    blueprint_group_1 = BlueprintGroup(url_prefix="test_url")
    blueprint_group_1_url_prefix = blueprint_group_1.url_prefix

    blueprint_group_2 = BlueprintGroup(url_prefix="test_url", version="test_version")
    blueprint_group_2_url_prefix = blueprint_group_2.url_prefix
    blueprint_group_2_version = blueprint_group_2.version


# Generated at 2022-06-26 03:04:47.604826
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    instance = BlueprintGroup()
    instance.append(None)
    assert len(instance._blueprints) == 1
    item = sanic.Blueprint('test')

    instance[0] = item
    assert len(instance._blueprints) == 1
    assert instance._blueprints[0] == item



# Generated at 2022-06-26 03:04:55.521868
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(sanic.Blueprint('blueprint_group_0_0', url_prefix='/bgp0/bgp0'))
    blueprint_group_0.append(sanic.Blueprint('blueprint_group_0_1', url_prefix='/bgp0/bgp1'))
    blueprint_group_0.append(sanic.Blueprint('blueprint_group_0_2', url_prefix='/bgp0/bgp2'))
    blueprint_group_0.append(sanic.Blueprint('blueprint_group_0_3', url_prefix='/bgp0/bgp3'))

# Generated at 2022-06-26 03:04:59.361999
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(sanic.blueprints.Blueprint('test_blueprint_8', url_prefix='/testurl'))
    blueprint_group_0[0] = sanic.blueprints.Blueprint('test_blueprint_9', url_prefix='/testurl')


# Generated at 2022-06-26 03:05:00.542108
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    test_case_0()
    test_case_1()



# Generated at 2022-06-26 03:05:04.804985
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    blueprint_group = BlueprintGroup()
    blueprint_group.append(bp1)
    blueprint_group.append(bp2)

    assert blueprint_group.blueprints[0] == bp1
    assert blueprint_group.blueprints[1] == bp2
    assert len(blueprint_group.blueprints) == 2
