

# Generated at 2022-06-26 02:59:59.995344
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_insert_blueprint_0 = Blueprint('blueprint_group_insert_blueprint_0', url_prefix='/blueprint_group_insert_blueprint_0')
    blueprint_group_insert_0 = blueprint_group_0.insert(int_0=0, item=blueprint_group_insert_blueprint_0)
    blueprint_group_insert_blueprint_1 = Blueprint('blueprint_group_insert_blueprint_1', url_prefix='/blueprint_group_insert_blueprint_1')
    blueprint_group_insert_1 = blueprint_group_0.insert(int_0=0, item=blueprint_group_insert_blueprint_1)

# Generated at 2022-06-26 03:00:05.594432
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group = BlueprintGroup(url_prefix='/api', version='v1')
    blueprint = Blueprint('bp_1', url_prefix='/bp_1')
    blueprint_group.append(blueprint)
    blueprint = Blueprint('bp_2', url_prefix='/bp_2')
    blueprint_group.append(blueprint)
    blueprint = Blueprint('bp_3', url_prefix='/bp_3')
    blueprint_group.append(blueprint)
    for bp in blueprint_group:
        assert bp.url_prefix == '/api/bp_3'


# Generated at 2022-06-26 03:00:12.313391
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup(
        url_prefix="local_0", version="v0", strict_slashes=True
    )
    assert blueprint_group_1._url_prefix == "local_0"
    assert blueprint_group_1._version == "v0"
    assert blueprint_group_1._strict_slashes == True


# Generated at 2022-06-26 03:00:15.167771
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()

    blueprint_group_1 = BlueprintGroup()
    blueprint_group_1.middleware(blueprint_group_0)


# Generated at 2022-06-26 03:00:21.317857
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup(url_prefix='/accounts', strict_slashes=False)
    blueprint_group_2 = BlueprintGroup(url_prefix='/accounts', strict_slashes=False)
    blueprint_0 = Blueprint('accounts', url_prefix='/accounts', strict_slashes=False)
    blueprint_1 = Blueprint('accounts', url_prefix='/accounts', strict_slashes=False)
    blueprint_group_1.append(blueprint_0)
    blueprint_group_2.append(blueprint_1)
    blueprint_group_0.append(blueprint_group_1)
    blueprint_group_0.append(blueprint_group_2)
    int_0 = blueprint_group_0.__len__()
    int_1

# Generated at 2022-06-26 03:00:27.599708
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.append(blueprint_1)
    blueprint_group_0.append(blueprint_2)
    blueprint_group_0.append(blueprint_3)


# Generated at 2022-06-26 03:00:34.159005
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_group_0 = BlueprintGroup(str_0, bool_0)
    blueprint_0 = blueprint_group_0.__getitem__(float_0)
    blueprint_1 = blueprint_group_0.__getitem__(int_0)
    blueprint_2 = blueprint_group_0.__getitem__(int_0)
    blueprint_3 = blueprint_group_0.__getitem__(int_0)
    blueprint_4 = blueprint_group_0.__getitem__(int_0)


# Generated at 2022-06-26 03:00:40.700783
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint("blueprint")
    blueprint_1 = Blueprint("blueprint")
    blueprint_2 = Blueprint("blueprint")
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.append(blueprint_1)
    blueprint_group_0.append(blueprint_2)
    blueprint_group_0.__delitem__(1)
    int_0 = blueprint_group_0.__len__()


# Generated at 2022-06-26 03:00:50.297890
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_2 = BlueprintGroup(url_prefix="/test_BlueprintGroup")
    blueprint_group_3 = BlueprintGroup(url_prefix="/test_BlueprintGroup",
                                       version="v1")
    blueprint_group_4 = BlueprintGroup(url_prefix="/test_BlueprintGroup",
                                       version="v1", strict_slashes=False)
    assert isinstance(blueprint_group_1, BlueprintGroup)
    assert isinstance(blueprint_group_2, BlueprintGroup)
    assert isinstance(blueprint_group_3, BlueprintGroup)
    assert isinstance(blueprint_group_4, BlueprintGroup)


# Generated at 2022-06-26 03:00:53.199336
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_0 = BlueprintGroup()
    try:
        blueprint_group_0.__delitem__(0)
    except IndexError:
        pass
    except BaseException as e:
        raise e


# Generated at 2022-06-26 03:00:58.515893
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    blueprint_group = BlueprintGroup()
    blueprint_0 = Blueprint("blueprint_0", url_prefix="/blueprint_0")
    blueprint_group.append(blueprint_0)



# Generated at 2022-06-26 03:01:05.900177
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    global blueprint_group_0
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(Blueprint('bp0', url_prefix='/bp0'))
    blueprint_group_0.append(Blueprint('bp1', url_prefix='/bp1'))
    blueprint_group_0.append(Blueprint('bp2', url_prefix='/bp2'))
    blueprint_group_0.append(Blueprint('bp3', url_prefix='/bp3'))
    blueprint_group_0.append(Blueprint('bp4', url_prefix='/bp4'))
    blueprint_group_0.append(Blueprint('bp5', url_prefix='/bp5'))
    blueprint_group_0.append(Blueprint('bp6', url_prefix='/bp6'))
    blueprint_group_

# Generated at 2022-06-26 03:01:08.293451
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-26 03:01:19.030587
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0[:] = [bp1, bp2, bp3]

    blueprint_group_1 = BlueprintGroup()
    blueprint_group_1[:] = [bp3, bp4]

    blueprint_group_2 = BlueprintGroup()
    blueprint_group_2[:] = [bp3, blueprint_group_1, blueprint_group_0]


# Generated at 2022-06-26 03:01:20.491611
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_0 = BlueprintGroup()


# Generated at 2022-06-26 03:01:22.761534
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    test_case_0()

if __name__ == "__main__":
    test_BlueprintGroup()

# Generated at 2022-06-26 03:01:24.920331
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.insert(blueprint_group_0, blueprint_group_0)


# Generated at 2022-06-26 03:01:28.425741
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Initialize BlueprintGroup
    blueprint_group = BlueprintGroup()
    # Initialize test value for argument fn
    fn = None
    # Call BlueprintGroup method middleware
    blueprint_group.middleware(fn)


# Generated at 2022-06-26 03:01:35.297888
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_1.append(sanic.Blueprint())
    blueprint_group_1.append(sanic.Blueprint())
    blueprint_group_1.append(sanic.Blueprint())
    blueprint_group_1.append(sanic.Blueprint())
    blueprint_group_1.append(sanic.Blueprint())
    blueprint_group_1.append(sanic.Blueprint())
    blueprint_group_1.append(sanic.Blueprint())
    blueprint_group_1.append(sanic.Blueprint())
    blueprint_group_1.append(sanic.Blueprint())
    blueprint_group_1.append(sanic.Blueprint())
    blueprint_group_1[5]
    blueprint_group_1[5] = sanic.Blueprint()
   

# Generated at 2022-06-26 03:01:45.959994
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    # Test for valid input
    blueprint_group_0 = BlueprintGroup(url_prefix=None, version=None, strict_slashes=False)
    blueprint_group_0.append(Blueprint(name="blueprint_0", url_prefix="/blueprint-0", 
        host=None, version="v1", strict_slashes=False))
    blueprint_group_0.append(Blueprint(name="blueprint_1", url_prefix="/blueprint-1", 
        host=None, version="v1", strict_slashes=False))
    blueprint_group_0.append(Blueprint(name="blueprint_2", url_prefix="/blueprint-2", 
        host=None, version="v1", strict_slashes=False))
    assert type(blueprint_group_0[0]) == Blueprint

# Unit test

# Generated at 2022-06-26 03:01:55.550105
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())

    assert isinstance(iter(blueprint_group_0), Iterator)


# Generated at 2022-06-26 03:01:59.413799
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():

    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.insert(0, blueprint_group_0)


# Generated at 2022-06-26 03:02:05.304192
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.__setitem__(0, bp1)
    bpg.__setitem__(1, bp2)


# Generated at 2022-06-26 03:02:12.528595
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup(None)
    blueprint_group_2 = BlueprintGroup("")
    blueprint_group_3 = BlueprintGroup("/")
    blueprint_group_4 = BlueprintGroup("/api")
    blueprint_group_5 = BlueprintGroup("", None)
    blueprint_group_6 = BlueprintGroup("", "")
    blueprint_group_7 = BlueprintGroup("", "/")
    blueprint_group_8 = BlueprintGroup("", "/api")
    blueprint_group_9 = BlueprintGroup("/", None)
    blueprint_group_10 = BlueprintGroup("/", "")
    blueprint_group_11 = BlueprintGroup("/", "/")
    blueprint_group_12 = BlueprintGroup("/", "/api")
    blueprint_group_13 = BlueprintGroup("/api", None)
    blueprint

# Generated at 2022-06-26 03:02:13.933136
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    test_case_0()


# Generated at 2022-06-26 03:02:17.052923
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
        blueprint_group_1 = BlueprintGroup()
        blueprint_group_1.append("blueprint_1")


# Generated at 2022-06-26 03:02:21.032403
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(Blueprint(name="Blueprint_name_0"))
    itemUInt8_0 = blueprint_group_0[0]
    assert type(itemUInt8_0) == Blueprint


# Generated at 2022-06-26 03:02:22.685541
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware()


# Generated at 2022-06-26 03:02:25.651711
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.insert(0, blueprint_0)


# Generated at 2022-06-26 03:02:31.782901
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group_1 = BlueprintGroup()
    blueprint_1 = Blueprint("test")
    blueprint_group_1.insert(0, blueprint_1)
    blueprint_group_1.append('test')
    blueprint_group_1.insert(2, 'test')
    blueprint_group_1.insert(1, 'test')
    assert blueprint_group_1._blueprints == ["test", "test", "test"]


# Generated at 2022-06-26 03:02:43.447430
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    # Test case : 0 - Default
    blueprint_group_0 = BlueprintGroup()
    list_of_blueprint_0 = [blueprint_0, blueprint_1]
    blueprint_group_0.extend(list_of_blueprint_0)
    assert blueprint_group_0[0] == blueprint_0
    assert blueprint_group_0[1] == blueprint_1


# Generated at 2022-06-26 03:02:53.261442
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(Blueprint('blueprint_16'))
    blueprint_group_0.append(Blueprint('blueprint_0'))
    blueprint_group_0.append(Blueprint('blueprint_1'))
    blueprint_group_0.append(Blueprint('blueprint_31'))
    blueprint_group_0.append(Blueprint('blueprint_8'))
    blueprint_group_0.append(Blueprint('blueprint_2'))
    blueprint_group_0.append(Blueprint('blueprint_3'))
    blueprint_group_0.append(Blueprint('blueprint_4'))
    blueprint_group_0.append(Blueprint('blueprint_5'))

# Generated at 2022-06-26 03:03:00.948013
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group_1 = BlueprintGroup(None, None, None)
    blueprint_group_1.insert(0, Blueprint("test_id_1", "/test_path_2", []))
    assert blueprint_group_1[0].id == "test_id_1"
    assert blueprint_group_1._url_prefix is None
    assert blueprint_group_1._version is None
    assert blueprint_group_1._strict_slashes is None
    assert blueprint_group_1[0].url_prefix == "/test_path_2"



# Generated at 2022-06-26 03:03:12.132873
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    # Test case 1
    """
    Scenario:
        Create a new `BlueprintGroup` object and append 3 objects
        of type `Blueprint` to the BlueprintGroup
    """
    blueprint_group_1 = BlueprintGroup()
    blueprint_0 = Blueprint('bp0')
    blueprint_1 = Blueprint('bp1')
    blueprint_2 = Blueprint('bp2')
    blueprint_group_1.append(blueprint_0)
    blueprint_group_1.append(blueprint_1)
    blueprint_group_1.append(blueprint_2)

    # Test case 2
    """
    Scenario:
        Create a new `BlueprintGroup` object and append 3 objects
        of type `Blueprint` to the BlueprintGroup
    """
    blueprint_group_2 = BlueprintGroup()
    blueprint_0 = Blueprint('bp0')


# Generated at 2022-06-26 03:03:21.626384
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint("blueprint_0", url_prefix = "/blueprint0/")
    blueprint_1 = Blueprint("blueprint_1", url_prefix = "/blueprint1/")
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.append(blueprint_1)
    blueprint_group_0.append(blueprint_1)
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0 = blueprint_group_0.__iter__()



# Generated at 2022-06-26 03:03:25.529096
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_0 = BlueprintGroup()
    # Test for method __len__ of class BlueprintGroup.
    # Note: Test for method __len__ of class BlueprintGroup.
    assert blueprint_group_0.__len__() == 0
    blueprint_group_1 = BlueprintGroup()
    # Note: Test for method __len__ of class BlueprintGroup.
    assert blueprint_group_1.__len__() == 0
    blueprint_group_2 = BlueprintGroup()
    # Note: Test for method __len__ of class BlueprintGroup.
    assert blueprint_group_2.__len__() == 0


# Generated at 2022-06-26 03:03:27.377367
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware('request')



# Generated at 2022-06-26 03:03:29.248077
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_0 = BlueprintGroup()
    del blueprint_group_0[0]



# Generated at 2022-06-26 03:03:35.182370
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group = BlueprintGroup()
    blueprint_0 = Blueprint('bp3', url_prefix='/bp3')
    blueprint_1 = Blueprint('bp4', url_prefix='/bp4')
    blueprint_group.insert(index=0,item=blueprint_0)
    blueprint_group.insert(index=0,item=blueprint_1)
    assert blueprint_group[0] == blueprint_0
    assert blueprint_group[1] == blueprint_1
    assert len(blueprint_group) == 2


# Generated at 2022-06-26 03:03:41.853605
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint_group_0 = BlueprintGroup(
        url_prefix="/api", version="v1", strict_slashes=True
    )
    assert blueprint_group_0.url_prefix == "/api"
    assert blueprint_group_0.version == "v1"
    assert blueprint_group_0.strict_slashes == True
    assert blueprint_group_0.blueprints == []
