

# Generated at 2022-06-26 02:59:55.429856
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint("blueprint_0")
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.middleware(lambda request: None)


# Generated at 2022-06-26 02:59:57.597804
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_0.blueprints = blueprint_group_1
    blueprint_group_1.blueprints = [Blueprint()]
    blueprint_group_1.blueprints[0].middleware = Mock()


# Generated at 2022-06-26 03:00:00.341082
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_1 = BlueprintGroup()
    with pytest.raises(AttributeError) as excinfo:
        blueprint_group_1.middleware()
    assert "middleware method can only be used as a decorator" in str(excinfo.value)


# Generated at 2022-06-26 03:00:09.924342
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint = Blueprint("test_bp")

    @blueprint.middleware("request")
    def _request_middleware(request):
        return request

    @blueprint_group_0.middleware("request")
    def _request_middleware(request):
        return request

    assert blueprint.middlewares["request"][-1] == blueprint.middlewares["request"][-1]
    assert blueprint.middlewares["request"][0] != blueprint_group_0.middlewares["request"][0]
    assert isinstance(blueprint_group_0.middlewares["request"][0], partial)
    assert isinstance(blueprint.middlewares["request"][0], partial)


# Generated at 2022-06-26 03:00:14.974072
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_0.append(blueprint_group_1)
    blueprint_group_1.append(sanic.Blueprint("blueprint_0"))
    blueprint_group_1.middleware(sanic.request_middleware)


# Generated at 2022-06-26 03:00:17.197988
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    def test_fn(request):
        pass
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(test_fn)


# Generated at 2022-06-26 03:00:20.594584
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    BPGroup = BlueprintGroup()

    @BPGroup.middleware('request')
    async def bp1_middleware(request):
        print('bp1_middleware')



# Generated at 2022-06-26 03:00:26.415791
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group = BlueprintGroup()
    blueprint_group.middleware(lambda x: x)
    blueprint_group.middleware(lambda x: x, attach_to='response')


# Generated at 2022-06-26 03:00:30.799120
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware("fn", "name")



# Generated at 2022-06-26 03:00:32.362857
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(text)

# Generated at 2022-06-26 03:00:43.555808
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.blueprints = [Blueprint(name="blueprint_obj_0")]
    blueprint_group_0.blueprints[0].middleware_stack = []
    blueprint_group_0.middleware(sanic.request_middleware)
    blueprint_group_0.middleware(sanic.response_middleware)

# Generated at 2022-06-26 03:00:48.103259
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Case #1
    blueprint_group_1 = BlueprintGroup()
    @blueprint_group_1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')
    assert blueprint_group_1.blueprints == []


# Generated at 2022-06-26 03:00:54.958242
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group = BlueprintGroup(url_prefix='/bpg', version='v1', strict_slashes=True)
    blueprint = Blueprint('bp', url_prefix='/bp')
    blueprint_group.append(blueprint)
    blueprint_group.middleware('request')(lambda request: print('bp group middleware'))
    assert blueprint.middlewares['request'][0].args == ()
    assert blueprint.middlewares['request'][0].func == (lambda request: print('bp group middleware'))
    assert blueprint.middlewares['request'][0].kwargs == { }


# Generated at 2022-06-26 03:01:00.680655
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Test for method middleware of class BlueprintGroup
    """

    # Test Case 1
    blueprint_group = BlueprintGroup()
    @blueprint_group.middleware
    def middleware_fn1(request):
        return request

    @blueprint_group.middleware
    def middleware_fn2(request):
        return request

    assert len(blueprint_group.blueprints) == 0

# Generated at 2022-06-26 03:01:03.307552
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint('bp1', url_prefix='/bp1')
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.middleware(lambda x: None)

# Generated at 2022-06-26 03:01:08.961178
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_0.middleware(None,None,None)
    blueprint_group_0.middleware(blueprint_group_1.middleware,None,None)
    blueprint_group_0.middleware(blueprint_group_1.middleware,None,None,None)
    blueprint_group_0.middleware(blueprint_group_1.middleware,None,None,None,None)



# Generated at 2022-06-26 03:01:20.603514
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from asyncio import sleep

    app = sanic.Sanic("test_BlueprintGroup_middleware")

    @app.listener("before_server_start")
    def before_server_start(app, loop):
        bp = Blueprint("test_bp")
        bp_group = BlueprintGroup()
        bp_group.append(bp)

        @bp_group.middleware("request")
        async def request_middleware(request):
            print("Request Middleware")
            await sleep(1)

        @bp_group.middleware("response")
        async def response_middleware(request, response):
            print("Response Middleware")
            await sleep(1)

        @bp.route("/test")
        async def hello_world(request):
            return text("Hello World")


# Generated at 2022-06-26 03:01:25.547216
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    # Unit test for method middleware of class BlueprintGroup
    # Test Method middleware of BlueprintGroup Object with no arguments
    assert blueprint_group_0.middleware()

if __name__ == "__main__":
    test_case_0()
    test_BlueprintGroup_middleware()

# Generated at 2022-06-26 03:01:27.289766
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()


# Generated at 2022-06-26 03:01:34.637233
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_1 = BlueprintGroup()

    blueprint_group_1.middleware()
    blueprint_group_1.middleware('request')
    blueprint_group_1.middleware('request', 'response')

    # creating blueprint to be appended to blueprint group
    blueprint_1 = Blueprint.group(sanic.Blueprint("test_blueprint_1"))

    # appending blueprint to blueprint group
    blueprint_group_1.append(blueprint_1)

    # register middleware for the group
    @blueprint_group_1.middleware('request')
    async def test_middleware(request):
        print("Test Middleware")

    # verify that the middleware is registered for the blueprints
    # in the group
    assert len(blueprint_group_1.blueprints[0].handlers.get('request')) == 1

# Generated at 2022-06-26 03:01:41.182197
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_middleware = BlueprintGroup()
    blueprint_group_middleware.middleware(args, kwargs)



# Generated at 2022-06-26 03:01:47.605235
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()

    blueprint_0 = Blueprint('test_bp_0', url_prefix='/bp1')
    blueprint_group_0.append(blueprint_0)

    @blueprint_group_0.middleware('request')
    def bp_group_test_middleware(request):
        return

    assert (hasattr(blueprint_0, '_middlewares'))



# Generated at 2022-06-26 03:01:49.829001
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(request)


# Generated at 2022-06-26 03:01:58.297890
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    blueprint_group = Blueprint.group(bp1, bp2)
    blueprint_group.middleware(bp1_only_middleware)
    blueprint_group.middleware(group_middleware)
    blueprint_group.append(bpg)
    # Register Blueprint group under the app
    blueprint_group.middleware(app_common_middleware)


# Generated at 2022-06-26 03:02:00.798248
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    def fn(request):
        pass
    blueprint_group_0.middleware(fn)



# Generated at 2022-06-26 03:02:07.450850
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.middleware(bp1)
    bpg.middleware(sanic.request)
    bpg.middleware()

# Generated at 2022-06-26 03:02:22.767683
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from unittest.mock import MagicMock
    from unittest.mock import patch
    mock_fn = MagicMock()
    mock_request = MagicMock()
    # Call BlueprintGroup.middleware()
    with patch('sanic.blueprints.BlueprintGroup.middleware', wraps=blueprint_group_0.middleware) as mocked_middleware:
        # Call the mocked middleware method
        with patch('sanic.blueprints.Blueprint.middleware', wraps=blueprint_group_0.middleware) as mocked_middleware_inner:
            mock_middleware = mocked_middleware(mock_fn)
            mock_middleware(mock_request)
            # Asert that the BlueprintGroup.middleware has been called
            assert mocked_middleware.called
            # Assert that the Blueprint.middleware

# Generated at 2022-06-26 03:02:32.346056
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    _middleware_func = MagicMock()
    bp_group = BlueprintGroup()
    bp_group.append(sanic.Blueprint('test_bp'))
    bp_group.append(sanic.Blueprint('test_bp2'))
    bp_group.middleware(_middleware_func)
    for bp in bp_group.blueprints:
        assert callable(_middleware_func)
        assert _middleware_func.call_count == 2

# Generated at 2022-06-26 03:02:35.713930
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0_middleware_0 = blueprint_group_0.middleware

    args_0 = [
        None,
    ]

    result_0 = blueprint_group_0_middleware_0(*args_0)
    assert result_0 == blueprint_group_0_middleware_0


# Generated at 2022-06-26 03:02:37.436189
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()


# Generated at 2022-06-26 03:02:46.759422
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # TODO : Implement unit test for method middleware of class BlueprintGroup
    pass

# Generated at 2022-06-26 03:02:49.426985
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    async def function():
        return False
    # Test for middleware
    blueprint_group_0.middleware(function)


# Generated at 2022-06-26 03:02:54.325511
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_1.blueprints = [Blueprint(__name__, url_prefix="/"), Blueprint(__name__, url_prefix="/")]
    blueprint_group_1.middleware(
        lambda request: sanic.response.text("Hello"),
        'request',
    )
    for blueprint in blueprint_group_1.blueprints:
        for middleware in blueprint.middlewares:
            assert isinstance(middleware, BlueprintMiddleware)


# Generated at 2022-06-26 03:02:58.726650
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    @blueprint_group_0.middleware
    def response_1(request):
        return request.url
    @blueprint_group_0.middleware
    def response_2(request):
        return request.url


# Generated at 2022-06-26 03:03:02.866411
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.blueprints.append(Blueprint("bp1", url_prefix='/bp1'))
    blueprint_group_0.blueprints.append(Blueprint("bp2", url_prefix='/bp2'))



# Generated at 2022-06-26 03:03:10.472261
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint("blueprint_0", url_prefix="blueprint_0")
    blueprint_1 = Blueprint("blueprint_1", url_prefix="blueprint_1")
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.append(blueprint_1)

    @blueprint_group_0.middleware("request")
    async def middleware_0(request):
        pass



# Generated at 2022-06-26 03:03:12.046628
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware()


# Generated at 2022-06-26 03:03:24.588005
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group = BlueprintGroup()
    def fn():
        return "testBlueprintGroup"
    def fn2():
        return "testBlueprintGroup2"
    bp = Blueprint("test", url_prefix="/test")
    bp.middleware(fn, fn2)
    blueprint_group.append(bp)
    group_middleware = blueprint_group.middleware(fn, "test_1", test_2="test")
    assert fn in bp.request_middleware
    assert fn in bp.response_middleware
    assert fn2 in bp.request_middleware
    assert fn2 in bp.response_middleware
    assert "test_1" in bp.request_middleware[fn]
    assert "test_1" in bp.response_middleware[fn]
    assert "test" in b

# Generated at 2022-06-26 03:03:34.269104
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_2 = BlueprintGroup()
    blueprint_group_3 = BlueprintGroup()
    blueprint_group_3.append(blueprint_group_0)
    blueprint_group_3.append(blueprint_group_1)
    blueprint_group_3.append(blueprint_group_2)

    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(str)
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_1.middleware(str, 1)
    blueprint_group_2 = BlueprintGroup()
    blueprint_group_2.middleware(str, 1, 2)
    blueprint_group_3 = BlueprintGroup()

# Generated at 2022-06-26 03:03:37.648791
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    #define
    blueprint_group_0 = BlueprintGroup()
    @blueprint_group_0.middleware('request')
    async def middleware_0(request):
        pass



# Generated at 2022-06-26 03:03:54.139665
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    
    class T:
        
        def __init__(self):
            self.call_args = None
            
        # signature for Blueprint.middleware
        def mm(self, fn, *, attach_to=None, name=None):
            self.call_args = (fn, attach_to, name)

    t = T()
    b1 = Blueprint('b1')
    b2 = Blueprint('b2')
    b1.middleware = t.mm
    b2.middleware = t.mm
    bg = BlueprintGroup(b1, b2)

    @bg.middleware()
    def m():
        pass

    assert t.call_args == (m, None, None)
    assert t.call_args == b2.middleware.call_args



# Generated at 2022-06-26 03:03:57.071779
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_2 = BlueprintGroup()
    blueprint_group_3 = BlueprintGroup()
    # TODO: Add test code here.

# Generated at 2022-06-26 03:04:08.440770
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(sanic.Blueprint('sanic.Blueprint_1', url_prefix=''))
    blueprint_group_0.append(sanic.Blueprint('sanic.Blueprint_2', url_prefix=''))
    blueprint_group_0.append(sanic.Blueprint('sanic.Blueprint_3', url_prefix=''))

    @blueprint_group_0.middleware
    def middleware_0(request):
        pass

# Generated at 2022-06-26 03:04:15.592760
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1: Blueprint = Blueprint('bp1', url_prefix = '/bp1')
    bp2: Blueprint = Blueprint('bp2', url_prefix = '/bp2')

    bp3: Blueprint = Blueprint('bp3', url_prefix = '/bp4')
    bp4: Blueprint = Blueprint('bp4', url_prefix = '/bp4')

    bpg: BlueprintGroup = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-26 03:04:26.744097
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class MiddlewareTest(object):
        def __init__(self, app, handler):
            self.handler = handler
            self.app = app
        async def __call__(self, request):
            return await self.handler(request)
    class BlueprintTest(sanic.Blueprint):
        def __init__(self, name, url_prefix=None):
            super().__init__(name, url_prefix=url_prefix)
        async def handler(self, request):
            return text('handler')
        def route(self, uri, methods=frozenset({'GET'})):
            return super().route(uri, methods=methods, handler=self.handler)
    blueprint_test = BlueprintTest(__name__, url_prefix='/test')

# Generated at 2022-06-26 03:04:28.289578
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware()



# Generated at 2022-06-26 03:04:33.969736
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    def decorator_function_1(*args, **kwargs):
        pass

    def decorator_function_2(*args, **kwargs):
        pass

    def decorator_function_3(*args, **kwargs):
        pass

    BlueprintGroup.middleware(decorator_function_1)
    BlueprintGroup.middleware(decorator_function_2)
    BlueprintGroup.middleware(decorator_function_3)



# Generated at 2022-06-26 03:04:35.295044
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(lambda request=None : None)



# Generated at 2022-06-26 03:04:38.129254
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint(name='blueprint_0', url_prefix='/blueprint_0')
    blueprint_group_0.append(blueprint_0)
    middleware_fn_0 = lambda request: request
    blueprint_group_0.middleware(middleware_fn_0)


# Generated at 2022-06-26 03:04:40.277604
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    fn_0 = lambda request: None
    blueprint_group_0.middleware(fn_0)

# Generated at 2022-06-26 03:05:00.648725
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # BlueprintGroup
    blueprint_group_0 = BlueprintGroup()
    @blueprint_group_0.middleware
    def _middleware(request):
        return text('Hello World!')

    @blueprint_group_0.route('/')
    def _handler(request):
        return json({'test_endpoint': 'test_response'})

    app = sanic.Sanic()
    app.blueprint(blueprint_group_0)
    response = app.test_client.get('/')
    assert str(response.status) == '200 OK'
    assert response.text == 'Hello World!'


# Test Case to demonstrate Registering Blueprint Group with an API Version

# Generated at 2022-06-26 03:05:01.843944
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(request=request)



# Generated at 2022-06-26 03:05:02.358142
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    pass

# Generated at 2022-06-26 03:05:02.834935
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    pass

# Generated at 2022-06-26 03:05:12.858730
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp_group = BlueprintGroup()

    bp_group.append(bp1)
    bp_group.append(bp2)

    @bp_group.middleware('request')
    async def bp_group_only_middleware(request):
        print('applied on Blueprint Group')

    # Unit test for method middleware of class BlueprintGroup
    def test_BlueprintGroup_middleware():
        bp1 = Blueprint('bp1', url_prefix='/bp1')
        bp2 = Blueprint('bp2', url_prefix='/bp2')
        bp_group = BlueprintGroup()

        bp_group.append(bp1)
        bp_

# Generated at 2022-06-26 03:05:16.544638
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    def function_0():
        return
    value_0 = blueprint_group_0.middleware(function_0)
    # check if it calls the middleware() method of Blueprint
    # check if it appends the middleware function to the list of middlewares

# Generated at 2022-06-26 03:05:18.535698
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # TODO: Implement test for method middleware of class BlueprintGroup
    pass


# Generated at 2022-06-26 03:05:25.611982
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0['0'] = Blueprint('bp_0', url_prefix='/bp_0')
    blueprint_group_0.append(Blueprint('bp_1', url_prefix='/bp_1'))
    @blueprint_group_0.middleware
    def func_0(request):
        pass
    assert len(blueprint_group_0) == 2
    assert issubclass(type(blueprint_group_0[0]), Blueprint)
    assert issubclass(type(blueprint_group_0[1]), Blueprint)
    # assert blueprint_group_0[0].middlewares == [func_0]
    assert blueprint_group_0[1].middlewares == [func_0]
    assert blueprint_group_0.url_prefix is None

# Generated at 2022-06-26 03:05:30.298238
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint(name = 'blueprint_0_0')
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.middleware(sanic.request_middleware)(sanic.request_handler)


# Generated at 2022-06-26 03:05:41.472628
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    url_prefix = 'test url prefix'
    version = 'test version'
    strict_slashes = True
    blueprint_group_0 = BlueprintGroup(url_prefix=url_prefix, version=version, strict_slashes=strict_slashes)
    args_0 = []
    kwargs_0 = {}

    @blueprint_group_0.middleware(*args_0, **kwargs_0)
    def register_middleware_for_blueprints(fn):
        assert isinstance(fn, types.FunctionType)
        assert None is fn()
    assert isinstance(register_middleware_for_blueprints, types.FunctionType)
    assert None is register_middleware_for_blueprints()
    fn_0 = register_middleware_for_blueprints
    args_1 = [fn_0]
    k

# Generated at 2022-06-26 03:06:17.243904
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    # bp_0 = Blueprint('bp_0', url_prefix='/bp_0', version=1, strict_slashes=True)
    # bp_1 = Blueprint('bp_1', url_prefix='/bp_1', version=1, strict_slashes=True)
    # blueprint_group_0.append(bp_0)
    # blueprint_group_0.append(bp_1)
    slots = blueprint_group_0.__slots__

# Generated at 2022-06-26 03:06:20.093397
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup("/prefix", "v1")
    blueprint_group_2 = BlueprintGroup("/prefix", "v1", False)


# Generated at 2022-06-26 03:06:26.712103
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_0 = BlueprintGroup()
    assert len (blueprint_group_0) == 0
    blueprint_0 = Blueprint(None)
    blueprint_group_0.append (blueprint_0)
    assert len (blueprint_group_0) == 1
    blueprint_group_0.__delitem__ (0)
    assert len (blueprint_group_0) == 0
    blueprint_1 = Blueprint(None)
    blueprint_group_0.append (blueprint_1)
    blueprint_2 = Blueprint(None)
    blueprint_group_0.append (blueprint_2)
    blueprint_3 = Blueprint(None)
    blueprint_group_0.append (blueprint_3)
    blueprint_4 = Blueprint(None)
    blueprint_group_0.append (blueprint_4)

# Generated at 2022-06-26 03:06:33.775365
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(Blueprint('blueprint-1'))
    blueprint_group_0.append(Blueprint('blueprint-2'))
    blueprint_group_0.append(Blueprint('blueprint-3'))
    blueprint_group_0.__setitem__(1, Blueprint('blueprint-4'))
    blueprint_group_0.__setitem__(1, Blueprint('blueprint-5'))


# Generated at 2022-06-26 03:06:40.449197
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    from sanic.blueprints import Blueprint
    from sanic.response import text
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(bp1)
    blueprint_group_0.insert(0, bp2)
    assert blueprint_group_0 == [bp2, bp1]
    blueprint_group_0.insert(2, blueprint_group_0)


# Generated at 2022-06-26 03:06:47.191184
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint = Blueprint('bp3', url_prefix='/bp4', version=1, strict_slashes=False)
    blueprint_group = BlueprintGroup(blueprint, url_prefix="/api", version="v1")
    assert blueprint_group._blueprints[0].name == 'bp3'
    assert blueprint_group._blueprints[0].url_prefix == '/bp4'
    assert blueprint_group._blueprints[0].version == 1
    assert blueprint_group._blueprints[0].strict_slashes == False


# Generated at 2022-06-26 03:06:48.865233
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_0 = BlueprintGroup()
    assert blueprint_group_0.__len__() == 0



# Generated at 2022-06-26 03:06:57.140683
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup(url_prefix='/api', version='v1.1')
    blueprint_group_2 = BlueprintGroup(url_prefix='/api', version='v1.0', strict_slashes=False)
    blueprint_group_3 = BlueprintGroup(url_prefix='/api', version='v1.1', strict_slashes=True)
    blueprint_group_4 = BlueprintGroup(url_prefix='/api/')
    blueprint_group_5 = BlueprintGroup(url_prefix='/api/', version='v2.0', strict_slashes=False)
    blueprint_group_6 = BlueprintGroup(url_prefix='/api/', version='v1', strict_slashes=True)


# Generated at 2022-06-26 03:07:00.950102
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint('simple_blueprint', url_prefix='/prefix')
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.__delitem__(0)


# Generated at 2022-06-26 03:07:06.916736
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   
    blueprint_group_0 = BlueprintGroup('url_prefix')
    ll_0 = [(blueprint_group_0._blueprints[0],)]
    assert blueprint_group_0[0] == (blueprint_group_0._blueprints[0],)


# Generated at 2022-06-26 03:07:56.555350
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group = BlueprintGroup()
    blueprint = Blueprint("bp_0")
    blueprint_group.insert(0, blueprint)

    assert blueprint_group[0] == blueprint

# Generated at 2022-06-26 03:07:59.132215
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_0 = BlueprintGroup()
    assert len(blueprint_group_0) == 0


# Generated at 2022-06-26 03:08:06.493089
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    # setup
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup()
    blueprint_1 = Blueprint(name='blueprint_1')
    blueprint_group_1.append(blueprint_1)
    blueprint_group_0.append(blueprint_group_1)

    # test
    assert blueprint_group_0._blueprints[0] == blueprint_group_1


# Generated at 2022-06-26 03:08:15.447690
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint(name='name_0', url_prefix='url_prefix_0', version='version_0', strict_slashes='strict_slashes_0')
    blueprint_1 = Blueprint(name='name_1', url_prefix='url_prefix_1', version='version_1', strict_slashes='strict_slashes_1')
    blueprint_2 = Blueprint(name='name_2', url_prefix='url_prefix_2', version='version_2', strict_slashes='strict_slashes_2')
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.append(blueprint_1)
    blueprint_group_0.append(blueprint_2)
    # Testing for int index

# Generated at 2022-06-26 03:08:16.771433
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()

    blueprint_group_0.__iter__()


# Generated at 2022-06-26 03:08:25.851244
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    print("\n Testing <class BlueprintGroup>.insert method:")

    print("\n Testing <class BlueprintGroup>.insert method with normal cases:")
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup(url_prefix=None, version=None, strict_slashes=None)
    blueprint_group_2 = BlueprintGroup(url_prefix="api", version="v2", strict_slashes=False)
    blueprint_group_3 = BlueprintGroup(url_prefix="api", version="v3", strict_slashes=False)
    blueprint_group_4 = BlueprintGroup(url_prefix="api", version="v2", strict_slashes=None)
    blueprint_group_5 = BlueprintGroup(url_prefix="api", version="v2", strict_slashes=True)
    blueprint_group_6 = BlueprintGroup

# Generated at 2022-06-26 03:08:34.154875
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup()

    blueprint_group_2 = BlueprintGroup()
    blueprint_group_3 = BlueprintGroup()

    blueprint_group_1.append(bp1)
    blueprint_group_3.append(bp2)

    blueprint_group_0.append(bp1)
    blueprint_group_0.append(bp2)

    blueprint_group_2.append(bp1)
    blueprint_group_2.append(blueprint_group_3)


# Generated at 2022-06-26 03:08:42.069789
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint_group_0 = BlueprintGroup()
    assert blueprint_group_0.url_prefix is None
    assert blueprint_group_0.blueprints == []
    assert blueprint_group_0.version is None
    assert blueprint_group_0.strict_slashes is None

    blueprint_group_1 = BlueprintGroup('/api', 'v1', True)
    assert blueprint_group_1.url_prefix == '/api'
    assert blueprint_group_1.blueprints == []
    assert blueprint_group_1.version == 'v1'
    assert blueprint_group_1.strict_slashes == True

    blueprint_group_2 = BlueprintGroup('/api/v1', '1.0', True)
    assert blueprint_group_2.url_prefix == '/api/v1'
    assert blueprint_group_2.blueprints

# Generated at 2022-06-26 03:08:46.289259
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint("blueprint_0", url_prefix=None, version=None, strict_slashes=None)
    value_0 = blueprint_group_0.insert(index=0, item=blueprint_0)
    assert value_0 is None


# Generated at 2022-06-26 03:08:50.309787
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    # Test params
    fn_0 = "fn_0"
    args_0 = []
    kwargs_0 = {"a": "a"}
    # Test body
    blueprint_group_0.middleware(fn_0, *args_0, **kwargs_0)
