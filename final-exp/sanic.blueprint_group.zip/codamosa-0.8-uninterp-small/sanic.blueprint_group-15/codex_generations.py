

# Generated at 2022-06-26 03:00:00.159737
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")

    bpg = BlueprintGroup(bp1, bp2)

    @bpg.middleware("request")
    async def request_middleware(request):
        pass

    @bpg.middleware("response")
    async def response_middleware(request, response):
        pass

# Generated at 2022-06-26 03:00:03.225148
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_0 = Blueprint('test_blueprint_0')
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.middleware(lambda x: x)


# Generated at 2022-06-26 03:00:15.570782
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    tuple_0 = ()
    blueprint_group_0 = BlueprintGroup(tuple_0)
    # Test for middleware
    global_mw_spy = []
    bp1_mw_spy = []

    @blueprint_group_0.middleware('request')
    async def global_mw_0(request):
        """ The global middleware will be registered on all the Blueprints in
        group """
        global_mw_spy.append(request)

    bp1 = Blueprint('bp1', url_prefix='/bp1')

    @bp1.middleware('request')
    async def bp1_mw_0(request):
        """ The bp1 middleware is specific to bp1 """
        bp1_mw_spy.append(request)

    blueprint_group_0

# Generated at 2022-06-26 03:00:19.984744
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)

    @group.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    # Register Blueprint group under the app
    app.blueprint(group)


# Generated at 2022-06-26 03:00:33.902421
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    tuple_0 = ()
    blueprint_group_0 = BlueprintGroup(tuple_0)
    tuple_0 = ()
    tuple_1 = ('a',)
    str_0 = 'a'
    dict_0 = {
        str_0: 'a'
    }
    sanic_0 = sanic.Sanic()
    tuple_2 = (sanic_0, dict_0)
    tuple_3 = ()
    dict_1 = {}
    dict_2 = {
        str_0: 'a'
    }
    sanic_1 = sanic.Sanic()
    tuple_4 = (sanic_1, dict_2)

# Generated at 2022-06-26 03:00:44.746115
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic(__name__)
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2, url_prefix='/api', version='v1')

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)


# Generated at 2022-06-26 03:00:54.449468
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Unit test for method middleware of class BlueprintGroup
    """
    # Create a BlueprintGroup object
    blueprint_group_0 = BlueprintGroup()
    # Assign a Sanic Blueprint object to the BlueprintGroup
    blueprint_group_0.append(sanic.Blueprint())
    # Assign a Sanic Blueprint object to the BlueprintGroup
    blueprint_group_0.append(sanic.Blueprint())
    # Assign a Sanic Blueprint object to the BlueprintGroup
    blueprint_group_0.append(sanic.Blueprint())
    # Verify if the lenght of the BlueprintGroup is 0
    assert len(blueprint_group_0) == 0
    # Create a Sanic Blueprint object and assign it to a variable
    blueprint_0 = sanic.Blueprint()
    # Add the Sanic Blueprint to the BlueprintGroup
    blueprint_group

# Generated at 2022-06-26 03:01:04.042824
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()

    bp = Blueprint('bp0', url_prefix='/bp0')
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')
    bp7 = Blueprint('bp7', url_prefix='/bp7')
    bp8 = Blueprint('bp8', url_prefix='/bp8')
    bp9 = Blueprint('bp9', url_prefix='/bp9')


# Generated at 2022-06-26 03:01:08.295947
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class Blueprint_0(Blueprint):
        __slots__ = ()
        def name(self):
            return super().name()
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint_0()
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_1.append(blueprint_0)
    blueprint_group_0.append(blueprint_group_1)
    def func_0(blueprint_arg, request, response):
        return request, response
    blueprint_group_0.middleware(func_0)
    pass

# Generated at 2022-06-26 03:01:19.855485
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    tuple_0 = ()
    blueprint_group_0 = BlueprintGroup(tuple_0)
    bp1 = Blueprint('bp1', url_prefix='/bp1')    
    bp2 = Blueprint('bp2', url_prefix='/bp2')    

    bp3 = Blueprint('bp3', url_prefix='/bp4')    
    bp3 = Blueprint('bp3', url_prefix='/bp4')    

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')



# Generated at 2022-06-26 03:01:29.833211
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup(url_prefix=None, version=None, strict_slashes=None)

    @blueprint_group_0.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    assert blueprint_group_0.blueprints == [], "blueprint_group_0.blueprints: {} != [], where blueprint_group_0 is BlueprintGroup(url_prefix=None, version=None, strict_slashes=None)".format(blueprint_group_0.blueprints)


# Generated at 2022-06-26 03:01:38.843806
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_2 = BlueprintGroup()
    blueprint_group_3 = BlueprintGroup()

    @blueprint_group_1.middleware('request')
    def test_middleware(request):
        pass

    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')

    # Override the middleware
    @bp1.middleware('request')
    def middleware_override(request):
        pass

    @bp2.middleware('request')
    def middleware_override(request):
        pass


    blueprint_group_3.append(bp1)
    blueprint_group_3.append(bp2)

    blueprint_group_2.append(blueprint_group_3)

# Generated at 2022-06-26 03:01:41.328714
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware("async def f(): pass")



# Generated at 2022-06-26 03:01:46.280773
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup(None, None)
    blueprint_group_1 = BlueprintGroup('/blu-et/it..1', 'e')
    blueprint_group_2 = BlueprintGroup(None, '1.0.0')
    blueprint_group_3 = BlueprintGroup('/blu-et/it..2', 5)

# Generated at 2022-06-26 03:01:56.983432
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Tests for method middleware of class BlueprintGroup
    # should return a partial object with the same attributes
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)


# Generated at 2022-06-26 03:01:57.650977
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    pass


# Generated at 2022-06-26 03:02:00.697523
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    def fn():
        return fn
    assert blueprint_group_0.middleware(fn) == fn


# Generated at 2022-06-26 03:02:05.642520
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # def middleware(self, *args, **kwargs):

    blueprint_group_0 = BlueprintGroup()

    # Function to be called as middleware
    async def middleware_1(request):
        pass

    blueprint_group_0.middleware(middleware_1)

# Generated at 2022-06-26 03:02:11.313318
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    mock_args = ['middleware_func', 'request']
    mock_kwargs = {}
    blueprint = Blueprint('mock_blueprint')
    blueprint_group = BlueprintGroup()
    blueprint_group.append(blueprint)

    partial = blueprint_group.middleware(*mock_args, **mock_kwargs)
    partial(lambda request: 0)
    
    # Test if the Blueprint middleware method is called
    blueprint.middleware.assert_called_with(mock_args[0], *mock_args[1:], **mock_kwargs)

# Generated at 2022-06-26 03:02:14.048874
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(lambda request: None, 'request')


# Generated at 2022-06-26 03:02:21.935461
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_2 = BlueprintGroup()
    blueprint_group_3 = BlueprintGroup()
    blueprint_group_0.middleware()
    blueprint_group_1.middleware('')
    blueprint_group_2.middleware('', '')
    blueprint_group_3.middleware('', '', '')


# Generated at 2022-06-26 03:02:29.757290
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp = Blueprint('bp-test', url_prefix='/')
    blueprint_group = BlueprintGroup()
    blueprint_group.append(bp)

    @bp.middleware('request')
    async def bp_middleware(request):
        assert request == bp_middleware_request_parameter

    bp_middleware_request_parameter = 'test_BlueprintGroup_middleware'    
    blueprint_group.middleware(bp_middleware)(bp_middleware_request_parameter)

# Generated at 2022-06-26 03:02:36.896424
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group = BlueprintGroup(url_prefix='/url_prefix', version = "version", strict_slashes = "strict_slashes")
    blueprint_group.strict_slashes = "strict_slashes"
    blueprint_group.version = "version"
    blueprint_group.url_prefix = '/url_prefix'
    blueprint = Blueprint('blueprint', url_prefix='/url_prefix', strict_slashes=False)
    blueprint.strict_slashes = False
    blueprint.url_prefix = '/url_prefix'
    blueprint.version = 'version'
    blueprint.url_prefix = '/url_prefix'
    blueprint.version = 'version'
    blueprint.strict_slashes = False
    blueprint_group.append(blueprint)

# Generated at 2022-06-26 03:02:47.529543
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0: Blueprint = Blueprint()
    blueprint_1: Blueprint = Blueprint()
    blueprint_group_0._blueprints = [blueprint_0, blueprint_1]

    for blueprint in blueprint_group_0._blueprints:
        blueprint.middleware = MagicMock()

    blueprint_group_0.middleware(
        MagicMock()
        # *args=["arg_0"], **kwargs={"kwarg_0": "kwarg_0"}
    )
    blueprint_0.middleware.assert_called_once_with(
        MagicMock()
        # *args=["arg_0"], **kwargs={"kwarg_0": "kwarg_0"}
    )

# Generated at 2022-06-26 03:02:49.936150
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup(url_prefix=None, version=None, strict_slashes=None)
    blueprint_group_0.middleware(None)

# Generated at 2022-06-26 03:02:56.624426
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic.log import log
    from sanic.response import json
    from sanic.blueprints import Blueprint
    from sanic import Sanic

    blueprint_0 = Blueprint('bp0', url_prefix='/bp0')
    blueprint_1 = Blueprint('bp1', url_prefix='/bp1')

    blueprint_group_0 = BlueprintGroup(url_prefix='/api', version='1.0')
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.append(blueprint_1)

    @blueprint_0.route('/')
    async def handler_for_route_0(request):
        return json({})

    @blueprint_1.route('/')
    async def handler_for_route_1(request):
        return json({})


# Generated at 2022-06-26 03:03:04.916419
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0._sanitize_blueprint = lambda bp: bp

    @blueprint_group_0.middleware('request')
    async def test_case_1(request):
        return request

    # Unit test for method append of class BlueprintGroup
    def test_case_2():
        blueprint_group_0.append(1)

    # Unit test for method insert of class BlueprintGroup
    def test_case_3():
        blueprint_group_0.insert(1, 1)



# Generated at 2022-06-26 03:03:08.763498
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    @blueprint_group_0.middleware('request')
    def request_middleware_0(request):
        return 'Hello World'

# Generated at 2022-06-26 03:03:10.393471
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware()



# Generated at 2022-06-26 03:03:12.321797
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Test Case 0

    # TODO: Create a Mock instance of Blueprint.middleware
    # TODO: call BlueprintGroup.middleware
    pass

# Generated at 2022-06-26 03:03:18.364796
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware()
    blueprint_group_0.middleware(name)


# Generated at 2022-06-26 03:03:29.332188
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    _middleware = BlueprintGroup.middleware
    _instance = BlueprintGroup()
    dummy_callee = lambda x: x
    with patch('sanic.blueprints.BlueprintGroup.middleware.__wrapped__', new=dummy_callee) as mock_method:
        assert callable(_middleware(_instance)) == True
        assert callable(_middleware(_instance, 1)) == True
        assert callable(_middleware(_instance, 1, 2)) == True
        assert callable(_middleware(_instance, 1, 2, a=1)) == True
        assert callable(_middleware(_instance, 1, a=1)) == True
        assert callable(_middleware(_instance, a=1)) == True
        assert callable(_middleware(_instance, **{'a': 1})) == True

# Generated at 2022-06-26 03:03:32.042199
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware()
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_1.middleware()


# Generated at 2022-06-26 03:03:38.357803
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic('sanic')
    blueprint_group_0 = BlueprintGroup()

    blueprint_group_0.middleware(lambda req: None)
    blueprint_group_0.middleware(lambda req: None, 'request')
    blueprint_group_0.middleware(lambda req, res: None, 'response')
    blueprint_group_0.middleware(lambda req: None, 'request', attach_to='bp')
    blueprint_group_0.middleware(lambda req: None, 'websocket', attach_to='bp')
    blueprint_group_0.middleware(lambda req: None, attach_to='bp')
    blueprint_group_0.middleware(lambda req: None, attach_to='bp', attach_to_all=True)

# Generated at 2022-06-26 03:03:43.707994
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup("/prefix", 3.2)

    @blueprint_group_0.middleware
    def function():
        pass

    @blueprint_group_1.middleware
    def function():
        pass



# Generated at 2022-06-26 03:03:45.836535
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware()



# Generated at 2022-06-26 03:03:49.957300
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_1 = blueprint_group_0.middleware()
    blueprint_group_2 = blueprint_group_0.middleware(fn=None)

# Generated at 2022-06-26 03:03:55.148804
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_middleware_0 = blueprint_group_0.middleware()
    assert blueprint_group_middleware_0
    blueprint_group_middleware_1 = blueprint_group_0.middleware(None)
    assert blueprint_group_middleware_1
    blueprint_group_middleware_2 = blueprint_group_0.middleware(None, None)
    assert blueprint_group_middleware_2

# Generated at 2022-06-26 03:04:03.450847
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_1 = BlueprintGroup('/api/v1')
    blueprint_1 = Blueprint('bp1', url_prefix='/bp1')
    blueprint_group_1.append(blueprint=blueprint_1)

    @blueprint_group_1.middleware('response')
    async def group_middleware(request, response):
        response.headers['custom_header'] = 'blueprint group middleware'

    assert blueprint_group_1.blueprints[0].middlewares['response'][0] == group_middleware


# Generated at 2022-06-26 03:04:13.386343
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup()

    @blueprint_group_0.middleware('response')
    async def bp_middleware(request):
        print(request)

    template = blueprint_group_0.blueprints[0].middlewares['response'][0]
    blueprint_group_0.blueprints[1] = blueprint_group_1
    blueprint_group_1.blueprints.append(blueprint_group_0.blueprints[0])

    blueprint_group_0.blueprints[1].middlewares['response'][0](sanic.response.text)

    assert blueprint_group_0.blueprints[1].middlewares['response'][0] == blueprint_group_0.blueprints[0].middlewares['response'][0]

# Generated at 2022-06-26 03:04:26.379202
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    args = ["v1", "v2"]
    kwargs = {"middleware_name": "test_middleware"}

    def register_middleware_for_blueprints(fn):
        for blueprint in blueprint_group_0.blueprints:
            blueprint.middleware(fn, *args, **kwargs)

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    blueprint_group_0.append(bp1)
    blueprint_group_0.append(bp2)

    blueprint_group_0.middleware(["v1", "v2"], **{"middleware_name": "test_middleware"})

    assert bp1.version == "v1"
    assert bp2.version == "v1"

# Generated at 2022-06-26 03:04:36.346432
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    expected_method_called = False
    app = sanic.Sanic()
    blueprint_group = BlueprintGroup()
    
    @blueprint_group.middleware
    def middleware_instance(request):
        nonlocal expected_method_called
        expected_method_called = True
    
    # Start the actual test
    app.blueprint(blueprint_group)

    # Verify that the middleware is applied
    assert app.middlewares['request'][0] == middleware_instance
    
    # Verify that the blueprint will be added
    blueprint_group.append(Blueprint('bp1'))
    assert blueprint_group.blueprints[0].name == 'bp1'
    assert blueprint_group.blueprints[0].middlewares['request'][0] == middleware_instance

# Generated at 2022-06-26 03:04:43.100634
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup(url_prefix='url_prefix_0', version=0, strict_slashes=False)
    blueprint_0 = Blueprint('name_0', url_prefix='url_prefix_0')
    blueprint_1 = Blueprint('name_1', url_prefix='url_prefix_1')
    blueprint_2 = Blueprint('name_2', url_prefix='url_prefix_2')
    blueprint_3 = Blueprint('name_3', url_prefix='url_prefix_3')
    blueprint_group_0.append(blueprint_3)
    blueprint_group_0.insert(0, blueprint_2)
    blueprint_group_0.insert(0, blueprint_1)
    blueprint_group_0.insert(0, blueprint_0)

# Generated at 2022-06-26 03:04:44.974898
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    @blueprint_group_0.middleware('request')
    def test(request):
        pass



# Generated at 2022-06-26 03:04:46.268669
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware()


# Generated at 2022-06-26 03:04:53.955899
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_1 = sanic.Blueprint(name="bp1", url_prefix="/bp1")
    blueprint_group_2 = sanic.Blueprint(name="bp2", url_prefix="/bp2")
    blueprint_group_3 = sanic.Blueprint(name="bp3", url_prefix="/bp3")

    bp_group = BlueprintGroup()
    bp_group.append(blueprint_group_1)
    bp_group.append(blueprint_group_2)

    @bp_group.middleware('request')
    async def bp_middleware(request):
        print('bp_middleware')
        return

    @blueprint_group_3.middleware('request')
    async def bp_middleware_3(request):
        print('bp_middleware_3')
        return



# Generated at 2022-06-26 03:04:57.135056
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Test with parameters:  *args, **kwargs
    blueprint_group_0 = BlueprintGroup()

    # Test with parameters:  fn, *args, **kwargs
    # Here, fn = args[0]
    @blueprint_group_0.middleware()
    def middleware_test(request):
        return request.url

    # Test with parameters:  fn
    @blueprint_group_0.middleware
    def middleware_test(request):
        return request.url


# Generated at 2022-06-26 03:05:03.075165
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_0 = Blueprint('bp1', url_prefix='/bp1')
    blueprint_1 = Blueprint('bp2', url_prefix='/bp2')
    blueprint_group_0 = BlueprintGroup(blueprint_0, blueprint_1, url_prefix="/api", version="v1")

    def mw(request):
        pass
    blueprint_group_0.middleware(mw)

    assert (blueprint_group_0.middlewares[0] == mw)
    assert (blueprint_group_0.middlewares[1] == mw)

# Generated at 2022-06-26 03:05:06.934096
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    app = sanic.Sanic()

    # call method middleware of object blueprint_group_0
    # assert_raises(TypeError, blueprint_group_0.middleware, app)

    assert_raises(AssertionError, blueprint_group_0.middleware, None)



# Generated at 2022-06-26 03:05:08.729947
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware()

# Generated at 2022-06-26 03:05:12.544923
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    pass



# Generated at 2022-06-26 03:05:21.764398
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    def test_blueprint_group_middleware(request):
        return text("blueprint_group_middleware")

    blueprint_group = BlueprintGroup()
    blueprint_group.middleware(test_blueprint_group_middleware)
    blueprint_0 = Blueprint("blueprint_0")
    blueprint_1 = Blueprint("blueprint_1")
    blueprint_2 = Blueprint("blueprint_2", url_prefix="/test")
    blueprint_3 = Blueprint("blueprint_3", url_prefix="/test")
    blueprint_group.append(blueprint_0)
    blueprint_group.append(blueprint_1)
    blueprint_group.append(blueprint_2)
    blueprint_group.append(blueprint_3)

    app = Sanic("test_BlueprintGroup_middleware")
    app.blueprint(blueprint_group)

# Generated at 2022-06-26 03:05:32.411042
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Create a Blueprint and register a route using the Decorator
    bp_0 = Blueprint("bp_0", url_prefix="v0")
    @bp_0.route("/api/v0")
    async def test_bp_0(request: sanic.request.Request) -> sanic.response.HTTPResponse:
        return sanic.response.text("bp_0")

    # Create a Blueprint and register a route using the Decorator
    bp_1 = Blueprint("bp_1", url_prefix="v0")
    @bp_1.route("/api/v0")
    async def test_bp_1(request: sanic.request.Request) -> sanic.response.HTTPResponse:
        return sanic.response.text("bp_1")

    # Create a Blueprint and register a route

# Generated at 2022-06-26 03:05:43.477986
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    def mock_middleware(*args, **kwargs):
        pass

    mock_app_0 = Mock()
    mock_app_1 = Mock()
    mock_app_2 = Mock()

    for mock_app in [mock_app_0, mock_app_1, mock_app_2]:
        mock_blueprint_0 = Mock()
        mock_blueprint_1 = Mock()
        mock_blueprint_2 = Mock()

        mock_app.blueprints = [mock_blueprint_0, mock_blueprint_1, mock_blueprint_2]

        mock_blueprint_0.group = Mock()
        mock_blueprint_1.group = Mock()
        mock_blueprint_2.group = Mock()

        def mock_middleware_0(*args, **kwargs):
            pass


# Generated at 2022-06-26 03:05:47.975331
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(bp1)
    blueprint_group_0.append(bp2)



# Generated at 2022-06-26 03:05:50.151416
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()

    response = blueprint_group_0.middleware("request")()
    assert response


# Generated at 2022-06-26 03:05:57.607363
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware()
    blueprint_group_0.middleware(request=True)
    blueprint_group_0.middleware(response=True)
    blueprint_group_0.middleware(request_response=True)
    blueprint_group_0.middleware(
        name='test_string_0',
        request=True,
        response=True,
        request_response=True)


# Generated at 2022-06-26 03:06:04.506690
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    name = "bp2_name"
    url_prefix = "bp2_url_prefix"
    version = "bp2_version"
    strict_slashes = "bp2_strict_slashes"

    b2 = Blueprint("bp2", name, url_prefix, version, strict_slashes)

    @b2.middleware("request")
    def bp2_only_middleware(request):
        pass

    blueprint_group0 = BlueprintGroup()
    blueprint_group0.append(b2)
    blueprint_group0.middleware()
    blueprint_group0.middleware("request", bp2_only_middleware)
    


# Generated at 2022-06-26 03:06:16.413681
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-26 03:06:17.994119
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    test_case_0()

blueprint_group_object = BlueprintGroup()
test_BlueprintGroup_middleware()

# Generated at 2022-06-26 03:06:25.757219
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware()



# Generated at 2022-06-26 03:06:27.196893
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group = BlueprintGroup()
    blueprint_group.middleware('request')


# Generated at 2022-06-26 03:06:35.366223
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprints = [create_blueprint("blueprint_0")]
    blueprint_group = BlueprintGroup()

    for blueprint in blueprints:
        blueprint_group.append(blueprint)

    @blueprint_group.middleware('request')
    async def middleware(request):
        print('applied on BlueprintGroup')

    _blueprints = []
    blueprints = blueprint_group.blueprints

    for blueprint in blueprints:
        _blueprints.append(blueprint)

    assert type(blueprint_group) is BlueprintGroup
    assert "middleware" in dir(blueprint_group)
    assert type(blueprint_group.middleware) is MethodType

# Generated at 2022-06-26 03:06:43.205525
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.blueprints.append(Blueprint())
    blueprint_group_0.middleware(
        Blueprint.middleware,
        Blueprint.middleware,
        Blueprint.middleware
    )
    blueprint_group_0.blueprints.append(Blueprint())
    blueprint_group_0.blueprints.append(Blueprint())
    blueprint_group_0.middleware(
        Blueprint.middleware,
        Blueprint.middleware,
        Blueprint.middleware
    )
    blueprint_group_0.middleware(
        Blueprint.middleware,
        Blueprint.middleware,
        Blueprint.middleware
    )

# Generated at 2022-06-26 03:06:46.556258
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware('request')



# Generated at 2022-06-26 03:06:55.681839
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    @bpg.middleware('request')
    async def bp1_only_middleware(request):
        print('test_BlueprintGroup_middleware(): common middleware applied for both bp1 and bp2')

    app = Sanic("test_middleware")
    app.blueprint(bpg)

    @app.route("/bp1")
    async def handler1(request):
        return text("It works!")

    @app.route("/bp2")
    async def handler2(request):
        return text("It works!")

    _

# Generated at 2022-06-26 03:07:01.066618
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_1.append(1)
    blueprint_group_1.middleware(1, 2, a=3)
    blueprint_group_1.middleware('fn', 1, a=3)
    blueprint_group_1.middleware('fn', 1, 2, 3, a= 3)
    blueprint_group_1.middleware('fn', a=3)


# Generated at 2022-06-26 03:07:05.514233
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    def handler(request):
        pass
    blueprint_group_0.middleware(handler)
    with pytest.raises(TypeError):
        blueprint_group_0.middleware()

# Generated at 2022-06-26 03:07:15.235812
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()  # Constructor call
    blueprint_group_0.blueprints = ['blueprints_0']
    blueprint_group_0.version = 'version_0'
    blueprint_group_0.url_prefix = 'url_prefix_0'
    blueprint_group_0.strict_slashes = 'strict_slashes_0'
    blueprint_group_0.middleware()
    blueprint_group_0.middleware('middleware_0', 'middleware_1')
    blueprint_group_0.middleware('middleware_0', middleware_1='middleware_1')

# Generated at 2022-06-26 03:07:22.310514
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_1 = BlueprintGroup()

    @blueprint_group_1.middleware('request')
    async def blueprint_group_1_middleware(request):
        print('applied on Blueprint : blueprint_group_1 Only')

    blueprint_group_2 = BlueprintGroup()

    @blueprint_group_2.middleware('request')
    async def blueprint_group_2_middleware(request):
        print('applied on Blueprint : blueprint_group_2 Only')

    blueprint_group_3 = BlueprintGroup()

    @blueprint_group_3.middleware('request')
    async def blueprint_group_3_middleware(request):
        print('applied on Blueprint : blueprint_group_3 Only')

    blueprint_group_0 = BlueprintGroup()


# Generated at 2022-06-26 03:07:47.333849
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_2 = BlueprintGroup()
    blueprint_group_3 = BlueprintGroup()
    blueprint_group_4 = BlueprintGroup()

    blueprint_group_0.middleware(['middleware_request_1', 'middleware_response_1'], strict_slashes=False)
    blueprint_group_1.middleware(['middleware_request_1', 'middleware_response_1'], strict_slashes=True)
    blueprint_group_2.middleware(['middleware_request_1', 'middleware_response_1'], strict_slashes=True, host='mock_host')

# Generated at 2022-06-26 03:07:49.706013
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint = Blueprint("test_middleware")
    blueprint_group = BlueprintGroup()
    blueprint_group.append(blueprint)
    middle = blueprint_group.middleware(None)
    assert middle is not None


# Generated at 2022-06-26 03:07:58.667903
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint(None)
    blueprint_1 = Blueprint(None)
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.append(blueprint_1)
    assert blueprint_0.middleware_functions == {sanic.request: [], sanic.response: [], None: []}
    assert blueprint_1.middleware_functions == {sanic.request: [], sanic.response: [], None: []}
    blueprint_group_0.middleware(sanic.request)
    assert blueprint_0.middleware_functions == {sanic.request: [sanic.request], sanic.response: [], None: []}

# Generated at 2022-06-26 03:08:04.556237
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup(
        "/fgys/q9qe", version="v1", strict_slashes=None
    )
    blueprint_group_0.middleware()
    blueprint_group_0.middleware(lambda request, response: None)  # type: ignore

# Generated at 2022-06-26 03:08:13.589209
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    # Provided a method as part of the middleware
    def bp1_middleware_fn():
        pass
    blueprint_group_0.middleware(bp1_middleware_fn)

    # Perform the direct method call to the middleware
    # method, to apply the middleware to all the blueprints
    # inside this group
    def bp2_middleware_fn():
        pass
    bp1_middleware_fn = blueprint_group_0.middleware
    bp1_middleware_fn(bp2_middleware_fn)

    blueprint_0 = Blueprint('x', url_prefix='/x')
    blueprint_1 = Blueprint('y', url_prefix='/y')
    blueprint_group_0 = BlueprintGroup()

# Generated at 2022-06-26 03:08:16.063797
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic.blueprints import Blueprint

    blueprint_group_0 = BlueprintGroup()

    @blueprint_group_0.middleware('request')
    def middleware_0():
        pass


# Generated at 2022-06-26 03:08:21.071483
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    
    app = sanic.Sanic("test_BlueprintGroup_middleware")
    app.config.from_pyfile("./tests/unit_tests/configs/test_sanic_blueprints.py")

    blueprint_group_0 = BlueprintGroup()

    @blueprint_group_0.middleware('request')
    async def middleware(request):
        pass

    assert blueprint_group_0.middleware is not None


# Generated at 2022-06-26 03:08:23.904315
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    def test(self, *args, **kwargs):
        self.app.request
    blueprint_group = BlueprintGroup()
    blueprint_group.middleware(test)

# Generated at 2022-06-26 03:08:30.252944
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_2 = BlueprintGroup()
    blueprint_3 = Blueprint('bp3', url_prefix='/bp3')
    blueprint_4 = Blueprint('bp4', url_prefix='/bp4')
    blueprint_group_2.append(blueprint_3)
    blueprint_group_2.append(blueprint_4)
    blueprint_group_1.append(blueprint_group_2)
    blueprint_group_1.middleware(a)


# Generated at 2022-06-26 03:08:33.861817
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_instance_1 = BlueprintGroup(url_prefix = '/api', version = 'v1.0', strict_slashes = True)
    app = sanic.Sanic('sanic')
    @blueprint_group_instance_1.middleware('request')
    def test_middleware_fn():
        return True


# Generated at 2022-06-26 03:09:04.731714
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Create BlueprintGroup instance for testing
    blueprint_group_0 = BlueprintGroup()

    # Local variables using se

# Generated at 2022-06-26 03:09:06.512990
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_1 = BlueprintGroup("", "", True)
    blueprint_group_1.middleware()



# Generated at 2022-06-26 03:09:08.483423
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    assert BlueprintGroup().middleware() == BlueprintGroup.middleware(BlueprintGroup())


# Generated at 2022-06-26 03:09:12.185957
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0._blueprints = []
    blueprint_group_0._url_prefix = None
    blueprint_group_0._version = None
    blueprint_group_0._strict_slashes = None
    def f(x):
        """Function f"""
        return x
    blueprint_group_0.middleware(f)


# Generated at 2022-06-26 03:09:13.209060
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()



# Generated at 2022-06-26 03:09:24.385719
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    group = Blueprint.group(bp1, bp2)


# Generated at 2022-06-26 03:09:32.626893
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(Blueprint(name='bp_0'))
    blueprint_group_0.append(Blueprint(name='bp_1'))
    blueprint_group_0.middleware(lambda r: r)
    blueprint_group_0.middleware(lambda r: r, attach_to='')
    blueprint_group_0.middleware(attach_to='', fn=lambda r: r)
    blueprint_group_0.middleware('', lambda r: r)
    blueprint_group_0.middleware('', fn=lambda r: r)
    blueprint_group_0.middleware(attach_to='', fn=lambda r: r)
    blueprint_group_0.middleware(fn=lambda r: r, attach_to='')


test_Blue

# Generated at 2022-06-26 03:09:35.413893
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    middleware_0 = [
        lambda a, b, request: None,
        lambda request: None,
    ]
    blueprint_group_0.middleware(*middleware_0)

# Generated at 2022-06-26 03:09:41.889448
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic.blueprints import Blueprint
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint("blueprint_0", url_prefix="url_prefix_0")
    blueprint_group_0.append(blueprint_0)
    blueprint_1 = Blueprint("blueprint_1", url_prefix="url_prefix_1")
    blueprint_group_0.append(blueprint_1)
    blueprint_group_0.middleware("request", attach_to="response")("fn")
    assert blueprint_0.middlewares["request"][0].fn == "fn"
    assert blueprint_1.middlewares["request"][0].fn == "fn"

# Generated at 2022-06-26 03:09:45.917774
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(None)
    assert blueprint_group_0.middleware(None) == None
    assert blueprint_group_0.middleware(None) == None
    assert blueprint_group_0.middleware(None) == None
    assert blueprint_group_0.middleware(None) == None
    assert blueprint_group_0.middleware(None) == None
