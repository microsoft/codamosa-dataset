

# Generated at 2022-06-26 03:00:05.678806
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # arrange
    bp01 = Blueprint("bp01", url_prefix="bp01")
    bp02 = Blueprint("bp02", url_prefix="bp02")
    bpg01 = BlueprintGroup("bpg01", url_prefix="bpg01")
    bpg01.append(bp01)
    bpg01.append(bp02)
    args = ["request"]
    kwargs = {}

    # act
    @bpg01.middleware(*args, **kwargs)
    def middleware_fuc(*args):
        pass

    # assert
    assert bp01.middlewares["request"] == [middleware_fuc]
    assert bp02.middlewares["request"] == [middleware_fuc]


# Generated at 2022-06-26 03:00:13.347408
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.blueprints = Blueprint.__new__(Blueprint)
    blueprint_group_0.blueprints.middleware = MagicMock(name="blueprint_group_0.blueprints.middleware")
    blueprint_group_0.blueprints.middleware.return_value = None
    blueprint_group_0.middleware(MagicMock(name="magic_mock_0"))



# Generated at 2022-06-26 03:00:15.292052
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware()


# Generated at 2022-06-26 03:00:26.234459
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Arrange
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_2 = BlueprintGroup()
    app_1 = sanic.Sanic()
    app_2 = sanic.Sanic()
    app_3 = sanic.Sanic()
    app_4 = sanic.Sanic()
    app_5 = sanic.Sanic()
    app_6 = sanic.Sanic()
    app_7 = sanic.Sanic()
    app_8 = sanic.Sanic()
    bp_1 = Blueprint('bp_1')
    bp_2 = Blueprint('bp_2')
    bp_3 = Blueprint('bp_3')
    bp_4 = Blueprint('bp_4')
    bp_5 = Blueprint('bp_5')

# Generated at 2022-06-26 03:00:30.800956
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(None)

# Generated at 2022-06-26 03:00:35.889751
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    def assert_equal(actual, expected):
        assert actual == expected, "%s != %s" % (actual, expected)
    @blueprint_group_0.middleware('request')
    def assert_equal_0(request):
        assert_equal(request, None)
    blueprint_group_0.blueprints[:] = [123]


# Generated at 2022-06-26 03:00:39.202448
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    @blueprint_group_0.middleware("request")
    async def test_middleware(request):
        pass

    assert len(blueprint_group_0.blueprints) == 0


# Generated at 2022-06-26 03:00:41.913047
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Test cases
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(sanic.response.html('html_0'))



# Generated at 2022-06-26 03:00:44.888757
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup("/api", "v1", False)
    blueprint_group_0.middleware("request")


# Generated at 2022-06-26 03:00:54.594716
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    def testBlueprint():
        bp = Blueprint("test_blueprint_group_middleware", url_prefix="/test")

        @bp.route("/", methods=["GET"])
        async def bp_fn(request):
            return text("ok")

        @bp.middleware("request")
        async def bp_middleware(request):
            assert True

        return bp

    bp_group = BlueprintGroup()
    bp_group.append(testBlueprint())

    @bp_group.middleware("request")
    async def bp_group_middleware(request):
        assert request
        return response.text("test")

    app = sanic.Sanic()
    app.blueprint(bp_group)
    request, response = app.test_client.get("/test/")


# Generated at 2022-06-26 03:01:00.442747
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # TODO: Remove the following line and set the appropriate object
    blueprint_group_0 = BlueprintGroup()

    # TODO: Remove the following line and set the appropriate object
    blueprint_group_0.middleware()



# Generated at 2022-06-26 03:01:01.329360
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
	
	pass


# Generated at 2022-06-26 03:01:04.585316
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()
    blueprint_group_0 = BlueprintGroup()

    @blueprint_group_0.middleware('request')
    async def zzz(request):
        return request

    # Add BlueprintGroup to App
    app.blueprint(blueprint_group_0)


# Generated at 2022-06-26 03:01:15.399341
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class ArgMock:
        pass

    # Test mocking
    blueprint_group = BlueprintGroup()
    blueprint_group.append = MagicMock()

    # Test for success
    # Arrange
    fn = MagicMock()
    args = ArgMock()
    args.__class__ = Iterable
    args.__iter__ = MagicMock()
    args.__iter__.return_value = []

    # Act
    blueprint_group.middleware(fn)

    # Assert
    blueprint_group.blueprints[0].middleware.assert_called_once_with(
        fn, *args.__iter__.return_value
    )

    # Test for failure
    # Arrange
    blueprint_group = BlueprintGroup()
    blueprint_group.blueprints = []

    # Act

# Generated at 2022-06-26 03:01:26.380643
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    server = sanic.Sanic("test_app")
    bp_group_0 = BlueprintGroup()
    # Middleware that will be applied to all Blueprint Group Blueprints
    @bp_group_0.middleware("request")
    async def bp_middleware(request):
        pass
    # Dropping a blueprint inside the group
    bp_0 = Blueprint("test_bp_0")
    bp_group_0.append(bp_0)
    # Dropping another blueprint inside the group
    bp_1 = Blueprint("test_bp_1")
    bp_group_0.append(bp_1)
    # Test of the existence of a common Middleware across all Blueprint
    # Blueprints
    assert len(bp_0.middleware_stack["request"]) == 1, "Common Middleware not applied"

# Generated at 2022-06-26 03:01:29.597877
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint()
    blueprint_group_0.append(blueprint_0=blueprint_0)
    blueprint_group_0.middleware(middleware=lambda request: None)


# Generated at 2022-06-26 03:01:34.453865
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    Blueprint.routes = {}
    Blueprint.middlewares = {}
    Blueprint.middleware_stack = {}
    Blueprint.error_handler = {}
    @blueprint_group_0.middleware('middlewares')
    def middleware(request, response):
        pass
    assert len(blueprint_group_0.middlewares['middlewares']) == 1



# Generated at 2022-06-26 03:01:44.846625
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup(version=False, strict_slashes=None)
    blueprint_group_1 = BlueprintGroup(version=None, strict_slashes=False)
    blueprint_group_2 = BlueprintGroup(version=True, strict_slashes=False)
    blueprint_group_3 = BlueprintGroup(version=False, strict_slashes=True)
    blueprint_group_4 = BlueprintGroup(version=True, strict_slashes=True)
    blueprint_group_5 = BlueprintGroup(version=False, strict_slashes=True)
    blueprint_group_6 = BlueprintGroup(version=False, strict_slashes=True)
    blueprint_group_7 = BlueprintGroup(version=None, strict_slashes=None)
    blueprint_group_8 = BlueprintGroup(version=False, strict_slashes=None)
   

# Generated at 2022-06-26 03:01:53.261075
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp2, url_prefix="/api", version="v1")
    bpg1 = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    bp1.middleware('request')(lambda x: 'test-middleware')
    bp2.middleware('request')(lambda x: 'test-middleware')
    bp3.middleware('request')(lambda x: 'test-middleware')

# Generated at 2022-06-26 03:01:58.325547
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_1 = BlueprintGroup("prefix", "1", True)
    blueprint_group_1.append(Blueprint("prefix_0", "prefix/0", "1", False))
    blueprint_group_1.append(Blueprint("prefix_1", "prefix/1", "1", True))

    blueprint_group_1.middleware("middleware")
    blueprint_group_1.blueprints[0].middleware("middleware_0")
    blueprint_group_1.blueprints[0].blueprints[0].middleware("middleware_00")

# Generated at 2022-06-26 03:02:10.803341
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_0.blueprints.append(blueprint_group_1)
    blueprint_group_1.blueprints.append(sanic.Blueprint("test_bp_0", None, None))
    result = blueprint_group_0.middleware(0)
    assert callable(result), "Error: method middleware of class BlueprintGroup should return a function."
    result = blueprint_group_0.middleware(0, 0)
    assert callable(result), "Error: method middleware of class BlueprintGroup should return a function."
    result = blueprint_group_0.middleware(0, (0))
    assert callable(result), "Error: method middleware of class BlueprintGroup should return a function."

# Generated at 2022-06-26 03:02:15.818728
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic.blueprints import Blueprint
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint(name="bp1", url_prefix="/api/v1/")
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.middleware(fn=lambda a: a)
    assert blueprint_0.middlewares == [lambda a: a]



# Generated at 2022-06-26 03:02:17.087819
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware()



# Generated at 2022-06-26 03:02:18.499624
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()

    blueprint_group_0.middleware(lambda x: None)


# Generated at 2022-06-26 03:02:20.521610
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(None, None)


# Generated at 2022-06-26 03:02:31.572110
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    print("###### start test_BlueprintGroup_middleware ######")
    app = sanic.Sanic()

    @app.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup()
    bpg.append(bp3)
    bpg.append(bp4)


# Generated at 2022-06-26 03:02:37.788256
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic("sanic-blueprint-group-middleware")

    @app.middleware("request")
    async def bp_group_middleware(request):
        request.ctx.bp_1_middleware_applied = True
        request.ctx.bp_2_middleware_applied = True
        request.ctx.group_middleware_applied = True

    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    @bp1.middleware("request")
    async def bp1_only_middleware(request):
        request.ctx.bp_1_middleware_applied = True


# Generated at 2022-06-26 03:02:40.661989
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(lambda request: None)
    blueprint_group_0.middleware(lambda request: None)


# Generated at 2022-06-26 03:02:42.708830
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    def fn(request):
        return request
    blueprint_group_0.middleware(fn)


# Generated at 2022-06-26 03:02:48.539901
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group = BlueprintGroup("test_url_prefix", "test_version", "test_strict_slashes")
    blueprint_group._sanitize_blueprint("test_param_0")
    blueprint_group.append("test_param_0")
    blueprint_group.insert("test_param_0")
    blueprint_group.middleware("test_param_0")

# Generated at 2022-06-26 03:03:07.345400
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup(None,None,False)
    blueprint_group_2 = BlueprintGroup("/v1",None,False)
    blueprint_group_3 = BlueprintGroup(None,None,True)
    blueprint_group_4 = BlueprintGroup("/v1")
    blueprint_group_5 = BlueprintGroup(strict_slashes=True)
    blueprint_group_6 = BlueprintGroup(version="v2")
    blueprint_group_7 = BlueprintGroup(version=1)
    blueprint_group_8 = BlueprintGroup(version=0.1)


# Generated at 2022-06-26 03:03:10.621743
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint(url_prefix='/fzgks', strict_slashes=False)
    blueprint_group_0.append(blueprint_0)


# Generated at 2022-06-26 03:03:14.132280
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_0 = BlueprintGroup()
    assert len(blueprint_group_0) == 0
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_1.append(Blueprint("blueprint_0"))
    assert len(blueprint_group_0) == 0



# Generated at 2022-06-26 03:03:16.908704
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_0 = BlueprintGroup()
    assert isinstance(blueprint_group_0.__len__(), int)


# Generated at 2022-06-26 03:03:20.212520
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.__delitem__()



# Generated at 2022-06-26 03:03:21.277708
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    test_case_0()

# Generated at 2022-06-26 03:03:29.890952
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    blueprint_group = BlueprintGroup(url_prefix="/v1")
    blueprint_group.append(sanic.Blueprint(name="test_bp_1"))
    blueprint_group.append(sanic.Blueprint(name="test_bp_2"))
    blueprint_group.append(sanic.Blueprint(name="test_bp_3"))

    blueprint_group.append(sanic.Blueprint(name="test_bp_4"))
    blueprint_group.append(sanic.Blueprint(name="test_bp_5"))

    blueprint_group.append(sanic.Blueprint(name="test_bp_6"))


# Generated at 2022-06-26 03:03:31.876647
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.insert(0, Blueprint("bp_group_test_0"))


# Generated at 2022-06-26 03:03:33.491267
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    BlueprintGroup___iter___ret_value_0 = blueprint_group_0.__iter__()
    assert BlueprintGroup___iter___ret_value_0 == blueprint_group_0.blueprints


# Generated at 2022-06-26 03:03:40.527139
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    list_of_blueprint_objects = []
    list_of_blueprint_objects.append(Blueprint())
    list_of_blueprint_objects.append(Blueprint())
    list_of_blueprint_objects.append(Blueprint())
    blueprint_group_0._blueprints = list_of_blueprint_objects
    for blueprint_group_0_iterator in blueprint_group_0:
        assert type(blueprint_group_0_iterator) == Blueprint


# Generated at 2022-06-26 03:03:52.177990
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_1 = BlueprintGroup()
    assert blueprint_group_1.middleware is not None


# Generated at 2022-06-26 03:03:59.177032
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp0 = Blueprint("bp0", url_prefix='/bp0')
    bp1 = Blueprint("bp1", url_prefix='/bp1')
    bp2 = Blueprint("bp2", url_prefix='/bp2')
    bp3 = Blueprint("bp3", url_prefix='/bp3')
    bp4 = Blueprint("bp4", url_prefix='/bp4')
    bp5 = Blueprint("bp5", url_prefix='/bp5')
    bp6 = Blueprint("bp6", url_prefix='/bp6')
    bp7 = Blueprint("bp7", url_prefix='/bp7')
    bp8 = Blueprint("bp8", url_prefix='/bp8')
    bp9 = Blueprint("bp9", url_prefix='/bp9')

    # Test default BlueprintGroup()
   

# Generated at 2022-06-26 03:04:03.032172
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_1 = BlueprintGroup()
    result = blueprint_group_1.__iter__()
    print(result)
    assert True


# Generated at 2022-06-26 03:04:09.617676
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group = BlueprintGroup()
    test_cases = [
        [Blueprint('bp_1'), 0, True],
        [Blueprint('bp_2'), 1, True],
        [Blueprint('bp_3'), 2, True],
        [Blueprint('bp_4'), 3, False],
        [Blueprint('bp_5'), 4, False],
        [Blueprint('bp_6'), -1, False],
        [Blueprint('bp_7'), -2, True],
        [Blueprint('bp_8'), -3, True],
        [Blueprint('bp_9'), -4, False],
        [Blueprint('bp_10'), -5, False],
    ]

# Generated at 2022-06-26 03:04:16.713853
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp0 = Blueprint("bp0", url_prefix="/bp0")
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup(bp0)
    blueprint_group_2 = BlueprintGroup(bp0, bp1)
    blueprint_group_3 = BlueprintGroup(bp0, bp1, bp2)
    blueprint_group_4 = BlueprintGroup(bp0, bp1, bp2, url_prefix="/group")
    blueprint_group_5 = BlueprintGroup(bp0, bp1, bp2, version=1.0)

# Generated at 2022-06-26 03:04:20.565289
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint = Blueprint('test', url_prefix = '/test')
    blueprint_group = BlueprintGroup()
    blueprint_group.append(blueprint)
    blueprint_group.insert(0, blueprint)
    
    blueprint_group.middleware(lambda x : x)
    blueprint_group.middleware(lambda x : x, attach_to = 'request')



# Generated at 2022-06-26 03:04:24.207146
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint('blueprint_1')
    blueprint_0.route('/blueprint_0')
    blueprint_group_0._blueprints = []
    blueprint_group_0[0] = blueprint_0
    assert blueprint_group_0 == blueprint_group_0


# Generated at 2022-06-26 03:04:31.577577
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_1.append(sanic.Blueprint("test_case_1"))
    blueprint_group_1.append(sanic.Blueprint("test_case_2"))
    blueprint_group_1.append(sanic.Blueprint("test_case_3"))
    assert blueprint_group_1.__getitem__(0).name == "test_case_1"
    assert blueprint_group_1.__getitem__(1).name == "test_case_2"
    assert blueprint_group_1.__getitem__(2).name == "test_case_3"


# Generated at 2022-06-26 03:04:32.809226
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group = BlueprintGroup()
    # 0 assertions required


# Generated at 2022-06-26 03:04:36.264439
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint.group(blueprint_group_0)
    assert isinstance(iter(blueprint_0), collections.abc.Iterator)


# Generated at 2022-06-26 03:05:05.582783
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    # BlueprintGroup instance
    blueprint_group = BlueprintGroup()

    # Blueprints to be added to the Blueprint Group
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    # Blueprint Routes
    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)



# Generated at 2022-06-26 03:05:10.739850
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0._blueprints = list()
    blueprint_group_0._blueprints.append('str')
    blueprint_group_0._blueprints.append('str')
    blueprint_group_0._blueprints.append('str')

    output = blueprint_group_0.__iter__()
    assert isinstance(output, 'listiterator')



# Generated at 2022-06-26 03:05:15.375826
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint_group = BlueprintGroup(url_prefix=None,
                                     version=None,
                                     strict_slashes=None)

    assert blueprint_group.url_prefix is None
    assert blueprint_group.blueprints == []
    assert blueprint_group.version is None
    assert blueprint_group.strict_slashes is None



# Generated at 2022-06-26 03:05:19.112792
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint(name="test", url_prefix="/test")
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0[0] = blueprint_0


# Generated at 2022-06-26 03:05:21.626361
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_1 = BlueprintGroup()
    if len(blueprint_group_1) != 0:
        raise URIError('Test Failed')

# Test case Blueprint Group : __iter__

# Generated at 2022-06-26 03:05:25.786425
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(Blueprint('bp0', url_prefix='/bp0'))
    blueprint_group_0[0:0] = [Blueprint('bp1', url_prefix='/bp1')]
    blueprint_group_0[-1:] = [Blueprint('bp2', url_prefix='/bp2')]
    blueprint_group_0[:1] = [Blueprint('bp3', url_prefix='/bp3'), Blueprint('bp4', url_prefix='/bp4')]

# Generated at 2022-06-26 03:05:31.902820
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_0 = BlueprintGroup(url_prefix=url_prefix_0, version=version_0, strict_slashes=strict_slashes_0)
    # staticmethod
    blueprint_group_0.__delitem__
    blueprint_group_0.__delitem__(index_0)
    blueprint_group_0.__delitem__(index_0)


# Generated at 2022-06-26 03:05:42.533703
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpGroup = BlueprintGroup()

    bpGroup.append(bp1)
    bpGroup.append(bp2)
    bpGroup.append(bp3)
    bpGroup.append(bp4)
    assert bpGroup[0] == bp1
    assert bpGroup[1] == bp2
    assert bpGroup[2] == bp3
    assert bpGroup[3] == bp4


# Generated at 2022-06-26 03:05:43.858509
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    assert BlueprintGroup().insert(0, Blueprint(__name__))


# Generated at 2022-06-26 03:05:48.657760
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0._blueprints
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0._blueprints
    blueprint_group_0.append(blueprint_1)
    blueprint_group_0._blueprints


# Generated at 2022-06-26 03:06:33.138179
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.__getitem__(0)


# Generated at 2022-06-26 03:06:38.408097
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group = BlueprintGroup()
    blueprint_1 = Blueprint('blueprint_1')
    blueprint_group.append(blueprint_1)
    assert blueprint_group.__len__() == 1
    blueprint_2 = Blueprint('blueprint_2')
    blueprint_group.append(blueprint_2)
    assert blueprint_group.__len__() == 2


# Generated at 2022-06-26 03:06:45.769837
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    class BlueprintMock():

        def __init__(self):
            self.middleware_calls = []

        def middleware(self, fn, *args, **kwargs):
            self.middleware_calls.append((fn, args, kwargs))

    blueprint_group = BlueprintGroup()
    blueprint = BlueprintMock()
    blueprint_group.append(blueprint)

    middleware = lambda *args: None
    blueprint_group.middleware(middleware, expect_exceptions=True)

    assert len(blueprint.middleware_calls) == 1
    assert len(blueprint.middleware_calls[0]) == 3
    assert blueprint.middleware_calls[0][0] == middleware
    assert blueprint.middleware_calls[0][1] == tuple()
    assert blueprint.middleware_c

# Generated at 2022-06-26 03:06:52.249847
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint(
        'app',
        strict_slashes=None,
        url_prefix=None,
        version=None,
        host=None,
        host_name=None,
        subdomain=None,
        url_defaults=None,
    )
    # Passing test case
    try:
        blueprint_group_0[0] = blueprint_0
    except Exception as e:
        # Check if issue caused by test case
        assert(False)


# Generated at 2022-06-26 03:06:55.915041
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup('/', '', True)
    blueprint_group_0.append(Blueprint('', url_prefix=''))
    blueprint_group_0.append(Blueprint('', url_prefix=''))
    blueprint_group_0.__iter__()



# Generated at 2022-06-26 03:06:59.866031
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint('bp1', url_prefix='/bp1')
    blueprint_group_0[0] = blueprint_0
    blueprint_1 = blueprint_group_0[0]
    assert blueprint_1 == blueprint_0


# Generated at 2022-06-26 03:07:01.596437
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint_group_0 = BlueprintGroup()
    assert len(blueprint_group_0) == 0


# Generated at 2022-06-26 03:07:07.162306
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group_1 = BlueprintGroup()
    blueprint_1 = Blueprint("bp4", url_prefix='/bp4', strict_slashes=False)
    blueprint_group_1.append(blueprint_1)
    blueprint_group_1.insert(0, blueprint_1)
    blueprint_group_1.insert(1, blueprint_1)


# Generated at 2022-06-26 03:07:16.809413
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint("blueprint_0")
    blueprint_0.add_route(lambda x: None, "/blueprint_0", methods=("GET",))
    blueprint_0.add_route(lambda x: None, "/blueprint_0", methods=("POST",))
    blueprint_0.add_route(lambda x: None, "/blueprint_0", methods=("PUT",))
    blueprint_0.add_route(lambda x: None, "/blueprint_0", methods=("OPTIONS",))
    blueprint_0.add_route(lambda x: None, "/blueprint_0", methods=("HEAD",))
    blueprint_0.add_route(lambda x: None, "/blueprint_0", methods=("DELETE",))

# Generated at 2022-06-26 03:07:18.108568
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.__iter__()



# Generated at 2022-06-26 03:08:50.851070
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint(None, None)
    blueprint_group_0._blueprints = [None]
    blueprint_group_0.__setitem__(0, blueprint_0)


# Generated at 2022-06-26 03:08:54.023624
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group = BlueprintGroup()
    blueprint_group._blueprints = ["asd", "asd"]
    blueprint_group_0 = blueprint_group
    blueprint_group.__delitem__(0)
    blueprint_group_0 = blueprint_group


# Generated at 2022-06-26 03:09:00.301706
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_1 = BlueprintGroup(strict_slashes=True, url_prefix='', version='v1')
    blueprint_group_1.append(blueprint_group_0)
    assert len(blueprint_group_1) == 1
    assert blueprint_group_1[0] == blueprint_group_0
    blueprint_group_1[0] = blueprint_group_1
    assert blueprint_group_1[0] == blueprint_group_1
    blueprint_group_1[0] = blueprint_group_0
    assert blueprint_group_1[0] == blueprint_group_0


# Generated at 2022-06-26 03:09:06.644312
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group = BlueprintGroup("/api", version="v1", strict_slashes=True)
    blueprint_group.append(Blueprint("bp_1", url_prefix= "/bp1"))
    blueprint_group[0] = Blueprint("bp_2", url_prefix= "/bp2")
    assert blueprint_group[0].url_prefix == "/api/bp2"


# Generated at 2022-06-26 03:09:08.587600
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    # assert that BlueprintGroup is of type BlueprintGroup
    assert isinstance(test_case_0(), BlueprintGroup)

# Generated at 2022-06-26 03:09:14.240763
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint_group_0 = BlueprintGroup()
    assert blueprint_group_0._blueprints == []
    assert blueprint_group_0._url_prefix is None
    assert blueprint_group_0._version is None
    assert blueprint_group_0._strict_slashes is None

    blueprint_group_1 = BlueprintGroup(
        url_prefix='/url_prefix',
        version='1.1',
        strict_slashes=True,
    )
    assert blueprint_group_1._blueprints == []
    assert blueprint_group_1._url_prefix == '/url_prefix'
    assert blueprint_group_1._version == '1.1'
    assert blueprint_group_1._strict_slashes is True


# test case for property 'url_prefix' of class BlueprintGroup

# Generated at 2022-06-26 03:09:16.655486
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0_instance = iter(blueprint_group_0)
    assert isinstance(blueprint_group_0_instance, object)


# Generated at 2022-06-26 03:09:27.521628
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint_group_init = BlueprintGroup()
    blueprint_group_init._blueprints.append(sanic.Blueprint)
    blueprint_group_init._blueprints.append(sanic.Blueprint)
    blueprint_group_init._blueprints.append(sanic.Blueprint)
    blueprint_group_init._url_prefix = "/"
    blueprint_group_init._version = 1.0
    blueprint_group_init._strict_slashes = False
    assert len(blueprint_group_init._blueprints) == 3
    assert blueprint_group_init._url_prefix == "/"
    assert blueprint_group_init._version == 1.0
    assert blueprint_group_init._strict_slashes == False
    # Build Blueprint group with constructor parameters

# Generated at 2022-06-26 03:09:30.115676
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint('bp1', url_prefix='/bp1')
    blueprint_group_0.append(blueprint_0)
    del blueprint_group_0[0]


# Generated at 2022-06-26 03:09:36.695874
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_group_0 = BlueprintGroup(None, None)
    blueprint_group_0._blueprints = [None, None, None]
    blueprint_group_0._url_prefix = '/'
    blueprint_group_0._version = 0
    blueprint_group_0._strict_slashes = False
    blueprint_group_0.append(None)
    blueprint_group_0.insert(0, None)
    blueprint_group_0.middleware(None)
    blueprint_group_0.middleware(None, None)
    blueprint_group_0.middleware(None, None, None)
    blueprint_group_0.middleware(None, None, None, None)
    blueprint_group_0.middleware(None, None, None, None, None)