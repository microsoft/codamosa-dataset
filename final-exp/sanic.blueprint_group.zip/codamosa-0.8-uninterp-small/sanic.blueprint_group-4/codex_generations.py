

# Generated at 2022-06-26 03:00:01.964486
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware()



# Generated at 2022-06-26 03:00:05.224155
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(lambda request: text("IN") + text("OUT"), "request")


# Generated at 2022-06-26 03:00:14.230851
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(fn)
    blueprint_group_0.middleware(fn, 'request')
    blueprint_group_0.middleware(fn, 'response')
    blueprint_group_0.middleware(fn, 'request', 'response')
    blueprint_group_0.middleware(fn, 'response', 'request')
    blueprint_group_0.middleware(fn, 'request', 'response', 'request')
    blueprint_group_0.middleware(fn, 'response', 'request', 'response')


# Generated at 2022-06-26 03:00:23.966319
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from unittest.mock import Mock
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.blueprints = Mock()
    blueprint_group_0.version = None
    blueprint_group_0.strict_slashes = None
    blueprint_group_0.blueprints.__getitem__ = Mock(return_value=None)

    blueprint_group_0.middleware('request', 'response')
    blueprint_group_0.blueprints.__getitem__.assert_called_once_with('request', 'response')
    blueprint_group_0.blueprints.__getitem__.reset_mock()
    blueprint_group_0.middleware()
    blueprint_group_0.blueprints.__getitem__.assert_not_called()

# Generated at 2022-06-26 03:00:26.876403
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()

    fn = None
    blueprint_group_0.middleware(fn)


# Generated at 2022-06-26 03:00:31.179680
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_1 = Blueprint()
    blueprint_group_0.append(blueprint_1)
    def expected_result():
        pass
    blueprint_group_0.middleware(expected_result)
    blueprint_2 = blueprint_1.middleware_stack[0]
    assert blueprint_2.handler == expected_result


# Generated at 2022-06-26 03:00:41.065863
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    method_0 = BlueprintGroup.middleware(BlueprintGroup)
    method_1 = BlueprintGroup.middleware(BlueprintGroup)
    method_2 = BlueprintGroup.middleware(BlueprintGroup)
    method_3 = BlueprintGroup.middleware(BlueprintGroup)
    method_4 = BlueprintGroup.middleware(BlueprintGroup)
    method_5 = BlueprintGroup.middleware(BlueprintGroup)
    method_6 = BlueprintGroup.middleware(BlueprintGroup)
    method_7 = BlueprintGroup.middleware(BlueprintGroup)
    method_8 = BlueprintGroup.middleware(BlueprintGroup)
    method_9 = BlueprintGroup.middleware(BlueprintGroup)
    method_10 = BlueprintGroup.middleware(BlueprintGroup)
    method_11 = BlueprintGroup.middleware(BlueprintGroup)
    method_12 = BlueprintGroup

# Generated at 2022-06-26 03:00:45.759258
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    args = []
    kwargs = {}

    def fn_0():
        return

    # AssertionError
    try:
        blueprint_group_0.middleware(fn_0)
    except AssertionError:
        pass

# Generated at 2022-06-26 03:00:55.379060
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_2 = BlueprintGroup()
    blueprint_group_0.append(blueprint_group_1)
    blueprint_group_1.append(blueprint_group_2)
    blueprint_group_2.middleware(lambda: 0).stub()
    blueprint_group_1.middleware(lambda: 0).stub()
    blueprint_group_0.middleware(lambda: 0).stub()

    blueprint_group_2.middleware(lambda: 0)(lambda: 0)
    blueprint_group_2.middleware(lambda: 0)(lambda: 0)
    blueprint_group_1.middleware(lambda: 0)(lambda: 0)
    blueprint_group_1.middleware(lambda: 0)(lambda: 0)
    blueprint

# Generated at 2022-06-26 03:00:59.593597
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(request=sanic.request.Request)
    blueprint_group_0.middleware(args=(), kwargs={})
    blueprint_group_0.middleware(lambda request: request)


# Generated at 2022-06-26 03:01:07.950056
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Setup the blueprint group object
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(test_BlueprintGroup_middleware.__dict__)


# Generated at 2022-06-26 03:01:15.938457
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # mocking the decorator object
    decorator_mock = Mock()

    # mocking the blueprint
    bp = Mock()
    bp.middleware = MagicMock()

    # mocking the blueprint group
    blueprint_group = BlueprintGroup()
    blueprint_group._blueprints = [bp]

    # calling the blueprint group's method middleware
    blueprint_group.middleware(decorator_mock)

    # making sure the blueprint's middleware is being called
    bp.middleware.assert_called_with(decorator_mock)

# Generated at 2022-06-26 03:01:26.826751
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-26 03:01:32.828907
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.blueprints = [None] * 7 # type: ignore
    blueprint_group_0.blueprints[0] = Blueprint()
    blueprint_group_0.blueprints[1] = Blueprint()
    blueprint_group_0.blueprints[2] = Blueprint()
    blueprint_group_0.blueprints[3] = Blueprint()
    blueprint_group_0.blueprints[4] = Blueprint()
    blueprint_group_0.blueprints[5] = Blueprint()
    blueprint_group_0.blueprints[6] = Blueprint()
    blueprint_group_0.blueprints[0].middleware = lambda *args, **kwargs: None # type: ignore
    blueprint_group_0.blueprints[1].middleware = lambda *args, **kwargs: None # type:

# Generated at 2022-06-26 03:01:34.845094
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(lambda arg_1: arg_1)


# Generated at 2022-06-26 03:01:44.562551
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint('bp0', url_prefix='/bp0')
    blueprint_1 = Blueprint('bp1', url_prefix='/bp1')
    blueprint_0.blueprint_group = blueprint_group_0
    blueprint_1.blueprint_group = blueprint_group_0
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.append(blueprint_1)

    @blueprint_group_0.middleware('request')
    def request(request):
        pass
    assert len(blueprint_0.request_middlewares) == 1
    assert len(blueprint_1.request_middlewares) == 1


# Generated at 2022-06-26 03:01:53.089202
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic('test_sanic_server')
    blueprint = Blueprint('test_sanic_blueprint')
    blueprint.middleware(
        lambda request: None
    )  # Calling method middleware on a Blueprint instance
    blueprint_group = BlueprintGroup()
    blueprint_group.middleware(lambda request: None)
    blueprint_group.middleware(lambda request: None, attach_to=None)
    blueprint_group.middleware(lambda request: None, attach_to="request")
    blueprint_group.middleware(lambda request: None, attach_to="response")
    blueprint_group.middleware(lambda request: None, attach_to="error")
    blueprint_group.middleware(lambda request: None, attach_to="request", group=-1)

# Generated at 2022-06-26 03:01:57.100398
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class Arg:
        def __init__(self):
            self.url_prefix = "/"
            self.version = 1
            self.strict_slashes = True
            self.middlewares = {}

    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.blueprints = [Arg()]
    blueprint_group_0.middleware("")

# Generated at 2022-06-26 03:02:00.470286
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_1.middleware('request')
    blueprint_group_1.middleware('request', 'response')

# Generated at 2022-06-26 03:02:09.433832
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bg = BlueprintGroup()
    bp_0 = Blueprint('bp_0', url_prefix='/bp_0')
    bp_1 = Blueprint('bp_1', url_prefix='/bp_1')
    bp_2 = Blueprint('bp_2', url_prefix='/bp_2')
    bg.append(bp_0)
    bg.append(bp_1)
    bg.append(bp_2)
    test_fn = lambda req: req
    bg.middleware(test_fn, 'request')
    bg.middleware('request')(test_fn)



# Generated at 2022-06-26 03:02:22.120504
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0._blueprints.append(object())

    blueprint_group_0.__iter__()


# Generated at 2022-06-26 03:02:33.021354
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group = BlueprintGroup()
    blueprint_group.append(sanic.Blueprint("test_0", url_prefix="/"))
    blueprint_group.append(sanic.Blueprint("test_1", url_prefix="/"))
    blueprint_group.append(sanic.Blueprint("test_2", url_prefix="/"))
    blueprint_group.append(sanic.Blueprint("test_3", url_prefix="/"))
    blueprint_group.append(sanic.Blueprint("test_4", url_prefix="/"))
    blueprint_group.append(sanic.Blueprint("test_5", url_prefix="/"))
    blueprint_group.append(sanic.Blueprint("test_6", url_prefix="/"))
    del blueprint_group[5]
    assert len(blueprint_group) == 6



# Generated at 2022-06-26 03:02:37.350862
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    # Create a new BlueprintObject instance and save it to BlueprintGroup
    blueprint_item_0 = Blueprint("")
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0[0] = blueprint_item_0

    # Validate that expected parameters are set correctly
    assert blueprint_group_0[0] == blueprint_item_0


# Generated at 2022-06-26 03:02:39.421119
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_1 = Blueprint()
    blueprint_group_0[0] = blueprint_1


# Generated at 2022-06-26 03:02:41.921520
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_0 = BlueprintGroup()
    var_1 = blueprint_group_0.__len__()
    assert var_1 == 0


# Generated at 2022-06-26 03:02:51.497207
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint(name = 'Blueprint_0', url_prefix = '/Blueprint_1')
    blueprint_group_0.append(blueprint_0)
    assert isinstance(blueprint_group_0[0], Blueprint)
    blueprints_0 = blueprint_group_0.blueprints
    blueprint_group_0[0] = blueprints_0[0]
    assert isinstance(blueprint_group_0[0], Blueprint)
    blueprint_0 = Blueprint(name = 'Blueprint_0', url_prefix = '/Blueprint_1')
    blueprint_group_0[0] = blueprint_0
    assert isinstance(blueprint_group_0[0], Blueprint)


# Generated at 2022-06-26 03:02:53.076156
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0[None] = None


# Generated at 2022-06-26 03:03:03.805555
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup(url_prefix="", version=None, strict_slashes=None)
    blueprint_group_2 = BlueprintGroup(url_prefix=None, version="", strict_slashes=None)
    blueprint_group_3 = BlueprintGroup(url_prefix=None, version=None, strict_slashes="")
    blueprint_group_4 = BlueprintGroup(url_prefix="", version="", strict_slashes=None)
    blueprint_group_5 = BlueprintGroup(url_prefix="", version=None, strict_slashes="")
    blueprint_group_6 = BlueprintGroup(url_prefix=None, version="", strict_slashes="")
    blueprint_group_7 = BlueprintGroup(url_prefix="", version="", strict_slashes="")
    blueprint_group

# Generated at 2022-06-26 03:03:08.720830
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_group_0 = BlueprintGroup()
    exception_thrown = False
    try:
        blueprint_group_0[0]
    except IndexError:
        exception_thrown = True
    assert exception_thrown is True


# Generated at 2022-06-26 03:03:09.826298
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    x = BlueprintGroup()
    #x.__setitem__(index, item)
    assert 0


# Generated at 2022-06-26 03:03:29.644472
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    # Test1
    blueprint = Blueprint('bp1', url_prefix='/bp1')
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_1._blueprints.append(blueprint)
    assert blueprint_group_1[0] == blueprint
    # Test2
    blueprint_group_2 = BlueprintGroup()
    with pytest.raises(IndexError) as error:
        blueprint_group_2[0]
    assert "list index out of range" in str(error.value)


# Generated at 2022-06-26 03:03:33.671360
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint_group = BlueprintGroup('/bp', 'v1', True)

    assert blueprint_group.url_prefix == '/bp'
    assert blueprint_group.version == 'v1'
    assert blueprint_group.strict_slashes is True
    assert isinstance(blueprint_group._blueprints, list)



# Generated at 2022-06-26 03:03:35.341403
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():

    blueprint_group_0 = BlueprintGroup()
    assert len(blueprint_group_0) == 0



# Generated at 2022-06-26 03:03:46.899476
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    app = sanic.Sanic(__name__)

    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint('bp0', url_prefix='/bp0')

    blueprint_group_0.append(blueprint_0)

    blueprint_group_1 = BlueprintGroup()
    blueprint_11 = Blueprint('bp11', url_prefix='/bp11')
    blueprint_12 = Blueprint('bp12', url_prefix='/bp12')

    blueprint_group_1.append(blueprint_11)
    blueprint_group_1.append(blueprint_12)
    blueprint_group_1.append(blueprint_group_0)

    blueprint_group_2 = BlueprintGroup()
    blueprint_21 = Blueprint('bp21', url_prefix='/bp21')

# Generated at 2022-06-26 03:03:54.062327
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_0 = BlueprintGroup()
    instance_0 = BlueprintGroup()
    instance_1 = BlueprintGroup()

    index_0 = 0
    blueprint_blueprint_0 = Blueprint('bp0', url_prefix='/bp0')
    instance_0.append(blueprint_blueprint_0)
    instance_0._setitem__(index_0, instance_1)

    instance_1.append(blueprint_blueprint_0)
    with raises(Exception):
        instance_1._setitem__(0, instance_0)


# Generated at 2022-06-26 03:03:57.660701
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    # arrange
    blueprint_group = BlueprintGroup()
    blueprint_list = [Blueprint("bp1", url_prefix='/bp1'), 
                      Blueprint("bp2", url_prefix='/bp2')]

    # act
    for blueprint in blueprint_list:
        blueprint_group.append(blueprint)
    
    # assert
    assert len(blueprint_group) == 2

# Generated at 2022-06-26 03:04:02.441628
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_1 = BlueprintGroup()
    assert len(blueprint_group_1) == 0
    blueprint_group_1.append(Blueprint('bp1', url_prefix='/bp1'))
    assert len(blueprint_group_1) == 1


# Generated at 2022-06-26 03:04:03.254294
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()


# Generated at 2022-06-26 03:04:04.292595
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.__delitem__(int())


# Generated at 2022-06-26 03:04:05.503767
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_1 = BlueprintGroup()



# Generated at 2022-06-26 03:04:41.037931
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group_0 = BlueprintGroup(strict_slashes="fXo", version="o", url_prefix="I")
    blueprint_group_0.insert(0, Blueprint(name="o", strict_slashes="l", version="f"))
    assert blueprint_group_0.blueprints[0].name == "o"
    assert blueprint_group_0.blueprints[0].strict_slashes == "l"
    assert blueprint_group_0.blueprints[0].version == "f"
    blueprint_group_0.insert(0, Blueprint(name="/", strict_slashes="`", version="{"))
    assert blueprint_group_0.blueprints[0].name == "/"
    assert blueprint_group_0.blueprints[0].strict_slashes == "`"
    assert blueprint_group_0.blue

# Generated at 2022-06-26 03:04:48.145141
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_1.append(Blueprint('blueprint_0'))
    blueprint_group_1.append(Blueprint('blueprint_1'))
    blueprint_group_1.append(Blueprint('blueprint_2'))
    blueprint_group_1.append(Blueprint('blueprint_3'))
    blueprint_group_1.append(Blueprint('blueprint_4'))
    blueprint_group_1.append(Blueprint('blueprint_5'))
    blueprint_group_1.append(Blueprint('blueprint_6'))
    blueprint_group_1.append(Blueprint('blueprint_7'))
    blueprint_group_1.append(Blueprint('blueprint_8'))

# Generated at 2022-06-26 03:04:50.650905
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    def custom_middleware_0(request):
        return
    blueprint_group_0.middleware(custom_middleware_0)



# Generated at 2022-06-26 03:04:53.849287
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint_group_0 = BlueprintGroup()
    assert blueprint_group_0.url_prefix == None
    assert blueprint_group_0.version == None
    assert blueprint_group_0.strict_slashes == None
    assert len(blueprint_group_0.blueprints) == 0


# Generated at 2022-06-26 03:04:58.345512
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_1 = BlueprintGroup()

    # Given
    blueprint_0 = Blueprint("Blueprint 0")
    blueprint_1 = Blueprint("Blueprint 1")
    blueprint_2 = Blueprint("Blueprint 2")

    blueprint_0.add_route(handler=sanic.response.text, uri="/", methods=["GET"])
    blueprint_1.add_route(handler=sanic.response.text, uri="/", methods=["GET"])
    blueprint_2.add_route(handler=sanic.response.text, uri="/", methods=["GET"])

    blueprint_group_1.append(blueprint_0)
    blueprint_group_1.append(blueprint_1)
    blueprint_group_1.append(blueprint_2)


# Generated at 2022-06-26 03:05:01.316763
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append("yP")
    blueprint_group_0[0] = "yP"
    assert blueprint_group_0[0] == "yP"


# Generated at 2022-06-26 03:05:03.935489
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    """
    Insert a new item into the Blueprint Group
    """
    blueprint = Blueprint("test")
    blueprint_group = BlueprintGroup()
    blueprint_group.insert(0, blueprint)

    assert blueprint_group._blueprints[0] == blueprint


# Generated at 2022-06-26 03:05:06.535028
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group = BlueprintGroup('/blueprints')
    bp = Blueprint('bp')
    blueprint_group[0] = bp
    assert blueprint_group[0] == bp


# Generated at 2022-06-26 03:05:08.599493
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware('request')


# Generated at 2022-06-26 03:05:15.451594
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    group_0 = BlueprintGroup(url_prefix='/api', version='v1')
    assert str(group_0.blueprints) == "[]"
    assert group_0.url_prefix == '/api'
    assert group_0.version == 'v1'

    group_1 = BlueprintGroup(url_prefix='/api', strict_slashes=False)
    assert str(group_1.blueprints) == "[]"
    assert group_1.url_prefix == '/api'
    assert group_1.strict_slashes == False



# Generated at 2022-06-26 03:06:19.430570
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_group_0 = BlueprintGroup(version=0, strict_slashes=None)
    blueprint_group_0.__class__ = sanic.blueprints.BlueprintGroup
    blueprint_group_0._blueprints = list()
    blueprint_group_0._blueprints.append(sanic.Blueprint('test_case_0_bp', url_prefix='/test_case_0_bp'))
    blueprint_group_0._url_prefix = '/test_case_0'
    blueprint_group_0._version = 0
    blueprint_group_0._strict_slashes = None
    assert blueprint_group_0.__getitem__(0) == sanic.Blueprint('test_case_0_bp', url_prefix='/test_case_0_bp')



# Generated at 2022-06-26 03:06:21.926243
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    blueprint_group_1 = BlueprintGroup()
    blueprint = Blueprint("test_blueprint")
    blueprint_group_1.append(blueprint)
    assert blueprint_group_1.blueprints == [blueprint]


# Generated at 2022-06-26 03:06:33.671825
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()
    blueprint_group_0 = BlueprintGroup()

    def test_func():
        pass

    def func_1(request):
        pass

    def func_2(request, param_1):
        pass

    def func_3(request, param_1, param_2):
        pass

    @blueprint_group_0.middleware('request')
    @blueprint_group_0.middleware('request')
    @blueprint_group_0.middleware('request')
    def middleware_test_func():
        pass

    blueprint_group_0.middleware('request', test_func)
    blueprint_group_0.middleware('request', test_func)

    bp_1 = Blueprint('bp1', url_prefix='/bp1')

# Generated at 2022-06-26 03:06:37.697338
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group_1 = BlueprintGroup()
    blueprint_1 = Blueprint(name="Blueprint_1")
    blueprint_group_1.insert(0, blueprint_1)
    assert blueprint_group_1._blueprints[0] == blueprint_1, "Inserting an item into a blueprint group does not work"



# Generated at 2022-06-26 03:06:45.388064
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group = BlueprintGroup()
    
    blueprint_group.append(Blueprint('blueprint_group_1', url_prefix='/blueprint_group_1'))
    blueprint_group.append(Blueprint('blueprint_group_2', url_prefix='/blueprint_group_2'))
    blueprint_group.append(Blueprint('blueprint_group_3', url_prefix='/blueprint_group_3'))
    blueprint_group.append(Blueprint('blueprint_group_4', url_prefix='/blueprint_group_4'))
    
    assert len(blueprint_group.blueprints) == 4

# Generated at 2022-06-26 03:06:49.777139
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(sanic.blueprints.Blueprint())
    blueprint_group_0.append(sanic.blueprints.Blueprint())
    blueprint_group_0.append(sanic.blueprints.Blueprint())
    assert len(blueprint_group_0) == 3

# Generated at 2022-06-26 03:06:51.762536
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_group_0 = BlueprintGroup()
    assert blueprint_group_0.__getitem__(0) == None


# Generated at 2022-06-26 03:06:55.454991
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_1 = Blueprint("bp1")
    blueprint_2 = Blueprint("bp2")
    blueprint_group_0.append(blueprint_1)
    blueprint_group_0.append(blueprint_2)
    assert len(blueprint_group_0) == 2

# Generated at 2022-06-26 03:06:56.833664
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(Blueprint())


# Generated at 2022-06-26 03:07:05.247814
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group = BlueprintGroup()
    blueprint_group._blueprints = ['foo', 'bar', 'baz', 'qux']
    blueprint_group_iter = blueprint_group.__iter__()
    blueprint_group_next = blueprint_group_iter.__next__()
    blueprint_group_next = blueprint_group_iter.__next__()
    blueprint_group_next = blueprint_group_iter.__next__()
    blueprint_group_next = blueprint_group_iter.__next__()
    blueprint_group_next = blueprint_group_iter.__next__()



# Generated at 2022-06-26 03:09:05.099254
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(None)
    blueprint_group_0[0] = None



# Generated at 2022-06-26 03:09:12.361503
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    try:
        bpg.insert(0, bp3)
        bpg.insert(3, bp4)
        bpg.insert(3, bp5)
    except Exception as e:
        print(e)


# Generated at 2022-06-26 03:09:17.143592
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint('bp1', url_prefix='/bp1', version='v')
    blueprint_1 = Blueprint('bp2', url_prefix='/bp2', version='v')
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.append(blueprint_1)
    blueprint_group_0.__setitem__(0, blueprint_1)


# Generated at 2022-06-26 03:09:21.027059
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.blueprints = [0, 1, 2]

    assert blueprint_group_0.__iter__() == [0, 1, 2]


# Generated at 2022-06-26 03:09:26.127226
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_0.append(blueprint_group_1)
    blueprint_group_2 = BlueprintGroup()
    blueprint_group_0.append(blueprint_group_2)
    for blueprint_group_elem in blueprint_group_0:
        pass


# Generated at 2022-06-26 03:09:29.634309
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
  try:
    # Create a new BlueprintGroup object
    blueprint_group_0 = BlueprintGroup()

    # Create an empty function
    def f_test():
      pass

    # Call method middleware of blueprint_group_0
    blueprint_group_0.middleware(f_test)
  except Exception as e:
    assert False


# Generated at 2022-06-26 03:09:33.934814
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint("autogen_0", url_prefix=None)
    blueprint_group_0.append(blueprint_0)
    blueprint_1 = Blueprint("autogen_1", url_prefix=None)
    blueprint_group_0.insert(0, blueprint_1)
    blueprint_group_0.insert(1, blueprint_1)


# Generated at 2022-06-26 03:09:35.413691
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0_result = blueprint_group_0.__getitem__(0)


# Generated at 2022-06-26 03:09:37.688198
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint('bp1', url_prefix='/bp1')
    blueprint_group_0.append(blueprint_0)


# Generated at 2022-06-26 03:09:41.520633
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(sanic.Blueprint('bp1', url_prefix='/bp1'))
    blueprint_group_0.append(sanic.Blueprint('bp2', url_prefix='/bp2'))
    blueprint_group_0[1] = blueprint_group_0[0]

