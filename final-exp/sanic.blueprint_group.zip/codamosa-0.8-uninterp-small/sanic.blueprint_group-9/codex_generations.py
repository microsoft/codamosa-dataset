

# Generated at 2022-06-26 02:59:55.429775
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    pass
    # optional_0 = None
    # kwargs_0 = None
    # BlueprintGroup._sanitize_blueprint(optional_0, kwargs_0)



# Generated at 2022-06-26 02:59:58.208638
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Creating a Blueprint Object
    blueprint_group_0 = BlueprintGroup()
    def fn_0(request):
        return text(request.url)
    blueprint_group_0.blueprints.append(fn_0)

    blueprint_0 = Blueprint("blueprint_0", url_prefix="url_prefix_0", version=1.1)
    blueprint_0.middleware(blueprint_group_0)


# Generated at 2022-06-26 03:00:01.161221
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    optional_0 = None
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint.group(blueprint_group_0, )
    blueprint_0.middleware()



# Generated at 2022-06-26 03:00:03.136891
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    optional_0 = None
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(optional_0)


# Generated at 2022-06-26 03:00:15.571044
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    _blueprint_0 = Blueprint("_blueprint_0", url_prefix="/_blueprint_0", version=11, strict_slashes=True)
    blueprint_group_0 = BlueprintGroup(url_prefix="/", version=13, strict_slashes=True)
    blueprint_group_0.append(_blueprint_0)
    blueprint_group_0.middleware(_blueprint_0)
    blueprint_group_0.middleware(_blueprint_0, "/")
    blueprint_group_0.middleware(_blueprint_0, "applied on Blueprint : bp1 Only")
    blueprint_group_0.middleware(_blueprint_0, "applied on Blueprint : bp1 Only", "/")

# Generated at 2022-06-26 03:00:18.198354
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    optional_0 = None
    blueprint_group_0 = BlueprintGroup()



# Generated at 2022-06-26 03:00:26.574599
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    mock_app_0 = MagicMock(name = 'app')
    mock_app_0.__module__ = 'sanic'
    mock_app_0.__name__ = 'app'

    mock_fn_0 = MagicMock(name = 'fn', return_value = None)
    mock_fn_0.__module__ = 'sanic'
    mock_fn_0.__name__ = 'fn'

    optional_0 = None

    # Create an instance of BlueprintGroup
    blueprint_group_0 = BlueprintGroup(optional_0, optional_0, optional_0)
    
    # Call method middleware of BlueprintGroup class with args (fn)
    blueprint_group_0.middleware(mock_fn_0)
    

# Generated at 2022-06-26 03:00:30.798949
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    test_case_0()


# Generated at 2022-06-26 03:00:33.064605
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    optional_0 = None
    blueprint_group_0 = BlueprintGroup()
    with pytest.raises(NotImplementedError):
        blueprint_group_0.middleware()

# Generated at 2022-06-26 03:00:36.099817
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    optional_0 = None
    blueprint_group_0 = BlueprintGroup()
    def function_0(function_0):
        return function_0
    blueprint_group_0.middleware(function_0)


# Generated at 2022-06-26 03:00:49.499862
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_2 = BlueprintGroup()
    blueprint_group_3 = BlueprintGroup()
    blueprint_group_4 = BlueprintGroup()
    blueprint_group_5 = BlueprintGroup()
    blueprint_group_6 = BlueprintGroup()
    blueprint_group_7 = BlueprintGroup()
    blueprint_group_8 = BlueprintGroup()
    blueprint_group_9 = BlueprintGroup()
    blueprint_group_10 = BlueprintGroup()
    blueprint_group_11 = BlueprintGroup()
    blueprint_group_12 = BlueprintGroup()
    blueprint_group_13 = BlueprintGroup()
    blueprint_group_14 = BlueprintGroup()
    blueprint_group_15 = BlueprintGroup()
    blueprint_group_16 = BlueprintGroup()
    blueprint_group_17 = BlueprintGroup()
   

# Generated at 2022-06-26 03:00:53.734646
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic(name="sanic-test")
    optional_0 = BlueprintGroup()
    app.blueprint(optional_0)
# testing the default value of middleware's 1st param: fn


# testing the default value of middleware's 2nd param: *args

# testing the default value of middleware's 3rd param: **kwargs




# Generated at 2022-06-26 03:01:02.897405
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware()
    blueprint_group_0.middleware(None)
    blueprint_group_0.middleware(None, None)
    blueprint_group_0.middleware(None, None)
    blueprint_group_0.middleware(None, None, None)
    blueprint_group_0.middleware(None, None, None)
    blueprint_group_0.middleware(None, None, None, None)
    blueprint_group_0.middleware(None, None, None, None)
    blueprint_group_0.middleware(None, None, None, None, None)
    blueprint_group_0.middleware(None, None, None, None, None)

# Generated at 2022-06-26 03:01:06.027631
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    parameters = "Optional[AsyncPartial[" + sanic.middleware.BaseHTTPMiddleware + "]]"
    optional_0 = None
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(optional_0)



# Generated at 2022-06-26 03:01:10.259886
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(lambda: None, lambda: None, lambda: None)
    blueprint_group_0.middleware(lambda: None, lambda: None)
    blueprint_group_0.middleware(lambda: None)


sanic.Blueprint.group = BlueprintGroup

# Generated at 2022-06-26 03:01:19.162406
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    optional_0 = None
    blueprint_group_0 = BlueprintGroup()
    class_type_0 = 2
    function_type_0 = partial(sanic.exceptions.abort, class_type_0, None)
    function_type_1 = partial(blueprint_group_0.middleware, function_type_0)
    function_type_1()
    class_type_1 = type
    function_type_2 = partial(
        blueprint_group_0.middleware, class_type_1, None)
    function_type_2()


# Generated at 2022-06-26 03:01:22.616218
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    # setup
    optional_0 = None
    blueprint_group_0 = BlueprintGroup()

    # test
    if (blueprint_group_0.middleware):
        raise RuntimeError



# Generated at 2022-06-26 03:01:24.073518
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    test_case_0()
    test_case_1()


# Generated at 2022-06-26 03:01:25.757683
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    optional_0 = None

    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware()

# Generated at 2022-06-26 03:01:34.002740
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bpg = BlueprintGroup(url_prefix="/prefix", version="v1", strict_slashes=True)

    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bp3 = Blueprint("bp3")

    bpg.append(bp1)
    bpg.append(bp2)

    bpg.middleware(sanic.request_middleware)
    assert len(bp1.middlewares.get("request", [])) == 1
    assert len(bp2.middlewares.get("request", [])) == 1
    assert len(bp3.middlewares.get("request", [])) == 0

    bpg.middleware(sanic.request_middleware, attach_to="response")
    assert len(bp1.middlewares.get("request", [])) == 1

# Generated at 2022-06-26 03:01:41.224647
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Test input and expected result
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(test_case_0)


# Generated at 2022-06-26 03:01:43.993620
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    optional_0 = None
    blueprint_group_0 = BlueprintGroup()
    middleware_0 = blueprint_group_0.middleware
    assert middleware_0


# Generated at 2022-06-26 03:01:48.266708
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Optional 0
    optional_0 = None
    # Optional 1
    optional_1 = "foo"
    # Optional 2
    optional_2 = "bar"
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(optional_0)


# Generated at 2022-06-26 03:01:52.239692
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Asserts that the BlueprintGroup middleware method returns a partial function that adds the defined function as a middleware for the blueprints that belong to the blueprint group.
    """
    # Create and instance of the BlueprintGroup class
    blueprint_group_0 = BlueprintGroup()

    # Test the middleware method of the BlueprintGroup class
    assert(callable(blueprint_group_0.middleware(lambda x: x)))



# Generated at 2022-06-26 03:01:56.763413
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    optional_0 = None
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint(url_prefix=optional_0)
    blueprint_group_0.append(blueprint_0)
    blueprint_1 = Blueprint(url_prefix=optional_0)
    blueprint_group_0.append(blueprint_1)
    blueprint_group_0.middleware(None)



# Generated at 2022-06-26 03:02:08.926065
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app_0 = sanic.Sanic()
    blueprint_group_0 = BlueprintGroup(url_prefix= "/api", version= "v1", strict_slashes= False)
    blueprint_group_0.url_prefix = "/api"
    blueprint_group_0.version = "v1"
    blueprint_group_0.strict_slashes = False
    blueprint_0 = Blueprint(name= "bp1", url_prefix= "/bp1")
    blueprint_group_0.blueprints = [blueprint_0]
    blueprint_1 = Blueprint(name= "bp2", url_prefix= "/bp2")
    blueprint_group_0.blueprints = [blueprint_1]
    blueprint_2 = Blueprint(name= "bp1", url_prefix= "/bp1")
    blueprint_0.name = "bp1"


# Generated at 2022-06-26 03:02:11.453419
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp = Blueprint('bp')


# Generated at 2022-06-26 03:02:13.750930
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware()


# Generated at 2022-06-26 03:02:16.834940
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    optional_0 = None
    blueprint_group_0 = BlueprintGroup()
    assert blueprint_group_0.middleware == NotImplemented


# Generated at 2022-06-26 03:02:19.013198
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    optional_0 = None
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware()



# Generated at 2022-06-26 03:02:30.159485
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    optional_0 = None
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware("YsWkfj")


# Generated at 2022-06-26 03:02:31.642141
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Case 1
    optional_0 = None
    blueprint_group_0 = BlueprintGroup()
    assert blueprint_group_0.middleware() is not None


# Generated at 2022-06-26 03:02:33.311759
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    optional_0 = None
    blueprint_group_0 = BlueprintGroup()
    test_case_0()


# Generated at 2022-06-26 03:02:37.304868
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    optional_0 = None
    blueprint_group_0 = BlueprintGroup()
    kwargs_0 = {"optional_1": optional_0}
    # Verify that the method does not return anything
    result = blueprint_group_0.middleware(kwargs_0)
    assert result is None


# Generated at 2022-06-26 03:02:46.242689
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # if True:
    #     raise Exception(
    #         "Cannot test middleware: do not know how to apply it and retrieve it"
    #         " from the object"
    #     )
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")
    blueprint_group_0 = Blueprint.group(bp1, bp2)
    blueprint_group_0.middleware(bp3, bp4)



# Generated at 2022-06-26 03:02:52.482443
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    optional_0 = None
    bp1_0 = Blueprint(optional_0, optional_0)
    bp2_0 = Blueprint(optional_0, optional_0)
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(bp1_0)
    blueprint_group_0.append(bp2_0)
    blueprint_group_0.middleware(optional_0)


if __name__ == "__main__":
    test_case_0()
    test_BlueprintGroup_middleware()

# Generated at 2022-06-26 03:02:56.578652
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware()
    blueprint_group_0.middleware("")
    blueprint_group_0.middleware("", "")
    blueprint_group_0.middleware("", "", "")


# Generated at 2022-06-26 03:02:59.526980
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(blueprint_group_0)
    # TODO: Make proper assertions


# Generated at 2022-06-26 03:03:02.362127
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    optional_0 = None
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(optional_0)
    blueprint_group_0.middleware()


# Generated at 2022-06-26 03:03:08.028859
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic("test_BlueprintGroup_middleware")
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(app.blueprint(None))

    @blueprint_group_0.middleware('response')
    async def middleware(request):
        pass



# Generated at 2022-06-26 03:03:22.920835
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    test_case_0()

# Generated at 2022-06-26 03:03:32.941432
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.blueprints = []
    blueprint_group_0.strict_slashes = None
    blueprint_group_0.url_prefix = 'http://www.example.com'
    blueprint_group_0.version = 0
    blueprint_0 = Blueprint()
    blueprint_0.name = 'name0'
    blueprint_0.defer = True
    blueprint_0.url_prefix = 'http://www.example.com'
    blueprint_0.strict_slashes = True
    blueprint_0.version = 0
    blueprint_0.websocket_timeout = 60
    blueprint_0.websocket_max_size = 102400
    blueprint_0.websocket_max_queue = 100
    blueprint_0.websocket_read_limit = 1024

# Generated at 2022-06-26 03:03:43.459630
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bp4 = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-26 03:03:53.623949
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    def _test_blueprint_group_middleware(middleware, *args, **kwargs):
        bp = Blueprint('bp')
        bp_group = BlueprintGroup(bp)
        assert len(bp.middlewares['request']) == 0
        bp_group.middleware(middleware, *args, **kwargs)
        assert len(bp.middlewares['request']) == 1
        assert bp.middlewares['request'][0][0] == middleware

    def middleware(request):
        pass

    _test_blueprint_group_middleware(middleware)
    _test_blueprint_group_middleware(middleware, attach_to='request')
    _test_blueprint_group_middleware(middleware, 'request')

# Generated at 2022-06-26 03:03:55.004688
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    optional_0 = None
    blueprint_group_0 = BlueprintGroup()
    assert blueprint_group_0.middleware


# Generated at 2022-06-26 03:03:57.109225
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    optional_0 = None
    blueprint_group_0 = BlueprintGroup()



# Generated at 2022-06-26 03:04:08.476966
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp3 = Blueprint('bp3', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-26 03:04:09.223278
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    test_case_0()


# Generated at 2022-06-26 03:04:11.468624
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Optional function parameter
    optional_0 = None

    # Instance of class BlueprintGroup for test
    blueprint_group_0 = BlueprintGroup()

    # Call method
    blueprint_group_0.middleware(
        optional_0
    )

# Generated at 2022-06-26 03:04:14.336456
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    optional_0 = None
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(optional_0)


# Generated at 2022-06-26 03:04:52.886772
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group_0 = BlueprintGroup()

    blueprint_0 = Blueprint("blueprint_0")
    blueprint_group_0.insert(0, blueprint_0)


# Generated at 2022-06-26 03:05:00.985495
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp_group = BlueprintGroup('test_prefix', version=1)
    assert bp_group.url_prefix == 'test_prefix'
    assert bp_group.version == 1
    assert bp_group.strict_slashes == None
    bp_group = BlueprintGroup(url_prefix='test2')
    assert bp_group.url_prefix == 'test2'
    assert bp_group.version == None
    assert bp_group.strict_slashes == None
    bp_group = BlueprintGroup()
    assert bp_group.url_prefix == None
    assert bp_group.version == None
    assert bp_group.strict_slashes == None
    bp_group = BlueprintGroup(version=2)
    assert bp_group.url_prefix == None
    assert b

# Generated at 2022-06-26 03:05:05.065467
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    optional_0 = None
    blueprint_group_0 = BlueprintGroup()
    blueprint_1 = Blueprint("bp1", "bp1")
    blueprint_group_0._blueprints.append(blueprint_1)
    blueprint_2 = Blueprint("bp2", "bp2")
    blueprint_group_0._blueprints.append(blueprint_2)
    blueprint_group_0._blueprints = blueprint_group_0._blueprints[0:1]


# Generated at 2022-06-26 03:05:10.490183
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    blueprint_group_0 = BlueprintGroup("/api", "v1", True)
    blueprint_group_0.append(bp1)
    blueprint_group_0.append(bp2)
    blueprint_group_0.append(bpg)
    blueprint_group_1 = BlueprintGroup("/api", "v1", True)
    blueprint_group_1.append(bp1)
    blueprint_group_

# Generated at 2022-06-26 03:05:15.450815
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    optional_0 = None
    blueprint_group_0 = BlueprintGroup()
    assert blueprint_group_0._blueprints == []
    blueprint_group_0._blueprints = optional_0
    assert blueprint_group_0._blueprints == []

    # Test Case
    blueprint_group_0._blueprints = optional_0
    assert blueprint_group_0._blueprints == []


# Generated at 2022-06-26 03:05:22.366989
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup('q0', 'q1', version='q2', strict_slashes='q3')
    blueprint_0 = Blueprint()
    blueprint_group_0.append(blueprint_0)
    blueprint_1 = Blueprint()
    blueprint_group_0.append(blueprint_1)
    blueprint_group_0._sanitize_blueprint(blueprint_group_0)
    blueprint_group_0.middleware(blueprint_group_0)
    blueprint_group_0.append(blueprint_0)



# Generated at 2022-06-26 03:05:25.500490
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    optional_0 = None
    blueprint_group_0 = BlueprintGroup()
    args_0 = [0, Blueprint]
    blueprint_group_0.__setitem__(*args_0)


# Generated at 2022-06-26 03:05:36.242771
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    optional_0 = BlueprintGroup()
    assert optional_0.middleware() is None
    assert optional_0.middleware() is None
    assert optional_0.middleware(True) is None
    assert optional_0.middleware(True) is None
    assert optional_0.middleware(True) is None
    assert optional_0.middleware() is None
    assert optional_0.middleware() is None
    assert optional_0.middleware() is None
    assert optional_0.middleware() is None
    assert optional_0.middleware() is None
    assert optional_0.middleware() is None
    assert optional_0.middleware() is None
    assert optional_0.middleware() is None
    assert optional_0.middleware() is None
    assert optional_0.middleware() is None

# Unit test

# Generated at 2022-06-26 03:05:38.881695
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    optional_0 = None
    blueprint_group_0 = BlueprintGroup()
    for blueprint in blueprint_group_0:
        pass


# Generated at 2022-06-26 03:05:49.185262
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    optional_0 = None
    blueprint_group_0 = BlueprintGroup()
    args_0 = None
    kwargs_0 = None
    def register_middleware_for_blueprints(blueprints):
        pass
    partial_func = blueprint_group_0.middleware(register_middleware_for_blueprints)
    # This method is used to perform the list's indexed setter operation.
    blueprint_group_0[0] = blueprint_group_0
    # This method is used to perform the list's indexed setter operation.
    blueprint_group_0[0] = blueprint_group_0
    # This method is used to delete an item from the list of blueprint
    # groups like it can be done on a regular list with index.
    del blueprint_group_0[0]