

# Generated at 2022-06-26 02:59:58.336996
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = Blueprint('name', url_prefix='/test')
    blueprint_group_0.blueprints = BlueprintGroup()
    var_0 = blueprint_group_0.blueprints.middleware('arg_0')
    var_1 = blueprint_group_0.middleware('arg_0')
    var_2 = blueprint_group_0.blueprints.middleware()
    var_3 = blueprint_group_0.middleware()
    var_4 = blueprint_group_0.blueprints.middleware('arg_0')('arg_1')
    # var_5 = blueprint_group_0.middleware('arg_0')('arg_1')
    var_6 = blueprint_group_0.blueprints.middleware()('arg_0')
    # var_7 = blueprint_group_0.middleware()

# Generated at 2022-06-26 03:00:00.944501
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup(url_prefix=str(), version=str(), strict_slashes=bool())
    blueprint_group_0.middleware()


# Generated at 2022-06-26 03:00:04.336329
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    schema_0 = ('c',)
    schema_1 = ('d',)
    def handler_0(request, *args, **kwargs):
        return request
    blueprint_group_0.middleware(handler_0, schema_0, schema_1)


# Generated at 2022-06-26 03:00:06.323588
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    var_0 = blueprint_group_0.middleware


# Generated at 2022-06-26 03:00:08.522639
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(0)


# Generated at 2022-06-26 03:00:13.413821
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint('bp_name', url_prefix='/bp1')
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.middleware(sanic.request_middleware)


# Generated at 2022-06-26 03:00:17.038365
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    var_0 = "blueprint_group_0"
    assert blueprint_group_0.middleware(**{})()(var_0) == var_0
    assert blueprint_group_0.middleware(var_0) == var_0

# Generated at 2022-06-26 03:00:20.413738
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    assert blueprint_group_0.__iter__() , "This should be an iterable"
    blueprint_group_0.middleware()



# Generated at 2022-06-26 03:00:25.662870
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    def register_middleware_for_blueprints(fn): pass

    # TODO: Test this method
    assert False


# Generated at 2022-06-26 03:00:34.019904
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_0.append(blueprint_group_1)
    blueprint_1 = Blueprint('bp2', url_prefix='/bp2')
    blueprint_group_1.append(blueprint_1)
    blueprint_group_2 = BlueprintGroup()
    blueprint_2 = Blueprint('bp2', url_prefix='/bp2')
    blueprint_group_2.append(blueprint_2)
    blueprint_group_1.append(blueprint_group_2)
    blueprint_group_0.middleware(None, None, None)


# Generated at 2022-06-26 03:00:46.603707
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_keyword_arg_none = None
    blueprint_group_positional_arg_none = None
    blueprint_group_return_value_none = blueprint_group_1.middleware(
        blueprint_group_keyword_arg_none, blueprint_group_positional_arg_none
    )
    blueprint_group_2 = BlueprintGroup()
    blueprint_group_1.__init__(blueprint_group_2)
    blueprint_group_param_none = None
    blueprint_group_1.middleware(blueprint_group_param_none)


# Generated at 2022-06-26 03:00:49.048146
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_1.middleware(None)

# Unit tests for __init__ of class BlueprintGroup

# Generated at 2022-06-26 03:00:58.939633
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Create a Sanic instance
    app_0 = sanic.Sanic()

    # Create a Blueprint object
    blueprint_0 = Blueprint('bp1', url_prefix='/bp1')

    # Create a Blueprint object
    blueprint_1 = Blueprint('bp2', url_prefix='/bp2')

    # Create a Blueprint object
    blueprint_2 = Blueprint('bp3', url_prefix='/bp4')

    # Create a Blueprint object
    blueprint_3 = Blueprint('bp4', url_prefix='/bp4')

    # Create a BlueprintGroup object
    blueprint_group_0 = BlueprintGroup(
        blueprint_2,
        blueprint_3,
        url_prefix = "/api",
        version = "v1"
    )

    # Register Blueprint object to the Sanic instance
    app_0.blueprint(blueprint_0)

# Generated at 2022-06-26 03:01:02.702008
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_1.url_prefix = "/test_url_prefix"
    blueprint_group_1.version = "/test_version"
    blueprint_group_1.strict_slashes = "/test_strict_slashes"

    blueprint_group_1.middleware("/test_blueprints")
    blueprint_group_1.middleware("/test_middleware", "/test_args", "/test_params")


# Generated at 2022-06-26 03:01:12.260492
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group = Blueprint("blueprint_group", url_prefix="blueprint_group")
    blueprint_group.middleware("blueprint_group")
    blueprint_group.middleware("blueprint_group", "blueprint_group")
    blueprint_group.middleware("blueprint_group", "blueprint_group", "blueprint_group")
    blueprint_group.middleware("blueprint_group", "blueprint_group", "blueprint_group", "blueprint_group")
    blueprint_group.middleware("blueprint_group", "blueprint_group", "blueprint_group", "blueprint_group", "blueprint_group")
    blueprint_group.middleware("blueprint_group", "blueprint_group", "blueprint_group", "blueprint_group", "blueprint_group", "blueprint_group")
    blueprint_

# Generated at 2022-06-26 03:01:18.413482
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.blueprints = list()
    blueprint_group_0.blueprints.append(Blueprint(name='1'))
    blueprint_group_0.blueprints.append(Blueprint(name='2'))
    blueprint_group_0.middleware(sanic.request_middleware)


# Generated at 2022-06-26 03:01:21.725571
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    def blueprints_middleware(request):
        pass
    blueprint_group_0.middleware(blueprints_middleware, server_name="app")


# Generated at 2022-06-26 03:01:25.369162
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Setup
    blueprint_group_0 = BlueprintGroup()
    def fn_0():
        return
    # Teardown

    # Test Case
    blueprint_group_0.middleware(fn_0)


# Generated at 2022-06-26 03:01:31.748662
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app_0 = sanic.Sanic()
    blueprint_group_0 = BlueprintGroup(url_prefix='/', version=100.0, strict_slashes=True)
    blueprint_0 = Blueprint(name='bp1', url_prefix='/', version=100.0, strict_slashes=True)
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.middleware(app_0)
    blueprint_group_0.middleware()
    blueprint_group_0.middleware(app_0)


# Generated at 2022-06-26 03:01:41.593030
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.blueprints = [ Blueprint('/path/to/blueprint', url_prefix='/blueprint'), Blueprint('/path/to/blueprint', url_prefix='/blueprint'), Blueprint('/path/to/blueprint', url_prefix='/blueprint'), Blueprint('/path/to/blueprint', url_prefix='/blueprint'), Blueprint('/path/to/blueprint', url_prefix='/blueprint') ]
    blueprint_group_0.blueprints[0].app = sanic.Sanic('sanic.app', load_env=True)
    blueprint_group_0.blueprints[1].app = sanic.Sanic('sanic.app', load_env=True)

# Generated at 2022-06-26 03:01:52.182539
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # test for method middleware
    blueprint_group_1 = BlueprintGroup()
    var_1 = Blueprint("dummy_bp_name_1")
    blueprint_group_1.append(var_1)
    var_2 = Blueprint("dummy_bp_name_2")
    blueprint_group_1.append(var_2)
    var_3 = Blueprint("dummy_bp_name_3")
    blueprint_group_1.append(var_3)
    var_4 = Blueprint("dummy_bp_name_4")
    blueprint_group_1.append(var_4)
    var_5 = Blueprint("dummy_bp_name_5")
    blueprint_group_1.append(var_5)

# Generated at 2022-06-26 03:01:55.935842
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(lambda arg_0 : arg_0)
    var_0 = blueprint_group_0.middleware(lambda arg_0 : arg_0)(lambda arg_0 : arg_0)

# Unit Test for append

# Generated at 2022-06-26 03:01:58.011661
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    assert True

# Generated at 2022-06-26 03:02:08.156303
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(Blueprint('bp1', url_prefix='/bp1'))
    blueprint_group_0.append(Blueprint('bp2', url_prefix='/bp2'))
    blueprint_group_0.middleware(lambda x: x)

    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(Blueprint('bp1', url_prefix='/bp1'))
    blueprint_group_0.append(Blueprint('bp2', url_prefix='/bp2'))
    var_0 = blueprint_group_0.middleware(lambda x: x)


# Generated at 2022-06-26 03:02:15.246472
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    var_1 = blueprint_group_0.middleware
    def var_2(request):
        return request
    var_3 = blueprint_group_0.middleware(var_2)


# Generated at 2022-06-26 03:02:27.072726
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Test Variables
    app = sanic.Sanic()
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.blueprints = [Blueprint('blueprint_1'), Blueprint('blueprint_2')]
    blueprint_group_0.url_prefix = 'url_prefix_1'
    blueprint_group_0.version = 'version_1'
    blueprint_group_0.strict_slashes = True
    blueprint_group_0.middleware(hello_world, var_1 = 'var_1')
    blueprint_group_0.append(Blueprint('blueprint_3'))
    blueprint_group_0.append(Blueprint('blueprint_4'))
    blueprint_group_0.insert(0, Blueprint('blueprint_5'))

# Generated at 2022-06-26 03:02:30.487356
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(blueprint_1)
    blueprint_group_0.middleware(middleware_function_0)


# Generated at 2022-06-26 03:02:33.956345
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # default value of argument bp is None
    class Middleware(object):
        def __init__(self):
            pass
    uri_0 = str()
    blueprint_group_0 = BlueprintGroup(uri_0)
    blueprint_group_0.middleware(Middleware())


# Generated at 2022-06-26 03:02:43.727043
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_2 = BlueprintGroup()

    blueprint_group_0.append(blueprint_group_1)
    blueprint_group_0.append(blueprint_group_2)
    blueprint_group_1.append(Sanic('sanic.app.Sanic'))
    blueprint_group_1.append(Sanic('sanic.app.Sanic'))
    blueprint_group_1.middleware(middleware='middleware_1', attach_to='request')
    blueprint_group_1.middleware(middleware='middleware_2', attach_to='request')
    blueprint_group_2.append(Sanic('sanic.app.Sanic'))

# Generated at 2022-06-26 03:02:47.231817
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.__init__()
    var_0 = blueprint_group_0.__iter__()



# Generated at 2022-06-26 03:03:02.807065
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_2 = BlueprintGroup()
    blueprint_group_3 = BlueprintGroup()
    blueprint_group_3 = BlueprintGroup()
    blueprint_group_4 = BlueprintGroup()
    blueprint_group_4 = BlueprintGroup()
    blueprint_group_5 = BlueprintGroup()
    blueprint_group_6 = BlueprintGroup()
    blueprint_group_7 = BlueprintGroup()
    blueprint_group_8 = BlueprintGroup()
    blueprint_group_9 = BlueprintGroup()
    blueprint_group_10 = BlueprintGroup()
    blueprint_group_11 = BlueprintGroup()
    blueprint_group_12 = BlueprintGroup()
    blueprint_group_13 = BlueprintGroup()
    blueprint_group_14 = BlueprintGroup()
    blueprint_group_15 = BlueprintGroup()
   

# Generated at 2022-06-26 03:03:10.434372
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.url_prefix = "/"
    blueprint_group_0.version = 2
    blueprint_group_0.strict_slashes = False
    blueprint_group_0.blueprints = {None}
    blueprint_group_0.__middleware = {}
    var_0 = blueprint_group_0.middleware
    blueprint_group_0.blueprints = {}
    var_1 = blueprint_group_0.middleware

# Generated at 2022-06-26 03:03:12.362621
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware()
    blueprint_group_0.middleware(None)

# Generated at 2022-06-26 03:03:24.627791
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    instance = BlueprintGroup()
    # Positive test
    # without middleware params
    # def middleware(self, *args, **kwargs):
    def test_blueprint_group_middleware_1():
        instance = BlueprintGroup()
        def register_middleware_for_blueprints(fn):
            for blueprint in instance._blueprints:
                app.blueprint.middleware(fn, *args, **kwargs)
        # with middleware params
        # def middleware(self, *args, **kwargs):
        def test_blueprint_group_middleware_2():
            instance = BlueprintGroup()
            def register_middleware_for_blueprints(fn):
                for blueprint in instance._blueprints:
                    app.blueprint.middleware(fn, *args, **kwargs)


# Generated at 2022-06-26 03:03:25.724305
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware('request', fn=None, args=None)


# Generated at 2022-06-26 03:03:30.693508
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Test for method middleware of class BlueprintGroup
    """
    blueprint_group_0 = BlueprintGroup()
    def method_0():

        # Implementation of decorator middleware.
        # Scope of middleware function
        var_0 = BlueprintGroup.middleware(blueprint_group_0)
        return var_0

    method_0()


# Generated at 2022-06-26 03:03:33.978916
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_obj_0 = BlueprintGroup()
    var_0 = blueprint_group_obj_0.middleware("test_string_0", "test_string_1", "test_string_2", test_string_2=test_string_2)


# Generated at 2022-06-26 03:03:36.511720
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(sanic.request)



# Generated at 2022-06-26 03:03:42.933830
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    @blueprint_group_0.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')
    @blueprint_group_0.middleware()
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')


# Generated at 2022-06-26 03:03:46.544894
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0._blueprints = None
    def function_0(fn):
        return fn
    blueprint_group_0.middleware(function_0)


# Generated at 2022-06-26 03:04:08.256642
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    var_0 = blueprint_group_0.append(sanic.Blueprint('bp1'))
    blueprint_group_0.middleware(sanic.middleware.AuthMiddleware())
    blueprint_group_0.middleware(lambda x: x)
    blueprint_group_0.middleware(sanic.middleware.RequestScopeMiddleware())
    blueprint_group_0.middleware(sanic.middleware.AuthMiddleware())
    blueprint_group_0.middleware(lambda x: x)
    blueprint_group_0.middleware(sanic.middleware.RequestScopeMiddleware())
    var_0 = blueprint_group_0.append(sanic.Blueprint('bp1'))
    blueprint_group_0.middleware(sanic.middleware.AuthMiddleware())
   

# Generated at 2022-06-26 03:04:15.273968
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
  bp = Blueprint("test_route_registry_1")
  bp2 = Blueprint("test_route_registry_2")
  bp_group = BlueprintGroup(bp, bp2)

  @bp.middleware("request")
  async def mw1(request):
    pass

  @bp2.middleware("request")
  async def mw2(request):
    pass

  @bp_group.middleware("request")
  async def group_mw(request):
    pass

  assert len(bp.middlewares["request"]) == 1
  assert len(bp2.middlewares["request"]) == 1
  assert len(bp_group.middlewares["request"]) == 1


# Generated at 2022-06-26 03:04:19.781839
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(Blueprint('bp1', url_prefix='/bp1'))
    blueprint_group_0.append(Blueprint('bp2', url_prefix='/bp2'))
    blueprint_group_0.middleware(sanic.middleware.request_handler.bp1_only_middleware)
    blueprint_group_0.middleware(sanic.middleware.request_handler.group_middleware)

# Generated at 2022-06-26 03:04:24.060256
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()

    # 1. Test function argument
    blueprint_group_0.middleware(foo)

    # 2. Test function & argument
    blueprint_group_0.middleware(foo, 123)

    # 3. Test function &  arguments
    blueprint_group_0.middleware(foo, 123, bar=12.3)


Blueprint.group = BlueprintGroup

# Generated at 2022-06-26 03:04:26.686301
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group = BlueprintGroup()
    try:
        blueprint_group.middleware(sanic.request)
    except Exception:
        pass
    else:
        assert False, "Expected exception"

# Generated at 2022-06-26 03:04:29.841657
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    var_0 = blueprint_group_0.middleware(sanic.request)
    var_0 = blueprint_group_0.middleware(sanic.response)


# Generated at 2022-06-26 03:04:39.758496
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_2 = BlueprintGroup()
    blueprint_group_3 = BlueprintGroup()
    blueprint_group_4 = BlueprintGroup()
    blueprint_group_5 = BlueprintGroup()
    blueprint_group_6 = BlueprintGroup()
    blueprint_group_7 = BlueprintGroup()
    blueprint_group_8 = BlueprintGroup()
    blueprint_group_9 = BlueprintGroup()
    blueprint_group_10 = BlueprintGroup()
    blueprint_group_11 = BlueprintGroup()
    blueprint_group_12 = BlueprintGroup()
    blueprint_group_13 = BlueprintGroup()
    blueprint_group_14 = BlueprintGroup()
    blueprint_group_15 = BlueprintGroup()
    blueprint_group_16 = BlueprintGroup()
    blueprint_group_17 = BlueprintGroup()




# Generated at 2022-06-26 03:04:43.170588
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup('/l^6W|Jlu/F,X=', '?p/fT&Jg8#v*!', 0.01)

    def middleware_function_0():
        pass

    blueprint_group_0.middleware(middleware_function_0, '^3q28,2QhF&Kh', 0.01)


# Generated at 2022-06-26 03:04:51.382214
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    # 12: char: space
    # 13: char: \n
    # 16: char: space
    # 17: char: \n
    # 19: char: space
    # 20: char: \n
    # 22: char: space
    # 23: char: \n
    # 45: char: space
    # 46: char: \n
    # 48: char: space
    # 49: char: \n
    # 52: char: space
    # 53: char: \n

    # this is a regular function
    def fn_0():
        var_0 = kwargs
        var_1 = 957
        var_2 = 932
        var_3 = 974
        var_4 = 985
        var_5 = 984

# Generated at 2022-06-26 03:04:52.912653
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_1.append(sanic.Blueprint())
    blueprint_group_1.middleware()


# Generated at 2022-06-26 03:05:29.502750
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    BlueprintGroup = BlueprintGroup()
    BlueprintGroup.append(var_0)


# Generated at 2022-06-26 03:05:32.934473
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_0 = BlueprintGroup()
    var_0 = Blueprint(url_prefix='/bp1', name='bp1')
    blueprint_group_0.__setitem__(0, var_0)


# Generated at 2022-06-26 03:05:42.846723
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Test basic attributes of the BlueprintGroup class
    blueprint_group_1 = BlueprintGroup(strict_slashes=True)
    var_0 = blueprint_group_1.__iter__()
    var_1 = blueprint_group_1.version
    var_2 = blueprint_group_1.url_prefix
    var_3 = blueprint_group_1.strict_slashes

    # Test basic setters of the BlueprintGroup class
    blueprint_group_1.version = 1
    blueprint_group_1.url_prefix = "str"
    blueprint_group_1.strict_slashes = False

    # Test invoke method middleware of class BlueprintGroup
    blueprint_group_1.middleware()


# Generated at 2022-06-26 03:05:53.484024
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
  # Instantiate BlueprintGroup
  BlueprintGroup_obj_1 = BlueprintGroup()
  # get all blueprints
  var_1 = BlueprintGroup_obj_1.blueprints
  assert var_1 == []
  # insert blueprints
  BlueprintGroup_obj_1.insert(0, var_1)
  # get all blueprints
  var_1 = BlueprintGroup_obj_1.blueprints
  assert var_1 == []
  # delete blueprints
  BlueprintGroup_obj_1.__delitem__(0)
  # get all blueprints
  var_1 = BlueprintGroup_obj_1.blueprints
  assert var_1 == []
  # insert blueprints
  BlueprintGroup_obj_1.insert(0, var_1)
  # get all blueprints
  var_1 = BlueprintGroup_obj_1.blueprints


# Generated at 2022-06-26 03:05:55.546638
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint_group_0 = BlueprintGroup(None, None, None)
    var_0 = blueprint_group_0.__iter__()


# Generated at 2022-06-26 03:06:04.608173
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(sanic.Blueprint('', url_prefix=''))
    blueprint_group_0.__getitem__(0)

    blueprint_group_1 = BlueprintGroup()
    blueprint_group_1.append(sanic.Blueprint('', url_prefix=''))
    blueprint_group_1.__getitem__(0)

    blueprint_group_2 = BlueprintGroup()
    blueprint_group_2.append(sanic.Blueprint('', url_prefix=''))
    blueprint_group_2.__getitem__(0)

    blueprint_group_3 = BlueprintGroup()
    blueprint_group_3.append(sanic.Blueprint('', url_prefix=''))
    blueprint_group_3.__getitem__(0)

    blueprint_

# Generated at 2022-06-26 03:06:08.134081
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append("")
    blueprint_group_0.append("")
    blueprint_group_0.__delitem__(0)


# Generated at 2022-06-26 03:06:13.227411
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup('/x', 'v')
    blueprint_0 = Blueprint('test', url_prefix='')
    blueprint_group_0._blueprints.append(blueprint_0)
    blueprint_group_0.middleware(lambda a : a, 'request')


# Generated at 2022-06-26 03:06:15.807351
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_group_0 = BlueprintGroup()
    var_0 = blueprint_group_0.__getitem__("0")


# Generated at 2022-06-26 03:06:24.128781
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    var_0 = blueprint_group_0.__iter__()
    assert not isinstance(var_0, str)
    assert not isinstance(var_0, int)
    assert not isinstance(var_0, float)
    assert not isinstance(var_0, bool)
    assert not isinstance(var_0, list)
    assert not isinstance(var_0, sanic.request.Request)
    assert not isinstance(var_0, sanic.response.HTTPResponse)
    assert not isinstance(var_0, sanic.response.Stream)
    assert not isinstance(var_0, sanic.response.File)
    assert not isinstance(var_0, sanic.response.FileStream)