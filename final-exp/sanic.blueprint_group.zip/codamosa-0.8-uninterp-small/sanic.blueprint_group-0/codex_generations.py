

# Generated at 2022-06-26 02:59:58.385820
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint('blueprint_0', 'blueprint_0')
    blueprint_1 = Blueprint('blueprint_1', 'blueprint_1')
    blueprint_group_0.append(blueprint_1)
    blueprint_group_0.append(blueprint_0)
    # Middleware registration with Blueprint Group
    @blueprint_group_0.middleware
    async def request_middleware(request):
        pass
    # Middleware registration with Blueprint Group
    @blueprint_group_0.middleware('request')
    async def request_middleware(request):
        pass
    # Middleware registration with Blueprint Group
    @blueprint_group_0.middleware('request', 'response')
    async def request_middleware(request, response):
        pass
    # Middleware

# Generated at 2022-06-26 03:00:02.284656
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    def dummy_fn(request):
        pass
    blueprint_group_0.middleware(dummy_fn)

    class DummyApp:

        async def handle_request(self, request, write_callback, stream_callback):
            pass

        def register_blueprint(self, blueprint, *args, **kwargs):
            pass

    blueprint_group_0.register(DummyApp())


# Generated at 2022-06-26 03:00:10.653084
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = BlueprintGroup()

    group.append(bp1)
    group.append(bp2)

    @group.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')
    
    assert(True == True)

# Generated at 2022-06-26 03:00:21.196372
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Create a new Sanic application instance to work with
    sanic_app = sanic.Sanic("blueprint-group.py")

    # Create an instance of BlueprintGroup and a Blueprint
    blueprint_group = BlueprintGroup()

    bp = Blueprint("test")

    # Append a blueprint to the group
    blueprint_group.append(bp)

    # Use the `middleware` method on the group to add a middleware for the
    # blueprint. As the blueprint is already part of the group, the middleware
    # will be applied to it automatically.
    @blueprint_group.middleware("request")
    async def test_middleware(request):
        pass

    # Verify that the middleware add to the group is also listed inside the
    # blueprint involved.
    assert len(bp.middlewares["request"]) == 1


# Generated at 2022-06-26 03:00:26.415479
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp = Blueprint('bp0', url_prefix='/bp0')
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp.middleware(bp1)


# Generated at 2022-06-26 03:00:32.334848
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()

    @blueprint_group_0.middleware('request')
    def middleware_fn_0(request):
        return request

    # Assertion
    assert len(blueprint_group_0.blueprints) == 0


# Generated at 2022-06-26 03:00:37.144899
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(bp1)
    blueprint_group_0.append(bp2)
    blueprint_group_0.append(bp3)
    blueprint_group_0.append(bp3)
    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-26 03:00:45.425704
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    def test_case_0():
        @blueprint_group_0.middleware()
        def test_case_0():
            pass
    def test_case_1():
        @blueprint_group_0.middleware(request=False)
        def test_case_1(fn_arg_0):
            pass
    def test_case_2():
        @blueprint_group_0.middleware(request=True)
        def test_case_2(fn_arg_0):
            pass



# Generated at 2022-06-26 03:00:51.354948
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint('blueprint_0')
    blueprint_1 = Blueprint('blueprint_1')
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.append(blueprint_1)
    blueprint_group_0.middleware(sanic.request)
    assert blueprint_0.middlewares[0] and blueprint_1.middlewares[0]

# Generated at 2022-06-26 03:00:55.944325
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint("blueprint_0", url_prefix="/blueprint_0")
    blueprint_0.middleware(response_handler_0)
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.middleware(response_handler_0)
    blueprint_group_0.middleware(response_handler_2)



# Generated at 2022-06-26 03:01:05.877855
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup(
        strict_slashes=True, version="1234", url_prefix="/blogs"
    )

    blueprint_group_1 = BlueprintGroup(
        strict_slashes=True, version="1234", url_prefix="/blogs"
    )
    blueprint_group_1 = BlueprintGroup(
        strict_slashes=True, version="1234", url_prefix="/blogs"
    )
    blueprint_group_2 = BlueprintGroup(
        strict_slashes=True, version="1234", url_prefix="/blogs"
    )
    blueprint_group_3 = BlueprintGroup(
        strict_slashes=True, version="1234", url_prefix="/blogs"
    )

    blueprint_group_0.blueprints = [blueprint_group_1]

# Generated at 2022-06-26 03:01:07.591089
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware()


# Generated at 2022-06-26 03:01:18.922516
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bg = BlueprintGroup()

    bg.append(bp1)
    bg.append(bp2)
    bg.append(bp3)
    assert len(bg) == 3
    assert bg[0] == bp1
    assert bg[1] == bp2
    assert bg[2] == bp3

    ctr = 0

# Generated at 2022-06-26 03:01:29.439175
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp5')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-26 03:01:33.643949
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    def middleware1():
        pass
    def middleware2():
        pass
    def middleware3():
        pass
    blueprint_group_0.middleware(middleware1,middleware2)
    blueprint_group_0.middleware(middleware3)
    blueprint_group_0.middleware(middleware1,middleware2,middleware3)

# Generated at 2022-06-26 03:01:37.603527
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup('/yMd8SbgGL')
    blueprint_group_0.middleware(lambda *args, **kwargs: None)
    blueprint_group_0.middleware(lambda x, *args, **kwargs: None, 'request')


# Generated at 2022-06-26 03:01:47.609006
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint(url_prefix=None, version=None, strict_slashes=None)
    blueprint_0.middleware = MagicMock()
    blueprint_1 = Blueprint(url_prefix=None, version=None, strict_slashes=None)
    blueprint_1.middleware = MagicMock()
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.append(blueprint_1)

    blueprint_group_0.middleware(1)
    blueprint_0.middleware.assert_called_once_with(1)
    blueprint_1.middleware.assert_called_once_with(1)



# Generated at 2022-06-26 03:01:49.493067
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware()


# Generated at 2022-06-26 03:01:51.608868
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(__name__)


# Generated at 2022-06-26 03:01:59.109002
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(blueprint_group_0)
    blueprint_group_0.middleware(blueprint_group_0, sanic.request)
    blueprint_group_0.middleware(blueprint_group_0, sanic.request, 'middleware')
    blueprint_group_0.middleware(blueprint_group_0, sanic.request, 'middleware', 'response')
    blueprint_group_0.middleware(blueprint_group_0, sanic.request, 'middleware', 'response', 'other')
    blueprint_group_0.middleware(blueprint_group_0, sanic.request, 'middleware', 'response', 'request')

# Generated at 2022-06-26 03:02:13.152489
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()

    @blueprint_group_0.middleware('request')
    async def method_handler_0(request):
        return

    blueprint_group_1 = BlueprintGroup()

    @blueprint_group_1.middleware('request')
    async def method_handler_1(request):
        return

    blueprint_group_2 = BlueprintGroup()

    @blueprint_group_2.middleware('request')
    async def method_handler_2(request):
        return

    blueprint_group_3 = BlueprintGroup()

    @blueprint_group_3.middleware('request')
    async def method_handler_3(request):
        return

    blueprint_group_4 = BlueprintGroup()


# Generated at 2022-06-26 03:02:23.290222
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0._blueprints = [sanic.Blueprint(), ]

    blueprint_group_0.middleware(lambda request: None)
    blueprint_group_0.middleware(lambda request: None, attach_to='request')
    blueprint_group_0.middleware(lambda request: None, attach_to='response')
    blueprint_group_0.middleware(lambda request: None, attach_to='request_and_response')
    blueprint_group_0.middleware(lambda request: None, attach_to=('request', 'response'))
    blueprint_group_0.middleware(lambda request: None, attach_to='request', append=False)


# Generated at 2022-06-26 03:02:26.429594
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.middleware(callable_0)


# Generated at 2022-06-26 03:02:35.403595
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    assert sanic.request.Request
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp2.middleware('request')
    async def bp2_only_middleware(request):
        print('applied on Blueprint : bp2 Only')

    @bpg.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    bp1.name = 'bp1'

# Generated at 2022-06-26 03:02:38.193565
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_2 = BlueprintGroup()
    blueprint_group_3 = BlueprintGroup()

# Generated at 2022-06-26 03:02:40.406269
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_1 = BlueprintGroup()
    def fn_0():pass
    blueprint_group_1.middleware(fn_0)

# Generated at 2022-06-26 03:02:48.028033
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint(name='bp0')
    blueprint_group_0.append(blueprint_0)
    @blueprint_group_0.middleware(str)
    def middleware_fn_0(request):
        pass
    blueprint_group_0.middleware(middleware_fn_0, name='blueprint_group_0')

# Generated at 2022-06-26 03:02:55.514875
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_1 = BlueprintGroup()
    app = sanic.Sanic()
    blueprint_1 = Blueprint('bp1', url_prefix='/bp1')
    blueprint_1_method_route = blueprint_1.route('/')
    blueprint_2 = Blueprint('bp2', url_prefix='/bp2')
    blueprint_2_method_route = blueprint_2.route('/<param>')
    blueprint_3 = Blueprint('bp3', url_prefix='/bp3')
    blueprint_3_method_route = blueprint_3.route('/')
    blueprint_4 = Blueprint('bp4', url_prefix='/bp4')
    blueprint_4_method_route = blueprint_4.route('/<param>')
    app.blueprint(blueprint_3)
    app.blueprint(blueprint_1)


# Generated at 2022-06-26 03:02:57.374849
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group = BlueprintGroup()

    blueprint_group.middleware(lambda request: None)



# Generated at 2022-06-26 03:03:08.887823
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_1 = BlueprintGroup(
        "/test_BlueprintGroup_middleware", "test", True
    )
    blueprint_1 = Blueprint("test name 1")
    blueprint_2 = Blueprint("test name 2")
    blueprint_group_1.append(blueprint_1)
    blueprint_group_1.append(blueprint_2)
    @blueprint_group_1.middleware('request')
    async def test_middleware(request):
        return request.name + '_' + request.version

    request = sanic.request.Request(
        None, None, {'name': 'sanic', 'version': '19.12.2'}
    )
    assert blueprint_group_1.middleware(request) == 'sanic_19.12.2'

# Generated at 2022-06-26 03:03:17.057984
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()

    blueprint_group_0.middleware(lambda request: None)


# Generated at 2022-06-26 03:03:20.639104
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(blueprint_group_0.middleware)

# Generated at 2022-06-26 03:03:29.578426
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_2 = BlueprintGroup()
    blueprint_group_3 = BlueprintGroup()
    blueprint_group_4 = BlueprintGroup()
    blueprint_group_0.middleware(bp=blueprint_group_1)
    blueprint_group_0.middleware(request=blueprint_group_2, response=blueprint_group_3)
    blueprint_group_0.middleware()
    blueprint_group_0.middleware(blueprint_group_4)
    blueprint_group_0.middleware(request=blueprint_group_1, response=blueprint_group_2)


# Generated at 2022-06-26 03:03:31.213383
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware()



# Generated at 2022-06-26 03:03:36.747245
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware()
    blueprint_group_0.middleware()
    blueprint_group_0.middleware()
    blueprint_group_0.middleware()
    blueprint_group_0.middleware()
    blueprint_group_0.middleware()
    blueprint_group_0.middleware()
    blueprint_group_0.middleware()
    blueprint_group_0.middleware()
    blueprint_group_0.middleware()
    blueprint_group_0.middleware()


# Generated at 2022-06-26 03:03:47.950839
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Create a Blueprint object
    blueprint_object_0 = Blueprint(url_prefix='/api', version='1.0.0')

    # Create a Blueprint object
    blueprint_object_1 = Blueprint(url_prefix='/api', version='1.0.0')

    # Create a Blueprint Group object
    blueprint_group_0 = BlueprintGroup(url_prefix='/api', version='1.0.0')

    # add blueprint_object_0 in blueprint_group_0
    blueprint_group_0.append(blueprint_object_0)

    # add blueprint_object_1 in blueprint_group_0
    blueprint_group_0.append(blueprint_object_1)

    # Create app with blueprints
    test_app = sanic.Sanic(configure_logging=False)


# Generated at 2022-06-26 03:03:52.638810
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp = Blueprint('bp', url_prefix='/bp')
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = Blueprint.group(bp1, bp2)
    # Method middleware of BlueprintGroup
    def register_middleware_for_bp(fn):
        bp.middleware(fn)
    def register_middleware_for_bp_group(fn):
        bpg.middleware(fn)
    def register_middleware_for_blueprints(fn):
        for blueprint in bpg.blueprints:
            blueprint.middleware(fn)
    assert(register_middleware_for_blueprints==register_middleware_for_bp_group)

# Generated at 2022-06-26 03:03:56.823038
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    def middleware_func(*args,**kwargs):
        return

    blueprint_group_0 = BlueprintGroup()
    assert blueprint_group_0.middleware(middleware_func) is None
    assert blueprint_group_0.middleware(middleware_func,123) is None
    assert blueprint_group_0.middleware(middleware_func,123,abc='abc') is None


# Generated at 2022-06-26 03:03:59.364866
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group = BlueprintGroup()

    def register_middleware_for_blueprints(fn):
        pass

    blueprint_group.middleware(register_middleware_for_blueprints)



# Generated at 2022-06-26 03:04:10.937369
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    bpg1 = BlueprintGroup(bp5, bp6, url_prefix="/api", version="v1")

    bpg2 = BlueprintGroup(bpg, bpg1, url_prefix="/api", version="v1")


# Generated at 2022-06-26 03:04:23.140612
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.middleware("request", attach_to="response")(bp1_only_middleware)
    bpg.middleware("request")(group_middleware)


# scope="sanic.blueprints.blueprint_group"

# Generated at 2022-06-26 03:04:27.644982
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    """
    Test cases for the Blueprint group class

    :return:
    """
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup(url_prefix="/api", version="v1")
    blueprint_group_2 = BlueprintGroup(strict_slashes=True)
    blueprint_group_3 = BlueprintGroup(url_prefix="/api", strict_slashes=True)

# Generated at 2022-06-26 03:04:28.932342
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_group = BlueprintGroup()
    blueprint_group.append()



# Generated at 2022-06-26 03:04:31.431807
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group_1 = BlueprintGroup()
    blueprint_0 = Blueprint("name_0")
    blueprint_group_1.insert(0, blueprint_0)


# Generated at 2022-06-26 03:04:35.969428
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint(url_prefix="/users/{user_id}", version=1, strict_slashes=True)

    blueprint_group_0.blueprints.append(blueprint_0)
    blueprint_group_0[0]



# Generated at 2022-06-26 03:04:43.138608
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    in_0 = Blueprint('bp1', url_prefix='/bp1')
    in_1 = Blueprint('bp2', url_prefix='/bp2')
    in_2 = BlueprintGroup(url_prefix='/bp0')
    o_0 = in_0
    o_1 = in_1
    o_2 = in_2
    in_2.insert(0, o_0)
    in_2.insert(1, o_1)
    assert len(in_2.blueprints) == 2
    assert in_2.blueprints[0].url_prefix == '/bp1'
    assert in_2.blueprints[1].url_prefix == '/bp2'



# Generated at 2022-06-26 03:04:48.663105
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint_group_1 = BlueprintGroup("/api", "v1")

    assert blueprint_group_1.url_prefix == "/api"
    assert blueprint_group_1.version == "v1"

    blueprint_group_2 = BlueprintGroup("/api")

    assert blueprint_group_2.url_prefix == "/api"
    assert blueprint_group_2.version == None

    blueprint_group_3 = BlueprintGroup()

    assert blueprint_group_3.url_prefix == None
    assert blueprint_group_3.version == None


# Generated at 2022-06-26 03:04:51.125310
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    _actual = iter(blueprint_group_0)
    assert isinstance(_actual, Iterator)
    #assert _actual is blueprint_group_0


# Generated at 2022-06-26 03:04:59.120293
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    for _index in range(0, 1):
        blueprint_group = BlueprintGroup()
        from random import randrange
        from types import GeneratorType
        from typing import List
        from unittest.mock import Mock, patch
        from urllib.parse import urlparse
        import json
        import os
        import pytest
        from sanic import Sanic
        from sanic.router import RouterError
        from sanic.websocket import WebSocketProtocol
        from sanic_compress import Compress
        from sanic_compress import Compress
        from sanic_compress import Compress
        from sanic_compress import Compress
        blueprint_group = BlueprintGroup()
        blueprint_group.append(blueprint=sanic.Blueprint())
        blueprint_group.append(blueprint=sanic.Blueprint())
       

# Generated at 2022-06-26 03:05:07.100958
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_0 = BlueprintGroup()
    assert 0 == len(blueprint_group_0)
    blueprint_group_0 = BlueprintGroup(version=1, strict_slashes=False)
    assert 0 == len(blueprint_group_0)
    blueprint_group_1 = BlueprintGroup(url_prefix='/bp1', version=1, strict_slashes=True)
    assert 0 == len(blueprint_group_1)
    bp_0 = Blueprint('bp1', url_prefix='/bp1')
    bp_1 = Blueprint('bp2', url_prefix='/bp2')
    bp_2 = Blueprint('bp3', url_prefix='/bp4')
    bp_3 = Blueprint('bp4', url_prefix='/bp4')

# Generated at 2022-06-26 03:05:24.741338
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_2 = BlueprintGroup()
    blueprint_group_3 = BlueprintGroup()
    blueprint_group_4 = BlueprintGroup()
    blueprint_group_5 = BlueprintGroup()
    blueprint_group_6 = BlueprintGroup()
    blueprint_group_7 = BlueprintGroup()
    blueprint_group_8 = BlueprintGroup()
    blueprint_group_9 = BlueprintGroup()
    blueprint_group_10 = BlueprintGroup()
    blueprint_group_11 = BlueprintGroup()
    blueprint_group_12 = BlueprintGroup()
    blueprint_group_13 = BlueprintGroup()
    blueprint_group_14 = BlueprintGroup()
    blueprint_group_15 = BlueprintGroup()
    blueprint_group_16 = BlueprintGroup()
    blueprint_group_17 = BlueprintGroup()
    blueprint_group_18 = BlueprintGroup()
   

# Generated at 2022-06-26 03:05:35.456780
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(Blueprint(name = 'name_0'))
    blueprint_group_0.append(Blueprint(name = 'name_1'))
    blueprint_group_0.append(Blueprint(name = 'name_2'))
    blueprint_group_0.append(Blueprint(name = 'name_3'))
    blueprint_group_0.append(Blueprint(name = 'name_4'))
    blueprint_group_0.append(Blueprint(name = 'name_5'))
    blueprint_group_0.append(Blueprint(name = 'name_6'))
    blueprint_group_0.append(Blueprint(name = 'name_7'))
    blueprint_group_0.append(Blueprint(name = 'name_8'))

# Generated at 2022-06-26 03:05:36.413016
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint_group_0 = BlueprintGroup()

# Generated at 2022-06-26 03:05:39.696339
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0._blueprints = list()
    with pytest.raises(TypeError):
        blueprint_group_0.__delitem__()


# Generated at 2022-06-26 03:05:42.533103
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(blueprint_group_0)
    
    

# Generated at 2022-06-26 03:05:45.384851
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    blueprint_group_0 = BlueprintGroup()
    blueprint = Blueprint('test_bp')
    blueprint_group_0.append(blueprint)
    assert blueprint_group_0.blueprints[0] == blueprint



# Generated at 2022-06-26 03:05:47.538656
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_0 = BlueprintGroup() 
    assert isinstance(blueprint_group_0.__len__(), int)


# Generated at 2022-06-26 03:05:53.643899
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_group_0 = BlueprintGroup('/bp', 1.0)
    blueprint_0 = Blueprint('bp0', '/bp1')
    blueprint_group_0.append(blueprint_0)
    blueprint_1 = Blueprint('bp1', '/bp2')
    blueprint_group_0.append(blueprint_1)
    assert blueprint_group_0[1] is blueprint_1


# Generated at 2022-06-26 03:05:57.513891
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_0 = BlueprintGroup("url_prefix_0", "version_0", 10)
    blueprint_0 = Blueprint("blueprint_0")
    blueprint_group_0[0] = blueprint_0



# Generated at 2022-06-26 03:05:59.281484
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    blueprint_group_0 = BlueprintGroup()

    blueprint_group_object_0 = blueprint_group_0.append(blueprint_0)


# Generated at 2022-06-26 03:06:23.440736
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group = BlueprintGroup("/api", "v1", True)
    blueprint = Blueprint("test_blueprint", url_prefix="/test")
    blueprint_group.insert(0, blueprint)
    assert blueprint_group[0].url_prefix == "/api/test"
    assert blueprint_group[0].version == "v1"
    assert blueprint_group[0].strict_slashes


# Generated at 2022-06-26 03:06:33.877133
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_2 = BlueprintGroup()
    blueprint_group_3 = BlueprintGroup()
    blueprint_0 = Blueprint("blueprint_0", url_prefix="1")
    blueprint_1 = Blueprint("blueprint_1", url_prefix="2")
    blueprint_2 = Blueprint("blueprint_2", url_prefix="3")
    blueprint_3 = Blueprint("blueprint_3", url_prefix="4")
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.append(blueprint_1)
    blueprint_group_1.append(blueprint_2)
    blueprint_group_1.append(blueprint_3)
    blueprint_group_2.append(blueprint_group_0)
    blueprint

# Generated at 2022-06-26 03:06:43.142378
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint_group_0 = BlueprintGroup()
    #
    # Test the length of BlueprintGroup is 0
    #
    assert len(blueprint_group_0) == 0, "The length of BlueprintGroup should be 0"

    blueprint_group_1 = BlueprintGroup("/api", "v1")

    blueprint_group_1.append(Blueprint("bp1", url_prefix="/bp1"))
    blueprint_group_1.append(Blueprint("bp2", url_prefix="/bp2"))
    blueprint_group_1.append(Blueprint("bp3", url_prefix="/bp3"))
    blueprint_group_1.append(Blueprint("bp4", url_prefix="/bp4"))

    #
    # Test the length of BlueprintGroup is 4
    #

# Generated at 2022-06-26 03:06:47.749089
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint = Blueprint('bp_1')
    blueprint_group = BlueprintGroup('blueprintGroup_0')
    blueprint_group[0] = blueprint
    assert blueprint_group[0] == blueprint


# Generated at 2022-06-26 03:06:49.366604
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_5 = BlueprintGroup()
    assert len(blueprint_group_5) == 0


# Generated at 2022-06-26 03:06:52.000328
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint_0 = Blueprint("blueprint_0")
    blueprint_1 = Blueprint("blueprint_1")
    blueprint_group_0 = BlueprintGroup(blueprint_0, blueprint_1)



# Generated at 2022-06-26 03:06:53.612266
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_0 = BlueprintGroup()
    assert blueprint_group_0.__len__() == 0


# Generated at 2022-06-26 03:06:57.895303
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_0 = BlueprintGroup()
    assert len(blueprint_group_0) == 0
    blueprint_0 = Blueprint("blueprint_0", url_prefix="blueprint_0")
    blueprint_group_0.append(blueprint_0)
    assert len(blueprint_group_0) == 1
    assert blueprint_group_0[0] == blueprint_0


# Generated at 2022-06-26 03:07:06.876528
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_0 = BlueprintGroup('/api', '1.0', False)
    blueprint_group_0.append(Blueprint('bp1', url_prefix='/bp1'))
    blueprint_group_0.append(Blueprint('bp2', url_prefix='/bp2'))
    blueprint_group_0.__setitem__(0, Blueprint('bp3'))
    blueprint_group_0[1] = Blueprint('bp4')
    blueprint_group_0.insert(0, Blueprint('bp5', url_prefix='/bp5'))
    blueprint_group_0.insert(1, Blueprint('bp6', url_prefix='/bp6'))



# Generated at 2022-06-26 03:07:12.261567
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group_0 = BlueprintGroup()
    blueprint_1 = Blueprint(url_prefix="/bp1")
    blueprint_2 = Blueprint(url_prefix="/bp2")
    blueprint_group_0.insert(0, blueprint_1)
    blueprint_group_0.insert(0, blueprint_2)

    assert blueprint_group_0[0] == blueprint_2
    assert blueprint_group_0[1] == blueprint_1


# Generated at 2022-06-26 03:08:00.395282
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp_a = Blueprint("bp_a",url_prefix="/a")
    bp_b = Blueprint("bp_b",url_prefix="/b")
    bp_c = Blueprint("bp_c",url_prefix="/c")

    group_a = BlueprintGroup("/group_a")
    group_b = BlueprintGroup("/group_b")
    group_c = BlueprintGroup("/group_c")

    group_a.append(bp_a)
    group_b.append(bp_b)
    group_c.append(bp_c)

    group_abc = BlueprintGroup("/abc")
    group_abc.append(group_a)
    group_abc.append(group_b)
    group_abc.append(group_c)

    #test __iter__ in class BlueprintGroup

# Generated at 2022-06-26 03:08:02.582543
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup()

    @blueprint_group_0.middleware('request')
    async def test_0_async_0(request):
        assert request.stream is None



# Generated at 2022-06-26 03:08:07.723809
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(Blueprint('bp1', url_prefix='/bp1'))
    blueprint_group_0.append(Blueprint('bp2', url_prefix='/bp2'))
    blueprint_group_0.__iter__()


# Generated at 2022-06-26 03:08:12.918004
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    """
    Test method __iter__ of class BlueprintGroup
    """
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(Blueprint('bp1', url_prefix='/bp1'))
    blueprint_group_0.append(Blueprint('bp2', url_prefix='/bp2'))

    for it in blueprint_group_0:
        pass


# Generated at 2022-06-26 03:08:14.820722
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_1.insert(0, Blueprint("bp_0"))


# Generated at 2022-06-26 03:08:19.817105
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup(url_prefix='/api', version=1, strict_slashes=False)
    blueprint_group_2 = BlueprintGroup(strict_slashes=False)
    blueprint_group_3 = BlueprintGroup(url_prefix='/api')
    blueprint_group_4 = BlueprintGroup(version=1, strict_slashes=False)



# Generated at 2022-06-26 03:08:29.698116
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    assert len(bpg) == 0
    bpg.insert(1,bp1)
    assert len(bpg) == 1
    assert bpg[0].url_prefix == '/api/bp1'
    bpg.insert(1, bp2)
    assert bpg[1].url_prefix == '/api/bp2'
    bpg.insert(2, bp3)
    assert bpg[2].url_prefix

# Generated at 2022-06-26 03:08:36.921703
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_0 = BlueprintGroup("str_arg_0", "str_arg_1", "str_arg_2")
    blueprint_0 = Blueprint("str_arg_3", "str_arg_4", "str_arg_5")
    blueprint_1 = Blueprint("str_arg_6", "str_arg_7", "str_arg_8")
    blueprint_2 = Blueprint("str_arg_9", "str_arg_10", "str_arg_11")
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.append(blueprint_1)
    blueprint_group_0.append(blueprint_2)
    blueprint_3 = Blueprint("str_arg_12", "str_arg_13", "str_arg_14")
    blueprint_group_0[1] = blueprint

# Generated at 2022-06-26 03:08:46.462029
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_1_rv = blueprint_group_1(__name__)
    blueprint_group_0.append(blueprint_group_1_rv)
    blueprint_group_1_rv.strict_slashes = True
    blueprint_group_1_rv.url_prefix = "/bp1"
    blueprint_group_0[0] = blueprint_group_1_rv
    assert blueprint_group_0[0].strict_slashes is True
    assert blueprint_group_0[0].url_prefix == "/bp1"
    blueprint_group_2 = BlueprintGroup()
    blueprint_group_2_rv = blueprint_group_2(__name__)

# Generated at 2022-06-26 03:08:51.129890
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group_0 = BlueprintGroup()
    b0 = Blueprint("b0",url_prefix="/b")
    b1 = Blueprint("b1")
    blueprint_group_0.insert(0,b0)
    blueprint_group_0.insert(1,b1)
    assert blueprint_group_0[0].name == "b0" and blueprint_group_0[1].name == "b1"