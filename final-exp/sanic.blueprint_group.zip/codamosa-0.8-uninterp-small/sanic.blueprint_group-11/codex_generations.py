

# Generated at 2022-06-26 03:00:02.125922
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.blueprints.append(Blueprint())
    def method_test_BlueprintGroup_middleware_0(instance):
        @instance.middleware('request')
        async def method_test_BlueprintGroup_middleware_0_0(request): pass
        return instance
    blueprint_group_0.blueprints = list(map(
        method_test_BlueprintGroup_middleware_0, blueprint_group_0.blueprints))
    blueprint_group_0.blueprints = list(map(
        method_test_BlueprintGroup_middleware_0, blueprint_group_0.blueprints))
    return blueprint_group_0

# Generated at 2022-06-26 03:00:07.947923
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-26 03:00:19.146655
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """Test BlueprintGroup method middleware.
    """
    blueprint_group_1 = BlueprintGroup()

    @blueprint_group_1.middleware('request')
    def dummy_coroutine_for_blueprint_group_1(request):
        pass

    assert len(blueprint_group_1._blueprints) == 0

    bp_3 = Blueprint('bp3', url_prefix='/bp4')

    blueprint_group_1.append(bp_3)

    assert len(blueprint_group_1._blueprints) == 1

    @blueprint_group_1.middleware('request')
    def dummy_coroutine_for_blueprint_group_1(request):
        pass

    assert len(bp_3.middlewares[sanic.request]) == 1

    blueprint_group_2 = BlueprintGroup()

    blueprint

# Generated at 2022-06-26 03:00:21.112470
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware()


# Generated at 2022-06-26 03:00:26.416088
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    sanic.request.Request
    sanic.response.HTTPResponse
    assert blueprint_group_0.middleware(lambda request: None)



# Generated at 2022-06-26 03:00:34.357506
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    def middleware_callback_0(request_0, *args, **kwargs):
        return text('OK')
    blueprint_group_0.middleware(middleware_callback_0)
    blueprint_group_0.middleware(middleware_callback_0, attach_to='request')
    blueprint_group_0.middleware(middleware_callback_0, attach_to='response')
    # print(blueprint_group_0._blueprints[0])
    assert blueprint_group_0._blueprints[0] != None


# Generated at 2022-06-26 03:00:38.835495
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup(
        url_prefix='/test', version=1, strict_slashes=True
    )
    blueprint_group_0.append(Sanic('sanic.app').blueprint(url_prefix='/test'))
    blueprint_group_0.middleware(1, foo='foo')


# Generated at 2022-06-26 03:00:40.747611
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware(lambda: None)


# Generated at 2022-06-26 03:00:51.818425
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic(__name__)
    bp1 = Blueprint('bp1',url_prefix='/bp1')
    bp2 = Blueprint('bp2',url_prefix='/bp2')
    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        return web.HTTPResponse(body="Hello from bp1")

    @bp2.middleware('request')
    async def bp2_only_middleware(request):
        return web.HTTPResponse(body="Hello from bp2")

    group = Blueprint.group(bp1, bp2)

    @group.middleware('request')
    async def group_middleware(request):
        return web.HTTPResponse(body="Hello from group")

    app.blue

# Generated at 2022-06-26 03:00:53.417807
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()



# Generated at 2022-06-26 03:00:58.374485
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group = BlueprintGroup()

    def middleware(request):
        pass

    blueprint_group.middleware(middleware)


# Generated at 2022-06-26 03:00:59.998972
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_1.middleware


# Generated at 2022-06-26 03:01:03.550876
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    # noinspection PyTypeChecker
    blueprint_group_0.middleware(None)
    # noinspection PyTypeChecker
    blueprint_group_0.middleware(args=None)
    # noinspection PyTypeChecker
    blueprint_group_0.middleware(kwargs=None)


# Generated at 2022-06-26 03:01:13.523071
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)

    # assert that the middleware is called
    @bp1.middleware('request')
    def bp1_only_middleware(request):
        assert request.method == 'GET'

    # assert that the blueprint group middleware is called
    @bpg.middleware('request')
    def group_middleware(request):
        assert request.method == 'GET'

    app = sanic.Sanic("test_BlueprintGroup_middleware")
    app.blueprint(bpg)


# Generated at 2022-06-26 03:01:24.876929
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()

    @blueprint_group_0.middleware('request')
    async def blueprint_group_0_request_fn(request):
        return request

    blueprint_group_0.blueprints = [Blueprint('blueprint', url_prefix='/a/b/c')]
    blueprint_group_0.blueprints = blueprint_group_0.blueprints[0]
    blueprint_group_0.blueprints = blueprint_group_0.blueprints.middlewares
    blueprint_group_0.blueprints = blueprint_group_0.blueprints['request']
    blueprint_group_0.blueprints = blueprint_group_0.blueprints[0]
    assert(blueprint_group_0.blueprints.__name__ == 'blueprint_group_0_request_fn')

# Unit test

# Generated at 2022-06-26 03:01:33.454917
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")


    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-26 03:01:41.757382
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint('blueprint_0', url_prefix='blueprint_0_url_prefix')
    blueprint_1 = Blueprint('blueprint_1', url_prefix='blueprint_1_url_prefix')
    blueprint_group_1 = BlueprintGroup(url_prefix='blueprint_group_1_url_prefix')
    blueprint_group_1.append(blueprint_0)
    blueprint_group_1.append(blueprint_1)
    blueprint_group_0.append(blueprint_group_1)
    blueprint_group_0.middleware(None)


# Generated at 2022-06-26 03:01:44.929400
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware()
    blueprint_group_0.middleware(1)
    blueprint_group_0.middleware(1, 2)


# Generated at 2022-06-26 03:01:52.037420
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    import pytest
    import sanic

    @blueprint.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    class blueprint:
        pass

    blueprint.blueprints = []
    blueprint.blueprints.append(blueprint)
    blueprint.blueprints.append(blueprint)

    blueprint.version = 1


    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.middleware('')
    blueprint_group_0._sanitize_blueprint(blueprint)



# Generated at 2022-06-26 03:01:54.216561
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_1.middleware(lambda x: x)


# Generated at 2022-06-26 03:02:03.842479
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    '''
    Test case to validate the functionality of __setitem__ method
    '''
    # __setitem__ is a abstract method of class BlueprintGroup
    # so we have to create a new object to test this method
    blueprintGroup_obj = BlueprintGroup()
    blueprint_obj = Blueprint('bp')
    blueprintGroup_obj[0] = blueprint_obj
    assert blueprint_obj.name == blueprintGroup_obj[0].name


# Generated at 2022-06-26 03:02:07.098803
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group = BlueprintGroup()
    item = Blueprint("bp1")
    index = 0
    blueprint_group.insert(index, item)


# Generated at 2022-06-26 03:02:09.500921
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint("blueprint_0", url_prefix="url_prefix_0")
    blueprint_group_0.insert(0, blueprint_0)

# Generated at 2022-06-26 03:02:18.646066
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
     blueprint_group_0 = BlueprintGroup()
     def mock_func0(request):
        return text('bp1')
     @blueprint_group_0.middleware('request')
     def mock_func1(request):
        return text('bp1')


# Generated at 2022-06-26 03:02:30.074116
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0.append(Blueprint())
    blueprint_group_0

# Generated at 2022-06-26 03:02:31.728700
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_0 = BlueprintGroup()
    assert len(blueprint_group_0) == 0


# Generated at 2022-06-26 03:02:34.217197
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(None)
    blueprint_group_0.append(None)

    assert 2 == len(blueprint_group_0)


# Generated at 2022-06-26 03:02:37.687269
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    blueprint_group_1 = BlueprintGroup()
    blueprint_1 = Blueprint("blueprint-1")
    blueprint_group_1.append(blueprint_1)
    assert blueprint_group_1[0] is blueprint_1


# Generated at 2022-06-26 03:02:42.032292
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_1.append(sanic.Blueprint("bp1"))
    blueprint_group_1.append(sanic.Blueprint("bp2"))
    blueprint_group_1.append(sanic.Blueprint("bp3"))

    assert len(blueprint_group_1) == 3


# Generated at 2022-06-26 03:02:43.782259
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_0 = BlueprintGroup()
    del blueprint_group_0[0]


# Generated at 2022-06-26 03:02:54.658977
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_group_0 = BlueprintGroup(url_prefix=None, version=None, strict_slashes=None)
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.append(blueprint_1)
    blueprint_group_0.append(blueprint_2)
    blueprint_group_0.append(blueprint_3)
    blueprint_group_0.append(blueprint_4)
    blueprint_group_0.append(blueprint_5)
    blueprint_group_0.append(blueprint_6)
    blueprint_group_0.append(blueprint_7)
    blueprint_group_0.append(blueprint_8)
    blueprint_group_0.append(blueprint_9)
    blueprint_group_0.append(blueprint_10)
    blueprint_group_0

# Generated at 2022-06-26 03:02:59.896349
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('nestedgroup', url_prefix='bp1')
    bp2 = Blueprint('nestedgroup', url_prefix='bp2')
    blueprint_group_0 = BlueprintGroup()

    blueprint_group_0.insert(0, bp1)
    blueprint_group_0.insert(0, bp2)


# Generated at 2022-06-26 03:03:03.074545
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.extend([Blueprint('bp1'), Blueprint('bp2')])
    # Testing
    blueprint_group_0.__delitem__(int)


# Generated at 2022-06-26 03:03:14.007453
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint("blueprint_0")
    blueprint_group_0.append(blueprint_0)
    assert blueprint_group_0._url_prefix == None
    blueprint_group_0._url_prefix = "/blueprint_group_0"
    blueprint_group_0._version = 1
    blueprint_group_0._strict_slashes = False
    blueprint_1 = Blueprint("blueprint_1", url_prefix="/blueprint_1")
    blueprint_1._strict_slashes = False
    blueprint_group_0.append(blueprint_1)
    assert blueprint_group_0._blueprints[0].url_prefix == "/blueprint_group_0/blueprint_0"

# Generated at 2022-06-26 03:03:26.531598
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint_group_0 = BlueprintGroup()

    blueprint_group_1 = BlueprintGroup("/api", "v1", True)
    blueprint_group_2 = BlueprintGroup("/api", "v1", False)
    blueprint_group_3 = BlueprintGroup("/api", "v1", None)
    blueprint_group_4 = BlueprintGroup("/api", None, True)
    blueprint_group_5 = BlueprintGroup("/api", None, False)
    blueprint_group_6 = BlueprintGroup("/api", None, None)
    blueprint_group_7 = BlueprintGroup(None, "v1", True)
    blueprint_group_8 = BlueprintGroup(None, "v1", False)
    blueprint_group_9 = BlueprintGroup(None, "v1", None)
    blueprint_group_10 = BlueprintGroup(None, None, True)


# Generated at 2022-06-26 03:03:29.332451
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_obj = BlueprintGroup()
    blueprint_group_obj[:]
    blueprint_group_obj.__delitem__()
    pass


# Generated at 2022-06-26 03:03:33.902816
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_0 = BlueprintGroup(None)
    blueprint_0 = Blueprint("blueprint_0", "blueprint_0", url_prefix="{}".format("blueprint_0"))
    blueprint_group_0.append(blueprint_0)
    blueprint_1 = Blueprint("blueprint_1", "blueprint_1", url_prefix="{}".format("blueprint_1"))
    blueprint_group_0.append(blueprint_1)
    blueprint_2 = Blueprint("blueprint_2", "blueprint_2", url_prefix="{}".format("blueprint_2"))
    blueprint_group_0.append(blueprint_2)
    del blueprint_group_0[1]
    assert len(blueprint_group_0) == 2


# Generated at 2022-06-26 03:03:37.509641
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_0 = BlueprintGroup(url_prefix=None, version=None, strict_slashes=None)
    # __len__ of class BlueprintGroup
    int_0 = len(blueprint_group_0)


# Generated at 2022-06-26 03:03:47.311839
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_1 = BlueprintGroup()
    blueprint_1 = Blueprint('bp1', url_prefix = '/bp1')
    blueprint_2 = Blueprint('bp2', url_prefix = '/bp2')

    blueprint_group_1.append(blueprint_1)
    blueprint_group_1.append(blueprint_2)
    blueprint_3 = Blueprint('bp3', url_prefix = '/bp3')
    blueprint_4 = Blueprint('bp4', url_prefix = '/bp4')
    blueprint_group_1.__setitem__(1, blueprint_3)
    blueprint_group_1.__setitem__(2, blueprint_4)


# Generated at 2022-06-26 03:03:56.486660
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup(url_prefix=None, version=None, strict_slashes=None)
    blueprint_group_2 = BlueprintGroup(url_prefix='/api', version=None, strict_slashes=None)
    blueprint_group_3 = BlueprintGroup(url_prefix='/api', version='v1', strict_slashes=None)
    blueprint_group_4 = BlueprintGroup(url_prefix='/api', version='v2', strict_slashes=None)
    blueprint_group_5 = BlueprintGroup(url_prefix='/api', version='v3', strict_slashes=None)
    blueprint_group_6 = BlueprintGroup(url_prefix='/api', version=None, strict_slashes='/')

# Generated at 2022-06-26 03:04:02.916912
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group = BlueprintGroup()
    for _ in blueprint_group:
        pass


# Generated at 2022-06-26 03:04:05.002745
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_0 = BlueprintGroup()
    t = Blueprint("", "", "")
    blueprint_group_0._blueprints = [t]
    blueprint_group_0.__setitem__(0, t)


# Generated at 2022-06-26 03:04:09.841862
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group = BlueprintGroup()
    assert blueprint_group.__len__() == 0
    assert len(blueprint_group) == 0
    blueprint_group.append("test string")
    assert blueprint_group.__len__() == 1
    assert len(blueprint_group) == 1


# Generated at 2022-06-26 03:04:16.365914
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_1 = BlueprintGroup()
    blueprint_1 = Blueprint("test_blueprint_0")
    blueprint_group_1.append(blueprint_1)
    del blueprint_group_1[0]

    blueprint_group_2 = BlueprintGroup()
    blueprint_2 = Blueprint("test_blueprint_1")
    blueprint_group_2.append(blueprint_2)
    del blueprint_group_2[0]

    blueprint_group_3 = BlueprintGroup()
    blueprint_3 = Blueprint("test_blueprint_2")
    blueprint_group_3.append(blueprint_3)
    del blueprint_group_3[0]

    blueprint_group_4 = BlueprintGroup()
    blueprint_4 = Blueprint("test_blueprint_3")
    blueprint_group_4.append(blueprint_4)

# Generated at 2022-06-26 03:04:26.490600
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(Blueprint(url_prefix="/api/v2/user"))
    blueprint_group_0.append(Blueprint(url_prefix="/api/v2/user"))
    blueprint_group_0.append(Blueprint(url_prefix="/api/v2/user"))
    blueprint_group_0.append(Blueprint(url_prefix="/api/v2/user"))
    blueprint_group_0.append(Blueprint(url_prefix="/api/v2/user"))
    blueprint_group_0.append(Blueprint(url_prefix="/api/v2/user"))
# BlueprintGroup.__len__
    blueprint_group_0.__len__()


# Generated at 2022-06-26 03:04:27.719402
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint_group_0 = BlueprintGroup()


# Generated at 2022-06-26 03:04:29.538894
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_0 = BlueprintGroup()
    assert len(blueprint_group_0) == 0



# Generated at 2022-06-26 03:04:32.364641
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    # Case 1
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.insert(1, 1)  # Passing args 1, 1
    assert len(blueprint_group_0) == 2

    # Case 2
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.insert(1, 1)  # Passing args 1, 1
    assert len(blueprint_group_0) == 2


# Generated at 2022-06-26 03:04:41.841229
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup()
    blueprint_group_2 = BlueprintGroup()

    blueprint_0 = Blueprint('bp0', url_prefix='/bp0')
    blueprint_1 = Blueprint('bp1', url_prefix='/bp1')
    blueprint_2 = Blueprint('bp2', url_prefix='/bp2')

    blueprint_group_0._blueprints = [blueprint_0, blueprint_1, blueprint_2]
    blueprint_group_1._blueprints = [blueprint_1]
    blueprint_group_2._blueprints = []

    assert [blueprint_0, blueprint_1, blueprint_2] == list(blueprint_group_0)
    assert [blueprint_1] == list(blueprint_group_1)

# Generated at 2022-06-26 03:04:44.097718
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append('blueprint_group_0')
