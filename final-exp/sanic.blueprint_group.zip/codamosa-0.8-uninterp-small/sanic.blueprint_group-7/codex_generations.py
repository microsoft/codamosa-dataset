

# Generated at 2022-06-26 03:00:02.185993
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_0 = BlueprintGroup()
    assert blueprint_group_0.__len__() == 0


# Generated at 2022-06-26 03:00:08.384441
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_group_1 = BlueprintGroup()
    blueprint_1 = Blueprint()
    blueprint_2 = Blueprint()
    blueprint_group_1.append(blueprint_1)
    blueprint_group_1.append(blueprint_2)
    blueprint_group_1.__getitem__(0)
    blueprint_group_1.__getitem__(1)


# Generated at 2022-06-26 03:00:16.418129
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup()
    assert blueprint_group_0 is not None
    assert blueprint_group_1 is not None

    assert blueprint_group_0 is not blueprint_group_1
    # Checking for default properties of the class object
    assert blueprint_group_0.url_prefix == None
    assert blueprint_group_0.blueprints == []
    assert blueprint_group_0.version == None
    assert blueprint_group_0.strict_slashes == None



# Generated at 2022-06-26 03:00:26.263273
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    blueprint_group_0 = BlueprintGroup()

    blueprint_0 = Blueprint(name='blueprint_0')
    blueprint_0.rate_limit = 'blueprint_0.rate_limit'

    blueprint_1 = Blueprint(name='blueprint_1')
    blueprint_1.rate_limit = 'blueprint_1.rate_limit'


    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.append(blueprint_1)

    blueprint_2 = Blueprint(name='blueprint_2')
    blueprint_2.rate_limit = 'blueprint_2.rate_limit'

    blueprint_group_0.append(blueprint_2)
    assert len(blueprint_group_0) == 3
    assert blueprint_group_0.blueprints[2].name == 'blueprint_2'



# Generated at 2022-06-26 03:00:31.483355
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    var_0 = blueprint_group_0.__iter__()
    assert var_0 is not None


# Generated at 2022-06-26 03:00:33.937391
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group_0 = BlueprintGroup()
    var_0 = blueprint_group_0.middleware("a", "b", "c", "d", "e")

# Generated at 2022-06-26 03:00:36.477809
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.insert(0, blueprint_0)


# Generated at 2022-06-26 03:00:37.861761
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # var.middleware(args, kwargs)
    pass

# Generated at 2022-06-26 03:00:40.379940
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(None)
    blueprint_group_0.__delitem__(0)



# Generated at 2022-06-26 03:00:44.648476
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint()
    blueprint_group_0.append(blueprint_0)
    blueprint_1 = Blueprint()
    blueprint_group_0.append(blueprint_1)


# Generated at 2022-06-26 03:00:55.577563
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-26 03:00:59.434011
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    blueprint_group_0 = BlueprintGroup()
    try:
        blueprint_group_0.append(0)
    except:
        var_0 = True
    else:
        var_0 = False
    assert var_0


# Generated at 2022-06-26 03:01:04.143218
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    # This is a test for a constructor of class BlueprintGroup
    # Instantiate the class
    blueprint_group = BlueprintGroup()

    # Test for the attributes of class BlueprintGroup
    assert isinstance(blueprint_group._blueprints, list)
    assert blueprint_group._blueprints == []
    assert blueprint_group._url_prefix is None
    assert blueprint_group._version is None
    assert blueprint_group._strict_slashes is None


# Generated at 2022-06-26 03:01:04.967020
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    pass


# Generated at 2022-06-26 03:01:08.410134
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group_0 = BlueprintGroup()
    blueprint_1 = Blueprint.register("bp_group_1")
    blueprint_group_0.insert(0, blueprint_1)
    assert blueprint_group_0._blueprints[0] == blueprint_1


# Generated at 2022-06-26 03:01:15.684134
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup(
        url_prefix='/api/v1', strict_slashes=True
    )
    blueprint_group_0.append(sanic.Blueprint('blueprint_1'))
    blueprint_group_0.append(sanic.Blueprint('blueprint_2'))
    blueprint_group_0.append(sanic.Blueprint('blueprint_3'))
    var_0 = blueprint_group_0.__iter__()


# Generated at 2022-06-26 03:01:26.591730
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint_group_0 = BlueprintGroup(None, None, None)
    blueprint_group_1 = BlueprintGroup(None, None, None)

    blueprint_group_2 = BlueprintGroup(None, None, None)
    blueprint_group_2 = BlueprintGroup(None, None, None)
    blueprint_group_3 = BlueprintGroup(None, None, None)

    class sanic_endpoint_0:
        def __init__(self, functions=None, host=None, include_in_schema=True, prefix=None, version=None, strict_slashes=None, tags=None, operation_id=None):
            pass


# Generated at 2022-06-26 03:01:28.755816
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint_group_0 = BlueprintGroup()
    assert isinstance(blueprint_group_0, BlueprintGroup)


# Generated at 2022-06-26 03:01:34.083129
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():

    blueprint_group_0 = BlueprintGroup(url_prefix='/api', version='v1', strict_slashes=False)
    blueprint_group_1 = BlueprintGroup(url_prefix='/api', version='v1', strict_slashes=False)

    blueprint_0 = Blueprint(url_prefix='/generate')
    blueprint_group_0.append(blueprint_0)

    blueprint_1 = Blueprint(url_prefix='/json')
    blueprint_group_0.append(blueprint_1)

    blueprint_group_1.append(blueprint_group_0)



# Generated at 2022-06-26 03:01:36.839944
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_0 = BlueprintGroup()
    assert type(blueprint_group_0) is BlueprintGroup, "invalid test"
    blueprint_group_0.__delitem__(0)
