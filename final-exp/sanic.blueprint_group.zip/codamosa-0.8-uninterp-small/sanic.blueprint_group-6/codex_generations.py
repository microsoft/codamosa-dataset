

# Generated at 2022-06-26 03:00:03.569358
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint('blueprint_0', url_prefix='/blueprint_0')
    blueprint_1 = Blueprint('blueprint_1', url_prefix='/blueprint_1')
    blueprint_1.url_prefix = '/blueprint_0/blueprint_1'
    blueprint_group_0.append(blueprint_0)
    blueprint_group_0.append(blueprint_1)


# Generated at 2022-06-26 03:00:06.493524
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    try:
        blueprint_group_0 = BlueprintGroup()
        blueprint_group_0.__delitem__(0)
    except:
        pass


# Generated at 2022-06-26 03:00:08.335389
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    blueprint_group_0 = BlueprintGroup()


# Generated at 2022-06-26 03:00:10.997069
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    test_result = iter(blueprint_group_0)


# Generated at 2022-06-26 03:00:15.252174
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint(url_prefix=None, strict_slashes=None)
    blueprint_group_0.append(blueprint_0)
    blueprint_1 = blueprint_group_0[0]



# Generated at 2022-06-26 03:00:20.509129
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_1 = BlueprintGroup(None, None, False)
    index_0 = 0
    try:
        del blueprint_group_1[index_0]
    except Exception as e:
        print(e)


# Generated at 2022-06-26 03:00:26.045690
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint('test', url_prefix='/test')
    blueprint_group_0.insert(0, blueprint_0)

# Generated at 2022-06-26 03:00:27.159249
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    blueprint_group_0 = BlueprintGroup()


# Generated at 2022-06-26 03:00:32.280565
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0.append(Blueprint('bp3', url_prefix='/bp3'))
    blueprint_group_0.append(Blueprint('bp4', url_prefix='/bp4'))
    blueprint_group_0.append(Blueprint('bp5', url_prefix='/bp5'))
    
    assert blueprint_group_0[0].name == 'bp3'
    assert blueprint_group_0[1].name == 'bp4'
    assert blueprint_group_0[2].name == 'bp5'


# Generated at 2022-06-26 03:00:42.697589
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Verify that this BlueprintGroup is intialized with no blueprints registered
    blueprint_group_0 = BlueprintGroup()
    assert len(blueprint_group_0) == 0

    # Verify that this BlueprintGroup is intialized with no middleware registered
    assert blueprint_group_0.middleware == BlueprintGroup.middleware

    # Verify that the correct url_prefix is set on the BlueprintGroup
    assert blueprint_group_0.url_prefix is None

    # Verify that the correct version is set on the BlueprintGroup
    assert blueprint_group_0.version is None

    # Verify that the correct strict_slashes is set on the BlueprintGroup
    assert blueprint_group_0.strict_slashes is None

    # Verify that the correct blueprints is set on the BlueprintGroup
    assert blueprint_group_0.blueprints is not None

    # Verify that the

# Generated at 2022-06-26 03:00:47.042112
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_0 = BlueprintGroup()
    try:
        blueprint_group_0.__delitem__(0)
    except:
        pass



# Generated at 2022-06-26 03:00:53.882187
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    blueprint_group_1 = BlueprintGroup()
    blueprint_1 = Blueprint('bp1', url_prefix='/bp1')

    blueprint_group_1.append(blueprint_1)
    blueprint_group_2 = BlueprintGroup()
    blueprint_2 = Blueprint('bp2', url_prefix='/bp2')

    blueprint_group_2.append(blueprint_2)
    blueprint_group_1.append(blueprint_group_2)

    assert blueprint_group_1.blueprints == [blueprint_1, blueprint_group_2]


# Generated at 2022-06-26 03:01:02.136792
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_1 = BlueprintGroup('/group1', 'v1', False)

    # Case 0:
    blueprint_group_2 = BlueprintGroup('/group2', 'v1', True)
    assert len(blueprint_group_2) == 0

    # Case 1:
    blueprint_1 = Blueprint('bp1', url_prefix='/bp1')
    blueprint_2 = Blueprint('bp2', url_prefix='/bp2')
    blueprint_group_1.append(blueprint_1)
    blueprint_group_1.append(blueprint_2)
    assert len(blueprint_group_1) == 2


# Generated at 2022-06-26 03:01:05.691042
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0._blueprints = [sanic.Blueprint(url_prefix=None, version=None, strict_slashes=None)]
    assert blueprint_group_0.__len__() == len(blueprint_group_0._blueprints)


# Generated at 2022-06-26 03:01:16.629196
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    # 0
    blueprint_group_0 = BlueprintGroup()
    assert len(blueprint_group_0) == 0

    # 1
    blueprint_0 = Blueprint('bp_0')
    blueprint_1 = Blueprint('bp_0')
    blueprint_group_1 = BlueprintGroup(blueprint_0, blueprint_1)
    assert len(blueprint_group_1) == 2
    assert blueprint_group_1[0] == blueprint_0
    assert blueprint_group_1[1] == blueprint_1

    # 2
    blueprint_group_1[0] = blueprint_1
    blueprint_group_1[1] = blueprint_0
    assert blueprint_group_1[0] == blueprint_1
    assert blueprint_group_1[1] == blueprint_0
    del blueprint_group_1[0]

# Generated at 2022-06-26 03:01:20.013074
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    blueprint_group_1 = BlueprintGroup()
    blueprint_1 = Blueprint('bp1', url_prefix='/bp1')
    blueprint_group_1.append(blueprint_1)


# Generated at 2022-06-26 03:01:29.662401
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_0._blueprints.append(Blueprint("BLUEPRINT_0"))
    blueprint_group_0._blueprints.append(Blueprint("BLUEPRINT_1"))
    blueprint_group_0._blueprints.append(Blueprint("BLUEPRINT_2"))
    blueprint_group_iterator_0 = blueprint_group_0.__iter__()
    assert blueprint_group_iterator_0.__next__() == Blueprint("BLUEPRINT_0")
    assert blueprint_group_iterator_0.__next__() == Blueprint("BLUEPRINT_1")
    assert blueprint_group_iterator_0.__next__() == Blueprint("BLUEPRINT_2")


# Generated at 2022-06-26 03:01:33.746620
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    blueprint_group_0 = BlueprintGroup()

    blueprint_0 = Blueprint('blueprint_0', url_prefix='/blueprint0')

    blueprint_group_0.append(blueprint_0)

    blueprint_1 = Blueprint('blueprint_1', url_prefix='/blueprint1')

    blueprint_group_0.append(blueprint_1)



# Generated at 2022-06-26 03:01:37.217088
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    assert bp1.url_prefix == '/bp1'
    assert bp2.url_prefix == '/bp2'

# Generated at 2022-06-26 03:01:44.372338
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_1 = BlueprintGroup()
    blueprint_2 = Blueprint(None, None, None, None)
    blueprint_group_1.append(blueprint_2)

    blueprint_1 = Blueprint(None, None, None, None)
    blueprint_group_1.append(blueprint_1)

    assert blueprint_group_1[1] == blueprint_1
    blueprint_group_1.__delitem__(0)
    assert blueprint_group_1[0] == blueprint_1



# Generated at 2022-06-26 03:01:57.507661
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_1 = BlueprintGroup()

    blueprint_0 = Blueprint(name='blueprint_0', url_prefix='/blueprint_0')
    blueprint_group_1.append(blueprint_0)

    blueprint_1 = Blueprint(name='blueprint_1', url_prefix='/blueprint_1')
    blueprint_group_1.append(blueprint_1)

    blueprint_group_1.__delitem__(index=0)

    assert len(blueprint_group_1.blueprints) == 1

    assert blueprint_group_1.blueprints[0] == blueprint_1



# Generated at 2022-06-26 03:02:02.097086
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_group_1 = BlueprintGroup(
        url_prefix=None, version=None, strict_slashes=None
    )
    blueprint_group_2 = BlueprintGroup(
        url_prefix=None, version=None, strict_slashes=None
    )
    blueprint_group_2.append(blueprint_group_1)
    blueprint_group_2.append(blueprint_group_1)
    blueprint_group_3 = Blueprint.group(blueprint_group_1, blueprint_group_2)
    blueprint_group_0 = Blueprint.group(blueprint_group_2, blueprint_group_2)
    del blueprint_group_1[0]
    try:
        blueprint_group_1[0]
    except IndexError:
        pass
    blueprint_group_3

# Generated at 2022-06-26 03:02:08.403907
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    blueprint_group_0 = BlueprintGroup('/5F5h1Q', version=8.7168, strict_slashes=True)
    blueprint_group_0.append(Blueprint('L4', url_prefix='/G'))
    blueprint_group_0.append(Blueprint('D', url_prefix='/s'))
    blueprint_group_0.__delitem__(1)


# Generated at 2022-06-26 03:02:15.784700
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint(name=str(), url_prefix=str(), strict_slashes=bool())
    blueprint_group_0.append(blueprint_0)
    blueprint_1 = Blueprint(name=str(), url_prefix=str(), strict_slashes=bool())
    blueprint_group_0[0] = blueprint_1
    assert not blueprint_group_0[0].name



# Generated at 2022-06-26 03:02:17.053994
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    with pytest.raises(TypeError):
        test_case_0().middleware()



# Generated at 2022-06-26 03:02:22.263424
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint_group_0 = BlueprintGroup()
    blueprint_0 = Blueprint(name='', url_prefix='/')
    blueprint_group_0.insert(0, blueprint_0)
    blueprint_0.url_prefix
    blueprint_group_0.url_prefix
    blueprint_group_0._sanitize_blueprint(blueprint_0)
    blueprint_group_0.blueprints
    blueprint_group_0.version
    blueprint_group_0.strict_slashes
    blueprint_group_0.__getitem__(0)
    blueprint_group_0.__setitem__(0, blueprint_0)
    blueprint_group_0.__delitem__(0)
    blueprint_group_0.__len__()
    blueprint_group_0.append(blueprint_0)

# Generated at 2022-06-26 03:02:26.325008
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    import types
    blueprint_group_0 = BlueprintGroup()
    temp_var_0 = blueprint_group_0.__iter__()
    assert isinstance(temp_var_0, types.GeneratorType)


# Generated at 2022-06-26 03:02:32.082900
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():  # real signature unknown; restored from __doc__
    """
    Abstract method implemented to turn the `BlueprintGroup` class
    into a list like object to support all the existing behavior.

    This method is used to perform the list's indexed setter operation.

    :param index: Index to use for inserting a new Blueprint item
    :param item: New `Blueprint` object.
    :return: None
    """
    pass


# Generated at 2022-06-26 03:02:35.055208
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group = BlueprintGroup()
    blueprint_group._blueprints = [sanic.Blueprint('blueprint_0', url_prefix=None), sanic.Blueprint('blueprint_1', url_prefix=None)]
    assert list(iter(blueprint_group)) == blueprint_group._blueprints


# Generated at 2022-06-26 03:02:37.101780
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    blueprint_group_0 = BlueprintGroup()
    print(blueprint_group_0.__iter__())
