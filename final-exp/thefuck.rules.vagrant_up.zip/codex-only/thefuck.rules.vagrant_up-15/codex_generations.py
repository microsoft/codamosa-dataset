

# Generated at 2022-06-24 07:28:44.072404
# Unit test for function get_new_command
def test_get_new_command():
    command = type('commands', (object,), {'script': 'vagrant up', 'script_parts': ['vagrant', 'up', '--provision']})
    assert get_new_command(command) == ['vagrant up --provision', 'vagrant up && vagrant up --provision']

# Generated at 2022-06-24 07:28:46.617295
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('vagrant rsync', 'The configured shell (powershell.exe) is not executable. Please verify this is a valid shell.')) == ["vagrant up && vagrant rsync", "vagrant up && vagrant rsync"]

# Generated at 2022-06-24 07:28:47.313960
# Unit test for function match
def test_match():
    command = Command('vagrant up')
    assert match(command)


# Generated at 2022-06-24 07:28:52.471439
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('vagrant ssh default',
                                   'The VM is not running. To run the '
                                   'VM, run `vagrant up`')) == 'vagrant up && vagrant ssh default'
    assert get_new_command(Command('vagrant ssh',
                                   'The VM is not running. To run the '
                                   'VM, run `vagrant up`')) == 'vagrant up && vagrant ssh'
    assert get_new_command(Command('vagrant ssh local',
                                   'The VM is not running. To run the '
                                   'VM, run `vagrant up`')) == ['vagrant up local && vagrant ssh local',
                                                                 'vagrant up && vagrant ssh local']


# Generated at 2022-06-24 07:29:02.222914
# Unit test for function match
def test_match():
    err_msg1 = u"""
The GSSAPI connection request was rejected by the SSH server. The
authentication that failed was:

    GSSAPI with credential "vagrant@VAGRANT-VM"

The error from the SSH server was:

    gssapi-keyex,gssapi-with-mic,publickey,keyboard-interactive,password
"""


# Generated at 2022-06-24 07:29:08.946275
# Unit test for function match
def test_match():
    assert match(Command('vagrant status', 'The VM is running. To stop this VM, you can run `vagrant halt` to\nshut it down forcefully, or you can run `vagrant suspend` to simply\nsuspend the virtual machine. In either case, to restart it again,\nyou can run `vagrant up`.\n\nThe following SSH command responded with a non-zero exit status.\nVagrant assumes that this means the command failed!\n\nnmap -p22 -oN /dev/stdout -sV localhost || true\n\nStdout from the command:\n\n\n\n\nStderr from the command:\n\n', '', '', '')) == True

# Generated at 2022-06-24 07:29:18.665336
# Unit test for function match
def test_match():
    c = Command('vagrant ssh', 'The name `server` is not in the list of configured machines. Run `vagrant up` to create it. Is the name misspelled?')
    assert(match(c) == True)

    c = Command('vagrant ssh', 'The name `server` is not in the list of configured machines. Run `vagrant up` to create it. Is the name misspelled?')
    assert(match(c) == True)

    c = Command('vagrant ssh', 'The name `server` is not in the list of configured machines.')
    assert(match(c) == False)


# Generated at 2022-06-24 07:29:20.391821
# Unit test for function match
def test_match():
    command = Command('vagrant ssh master', 'The VM must be running to open SSH connection.')
    assert match(command)


# Generated at 2022-06-24 07:29:23.558144
# Unit test for function match
def test_match():
    assert match(Command('vagrant ssh', 'The forwarded port to 0.0.0.0:2222 is not available on the remote machine. You will want to run `vagrant up` so that Vagrant can forward the ports.\n')).script == 'vagrant ssh'


# Generated at 2022-06-24 07:29:32.176710
# Unit test for function match
def test_match():
    cmd_not_vagrant = Command('ssh localhost', '')
    assert not match(cmd_not_vagrant)

    cmd_vagrant_up_machine = Command(u"vagrant up machine0",
                                     u"The machine 'machine0' is already running.")
    assert not match(cmd_vagrant_up_machine)

    cmd_vagrant_ssh_machine = Command(u"vagrant ssh machine0",
                                      u"The machine 'machine0' is not running.")
    assert match(cmd_vagrant_ssh_machine)

    cmd_vagrant_ssh = Command(u"vagrant ssh",
                              u"The machine 'default' is not running.")
    assert match(cmd_vagrant_ssh)



# Generated at 2022-06-24 07:29:40.472453
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("vagrant ssh-config", "The SSH command responded with a non-zero exit status. Vagrant \
assumes that this means the command failed. The output for this command should be in the log above. Please read \
the output to determine what went wrong.")
    new_command = get_new_command(command)
    assert new_command == [shell.and_(u"vagrant up", command.script), shell.and_(u"vagrant up", command.script)]
    command = Command("vagrant ssh-config my_machine", "The SSH command responded with a non-zero exit status. Vagrant \
assumes that this means the command failed. The output for this command should be in the log above. Please read \
the output to determine what went wrong.")
    new_command = get_new_command(command)

# Generated at 2022-06-24 07:29:48.888531
# Unit test for function match
def test_match():
    assert match(Command("vagrant ssh", "The environment has not yet been created. Run `vagrant up` to create the environment. If a machine is not created, only the default provider will be shown. So if you're using a non-default provider, make sure to create a machine with `vagrant up`"))
    assert match(Command("vagrant ssh", "Vagrant instance has not been created yet, use `vagrant up`"))
    assert not match(Command("vagrant ssh", "Vagrant instance has been created, use `vagrant up`"))
    assert not match(Command("vagrant ssh", "vagrant up"))


# Generated at 2022-06-24 07:29:51.965860
# Unit test for function match
def test_match():
    assert match(Command('vagrant global-status', '', 'The running environment has not been booted.\n'))
    assert not match(Command('vagrant global-status', '', 'vagrant global-status'))


# Generated at 2022-06-24 07:29:59.410713
# Unit test for function match
def test_match():
  test_command = "vagrant provision app && vagrant ssh app -c " \
                 "'sudo /usr/bin/chef-client' (default) The Berkshelf " \
                 "shelf is not at the expected path. Please run `berks " \
                 "vendor /vagrant/berks-cookbooks` to sync the " \
                 "Berkshelf dependencies. (default) You need to forward " \
                 "ports. Please run `vagrant up` again."

  def func(command): return match(command)
  if func(Cmd(test_command)) == True:
      print("test_match: Ok")
  else:
      print("test_match: Failed")


# Generated at 2022-06-24 07:30:03.576243
# Unit test for function match
def test_match():
    cmd = Command('vagrant reload', 'VM not created. Run `vagrant up` first.')
    assert match(cmd)

    cmd2 = Command('vagrant reload', 'No machine specified and more than one machine is present.')
    assert not match(cmd2)


# Generated at 2022-06-24 07:30:07.363882
# Unit test for function match
def test_match():
    assert match(Command('vagrant ssh', "", "Machine doesn't exist yet. Run `vagrant up` first."))
    assert not match(Command('vagrant ssh', "", "Machine doesn't exist yet. Run vagrant up first."))


# Generated at 2022-06-24 07:30:14.601813
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.vagrant_up import get_new_command
    assert get_new_command(Command('vagrant ssh', '', '', 0, 1)) == shell.and_('vagrant up', 'vagrant ssh')
    assert get_new_command(Command('vagrant ssh', '', '', 0, 2)) == [
        shell.and_('vagrant up default', 'vagrant ssh'),
        shell.and_('vagrant up', 'vagrant ssh')
    ]
    assert get_new_command(Command('vagrant ssh', '', '', 0, 3)) == [
        shell.and_('vagrant up default', 'vagrant ssh'),
        shell.and_('vagrant up', 'vagrant ssh')
    ]

# Generated at 2022-06-24 07:30:23.896135
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('ls', '/not/a/vagrant:project/')
    cmds = get_new_command(command)
    assert cmds == 'vagrant up && ls'
    command = Command('ls', '/not/a/vagrant:project/ default')
    cmds = get_new_command(command)
    assert cmds == 'vagrant up default && ls'
    command = Command('ls', '/not/a/vagrant:project/ default1')
    cmds = get_new_command(command)
    assert cmds == 'vagrant up default1 && ls'
    command = Command('ls', '/not/a/vagrant:project/ default1 default2')
    cmds = get_new_command(command)
    assert cmds == 'vagrant up default1 && ls'

# Generated at 2022-06-24 07:30:30.905165
# Unit test for function match
def test_match():
    command = Command(script='ls /tmp', output='A Vagrant environment or target machine is required to run this command. Run `vagrant init` to create a new Vagrant environment. Or, get an ID of a target machine from `vagrant global-status` to run this command on. A final option is to change to a directory with a Vagrantfile and to try again.')
    result = match(command)
    assert result == True



# Generated at 2022-06-24 07:30:34.791360
# Unit test for function match
def test_match():
    assert match(Command('vagrant ssh', 'Machine is not running. To start this machine, run `vagrant up`'))
    assert not match(Command('vagrant up', 'Machine is not running. To start this machine, run `vagrant up`'))
    assert not match(Command('vagrant up', 'Machine is up'))


# Generated at 2022-06-24 07:30:42.773097
# Unit test for function get_new_command
def test_get_new_command():
    actual_command = Command("vagrant ssh", "", "The environment has not been created", 1)
    new_command = get_new_command(actual_command)
    assert new_command == [
        "vagrant up && vagrant ssh",
        "vagrant up && vagrant ssh"
    ]

    actual_command = Command("vagrant ssh default", "", "The environment has not been created", 1)
    new_command = get_new_command(actual_command)
    assert new_command == [
        "vagrant up default && vagrant ssh default",
        "vagrant up && vagrant ssh default"
    ]

# Generated at 2022-06-24 07:30:51.029096
# Unit test for function match

# Generated at 2022-06-24 07:30:52.094995
# Unit test for function match
def test_match():
    assert match(Command('vagrant up', ''))
    assert not match(Command('ls', ''))


# Generated at 2022-06-24 07:30:56.693781
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("vagrant reload db --provision", "", 0)) == \
           shell.and_(u"vagrant up db", "vagrant reload db --provision")
    assert get_new_command(Command("vagrant reload --provision", "", 0)) == \
           [shell.and_(u"vagrant up", "vagrant reload --provision"),
            shell.and_(u"vagrant up db", "vagrant reload --provision")]

# Generated at 2022-06-24 07:31:03.316204
# Unit test for function match

# Generated at 2022-06-24 07:31:05.340794
# Unit test for function match

# Generated at 2022-06-24 07:31:09.821278
# Unit test for function get_new_command
def test_get_new_command():
    assert ('vagrant up' == get_new_command(Command('vagrant ssh', '')).script)
    assert ('vagrant up default' == get_new_command(Command('vagrant ssh default', '')).script)
    assert (['vagrant up default', 'vagrant up'] == get_new_command(Command('vagrant ssh default', '')).script_parts)


# Generated at 2022-06-24 07:31:11.675359
# Unit test for function match
def test_match():
    command = Command('vagrant ssh', 'There are no instance of this box')
    assert match(command)


# Generated at 2022-06-24 07:31:18.515773
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('vagrant ssh', '')) == ['vagrant up']
    assert get_new_command(Command('vagrant ssh web', '')) == [
        'vagrant up web', 'vagrant up']
    assert get_new_command(Command('vagrant ssh webserver1', '')) == [
        'vagrant up webserver1', 'vagrant up']
    assert get_new_command(Command('vagrant ssh webserver2', '')) == [
        'vagrant up webserver2', 'vagrant up']

# Generated at 2022-06-24 07:31:21.764359
# Unit test for function match
def test_match():
    assert match(Command('vagrant status',
                         "The VM is not created. Run `vagrant up` to create the VM. If a VM already exists, run `vagrant resume` to re-establish SSH connection."))
    assert not match(Command('vagrant up', ""))


# Generated at 2022-06-24 07:31:27.426394
# Unit test for function get_new_command
def test_get_new_command():
    # create Command object with script 'vagrant up opengrok'
    command = Command('vagrant up opengrok')
    command.script_parts = ['vagrant', 'up', 'opengrok']
    cmd = u"vagrant up opengrok"

    # assert get_new_command(command) equal to [cmd, cmd]
    assert [cmd, cmd] == get_new_command(command)

# Generated at 2022-06-24 07:31:29.353816
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("./test.sh b")
    assert get_new_command(command) == shell.and_(u"vagrant up b", command.script)


# Generated at 2022-06-24 07:31:32.892584
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(u'vagrant ssh', u'theck is not running. To fix this error, run `vagrant up`')
    assert_equal(get_new_command(command), u'vagrant up && vagrant ssh')

    command = Command(u'vagrant ssh web', u'theck is not running. To fix this error, run `vagrant up`')
    asser

# Generated at 2022-06-24 07:31:41.923526
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('', 'run `vagrant up` to start this vm', '')) == u"vagrant up && vagrant up"
    assert get_new_command(Command('', 'run `vagrant up` to start this vm', 'vagrant ssh')) == [u"vagrant up && vagrant ssh", "vagrant up && vagrant up && vagrant ssh"]
    assert get_new_command(Command('', 'run `vagrant up` to start this vm', 'vagrant ssh test1')) == [u"vagrant up test1 && vagrant ssh test1", "vagrant up && vagrant up && vagrant ssh test1"]

# Generated at 2022-06-24 07:31:46.224674
# Unit test for function match
def test_match():
    assert match(Command('vagrant snapshot push',
        "There are no active machines to push to. Run `vagrant up` to create"
        " and start a machine, then try again."))

    assert not match(Command('vagrant snapshot push',
        "The machine specified doesn't exist."))

# Generated at 2022-06-24 07:31:52.528945
# Unit test for function match
def test_match():
    assert match(Command('vagrant ssh master', '', 'There are errors'))
    assert match(Command('vagrant ssh master', '', 'The machine'))
    assert match(Command('vagrant up', '', 'The machine'))
    assert match(Command('vagrant up', '', 'There are errors'))
    assert not match(Command('other random command', '', 'The machine'))



# Generated at 2022-06-24 07:31:55.603806
# Unit test for function match
def test_match():
    assert match(Command('vagrant ssh', '', 'A Vagrant environment or target machine is required to run this')).output == 'A Vagrant environment or target machine is required to run this'
    assert not match(Command('git branch', '', '* develop'))

# Generated at 2022-06-24 07:31:57.914250
# Unit test for function match
def test_match():
    assert match(Command(script='vagrant ssh',
                         output='The boxed \'precise64\' doesn\'t seem to be running'))


# Generated at 2022-06-24 07:32:02.025377
# Unit test for function match
def test_match():
    cmd = Command(script='vagrant ssh',
                  output='The environment has not yet been created. Run `vagrant up` to '
                         'create the environment.')
    assert match(cmd)
    assert not match(Command(script='ls',
                             output='The environment has not yet been created. Run `vagrant up` to '
                                    'create the environment.'))


# Generated at 2022-06-24 07:32:04.495790
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('vagrant ssh', '')) == 'vagrant up && vagrant ssh'
    assert get_new_command(Command('vagrant ssh machine', '')) == ['vagrant up machine && vagrant ssh machine', 'vagrant up && vagrant ssh machine']

# Generated at 2022-06-24 07:32:10.148227
# Unit test for function match
def test_match():
    assert match(Command("vagrant ssh",
                         "The guest machine entered an invalid state while "
                         "waiting for it to boot. Valid states are 'starting, "
                         "running'. The machine is in the 'stopped' state. "
                         "Please verify everything is configured properly and "
                         "try again.",
                         "run vagrant ssh"))

    assert not match(Command("vagrant ssh", ""))



# Generated at 2022-06-24 07:32:15.167095
# Unit test for function match
def test_match():
    assert match(Command('vagrant ssh', 'NOTICE [default] The forwarded port to 22 on 0.0.0.0 is already in use on the host machine.'))
    assert match(Command('vagrant status', 'The VM is not running because a state was not found.'))
    assert match(Command('vagrant ssh', 'ERROR: No machine name(s) specified.'))
    assert match(Command('vagrant ssh', '')) == False
    return True


# Generated at 2022-06-24 07:32:17.939563
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('vagrant up') == 'vagrant up'
    assert get_new_command('vagrant provision') == 'vagrant up; vagrant provision'
    assert get_new_command('vagrant provision foo') == 'vagrant up foo; vagrant provision foo'

# Generated at 2022-06-24 07:32:24.998465
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("vagrant snapshot push", "")) == ["vagrant up && vagrant snapshot push"]
    assert get_new_command(Command("vagrant ssh", "")) == ["vagrant up && vagrant ssh"]
    assert get_new_command(Command("vagrant up example", "")) == ["vagrant up example && vagrant up example", "vagrant up && vagrant up example"]
    assert get_new_command(Command("vagrant ssh example", "")) == ["vagrant up example && vagrant ssh example", "vagrant up && vagrant ssh example"]
    assert get_new_command(Command("vagrant test", "")) == ["vagrant up && vagrant test"]

# Generated at 2022-06-24 07:32:33.519223
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    command = Command(script='vagrant ssh\n',
                      output=u'The VM must be running to open SSH connection.\n'
                             u'Run `vagrant up` to start the virtual machine.\n')
    assert get_new_command(command) == "vagrant up"

    command = Command(script='vagrant ssh web\n',
                      output=u'The VM must be running to open SSH connection.\n'
                             u'Run `vagrant up` to start the virtual machine.\n')
    assert get_new_command(command) == ["vagrant up web", "vagrant up"]

# Generated at 2022-06-24 07:32:38.767585
# Unit test for function get_new_command
def test_get_new_command():
    new_cmd = get_new_command(Command('vagrant ssh first_machine'))
    assert new_cmd == [shell.and_(u"vagrant up first_machine", "vagrant ssh first_machine"),
                       shell.and_(u"vagrant up", "vagrant ssh first_machine")]

    new_cmd = get_new_command(Command('vagrant ssh'))
    assert new_cmd == shell.and_(u"vagrant up", "vagrant ssh")

# Generated at 2022-06-24 07:32:43.594668
# Unit test for function match
def test_match():
    assert match(Command('vagrant status',
                         'The environment has not yet been created. Run `vagrant up` to create the environment. If a '
                         'machine is not created, only the default provider will be shown. So if you\'re using a '
                         'protein, explicitly specify the provider with `vagrant up --provider=PROVIDER`. ')) is True
    assert match(Command('vagrant status',
                         'Current machine states: web running (virtualbox) db not created (virtualbox)')) is False

# Generated at 2022-06-24 07:32:53.566324
# Unit test for function match

# Generated at 2022-06-24 07:32:57.502144
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('vagrant ssh', '', 'Vagrant machine \'default\' not created', '', 1)) == ['vagrant up && vagrant ssh', 'vagrant up default && vagrant ssh']
    assert get_new_command(Command('vagrant ssh default', '', 'Vagrant machine \'default\' not created', '', 1)) == ['vagrant up default && vagrant ssh default', 'vagrant up && vagrant ssh default']

# Generated at 2022-06-24 07:33:02.327202
# Unit test for function match
def test_match():
    assert match(Command('vagrant up',
                        '\"default\" has already been created.',
                        'Aborting.'))
    assert match(Command('vagrant up',
                        'No default providers are available for this box'))

    assert not match(Command('vagrant up', 'Already up-to-date'))
    assert not match(Command('vagrant up', 'No name'))

# Generated at 2022-06-24 07:33:04.201333
# Unit test for function get_new_command
def test_get_new_command():
    assert 'vagrant up' in get_new_command(Command('vagrant ssh', ''))[0]

# Generated at 2022-06-24 07:33:10.952004
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(u"vagrant ssh", u"", u"There are no instances running. To run a new instance, run `vagrant up`")
    new_command = get_new_command(command)
    assert new_command == u"vagrant up && vagrant ssh"

    command = Command(u"vagrant up", u"", u"There are no instances running. To run a new instance, run `vagrant up`")
    new_command = get_new_command(command)
    assert new_command == u"vagrant up"

    command = Command(u"vagrant ssh mymachine", u"", u"There are no instances running. To run a new instance, run `vagrant up`")
    new_command = get_new_command(command)

# Generated at 2022-06-24 07:33:17.006505
# Unit test for function match
def test_match():
    assert match(Command('vagrant up',
                         'No environment macthed, please run `vagrant up`'))

    assert match(Command('vagrant ssh',
                         'No environment macthed, please run `vagrant up`'))

    assert not match(Command('vagrant up',
                             'Starting machine...'))

    assert not match(Command('vagrant ssh',
                             'Starting machine...'))


# Generated at 2022-06-24 07:33:20.423499
# Unit test for function match
def test_match():
    assert match(Command('vagrant init',
            "The environment has not yet been created. Run 'vagrant up' to "
            "create the environment. If a machine is not created, only the "
            "default provider will be shown. So if you're using a "
            "non-default provider, make sure to create the machine "
            "so that information can be shown.\n"))



# Generated at 2022-06-24 07:33:27.950428
# Unit test for function get_new_command
def test_get_new_command():
    command_without_machine = Command('echo "Please run `vagrant up` to "',
                                      'Please run `vagrant up` to ')
    assert get_new_command(command_without_machine) == shell.and_('vagrant up',
                                                                  'echo "Please run `vagrant up` to "')

    command_with_machine = Command('echo "Please run `vagrant up` to "',
                                      'Please run `vagrant up` to ')
    assert get_new_command(command_with_machine) == shell.and_('vagrant up {}'.format('machine'),
                                                               'echo "Please run `vagrant up` to "')


enabled_by_default = True
priority = 1000

# Generated at 2022-06-24 07:33:31.321208
# Unit test for function match
def test_match():
    assert match(Command('vagrant destroy', output='Run `vagrant up` to start this virtual machine.'))
    assert match(Command('vagrant ansible', output='Run `vagrant up` to start this virtual machine.'))
    assert not match(Command('vagrant init', output='A Vagrantfile has been placed in this directory'))

# Generated at 2022-06-24 07:33:41.826235
# Unit test for function get_new_command
def test_get_new_command():
    test_command = Command('vagrant halt', '', '==> default: Attempting graceful shutdown of VM...\nMachine default is not running. Run `vagrant up` to start it.')
    assert get_new_command(test_command) == "vagrant up && vagrant halt"

    test_command = Command('vagrant ssh', '', 'The machine with the name default is not currently running. Run `vagrant up` to start the machine.')
    assert get_new_command(test_command) == "vagrant up && vagrant ssh"

    test_command = Command('vagrant ssh machine', '', 'The machine with the name machine is not currently running. Run `vagrant up` to start the machine.')

# Generated at 2022-06-24 07:33:47.489228
# Unit test for function get_new_command
def test_get_new_command():
    command.Script('vagrant ssh', '',
                   'The virtual machine is not created. Please run `vagrant up` to create it.').assert_matches(match)
    command.Script('vagrant ssh foo', '',
                   'The virtual machine is not created. Please run `vagrant up` to create it.').assert_matches(match)
    (get_new_command(command.Script('vagrant ssh', '',
                   'The virtual machine is not created. Please run `vagrant up` to create it.')) ==
     shell.and_('vagrant up', 'vagrant ssh'))

# Generated at 2022-06-24 07:33:55.850304
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("vagrant ssh", "The machine with the name 'default' was not found configured for this Vagrant environment. Run `vagrant up` to create the machine. If a machine is not created, only the default provider will be shown. So if you're seeing this message, either the machine is not created or Vagrant couldn't detect it.\n")) == "vagrant up && vagrant ssh"

# Generated at 2022-06-24 07:34:00.435586
# Unit test for function match
def test_match():
    assert match(Command('vagrant provision', 'The virtual machine with the name `default`\n'
                                              'wasn\'t created. To create the virtual machine,\n'
                                              'run `vagrant up`'))
    assert not match(Command('vagrant provision', 'Something else'))



# Generated at 2022-06-24 07:34:07.284368
# Unit test for function match
def test_match():
    assert match(Command("vagrant ssh somebox",
    """
    The guest machine entered an invalid state while waiting for it
    to boot. Valid states are 'starting, running'. The machine is in the
    'poweroff' state. Please verify everything is configured
    properly and try again.

    If the provider you're using has a GUI that comes with it,
    it is often helpful to open that and watch the machine, since the
    GUI often has more helpful error messages than Vagrant can retrieve.
    For example, if you're using VirtualBox, run `vagrant up` while the
    VirtualBox GUI is open.

    The primary issue for this error is that the provider you're using
    is not properly configured. This is very rarely a Vagrant issue.
    """))



# Generated at 2022-06-24 07:34:08.907171
# Unit test for function match
def test_match():
    assert match(Command('vagrant ssh'))
    assert not match(Command('foo'))


# Generated at 2022-06-24 07:34:10.568775
# Unit test for function match
def test_match():
    command = Command('vagrant ssh', 'VM not created. Run `vagrant up`')
    assert match(command)


# Generated at 2022-06-24 07:34:13.475309
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("vagrant status") == "vagrant up && vagrant status"
    assert get_new_command("vagrant status m1") == ["vagrant up m1 && vagrant status", "vagrant up && vagrant status"]


# Generated at 2022-06-24 07:34:15.651533
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command('vagrant provision') == 'vagrant up')
    assert(get_new_command('vagrant ssh') == 'vagrant up && vagrant ssh')

# Generated at 2022-06-24 07:34:21.407041
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("vagrant reload", "There are errors in the configuration of this machine. Please fix\n"
                      "the following errors and try again:\n"
                      "\n"
                      "VM must be created before running this command.",
                      "vagrant reload")
    assert get_new_command(command) == "vagrant up && vagrant reload"

    command = Command("vagrant ssh", "The SSH command responded with a non-zero exit status. Vagrant\n"
                      "assumes that this means the command failed. The output for this command\n"
                      "should be in the log above. Please read the output to determine what\n"
                      "went wrong.", "vagrant ssh")
    assert get_new_command(command) == [u'vagrant up default && vagrant ssh', 'vagrant up && vagrant ssh']

# Generated at 2022-06-24 07:34:30.218053
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('vagrant up', '', '\n==> vagrant: Could not find a suitable provider for ""\n'
                                                 'Run `vagrant up --provider=PROVIDER` to see a list of available\n'
                                                 'providers for this action.\n'
                                                 '\n'
                                                 'The provider "vbox" could not be found, but was requested to\n'
                                                 'back the machine "abcd". Please use a provider that exists and is\n'
                                                 'supported by your Vagrant installation.\n')) == \
           'vagrant up && vagrant up'


# Generated at 2022-06-24 07:34:35.272762
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    cmd = Command('vagrant up', 'The VM is currently stopped. '
                  'To restart the VM, run `vagrant up`')
    assert get_new_command(cmd) == ['vagrant up', 'vagrant up && vagrant up']
    cmd = Command('vagrant ssh vm1', 'The VM is currently stopped. '
                  'To restart the VM, run `vagrant up`')
    assert get_new_command(cmd) == ['vagrant up vm1 && vagrant ssh vm1',
                                    'vagrant up && vagrant ssh vm1']

# Generated at 2022-06-24 07:34:41.176954
# Unit test for function match

# Generated at 2022-06-24 07:34:43.895959
# Unit test for function match
def test_match():
    assert match(Command('vagrant up', 'The environment has not yet been created. Run `vagrant up` to create the environment.'))
    assert not match(Command('vagrant up', 'No machine matching "cassandra" was found. This command will attempt to start any'))


# Generated at 2022-06-24 07:34:45.645443
# Unit test for function get_new_command

# Generated at 2022-06-24 07:34:50.434576
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("vagrant status", "", "The environment has not yet been created. Run vagrant up")) == u'vagrant up && vagrant status'
    assert get_new_command(Command("vagrant status vm1", "", "The environment has not yet been created. Run vagrant up")) == [u'vagrant up vm1 && vagrant status', u'vagrant up && vagrant status']


# Generated at 2022-06-24 07:34:57.287880
# Unit test for function get_new_command
def test_get_new_command():
    # Unit test for function get_new_command
    commands = ["vagrant status", "vagrant status master", "vagrant status slave"]
    commands_out = [u"vagrant up && vagrant status",
                    u"vagrant up master && vagrant status master",
                    u"vagrant up slave && vagrant status slave"]
    for i in range(0, len(commands)):
        assert get_new_command(Command(commands[i],
                                       commands_out[i]))[0].script == commands_out[i]
        assert get_new_command(Command(commands[i],
                                       commands_out[i]))[1].script == commands[i]

# Generated at 2022-06-24 07:35:05.748176
# Unit test for function get_new_command
def test_get_new_command():
    # no machine name
    command = Command('vagrant halt', '', 'stdout', 'stderr')
    assert get_new_command(command)[0] == 'vagrant up && vagrant halt'

    # one machine name
    command = Command('vagrant halt machine1', '', 'stdout', 'stderr')
    assert get_new_command(command)[0] == 'vagrant up machine1 && vagrant halt machine1'

    # two machine names
    command = Command('vagrant halt machine1 machine2', '', 'stdout', 'stderr')
    assert get_new_command(command)[0] == 'vagrant up machine1 machine2 && vagrant halt machine1 machine2'

# Generated at 2022-06-24 07:35:14.551613
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    # 1. try to start all instances
    command = Command(script='vagrant ssh',
                      stderr='The SSH command responded with a non-zero exit status. Vagrant assumes that this means the command failed.\n'
                            "The output for this command should be in the log above. Please read the output to determine what went wrong.\n"
                            "run `vagrant up` to start your instances.",
                      env={'LANG': 'C'})
    assert get_new_command(command) == 'vagrant up && vagrant ssh'

    # 2. try to start specific instances

# Generated at 2022-06-24 07:35:22.552542
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('vagrant ssh vagrant','','The machine with the name \'grant\' was not found configured for this Vagrant environment.','')
    assert [u'vagrant up vagrant ; vagrant ssh vagrant', u'vagrant up ; vagrant ssh vagrant'] == get_new_command(command)
    command = Command('vagrant ssh vagrant','','A Vagrant environment or target machine is required to run this command. Run `vagrant init` to create a new Vagrant environment. Or, get an ID of a target machine from `vagrant global-status` to run this command on. A final option is to change to a directory with a Vagrantfile and to try again.','')
    assert u'vagrant up vagrant ; vagrant ssh' == get_new_command(command)[0]
    assert u'vagrant up ; vagrant ssh' == get

# Generated at 2022-06-24 07:35:29.291022
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('vagrant ssh', 'The specified command requires running Vagrant. Run `vagrant up`.')
    assert get_new_command(command) == "vagrant up && vagrant ssh"

    command = Command('vagrant ssh server', 'The specified command requires running Vagrant. Run `vagrant up`.')
    assert get_new_command(command) == ["vagrant up server && vagrant ssh server", "vagrant up && vagrant ssh"]

# Generated at 2022-06-24 07:35:34.215004
# Unit test for function get_new_command
def test_get_new_command():
    # Vagrant machine name
    assert get_new_command(Command('vagrant ssh')) == 'vagrant up && vagrant ssh'
    assert get_new_command(Command('vagrant ssh xxxx')) == ['vagrant up xxxx && vagrant ssh xxxx', 'vagrant up && vagrant ssh xxxx']

    # Case insensitive
    assert get_new_command(Command('vagrant SSh')) == 'vagrant up && vagrant SSh'

# Generated at 2022-06-24 07:35:38.107934
# Unit test for function get_new_command
def test_get_new_command():
    command = CliCommand(script = "cd project && vagrant ssh --provision web1")
    assert get_new_command(command) == [shell.and_(u"vagrant up web1", "cd project && vagrant ssh --provision web1"),
                                        shell.and_(u"vagrant up", "cd project && vagrant ssh --provision web1")]


enabled_by_default = True

# Generated at 2022-06-24 07:35:43.117921
# Unit test for function match
def test_match():
    assert match(Command('hello world', '', 'The VM failed to boot'))
    assert not match(Command('hello world', '', 'the VM failed to boot'))
    assert match(Command('vagrant up', '', 'The VM failed to boot'))
    assert match(Command('vagrant up wibble', '', 'The VM failed to boot'))
    assert not match(Command('vagrant halt', '', 'The VM failed to boot'))


# Generated at 2022-06-24 07:35:52.995964
# Unit test for function get_new_command
def test_get_new_command():
    cmd_script = "vagrant ssh-config --host dev2"
    output = 'A Vagrant environment or target machine is required to run this'
    output = output + '     command. Run `vagrant init` to create a new'
    output = output + '     environment. Or, get an ID of a target machine'
    output = output + '     from `vagrant global-status` to run this command'
    output = output + '     on. A final option is to change to a directory'
    output = output + '     with a Vagrantfile and to try again.'
    command = Command(cmd_script, output)
    assert get_new_command(command) == shell.and_('vagrant up', cmd_script)

    cmd_script = "vagrant ssh-config --host dev2"

# Generated at 2022-06-24 07:35:58.346844
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    command = Command(
        script='vagrant ssh hello -- vagrant provision',
        stderr='Machine hello is required to run this command. Please run `vagrant up` to start the machine.')

    assert get_new_command(command) == [u"vagrant up hello && vagrant ssh hello -- vagrant provision", u"vagrant up && vagrant ssh hello -- vagrant provision"]

# Generated at 2022-06-24 07:36:01.484704
# Unit test for function get_new_command
def test_get_new_command():
    assert [u'vagrant up', u'vagrant ssh'] == get_new_command(Command(u'vagrant sssh', ''))
    assert [u'vagrant up foo', u'vagrant up'] == get_new_command(Command(u'vagrant ssh foo', ''))

# Generated at 2022-06-24 07:36:07.477376
# Unit test for function get_new_command
def test_get_new_command():
    from mock import Mock
    command = Mock(script_parts=['add', 'foo', 'bar'], script="")
    assert 'vagrant up foo' in get_new_command(command)[0]
    assert 'vagrant up' in get_new_command(command)[1]

    command = Mock(script_parts=['add', 'foo', 'bar'], script="run")
    assert 'vagrant up foo run' in get_new_command(command)[0]
    assert 'vagrant up run' in get_new_command(command)[1]

    command = Mock(script_parts=['add', 'foo'], script="run")
    assert get_new_command(command)[0] == 'vagrant up run'

    command = Mock(script_parts=['add'], script="run")
    assert get_new_command

# Generated at 2022-06-24 07:36:12.664540
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('vagrant ssh', ''))[0] == 'vagrant up && vagrant ssh'
    assert get_new_command(Command('vagrant ssh machine', ''))[0] == 'vagrant up machine && vagrant ssh machine'
    assert get_new_command(Command('vagrant ssh machine', ''))[1] == 'vagrant up && vagrant ssh machine'

# Generated at 2022-06-24 07:36:19.688821
# Unit test for function get_new_command
def test_get_new_command():
    assert "vagrant up" in get_new_command(Command('vagrant foo'))[0]
    assert "vagrant foo" in get_new_command(Command('vagrant foo'))[0]
    assert "vagrant foo" in get_new_command(Command('vagrant foo'))[1]
    assert "vagrant up" in get_new_command(Command('vagrant foo'))[1]
    assert "vagrant up bar" in get_new_command(Command('vagrant foo bar'))[0]
    assert "vagrant foo bar" in get_new_command(Command('vagrant foo bar'))[0]
    assert "vagrant foo bar" in get_new_command(Command('vagrant foo bar'))[1]

# Generated at 2022-06-24 07:36:29.732276
# Unit test for function match
def test_match():
    assert match(Command(script="vagrant ssh",
        output="default: The guest machine entered an invalid state while waiting for it "
               "to boot. Valid states are 'starting, running'. The machine is in the 'unknown' "
               "state. Please verify everything is configured properly and try again. "
               "If the provider you're using has a GUI that comes with it, it is often helpful "
               "to open that and watch the machine, since the GUI often has more helpful error "
               "messages than Vagrant can retrieve. For example, if you're using VirtualBox, "
               "run `vagrant up` while the VirtualBox GUI is open. The primary issue for this "
               "error is that the provider you're using is not properly configured. This is "
               "very rarely a Vagrant issue."))

# Generated at 2022-06-24 07:36:31.221870
# Unit test for function match
def test_match():
    assert(match(Command("vagrant ssh vagrant-vm-1", "", "", "", "", "")))



# Generated at 2022-06-24 07:36:33.081244
# Unit test for function match
def test_match():
    assert match(Command('vagrant ssh machine', "machine is not running"))

# Generated at 2022-06-24 07:36:35.238724
# Unit test for function match
def test_match():
    assert match(Command('vagrant ssh', 'stdout'))
    assert not match(Command('vagrant', 'stdout'))


# Generated at 2022-06-24 07:36:43.512581
# Unit test for function match
def test_match():
    cmd = Command("vagrant ssh",
                  """The box 'ubuntu/trusty64' could not be found or
could not be accessed in the remote catalog. If this is a private
box on HashiCorp's Atlas, please verify you're logged in via
`vagrant login`. Also, please double-check the name. The expanded
URL and error message are shown below:

URL: ["https://atlas.hashicorp.com/ubuntu/trusty64"]
Error: 

Vagrant assumes that this means the box could not be
found. Please verify the box is installed.
A `vagrant up` command should trigger a download.""")
    assert match(cmd)
    

# Generated at 2022-06-24 07:36:45.709175
# Unit test for function match
def test_match():
    command = Command('vagrant provision', 'The host path of the shared folder is missing: /vagrant')
    assert (match(command) is True)

# Generated at 2022-06-24 07:36:48.985473
# Unit test for function match
def test_match():
    assert match(Command('vagrant ssh server1', '', 'The guest machine entered an invalid state while waiting for it'))
    assert match(Command('vagrant rsync', '', 'The guest machine entered an invalid state while waiting for it\r\r\n'))
    assert not match(Command('vagrant ssh server1', '', 'The guest machine entered an invalid state while waiting for it'))
    assert not match(Command('vagrant rsync', '', 'The guest machine entered an invalid state while waiting for it\r\r\n'))


# Generated at 2022-06-24 07:36:51.961390
# Unit test for function match
def test_match():
    assert match(Command('vagrant status', 'The environment has not yet been created. Run `vagrant up` to create the environment.'))


# Generated at 2022-06-24 07:36:55.695335
# Unit test for function match
def test_match():
    assert match(Command("vagrant up", "The environment has not yet been created. Run vagrant up to"
                                            " create the environment. If a virtual environment has been"
                                            " created, see vagrant status for more information."))



# Generated at 2022-06-24 07:36:56.810942
# Unit test for function match
def test_match():
    assert match(Command('vagrant ssh dbs', ''))
    assert not match(Command('echo "vagrant: command not found"', ''))
    

# Generated at 2022-06-24 07:36:58.334288
# Unit test for function match
def test_match():
    assert match(Command('vagrant ssh dev', 'The SSH command failed!\n'
                                           'Please check that the VM exists and'
                                           ' is running, and try again.'))
    assert not match(Command('vagrant status', ''))


# Generated at 2022-06-24 07:37:06.584438
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    script = Command('vagrant status', 'default machine is not created', '')
    cmds = get_new_command(script)
    assert cmds[0] == 'vagrant up && vagrant status && vagrant ssh'
    assert cmds[1] == 'vagrant up && vagrant status && vagrant ssh'

    script = Command('vagrant status foo', 'default machine is not created', '')
    cmds = get_new_command(script)
    assert cmds[0] == 'vagrant up foo && vagrant status foo && vagrant ssh foo'
    assert cmds[1] == 'vagrant up && vagrant status foo && vagrant ssh foo'


enabled_by_default = True

# Generated at 2022-06-24 07:37:11.230190
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script=u"vagrant ssh",
                      stdout=u"The SSH command responded with a non-zero exit status. Vagrant assumes that this means the command failed.\nThe output for this command should be in the log above. Please read the output to determine what went wrong.\n")
    cmds = get_new_command(command)
    assert cmds == shell.and_(u"vagrant up", u"vagrant ssh")

# Generated at 2022-06-24 07:37:19.182337
# Unit test for function match
def test_match():
    assert match(Command('vagrant ssh',
                         'The environment has not yet been created. Run `vagrant up` to create the environment. If a virtual machine is already running, vagrant ssh will automatically connect to that machine. Otherwis'))
    assert not match(Command('vagrant ssh', ''))
    assert not match(Command('vagrant up',
                             'The environment has not yet been created. Run `vagrant up` to create the environment. If a virtual machine is already running, vagrant ssh will automatically connect to that machine. Otherwis'))


# Generated at 2022-06-24 07:37:24.122201
# Unit test for function get_new_command
def test_get_new_command():
    """
    Test function get_new_command
    """
    assert get_new_command(Command('vagrant ssh', '')) == ['vagrant up; vagrant ssh',
                                                           'vagrant up; vagrant ssh']
    assert get_new_command(Command('vagrant ssh classic', '')) == ['vagrant up classic; vagrant ssh classic',
                                                                   'vagrant up; vagrant ssh; vagrant ssh classic']

# Generated at 2022-06-24 07:37:25.404082
# Unit test for function match
def test_match():
    command = Command('vagrant ssh web1')
    assert match(command) is True

# Generated at 2022-06-24 07:37:30.851816
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("vagrant ssh",
                      "The environment has not yet been created. Run `vagrant up` to create the environment. \n\
If a machine is not created, only the default provider will be shown. So if a provider is not listed, \n\
then the machine is not created for that environment.")
    assert get_new_command(command) == shell.and_(u"vagrant up", command.script)

    command = Command("vagrant ssh default",
                      "The environment has not yet been created. Run `vagrant up` to create the environment. \n\
If a machine is not created, only the default provider will be shown. So if a provider is not listed, \n\
then the machine is not created for that environment.")

# Generated at 2022-06-24 07:37:35.837177
# Unit test for function get_new_command
def test_get_new_command():
    assert shell.and_(u"vagrant up", u"vagrant ssh") == get_new_command(Command("vagrant ssh"))
    assert shell.and_(u"vagrant up", u"vagrant ssh") == get_new_command(Command("vagrant ssh"))
    assert shell.and_(u"vagrant up", u"vagrant ssh") == get_new_command(Command("vagrant ssh"))

# Generated at 2022-06-24 07:37:39.457869
# Unit test for function match
def test_match():
    assert match(Command('vagrant ssh localhost', 
        'The VM must be created and running to run this command. Run `vagrant up` to '
        'create the VM. If the VM is running, you may need to run `vagrant provision` '
        'to configure the newly installed software.'))
    assert not match(Command('vagrant ssh localhost', ''))


# Generated at 2022-06-24 07:37:43.365317
# Unit test for function match
def test_match():
    assert match(Command('vagrant ssh', '', 'The environment has not been created. Run `vagrant up` to create the environment.'))
    assert match(Command('vagrant ssh', '', 'The environment has not yet been created. Run `vagrant up` to create the environment.'))


# Generated at 2022-06-24 07:37:50.092536
# Unit test for function match
def test_match():
    assert match(Command('vagrant status',
        " ==> default: The VM is running. To stop this VM, you can run `vagrant halt` to\n"
        "==> default: shut it down forcefully, or you can run `vagrant suspend` to simply\n"
        "==> default: suspend the virtual machine. In either case, to restart it again,\n"
        "==> default: simply run `vagrant up`.\n"))


# Generated at 2022-06-24 07:37:53.054892
# Unit test for function match
def test_match():
	res=match(Command('', '', 'The environment has not yet been created. Run `vagrant up` to create the environment.'))
	assert res == True
	res=match(Command('', '', 'This command is not valid for the current environment.'))
	assert res == False


# Generated at 2022-06-24 07:37:55.572305
# Unit test for function match
def test_match():
    command = Command(script="vagrant up ubuntu")
    assert match(command)


# Generated at 2022-06-24 07:38:03.941728
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='vagrant ssh', output="The SSH command attempted to connect to the following places:\n\
    127.0.0.1:2222 \nTo fix this, run `vagrant up`")
    assert get_new_command(command)[0] == "vagrant up && vagrant ssh"

    command = Command(script='vagrant ssh vm2', output="The SSH command attempted to connect to the following places:\n\
    127.0.0.1:2222 \nTo fix this, run `vagrant up`")
    assert get_new_command(command)[0] == "vagrant up vm2 && vagrant ssh vm2"
    assert get_new_command(command)[1] == "vagrant up && vagrant ssh vm2"

# Generated at 2022-06-24 07:38:08.494512
# Unit test for function match
def test_match():
    command = Mock(script='vagrant ssh hostname', output='The specified host is not running')
    assert match(command)
    command = Mock(script='vagrant ssh hostname', output='The specified host is runnning')
    assert not match(command)


# Generated at 2022-06-24 07:38:17.900853
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('vagrant status', 'The environment has not yet been created. Run `vagrant up` to create the environment. If a virtual machine is running, you can use `vagrant provision` to force provisioning. A frozen environment is not able to be booted.')) == shell.and_('vagrant up', 'vagrant status')
    assert get_new_command(Command('vagrant ssh machine1', 'The environment has not yet been created. Run `vagrant up` to create the environment. If a virtual machine is running, you can use `vagrant provision` to force provisioning. A frozen environment is not able to be booted.')) == [shell.and_('vagrant up machine1', 'vagrant ssh machine1'), shell.and_('vagrant up', 'vagrant ssh machine1')]

# Generated at 2022-06-24 07:38:21.845956
# Unit test for function match
def test_match():
    from thefuck.types import Command
    output = "The SSH command responded with a non-zero exit status. Vagrant" \
             " assumes that this means the command failed. The output for" \
             " this command should be in the log above. Please read the output"\
             " to determine what went wrong. Alternatively, you may run `vagrant up`"\
             " to try again automatically."
    assert match(Command("vagrant ssh", output))
    assert not match(Command("vagrant ssh", "abcde"))


# Generated at 2022-06-24 07:38:26.231540
# Unit test for function match
def test_match():
    assert match(Command('vagrant up --provider=virtualbox', None, '', '',
                         'A Vagrant environment or target machine is required to run this comm'))
    assert not match(Command('vagrant up --provider=virtualbox', None, '', '', ''))


# Generated at 2022-06-24 07:38:28.603693
# Unit test for function match
def test_match():
    command = Command(script=u"vagrant destroy", output=u"Message2")
    assert match(command)



# Generated at 2022-06-24 07:38:31.135988
# Unit test for function match
def test_match():
    assert match(Command(script='vagrant ssh',
                        output='Vagrant instance not created. Run `vagrant up`'))
    assert not match(Command(script='vagrant ssh',
                             output='Vagrant instance is not created.'))



# Generated at 2022-06-24 07:38:35.282654
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('vagrant up', '')) == shell.and_(u"vagrant up", '')
    assert get_new_command(Command('vagrant ssh dev', '')) == [u"vagrant up dev", shell.and_(u"vagrant up", '')]

# Generated at 2022-06-24 07:38:38.392465
# Unit test for function match
def test_match():
    assert match(Command("vagrant ssh",
                         "The specified command 'ssh' could not be found. Maybe you meant 'status', 'destroy' or 'up'? Try vagrant.\n Try running `vagrant up`."))


# Generated at 2022-06-24 07:38:45.095789
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('vagrant up', '', '', '', '', '')) == shell.and_('vagrant up', '')
    assert get_new_command(Command('vagrant ssh', '', '', '', '', '')) == shell.and_('vagrant up', '')
    assert get_new_command(Command('vagrant ssh test', '', '', '', '', '')) == [shell.and_('vagrant up test', ''), shell.and_('vagrant up', '')]