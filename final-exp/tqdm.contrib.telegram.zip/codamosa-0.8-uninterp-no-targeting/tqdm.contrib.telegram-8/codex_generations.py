

# Generated at 2022-06-22 05:12:17.014374
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    try:
        TelegramIO(token="", chat_id="")
    except:
        pass

# Hide all members from sphinx-apidoc
__all__.extend([s for s in dir() if s[0] != '_'])

# Generated at 2022-06-22 05:12:28.700293
# Unit test for function trange
def test_trange():
    """Unit test for `tqdm.contrib.telegram.trange`"""
    from ast import literal_eval
    trange(3, desc='TOKEN', token='TOKEN', chat_id='CHAT_ID')
    trange(3, desc='TOKEN', bar_format='{n_fmt}/{total_fmt} [{desc}{bar}]',
           token='TOKEN', chat_id='CHAT_ID')
    trange(3, desc='TOKEN', bar_format='{n_fmt}/{total_fmt} [{desc}{bar}]',
           token='TOKEN', chat_id='CHAT_ID').close()

# Generated at 2022-06-22 05:12:40.761944
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    import os
    from tempfile import mkstemp
    from .utils_test import closing, subprocess_run
    with closing(mkstemp()) as (fd, fname):
        os.close(fd)
        p = subprocess_run(
            ['python', '-m', 'tqdm', '--token=1234567890', '--chat_id=telegram',
             '--dynamic_ncols', '10', '-n', '2', fname])

        assert p.returncode == 0
        stdout = p.stdout.decode()
        errout = p.stderr.decode()
        assert '20%|##         | 1/2 [00:00<?' in stdout
        assert '40%|####       | 1/2 [00:00<' in errout

# Generated at 2022-06-22 05:12:45.444874
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    assert tqdm_telegram(foo='bar')
    try:
        assert tqdm_telegram()
    except Exception:
        return
    raise AssertionError('tqdm_telegram constructor is expected to fail since '
                         'Telegram Bot token and chat ID are not given.')


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-22 05:12:47.171612
# Unit test for function trange
def test_trange():
    from .tests_tqdm import pretest_posttest
    pretest_posttest(trange)

# Generated at 2022-06-22 05:12:52.885261
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    global tbio
    a = tqdm_telegram(range(5), token="539300906:AAEFXxWZuNB7g4KMOp4neSCUHd6UuVQSQ9Y", chat_id="694241039")
    a.write("test1")
    a.close()
    a.write("test2")

test_tqdm_telegram_close()

# Generated at 2022-06-22 05:12:57.895266
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from json import loads
    sent = [['foo', ''], ['bar', '...'],
            ['baz', '`baz`'], ['baz ', '`baz `'], ['baz\n', '`baz`\n⠀']]
    for s, r in sent:
        assert TelegramIO('', '').write(s) == r
    assert loads(TelegramIO('', '').write(None)) is None

# Generated at 2022-06-22 05:12:59.306409
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    """Unit test for constructor of class TelegramIO."""
    TelegramIO(
        '', '')



# Generated at 2022-06-22 05:13:05.582278
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    # empty display
    def _empty_display():
        t = tqdm_telegram(disabled=True)
        t.display()
        assert t.format_dict == {}

    # basic display
    def _basic_display():
        t = tqdm_telegram(disabled=True)
        t.total = 1000
        t.format_dict = {'bar_format': '{bar}'}
        t.n = 100
        t.display()
        assert t.format_dict == {'bar_format': '{bar:10u}', 'n': 100}

    # display on reset
    def _display_on_reset():
        t = tqdm_telegram(disabled=True)
        t.total = 1000
        t.format_dict = {'bar_format': '{bar}'}
       

# Generated at 2022-06-22 05:13:06.299016
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    tgr = ttgrange(50)
    tgr.close()

# Generated at 2022-06-22 05:14:39.364944
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from .test_utils import decorate_methods
    from .utils_enter_exit import patch
    from tqdm.auto import tqdm
    import time
    # Regular tqdm
    tqdm(range(3), desc="regular").write("foo")
    # TqdmTelegram
    tio = TelegramIO("TOKEN", "CHAT_ID")
    with patch(tio) as p:
        tio.write("foo")
        assert p.write.called
    # TqdmTelegram
    tqdm_telegram(range(3), desc="ttg").write("foo")
    # Delete token/chat_id
    tqdm_telegram = TelegramIO.__base__
    decorate_methods(tqdm_telegram, TelegramIO.__init__)
    tqdm_te

# Generated at 2022-06-22 05:14:46.440754
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm import tnrange
    # Dummy token and chat_id
    token = '0'
    chat_id = '0'
    progressbar = tqdm_telegram(tnrange(0, 0), token=token, chat_id=chat_id)
    progressbar.clear()
    # 1 - Check that we do not send any message to Telegram (using token '0')
    # 2 - Check that we do not send any message to Telegram (using chat_id '0')

# Generated at 2022-06-22 05:14:48.664967
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tgio = TelegramIO(token='{token}', chat_id='{chat_id}')
    tgio.write('testing')

# Generated at 2022-06-22 05:14:50.764554
# Unit test for function trange
def test_trange():
    from time import sleep
    for _ in trange(4, token='{token}', chat_id='{chat_id}'):
        sleep(3600)

# Generated at 2022-06-22 05:14:58.788617
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import time
    import tqdm as tqdm_auto
    tqdm_auto.write('Test of clear method\n')
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    with ttgrange(10, token=token, chat_id=chat_id) as t:
        for i in t:
            t.write(str(i))
            time.sleep(1)
            t.clear()
    tqdm_auto.write('End of test\n')

# Generated at 2022-06-22 05:15:09.459798
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from .tests_tqdm import ClosingStringIO
    import re

    with ClosingStringIO() as s:
        t = tqdm(
            total=1,
            file=s,
            desc=" ",
            unit_scale=True,
            miniters=1,
            mininterval=0,
            disable=False,
            token='1234567890:AAEfOIHtIusNVVR9XN5O8F5rZM-NxwmE1mM',
            chat_id='123456789')
        t.update()
        s.seek(0)

# Generated at 2022-06-22 05:15:11.425430
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    assert TelegramIO("InvalidToken", "InvalidId").message_id is None

# Generated at 2022-06-22 05:15:19.719850
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from tqdm import tqdm, trange
    from tqdm.contrib.telegram import tqdm_telegram, ttgrange
    with tqdm(range(1), leave=False, disable=True) as t:
        t.close()
    with tqdm_telegram(range(1), leave=False, disable=True) as t:
        t.close()
    with trange(1, leave=False, disable=True) as t:
        t.close()
    with ttgrange(1, leave=False, disable=True) as t:
        t.close()

# Generated at 2022-06-22 05:15:30.482394
# Unit test for function trange
def test_trange():
    """Unit test for function trange."""
    from nose.tools import assert_raises
    from os import environ
    from time import sleep
    from .utils import pretest

    pretest()

    # Check raise error on default args
    assert_raises(TypeError, trange)

    # Check basic behaviour
    for i in trange(10, token=environ.get('TQDM_TELEGRAM_TOKEN'),
                    chat_id=environ.get('TQDM_TELEGRAM_CHAT_ID')):
        sleep(0.01)
    # Check disable

# Generated at 2022-06-22 05:15:31.083981
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    assert TelegramIO('{token}', '{chat_id}').message_id

# Generated at 2022-06-22 05:18:26.347369
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    token = "1234"
    chat_id = "chat_id"
    text = "text"
    message_id = 1234
    url = 'https://api.telegram.org/bot1234/sendMessage'
    data = {'chat_id': 'chat_id', 'parse_mode': 'MarkdownV2', 'text': '`text`'}
    edit_message_url = 'https://api.telegram.org/bot1234/editMessageText'
    edit_message_data = {'chat_id': 'chat_id', 'message_id': message_id,
                         'parse_mode': 'MarkdownV2', 'text': '`text`'}
    delete_message_url = 'https://api.telegram.org/bot1234/deleteMessage'

# Generated at 2022-06-22 05:18:32.174248
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    try:
        tqdm_telegram()
    except:  # noqa
        raise AssertionError('tqdm_telegram fails to initialize without args.')
    tt = tqdm_telegram(disable=True)
    tt.display()
    tt = tqdm_telegram(disable=False, token='0', chat_id='0')
    tt.display()

# Generated at 2022-06-22 05:18:35.900587
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    """Test for method tqdm_telegram.display()."""
    tg = tqdm_telegram(total=1)
    tg.update(1)
    tg.display()
    assert not tg.tgio.tg_thread.is_alive()
    tg._instances.clear()

# Generated at 2022-06-22 05:18:40.532518
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    """Unit test for the constructor of class TelegramIO."""
    token = '123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11'
    chat_id = '12345678'
    TelegramIO(token, chat_id)

if __name__ == "__main__":
    test_TelegramIO()

# Generated at 2022-06-22 05:18:51.621979
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from requests import codes
    from time import sleep
    from ..autonotebook import tqdm as tqdm_notebook

    telegramio = TelegramIO('', '')

    # No message_id
    res = telegramio.write('')

    # Define a correct token & chat_id
    telegramio.token = 'TOKEN'
    telegramio.chat_id = 'CHATID'

    # message_id
    res = telegramio.write('')
    assert res.result.status_code == codes['ok']
    sleep(5)

    # Insert a new line in the message
    res = telegramio.write('')
    assert res.result.status_code == codes['ok']
    sleep(5)

    # Remove previous message
    res = telegramio.delete()
   

# Generated at 2022-06-22 05:19:01.365692
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import io
    import sys
    from io import StringIO
    io_out = io.StringIO()
    class tqdm(tqdm_telegram):
        _instances = []
        @classmethod
        def write(cls, *args, **kwargs):
            io_out.write(*args, **kwargs)
        def display(self, **kwargs):
            super(tqdm, self).display(**kwargs)

    f = tqdm(iterable=range(1000), desc='desc', bar_format='{l_bar}{bar}|',
             ncols=50, nrows=5, disable=False)
    assert not f.disable
    f.refresh()

# Generated at 2022-06-22 05:19:09.171498
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from io import StringIO as SIO
    from sys import stdout, version_info
    from .tests_tqdm import unicode

    for disable in [True, False]:
        with SIO() as out:
            stdout = out
            dl = (1, 2, 4, 8)
            with tqdm(total=16, disable=disable, smoothing=0,
                      bar_format="{l_bar}{bar}{r_bar}") as pbar:
                pbar.update(1)
                pbar.write("\r")
                pbar.update(1)
                pbar.write("\r")
                pbar.update(1)
                pbar.write("\r")
                pbar.update(1)
                pbar.write("\r")
                pbar.update(2)


# Generated at 2022-06-22 05:19:19.893187
# Unit test for function trange
def test_trange():
    """Test for: tqdm.contrib.telegram.trange"""
    from .utils_test import closing, dummy_tqdm
    vals = []
    with closing(dummy_tqdm()) as t:
        for _ in trange(t, 10, desc='description', ncols=0):
            vals.append(t.format_dict)
    assert all(v['desc'] == 'description' for v in vals)
    assert all('desc' not in v['bar_format'] for v in vals)
    assert any('ncols' not in v['bar_format'] for v in vals)
    assert not any('r_bar' in v['bar_format'] for v in vals)


# Unit tests for function TelegramIO