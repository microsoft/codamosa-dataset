

# Generated at 2022-06-22 05:11:56.954952
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    with tqdm_telegram(total=6, unit_scale=True, unit_divisor=1024,
                       unit='B', miniters=1) as pbar:
        for i in range(6):
            pbar.update()

# Generated at 2022-06-22 05:12:08.101185
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    kwargs = {'desc': 'Progress',
              'token': '{token}',
              'chat_id': '{chat_id}',
              'total': 10}
    t = tqdm_telegram(_range(10), **kwargs)

    t.close()
    assert(t.tgio.message_id is None)

    kwargs['disable'] = True
    t = tqdm_telegram(_range(10), **kwargs)

    t.close()
    assert(t.tgio.message_id is None)

    t = tqdm_telegram(_range(10), **kwargs)
    assert(t.tgio.message_id is None)

    kwargs['disable'] = False
    t = tqdm_telegram(_range(10), **kwargs)

# Generated at 2022-06-22 05:12:09.336612
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    assert tqdm_telegram(total=10).close == None

# Generated at 2022-06-22 05:12:13.351325
# Unit test for function trange
def test_trange():
    from .utils import _test_trange
    _test_trange(tqdm_telegram)


if __name__ == "__main__":
    r = trange(5)
    for i in r:
        pass

# Generated at 2022-06-22 05:12:16.321522
# Unit test for function trange
def test_trange():
    for _ in trange(4, token='{token}', chat_id='{chat_id}'):
        pass


if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-22 05:12:28.262489
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    class TelegramIOMock:
        @staticmethod
        def post(url, data):
            assert url.startswith(TelegramIO.API)
            assert url.endswith('/sendMessage')
            assert data['chat_id'] == '{chat_id}'
            assert data['text'] == '`{text}`'
            assert data['parse_mode'] == 'MarkdownV2'
            return {'error_code': None, 'result': {'message_id': 12345678}}

    union = {'session': TelegramIOMock()}

    TelegramIO('{token}', '{chat_id}', **union)

    # TelegramIO('{token}', '{chat_id}', **union)
    # # -> does not send a new message



# Generated at 2022-06-22 05:12:32.456812
# Unit test for function trange
def test_trange():  # pragma: no cover
    from time import sleep
    for i in trange(5, color="green", token="{token}", chat_id="{chat_id}"):
        sleep(.5)

if __name__ == "__main__":  # pragma: no cover
    test_trange()

# Generated at 2022-06-22 05:12:43.442813
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    # File-like object
    import io
    with io.StringIO() as f:
        t = tqdm_telegram(total=0, file=f, disable=True)
        t.close()
    # Telegram
    token = getenv('TQDM_TELEGRAM_TEST_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_TEST_CHAT_ID')
    if token is None or chat_id is None:
        return
    for t in [tqdm_telegram(total=1, token=token, chat_id=chat_id),
              tqdm_telegram(total=0, token=token, chat_id=chat_id)]:
        t.close()

# Generated at 2022-06-22 05:12:54.386472
# Unit test for function trange
def test_trange():
    """Test the function ttgrange."""
    from copy import copy
    from random import random
    from sys import getrefcount as grc
    from time import sleep
    kwargs = {'total': 50, 'miniters': 10,
              'token': '{token}', 'chat_id': '{chat_id}',
              'mininterval': 0.01}
    a = range(kwargs['total'])
    for i in trange(**kwargs):
        assert i == a[i]
        sleep(abs(random() - 0.5) / 50)
        kwargs2 = copy(kwargs)
        kwargs2['total'] = 20
        b = range(kwargs2['total'])
        for j in trange(**kwargs2):
            assert j == b[j]

# Generated at 2022-06-22 05:12:59.163298
# Unit test for function trange
def test_trange():
    from .utils_tqdm_test import _test_tqdm_basic, _test_tqdm_write
    _test_tqdm_basic(ttgrange)
    _test_tqdm_write(tqdm_telegram)


if __name__ == '__main__':
    from .utils_test import _test_telegram
    _test_telegram()
    test_trange()

# Generated at 2022-06-22 05:15:30.188049
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    try:
        TelegramIO(token='token', chat_id='chat_id')
        TelegramIO(token='token', chat_id='chat_id').write('message')
    except Exception:
        from traceback import print_exc
        print_exc()
        raise


# tests that non-inheritants of tqdm
# still work with the telegram bar

# Generated at 2022-06-22 05:15:39.072202
# Unit test for function trange
def test_trange():
    """
    Tests `tqdm.contrib.telegram.trange` function.
    """
    from time import sleep
    import sys

    class _TestIO(object):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
        def __getattr__(self, name):
            return lambda *a, **k: None

    tqdm_telegram.write = _TestIO()

    def w(s):
        sys.stderr.write(s)

    trange(3, bar_format='{l_bar}{bar}{r_bar}', file=sys.stderr,
           disable=None)
    sleep(0.1)


# Generated at 2022-06-22 05:15:49.609672
# Unit test for function trange
def test_trange():
    from .test_tqdm import _range, test, unicode
    # Test bypassing `__init__` from `tqdm_auto.__init__`

# Generated at 2022-06-22 05:15:57.801792
# Unit test for function trange
def test_trange():
    """Functional unit test"""
    # Just test the basic functionality
    with trange(10, token='288546412:AAF5jAoZsq0ulvxoS4zPqo3_8Mj-9a0N-Og',
                chat_id='133784275', desc='Unit test') as t:
        for i in t:
            t.sleep(0.2)
            t.set_description('Unit test - Step %i' % i)

# Generated at 2022-06-22 05:15:59.775848
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    io = TelegramIO("token", "chat_id")
    io.write("text")
    assert io.text == "text"


# Generated at 2022-06-22 05:16:03.936895
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    with tqdm_telegram(total=3, unit='Bs', leave=True) as t:
        for i in range(3):
            t.update()
            assert t.n == i
            t.clear()
            assert t.n == 0
            t.update(2)
            assert t.n == 2
            t.refresh()
            assert t.n == 2
            t.clear()
            assert t.n == 0

# Generated at 2022-06-22 05:16:10.032007
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    from time import sleep
    with trange(3, token='1123456789:AAAsdf-HbQGstKW0lwQF47z6lK0_ZaU5Zk-',
                chat_id='9876543210') as t:
        for i in t:
            sleep(1)

# Generated at 2022-06-22 05:16:15.212444
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    import os
    import tqdm
    tqdm.monitor_interval = 0
    fp = TelegramIO(os.getenv('TQDM_TELEGRAM_TOKEN'), os.getenv('TQDM_TELEGRAM_CHAT_ID'))
    assert fp.message_id != None
    fp.delete()

# Generated at 2022-06-22 05:16:25.575595
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from os import getenv
    from time import sleep
    from tqdm.utils import _term_move_up

    # Testing nose-xunit
    if getenv('NOSE_XUNIT_FILE'):
        warn("NOSE_XUNIT_FILE environment variable detected, not "
             "running tqdm_telegram constructor test")
        return

    # Testing TQDM_TELEGRAM_TOKEN & TQDM_TELEGRAM_CHAT_ID
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')

# Generated at 2022-06-22 05:16:26.665587
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    TelegramIO('{token}', '{chat_id}')