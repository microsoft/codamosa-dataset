

# Generated at 2022-06-22 05:12:56.973912
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from os import getenv
    from unittest import TestCase, main

    class Tests(TestCase):
        "Tests for TelegramIO."
        token = getenv('TQDM_TELEGRAM_TOKEN') if getenv('TQDM_TELEGRAM_TOKEN') else ''
        chat_id = getenv('TQDM_TELEGRAM_CHAT_ID') if getenv('TQDM_TELEGRAM_CHAT_ID') else ''
        def test_constructor(self):
            """Check constructor"""
            with self.assertRaises(TypeError):
                tqdm_telegram(iterable=[], ncols=0)
            # no token or chat id
            with self.assertRaises(ValueError):
                tqdm_telegram(token='')

# Generated at 2022-06-22 05:13:03.051069
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    with tqdm_telegram(token='INVALID', chat_id=123, total=1,
                       disable=True) as pbar:
        assert pbar.tgio is None
        assert pbar.total == 1
        del pbar.tgio
        pbar.close()
    # test auto-selection
    with tqdm(token='INVALID', chat_id=123, total=1,
              disable=True) as pbar:
        assert type(pbar).__name__ == 'tqdm_telegram'
        assert pbar.tgio is None
        assert pbar.total == 1
        del pbar.tgio
        pbar.close()

# Generated at 2022-06-22 05:13:04.577212
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tgio = TelegramIO(token="test", chat_id="test")
    tgio.write("test")
    assert tgio.text == "test"


# Generated at 2022-06-22 05:13:09.510059
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from datetime import timedelta
    from time import sleep

    token = 'j4_sYsR-RvQ2wzrC7IuHCe6XRcjPRQJbjjGm-UY'
    chat_id = 'a6c0a6c0a6c0a6c0a6c0a6c0a6c0a6c0a6c0a6c'
    # token = 'xEmeMfZV14Pe5B5etmx1c8uKFy-rzxUGuFtpRXj'
    # chat_id = 'sdkjbfdkjbf'
    token1 = 'j4_sYsR-RvQ2wzrC7IuHCe6XRcjPRQJbjjGm-UY'


# Generated at 2022-06-22 05:13:20.101210
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    """Unit test for method delete of class TelegramIO"""
    from tqdm.utils import _term_move_up

    tg = TelegramIO("testtoken", "testchat")
    tg.write("test")
    tg.delete()
    #test if delete post goes through
    assert(tg._message_id is None)
    tg.write("test")
    assert(tg._message_id is not None)
    tg.close()
    #test if message_id is None after close
    assert(tg._message_id is None)

    #test if it raises an exception when no message_id is set
    try:
        tg.delete()
    except:
        raise AssertionError

if __name__ == "__main__":
    from doctest import testmod
    testmod()

# Generated at 2022-06-22 05:13:25.948091
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    # Unit test for class tqdm_telegram
    try:
        import io
    except ImportError:
        return
    io_tg = io.StringIO()
    with tqdm(_range(100), file=io_tg) as t:
        for i in _range(100):
            t.update()
            if not (i % 5):
                t.clear()

# Generated at 2022-06-22 05:13:33.761179
# Unit test for function trange
def test_trange():
    with trange(10, token='480658976:AAHFI0rKQ40Y0fC6EgvJxwj6PNL-6b1U6_g',
                chat_id='-1001234345643') as t:
        for i in t:
            if i == 5:
                t.set_description('A description')
            time.sleep(0.1)

# Generated at 2022-06-22 05:13:41.777445
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    with tqdm_telegram(
            total=100, token='{token}', chat_id='{chat_id}') as t:
        try:
            for i in t:
                t.update()
                if i == 50:
                    break
        # class tqdm_telegram must be defined above
        except NameError:
            raise Exception("class tqdm_telegram is undefined")


if __name__ == '__main__':
    import doctest
    doctest.testmod(
        name='test_tqdm_telegram',
        optionflags=doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-22 05:13:44.236871
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from .utils_test import _test_clear
    _test_clear(tqdm_telegram)


if __name__ == "__main__":
    from ._main import _test
    _test()

# Generated at 2022-06-22 05:13:46.936630
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    telegram_tqdm = tqdm_telegram(leave=False,
                                  token='{token}',
                                  chat_id='{chat_id}')
    telegram_tqdm.close()
    return

# Generated at 2022-06-22 05:17:13.032927
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    # If a message was sent to Telegram by tqdm_telegram,
    # it should be deleted unless leave=True
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if token is None or chat_id is None:
        warn("TQDM_TELEGRAM_TOKEN or TQDM_TELEGRAM_CHAT_ID "
             "environment variable not set. Skipping test.", TqdmWarning)
    else:
        tg = tqdm_telegram(range(10), token=token, chat_id=chat_id, leave=False)
        tg.delete = lambda: True  # Workaround for telegram-limited deletion
        tg.close()

# Generated at 2022-06-22 05:17:21.971350
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from requests.exceptions import RequestException
    from requests.packages.urllib3.exceptions import ReadTimeoutError

    class SessionMock:
        class postMock:
            def __init__(self):
                self.data = {}

            def json(self):
                if self.data['message_id'] == 'b':
                    return {'error_code': 429}
                else:
                    return {'result': {'message_id': self.data['message_id']}}

        def __init__(self):
            self.post = self.postMock()

    class TelegramIOMock(TelegramIO):
        def __init__(self, token, chat_id, tgio):
            super(TelegramIOMock, self).__init__(token, chat_id)


# Generated at 2022-06-22 05:17:29.719140
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """
    Test that the method close of class `tqdm_telegram` works as expected.
    """
    import socket
    import tempfile
    import time
    import unittest

    import requests

    try:
        requests.get('http://docs.tqdm.ml')
    except socket.gaierror:
        unittest.skip("https://api.telegram.org is not reachable")

    temp_file = tempfile.NamedTemporaryFile(delete=False)
    temp_file.close()


# Generated at 2022-06-22 05:17:40.161538
# Unit test for function trange
def test_trange():
    """Unit test for trange"""
    from ..utils import _term_move_up
    out = tqdm_telegram(token='539851757:AAFb8W5wRnR6pdlm6HvU8A5WnMJrC3qy9aA',
                        chat_id='744591301', leave=False)
    out.write('Testing...')
    out.update(10)
    out.close()
    out.write('Test passed.')
    out.write('Testing...')
    out.update(10, postfix='Postfix.')
    out.close()
    out.write('Test passed.')
    out.write('Testing...')
    out.update(10, postfix="Postfix.", bar_format='{bar:10u}')
    out.close()

# Generated at 2022-06-22 05:17:51.471771
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from os import devnull
    from time import sleep
    tqdm_auto.set_lock(thread=True, external=True)
    tqdm_auto.write("tqdm_telegram: test 1/2...", file=open(devnull, 'w'))
    tqdm_auto.write("tqdm_telegram: test 2/2...", file=open(devnull, 'w'))
    for i in tqdm_telegram(range(3), token='1', chat_id='2',
                           desc="tqdm_telegram: test 1/2..."):
        sleep(0.5)
    for i in tqdm_telegram(range(3), token='1', chat_id='2',
                           desc="tqdm_telegram: test 2/2..."):
        sleep

# Generated at 2022-06-22 05:18:02.881903
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    """Unit test for method write of class TelegramIO."""
    from time import sleep
    from inspect import getsourcelines
    from .._tqdm import tqdm

    tqdm.write(getsourcelines(test_TelegramIO_write)[0][0])

    tgio = TelegramIO('734890591:AAFy7VmK4tPs1xV3hH8WZKV0v-EShP2QF-s',
                      '547576984')
    tgio.write('0')
    tgio.write('1')
    tgio.write('2')
    sleep(1)
    tgio.write('1234567890')
    sleep(1)
    tgio.write('12345')

# Generated at 2022-06-22 05:18:10.111636
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    # To run the test, add the following in your virtual environment
    # export TQDM_TELEGRAM_TOKEN={token}
    # export TQDM_TELEGRAM_CHAT_ID={chat_id}
    tg = TelegramIO(getenv('TQDM_TELEGRAM_TOKEN'), getenv('TQDM_TELEGRAM_CHAT_ID'))
    tg.message_id
    assert tg.delete()



# Generated at 2022-06-22 05:18:18.565611
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import unittest
    import json
    import httpretty
    from tqdm.contrib.telegram import TelegramIO

# Generated at 2022-06-22 05:18:23.056490
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from tqdm import tqdm_telegram
    for _ in tqdm_telegram(
            range(5), token='token', chat_id=123456789,
            desc='Testing tqdm_telegram function: '):
        pass

if __name__ == "__main__":
    test_tqdm_telegram()

# Generated at 2022-06-22 05:18:33.193725
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    def assert_close(tqdmobj):
        # assert that a tqdm object is closed to save resources
        assert tqdmobj.close() == None

    # test the close() method of tqdm_telegram
    assert_close(tqdm(range(10)))
    assert_close(tqdm(range(10), leave=True))
    assert_close(tqdm(range(10), leave=None))

    # test the close() method of tqdm_telegram with an empty iterable
    assert_close(tqdm(range(0)))
    assert_close(tqdm(range(0), leave=True))
    assert_close(tqdm(range(0), leave=None))
