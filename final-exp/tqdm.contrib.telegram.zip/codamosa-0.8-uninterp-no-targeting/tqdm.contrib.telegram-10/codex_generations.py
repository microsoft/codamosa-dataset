

# Generated at 2022-06-22 05:12:18.507598
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    tqdm_telegram(leave=False).close()


if __name__ == "__main__":
    with tqdm_telegram(total=10000, ncols=60, postfix="Semi-Blocking IO") as t:
        for i in _range(10000):
            t.update()
            t.write(str(t))

# Generated at 2022-06-22 05:12:27.181342
# Unit test for function trange
def test_trange():
    """Test `tqdm.tgrange`"""
    with trange(2, token='{token}', chat_id='{chat_id}') as t:
        for i in t:  # pragma: no cover
            assert isinstance(i, int)
            t.set_description("Testing trange in tqdm.contrib.telegram")
            t.display()

if __name__ == '__main__':  # pragma: no cover
    # TODO: remove this test when the Python API will be available
    test_trange()

# Generated at 2022-06-22 05:12:28.477540
# Unit test for function trange
def test_trange():
    trange(10, token='{token}', chat_id='{chat_id}')

# Generated at 2022-06-22 05:12:40.098389
# Unit test for function trange
def test_trange():
    import sys
    from .utils_test import closing, _io
    for __ in trange(4, token=sys.argv[1], chat_id=sys.argv[2]):
        for _ in trange(4, desc='nested loop', token=sys.argv[1],
                        chat_id=sys.argv[2]):
            with closing(tqdm_telegram(
                    _range(6), file=_io.StringIO(),
                    desc='nested loop (trange)', disable=False,
                    token=sys.argv[1], chat_id=sys.argv[2])) as t:
                for i in t:
                    pass  # do something slow


if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-22 05:12:48.030720
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    if hasattr(__builtins__, 'xrange'):  # in Python 2.x range is a wrapper
        cls = tqdm_telegram
        for i in cls(xrange(3), file=tqdm_telegram.write, disable=None):
            assert i == 0 or i == 1 or i == 2
        for i in cls(xrange(3), file=tqdm_telegram.write, disable=True):
            assert i == 0 or i == 1 or i == 2
        for i in cls(xrange(3), file=tqdm_telegram.write):
            assert i == 0 or i == 1 or i == 2

# Generated at 2022-06-22 05:12:57.513620
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import json
    from os import environ
    from os.path import dirname, abspath
    from sys import path
    from unittest import TestCase, main
    from uuid import uuid4
    from warnings import warn
    from .utils_com import _assertWarns

    tgio = TelegramIO(
        environ.get('TQDM_TELEGRAM_TOKEN'),
        environ.get('TQDM_TELEGRAM_CHAT_ID'))
    if tgio.message_id is None:
        warn("Please set env variables TQDM_TELEGRAM_TOKEN and "
             "TQDM_TELEGRAM_CHAT_ID and retry.", RuntimeWarning)
        return

# Generated at 2022-06-22 05:12:58.764929
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    for leave in [True, False, None]:
        for pos in [0, 1]:
            tt = tqdm_telegram(leave=leave, pos=pos)
            tt.close()

# Generated at 2022-06-22 05:12:59.819527
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    pbar = tqdm_telegram(total=1, leave=False)
    pbar.close()
    assert pbar.tgio.message_id is None

# Generated at 2022-06-22 05:13:03.216713
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if not (token and chat_id):
        warn("`TQDM_TELEGRAM_TOKEN`/`TQDM_TELEGRAM_CHAT_ID` not set, skipping "
             "test!", TqdmWarning)
    else:
        i = TelegramIO(token, chat_id)
        assert (i.message_id is not None)
        i.write('`Hello, world!`')
        i.delete()

# Generated at 2022-06-22 05:13:07.999210
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    class dummy:
        def write(self, *args, **kwargs):
            pass
    with dummy() as fd:
        bar = tqdm_telegram(fd, bar_format="<bar/>",
                postfix={"123456789": "123456789"})
        bar.display()
        assert bar.tgio.text == "123456789\n               "
    with dummy() as fd:
        bar = tqdm_telegram(fd, bar_format="{bar}",
                postfix={"123456789": "123456789"})
        bar.display()
        assert bar.tgio.text == "123456789\n               "

# Generated at 2022-06-22 05:15:37.506268
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    """
    tqdm.contrib.telegram.TelegramIO(token, chat_id)
    """
    try:
        from os import getenv
        token = getenv('TQDM_TELEGRAM_TOKEN')
        chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    except Exception:
        pass
    else:
        try:
            TelegramIO(token, chat_id)
        except Exception:
            pass
        else:
            return
    warn("TelegramIO could not be tested (set TQDM_TELEGRAM_TOKEN and "
         "TQDM_TELEGRAM_CHAT_ID)", TqdmWarning, stacklevel=2)

# Generated at 2022-06-22 05:15:48.584001
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():

    t = tqdm_telegram(1, disable = False)
    t.postfix = {'test':1}
    t.display()
    t.close()

    t = tqdm_telegram(1, disable = False)
    t.postfix = {'test':1}
    t.pos = 1
    t.display()
    t.close()

    t = tqdm_telegram(1, disable = False)
    t.postfix = {'test':1}
    t.pos = 1
    t.close()

    t = tqdm_telegram(1, disable = True)
    t.close()

    t = tqdm_telegram(1, disable = False)
    t.postfix = {'test':1}
    t.write('test message')

# Generated at 2022-06-22 05:15:56.980715
# Unit test for function trange
def test_trange():
    with trange(10, token='{token}', chat_id='{chat_id}') as t:
        for i in t:
            if i == 5:
                t.set_description('testing ... ')
            time.sleep(.1)


if __name__ == '__main__':
    minimum_interval = 0.1
    try:
        import pytelegram
        test_trange()
    except Exception:
        warn("Tests failed", TqdmWarning)

# Generated at 2022-06-22 05:16:01.103870
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    try:
        with tqdm_telegram(total=10) as pbar:
            for _ in pbar:
                pass
    except Exception as e:
        tqdm_auto.write(str(e))
    else:
        assert pbar.n == 10, "Pbar was not able to iterate."

# Generated at 2022-06-22 05:16:04.340604
# Unit test for function trange
def test_trange():
    """Mainly to test trange docstring"""
    with trange(3, token='{token}', chat_id='{chat_id}') as t:
        for i in t:
            pass

if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-22 05:16:15.870514
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    """
    Test that the Telegram display method works as intended.
    """
    import pandas as pd
    import numpy as np
    import random
    import re

    # Randomly select one of the below methods and set as "method"
    def method_1(data, attr):
        data.loc[:,attr] = np.random.randn(len(data))
        return data

    def method_2(data, attr):
        data.loc[:,attr] = np.random.randn(len(data))
        return data

    def method_3(data, attr):
        data.loc[:,attr] = np.random.randn(len(data))
        return data

    method_list = [
        method_1,
        method_2,
        method_3
    ]

    # Telegram

# Generated at 2022-06-22 05:16:18.476481
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from .tests_telegram import test_tqdm_telegram_close as test
    return test()

# Generated at 2022-06-22 05:16:20.945740
# Unit test for function trange
def test_trange():
    from .utils import _test_range
    _test_range(tqdm, ttgrange, **{'total':10})

# Generated at 2022-06-22 05:16:29.911362
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    from multiprocessing import Process, Queue
    q = Queue()
    def f(q):
        tio = TelegramIO('token', 'chat_id')
        q.put(tio)
    p = Process(target=f, args=(q,))
    p.start()
    tio = q.get()
    try:
        tio.message_id
        tio.write('foo')
    except Exception:
        raise
    finally:
        p.join(timeout=30)


if __name__ == '__main__':
    from tqdm._utils import _term_move_up
    from tqdm._main import main as tqdm_main
    from os import getenv
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv

# Generated at 2022-06-22 05:16:40.085117
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    """Test write method of TelegramIO class"""
    import sys
    # pylint: disable=unused-argument
    # For pylint
    def test_func(file, token=None, chat_id=None, echo=True):
        file.write("test")
        file.write("")
        file.write("")
        file.write("test")
        file.write("test")
        file.write("test")
        file.write("test")

    class TestTqdm(object):
        """Class to write test for tqdm function"""
        ncols = 80

        def __enter__(self):
            self._write = sys.stdout.write
            sys.stdout.write = lambda x: None

        def __exit__(self, *args):
            sys.stdout.write = self._write