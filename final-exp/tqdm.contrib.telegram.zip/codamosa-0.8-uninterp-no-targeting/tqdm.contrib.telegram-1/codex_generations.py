

# Generated at 2022-06-22 05:12:44.109074
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    with tqdm_telegram(total=None, token='', chat_id='') as f:
        pass

# Generated at 2022-06-22 05:12:47.583603
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    try:
        import sys
        with tqdm_telegram(token="a", chat_id="b", file=sys.stdout):
            pass
    except:
        return False
    return True

# Generated at 2022-06-22 05:12:51.802681
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    t = TelegramIO('token', 'chat_id')
    t.write('text')
    assert t.text == 'text'
    t.write(30*'ty')
    assert t.text == 30*'ty'
    t.write('')
    assert t.text == '...'


# Generated at 2022-06-22 05:12:56.345919
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    tg = tqdm_telegram()
    tg.close()
    tg.disable = True
    tg.close()
    tg.disable = False
    tg.leave = True
    tg.close()
    tg.leave = None
    tg.pos = 10
    tg.close()
    tg.pos = 0
    tg.close()

# Generated at 2022-06-22 05:13:00.437562
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    """Test for tqdm_telegram.clear()"""
    from tqdm.contrib import test_tqdm_telegram_clear
    return test_tqdm_telegram_clear()

if __name__ == '__main__':
    import doctest
    doctest.testmod(
        name="telegram",
        optionflags=doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-22 05:13:04.136388
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    g = lambda x, y: TelegramIO(x, y)
    for i in range(3):
        assert g('t', 'c') == g('t', 'c')  # caching
        assert g('t', 'c') != g('t', 'd')
        assert g('t', 'c') != g('s', 'c')
        assert g('t', 'c') != g('s', 'd')



# Generated at 2022-06-22 05:13:05.342684
# Unit test for function trange
def test_trange():
    for _ in trange(3):
        for _ in trange(3):
            for _ in trange(3):
                pass

# Generated at 2022-06-22 05:13:09.112916
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from sys import platform

    msg = "write"
    if platform != 'win32':
        token = getenv('TQDM_TELEGRAM_TOKEN') or '1234567890:ABCDEFGHIJKLMNOPQRSTUVWXYZ'
        chat_id = getenv('TQDM_TELEGRAM_CHAT_ID') or '12345678'
    else:
        token, chat_id = '', ''
    tgio = TelegramIO(token, chat_id)
    tgio.write(msg)
    tgio.clear()
    tgio.close()
    return msg

# Generated at 2022-06-22 05:13:11.188667
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from tests_tqdm import with_setup, _range

    @with_setup(pretest=lambda: tqdm.set_slower_interval())
    def test():
        for i in tqdm(_range(3), token='10', chat_id='10', miniters=1):
            pass

    test()

# Generated at 2022-06-22 05:13:14.858237
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    try:
        tgio = TelegramIO('', '')
        tgio.write('')
        tgio.delete()
        tgio.close()
    except Exception:
        raise ImportError("TelegramIO failed")


if __name__ == '__main__':
    test_TelegramIO()

# Generated at 2022-06-22 05:15:18.569827
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from numpy.testing import assert_equal

    def check(fmt, expected):
        t = tqdm_telegram(disable=True, bar_format=fmt)
        t.format_meter()
        assert_equal(t.format_dict["bar"], expected)

    check(
        None, '{l_bar}{bar:10u}{r_bar}')
    check(
        '{bar}', '{l_bar}{bar:10u}{r_bar}')
    check(
        'aaa {bar} bbb', 'aaa {bar:10u} bbb')
    check(
        'aaa {bar}', 'aaa {bar:10u}')
    check(
        '{bar} bbb', '{l_bar}{bar:10u} bbb')

# Generated at 2022-06-22 05:15:25.335640
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    for clear in [True, False]:
        with tqdm(range(2), token='856277137:AAHmrR7vA1WbH8Uyy589F-cjZmkd-kx-x8Q', chat_id='1008733244563') as pbar:
            pbar.clear(nolock=clear)


if __name__ == '__main__':
    test_tqdm_telegram_clear()

# Generated at 2022-06-22 05:15:34.664238
# Unit test for function trange
def test_trange():
    name = "tqdm.contrib.telegram.trange"
    ttgrange(10, desc=name)
    ttgrange(0, 10, desc=name, mininterval=0)
    with ttgrange(10, desc=name, leave=True) as t:
        for x in t:
            t.set_description("desc %d" % x)
            t.set_postfix(x=x)
            t.update()
            time.sleep(.1)
    with ttgrange(5) as t:
        for x in t:
            t.set_description(name)
            t.update()
            time.sleep(.1)

# Generated at 2022-06-22 05:15:35.498544
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    raise NotImplementedError


# Generated at 2022-06-22 05:15:40.311502
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    io = TelegramIO(token="{token}", chat_id="{chat_id}")
    io.write("Hello World")
    io.delete()
    io.write("Bye World")
    io.delete()
    io.close()

# Generated at 2022-06-22 05:15:48.029714
# Unit test for function trange
def test_trange():
    """Testing trange function"""
    with trange(1, token='{token}', chat_id='{chat_id}') as t:
        t.update(1)
    # Unit test for function tqdm
    def test_tqdm(iterable):
        """Testing tqdm function"""
        with tqdm(iterable, token='{token}', chat_id='{chat_id}') as t:
            for i in t:
                t.update()
        for i in tqdm(iterable, token='{token}', chat_id='{chat_id}'):
            pass

# Generated at 2022-06-22 05:15:54.583790
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    tgio = TelegramIO(token, chat_id)
    tgio.delete()
    tgio.close()


# Generated at 2022-06-22 05:16:02.369441
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    try:
        token = getenv('TQDM_TELEGRAM_TOKEN')
        chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
        TelegramIO(token, chat_id).delete()
    except:
        pass


if __name__ == '__main__':
    from os import getenv

    test_TelegramIO_delete()
    for i in tqdm(range(100), desc='Testing TelegramIO',
                  token=getenv('TQDM_TELEGRAM_TOKEN'),
                  chat_id=getenv('TQDM_TELEGRAM_CHAT_ID')):
        pass

# Generated at 2022-06-22 05:16:09.210221
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    """
    requires `token` & `chat_id`
    """
    process = tqdm_telegram(total=100, disable=True)

    def method_display():
        process.display(n=10, total=100)
        process.display()
    if getenv('TQDM_TELEGRAM_TOKEN') and getenv('TQDM_TELEGRAM_CHAT_ID'):
        method_display()

# Generated at 2022-06-22 05:16:16.329887
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import argparse
    # This is to avoid RuntimeErrors when testing
    argparse.ArgumentParser().exit = lambda *args, **kwargs: None

    # Instantiate a tqdm_telegram object
    tg = tqdm_telegram(total=1, disable=True)
    # Fast-forward
    tg.n = 1
    # Tested method
    tg.display()
    return tg.format_dict['desc']

if __name__ == "__main__":
    from doctest import testmod
    testmod(name="telegram")