

# Generated at 2022-06-22 05:12:09.861682
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    try:
        telegram_io = TelegramIO('a', 'b')
    except Exception as e:
        tqdm_auto.write(str(e))
    else:
        telegram_io.delete()

# Generated at 2022-06-22 05:12:12.274479
# Unit test for function trange
def test_trange():
    from .utils_test import _test_trange
    _test_trange(trange)

# Generated at 2022-06-22 05:12:16.323535
# Unit test for function trange
def test_trange():
    try:
        import cPickle as pickle
        with tqdm(total=5) as pbar:
            for i in trange(5, total=5):
                pickle.dumps(pbar)
    except Exception as exception:
        assert False, exception

test_trange()

# Generated at 2022-06-22 05:12:24.148971
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm.contrib.telegram import tqdm
    pos = 0
    with tqdm(
            total=10,
            token='bot_token',
            chat_id='chat_id',
            mininterval=0.1,
            miniters=1,
            leave=True) as pbar:
        for i in range(10):
            pbar.update()
            pbar.clear()
            pos += 1
    assert pos == 10, pos


# Generated at 2022-06-22 05:12:26.637773
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tgio = TelegramIO("", "")
    tgio.write("")
    tgio.delete()

# Generated at 2022-06-22 05:12:32.255893
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    # Case-1: leave = False
    tqdm_telegram(total=1, leave=False, disable=True).close()  # no exception
    # Case-2: leave = None and pos == 0
    tqdm_telegram(total=1, disable=True).close()  # no exception
    # Case-3: leave = True
    tqdm_telegram(total=1, leave=True, disable=True).close()  # no exception

# Generated at 2022-06-22 05:12:39.849754
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    pbar = tqdm_telegram(total=10)
    assert len(pbar.format_dict) == 10
    assert pbar.format_dict['bar_format'] == '{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}]'
    assert pbar.format_dict['unit'] == 'it'
    pbar.close()



# Generated at 2022-06-22 05:12:45.338650
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    try:
        assert getenv('TQDM_TELEGRAM_TOKEN') is not None and getenv('TQDM_TELEGRAM_CHAT_ID') is not None
        t = tqdm_telegram(total=1, desc="test")
        time.sleep(1)
        assert t.total == 1
        t.clear()
        time.sleep(1)
        assert t.total == 1
        t.close()
    except:
        pass

# Generated at 2022-06-22 05:12:55.020519
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    """Test tqdm.contrib.telegram"""

    # Test token and chat_id not specified
    with tqdm(total=10,
              desc='Token & ChatID not specified',
              bar_format='{desc}: {bar}|{n_fmt}/{total_fmt} [{elapsed}]') as t:
        for i in range(10):
            t.update()
            time.sleep(0.05)

    # Test token not specified

# Generated at 2022-06-22 05:12:57.277064
# Unit test for function trange
def test_trange():
    """Test for trange"""
    for _ in tqdm_telegram(range(10)):
        pass
    for _ in ttgrange(10):
        pass

# Generated at 2022-06-22 05:14:43.518105
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    out = tqdm_telegram(range(10), ascii=True, token=12345, chat_id='my_chat')
    out.close()
    out = tqdm_telegram(range(10), token=12345, chat_id='my_chat')
    out.close()

# Generated at 2022-06-22 05:14:49.393691
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    try:
        import requests
    except Exception:
        return
    try:
        requests.post('https://api.telegram.org/bot123/sendMessage'
                      '', data={'chat_id': '123', 'text': 'hello'}).json()
    except Exception as e:
        assert "too many requests" in str(e).lower()

# Generated at 2022-06-22 05:15:01.519064
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import sys
    import json
    from time import sleep
    from random import random
    from io import StringIO
    from requests import Session
    from types import SimpleNamespace

    # fake tqdm_telegram
    class tqdm_telegram(object):
        # pylint: disable=too-many-instance-attributes
        class tgio(object):
            session = Session()

            def attach(self, tqdm):
                self.tqdm = tqdm
                tqdm.tgio = self

            def write(self, s):
                if s.startswith("\x1b[?25h\x1b[0m"):
                    s = s[11:]
                if s.endswith("\r "):
                    s = s[:-2]

# Generated at 2022-06-22 05:15:06.730119
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear(): # pragma: no cover
    import time
    from os import getenv
    with tqdm(total=50, unit='it', disable=not getenv('TQDM_TEST_TG')) as pbar:
        for i in range(50):
            time.sleep(0.05)
            pbar.update()
            if i % 5 == 0:
                pbar.clear()
    return True

# Generated at 2022-06-22 05:15:18.216435
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    from platform import node
    from time import sleep
    from random import randint
    from tqdm.contrib.telegram import TelegramIO
    from tqdm.utils import _decode_unicode
    getenv('TQDM_TELEGRAM_TOKEN') and getenv(
        'TQDM_TELEGRAM_CHAT_ID')  # test if env vars are set
    try:
        tg = TelegramIO(getenv('TQDM_TELEGRAM_TOKEN'),
                        getenv('TQDM_TELEGRAM_CHAT_ID'))
    except Exception as e:
        tqdm_auto.write(str(e))
    else:
        with tg:
            tg.write("`%s` test: " % node())

# Generated at 2022-06-22 05:15:27.330342
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import pytest
    from requests.exceptions import HTTPError
    t = TelegramIO(token="dummy_token", chat_id="dummy_chat_id")
    m = t.message_id
    assert m is None
    t.text = "dummy text"
    with pytest.raises(Exception):
        t.write("dummy text")
    assert t.message_id is None
    t._message_id = 1234
    with pytest.raises(HTTPError):
        t.write("dummy text")
    assert t.message_id is None


# Generated at 2022-06-22 05:15:32.590127
# Unit test for function trange
def test_trange():
    """test_trange()"""
    with trange(5, token='{token}', chat_id='{chat_id}') as t:
        for i in t:
            t.set_description('**A**', refresh=False)
            t.set_postfix(file=str(i), refresh=False)
            t.update()
            if i == 2:
                t.set_postfix(fail='X', refresh=False)
                t.update()

# Generated at 2022-06-22 05:15:37.443709
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from io import StringIO
    sys = StringIO()
    tqdm_auto.close()
    tqdm_auto.set_slower_interval(0.1)
    tqdm_auto.set_lock(True)
    tqdm_auto.file = sys
    tgio = TelegramIO('', '')
    tgio.text = 'some text'
    tgio.write('some text')
    assert tgio.session.post.called == True


# Generated at 2022-06-22 05:15:48.534245
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .utils_test import TestTqdm, _io

    class TestTqdmTelegram(TestTqdm):
        """Test Class for tqdm_telegram"""
        def __init__(self, **kwargs):
            super(TestTqdmTelegram, self).__init__(**kwargs)
            self.tgio = TelegramIO('test_token', 'test_chat_id')

        def tgrange(self, *args, **kwargs):
            return tqdm_telegram(_range(*args), **kwargs)

    with _io():
        with TestTqdmTelegram() as t:
            t.test_disp_unicode()
            t.test_disp_unicode_leave()
            t.test_disp_unicode_noloop()
            t.test_dis

# Generated at 2022-06-22 05:15:53.637561
# Unit test for function trange
def test_trange():
    from tqdm.auto import trange
    with trange(10, token='123', chat_id='456') as t:
        for i in t:
            t.set_description('hi %i' % i)
            pass

# Generated at 2022-06-22 05:17:39.197444
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    """
    >>> t = tqdm_telegram(range(3), token='{token}', chat_id='{chat_id}')
    >>> for _ in t:
    ...     pass
    ...
    """
    return

# Generated at 2022-06-22 05:17:49.633308
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import time
    import os
    import shutil
    import sys
    sys.stdout = open(os.devnull, 'w')
    try:
        t = tqdm_telegram(total=100, disable=False, token=os.getenv('TQDM_TELEGRAM_TOKEN'), chat_id=os.getenv('TQDM_TELEGRAM_CHAT_ID'))
        for i in _range(10):
            t.update()
            time.sleep(0.01)
        t.clear()
    finally:
        sys.stdout = sys.__stdout__
        os.remove("os.devnull")
        shutil.rmtree("__pycache__")


# Generated at 2022-06-22 05:18:01.245198
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """Unit test for method close of class tqdm_telegram"""
    # Imports
    from os import getenv
    import sys
    from tempfile import NamedTemporaryFile
    from .utils import _range

    from .utils import _range
    from .utils_test import testit

    # Initialize
    with NamedTemporaryFile(mode='w+t') as tmp:
        token = getenv('TQDM_TELEGRAM_TOKEN')
        chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')

# Generated at 2022-06-22 05:18:08.101535
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import sys
    import time
    bar_format = '[{:10u}]'
    with tqdm_telegram(total=4, bar_format=bar_format) as pbar:
        for i in range(4):
            pbar.display(bar_format=bar_format)
            time.sleep(1)
    sys.stdout.write('\n')


if __name__ == '__main__':
    test_tqdm_telegram_display()

# Generated at 2022-06-22 05:18:09.094826
# Unit test for function trange
def test_trange():
    return ttgrange(0)

# Generated at 2022-06-22 05:18:12.237167
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import unittest

    class TestCase(unittest.TestCase):
        def test_clear(self):
            tqdm(total=100, disable=True, leave=False).clear()

    unittest.main()

# Generated at 2022-06-22 05:18:24.445369
# Unit test for function trange
def test_trange():
    import sys
    import time


# Generated at 2022-06-22 05:18:32.692650
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    """
    test for :class:`TelegramIO`
    """
    from .common import with_telegram_credentials

    with with_telegram_credentials() as (token, chat_id):
        header = 'Testing TelegramIO'
        io = TelegramIO(token, chat_id)

        assert io.message_id is not None
        io.write(header)

        io.write(header)
        io.write(header)
        io.write('i' * 4096)
        io.write('f' * 4096)

        io.delete()
    io.__del__()

# Generated at 2022-06-22 05:18:36.414848
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tg = TelegramIO("token", "chat_id")
    tg.message_id = "message_id"
    assert tg.delete() == True, "The method delete of class TelegramIO failed"
    try:
        tg.submit()
        assert False, "The method submit of class TelegramIO failed"
    except:
        assert True

# Generated at 2022-06-22 05:18:37.274268
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from .tests_telegram import test_tgrange
    test_tgrange(tqdm)