

# Generated at 2022-06-22 05:13:57.466447
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from time import sleep

    message_id = None
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    tgio = TelegramIO(token, chat_id)
    for i in range(10):
        message_id = tgio.message_id
        tgio.write("Hello World %d" % i)
        sleep(2)
    tgio.submit(tgio.session.post, tgio.API + '%s/deleteMessage' % token,
                data={'chat_id': chat_id, 'message_id': message_id})


# If a file is executed, then __name__ == '__main__'
if __name__ == '__main__':
    test_

# Generated at 2022-06-22 05:14:00.118767
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    # Test without token & chat_id
    with tqdm_telegram(total=2) as t:
        assert len(t) == 2

    # Test with token & chat_id
    with tqdm_telegram(total=2, token='{token}', chat_id='{chat_id}') as t:
        assert len(t) == 2

if __name__ == "__main__":
    from doctest import testmod
    testmod(verbose=True)

# Generated at 2022-06-22 05:14:01.709979
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    io = TelegramIO('', '')

# Generated at 2022-06-22 05:14:07.573832
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    """Test `TelegramIO.delete()`."""

    def example_token():
        return '123456789:AAEe5j5TRI7nRwD5zBp7ykKWf3Y9X5_I3-k'

    def example_chat_id():
        return '123456789'

    tgio = TelegramIO(example_token(), example_chat_id())
    deleted_message_id = tgio.delete()
    assert deleted_message_id == tgio._message_id

# Generated at 2022-06-22 05:14:18.904588
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from time import sleep
    from requests_mock import Mocker as _Mocker
    from requests import Session as _Session
    from io import StringIO as _StringIO

    def tqdm_mock(*args, **kwargs):
        io = _StringIO()
        t = tqdm_telegram(*args, file=io, **kwargs)
        t.tgio.session = _Mocker()

        def collector():
            global _line
            for line in io:
                _line = line

        t.thread_collector = collector
        t.thread_collector()
        t.start()
        try:
            yield t
        finally:
            t.close()

    def send_message():
        global _line
        _line = None

# Generated at 2022-06-22 05:14:27.465549
# Unit test for function trange
def test_trange():
    for _ in trange(2, desc="Test trange", ascii=True, token='964268919:AAGsy3Jq5l5xbZYcAnvHB8ktIxA6ch-LX9g', chat_id='207802250'):  # NOQA
        for __ in trange(2, desc="Nested", ascii=True, token='964268919:AAGsy3Jq5l5xbZYcAnvHB8ktIxA6ch-LX9g', chat_id='207802250'):  # NOQA
            pass


# Generated at 2022-06-22 05:14:35.492853
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    """Test case for tqdm_telegram constructor."""
    # No token
    try:
        tqdm_telegram(token=None, chat_id='0')
    except TypeError:
        pass
    else:
        raise AssertionError("tqdm(token=None) should not pass.")

    # No chat id
    try:
        tqdm_telegram(token='0', chat_id=None)
    except TypeError:
        pass
    else:
        raise AssertionError("tqdm(chat_id=None) should not pass.")



# Generated at 2022-06-22 05:14:39.902458
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .utils_test import test_tqdm
    import io
    from warnings import catch_warnings, simplefilter
    test_tqdm(tqdm_telegram)
    with io.StringIO() as f:
        with catch_warnings():
            simplefilter("ignore", category=TqdmWarning)
            with tqdm_telegram(total=10, file=f, mininterval=0) as pbar:
                pbar.display()  # should not raise any warnings

# Generated at 2022-06-22 05:14:42.970518
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """Test for method close of class tqdm_telegram"""
    from tqdm._tqdm import _range
    from tqdm.contrib.telegram import tqdm
    with tqdm(_range(1000), token='{token}', chat_id='{chat_id}', ncols=80,
              ascii=True) as t:
        for _ in t:
            pass

# Generated at 2022-06-22 05:14:49.807992
# Unit test for function trange
def test_trange():
    """Test trange"""
    # pylint: disable=protected-access
    with tqdm(total=10, desc="Test", unit="B",
              token='667714732:AAHvG8ZOeRwDRzgNJ2QF65Evz8PNNThM-tI',
              chat_id='205308360') as pbar:
        for _ in range(10):
            pbar.update()

# Generated at 2022-06-22 05:16:31.348195
# Unit test for function trange
def test_trange():
    # Only test use-case (for coverage)
    list(trange(5, token='0', chat_id='0'))

# Generated at 2022-06-22 05:16:35.345182
# Unit test for function trange
def test_trange():
    from .tests_telegram import test_trange as _test_trange
    return _test_trange(tqdm, trange)

# Generated at 2022-06-22 05:16:42.295485
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    import os
    import requests
    x = TelegramIO("1101244586:AAHvbMBCHArhfcsX8I07q3CvnGJU6ZlU6_s",
                   "-255856543")
    os.environ["TQDM_TELEGRAM_CHAT_ID"] = "-255856543"
    os.environ["TQDM_TELEGRAM_TOKEN"] = "1101244586:AAHvbMBCHArhfcsX8I07q3CvnGJU6ZlU6_s"
    x.message_id
    x.delete()

# Generated at 2022-06-22 05:16:52.744203
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    """Test tqdm_telegram()"""
    tqdm_telegram(range(1000), token='token', chat_id='chat_id')
    tqdm_telegram(range(1000), token='token', chat_id='chat_id', miniters=1)
    tqdm_telegram(range(1000), token='token', chat_id='chat_id', mininterval=0.1)
    tqdm_telegram(range(1000), token='token', chat_id='chat_id', mininterval=0.1, miniters=1)
    tqdm_telegram(range(1000), token='token', chat_id='chat_id', mininterval=0.1, miniters=1, smoothing=1)

# Generated at 2022-06-22 05:16:55.313956
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import pytest
    with pytest.raises(AttributeError):
        TelegramIO('token', 'chat_id').write('message')

# Generated at 2022-06-22 05:16:56.478411
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    assert TelegramIO('token', 'chat_id').delete() is None

# Generated at 2022-06-22 05:17:03.268841
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    """Test method delete"""
    import os
    token = os.environ("TQDM_TELEGRAM_TOKEN",
                       "123456789:TEST-TOKEN-TEST-TEST-TEST-TEST")
    chat_id = os.environ("TQDM_TELEGRAM_CHAT_ID",
                         "123456789")
    t = TelegramIO(token, chat_id)
    t.write("test message")
    fid = t.message_id
    t.delete()
    t.close()
    if not t.delete():
       raise RuntimeError("Failed to delete message with id {}.".format(fid))

# Generated at 2022-06-22 05:17:05.484884
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    # this test should never fail
    t = tqdm_telegram(pos=0, leave=True)
    t.close()

# Generated at 2022-06-22 05:17:09.968194
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    class test_class():
        def __init__(self):
            self.test_data = 'test'

    def test_write(test_class_data):
        return test_class_data.test_data
    test_object = TelegramIO("", "")
    assert test_write(test_object) == test_object.write("test")

# Generated at 2022-06-22 05:17:15.574456
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    try:
        import pandas  # noqa
        import numpy  # noqa
    except ImportError:
        return  # tqdm_pandas and tqdm_notebook unavailable
    try:
        t = tqdm(total=3)
        t.clear()
        # "t.clear()" is equivalent to "t.write("")"
        assert t.format_dict['desc'] == ''
    finally:
        t.close()
        del t