

# Generated at 2022-06-22 05:14:08.701889
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    with tqdm_auto.wrapattr(TelegramIO, 'API', "https://httpbin.org/post"):
        token = '1234'
        chat_id = '5678'
        tgio = TelegramIO(token, chat_id)
        assert tgio.token == token
        assert tgio.chat_id == chat_id
        assert tgio.session
        assert tgio.text == 'TelegramIO'
        assert tgio.message_id is None
        del tgio._message_id
        assert tgio.message_id is None
        message_id = 12345

# Generated at 2022-06-22 05:14:19.852216
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    """Unit test for constructor of class TelegramIO."""
    # pylint: disable=protected-access
    tgio = TelegramIO(token='test_token', chat_id='test_chat')
    assert tgio.token == 'test_token'
    assert tgio.chat_id == 'test_chat'
    assert callable(tgio.write)
    assert callable(tgio.delete)
    assert tgio._message_id is None
    tgio._message_id = 'test_message_id'
    assert tgio.message_id == 'test_message_id'
    tgio._message_id = None
    assert tgio.message_id is None


if __name__ == "__main__":
    from doctest import testmod
    testmod()

# Generated at 2022-06-22 05:14:24.795311
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from time import sleep
    for _ in ttgrange(total=4):
        sleep(0.1)
        tqdm_auto.write("Cool!")


if __name__ == '__main__':
    test_TelegramIO_write()

# Generated at 2022-06-22 05:14:34.927729
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    try:
        import requests
    except ImportError:
        tqdm_auto.write("Skipping test: no requests installed, "
                        "can't create/edit Telegram messages.")
        return

    # Missing token:
    assert tqdm_telegram(token=None).tgio.message_id is None
    # Missing chat_id:
    assert tqdm_telegram(chat_id=None).tgio.message_id is None
    # Missing token and chat_id:
    assert tqdm_telegram(token=None, chat_id=None).tgio.message_id is None
    # Missing token or chat_id:

# Generated at 2022-06-22 05:14:35.768569
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    return tqdm_telegram.display('a')

# Generated at 2022-06-22 05:14:42.406420
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    try:
        import requests
    except ImportError:
        requests = None
    if requests is None:
        return
    session = requests.Session()

    import time
    import re
    from os import environ

    from .utils_worker import _RandomSleep
    from .utils import _term_move_up
    # In Python 2.6, the `random` module is called `Random`
    try:
        from random import random
    except ImportError:
        from random import Random
        random = Random().random

    try:
        # Python 2
        import __builtin__ as builtins
    except ImportError:
        # Python 3
        import builtins
    try:
        # Python 2
        builtins.input = raw_input
    except AttributeError:
        pass


# Generated at 2022-06-22 05:14:48.336281
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tgIO = TelegramIO(token='mytoken', chat_id='myid')
    assert tgIO.write('text')
    assert tgIO.write('') == None
    assert tgIO.write(None) == None
    assert tgIO.write('\r') == None
    assert tgIO.message_id != None

# Generated at 2022-06-22 05:14:50.282073
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    telegram_io = TelegramIO(token='', chat_id='')
    telegram_io.write('Hello')
    return True

# Generated at 2022-06-22 05:14:51.986668
# Unit test for function trange
def test_trange():
    from .tests_telegram import test_trange
    test_trange()

# Generated at 2022-06-22 05:15:03.528833
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    tgio = TelegramIO(token='123456789:ABCDEFfghijklmNOPQrSTUVWxyZ0123456789',
                      chat_id='123456789')
    assert tgio.message_id is not None  # message created
    tg = tqdm_telegram(
        iterable=_range(10), disable=False, token=tgio.token,
        chat_id=tgio.chat_id, miniters=1, mininterval=1,
        maxinterval=1, dynamic_ncols=True)

# Generated at 2022-06-22 05:17:34.898325
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    r = list(tqdm_telegram(iterable='1234', leave=False,
                           token=getenv('TQDM_TELEGRAM_TOKEN'),
                           chat_id=getenv('TQDM_TELEGRAM_CHAT_ID')))
    assert r == list('1234'), repr(r)

# Test is not run during `pip install tqdm`:
if __name__ == "__main__":
    test_tqdm_telegram()

# Generated at 2022-06-22 05:17:41.927714
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from inspect import signature
    from tqdm._tqdm import string_types, _supports_unicode

    # Check that no new arguments have been added
    assert signature(tqdm_telegram.display).parameters == \
           signature(tqdm_auto.display).parameters

    # Check that the method returns None
    assert tqdm_telegram.display() is None

    # Check that bar is properly printed
    t = tqdm_telegram(total=10, mininterval=0.001,
                      disable=not _supports_unicode)
    t.display(bar_format='{bar}')
    assert isinstance(t.tgio.text, string_types)
    assert '\x1b[?25l' in t.tgio.text  # invisible cursor

# Generated at 2022-06-22 05:17:42.930654
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    TelegramIO('', '')

# Generated at 2022-06-22 05:17:45.152793
# Unit test for constructor of class tqdm_telegram

# Generated at 2022-06-22 05:17:49.583147
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    try:
        import string  # noqa
    except ImportError:
        import string  # noqa
    assert (string.printable + string.whitespace).startswith(
        tqdm(string.printable + string.whitespace, disable=True) + '_' * 10)

# Generated at 2022-06-22 05:17:51.472005
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tgio = TelegramIO('token', 'chat_id')
    tgio.delete()

# Generated at 2022-06-22 05:17:55.188358
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from itertools import count
    from random import random
    with tqdm_telegram(
            token=getenv('TQDM_TELEGRAM_TOKEN'),
            chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'),
            total=1000, miniters=1, mininterval=0.5, unit='B', unit_scale=True,
            unit_divisor=1024, dynamic_ncols=True, ascii=None) as t:
        for i in count():
            t.update()
            if random() < 0.1 or i == 1000:
                break
    t.close()

# Generated at 2022-06-22 05:17:58.634214
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    import io
    with io.StringIO() as buf, tqdm_telegram(leave=True) as pbar:
        pbar.write('foobar')
        assert buf.getvalue() == 'foobar\n'

# Generated at 2022-06-22 05:17:59.258090
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    pass

# Generated at 2022-06-22 05:18:01.902226
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    with tqdm_telegram(total=10, token='', chat_id='') as t:
        t.update()
        t.close()
    assert t.n == 1