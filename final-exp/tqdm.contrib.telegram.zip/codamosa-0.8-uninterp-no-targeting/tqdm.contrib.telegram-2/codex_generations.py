

# Generated at 2022-06-22 05:12:40.848414
# Unit test for method delete of class TelegramIO

# Generated at 2022-06-22 05:12:44.905819
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """
    Proceeds to call `close` on each of the two classes where `close` is
    implemented and checks that the `close` method of the two classes
    executes without error.
    """
    tqdm_telegram(range(10),disable=False).close()
    tqdm_telegram(range(10),disable=True).close()

# Generated at 2022-06-22 05:12:46.992909
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tgio = TelegramIO('TelegramIO', 'test_TelegramIO_delete')
    assert tgio.delete() is None

# Generated at 2022-06-22 05:12:50.826429
# Unit test for function trange
def test_trange():
    """Unit test for trange"""
    with tqdm(total=100) as t:
        for i in trange(100, leave=False):
            t.update()

if __name__ == "__main__":
    from doctest import testmod
    testmod()

# Generated at 2022-06-22 05:12:52.930047
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tgio = TelegramIO('', '')
    for i in range(10):
        tgio.write('test')


# Generated at 2022-06-22 05:12:57.317831
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from .tests_tqdm import pretest_posttest

    @pretest_posttest
    def baz():
        for i in tqdm(range(10), token='{token}', chat_id='{chat_id}'):
            if i == 3:
                tqdm.clear()
                tqdm.close()
            else:
                pass
    baz()

# Generated at 2022-06-22 05:13:00.473607
# Unit test for function trange
def test_trange():
    """
    Tests that trange runs without error.
    """
    list(trange(10, token='{token}', chat_id='{chat_id}'))


if __name__ == '__main__':
    from ..utils import _test_env
    _test_env()
    test_trange()

# Generated at 2022-06-22 05:13:02.365282
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    io = TelegramIO(token = "123456789:AAG90e14HJmfV3BAHO0ve6IKru3qJZ0Hpv8", chat_id = "793616467")
    print(io.write("test_TelegramIO_write"))


# Generated at 2022-06-22 05:13:03.912139
# Unit test for function trange
def test_trange():
    cls = tqdm(trange(10))
    try:
        assert len(cls) == 10
    finally:
        cls.close()


if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-22 05:13:04.995049
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    with tqdm_telegram(disable=True) as t:
        assert t.tgio.write("Test") is None


# Generated at 2022-06-22 05:15:07.548959
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    telegramIO = TelegramIO(token, chat_id)
    telegramIO.delete()

if __name__ == '__main__':
    test_TelegramIO_delete()

# Generated at 2022-06-22 05:15:14.066881
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    try:
        a = tqdm_telegram(
            'foo', file=TelegramIO('871887112:IAFbwi2Nrs8Wd9XRvf0CzAno', '878312412'),
            disable=True)
    except Exception:
        pass
    finally:
        a.close()

# Generated at 2022-06-22 05:15:22.159980
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    # Test normal case (clear once)
    import io
    import sys
    out = io.StringIO()
    sys.stdout = out
    t = tqdm_telegram(range(10), token='@', chat_id='@')
    t.clear()
    sys.stdout = sys.__stdout__
    assert out.getvalue()[-10:].strip() == ''
    assert 'tqdm_telegram' in out.getvalue()
    # Test case with 2 clears
    out = io.StringIO()
    sys.stdout = out
    t = tqdm_telegram(range(10), token='@', chat_id='@')
    t.clear()
    t.clear()
    sys.stdout = sys.__stdout__

# Generated at 2022-06-22 05:15:27.637447
# Unit test for function trange
def test_trange():
    """
    Unit test for trange
    """
    for _ in trange(4, ncols=20, desc='_', mininterval=0.01,
                    token='463901220:AAG5I5XTbjl2X-7LTC_Dt-ejhxKCVCtFfds',
                    chat_id='832512800'):
        pass

# Generated at 2022-06-22 05:15:33.524764
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tgio = TelegramIO('1234567890', '-987654321')
    tgio.message_id = 12345
    future = tgio.delete()
    response = future.result()
    assert response.url == 'https://api.telegram.org/bot1234567890/deleteMessage'
    assert response.headers['Content-Type'] == 'application/x-www-form-urlencoded'
    assert response.request.body == 'chat_id=-987654321&message_id=12345'

# Generated at 2022-06-22 05:15:34.587496
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    assert TelegramIO('{token}', '{chat_id}').write('hello world')

# Generated at 2022-06-22 05:15:36.276204
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .tests_telegram import test_tqdm_telegram_display
    test_tqdm_telegram_display()

# Generated at 2022-06-22 05:15:37.058819
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    TelegramIO(token='', chat_id='')

# Generated at 2022-06-22 05:15:42.718653
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm.auto import tqdm
    from tqdm.utils import _decr_instances

    tgio = TelegramIO(
        token=getenv('TQDM_TELEGRAM_TOKEN'),
        chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'))

    old_instances, tqdm_auto.instances = tqdm_auto.instances, dict()

# Generated at 2022-06-22 05:15:46.919311
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    tgio = TelegramIO(token, chat_id)
    tgio.write('test')
    assert tgio.message_id
    tgio.delete()

# Generated at 2022-06-22 05:17:54.354568
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    import os
    import sys

    if sys.version_info[0] < 3:
        name = 'xrange'
    else:
        name = 'range'

    tqdm_telegram(name, disable=True)
    tqdm_telegram(name, token=os.getenv('TQDM_TELEGRAM_TOKEN', ''),
                  chat_id=os.getenv('TQDM_TELEGRAM_CHAT_ID', ''))

# Generated at 2022-06-22 05:17:56.868239
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from tqdm.utils import _term_move_up

    tgio = TelegramIO("token", "chat_id")
    tgio.write("test1")
    # _term_move_up(1)
    # tgio.write("test2")
    # _term_move_up(1)
    # tgio.write("test3")

# Generated at 2022-06-22 05:18:00.688459
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    telegramio = TelegramIO('739364479:AAHo-fVuwBGwg4I1zb4eB9XHVuGKBB5O5D0', '-200128399')
    telegramio.delete()

# Generated at 2022-06-22 05:18:08.346752
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import time
    fmt = ""
    chars = "-+*/"
    token = "726267861:AAE8FSlSe-jepDfZT-BZ9MG8W1GHEsxIFi0"
    chat_id = "211280495"

    for ch in chars:
        for i in tqdm(range(3), token = token, chat_id = chat_id,
                      unit_scale=True, unit='iB', postfix={"foo": 0}):
            time.sleep(0.01)
            fmt += ch
        time.sleep(0.1)
        assert fmt == "+++---+++---+++---"
        fmt = ""


if __name__ == '__main__':
    from ..utils import _test_env
    _test_env()
    test_t

# Generated at 2022-06-22 05:18:17.283004
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    """Testing the tqdm_telegram function"""
    class Token(object):
        """Token"""
        def __init__(self, token):
            self.token = token

        def __repr__(self):
            return "token='bot123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11'"

    token = Token("bot123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11")
    tqdm_telegram(xrange(10), token=token)
    ttgrange(20, token=token)
    tqdm(xrange(20), chat_id=456789, token=token)
    trange(20, chat_id=456789, token=token)

# Generated at 2022-06-22 05:18:28.349538
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    x = tqdm_telegram(total=1, unit='B', unit_scale=True,
                      miniters=1, mininterval=0.01, leave=True,
                      token='{token}', chat_id='{chat_id}')
    assert x.dynamic_mess
    x.n = 1
    x.display()
    x.close()
    x = tqdm_telegram(total=1, unit='B', unit_scale=True,
                      miniters=1, mininterval=0.01, leave=True,
                      token='{token}', chat_id='{chat_id}',
                      format='{bar:10u} {n_fmt_!s}/{total_fmt_!s}')
    assert x.dynamic_mess
    x.n = 1

# Generated at 2022-06-22 05:18:33.170170
# Unit test for function trange
def test_trange():
    """Unit test for trange"""
    from ..auto import trange
    # token and chat_id should be properly configured in `__main__`
    token = getenv('TQDM_TELEGRAM_TOKEN') or '{token}'
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID') or '{chat_id}'

    # Send a Telegram message
    for i in trange(3, desc='test', disable=False, ascii=True,
                    token=token, chat_id=chat_id):
        assert i == i  # do nothing

    # Should not send anything
    for i in trange(3, desc='test', disable=True, ascii=True,
                    token=token, chat_id=chat_id):
        assert i == i  # do nothing

# Generated at 2022-06-22 05:18:39.030384
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import tracemalloc
    tracemalloc.start()
    tqdm(exit=False).clear()
    tracemalloc.stop()
    snapshot = tracemalloc.take_snapshot()
    top_stats = snapshot.statistics('lineno')
    assert top_stats[0].count == 0
    assert top_stats[1].count == self.length

# Generated at 2022-06-22 05:18:46.448208
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    # Test close method when leave=False
    with tqdm_telegram(iterable=[1,2,3], leave=False, token='{token}', chat_id='{chat_id}') as pbar:
        for i in pbar:
            pass
    # Test close method when leave=True
    with tqdm_telegram(iterable=[1,2,3], leave=True, token='{token}', chat_id='{chat_id}') as pbar:
        for i in pbar:
            pass


# Generated at 2022-06-22 05:18:47.091999
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    pass