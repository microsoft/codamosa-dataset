

# Generated at 2022-06-22 05:12:02.624402
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from time import sleep
    from tqdm.contrib.telegram import tqdm_telegram

    with tqdm_telegram(total=10, leave=True, token='token', chat_id='chat_id') as t:
        for i in range(10):
            assert not t.disable
            t.update()
            t.clear()
            assert t.disable
            sleep(0.01)

    assert t.n == 10


# Generated at 2022-06-22 05:12:07.553074
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tgr = TelegramIO("token", "chat_id")
    tgr.submit(tgr.session.post, tgr.API + 'token/sendMessage', data={'text': '`text`',
               'chat_id': "chat_id", 'parse_mode': 'MarkdownV2'}).result()
    tgr.delete()

# Generated at 2022-06-22 05:12:12.319356
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    import sys
    import time
    with tqdm(total=10, file=sys.stdout, miniters=0, mininterval=0) as t:
        time.sleep(.1)
        t.telegram_io.submit(t.telegram_io.delete)()
        time.sleep(1)

# Generated at 2022-06-22 05:12:15.619422
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    for _ in tqdm(iterable=[], token='1', chat_id='2'):
        pass
    for _ in tqdm(iterable=[], token='1', chat_id='2', disable=True):
        pass

# Generated at 2022-06-22 05:12:17.938013
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    with tqdm_telegram(leave=True, total=1) as pbar:
        assert pbar.smoothing == 1

# Generated at 2022-06-22 05:12:29.768702
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm.utils import _term_move_up
    import logging as lg
    lg.getLogger('tqdm').setLevel(lg.CRITICAL)
    try:
        from io import StringIO
    except ImportError:
        from StringIO import StringIO
    f = StringIO()
    t = tqdm_telegram(0, file=f)
    t.display()
    assert '0it [00:00, ?it/s]' in f.getvalue()
    t.update()
    f.truncate(0)
    t.display()
    assert '1it [00:00, ?it/s]' in f.getvalue()
    t.close()
    f = StringIO()
    t = tqdm_telegram(8, file=f)

# Generated at 2022-06-22 05:12:41.608037
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from tqdm.contrib.telegram import tqdm
    from tqdm._version import __version__
    from os import getenv
    from sys import version_info
    from colorama import init
    init()
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if not token or not chat_id:
        raise Exception('Not given token or chat_id')
    else:
        with tqdm(total=100, token=token, chat_id=chat_id) as t:
            for i in range(100):
                t.update()

# Generated at 2022-06-22 05:12:45.216545
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    return
    tgio = TelegramIO('{token}', '{chat_id}')
    tgio.delete()


if __name__ == '__main__':
    try:
        import pytest
        pytest.main([__file__])
    finally:
        test_TelegramIO_delete()

# Generated at 2022-06-22 05:12:54.933203
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    t = TelegramIO(token="test_write_token", chat_id="test_chat_id")

    t.text = "test"
    t._message_id = 5

    # test if message_id is set to None if a request error occurs
    # should return None as error could not be catched
    t.session.request = lambda *args, **kwargs: None
    assert t.message_id is None

    # return 500 error code
    t.session.request = lambda *args, **kwargs: \
        {'status_code': 500, 'json': lambda: {}}

    # return 429 error code
    t.session.request = lambda *args, **kwargs: \
        {'status_code': 429, 'json': lambda: {}}
    assert t.message_id is None

    # message_id given by

# Generated at 2022-06-22 05:13:02.031115
# Unit test for function trange
def test_trange():
    """Test for telegram trange"""
    from .utils_test import vercmp
    from .utils_test import _TestTelegramIO, _tgio
    from .utils_test import pretest_posttest

    @pretest_posttest(teardown=lambda: _tgio.close())
    def test_trange(n):
        """Test for trange."""
        try:
            with _TestTelegramIO(name='TestTelegramIO') as io:
                trange(n, file=io)
        except Exception as e:
            # test OK if error is known
            assert vercmp(str(e), "TelegramIO.write") == 0
        else:
            assert False

    test_trange(10)

# Generated at 2022-06-22 05:14:30.322411
# Unit test for function trange
def test_trange():
    """Unit test for function trange."""
    def var_compare(var_name, val, exp_val, exp_type):
        var = eval(var_name)
        assert isinstance(var, exp_type), \
            "Type mismatch: variable '%s' should be of type %s" % (
                var_name, exp_type.__name__)
        assert var != val, "'%s' %s is not %s" % (var_name, var, val)
        assert var == exp_val, "'%s' %s does not match %s" % (
            var_name, var, exp_val)

    def check_trange(n, *args, **kwargs):
        var_compare('n', n, n, int)

# Generated at 2022-06-22 05:14:36.626209
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(['a','b','c'], 'test', total=3)
    assert t.leave == False
    assert t.pos == 0
    # set these variables to make close() return True
    t.leave = True
    t.disable = False
    t.pos = 3
    t.close()
    # set these variables to make close() return False
    t.leave = False
    t.disable = False
    t.pos = 0
    t.close()

# Generated at 2022-06-22 05:14:42.969580
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from unittest import TestCase, main
    from tqdm import tnrange

    tc = TestCase()

    # Test with a valid {token} and {chat_id}
    with tqdm(token='', chat_id='') as tq:
        for i in tnrange(1):
            pass
    tc.assertEqual(tq.dynamic_mess, "{bar:10}{r_bars}")
    tc.assertEqual(tq._instances, set())

    # Test with an invalid {token}
    def _test_invalid_token():
        with tqdm(token='', chat_id='') as tq:
            for i in tnrange(1):
                pass
    tc.assertRaises(ValueError, _test_invalid_token)



# Generated at 2022-06-22 05:14:46.437175
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tgio = TelegramIO('', '')
    try:
        tgio.delete()
    except:
        raise AssertionError
    return True

# Generated at 2022-06-22 05:14:49.393069
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Unit test for function trange"""
    from ..tqdm import trange
    from .utils_test import _test_telegram

    _test_telegram(trange)

# Generated at 2022-06-22 05:14:53.556201
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    try:
        import pytest
        p = pytest.importorskip("pytest")
    except:
        import unittest
        class TestTqdmTelegram(unittest.TestCase):
            pass



# Generated at 2022-06-22 05:15:05.045338
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    try:
        import collections
        collectionsAbc = collections.abc
    except AttributeError:
        import collections as collectionsAbc
    try:
        from requests.exceptions import ConnectionError
    except ImportError:
        from requests.packages.urllib3.exceptions import ConnectionError
    from unittest.mock import MagicMock

    class my_tqdm(tqdm_telegram):
        def __init__(self, iterable, **kwargs):
            super(my_tqdm, self).__init__(iterable, **kwargs)
            self.format_dict = kwargs

        def _format_meter(self):
            return '{{bar_format}}'.format(**self.format_dict)

    # Short version of ConnectionError

# Generated at 2022-06-22 05:15:07.503804
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    # test sending string
    tg = TelegramIO("testtoken", "testchatid")
    tg.write("teststring")
    tg.write("teststring2")


# Generated at 2022-06-22 05:15:17.103416
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tgio = TelegramIO('SOME_TOKEN_TEST', 'SOME_CHAT_ID_TEST')
    tgio.submit(tgio.write, '')
    tgio.flush()
    assert 'SOME_TOKEN_TEST' != tgio.token
    assert 'SOME_CHAT_ID_TEST' != tgio.chat_id
    assert tgio.message_id is not None
    assert tgio.text == 'TelegramIO'
    tgio.write('test')
    tgio.flush()
    assert tgio.text == 'test'

# Generated at 2022-06-22 05:15:18.253279
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    assert TelegramIO(token='{token}', chat_id='{chat_id}')

# Generated at 2022-06-22 05:18:11.699213
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    tgio = TelegramIO('xxxx', 'yyyy')
    tgio.write()
    tgio.delete()

# Generated at 2022-06-22 05:18:12.993047
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    a = TelegramIO("", "")
    a = TelegramIO("", "")

# Generated at 2022-06-22 05:18:17.077168
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    io = TelegramIO(token="123456789:TestToken", chat_id="123456789")
    io.write("Test")
    io.submit(io.write, "Test")

# Generated at 2022-06-22 05:18:28.134626
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import unittest
    import inspect

    def get_telegram_token():
        with open(__file__, "r") as f:
            tl = f.readline()
        if tl.startswith("TQDM_TELEGRAM_TOKEN"):
            t_token = tl.split("=")[1].strip()
        else:
            t_token = "00000000:AAAAAAA"
        return t_token

    def get_telegram_chat_id():
        with open(__file__, "r") as f:
            tl = f.readline()
        if tl.startswith("TQDM_TELEGRAM_CHAT_ID"):
            t_chat_id = tl.split("=")[1].strip()

# Generated at 2022-06-22 05:18:31.792784
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    io = TelegramIO('00000000:0000000000000000000000000000000000000000', '123456789')
    io.write("123")
    io.write("456")
    io.write("789")
    io.write("000")
    io.delete()

# Generated at 2022-06-22 05:18:33.522677
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from tqdm import tqdm
    from time import sleep

    with tqdm(total=100, desc="Test tqdm_telegram constructor") as pbar:
        for i in pbar:
            sleep(1)

# Generated at 2022-06-22 05:18:45.081996
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    # Initialize
    import time
    token = getenv('TQDM_TELEGRAM_TOKEN')
    if not token:
        print("!! telegram token is not defined !!")
        return
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if not chat_id:
        print("!! telegram chat_id is not defined !!")
        return
    telegram_msg = "**Unit test for method close in class tqdm_telegram**"

    # Test for default
    for _ in tqdm_telegram(range(3), token=token, chat_id=chat_id,
                           desc="Default: leave=False"):
        time.sleep(1)
    time.sleep(1)

    # Test for leave=True

# Generated at 2022-06-22 05:18:50.570724
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    tgio = TelegramIO(
        '<token>',
        '<chat_id>')
    assert tgio.token == '<token>'
    assert tgio.chat_id == '<chat_id>'
    assert repr(tgio) == "TelegramIO(token='<token>', chat_id='<chat_id>')"

# Generated at 2022-06-22 05:18:55.985666
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    tgio = TelegramIO(
        'token', 'chat_id')
    assert tgio.tgio == tgio
    assert tgio.token == 'token'
    assert tgio.chat_id == 'chat_id'
    assert tgio.session
    assert tgio.message_id

# Generated at 2022-06-22 05:18:59.231950
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    def mock_write(s):
        assert (s == ' ')
    t = tqdm([1], clear=True)
    t.tgio.write = mock_write
    t.close()