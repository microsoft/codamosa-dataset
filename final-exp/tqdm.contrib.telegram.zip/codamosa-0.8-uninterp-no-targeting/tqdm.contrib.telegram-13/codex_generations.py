

# Generated at 2022-06-22 05:14:52.664153
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    _t = ttgrange(5)
    for i in _t:
        if i >= 3:
            break
    _t.close()

# Generated at 2022-06-22 05:15:04.184144
# Unit test for function trange
def test_trange():
    """Test for trange."""
    from .utils import discretize_intervals, downscale_intervals
    from .gui import tgrange

    for cls in tgrange, ttgrange:
        for n in (1, 2, 3, 4):
            for leave in [None, True, False]:
                for total in [2, 3, 4, 5, 6]:
                    pbar = cls(total=total, leave=leave)
                    assert pbar.total == total
                    assert len(pbar) == 0
                    assert not pbar.disable
                    pbar.update(n)  # will also test __len__
                    assert len(pbar) == n
                    pbar.update()  # will also test __len__
                    assert len(pbar) == n + 1
                    pbar.update()  # will

# Generated at 2022-06-22 05:15:14.736148
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    TelegramIO(getenv('TQDM_TELEGRAM_TOKEN'), getenv('TQDM_TELEGRAM_CHAT_ID')).delete()


if __name__ == '__main__':  # pragma: no cover
    from os import sys
    r = tqdm(ttgrange(4),
             token=getenv('TQDM_TELEGRAM_TOKEN'),
             chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'))
    for _ in r:
        r.set_description("{name}: {n}/{total}".format(name=sys.argv[0], **r.format_dict))
        r.display(**r._time)
    r.close()

# Generated at 2022-06-22 05:15:17.800550
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    """
    This test checks that clear() does not throw an error
    """
    for _ in tqdm(range(5), token='{token}', chat_id='{chat_id}'):
        pass
    _.clear()

# Generated at 2022-06-22 05:15:26.597011
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    for i in tqdm_telegram(_range(3), token='937698250:AAH8ABNwR1sNpNfYsV4o4fDzouP9oAMTLiU', chat_id='646536647') :
        pass
    for i in tqdm_telegram(_range(3), token='937698250:AAH8ABNwR1sNpNfYsV4o4fDzouP9oAMTLiU', chat_id='646536647', leave=True) :
        pass

# Generated at 2022-06-22 05:15:29.252457
# Unit test for function trange
def test_trange():
    with trange(4, token='BOT_TOKEN', chat_id='CHAT_ID') as t:
        for i in t:
            assert i == t.n

# Generated at 2022-06-22 05:15:31.205266
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from .tests_telegram import test_tqdm_telegram
    test_tqdm_telegram()


# Generated at 2022-06-22 05:15:35.608498
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    with trange(10, token='{token}', chat_id='{chat_id}') as t:
        for i in t:
            t.set_description("Test trange")

if __name__ == '__main__':
    import sys
    if '--test' in sys.argv:
        test_trange()

# Generated at 2022-06-22 05:15:39.388477
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    TelegramIO(None, None).write(None)


if __name__ == '__main__':
    from doctest import testmod
    testmod(verbose=True)

# Generated at 2022-06-22 05:15:44.287242
# Unit test for function trange
def test_trange():
    import time
    for _ in trange(3, token=getenv('TQDM_TELEGRAM_TOKEN'),
                    chat_id=getenv('TQDM_TELEGRAM_CHAT_ID')):
        time.sleep(0.1)


if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-22 05:17:56.974493
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    class TestClass:
        str_io = None

    class TestTqdmTelegram(tqdm_telegram):
        def __init__(self, *args, **kwargs):
            super(TestTqdmTelegram, self).__init__(*args, **kwargs)
            self.tgio = TelegramIO(TestClass.str_io)

    TestClass.str_io = StringIO()
    t = TestTqdmTelegram(iterable=range(20), leave=True,
                       bar_format='{l_bar}{bar}{r_bar}',
                       mininterval=0, miniters=1)
    for _ in t:
        pass
    assert len(TestClass.str_io.getvalue().strip().split('\n')) == 20

    TestClass.str_io = StringIO()


# Generated at 2022-06-22 05:18:06.563107
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from subprocess import check_output
    from time import sleep
    try:
        # In case of running tests inside a call to "tqdm_telegram"
        {'leave': True}.pop('leave')
    except KeyError:
        return
    with ttgrange(2, 0, -1, leave=True) as pbar:
        sleep(.1)
        pbar.close()
    try:
        # In case of running tests inside a call to "tqdm_telegram"
        {'leave': None}.pop('leave')
    except KeyError:
        return
    with ttgrange(0) as pbar:
        sleep(.1)
        pbar.close()
    with ttgrange(2) as pbar:
        sleep(.1)
        pbar.close()
   

# Generated at 2022-06-22 05:18:16.354266
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    # In following test case, close method should not delete the message.
    with tqdm(total=10) as pbar:
        while not pbar.n == pbar.total:
            pbar.update()
            if pbar.n == int(pbar.total * 0.5):
                pbar.close()
    # In following test case, close method should delete the message.
    with tqdm(total=10) as pbar:
        while not pbar.n == pbar.total:
            pbar.update()
            if pbar.n == int(pbar.total * 0.50):
                pbar.close(leave=False)
    # In following test case, close method should delete the message.

# Generated at 2022-06-22 05:18:22.059269
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    telegram_msg = "  0%|                                                    | 0/10 [00:00<?, ?it/s]"
    out = tqdm_telegram(total=10)
    out.display()
    assert telegram_msg in out.format_dict['postfix'][-1]


if __name__ == '__main__':
    from pytest import main
    main([__file__])

# Generated at 2022-06-22 05:18:27.974316
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from random import randint
    token =  getenv('TQDM_TELEGRAM_TOKEN')
    chat_id =  getenv('TQDM_TELEGRAM_CHAT_ID')
    s = 'test_write_'+str(randint(0,10000))
    ti = TelegramIO(token, chat_id)
    assert ti.message_id
    ti.write(s)

# Generated at 2022-06-22 05:18:38.290980
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    global flag
    flag = False
    t = ttgrange(0,1,1,disable=True)
    t.close()
    assert flag
    flag = False
    t = ttgrange(0,1,1,leave=True,disable=True)
    t.close()
    assert flag
    flag = False
    t = ttgrange(0,1,1,leave=None,disable=True)
    t.close()
    assert not flag
    flag = False
    t = ttgrange(0,1,1,disable=True)
    t.close()
    assert not flag
    flag = False
    t = ttgrange(0,2,2,leave=True,disable=True)
    t.close()
    assert flag
    flag = False
    t = ttgr

# Generated at 2022-06-22 05:18:41.388317
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    # Tests the method write of class TelegramIO
    ti = TelegramIO(token='000000000:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
                    chat_id='00000000')
    ti.write('test')

# Generated at 2022-06-22 05:18:51.669330
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    # pylint: disable=protected-access
    tgr = tqdm_telegram(3)
    tgr.tgio._message_id = '123'
    tgr.tgio = None  # to disable delete
    tgr.close()
    tgr = tqdm_telegram(3)
    tgr.tgio._message_id = '123'
    tgr.tgio = None  # to disable delete
    tgr.close(False)
    tgr = tqdm_telegram(3)
    tgr.tgio._message_id = '123'
    tgr.tgio = None  # to disable delete
    tgr.leave = None
    tgr.close()


# Generated at 2022-06-22 05:18:56.533572
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    import sys
    try:
        list(tqdm_telegram('123'))
    except TypeError as e:
        if "'token'" in str(e):
            return
    raise RuntimeError("Should have raised TypeError")

if __name__ == "__main__":
    test_tqdm_telegram()

# Generated at 2022-06-22 05:18:59.392004
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    io = TelegramIO('123456789abcdef', '012345678')
    io.write('text')
    io.delete()
    io.close()