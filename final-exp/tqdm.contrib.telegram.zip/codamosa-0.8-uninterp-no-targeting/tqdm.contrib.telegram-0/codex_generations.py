

# Generated at 2022-06-22 05:11:27.372245
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    for i in tqdm([1, 2, 3]):
        pass

# Generated at 2022-06-22 05:11:38.068913
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    """Unit test for method delete of class TelegramIO."""
    from os import getenv
    from sys import modules
    from tqdm.auto import tqdm
    from .tests_telegram_token import TOKEN, CHAT_ID
    # Prevent tqdm from raising TQDM_TELEGRAM_TOKEN/CHAT_ID not set errors
    setattr(modules[__name__], '__name__', '__main__')
    getenv.__self__.get.side_effect = lambda x, d=None: globals().get(x.upper())
    # Try deleting a non-existent message
    tgio = TelegramIO(TOKEN, CHAT_ID)
    tqdm(tgio.delete())
    # Try deleting an existing message

# Generated at 2022-06-22 05:11:41.765036
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """test_tqdm_telegram_close"""
    tq_test = tqdm_telegram(range(10))
    tq_test.close()

# test_tqdm_telegram_close()

# Generated at 2022-06-22 05:11:52.511830
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    # type: () -> None
    import sys
    import re
    import platform
    import multiprocessing

    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    assert token, "Please define TQDM_TELEGRAM_TOKEN env variable"
    assert chat_id, "Please define TQDM_TELEGRAM_CHAT_ID env variable"
    try:
        from requests import post
    except ImportError:
        print("Skipping integration test (requires requests)")
        return

    def _get_telegram(token, chat_id):
        import requests
        from .utils_worker import MonoWorker
        from .utils_telegram_tqdm import TelegramIO
        session = requests.Session

# Generated at 2022-06-22 05:12:03.979278
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm._utils import SimpleTextIOWrapper
    from io import StringIO
    from threading import Timer
    import time
    import json

    # Extract the result of the requests.Session.post method
    def _post_test(test_values, dest, **kwargs):
        json_response = json.dumps(test_values)
        dest.write_now(json_response + "\n")

    # Mock the result of the requests.get method
    def _get_test(self, values):
        self._post_test(values, self.dest)
        self._post_test(values, self.dest)
        self._post_test(values, self.dest)

    # Initialize a mocked object
    dest = StringIO()
    tgio = TelegramIO(session=Session())

# Generated at 2022-06-22 05:12:12.275321
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    """Test for tqdm_telegram, prints updates to a Telegram Bot."""
    from time import sleep
    with tqdm_telegram(total=5, desc='test', **{
            'token': '123456789:ABCD-123456789xxxYYYabcdefghijklmnopqrstuvw',
            'chat_id': '123456789'}) as t:
        for i in range(5):
            sleep(.2)
            t.update()


if __name__ == "__main__":
    test_tqdm_telegram()

# Generated at 2022-06-22 05:12:18.086555
# Unit test for function trange
def test_trange():
    """Test for `tqdm.contrib.telegram.trange()`"""
    from .utils import _test_resize
    _test_resize(trange, make_args=lambda t: (t,))
    _test_resize(trange, make_args=lambda t: (t, t))
    _test_resize(trange, make_args=lambda t: (t, t, t//2))

# Generated at 2022-06-22 05:12:29.945116
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from tqdm.tests import tests
    import time
    import random
    import gc
    time.sleep(3)
    # Uncomment to test
    # tqdm.write("*** TelegramIO tests")
    tgio = TelegramIO("123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11",
                      "1122334455")
    N = 5
    tests.write_center(str(tgio.message_id))
    for i in tgio.write("test TelegramIO: %i" % random.randint(1, N)):
        time.sleep(0.1)
    gc.collect()  # force message deletion
    time.sleep(0.5)
    gc.collect()  # force message deletion
    time.sleep(0.5)
   

# Generated at 2022-06-22 05:12:34.651534
# Unit test for function trange
def test_trange():
    """
    Unit test for `trange`
    """
    # First simple case, with no Telegram token and no chat ID
    with trange(10) as t:
        for i in t:
            assert t.last_print_t - t.start_t <= t.miniters
            t.update()
    # Second simple case, with a Telegram token but no chat ID
    with trange(10, token='{token}') as t:
        for i in t:
            assert t.last_print_t - t.start_t <= t.miniters
            t.update()
    # Third simple case, with no Telegram token but a chat ID
    with trange(10, chat_id='{chat_id}') as t:
        for i in t:
            assert t.last_print_t - t.start

# Generated at 2022-06-22 05:12:39.400398
# Unit test for function trange
def test_trange():
    """Unit test for trange"""
    with trange(1, token='{token}', chat_id='{chat_id}') as t:
        for i in t:
            assert i == 0
            break

# Generated at 2022-06-22 05:14:06.999728
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    Session().post("https://api.telegram.org/bot{token}/getMe".format(token=getenv('TQDM_TELEGRAM_TOKEN')))

# Generated at 2022-06-22 05:14:18.056189
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    """ unit test for class TelegramIO """
    # pylint: disable=anomalous-backslash-in-string
    io = TelegramIO("1234:ABCD", "-987654321")
    io.write("")
    io.write("-")
    io.write("abc")
    io.write("defgh")
    io.write("xyz")
    io.write("a")
    io.write("b")
    io.write("c")
    io.write("d")
    io.message_id
    io.write("e")
    io.write("f")
    io.write("g")
    io.write("h")
    io.write("i")
    io.write("")
    io.write("")
    io.write("")
    io.delete()

# Generated at 2022-06-22 05:14:22.316289
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    io = io()
    with tqdm_telegram(total=10, file=io) as pbar:
        fmt = pbar.format_dict
        assert fmt.get('bar_format', None)
    assert io.getvalue().strip() == ''



# Generated at 2022-06-22 05:14:30.282016
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from io import StringIO
    try:
        from nose import with_setup
        with_setup
    except ImportError:  # nose does not exist
        with_setup = lambda func, setup_func: func  # noqa: E731
    buf = StringIO()

    def tear_down():
        buf.close()
        tqdm_telegram.screen_format = "%-*s %*s%s"

    @with_setup(None, tear_down)
    def _test_tqdm_telegram_display():
        """Test tqdm_telegram display"""
        # test normal behavior
        tqdm_telegram.screen_format = "%-*s %*s%s"
        t = tqdm_telegram(total=5, file=buf)

# Generated at 2022-06-22 05:14:33.293897
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    TelegramIO(
        token='986467806:AAFChJhZw97pZGm6zEkM8m_mh2nCq3Y6Y2E',
        chat_id='62760543')

# Generated at 2022-06-22 05:14:39.039245
# Unit test for function trange
def test_trange():
    for _ in trange(2, 3, token='A', chat_id='B'):
        pass  # xdoctest: +ELLIPSIS
    for _ in tqdm(iterable=_range(3), token='A', chat_id='B'):
        pass
    for _ in ttgrange(2, 3, token='A', chat_id='B'):
        pass
    for _ in ttgrange(3, token='A', chat_id='B'):
        pass
    for _ in tqdm(iterable=_range(3)):
        pass

# Generated at 2022-06-22 05:14:42.994499
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    class TE(TelegramIO):
        def __init__(self, *args, **kwargs):
            self._message_id = 0
            self.submit = lambda x, y, z: print(x, y, z)

    t = TE(token='', chat_id='')
    t.delete()

# Generated at 2022-06-22 05:14:49.849703
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    io = TelegramIO(TOKEN, CHAT_ID)
    io.write('Some text')
    io.write('Some text')
    io.write('\n')
    io.write('')
    io.write('Some text')
    io.close()

if __name__ == '__main__':
    TOKEN = 'token'
    CHAT_ID = 'chat_id'
    test_TelegramIO_write()

# Generated at 2022-06-22 05:14:54.768386
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    import time
    with tqdm(_range(10), token='123456789:AAHkcj0F9IIp_o08Yp_gZwqIs1', chat_id='-1001194376230') as t:
        for i in t:
            if i == 1:
                t.close()
                time.sleep(1)

# Generated at 2022-06-22 05:14:58.789046
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    token = "{token}"
    chat_id = "{chat_id}"
    ti = TelegramIO(token, chat_id)
    ti.close()

if __name__ == "__main__":
    test_TelegramIO()

# Generated at 2022-06-22 05:18:03.461728
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from os import environ
    from time import sleep

    try:
        import pandas
        from pandas._testing import is_categorical_dtype

        environ['TQDM_DISABLE'] = ""
        if not is_categorical_dtype(pandas.CategoricalDtype):
            if hasattr(pandas, '__version__'):
                if pandas.__version__.split('.') >= ['1', '1']:
                    environ['TQDM_DISABLE'] = ""
            elif hasattr(pandas, '__version__'):
                if pandas.__version__.split('.') >= ['1', '1']:
                    environ['TQDM_DISABLE'] = ""
    except:
        pass


# Generated at 2022-06-22 05:18:11.276443
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    import sys
    from requests import ReadTimeout

    try:
        TelegramIO("", "")  # missing args
    except ValueError:
        pass
    else:
        sys.exit("`ValueError` not raised!")

    try:
        TelegramIO("", "1").text = "test"  # missing args
    except (ReadTimeout, Exception):
        pass
    else:
        sys.exit("`%s` not raised!" % ReadTimeout.__name__)

if __name__ == "__main__":
    test_TelegramIO()

# Generated at 2022-06-22 05:18:17.078426
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    # pylint: disable=W0212
    # pylint: disable=C0103
    tg = TelegramIO("token", "chat_id")
    assert tg.tgio._message_id is None
    tg.tgio.write("this is a test message")
    assert tg.tgio._message_id is not None



# Generated at 2022-06-22 05:18:24.251737
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from .version import __version__
    # Test leave and not pos
    telegramIO = TelegramIO("fakeToken", "fakeChatId")
    tqdm_telegram_test = tqdm_telegram(["fake_iterable"], leave=True,
                                       file=telegramIO)
    tqdm_telegram_test.close()

    # Test not leave and pos
    telegramIO = TelegramIO("fakeToken", "fakeChatId")
    tqdm_telegram_test = tqdm_telegram([], leave=False,
                                       file=telegramIO)
    tqdm_telegram_test.close()

    # Test not leave and not pos
    telegramIO = TelegramIO("fakeToken", "fakeChatId")

# Generated at 2022-06-22 05:18:32.124866
# Unit test for function trange
def test_trange():
    """Basic unit tests for `tqdm.contrib.telegram.trange`"""
    from ..utils import _supports_unicode
    with tqdm(trange(3), ascii=True, unit='th') as pbar:
        pbar.write('Hello World')
    with tqdm(trange(3), unit='th') as pbar:
        pbar.write('Hello World')
        if _supports_unicode():
            pbar.write('żółć')


if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-22 05:18:33.313844
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tio = TelegramIO('token', 'chat_id')
    assert tio.write('abc').result().text == 'abc'



# Generated at 2022-06-22 05:18:35.962566
# Unit test for function trange
def test_trange():
    """Testing trange function"""
    assert list(trange(10)) == list(range(10))

# Generated at 2022-06-22 05:18:45.421474
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    """
    Unit test for method delete of class TelegramIO
    """
    import os
    import pytest
    # Create an instance of class TelegramIO
    token = os.environ.get('TQDM_TELEGRAM_TOKEN')
    chat_id = os.environ.get('TQDM_TELEGRAM_CHAT_ID')
    if token is None or chat_id is None:
        pytest.skip(
            'Environment variables TQDM_TELEGRAM_TOKEN or '
            'TQDM_TELEGRAM_CHAT_ID not found')
    telegramIO = TelegramIO(token, chat_id)
    # Test method delete
    assert telegramIO.delete()

# Generated at 2022-06-22 05:18:47.624909
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    t = tqdm_telegram(range(10), token='1234', chat_id='12345')
    t.clear()

# Generated at 2022-06-22 05:18:50.070542
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from .utils_test import _test_close
    with _test_close('', [0, 3, 6]) as bar:
        for i in bar:
            pass