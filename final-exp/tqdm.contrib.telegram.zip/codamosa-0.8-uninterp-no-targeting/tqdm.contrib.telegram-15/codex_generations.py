

# Generated at 2022-06-22 05:13:31.071861
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    try:
        TelegramIO(token="", chat_id="")
    except Exception:
        pass

# Generated at 2022-06-22 05:13:34.167119
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    io = TelegramIO(token='123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZ-abcdefg',
                    chat_id=123456789)
    io.write('Test')



# Generated at 2022-06-22 05:13:43.489305
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from time import sleep
    from nose.plugins.skip import SkipTest
    try:
        chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
        token = getenv('TQDM_TELEGRAM_TOKEN')
        pbar = tqdm_telegram(total=100, token=token, chat_id=chat_id)
        assert pbar.n == 0
        pbar.update(n=10)
        sleep(1)
        assert pbar.n == 10
    except Exception as e:
        raise SkipTest(str(e) + "\nTQDM_TELEGRAM_CHAT_ID & TQDM_TELEGRAM_TOKEN "
                       "environment variables required for test_tqdm_telegram_display()")

# Generated at 2022-06-22 05:13:45.371235
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    """Merely test that we can initialise the class"""
    tqdm_telegram(token='foo', chat_id='bar')

# Generated at 2022-06-22 05:13:51.653860
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from os import environ
    from os.path import dirname, join as pathjoin
    from shutil import rmtree
    from sys import executable as sys_exec
    from tempfile import mkdtemp

    test_tokens = []
    if 'TQDM_TELEGRAM_TOKEN' not in environ:
        try:
            me = join(dirname(__file__), 'me.txt')
            with open(me) as f:
                test_tokens = [t.strip() for t in f.readlines()]
        except Exception:
            pass
    test_chat_id = []

# Generated at 2022-06-22 05:13:54.189790
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from time import sleep
    from tqdm.contrib.telegram import tqdm, trange
    for i in tqdm(range(5), token='{token}', chat_id='{chat_id}'):
        sleep(1)
    for i in trange(5, token='{token}', chat_id='{chat_id}'):
        sleep(1)


if __name__ == '__main__':
    test_tqdm_telegram()

# Generated at 2022-06-22 05:13:58.454515
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    """Unit test for method write of class TelegramIO"""
    import io

    class MockResponse:
        def __init__(self, status_code, text):
            self.status_code = status_code
            self.text = text

    class MockSession:
        def post(self, url, data):
            return MockResponse(200, '{"result":{"message_id":1}}')

    class MockMessage(TelegramIO):
        def __init__(self, token, chat_id):
            super(MockMessage, self).__init__(token, chat_id)
            self.token = token
            self.chat_id = chat_id
            self.session = MockSession()
            self.text = ''
            self.message_id = 0

# Generated at 2022-06-22 05:14:00.757776
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    try:
        if TelegramIO('test_token', 'test_chat_id').message_id is None:
            raise ValueError("telegram-tqdm unit test failed!")
    except Exception as e:
        raise ValueError("telegram-tqdm unit test failed {}".format(e)) from e


if __name__ == '__main__':
    test_tqdm_telegram_close()

# Generated at 2022-06-22 05:14:09.321653
# Unit test for constructor of class tqdm_telegram

# Generated at 2022-06-22 05:14:18.055223
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():

    import time
    import sys
    import io

    i, max_iter = 0, 5
    t = tqdm_telegram(total=max_iter, file=sys.stdout, leave=True, ascii=True)

    while i <= max_iter:
        t.clear()
        t.display()
        tqdm_auto.write('\n')
        time.sleep(0.1)
        i += 1

    t.close()
    t.close()  # test for error

if __name__ == '__main__':
    test_tqdm_telegram_clear()

# Generated at 2022-06-22 05:16:18.435239
# Unit test for function trange
def test_trange():
    l = list(trange(10))
    assert l == list(range(10))

# Generated at 2022-06-22 05:16:27.090704
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    """
    Unit test `tqdm_telegram`'s `clear` method.
    Associate `tqdm_telegram`'s `display` method to an object (a class),
    and ensure the object doesn't raise any errors by calling its `clear`
    method.
    """
    # pylint: disable=missing-class-docstring

    class TestTqdmTelegram:
        """
        Class used to test `tqdm_telegram`'s `clear` method.
        It is used because both `tqdm` and `trange` are classes,
        so we need to associate tqdm_telegram's `display` method
        to an object to test `clear`.
        """

# Generated at 2022-06-22 05:16:37.407337
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    """Unit test for write method of TelegramIO class"""
    import requests
    import pytest

    token = '1009085006:AAG6v-8fhO4oTAwAK4Q1Bikv_8WNE1cX0yM'
    chat_id = '367515487'
    tgio = TelegramIO(token, chat_id)
    assert hasattr(tgio, 'message_id'), (
        "message_id property of TelegramIO class wasn't returned.")
    tgio.write("Test message")
    assert hasattr(tgio, 'text'), (
        "text property of TelegramIO class wasn't returned.")
    tgio.close()

# Generated at 2022-06-22 05:16:47.734578
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    """
    Test the method clear of the class tqdm_telegram.
    """
    from time import sleep
    from tqdm import tqdm
    from tqdm.contrib.telegram import tqdm_telegram
    items = range(10)
    for i in tqdm(items, desc="Cleaning", ncols=80, ascii=True,
                  postfix=None, unit="nit"):
        tqdm_telegram.clear()
        print("\033[F\033[K" + "Cleaning: " + str(i))
        sleep(1)



# Generated at 2022-06-22 05:16:51.195804
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    assert TelegramIO("", "").write("1234567890") is None
    assert TelegramIO.__doc__, "__doc__ is empty"
    assert tqdm_telegram, "__doc__ is empty"
    assert trange, "__doc__ is empty"

# Generated at 2022-06-22 05:16:52.445790
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from .test_tqdm_telegram import main
    main()

# Generated at 2022-06-22 05:16:59.889189
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    """Unit-test for TelegramIO.delete().

    Check if deleting a message works without warnings.
    """

    from tqdm.contrib.telegram import TelegramIO
    from os import environ

    token = environ.get('TQDM_TELEGRAM_TOKEN', None)
    chat_id = environ.get('TQDM_TELEGRAM_CHAT_ID', None)

    if token is None or chat_id is None:
        # TelegramIO.delete() cannot be tested w/o a token or chat_id
        pass
    else:
        io = TelegramIO(token, chat_id)
        io.write("testing")
        io.delete()

# Generated at 2022-06-22 05:17:10.147851
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    token, chat_id = getenv('TQDM_TELEGRAM_TOKEN'), getenv('TQDM_TELEGRAM_CHAT_ID')
    if token and chat_id:
        tgio = TelegramIO(token, chat_id)
        assert tgio.message_id is not None
        assert tgio.delete() is not None
    else:
        print('test_TelegramIO_delete:',
              'To run the tests, please set the environment variables',
              '$TQDM_TELEGRAM_TOKEN and $TQDM_TELEGRAM_CHAT_ID to Telegram',
              'Bot token and chat ID, respectively.')



# Generated at 2022-06-22 05:17:18.770431
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    """Unit test for method display of class tqdm_telegram."""
    pass
    # t = tqdm(desc='test_tqdm_telegram_display', unit='it', total=9,
    #         disable=True)
    # t.display(n=0, total=10)
    # t.display(n=1, total=10)
    # t.display(n=2, total=10)
    # t.display(n=3, total=10)
    # t.display(n=4, total=10)
    # t.display(n=5, total=10)
    # t.display(n=6, total=10)
    # t.display(n=7, total=10)
    # t.display(n=8, total=10)
    # t.display

# Generated at 2022-06-22 05:17:27.340950
# Unit test for function trange
def test_trange():
    from time import sleep
    from .compatibility import PY2
    if PY2:
        from tqdm._utils import _range
    else:
        from tqdm._utils import _range as _range2

    def test_func(N):
        for _ in trange(N):
            sleep(.01)  # long-running task
        return 42

    # Uncomment the following lines to test a Telegram bot:
    # token = "{token}"
    # chat_id = "{chat_id}"
    # ret = test_func(50)
    # assert ret == 42

    # Default parameter
    assert len(list(tqdm(range(5)))) == 5

    # Iterable as parameter
    assert len(list(tqdm(_range(5)))) == 5

    # Iterable + ncols
    assert len