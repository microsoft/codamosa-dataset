

# Generated at 2022-06-18 11:26:55.209920
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(total=10, leave=True)
    t.close()
    assert t.tgio.message_id is None
    t = tqdm_telegram(total=10, leave=False)
    t.close()
    assert t.tgio.message_id is None
    t = tqdm_telegram(total=10, leave=None)
    t.close()
    assert t.tgio.message_id is None
    t = tqdm_telegram(total=10, leave=None)
    t.update(10)
    t.close()
    assert t.tgio.message_id is None

# Generated at 2022-06-18 11:27:03.960919
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from io import StringIO
    from sys import stdout
    from time import sleep
    from tqdm import tqdm_telegram
    from tqdm.utils import _term_move_up
    from tqdm.contrib.telegram import TelegramIO

    # Create a fake TelegramIO object
    class FakeTelegramIO(TelegramIO):
        def __init__(self, *args, **kwargs):
            self.text = ''
            self.message_id = 0
        def write(self, s):
            self.text = s
        def delete(self):
            pass

    # Create a fake stdout
    stdout = StringIO()

    # Create a tqdm object
    t = tqdm_telegram(total=10, file=stdout, tgio=FakeTelegramIO())

    # Test

# Generated at 2022-06-18 11:27:09.754626
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.auto import tqdm
    from time import sleep
    from sys import stderr

    for i in tqdm_telegram(range(10), token='{token}', chat_id='{chat_id}'):
        sleep(0.1)

# Generated at 2022-06-18 11:27:16.879222
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from io import StringIO
    from sys import stdout
    from tqdm import tqdm as tqdm_base
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.utils import _term_move_up

    # Test tqdm_telegram.display()
    with StringIO() as f:
        with tqdm_telegram(total=10, file=f, leave=False,
                           bar_format='{l_bar}{bar:10u}{r_bar}') as t:
            for i in range(10):
                t.update()
        assert f.getvalue() == _term_move_up() + '\r' + '{l_bar}{bar:10u}{r_bar}'

    # Test tqdm_telegram.display() with

# Generated at 2022-06-18 11:27:25.094629
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    """
    Unit test for method write of class TelegramIO
    """
    import os
    import sys
    import time
    import unittest

    from .utils_test import _test_write

    class TelegramIOTest(unittest.TestCase):
        def test_write(self):
            """
            Unit test for method write of class TelegramIO
            """
            _test_write(TelegramIO, 'TQDM_TELEGRAM_TOKEN', 'TQDM_TELEGRAM_CHAT_ID')

    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-18 11:27:33.713622
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    """
    Unit test for method clear of class tqdm_telegram.
    """
    import sys
    from io import StringIO
    from tqdm import tqdm
    from tqdm.contrib.telegram import tqdm_telegram

    # Test for tqdm
    with StringIO() as f:
        sys.stdout = f
        tqdm(range(10), desc='Test for tqdm', leave=False).clear()

# Generated at 2022-06-18 11:27:43.233640
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import sys
    import time
    from os import getenv
    from requests import Session
    from tqdm.contrib.telegram import TelegramIO
    from tqdm.utils import _range

    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if not (token and chat_id):
        sys.exit("Please set the environment variables "
                 "TQDM_TELEGRAM_TOKEN and TQDM_TELEGRAM_CHAT_ID")

    tgio = TelegramIO(token, chat_id)
    tgio.write("Hello world!")
    for i in _range(10):
        tgio.write("%d" % i)
        time.sleep(1)

# Generated at 2022-06-18 11:27:49.628147
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.auto import tqdm
    from time import sleep
    from os import getenv
    from requests import Session
    from requests.exceptions import ConnectionError
    from warnings import warn
    from ..utils import _range

    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if not (token and chat_id):
        warn("TQDM_TELEGRAM_TOKEN and TQDM_TELEGRAM_CHAT_ID must be set.")
        return

    session = Session()

# Generated at 2022-06-18 11:27:51.348955
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .utils_test import _test_display
    _test_display(tqdm_telegram)

# Generated at 2022-06-18 11:27:53.708423
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(total=2, leave=False)
    t.close()
    t = tqdm_telegram(total=2, leave=True)
    t.close()

# Generated at 2022-06-18 11:29:57.046974
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .utils_test import _test_display
    _test_display(tqdm_telegram)

# Generated at 2022-06-18 11:30:05.327964
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.auto import tqdm
    from tqdm.utils import _term_move_up
    from time import sleep
    from sys import stdout
    from io import StringIO
    from unittest import TestCase, main

    class TestTqdmTelegramDisplay(TestCase):
        def setUp(self):
            self.stdout = stdout
            self.stdout_fd = stdout.fileno()
            self.stdout_str = StringIO()
            stdout.close()
            stdout = open(self.stdout_fd, 'w', encoding='utf-8')
            stdout.write('')
            stdout.flush()
            stdout.close()

# Generated at 2022-06-18 11:30:08.438520
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import time
    t = tqdm_telegram(total=10, leave=False)
    for i in range(10):
        t.update()
        time.sleep(0.1)
    t.clear()
    t.close()

# Generated at 2022-06-18 11:30:10.385736
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from .utils_test import _test_clear
    _test_clear(tqdm_telegram)

# Generated at 2022-06-18 11:30:16.914848
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(total=1, leave=False)
    t.close()
    assert t.tgio.message_id is None
    t = tqdm_telegram(total=1, leave=True)
    t.close()
    assert t.tgio.message_id is not None
    t = tqdm_telegram(total=1, leave=None)
    t.close()
    assert t.tgio.message_id is None
    t = tqdm_telegram(total=1, leave=None)
    t.update(1)
    t.close()
    assert t.tgio.message_id is not None

# Generated at 2022-06-18 11:30:26.405062
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    import time
    from tqdm.contrib.telegram import tqdm, trange
    for i in trange(10, token='{token}', chat_id='{chat_id}'):
        time.sleep(0.1)
    for i in trange(10, token='{token}', chat_id='{chat_id}', leave=True):
        time.sleep(0.1)
    for i in trange(10, token='{token}', chat_id='{chat_id}', leave=False):
        time.sleep(0.1)
    for i in trange(10, token='{token}', chat_id='{chat_id}', leave=None):
        time.sleep(0.1)

# Generated at 2022-06-18 11:30:36.634210
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from os import getenv
    from time import sleep
    from tqdm.contrib.telegram import tqdm, trange
    from tqdm.contrib.telegram.utils_worker import MonoWorker
    from tqdm.contrib.telegram.utils_worker import _Worker
    from tqdm.contrib.telegram.utils_worker import _WorkerPool
    from tqdm.contrib.telegram.utils_worker import _WorkerPoolExecutor
    from tqdm.contrib.telegram.utils_worker import _WorkerPoolThread
    from tqdm.contrib.telegram.utils_worker import _WorkerThread
    from tqdm.contrib.telegram.utils_worker import _WorkerProcess
    from tqdm.contrib.telegram.utils_worker import _Worker

# Generated at 2022-06-18 11:30:39.024420
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tgio = TelegramIO('token', 'chat_id')
    tgio.write('test')


# Generated at 2022-06-18 11:30:47.526746
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from os import environ
    from time import sleep
    from tqdm import tqdm
    from tqdm.contrib.telegram import tqdm_telegram

    environ['TQDM_TELEGRAM_TOKEN'] = '123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    environ['TQDM_TELEGRAM_CHAT_ID'] = '123456789'

    for i in tqdm(range(10)):
        sleep(0.1)

    for i in tqdm_telegram(range(10)):
        sleep(0.1)

# Generated at 2022-06-18 11:30:55.812620
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from time import sleep
    from tqdm.auto import tqdm
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.contrib.telegram import ttgrange
    from tqdm.contrib.telegram import tqdm
    from tqdm.contrib.telegram import trange

    for cls in (tqdm, tqdm_telegram, ttgrange, tqdm, trange):
        with cls(total=10, token='{token}', chat_id='{chat_id}') as pbar:
            for i in range(5):
                pbar.update()
                sleep(0.1)
            pbar.clear()
            for i in range(5):
                pbar.update()
                sleep(0.1)

# Generated at 2022-06-18 11:33:15.596196
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    import time
    from tqdm.contrib.telegram import tqdm, trange
    for i in trange(10, token='{token}', chat_id='{chat_id}'):
        time.sleep(.1)
    for i in trange(10, token='{token}', chat_id='{chat_id}', leave=True):
        time.sleep(.1)
    for i in trange(10, token='{token}', chat_id='{chat_id}', leave=False):
        time.sleep(.1)
    for i in trange(10, token='{token}', chat_id='{chat_id}', leave=None):
        time.sleep(.1)