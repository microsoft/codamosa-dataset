

# Generated at 2022-06-18 11:29:52.263128
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .utils_test import _test_display
    _test_display(tqdm_telegram)

# Generated at 2022-06-18 11:29:53.633963
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .utils_test import _test_display
    _test_display(tqdm_telegram)

# Generated at 2022-06-18 11:29:58.897396
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.auto import tqdm
    from time import sleep
    for _ in tqdm(range(10), token='{token}', chat_id='{chat_id}'):
        sleep(0.1)
    for _ in tqdm(range(10), token='{token}', chat_id='{chat_id}'):
        sleep(0.1)
        tqdm.clear()


# Generated at 2022-06-18 11:29:59.972230
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tg = TelegramIO('token', 'chat_id')
    tg.delete()

# Generated at 2022-06-18 11:30:08.654638
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.auto import tqdm
    from tqdm.utils import _term_move_up
    from time import sleep
    from os import getenv
    from os.path import join
    from os import getcwd
    from os import remove
    from os import listdir
    from os import mkdir
    from os import rmdir
    from os import getenv
    from os.path import isdir
    from os.path import isfile
    from os.path import exists
    from os.path import abspath
    from os.path import dirname
    from os.path import basename
    from os.path import join
    from os.path import expanduser
    from os.path import expandvars
    from os.path import normpath


# Generated at 2022-06-18 11:30:10.620321
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .utils_test import _test_display
    _test_display(tqdm_telegram)

# Generated at 2022-06-18 11:30:18.410560
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import sys
    from io import StringIO
    from tqdm.auto import tqdm

    # Test with bar_format
    with StringIO() as f:
        with tqdm(total=10, file=f, bar_format='{bar}') as t:
            t.display()
        assert f.getvalue() == '          \r'

    # Test without bar_format
    with StringIO() as f:
        with tqdm(total=10, file=f) as t:
            t.display()
        assert f.getvalue() == '          \r'

    # Test with bar_format and ncols
    with StringIO() as f:
        with tqdm(total=10, file=f, bar_format='{bar}', ncols=10) as t:
            t.display()

# Generated at 2022-06-18 11:30:29.090144
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from io import StringIO
    from sys import stdout
    from time import sleep
    from tqdm import tqdm
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.utils import _term_move_up

    # Test tqdm_telegram display
    with StringIO() as f:
        with tqdm(total=10, file=f, mininterval=0.01) as pbar:
            for i in range(10):
                sleep(0.1)
                pbar.update()
        assert f.getvalue() == '\n'


# Generated at 2022-06-18 11:30:39.150269
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from io import StringIO
    from sys import stdout
    from time import sleep
    from tqdm import tqdm
    from tqdm.contrib.telegram import tqdm_telegram

    # Test tqdm_telegram display method
    with StringIO() as f:
        with tqdm(total=10, file=f) as pbar:
            sleep(0.1)
            pbar.update(1)
            pbar.display()
            pbar.update(1)
            pbar.display()
            pbar.update(1)
            pbar.display()
            pbar.update(1)
            pbar.display()
            pbar.update(1)
            pbar.display()
            pbar.update(1)
            pbar.display()

# Generated at 2022-06-18 11:30:40.989304
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(total=10, leave=False)
    t.close()
    assert t.tgio.message_id is None

# Generated at 2022-06-18 11:32:59.610644
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm.contrib.telegram import tqdm_telegram
    import time
    import sys
    import os
    import re
    import io
    import tempfile
    import unittest
    import subprocess

    # Test for method display of class tqdm_telegram
    class TestTqdmTelegramDisplay(unittest.TestCase):
        def setUp(self):
            self.token = os.getenv('TQDM_TELEGRAM_TOKEN')
            self.chat_id = os.getenv('TQDM_TELEGRAM_CHAT_ID')
            self.t = tqdm_telegram(total=10, token=self.token, chat_id=self.chat_id)
            self.t.update(5)

        def test_display(self):
            self

# Generated at 2022-06-18 11:33:08.781241
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import sys
    from io import StringIO
    from tqdm.contrib.telegram import tqdm, trange
    from tqdm.auto import tqdm as tqdm_auto
    from tqdm.utils import _supports_unicode
    from tqdm.tests.utils import _range

    # Test for method clear of class tqdm_telegram
    # Test for method clear of class tqdm_telegram
    # Test for method clear of class tqdm_telegram
    # Test for method clear of class tqdm_telegram
    # Test for method clear of class tqdm_telegram
    # Test for method clear of class tqdm_telegram
    # Test for method clear of class tqdm_telegram
    # Test for method clear of class tqdm_telegram
    # Test

# Generated at 2022-06-18 11:33:15.843630
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(total=1, leave=False, token='{token}', chat_id='{chat_id}')
    t.close()
    t = tqdm_telegram(total=1, leave=True, token='{token}', chat_id='{chat_id}')
    t.close()
    t = tqdm_telegram(total=1, leave=None, token='{token}', chat_id='{chat_id}')
    t.close()
    t = tqdm_telegram(total=1, leave=None, token='{token}', chat_id='{chat_id}')
    t.update(1)
    t.close()


# Generated at 2022-06-18 11:33:22.088733
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .tests_tqdm import pretest_posttest_monkeypatch
    from .tests_tqdm import StringIO
    from .tests_tqdm import closing
    from .tests_tqdm import _range
    from .tests_tqdm import format_interval
    from .tests_tqdm import UnicodeIO
    from .tests_tqdm import _environ
    from .tests_tqdm import _supports_unicode
    from .tests_tqdm import _term_move_up
    from .tests_tqdm import _unicode
    from .tests_tqdm import _unicode_type
    from .tests_tqdm import _range
    from .tests_tqdm import _time
    from .tests_tqdm import _zip
    from .tests_tqdm import _ch