

# Generated at 2022-06-18 11:28:04.766236
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.auto import tqdm
    from time import sleep
    for i in tqdm(range(10), token='{token}', chat_id='{chat_id}'):
        sleep(0.1)
        tqdm.clear()
        sleep(0.1)
        tqdm.close()

# Generated at 2022-06-18 11:28:14.949364
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """
    Test method close of class tqdm_telegram.
    """
    from time import sleep
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.auto import tqdm

    # Test leave=True
    with tqdm(total=10, leave=True) as t:
        for i in range(10):
            sleep(0.1)
            t.update()

    # Test leave=False
    with tqdm(total=10, leave=False) as t:
        for i in range(10):
            sleep(0.1)
            t.update()

    # Test leave=None
    with tqdm(total=10, leave=None) as t:
        for i in range(10):
            sleep(0.1)
            t.update

# Generated at 2022-06-18 11:28:25.236903
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from io import StringIO
    from sys import stdout
    from tqdm import tqdm as tqdm_std
    from tqdm.contrib.telegram import tqdm_telegram as tqdm_tg
    from tqdm.utils import _term_move_up

    # Test with tqdm_telegram
    with StringIO() as f:
        with tqdm_tg(total=10, file=f, mininterval=0.01) as t:
            for i in range(10):
                t.update()
        assert f.getvalue() == '\r' + _term_move_up() + '\r'

    # Test with tqdm_std

# Generated at 2022-06-18 11:28:32.865345
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from os import environ
    from time import sleep
    from unittest import TestCase

    class TestTelegramIO(TestCase):
        def setUp(self):
            self.token = environ.get('TQDM_TELEGRAM_TOKEN')
            self.chat_id = environ.get('TQDM_TELEGRAM_CHAT_ID')
            self.tgio = TelegramIO(self.token, self.chat_id)

        def tearDown(self):
            self.tgio.delete()

        def test_write(self):
            self.tgio.write("Hello World")
            sleep(1)
            self.tgio.write("Hello World")
            sleep(1)
            self.tgio.write("Hello World")
            sleep(1)

# Generated at 2022-06-18 11:28:37.173311
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from time import sleep
    from tqdm.auto import tqdm
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.contrib.telegram.utils_worker import MonoWorker

    # Test tqdm_telegram.clear()

# Generated at 2022-06-18 11:28:38.648030
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .utils_test import _test_display
    _test_display(tqdm_telegram)

# Generated at 2022-06-18 11:28:45.556942
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from io import StringIO
    from sys import stdout
    from time import sleep
    from unittest import TestCase

    class TestTqdmTelegramDisplay(TestCase):
        def test_tqdm_telegram_display(self):
            with StringIO() as f:
                with tqdm_telegram(total=10, file=f, mininterval=0.01,
                                   disable=True) as pbar:
                    for _ in range(10):
                        pbar.update()
                        sleep(0.01)
                self.assertEqual(f.getvalue(),
                                 '                                            \r')

    # Run tests
    TestTqdmTelegramDisplay().test_tqdm_telegram_display()

# Generated at 2022-06-18 11:28:49.508067
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm.contrib.telegram import tqdm_telegram
    import time
    for i in tqdm_telegram(range(10), token='{token}', chat_id='{chat_id}'):
        time.sleep(0.1)
        if i == 5:
            tqdm_telegram.clear(leave=True)
            break

# Generated at 2022-06-18 11:28:51.247313
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .utils_test import _test_display
    _test_display(tqdm_telegram)

# Generated at 2022-06-18 11:29:00.276624
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from os import environ
    from time import sleep
    from tqdm.contrib.telegram import tqdm_telegram
    environ['TQDM_TELEGRAM_TOKEN'] = '123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    environ['TQDM_TELEGRAM_CHAT_ID'] = '123456789'
    for i in tqdm_telegram(range(10), leave=True):
        sleep(0.1)
    for i in tqdm_telegram(range(10), leave=False):
        sleep(0.1)
    for i in tqdm_telegram(range(10), leave=None):
        sleep(0.1)

# Generated at 2022-06-18 11:31:20.868626
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm.auto import tqdm
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.utils import _term_move_up
    from io import StringIO
    import sys
    import time

    def test_display(t):
        t.display()
        t.display()
        t.display()
        t.display()
        t.display()
        t.display()
        t.display()
        t.display()
        t.display()
        t.display()
        t.display()
        t.display()
        t.display()
        t.display()
        t.display()
        t.display()
        t.display()
        t.display()
        t.display()
        t.display()
        t.display()

# Generated at 2022-06-18 11:31:22.413393
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(total=10)
    t.close()
    assert t.tgio.message_id is None

# Generated at 2022-06-18 11:31:25.994092
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm.contrib.telegram import tqdm_telegram
    from time import sleep
    for i in tqdm_telegram(range(10), token='{token}', chat_id='{chat_id}'):
        sleep(0.1)
        if i == 5:
            tqdm_telegram.clear()
    tqdm_telegram.close()

# Generated at 2022-06-18 11:31:34.445495
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    import pytest
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.auto import tqdm
    from tqdm.utils import _term_move_up
    from tqdm.std import TqdmDeprecationWarning
    from tqdm.utils import _range

    with pytest.warns(TqdmDeprecationWarning):
        with tqdm_telegram(_range(10), leave=True, disable=True) as t:
            t.close()

    with pytest.warns(TqdmDeprecationWarning):
        with tqdm_telegram(_range(10), leave=False, disable=True) as t:
            t.close()


# Generated at 2022-06-18 11:31:39.475817
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from time import sleep
    from tqdm import tqdm_telegram
    for i in tqdm_telegram(range(10), token='{token}', chat_id='{chat_id}'):
        sleep(0.5)
        if i == 5:
            tqdm_telegram.clear(leave=True)
            break

if __name__ == '__main__':
    test_tqdm_telegram_clear()

# Generated at 2022-06-18 11:31:46.056836
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(total=10, leave=False, disable=False)
    t.close()
    assert t.tgio.message_id is None
    t = tqdm_telegram(total=10, leave=True, disable=False)
    t.close()
    assert t.tgio.message_id is not None
    t = tqdm_telegram(total=10, leave=None, disable=False)
    t.close()
    assert t.tgio.message_id is not None
    t = tqdm_telegram(total=0, leave=None, disable=False)
    t.close()
    assert t.tgio.message_id is None

# Generated at 2022-06-18 11:31:48.656026
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tgio = TelegramIO('token', 'chat_id')
    tgio.delete()

# Generated at 2022-06-18 11:31:52.749845
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(total=10, leave=False)
    t.close()
    assert t.tgio.message_id is None
    t = tqdm_telegram(total=10, leave=True)
    t.close()
    assert t.tgio.message_id is not None

# Generated at 2022-06-18 11:31:55.547706
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    """Test tqdm_telegram"""
    with tqdm_telegram(total=10, token='{token}', chat_id='{chat_id}') as pbar:
        for i in range(10):
            pbar.update()

# Generated at 2022-06-18 11:32:02.414436
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from .tests_tqdm import pretest_posttest_monkeypatch
    from .tests_tqdm import StringIO
    from .tests_tqdm import closing
    from .tests_tqdm import _range
    from .tests_tqdm import format_interval
    from .tests_tqdm import UnicodeIO
    from .tests_tqdm import _environ
    from .tests_tqdm import _supports_unicode
    from .tests_tqdm import _range
    from .tests_tqdm import _time
    from .tests_tqdm import _unittest
    from .tests_tqdm import _io
    from .tests_tqdm import _sys
    from .tests_tqdm import _term_move_up
    from .tests_tqdm import _term_move