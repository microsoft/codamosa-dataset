

# Generated at 2022-06-18 11:27:48.635439
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from os import environ
    from time import sleep
    from unittest import TestCase
    from unittest.mock import patch

    class TestTelegramIO(TestCase):
        def setUp(self):
            self.token = environ.get('TQDM_TELEGRAM_TOKEN')
            self.chat_id = environ.get('TQDM_TELEGRAM_CHAT_ID')
            self.tgio = TelegramIO(self.token, self.chat_id)

        @patch('requests.Session.post')
        def test_write(self, mock_post):
            self.tgio.write('test')
            mock_post.assert_called_once()

# Generated at 2022-06-18 11:27:56.317444
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(total=10, disable=True)
    t.close()
    t = tqdm_telegram(total=10, disable=False)
    t.close()
    t = tqdm_telegram(total=10, disable=False, leave=True)
    t.close()
    t = tqdm_telegram(total=10, disable=False, leave=False)
    t.close()
    t = tqdm_telegram(total=10, disable=False, leave=None)
    t.close()
    t = tqdm_telegram(total=10, disable=False, leave=None)
    t.pos = 1
    t.close()

# Generated at 2022-06-18 11:28:04.345293
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from os import getenv
    from time import sleep
    from requests import Session
    from tqdm.contrib.telegram import TelegramIO
    from tqdm.contrib.telegram import tqdm, trange
    from tqdm.contrib.telegram import tqdm_telegram, ttgrange
    from tqdm.contrib.telegram import __doc__ as __doc__telegram
    from tqdm.contrib.telegram import __all__ as __all__telegram

    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if not (token and chat_id):
        return

    io = TelegramIO(token, chat_id)
    io.write("Hello World!")


# Generated at 2022-06-18 11:28:09.680349
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(total=10)
    t.close()
    assert t.tgio.message_id is None
    t = tqdm_telegram(total=10, leave=True)
    t.close()
    assert t.tgio.message_id is not None
    t = tqdm_telegram(total=10, leave=False)
    t.close()
    assert t.tgio.message_id is None
    t = tqdm_telegram(total=10, leave=None)
    t.close()
    assert t.tgio.message_id is None
    t = tqdm_telegram(total=10, leave=None)
    t.update(1)
    t.close()
    assert t.tgio.message_id is not None

# Generated at 2022-06-18 11:28:21.235912
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from os import getenv
    from time import sleep
    from tqdm.auto import tqdm
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.contrib.telegram.utils_worker import MonoWorker

    # Test tqdm_telegram constructor
    assert isinstance(tqdm_telegram(disable=True), tqdm)
    assert isinstance(tqdm_telegram(token=getenv('TQDM_TELEGRAM_TOKEN'),
                                    chat_id=getenv('TQDM_TELEGRAM_CHAT_ID')),
                      tqdm_telegram)

    # Test tqdm_telegram.write

# Generated at 2022-06-18 11:28:22.690978
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .utils_test import _test_display
    _test_display(tqdm_telegram)

# Generated at 2022-06-18 11:28:30.558250
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from io import StringIO
    from sys import stdout
    from time import sleep
    from tqdm import tqdm
    from tqdm.contrib.telegram import tqdm_telegram

    # Test tqdm_telegram.display()
    with StringIO() as f:
        with tqdm(total=10, file=f, ncols=0, mininterval=0) as pbar:
            for i in range(10):
                pbar.update()
                sleep(0.1)
        assert f.getvalue() == '\r  0%|          | 0/10 [00:00<?, ?it/s]\n'


# Generated at 2022-06-18 11:28:37.778848
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from .tests_tqdm import pretest_posttest_monkeypatch, closing, UnicodeIO
    with closing(UnicodeIO()) as our_file:
        with pretest_posttest_monkeypatch(our_file, 'write'):
            with tqdm_telegram(total=10, file=our_file,
                               token='{token}', chat_id='{chat_id}') as t:
                t.update(5)
                t.clear()
                t.update(5)
                t.close()
            assert our_file.getvalue() == '\r  5%|#         | 5/10 [00:00<?, ?it/s]\r'

# Generated at 2022-06-18 11:28:45.351734
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm.auto import tqdm
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.utils import _term_move_up
    from time import sleep

    with tqdm(total=10, desc='test') as pbar:
        pbar.write('test')
        sleep(0.1)
        pbar.write('test2')
        sleep(0.1)
        pbar.write('test3')
        sleep(0.1)
        pbar.clear()
        pbar.write('test4')
        sleep(0.1)
        pbar.write('test5')
        sleep(0.1)
        pbar.write('test6')
        sleep(0.1)
        pbar.close()


# Generated at 2022-06-18 11:28:53.601208
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(total=10, disable=True)
    t.close()
    t.close()
    t.close()
    t.close()
    t.close()
    t.close()
    t.close()
    t.close()
    t.close()
    t.close()
    t.close()
    t.close()
    t.close()
    t.close()
    t.close()
    t.close()
    t.close()
    t.close()
    t.close()
    t.close()
    t.close()
    t.close()
    t.close()
    t.close()
    t.close()
    t.close()
    t.close()
    t.close()
    t.close()
    t.close()


# Generated at 2022-06-18 11:31:24.662422
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.auto import tqdm
    from tqdm.utils import _term_move_up
    from tqdm.std import sys
    from io import StringIO
    from time import sleep
    from os import getenv
    from os.path import exists
    from requests import Session
    from requests.exceptions import ConnectionError
    from warnings import catch_warnings
    from contextlib import contextmanager

    # Get token and chat_id
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')

    # Check if token and chat_id are set
    if not token:
        raise ValueError("Missing token")

# Generated at 2022-06-18 11:31:33.080667
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from io import StringIO
    from sys import stdout
    from time import sleep
    from tqdm.auto import tqdm
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.utils import _term_move_up

    # Test with tqdm_telegram
    with StringIO() as f:
        with tqdm_telegram(total=10, file=f, mininterval=0.1,
                           token='{token}', chat_id='{chat_id}') as pbar:
            for i in range(10):
                sleep(0.1)
                pbar.update()
        assert f.getvalue() == '\n'

    # Test with tqdm

# Generated at 2022-06-18 11:31:35.475140
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm.contrib.telegram import tqdm
    import time
    for i in tqdm(range(10), token='{token}', chat_id='{chat_id}'):
        time.sleep(1)

# Generated at 2022-06-18 11:31:44.391878
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(total=10, leave=True, disable=True)
    t.close()
    t = tqdm_telegram(total=10, leave=False, disable=True)
    t.close()
    t = tqdm_telegram(total=10, leave=True, disable=False)
    t.close()
    t = tqdm_telegram(total=10, leave=False, disable=False)
    t.close()
    t = tqdm_telegram(total=10, leave=None, disable=True)
    t.close()
    t = tqdm_telegram(total=10, leave=None, disable=False)
    t.close()
    t = tqdm_telegram(total=10, leave=None, disable=False)
    t

# Generated at 2022-06-18 11:31:53.690480
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import sys
    from io import StringIO
    from tqdm.contrib.telegram import TelegramIO

    # Create a StringIO object
    capturedOutput = StringIO()
    sys.stdout = capturedOutput

    # Create a TelegramIO object
    tgio = TelegramIO(token='123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZ', chat_id='123456789')
    tgio.write('Hello World!')

    # Get the value stored in the StringIO object
    sys.stdout = sys.__stdout__  # Reset redirect.
    print('Captured', capturedOutput.getvalue())

if __name__ == '__main__':
    test_TelegramIO_write()

# Generated at 2022-06-18 11:31:54.970512
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from .utils_test import _test_clear
    _test_clear(tqdm_telegram)

# Generated at 2022-06-18 11:31:58.063990
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from time import sleep
    from tqdm import tqdm
    from tqdm.contrib.telegram import tqdm_telegram

    for i in tqdm(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm_telegram.clear()
            break

# Generated at 2022-06-18 11:32:00.101346
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm.contrib.telegram import tqdm, trange
    for i in trange(10, token='{token}', chat_id='{chat_id}'):
        pass

# Generated at 2022-06-18 11:32:04.223797
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import time
    from tqdm import tqdm
    with tqdm(total=100, token='{token}', chat_id='{chat_id}') as pbar:
        for i in range(10):
            pbar.update(10)
            time.sleep(1)
            pbar.clear()
            time.sleep(1)

if __name__ == '__main__':
    test_tqdm_telegram_clear()

# Generated at 2022-06-18 11:32:12.038091
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from os import environ
    from sys import version_info
    from time import sleep
    from tqdm.auto import tqdm as tqdm_auto
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.contrib.telegram import tqdm, trange

    # Test tqdm_telegram
    environ['TQDM_TELEGRAM_TOKEN'] = '1234567890:AABBCCDDEEFFGGHHIIJJKKLLMMNNOOPPQQ'
    environ['TQDM_TELEGRAM_CHAT_ID'] = '-123456789'
    for i in tqdm_telegram(range(10), desc='test_tqdm_telegram'):
        sleep(0.1)

    # Test tqdm