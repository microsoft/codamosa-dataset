

# Generated at 2022-06-18 11:26:21.620563
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """
    Unit test for method close of class tqdm_telegram.
    """
    t = tqdm_telegram(total=10)
    t.close()
    assert t.disable

# Generated at 2022-06-18 11:26:24.066188
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    t = tqdm_telegram(total=10, token='{token}', chat_id='{chat_id}')
    t.display()
    t.close()

# Generated at 2022-06-18 11:26:33.319589
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import sys
    import time
    import unittest
    from unittest.mock import patch

    class TestTelegramIO(unittest.TestCase):
        def setUp(self):
            self.token = '123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZ'
            self.chat_id = '123456789'
            self.tgio = TelegramIO(self.token, self.chat_id)

        def test_write(self):
            with patch.object(self.tgio.session, 'post') as mock_method:
                self.tgio.write('test')

# Generated at 2022-06-18 11:26:39.432519
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    """Test tqdm_telegram constructor"""
    # Test with token and chat_id
    tqdm_telegram(token='123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZ',
                  chat_id='123456789')
    # Test with token and chat_id in environment variables
    import os
    os.environ['TQDM_TELEGRAM_TOKEN'] = '123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    os.environ['TQDM_TELEGRAM_CHAT_ID'] = '123456789'
    tqdm_telegram()
    # Test with token in environment variable and chat_id
    tqdm_telegram(chat_id='123456789')
    # Test with token and chat_

# Generated at 2022-06-18 11:26:45.374681
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from io import StringIO
    from sys import stdout
    from time import sleep
    from tqdm import tqdm
    from tqdm.contrib.telegram import TelegramIO

    # Create a fake TelegramIO
    class FakeTelegramIO(TelegramIO):
        def __init__(self, *args, **kwargs):
            super(FakeTelegramIO, self).__init__(*args, **kwargs)
            self.text = ""

        def write(self, s):
            self.text = s

    # Create a fake tqdm
    class FakeTqdm(tqdm):
        def __init__(self, *args, **kwargs):
            super(FakeTqdm, self).__init__(*args, **kwargs)
            self.tgio = FakeTelegramIO("", "")

   

# Generated at 2022-06-18 11:26:56.653056
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import time
    import sys
    from os import getenv
    from requests import Session
    from tqdm.contrib.telegram import TelegramIO
    from tqdm.auto import tqdm

    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')

    if token is None or chat_id is None:
        print("Please set the environment variables TQDM_TELEGRAM_TOKEN and TQDM_TELEGRAM_CHAT_ID")
        sys.exit(1)

    tgio = TelegramIO(token, chat_id)
    tgio.write("Hello World!")
    time.sleep(1)
    tgio.write("Hello World!")
    time.sleep(1)


# Generated at 2022-06-18 11:27:05.049031
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.auto import tqdm
    from time import sleep
    from os import getenv
    from requests import Session
    from requests.exceptions import ConnectionError
    from tqdm.utils import _range

    def _test_tqdm_telegram_display(token, chat_id):
        session = Session()
        try:
            session.post(
                'https://api.telegram.org/bot%s/sendMessage' % token,
                data={'text': '`' + 'test_tqdm_telegram_display' + '`',
                      'chat_id': chat_id, 'parse_mode': 'MarkdownV2'})
        except ConnectionError:
            return

# Generated at 2022-06-18 11:27:12.207529
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.auto import tqdm
    from time import sleep
    for leave in [True, False, None]:
        for pos in [0, 1]:
            with tqdm(total=1, leave=leave, position=pos) as pbar:
                pbar.update(1)
                sleep(1)
            with tqdm_telegram(total=1, leave=leave, position=pos) as pbar:
                pbar.update(1)
                sleep(1)

# Generated at 2022-06-18 11:27:13.663916
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .utils_test import _test_display
    _test_display(tqdm_telegram)

# Generated at 2022-06-18 11:27:22.794286
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from io import StringIO
    from sys import stdout
    from time import sleep
    from tqdm import tqdm
    from tqdm.contrib.telegram import tqdm_telegram

    with StringIO() as f:
        for i in tqdm(range(10), file=f, ncols=80, ascii=True,
                      bar_format='{l_bar}{bar}{r_bar}'):
            sleep(0.1)
        f.seek(0)

# Generated at 2022-06-18 11:30:26.167766
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import sys
    from os import getenv
    from time import sleep
    from tqdm.contrib.telegram import TelegramIO
    from tqdm.auto import tqdm
    from tqdm.utils import _term_move_up

    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')

    if not (token and chat_id):
        print("Please set the environment variables TQDM_TELEGRAM_TOKEN "
              "and TQDM_TELEGRAM_CHAT_ID")
        sys.exit(1)

    tg = TelegramIO(token, chat_id)
    tg.write("Hello")
    sleep(1)
    tg.write("World")

# Generated at 2022-06-18 11:30:36.296286
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.auto import tqdm
    from tqdm.utils import _term_move_up
    import sys

    # Test with a tqdm_telegram object
    with tqdm_telegram(total=10, token='{token}', chat_id='{chat_id}') as t:
        for i in range(10):
            t.update()
            sys.stdout.write(_term_move_up())
            sys.stdout.flush()

    # Test with a tqdm object
    with tqdm(total=10) as t:
        for i in range(10):
            t.update()
            sys.stdout.write(_term_move_up())
            sys.stdout.flush()

# Generated at 2022-06-18 11:30:47.526980
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.auto import tqdm
    from tqdm.utils import _term_move_up
    from time import sleep
    from sys import stdout

    with tqdm(total=10, file=stdout, ncols=100) as pbar:
        for i in range(10):
            pbar.update()
            sleep(0.1)
        pbar.display()
        _term_move_up()
        print("")

    with tqdm_telegram(total=10, file=stdout, ncols=100,
                       token='{token}', chat_id='{chat_id}') as pbar:
        for i in range(10):
            pbar.update()

# Generated at 2022-06-18 11:30:55.766453
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from time import sleep
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.contrib.telegram import TelegramIO
    from tqdm.contrib.telegram import ttgrange
    from tqdm.contrib.telegram import tqdm
    from tqdm.contrib.telegram import trange
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.contrib.telegram import TelegramIO
    from tqdm.contrib.telegram import ttgrange
    from tqdm.contrib.telegram import tqdm
    from tqdm.contrib.telegram import trange
    from tqdm.contrib.telegram import tqdm_telegram

# Generated at 2022-06-18 11:31:04.314879
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    import os
    import sys
    import time
    from io import StringIO
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.utils import _term_move_up

    # Setup
    tqdm_telegram.leave = False
    tqdm_telegram.pos = 0
    tqdm_telegram.disable = False
    tqdm_telegram.tgio = TelegramIO(
        token=os.environ['TQDM_TELEGRAM_TOKEN'],
        chat_id=os.environ['TQDM_TELEGRAM_CHAT_ID'])

    # Test

# Generated at 2022-06-18 11:31:14.446728
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from os import environ
    from time import sleep

    # Test with token and chat_id
    token = environ.get('TQDM_TELEGRAM_TOKEN')
    chat_id = environ.get('TQDM_TELEGRAM_CHAT_ID')
    if token and chat_id:
        with tqdm_telegram(token=token, chat_id=chat_id, total=10) as t:
            for i in range(10):
                sleep(0.1)
                t.update()

    # Test with token and chat_id in environment variables
    environ['TQDM_TELEGRAM_TOKEN'] = token
    environ['TQDM_TELEGRAM_CHAT_ID'] = chat_id

# Generated at 2022-06-18 11:31:17.446025
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from time import sleep
    t = tqdm_telegram(total=10, leave=False, token='{token}', chat_id='{chat_id}')
    for i in range(10):
        sleep(0.1)
        t.update()
    t.close()

# Generated at 2022-06-18 11:31:21.347584
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import time
    from tqdm.contrib.telegram import tqdm_telegram
    for i in tqdm_telegram(range(10), token='{token}', chat_id='{chat_id}'):
        time.sleep(1)
        if i == 5:
            tqdm_telegram.clear(leave=True)
            break

# Generated at 2022-06-18 11:31:29.597307
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from os import getenv
    from time import sleep
    from requests import Session
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.contrib.telegram.utils_worker import MonoWorker
    from tqdm.contrib.telegram.utils_worker import _Worker
    from tqdm.contrib.telegram.utils_worker import _WorkerThread
    from tqdm.contrib.telegram.utils_worker import _WorkerProcess
    from tqdm.contrib.telegram.utils_worker import _WorkerFuture
    from tqdm.contrib.telegram.utils_worker import _WorkerAsyncio
    from tqdm.contrib.telegram.utils_worker import _WorkerTornado

# Generated at 2022-06-18 11:31:38.102170
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from os import environ
    from time import sleep
    from unittest import TestCase

    class TestTelegramIO(TestCase):
        def setUp(self):
            self.token = environ.get('TQDM_TELEGRAM_TOKEN')
            self.chat_id = environ.get('TQDM_TELEGRAM_CHAT_ID')
            self.tgio = TelegramIO(self.token, self.chat_id)

        def test_write(self):
            self.tgio.write('test')
            sleep(1)
            self.tgio.write('test2')
            sleep(1)
            self.tgio.write('test3')
            sleep(1)
            self.tgio.delete()

    TestTelegramIO().test_write()