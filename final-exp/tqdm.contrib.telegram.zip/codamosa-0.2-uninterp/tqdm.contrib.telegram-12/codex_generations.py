

# Generated at 2022-06-18 11:28:59.274247
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from time import sleep
    from tqdm.contrib.telegram import tqdm_telegram
    for i in tqdm_telegram(range(10), token='{token}', chat_id='{chat_id}'):
        sleep(0.1)
        if i == 5:
            tqdm_telegram.clear()
            tqdm_telegram.close()
            break

# Generated at 2022-06-18 11:29:03.138789
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm.contrib.telegram import tqdm_telegram
    import time
    for i in tqdm_telegram(range(10), token='{token}', chat_id='{chat_id}'):
        time.sleep(0.1)

# Generated at 2022-06-18 11:29:10.506925
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(total=10)
    t.close()
    assert t.tgio.message_id is None
    t = tqdm_telegram(total=10, leave=True)
    t.close()
    assert t.tgio.message_id is not None
    t = tqdm_telegram(total=10, leave=False)
    t.close()
    assert t.tgio.message_id is None
    t = tqdm_telegram(total=10, leave=None)
    t.close()
    assert t.tgio.message_id is None
    t = tqdm_telegram(total=10, leave=None)
    t.update(10)
    t.close()
    assert t.tgio.message_id is not None

# Generated at 2022-06-18 11:29:15.907336
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm import tqdm
    from time import sleep
    for i in tqdm(range(10), token='{token}', chat_id='{chat_id}'):
        sleep(0.1)
    for i in tqdm_telegram(range(10), token='{token}', chat_id='{chat_id}'):
        sleep(0.1)

if __name__ == '__main__':
    test_tqdm_telegram_display()

# Generated at 2022-06-18 11:29:26.579564
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from io import StringIO
    from sys import stdout
    from time import sleep
    from tqdm import tqdm as tqdm_base
    from tqdm.contrib.telegram import tqdm_telegram as tqdm_telegram_base

    # Test tqdm_telegram.display
    with StringIO() as f:
        with tqdm_telegram_base(total=10, file=f, disable=True) as t:
            t.display()
            assert f.getvalue() == '\n'
        with tqdm_telegram_base(total=10, file=f, disable=True) as t:
            t.display(bar_format='{bar}')
            assert f.getvalue() == '\n'

# Generated at 2022-06-18 11:29:35.846940
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from os import getenv
    from time import sleep
    from tqdm.auto import tqdm
    from tqdm.contrib.telegram import tqdm_telegram

    tqdm_telegram(token=getenv('TQDM_TELEGRAM_TOKEN'),
                  chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'))
    tqdm_telegram(token=getenv('TQDM_TELEGRAM_TOKEN'),
                  chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'),
                  disable=True)

# Generated at 2022-06-18 11:29:37.932023
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from time import sleep
    for _ in tqdm(range(10), token='{token}', chat_id='{chat_id}'):
        sleep(0.1)

# Generated at 2022-06-18 11:29:45.273839
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from time import sleep
    from tqdm import tqdm
    from tqdm.contrib.telegram import tqdm_telegram
    for i in tqdm(range(10)):
        sleep(0.1)
        tqdm_telegram.clear()
        sleep(0.1)
        tqdm.clear()
        sleep(0.1)
        tqdm.clear()
        sleep(0.1)
        tqdm_telegram.clear()
        sleep(0.1)
        tqdm.clear()
        sleep(0.1)
        tqdm_telegram.clear()
        sleep(0.1)
        tqdm.clear()
        sleep(0.1)
        tqdm_telegram.clear()
        sleep(0.1)
        t

# Generated at 2022-06-18 11:29:53.131943
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from io import StringIO
    from sys import stdout
    from tqdm.auto import tqdm
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.utils import _term_move_up

    # Test tqdm_telegram.display()
    with StringIO() as f:
        with tqdm(total=10, file=f, leave=False) as pbar:
            pbar.display(n=5, total=10)
            assert f.getvalue() == '\r  5/10 [50%]'
            pbar.display(n=7, total=10)
            assert f.getvalue() == '\r  7/10 [70%]'
            pbar.display(n=10, total=10)

# Generated at 2022-06-18 11:30:01.210007
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from io import StringIO
    from sys import stdout
    from time import sleep
    from tqdm.auto import tqdm
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.utils import _term_move_up

    # Test tqdm_telegram.display()
    with StringIO() as f:
        with tqdm(total=10, file=f, leave=False) as pbar:
            pbar.display(**pbar.format_dict)
            assert f.getvalue() == '  0%|          | 0/10 [00:00<?, ?it/s]\n'
            pbar.update()
            pbar.display(**pbar.format_dict)

# Generated at 2022-06-18 11:32:38.306827
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tgio = TelegramIO('token', 'chat_id')
    tgio.delete()

# Generated at 2022-06-18 11:32:43.976129
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    import os
    import sys
    import time
    import unittest
    from unittest import mock
    from unittest.mock import patch
    from requests import Session
    from requests.exceptions import ConnectionError

    class TestTelegramIO(unittest.TestCase):
        def setUp(self):
            self.token = os.environ['TQDM_TELEGRAM_TOKEN']
            self.chat_id = os.environ['TQDM_TELEGRAM_CHAT_ID']
            self.session = Session()
            self.text = 'test_TelegramIO_delete'
            self.message_id

        @property
        def message_id(self):
            if hasattr(self, '_message_id'):
                return self._message_id

# Generated at 2022-06-18 11:32:45.145872
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tgio = TelegramIO('token', 'chat_id')
    assert tgio.write('test') is None
    tgio.close()

# Generated at 2022-06-18 11:32:47.005755
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(total=10, leave=False)
    t.close()
    assert t.tgio.message_id is None

# Generated at 2022-06-18 11:32:48.246169
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .utils_test import _test_display
    _test_display(tqdm_telegram)

# Generated at 2022-06-18 11:32:55.543392
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    import os
    import time
    import unittest

    class TestTelegramIO(unittest.TestCase):
        def setUp(self):
            self.token = os.getenv('TQDM_TELEGRAM_TOKEN')
            self.chat_id = os.getenv('TQDM_TELEGRAM_CHAT_ID')
            self.tgio = TelegramIO(self.token, self.chat_id)

        def test_delete(self):
            self.tgio.write('test_delete')
            time.sleep(1)
            self.tgio.delete()
            time.sleep(1)

    unittest.main(argv=['first-arg-is-ignored'], exit=False)

# Generated at 2022-06-18 11:32:58.279032
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    t = tqdm_telegram(total=10, token='{token}', chat_id='{chat_id}')
    t.display()
    t.close()

# Generated at 2022-06-18 11:33:07.971267
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import time
    from io import StringIO
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.auto import tqdm
    from tqdm.utils import _term_move_up

    with StringIO() as f:
        with tqdm(total=10, file=f, leave=False) as pbar:
            for i in range(10):
                time.sleep(0.1)
                pbar.update()

# Generated at 2022-06-18 11:33:10.356655
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from time import sleep
    from tqdm.contrib.telegram import tqdm_telegram
    for i in tqdm_telegram(range(10), token='{token}', chat_id='{chat_id}'):
        sleep(1)
        if i == 5:
            tqdm_telegram.clear(leave=True)
            break

# Generated at 2022-06-18 11:33:14.173036
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    """
    Unit test for method clear of class tqdm_telegram
    """
    from time import sleep
    from tqdm.contrib.telegram import tqdm, trange
    for i in trange(10, token='{token}', chat_id='{chat_id}'):
        sleep(0.1)
        if i == 5:
            tqdm.clear()