

# Generated at 2022-06-18 11:27:03.406207
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from time import sleep
    from tqdm.auto import tqdm
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.contrib.telegram import TelegramIO
    from tqdm.contrib.telegram import ttgrange
    from tqdm.contrib.telegram import tqdm
    from tqdm.contrib.telegram import trange
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.contrib.telegram import TelegramIO
    from tqdm.contrib.telegram import ttgrange
    from tqdm.contrib.telegram import tqdm
    from tqdm.contrib.telegram import trange
    from tqdm.contrib.telegram import tqdm_te

# Generated at 2022-06-18 11:27:09.416285
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from io import StringIO
    from sys import stdout
    from time import sleep
    from tqdm import tqdm
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.utils import _term_move_up

    # Test display
    with StringIO() as f:
        with tqdm(total=10, file=f) as pbar:
            pbar.display()
            assert f.getvalue() == '\r  0%|          | 0/10 [00:00<?, ?it/s]\n'
            pbar.update()
            pbar.display()
            assert f.getvalue() == '\r  0%|          | 0/10 [00:00<?, ?it/s]\n'
            pbar.update()

# Generated at 2022-06-18 11:27:16.706938
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from os import getenv
    from time import sleep
    from requests import Session
    from tqdm.contrib.telegram import TelegramIO
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.contrib.telegram import ttgrange
    from tqdm.contrib.telegram import tqdm
    from tqdm.contrib.telegram import trange
    from tqdm.contrib.telegram import test_TelegramIO_write
    from tqdm.contrib.telegram import __author__
    from tqdm.contrib.telegram import __all__
    from tqdm.contrib.telegram import __doc__
    from tqdm.contrib.telegram import __version__
    from tqdm.contrib.telegram import __license

# Generated at 2022-06-18 11:27:21.623051
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(total=10, leave=False)
    t.close()
    assert t.tgio.message_id is None
    t = tqdm_telegram(total=10, leave=True)
    t.close()
    assert t.tgio.message_id is not None

# Generated at 2022-06-18 11:27:24.001989
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    """Test tqdm_telegram.display()"""
    from .utils_test import _test_display
    _test_display(tqdm_telegram)

# Generated at 2022-06-18 11:27:32.798425
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from os import environ
    environ['TQDM_TELEGRAM_TOKEN'] = '123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    environ['TQDM_TELEGRAM_CHAT_ID'] = '123456789'
    tqdm_telegram(range(10))
    tqdm_telegram(range(10), token='123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZ',
                  chat_id='123456789')
    tqdm_telegram(range(10), token='123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZ',
                  chat_id='123456789', disable=True)

# Generated at 2022-06-18 11:27:37.546196
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from time import sleep
    from tqdm import tqdm
    from tqdm.contrib.telegram import tqdm_telegram
    for i in tqdm(range(10)):
        sleep(0.1)
        tqdm_telegram.clear()
        sleep(0.1)

# Generated at 2022-06-18 11:27:45.310718
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    """
    Unit test for method write of class TelegramIO
    """
    from os import environ
    from time import sleep
    from unittest import TestCase

    class TestTelegramIO(TestCase):
        def setUp(self):
            self.token = environ.get('TQDM_TELEGRAM_TOKEN')
            self.chat_id = environ.get('TQDM_TELEGRAM_CHAT_ID')
            self.tgio = TelegramIO(self.token, self.chat_id)

        def test_write(self):
            self.tgio.write('test')
            sleep(1)
            self.tgio.write('test2')
            sleep(1)
            self.tgio.write('test3')
            sleep(1)

# Generated at 2022-06-18 11:27:46.506102
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(total=10)
    t.close()
    assert t.disable

# Generated at 2022-06-18 11:27:52.273046
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """
    Test the method close of class tqdm_telegram
    """
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.contrib.telegram import TelegramIO
    import time
    import os
    import requests
    import json

    # Create a tqdm_telegram object
    tg = tqdm_telegram(total=100, leave=False, disable=False)
    # Create a TelegramIO object
    tgio = TelegramIO(token=os.getenv('TQDM_TELEGRAM_TOKEN'), chat_id=os.getenv('TQDM_TELEGRAM_CHAT_ID'))
    # Create a session
    session = requests.Session()
    # Get the message_id
    message_id = tgio.message_id

# Generated at 2022-06-18 11:29:39.656069
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm.contrib.telegram import tqdm_telegram
    import time
    for i in tqdm_telegram(range(10), token='{token}', chat_id='{chat_id}'):
        time.sleep(0.1)
        if i == 5:
            tqdm_telegram.clear(leave=True)
            break


# Generated at 2022-06-18 11:29:46.885823
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from os import environ
    from time import sleep
    from unittest import TestCase

    class TestTqdmTelegramClose(TestCase):
        def test_tqdm_telegram_close(self):
            environ['TQDM_TELEGRAM_TOKEN'] = '123456789:AAHdqTcvCH1vGWJxfSeofSAs0K5PALDsaw'
            environ['TQDM_TELEGRAM_CHAT_ID'] = '123456789'
            for i in tqdm(range(10)):
                sleep(0.1)
            for i in tqdm(range(10), leave=True):
                sleep(0.1)
            for i in tqdm(range(10), leave=False):
                sleep(0.1)

    TestT

# Generated at 2022-06-18 11:29:54.637745
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm.auto import tqdm
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.utils import _term_move_up

    # Test tqdm_telegram.display()
    t = tqdm_telegram(total=10)
    t.display()
    t.close()

    # Test tqdm_telegram.display() with bar_format
    t = tqdm_telegram(total=10, bar_format='{bar}')
    t.display()
    t.close()

    # Test tqdm_telegram.display() with bar_format and ncols
    t = tqdm_telegram(total=10, bar_format='{bar}', ncols=80)
    t.display()
    t.close()

# Generated at 2022-06-18 11:29:56.715944
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tgio = TelegramIO('token', 'chat_id')
    tgio.write('test')
    assert tgio.text == 'test'

# Generated at 2022-06-18 11:30:00.938603
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    """
    Unit test for method delete of class TelegramIO.
    """
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if token is None or chat_id is None:
        return
    tgio = TelegramIO(token, chat_id)
    tgio.delete()

# Generated at 2022-06-18 11:30:02.345547
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .utils_test import _test_display
    _test_display(tqdm_telegram)

# Generated at 2022-06-18 11:30:11.534376
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from .tests_tqdm import pretest_posttest_monkeypatch
    with pretest_posttest_monkeypatch():
        from tqdm.contrib.telegram import tqdm_telegram
        from tqdm.tests import _range
        from tqdm.auto import tqdm
        from os import getenv
        from requests import Session
        from warnings import warn
        from ..utils import _range
        from .utils_worker import MonoWorker

        class TelegramIO(MonoWorker):
            """Non-blocking file-like IO using a Telegram Bot."""
            API = 'https://api.telegram.org/bot'

            def __init__(self, token, chat_id):
                """Creates a new message in the given `chat_id`."""
                super(TelegramIO, self).__init__()

# Generated at 2022-06-18 11:30:14.653545
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import time
    from tqdm.contrib.telegram import tqdm
    for i in tqdm(range(10), token='{token}', chat_id='{chat_id}'):
        time.sleep(0.1)
        if i == 5:
            tqdm.clear()

# Generated at 2022-06-18 11:30:24.049557
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import pytest
    from requests.exceptions import ConnectionError
    from tqdm.contrib.telegram import TelegramIO
    tgio = TelegramIO('token', 'chat_id')
    tgio.session.post = lambda *a, **kw: {'error_code': 429}
    with pytest.warns(TqdmWarning):
        tgio.write('test')
    tgio.session.post = lambda *a, **kw: {'result': {'message_id': 'message_id'}}
    tgio.write('test')
    tgio.session.post = lambda *a, **kw: ConnectionError()
    tgio.write('test')

# Generated at 2022-06-18 11:30:31.966617
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.auto import tqdm
    import time
    t = tqdm_telegram(total=10, token='{token}', chat_id='{chat_id}')
    for i in t:
        time.sleep(0.1)
        t.display()
    t.close()
    t = tqdm(total=10, token='{token}', chat_id='{chat_id}')
    for i in t:
        time.sleep(0.1)
        t.display()
    t.close()