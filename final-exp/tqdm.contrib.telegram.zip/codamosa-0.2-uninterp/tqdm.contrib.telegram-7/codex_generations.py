

# Generated at 2022-06-18 11:29:41.905944
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from time import sleep
    from tqdm import tqdm
    from tqdm.contrib.telegram import tqdm_telegram
    for i in tqdm(range(10)):
        sleep(0.1)
    for i in tqdm_telegram(range(10), token='{token}', chat_id='{chat_id}'):
        sleep(0.1)
        i.clear()
        sleep(0.1)

if __name__ == '__main__':
    test_tqdm_telegram_clear()

# Generated at 2022-06-18 11:29:49.597536
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from io import StringIO
    from sys import stdout
    with StringIO() as f:
        with tqdm(total=10, file=f, mininterval=0.1) as t:
            for i in range(10):
                t.update()
                assert t.format_dict['bar'] == '#' * i
                assert t.format_dict['n'] == i + 1
                assert t.format_dict['n_fmt'] == str(i + 1)
                assert t.format_dict['rate'] == t.format_dict['rate_noinv']
                assert t.format_dict['rate_noinv'] == t.format_dict['rate_noinv_fmt']

# Generated at 2022-06-18 11:29:53.059358
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from time import sleep
    from tqdm.contrib.telegram import tqdm_telegram
    for i in tqdm_telegram(range(10), token='{token}', chat_id='{chat_id}'):
        sleep(0.1)
        if i == 5:
            tqdm_telegram.clear()

# Generated at 2022-06-18 11:30:00.820891
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.auto import tqdm
    from time import sleep
    from os import getenv
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if token and chat_id:
        with tqdm_telegram(total=10, token=token, chat_id=chat_id) as pbar:
            for i in range(10):
                sleep(1)
                pbar.update()
    else:
        with tqdm(total=10) as pbar:
            for i in range(10):
                sleep(1)
                pbar.update()

# Generated at 2022-06-18 11:30:09.815492
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from io import StringIO
    from sys import stdout
    from time import sleep
    from tqdm import tqdm as tqdm_base
    from tqdm.contrib.telegram import tqdm_telegram

    # Test with tqdm_telegram
    with StringIO() as f:
        with tqdm_telegram(total=10, file=f, token='{token}', chat_id='{chat_id}') as pbar:
            for i in range(10):
                sleep(0.1)
                pbar.update()
        assert f.getvalue() == ''

    # Test with tqdm_base

# Generated at 2022-06-18 11:30:17.667368
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm import tqdm
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.contrib.telegram import TelegramIO
    from tqdm.contrib.telegram import ttgrange
    from tqdm.contrib.telegram import tqdm
    from tqdm.contrib.telegram import trange
    from tqdm.contrib.telegram import test_tqdm_telegram_clear
    from tqdm.contrib.telegram import __author__
    from tqdm.contrib.telegram import __all__
    from tqdm.contrib.telegram import __version__
    from tqdm.contrib.telegram import __doc__
    from tqdm.contrib.telegram import __package__

# Generated at 2022-06-18 11:30:28.284778
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm.auto import tqdm
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.utils import _term_move_up

    with tqdm(total=10, desc='test', file=tqdm_telegram(
            token='{token}', chat_id='{chat_id}')) as pbar:
        pbar.write('test')
        pbar.clear()
        pbar.write('test')
        pbar.clear()
        pbar.write('test')
        pbar.clear()
        pbar.write('test')
        pbar.clear()
        pbar.write('test')
        pbar.clear()
        pbar.write('test')
        pbar.clear()
        pbar.write('test')
       

# Generated at 2022-06-18 11:30:34.147345
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    """
    Unit test for method display of class tqdm_telegram.
    """
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.auto import tqdm
    from tqdm.utils import _term_move_up
    from tqdm.utils import _supports_unicode
    from tqdm.utils import _environ_cols_wrapper
    from tqdm.utils import _unicode
    from tqdm.utils import _range
    from tqdm.utils import _screen_shape
    from tqdm.utils import _unicode_len
    from tqdm.utils import _unicode_type
    from tqdm.utils import _term_move_up
    from tqdm.utils import _supports_unicode

# Generated at 2022-06-18 11:30:45.275031
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(total=10)
    t.close()
    assert t.tgio.message_id is None
    t = tqdm_telegram(total=10, leave=True)
    t.close()
    assert t.tgio.message_id is not None
    t = tqdm_telegram(total=10, leave=False)
    t.close()
    assert t.tgio.message_id is None
    t = tqdm_telegram(total=10, leave=None)
    t.close()
    assert t.tgio.message_id is None
    t = tqdm_telegram(total=10, leave=None)
    t.update(10)
    t.close()
    assert t.tgio.message_id is not None

# Generated at 2022-06-18 11:30:53.143961
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(total=10, leave=False)
    t.close()
    assert t.tgio.message_id is None
    t = tqdm_telegram(total=10, leave=True)
    t.close()
    assert t.tgio.message_id is not None
    t = tqdm_telegram(total=10, leave=None)
    t.close()
    assert t.tgio.message_id is None
    t = tqdm_telegram(total=10, leave=None)
    t.update(1)
    t.close()
    assert t.tgio.message_id is not None

# Generated at 2022-06-18 11:32:43.331081
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(total=1, leave=False)
    t.close()
    assert t.tgio.message_id is None
    t = tqdm_telegram(total=1, leave=True)
    t.close()
    assert t.tgio.message_id is not None
    t = tqdm_telegram(total=0, leave=None)
    t.close()
    assert t.tgio.message_id is None
    t = tqdm_telegram(total=0, leave=None)
    t.update(1)
    t.close()
    assert t.tgio.message_id is not None

# Generated at 2022-06-18 11:32:49.740351
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    """Test for tqdm_telegram constructor"""
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.auto import tqdm
    from tqdm.utils import _term_move_up
    from tqdm.tests import pretest_posttest

    with pretest_posttest() as (stdout, _):
        for _ in tqdm_telegram(range(3)):
            pass
        assert stdout.getvalue() == _term_move_up() + '\r' + \
            '{l_bar}{bar:10u}{r_bar}' + '\n'
        for _ in tqdm(range(3), disable=True):
            pass

# Generated at 2022-06-18 11:32:58.992374
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from time import sleep
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.contrib.telegram.utils_worker import MonoWorker
    from tqdm.contrib.telegram.utils_worker import _worker_thread
    from tqdm.contrib.telegram.utils_worker import _worker_thread_stop
    from tqdm.contrib.telegram.utils_worker import _worker_thread_start
    from tqdm.contrib.telegram.utils_worker import _worker_thread_join
    from tqdm.contrib.telegram.utils_worker import _worker_thread_is_alive
    from tqdm.contrib.telegram.utils_worker import _worker_thread_is_stopped

# Generated at 2022-06-18 11:33:08.384682
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from os import environ
    from time import sleep
    from tqdm.auto import tqdm
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.contrib.telegram.utils_worker import MonoWorker

    # Test constructor
    tqdm_telegram(disable=True)
    tqdm_telegram(token='token', chat_id='chat_id')
    tqdm_telegram(token='token', chat_id='chat_id', disable=True)
    tqdm_telegram(token='token', chat_id='chat_id', disable=False)
    tqdm_telegram(token='token', chat_id='chat_id', disable=False,
                  mininterval=0.1)

# Generated at 2022-06-18 11:33:13.273200
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from io import StringIO
    from sys import stdout
    from time import sleep

    try:
        stdout = StringIO()
        t = tqdm_telegram(total=10, file=stdout, mininterval=0.1)
        for i in range(10):
            t.update()
            sleep(0.1)
    finally:
        stdout = stdout.getvalue()
        t.close()
    assert '\r' in stdout
    assert '\n' not in stdout
    assert '100%' in stdout

# Generated at 2022-06-18 11:33:20.438111
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from os import environ
    from time import sleep
    from unittest import TestCase
    from unittest.mock import patch

    class TestTqdmTelegramClose(TestCase):
        def setUp(self):
            self.token = environ.get('TQDM_TELEGRAM_TOKEN')
            self.chat_id = environ.get('TQDM_TELEGRAM_CHAT_ID')
            self.tqdm = tqdm_telegram(
                range(10), token=self.token, chat_id=self.chat_id)

        def tearDown(self):
            self.tqdm.close()
