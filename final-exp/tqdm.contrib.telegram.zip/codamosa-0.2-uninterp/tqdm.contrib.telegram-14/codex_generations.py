

# Generated at 2022-06-18 11:26:08.814087
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    import time
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.auto import tqdm
    with tqdm(total=10, leave=False) as pbar:
        for i in range(10):
            time.sleep(0.1)
            pbar.update(1)
    with tqdm_telegram(total=10, leave=False, token='{token}', chat_id='{chat_id}') as pbar:
        for i in range(10):
            time.sleep(0.1)
            pbar.update(1)

# Generated at 2022-06-18 11:26:13.690600
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from time import sleep
    for i in tqdm_telegram(range(3), token='{token}', chat_id='{chat_id}'):
        sleep(0.1)
        tqdm_telegram.clear()
        sleep(0.1)

# Generated at 2022-06-18 11:26:22.788013
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from os import environ
    from time import sleep
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.contrib.telegram.utils_worker import MonoWorker
    from tqdm.contrib.telegram.utils_worker import ThreadPoolExecutor

    environ['TQDM_TELEGRAM_TOKEN'] = '123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    environ['TQDM_TELEGRAM_CHAT_ID'] = '123456789'

    with tqdm_telegram(total=10, desc='test_tqdm_telegram_display') as t:
        for i in range(10):
            sleep(0.1)
            t.update()


# Generated at 2022-06-18 11:26:32.261161
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    # Test leave=True
    t = tqdm_telegram(total=10, leave=True)
    t.close()
    assert t.tgio.message_id is None
    # Test leave=False
    t = tqdm_telegram(total=10, leave=False)
    t.close()
    assert t.tgio.message_id is not None
    # Test leave=None
    t = tqdm_telegram(total=10, leave=None)
    t.close()
    assert t.tgio.message_id is None
    # Test leave=None and pos=0
    t = tqdm_telegram(total=10, leave=None)
    t.update(10)
    t.close()
    assert t.tgio.message_id is not None

# Generated at 2022-06-18 11:26:39.992025
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from os import environ
    from time import sleep
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.utils import _term_move_up

    # Test with token and chat_id
    environ['TQDM_TELEGRAM_TOKEN'] = '123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    environ['TQDM_TELEGRAM_CHAT_ID'] = '123456789'
    t = tqdm_telegram(total=10)
    for i in range(10):
        sleep(0.1)
        t.update()
    t.close()
    _term_move_up()

    # Test without token and chat_id

# Generated at 2022-06-18 11:26:49.645898
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from os import getenv
    from sys import version_info
    from time import sleep
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.contrib.telegram.utils_worker import MonoWorker
    from tqdm.utils import _range

    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')

    if version_info[0] == 2:
        from tqdm import tqdm as tqdm_auto
    else:
        from tqdm.auto import tqdm as tqdm_auto


# Generated at 2022-06-18 11:26:51.969630
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tgio = TelegramIO('token', 'chat_id')
    tgio.delete()
    tgio.close()

# Generated at 2022-06-18 11:27:02.097063
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from time import sleep
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.contrib.telegram import TelegramIO
    from tqdm.contrib.telegram import tqdm
    from tqdm.contrib.telegram import trange
    from tqdm.contrib.telegram import ttgrange
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.contrib.telegram import TelegramIO
    from tqdm.contrib.telegram import tqdm
    from tqdm.contrib.telegram import trange
    from tqdm.contrib.telegram import ttgrange
    from tqdm.contrib.telegram import tqdm_telegram

# Generated at 2022-06-18 11:27:05.717504
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import sys
    import time
    from tqdm.contrib.telegram import TelegramIO
    tgio = TelegramIO(token='{token}', chat_id='{chat_id}')
    for i in range(10):
        tgio.write(str(i))
        time.sleep(1)
    tgio.write('Done')
    sys.exit(0)

# Generated at 2022-06-18 11:27:14.449446
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from os import environ
    from time import sleep
    token = environ.get('TQDM_TELEGRAM_TOKEN')
    chat_id = environ.get('TQDM_TELEGRAM_CHAT_ID')
    if token is None or chat_id is None:
        return
    tgio = TelegramIO(token, chat_id)
    tgio.write("Hello World!")
    sleep(1)
    tgio.write("Hello World!")
    sleep(1)
    tgio.write("Hello World!")
    sleep(1)
    tgio.write("Hello World!")
    sleep(1)
    tgio.write("Hello World!")
    sleep(1)
    tgio.write("Hello World!")
    sleep(1)
    t

# Generated at 2022-06-18 11:29:10.189293
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from os import environ
    from time import sleep
    from tqdm.contrib.telegram import TelegramIO
    from tqdm.utils import _term_move_up
    tg = TelegramIO(environ['TQDM_TELEGRAM_TOKEN'],
                    environ['TQDM_TELEGRAM_CHAT_ID'])
    tg.write('test')
    sleep(1)
    tg.write('test')
    sleep(1)
    tg.write('test')
    sleep(1)
    tg.write('test')
    sleep(1)
    tg.write('test')
    sleep(1)
    tg.write('test')
    sleep(1)
    tg.write('test')
    sleep(1)
    tg.write('test')

# Generated at 2022-06-18 11:29:18.562577
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm import tqdm
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.contrib.telegram import TelegramIO
    from tqdm.contrib.telegram import ttgrange
    from tqdm.contrib.telegram import tqdm
    from tqdm.contrib.telegram import trange
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.contrib.telegram import TelegramIO
    from tqdm.contrib.telegram import ttgrange
    from tqdm.contrib.telegram import tqdm
    from tqdm.contrib.telegram import trange
    from tqdm.contrib.telegram import tqdm_telegram

# Generated at 2022-06-18 11:29:28.387528
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from os import getenv
    from time import sleep
    from tqdm import tqdm
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.contrib.telegram.utils_worker import MonoWorker
    from tqdm.contrib.telegram.utils_worker import ThreadPoolExecutor

    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if not (token and chat_id):
        raise RuntimeError("Please set TQDM_TELEGRAM_TOKEN and "
                           "TQDM_TELEGRAM_CHAT_ID")

    tqdm_telegram.tgio = TelegramIO(token, chat_id)
    tqdm_

# Generated at 2022-06-18 11:29:32.001111
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    with tqdm_telegram(total=10, token='123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZ', chat_id='123456789') as pbar:
        for i in range(10):
            pbar.update()

# Generated at 2022-06-18 11:29:33.139114
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tg = TelegramIO('', '')
    tg.delete()

# Generated at 2022-06-18 11:29:38.370315
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(total=10, leave=True)
    t.close()
    t = tqdm_telegram(total=10, leave=False)
    t.close()
    t = tqdm_telegram(total=10, leave=None)
    t.close()
    t = tqdm_telegram(total=10, leave=None)
    t.update(10)
    t.close()

# Generated at 2022-06-18 11:29:45.733024
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from os import environ
    from time import sleep
    from .utils import _range
    from .utils_test import _supports_unicode, _test_closing, _test_leave
    from .utils_test import _test_postfix, _test_unit_scale, _test_write
    from .utils_test import _test_miniters, _test_mininterval, _test_gui
    from .utils_test import _test_desc, _test_total, _test_dynamic_miniters
    from .utils_test import _test_position, _test_smoothing, _test_unicode
    from .utils_test import _test_iterable, _test_deprecated_miniters
    from .utils_test import _test_deprecated_mininterval
    from .utils_test import _test_

# Generated at 2022-06-18 11:29:47.286740
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from .tests_telegram import test_tqdm_telegram
    test_tqdm_telegram()

# Generated at 2022-06-18 11:29:54.882003
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.auto import tqdm
    from tqdm.utils import _term_move_up
    from time import sleep

    # Test for method display of class tqdm_telegram
    with tqdm(total=10, disable=True) as pbar:
        for i in range(10):
            pbar.update(1)
            sleep(0.1)
            pbar.display()

    # Test for method display of class tqdm_telegram
    with tqdm(total=10, disable=True) as pbar:
        for i in range(10):
            pbar.update(1)
            sleep(0.1)
            pbar.display()
            _term_move_up()

    # Test for

# Generated at 2022-06-18 11:30:03.222872
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm.auto import tqdm
    from tqdm.contrib.telegram import tqdm_telegram
    import sys
    import time

    # Test tqdm_telegram
    with tqdm(total=10, file=sys.stdout) as pbar:
        for i in range(10):
            time.sleep(0.1)
            pbar.update()

    # Test tqdm
    with tqdm(total=10, file=sys.stdout) as pbar:
        for i in range(10):
            time.sleep(0.1)
            pbar.update()

    # Test tqdm_telegram

# Generated at 2022-06-18 11:33:13.415061
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tg = TelegramIO('token', 'chat_id')
    tg.delete()

# Generated at 2022-06-18 11:33:17.604372
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import time
    from tqdm.contrib.telegram import tqdm_telegram
    with tqdm_telegram(total=10, token='{token}', chat_id='{chat_id}') as pbar:
        for i in range(10):
            pbar.update(1)
            time.sleep(0.1)
            pbar.clear()
            time.sleep(0.1)