

# Generated at 2022-06-18 11:26:35.841036
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm.auto import tqdm
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.utils import _term_move_up
    from tqdm.std import sys

    def _test_display(cls):
        with cls(total=10) as pbar:
            for i in range(10):
                pbar.update()
                pbar.display()
                sys.stderr.write(_term_move_up())
                sys.stderr.flush()

    _test_display(tqdm)
    _test_display(tqdm_telegram)

# Generated at 2022-06-18 11:26:40.722215
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from os import environ
    token = environ.get('TQDM_TELEGRAM_TOKEN')
    chat_id = environ.get('TQDM_TELEGRAM_CHAT_ID')
    if token is None or chat_id is None:
        raise RuntimeError("Please set TQDM_TELEGRAM_TOKEN and TQDM_TELEGRAM_CHAT_ID")
    tgio = TelegramIO(token, chat_id)
    tgio.write("Hello World!")
    tgio.delete()

# Generated at 2022-06-18 11:26:51.063986
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    """
    Unit test for method display of class tqdm_telegram
    """
    from time import sleep
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.auto import tqdm
    from tqdm.utils import _term_move_up
    from tqdm.std import sys
    from tqdm.std import StringIO

    # Test with disable=True
    with tqdm(disable=True) as t:
        t.display()

    # Test with disable=False
    with tqdm(disable=False) as t:
        t.display()

    # Test with disable=False and leave=True
    with tqdm(disable=False, leave=True) as t:
        t.display()

    # Test with disable=False and leave=False
   

# Generated at 2022-06-18 11:26:54.218295
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    """Unit test for method display of class tqdm_telegram"""
    from .utils_test import _test_display
    _test_display(tqdm_telegram)

# Generated at 2022-06-18 11:26:56.866784
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(disable=True)
    t.close()
    t = tqdm_telegram(disable=False)
    t.close()

# Generated at 2022-06-18 11:27:05.212382
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.auto import tqdm
    from tqdm.utils import _term_move_up
    from time import sleep
    from os import getenv
    from os.path import isfile
    from os import remove
    from sys import stdout
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = stdout, stderr
        try:
            stdout, stderr = new_out, new_err
            yield stdout, stderr
        finally:
            stdout, stderr = old_out, old_err


# Generated at 2022-06-18 11:27:14.413684
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import sys
    from io import StringIO
    from tqdm.auto import tqdm

    class tqdm_telegram_test(tqdm_telegram):
        def display(self, **kwargs):
            super(tqdm_telegram_test, self).display(**kwargs)
            self.tgio.write(self.format_meter(**self.format_dict))

    # Test with bar_format
    with StringIO() as our_file, \
            StringIO() as err_file, \
            tqdm_telegram_test(
                total=10, file=our_file, bar_format='{bar}',
                disable=False, token='{token}', chat_id='{chat_id}') as t:
        for i in range(10):
            t.update()
       

# Generated at 2022-06-18 11:27:23.541705
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(total=10)
    t.close()
    assert t.tgio.message_id is None
    t = tqdm_telegram(total=10, leave=True)
    t.close()
    assert t.tgio.message_id is not None
    t = tqdm_telegram(total=10, leave=False)
    t.close()
    assert t.tgio.message_id is None
    t = tqdm_telegram(total=0, leave=None)
    t.close()
    assert t.tgio.message_id is None
    t = tqdm_telegram(total=10, leave=None)
    t.close()
    assert t.tgio.message_id is not None

# Generated at 2022-06-18 11:27:32.222228
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from io import StringIO
    from sys import stdout
    from time import sleep
    from tqdm import tqdm

    with StringIO() as f:
        with tqdm(total=10, file=f, leave=False) as pbar:
            for i in range(10):
                pbar.update()
                sleep(0.1)
        assert f.getvalue() == ''

    with StringIO() as f:
        with tqdm(total=10, file=f, leave=True) as pbar:
            for i in range(10):
                pbar.update()
                sleep(0.1)
        assert f.getvalue() != ''


# Generated at 2022-06-18 11:27:41.802020
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    import os
    import sys
    import time
    from tqdm.contrib.telegram import TelegramIO
    from tqdm.auto import tqdm
    from tqdm.utils import _term_move_up

    token = os.getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = os.getenv('TQDM_TELEGRAM_CHAT_ID')
    if not (token and chat_id):
        print("Please set TQDM_TELEGRAM_TOKEN and TQDM_TELEGRAM_CHAT_ID "
              "environment variables to run this test.")
        sys.exit(1)

    tgio = TelegramIO(token, chat_id)
    tgio.write("Test message")
    time.sleep(1)
    tgio.delete

# Generated at 2022-06-18 11:29:52.372685
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm.auto import tqdm
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.utils import _term_move_up
    from time import sleep
    from sys import stdout
    from io import StringIO
    from re import sub

    # Test tqdm_telegram.display()
    with StringIO() as f:
        with tqdm(total=10, file=f, ncols=0, mininterval=0) as t:
            for i in range(10):
                t.update()
                sleep(0.1)

# Generated at 2022-06-18 11:29:58.180627
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.auto import tqdm
    from time import sleep
    from os import getenv
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    for i in tqdm_telegram(range(10), token=token, chat_id=chat_id):
        sleep(0.1)
        tqdm.clear()
        sleep(0.1)

# Generated at 2022-06-18 11:30:06.793240
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from os import environ
    from time import sleep
    from requests import Session
    from .utils_worker import MonoWorker
    from .utils_telegram import TelegramIO

    class TestTelegramIO(TelegramIO):
        def __init__(self, token, chat_id):
            super(TestTelegramIO, self).__init__(token, chat_id)
            self.session = Session()
            self.text = self.__class__.__name__
            self.message_id

    class TestMonoWorker(MonoWorker):
        def __init__(self):
            super(TestMonoWorker, self).__init__()
            self.session = Session()

        def submit(self, func, *args, **kwargs):
            return func(*args, **kwargs)


# Generated at 2022-06-18 11:30:15.092209
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """
    Test for method close of class tqdm_telegram
    """
    t = tqdm_telegram(total=100, leave=True)
    t.close()
    assert t.disable == True
    t.close()
    assert t.disable == True
    t = tqdm_telegram(total=100, leave=False)
    t.close()
    assert t.disable == True
    t.close()
    assert t.disable == True
    t = tqdm_telegram(total=100, leave=None)
    t.close()
    assert t.disable == True
    t.close()
    assert t.disable == True
    t = tqdm_telegram(total=100, leave=None)
    t.close()
    assert t.disable == True
    t.close()

# Generated at 2022-06-18 11:30:24.516693
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .tests_tqdm import pretest_posttest_monkeypatch
    from .tests_tqdm import StringIO
    from .tests_tqdm import _range
    from .tests_tqdm import closing
    from .tests_tqdm import format_interval
    from .tests_tqdm import format_meter
    from .tests_tqdm import format_sizeof
    from .tests_tqdm import format_timespan
    from .tests_tqdm import format_transferrate
    from .tests_tqdm import format_eta
    from .tests_tqdm import format_speed
    from .tests_tqdm import format_size
    from .tests_tqdm import format_number
    from .tests_tqdm import format_percentage
    from .tests_tqdm import format_

# Generated at 2022-06-18 11:30:27.982692
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tg = TelegramIO(getenv('TQDM_TELEGRAM_TOKEN'),
                    getenv('TQDM_TELEGRAM_CHAT_ID'))
    tg.delete()

# Generated at 2022-06-18 11:30:38.044909
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm import tqdm
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.contrib.telegram import TelegramIO
    from tqdm.contrib.telegram import ttgrange
    from tqdm.contrib.telegram import tqdm
    from tqdm.contrib.telegram import trange
    from tqdm.contrib.telegram import test_tqdm_telegram_clear
    from tqdm.contrib.telegram import __author__
    from tqdm.contrib.telegram import __all__
    from tqdm.contrib.telegram import __doc__
    from tqdm.contrib.telegram import __version__
    from tqdm.contrib.telegram import __license__

# Generated at 2022-06-18 11:30:46.875583
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(total=100, disable=True)
    t.close()
    t = tqdm_telegram(total=100, leave=True)
    t.close()
    t = tqdm_telegram(total=100, leave=False)
    t.close()
    t = tqdm_telegram(total=100, leave=None)
    t.close()
    t = tqdm_telegram(total=100, leave=None)
    t.pos = 1
    t.close()
    t = tqdm_telegram(total=100, leave=None)
    t.pos = 0
    t.close()

# Generated at 2022-06-18 11:30:49.041151
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tg = TelegramIO('token', 'chat_id')
    tg.delete()

# Generated at 2022-06-18 11:30:55.495422
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.auto import tqdm
    from time import sleep
    from os import getenv
    from sys import stderr
    from io import StringIO
    from unittest import TestCase

    class TestTelegram(TestCase):
        def setUp(self):
            self.token = getenv('TQDM_TELEGRAM_TOKEN')
            self.chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
            self.old_stderr = stderr
            stderr = StringIO()

        def tearDown(self):
            stderr = self.old_stderr
