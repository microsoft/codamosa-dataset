

# Generated at 2022-06-18 11:27:45.462764
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from io import StringIO
    from sys import stdout
    from time import sleep
    from tqdm import tqdm
    from tqdm.contrib.telegram import tqdm_telegram

    # Test with a token and a chat_id
    with StringIO() as f:
        tqdm_telegram(
            [1, 2, 3], file=f, token='1234567890:ABCDEFGHIJKLMNOPQRSTUVWXYZ',
            chat_id='1234567890').display()
        assert f.getvalue() == '\r  0%|          | 0/3 [00:00<?, ?it/s]\n'

    # Test with a token and a chat_id

# Generated at 2022-06-18 11:27:46.693372
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tgio = TelegramIO('token', 'chat_id')
    tgio.delete()

# Generated at 2022-06-18 11:27:52.413278
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """
    Unit test for method close of class tqdm_telegram.
    """
    from tqdm.auto import tqdm
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.contrib.telegram import ttgrange
    from tqdm.contrib.telegram import tqdm
    from tqdm.contrib.telegram import trange
    from tqdm.contrib.telegram import TelegramIO
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.contrib.telegram import ttgrange
    from tqdm.contrib.telegram import tqdm
    from tqdm.contrib.telegram import trange
    from tqdm.contrib.telegram import TelegramIO
   

# Generated at 2022-06-18 11:28:00.828544
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    # Test for leave=True
    t = tqdm_telegram(total=10, leave=True)
    t.close()
    assert t.tgio.message_id is None

    # Test for leave=False
    t = tqdm_telegram(total=10, leave=False)
    t.close()
    assert t.tgio.message_id is not None

    # Test for leave=None
    t = tqdm_telegram(total=10, leave=None)
    t.close()
    assert t.tgio.message_id is None

    # Test for leave=None and pos=0
    t = tqdm_telegram(total=10, leave=None)
    t.update(10)
    t.close()
    assert t.tgio.message_id is not None

# Generated at 2022-06-18 11:28:08.549853
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tgio = TelegramIO('12345678:ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghi',
                      '1234567890')
    assert tgio.write('test') is None
    assert tgio.write('test') is None
    assert tgio.write('test') is None
    assert tgio.write('test') is None
    assert tgio.write('test') is None
    assert tgio.write('test') is None
    assert tgio.write('test') is None
    assert tgio.write('test') is None
    assert tgio.write('test') is None
    assert tgio.write('test') is None
    assert tgio.write('test') is None
    assert tgio.write('test') is None

# Generated at 2022-06-18 11:28:19.926434
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    """
    Unit test for method write of class TelegramIO
    """
    import os
    import sys
    import unittest
    from unittest.mock import patch
    from requests import Response

    class TestTelegramIO(unittest.TestCase):
        """
        Unit test for method write of class TelegramIO
        """
        def setUp(self):
            self.token = os.getenv('TQDM_TELEGRAM_TOKEN')
            self.chat_id = os.getenv('TQDM_TELEGRAM_CHAT_ID')
            self.tgio = TelegramIO(self.token, self.chat_id)

        def test_write(self):
            """
            Test write method
            """

# Generated at 2022-06-18 11:28:24.770228
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from time import sleep
    from tqdm.contrib.telegram import tqdm, trange
    for i in trange(10, token='{token}', chat_id='{chat_id}'):
        sleep(0.1)
    for i in trange(10, token='{token}', chat_id='{chat_id}', leave=False):
        sleep(0.1)

# Generated at 2022-06-18 11:28:29.871401
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    """
    Unit test for method clear of class tqdm_telegram.
    """
    import time
    from tqdm.contrib.telegram import tqdm, trange
    for i in trange(10, token='{token}', chat_id='{chat_id}'):
        time.sleep(0.1)
        if i == 5:
            tqdm.clear()

if __name__ == '__main__':
    test_tqdm_telegram_clear()

# Generated at 2022-06-18 11:28:31.544959
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tg = TelegramIO('{token}', '{chat_id}')
    tg.delete()
    tg.close()

# Generated at 2022-06-18 11:28:33.086140
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """
    Test if the method close of class tqdm_telegram works properly.
    """
    t = tqdm_telegram(total=10)
    t.close()
    assert t.disable

# Generated at 2022-06-18 11:30:37.606885
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """
    Test for method close of class tqdm_telegram.
    """
    import os
    import time
    import random
    import unittest

    class TestTqdmTelegramClose(unittest.TestCase):
        """
        Test for method close of class tqdm_telegram.
        """
        def test_tqdm_telegram_close(self):
            """
            Test for method close of class tqdm_telegram.
            """
            token = os.getenv('TQDM_TELEGRAM_TOKEN')
            chat_id = os.getenv('TQDM_TELEGRAM_CHAT_ID')
            if token is None or chat_id is None:
                return

# Generated at 2022-06-18 11:30:39.770739
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tg = TelegramIO('token', 'chat_id')
    tg.write('test')
    assert tg.text == 'test'

# Generated at 2022-06-18 11:30:45.691284
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from time import sleep
    from tqdm.contrib.telegram import tqdm, trange
    for i in trange(10, token='{token}', chat_id='{chat_id}'):
        sleep(0.1)
        if i == 5:
            tqdm.clear()

if __name__ == '__main__':
    test_tqdm_telegram_clear()

# Generated at 2022-06-18 11:30:54.305203
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from time import sleep
    from tqdm import tqdm
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.contrib.telegram.utils_worker import MonoWorker

    # Create a tqdm_telegram instance
    tg = tqdm_telegram(total=10, token='{token}', chat_id='{chat_id}')

    # Create a tqdm instance
    t = tqdm(total=10)

    # Test clear method of tqdm_telegram
    tg.clear()

    # Test clear method of tqdm
    t.clear()

    # Test clear method of MonoWorker
    MonoWorker.clear()

    # Test clear method of tqdm_telegram
    tg.clear()

    # Test clear method

# Generated at 2022-06-18 11:30:57.781801
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm.contrib.telegram import tqdm, trange
    for i in trange(10, token='{token}', chat_id='{chat_id}'):
        pass

# Generated at 2022-06-18 11:30:59.606069
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .utils_test import _test_display
    _test_display(tqdm_telegram)

# Generated at 2022-06-18 11:31:03.072246
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from time import sleep
    from tqdm.contrib.telegram import tqdm, trange
    for i in trange(10, token='{token}', chat_id='{chat_id}'):
        sleep(0.1)
        if i == 5:
            tqdm.clear()


# Generated at 2022-06-18 11:31:05.528378
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    import os
    from .utils_test import _test_delete
    _test_delete(TelegramIO(os.getenv('TQDM_TELEGRAM_TOKEN'),
                            os.getenv('TQDM_TELEGRAM_CHAT_ID')))

# Generated at 2022-06-18 11:31:15.908936
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from os import environ
    environ['TQDM_TELEGRAM_TOKEN'] = '123456789:AAHd-_GHIjKLmnOPqrSTuvWXyZ12345678'
    environ['TQDM_TELEGRAM_CHAT_ID'] = '1234567890'
    tqdm_telegram(range(3))
    tqdm_telegram(range(3), token='123456789:AAHd-_GHIjKLmnOPqrSTuvWXyZ12345678',
                  chat_id='1234567890')

# Generated at 2022-06-18 11:31:18.748253
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    import pytest
    from tqdm.contrib.telegram import tqdm_telegram

    with pytest.raises(Exception):
        tqdm_telegram(range(10), token='{token}', chat_id='{chat_id}').close()