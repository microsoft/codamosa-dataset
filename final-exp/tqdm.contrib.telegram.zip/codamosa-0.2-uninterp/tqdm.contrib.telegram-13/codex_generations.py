

# Generated at 2022-06-18 11:27:33.265500
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """
    Tests method close of class tqdm_telegram.
    """
    from time import sleep
    from tqdm import tqdm
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.contrib.telegram.utils_worker import MonoWorker

    # Test tqdm_telegram.close()
    tqdm_telegram(range(10), leave=False, disable=True).close()
    tqdm_telegram(range(10), leave=False, disable=False).close()
    tqdm_telegram(range(10), leave=True, disable=True).close()
    tqdm_telegram(range(10), leave=True, disable=False).close()

# Generated at 2022-06-18 11:27:42.920930
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.auto import tqdm
    from time import sleep
    from os import getenv
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    for _ in tqdm(range(10), token=token, chat_id=chat_id):
        sleep(0.1)
        tqdm.clear()
    for _ in tqdm(range(10), token=token, chat_id=chat_id):
        sleep(0.1)
        tqdm.clear(nolock=True)

# Generated at 2022-06-18 11:27:49.378104
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    """Test tqdm_telegram constructor"""
    # Test token and chat_id
    with tqdm_telegram(total=1, token='token', chat_id='chat_id') as pbar:
        assert pbar.tgio.token == 'token'
        assert pbar.tgio.chat_id == 'chat_id'
    # Test token and chat_id from environment variables
    with tqdm_telegram(total=1) as pbar:
        assert pbar.tgio.token == getenv('TQDM_TELEGRAM_TOKEN')
        assert pbar.tgio.chat_id == getenv('TQDM_TELEGRAM_CHAT_ID')
    # Test disable
    with tqdm_telegram(total=1, disable=True) as pbar:
        assert pbar

# Generated at 2022-06-18 11:27:57.935357
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import sys
    from io import StringIO
    from tqdm.contrib.telegram import tqdm_telegram
    with StringIO() as f:
        t = tqdm_telegram(range(10), file=f, disable=True)
        t.clear()
        assert f.getvalue() == ""
        t.close()
        assert f.getvalue() == ""
        t = tqdm_telegram(range(10), file=f)
        t.clear()
        assert f.getvalue() == ""
        t.close()
        assert f.getvalue() == ""
        t = tqdm_telegram(range(10), file=f, leave=True)
        t.clear()
        assert f.getvalue() == ""
        t.close()
        assert f.getvalue() == ""

# Generated at 2022-06-18 11:28:00.827733
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from time import sleep
    from tqdm import tqdm_telegram
    for i in tqdm_telegram(range(10), token='{token}', chat_id='{chat_id}'):
        sleep(0.1)

# Generated at 2022-06-18 11:28:02.655926
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    with tqdm_telegram(total=10, token='{token}', chat_id='{chat_id}') as t:
        for i in range(10):
            t.update()

# Generated at 2022-06-18 11:28:08.577967
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.auto import tqdm
    from tqdm.utils import _term_move_up
    from io import StringIO
    from sys import stdout
    from time import sleep
    from os import environ

    environ['TQDM_TELEGRAM_TOKEN'] = '123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    environ['TQDM_TELEGRAM_CHAT_ID'] = '123456789'

    with StringIO() as f:
        with tqdm_telegram(total=10, file=f, leave=False) as pbar:
            for i in range(10):
                pbar.update()
                sleep(0.1)

# Generated at 2022-06-18 11:28:19.926339
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from io import StringIO
    import sys
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.utils import _term_move_up

    # Test with no bar_format
    with StringIO() as our_file, StringIO() as err_file:
        sys.stderr = err_file
        with tqdm_telegram(total=10, file=our_file, bar_format=None) as t:
            t.display()
        sys.stderr = sys.__stderr__
        assert our_file.getvalue() == '{l_bar}{bar:10u}{r_bar}\r'
        assert err_file.getvalue() == ''

    # Test with bar_format

# Generated at 2022-06-18 11:28:21.668839
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(total=10, leave=False)
    t.close()
    assert t.tgio.message_id is None
    t = tqdm_telegram(total=10, leave=True)
    t.close()
    assert t.tgio.message_id is not None

# Generated at 2022-06-18 11:28:29.650334
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    import os
    import time
    import unittest
    from tqdm.contrib.telegram import TelegramIO
    from tqdm.utils import _term_move_up

    class TelegramIOTest(unittest.TestCase):
        def setUp(self):
            self.token = os.environ.get('TQDM_TELEGRAM_TOKEN')
            self.chat_id = os.environ.get('TQDM_TELEGRAM_CHAT_ID')
            self.tgio = TelegramIO(self.token, self.chat_id)
            self.tgio.write("")

        def test_delete(self):
            self.tgio.delete()
            time.sleep(1)
            self.assertEqual(self.tgio.message_id, None)

    unittest

# Generated at 2022-06-18 11:29:57.542280
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from .utils_test import _test_close
    _test_close(tqdm_telegram)

# Generated at 2022-06-18 11:29:58.935678
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .utils_test import _test_display
    _test_display(tqdm_telegram)

# Generated at 2022-06-18 11:30:07.679239
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from io import StringIO
    from sys import stdout
    from time import sleep
    from tqdm import tqdm
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.utils import _term_move_up

    # Test tqdm_telegram.display
    with StringIO() as f:
        with tqdm(total=10, file=f, ncols=100) as pbar:
            pbar.display()
            assert f.getvalue() == '\n'

    with StringIO() as f:
        with tqdm(total=10, file=f, ncols=100) as pbar:
            pbar.display(bar_format='{l_bar}{bar}{r_bar}')
            assert f.getvalue() == '\n'

# Generated at 2022-06-18 11:30:15.807359
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    import time
    from tqdm.contrib.telegram import tqdm, trange
    for i in trange(10, token='{token}', chat_id='{chat_id}'):
        time.sleep(0.1)
    for i in trange(10, token='{token}', chat_id='{chat_id}', leave=True):
        time.sleep(0.1)
    for i in trange(10, token='{token}', chat_id='{chat_id}', leave=False):
        time.sleep(0.1)
    for i in trange(10, token='{token}', chat_id='{chat_id}', leave=None):
        time.sleep(0.1)

# Generated at 2022-06-18 11:30:25.221369
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.auto import tqdm
    from tqdm.utils import _term_move_up
    from tqdm.utils import _range
    from tqdm.utils import _environ_cols_wrapper
    from tqdm.utils import _unicode
    from tqdm.utils import _supports_unicode
    from tqdm.utils import _environ_cols_wrapper
    from tqdm.utils import _screen_shape
    from tqdm.utils import _unicode
    from tqdm.utils import _supports_unicode
    from tqdm.utils import _range
    from tqdm.utils import _term_move_up
    from tqdm.utils import _unicode

# Generated at 2022-06-18 11:30:27.621678
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from .utils_test import _test_clear
    _test_clear(tqdm_telegram)

# Generated at 2022-06-18 11:30:37.652467
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm import tqdm
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.contrib.telegram.utils_worker import MonoWorker
    from tqdm.contrib.telegram.utils_worker import Worker
    from tqdm.contrib.telegram.utils_worker import WorkerPool
    from tqdm.contrib.telegram.utils_worker import _WorkerPool
    from tqdm.contrib.telegram.utils_worker import _WorkerPoolExecutor
    from tqdm.contrib.telegram.utils_worker import _WorkerPoolThread
    from tqdm.contrib.telegram.utils_worker import _WorkerPoolProcess
    from tqdm.contrib.telegram.utils_worker import _WorkerPoolFuture

# Generated at 2022-06-18 11:30:39.813978
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(total=10)
    t.close()
    assert t.tgio.message_id is None

# Generated at 2022-06-18 11:30:48.733247
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(total=10)
    t.close()
    assert t.tgio.message_id is None
    t = tqdm_telegram(total=10, leave=True)
    t.close()
    assert t.tgio.message_id is not None
    t = tqdm_telegram(total=0, leave=True)
    t.close()
    assert t.tgio.message_id is not None
    t = tqdm_telegram(total=0, leave=False)
    t.close()
    assert t.tgio.message_id is None

# Generated at 2022-06-18 11:30:58.164156
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from os import getenv
    from time import sleep
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.tests import common
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if token is None or chat_id is None:
        raise common.SkipTest("No Telegram token or chat ID found")
    t = tqdm_telegram(total=10, token=token, chat_id=chat_id)
    for i in range(10):
        sleep(0.1)
        t.update()
    t.close()

# Generated at 2022-06-18 11:32:27.188182
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tgio = TelegramIO('', '')
    tgio.delete()

# Generated at 2022-06-18 11:32:29.733574
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from time import sleep
    from tqdm.contrib.telegram import tqdm, trange
    for i in trange(10, token='{token}', chat_id='{chat_id}'):
        sleep(0.1)
        if i == 5:
            tqdm.clear()


# Generated at 2022-06-18 11:32:33.191309
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(total=10, leave=False)
    t.close()
    assert t.tgio.message_id is None
    t = tqdm_telegram(total=10, leave=True)
    t.close()
    assert t.tgio.message_id is not None
    t = tqdm_telegram(total=10, leave=None)
    t.close()
    assert t.tgio.message_id is None
    t = tqdm_telegram(total=10, leave=None)
    t.update(1)
    t.close()
    assert t.tgio.message_id is not None

# Generated at 2022-06-18 11:32:35.931494
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from time import sleep
    from tqdm.contrib.telegram import tqdm, trange
    for i in trange(10, token='{token}', chat_id='{chat_id}'):
        sleep(0.1)
        if i == 5:
            tqdm.clear()


# Generated at 2022-06-18 11:32:42.017861
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from os import environ
    from time import sleep
    from tqdm.contrib.telegram import TelegramIO
    from tqdm.tests import _range

    token = environ.get('TQDM_TELEGRAM_TOKEN')
    chat_id = environ.get('TQDM_TELEGRAM_CHAT_ID')
    if not (token and chat_id):
        raise ValueError("Missing token or chat_id")

    tgio = TelegramIO(token, chat_id)
    for i in _range(10):
        tgio.write(str(i))
        sleep(1)
    tgio.delete()

# Generated at 2022-06-18 11:32:45.268646
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from time import sleep
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.auto import tqdm
    from tqdm.utils import _term_move_up
    for _ in tqdm_telegram(range(3), token='{token}', chat_id='{chat_id}'):
        sleep(0.1)
        tqdm.write('\n' + _term_move_up() + '\n')

# Generated at 2022-06-18 11:32:53.102019
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm.auto import tqdm
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.utils import _term_move_up
    from io import StringIO
    import sys
    import time

    # Test tqdm_telegram.display()
    with StringIO() as f:
        with tqdm(total=10, file=f, ncols=80) as pbar:
            pbar.display()
            assert pbar.format_dict['bar_format'] == '{l_bar}{bar}{r_bar}'
            assert f.getvalue() == '  0%|          | 0/10 [00:00<?, ?it/s]\n'
            pbar.update(1)
            pbar.display()
            assert pbar.format_

# Generated at 2022-06-18 11:32:54.655159
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(total=100)
    t.close()
    assert t.tgio.message_id is None

# Generated at 2022-06-18 11:33:05.238358
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    import os
    import sys
    from time import sleep
    from tqdm.contrib.telegram import TelegramIO
    from tqdm.contrib.telegram import tqdm, trange
    from tqdm.contrib.telegram import tqdm_telegram, ttgrange
    from tqdm.contrib.telegram import tqdm_telegram as tqdm_telegram_alias
    from tqdm.contrib.telegram import ttgrange as trange_alias

    token = os.environ.get('TQDM_TELEGRAM_TOKEN')
    chat_id = os.environ.get('TQDM_TELEGRAM_CHAT_ID')

# Generated at 2022-06-18 11:33:12.676805
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import sys
    import time
    import unittest
    from unittest.mock import patch

    class TestTelegramIO(unittest.TestCase):
        def test_write(self):
            with patch.object(sys, 'argv', ['tqdm', '--token', '1234567890',
                                            '--chat_id', '1234567890']):
                tg = TelegramIO('1234567890', '1234567890')
                tg.write('test')
                time.sleep(1)
                tg.write('test')
                time.sleep(1)
                tg.write('test')
                time.sleep(1)
                tg.write('test')
                time.sleep(1)
                tg.write('test')
                time.sleep(1)
               