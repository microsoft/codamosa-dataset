

# Generated at 2022-06-18 11:25:35.281676
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(total=1, leave=False)
    t.close()
    t = tqdm_telegram(total=1, leave=True)
    t.close()
    t = tqdm_telegram(total=1, leave=None)
    t.close()
    t = tqdm_telegram(total=1, leave=None)
    t.update(1)
    t.close()

# Generated at 2022-06-18 11:25:43.881565
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from time import sleep
    from tqdm.contrib.telegram import TelegramIO
    tgio = TelegramIO('{token}', '{chat_id}')
    tgio.write('test')
    sleep(1)
    tgio.write('test2')
    sleep(1)
    tgio.write('test3')
    sleep(1)
    tgio.write('test4')
    sleep(1)
    tgio.write('test5')
    sleep(1)
    tgio.write('test6')
    sleep(1)
    tgio.write('test7')
    sleep(1)
    tgio.write('test8')
    sleep(1)
    tgio.write('test9')
    sleep(1)
    tgio.write

# Generated at 2022-06-18 11:25:52.902295
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from time import sleep
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.auto import tqdm
    from tqdm.utils import _term_move_up
    from tqdm.std import sys

    t = tqdm_telegram(total=10, token='{token}', chat_id='{chat_id}')
    for i in t:
        sleep(0.1)
    t.close()

    t = tqdm(total=10, token='{token}', chat_id='{chat_id}')
    for i in t:
        sleep(0.1)
    t.close()

    t = tqdm(total=10, token='{token}', chat_id='{chat_id}')

# Generated at 2022-06-18 11:25:54.509371
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .utils_test import _test_display
    _test_display(tqdm_telegram)

# Generated at 2022-06-18 11:25:56.378021
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from time import sleep
    for _ in tqdm_telegram(range(10), token='{token}', chat_id='{chat_id}'):
        sleep(0.1)

# Generated at 2022-06-18 11:26:04.839399
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm import tqdm
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.contrib.telegram import TelegramIO
    from tqdm.contrib.telegram import ttgrange
    from tqdm.contrib.telegram import tqdm
    from tqdm.contrib.telegram import trange
    from tqdm.contrib.telegram import test_tqdm_telegram_clear
    from tqdm.contrib.telegram import __author__
    from tqdm.contrib.telegram import __all__
    from tqdm.contrib.telegram import __doc__
    from tqdm.contrib.telegram import __version__
    from tqdm.contrib.telegram import __license__

# Generated at 2022-06-18 11:26:10.968604
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """
    Test method close of class tqdm_telegram.
    """
    t = tqdm_telegram(total=10, leave=False)
    t.close()
    t = tqdm_telegram(total=10, leave=True)
    t.close()
    t = tqdm_telegram(total=10, leave=None)
    t.close()
    t = tqdm_telegram(total=10, leave=None)
    t.update(1)
    t.close()

# Generated at 2022-06-18 11:26:18.814078
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm.contrib.telegram import tqdm_telegram
    from time import sleep
    for i in tqdm_telegram(range(10), token='{token}', chat_id='{chat_id}'):
        sleep(0.1)
        if i == 5:
            tqdm_telegram.clear(leave=True)
            break
    for i in tqdm_telegram(range(10), token='{token}', chat_id='{chat_id}'):
        sleep(0.1)
        if i == 5:
            tqdm_telegram.clear(leave=False)
            break

# Generated at 2022-06-18 11:26:20.864766
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    with tqdm_telegram(total=1, token='{token}', chat_id='{chat_id}') as t:
        t.update()

# Generated at 2022-06-18 11:26:25.397412
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm.contrib.telegram import tqdm_telegram
    import time
    for i in tqdm_telegram(range(10), token='{token}', chat_id='{chat_id}'):
        time.sleep(0.1)
        if i == 5:
            tqdm_telegram.clear(leave=True)
            break

# Generated at 2022-06-18 11:29:06.355363
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from time import sleep
    from tqdm.contrib.telegram import tqdm, trange
    for i in trange(10, token='{token}', chat_id='{chat_id}'):
        sleep(0.1)
        if i == 5:
            tqdm.clear()

if __name__ == '__main__':
    test_tqdm_telegram_clear()

# Generated at 2022-06-18 11:29:10.016698
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import time
    from tqdm.contrib.telegram import tqdm, trange
    for i in trange(10, token='{token}', chat_id='{chat_id}'):
        time.sleep(0.1)
        if i == 5:
            tqdm.clear()
            time.sleep(0.1)

# Generated at 2022-06-18 11:29:14.208632
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm.contrib.telegram import tqdm_telegram
    import time
    for i in tqdm_telegram(range(5), token='{token}', chat_id='{chat_id}'):
        time.sleep(1)
        if i == 2:
            tqdm_telegram.clear(leave=True)
            break


# Generated at 2022-06-18 11:29:20.361574
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from unittest import TestCase, main
    from io import StringIO
    from time import sleep
    from tqdm.contrib.telegram import tqdm_telegram

    class TestTqdmTelegram(TestCase):
        def test_close(self):
            with StringIO() as f:
                for i in tqdm_telegram(range(10), file=f):
                    sleep(0.1)
                self.assertEqual(f.getvalue(), '')

    main()

# Generated at 2022-06-18 11:29:25.546562
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """
    Tests the method close of class tqdm_telegram
    """
    t = tqdm_telegram(total=10, leave=False)
    t.close()
    assert t.tgio.message_id is None

    t = tqdm_telegram(total=10, leave=True)
    t.close()
    assert t.tgio.message_id is not None

# Generated at 2022-06-18 11:29:34.241467
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from os import environ
    from time import sleep
    from requests import Session
    from tqdm.contrib.telegram import TelegramIO
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.contrib.telegram import ttgrange
    from tqdm.contrib.telegram import tqdm
    from tqdm.contrib.telegram import trange
    from tqdm.contrib.telegram import __version__
    from tqdm.contrib.telegram import __author__
    from tqdm.contrib.telegram import __all__
    from tqdm.contrib.telegram import __doc__
    from tqdm.contrib.telegram import __file__
    from tqdm.contrib.telegram import __name__

# Generated at 2022-06-18 11:29:36.687385
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tg = TelegramIO(token='token', chat_id='chat_id')
    tg.write('test')
    tg.close()

# Generated at 2022-06-18 11:29:43.892726
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.auto import tqdm
    from time import sleep
    from os import getenv

    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')

    t = tqdm_telegram(total=100, token=token, chat_id=chat_id)
    for i in tqdm(range(10)):
        sleep(0.1)
        t.update(10)
    t.clear()
    for i in tqdm(range(10)):
        sleep(0.1)
        t.update(10)
    t.close()

# Generated at 2022-06-18 11:29:45.242085
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from .utils_test import _test_clear
    _test_clear(tqdm_telegram)

# Generated at 2022-06-18 11:29:49.562818
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from time import sleep
    from tqdm import tqdm
    from tqdm.contrib.telegram import tqdm_telegram
    for i in tqdm(range(10)):
        sleep(0.1)
    for i in tqdm_telegram(range(10), token='{token}', chat_id='{chat_id}'):
        sleep(0.1)

# Generated at 2022-06-18 11:32:57.205627
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from time import sleep
    for _ in tqdm(range(10), token='{token}', chat_id='{chat_id}'):
        sleep(0.1)
        tqdm.clear()
        sleep(0.1)

# Generated at 2022-06-18 11:33:03.236104
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(total=10, leave=False)
    t.close()
    assert t.tgio.text == "..."
    t = tqdm_telegram(total=10, leave=True)
    t.close()
    assert t.tgio.text == "..."
    t = tqdm_telegram(total=10, leave=None)
    t.close()
    assert t.tgio.text == "..."

# Generated at 2022-06-18 11:33:05.163368
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .utils_test import _test_display
    _test_display(tqdm_telegram)

# Generated at 2022-06-18 11:33:09.205381
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from time import sleep
    from tqdm.auto import tqdm
    for i in tqdm(range(10), token='{token}', chat_id='{chat_id}'):
        sleep(0.1)
        if i == 5:
            tqdm.clear()

if __name__ == '__main__':
    test_tqdm_telegram_clear()

# Generated at 2022-06-18 11:33:13.828788
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from os import environ
    environ['TQDM_TELEGRAM_TOKEN'] = '123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    environ['TQDM_TELEGRAM_CHAT_ID'] = '123456789'
    tqdm_telegram(range(10))
    del environ['TQDM_TELEGRAM_TOKEN']
    del environ['TQDM_TELEGRAM_CHAT_ID']

# Generated at 2022-06-18 11:33:20.928319
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.auto import trange
    from tqdm.utils import _term_move_up
    from io import StringIO
    import sys
    import time

    # test with file-like object
    f = StringIO()
    with tqdm_telegram(total=10, file=f, mininterval=0) as t:
        for i in trange(10, file=f, mininterval=0):
            time.sleep(0.1)
            t.update()