

# Generated at 2022-06-18 11:28:03.670356
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    import time
    from tqdm import tqdm
    from tqdm.contrib.telegram import tqdm_telegram
    for t in (tqdm, tqdm_telegram):
        with t(total=10) as pbar:
            for i in range(10):
                time.sleep(0.1)
                pbar.update()
        assert pbar.n == 10
        assert pbar.n == pbar.total
        assert pbar.last_print_n == pbar.total
        assert pbar.last_print_n == pbar.n
        assert pbar.last_print_n == 10
        assert pbar.n == pbar.last_print_n
        assert pbar.n == 10
        assert pbar.total == 10

# Generated at 2022-06-18 11:28:08.074707
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from time import sleep
    from tqdm.contrib.telegram import tqdm, trange
    for i in trange(10, token='{token}', chat_id='{chat_id}'):
        sleep(0.1)
        if i == 5:
            tqdm.clear()


# Generated at 2022-06-18 11:28:10.085008
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .utils_test import _test_display
    _test_display(tqdm_telegram)

# Generated at 2022-06-18 11:28:14.265104
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(total=1, leave=False)
    t.close()
    assert t.tgio.message_id is None
    t = tqdm_telegram(total=1, leave=True)
    t.close()
    assert t.tgio.message_id is not None

# Generated at 2022-06-18 11:28:24.691970
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from io import StringIO
    from sys import stdout
    from time import sleep
    from tqdm.auto import tqdm
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.utils import _term_move_up

    # Test tqdm_telegram.display
    with StringIO() as f:
        for _ in tqdm_telegram(range(10), file=f, mininterval=0.1):
            sleep(0.1)
        assert f.getvalue() == ""

    # Test tqdm_telegram.display with bar_format

# Generated at 2022-06-18 11:28:31.545060
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from time import sleep
    from tqdm import tqdm
    for i in tqdm(range(3), desc='1st loop', leave=False,
                  token='{token}', chat_id='{chat_id}'):
        sleep(0.5)
        tqdm.write("")
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            sleep(0.5)
            tqdm.write("")
            for k in tqdm(range(2), desc='3rd loop', leave=False):
                sleep(0.5)
                tqdm.write("")
        tqdm.write("")
    tqdm.write("")

# Generated at 2022-06-18 11:28:36.169170
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from time import sleep
    from tqdm.auto import tqdm as tqdm_auto
    from tqdm.contrib.telegram import tqdm_telegram

    for cls in (tqdm_auto, tqdm_telegram):
        with cls(total=10, desc='test') as pbar:
            for i in range(10):
                pbar.update()
                sleep(0.1)
                pbar.clear()
                sleep(0.1)
                pbar.display()
                sleep(0.1)
                pbar.clear()
                sleep(0.1)
                pbar.display()
                sleep(0.1)
                pbar.clear()
                sleep(0.1)
                pbar.display()
                sleep(0.1)

# Generated at 2022-06-18 11:28:40.997158
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from time import sleep
    from tqdm.contrib.telegram import tqdm, trange
    for i in trange(10, token='{token}', chat_id='{chat_id}'):
        sleep(0.1)
        if i == 5:
            tqdm.clear()

if __name__ == '__main__':
    test_tqdm_telegram_clear()

# Generated at 2022-06-18 11:28:42.591459
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(total=1)
    t.close()
    assert t.tgio.message_id is None

# Generated at 2022-06-18 11:28:44.373747
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(total=1)
    t.close()
    assert t.tgio.message_id is None

# Generated at 2022-06-18 11:30:39.771763
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .tests_tqdm import TestTqdm
    TestTqdm.test_display(tqdm_telegram)

# Generated at 2022-06-18 11:30:50.694551
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from time import sleep
    from tqdm import tqdm
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.contrib.telegram import TelegramIO
    from tqdm.contrib.telegram import ttgrange
    from tqdm.contrib.telegram import tqdm
    from tqdm.contrib.telegram import trange
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.contrib.telegram import TelegramIO
    from tqdm.contrib.telegram import ttgrange
    from tqdm.contrib.telegram import tqdm
    from tqdm.contrib.telegram import trange
    from tqdm.contrib.telegram import tqdm_telegram


# Generated at 2022-06-18 11:30:52.943835
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm.contrib.telegram import tqdm, trange
    for i in trange(10, token='{token}', chat_id='{chat_id}'):
        pass

# Generated at 2022-06-18 11:30:55.221880
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .utils_test import _test_display
    _test_display(tqdm_telegram)

# Generated at 2022-06-18 11:30:57.916687
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(total=1, leave=False)
    t.close()
    assert t.tgio.message_id is None

# Generated at 2022-06-18 11:31:02.531840
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from time import sleep
    from tqdm.contrib.telegram import tqdm, trange
    for i in trange(10, token='{token}', chat_id='{chat_id}'):
        sleep(0.1)
        if i == 5:
            tqdm.clear()

if __name__ == '__main__':
    test_tqdm_telegram_clear()

# Generated at 2022-06-18 11:31:11.178844
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from io import StringIO
    from sys import stdout
    from time import sleep
    from tqdm import tqdm
    from tqdm.contrib.telegram import tqdm_telegram

    # Test tqdm_telegram.display
    with StringIO() as f:
        with tqdm(total=10, file=f) as pbar:
            for i in range(10):
                pbar.update()
                sleep(0.1)
        assert f.getvalue() == '\r  0%|          | 0/10 [00:00<?, ?it/s]\n'

    # Test tqdm_telegram.display

# Generated at 2022-06-18 11:31:17.299236
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm.auto import tqdm
    import time
    with tqdm(total=10, token='{token}', chat_id='{chat_id}') as pbar:
        for i in range(10):
            pbar.update(1)
            time.sleep(1)
            pbar.clear()
            time.sleep(1)

if __name__ == '__main__':
    test_tqdm_telegram_clear()

# Generated at 2022-06-18 11:31:18.396377
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tg = TelegramIO('token', 'chat_id')
    tg.delete()

# Generated at 2022-06-18 11:31:21.440685
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from time import sleep
    from tqdm import tqdm
    for i in tqdm(range(10), token='{token}', chat_id='{chat_id}'):
        sleep(0.1)
        if i % 2 == 0:
            tqdm.clear()