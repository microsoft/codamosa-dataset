

# Generated at 2022-06-24 10:02:01.095842
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    return TelegramIO(getenv('TQDM_TELEGRAM_TOKEN'),
                      getenv('TQDM_TELEGRAM_CHAT_ID'))

# Generated at 2022-06-24 10:02:10.604980
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    with tqdm_telegram(total=1,
                       token='123123:not-a-real-token-123321123',
                       chat_id='-101010101011010') as t:
        assert t.position == 0
        assert t.last_print_t == 0
        assert t.last_print_n == 0
        assert t.dynamic_ncols
        assert t.n == 1
        assert t.total == 1
        assert t.desc == ''
        assert t.postfix == {}
        assert t.bar_format == ''
        assert t.unit_scale is True
        assert t.leave is None
        assert t.unit_divisor is None
        assert t.miniters == 1
        assert t.maxinterval == 10
        assert t.mininterval == 0.1

# Generated at 2022-06-24 10:02:19.764279
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm.auto import tqdm
    from tqdm.contrib import telegram
    import time

    # simple example
    with telegram.tqdm(total=10, token='122640456:AAEOWSbomNcJ9K3vak8Wp-aOiP66YGzNvD8', chat_id='132934184') as t:
        for i in range(10):
            time.sleep(1)
            t.update()

    # simple example

# Generated at 2022-06-24 10:02:28.269645
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm import tnrange, trange, tqdm_notebook
    from tqdm._utils import _term_move_up

    for cls in (tqdm_telegram, tnrange):
        with cls(5) as pbar:
            for _ in range(3):
                pbar.update(1)
                pbar.clear()
                pbar.write('hello')
                pbar.display()
            pbar.update(1)
            pbar.clear()
            pbar.write('hello')
            pbar.display()
            pbar.update(1)
    tqdm_telegram(5, disable=True)



# Generated at 2022-06-24 10:02:29.722237
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from .utils_test import _test_clear
    _test_clear(tqdm_telegram)

# Generated at 2022-06-24 10:02:34.501112
# Unit test for function trange
def test_trange():
    '''Test for function trange'''
    from tqdm.contrib.telegram import ttgrange
    import time
    import datetime
    start = time.time()
    for i in ttgrange(10):
        time.sleep(1)
        assert str(datetime.timedelta(seconds=int(time.time() - start))) in self.bar_format



# Generated at 2022-06-24 10:02:35.703001
# Unit test for function trange
def test_trange():
    from .tests_telegram import testit
    testit(trange)

# Generated at 2022-06-24 10:02:37.820906
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    TelegramIO(getenv('TQDM_TELEGRAM_TOKEN'),
               getenv('TQDM_TELEGRAM_CHAT_ID'))


# Generated at 2022-06-24 10:02:46.028863
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    """
    Unit test for method write of class TelegramIO
    """
    import pytest
    from requests.exceptions import RequestException

    class MockResponse(object):
        def __init__(self, status_code, raise_for_status, json):
            self.raise_for_status = raise_for_status
            self.json = json
            self.status_code = status_code

        def raise_for_status(self):
            if self.raise_for_status:
                raise RequestException("Connection error")

    class MockSession(object):
        def __init__(self):
            return

        def post(self, url, data):
            return MockResponse(200, False, {'result': {'message_id': -1}})


# Generated at 2022-06-24 10:02:57.219355
# Unit test for function trange
def test_trange():
    """Test the trange function"""
    from time import sleep
    from os import getenv, unsetenv
    from .utils_test import test_telegram_token, _test_closing, _range

    unsetenv('TQDM_TELEGRAM_TOKEN')
    unsetenv('TQDM_TELEGRAM_CHAT_ID')

    # No Telegram configured
    tt = trange(3)
    _test_closing(tt)
    with tt:
        for _ in tt:
            sleep(0.1)
    _test_closing(tt)

    # Invalid Telegram settings
    tt = trange(3, token='123')
    _test_closing(tt)
    tt = trange(3, token='123', chat_id='123')
    _test_cl

# Generated at 2022-06-24 10:03:06.902915
# Unit test for function trange
def test_trange():
    desc = "ttgrange"
    for _ in trange(3, token='{token}', chat_id='{chat_id}', desc=desc):
        pass
    for x in trange(10, 30, token='{token}', chat_id='{chat_id}'):
        pass
    for x in trange(10, token='{token}', chat_id='{chat_id}', unit="blah"):
        pass
    for x in trange(10, unit="inches", token='{token}', chat_id='{chat_id}'):
        pass



# Generated at 2022-06-24 10:03:10.859203
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    mytqdm = tqdm_telegram(
        range(10), leave=False, token='{token}', chat_id='{chat_id}')
    for i in mytqdm:
        pass
    mytqdm.close()

test_tqdm_telegram_close()

# Generated at 2022-06-24 10:03:17.317324
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    message_id = None
    try:
        message_id = TelegramIO(token, chat_id).message_id
        assert message_id != None
        assert TelegramIO(token, chat_id).delete() == None
    finally:
        if message_id != None:
            TelegramIO(token, chat_id).delete()

# Generated at 2022-06-24 10:03:25.531320
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from .utils_testing import TestTqdmIO
    from .tests_tqdm import pretest_posttest

    with TestTqdmIO(cls=tqdm_telegram) as t:
        kwargs = dict(ncols=10, token='{token}', chat_id='{chat_id}')
        t.start(**kwargs)
        t.update()
        t.update(5)
        t.update()
        t.update(5)

        t.clear(**kwargs)
        t.refresh(0, **kwargs)

        t.close()


if __name__ == "__main__":
    from doctest import testmod
    from . import tqdm as tqdm_mod
    testmod(tqdm_mod)
    test_tqdm_

# Generated at 2022-06-24 10:03:26.674284
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    tg = TelegramIO('{token}', '{chat_id}')
    tg.message_id  # Creates new message.
    tg.write('qwerty')
    tg.delete()

# Generated at 2022-06-24 10:03:33.414604
# Unit test for function trange
def test_trange():
    """Test function trange"""
    try:
        trange(1)
    except Exception:
        pass
    else:
        raise AssertionError()
    try:
        trange(1, token='{token}', chat_id='{chat_id}')
    except Exception:
        raise AssertionError()

# Generated at 2022-06-24 10:03:36.426084
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    try:
        TelegramIO(token=getenv('TQDM_TELEGRAM_TOKEN'),
                   chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'))
    except NameError:
        pass

# Generated at 2022-06-24 10:03:40.650541
# Unit test for function trange
def test_trange():
    """Test function `trange`."""
    assert (list(trange(10, mininterval=0.001, leave=False)) ==
            list(range(10)))

# Generated at 2022-06-24 10:03:45.457474
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    import os
    if 'TQDM_TELEGRAM_TOKEN' not in os.environ and 'TQDM_TELEGRAM_CHAT_ID' not in os.environ:
        return
    t = tqdm(range(10), disable=False)
    t.close()
    t.close()
    t.close()

# Generated at 2022-06-24 10:03:49.206288
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    t_tqdm = tqdm_telegram('test', token=getenv('TQDM_TELEGRAM_TOKEN'),
                           chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'))



# Generated at 2022-06-24 10:03:52.632491
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    import os
    import tempfile
    class MockSession:
        def post(self, url, data): return b''

# Generated at 2022-06-24 10:03:56.008346
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    t = tqdm_telegram(xrange(10), token='12345', chat_id='67890')
    t.close()

# Generated at 2022-06-24 10:04:03.093789
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if not (token and chat_id):
        warn("No test data found (set `$TQDM_TELEGRAM_TOKEN` and "
             "`$TQDM_TELEGRAM_CHAT_ID`)", TqdmWarning, stacklevel=2)
        return True  # pass
    tgio = TelegramIO(token, chat_id)
    assert tgio.message_id is not None
    assert tgio.text == tgio.__class__.__name__

# Generated at 2022-06-24 10:04:05.317551
# Unit test for function trange
def test_trange():
    from .utils_test import _test_tgrange
    _test_tgrange()


if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-24 10:04:08.179299
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    try:
        with TelegramIO('', ''):
            pass
    except Exception as e:
        print(e)


# Unit test function for class tqdm_telegram

# Generated at 2022-06-24 10:04:13.889378
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tg = TelegramIO(token='dummy', chat_id='dummy')
    tg.message_id = 666
    assert tg.write('dummy') != None

# Generated at 2022-06-24 10:04:23.504349
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm.contrib import telegram
    from tqdm import tqdm
    from time import sleep

    class MockTgIO(telegram.TelegramIO):
        def __init__(self):
            self.text = 'Not empty before clearing'

        def write(self, s):
            self.text = s

        def delete(self):
            self.text = None

    tgio = MockTgIO()
    pbar = tqdm_telegram(range(3), tgio=tgio)
    sleep(0.2)
    assert tgio.text != ''
    pbar.clear()
    sleep(0.2)
    assert tgio.text == ''
    pbar.close()

# Generated at 2022-06-24 10:04:30.315072
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    """
    Unit test for method write of class TelegramIO
    """
    tg = TelegramIO('123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11', '12345678')
    tg.write('test text')
    tg.write('test text 2')
    tg.write('test text 2')
    tg.write('test text')
    tg.write('test text with line break\n')
    tg.write('test text with line break\n\n')
    tg.delete()


# Generated at 2022-06-24 10:04:40.736864
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    import sys
    import os
    import time

    def myclose_mock(self, bar_format=None, ncols=None, ascii=None,
                     disable=False, unit='it', unit_scale=False,
                     unit_divisor=1000, miniters=None, mininterval=0.1,
                     mininterval_save=None, postfix=None,
                     maxinterval=10.0, maxinterval_save=None,
                     file=sys.stderr, dynamic_ncols=False, smoothing=0.3,
                     bar_format_save=None, initial=0, total=None,
                     position=None, desc=None, leave=False):
        self.leave = leave
        self.disable = disable
        self.pos = 0
        self.total = 10



# Generated at 2022-06-24 10:04:43.837586
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """Test if method `close` of class `tqdm_telegram` works properly"""
    tgrange = ttgrange(5)
    tgrange.close()
    assert tgrange.tgio.message_id is None

# Generated at 2022-06-24 10:04:46.835623
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    """Unit test for method delete of class TelegramIO"""
    token, chat_id = "test_telegram_token", "test_telegram_chat_id"
    tgio = TelegramIO(token, chat_id)
    assert tgio.delete()

# Generated at 2022-06-24 10:04:51.057628
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from time import time

    tg = TelegramIO('{token}', '{chat_id}')
    # send first message
    tg.write('Test')
    # replace message text
    tg.write('Test 2')
    # wait for message to arrive
    while time() - float(tg.last_update) < 1:
        pass
    # delete message
    tg.delete()

# Generated at 2022-06-24 10:04:55.843005
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    try:
        with tqdm(token='', chat_id='') as t:
            pass
    except Exception:
        pass
    else:
        raise RuntimeError("tqdm_telegram.close() exception test failed")

# Generated at 2022-06-24 10:04:59.771018
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    # pylint: disable=line-too-long
    assert TelegramIO('0000', '0000').write("!@#$%^&*") == None


# Generated at 2022-06-24 10:05:01.529693
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    x = tqdm_telegram([1], token='{token}', chat_id='{chat_id}')
    x.close()

# Generated at 2022-06-24 10:05:02.892788
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    f = TelegramIO('{token}', '{chat_id}')
    f.write("")


# Generated at 2022-06-24 10:05:07.091197
# Unit test for function trange
def test_trange():
    """Unit test for trange"""
    with trange(3, token='{token}', chat_id='{chat_id}') as t:
        for i in t:
            assert i < 4

# Generated at 2022-06-24 10:05:10.753800
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():

    pbar = tqdm_telegram(desc="test", total=100)
    pbar.clear()
    pbar.close()


if __name__ == '__main__':

    test_tqdm_telegram_clear()

# Generated at 2022-06-24 10:05:22.077467
# Unit test for function trange
def test_trange():
    from .utils_test import vertsize
    from .utils_test import discretize
    from .utils_test import _test_short_repr

    # test range
    for r in (None, 5, 100):
        for leave in (True, False):
            for disable in (True, False):
                with trange(r,
                            desc='Enabling \ud83d\ude03',
                            leave=leave,
                            disable=disable) as t:
                    assert t is not None
                    assert t.iterable == range(r)
                    # Tests basic functionality of non-blocking writes and
                    # proper context manager use
                    for i in t:
                        if i == 2:
                            t.set_description('Testing')
                            t.refresh()
                        if 3 < i < 6:
                            t.set

# Generated at 2022-06-24 10:05:25.504500
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    """Test constructor of class tqdm_telegram."""
    tgtqdm = tqdm_telegram(total=10)
    assert not tgtqdm.leave
    tgtqdm.close()

# Generated at 2022-06-24 10:05:34.257921
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from .test_utils_worker import test_MonoWorker_run
    from .test_utils_worker import test_MonoWorker_write

    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')

    tgio = TelegramIO(token, chat_id)

    # test for method run of class MonoWorker
    test_MonoWorker_run(tgio)

    # test for method write of class MonoWorker
    test_MonoWorker_write(tgio)


if __name__ == "__main__":
    test_TelegramIO_write()

# Generated at 2022-06-24 10:05:43.423665
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .tests_tqdm import pretest_posttest_decorator
    import os
    import random
    import sys

    @pretest_posttest_decorator
    def unit_test():
        """Unit test for method display of class tqdm_telegram"""

        # Test for the large bar_format
        with tqdm(total=100, bar_format='{bar}\n{n_fmt:10u}/{total_fmt:10u}'
                  ' [{elapsed}<{remaining}, {rate_fmt:5.2f}{postfix}]') as bar:
            for i in range(10):  # 10 times
                bar.update(10)

        # Test for Telegram
        token = os.getenv('TQDM_TELEGRAM_TOKEN')
        chat_

# Generated at 2022-06-24 10:05:46.749940
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    tqdm_telegram(range(1))
    tqdm_telegram(range(1), leave=True)
    tqdm_telegram(range(1), leave=False)
    tqdm_telegram(range(1), leave=None)

# Generated at 2022-06-24 10:05:53.253885
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    a = tqdm(range(10), token = getenv('TQDM_TELEGRAM_TOKEN'), chat_id = getenv('TQDM_TELEGRAM_CHAT_ID'))
    a.close()
    b = tqdm(range(10), token = getenv('TQDM_TELEGRAM_TOKEN'), chat_id = getenv('TQDM_TELEGRAM_CHAT_ID'))
    b.close(True)
    c = tqdm(range(10), token = getenv('TQDM_TELEGRAM_TOKEN'), chat_id = getenv('TQDM_TELEGRAM_CHAT_ID'))
    c.close(leave=True)

# Generated at 2022-06-24 10:05:57.456929
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    with tqdm_telegram(desc='Testing...', disable=True) as pbar:
        assert(hasattr(pbar, 'tgio'))
        assert(isinstance(pbar.tgio, TelegramIO))
        assert(pbar.tgio.text == 'TelegramIO')
        pbar.write('Testing...')
        pbar.close()

# Generated at 2022-06-24 10:06:04.102594
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from ._tqdm.utils import _term_move_up as move_up
    from ._tqdm.version import __version__

    with open("/dev/null", "w") as devnull:
        stdout = tqdm_auto(file=devnull)
        tqdm_auto.write = lambda s, **x: setattr(stdout, '_inst_force_refresh',
                                                 True)

        for n in [4, 5, -4, -5, 0, 1, 2, 3, 10, -10, 90, -90]:
            t = tqdm_telegram(total=n, miniters=1, mininterval=0,
                              ascii=None, desc="test description")
            # Initial write
            t.display()
            if n <= 0:
                assert t

# Generated at 2022-06-24 10:06:11.637598
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from time import sleep
    from tqdm import tqdm
    from .utils_telegram import delete  # type: ignore
    print("\nTesting tqdm_telegram.close()")
    tg = tqdm_telegram(total=10, desc="Dummy", disable=True)
    tg.close()  # should not raise any exception
    assert tg.disable
    tg.close(False)  # should not raise any exception
    assert tg.disable
    tg.close(True)  # should not raise any exception
    assert tg.disable
    tg.close(True, False)  # should not raise any exception
    assert tg.disable
    tg.close()  # should not raise any exception
    assert tg.disable
    tg.close()  # should not raise any exception

# Generated at 2022-06-24 10:06:19.168945
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    # test with `leave=False`
    tgr = tqdm(total=2, leave=False)
    tgr.update()
    tgr.close()
    # test with `leave=True`
    tgr = tqdm(total=2, leave=True)
    tgr.update()
    tgr.close()
    # test with `leave=None` when `pos=0`
    tgr = tqdm(total=2, leave=None)
    tgr.close()
    # test with `leave=None` when `pos != 0`
    tgr = tqdm(total=2, leave=None)
    tgr.update()
    tgr.close()


# Generated at 2022-06-24 10:06:25.032754
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import sys
    import time
    import datetime
    from io import StringIO
    from collections import OrderedDict
    # get message as sys.stdout
    orig_stdout = sys.stdout
    sys.stdout = StringIO()
    a = tqdm_telegram([1, 2, 3], token='{token}', chat_id='{chat_id}')
    # get messages with .format_meter
    s = OrderedDict()
    s['n'] = a.format_dict['n']
    s['total'] = a.format_dict['total'][0]
    s['elapsed'] = str(
        datetime.timedelta(seconds=int(round(a.format_dict['elapsed']))))

# Generated at 2022-06-24 10:06:33.315134
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm.contrib.telegram import tqdm_telegram, TelegramIO
    tok = 'TESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTEST'
    cid = 'TESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTEST'
    tel = tqdm_telegram(token=tok, chat_id=cid)
    tel.tgio = TelegramIO(tok, cid)
    tel.display()

if __name__ == '__main__':
    test_tqdm_telegram_display()
    print("Please run `python3 -m tqdm.contrib.telegram` to see example")

# Generated at 2022-06-24 10:06:36.985314
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    """
    Unit test for method write of class TelegramIO.
    """
    io = TelegramIO("test_token", "test_chat_id")
    io.write("hello")

# Generated at 2022-06-24 10:06:41.182362
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    t = tqdm_telegram(total=4,
        bar_format='{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}]')
    for _ in t:
        t.display()


# Generated at 2022-06-24 10:06:44.085361
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from tqdm.auto import tqdm
    assert not tqdm_telegram().pos


if __name__ == '__main__':
    from pytest import main
    main([__file__])

# Generated at 2022-06-24 10:06:54.823095
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    assert tqdm_telegram(away=10).format_dict['bar_format'] == '{l_bar}{bar:10u}{r_bar}'
    assert tqdm_telegram(away=10, bar_format='{bar}').format_dict[
               'bar_format'] == '{l_bar}{bar:10u}{r_bar}'
    assert tqdm_telegram(away=10, bar_format='{bar:20}').format_dict[
               'bar_format'] == '{l_bar}{bar:20u}{r_bar}'
    assert tqdm_telegram(away=10, bar_format='{bar:10}').format_dict[
               'bar_format'] == '{l_bar}{bar:10u}{r_bar}'
    assert tqdm_

# Generated at 2022-06-24 10:07:02.393747
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """
    Test if method close send and delete messages as expected
    """
    tg = tqdm_telegram(token='895331459:AAH6zYh0s9_LeWxRjSH6JGc0s3qJl-w8cTU',
                       chat_id='485999781', mininterval=0, miniters=1)
    tg.display()
    tg.close()

if __name__ == "__main__":
    test_tqdm_telegram_close()

# Generated at 2022-06-24 10:07:05.540896
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    io = TelegramIO('fake_token', 'fake_chat_id')
    io._message_id = 123123123
    assert io.message_id == 123123123
    assert io.delete()
    assert io.message_id is None

# Generated at 2022-06-24 10:07:10.238753
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    with tqdm_telegram(total=10, bar_format='{l_bar}{bar}{r_bar}',
                       token='859390870:AAENLM6S5UwLm8HvI-yM4mJ4g4m6_8qI3Y0',
                       chat_id='331537272') as ttg:
        for i in range(10):
            ttg.update(1)

if __name__ == "__main__":
    test_tqdm_telegram()

# Generated at 2022-06-24 10:07:20.791719
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import time
    from requests import Session
    def status(self, s):
        s = s.replace('\r', '').strip()
        if s:
            self.tgio.write(s)

    tg = TelegramIO(
        token='236186501:AAHAqL-aAEL040w7JvNbWjV8X9x6UfV6U2o',
        chat_id='@tqdm_testing')
    tg.session = Session()
    tg.write('Por favor, mande `/start` você mesmo')
    tg.write('{...}')
    tg.write('{...}')
    tg.write('{...}')
    tg.write('{...}')
    tg.write('{...}')
    t

# Generated at 2022-06-24 10:07:24.086438
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tgio = TelegramIO('token', 'chat_id')
    tgio.message_id
    assert tgio.delete() is None

# Generated at 2022-06-24 10:07:30.022705
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    """Unit test for method delete of class TelegramIO"""
    tg = TelegramIO(token='397135642:AAFohXKj_zV7iE5rGz5PjKfWYzVbZmLmf3E',
                    chat_id='@tqdmbot')
    assert tg.message_id is not None
    tg.write("Hello Telegram")
    tg.delete()



# Generated at 2022-06-24 10:07:34.141454
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    t = tqdm_telegram(_range(2))
    assert t.disable == False
    t.close()



# Generated at 2022-06-24 10:07:40.991334
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    # verification of method write with different messages
    from os import environ as os_environ
    from random import choice as random_choice
    from string import ascii_letters as letters

    token = os_environ.get('TQDM_TELEGRAM_TOKEN')
    chat_id = os_environ.get('TQDM_TELEGRAM_CHAT_ID')
    
    if not token or not chat_id:
        raise Exception("incomplete Telegram environment variables")

    for _ in range(10):
        message = ''.join([random_choice(letters) for _ in range(10)])
        tgio = TelegramIO(token, chat_id)
        tgio.write(message)
        assert tgio.text == message



# Generated at 2022-06-24 10:07:47.364825
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    # Initialization
    token  = 'token'
    chat_id  = 'chat_id'
    text = 'text'
    # Assignmant
    message_id = TelegramIO(token, chat_id).message_id
    if message_id is None:
        return
    # Test
    TelegramIO(token, chat_id).write(text)
    # Cleanup
    TelegramIO(token, chat_id).delete()
    return

# Generated at 2022-06-24 10:07:56.512521
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    # Return values for functions of class TelegramIO
    # If URL is invalid, it raises Exception
    query_values_mock = {
        "http://foo.com/bot_token/sendMessage":
            {"ok": True,
             "result": {"message_id": "test_message_id"}},

        "https://api.telegram.org/bot_valid_token/sendMessage":
            {"ok": True,
             "result": {"message_id": "test_message_id"}},

        "https://api.telegram.org/bot_valid_token/editMessageText":
            {"ok": True},

        "https://api.telegram.org/bot_valid_token/deleteMessage":
            {"ok": True}
    }

    class Query():
        def __init__(self, url):
            self.status

# Generated at 2022-06-24 10:08:05.289193
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    import re
    from time import sleep
    from .utils import _range as _trange

    try:
        from nose import with_setup  # module missing in PYPY
    except ImportError:
        def with_setup(f):
            return f

    TOKEN = "TEST_TELEGRAM_TOKEN"
    CHAT_ID = "TEST_TELEGRAM_CHAT_ID"
    re_start = re.compile("^\.\.\.$")
    re_end = re.compile("^\d+it/s$")

    def remove_test_messages():
        from tqdm.std import time
        sleep(3 * time.sleep_interval)  # wait for the message to be created
        session = Session()

# Generated at 2022-06-24 10:08:09.399676
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    with tqdm(ascii=True, token='{token}', chat_id='{chat_id}') as t:
        x = 0
        while x < 5:
            t.clear()
            t.display()
            t.write(str(x))
            t.update()
            x += 1

# Generated at 2022-06-24 10:08:20.247626
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    # Constructor
    tgio = TelegramIO('{token}', '{chat_id}')
    assert tgio.token == '{token}'
    assert tgio.chat_id == '{chat_id}'
    assert tgio._message_id is not None

    # set message_id
    tgio._message_id = 114514
    assert tgio.message_id == 114514

    # write
    tgio.write('test')
    assert tgio.text == 'test'

    from os import devnull
    from .utils_telegram import PatchRequest
    from .utils import set_fileio_watcher
    null = open(devnull, 'w')

# Generated at 2022-06-24 10:08:26.316923
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from .tests_tqdm import Range
    with tqdm_telegram(token='123', chat_id='123', leave=True,
                       unit='B', unit_scale=True,
                       total=1024) as pbar:
        for i in Range(1024):
            pbar.update(256)
            pbar.clear()

# Generated at 2022-06-24 10:08:32.371397
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    with tqdm_telegram(total=0, desc='test_tqdm_telegram',
                       token='732016024:AAEAb1W69fEccoDh4Q_pyEkRzW2BW8eii_A',
                       chat_id='661449756', disable=False) as pbar:
        pass


if __name__ == '__main__':
    from pytest import main
    main([__file__])

# Generated at 2022-06-24 10:08:35.118263
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    try:
        t = tqdm(total=1, token='{token}', chat_id='{chat_id}')
    except Exception:
        # Passes if constructor of tqdm_telegram raises an exception
        pass
    else:
        # Fails if constructor of tqdm_telegram does not raise an exception
        assert False

# Generated at 2022-06-24 10:08:42.525241
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    with tqdm_telegram(total=3) as pbar:
        assert pbar.n == 0
        assert pbar.last_print_n == 0
        assert pbar.dynamic_ncols == True
        pbar.update(2)
        assert pbar.n == 2
        assert pbar.last_print_n == 0
        assert pbar.dynamic_ncols == True
        pbar.update()
        assert pbar.n == 3
        assert pbar.last_print_n == 3
        assert pbar.dynamic_ncols == True
        pbar.close()
        assert pbar.n == 3
        assert pbar.last_print_n == 3
        assert pbar.dynamic_ncols == True


# Generated at 2022-06-24 10:08:43.582915
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tg = TelegramIO('token', 'chat_id')
    tg.delete()

# Generated at 2022-06-24 10:08:50.036962
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    """
    Simple test to check if class tqdm_telegram created without any errors.
    """
    with tqdm_telegram(total=100, disable=False,
                       token='{token}', chat_id='{chat_id}') as pbar:
        for i in range(100):
            pbar.update(1)

# Generated at 2022-06-24 10:08:51.580014
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    tio = TelegramIO('TOKEN', 'CHAT_ID')


# Generated at 2022-06-24 10:08:57.108270
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import sys
    import time

    with open(sys.argv[0]) as f:
        f.seek(0, 2)
        filesize = f.tell()
    tg = tqdm_telegram(total=filesize, file=sys.stdout)
    for i in range(4):
        time.sleep(1)
        tg.display()
    del tg

# Generated at 2022-06-24 10:09:00.386677
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    assert not tqdm_telegram(token="", chat_id="").display_tqdm
    assert not tqdm_telegram(disable=True).display_tqdm
    assert tqdm_telegram(token="a", chat_id="b").display_tqdm

# Generated at 2022-06-24 10:09:05.274781
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    from unittest import TestCase, main
    
    class Test(TestCase):
        def test_delete(self):
            from tqdm.contrib.telegram import TelegramIO

            token = "678486173:AAEIAJ6Z9Y6-4b6g2Uw3hqHmMLU_dVBmzvg"
            chat_id = '364514278'
            io = TelegramIO(token, chat_id)
            io.message_id
            io.delete()

    main()


if __name__ == '__main__':
    test_TelegramIO_delete()

# Generated at 2022-06-24 10:09:13.797333
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange.
    It may fail if your token is invalid.
    """
    from nose.tools import assert_equal
    from random import randint
    from time import sleep

    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')

    with tqdm(leave=False, total=5,
              token=token, chat_id=chat_id) as pbar:
        assert_equal(len(pbar), 5)
        for _ in range(5):
            sleep(randint(0, 50) / 1000.)
            pbar.update(1)
    assert_equal(pbar.n, 5)

# Generated at 2022-06-24 10:09:22.732598
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import io
    import sys

    if io.StringIO is not io.BytesIO:
        PrintIO = io.StringIO
    else:
        PrintIO = io.BytesIO

    old_stdout = sys.stdout
    sys.stdout = PrintIO()

    try:
        token = getenv('TQDM_TELEGRAM_TOKEN')
        chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
        tg = TelegramIO(token, chat_id)
        tg.write('test')
    finally:
        sys.stdout = old_stdout



# Generated at 2022-06-24 10:09:23.979381
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    uut = tqdm_telegram([1, 2])
    uut.close()

# Generated at 2022-06-24 10:09:32.422931
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from nose.tools import assert_equal
    from tqdm.utils import format_sizeof
    from time import sleep

    def test(kwargs):
        try:
            telegram = tqdm_telegram(total=10, **kwargs)
            for i in range(10):
                sleep(0.5)
                telegram.update()
            telegram.close()
        except Exception as e:
            print(str(e))

    for kwargs in [
        {'chat_id': '@tqdm'}, {'token': 'unittest', 'chat_id': '@tqdm'}
    ]:
        test(kwargs)

# Generated at 2022-06-24 10:09:40.018116
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    kwargs = {'token': 'fake_token', 'chat_id': 'fake_chat_id'}
    kwargs.update(total=5)

    # Test with disable=True
    tqdm(**kwargs)

    # Test with disable=False
    kwargs.update(disable=False)
    tqdm(**kwargs)

    # Test with arguments in other positions
    kwargs = {'token': 'fake_token', 'chat_id': 'fake_chat_id'}
    kwargs.update(_total=5)



# Generated at 2022-06-24 10:09:41.741135
# Unit test for function trange
def test_trange():
    from .tests_telegram import test_trange
    test_trange(tqdm, trange)

# Generated at 2022-06-24 10:09:49.745242
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    try:
        import httmock
    except ImportError:
        httmock = None
    if httmock is None:
        raise unittest.SkipTest()

    import pkg_resources
    from json import dumps

    from ..std import __copyright__
    from .main import _version


# Generated at 2022-06-24 10:09:54.022321
# Unit test for function trange
def test_trange():
    with trange(10, token=getenv('TQDM_TELEGRAM_TOKEN'),
                chat_id=getenv('TQDM_TELEGRAM_CHAT_ID')) as t:
        for i in t:
            assert i > -1
            t.update()

if __name__ == '__main__':
    from os import environ
    token = environ.get('TQDM_TELEGRAM_TOKEN')
    chat_id = environ.get('TQDM_TELEGRAM_CHAT_ID')
    test_trange()

# Generated at 2022-06-24 10:10:04.002424
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    t = tqdm_telegram(
        total=100,
        token='',
        chat_id='',
        mininterval=0.1)

    assert t.format_dict['bar_format'] == '{l_bar}{bar:10u}{r_bar}'
    assert t.format_dict['bar_format'] != '<bar/>'

    assert t.format_meter(**t.format_dict) == "   0%|          | 0/100 [00:00<?, ?it/s]"

    t.update()

    assert t.format_dict['bar_format'] == '{l_bar}{bar:10u}{r_bar}'
    assert t.format_dict['bar_format'] != '<bar/>'


# Generated at 2022-06-24 10:10:08.996833
# Unit test for function trange
def test_trange():
    from time import sleep
    for i in tqdm(trange(10, token='440683967:AAE1DeO_Fc3zqGAlFc05V7vYJtakLKG2Cgg', chat_id='-239592823'), desc='1st loop'):
        for j in tqdm(trange(5, token='440683967:AAE1DeO_Fc3zqGAlFc05V7vYJtakLKG2Cgg', chat_id='-239592823'), desc='2nd loop', leave=False):
            sleep(0.01)

if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 10:10:19.264248
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    import sys
    import re
    import os
    import string
    import random
    import filecmp
    from time import sleep
    from os import getenv
    from io import StringIO

    def equals_file_or_stringio(file_path, stringio):
        if file_path and stringio:
            f = open(file_path)
            file_data = f.read()
            f.close()
            stringio.seek(0)
            string_data = stringio.read()
            return file_data == string_data
        else:
            return False

    def _test_TelegramIO(token, chat_id, ret_filename=None):
        # Suppress the output of log messages
        original_stderr = sys.stderr
        sys.stderr = StringIO()

# Generated at 2022-06-24 10:10:24.053661
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import pickle
    from time import sleep
    with open(__file__, 'rb') as f:
        token = pickle.loads(f.read(1024))

    for _ in tqdm(range(10), token=token, chat_id=1):
        sleep(0.1)
    print('done')


# Generated at 2022-06-24 10:10:27.873755
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    i = ttgrange(1, desc='test', mininterval=0.001)
    assert i.tgio
    assert i.tgio.tgio.text == 'tqdm_telegram'
    i.clear()
    assert not i.tgio.tgio.text
    i.close()
    assert i.tgio

# Generated at 2022-06-24 10:10:29.525541
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(range(10),disable=True)
    assert t.disable
    t.close()
    t.close()

# Generated at 2022-06-24 10:10:33.722555
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    try:
        tqdm_telegram(total=10).close()
    except KeyboardInterrupt:
        return


if __name__ == '__main__':
    test_tqdm_telegram_close()

# Generated at 2022-06-24 10:10:35.959612
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tg = TelegramIO(token='{token}', chat_id='{chat_id}')
    print(tg.delete())


# Generated at 2022-06-24 10:10:38.390645
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    with tqdm_telegram(range(100), 'test') as t:
        for i in t:
            t.set_postfix("post" + str(i))

# Generated at 2022-06-24 10:10:41.148722
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(token='123456789:ABCDEFG-JKLMNOPQRSTUVWXYZ', chat_id='1111')
    t.close()

# Generated at 2022-06-24 10:10:42.711148
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    with tqdm_telegram(total=1) as pbar:
        pass

# Generated at 2022-06-24 10:10:46.442514
# Unit test for function trange
def test_trange():
    with trange(10, token='', chat_id='', disable=True) as t:
        for i in t:
            t.set_postfix(i=i)
            if i == 6:
                t.n = 1
                t.refresh()
            if i == 9:
                assert t.pos == 10

# Generated at 2022-06-24 10:10:57.890540
# Unit test for method display of class tqdm_telegram

# Generated at 2022-06-24 10:11:01.748820
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    io = TelegramIO('123456789', '987654321')
    io.write(1)


if __name__ == '__main__':
    test_TelegramIO_write()

# Generated at 2022-06-24 10:11:08.859826
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import threading, time
    myStr = "test"
    myTqdm = tqdm_telegram(myStr, token='619960759:AAEulnge5BxNvj8X_W64YF-HktdIjKvw8Jg')
    def foo(myTqdm, i):
        for j in myTqdm:
            time.sleep(i) # Slight pause for each loop
    for i in myTqdm:
        threading.Thread(target=foo, args=(myTqdm, i)).start()
        myTqdm.clear()
        time.sleep(2) # Slight pause for each loop
    myTqdm.close()
test_tqdm_telegram_clear()

# Generated at 2022-06-24 10:11:12.821307
# Unit test for function trange
def test_trange():
    for _ in trange(10, desc='tqdm iteration', token='416619988:AAGKXXd4W8pJZrA7Z-L5NzF7VNp9XIZ_CMg', chat_id='-1001399490441'):
        time.sleep(1)

# Generated at 2022-06-24 10:11:20.835609
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    class tqdm_t(object):
        def __init__(self):
            self.format_dict = {'total': 2, 'dynamic_ncols': True,
                                'bar_format': '{bar:10u}'}

    t = tqdm_t()
    t.tgio = TelegramIO('tg_token', '1234')
    tqdm_telegram.display(t, total=20)
    assert t.tgio.text == "[300.00it/s]   5%|5         | 1/20 [00:00<00:04," \
                          "1.99it/s]"

    t = tqdm_t()
    t.tgio = TelegramIO('tg_token', '1234')
    t.format_dict['total'] = 20
    t.format

# Generated at 2022-06-24 10:11:25.109810
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from .utils_worker import MonoPool as Worker
    worker = Worker()
    token = '999999999:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
    chat_id = "-9999999999"
    tgio = TelegramIO(token=token, chat_id=chat_id)
    tgio.submit = worker.submit
    tgio.write("Hello World!")
    # test that no error codes are received
    assert not tgio.error



# Generated at 2022-06-24 10:11:29.562098
# Unit test for function trange
def test_trange():
    """Sample usage"""
    for _ in trange(10, token='{token}', chat_id='{chat_id}'):
        pass

# Generated at 2022-06-24 10:11:38.925126
# Unit test for function trange
def test_trange():
    """Simple unit tests for trange"""
    from time import sleep

    total = 16
    with trange(total, token='235525690:AAE_Nc-CiT82yf-j7YpvT-MVHs_cZs0V7Kg',
                chat_id='206252202', desc='Test') as pbar:
        for j in pbar:
            sleep(0.1)
            pbar.set_description("Test %i" % j)
            pbar.update()
    assert pbar.n == total
    assert pbar.last_print_n == total
    assert pbar.n_fmt == str(total)


if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-24 10:11:45.106144
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    class SessionMockup(object):
        def post(self, url, data):
            return None
    tgio = TelegramIO(token='token', chat_id='chat_id')
    tgio.session = SessionMockup()
    tgio.message_id = 12345
    ret = tgio.delete()
    assert ret.done()
    return

# Generated at 2022-06-24 10:11:56.713589
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    """Unit test for method delete of class TelegramIO."""
    # Unit test currently only runs for py2 due to UnicodeDecodeError on py3
    # See: https://github.com/tqdm/tqdm/issues/675
    from sys import version_info
    if version_info[0] == 2:
        from os import unlink
        from os.path import exists
        from shutil import rmtree
        from tempfile import mkdtemp, mkstemp
        from .tests_tqdm import pretest

        pretest()

        # File tests
        with open(mkstemp()[1], 'wb') as f:
            with tqdm(f) as pbar:
                pbar.write(b'a')
                pbar.close()
                pbar.clear()

        # StringIO tests

# Generated at 2022-06-24 10:12:01.799018
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    assert TelegramIO(token=getenv('TQDM_TELEGRAM_TOKEN'),
                      chat_id=getenv('TQDM_TELEGRAM_CHAT_ID')).message_id