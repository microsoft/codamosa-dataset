

# Generated at 2022-06-24 10:01:57.471577
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    TelegramIO(getenv('TQDM_TELEGRAM_TOKEN'), getenv(
        'TQDM_TELEGRAM_CHAT_ID')).write("Test_TelegramIO")

# Generated at 2022-06-24 10:01:59.619528
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    with tqdm(total=10) as t:
        for x in range(10):
            t.update()
            if x == 5:
                t.close()
                t.clear()
                t.reset(total=20)
                t.total = 20



# Generated at 2022-06-24 10:02:03.011610
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import pytest

    with pytest.raises(Exception) as e:
        tgio = TelegramIO(token='', chat_id='')
        tgio.message_id
    assert str(e.value) == 'No JSON object could be decoded'

# Generated at 2022-06-24 10:02:12.546186
# Unit test for method close of class tqdm_telegram

# Generated at 2022-06-24 10:02:19.783502
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    from os import environ
    from unittest import TestCase
    from unittest.mock import Mock, patch
    from json import loads
    from collections import namedtuple
    from warnings import filterwarnings

    # Mock for debugging only, just in case
    filterwarnings('ignore', '', TqdmWarning)

    # Prepare test data
    chat_id = environ.get('TQDM_TELEGRAM_CHAT_ID')
    token = environ.get('TQDM_TELEGRAM_TOKEN')
    message_id = 0
    # Prepare test case
    class TestCase(TestCase):
        def setUp(self):
            self.tgio = TelegramIO(token, chat_id)

# Generated at 2022-06-24 10:02:22.638149
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    # import time
    from .utils_testing import _TelegramIO_write
    # time.sleep(1)
    _TelegramIO_write()

# Generated at 2022-06-24 10:02:28.373706
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    t = tqdm_telegram(total=10, token='{token}', chat_id='{chat_id}')
    t.close()
    return True

# Generated at 2022-06-24 10:02:30.364022
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    from .utils import _test_telegram_trange
    _test_telegram_trange(trange)

# Generated at 2022-06-24 10:02:36.944378
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    class dummy_telegram(telegramIO):
        def __init__(self, *args, **kwargs):
            self.write_called = False
            self.delete_called = False

        def write(self, s):
            self.write_called = True

        def delete(self):
            self.delete_called = True

    with closing(dummy_telegram()) as tg:
        t = tqdm_telegram(total=10, tgio=tg)
        t.clear()
        assert tg.write_called
        t.close()
        assert tg.delete_called

# Generated at 2022-06-24 10:02:45.404109
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    from time import time
    from copy import copy
    from .utils import _progbar

    IOLock = 'threading.Lock'
    bar = ttgrange(2)
    bar.close()
    bar.tgio.delete()
    bar.tgio.text = "t-{time:.0f}".format(time=time())
    bar.tgio.write(bar.tgio.text)
    time.sleep(1)
    bar.tgio.delete()
    bar.tgio.text = "t-{time:.0f}".format(time=time())
    bar.tgio.write(bar.tgio.text)
    bar.refresh()
    bar.close()
    bar.tgio.delete()

# Generated at 2022-06-24 10:02:46.648856
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    for i in tqdm(range(5)):
        pass



# Generated at 2022-06-24 10:02:57.732098
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from unittest import main
    from requests import post, get
    from tqdm.contrib.telegram import tqdm_telegram, tqdm
    token, chat_id = "1234567890", "1234567890"
    try:
        response = post(
            "https://api.telegram.org/bot{token}/getUpdates".format(token=token)
        ).json()['result'][-1]
    except Exception as e:
        warn(str(e))
        raise RuntimeError('No response from Telegram')
    if 'update_id' not in response:
        warn(response)
        raise RuntimeError('Invalid response from Telegram')

# Generated at 2022-06-24 10:03:09.037002
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    def captured_output(func, *args):
        import sys
        import io
        from contextlib import redirect_stdout
        f = io.StringIO()
        with redirect_stdout(f):
            func(*args)
        output = f.getvalue()
        return output[:-1] if output[-1] == '\n' else output

    assert captured_output(TelegramIO(token='123', chat_id='456').write, "") == ""
    assert captured_output(TelegramIO(token='123', chat_id='456').write, "abc") == "abc"
    assert captured_output(TelegramIO(token='123', chat_id='456').write, "abc\n") == "abc"

# Generated at 2022-06-24 10:03:14.465845
# Unit test for function trange
def test_trange():
    for _ in tqdm(_range(3), token='1167866376:AAHI0qCPZsNxuNkwpk-h29NqFs9fM7Vu-rE', chat_id='182393273', position=0):
        try:
            continue
        except (KeyboardInterrupt, SystemExit) as exc:
            break

# Generated at 2022-06-24 10:03:16.780918
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    """Unit test for method delete of class TelegramIO."""
    tgio = TelegramIO('token', 'chat_id')
    assert isinstance(tgio, MonoWorker)
    assert tgio.message_id is None
    assert tgio.delete() is None

# Generated at 2022-06-24 10:03:25.092340
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from sys import version_info
    from random import randrange
    from time import sleep
    from faulthandler import enable
    enable()  # enable trace-backs

    # check that tqdm_telegram constructor doesn't raise an exception
    list(tqdm(range(10), ncols=0, ascii=True, disable=True, token="111", chat_id="123"))
    list(tqdm(range(10), ncols=0, ascii=True, disable=False, token="111", chat_id="123"))

    # check that ttgrange constructor doesn't raise an exception
    list(tqdm(range(10), ncols=0, ascii=True, disable=True, token="111", chat_id="123"))

# Generated at 2022-06-24 10:03:36.928896
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    """Test tqdm_telegram"""
    # Test without args
    obj = tqdm_telegram()
    assert obj.__doc__ == __doc__
    for i in obj:
        break
    # Test with args (iterable) (token, chat_id)
    obj = tqdm_telegram(iter([1, 2, 3]), token="123", chat_id="321")
    assert obj.__doc__ == __doc__
    for i in obj:
        break
    # Test with args (iterable, desc) (token, chat_id)
    obj = tqdm_telegram(iter([1, 2, 3]), "desc", token="123", chat_id="321")
    assert obj.__doc__ == __doc__
    for i in obj:
        break
    # Test with args (iterable

# Generated at 2022-06-24 10:03:40.361377
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    assert tqdm_telegram(list(range(100))).display() is None

# Generated at 2022-06-24 10:03:43.201578
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    try:
        tgio = TelegramIO('', '')
        tgio.write("test")
        tgio.delete()
    except Exception as e:
        tqdm_auto.write(str(e))

# Generated at 2022-06-24 10:03:51.405755
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import time
    from random import random

    with tqdm_telegram(total=10, leave=True, token='{token}', chat_id='{chat_id}') as pbar:
        for i in range(10):
            pbar.update()
            time.sleep(random())
            if random() <= 0.3:
                pbar.clear(True)

# Generated at 2022-06-24 10:03:56.776958
# Unit test for function trange
def test_trange():
    """Unit test for trange"""
    with trange(3, token=getenv('TQDM_TELEGRAM_TOKEN'),
                chat_id=getenv('TQDM_TELEGRAM_CHAT_ID')) as t:
        for i in t:
            assert (i == t.n)

# Generated at 2022-06-24 10:03:59.545383
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    io = TelegramIO('12345', '67890')
    io.message_id = 1
    mock = io.session.post = lambda *a, **kw: {'result': True}
    io.delete()

# Generated at 2022-06-24 10:04:06.117885
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    TGIO = TelegramIO('', '@tqdml')
    TGIO.write('abc')
    TGIO.submit(TGIO.write, 'def').get()

# Generated at 2022-06-24 10:04:08.160649
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from . import _test_display
    _test_display(tqdm_telegram)
    assert hasattr(tqdm_telegram, 'display')

# Generated at 2022-06-24 10:04:11.881250
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    # tested in tqdm_telegram
    pass

# Generated at 2022-06-24 10:04:12.627870
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    assert TelegramIO('', '')

# Generated at 2022-06-24 10:04:18.292619
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    """Test tqdm_telegram"""
    from os import environ as E
    for i in tqdm(range(2), token=E.get('TQDM_TELEGRAM_TOKEN'),
                  chat_id=E.get('TQDM_TELEGRAM_CHAT_ID')):
        pass



# Generated at 2022-06-24 10:04:23.188711
# Unit test for constructor of class tqdm_telegram

# Generated at 2022-06-24 10:04:31.671472
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    tok = getenv('TQDM_TELEGRAM_TOKEN')
    if tok is None:
        raise Exception("Undefined Telegram token: set `TQDM_TELEGRAM_TOKEN`.")
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if chat_id is None:
        raise Exception("Undefined Telegram chat ID: "
                        "set `TQDM_TELEGRAM_CHAT_ID`.")
    w = TelegramIO(tok, chat_id)
    w.write('test')
    res = w.delete()
    assert res.result() is None
    try:
        res.result()
    except Exception as e:
        assert str(e) == 'No result yet'

# Generated at 2022-06-24 10:04:36.931856
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    token   = 'test'
    chat_id = 'test'
    tgio    = TelegramIO(token, chat_id)

    assert token == tgio.token
    assert chat_id == tgio.chat_id
    assert tgio.session is not None


# Generated at 2022-06-24 10:04:45.703816
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    def clear_bar_with_format(bar_format=None, **kwargs):
        with tqdm_telegram(total=100, bar_format=bar_format,
                           token='{token}', chat_id='{chat_id}',
                           disable=True, **kwargs) as pbar:
            pbar.write('')
            pbar.clear()

    clear_bar_with_format()
    clear_bar_with_format(bar_format='{bar}')
    clear_bar_with_format(bar_format='{l_bar}')
    clear_bar_with_format(bar_format='{r_bar}')
    clear_bar_with_format(bar_format='{bar} {n_fmt}')

# Generated at 2022-06-24 10:05:00.408181
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import os
    import sys
    import time

    try:
        os.close(1)
    except OSError:  # already closed
        pass
    old_stderr = sys.stderr
    sys.stderr = sys.stdout

    x = tqdm_telegram(
        total=5,
        token="1023595582:AAFp8ikv7Vuq3hJucdsVZTYSn8fv7Vh9GzA",
        chat_id="1023595582")

    for _ in x:
        time.sleep(0.1)

    x.close()
    assert len(x.format_dict) == 1
    assert x.format_dict['bar_format'] == '{l_bar}{bar:10u}{r_bar}'

   

# Generated at 2022-06-24 10:05:10.565865
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    """Unit test for method `write` of class `TelegramIO`."""
    tgio = TelegramIO(token=getenv('TQDM_TELEGRAM_TOKEN'),
                      chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'))
    try:
        import pytest
        pytest.skip("Please `export TQDM_TELEGRAM_TOKEN=")
    except:
        pass
    tgio.write('test')

if __name__ == '__main__':
    test_TelegramIO_write()

# Generated at 2022-06-24 10:05:21.317915
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """
    Unit test to check if method close of class tqdm_telegram works properly.
    """
    from os import environ
    from io import StringIO
    from time import time as _time, sleep
    import pytest

    environ['TQDM_TELEGRAM_TOKEN'] = 'test_token'
    environ['TQDM_TELEGRAM_CHAT_ID'] = '-1'
    capfd = None
    tgrange = tqdm_telegram(total=3)

    for _ in tgrange:
        sleep(1)
        continue

    tgrange.close()

    out, err = capfd.readouterr()
    assert out == ''
    assert err == ''

# Generated at 2022-06-24 10:05:27.666325
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    try:
        c = tqdm_telegram(xrange(20), token=getenv('TQDM_TELEGRAM_TOKEN'),
                chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'))
        c.mininterval = -1
        for i in c:
            pass
    except Exception as e:
        tqdm_auto.write(str(e))
    else:
        return

# Generated at 2022-06-24 10:05:32.630935
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """Tests if the method close is correctly implemented for tqdm_telegram"""
    from os import getenv
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')

    tg = tqdm_telegram(total=1, token=token, chat_id=chat_id)
    tg.close()

# Generated at 2022-06-24 10:05:41.926679
# Unit test for method clear of class tqdm_telegram

# Generated at 2022-06-24 10:05:44.723537
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    # Check that the method delete won't raise a specific exception
    t = TelegramIO('TOKEN', 'CHAT_ID').delete()
    assert(t)

# Generated at 2022-06-24 10:05:54.424960
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from datetime import timedelta as td
    from time import sleep

    # Test tqdm_telegram with Telegram bot
    with tqdm_telegram(total=100, ncols=50, disable=False,
                       token=getenv('TQDM_TELEGRAM_TOKEN'),
                       chat_id=getenv('TQDM_TELEGRAM_CHAT_ID')) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)

    # Test tqdm_telegram without Telegram bot
    with tqdm_telegram(total=100, ncols=50, disable=True,
                       token='incorrect', chat_id='incorrect') as pbar:
        for i in range(10):
            sleep(0.1)
            p

# Generated at 2022-06-24 10:06:04.782810
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():

    from tqdm.utils import _term_move_up, _environ_cols_wrapper
    from tqdm.auto import tqdm

    begints = time.time()
    t = tqdm_telegram(range(10), token='token', chat_id='id')
    for i in t:
        time.sleep(0.01)
    t.close()
    endts = time.time()
    assert (endts - begints) > 10  # 10 iterations of 0.01 s + network delay
    assert (endts - begints) < 20  # 10 iterations of 0.01 s + network delay

    time.sleep(0.01)
    print(_term_move_up() + "hello world\rgoodbye world")
    assert _environ_cols_wrapper() is not None

# Generated at 2022-06-24 10:06:05.551755
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    return True


# Generated at 2022-06-24 10:06:06.650305
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    tg = TelegramIO('TOKEN', 'CHAT_ID')

# Generated at 2022-06-24 10:06:13.695557
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    """
    Write method test to verify behavior of class TelegramIO write method.
    """
    class TelegramIOTest(TelegramIO):
        """
        Mock class of TelegramIO to intercept write calls and verify
        their behavior.
        """
        def __init__(self, token, chat_id):
            super(TelegramIOTest, self).__init__(token, chat_id)
            self.calls = []

        def write(self, s):
            """
            Intercepts write calls and store them in instance's attribute calls.
            """
            self.calls.append(s)

    token = 'FAKE_TOKEN'
    chat_id = 'FAKE_CHAT_ID'
    tgio = TelegramIOTest(token, chat_id)

    text1 = 'Test'

# Generated at 2022-06-24 10:06:23.894080
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tqdm_auto.write("Testing TelegramIO.write...")
    tg = TelegramIO("6e30bb6e3c6f2a0c7343b8e8d41c9e974", "1182547")
    assert tg.write("test") is not None
    assert tg.write("test test") is not None
    assert tg.write("") is not None
    tg.delete()
    tg.close()
    tg = TelegramIO("6e30bb6e3c6f2a0c734", "1182547")
    assert tg.write("test") is None
    assert tg.write("test test") is None
    assert tg.write("") is None
    tg.delete()
    tg.close()

# Generated at 2022-06-24 10:06:28.585309
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    with tqdm(total=2) as pbar:
        pbar.write('Hello, world!')
        pbar.n = 1
    pbar.close()
    # the following line should not raise an exception
    pbar.close()


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 10:06:39.938984
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from os import getenv
    try:
        from tqdm.cli import main
    except ImportError:
        from tqdm.main import main
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')

# Generated at 2022-06-24 10:06:44.676377
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    desc = 'test_desc'
    token = "1170180381:AAEJbHn0LE69q-rQ1FyT9TnTfTNJ6M7o6Uc"
    chat_id = "-371363706"
    t = tqdm_telegram(range(1), desc=desc, token=token, chat_id=chat_id)
    t.close()

# Generated at 2022-06-24 10:06:48.693041
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    assert TelegramIO("TOKEN", "CHAT_ID").write("Hello World!")
    assert TelegramIO("TOKEN", "CHAT_ID").write("")


# Generated at 2022-06-24 10:06:55.833368
# Unit test for function trange
def test_trange():
    from os import remove
    from time import sleep

    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if token and chat_id:
        for i in trange(5, desc='', token=token, chat_id=chat_id):
            sleep(0.05)
    else:
        warn("`trange` unit test skipped: "
             "set TQDM_TELEGRAM_TOKEN and TQDM_TELEGRAM_CHAT_ID",
             TqdmWarning)

if __name__ == '__main__':
    # test_trange()
    pass

# Generated at 2022-06-24 10:07:02.385310
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    with open("tempfile.txt", "w") as f:
        f.write("test")
        f.flush()

    input_file = open("tempfile.txt", "r")
    file_length = sum(1 for line in input_file)
    input_file.seek(0)

    with tqdm_telegram(unit="lines", total=file_length, disable=False) as pbar:
        for line in input_file:
            pbar.clear()



# Generated at 2022-06-24 10:07:07.122196
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    text = 'Initial text'
    text_new = 'Replacement text'
    token = '[token]'
    chat_id = '[chat_id]'
    io = TelegramIO(token, chat_id)
    try:
        io.write(text)
    except Exception as e:
        assert str(e).find('Too Many Requests: try again later') != -1

test_TelegramIO_write()

# Generated at 2022-06-24 10:07:18.003659
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from os import environ, getenv
    from unittest import TestCase, SkipTest

    try:
        from unittest.mock import patch, Mock
    except ImportError:
        from mock import patch, Mock

    class TqdmTelegramTest(TestCase):
        def setUp(self):
            self.token = 'TOKEN'
            self.chat_id = 'CHAT-ID'
            self.patch_g = patch.dict(environ, {'TQDM_TELEGRAM_TOKEN': self.token,
                                       'TQDM_TELEGRAM_CHAT_ID': self.chat_id})
            self.patch_g.start()

        def tearDown(self):
            self.patch_g.stop()


# Generated at 2022-06-24 10:07:30.477070
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from unittest import main
    from .tests_tqdm import PretendKeyboardInterrupt

    class TestTelegramIO(TelegramIO):
        _message_id = 'messageid'

        def __init__(self, *args, **kwargs):
            self.clear_called = False
            self.write_called = False
            super(TestTelegramIO, self).__init__(*args, **kwargs)

        def write(self, s=''):
            self.write_called = True

        def delete(self):
            self.clear_called = True

    class Testtqdm_telegram(tqdm_telegram):
        tgio = TestTelegramIO

# Generated at 2022-06-24 10:07:38.731086
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    tqdm_telegram.display(
        format_dict={'bar_format': '<bar/>', 'auto_update_format': False})
    tqdm_telegram.display(
        format_dict={'bar_format': '{bar}', 'auto_update_format': False})
    tqdm_telegram.display(
        format_dict={'bar_format': '{l_bar}{bar}{r_bar}', 'auto_update_format': False})
    tqdm_telegram.display(
        format_dict={'bar_format': '{bar:10u}', 'auto_update_format': False})

# Generated at 2022-06-24 10:07:43.440692
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    """Unit test for method delete of class TelegramIO"""
    token = getenv('TQDM_TELEGRAM_TOKEN', "")
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID', "")
    tgio = TelegramIO(token, chat_id)
    tgio.message_id
    tgio.delete()

# Generated at 2022-06-24 10:07:54.254452
# Unit test for method display of class tqdm_telegram

# Generated at 2022-06-24 10:08:04.606725
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    """
    Unit test for class `tqdm_telegram`.
    """
    import time
    import sys
    import traceback

    try:
        from .tests_tqdm import bypass_tqdm
    except ImportError:
        from .tests_tqdm_py2 import bypass_tqdm
    with bypass_tqdm():
        for _ in tqdm(range(3), total=3,
                       token='123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11',
                       chat_id='123456789',
                       bar_format='{l_bar}{bar:10}|{n_fmt}/{total_fmt} [{elapsed}, {rate_noinv_fmt}, {postfix}]'):
            time.sleep(0.1)

# Generated at 2022-06-24 10:08:06.649883
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    for _ in tqdm_telegram([4, 5, 6]):
        pass



# Generated at 2022-06-24 10:08:10.825104
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    tok = getenv('TQDM_TELEGRAM_TOKEN')
    cid = getenv('TQDM_TELEGRAM_CHAT_ID')
    if not (tok and cid):
        warn("No token and/or ID", TqdmWarning)
        return
    _ = TelegramIO(tok, cid)

# Generated at 2022-06-24 10:08:16.987225
# Unit test for function trange
def test_trange():
    """Unit tests"""
    out = io.StringIO()
    expected = "  0%|          | 0/11 [00:00<?, ?it/s]\n"

    with redirect_stdout(out), redirect_stderr(out):
        with tqdm(range(11), file=out) as pbar:
            for i in pbar:
                if i == 5:
                    pbar.set_description("testing")
        assert out.getvalue() == expected

# Generated at 2022-06-24 10:08:28.860840
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from requests_mock import Mocker
    from requests import Session

    text = 'test_tqdm_telegram_close'

    def delete_request():
        return ({'error_code': 429, 'description': 'Too Many Requests: retry after 1'}, 200)

    with Mocker() as m:
        session = Session()
        m.post(TelegramIO.API + 'token/sendMessage', json={
            'result': {'message_id': 123, 'chat': {'id': 456}, 'text': '`' + text + '`'},
            'ok': True})
        m.get(TelegramIO.API + 'token/deleteMessage', status_code=200, json=delete_request)


# Generated at 2022-06-24 10:08:33.988147
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    tgio = TelegramIO(token, chat_id)
    assert tgio.write("test") is not None



# Generated at 2022-06-24 10:08:42.052432
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .utils_test import _test_display

    def create_instance(parameter_dict=None):
        if parameter_dict is None:
            parameter_dict = {}


# Generated at 2022-06-24 10:08:48.350479
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    """
    Unit test for method display of class tqdm_telegram.

    It contains a unit test for display method. This method is responsible for
    writing the message to a Telegram Bot.

    It works on:
    - Check if the method is writting the correct string on the given
      Telegram Bot.
    - Check if it is possible to replace the current string on a Telegram Bot

    """
    from .tests_tqdm import _suppress_stderr, _range
    import unittest
    import re

    class _TestTelegramIO(unittest.TestCase):
        """
        Unit test for method display of class tqdm_telegram.
        """


# Generated at 2022-06-24 10:08:53.464342
# Unit test for function trange
def test_trange():
    import time
    import sys
    import gc
    time.sleep(3)
    if not (2 < int(sys.version[0])):
        from xmlrpclib import ServerProxy
        pypi = ServerProxy('https://pypi.python.org/pypi')
        for _ in trange(max(map(int, pypi.package_releases('tqdm'))),
                        token='{token}', chat_id='{chat_id}'):
            gc.collect()

if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 10:08:55.576771
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    t = TelegramIO("token", "chat_id")
    t.message_id = 123
    t.delete().join()

# Generated at 2022-06-24 10:08:59.199056
# Unit test for function trange
def test_trange():
    from . import _test_trange
    for i in trange(4, token=getenv('TQDM_TEST_TOKEN'), chat_id=getenv('TQDM_TEST_CHAT_ID')):
        pass
    _test_trange.test_trange()

# Generated at 2022-06-24 10:09:04.019396
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    if getenv('CI') or getenv('DISABLE_TQDM_TESTS'):
        return
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if token and chat_id:
        TelegramIO(token, chat_id).write('`tqdm.contrib.telegram` **unit** '
                                         '**test**')

# Generated at 2022-06-24 10:09:11.688604
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    # fake token & chat_id
    tg = TelegramIO('fail', 0)
    # fake format_dict
    x = tqdm_telegram(0, file=tg)
    tg.message_id = 0
    x.display(l_bar='{desc}', bar='{percentage:3.0f}%', bar_format='{bar}')


if __name__ == '__main__':
    from doctest import testmod
    testmod(name='telegram',
            optionflags=doctest.NORMALIZE_WHITESPACE)
    test_tqdm_telegram_display()

# Generated at 2022-06-24 10:09:16.845763
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    '''
    >>> with tqdm([0, 1], token='{token}', chat_id='{chat_id}') as t:
    ...     assert t.disable == False
    ...     t.close()
    '''
    pass

if __name__ == '__main__':
    from doctest import testmod
    testmod()

# Generated at 2022-06-24 10:09:19.799551
# Unit test for function trange
def test_trange():
    with trange(10, token='{token}', chat_id='{chat_id}') as t:
        for i in t:
            sleep(0.01)

# Generated at 2022-06-24 10:09:24.098884
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    class MyTelegramIO(TelegramIO):
        def __init__(self):
            self.token = ""
            self.chat_id = ""
        def submit(self, *args, **kwargs):
            print(args)
            print(kwargs)

    io = MyTelegramIO()
    io.delete()

# Generated at 2022-06-24 10:09:27.558303
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    try:
        TelegramIO('token', 'chat_id')
    except Exception as e:
        raise
    else:
        pass


# Generated at 2022-06-24 10:09:39.709376
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from time import sleep
    from sys import version_info
    from os import environ
    from .utils import TqdmTypeError
    from .format_dict import FormatCustomText

    # Test for missing_token
    try:
        with tqdm_telegram(total=10) as pbar:
            sleep(0.01)
            raise AssertionError()
    except TqdmTypeError:
        pass

    # Test for missing_chat_id
    try:
        with tqdm_telegram(total=10, token='{token}') as pbar:
            sleep(0.01)
            raise AssertionError()
    except TqdmTypeError:
        pass

    # Test for missing_token,missing_chat_id

# Generated at 2022-06-24 10:09:44.253060
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    t = tqdm_telegram(disable=True, leave=True, unit_scale=True)
    t.format_dict['bar_format'] = "<bar/>"
    t.display()
    assert t.last_print_n == 0
    t.total = 100
    t.display()
    assert t.last_print_n == 0


# Generated at 2022-06-24 10:09:50.599779
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    import sys
    if sys.version_info[0] == 3:
        range = _range
    else:
        from builtins import range
    t = tqdm_telegram(range(10))
    t.close()

# Generated at 2022-06-24 10:09:54.311887
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .tests_telegram import test_tqdm_telegram_display
    test_tqdm_telegram_display()


if __name__ == '__main__':
    from doctest import testmod
    testmod(verbose=True)

# Generated at 2022-06-24 10:09:56.600442
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tg = TelegramIO(token='', chat_id='')
    tg.write('The test passed')
    tg._TelegramIO__worker.stop()


# Generated at 2022-06-24 10:10:03.069240
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from ..utils import _decode_unicode
    tg_io = TelegramIO('token', 'chat_id')
    tg_io.write('test')
    from multiprocessing.pool import ThreadPool
    try:
        ThreadPool(1).wait_completion()
    except Exception as e:
        tqdm_auto.write(_decode_unicode(str(e)))
    else:
        tg_io.write('test')
        tg_io.delete()

# Generated at 2022-06-24 10:10:08.015090
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    try:
        t = tqdm(total=100, disable=True, leave=True)
    except Exception as e:
        print(str(e))
        return False

# Generated at 2022-06-24 10:10:17.981791
# Unit test for function trange
def test_trange():
    from time import sleep
    for i in trange(5, token='123456789:ABCDEFGHIJKLMNOPQURSTUVXYZ',
                    chat_id='12345', desc='desc', ascii=True):
        if i == 0:
            assert tqdm_telegram.format_dict['desc'] == 'desc'
            assert tqdm_telegram.format_dict['bar_format'] == '[{n_fmt}/{total_fmt}] {percentage:3.0f}% |{bar:20}{r_bar}| {desc}'
        elif i == 1:
            assert tqdm_telegram.format_dict['desc'] == 'desc'

# Generated at 2022-06-24 10:10:27.886585
# Unit test for function trange
def test_trange():
    """Test trange"""
    with tqdm(total=10) as t:
        assert hasattr(t, 'mininterval')
    assert t.mininterval == 0.1
    for _ in trange(4, ncols=40, ascii=True, disable=None, mininterval=0.1,
                    total=10, desc='test', unit='it', unit_scale=True,
                    unit_divisor=1000, dynamic_ncols=True, leave=True):
        assert t.mininterval == 0.1
        assert t.disable is None
        assert hasattr(t, 'miniters')
        assert t.total == 10
        assert t.desc == 'test'
        assert t.unit == 'it'
        assert t.unit_scale == True
        assert t.unit_

# Generated at 2022-06-24 10:10:29.555340
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    assert TelegramIO('', '').message_id is None
    assert TelegramIO('token', 'chat_id').message_id is not None

# Generated at 2022-06-24 10:10:38.630903
# Unit test for function trange
def test_trange():
    # python3
    try:
        trange(1, token='{token}', chat_id='{chat_id}')
    except Exception:
        pass

    trange(1, desc='tqdm', leave=True, mininterval=0, token='{token}',
           chat_id='{chat_id}')

    # python2
    try:
        trange(1, token='{token}', chat_id='{chat_id}')
    except Exception:
        pass

    trange(1, desc='tqdm', leave=True, mininterval=0, token='{token}',
           chat_id='{chat_id}')

# Generated at 2022-06-24 10:10:42.260335
# Unit test for function trange
def test_trange():
    for n in trange(5, token=getenv('TQDM_TELEGRAM_TOKEN'),
                    chat_id=getenv('TQDM_TELEGRAM_CHAT_ID')):
        assert n is not None

# Generated at 2022-06-24 10:10:49.822736
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from io import StringIO
    import sys
    import json
    import os
    import re
    import time

    # define the module-level class with name 'tqdm' to execute the method 'display'
    class tqdm():
        def display(self, **kwargs):
            if not hasattr(self, 'output'):
                self.output = StringIO()
            super(tqdm, self).display(file=self.output, **kwargs)

    # create a fake class tqdm with name 'tqdm'
    tqdm.__name__ = 'tqdm'
    # import the method display of tqdm_telegram to the class tqdm
    tqdm.display = tqdm_telegram.display

    # define a token and a chat id for the test
    token = os.en

# Generated at 2022-06-24 10:10:58.078684
# Unit test for function trange
def test_trange():
    """Unit test for function `trange`."""
    from os import getenv
    from random import random
    from time import sleep

    token = getenv("TQDM_TELEGRAM_TOKEN")
    if token is None or len(token) == 0:
        raise Exception("Missing environment variable TQDM_TELEGRAM_TOKEN")
    chat_id = getenv("TQDM_TELEGRAM_CHAT_ID")
    if chat_id is None or len(chat_id) == 0:
        raise Exception("Missing environment variable TQDM_TELEGRAM_CHAT_ID")

    # Run the test
    for i in trange(5, total=5, desc="In trange", token=token, chat_id=chat_id):
        sleep(random())



# Generated at 2022-06-24 10:11:04.427298
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    """Tests that the TelegramIO constructor works."""
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if token and chat_id:
        tgio = TelegramIO(token, chat_id)
        assert(tgio is not None)


if __name__ == '__main__':
    test_TelegramIO()

# Generated at 2022-06-24 10:11:10.583611
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    # Test if delete method works correctly without any errors
    # If not it will raise AssertionError
    tgio = TelegramIO(None, None)
    tgio._message_id = 123
    try:
        tgio.delete()
    except Exception as e:
        tqdm_auto.write(str(e))
        assert True, "delete method has error"
    assert True, "delete method works correctly"

# Generated at 2022-06-24 10:11:17.059448
# Unit test for function trange
def test_trange():
    from time import sleep
    from numpy.random import random
    for i in trange(10, token='111122223333444455556666',
                    chat_id='@tqdm_test'):
        sleep(.1 * random())
    for i in trange(11, token='111122223333444455556666',
                    chat_id='@tqdm_test'):
        sleep(.1 * random())
    print('Telegram trange() unit test successful!')



# Generated at 2022-06-24 10:11:22.345634
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import unittest
    class TestTqdmTelegramClear(unittest.TestCase):
        def test_clear(self):
            import tqdm.contrib.telegram as tqdm

            with self.assertRaises(tqdm.tqdm_telegram.TelegramIOError):
                with tqdm.tqdm_telegram(token='token') as pbar:
                    pbar.clear()
    unittest.main()

# Generated at 2022-06-24 10:11:28.103371
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    with tqdm(total=1, unit='B', unit_scale=True, miniters=1) as pbar:
        io = pbar.telegramio
        io.write(b'a')
        io.write(b'a')
        io.write(b'a')
        io.write(b'a')


# Generated at 2022-06-24 10:11:32.816307
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    try:
        tt = tqdm_telegram([0], token="__UNIT_TEST__TOKEN__",
                           chat_id="__UNIT_TEST__CHAT_ID__")
        tt.write()
        tt.close()
        assert True
    except Exception:
        assert False

# Generated at 2022-06-24 10:11:41.269848
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    # Test TelegramIO
    tgio = TelegramIO(token='123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11',
                      chat_id='1234567890')
    tgio.write('_test_tqdm')
    tqdm_auto.write(tgio._message_id)
    tgio.delete()

    # Test tqdm_telegram

# Generated at 2022-06-24 10:11:44.029626
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tgio = TelegramIO('{token}', '{chat_id}')
    future = tgio.delete()
    assert future.result() is None

# Generated at 2022-06-24 10:11:50.950319
# Unit test for function trange
def test_trange():
    from os import devnull
    from random import random
    from time import sleep
    for _ in trange(10, token='1197087837:AAFVY8XhWp_0o0TfTjl1Vbm1sWZnDlZmGVE', chat_id='756527796', mininterval=0.1, file=open(devnull, 'w')):
        sleep(random() / 2)

# Generated at 2022-06-24 10:11:53.714359
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tg_io = TelegramIO('1','2')
    tg_io.message_id = '111'
    tg_io.delete()