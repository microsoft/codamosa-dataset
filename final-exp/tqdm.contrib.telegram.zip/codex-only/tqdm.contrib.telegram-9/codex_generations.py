

# Generated at 2022-06-24 10:01:46.806918
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    try:
        tqdm_telegram.__init__(
            tqdm_telegram, iterable, token='{token}', chat_id='{chat_id}')
    except:
        pass

# Generated at 2022-06-24 10:01:48.980117
# Unit test for function trange
def test_trange():
    tgr = trange(1, 1, token='1234', chat_id='1234')
    list(tgr)  # will print traceback if test fails

# Generated at 2022-06-24 10:01:50.678687
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    TelegramIO('mock_token', 'mock_chat_id')

# Generated at 2022-06-24 10:01:53.629399
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    t = tqdm_telegram(total=10,disable=True)
    assert t.disable
    t = tqdm_telegram(total=10,disable=False)
    assert not t.disable
    

# Generated at 2022-06-24 10:01:57.703020
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    """Tests if TelegramIO.write() can handle invalid tokens."""
    from .utils_test import _test_write_with_wrong_token
    _test_write_with_wrong_token(tqdm_telegram)


# Generated at 2022-06-24 10:02:05.580094
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    tgm = tqdm_telegram(total=2, desc='test', initial=0, mininterval=1, miniters=1,
                        disable=False, leave=False, bar_format="{bar}",
                        token=getenv('TQDM_TELEGRAM_TOKEN'),
                        chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'))
    tgm.display()
    tgm.update()


if __name__ == '__main__':
    from doctest import testmod
    testmod(optionflags=+testmod.ELLIPSIS)

# Generated at 2022-06-24 10:02:16.884152
# Unit test for function trange
def test_trange():
    """Test trange function"""
    from ..utils import _terminal_size
    from time import sleep
    with ttgrange(4) as t:
        for i in t:
            sleep(0.5)
    with ttgrange(4, token='392001694:AAE-w_RFXcChJdYydP8IW5f5xDq3ZPqIVOI',
                  chat_id='27053734') as t:
        for i in t:
            sleep(0.5)

# Generated at 2022-06-24 10:02:20.821180
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    t = tqdm_telegram(token='{token}', chat_id='{chat_id}')
    t.write = tqdm_telegram.write
    t.close = tqdm_telegram.close
    t.write('test_tqdm_telegram')
    t.close()

# Generated at 2022-06-24 10:02:33.587069
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from .utils_test import closing
    from requests import HTTPError

    def test_write(s, msg_id='15', text='', code=200, err=None):
        for c in (r'\r', r'\r\r', r'\r\n\r', r'\r\n\r\r', r'\r\n\r\n\r'):
            if c in s or c.replace('\\r', '\r') in s:
                return  # Exception Error
        message_id = msg_id
        tgio = TelegramIO('test_tok', 'test_cid')
        tgio._message_id = message_id

# Generated at 2022-06-24 10:02:41.667251
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    import getpass
    while True:
        try:
            token = input('Telegram token [default: ${TQDM_TELEGRAM_TOKEN}]: ')
            chat_id = input('Telegram chat ID [default: '
                            '${TQDM_TELEGRAM_CHAT_ID}]: ')
        except NameError:
            token = getpass.getpass('Telegram token [default: '
                                    '${TQDM_TELEGRAM_TOKEN}]: ')
            chat_id = getpass.getpass('Telegram chat ID [default: '
                                      '${TQDM_TELEGRAM_CHAT_ID}]: ')
        if token and chat_id:
            break
        print('Error: both `token` and `chat_id` are required.')

# Generated at 2022-06-24 10:02:45.144321
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    t = tqdm_telegram(token='token', chat_id='chat_id')
    t.display()

# Generated at 2022-06-24 10:02:56.599128
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import re
    import requests
    from time import sleep
    tqdm_mininterval = tqdm_telegram.mininterval

# Generated at 2022-06-24 10:03:06.664061
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from .test_tqdm import FakeTTY

    with FakeTTY() as tty:
        for t in [tqdm_telegram, tqdm, ttgrange]:
            pbar = t(iterable=range(3), file=tty, disable=False)
            assert pbar.moveto is None
            pbar.clear()
            assert pbar.moveto is None
            pbar.close()
            assert pbar.moveto is None
            assert tty.file.getvalue() == '\x1b7\x1b[?25l\x1b[K\x1b8'

# Generated at 2022-06-24 10:03:08.072807
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(1)
    t.close()

# Generated at 2022-06-24 10:03:09.585493
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    # TODO: implement unit test for method write of class TelegramIO
    pass

# Generated at 2022-06-24 10:03:10.901004
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    assert tqdm(total=100, unit='***').clear().close().pos == 0

# Generated at 2022-06-24 10:03:19.606638
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tgio = TelegramIO('0123456789:AAG90e14-0f8-40183Dzuyfhjfhjfhd',
                                 '@tqdm_bot')
    assert tgio.token == '0123456789:AAG90e14-0f8-40183Dzuyfhjfhjfhd'
    assert tgio.chat_id == '@tqdm_bot'
    assert tgio.text == 'TelegramIO'

    # Verify the method write
    tgio.write('Hello world')
    assert tgio.text == 'Hello world'

    # Verify the method delete
    tgio.delete()
    assert tgio.message_id == None

# Generated at 2022-06-24 10:03:28.744598
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    import os
    import json
    from requests import Session
    from tqdm.contrib.telegram import TelegramIO
    if 'TQDM_TELEGRAM_TOKEN' not in os.environ:
        raise RuntimeError(
            'Can not test delete method of class TelegramIO: '
            'the environment variable TQDM_TELEGRAM_TOKEN is not defined.')
    if 'TQDM_TELEGRAM_CHAT_ID' not in os.environ:
        raise RuntimeError(
            'Can not test delete method of class TelegramIO: '
            'the environment variable TQDM_TELEGRAM_CHAT_ID is not defined.')
    session = Session()

# Generated at 2022-06-24 10:03:39.027077
# Unit test for function trange
def test_trange():
    from .utils_test import test, _test_telegram_chat_id, tqdm_telegram_test as tt

    def _test(**kwargs):
        return tt(range(10), **kwargs)

    if _test_telegram_chat_id():
        with test(_test):
            assert '[trange]' in _test()._desc  # noqa: WPS441
            assert '[trange]' in _test(desc='trange')._desc
            assert '[trange]' in _test(desc='%s', descargs=('trange',))._desc
            assert '[trange]' in _test(desc='%s', descargs=('trange',))._desc
            assert _test()._total == 10
            assert _test(total=9)._total == 9

# Generated at 2022-06-24 10:03:39.517618
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    assert TelegramIO('token', 'chat_id').delete()

# Generated at 2022-06-24 10:03:48.230529
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import sys
    import time

    # tqdm_telegram instance
    t = tqdm_telegram(total=10, desc='tqdm_telegram')
    t.display()          # display bar
    time.sleep(2)
    t.clear()            # clear bar, but stay on the same line
    time.sleep(2)
    t.close()            # clear bar and move to next line
    sys.stdout.write("\n" * 4)

    # tqdm_telegram instance (position=6, bar for bar_format)
    t = tqdm_telegram(total=10, desc='tqdm_telegram', bar_format='{bar:10u}')
    t.display(pos=6)     # display bar
    time.sleep(2)
    t.clear()           

# Generated at 2022-06-24 10:03:59.659891
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    """
    Tests that method write of TelegramIO correctly edits a message.
    """
    import sys
    import time
    import tqdm.contrib.test_utils as ttu
    from .utils_test import assert_same_bar_colour

    io = TelegramIO('1234567890', '9876543210')
    io.write('Hello')
    io.write('World')
    io.write('Hello')
    io.write('World')

    # Test flush
    for i in tqdm(range(10), file=io, ncols=80):
        time.sleep(0.1)

    # Test write after closing
    tqdm.write("This is a test.", file=io)
    assert ttu.delete_colouring(io.text) == ttu.delete_colouring("This is a test.")

# Generated at 2022-06-24 10:04:01.630688
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    p = tqdm_telegram(total=1000000)
    p.clear()

# Generated at 2022-06-24 10:04:05.903173
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import sys

    telegram_test_token = "1234:test_test"
    telegram_test_chat = "1"

    for _ in tqdm_telegram(_range(10), token=telegram_test_token,
                           chat_id=telegram_test_chat):
        sys.stdout.write("\n")



# Generated at 2022-06-24 10:04:13.441660
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    ###############
    # Test token and chat_id are both required.
    from sys import stderr
    from contextlib import redirect_stderr
    from os import devnull
    # with redirect_stderr(devnull):
    #     tqdm_telegram(range(3), disable=True)

    ###############
    # Test message is sent on instantiation.
    from os import environ
    environ["TQDM_TELEGRAM_TOKEN"] = "924673530:AAG2HwvGtffWx8kp_AwdAjEHpvzmWf9XcRU"
    environ["TQDM_TELEGRAM_CHAT_ID"] = "-270940203"
    tqdm_telegram(range(3), disable=True)

# Generated at 2022-06-24 10:04:23.573853
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    import time
    import os

    try:
        for _ in tqdm_telegram(
                _range(100),
                token=os.environ['TQDM_TELEGRAM_TOKEN'],
                chat_id=os.environ['TQDM_TELEGRAM_CHAT_ID'],
                mininterval=0.1):
            time.sleep(0.01)
    except:
        return False
    else:
        return True


if __name__ == "__main__":
    import time
    import os


# Generated at 2022-06-24 10:04:29.194085
# Unit test for function trange
def test_trange():
    n = 10000
    for mininterval in [None, 0, 0.002, 0.02, 0.2, 1, 10]:
        # Test trange
        fobj = TelegramIO(
            token=getenv('TQDM_TELEGRAM_TOKEN'),
            chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'))
        for _ in range(10):
            fobj.write("hi")
        for _ in tqdm(range(n), mininterval=mininterval, file=fobj):
            pass
        for _ in range(10):
            fobj.write("hi")


if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-24 10:04:39.167878
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    from ..utils import _environ_cols_wrapper
    from ..std import sys

    tg = TelegramIO('TOKEN', 'CHAT_ID')
    assert tg.message_id is not None
    tg.write(' ')
    tg.delete()
    if not sys.flags.interactive:
        # Run tests only if not in `ipython`
        with _environ_cols_wrapper(100):
            tqdm_telegram(iterable=range(10), desc=tg, mininterval=0).close()
    tg.close()
    tg.delete()
    tg.tgio.close()

# Generated at 2022-06-24 10:04:41.235563
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    tg = tqdm(token='', chat_id='')
    tg.close()
    tg.close()

# Generated at 2022-06-24 10:04:50.141222
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    """Unit test for `tqdm_telegram`"""
    from subprocess import getoutput
    text = __doc__.split('\n\n')[0]

    def run(cmd):
        """Helper"""
        out = getoutput(cmd)
        assert 'ERROR:' not in out, out
        return out

    try:
        token = run('grep "%s ... %s" %s' %
                    (text[:16], text[-16 - len('token') - 1: -16],
                     __file__)).split('\n')[-1].split()[0].strip("'")
        assert token.startswith('token=')
        token = token[len('token='):]
    except Exception:
        token = None

# Generated at 2022-06-24 10:04:54.424052
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    t = TelegramIO(token='123456789:A1B2C3D4E5F6G7H8I9J0K1L2M3N4O5P6',
                   chat_id='123456789')
    assert t.text == t.__class__.__name__
    assert t.message_id is not None
    assert t.write('test') is not None

# Generated at 2022-06-24 10:05:01.241442
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tmp = TelegramIO("", "")
    tmp.write("")
    tmp.write("\r")
    tmp.write("\r  \r")
    tmp.write("\n\n\n")
    tmp.write("\r2\r\n\n")
    tmp.write("\r3\r\r")

# Generated at 2022-06-24 10:05:10.104280
# Unit test for function trange
def test_trange():
    n = 1000
    for i in trange(n, desc='Test', leave=False,
                    token='1392435063:AAG4n4eU4At6UiZE6UvQ6NKB-Lk-QHhDju8',
                    chat_id='937016197'):
        assert i < n
    # Also test context manager
    with trange(n, desc='Test',
                token='1392435063:AAG4n4eU4At6UiZE6UvQ6NKB-Lk-QHhDju8',
                chat_id='937016197') as t:
        for i in t:
            assert i < n

# Generated at 2022-06-24 10:05:14.036506
# Unit test for function trange
def test_trange():
    for _ in trange(4, token='{token}', chat_id='{chat_id}'):
        pass
    for _ in tqdm(range(4), token='{token}', chat_id='{chat_id}'):
        pass

# Generated at 2022-06-24 10:05:18.153488
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    assert tqdm_telegram(disable=True, ncols=0, bar_format="<bar>").display(
        n=1, total=1, bar_format="<bar>") is None

# Generated at 2022-06-24 10:05:21.116985
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from .utils_test import _test_tqdm_clear
    _test_tqdm_clear(tqdm)

# Generated at 2022-06-24 10:05:28.672403
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    from os import environ
    from time import sleep
    from tqdm import trange
    from tqdm.contrib import telegram
    for i in trange(3):
        try:
            telegram.TelegramIO(environ.get('TQDM_TELEGRAM_TOKEN'),
                                environ.get('TQDM_TELEGRAM_CHAT_ID')).delete()
        except Exception as e:
            trange.write(str(e))
        sleep(2**i)



# Generated at 2022-06-24 10:05:30.819686
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    t = tqdm_telegram()
    t._n = 10
    t.clear()
    assert t.n == 10

# Generated at 2022-06-24 10:05:39.771352
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    import time
    import numpy as np
    from tqdm import tqdm, trange

    def random_char(y):
        time.sleep(np.random.random())
        return '*'

    for _ in trange(4, desc='FAIL x4', leave=False, ascii=True,
                    disable=None):
        for _ in tqdm([random_char(i) for i in range(20)],
                      desc='OK',
                      total=20,
                      disable=False,
                      ascii=True,
                      leave=False):
            pass


if __name__ == "__main__":
    test_TelegramIO_delete()

# Generated at 2022-06-24 10:05:42.530351
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    (tqdm_telegram(range(3), disable=True)
         .clear()
         .close())

# Generated at 2022-06-24 10:05:53.184766
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import requests
    from tqdm.auto import tqdm
    from .utils_test import no_pandas
    if no_pandas:
        return

    # Create a new message
    token = '{token}'
    chat_id = '{chat_id}'
    IO = TelegramIO(token, chat_id)
    assert IO.message_id, "`token` or `chat_id` is incorrect or the bot is rate limited."
    IO.text = "__init__"
    IO.write("__write__")

    # Retrieve all messages from `chat_id`
    try:
        res = requests.get(IO.API + '%s/getUpdates' % token).json()
    except Exception as e:
        tqdm.write(str(e))
    else:
        res

# Generated at 2022-06-24 10:06:00.007833
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm.auto import tqdm
    import time
    for __ in tqdm_telegram(range(10), 'test_display_tg'):
        time.sleep(0.1)

    for __ in tqdm_telegram(range(10), 'test_display_tg_no_leaving',
                            leave=False):
        time.sleep(0.1)

    for __ in tqdm(range(10), 'test_display_no_tg'):
        time.sleep(0.1)

# Generated at 2022-06-24 10:06:01.442932
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    for _ in tqdm_telegram(range(3), token="", chat_id=""):
        pass
        # Print a status bar.

# Generated at 2022-06-24 10:06:04.740820
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import os
    os.environ['TQDM_TELEGRAM_TOKEN'] = os.environ['TQDM_TELEGRAM_CHAT_ID'] = ''
    TelegramIO(token='test', chat_id='test').write('')

# Generated at 2022-06-24 10:06:09.944744
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from os import getenv
    from warnings import catch_warnings
    from .utils_test import pretest_posttest

    def write(t, *args):
        ttgrange(t, token=getenv("TQDM_TELEGRAM_TOKEN"),
                 chat_id=getenv("TQDM_TELEGRAM_CHAT_ID")).write(*args)

    with catch_warnings(record=True):
        pretest_posttest(write)("a\n", "b\r")

# Generated at 2022-06-24 10:06:12.329960
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from ._utils import _test_tqdm_telegram
    _test_tqdm_telegram(tqdm)



# Generated at 2022-06-24 10:06:19.516588
# Unit test for function trange
def test_trange():
    tgrng = trange(10, token='632514596:AAEoCSdDwUTnRlxHxr8Zhwg0eExh0z_qfXA', chat_id='609898472',
                   dynamic_ncols=True, ascii=True, bar_format='{l_bar}{bar}{r_bar}{bar:-10b}')
    for _ in tgrng:
        tgrng.set_description("Test description")
        tgrng.update()
        time.sleep(0.01)
    assert tgrng.n == 10

if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-24 10:06:23.118706
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    # Test case of close method (leave=False)
    obj = tqdm_telegram(disable=False)
    obj.close()

    # Test case of close method (leave=True)
    obj = tqdm_telegram(leave=True)
    obj.close()

# Generated at 2022-06-24 10:06:27.841319
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    from os import environ
    from requests import Session
    session = Session()
    TelegramIO(environ.get('TQDM_TELEGRAM_TOKEN'),
               environ.get('TQDM_TELEGRAM_CHAT_ID')).delete()

# Generated at 2022-06-24 10:06:35.422738
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tqdm_auto.write(
        "Initializing test_TelegramIO_delete, please wait...")
    # Create a TelegramIO
    test_token = input("Please paste your Telegram Bot token here: ")
    test_chat_id = input("Please paste your Telegram chat ID here: ")
    test_message_id = TelegramIO(test_token, test_chat_id).message_id
    test_token = test_token.replace("bot", "")
    # Delete the message
    res = tqdm_auto._make_req(
        "https://api.telegram.org/bot" + test_token + "/deleteMessage",
        data={'chat_id': test_chat_id, 'message_id': test_message_id}).json()
    # Write results

# Generated at 2022-06-24 10:06:38.606915
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    from time import sleep
    tg = TelegramIO('token', 'chat_id')
    tg.delete()
    sleep(1)  # wait for async operation to complete


# Generated at 2022-06-24 10:06:45.204986
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    from os import environ
    from tempfile import TemporaryFile
    with TemporaryFile('w+') as f:
        telegramio = TelegramIO(
            environ.get('TQDM_TELEGRAM_TOKEN'),
            environ.get('TQDM_TELEGRAM_CHAT_ID'))
        for err in telegramio.map(telegramio.write, "Hello World !"):
            assert environ.get('TRAVIS_EVENT_TYPE') == 'cron', \
                "This test is only ran by the bot itself."
            assert err is None, err

# Generated at 2022-06-24 10:06:50.087934
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    from unittest import TestCase, main
    from os import getenv
    from re import search
    class TestTelegramIO(TestCase):
        def setUp(self):
            self.a = TelegramIO(token=getenv('TQDM_TELEGRAM_TOKEN'), chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'))
            self.a.message_id
            self.a.session = Session()
            self.message_id = self.a.message_id
            self.chat_id = self.a.chat_id
            self.token = self.a.token
            delete_api = 'https://api.telegram.org/bot' + self.token + '/deleteMessage'

# Generated at 2022-06-24 10:06:56.127743
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    telegram_token = getenv('TQDM_TELEGRAM_TOKEN')
    telegram_chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if telegram_token is None or telegram_chat_id is None:
        print("Skiping test: No Telegram credentials")
        return
    tg = TelegramIO(telegram_token, telegram_chat_id)
    tg._message_id = 99999999
    # telegram_token and telegram_chat_id are used by _write method,
    # so we must set it as arguments
    tg.delete(telegram_token, telegram_chat_id)

# Generated at 2022-06-24 10:06:57.975321
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    tqdm_telegram(range(3), token='test', chat_id='test')

# Generated at 2022-06-24 10:07:07.221662
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    class TestTelegramIO(TelegramIO):
        """
        Mock TelegramIO
        """
        def __init__(self):
            self.close_executed = False
        def close(self):
            self.close_executed = True

    # leave=False, pos=0
    test_tgio = TestTelegramIO()
    test_tqdm = tqdm_telegram(total=0, leave=False, disable=False, tgio=test_tgio)
    test_tqdm.close()
    assert not test_tgio.close_executed

    # leave=True, pos=0
    test_tgio = TestTelegramIO()
    test_tqdm = tqdm_telegram(total=0, leave=True, disable=False, tgio=test_tgio)
    test_

# Generated at 2022-06-24 10:07:08.951888
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(range(3), disable=True)
    t.close()

# Generated at 2022-06-24 10:07:13.201160
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    def no_output_with(s):
        print(s, end='')

    with tqdm_telegram(total=10, file=no_output_with) as t:
        t.clear()
        t.clear()
        t.clear()
        t.clear()

# Generated at 2022-06-24 10:07:22.347842
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    token = '{token}'
    chat_id = '{chat_id}'
    telegramIO = TelegramIO(token, chat_id)
    message_id = telegramIO.message_id
    telegramIO.delete()
    try:
        telegramIO.delete()
    except Exception as e:
        if e.response.json().get('error_code') == 400:
            tqdm_auto.write("We have deleted a message that does not exist")
        else:
            tqdm_auto.write(str(e))
    else:
        telegramIO = TelegramIO(token, chat_id)
        telegramIO.delete()
        tqdm_auto.write("We have deleted a message that exists")
    telegramIO = TelegramIO(token, chat_id)
    telegramIO.message

# Generated at 2022-06-24 10:07:29.092695
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from time import sleep
    from tqdm.contrib.telegram import TelegramIO
    tg = TelegramIO(token='{token}', chat_id='{chat_id}')
    for i in tqdm_telegram(range(5), disable=True):
        sleep(1)
        tg.write(str(i))


if __name__ == '__main__':
    from doctest import testmod
    from sys import stderr
    testmod()

# Generated at 2022-06-24 10:07:38.027141
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    class Fake(object):
        def __init__(self, token, chat_id):
            self.resp = {'result': {'message_id': 123456}}  # overwrite
            tgio = TelegramIO(token, chat_id)
            tgio.session.post = lambda *a, **kw: Fake(None, None)

        def json(self):
            return self.resp

    g = Fake('123', '456')
    g.resp['error_code'] = 404
    assert g.message_id is None
    g.resp['error_code'] = 429
    assert g.message_id is None


if __name__ == "__main__":
    from doctest import testmod
    from telegram_bot2 import TelegramBot
    from tqdm._utils import _term_move_up

    tb

# Generated at 2022-06-24 10:07:49.343633
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from io import StringIO
    from time import sleep
    import sys

    # Fails in PyPy3 6.0.0 because of
    # https://bitbucket.org/pypy/pypy/issues/3116/support-for-stream-wrappers-such-as-io
    if sys.implementation.name == 'pypy' and sys.version_info[:3] == (3, 6, 0):
        return

    # Set up output capture
    sio = StringIO()
    sys.stdout = sio
    try:
        t = tqdm_telegram(0, file=sys.stdout)
        sleep(1)
        t.clear()
        sleep(1)
        t.close()
    finally:
        sys.stdout = sys.__stdout__


# Generated at 2022-06-24 10:07:57.291963
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    import argparse
    from os import remove

    from .utils import _range
    from .utils_test import pretest, posttest, catch_warnings
    from .utils_test import with_import


# Generated at 2022-06-24 10:08:05.614723
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    token = '{token}'
    chat_id = '{chat_id}'
    message = TelegramIO(token, chat_id)
    message.message_id
    message.write('test')
    message.delete()


if __name__ == '__main__':
    import sys
    import json
    import signal
    from os import getenv

    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if token is None or chat_id is None:
        sys.exit("\nNeed 'TQDM_TELEGRAM_TOKEN' "
                 "and 'TQDM_TELEGRAM_CHAT_ID' env variables!\n")

# Generated at 2022-06-24 10:08:13.918015
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    import unittest
    import unittest.mock as mock
    class TestTelegramIO(unittest.TestCase):
        def test_delete(self):
            tgio = TelegramIO('mock_token', 'mock_chat_id')
            with mock.patch.object(tgio.session, 'post', autospec=True) as mock_session_post:
                mock_session_post.return_value.json.return_value = {'ok': True}
                future = tgio.delete()
                assert mock_session_post.call_args == mock.call(
                    'https://api.telegram.org/botmock_token/deleteMessage',
                    data={'chat_id': 'mock_chat_id', 'message_id': 'mock_message_id'})

# Generated at 2022-06-24 10:08:18.460978
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from time import sleep
    try:
        tqdm(total=5, disable=True)
    except:
        tqdm_telegram(total=5)
    sleep(5)


if __name__ == '__main__':
    test_tqdm_telegram_clear()

# Generated at 2022-06-24 10:08:21.023796
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tgio = TelegramIO('', '')
    tgio.write('hello')

# Generated at 2022-06-24 10:08:23.233241
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tg = TelegramIO('{token}', '{chat_id}')
    tg.write('test')
    
if __name__ == '__main__':
    test_TelegramIO_write()

# Generated at 2022-06-24 10:08:28.832822
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    """Unit tests for `tqdm.contrib.telegram.tqdm_telegram.__init__`."""
    # pylint: disable=protected-access
    # pylint: disable=protected-access,no-member
    io = tqdm_telegram(0)._instances[0]
    assert io.tgio.token == getenv('TQDM_TELEGRAM_TOKEN')
    assert io.tgio.chat_id == getenv('TQDM_TELEGRAM_CHAT_ID')
    assert io.display() is None



# Generated at 2022-06-24 10:08:34.286224
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    with tqdm_telegram(10) as t:
        t.write(str(t))


if __name__ == '__main__':
    from time import sleep
    with tqdm(total=10) as t:
        for i in range(10):
            sleep(0.100)
            t.update()

# Generated at 2022-06-24 10:08:41.302451
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    import os, sys
    try:
        if sys.version_info >= (3,0):
            os.remove('test/test_TelegramIO_delete.txt')
        else:
            os.remove('test/test_TelegramIO_delete.txt'
                if os.path.isfile('test/test_TelegramIO_delete.txt')
                else 'test/test_TelegramIO_delete.txt')
    except OSError as e:
        if e.errno != os.errno.ENOENT:
            raise

# Generated at 2022-06-24 10:08:45.596204
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    TelegramIO(token="", chat_id="")

# Generated at 2022-06-24 10:08:57.983018
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if not (token and chat_id):
        warn("Missing {token} and/or {chat_id} environment variables"
             " (see <https://github.com/tqdm/tqdm#contrib>)."
             " Skipping tests.")
    else:
        io = TelegramIO(token, chat_id)
        assert io.token == token
        assert io.chat_id == chat_id
        assert io.session
        assert io.write("test")
        assert io.delete()

# Generated at 2022-06-24 10:09:03.057548
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    """
    Tests whether it deletes the message or not.
    @return: True if the message is deleted, False if not.
    """
    token = '1389745261:AAGOpcCvEaKpjKxNk7Zf_jwvV7xsniJjjdA'
    chat_id = '435780697'
    tgio = TelegramIO(token, chat_id)
    tgio.delete()
    return True


# Generated at 2022-06-24 10:09:10.530194
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    t1 = TelegramIO('1401977053:AAH9X9Pb6gJU-2KH8dMRfVlGx6m1FV7cd_8',
                    '718040516')
    t1.write('test')
    t1._TelegramIO__del__()

if __name__ == '__main__':
    test_TelegramIO_write()

# Generated at 2022-06-24 10:09:16.897044
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from .tests_tqdm import pretest_posttest_run
    assert pretest_posttest_run(tqdm_telegram(0, 1))


if __name__ == '__main__':
    from .tests_tqdm import _test_tqdm
    _test_tqdm()

# Generated at 2022-06-24 10:09:23.611395
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    # Case 1: Leave = False
    tqdm_telegram(leave=False).close()
    # Case 2: Leave = True
    tqdm_telegram(leave=True).close()
    # Case 3: Leave = None and pos = 0
    tqdm_telegram(leave=None, pos=0).close()
    # Case 4: Leave = None and pos > 0
    tqdm_telegram(leave=None, pos=1).close()

# Generated at 2022-06-24 10:09:28.608756
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    t = tqdm_telegram(total=10, ascii=True, disable=True)
    assert t.clear().getvalue() == ''

if __name__ == '__main__':
    from doctest import testmod
    testmod()

# Generated at 2022-06-24 10:09:39.236136
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    """
    Test the method write of class TelegramIO.
    """
    import json
    import requests_mock
    with requests_mock.Mocker(real_http=True) as mock:
        def callback(request, context):
            payload = json.loads(request.body)
            context.status_code = 200
            if payload['message_id'] == 28:
                context.status_code = 400
            return context.status_code
        mock.post('https://api.telegram.org/bot{token}/editMessageText',
                  text=callback)
        tgio = TelegramIO('{token}', '{chat_id}')
        tgio.delete()
        tgio.write('..')
        tgio.close()

# Generated at 2022-06-24 10:09:47.722951
# Unit test for function trange
def test_trange():
    """Functional test of `tqdm.contrib.telegram.trange`"""
    from .utils import _supports_unicode, _range
    expected = "[" + "".join(["_ " for _ in _range(100)]) + "]"
    with ttgrange(100) as t:
        for i in t:
            pass
        assert t.unit_scale == 1
        assert t.total == 100
        assert t.smoothing == 1
        assert t.miniters == 1
        assert t.mininterval == 0
        assert t.dynamic_miniters == 0
        assert t.ascii is False
        assert t.desc == ''
        assert t.unit == 'it'
        assert t.unit_divisor == 1
        assert t.postfix == {}
        assert t

# Generated at 2022-06-24 10:09:50.185409
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    tg = TelegramIO(getenv('TQDM_TELEGRAM_TOKEN'), getenv('TQDM_TELEGRAM_CHAT_ID'))
    tg.write("Test")
    tg.close()

# Generated at 2022-06-24 10:10:00.234478
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    """Unit test for constructor of class tqdm_telegram"""
    # pylint: disable=protected-access
    # pylint: disable=unused-variable
    try:
        from unittest.mock import MagicMock, patch
    except ImportError:
        from mock import MagicMock, patch

    from ..utils import _closing
    from ..std import StringIO

    class DummyToken:
        """Dummy Telegram token"""
        def __getattr__(self, item):
            return self

        def __call__(self, *args, **kwargs):
            return self

        def __repr__(self):
            return 'foo'

    class DummyChatID:
        """Dummy Telegram chat ID"""
        def __repr__(self):
            return '1'

    token = DummyToken

# Generated at 2022-06-24 10:10:09.161636
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from io import BytesIO as StringIO
    from math import isinf
    from re import sub
    from textwrap import dedent
    from xml.dom import minidom

    from .utils_test import char_range, TestCase, pretest_lock, posttest_lock
    from .utils_test import pretest_tee, posttest_tee

    # Parameters
    py3 = (str != bytes)
    fmt = ("{l_bar:10}{bar:10}{r_bar:10} "
           "{n_fmt:10}{postfix}\n{total}{unit}")
    bar_len = len(fmt.format(l_bar='', bar='', r_bar='',
                             n_fmt='', postfix='', total='', unit=''))

# Generated at 2022-06-24 10:10:13.921088
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """
    Test if tqdm_telegram's close method is executed
    :return:
    """
    from tqdm.contrib.telegram import tqdm
    for i in tqdm(range(10), token='{token}', chat_id='{chat_id}'):
        print(i)
    return


if __name__ == '__main__':
    test_tqdm_telegram_close()

# Generated at 2022-06-24 10:10:16.523963
# Unit test for function trange
def test_trange():
    for _ in trange(10, token='{token}', chat_id='{chat_id}'):
        pass

if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 10:10:25.182745
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    """
    Class tqdm_telegram should clear bar on empty description.
    """
    from .utils_test import TEST_TOKEN, TEST_CHAT_ID
    from .utils_test import tqdm_telegram_test_bar_format

    t = tqdm_telegram_test_bar_format.tqdm(
        [], token=TEST_TOKEN, chat_id=TEST_CHAT_ID)
    assert t.tgio.text == 'tqdm_telegram_test_bar_format'
    t.write("")
    assert t.tgio.text == '...'

# Generated at 2022-06-24 10:10:28.505056
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Test trange"""
    from time import sleep
    for _ in trange(10, token=getenv('TQDM_TELEGRAM_TOKEN'),
                    chat_id=getenv('TQDM_TELEGRAM_CHAT_ID')):
        sleep(0.02)

# Generated at 2022-06-24 10:10:38.532854
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    """
    Make sure that `tqdm_telegram` can be created without errors.
    """
    t = tqdm_telegram(0, 0, disable=True)
    assert t.format_dict['bar_format'] == '{bar}'
    assert t.format_dict['format_dict'] == '{bar}'
    assert t.format_dict['bar_format_dict'] is None
    t.close()

    t = tqdm_telegram(0, 0, disable=True, ncols=0)
    assert t.format_dict['bar_format'] == '{bar}'
    assert t.format_dict['format_dict'] == '{bar}'
    assert t.format_dict['bar_format_dict'] is None
    t.close()

    t = tqdm_te

# Generated at 2022-06-24 10:10:47.787411
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    """Unit test for method display of class tqdm_telegram"""
    from ._tqdm_test_decor import _test_display, _test_display_entire

    # Test case 1
    @_test_display('{bar}', pos_limit=0)
    def test_case_1(desc=''):
        return tqdm_telegram(total=0, bar_format=desc)

    def test_case_1_success():
        """Test case 1 success"""
        import time
        from .utils_telegram import tgrange
        from .utils_test import pbar_meter, pbars_meter

        for i in tgrange(10, token='{token}', chat_id='{chat_id}'):
            time.sleep(0.1)

# Generated at 2022-06-24 10:10:52.929849
# Unit test for function trange
def test_trange():
    from time import sleep
    for i in trange(3, token=getenv('TQDM_TELEGRAM_TOKEN'),
                    chat_id=getenv('TQDM_TELEGRAM_CHAT_ID')):
        sleep(.5)

# Generated at 2022-06-24 10:10:59.169049
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    from os import environ
    TelegramIO(environ.get("TQDM_TELEGRAM_TOKEN"),
               environ.get("TQDM_TELEGRAM_CHAT_ID"))

# Generated at 2022-06-24 10:11:01.657125
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tgio = TelegramIO("asd123", "asd123")
    tgio.write("Hello World!")


# Generated at 2022-06-24 10:11:08.976631
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from collections import namedtuple
    from .utils_test import _io_wrapper
    TestArgs = namedtuple('TestArgs', ('total', 'pos', 'desc', 'leave'))
    TestFmt = namedtuple('TestFmt', ('bar_format', 'bar_length',
                                     'postfix_str'))

    # Instantiation
    tg = TelegramIO(token='token', chat_id='chat_id')
    tg._message_id = 12345

    # Test actual display
    tg.write('test')

    # Test default bar formats
    ta = TestArgs(total=100, pos=10, desc='test', leave=False)

# Generated at 2022-06-24 10:11:10.936803
# Unit test for function trange
def test_trange():
    """Test function `trange`"""
    from tqdm.auto import trange
    assert ttgrange is trange

# Generated at 2022-06-24 10:11:13.397482
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(_range(1))
    t.close()
    t = tqdm_telegram(_range(0))
    t.close()

# Generated at 2022-06-24 10:11:20.484093
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """
    Test close method of class tqdm_telegram for successful and unsuccessful
    connect to Telegram API
    """
    def test_success_connect():
        """
        Create an instance of tqdm_telegram with successful connection to
        Telegram API.
        """
        tt = tqdm_telegram(token='{token}', chat_id='{chat_id}')
        tt.close()

    def test_unsuccessful_connect():
        """
        Create an instance of tqdm_telegram with unsuccessful connection to
        Telegram API.
        """
        tt = tqdm_telegram(token='NonExistingToken', chat_id='12345')
        tt.close()

# Generated at 2022-06-24 10:11:25.767468
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    with tqdm_telegram(total=10, token=token, chat_id=chat_id) as pbar:
        for i in pbar:
            pass

# Generated at 2022-06-24 10:11:30.468375
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    for _ in tqdm_telegram(range(100), total=100,
                           token='1276059532:AAF6Ak8QFwI_6gZLvnMgpS6bZjxBn-pTzdk',
                           chat_id='@tqdmit'):
        pass

# Generated at 2022-06-24 10:11:34.816316
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    n = 100
    t = tqdm_telegram(total=n, desc='testing', mininterval=0)
    for i in t:
        assert t.total == n
        assert i <= n
        assert t.dynamic_messages
        assert t.n != 0
        break
    t.close()

# Generated at 2022-06-24 10:11:48.070341
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    '''
    >>> from tqdm import tqdm
    >>> pbar = tqdm(total=2, desc='long desc', bar_format='{desc} {bar}',
    ...             disable=False)
    long desc :   0%|                                                          | 0/2 [00:00<?, ?it/s]
    >>> assert pbar.format_dict['desc'] == 'long desc '
    >>> assert not pbar.format_dict['bar_format'].startswith('{desc}')
    >>> pbar.update(1)
    >>> assert pbar.format_dict['bar_format'].startswith('{desc}')
    >>> pbar.close()
    '''
    from tqdm import tqdm
    from tqdm._tqdm_gui import tqdm_gui
   