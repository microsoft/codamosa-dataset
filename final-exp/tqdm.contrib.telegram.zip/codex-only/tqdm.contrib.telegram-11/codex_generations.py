

# Generated at 2022-06-24 10:02:04.968129
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    import types
    import warnings
    with warnings.catch_warnings():
        warnings.filterwarnings('error')
        try:
            tg = TelegramIO('', '')
        except TqdmWarning:
            pass
        else:
            raise TypeError('Should have raised a warning')
    tg = TelegramIO('test', 'test')
    assert tg.token == 'test'
    assert tg.chat_id == 'test'
    assert tg.text == 'test'
    assert tg.session.__class__.__name__ == 'Session'
    assert tg.message_id is None
    assert isinstance(tg.write, types.MethodType)
    assert isinstance(tg.delete, types.MethodType)

# Generated at 2022-06-24 10:02:16.883603
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    '''
    Test function for tqdm.contrib.telegram.TelegramIO

    Checks if constructor of TelegramIO class working properly
    '''
    __author__ = {"github.com/": ["casperdcl"]}
    from os import getenv
    from warnings import warn
    from requests import Session
    from tqdm.contrib.telegram import TelegramIO, tqdm_telegram
    from tqdm.auto import tqdm
    from tqdm.utils import _range
    from tqdm.utils import _range
    from unittest import TestCase

    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    assert token is not None and chat_id is not None

# Generated at 2022-06-24 10:02:20.481005
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    test = TelegramIO("", "")
    assert test.write("") is None
    assert test.write("test") is None
    assert test.write("test") is None
    assert test.write("test") is None


# Unit tests for class tqdm_telegram

# Generated at 2022-06-24 10:02:29.535601
# Unit test for function trange
def test_trange():
    """Unit test for trange"""
    trange(10, desc="trange", token=getenv('TQDM_TELEGRAM_TOKEN'),
           chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'), disable=False,
           ascii=True, unit="it", unit_scale=False, unit_divisor=1000)
    tqdm(range(10), desc="tqdm", token=getenv('TQDM_TELEGRAM_TOKEN'),
         chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'), disable=False,
         ascii=True, unit="it", unit_scale=False, unit_divisor=1000)

# Generated at 2022-06-24 10:02:36.666413
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    """Unit test for method write of class TelegramIO"""
    class test:
        def __init__(self, response_json, exception=None):
            self.response_json = response_json
            self.exception = exception

    def post(url, data):
        """
        - When there is no exception, returns {"ok": True, "result": {"message_id": 1305}}
        - When telegram reports rate limit error, returns {"ok": False, "error_code": 429}
        - When telegram reports a more unexpected error, raises an exception
        """
        if test_object.exception:
            raise test_object.exception
        else:
            return test_object

    test_object = test({"ok": True, "result": {"message_id": 1305}})

# Generated at 2022-06-24 10:02:45.371951
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    t = tqdm_telegram(
        token='', chat_id='', disable=True,
        desc='test', ncols=10, mininterval=0.1, positional_args=1,
        total=10, unit='it', unit_scale=False, unit_divisor=1.0,
        dynamic_ncols=True, smoothing=0., bar_format=None, initial=0,
        position=0, leave=False, miniters=0, ascii=False,
        disable_tqdm=False, **{})
    t.update(5)
    assert(
        t.display(width=10) ==
        'test    50%|######   | 5/10 [00:00<00:00, ?it/s]')
    t.total = None

# Generated at 2022-06-24 10:02:48.333191
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    """Unit test."""
    print('Unit test TelegramIO.write')
    tg = TelegramIO('', '')
    tg.write('Unit test')

# Generated at 2022-06-24 10:02:52.604411
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    io = TelegramIO('token', 'chat_id')
    io.write('')
    io.write('hello')
    io.write('hello')
    io.write('')
    io.write('hi')
    io.write('')


# Generated at 2022-06-24 10:02:58.305325
# Unit test for function trange
def test_trange():
    from tests_tqdm import with_setup, pretest, posttest, _decode, _range, \
        closing, StringIO, sys
    with closing(StringIO()) as our_file:
        with with_setup(pretest, posttest):
            for _ in trange(10, file=our_file, token='{token}',
                            chat_id='{chat_id}'):
                pass

# Generated at 2022-06-24 10:03:07.903461
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    teleg = TelegramIO('1234', '5678')

    assert teleg.write('hey') == None

    try:
        teleg.write('coucou')
        assert True
    except Exception as e:
        assert False

    try:
        teleg.write('coucou')
        assert True
    except Exception as e:
        assert False

    try:
        teleg.write('coucou')
        assert True
    except Exception as e:
        assert False

    try:
        teleg.write('')
        assert True
    except Exception as e:
        assert False



# Generated at 2022-06-24 10:03:14.771430
# Unit test for function trange
def test_trange():
    tqdm.write = tqdm.write_ = lambda x, **kw: tqdm._instances.get(
        id(tqdm._instances), tqdm).write(x, **kw)
    assert trange(5, 10) == list(range(5, 10))
    tqdm.write('test_trange')
    tqdm._instances.get(id(tqdm._instances), tqdm).close()
    assert not tqdm._instances



# Generated at 2022-06-24 10:03:23.687897
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():

    # This is just a unit test which only tests the new functionality of
    # the method display of the class tqdm_telegram, the rest is tested
    # in the main tqdm package.

    # Set the following enviroment variables to your Telegram Token and
    # Chat ID respectively to test the Telegram updating functionality.
    # TQDM_TELEGRAM_TOKEN: your Telegram bot Token
    # TQDM_TELEGRAM_CHAT_ID: your Telegram chat ID

    # Check if the environment variables are set
    if 'TQDM_TELEGRAM_TOKEN' not in getenv('TQDM_TELEGRAM_TOKEN'):
        print('TQDM_TELEGRAM_TOKEN not set, skipping test')
        return

# Generated at 2022-06-24 10:03:25.467084
# Unit test for function trange
def test_trange():
    """Unit test"""
    from .utils import _test_telegram_function
    _test_telegram_function(trange)

# Generated at 2022-06-24 10:03:27.996798
# Unit test for function trange
def test_trange():
    from time import sleep

    rng = trange(10, token='{token}', chat_id='{chat_id}')
    for _ in rng:
        sleep(1)

# Generated at 2022-06-24 10:03:34.426807
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    try:
        from unittest import mock
    except ImportError:
        from unittest.mock import mock

    session = mock.Mock()
    session.post.return_value.json.return_value = {'ok': True}

    token = '0123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZabcefghi'
    chat_id = '123456789'
    message_id = '987654321'

    class Response(object):
        def __init__(self):
            self.status_code = 200

    io = TelegramIO(token, chat_id)
    io.session = session
    io.message_id = message_id

    assert io.delete()

    assert session.post.called

# Generated at 2022-06-24 10:03:40.809780
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from os import getenv
    from unittest import main, TestCase
    from time import sleep
    from requests import Session

    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    auth = {'token': token, 'chat_id': chat_id}
    session = Session()

    class Test(TestCase):
        def setUp(self):
            self.tgio = TelegramIO(**auth)
        def tearDown(self):
            self.tgio.delete()
            self.tgio.close()
            sleep(1)
        def test_delete(self):
            msg = self.tgio.message_id
            self.tgio.delete()

# Generated at 2022-06-24 10:03:46.025244
# Unit test for function trange
def test_trange():  # pragma: no cover
    try:
        from astropy.tests.helper import pytest  # noqa
    except Exception:
        from pytest import importorskip  # noqa
        importorskip('astropy')
    pytest.main([__file__, '-v'])

if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 10:03:53.034964
# Unit test for function trange
def test_trange():
    """Tests that `trange` is a `TelegramIO` progressbar that
    automatically updates when done."""
    from ..auto import tqdm as tqdm_auto
    import sys
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    assert token and chat_id, "Please set TQDM_TELEGRAM_TOKEN & " \
        "TQDM_TELEGRAM_CHAT_ID environment variables " \
        "in order to test the Telegram integration."
    with trange(10, token=token, chat_id=chat_id) as t:
        assert isinstance(t, tqdm_telegram)

# Generated at 2022-06-24 10:03:56.777140
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from tqdm import tqdm

    for leave in [True, False]:
        pbar = tqdm_telegram(total=100, leave=leave)
        pbar.close()

# Generated at 2022-06-24 10:03:59.702233
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    with tqdm_telegram(total=100, token='{token}', chat_id='{chat_id}') as pbar:
        for i in _range(100):
            pbar.update()

# Generated at 2022-06-24 10:04:06.559374
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    try:
        for i in tqdm(
                iterable=_range(5),
                token='1075267807:AAGZ6WGgfE9XNlA7RbY2iNsh-gw1E-xKSUs',
                chat_id='722753339',
                mininterval=1):
            time.sleep(2)
    except Exception as e:
        # todo: It will raise the exception, but it doesn't affect the test.
        # tqdm_auto.write(str(e))
        return False
    return True

# Generated at 2022-06-24 10:04:08.896754
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from ..tests import examples
    list(tqdm_telegram(examples.sleeps(), ncols=80))


if __name__ == '__main__':
    test_tqdm_telegram()

# Generated at 2022-06-24 10:04:14.421660
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    # token and chat_id should be changed to valid one before running the test
    tgi = TelegramIO("0:0", "-1")


if __name__ == "__main__":
    test_TelegramIO()

# Generated at 2022-06-24 10:04:19.541403
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    TOKEN = getenv('TQDM_TELEGRAM_TOKEN')
    CHAT_ID = getenv('TQDM_TELEGRAM_CHAT_ID')
    if not TOKEN or not CHAT_ID:
        return
    tqdm_auto.write(__doc__)

# Generated at 2022-06-24 10:04:20.441684
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from .tests import test_clear

    test_clear(tqdm_telegram)

del absolute_import, getenv

# Generated at 2022-06-24 10:04:27.930036
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    class dummy_tqdm_telegram(tqdm_telegram):
        def __init__(self, *args, **kwargs):
            super(dummy_tqdm_telegram, self).__init__(*args, **kwargs)
            self.format_meter = lambda **fmt: ''.join(
                str(fmt.get(i)) for i in sorted(fmt))

    # with mininterval == 0
    t0 = dummy_tqdm_telegram(10, miniters=1, mininterval=0)
    assert t0.display() == '0000|00000    |'
    assert t0.display(pos=5) == '0000|50000    |'

# Generated at 2022-06-24 10:04:37.762651
# Unit test for function trange
def test_trange():
    from random import random
    from time import sleep

    with trange(10, token='270424747:AAEJzYgYC_yA-k8XNPqpJnKMfCuf7VSOJqM',
                chat_id='-1001168952854') as t:
        for i in t:
            t.set_description("Gen {}".format(i))
            t.set_postfix(i=i, loss=random())
            sleep(.1)



# Generated at 2022-06-24 10:04:42.963053
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    try:
        token = getenv('TQDM_TELEGRAM_TOKEN')
        chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    except Exception:
        pass
    else:
        if token and chat_id:
            try:
                tg = TelegramIO(token, chat_id)
                tg.delete()
                print('Unit test passed.')
            except Exception as e:
                print(e)
    print('Unit test failed.')

# Generated at 2022-06-24 10:04:45.790762
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    tgio = TelegramIO(token, chat_id)
    tgio.write("test_TelegramIO_write")



# Generated at 2022-06-24 10:04:52.030822
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import unittest

    class TestTqdmDisplay(unittest.TestCase):
        def test_display(self):
            # Set up
            tgr = tqdm(total=10)
            # Test
            tgr.update(4)
            tgr.display(bar_format='{percentage:3.0f}%')
            # Assert
            self.assertEqual(tgr.format_dict['bar_format'], '{l_bar}{bar:10u}{r_bar}')
            # Clean up
            tgr.close()

    unittest.main()


# Generated at 2022-06-24 10:04:57.342359
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import pytest, tempfile, tqdm
    with tempfile.NamedTemporaryFile() as fp:
        tqdm.write(fp.name, 'test')
        with open(fp.name, 'r') as fp_2:
            assert fp_2.read().strip() == 'test'

test_TelegramIO_write()

# Generated at 2022-06-24 10:04:59.553206
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    tg = TelegramIO(token='a', chat_id='b')
    tg.__del__()

# Generated at 2022-06-24 10:05:00.815793
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    print(TelegramIO('bot_token', 'chat_id'))

# Generated at 2022-06-24 10:05:10.235363
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from .utils_test import closing
    from .utils_test import closing_thread
    from .utils_test import closing_subprocess

    with closing(tqdm_telegram(total=4)) as t:
        for i in range(4):
            t.update()
            t.close()  # Can be closed multiple times

    with closing_subprocess(tqdm_telegram(total=4)) as t:
        for i in range(4):
            t.update()
            t.close()  # Can be closed multiple times

    with closing_thread(tqdm_telegram(total=4)) as t:
        for i in range(4):
            t.update()
            t.close()  # Can be closed multiple times



# Generated at 2022-06-24 10:05:16.245522
# Unit test for function trange
def test_trange():
    from .utils import _term_move_up
    for _ in ttgrange(2):
        tqdm.write('Foo')
        for _ in ttgrange(3, desc='Bar', leave=False, unit='Baz'):
            tqdm.write('Baz')
            _term_move_up()
        _term_move_up()

# Generated at 2022-06-24 10:05:26.814500
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    import time
    from os import environ as env
    from os import kill
    from sys import executable as python
    from signal import SIGINT

    t = TelegramIO(env['TQDM_TELEGRAM_TOKEN'], env['TQDM_TELEGRAM_CHAT_ID'])
    t.submit(t.session.post, t.API + '%s/sendMessage' % t.token,
             data={'text': '`' + t.__class__.__name__ + '`', 'chat_id': t.chat_id,
                   'parse_mode': 'MarkdownV2'})

# Generated at 2022-06-24 10:05:33.803904
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if token is None or chat_id is None:
        exit("TQDM_TELEGRAM_TOKEN or TQDM_TELEGRAM_CHAT_ID not set:"
             " please set the variables in the environment.")

    io = TelegramIO(token, chat_id)
    io.write("Test Message")

if __name__ == '__main__':
    test_TelegramIO_write()

# Generated at 2022-06-24 10:05:38.842148
# Unit test for function trange
def test_trange():
    """Unit test for tqdm_telegram.trange"""
    from time import sleep
    with trange(3, token=None, chat_id=None) as t:
        for i in t:  # thanks to __enter__, `t` is set as default
            sleep(.2)

# Generated at 2022-06-24 10:05:44.080480
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    message_id = 1
    token = 'test_token'
    chat_id = 1000
    tq = tqdm_telegram(total=10, disable=False, leave=False, message_id=message_id, token=token, chat_id=chat_id)
    tq.close()
    assert tq.tgio.message_id is None

# Generated at 2022-06-24 10:05:54.052923
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from sys import version_info
    from .utils import free_port
    from .utils import FakeTelegramIO

    if version_info < (3, 0):
        from io import BytesIO as StringIO
    else:
        from io import StringIO
    import time
    import socket

    timeout = 2
    port = free_port()
    tgio = FakeTelegramIO(port)
    tgio.start()

# Generated at 2022-06-24 10:06:02.472853
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from requests_mock import Mocker
    from nose.tools import assert_equal, assert_in, assert_is_not_none
    with Mocker() as m:
        m.post('https://api.telegram.org/bot123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11/sendMessage', json={'ok': True, 'result': {'message_id': 123456789}})
        m.post('https://api.telegram.org/bot123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11/editMessageText', json={'ok': True})

# Generated at 2022-06-24 10:06:05.108859
# Unit test for function trange
def test_trange():
    with tqdm(total=2) as pbar:
        _ = [i**2 for i in trange(3)]
        pbar.update()
        _ = [i**2 for i in trange(3)]

# Generated at 2022-06-24 10:06:08.680083
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    io = TelegramIO(token=getenv('TQDM_TELEGRAM_TOKEN'),
                    chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'))
    assert io.message_id is not None
    m = io.write('test')
    assert m is not None



# Generated at 2022-06-24 10:06:15.204619
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    """Unit test for constructor of class tqdm_telegram"""
    for _token in [None, '{token}']:
        for _chat_id in [None, '{chat_id}']:
            t = tqdm_telegram(total=100, disable=True, token=_token, chat_id=_chat_id)
            assert t.disable
            t = tqdm_telegram(total=100, token=_token, chat_id=_chat_id)
            if _token and _chat_id:
                assert not t.disable
            else:
                assert t.disable

if __name__ == '__main__':
    from doctest import testmod
    testmod(verbose=True)

# Generated at 2022-06-24 10:06:20.684680
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    class TestTqdm(tqdm_telegram):
        def close(self):
            super(TestTqdm, self).close()
            self.leave = True
            self._closed = True

        def check(self):
            return self._closed

    t = TestTqdm()
    assert (not t.check())
    t.close()
    assert (t.check())

# Generated at 2022-06-24 10:06:26.214658
# Unit test for function trange
def test_trange():
    import sys
    import shutil
    try:
        for i in trange(4, token='', chat_id=''):
            pass
    except Exception as e:
        assert e.args == ("Missing {token} and {chat_id}",)
    else:
        raise AssertionError("Missing {token} and {chat_id}")

    # with open("test_file", "w") as f:
    with tqdm(total=4, file=sys.stdout, ncols=shutil.get_terminal_size()[0])\
            as pbar:
        for i in trange(4, token='', chat_id='', leave=False, file=pbar):
            pbar.set_description("test %i" % i)
            pbar.update()
    # os.remove("

# Generated at 2022-06-24 10:06:29.595457
# Unit test for function trange
def test_trange():
    """Unit test for function trange."""
    from nose.tools import assert_equal

    for _ in trange(1, token='{token}', chat_id='{chat_id}'):
        assert_equal(True, True)

# Generated at 2022-06-24 10:06:31.401316
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from .telegram_test import test_tqdm_telegram_clear
    test_tqdm_telegram_clear()

# Generated at 2022-06-24 10:06:37.989571
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    import time
    import random
    import os
    import requests
    import requests_mock
    from nose.tools import raises

    token = "TOKEN"
    chat_id = "CHATID"
    telegram_url = "%s%s/%s" % (TelegramIO.API, token, "sendMessage")

    # test no token provided
    with raises(KeyError):
        for i in tqdm(range(10000), total=10000, mininterval=0.0):
            time.sleep(0.002089)
    with raises(KeyError):
        for i in tqdm(range(10000), total=10000, mininterval=0.0,
                      token=token):
            time.sleep(0.002089)
    # test no chat id provided

# Generated at 2022-06-24 10:06:39.736115
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .utils import _test_display
    _test_display(tqdm_telegram)

# Generated at 2022-06-24 10:06:42.888397
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    # from .test_tqdm import pretest, posttest
    # pretest()
    t = TelegramIO(token='', chat_id='')
    # posttest()
    del t

# Generated at 2022-06-24 10:06:48.813044
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from io import StringIO
    from requests import Session
    from json import dumps
    from tqdm.contrib.telegram import tqdm_telegram, TelegramIO

    token = 'token'
    chat_id = 'chat_id'
    msg_id = 'msg_id'
    expected_body = dumps(
        {'text': '`' + '...' + '`', 'chat_id': chat_id, 'message_id': msg_id,
        'parse_mode': 'MarkdownV2'})

    mock_session = Session()

    class MockResponse:
        data = {}
        status_code = 200
        def json(self): return self.data


# Generated at 2022-06-24 10:06:52.667602
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from mock import patch
    from io import StringIO

    f = StringIO()

    with patch('sys.stderr', f):
        example = tqdm_telegram(range(10), desc='Testing', ncols=50)
        example.display()

    example.close()



# Generated at 2022-06-24 10:07:02.808467
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from unittest import TestCase
    from io import StringIO
    class Test(TestCase):
        def test(self):
            with tqdm_telegram(
                disable=True, postfix=False, dynamic_ncols=True
            ) as t:
                with StringIO() as s:
                    t.file = s
                    t.display()
                    t.display_dict['total'] = 10
                    t.display_dict['pos'] = 5
                    t.display_dict['desc'] = 'description'
                    t.display()
                    t.display_dict['total'] = None
                    t.display()
                    t.display_dict['bar_format'] = '{desc}: {bar}'
                    t.display()
                    t.file.seek(0)
                    actual = t.file.read()

# Generated at 2022-06-24 10:07:06.287541
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tg = TelegramIO(
        kwargs.pop('token', getenv('TQDM_TELEGRAM_TOKEN')),
        kwargs.pop('chat_id', getenv('TQDM_TELEGRAM_CHAT_ID')))
    tg.delete()

# Generated at 2022-06-24 10:07:11.986811
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    class TestTelegramIO(TelegramIO):
        def __init__(self, *args, **kwargs):
            self.exception = False
            super(TestTelegramIO, self).__init__(*args, **kwargs)

        def submit(self, func, *args, **kwargs):
            try:
                func(*args, **kwargs)
            except Exception:
                self.exception = True

    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    token = getenv('TQDM_TELEGRAM_TOKEN')
    # create a test message
    data = {'text': 'test', 'chat_id': chat_id, 'parse_mode': 'MarkdownV2'}

# Generated at 2022-06-24 10:07:18.054867
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    telegram = tqdm_telegram(iter(range(3)), token='', chat_id='')
    telegram.close()
    assert telegram.close() is None

# Generated at 2022-06-24 10:07:29.135898
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    t = tqdm_telegram(3)
    t.display()
    assert t.tgio.text == '...'
    t.update(1)
    t.display()
    assert t.tgio.text == '|#                  | 25%'
    t.update(1)
    t.display()
    assert t.tgio.text == '|##                 | 50%'
    t.update(1)
    t.display()
    assert t.tgio.text == '|###                | 75%'
    t.update(1)
    t.display()
    assert t.tgio.text == '|###                | 100%'

# Generated at 2022-06-24 10:07:35.476485
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import time, datetime, itertools

    # this test verifies that a progressbar which is cleared (pbar.clear())
    # doesn't raise an exception on close

    socks_list = [12, 21, 43, 34]
    while True:
        tpbar = tqdm_telegram(total=len(socks_list), leave=False)
        for sock in socks_list:
            tpbar.update()
            time.sleep(0.5)

        time.sleep(0.5)
        tpbar.clear()
        tpbar.close()

        time.sleep(2.0)



# Generated at 2022-06-24 10:07:37.530307
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm("")
    t.close()
    assert t.tgio.message_id
    t.close()


# Generated at 2022-06-24 10:07:39.696505
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(range(1))
    t.close()
    assert t.n == 0

# Generated at 2022-06-24 10:07:42.778155
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import sys
    import time
    ttgrange(10, token=sys.argv[1])


if __name__ == "__main__":
    test_TelegramIO_write()

# Generated at 2022-06-24 10:07:46.526829
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    for leave in [True, False, None]:
        with tqdm(total=1, leave=leave) as t:
            t.update(1)
            assert t.n == 1
            t.close()
            assert t.n == 1

# Generated at 2022-06-24 10:07:55.989954
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    # TelegramIO tests.
    import os
    tio1 = TelegramIO(os.getenv('TQDM_TELEGRAM_TOKEN'),
                      os.getenv('TQDM_TELEGRAM_CHAT_ID'))
    tio1.write("")
    tio1.write("")
    tio1.write("")
    tio1.write("")
    tio2 = tio1.__class__(tio1.token, tio1.chat_id)
    tio2.write("")
    tio2.write("")
    tio2.write("")
    tio2.write("")
    tio2.write("")
    tio2.write("")
    tio2.write("")

# Generated at 2022-06-24 10:07:58.973748
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    try:
        import requests
        _test_TelegramIO_write()
    except ImportError:
        pass



# Generated at 2022-06-24 10:08:05.130416
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from .tests_tqdm import funcs
    for func in funcs:
        try:
            with tqdm_telegram(**func()) as t:
                t.clear()
        except (OSError, IOError) as e:
            tqdm_auto.write("Caught %s." % e)

# Generated at 2022-06-24 10:08:12.308964
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange.
    """
    from os import unsetenv
    token = getenv('TQDM_TELEGRAM_TOKEN')  # nosec
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')  # nosec
    if token is None or chat_id is None:
        return
    unsetenv('TQDM_TELEGRAM_TOKEN')
    unsetenv('TQDM_TELEGRAM_CHAT_ID')
    assert trange(10, token=token, chat_id=chat_id)

# Generated at 2022-06-24 10:08:19.929250
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    import re
    io = io=TelegramIO("123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghiJ", "123456789")
    assert re.search(r"\d{9}:\w{35}", io.token), "Expected token to be a string"
    assert re.search(r"\d{9}", io.chat_id), "Expected chat_id to be a string of numbers"
    assert type(io.message_id) == int, "Expected message_id to be an integer"

test_tqdm_telegram()

# Generated at 2022-06-24 10:08:22.505383
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    t = tqdm_telegram(token='{token}', chat_id='{chat_id}',
                      total=100, disable=True)
    t.display()
    assert True

# Generated at 2022-06-24 10:08:30.353974
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import pytest
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    telegramIO = TelegramIO(token, chat_id)
    with pytest.raises(AttributeError):
        telegramIO._message_id

# Generated at 2022-06-24 10:08:34.065974
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    token = getenv('TQDM_TEST_TOKEN')
    chat_id = getenv('TQDM_TEST_CHAT_ID')
    TelegramIO(token, chat_id)
    TelegramIO(token, chat_id).write('test')

# Generated at 2022-06-24 10:08:36.398187
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    io = TelegramIO("", "")
    io.text = "test"
    io.close()
    assert hasattr(io, '_message_id') is False

# Generated at 2022-06-24 10:08:38.150218
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    io = TelegramIO('', '', disable=True)
    io.write('\n')
    assert io.text == '\n'



# Generated at 2022-06-24 10:08:45.675793
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    """Unit test for constructor of class TelegramIO."""
    # pylint: disable=protected-access
    # pylint: disable=import-outside-toplevel
    from ..std import _term_move_up
    class _IO(TelegramIO):
        def __init__(self, token, chat_id):
            super(_IO, self).__init__(token, chat_id)
            self._message_id = 888
            self._write_calls = []

        def write(self, s):
            self._write_calls.append(s)

        def __enter__(self):
            return self

        def __exit__(self, *args):
            del self._write_calls
            del self.text


# Generated at 2022-06-24 10:08:50.613108
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    io = TelegramIO('token', 'chat_id')
    io.write('text')

# Generated at 2022-06-24 10:08:52.729855
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    TelegramIO("123", "123")
    TelegramIO(token="123", chat_id="123")

# Generated at 2022-06-24 10:08:55.751864
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    """test_TelegramIO_delete()"""
    from os import getenv
    tg = TelegramIO(getenv('TQDM_TELEGRAM_TOKEN'), getenv('TQDM_TELEGRAM_CHAT_ID'))
    tg.write("this should create a message")
    assert tg.message_id is not None
    tg.delete()

# Generated at 2022-06-24 10:09:04.112473
# Unit test for function trange
def test_trange():

    # file-like object
    try:
        from cStringIO import StringIO
    except ImportError:
        from io import StringIO as cStringIO
    import sys
    with tqdm(total=7, bar_format='{n}/{total}') as pbar:
        pbar.update(1)
        old_stdout = sys.stdout
        try:
            sys.stdout = StringIO()
            for i in tgrange(4):
                pbar.update()
                pbar.write('testing')
            sys.stdout = old_stdout
        finally:
            sys.stdout = old_stdout

    # real
    import time

# Generated at 2022-06-24 10:09:04.688485
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    return None

# Generated at 2022-06-24 10:09:13.138285
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import re
    from subprocess import Popen, PIPE
    from time import sleep

    def _test_telegram_write(token, chat_id, method='POST', timeout=3,
                             expect_http_code=200, verbose=0):
        # construct a `tqdm` instance
        tqdmi = tqdm_telegram(
            [1.1],
            refresh=0,
            token=token,
            chat_id=chat_id,
            bar_format='{bar}',
            mininterval=0.05,
            miniters=1,
            leave=True,
            unit='B',
            initial=0,
            postfix={'B': 1.1},
            file=None
        )

        # construct a `requests` instance
        reqsi = Session()

# Generated at 2022-06-24 10:09:18.635417
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    class TelegramIO_write(TelegramIO):
        def write(self, s):
            self.text = s
    li = TelegramIO_write('fake_token', 'fake_chat_id')
    assert(li.text == li.__class__.__name__)
    li.write('new_text')
    assert(li.text == 'new_text')

# Generated at 2022-06-24 10:09:20.107832
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    assert TelegramIO('token', 'chat_id').message_id is None

# Generated at 2022-06-24 10:09:26.854045
# Unit test for function trange
def test_trange():
    """Test tqdm.trange() robustness."""
    assert list(tqdm([])) == []
    assert list(tqdm(iter([]))) == []
    assert list(tqdm(iter(list()))) == []
    assert list(tqdm(iter(tuple()))) == []
    assert list(tqdm(iter(x for x in []))) == []
    assert list(tqdm(iter(()))) == []
    assert list(tqdm(iter(x for x in ()))) == []


# Generated at 2022-06-24 10:09:33.325573
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    try:
        for obj in [tqdm_telegram(), tqdm(), trange()]:
            assert not obj.disable
            assert isinstance(obj.tgio, TelegramIO)
    except:
        raise Exception()
    finally:
        tqdm_telegram.close()

# Generated at 2022-06-24 10:09:42.305231
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    import requests_mock
    with requests_mock.Mocker() as mock:
        mock.post(TelegramIO.API + '{token}/sendMessage',
                  json={'result': {'message_id': '{message_id}'}})
        # token=None
        TelegramIO(None, '{chat_id}')
        # chat_id=None
        TelegramIO('{token}', None)
        # chat_id=None, token=None
        TelegramIO(None, None)
        # token=None, chat_id=None
        TelegramIO(None, None)
        # token=..., chat_id=...
        TelegramIO('{token}', '{chat_id}')

# Generated at 2022-06-24 10:09:45.070272
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from ._tqdm_telegram_test import _test_tqdm_telegram_clear
    _test_tqdm_telegram_clear()

# Generated at 2022-06-24 10:09:49.459320
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    pass


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-24 10:09:52.926817
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    tqdm(total=10, token=getenv('TQDM_TELEGRAM_TOKEN'), chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'))

test_tqdm_telegram()

# Generated at 2022-06-24 10:09:55.213854
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    assert TelegramIO(
        getenv('TQDM_TELEGRAM_TOKEN'), getenv('TQDM_TELEGRAM_CHAT_ID')
    ).delete() == None

# Generated at 2022-06-24 10:09:59.680508
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    """
    Check if the Telegram message is created,
    with the correct text and without formatting (bold in the example).
    """
    tgio = TelegramIO('{token}', '{chat_id}')
    tgio.write('***Telegram_message***')



# Generated at 2022-06-24 10:10:04.474165
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from warnings import catch_warnings
    import sys

    with \
        catch_warnings(record=True), \
        tqdm_telegram(total=0, leave=False, mininterval=0, file=sys.stdout) \
            as pbar:
        pbar.write('foo')
    assert not hasattr(pbar, '_message_id')

# Generated at 2022-06-24 10:10:08.835733
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    tgio = TelegramIO(token, chat_id)
    tgio.submit(tgio.delete)()
    assert getattr(tgio, '_message_id', None) is None

# Generated at 2022-06-24 10:10:12.714812
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    token = {token}
    chat_id = {chat_id}
    tgio = TelegramIO(token, chat_id)
    res = tgio.delete()
    assert tgio.message_id is None

if __name__ == "__main__":
    test_TelegramIO_delete()

# Generated at 2022-06-24 10:10:16.691202
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    text = "text"
    t = tqdm_telegram(total=100, unit_scale=True, unit='iB')
    t.write = lambda x: (setattr(t, 'text', x))
    t.clear(text)
    assert t.text == text
    t.close()

# Generated at 2022-06-24 10:10:26.946606
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tgio = TelegramIO('12345:abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ',
                      '1234567890123456789')
    assert tgio.write('hello') is None
    assert tgio.message_id is None
    tgio = TelegramIO('12345:abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ',
                      '1234567890123456789')
    assert tgio.message_id == None  # noqa
    assert tgio.write('hello') is None


if __name__ == "__main__":
    test_TelegramIO_write()

# Generated at 2022-06-24 10:10:31.443556
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    with tqdm(total=3) as pbar:
        pbar.update(1)
    assert pbar.n == 1

# Generated at 2022-06-24 10:10:34.718831
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    try:
        _ = tqdm_telegram(token='', chat_id='', ascii=True).start()
    except KeyError:
        pass

# Generated at 2022-06-24 10:10:40.949226
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    print("Sending a message to chat_id={} ...".format(chat_id))
    io = TelegramIO(token=token, chat_id=chat_id)
    io.write("This is a test message from tqdm.\n"
             "If it appears in your chat, unit test passed.")
    io.delete()
    io.close()

if __name__ == '__main__':
    test_TelegramIO_delete()

# Generated at 2022-06-24 10:10:44.789602
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(range(10), disable=True)
    assert t.disable is True
    t.close()

    t = tqdm_telegram(range(10), disable=False)
    assert t.disable is False
    t.close()

# Generated at 2022-06-24 10:10:52.898053
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from .utils_test import _imap_ids
    from .tests_main import tests
    _, _, close, token, chat_id, chat_id_test = _imap_ids()
    with tests.lock:
        tests.globals.update(locals())
    tqdm.write(str(TelegramIO(token, chat_id_test).write("hello") or
                    TelegramIO(token, chat_id).write("hello")))
    close()

# Generated at 2022-06-24 10:10:57.725725
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from .tests_telegram import test_tqdm_telegram
    test_tqdm_telegram(tqdm_telegram)

# Generated at 2022-06-24 10:11:07.434585
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    tgio_mock = TelegramIO('token', 'chat_id')
    tgio_mock.message_id = 'message_id'
    tgio_mock.session.post = lambda url, data: {}
    tgio_mock.tgio = tgio_mock
    with tqdm_telegram(disable=True) as t:
        t.close()
        t.tgio = tgio_mock
        t.close()
        t.tgio = tgio_mock
        t.leave = None
        t.close()
        t.tgio = tgio_mock
        t.leave = False
        t.pos = 0
        t.close()
        t.tgio = tgio_mock
        t.leave = False
        t.pos

# Generated at 2022-06-24 10:11:12.177157
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    with tqdm_telegram(total=5, unit='A', unit_scale=True, ascii=True) as pbar:
        for i in range(5):
            pbar.update()
            time.sleep(0.5)

if __name__ == '__main__':
    test_tqdm_telegram()

# Generated at 2022-06-24 10:11:22.035714
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tg = TelegramIO(getenv('TQDM_TELEGRAM_TOKEN'),
                    getenv('TQDM_TELEGRAM_CHAT_ID'))
    tg.write('test')
    tg.delete()

# Generated at 2022-06-24 10:11:26.054811
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tgio = TelegramIO('123456789:abcdefghijklmnopqrstuvwxyz', 0)
    tgio.write("message")
    tgio.delete()

# Generated at 2022-06-24 10:11:30.205095
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    from os import getenv
    t = TelegramIO(token=getenv('TQDM_TELEGRAM_TOKEN'),
                   chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'))


# Generated at 2022-06-24 10:11:35.332790
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    from requests import codes
    from tqdm.contrib.telegram import TelegramIO
    t = TelegramIO(getenv('TQDM_TELEGRAM_TOKEN') , getenv('TQDM_TELEGRAM_CHAT_ID'))
    assert t.token
    assert t.chat_id
    assert t.message_id

# Generated at 2022-06-24 10:11:42.656942
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    tqdm_obj = tqdm(total=100, token=token, chat_id=chat_id)
    tqdm_obj.close()

# Generated at 2022-06-24 10:11:43.793060
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    pass



# Generated at 2022-06-24 10:11:47.449616
# Unit test for function trange
def test_trange():
    list(trange(5, desc='desc', leave=True, token=getenv('TQDM_TELEGRAM_TOKEN'),
                chat_id=getenv('TQDM_TELEGRAM_CHAT_ID')))


if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-24 10:11:58.513826
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from io import StringIO
    from time import time

    with StringIO() as f, tqdm_telegram(
            total=5, bar_format='{l_bar}{bar:10.2f}|{desc}|{desc_len}|{r_bar}',
            file=f, desc='test') as t:
        t.update(1)
        t.clear()
        t.update(2)
        t.clear(2)
        t.update(3)
        t.refresh()
        f.seek(0)
        assert f.read()

