

# Generated at 2022-06-24 10:01:47.349750
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    with tqdm_telegram(total=2, disable=False) as t:
        t.update(2)
        for i in tqdm_auto(range(3), disable=False):
          if i==1:
            t.close()
          assert t.disable==True

# Generated at 2022-06-24 10:01:54.936384
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    """Test the method: TelegramIO.write()"""
    # Initialization
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    tgio = TelegramIO(token, chat_id)
    # Test TelegramIO.write()
    s = "Hello World "
    tgio.write(s)
    # Test TelegramIO.write() with empty string
    s = ""
    tgio.write(s)
    # Test TelegramIO.write() with the same string
    s = "Hello World "
    tgio.write(s)
    # Test TelegramIO.write() with a few duplicates in a row
    s = "Hello World "
    tgio.write(s)
    tgio.write(s)
   

# Generated at 2022-06-24 10:01:57.854082
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    io = ttgrange(None, None, desc='Test', token='your-token-here',
                  chat_id='your-chat-id-here')
    assert isinstance(io, tqdm_telegram)
    io.close()

# Generated at 2022-06-24 10:02:09.025827
# Unit test for constructor of class tqdm_telegram

# Generated at 2022-06-24 10:02:12.898694
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    """Unit test for constructor of class tqdm_telegram"""
    _ = TelegramIO(token='some_token', chat_id='some_chat_id')


if __name__ == "__main__":
    from doctest import testmod
    testmod(verbose=True)

# Generated at 2022-06-24 10:02:19.641241
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from tqdm.contrib.telegram import tqdm_telegram
    from time import sleep
    with tqdm_telegram(total=2, desc='testing', leave=False,
                       token='801988238:AAG7OKYlLgcyNJ9rLdizPvHVrozSpij_i0c',
                       chat_id='573013308', leave=False) as t:
        sleep(0.1)
        t.update()


if __name__ == '__main__':
    test_tqdm_telegram_close()

# Generated at 2022-06-24 10:02:29.420745
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from requests import Session
    from os import environ
    from os.path import exists as _exists
    """Unit test for method write of class TelegramIO"""

    # If the file "test_token.txt" exists in the folder of this file, test
    # with the content of the file, else test with environment variable
    if _exists("test_token.txt"):
        with open("test_token.txt", "r") as f:
            token = f.readline().strip()
    else:
        token = environ.get('TQDM_TELEGRAM_TOKEN')

    # If the file "test_chat.txt" exists in the folder of this file, test
    # with the content of the file, else test with environment variable

# Generated at 2022-06-24 10:02:32.467848
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from time import sleep

    from .utils_testing import _test_telegram

    with _test_telegram() as (_, *args):
        for i in tqdm(*args):
            # Need to sleep to get updates
            sleep(1)

# Generated at 2022-06-24 10:02:38.679478
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    token = getenv('TQDM_TELEGRAM_TOKEN_DELETE')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID_DELETE')
    tgio = TelegramIO(token, chat_id)
    if '{token}' in token or '{chat_id}' in chat_id or tgio.message_id is None:
        return
    with tqdm_telegram(token=token, chat_id=chat_id) as t:
        assert t.tgio.message_id == tgio.message_id
    tgio.delete()

# Generated at 2022-06-24 10:02:43.524557
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    """
    TelegramIO.write(s)
    TelegramIO.write()
    TelegramIO.write()
    TelegramIO.write('test')
    TelegramIO.close()
    """
    from .utils_test import check_test_function_output
    check_test_function_output(test_TelegramIO_write,
                               "TelegramIO.write(s)\n")



# Generated at 2022-06-24 10:02:54.425526
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from requests import exceptions as rexc
    from unittest import mock

    def _test_write(session_post, response):
        tgio = TelegramIO('token', 'chat_id')
        tgio.session.post = session_post
        tgio.write('text')
        assert tgio.text == 'text'
        assert tgio._message_id == response['message_id']

    def _test_write_failed(session_post):
        with mock.patch('tqdm.utils.decode_bytes',
                        side_effect=lambda x: x.decode()):
            tgio = TelegramIO('token', 'chat_id')
            tgio.session.post = session_post
            tgio.write('text')

    # Success

# Generated at 2022-06-24 10:03:02.621525
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    io = TelegramIO(token="123", chat_id="321")
    assert io.token == "123"
    assert io.chat_id == "321"
    assert io.write("abc") == None
    assert io.delete() == None


# Generated at 2022-06-24 10:03:06.159423
# Unit test for function trange
def test_trange():
    from time import sleep
    for _ in trange(3, token=getenv('TQDM_TELEGRAM_TOKEN'),
                    chat_id=getenv('TQDM_TELEGRAM_CHAT_ID')):
        sleep(1)

# Generated at 2022-06-24 10:03:12.402385
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    tg = tqdm_telegram(token='{token}', chat_id='{chat_id}', desc='Test')
    from tqdm._utils import _term_move_up
    assert tg.disable is False

# Generated at 2022-06-24 10:03:17.735324
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    """ This tests that the tqdm TelegramIO class
    does not throw any errors upon attempting to delete a message
    that no longer exists.
    """
    try:
        io = TelegramIO('token', 'chat_id')
        io.delete()
    except Exception as e:
        print(str(e))
        print("Error: %s", str(e))
        raise(e)
    return True

# Generated at 2022-06-24 10:03:22.838446
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    with tqdm(token="FAKE_TOKEN", chat_id="FAKE_CHAT_ID", total=2) as t:
        assert not t.disable
    assert not hasattr(t, 'tgio')
    with tqdm(disable=True) as t:
        assert t.disable
    with tqdm(token=None, chat_id=None) as t:
        assert t.disable

# Generated at 2022-06-24 10:03:29.433863
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    # Test 1
    try:
        with tqdm(total=0, disable=True) as t:
            assert t.total == 0
    except BaseException:
        raise RuntimeError('test_trange Test 1 failed')

    # Test 2
    try:
        with tqdm(disable=True) as t:
            assert t.total == 0
    except BaseException:
        raise RuntimeError('test_trange Test 2 failed')

    # Test 3
    try:
        trange_return = trange(1)
    except BaseException:
        raise RuntimeError('test_trange Test 3 failed')

# Generated at 2022-06-24 10:03:35.697767
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    try:
        tqdm_telegram(total=0, token='t1', chat_id='c1').clear()
        tqdm_telegram(total=0, token='t2', chat_id='c2').close()
    except Exception:
        import traceback
        warn('\n' + traceback.format_exc())

# Generated at 2022-06-24 10:03:40.650855
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tg = TelegramIO('token', 'chat_id')
    tg.message_id
    res = tg.delete().result()
    assert res.status_code == 200
    assert res.json()['ok'] is True
    assert res.json()['result'] is True

# Generated at 2022-06-24 10:03:48.986949
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    import tempfile
    with tempfile.NamedTemporaryFile(mode='w', delete=False) as tf:
        tqdm_telegram().close()
        tqdm_telegram(leave=False).close()
        tqdm_telegram(leave=True).close()
        tqdm_telegram(leave=None, pos=1).close()
        tqdm_telegram(leave=None, pos=0).close()
        tqdm_telegram(disable=True).close()
        tqdm_telegram(file=tf).close()
        tqdm_telegram(file=tf, disable=True).close()
        tqdm_telegram(file=tf, leave=False).close()
        tqdm_telegram(file=tf, leave=True).close()
        tqdm_

# Generated at 2022-06-24 10:03:58.030616
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    """Testing method `write` of class `TelegramIO`."""
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch
    io = TelegramIO('{token}', '{chat_id}')
    io.write("Testing method `write` of class `TelegramIO`.")
    with patch('tqdm.contrib.telegram.TelegramIO.submit') as submit:
        io.write("Testing method `write` of class `TelegramIO`.")
        submit.assert_called_once()
    io.close()



# Generated at 2022-06-24 10:04:08.590833
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    import sys
    # This part is used to just check the constructor without any Telegram API
    # calls. If a Telegram API call is made here (e.g., tgr = tqdm_telegram()),
    # it would be used as a real API call, meaning that a POST request would
    # actually be made to the Telegram API. 
    tqdm_auto.monitor_interval = 0
    tqdm_auto.miniters = 1
    tgr = tqdm_telegram(total=10, leave=False, file=sys.stdout)
    assert tgr.tgio.token == None
    tgr = tqdm_telegram(total=10, leave=False, file=sys.stdout, token="mytoken")
    assert tgr.tgio.token == "mytoken"
    tgr = tq

# Generated at 2022-06-24 10:04:17.091528
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    import unittest

    class Test(unittest.TestCase):
        @staticmethod
        def test():
            tgIO = TelegramIO("token", "chat_id")
            with open('test.txt', 'r+') as f:
                tgIO.write(f.read())

    unittest.main(module=__name__, exit=False)

# Generated at 2022-06-24 10:04:19.949054
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    io = TelegramIO('token', '1')
    try:
        iob = io.__enter__()
    except Exception as e:
        tqdm_auto.write(str(e))
        io.__exit__(None, None, None)
        raise e
    else:
        io.__exit__(None, None, None)
        return iob

# Generated at 2022-06-24 10:04:23.957513
# Unit test for function trange
def test_trange():
    x = list(trange(10, token='{token}', chat_id='{chat_id}'))
    assert x == list(range(10))
test_trange.test = ['-t', '--no-xsrf-cookies', '--token', '{token}',
                    '--chat_id', '{chat_id}']

# Generated at 2022-06-24 10:04:25.290813
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    for i in tqdm([1,2,3]):
        pass

# Generated at 2022-06-24 10:04:27.362673
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    io = TelegramIO('token', 'chat_id')
    io.write('text')
    io.write('other text')

# Generated at 2022-06-24 10:04:33.380026
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    """Unit test for method display of class tqdm_telegram"""
    from . import tqdm_telegram
    from .utils_worker import MonoWorker
    from .utils import FormatLabel
    from tqdm import tqdm
    from time import sleep
    import sys

    class MyTqdmTelegram(tqdm_telegram):
        def __init__(self, *args, **kwargs):
            self.__init(*args, **kwargs)

    class TestIo(MonoWorker):
        def __init__(self):
            super(TestIo, self).__init__()
            self.s = ''

        def write(self, s):
            self.s = s

    io = TestIo()

# Generated at 2022-06-24 10:04:36.723113
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    m = tqdm_telegram(0, bar_format="{bar}", token='{token}', chat_id='{chat_id}', leave=True)
    m.display()
    m.close()


# Generated at 2022-06-24 10:04:45.217555
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    f = __file__
    warnings.simplefilter('ignore', TqdmDeprecationWarning)
    import re
    try:
        import nose
    except BaseException:
        return

    # Remove the "test_" prefix of the file name.
    assert f.endswith('.py'), (
        'Unit test file should be end with ".py"')
    f = re.sub(r'test_', '', os.path.basename(f))

    def test_tqdm():
        # For testing `clear`
        with tqdm(total=10, file=tqdm_telegram.write,
                  ascii=False) as pbar:
            for i in range(10):
                pbar.update()
                if 2 <= i < 5:
                    pbar.clear()

    # Run generated unit

# Generated at 2022-06-24 10:04:47.018630
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    msg = 'test'
    try:
        t = tqdm(total=1, desc=msg)
        t.close()
        assert t.tgio.text == msg
    except:
        pass

# Generated at 2022-06-24 10:04:50.419753
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    """Unit test for method clear of class tqdm_telegram."""
    from .test_tqdm import pretest_posttest

    def posttest_hook(res):
        res.tgio.delete()

    pretest_posttest(tqdm_telegram, posttest_hook)

# Generated at 2022-06-24 10:04:51.899734
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from .tests import _test_clear
    _test_clear(tqdm_telegram)

# Generated at 2022-06-24 10:04:58.016655
# Unit test for function trange
def test_trange():
    """Test function for trange."""
    from random import random

    for _ in trange(10, unit_scale=.01, unit='s', position=0, desc='Test',
                    disable=False, token='{token}', chat_id='{chat_id}'):
        sleep(random() / 3)


if __name__ == '__main__':
    from time import sleep
    test_trange()

# Generated at 2022-06-24 10:05:04.664253
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """
    Tests method `close` of class `tqdm_telegram`
    """
    class MockTelegramIO(TelegramIO):
        def delete(self):
            pass

    from unittest import TestCase

    class MockTqdmTelegram(tqdm_telegram):
        def __init__(self, *args, **kwargs):
            tqdm_telegram.__init__(self, *args, **kwargs)
        def format_meter(self, *args, **kwargs):
            return 'A meter'


# Generated at 2022-06-24 10:05:08.542773
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from .tests import _test_write as func
    tqdm_telegram.write = func
    tgio = TelegramIO("", "")
    tgio.write("test")


if __name__ == '__main__':
    from doctest import testmod
    testmod(verbose=True)

# Generated at 2022-06-24 10:05:11.476913
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    TelegramIO("407165265:AAFnMBFTs_3qB9QoS1nSVtAoMoPZN4YDl0s", "238199766")

# Generated at 2022-06-24 10:05:18.876723
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    try:
        import pytest
        t = TelegramIO('{token}', '{chat_id}')
        t.delete()
    except Exception as e:
        tqdm_auto.write(str(e))
        assert 0
if __name__ == "__main__":
    test_TelegramIO_delete()

# Generated at 2022-06-24 10:05:21.714325
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram("foo", disable=True)
    t.close()
    assert True


# Generated at 2022-06-24 10:05:24.439457
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    assert tqdm_telegram(total=1, ascii=True,
                         token="token", chat_id="chat_id")

# Generated at 2022-06-24 10:05:26.543512
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    t = TelegramIO(token='{token}', chat_id='{chat_id}')
    t.write('test')
    t.delete()

# Generated at 2022-06-24 10:05:37.476358
# Unit test for function trange
def test_trange():
    """
    Test correctness of trange by comparing it with original trange
    """
    from tqdm.auto import trange
    from itertools import repeat
    with trange(10) as t:
        with ttgrange(10) as ttg:
            for i, j in zip(t, ttg):
                assert i == j
    with trange(10, 2) as t:
        with ttgrange(10, 2) as ttg:
            for i, j in zip(t, ttg):
                assert i == j
    with trange(10, 1, 3) as t:
        with ttgrange(10, 1, 3) as ttg:
            for i, j in zip(t, ttg):
                assert i == j

# Generated at 2022-06-24 10:05:45.615066
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    token = getenv('TQDM_TELEGRAM_TOKEN')
    if not token:
        warn("No `TQDM_TELEGRAM_TOKEN` environment variable. Skipping test...",
             TqdmWarning)
        return
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if not chat_id:
        warn("No `TQDM_TELEGRAM_CHAT_ID` environment variable. "
             "Skipping test...", TqdmWarning)
        return
    try:
        TelegramIO(token, chat_id)
    except Exception as e:
        warn("Failed to create Telegram IO. Skipping test...", TqdmWarning)


if __name__ == '__main__':
    test_TelegramIO()

# Generated at 2022-06-24 10:05:48.556148
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tgio = TelegramIO(getenv('TQDM_TELEGRAM_TOKEN'),
                      getenv('TQDM_TELEGRAM_CHAT_ID'))
    tgio.submit(tgio.delete)

# Generated at 2022-06-24 10:05:57.457313
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    for _ in tqdm(
            range(8),
            # token='1',
            # chat_id='2',
            unit='it',
            total=10, leave=False,
            miniters=1, mininterval=0.1,
            maxinterval=10.0, mininterval_multiplier=1,
            disable=False, unit_scale=False, unit_divisor=1000,
            ascii=None,
            dynamic_ncols=False, smoothing=0.3, bar_format=None,
            initial=0, position=None):
        pass

# Generated at 2022-06-24 10:06:05.361345
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from unittest import mock
    tg = tqdm_telegram(disable=True)
    tg.tgio.session.post = mock.Mock()
    tg.close()
    tg.tgio.session.post.assert_not_called()

    tg.disable = False
    tg.leave = False
    tg.pos = 1
    tg.close()
    tg.tgio.session.post.assert_called()

    tg.disable = False
    tg.leave = True
    tg.pos = 0
    tg.close()
    assert tg.tgio.session.post.call_count == 2
    tg.tgio.session.post.reset_mock()

    tg.leave = False
    tg.pos = 0

# Generated at 2022-06-24 10:06:12.514814
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    with open("/dev/null", "w") as devnull:
        tqdm_auto.write = devnull.write
        tgio = TelegramIO("TESTIINGTESTING", "@python_tqdm")
        tgio.write("Test 1")
        tgio.write("Test 1")
        assert tgio.write("Test 2") is not None
        tgio.submit = lambda *args: tqdm_auto.write("Request: " + repr(args))
        tgio.write("Test 3")
        tgio.write("Test 3")
        tgio.submit = lambda *args: None
        assert tgio.write("Test 4") is None
        tqdm_auto.write = tqdm_auto._instant_write

# Generated at 2022-06-24 10:06:16.634378
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    """Test tqdm_telegram class constructor"""
    import sys
    try:
        import pytest
    except ImportError:
        return  # handle import error
    with pytest.raises(Exception):
        _ = tqdm_telegram(range(5), file=sys.stdout,
                          token=None, chat_id=None)

# Generated at 2022-06-24 10:06:22.664040
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if token is None or chat_id is None:
        return
    tgr = tqdm_telegram(1, token=token, chat_id=chat_id)
    tgr.write = tgr.display
    tgr.write()
    tgr.close()


# Generated at 2022-06-24 10:06:23.854610
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from ..format_size import format_size
    from ..std import FormatStrin

# Generated at 2022-06-24 10:06:29.691923
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from sys import argv
    argv.extend(['token', 'chat_id'])
    with tqdm_telegram(total=4, unit='B', leave=True) as pbar:
        pbar.display()
        # Expected result is "{bar}\n\n"
        assert len(pbar.format_meter()) == len('{bar}\n\n')
        pbar.close()
    try:
        pbar.close()
    except RuntimeError:
        assert True

# Generated at 2022-06-24 10:06:35.307077
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    try:
        TelegramIO(getenv('TQDM_TELEGRAM_TEST_TOKEN'),
                   getenv('TQDM_TELEGRAM_TEST_CHAT_ID'))
    except:
        pass
    else:
        raise ValueError('TelegramIO constructor does not raise error')

# Generated at 2022-06-24 10:06:40.057395
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    """Test for Telegram Bot."""
    for i in tqdm(range(10), token='123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZ', chat_id='1234567890'):
        time.sleep(0.01)
    time.sleep(2)

# Generated at 2022-06-24 10:06:43.266533
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    def _test_init():
        return tqdm_telegram(token='{token}', chat_id='{chat_id}',
                             disable=True)
    assert _test_init() is not None


# Generated at 2022-06-24 10:06:53.855428
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import requests_mock
    from requests.exceptions import ConnectionError

    class MockTqdmTelegram(tqdm_telegram):
        def __init__(self, *args, **kwargs):
            self.tgio = None
            super(MockTqdmTelegram, self).__init__(*args, **kwargs)

        def display(self, *args, **kwargs):
            pass

    with requests_mock.mock() as mock:
        def edit_message_text(request, context):
            # If there's an error, don't send an HTTP response
            if context.get('exception'):
                raise context['exception']
            context.status_code = 200
            return {}


# Generated at 2022-06-24 10:06:56.314127
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .utils_test import tqdm_telegram_test
    tqdm_telegram_test(tqdm_telegram)

# Generated at 2022-06-24 10:07:00.754353
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import pytest
    t = tqdm_telegram('123', leave=False)
    t.n = 4
    t.clear(); t.display(); t.close()
    t.n = 4; t.last_print_n = 4
    t.clear(); t.display(); t.close()

# Generated at 2022-06-24 10:07:04.407426
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tgio = TelegramIO('', '')
    assert tgio.write("1\n2\n") is None  # no future
    tgio = TelegramIO('', '-1')
    assert tgio.write("1\n2\n3") is None  # no future

# Generated at 2022-06-24 10:07:11.042055
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    iterable = [1,2,3]
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if token and chat_id:
        for i in trange(3, token=token, chat_id=chat_id):
            assert i in iterable


if __name__ == '__main__':
    test_tqdm_telegram()

# Generated at 2022-06-24 10:07:17.266184
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from time import sleep
    from os import devnull

    # Create a fake file-like object
    f = open(devnull, 'wb')

    # Create a tqdm_telegram object
    t = tqdm_telegram('Hi!', file=f)

    # Call the clear method
    t.clear()

    # Close the fake file-like object (to avoid an ResourceWarning)
    f.close()

# Generated at 2022-06-24 10:07:23.009346
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    tg = tqdm_telegram(range(3), unit_scale=True)
    tg.close()
    assert isinstance(tg.tgio, TelegramIO)

# Generated at 2022-06-24 10:07:30.233353
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    """
    Unit test for method display of class tqdm_telegram
    """
    from tqdm.auto import trange
    from tqdm.utils import _term_move_up
    _pbar = tqdm_telegram(1, file=open(os.devnull, 'w'))
    _pbar.format_dict = dict(bar_format='{l_bar}{bar}{r_bar}')
    _pbar.display()
    assert _pbar.format_meter(bar='█', ncols=10).endswith('█')



# Generated at 2022-06-24 10:07:39.212659
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    """
    >>> t = tqdm_telegram(token='{token}', chat_id='{chat_id}', total=10, leave=False)
    >>> t.update()
    >>> t.clear()
    >>> t.update()
    >>> t.close()
    """
    pass


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 10:07:50.497044
# Unit test for function trange
def test_trange():
    """Unit test for `tqdm.contrib.telegram.trange`"""
    kwargs = {'token': getenv('TQDM_TELEGRAM_TOKEN'),
              'chat_id': getenv('TQDM_TELEGRAM_CHAT_ID')}
    with ttgrange(2, token='token_dummy', chat_id='chat_id_dummy') as bar:
        assert bar.tgio.token == 'token_dummy'
        assert bar.tgio.chat_id == 'chat_id_dummy'
        for __ in bar:
            pass
        assert bar.tgio.token == 'token_dummy'
        assert bar.tgio.chat_id == 'chat_id_dummy'
        bar.close()

# Generated at 2022-06-24 10:07:53.511855
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tg = TelegramIO("token", "chat_id")
    tg._message_id = 12345
    assert tg.message_id == 12345
    tg.delete()
    assert tg.message_id is None

# Generated at 2022-06-24 10:08:04.573035
# Unit test for function trange
def test_trange():
    """Test trange()"""
    import sys

    class Tee(object):
        def __init__(self):
            self.buffer = ''

        def write(self, s):
            self.buffer += s

        def flush(self):
            pass

        def getvalue(self):
            val = self.buffer
            self.buffer = ''
            return val
    for _token in [None, 'token']:
        for _chat_id in [None, 'chat_id']:
            sys.stdout = Tee()
            for _disable in [True, False]:
                for _total in [None, 1, 10]:
                    kwargs = {}
                    if _token is not None:
                        kwargs['token'] = _token
                    if _chat_id is not None:
                        kwargs['chat_id'] = _

# Generated at 2022-06-24 10:08:09.311763
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    assert not tqdm_telegram(disable=True).close()
    tqdm_telegram().close()
    tqdm_telegram(leave=True).close()
    tqdm_telegram(total=1, leave=None).n = 1
    tqdm_telegram(total=1, leave=None).close()

# Generated at 2022-06-24 10:08:13.286375
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    fd = tqdm_telegram(token='1234', chat_id='4321')
    fd.total = 100
    fd.pos = 0
    fd.display()
    fd.pos = 10
    fd.display(ncols=10)
    fd.pos = 100
    fd.display()

# Generated at 2022-06-24 10:08:23.392862
# Unit test for method display of class tqdm_telegram

# Generated at 2022-06-24 10:08:25.995386
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    tg = TelegramIO(token='key', chat_id='id')
    assert tg.token == 'key'
    assert tg.chat_id == 'id'

# Generated at 2022-06-24 10:08:34.643522
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from time import sleep
    from os import remove
    from multiprocessing import Process, Queue
    try:
        from io import StringIO
    except ImportError:
        from io import BytesIO as StringIO

    if getenv('TEST_TQDM_TELEGRAM_TOKEN') is None or \
            getenv('TEST_TQDM_TELEGRAM_CHAT_ID') is None:
        return

    # Without Telegram token and chat_id
    tgio = TelegramIO(None, None)
    tgio.write('Hello')
    tgio.delete()
    tgio.close()

    # With Telegram token and chat_id

# Generated at 2022-06-24 10:08:36.300887
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    tt = tqdm_telegram(total=100)
    tt.close()
    tt.close()

# Generated at 2022-06-24 10:08:39.595527
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    io = TelegramIO('tokentest', 'chat_id_test')
    test_write_1 = "hello"
    test_write_2 = "world"
    io.write(test_write_1)
    io.write(test_write_2)

# Generated at 2022-06-24 10:08:43.532677
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():

    def test_eol_sp(s):
        """Test that spaces are properly handled at end of line"""
        io = TelegramIO('dummy','dummy')
        io.write(s)
        assert s == io.text  # no changes in display

    for s in ['test', 'test\n', 'test \n', 'test  \n', 'test   \n']:
        yield (test_eol_sp, s)

# Generated at 2022-06-24 10:08:45.829882
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    # Create a new TelegramIO object and test if it's not None
    tgIO = TelegramIO(token="token", chat_id=0)
    assert tgIO is not None   
    

# Generated at 2022-06-24 10:08:59.374841
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import math
    import time
    with tqdm_telegram(total=math.ceil(math.log(10, 2)),
                       desc="Testing start",
                       initial=0, token='1008831879:AAEO7Vu8W5r5rGc5n5l93YJb5_F-LxgfZA0',
                       #token='982437286:AAHoZU6BjY76QEOJ6eRbNDdwfOyFov-Lkmg',
                       chat_id='-322911603',
                       #chat_id='-413905442',
                       leave=True, miniters=1) as pbar:
        pbar.display(**dict(pbar.format_dict, rate=1))

# Generated at 2022-06-24 10:09:06.939763
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    token = '417445541:AAG5kqhZV7_uS_8SNW7CBLn0H2b7YwYlFX8'
    chat_id = '91996870'
    io = TelegramIO(token, chat_id)
    io.delete()

# Generated at 2022-06-24 10:09:10.885493
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    assert repr(tqdm_telegram([], token='token', chat_id='chat_id')) == \
        "tqdm_telegram([], token='token', chat_id='chat_id')"

# Generated at 2022-06-24 10:09:13.332792
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    with tqdm(total=4, desc='Tqdm Telegram') as pbar:
        for i in range(4):
            pbar.update()

# Generated at 2022-06-24 10:09:20.113242
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    try:
        from os import remove
    except ImportError:
        return  # Python < 2.6
    try:
        token = getenv('TQDM_TELEGRAM_TOKEN')
        chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
        TelegramIO(token, chat_id)
    except Exception:
        pass
    finally:
        try:
            remove('token')
        except OSError:
            pass

# Generated at 2022-06-24 10:09:21.114013
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    t = TelegramIO("token", "chatId")

# Generated at 2022-06-24 10:09:29.489010
# Unit test for constructor of class TelegramIO

# Generated at 2022-06-24 10:09:31.829415
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    TelegramIO('{token}', '{chat_id}')

# Generated at 2022-06-24 10:09:33.782265
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    io = TelegramIO('12345678', '1')
    io.message_id
    io.delete()

# Generated at 2022-06-24 10:09:36.538876
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from time import sleep
    for _ in tqdm_telegram(list(range(10))):
        sleep(0.1)


# Generated at 2022-06-24 10:09:41.519217
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    token = '12345678:ABCDEFGHIJKLMNOPQRSTUVWXXYZ1234567'
    chat_id = '12345678'
    tgio = TelegramIO(token, chat_id)
    tgio.write('Hello!')
    tgio.write('Bye!')
    assert tgio.message_id == 12345678
    tgio.close()

# Generated at 2022-06-24 10:09:46.756021
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    import pytest
    t = tqdm_telegram(range(3), leave=True)
    t.close()
    with pytest.raises(AttributeError):
        t.tgio.delete()

    t = tqdm_telegram(range(3), leave=False)
    t.close()
    try:
        t.tgio.delete()
    except Exception as e:
        pytest.fail("t.tgio.delete() raised exception: " + str(e))

# Generated at 2022-06-24 10:09:49.775674
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    # tqdm_telegram is a subclass of tqdm_auto,
    # and we have built-in-test for tqdm_auto's close.
    from .test_tqdmao import test_tqdm_auto_close
    test_tqdm_auto_close(tqdm_telegram)

# Generated at 2022-06-24 10:09:58.241554
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if token is None or chat_id is None:
        raise Exception("Env TQDM_TELEGRAM_TOKEN and TQDM_TELEGRAM_CHAT_ID "
                        "must be set for testing")
    tt = tqdm_telegram(total=100000,
                       bar_format='{bar:10u}{postfix[0]}{postfix[1]}',
                       token=token, chat_id=chat_id)
    for i in _range(1000000):
        tt.update()
    tt.close()

# Generated at 2022-06-24 10:10:00.055872
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import sys
    tgio = TelegramIO(sys.argv[1], sys.argv[2])
    tgio.write("hello")
    tgio.close()

# Generated at 2022-06-24 10:10:01.448238
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import doctest
    doctest.testmod(verbose=True)


# Generated at 2022-06-24 10:10:10.066872
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    # Test warnings
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always')
        tqdm(total=10, mininterval=0.1, disable=True, token='', chat_id='')
    assert len(w) == 1, "No warning given"
    assert issubclass(w[-1].category, TqdmWarning), \
        "Not a TqdmWarning: {0}".format(w[-1].message)
    assert "Creation rate limit" in str(w[-1].message)

    # Test basic usage
    d = {}
    n = 100
    for i in tqdm(range(n), token='', chat_id=''):
        d[i] = i * 2
        time.sleep(0.01)

# Generated at 2022-06-24 10:10:15.919871
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    try:
        with tqdm_telegram([1, 2, 3]) as t:
            for i in t:
                t.update(1)
    except Exception as e:
        print(e)
    else:
        print("PASSED")

if __name__ == "__main__":
    test_tqdm_telegram_close()

# Generated at 2022-06-24 10:10:23.449889
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from .tests import TqdmDeprecationWarning
    from .tests.test_tqdm_telegram import TokenTest, ChatIdTest, AssertWarns
    import sys

    def _run_assert_warns_test(callable, *args, **kwargs):
        with AssertWarns(TqdmDeprecationWarning):
            with AssertWarns(TokenTest):
                callable(*args, **kwargs)

    # test class `TokenTest`
    _run_assert_warns_test(tqdm_telegram, token='1234')

    # test class `ChatIdTest`
    _run_assert_warns_test(tqdm_telegram, chat_id='1234')

# Generated at 2022-06-24 10:10:33.103156
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    # Delete a non-existing message returns True
    class MockSession:
        def post(self, request, data):
            return {'error_code' : None}
    io = TelegramIO('token', 'chat_id')
    io._message_id = 0
    io.session = MockSession()
    assert io.delete() is None

    # Delete a non-existing message returns False
    class MockSession:
        def post(self, request, data):
            return {'error_code' : 400}
    io = TelegramIO('token', 'chat_id')
    io._message_id = 0
    io.session = MockSession()
    assert io.delete() == False

    # Delete an existing message returns True
    class MockSession:
        def post(self, request, data):
            return {'error_code' : None}

# Generated at 2022-06-24 10:10:35.411242
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from time import sleep
    for i in range(10):
        print("test_tqdm_telegram_clear")
        sleep(1)


# Generated at 2022-06-24 10:10:42.349909
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from tqdm import tqdm
    from tqdm.contrib.telegram import tqdm_telegram
    for t in (tqdm, tqdm_telegram):
        if t == tqdm_telegram:
            t = tqdm_telegram(disable=True)
        # Test on empty iterator
        pbar_empty = t(total=0)
        pbar_empty.close()
        # Test on iterator with `leave=True`
        pbar_leave = t(total=3, leave=True)
        pbar_leave.update(1)
        pbar_leave.close()
        # Test on iterator with `leave=False`
        pbar_noleave = t(total=3, leave=False)
        pbar_noleave.update(1)
        pbar_

# Generated at 2022-06-24 10:10:44.433551
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    telegram_io = TelegramIO(token='your_token', chat_id='your_chat_id')
    assert(telegram_io.delete())

# Generated at 2022-06-24 10:10:50.636800
# Unit test for function trange
def test_trange():
    """Test trange"""
    assert list(ttgrange(13)) == list(range(13))


if __name__ == "__main__":
    r = ttgrange(13)
    for _ in r:
        r.set_description("Foo")
        r.update()

# Generated at 2022-06-24 10:10:54.114773
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tgio = TelegramIO(token='', chat_id='')

    # check if the write function is working
    tgio.write('tqdm')
    assert tgio.text == 'tqdm'
    tgio.text = 'TelegramIO'
    assert tgio.text == 'TelegramIO'

# Generated at 2022-06-24 10:11:06.112834
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from io import StringIO
    import requests
    import random
    global_token = '965101003:AAExeRzRd5K5G5PJaWqf8Qv1i6ufuUQXIk8'
    global_chat_id = '-1001437461218'
    telegram_io = StringIO()
    tg_tqdm = tqdm_telegram(
        'baz', file=telegram_io, token=global_token,
        chat_id=global_chat_id)
    tg_tqdm.display()

    def check_end(tqdm):
        api_url = (
            'https://api.telegram.org/bot' + global_token
            + '/editMessageText')

# Generated at 2022-06-24 10:11:09.493058
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import tqdm.contrib.telegram as tele
    t = tele.tqdm(token="", chat_id="")
    t.write("done")
    t.clear()
    t.close()

# Generated at 2022-06-24 10:11:15.926910
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import mock
    import sys
    with mock.patch.object(TelegramIO, 'write', autospec=True) as io_write_mock:
        with tqdm(
                iterable=range(10),
                file=sys.stdout,
                disable=False,
                leave=False,
                token='foo',
                chat_id='bar'
                ) as tqdm_obj:
            tqdm_obj.write('')
    io_write_mock.assert_called_once()

# Generated at 2022-06-24 10:11:26.103895
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from threading import Thread
    from time import sleep
    from tqdm.auto import tqdm
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')

    def _telegram_api_write(token, chat_id):
        tio = TelegramIO(token, chat_id)
        for i in tqdm(range(10), disable=True):
            sleep(1)
            tio.write("test")
        tio.write("finish")
        tio.close()

    assert token is not None
    assert chat_id is not None
    t = Thread(target=_telegram_api_write, args=(token, chat_id))
    t.start()

# Generated at 2022-06-24 10:11:36.803104
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    """Unit test for method write of class TelegramIO"""
    session = Session()
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    # create first message
    res = session.post(
        '%s%s/sendMessage' % (TelegramIO.API, token),
        data={'text': 'ping', 'chat_id': chat_id,
              'parse_mode': 'MarkdownV2'})
    message_id = res.json()['result']['message_id']
    # edit message

# Generated at 2022-06-24 10:11:38.497914
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    TelegramIO("token", "chat_id")

# Generated at 2022-06-24 10:11:49.015981
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    try:
        from io import StringIO
    except ImportError:
        from StringIO import StringIO
    import subprocess
    import sys
    import time

    def out_str_to_pbar(s):
        from .gui.tqdm_notebook import tqdm_notebook
        from .gui.tqdm_pandas import tqdm_pandas