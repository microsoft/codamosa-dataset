

# Generated at 2022-06-24 10:02:03.176271
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """
    Unit test for :meth:`tqdm.contrib.telegram.tqdm_telegram.close`

    Take in input a TelegramIO instance and test that method close has no
    effects when TelegramIO has no attribute message_id.
    """
    tg_instance = TelegramIO('token', 'chat_id')
    tg_instance.close()
    # if close does not work, an exception will rise when calling
    # tg_instance.delete
    tg_instance.delete()


# Generated at 2022-06-24 10:02:10.632584
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from os import environ

    # Ensure missing arguments are detected early
    try:
        tqdm_telegram(total=5)
    except Exception as e:
        assert 'token' in e.args[0]
    try:
        tqdm_telegram(total=5, token='TOKEN')
    except Exception as e:
        assert 'chat_id' in e.args[0]

    # Ensure environment variables are supported
    environ['TQDM_TELEGRAM_TOKEN'] = 'token'
    environ['TQDM_TELEGRAM_CHAT_ID'] = 'chat_id'
    tqdm_telegram(total=5)

# Generated at 2022-06-24 10:02:16.060042
# Unit test for function trange
def test_trange():
    from time import sleep
    for _ in trange(10, token='1852865707:AAH-jC9N0sTJFcZsWOQsM_KjJf1bvGjovzA',
                    chat_id='-345126851', mininterval=0.5, miniters=1):
        sleep(0.115)


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 10:02:21.780871
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    try:
        from importlib.resources import path
    except ImportError:
        from importlib_resources import path
    import os

    with path(__package__, "token.txt") as file:
        token = file.read_text().strip()
        chat_id = os.environ.get('TQDM_TELEGRAM_CHAT_ID')
        if chat_id is None:
            warn("No `TQDM_TELEGRAM_CHAT_ID` env var, skipping test.",
                 TqdmWarning, stacklevel=2)
            return
        for _ in tqdm_telegram(range(1), token=token, chat_id=chat_id):
            break
    # No crashes

# Generated at 2022-06-24 10:02:27.262624
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    s = tqdm_telegram.display({'total': 99, 'n': 99, 'desc': 'foo',
                               'bar_format': '{l_bar}{bar:20u}{r_bar}'},
                              pos=None, leave=False,
                              bar_format='{l_bar}{bar:20u}{r_bar}')
    assert '[foo] 100%|####################| ' in s



# Generated at 2022-06-24 10:02:32.319029
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    try:
        token = getenv('TQDM_TELEGRAM_TOKEN')
    except Exception as e:
        tqdm_auto.write("WARNING: " + str(e))
    if token:
        tgio = TelegramIO(token=token, chat_id='-1001373340126')
        tgio.write(text="Test")

# Generated at 2022-06-24 10:02:38.841965
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    """Test `tqdm_telegram.display()` function."""
    from ..tqdm import trange

    for _ in trange(1, dynamic_ncols=True, smoothing=0):
        for i in trange(5, 10, dynamic_ncols=True):
            for _ in trange(20, dynamic_ncols=True, leave=False,
                            bar_format='{l_bar}{bar}'):
                pass
        for _ in trange(20, leave=False):
            pass
    # TODO: test with tgrange



# Generated at 2022-06-24 10:02:41.611105
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    t = TelegramIO('test', 'test')
    # test forbidden and allowed
    x = t.write('a' * 5001)
    assert x is None
    x = t.write('a' * 5000)
    assert x is not None
    t.close()
    del t

# Generated at 2022-06-24 10:02:45.072115
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    t = tqdm_telegram('test', disable=True, mininterval=0)
    try:
        t.display(bar_format='{l_bar} {bar} {r_bar}')

        t.close()  # make delete code unit testable
    finally:
        t.disable = False

# Generated at 2022-06-24 10:02:52.103667
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    delete = True
    try:
        token = getenv('TQDM_TELEGRAM_TOKEN')
        chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    except Exception:
        delete = False

    if delete:
        tqdm.write("\nTesting delete...")
        tg = tqdm(total=1, disable=True,
                  token=token, chat_id=chat_id)
        tg.close()

# Generated at 2022-06-24 10:03:00.735832
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .utils import _report_fake_t, _test_lib as test_lib

    def _test_tqdm_telegram_display(**kwargs):
        # set default args
        kwargs['unit'] = kwargs.get('unit', 'iB')
        kwargs['unit_scale'] = kwargs.get('unit_scale', True)
        kwargs['ascii'] = kwargs.get('ascii', True)
        kwargs['token'] = kwargs.get('token', '566148164:AAF5nHv5f_Kxg7k-n1pXVFnIzK25lfw-5rE')
        kwargs['chat_id'] = kwargs.get('chat_id', '563122759')
        # get a

# Generated at 2022-06-24 10:03:07.294417
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """ Ensure that tqdm_telegram is deleted from chat when it leaves """
    tgrange = tqdm_telegram(range(10))
    for i in tgrange:
        pass
    tgrange.close()

# Generated at 2022-06-24 10:03:11.180507
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    io = TelegramIO(
        kwargs.pop('token', getenv('TQDM_TELEGRAM_TOKEN')),
        kwargs.pop('chat_id', getenv('TQDM_TELEGRAM_CHAT_ID')))
    io.write('Hello World!')
    io.delete()

# Generated at 2022-06-24 10:03:19.268758
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    """test for class TelegramIO method delete"""
    # this test as a side effect sends one message to the bot
    # make sure you have the environment variables defined
    # TQDM_TELEGRAM_TOKEN and TQDM_TELEGRAM_CHAT_ID
    print("Testing TelegramIO method delete")

    t = TelegramIO(getenv('TQDM_TELEGRAM_TOKEN'),
                   getenv('TQDM_TELEGRAM_CHAT_ID'))
    # method message_id will create a message
    t.message_id
    # method delete should delete the created message
    print("Deleting the message sent to the bot (check manually)")
    t.delete()

# Generated at 2022-06-24 10:03:28.645892
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from time import sleep
    from unittest import TestCase
    from mock import patch

    class TestClass(TestCase):
        @patch('requests.post')
        def test_write_edit(self, requests_post):
            tg = TelegramIO('token', 'chat_id')
            tg.write('blah')
            self.assertTrue(requests_post.called)
            self.assertEqual(requests_post.call_args[0][0],
                             'https://api.telegram.org/bot' + 'token' +
                             '/editMessageText')

        @patch('requests.post')
        def test_write_create(self, requests_post):
            tg = TelegramIO('token', 'chat_id')
            del tg._message_id

# Generated at 2022-06-24 10:03:30.264055
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    with tqdm_telegram(total=10) as t:
        t.close()

# Generated at 2022-06-24 10:03:38.714162
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    with tqdm_telegram(total=10, ncols=0, disable=True,
                       ascii=True) as pbar:
        pbar.update()
        pbar.display()
        assert pbar.last_print_n == 1
        assert pbar.last_print_t == pbar.elapsed
        assert pbar.dynamic_display()

    with tqdm_telegram(total=1, ncols=100, disable=True,
                       ascii=True) as pbar:
        pbar.display()
        assert pbar.dynamic_display()

# Generated at 2022-06-24 10:03:41.457862
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tgio = TelegramIO('DUMMY_TOKEN', 'DUMMY_CHAT_ID')
    tgio.delete()

# Generated at 2022-06-24 10:03:45.079588
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    iostream = TelegramIO('{token}', '{chat_id}')
    iostream.write("testing")
    iostream.submit(iostream.write, "testing again")

# Generated at 2022-06-24 10:03:52.884913
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    """Unit test to check if TelegramIO creates a new message correctly."""
    from os import getenv
    from requests import get
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    assert token and chat_id, 'Ensure environment variables' \
                              ' TQDM_TELEGRAM_TOKEN and TQDM_TELEGRAM_CHAT_ID' \
                              ' are set and point to a Telegram bot API token' \
                              ' and a chat ID, respectively.'
    tgio = TelegramIO(token, chat_id)
    assert tgio.message_id, 'TelegramIO.__init__() FAILED'

# Generated at 2022-06-24 10:03:56.401888
# Unit test for function trange
def test_trange():
    from math import sqrt

    for _ in trange(3, leave=False, desc="xyz", total=3):
        for _ in trange(3, leave=False, desc="xyz", total=3):
            for _ in trange(3, leave=False, desc="xyz", total=3):
                for x in range(100):
                    sqrt(x ** x + x ** 2)

# Generated at 2022-06-24 10:04:02.505859
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    bot_token = getenv("TQDM_TELEGRAM_TOKEN")
    chat_id = getenv("TQDM_TELEGRAM_CHAT_ID")
    if bot_token and chat_id:
        import time
        tg = TelegramIO(bot_token, chat_id)
        tg.write("ttgrange test_TelegramIO_write")
        time.sleep(6)
        tg.write("ttgrange test_TelegramIO_write")
        time.sleep(6)
        tg.delete()

# Generated at 2022-06-24 10:04:04.149478
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    try:
        tqdm_telegram(total=3)
    except Exception:
        pass



# Generated at 2022-06-24 10:04:07.970110
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tg = TelegramIO(token=getenv('TQDM_TELEGRAM_TOKEN'), chat_id=int(getenv('TQDM_TELEGRAM_CHAT_ID')))
    tg.message_id
    tg.delete()
    tg.write("test")
    tg.delete()
    tg.close()

# Generated at 2022-06-24 10:04:16.989276
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from .tests import compare_tqdm
    with compare_tqdm(tqdm_telegram, tqdm_auto, unit="i",
                      total=1, disable=False, mininterval=0.5,
                      token="", chat_id="") as (bar1, bar2):
        for i in bar1:
            pass
        for i in bar2:
            pass

# Generated at 2022-06-24 10:04:19.541659
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    total = 5
    x = tqdm_telegram(total=total, disable=False)
    for i in range(total):
        x.update(1)
        x.clear()

# Generated at 2022-06-24 10:04:27.575041
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import time

    with tqdm_telegram(
            total=100, bar_format=
            '{l_bar}{bar:10u}{r_bar}|{n_fmt}/{total_fmt}[{elapsed}<{remaining}]',
            token='1226153346:AAGGBZJwFXp5srOJ5K5D9gWfBJOn37zHCOY',
            chat_id='663218254') as pbar:
        for i in range(200):
            pbar.n += 1
            time.sleep(0.01)
        pbar.total = 200

# Generated at 2022-06-24 10:04:30.982668
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import pytest
    curr = tqdm_telegram(total=10, token='154444015:AAF6FkuC-kcMwUV5D5PMyzUP_X9oc1hJFCk', chat_id='-172087327')
    curr.n = 7
    curr.display()


# Generated at 2022-06-24 10:04:40.113146
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm.contrib.telegram import tqdm, ttgrange
    from sys import getdefaultencoding, version_info
    from time import sleep
    from random import random
    from os import environ as env
    from os.path import exists

    n = 15

    for n in [4, 5]:
        for i in ttgrange(n, token=env.get('TQDM_TELEGRAM_TOKEN'),
                          chat_id=env.get('TQDM_TELEGRAM_CHAT_ID'),
                          leave=True,
                          disable=False):
            sleep(0.5)
        assert exists('.tqdm_telegram_display')



# Generated at 2022-06-24 10:04:43.191068
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    for pbar in [tqdm_telegram(range(10), leave=True),
                 tqdm_telegram(range(10), leave=False),
                 tqdm_telegram(range(10)),
                 tqdm_telegram(range(10))]:
        pbar.close()

# Generated at 2022-06-24 10:04:47.139995
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    token, chat_id = (
        '123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11', '123456')
    tgio = TelegramIO(token, chat_id)
    assert tgio.token == token
    assert tgio.chat_id == chat_id

# Generated at 2022-06-24 10:04:49.956761
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    io = TelegramIO(token="None", chat_id="None")
    io.message_id = 1
    io.session.post = lambda x, data: {"error_code": None}
    io.write('')

# Generated at 2022-06-24 10:05:00.109018
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from sys import version_info
    from time import sleep
    from re import findall
    from requests import Session
    from multiprocessing import Process
    from os import getenv
    from ..tqdm import tqdm
    api = 'https://api.telegram.org/bot'
    chat_id = "1"
    token = "1"


# Generated at 2022-06-24 10:05:05.925699
# Unit test for function trange
def test_trange():
    """Test trange."""
    n = 10
    t1 = trange(n, token='{token}', chat_id='{chat_id}')
    t2 = tqdm(range(n), token='{token}', chat_id='{chat_id}')
    for i1, i2 in zip(t1, t2):
        assert i1 == i2
    t1.close()
    t2.close()


if __name__ == "__main__":
    from sys import argv
    from time import sleep

    def main():
        """Main function."""
        test_trange()

    if len(argv) > 1:
        main()
    else:  # pragma: no cover
        while True:
            main()
            sleep(5)

# Generated at 2022-06-24 10:05:12.560557
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    class tqdm_telegram_close(tqdm_telegram):
        def clear(self, *args, **kwargs):
            super(tqdm_telegram_close, self).clear(*args, **kwargs)
            self.close()

    for i in tqdm_telegram_close(range(10), token='731098577:AAFGSj6_O45EoOadYP0gx6b-vO9j_4Fz6_4', chat_id='674642972'):
        pass


test_tqdm_telegram_close()

# Generated at 2022-06-24 10:05:19.445801
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    # ttgrange instantiates a tqdm_telegram object
    # then adds defaults of leave as None and pos as 0
    # tqdm_telegram.close() looks for leave, if leave is None it looks for pos
    # this tests for the two cases where leave is None and pos is 0 and leave is not None and pos is 0
    ttgrange(4).close()
    ttgrange(4, leave=True).close()

# Generated at 2022-06-24 10:05:24.959057
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    assert token and chat_id
    ti = TelegramIO(
        token=token,
        chat_id=chat_id)
    assert ti.message_id
    ti.write("hello world")

# Generated at 2022-06-24 10:05:35.319490
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from requests import Session
    from os import getenv
    from ..std import TqdmDeprecationWarning

    def test_clear(t):
        try:
            t.close()
        except:
            pass

        s = Session()
        t = tqdm_telegram(range(10), session=s,
                          token=getenv('TQDM_TELEGRAM_TOKEN'),
                          chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'))
        t.clear()
        t.close()

        t = tqdm_telegram(range(10), session=s,
                          token=getenv('TQDM_TELEGRAM_TOKEN'),
                          chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'))

# Generated at 2022-06-24 10:05:36.410295
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    _ = tqdm_telegram(token='', chat_id='')

# Generated at 2022-06-24 10:05:44.390000
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import time
    from tqdm import trange
    from .utils_telegram import TelegramIO

    with TelegramIO('{token}', '{chat_id}') as io:
        with trange(10, bar_format='{bar} {r_bar} {n_fmt}', ncols=50,
                    file=io, miniters=10, mininterval=1.0, disable=False) as t:
            time.sleep(0.05)
            t.update(0)
            time.sleep(1)


if __name__ == '__main__':
    test_tqdm_telegram_clear()

# Generated at 2022-06-24 10:05:46.785023
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    x = TelegramIO(token='{token}', chat_id='{chat_id}')
    x.write('Hello World')
    x.write('How are you')
    x.delete()

# Generated at 2022-06-24 10:05:53.028753
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    TelegramIO(getenv('TQDM_TELEGRAM_TOKEN'), getenv('TQDM_TELEGRAM_CHAT_ID'))



# Generated at 2022-06-24 10:06:01.825328
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import sys
    #import requests
    #token = getenv('TQDM_TELEGRAM_TOKEN')
    #chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    tqdm_io = TelegramIO('Token', 'ChatID')
    assert tqdm_io.write('Testing')
    assert tqdm_io.write('Testing')
    assert tqdm_io.write('Testing')
    assert tqdm_io.text == 'Testing'
    #assert requests.post(TelegramIO.API + '%s/sendMessage' % token,
    #                     data={'text': '`' + tqdm_io.text + '`',
    #                           'chat_id': chat_id, 'parse_mode': 'MarkdownV2'}).json()['

# Generated at 2022-06-24 10:06:03.915843
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    """Unit test for method delete of class TelegramIO."""
    tgio = TelegramIO('{token}', '{chat_id}')
    tgio.delete()
    return tgio


# Generated at 2022-06-24 10:06:07.854908
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    text = "test_write"
    io = TelegramIO('1234567890:test', '1234567890')
    io.write(text)
    assert(io.token == '1234567890:test')
    assert(io.chat_id == '1234567890')
    assert(io.text == text)


# Generated at 2022-06-24 10:06:11.557224
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    try:
        for _ in tqdm_telegram([], bar_format='{l_bar}{bar}| {n_fmt}/{total_fmt} [{rate_fmt}{postfix}]',
                               total=1, leave=True):
            pass
    except Exception:
        return False
    return True

# Generated at 2022-06-24 10:06:16.503348
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from requests import Session
    from .utils_worker import MonoWorker, DEFAULT_SENTINEL

    class TelegramIO(MonoWorker):
        API = 'https://api.telegram.org/bot'

        def __init__(self, token, chat_id):
            super(TelegramIO, self).__init__()
            self.token = token
            self.chat_id = chat_id
            self.session = Session()
            self.text = self.__class__.__name__
            self.message_id

        @property
        def message_id(self):
            if hasattr(self, '_message_id'):
                return self._message_id

# Generated at 2022-06-24 10:06:19.132178
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    telegram_write_io = TelegramIO(token="", chat_id="")
    telegram_write_io.message_id = -1

    assert(telegram_write_io.write(s="test_tqdm")) == None


# Generated at 2022-06-24 10:06:24.534692
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    """
    $ pytest tqdm/contrib/telegram.py

    or

    $ python -c "import tqdm.contrib; tqdm.contrib.telegram.test_tqdm_telegram()"
    """
    # Smoke test
    with tqdm(total=10, token='{token}', chat_id='{chat_id}') as t:
        for i in range(10):
            t.update()

# Generated at 2022-06-24 10:06:33.614582
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import re
    import sys
    tg = TelegramIO('123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11', '123456789')
    assert tg.write('1') is None
    assert re.match(r'^\d+$', tg.message_id) is not None
    assert tg.write('2') is None
    assert tg.write('3\n') is None
    sys.stderr.flush()
    tg.close()
    try:
        tg.write('4')
    except AttributeError:
        pass
    else:
        assert False, 'AttributeError expected when closing'

# Generated at 2022-06-24 10:06:35.404043
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    telegramIO = TelegramIO(token="123", chat_id="567")

# Generated at 2022-06-24 10:06:39.736007
# Unit test for function trange
def test_trange():
    for _ in tqdm(trange(3), token='{token}', chat_id='{chat_id}'):
        pass


if __name__ == '__main__':
    from doctest import testmod
    testmod(verbose=True)

# Generated at 2022-06-24 10:06:41.231548
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    tqdm(token='token', chat_id='chat_id')

# Generated at 2022-06-24 10:06:48.036028
# Unit test for function trange
def test_trange():
    """
    Unit test for function `trange`.
    """
    try:
        token = getenv('TQDM_TELEGRAM_TOKEN')
        chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    except KeyError:
        return  # Telegram token and chat ID are unknown
    from time import sleep
    from requests import Session
    session = Session()
    with trange(5, token=token, chat_id=chat_id) as t:
        for i in t:
            sleep(1)
    res = session.post(
        'https://api.telegram.org/bot%s/deleteMessage' % token,
        data={'chat_id': chat_id, 'message_id': t.tgio.message_id}).json()

# Generated at 2022-06-24 10:06:55.961987
# Unit test for function trange
def test_trange():
    from ..utils import _decode
    with ttgrange(4, token='123456789:AAG90e14-0f8-40183D1DE-ABCDEF123456',
                  chat_id='@gittqdmtest') as t:
        for i in t:
            assert _decode(t.format_dict["desc"]) == "test_trange(): "
    # Test temination with error

# Generated at 2022-06-24 10:07:04.327765
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    '''Test for tqdm_telegram.clear'''
    import tqdm

    tqdm_inst = tqdm.contrib.telegram.tqdm(
        range(100), token='661724607:AAEMjDwM8YJyO_akgh_jKQFqr3qk5mZzOuA',
        chat_id='-1001238871345', mininterval=1)
    for i in tqdm_inst:
        tqdm_inst.clear()
        tqdm_inst.display()
        if i < 98:
            tqdm_inst.close()
            break

# Generated at 2022-06-24 10:07:07.982588
# Unit test for function trange
def test_trange():
    from .utils import _progbar
    from .utils_tests import sizeof_fmt
    out = ""
    with ttgrange(100) as pbar:
        for i in pbar:
            out += str(sizeof_fmt(i)) + "\n"
    assert out == _progbar(100), out[:500]

# Generated at 2022-06-24 10:07:09.811284
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    t = TelegramIO(token='432432', chat_id='432432')
    t.write('TEST_MESSAGE')
    assert t.text == 'TEST_MESSAGE'

# Generated at 2022-06-24 10:07:20.673275
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    try:
        from io import StringIO
    except ImportError:
        from io import BytesIO as StringIO
    import sys
    try:
        import mock
    except ImportError:
        from unittest import mock
    sys_stdout = sys.stdout
    sys.stdout = StringIO()
    test_token = "0123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZ012345678"
    test_chat_id = "123456789"
    ti = TelegramIO(test_token, test_chat_id)

    def side_effect(url, data):
        if url == TelegramIO.API + test_token + "/sendMessage":
            assert data['text'] == "`__init__`"
            assert data['chat_id'] == test_chat_id
           

# Generated at 2022-06-24 10:07:22.679402
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    tqdm_telegram(token='1', chat_id='1').display()

# Generated at 2022-06-24 10:07:26.548867
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    import os
    token = os.getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = os.getenv('TQDM_TELEGRAM_CHAT_ID')
    TelegramIO(token, chat_id)

# Generated at 2022-06-24 10:07:32.375599
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    if "CI" not in getenv("TRAVIS_BRANCH") and "APPVEYOR" not in getenv("CI"):
        assert False, "This is only to be run as a unit test in CI"
    token = "telegram_config_token"
    chat_id = "telegram_config_chat_id"
    # Erroneous token and chat_id are used on purpose to check exception handling
    test_object = TelegramIO(token, chat_id)
    assert test_object.delete() is not None

# Generated at 2022-06-24 10:07:36.811328
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    tt = tqdm_telegram(token='1097925556:AAE-oQiC2vj8WJ3qfNr1r38NcGNvOnxWjwA', chat_id='441713556', total=100)
    tt.close()
    assert hasattr(tt.tgio, '_message_id')

# Generated at 2022-06-24 10:07:48.703399
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from os import devnull
    from sys import stdout
    from tqdm.contrib.telegram import tqdm_telegram

    with open(devnull, 'w') as fout:
        with tqdm_telegram(total=0, file=fout) as pbar:
            pbar.close()

    with open(devnull, 'w') as fout:
        with tqdm_telegram(total=1, file=fout) as pbar:
            pbar.close()

    with tqdm_telegram(total=0) as pbar:
        pbar.close()

    with tqdm_telegram(total=1) as pbar:
        pbar.close()


# Generated at 2022-06-24 10:07:52.118603
# Unit test for function trange
def test_trange():
    """Tests range"""
    for _ in trange(10, token=getenv('TQDM_TELEGRAM_TOKEN'),
                    chat_id=getenv('TQDM_TELEGRAM_CHAT_ID')):
        pass

# Generated at 2022-06-24 10:07:56.338044
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import pytest
    with pytest.raises(Exception):
        TelegramIO(token='', chat_id='').write('test')
    with pytest.raises(Exception):
        TelegramIO(token='asd', chat_id='').write('test')
    with pytest.raises(Exception):
        TelegramIO(token='asd', chat_id='asd').write('test')

# Generated at 2022-06-24 10:08:05.346514
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from .tests_tqdm import pandas, unicode, time  # NOQA
    from .tests_tqdm import DiscreteTimer as Timer  # NOQA
    from .tests_tqdm import _range  # NOQA

    with pandas.option_context('display.max_rows', None, 'display.max_columns', None):  # NOQA
        # Test clear()
        with tqdm(total=10, unit='it', unit_scale=False) as pbar:
            pbar.display()
            pbar.clear()
            pbar.write('This is a message.')
            pbar.display()
            pbar.update(10)
            pbar.write('This is a message.')
            pbar.display()
            assert pbar.n == 10
            assert p

# Generated at 2022-06-24 10:08:11.361388
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    try:
        t = tqdm_telegram(
            iterable=range(100),
            token=getenv('TQDM_TELEGRAM_TOKEN'),
            chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'))
        with t:
            for _ in t:
                t.clear()
    except Exception as e:
        t.close()
        print(str(e), 'clearing test on class tqdm_telegram failed!')

# Generated at 2022-06-24 10:08:15.117684
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import urllib
    try:
        urllib.urlopen("https://api.telegram.org")
    except Exception:
        return
    from .utils_test import _test_display
    _test_display(tqdm_telegram, "tqdm_telegram")

# Generated at 2022-06-24 10:08:18.376823
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    f = tqdm_telegram(total=1)
    f.close()
    assert f.desc == ''
    assert f.dynamic_ncols


# Test whether '\r' can be printed (no newline)

# Generated at 2022-06-24 10:08:25.501063
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from .tests_tqdm import pretest_posttest, closing, closing_iter
    pretest_posttest(tqdm_telegram, "test", total=10, disable=True)
    pretest_posttest(tqdm_telegram, closing("test"),
                     total=10, disable=True)
    pretest_posttest(tqdm_telegram, closing_iter("test"),
                     total=10, disable=True)


if __name__ == '__main__':
    from doctest import testmod
    testmod(verbose=True)

# Generated at 2022-06-24 10:08:28.931096
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    try:
        TelegramIO(123456, 456123).delete()
    except Exception as e:
        pass
    else:
        raise Exception("Should raise error")



# Generated at 2022-06-24 10:08:32.495023
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    tg = TelegramIO('token', 'chat_id')
    assert tg.message_id is None

# Generated at 2022-06-24 10:08:38.603198
# Unit test for function trange
def test_trange():
    from tqdm._tqdm import _term_move_up
    try:
        with tqdm(total=30, leave=True, desc='A') as t:
            for i in range(10):
                t.update()
                _term_move_up()
    except Exception as e:
        raise type(e)(str(e) + '\n'
                      "Test tqdm.contrib.telegram.trange failed.\n"
                      "This probably means you do not have "
                      "'Telegram' installed.").with_traceback(e.__traceback__)

# Generated at 2022-06-24 10:08:41.905307
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    for token in [getenv('TQDM_TELEGRAM_TOKEN'), 'aaaaaaaaaaaaaaaaaaaaaaaaaa']:
        for chat_id in [getenv('TQDM_TELEGRAM_CHAT_ID'), '111222333']:
            io = TelegramIO(token, chat_id)
            io.delete()

# Generated at 2022-06-24 10:08:44.687528
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    with tqdm(total=1, token='{token}', chat_id='{chat_id}') as pbar:
        pbar.update()


if __name__ == "__main__":
    test_tqdm_telegram()

# Generated at 2022-06-24 10:08:47.760422
# Unit test for function trange
def test_trange():
    from time import sleep
    with ttgrange(4) as pbar:
        for i in range(4):
            sleep(1)
            pbar.update(1)

# Generated at 2022-06-24 10:08:57.368929
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange.
    Verifies that:
    - trange is a function
    - trange doesn't crash
    - trange outputs a
    """
    assert callable(trange)
    assert isinstance(trange(0), tqdm_telegram)


if __name__ == '__main__':
    from os import getenv

    tqdm(
        _range(1000),
        token=getenv('TQDM_TELEGRAM_TOKEN'),
        chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'))

# Generated at 2022-06-24 10:09:04.912909
# Unit test for function trange
def test_trange():
    """Test function `trange`."""
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if not (token and chat_id):
        from os import devnull
        from sys import stderr

# Generated at 2022-06-24 10:09:06.939032
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm(total=2)
    t.close()

# Generated at 2022-06-24 10:09:08.218921
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    # !!!!! NO UNIT TESTS !!!!!
    pass


# Generated at 2022-06-24 10:09:16.949952
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import sys
    import pytest
    from io import StringIO
    from tqdm._utils import _term_move_up
    progress = 0
    with StringIO() as f:
        with tqdm_telegram(total=100, file=f, unit='B', unit_scale=True,
                           miniters=1) as pbar:  # noqa: F841
            progress = 0
            while progress < 100:
                pbar.update(1)
                progress = pbar.n + 1
        value = f.getvalue()
        code = '\x1b[1A\x1b[2K'
        assert code in value.replace('\n', code)
        assert '\x1b[2A' not in value.replace('\n', '\x1b[2A')
       

# Generated at 2022-06-24 10:09:26.926344
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from time import sleep
    from urllib.parse import urlparse
    from random import randint
    from string import ascii_letters

    io = TelegramIO("token", "chat_id")
    io.text = ""  # force creation
    io.write("")  # force update
    io.write(ascii_letters + ascii_letters[::-1])
    io.write("")
    io.write(" ")
    io.write(" \n")
    io.write("   \n")
    io.write("\n")
    io.write("a")
    io.write("a")
    io.write("a")

# Generated at 2022-06-24 10:09:29.895897
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tgio = TelegramIO(token='1312313123', chat_id='2423423423')
    assert(tgio.write('test1') is None)


# Generated at 2022-06-24 10:09:36.086133
# Unit test for function trange
def test_trange():
    from .utils_test import verify_interactive_tqdm, verify_non_ascii
    for _ in trange(3, token='404249409', chat_id='523792414'):
        verify_interactive_tqdm(_)
        verify_non_ascii(_)


if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-24 10:09:40.922471
# Unit test for function trange
def test_trange():
    """
    Unit test for trange
    """
    with trange(10, token=getenv('TQDM_TELEGRAM_TOKEN'), chat_id=getenv('TQDM_TELEGRAM_CHAT_ID')) as t:
        for i in t:
            t.set_description("Description %i" % i)
            t.update(i)

# Generated at 2022-06-24 10:09:44.047269
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    pbar = tqdm_telegram(total=1)
    assert not pbar.total_seconds_elapsed

    # clear
    pbar.clear()

    # check
    assert not pbar.total_seconds_elapsed

# Generated at 2022-06-24 10:09:49.962567
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import time
    import tqdm as tqdm_std
    tgio = TelegramIO('<token>', '<chat_id>')
    tgio.write("")
    tgio.write("1")
    tgio.write("2")
    for i in tqdm_std.trange(10):  # NOQA
        tgio.write(str(i))
        time.sleep(1)
    tgio.delete()

# Generated at 2022-06-24 10:09:51.532503
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    TelegramIO('{token}', '{chat_id}')

# Generated at 2022-06-24 10:10:01.692589
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    """
    Unit test for method write of class TelegramIO.
    """
    import sys
    import random
    import pytest
    import threading
    if sys.version_info < (3,):
        pytest.skip("python2 is not supported", allow_module_level=True)

    tgio = TelegramIO(token='{token}', chat_id='{chat_id}')

    # Test that method write sends a message to telegram
    threading.Timer(1,
        lambda: tgio.write(tgio.text + '\n' + tgio.text)
    ).start()
    threading.Timer(2,
        lambda: tgio.write(tgio.text + '\n' + tgio.text)
    ).start()

# Generated at 2022-06-24 10:10:14.487861
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    def test_fields(fields):
        fmt = tqdm_telegram.format_dict.copy()
        fmt.update(fields)
        fmt['bar_format'] = fmt['bar_format'].replace(
            '<bar/>', '{bar:10u}').replace('{bar}', '{bar:10u}')
        message = tqdm_telegram.format_meter(**fmt)

# Generated at 2022-06-24 10:10:24.388293
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    tqdm1 = tqdm_telegram(leave=True, disable=False)
    tqdm2 = tqdm_telegram(leave=False, disable=False)
    tqdm3 = tqdm_telegram(leave=None, disable=False, pos=10)
    tqdm4 = tqdm_telegram(leave=None, disable=False, pos=0)
    tqdm5 = tqdm_telegram(disable=True)
    tqdm1.close()
    tqdm2.close()
    tqdm3.close()
    tqdm4.close()
    tqdm5.close()



# Generated at 2022-06-24 10:10:30.371727
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    try:
        import pytest
    except ImportError:
        return
    import os

    chat_id = os.getenv('TQDM_TELEGRAM_CHAT_ID', '-9999999')
    token = os.getenv('TQDM_TELEGRAM_TOKEN', '-9999999')
    t = TelegramIO(token=token, chat_id=chat_id)
    t.write('test start')
    assert t.write('test') is None, 'Telegram is not available'

    t.delete()
    from time import sleep
    sleep(5)
    t.write('test end')
    assert t.write('test') is None, 'Telegram is not available'

# Generated at 2022-06-24 10:10:33.764348
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tgio = TelegramIO('TOKEN', 'CHAT_ID')
    tgio.write('test')
    tgio.close()

# Generated at 2022-06-24 10:10:36.848907
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(total=None)
    t.close()


if __name__ == '__main__':
    from doctest import testmod
    testmod(verbose=2)

# Generated at 2022-06-24 10:10:38.495372
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    tqdm_telegram(token='token', chat_id='id', total=10)

# Generated at 2022-06-24 10:10:40.484100
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    with tqdm_telegram(total=100) as pbar:
        pbar.close()


# Generated at 2022-06-24 10:10:42.317134
# Unit test for function trange
def test_trange():
    from time import sleep
    from random import random
    with trange(10, token='123', chat_id='-123') as t:
        for i in t:
            sleep(random())

# Generated at 2022-06-24 10:10:49.273888
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    '''
    Testing method write of class TelegramIO
    '''
    import time
    import sys
    import pytest
    with pytest.raises(AttributeError):
        TelegramIO().write('')
    a = TelegramIO('1234567890ABCDEF', '1234567890')
    a.write('a')
    assert 'a' in a.text
    assert a.message_id is not None
    a.write('aaaa')
    assert 'aaaa' in a.text
    a.write('bbbb')
    assert 'bbbb' in a.text
    time.sleep(1)
    with pytest.raises(AttributeError):
        sys.stdout.write(a)

# Generated at 2022-06-24 10:10:56.345078
# Unit test for function trange
def test_trange():
    from .utils import _test_nested
    try:
        from urllib.parse import quote
    except ImportError:
        from urllib import quote
    from time import sleep
    try:
        from urllib.request import urlopen
    except ImportError:
        from urllib2 import urlopen
    try:
        from urllib.error import URLError
    except ImportError:
        from urllib2 import URLError
    with _test_nested() as (token, chat_id):
        url = 'https://api.telegram.org/bot%s/sendMessage?chat_id=%s&text=%s' % (
            token, quote(str(chat_id)), quote('test'))

# Generated at 2022-06-24 10:11:00.504886
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    import sys
    import time
    temp_tqdm_telegram = tqdm_telegram(range(1), leave=True, file=sys.stdout)
    temp_tqdm_telegram.display()
    None == temp_tqdm_telegram.close()
    time.sleep(1)
    temp_tqdm_telegram = tqdm_telegram(range(1), leave=False, file=sys.stdout)
    temp_tqdm_telegram.display()
    None == temp_tqdm_telegram.close()
    time.sleep(1)

# Generated at 2022-06-24 10:11:02.781062
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    with tqdm(total=10) as progress:
        progress.display = lambda **kwargs: None
        progress.display()

# Generated at 2022-06-24 10:11:07.241246
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    from time import sleep
    token = tqdm_auto.get_lock().getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = tqdm_auto.get_lock().getenv('TQDM_TELEGRAM_CHAT_ID')
    tgio = TelegramIO(token, chat_id)
    tgio.write("testing")
    sleep(3)
    tgio.delete()


# Generated at 2022-06-24 10:11:13.812418
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    with tqdm_telegram(total=2,
                       token='917042486:AAHAmYfNrrlJxHWGkO83oQ2iOt1_'
                             'yFmsogKc',
                       chat_id='819404984',
                       desc='Example') as pbar:
        pbar.update(0)  # event if it is 0
        pbar.update(0)
        pbar.update(1)
        pbar.update(1)

# Generated at 2022-06-24 10:11:21.501639
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    import random as r
    from .utils_telegram import get_test_env
    token, chat_id = get_test_env()
    from ._tqdm_gui import tgrange
    L = list(range(5))
    r.shuffle(L)
    sum(tqdm_telegram(L, token=token, chat_id=chat_id))
    sum(tqdm_telegram(L, token=token, chat_id=chat_id, leave=False))
    sum(tqdm_telegram(L, token=token, chat_id=chat_id, leave=True))
    sum(tqdm(L, token=token, chat_id=chat_id))
    sum(tgrange(10, token=token, chat_id=chat_id))

# Generated at 2022-06-24 10:11:26.329151
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    from .utils import TqdmDeprecationWarning
    warn("TelegramIO is deprecated in favour of tqdm_telegram().",
         TqdmDeprecationWarning)

    tg = TelegramIO('', '')
    assert tg.message_id is None
    assert tg.write("") is None

# Generated at 2022-06-24 10:11:37.283508
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from os import getenv
    from time import sleep
    from numpy import random
    from requests import Session
    from requests.models import Response
    from tqdm.contrib.telegram import tqdm_telegram
    from .utils_worker import MonoWorker

    class TelegramIO(MonoWorker):
        API = 'https://api.telegram.org/bot'

        def __init__(self, token, chat_id):
            super(TelegramIO, self).__init__()
            self.token = token
            self.chat_id = chat_id
            self.session = Session()
            self.text = self.__class__.__name__
            self.message_id

        @property
        def message_id(self):
            if hasattr(self, '_message_id'):
                return self

# Generated at 2022-06-24 10:11:46.011574
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    """Unit test for constructor of class tqdm_telegram"""
    t = tqdm_telegram('Loading...', token='token', chat_id='chat_id')
    t2 = tqdm_telegram('Loading...', token='token', chat_id='chat_id',
                    mininterval=0.1)
    assert t.token == t2.token
    assert t.chat_id == t2.chat_id
    assert t.mininterval == 0
    assert t2.mininterval == 0.1
    t.close()
    t2.close()

# Generated at 2022-06-24 10:11:54.019306
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm.auto import tqdm
    # Empty tqdm instance
    t = tqdm_telegram()
    # Test 1 & 2: display and update
    t.total = 1
    t.display()
    assert t._time.last_print_t == 0
    t.display()
    assert t._time.last_print_t > 0
    # Test 3: clear
    t.total = None
    t.clear()
    # Test 4: close
    t.close()

# Generated at 2022-06-24 10:11:58.715353
# Unit test for function trange
def test_trange():
    from .utils_test import compare_tqdm_to_telegram, _range
    from .utils_test import has_telegram_token_and_chat_id
    if has_telegram_token_and_chat_id():
        compare_tqdm_to_telegram(trange, _range)


if __name__ == '__main__':
    test_trange()