

# Generated at 2022-06-24 10:01:54.095015
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    with tqdm_telegram(total=10) as t:
        for i in range(10):
            t.update(1)
            time.sleep(0.3)


# Generated at 2022-06-24 10:01:57.272972
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    """Test method write of class TelegramIO"""
    tg = TelegramIO('token','chat_id')
    tg.write('test')
    tg.stop()

# Generated at 2022-06-24 10:02:08.858058
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    import re
    import tqdm
    import sys
    from os import environ
    from time import sleep
    if sys.version_info >= (3,):
        from urllib.request import urlopen
    else:
        from urllib import urlopen
    tqdm_telegram.close()
    tio = TelegramIO(token=environ.get('TQDM_TELEGRAM_TOKEN', ''),
                     chat_id=environ.get('TQDM_TELEGRAM_CHAT_ID', ''))
    tio.write('text')
    sleep(0.3)
    tio.delete()
    with open(__file__) as f:
        for i in tqdm.tqdm(f, tio=tio):
            sleep(1e-6)
    assert re

# Generated at 2022-06-24 10:02:13.242220
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tgio = TelegramIO('test', 'test')
    tgio._message_id = 'test'
    assert tgio.message_id == 'test'

    import pytest
    with pytest.warns(TqdmWarning):
        tgio.delete()



# Generated at 2022-06-24 10:02:18.584169
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from .telegram_test_token import TEST_TOKEN, TEST_CHAT_ID
    from .utils_test import tqdm_telegram_write

    # TODO: fix test
    return

    tqdm_auto.write(
        tqdm_telegram_write(TelegramIO(TEST_TOKEN, TEST_CHAT_ID)))

if __name__ == "__main__":
    test_TelegramIO_write()

# Generated at 2022-06-24 10:02:20.340547
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    for _ in tqdm(iterable, token='token', chat_id='chat_id', miniters=1):
        pass

# Generated at 2022-06-24 10:02:24.123806
# Unit test for function trange
def test_trange():
    with trange(2) as t:
        _ = t.write("Hello")
        assert t.n == 0
        t.update()
        assert t.n == 1
    assert t.n == 2

# Generated at 2022-06-24 10:02:26.306970
# Unit test for function trange
def test_trange():
    """Test for trange"""
    from .utils_testing import check_tqdm_basic_usecase
    check_tqdm_basic_usecase(trange)



# Generated at 2022-06-24 10:02:35.267121
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from sys import version_info
    from os import environ

    TQDM_TELEGRAM_TOKEN = environ.get('TQDM_TELEGRAM_TOKEN')
    TQDM_TELEGRAM_CHAT_ID = environ.get('TQDM_TELEGRAM_CHAT_ID')

    in_token = '<invalid>'
    in_chat_id = '<invalid>'

    if version_info[0] == 2:
        # Doctest doesn't work properly on PY2
        class XrangeMock(object):
            def __init__(self, x):
                self.x = x

            def __iter__(self):
                return self

            def next(self):
                if self.x > 0:
                    self.x -= 1
                    return self.x

# Generated at 2022-06-24 10:02:40.714921
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    tg = tqdm_telegram(range(10), token="dummytoken", chat_id="dummychatid")
    assert tg.close() == None
    tg2 = tqdm_telegram(range(10), token="dummytoken", chat_id="dummychatid", leave=True)
    assert tg2.close() == None
    tg3 = tqdm_telegram(range(10), token="dummytoken", chat_id="dummychatid", leave=False)
    assert tg3.close() == None

# Generated at 2022-06-24 10:02:54.083320
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import time
    import sys
    from tqdm import tqdm
    try:
        input = raw_input
    except NameError:
        pass
    for _ in tqdm_telegram(range(1), token='', chat_id='', desc='Unit testing',
                           bar_format='{desc}: {n_fmt}/{total_fmt} [{elapsed_s}'
                                      '/{remaining_s}, {rate_fmt}{postfix}]',
                           mininterval=1):
        time.sleep(0.01)
        if '--test_tqdm_telegram_clear' in sys.argv:
            tqdm.clear()

# Generated at 2022-06-24 10:03:01.904481
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    try:
        import requests  # NOQA
    except ImportError:
        return
    tgio = TelegramIO('{token}', '{chat_id}')
    assert tgio.write("")
    assert tgio.delete()

# Generated at 2022-06-24 10:03:10.686799
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    try:
        token = getenv('TQDM_TELEGRAM_TOKEN')
        chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    except:
        warn("TQDM_TELEGRAM_{TOKEN,CHAT_ID} env variables not set.",
             TqdmWarning, stacklevel=2)
        return

    telegram_io = TelegramIO(token, chat_id)
    f = telegram_io.submit(telegram_io.session.post, 
        telegram_io.API + '%s/sendMessage' % telegram_io.token,
        data={'text': '`' + telegram_io.text + '`', 'chat_id': telegram_io.chat_id,
        'parse_mode': 'MarkdownV2'})


# Generated at 2022-06-24 10:03:12.928714
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from .tests_telegram import _test_clear
    _test_clear(tqdm_telegram)

# Generated at 2022-06-24 10:03:22.242485
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from .utils import _read, _range
    r = _read(None, '', '', False)
    p = tqdm_telegram(total=None, leave=False, file=r,
                      token='', chat_id='', disable=True)
    assert r._has_screen()
    p.close()
    assert r._has_screen()

    p = tqdm_telegram(total=None, leave=False, file=r,
                      token='', chat_id='', disable=False)
    p.close()
    assert not r._has_screen()

    p = tqdm_telegram(total=None, leave=True, file=r,
                      token='', chat_id='', disable=False)
    p.close()
    assert r._has_screen()

    p = tqdm_

# Generated at 2022-06-24 10:03:33.712002
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm.contrib import telegram
    known_kwargs = {
        'total': 10000,
        'dynamic_ncols': True,
        'disable': False,
        'leave': False,
        'ncols': 0,
        'mininterval': 0.1,
        'miniters': None,
        'ascii': True,
        'desc': 'tqdm_telegram class method display check',
        'postfix': '',
        'unit': 'it',
        'unit_scale': False,
        'gui': None,
        'sp': '',
        'nested': False,
        'position': 0,
        'bar_format': None
    }
    with telegram.tqdm(reset=True) as tqdm_obj:
        tqdm_

# Generated at 2022-06-24 10:03:38.969379
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from unittest import main
    from tqdm.auto import tqdm
    from tqdm.contrib.telegram import TelegramIO

    def _test_TelegramIO_write():
        tg = TelegramIO(token='749540108:AAHH501P786L_n0s8WJzU6dCaUZD3CHqTx8', chat_id='664862091')
        tg.write('hello world')
        tg.close()

    tqdm(_test_TelegramIO_write())
    main()

# Generated at 2022-06-24 10:03:44.094581
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    iterable = [0, 1, 2, 3]

    token = ""
    chat_id = ""
    from tqdm.contrib.telegram import tqdm, trange

    for i in tqdm(iterable, token=token, chat_id=chat_id):
        x = i


# Generated at 2022-06-24 10:03:54.586916
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import sys
    import io
    import unittest

    def fake_print(*args, **kwargs):
        # disable output
        pass
    tqdm_telegram.write = fake_print
    sys.stdout = io.StringIO()
    test_tqdm = tqdm_telegram(
        iterable=1,
        desc="test_tqdm",
        ascii=True,
        mininterval=0,
        miniters=1,
        unit=" bytes",
        mininterval=0.002)
    test_tqdm.n = 10
    test_tqdm.total = 100
    test_tqdm.update_to(test_tqdm.n)
    assert test_tqdm.display() == None
    sys.stdout = sys.__stdout

# Generated at 2022-06-24 10:04:00.316969
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import sys
    tokens = sys.argv[1:]
    if tokens:
        tg = TelegramIO(tokens[0], tokens[1])
        for i in range(4):
            tg.write("Test %d" % i)
        tg.delete()
        tg.write("Test X")


if __name__ == "__main__":
    test_TelegramIO_write()

# Generated at 2022-06-24 10:04:09.984909
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    class msgIO:
        def __init__(self, msg):
            self.msg = msg
        def pprint(self):
            return self.msg
    with tqdm(total=1, unit_scale=0, dynamic_ncols=True,
              bar_format='{desc}: {percentage:3.0f}%|{bar}|',
              disable=False, leave=False) as progress:
        progress.write('Hi')
        progress.set_description(msgIO('Hello'))
        progress.update()
        progress.close()

# Generated at 2022-06-24 10:04:22.108981
# Unit test for function trange
def test_trange():
    """Test module"""
    with trange(10, token='861649273:AAH_IFrUxIr__cJnTzUsdTb8pvn_7G9X56E',
                chat_id='172849124') as t:
        for i in t:
            t.set_description("Description")
            t.set_postfix({"key": "value", "key2": i})
            pass
    trange(10, token='861649273:AAH_IFrUxIr__cJnTzUsdTb8pvn_7G9X56E',
           chat_id='172849124', leave=True)

# Generated at 2022-06-24 10:04:27.435399
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """Test for method close of class tqdm_telegram."""
    t = tqdm_telegram(disable=True, leave=False, pos=0)
    t.disable = False
    t.close()
    t.disable = False
    t.leave = True
    t.close()
    t.disable = False
    t.leave = None
    t.pos = 1
    t.close()


if __name__ == '__main__':
    import doctest
    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-24 10:04:31.478716
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm._utils import _term_move_up
    from tqdm.auto import tqdm

    # Test if a call of clear() works without error
    with tqdm(total=3) as pbar:
        _term_move_up()
        pbar.clear()
        pbar.clear()
        _term_move_up()
        pbar.clear()
        _term_move_up()

# Generated at 2022-06-24 10:04:40.974175
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    # create tqdm_telegram instance with leave=True
    t = tqdm_telegram(range(10), bar_format='{bar}', leave=True)
    t.update(1)
    t.close()
    # create tqdm_telegram instance with leave=True, pos=0
    t = tqdm_telegram(range(10), bar_format='{bar}', leave=True, pos=0)
    t.close()
    # create tqdm_telegram instance with leave=False, pos=0
    t = tqdm_telegram(range(10), bar_format='{bar}', leave=False, pos=0)
    t.close()
    # create tqdm_telegram instance with leave=False, pos=1

# Generated at 2022-06-24 10:04:42.624291
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    """Unit test for constructor of class TelegramIO"""
    TelegramIO('_not_a_token_',
               '_not_a_chat_id_')

# Generated at 2022-06-24 10:04:51.590220
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    class FakeStr(str):
        def __init__(self, s=''):
            self.i = 0
            super(FakeStr, self).__init__(s)

        def join(self, l):
            assert type(l) is list
            return (str(self.i) + ':' + ''.join(map(str, l))
                    if self.i == 1 or len(l) != 0 else '')

    with tqdm_telegram(iterable=list(range(10)), disable=True,
                       bar_format=FakeStr()) as t:
        for i in t:
            assert t.format_dict['bar_format'] == '{l_bar}{bar:10u}{r_bar}'

# Generated at 2022-06-24 10:05:01.274656
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    class MockTelegramIO(TelegramIO):
        """Mock TelegramIO"""
        def __init__(self, *args, **kwargs):
            super(MockTelegramIO, self).__init__(*args, **kwargs)
            self.messages = []
        def write(self, s):
            self.messages.append(s)

    def assert_substr_in(substr, messages):
        for message in messages:
            if substr in message:
                return
        raise AssertionError("%s not found in %s" % (substr, messages))

    progress = tqdm_telegram(total=5, desc='Test message', leave=False,
                             disable=True, unit='it', unit_scale=False)

# Generated at 2022-06-24 10:05:11.402005
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from time import sleep
    from signal import signal, SIGINT
    def catch_signal(*_):
        signal(SIGINT, catch_signal)  # reinstall signal handler
        raise KeyboardInterrupt()
    signal(SIGINT, catch_signal)  # quit on Ctrl+C
    token = getenv('TQDM_TEST_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TEST_TELEGRAM_CHAT_ID')
    if not (token and chat_id):
        raise ImportError("You need to setup environment variables: "
                          "TQDM_TEST_TELEGRAM_TOKEN, "
                          "TQDM_TEST_TELEGRAM_CHAT_ID")
    tgio = TelegramIO(token, chat_id)
   

# Generated at 2022-06-24 10:05:22.244171
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    # Check for absence of required parameters
    try:
        tqdm_telegram()
    except TypeError:
        pass
    else:
        raise Exception('tqdm_telegram failed!')

if __name__ == '__main__':
    from multiprocessing import freeze_support
    from time import sleep
    try:
        freeze_support()
    except NameError:
        pass

    total = 10

    # test that the original implementation functions
    with tqdm(total=total) as progressbar:
        for i in range(total):
            sleep(0.1)
            progressbar.update()

    # test that the Telegram implementation functions
    with tqdm_telegram(total=total) as progressbar:
        for i in range(total):
            sleep(0.1)
            progressbar.update

# Generated at 2022-06-24 10:05:25.681484
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    pass

# Generated at 2022-06-24 10:05:28.657912
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    token = '12345:abcdef'
    chat_id = '54321'
    io = TelegramIO(token, chat_id)
    io.write('foo')
    io.delete()

# Generated at 2022-06-24 10:05:39.068096
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """Unit test for method close of class tqdm_telegram"""
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')

    # test leave=False (default)
    with tqdm_telegram(range(10), token=token, chat_id=chat_id):
        pass
    # test leave=True
    with tqdm_telegram(range(10), token=token, chat_id=chat_id, leave=True):
        pass
    # test leave=None pos=0
    with tqdm_telegram(range(10), token=token, chat_id=chat_id, leave=None):
        pass
    # test leave=None pos=1

# Generated at 2022-06-24 10:05:48.371499
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    """Test the method delete of TelegramIO"""

    class TestException(Exception):
        pass

    class TestSession(object):
        def __init__(self):
            self.deleted = False

        def post(self, url, data):
            if url == TestTelegramIO.API + TestTelegramIO.token + \
                    '/deleteMessage':
                if data['chat_id'] == TestTelegramIO.chat_id and \
                        data['message_id'] == TestTelegramIO.message_id:
                    self.deleted = True
                else:
                    raise TestException('call with incorrect parameters')
            else:
                raise TestException('call with incorrect url')

    class TestTelegramIO(TelegramIO):
        def submit(self, func, *args, **kwargs):
            return func(*args, **kwargs)



# Generated at 2022-06-24 10:06:00.110704
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from os import getenv
    from .tests_telegram import token, chat_id

    assert tqdm_telegram(disable=True)
    assert tqdm_telegram(token=token, chat_id=chat_id)
    assert tqdm_telegram(token=token, chat_id=chat_id).tgio.message_id
    assert not tqdm_telegram().disable
    assert tqdm_telegram(token=token, chat_id=chat_id).disable
    assert not tqdm_telegram(token=token, chat_id=chat_id).tgio.message_id
    assert tqdm_telegram().disable
    assert tqdm_telegram(token=token + ' ', chat_id=chat_id).disable

# Generated at 2022-06-24 10:06:01.761065
# Unit test for function trange
def test_trange():
    from .tests_telegram import test_trange
    test_trange(trange)

# Generated at 2022-06-24 10:06:03.446197
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    io = TelegramIO("", "")
    io.submit(io.delete)

# Generated at 2022-06-24 10:06:06.726800
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    try:
        with tqdm(total=10, token='37393732:q3jq3ghjfhjf34',
                  chat_id=24243242) as pbar:
            for _ in pbar:
                pass
    except Exception as e:
        pass

# Generated at 2022-06-24 10:06:11.730121
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    import os
    import sys

    token = os.environ['TQDM_TELEGRAM_TOKEN']
    chat_id = os.environ['TQDM_TELEGRAM_CHAT_ID']

    for i in _range(3):
        m = TelegramIO(token, chat_id)
        m.write('this is a test ' + str(i))
        m.delete()

    return True


if __name__ == '__main__':
    sys = test_TelegramIO_delete()

# Generated at 2022-06-24 10:06:18.402895
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    # Test with token/chat_id
    try:
        tqdm_telegram(iter('12345'), token="123", chat_id="321")
    except KeyError:
        pass
    else:
        raise ValueError("tqdm_telegram did not raise KeyError for invalid API response")

    # Test with no token/chat_id
    tqdm_telegram(iter('12345'))

    # Test token/chat_id from environment
    with tqdm_auto.set_slower_interval(1e-9):
        tqdm_telegram(iter('12345'), token=None, chat_id=None)

# Generated at 2022-06-24 10:06:23.971058
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    tt = tqdm_telegram(token=getenv('TQDM_TELEGRAM_TOKEN'),
                       chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'))
    tt.total = 100
    tt.n = 50
    tt.display()
    tt.close()

if __name__ == '__main__':
    test_tqdm_telegram_display()

# Generated at 2022-06-24 10:06:28.858305
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    @tqdm_telegram(token='812695087:AAFwdDdAH7Ae-W8gv3lJmXrgNFd7QmO6ZR4',
                   chat_id='-1001489307602', total=10)
    def foo():
        for i in range(10):
            yield i
    list(foo())

# Generated at 2022-06-24 10:06:30.379263
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    assert TelegramIO('token', 'chat_id').message_id is None

# Generated at 2022-06-24 10:06:34.294907
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t=tqdm_telegram(disable=True)
    assert t.disable == True
    t.close()


# Generated at 2022-06-24 10:06:37.312456
# Unit test for function trange
def test_trange():
    """
    >>> for i in trange(4, token='{token}', chat_id='{chat_id}'):
    ...     sleep(.1)
    """
    pass


if __name__ == "__main__":
    import doctest
    doctest.testmod(verbose=True, optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-24 10:06:39.062284
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    for _ in tqdm(iterable=range(10), token='', chat_id=''):
        pass

# Generated at 2022-06-24 10:06:46.928194
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    try:
        from requests.exceptions import ConnectionError
    except ImportError:
        return
    text = "test_TelegramIO_write_text"
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if not token or not chat_id:
        return

    class DummySession(object):
        def __init__(self):
            self.text = ''
            self.error = None

        def post(self, url, data):
            if self.error:
                raise self.error
            self.text = data['text']
            return DummyResponse()

    class DummyResponse(object):
        def json(self):
            return {'result': {'message_id': 1}}

    dummy

# Generated at 2022-06-24 10:06:58.333503
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import random
    import string

    token, chat_id = getenv('TQDM_TELEGRAM_TOKEN'), getenv('TQDM_TELEGRAM_CHAT_ID')
    if not (token and chat_id):
        warn("Environment variables 'TQDM_TELEGRAM_TOKEN' and 'TQDM_TELEGRAM_CHAT_ID' not found.", TqdmWarning)
        return

# Generated at 2022-06-24 10:07:04.208075
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    """Unit test for constructor of class tqdm_telegram"""
    def constructor(*args, **kwargs):
        try:
            tqdm_telegram(*args, **kwargs)
        except TypeError as e:
            raise e

    constructor(range(10), token='123456789:ABCDEFG')
    constructor(range(10), chat_id='123456789')

    with tqdm_telegram(range(10)) as _:
        pass

# Generated at 2022-06-24 10:07:10.185305
# Unit test for function trange
def test_trange():
    from time import sleep
    list(tqdm(ttgrange(2)))
    list(tqdm(ttgrange(2), mininterval=0))
    list(tqdm(ttgrange(9), mininterval=0, leave=True))
    list(tqdm(ttgrange(9), desc='1st loop', mininterval=0, leave=True))
    sleep(1.5)
    list(tqdm(ttgrange(9), desc='2nd loop', mininterval=0, leave=True))
    list(tqdm(ttgrange(9), desc='3rd loop', mininterval=0, leave=False))

# Generated at 2022-06-24 10:07:13.628704
# Unit test for function trange
def test_trange():
    import time
    from nose.tools import assert_equal
    from .telegram import trange
    for i in trange(3):
        time.sleep(.1)
    assert_equal(i, 2)

# Generated at 2022-06-24 10:07:17.964860
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    x = TelegramIO("test_token", "test_id")
    assert (x.message_id == None)
    x.write("a")
    assert (x.message_id != None)
    x.write("b")
    assert (x.message_id != None)


# Generated at 2022-06-24 10:07:23.909772
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from .tests_tqdm import pretest_posttest_printing

    token = getenv('TQDM_TELEGRAM_TOKEN')
    if not token:
        raise SystemExit("Please set the environment variable "
                         "TQDM_TELEGRAM_TOKEN")

    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if not chat_id:
        raise SystemExit("Please set the environment variable "
                         "TQDM_TELEGRAM_CHAT_ID")

    with pretest_posttest_printing():
        tqdm_telegram(_range(10), token=token, chat_id=chat_id).clear()

# Generated at 2022-06-24 10:07:32.888482
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    try:
        token = getenv('TQDM_TELEGRAM_TOKEN')
        chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    except Exception as e:
        msg = 'Error: could not get Telegram credentials from environment variables.'
        raise RuntimeError(msg)
    try:
        import requests
    except ImportError:
        return
    try:
        s = TelegramIO(token, chat_id)
        s.write('test')
        assert 'test' in s.session.post(s.API + '%s/getUpdates' % s.token).json()
    finally:
        try:
            s.delete()
            s.__exit__(None, None, None)
        except Exception:
            pass



# Generated at 2022-06-24 10:07:35.805460
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    import time

    for i in tqdm_telegram(range(5), token='1234', chat_id='0', leave=True):
        time.sleep(0.5)



# Generated at 2022-06-24 10:07:42.655878
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import re
    from tqdm import tqdm
    # Sample 1: most basic functionality
    for i in tqdm_telegram(
            _range(10), desc="Test 1", disable=True,
            token="1234567890:ABCDEF", chat_id="1234567890"):
        pass
    # Sample 2: bar_format
    for i in tqdm_telegram(
            _range(10), desc="Test 2", disable=True,
            token="1234567890:ABCDEF", chat_id="1234567890",
            bar_format="{l_bar}{bar}{r_bar}"):
        pass
    # Sample 3: bar_format and format_dict

# Generated at 2022-06-24 10:07:52.515536
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    """Unit test for method clear of class tqdm_telegram"""
    # Note: below is the correct way to import in windows, while downgrading to
    # module level imports can cause bugs
    from tqdm import tnrange
    from tqdm.contrib.telegram import ttgrange
    for j in tnrange(4):
        for tqdm_cls in (ttgrange,
                         tqdm_telegram):
            with tqdm_cls(range(2)) as t:
                for i in t:
                    if i == 1:
                        t.clear()

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 10:07:56.647818
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    TelegramIO(token='token', chat_id='chat_id').delete()

# Generated at 2022-06-24 10:08:05.452043
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    global TelegramIO
    import unittest
    import responses
    token = '123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZ123456789'
    chat_id = '12345'
    message_id = '12345'

    class TestTelegramIOWrite(unittest.TestCase):
        """Unit tests for the `TelegramIO.write` method"""

        def setUp(self):
            self.uut = TelegramIO(token, chat_id)
            self.uut._message_id = message_id


# Generated at 2022-06-24 10:08:08.564410
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    from nose.tools import nottest
    from tqdm.auto import trange

    with nottest():
        for i in trange(10, token='915703621:AAERUvJMX1mW4pDlguGpAFPb79P_nA3qBgk', chat_id='-1001294018062'):
            pass



# Generated at 2022-06-24 10:08:16.545111
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    class _tqdm_telegram(tqdm_telegram):
        def __init__(self, *args, **kwargs):
            self.disable = True
            self.leave = False
            self.pos = 1
    T = _tqdm_telegram('test')
    T.close()
    T.leave = True
    T.close()

if __name__ == '__main__':
    from doctest import testmod
    testmod(verbose=True)

# Generated at 2022-06-24 10:08:19.115601
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    telegram_io_obj = TelegramIO(token='token', chat_id='chat_id')
    future = telegram_io_obj.delete()
    if future is not None:
        future.result()

# Generated at 2022-06-24 10:08:23.598374
# Unit test for function trange
def test_trange():
    from ..utils import _sys
    from time import sleep
    with trange(5, token=_sys.argv[1], chat_id=_sys.argv[2]) as t:
        for i in t:
            sleep(0.05)


if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-24 10:08:29.424434
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    with tqdm_telegram([i for i in range(100)], total=100) as pbar:
        for i in range(100):
            pbar.update()
            if i % 10 == 0:
                pbar.clear()

# Generated at 2022-06-24 10:08:39.212209
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import requests
    import random
    import string
    import os
    token = os.environ.get('TQDM_TELEGRAM_TOKEN')
    chat_id = os.environ.get('TQDM_TELEGRAM_CHAT_ID')
    if token is None or chat_id is None:
        print("Warning: TQDM_TELEGRAM_TOKEN and TQDM_TELEGRAM_CHAT_ID \
              environment variables not found. Skipping test_TelegramIO_write ...")
    else:
        randomString = ''.join(random.choice(string.ascii_letters) for i in range(10))
        print('Using token %s and chat_id %s' % (token, chat_id))

# Generated at 2022-06-24 10:08:41.509718
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    pbar = tqdm(range(10), token = 'token', chat_id = 'chat_id')
    for _ in pbar:
        pbar.n += 1
        pbar.refresh()
        pbar.clear()

# Generated at 2022-06-24 10:08:49.134319
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    """
    Sample script to manually test `tqdm.contrib.telegram.__init__.TelegramIO`
    """
    import os
    token = os.getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = os.getenv('TQDM_TELEGRAM_CHAT_ID')
    TelegramIO(token, chat_id)

# Generated at 2022-06-24 10:08:59.823370
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    # Test `token` must be given
    try:
        TelegramIO(chat_id="0")
    except TypeError:
        pass
    else:
        raise AssertionError(
            "`token` is not required in `TelegramIO`").with_traceback()

    # Test `chat_id` must be given
    try:
        TelegramIO(token="0")
    except TypeError:
        pass
    else:
        raise AssertionError(
            "`chat_id` is not required in `TelegramIO`").with_traceback()



# Generated at 2022-06-24 10:09:04.766594
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    for _ in trange(1, token='{token}', chat_id='{chat_id}', mininterval=1, miniters=1):
        pass

# Generated at 2022-06-24 10:09:13.188602
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(["abc", "def", "ghi"], total=3,
        token='985460290:AAG9yxhvSNgJyy3LKj2IxH0SjvY8Wg3q3LA',
        chat_id='1156556375')

    # Asserts for close of class tqdm_telegram
    assert t.leave is None
    t.close()
    assert t.leave is None

    # Asserts for close of class tqdm_telegram

# Generated at 2022-06-24 10:09:20.375580
# Unit test for function trange
def test_trange():
    def testit(a, b):
        ttgrange(a, b).close()
    tgrange = ttgrange
    testit(10, 1000000)
    testit(10, 1000000)
    testit(10, 10000000)
    testit(10, 10000000)
    testit(10, 100000)
    testit(0, 0)
    testit(0, 0)


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 10:09:23.319594
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    import os
    assert bool(os.environ.get('TQDM_TELEGRAM_TOKEN'))
    assert bool(os.environ.get('TQDM_TELEGRAM_CHAT_ID'))
    ti = TelegramIO(os.environ['TQDM_TELEGRAM_TOKEN'],
                    os.environ['TQDM_TELEGRAM_CHAT_ID'])
    ti.write('test')
    ti.delete()
    ti.clear()

# Generated at 2022-06-24 10:09:32.792723
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    "Tests clearing of telegram message"
    import multiprocessing
    from getpass import getuser
    from time import sleep
    if not getenv('TQDM_TELEGRAM_TEST'):
        return
    # make sure there's no errors in tqdm/tqdm_gui/tqdm_telegram packages
    from ..utils import _range, format_interval, format_sizeof
    from .gui import tqdm_gui
    from .telegram import tqdm_telegram

    sleep(1)  # sleep for a few seconds to make sure user has read above

    tqdm_auto.write("Testing clearing of Telegram message...")
    token = "123456789:ABC-DEF1234ghIkl-zyx57W2v1u123ew11"

# Generated at 2022-06-24 10:09:41.608068
# Unit test for function trange
def test_trange():
    with tqdm(total=10, token=getenv('TQDM_TELEGRAM_TOKEN'),
              chat_id=getenv('TQDM_TELEGRAM_CHAT_ID')) as pbar:
        for i in range(10):
            pbar.update()
    with tqdm(total=10, unit='B', token=getenv('TQDM_TELEGRAM_TOKEN'),
              chat_id=getenv('TQDM_TELEGRAM_CHAT_ID')) as pbar:
        for i in range(10):
            pbar.update(5 * i + 1)


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 10:09:42.824828
# Unit test for function trange
def test_trange():
    for _ in trange(10):
        ...

# Generated at 2022-06-24 10:09:49.728234
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from os import getenv as env
    from os import unsetenv as unset
    from sys import version_info
    from time import sleep
    from traceback import format_exc


# Generated at 2022-06-24 10:09:59.489669
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    import sys
    counters = [1, 5, 10]
    tokens = ['', '{token}']
    chat_ids = ['', '{chat_id}']
    old_stderr = sys.stderr

# Generated at 2022-06-24 10:10:05.152961
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    token = "1"
    chat_id = "2"
    test = TelegramIO(token, chat_id)
    assert test.token is token
    assert test.chat_id is chat_id
    assert test._message_id is None
    test.write("")
    assert test._message_id is not None

# Generated at 2022-06-24 10:10:13.155085
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    try:
        import pytest
    except ImportError:
        warn('Could not import pytest, skipping test', TqdmWarning)
        return
    # Test string format display
    bf = '{l_bar}{bar:10u}{r_bar}'
    kwargs = {'disable': True, 'bar_format': bf}
    tg = tqdm_telegram(**kwargs)
    # Test generate bar_format
    bar_format = tg.format_meter(**tg.format_dict)
    assert bar_format == bf
    # Test bar_format is unchanged
    bf2 = '{l_bar}{bar:10u}{r_bar}'
    kwargs = {'disable': True, 'bar_format': bf2}
    tg = tqdm_telegram

# Generated at 2022-06-24 10:10:15.703342
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    """Test method delete of class TelegramIO."""
    io = TelegramIO("token", "chat_id")
    io.write("test")
    io.delete()

# Generated at 2022-06-24 10:10:24.102532
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import json
    import requests
    import time
    import unittest
    token_test = 'some_token'
    chat_id_test = 'some_chat_id'
    io = TelegramIO(token_test, chat_id_test)
    io.write('some text')
    if hasattr(io, '_message_id') and io._message_id is not None:
        req_str = io.API + token_test + '/deleteMessage?chat_id=' + chat_id_test + '&message_id=' + str(io._message_id)
        requests.post(req_str)
    io.write('some text')

# Generated at 2022-06-24 10:10:27.286389
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    for leave in [None, True, False]:
        for pos in [0, 1, 2]:
            t = tqdm_telegram(total=3, leave=leave, pos=pos, disable=True)
            t.close()

# Generated at 2022-06-24 10:10:38.196867
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from io import StringIO
    from random import randint
    from tqdm import _bool_or_str, _term_move_up, _term_move_down, _term_width
    from tqdm.auto import tqdm as _tqdm, trange as _trange, TMonitor
    from tqdm.contrib.telegram import tqdm, trange

    # Main test
    for token in ['test_token', None]:
        for chat_id in ['test_chat_id', None]:
            with TMonitor(False, token=token, chat_id=chat_id) as t:
                with tqdm(total=1) as pbar:
                    pass
                assert t.io.closed

# Generated at 2022-06-24 10:10:41.816372
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    io = TelegramIO('123', '123')
    io.message_id = '123'
    # io._message_id = 123  # Would cause _message_id to be hidden
    assert io.delete() is None
    io.close()

# Generated at 2022-06-24 10:10:48.897364
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from tqdm import tqdm_gui

    # Test token and chat_id is None
    tqdm_telegram(token=None, chat_id=None)
    # Test token is None
    tqdm_telegram(token=None, chat_id='123')
    # Test chat_id is None
    tqdm_telegram(token='qqq', chat_id=None)
    # Test both token and chat_id is not None
    with tqdm_gui(token='qqq', chat_id='456') as t:
        for i in ttgrange(10):
            pass


# Test of function ttgrange

# Generated at 2022-06-24 10:10:57.993909
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm.contrib.telegram import tqdm, trange
    import contextlib, io

    @contextlib.contextmanager
    def captured_output():
        new_out, new_err = io.StringIO(), io.StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        for i in tqdm(range(10), token="fake_token", chat_id="fake_chat_id"):
            pass
        assert "Successfully" in out.getvalue

# Generated at 2022-06-24 10:11:01.087553
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if not token or not chat_id:
        warn("TQDM_TELEGRAM_TOKEN and/or TQDM_TELEGRAM_CHAT_ID are not set.",
             TqdmWarning)
    TelegramIO(token, chat_id).write('TEST')

# Generated at 2022-06-24 10:11:07.959076
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if not (token and chat_id):
        return
    telegram = TelegramIO(token, chat_id)
    assert telegram.token == token
    assert telegram.chat_id == chat_id
    assert telegram.text == 'TelegramIO'
    assert telegram.message_id is not None
    telegram.write('test')
    assert telegram.text == 'test'
    telegram.write('test')
    assert telegram.text == 'test'
    telegram.close()

# Generated at 2022-06-24 10:11:17.742903
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from os import devnull
    from sys import stderr
    from subprocess import Popen, PIPE, call
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')

    with open(devnull, 'w') as fnull:
        if not all([token, chat_id]):
            print('WARNING: tqdm.contrib.telegram', file=stderr)
            print('   token=%r, chat_id=%r' % (token, chat_id), file=stderr)
            print('   Unable to test Telegram hook', file=stderr)
            return True


# Generated at 2022-06-24 10:11:28.331395
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    # case 1
    tgr = ttgrange(4, leave=True)
    tgr_close = tgr.close()
    assert tgr_close is None, 'test case 1 failed'
    # case 2
    tgr = ttgrange(4, leave=False)
    tgr_close = tgr.close()
    assert tgr_close is None, 'test case 2 failed'
    # case 3
    tgr = ttgrange(4, leave=None)
    tgr_close = tgr.close()
    assert tgr_close is None, 'test case 3 failed'
    # case 4
    tgr = ttgrange(0, leave=False)
    tgr_close = tgr.close()
    assert tgr_close is None, 'test case 4 failed'
    # case

# Generated at 2022-06-24 10:11:35.184057
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    # test_1
    def dummy_func_1():
        with tqdm(total=101) as pbar:
            for i in range(101):
                pbar.update(1)
    dummy_func_1()

    # test_2
    def dummy_func_2():
        with tqdm(total=0) as pbar:
            for i in range(101):
                pbar.update(1)
    dummy_func_2()

# Generated at 2022-06-24 10:11:38.391406
# Unit test for function trange
def test_trange():
    list(ttgrange(10))

# Generated at 2022-06-24 10:11:48.790266
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import io
    from threading import Thread
    from time import sleep
    from queue import Queue
    from unittest import TestCase

    class tqdm_telegram_display_test(TestCase):
        """
        Unit test for `tqdm_telegram`'s `display` method.
        """
        @staticmethod
        def test_display(q):
            """
            Tests the `display` method of `tqdm_telegram` by showing a progress
            bar for 5 seconds and ending with a completed progress bar.
            """
            iotest = io.StringIO()
            with tqdm(total=1000, file=iotest) as t:
                for i in tqdm(range(1, 101)):
                    sleep(0.05)
                    t.update()


# Generated at 2022-06-24 10:12:00.075590
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    # pylint: disable=unused-variable
    from os import getenv
    from time import sleep
    from warnings import warn
    # pylint: enable=unused-variable

    def warning_format(message, category, filename, lineno, line=None):
        return (str(message) + '\n')

    warn('', TqdmWarning, warning_format, 0)  # clear warnings

    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')

    if token is None:
        raise ValueError("Please set the TQDM_TELEGRAM_TOKEN env variable.")