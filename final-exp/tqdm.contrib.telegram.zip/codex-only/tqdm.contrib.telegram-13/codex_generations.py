

# Generated at 2022-06-24 10:02:00.383670
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    """Unit test for method write of class TelegramIO"""
    tg_token = input("Token of Telegram bot: ")
    chat_id = input("Chat ID: ")
    text = input("Text to display: ")
    tgio = TelegramIO(tg_token, chat_id)
    tgio.write(text)

if __name__ == '__main__':
    # test_TelegramIO_write()
    from time import sleep
    from random import random

    for i in tqdm(ttgrange(10), token='705947027:AAHYjI4e4a9X2HnL1tKgMtNNxSf4d4l_Fg0',
                   chat_id='603738161'):
        sleep(random())

# Generated at 2022-06-24 10:02:08.003133
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """ Unit tests for method close of class tqdm_telegram """
    with tqdm_telegram(total=10) as pbar:
        pbar.update()
    assert pbar.leave is True
    with tqdm_telegram(total=-10) as pbar:
        pbar.update()
    assert pbar.leave is False
    with tqdm_telegram(total=0) as pbar:
        pbar.update()
    assert pbar.leave is True

# Generated at 2022-06-24 10:02:17.457181
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    """Attention -- this test will post a message to a Telegram user!"""
    from os import getenv, unlink
    from os.path import isfile
    from tempfile import mkstemp
    from time import sleep

    from requests import codes
    from requests.exceptions import ConnectionError, SSLError

    token = "NOTOKEN"
    chat_id = "NOTCHAT"

    # Only run for when TQDM_TELEGRAM_TOKEN and TQDM_TELEGRAM_CHAT_ID are set.
    # In case of failure, this will prepend {token} and {chat_id} to the
    # following string so that the user can replace them:
    try:
        token = getenv("TQDM_TELEGRAM_TOKEN")
    except Exception:
        pass

# Generated at 2022-06-24 10:02:27.759468
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    # Working case
    tg = TelegramIO("my_token", "my_chat")
    m = tg.message_id
    a = tg.delete()
    b = tg.session.post(tg.API + '%s/deleteMessage' % tg.token,
                        data={'chat_id': tg.chat_id, 'message_id': m})
    assert a.result() == b.result()
    # "Chat not found" error case
    tg = TelegramIO("my_token", "my_chat_not_found")
    m = tg.message_id
    a = tg.delete()

# Generated at 2022-06-24 10:02:29.496638
# Unit test for function trange
def test_trange():
    assert trange(1)
    assert trange(1, 2)
    assert trange(1, 2, 3)

# Generated at 2022-06-24 10:02:35.742392
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if not (token and chat_id):
        warn("Token or chat_id or both undefined. Skipping test_tqdm_telegram_clear().",
             TqdmWarning, stacklevel=2)
    else:
        with tqdm_telegram(total=2, token=token, chat_id=chat_id) as t:
            t.update()
            t.clear()
            t.update()

# Generated at 2022-06-24 10:02:37.324481
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    tg = TelegramIO('token', 'chat_id').write('text')
    assert '"ok":true' in tg.result.text

# Generated at 2022-06-24 10:02:45.724149
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    '''
    Close method of tqdm_telegram sends the last output to the chat and deletes the bot message
    if leave=True and pos is not 0.
    '''
    try:
        import requests_mock
    except ImportError:
        warn("telegram tests require requests_mock to be installed", TqdmWarning)
        return

    with requests_mock.Mocker() as m:
        m.post("https://api.telegram.org/bot{token}/sendMessage".format(token='{token}'),
               text='{"result": {"message_id": "123"}}')

        m.post("https://api.telegram.org/bot{token}/editMessageText".format(token='{token}'),
               text='{"ok": "123"}')

        t = tqdm_telegram

# Generated at 2022-06-24 10:02:51.736451
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    try:
        from requests.exceptions import ConnectionError
        tg = TelegramIO('not_a_token', 'not_a_chat_id')
        tg.delete()  # should print the error in the console
        tg.tgio.delete()  # should fail
        assert ConnectionError  # pyflakes
    except ImportError:
        pass  # module 'requests' is not installed

# Generated at 2022-06-24 10:02:55.568024
# Unit test for function trange
def test_trange():
    """Test function `trange`."""
    try:
        list(tqdm(trange(3)))
    except Exception:
        list(tqdm(trange(3)))
    else:
        list(tqdm(trange(3)))

# Generated at 2022-06-24 10:03:00.575713
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    # Create a new message in the given `chat_id`
    io = TelegramIO(
        token = 'token',
        chat_id = 'chat_id')
    message_id = io.message_id

    # Replace internal `message_id`'s text with `s`
    io.write('s')
    assert io.text=='s'

    # Delete internal `message_id`
    io.delete()
    assert io.event_source.nr_uncaught_errors == 0

test_TelegramIO()

# Generated at 2022-06-24 10:03:07.751282
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from pytest import raises
    from requests.exceptions import ConnectionError
    from .utils import nocolor_range
    bad_token = TelegramIO('token', 'chat_id')
    # Check the error for a bad token
    with raises(ConnectionError):
        bad_token.write('message')


# Generated at 2022-06-24 10:03:09.080072
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    assert TelegramIO('a', 'b')

# Generated at 2022-06-24 10:03:13.769561
# Unit test for function trange
def test_trange():
    from time import sleep
    trange(1, token='0', chat_id='0')
    for _ in ttgrange(10, unit='custom unit', token='0', chat_id='0'):
        sleep(0.01)

if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 10:03:22.844180
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from unittest import main as start_test
    from .utils_test import TestCaseMixin, _io, _range

    class _TestDisplayWithTelegram(TestCaseMixin):
        tgrange = None  # type: _tgrange
        test_len = 10

        @classmethod
        def setUpClass(cls):
            super(_TestDisplayWithTelegram, cls).setUpClass()
            cls.tgrange = tqdm_telegram(_range(cls.test_len), file=_io.StringIO())
            cls.tgrange.start()

        def test_display(self):
            assert self.tgrange.format_dict['bar_format'] == '{l_bar}{bar:10u}{r_bar}'
            self.tgrange.update()

# Generated at 2022-06-24 10:03:30.944196
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    t = tqdm_telegram(None, token='', chat_id='', desc='my desc')
    t.display()
    t = tqdm_telegram(None, token='', chat_id='', desc=None)
    t.display()
    t = tqdm_auto(None, desc='my desc', disable=True)
    t.display()
    t = tqdm_telegram(None, token='', chat_id='', desc='my desc')
    t.format_dict = t.format_dict.copy()

# Generated at 2022-06-24 10:03:34.263294
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import time
    print('\nTEST TelegramIO.write')
    t = TelegramIO(token='', chat_id='')
    t.write('\nstart...')
    time.sleep(1)
    t.write('1 ...')
    time.sleep(1)
    t.write('2 ...')
    time.sleep(1)
    t.write('done.\n')

# Generated at 2022-06-24 10:03:36.353280
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(total=100, disable=True, leave=False)
    t.close()


# Generated at 2022-06-24 10:03:42.406752
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    import sys
    from ..tests.close_all import _close

    if '--test' not in sys.argv[1:]:
        return
    tgio = TelegramIO('--token--', '--chat-id--')
    tgio.message_id
    tgio.delete()
    _close(tgio)

# Generated at 2022-06-24 10:03:49.888534
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from . import _test_tqdm
    pbar = tqdm_telegram(total=10)
    _test_tqdm.test_clear(pbar)



# Generated at 2022-06-24 10:04:00.947898
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from nose.tools import assert_less
    from unittest import mock
    from requests.sessions import Session
    from urllib3.util.url import Url
    from urllib3.util import parse_url as parse

    kw = {
        'desc': 'something',
        'rate': 'something',
        'bar_format': '{l_bar}{bar}{r_bar}',
        'total': 1000,
        'postfix': 'something',
    }
    obj = tqdm_telegram(**kw)
    obj.tgio = mock.MagicMock(spec=TelegramIO)
    with mock.patch.object(
            Session, 'post', return_value=mock.MagicMock()
    ) as mock_post:
        obj.display(**kw)

# Generated at 2022-06-24 10:04:06.136420
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    token = '994220797:AAHPDsbzgOI-pYwzJd0jbpWKS8_fZgMfhGc'
    chat_id = '445959041'
    tgio = TelegramIO(token, chat_id)
    tgio.message_id
    tgio.write('deleteme')
    tgio.delete()
    # Nothing to do here

# Generated at 2022-06-24 10:04:17.442028
# Unit test for function trange
def test_trange():
    data = list(trange(5, unit="tests", sleep=0.5,
                       token=getenv('TQDM_TELEGRAM_TOKEN'),
                       chat_id=getenv('TQDM_TELEGRAM_CHAT_ID')))
    assert data == list(range(5))


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-24 10:04:19.634138
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    t = tqdm_telegram(total=1, disable=False)
    assert not t.n
    t.close()



# Generated at 2022-06-24 10:04:27.625730
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    import tqdm
    import time

    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if chat_id is None:
        raise Exception('Chat ID is not set')

    def test(leave=False):
        rng = tqdm.tqdm(tqdm.trange(5, desc='test', leave=leave, token=token, chat_id=chat_id))
        for i in rng:
            time.sleep(0.5)
        try:
            assert rng.tgio.futures.empty() and not rng.tgio.thread.is_alive()
        except:
            return rng

    return (test(False), test(None), test(True))

# Generated at 2022-06-24 10:04:33.398030
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tio = TelegramIO(token="test_token", chat_id="test_chat_id")
    tio.write("test")
    tio.delete()



# Generated at 2022-06-24 10:04:35.974133
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tgio = TelegramIO('<token>', '<chat_id>')
    tgio.write("Test")


# Generated at 2022-06-24 10:04:39.538540
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    # import requires
    import time
    # create instance
    t = tqdm_telegram(range(100))
    # invoke method in instance
    t.close()
    # assert file
    # see no errors in stdout (no tqdm messages)
    # time.sleep(3)

# Generated at 2022-06-24 10:04:44.936936
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    """
    Creates, deletes and check that the message is gone.
    """
    io = TelegramIO('{token}', '{chat_id}')
    io.message_id
    io.delete()
    assert io.message_id is None
    io.delete()
    assert io.message_id is None

if __name__ == "__main__":
    import time
    for i in tqdm(
            _range(1000),
            token='{token}', chat_id='{chat_id}',
            desc="test"):
        time.sleep(0.01)

# Generated at 2022-06-24 10:04:46.041715
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    assert TelegramIO('tk','ch').write('s') == None

# Generated at 2022-06-24 10:04:55.546409
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    io = TelegramIO(getenv('TQDM_TELEGRAM_TOKEN'),
                    getenv('TQDM_TELEGRAM_CHAT_ID'))
    assert io.message_id is not None
    io.write('大家好！')

# Generated at 2022-06-24 10:05:01.273673
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    if not os.environ.get('TQDM_TELEGRAM_TOKEN'):
        return
    progress = tqdm_telegram(range(1,20), token=os.environ['TQDM_TELEGRAM_TOKEN'], chat_id=os.environ['TQDM_TELEGRAM_CHAT_ID'])
    progress.clear()
    progress.close()


if __name__ == '__main__':
    from os import getenv
    ttgrange(int(getenv('TQDM_END', '100'))).close()

# Generated at 2022-06-24 10:05:07.878123
# Unit test for function trange
def test_trange():
    import time
    # We use the disable argument because don't want to spam the Telegram bot
    # while we are running the tests.
    with trange(2, disable=True) as t:
        for i in t:
            time.sleep(0.3)


# Wrapping function tqdm_telegram

# Generated at 2022-06-24 10:05:10.639187
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    with tqdm_telegram(disable=True) as t:
        assert t.disable
        t.close()


# Generated at 2022-06-24 10:05:17.977442
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if token and chat_id:
        tqdm(token=token, chat_id=chat_id, total=100, disable=False)
        tqdm(token=token, chat_id=chat_id, total=100, disable=True)

# Generated at 2022-06-24 10:05:22.406186
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    with tqdm_telegram(10) as t:
        t.display(**t.format_dict)
        t.clear(None)
        t.n = 10
        t.display(**t.format_dict)

# Generated at 2022-06-24 10:05:29.958609
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm.utils import _term_move_up
    from tqdm.std import StringIO
    from time import sleep

    f = StringIO()
    n = 80
    for i in tqdm_telegram(range(n), bar_format='{bar}', file=f):
        sleep(0.1)
    f.seek(0)
    assert len(f.read().splitlines()) == n + 2  # for terminal escape code
    assert _term_move_up + '\r' in f.getvalue()

# Generated at 2022-06-24 10:05:33.876953
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    io = TelegramIO('token', 'chat_id')
    io.write('Hello\n')
    io.write('World')
    io.write('!')


if __name__ == '__main__':
    from inspect import getdoc
    print(getdoc(TelegramIO))

# Generated at 2022-06-24 10:05:38.543485
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from .tests_telegram import test_tqdm_telegram_docstrings

    test_tqdm_telegram_docstrings()


if __name__ == "__main__":
    test_tqdm_telegram()

# Generated at 2022-06-24 10:05:45.492712
# Unit test for function trange
def test_trange():
    from io import BytesIO
    from .utils_telegram import token, chat_id
    s = BytesIO()
    for i in trange(10, token=token, chat_id=chat_id, file=s, mininterval=1e-6,
                    miniters=1, desc="test-trange"):
        pass
    assert str(s.getvalue()).endswith("100%|██████████| 10/10 [00:00<00:00, ?it/s]\n")



# Generated at 2022-06-24 10:05:52.421964
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    # Source: https://github.com/tqdm/tqdm/blob/cfb8ae7ab51d9a9f241cbbaf8e8c2afa59e416b0/tqdm/_tqdm_test.py#L115
    from io import BytesIO
    from tqdm.auto import tqdm, trange

    with tqdm(total=9,
              bar_format='{percentage:3.0f}% {bar}|',
              ncols=75, disable=False) as pbar:
        pbar.display()
        pbar.update()
        # with (BytesIO if PY2 else StringIO)() as our_file:

# Generated at 2022-06-24 10:05:56.498610
# Unit test for function trange
def test_trange():
    # Static trange
    with tqdm(total=10) as pbar:
        for i in pbar:
            time.sleep(0.1)
            if i == 5:
                pbar.set_postfix(i=6)
                break

# if __name__ == '__main__':
#     test_trange()

# Generated at 2022-06-24 10:06:02.321781
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import requests, sys
    from _tqdm_test_utils import comparison, pretest_posttest_test
    with comparison(tqdm_telegram, sys.stdout, total=10, ncols=20,
                    # print_steps=1, smoothing=0,
                    bar_format='{bar:10u}', desc='tqdm_telegram clear test') \
         as (bar1, bar2):
        for i in bar1:
            if i >= 5:
                bar1.clear()
                bar2.clear()
            bar1.update()
            bar2.update()
            if i >= 5:
                break
        for i in bar1:
            bar1.update()
            bar2.update()



# Generated at 2022-06-24 10:06:06.112426
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from .tests_telegram_token_chat_id import (token, chat_id)
    tgio = TelegramIO(token, chat_id)
    tgio.write("")
    tgio.write("")
    tgio.write("")
    tgio.close()


# Generated at 2022-06-24 10:06:13.152414
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    """Test for `TelegramIO.delete`.

    Warnings
    --------
    This does not actually delete a message.
    """
    t = TelegramIO('000000000:ABCDEFGHIJKLMNOPQRSTUVXZabcdefghi',
                   '123456789')
    assert t.delete() is not None


if __name__ == '__main__':  # pragma: no cover
    import json
    import time
    import sys

    url = 'https://api.telegram.org/bot'
    token, chat_id = sys.argv[1:]

# Generated at 2022-06-24 10:06:15.171163
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    io = TelegramIO("test_token", "test_chat_id")
    assert io.delete()
    # TODO: real testing for TelegramIO.delete()


# Generated at 2022-06-24 10:06:18.140992
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    for bar_format in ('{bar}', '{bar:10u}'):
        tqdm_telegram(
            bar_format=bar_format,
            token='0' * 34, chat_id='0' * 5).update()

# Generated at 2022-06-24 10:06:21.369794
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    with tqdm_telegram(total=2) as pbar:
        pbar.update()
        pbar.tgio.write('deleted')
        pbar.tgio.delete()

# Generated at 2022-06-24 10:06:29.224413
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    class TelegramIO_mock(TelegramIO):
        def __init__(self, token, chat_id):
            self.token = token
            self.chat_id = chat_id
            self.session = {'post': lambda *args, **kwargs: None}
    io = TelegramIO_mock(token='XXX', chat_id='YYY')
    io.write("")
    io.delete()

# Generated at 2022-06-24 10:06:32.264557
# Unit test for method delete of class TelegramIO

# Generated at 2022-06-24 10:06:43.382399
# Unit test for constructor of class tqdm_telegram

# Generated at 2022-06-24 10:06:48.173404
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    tf = TelegramIO('foobar', 'foobar')
    assert tf.message_id is None
    assert tf.write("hello") is None
    assert tf.delete() is None
    tf.close()
    assert tf.message_id is None

# Generated at 2022-06-24 10:06:56.127860
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    import sys
    from os import getenv

    from .utils_test import check, get_empty_bar, Systimer, init_worker

    tqdm_auto.write = \
        lambda *args, **kw: sys.stdout.write(str(args) + str(kw) + '\n')

    def _check(token, chat_id=None):
        init_worker()
        with Systimer() as t:
            with check(tqdm_telegram, token=token, chat_id=chat_id,
                       postfix="test") as tgr:
                tgr.write("...")
            assert t.interval >= 2.0
        init_worker()

# Generated at 2022-06-24 10:07:02.033565
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm import tqdm

    # update the TelegramIO attributes for the test
    tqdm(ascii=True, token=getenv('TQDM_TELEGRAM_TOKEN'),
         chat_id=getenv('TQDM_TELEGRAM_CHAT_ID')).display()


if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=True)  # pragma: no cover

# Generated at 2022-06-24 10:07:09.914657
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    def check_fmt(bar_format, l_bar, r_bar, bar, n_closings, n_openings,
                  n_bar, n_l_bar, n_r_bar):
        t = tqdm_telegram(bar_format=bar_format)
        t.format_dict['l_bar'] = l_bar
        t.format_dict['r_bar'] = r_bar
        t.format_dict['bar'] = bar
        assert t.format_meter().count('{') == n_openings
        assert t.format_meter().count('}') == n_closings
        assert t.format_meter().count(bar) == n_bar
        assert t.format_meter().count(l_bar) == n_l_bar

# Generated at 2022-06-24 10:07:10.830272
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    TelegramIO('a', 'b')

# Generated at 2022-06-24 10:07:13.002847
# Unit test for function trange
def test_trange():
    """tester"""
    range(10)


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 10:07:18.612022
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    from time import sleep
    from tqdm.auto import tqdm
    tgr = TelegramIO("", "")
    tgr.write("")
    tgr.delete()
    for i in tqdm(range(10)):
        sleep(0.01)
        tgr.write("num = " + str(i))
    tgr.delete()
    tgr.write("")

# Generated at 2022-06-24 10:07:23.192865
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    """Test """
    t = tqdm_telegram(range(10), token='{token}', chat_id='{chat_id}')
    t.clear()



# Generated at 2022-06-24 10:07:32.410192
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from os import linesep
    from io import StringIO
    # Test of display method of tqdm_telegram class
    class tqdm_telegram_test(tqdm_telegram):
        class _default_write_attributes(object):
            def __init__(self, file):
                self.file = file
        def __init__(self, iterable=None, **kwargs):
            self._info_dict = {}
            self.dynamic_ncols = None
            self.set_description = self.set_postfix = self.update = None
            self.__enter__ = self.__exit__ = self._instant_gui = None
            self.gui = self.gui_arr = self.ncols = self.sp = None

# Generated at 2022-06-24 10:07:37.044489
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from ..std import tqdm as tqdm_std
    # Initialize a tqdm_std instance
    t = tqdm_std(range(100), leave=True, disable=True)
    # Initialize a tqdm_telegram instance
    tg = tqdm_telegram(range(100), leave=True, disable=True)
    # Test display method
    tg.display(t)

# Generated at 2022-06-24 10:07:39.746092
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    for i in tqdm(iterable, token='{token}', chat_id='{chat_id}'):
        pass
    assert True

# Generated at 2022-06-24 10:07:41.634771
# Unit test for function trange
def test_trange():
    import time
    with trange(10) as t:
        for i in t:
            time.sleep(0.1)
            t.set_postfix(i=i)

# Generated at 2022-06-24 10:07:44.776630
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import pytest
    ti = TelegramIO(123, 123)
    ti.message_id
    with pytest.raises(Exception):
        # Add an assertion
        assert ti.write('a')


# Generated at 2022-06-24 10:07:46.627135
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    TelegramIO(token='SUCH', chat_id='MUCH')

# Generated at 2022-06-24 10:07:56.148084
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from os import devnull
    from sys import stderr, getfilesystemencoding
    from locale import getdefaultlocale
    from tempfile import TemporaryFile

    enc = getfilesystemencoding() or getdefaultlocale()[1]
    devnull = open(devnull, 'w')

    with TemporaryFile(mode="w+", encoding=enc) as f:
        # Test `**kwargs` pass-through
        t = tqdm(total=10, file=f, desc='foo', bar_format='{l_bar}{bar:10u}{r_bar}')
        t.write("")
        t.update(3)
        f.seek(0)
        s = f.read()
    assert 'foo|#####    |30.0%' in s


# Generated at 2022-06-24 10:08:05.144367
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    import os
    import json
    import requests
    import tqdm.contrib.telegram
    import unittest

    class TestFormatter(unittest.TestCase):
        try:
            from StringIO import StringIO
        except ImportError:
            from io import StringIO
        def setUp(self):
            try:
                # We do not do this in `__init__` to avoid 0% progress on
                # exception (if it occurs before initial progress)
                self.tgio = tqdm.contrib.telegram.TelegramIO(
                    '123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmno',
                    '123456789')
            except requests.exceptions.ConnectionError:
                self.fail('requires internet connection')


# Generated at 2022-06-24 10:08:13.562812
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    import os
    import sys
    import time

    old_env_token = os.environ.get('TQDM_TELEGRAM_TOKEN', '')
    old_env_chat_id = os.environ.get('TQDM_TELEGRAM_CHAT_ID', '')


# Generated at 2022-06-24 10:08:23.392686
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    token = 'xyz'
    chat_id = '0123456789'
    tg = TelegramIO(token, chat_id)

    # No session var
    s = "hello world"
    assert tg.write(s) == None, \
        "Session uninitialized, should return None"
    assert tg.text == "TelegramIO", \
        "Text was modified unexpectedly"

    # Session var, but no message_id
    tg.session = Session()
    assert tg.write(s) == None, \
        "No message_id, should return None"
    assert tg.text == "TelegramIO", \
        "Text was modified unexpectedly"

    # Session var and message_id
    tg.message_id = 42

# Generated at 2022-06-24 10:08:27.418451
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    assert hasattr(tqdm_telegram, '__init__')

# Test for constructor of class TelegramIO

# Generated at 2022-06-24 10:08:31.774571
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    """Test compatibility of TelegramIO().write with the tqdm API."""
    tgio = TelegramIO('', '', disable=True)
    tgio.write("Hello World!")
    tgio.write("")
    tgio.write("")
    tgio.write("")
    tgio.write("")

# Generated at 2022-06-24 10:08:38.627052
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    # token & chat_id are taken from environment variables
    with tqdm(total=1, bar_format='{elapsed}') as t:
        t.sleep()
    tqdm(total=1, bar_format='{elapsed}')

    # token &/or chat_id provided as arguments
    with tqdm(total=1, bar_format='{elapsed}', token=getenv('TQDM_TELEGRAM_TOKEN')) as t:
        t.sleep()
    tqdm(total=1, bar_format='{elapsed}', token=getenv('TQDM_TELEGRAM_TOKEN'))


# Generated at 2022-06-24 10:08:43.195034
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    try:
        __import__('requests').Session().post(
            'https://api.telegram.org/bot%s/deleteMessage' % (
                getenv('TQDM_TELEGRAM_TOKEN')), data={
                'chat_id': getenv('TQDM_TELEGRAM_CHAT_ID'),
                'message_id': '1'}).json()
    except Exception:
        pass
    else:
        raise AssertionError()

# Generated at 2022-06-24 10:08:49.134377
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    # test with default bar format
    t = tqdm_telegram(range(100), total=100)
    fmt = t.format_dict
    fmt['bar_format'] = fmt['bar_format'].replace('<bar/>', '{bar:10u}').replace('{bar}', '{bar:10u}')
    s = t.format_meter(**fmt)
    assert "100/100" in s
    assert "100%|█████████" in s
    t.close()
    # test with bar_format
    t = tqdm_telegram(range(100), total=100, bar_format="{postfix[0]} {postfix[1]}")
    fmt = t.format_dict

# Generated at 2022-06-24 10:08:59.656964
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from unittest import TestCase
    from contextlib import contextmanager

    @contextmanager
    def assertRaisesPri(e):
        try:
            yield
        except e as e_:
            assert e_.args[0] == "assertion failed"
        else:
            raise AssertionError("assertion failed")

    class Testtqdm_telegram(TestCase):
        def test_close(self):
            for t in [tqdm_telegram, trange]:
                t(0).close()
                t(1, disable=True).close()
                with assertRaisesPri(AssertionError):
                    t(1).close()
                t(1, leave=True).close()
                with assertRaisesPri(AssertionError):
                    t(1).close()

# Generated at 2022-06-24 10:09:00.657173
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    """Unit test for constructor of class TelegramIO."""
    x = TelegramIO("token", "chat_id")

# Generated at 2022-06-24 10:09:03.084346
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    ti = TelegramIO('token', 'chat_id')
    assert ti is not None
    ti.close()
    ti = TelegramIO('token', 'chat_id')
    ti.write('some string')
    ti.close()

# Generated at 2022-06-24 10:09:12.616552
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    """Tests TelegramIO init."""
    import os
    import unittest

    class TelegramIOTest(unittest.TestCase):
        """Test class to test TelegramIO init."""

        @unittest.skipIf(
            'TRAVIS' in os.environ and os.environ['TRAVIS'] == 'true',
            "Travis fails (it is a problem in their infra probably)")
        def test_init(self):
            """Test TelegramIO init."""
            try:
                io = TelegramIO(
                    os.environ['TQDM_TELEGRAM_TOKEN'],
                    os.environ['TQDM_TELEGRAM_CHAT_ID'])
                io.__class__.__name__
                io.write("test")
            finally:
                io.delete()

# Generated at 2022-06-24 10:09:14.009332
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    assert hasattr(tqdm_telegram, 'display')



# Generated at 2022-06-24 10:09:24.740947
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    try:
        import sys
        import unittest
    except ImportError:  # pragma: no cover
        pass  # pragma: nocover
    else:  # pragma: no cover
        try:
            # python3
            from io import StringIO
        except ImportError:  # pragma: no cover
            from io import BytesIO as StringIO

        class TqdmTelegramClearTests(unittest.TestCase):

            def setUp(self):
                self.old_stderr = sys.stderr
                sys.stderr = self.new_stderr = StringIO()
                self.stderr = self.new_stderr

            def tearDown(self):
                sys.stderr = self.old_stderr
                self.stderr.close()

           

# Generated at 2022-06-24 10:09:31.486349
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    """Unit test for method :meth:`delete` of class :class:`TelegramIO`."""
    if not (getenv('TQDM_TELEGRAM_TOKEN') and getenv('TQDM_TELEGRAM_CHAT_ID')):
        warn("Unit test skipped: no `TQDM_TELEGRAM_TOKEN` or `TQDM_TELEGRAM_CHAT_ID` in env.", TqdmWarning, stacklevel=2)
        return

    from time import sleep
    from os import kill
    from signal import signal, SIGINT, SIGTERM
    from multiprocessing import Process
    from nose.tools import timed


# Generated at 2022-06-24 10:09:41.784807
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    # this is a stand-alone script
    from os import environ
    from os.path import realpath, dirname
    from pandas import read_csv
    from sklearn.linear_model import LogisticRegression
    from sklearn.model_selection import train_test_split
    from subprocess import Popen, PIPE
    from unittest import TestCase
    from tqdm import tqdm as tqdm_auto

    THIS_DIR = dirname(realpath(__file__))
    PACKAGE_DIR = dirname(THIS_DIR)
    DATA_PATH = PACKAGE_DIR + '/../tests/test_pandas_iris.csv'
    TEST_TOKEN = environ['TQDM_TELEGRAM_TEST_TOKEN']

# Generated at 2022-06-24 10:09:46.348209
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    x = TelegramIO("490890209:AAFsJJ8TaPJybRPx-X1OIYUH0XLmlCpDTWo", "-1001198868993")
    x.delete()


if __name__ == '__main__':
    r = trange(3)
    for i in r:
        r.display()
    r.close()

# Generated at 2022-06-24 10:09:52.857014
# Unit test for function trange
def test_trange():
    from requests import get
    from .utils import _time, _set_mac_slider_pos
    N = 10
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    try:
        for _ in trange(N, token=token, chat_id=chat_id):
            get('https://www.google.com/search?q=test')
    except ValueError:
        pass
    else:
        assert any('test' in i.json().get('result', {}).get('text', '')
                   for i in get(
                       'https://api.telegram.org/bot%s/getUpdates' % token)
                   .json().get('result', {}))
    # Test with empty range (

# Generated at 2022-06-24 10:09:59.812850
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from time import sleep
    from os import environ
    token = environ['TQDM_TELEGRAM_TOKEN']
    chat_id = environ['TQDM_TELEGRAM_CHAT_ID']
    T = TelegramIO(token, chat_id)
    T.write("Running Unit Test")
    sleep(1)
    T.write("Running Unit Test.....")
    sleep(1)
    T.write("Running Unit Test...... done!")
    if T.message_id is not None:
        sleep(2)
        T.delete()

# Generated at 2022-06-24 10:10:03.396615
# Unit test for function trange
def test_trange():
    for _ in trange(3, token="391224487:AAH5y5qbZ3qoZYI-db1-NQlA0R9XaA-pTBg", chat_id="547697951"):
        pass

# Generated at 2022-06-24 10:10:07.733022
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    class TestTelegramIO(TelegramIO):
        def __init__(self, token, chat_id):
            super(TestTelegramIO, self).__init__(token, chat_id)
            self._message_id = 42

        @property
        def message_id(self):
            return self._message_id

    t = TestTelegramIO('token', 'chat_id')
    assert t.message_id == 42
    t.delete()


# Generated at 2022-06-24 10:10:14.718865
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from shutil import rmtree
    from os import mkdir, environ
    from tempfile import gettempdir
    from tqdm import tqdm
    from tqdm._utils import _term_move_up

    temp_dir = gettempdir() + '/tqdm-telegram-test'
    mkdir(temp_dir)
    environ['TQDM_TELEGRAM_TOKEN'] = '1'
    environ['TQDM_TELEGRAM_CHAT_ID'] = '2'

# Generated at 2022-06-24 10:10:22.974410
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """
    Tests that the tqdm_telegram class updates the progress bar while running,
    and that the progress bar properly updates its message after being closed.
    """
    import time
    test_obj = tqdm_telegram(iterable=range(10))
    for i in test_obj:
        time.sleep(1)

    assert (test_obj.pos == 10)


if __name__ == "__main__":
    from os import getenv
    from sys import argv

    # Test:
    if len(argv) == 3:
        for i in tqdm(range(1000), token=argv[1], chat_id=argv[2]):
            pass

# Generated at 2022-06-24 10:10:28.498498
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    token = '999184530:AAEzgv8nWewH_J9bDZWiGg-vNakWn5JNlwM'
    chat_id = '-427155596'
    text = 'test_tqdm'
    write = TelegramIO(token=token, chat_id=chat_id).write(text)
    print(write)

if __name__ == '__main__':
    test_TelegramIO_write()

# Generated at 2022-06-24 10:10:40.063159
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import sys
    from io import TextIOWrapper
    from .utils_bar import ProgressBar
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    with patch('sys.stderr', new_callable=TextIOWrapper) as fake_stderr:
        pbar = ProgressBar(0, 100)
        pbar.n = 10
        pbio = tqdm_telegram(pbar)
        pbio.display()
        pbio.close()
        ncols = int(fake_stderr.write.call_args[0][1].split(' ')[2])
        nlines = int(fake_stderr.write.call_args[0][1].split(' ')[1])

# Generated at 2022-06-24 10:10:48.841056
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import json
    import socket, ssl, http.client, urllib.request, urllib.parse, urllib.error
    import requests

    # Monkey patching urllib.request.urlopen()
    # inject a fake token and chat_id to make it work
    # getUpdates did not work properly :'(
    token = '123456789:ABCD1234EFGH5678IJKL90AB'
    chat_id = 'ABCD1234'
    old_urlopen = urllib.request.urlopen
    def new_urlopen(*args, **kwargs):
        if 'getUpdates' in args[0]:
            return old_urlopen(*args, **kwargs)
        # otherwise:
        host, rest = args[0].split('/', 3)[2:]
        data = json

# Generated at 2022-06-24 10:10:56.097865
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    from time import time
    from os import environ
    from tqdm import tqdm

    environ['TQDM_TELEGRAM_TOKEN'] = '818461490:AAGnG6dPW6U8v6jnLnU1qXLr3QlKjyC9Xhc'
    environ['TQDM_TELEGRAM_CHAT_ID'] = '-1001373704559'

    for i in tqdm(iterable=range(1,11), total=10, mininterval=0.5, desc='Test4'):
        try:
            tqdm.write(i)
        except:
            tqdm.tgio.delete()


# Generated at 2022-06-24 10:11:01.702835
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    desc = "Random tests"
    assert tqdm_telegram(desc=desc, total=10,
                         token=getenv('TQDM_TELEGRAM_TOKEN'),
                         chat_id=getenv('TQDM_TELEGRAM_CHAT_ID')).write(desc)

# Generated at 2022-06-24 10:11:06.715447
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    kwargs = dict(mininterval = 0.1, leave = True, disable = False)
    t = tqdm_telegram(iterable = ['a', 'b', 'c'], **kwargs)
    assert not t.leave
    t.close()

    t = tqdm_telegram(iterable = ['a', 'b', 'c'], **kwargs)
    assert t.leave
    t.close()

# Generated at 2022-06-24 10:11:16.797357
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    import warnings
    warnings.simplefilter('ignore', TqdmWarning)
    # token & chat_id are passed to the TqdmIO class as keyword arguments
    t = TelegramIO(token='', chat_id='')


if __name__ == '__main__':
    import argparse
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('-t', '--token', help="Telegram token")
    p.add_argument('-c', '--chat_id', help="Telegram chat ID")
    p.add_argument('-n', '--n', type=int, default=10, help="Number of iterations")

# Generated at 2022-06-24 10:11:19.376789
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    res = TelegramIO.write(TelegramIO(None, None), "Bom dia")
    assert res.result() == None

# Generated at 2022-06-24 10:11:26.879345
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    """Test method `TelegramIO.delete`."""
    from os import environ
    assert environ.get('TQDM_TELEGRAM_TOKEN') is not None
    assert environ.get('TQDM_TELEGRAM_CHAT_ID') is not None
    with TelegramIO(environ['TQDM_TELEGRAM_TOKEN'],
                    environ['TQDM_TELEGRAM_CHAT_ID']) as tgio:
        tgio.write("Testing...").result()
        assert tgio.delete().result() is None
        tgio.write('Testing...')

# Generated at 2022-06-24 10:11:34.177570
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    t = tqdm(total=10, token='877819803:AAHUsDfGrF_HPrt2JT1T0TtC0huYV7c1Zec',
             chat_id='27684811')
    for i in t:
        t.write('hello')
        t.set_description('A very long description')
        t.set_description_str('A very long description str')
        t.n = 5
        t.refresh()
        pass

# Generated at 2022-06-24 10:11:37.448049
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
	token = getenv('TQDM_TELEGRAM_TOKEN')
	chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
	tgio = TelegramIO(token, chat_id)
	tgio.delete()

# Generated at 2022-06-24 10:11:48.070733
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    """
    Tests the `delete` method of the class TelegramIO.
    """
    # Verify that the "delete" method of the TelegramIO object works properly
    # for the errors specified by the Telegram API
    tg_token = "some_token"
    tg_chat_id = "-1001122334455"
    error_codes = [403, 404, 400]
    for error_code in error_codes:
        tgio_error = TelegramIO(tg_token, tg_chat_id)
        tgio_error.session.post = lambda *_: {"error_code": error_code}
        # Updating message ID, so the delete method will be called
        tgio_error._message_id = 1
        tgio_error.delete()

# Generated at 2022-06-24 10:11:55.776760
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    """
    Unit test for method display of class tqdm_telegram.
    """
    from tqdm.auto import tqdm
