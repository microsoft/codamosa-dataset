

# Generated at 2022-06-24 10:01:56.549800
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from .utils_test import _test_leave, _test_nested, _test_no_leave

    # Test tqdm_telegram_close with leave=None
    _test_leave(tqdm_telegram, leave=None)
    # Test tqdm_telegram_close with leave=True
    _test_leave(tqdm_telegram, leave=True)
    # Test tqdm_telegram_close with leave=False
    _test_no_leave(tqdm_telegram, leave=False)
    # Test tqdm_telegram_close with nested=True
    _test_nested(tqdm_telegram, nested=True)

# Generated at 2022-06-24 10:01:59.638087
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    TelegramIO.API = "https://api.telegram.org/bot"
    telegram_io = TelegramIO(token='mytoken', chat_id='mychat_id')
    assert telegram_io


# Generated at 2022-06-24 10:02:10.045588
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    # It is not a good idea to run such test in Travis CI
    # so I block this test case by Travis CI
    try:
        from os import getenv
        assert (getenv('TRAVIS_CI') == 'true')
        return
    except:
        pass
    # Test case
    from tqdm._tqdm import tgrange
    from time import sleep
    import re
    import json
    import requests
    from string import Template
    from random import randint
    from os import environ
    from os.path import join
    from os import remove
    from tempfile import mkdtemp

    def get_token():
        # get token
        path = join(mkdtemp(), 'token')

# Generated at 2022-06-24 10:02:19.305372
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from time import sleep
    from six.moves import StringIO  # pylint: disable=E0401

    with StringIO() as f:
        with tqdm_telegram(total=10, file=f, token='{token}', chat_id='{chat_id}',
                           mininterval=0) as pbar:
            for _ in pbar:
                sleep(0.01)

        # Disabling display
        assert f.getvalue() == ""

        # Re-enabling display
        pbar.write(True)

        # Test bar formatting
        f.seek(0)
        assert '[' in f.getvalue()
        assert ']' in f.getvalue()


if __name__ == "__main__":
    test_tqdm_telegram_display()

# Generated at 2022-06-24 10:02:29.118919
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from io import StringIO
    from random import random
    out = StringIO()

    # Test for leave=True
    for leave in [True, False]:
        t = tqdm(total=1, leave=leave,
                 token='123456789:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
                 chat_id='1234567890',
                 file=out)
        t.update(1)
        t.close()

    t = tqdm(total=1, leave=None,
             token='123456789:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
             chat_id='1234567890',
             file=out)
    t.update(1)
    t.close()

    t.close()  # test for repeated close

    # Test for post-close with `del` for leave=None

# Generated at 2022-06-24 10:02:32.155370
# Unit test for function trange
def test_trange():
    trange(3)
    trange(3, token='{token}', chat_id='{chat_id}')


if __name__ == '__main__':
    from .utils_tests import _test_telegram
    _test_telegram()

# Generated at 2022-06-24 10:02:40.183848
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    """Test for TelegramIO"""
    # pylint: disable=protected-access
    import requests
    from tqdm.contrib.telegram import TelegramIO
    from tqdm.contrib.tests import pretest_posttest

    def wrapper():
        """Wrapper to provide access to TelegramIO ivars"""
        def new_post(*args, **kwargs):
            """New requests.Session.post() method"""
            res = {'ok': True, 'result': {'message_id': 1},
                   'description': 'New message'}
            if args[1].endswith('sendMessage'):
                requests.Session.post = session.post
                TelegramIO(token, chat_id).write('Start\n')
                requests.Session.post = new_post

# Generated at 2022-06-24 10:02:45.809548
# Unit test for function trange
def test_trange():
    from .test_tqdm import with_setup, _range  # NOQA
    from .utils import FormatCustom, closing

    @with_setup(pretest=closing(False))
    def test():
        for _ in trange(10, bar_format=FormatCustom('{bar}'),
                        token='728373763:AAEt-XPk-FcX9vj856yWwhH3qfQ2Ej_vAl8',
                        chat_id='-1001227532851'):
            pass
        assert ncols() > 0

    test()

# Generated at 2022-06-24 10:02:52.288402
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    try:
        for i in tqdm(iterable=range(30), token='828622105:AAEIcwv-GNmGOc8G9fQ2QmEzvhjbRC_MpUY', chat_id='746826399', leave=True):
            assert(isinstance(i, int))
    except Exception as e:
        print(e)


# Generated at 2022-06-24 10:02:57.377938
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import time
    tg = TelegramIO('testtoken', 987654)
    tg.write('test')
    time.sleep(1.1)
    tg.write('test2')
    time.sleep(1.1)
    tg.write('test3')
    time.sleep(1.1)
    tg.delete()

# Generated at 2022-06-24 10:03:09.000793
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    tgio = TelegramIO(token, chat_id)
    tgio._message_id = (
        TelegramIO(token, chat_id).session.post(
            TelegramIO.API + '%s/sendMessage' % token,
            data={'text': '`' + tgio.__class__.__name__ + '`', 'chat_id': chat_id,
                  'parse_mode': 'MarkdownV2'}).json())['result']['message_id']

# Generated at 2022-06-24 10:03:15.952460
# Unit test for function trange
def test_trange():
    for _ in trange(3, token='{token}', chat_id='{chat_id}'):
        pass
    for _ in trange(3, desc='Telegram', token='{token}', chat_id='{chat_id}'):
        pass
    for _ in trange(3, desc='Telegram', leave=True,
                    token='{token}', chat_id='{chat_id}'):
        pass


if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-24 10:03:23.413768
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """
    Tests the close method of tqdm_telegram.
    """
    import os
    import shutil

    count = 100000
    os.environ['TQDM_TELEGRAM_TOKEN'] = 'token'
    os.environ['TQDM_TELEGRAM_CHAT_ID'] = 'chat_id'
    try:
        tgr = ttgrange(count)
        for i in tgr:
            pass
        tgr.close()
    finally:
        del os.environ['TQDM_TELEGRAM_TOKEN']
        del os.environ['TQDM_TELEGRAM_CHAT_ID']

# Generated at 2022-06-24 10:03:25.753719
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tgio = TelegramIO('1234567890:AABB-1234567890_AABB1234567890',
                      '-1234567')
    tgio.write('`Test`')

# Generated at 2022-06-24 10:03:37.850136
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from os import system
    from sys import version_info, stdout
    from time import sleep
    from traceback import format_exc
    from .utils_test import TestTqdm, _range, ClosingStringIO

    if version_info[0] >= 3:
        from io import StringIO
    else:
        from StringIO import StringIO

    system('clear')
    with closing(ClosingStringIO()) as f:
        with TestTqdm(f, mininterval=0.0001, miniters=1,
                      desc='tqdm_telegram', leave=True, ncols=80,
                      disable=False, ascii=True, nrows=1) as bar:
            bar.update()
            sleep(2)
        tqdm_auto.write(f.getvalue())


# Generated at 2022-06-24 10:03:41.273926
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    """Test tqdm_telegram.clear"""
    t = tqdm_telegram(total=10, disable=True)
    t.clear()

# Generated at 2022-06-24 10:03:49.262270
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import pytest
    import re
    import random
    import string

    telegram_api_url = 'https://api.telegram.org/bot'
    token = '00000000:00000000000000000000000000000000'
    chat_id = '-00000000000000000'

    requests_mock = pytest.importorskip('requests_mock')

    with requests_mock.Mocker() as mocker:
        tgio = TelegramIO(token, chat_id)
        tgio._message_id = 111111111111

        def send_message_callback(request, context):
            result = {'ok': True, 'result': {'message_id': 111111111111}}
            return result

        def edit_message_callback(request, context):
            data = request.text

# Generated at 2022-06-24 10:03:55.236392
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    """
    >>> from tqdm.contrib.telegram import tqdm
    >>> import time
    >>> with tqdm(total=5, token='{token}', chat_id='{chat_id}') as pbar:
    ...     for i in pbar:
    ...         time.sleep(1)
    """
    pass


# Generated at 2022-06-24 10:04:04.149851
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from unittest import TestCase, main

    class DisplayT(TestCase):
        def setUp(self):
            self.t = tqdm_auto()
            self.t.refresh = lambda *a, **k: None

        def test_display(self):
            self.t.total = None
            self.t.format_meter = lambda *a, **k: 'bar'
            self.t.display()
            tqdm_auto.write.assert_called_with('bar')

        def test_clear(self):
            self.t.leave = True
            self.t.clear()
            tqdm_auto.write.assert_called_with('\r')

    import mock
    tqdm_auto.write = mock.Mock()
    main()

# Generated at 2022-06-24 10:04:11.883743
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import getpass
    import textwrap
    tg = TelegramIO(token=getpass.getpass('Telegram Token:'),
                    chat_id=getpass.getpass('Chat ID:'))

# Generated at 2022-06-24 10:04:22.728758
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from os import getenv
    from sys import platform
    from time import sleep

    try:
        from nose.tools import assert_equal
    except:
        assert_equal = lambda a, b: a == b

    tg = tqdm_telegram(getenv("TQDM_TELEGRAM_TOKEN"),
                       getenv("TQDM_TELEGRAM_CHAT_ID"))
    sleep(.1)
    tg.write("1")
    sleep(.1)
    tg.write("2")
    sleep(.1)
    tg.write("3")
    sleep(.1)
    tg.write("4")
    sleep(.1)
    tg.write("5")
    sleep(.1)
    tg.write("6")
    sleep(.1)


# Generated at 2022-06-24 10:04:28.823939
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from .utils_telegram import UnitTest
    unit = UnitTest()
    io = TelegramIO(token=unit.token, chat_id=unit.chat_id)

    def io_write(s, expected_s=''):
        io.write(s)
        io.flush()

    io_write("A")
    io_write("B")
    io_write("C")
    io_write("", "...")
    io.delete()
    io_write("A")

# Generated at 2022-06-24 10:04:34.652829
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    io = TelegramIO('42', '69')
    io.write('hello world')
    assert io.text == 'hello world'
    io.delete()
    assert io.text is None

# Generated at 2022-06-24 10:04:37.870706
# Unit test for function trange
def test_trange():
    with trange(3, token='...', chat_id='...') as t:
        for i in t:
            assert getattr(t, 'n', 0) == i
            assert t.n == i
            t.update()

# Generated at 2022-06-24 10:04:40.479232
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    speedtest = tqdm(total=100, leave=False, unit='B', unit_scale=True)
    for i in range(100):
        speedtest.update()
    speedtest.close()

# Generated at 2022-06-24 10:04:46.323264
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    tg = TelegramIO('1', '1')
    assert tg.token == '1'
    assert tg.chat_id == '1'
    tgio = tqdm(1, token='1', chat_id='1').tgio
    assert tgio.token == '1'
    assert tgio.chat_id == '1'
    assert tgio.message_id is not None
    tgio.delete()
    assert tgio.message_id is None



# Generated at 2022-06-24 10:04:53.019242
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
	from os import system
	system('rm -f 2>/dev/null test_tqdm_telegram.log')
	with open('test_tqdm_telegram.log','w') as fp:
		from time import sleep
		from tqdm import tqdm
		token, chat_id= [line.split('=')[1]
						 for line in open('./.telegram')]
		for i in tqdm(range(10), token=token, chat_id=chat_id, file=fp):
			sleep(1)

if __name__ == '__main__':
	test_tqdm_telegram()

# Generated at 2022-06-24 10:04:57.265655
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    try:
        tgio = TelegramIO("1234567890:GHIJKLMNO_PQRSwxyzABCDEFGHJKLMno", 12345678)
    except Exception:
        pass
    else:
        tgio.delete()
        tgio.close()

# Generated at 2022-06-24 10:05:00.635610
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    t=tqdm_telegram(1)
    for i in t:
        t.clear()
        break

# Generated at 2022-06-24 10:05:08.921326
# Unit test for function trange
def test_trange():
    """Test trange"""
    tr = trange(3, token='588932655:AAHzRt1N7zNdJq3bXt_QDyKiGBPJgDAYcMU', chat_id='743863463')
    assert isinstance(tr, tqdm_auto)
    assert isinstance(tr, tqdm_telegram)
    for i in tr:
        pass
    tr.close()

# Generated at 2022-06-24 10:05:12.060089
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tio = TelegramIO('foo', 'bar')
    tio._message_id = 42
    assert tio.delete()


if __name__ == "__main__":
    from doctest import testmod
    testmod(verbose=True)

# Generated at 2022-06-24 10:05:15.049596
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    # Lint test
    TelegramIO(None, None)


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-24 10:05:19.976557
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from ..tqdm import main
    main(["test", "--test-method", "tqdm_telegram.test_tqdm_telegram"],
         standalone_mode=False)


if __name__ == "__main__":
    test_tqdm_telegram()

# Generated at 2022-06-24 10:05:22.085230
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tg = TelegramIO('', '')
    assert not (hasattr(tg, '_message_id') and tg.delete())

# Generated at 2022-06-24 10:05:29.852808
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    try:
        # Make sure that Telegram token and chat ID is set
        # correctly in the environment variables
        t = tqdm_telegram(total=100, token=getenv('TQDM_TELEGRAM_TOKEN'),
                          chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'))
        # Close the channel to avoid duplicate messages
        t.close()
    except ImportError:
        pass  # No telegram
    except RuntimeError:
        pass  # No way to test the telegram

# Generated at 2022-06-24 10:05:35.139466
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    # Test clears by leaving and not leaving
    for leave in [False, True]:
        tqdm_telegram(["a", "b", "c", "d"], leave=leave,
                      token=getenv("TQDM_TELEGRAM_TOKEN"),
                      chat_id=getenv("TQDM_TELEGRAM_CHAT_ID")).clear()


# Generated at 2022-06-24 10:05:36.204334
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    # Unit test for method clear of class tqdm_telegram
    pass

# Generated at 2022-06-24 10:05:38.950442
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tio = TelegramIO('token', 'chat_id')
    tio.write('test')
    tio.write('test')
    tio.write('test')
    tio.write('test')
    tio.write('test')
    tio.write('test')

# Generated at 2022-06-24 10:05:48.519528
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    """
    Unit test for method display of class tqdm_telegram.
    """
    tq = tqdm_telegram('TEST', disable=True)
    tq.bar_format = '{l_bar}|{bar}|{r_bar}|'
    tq.format_dict = {'n': 10, 'n_fmt': '', 'rate': 1.0}
    tq.display()
    tq.close()
    tq = tqdm_telegram('TEST', disable=True)
    tq.format_dict = {'n': 10, 'n_fmt': '', 'rate': 1.0}
    tq.display()
    tq.close()
    tq = tqdm_telegram('TEST', disable=True)
    tq.bar

# Generated at 2022-06-24 10:05:51.854810
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    for leave in [None, True, False]:
        for i in tqdm_telegram(iterable=range(10),
                               leave=leave, token='{token}',
                               chat_id='{chat_id}'):
            pass

# Generated at 2022-06-24 10:05:58.449695
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from io import StringIO
    from tqdm.auto import tqdm
    import sys
    f = StringIO()
    sys.stderr = f
    a = tqdm_telegram(token='1148856387:AAHVXbvvJe_1tZpKwC-P7-F5EoKj3_JFt5k', chat_id='171374122', file=sys.stderr, total=10)
    a.clear()
    a.close()

# Generated at 2022-06-24 10:06:03.950342
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    """Test method write of class TelegramIO"""
    from .test_timeformat import test_example
    import os

    token = os.getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = os.getenv('TQDM_TELEGRAM_CHAT_ID')

    if not (token and chat_id):
        raise Exception("You need to set `TQDM_TELEGRAM_TOKEN` and "
                        "`TQDM_TELEGRAM_CHAT_ID` environment variables")

    telegramIO = TelegramIO(token, chat_id)
    test_example(telegramIO)

# Generated at 2022-06-24 10:06:06.837706
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    client = TelegramIO(
        chat_id='',
        token=''
    )
    msg_id = client.message_id
    response = client.delete()
    assert response.result().status_code == 200, "Request was not successful"

# Generated at 2022-06-24 10:06:12.456998
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    try:
        with tqdm_telegram(unit="B", unit_scale=True, miniters=1,
                           token='1074718251:AAFaUnv2h_UYwCTuV7f0N1gGVk-yDplTzTg',
                           chat_id='-1001441947146') as t:
            for i in tqdm_telegram(tqdm_auto.range(10), leave=False):
                t.update(i)
    except Exception as e:
        pass


# Generated at 2022-06-24 10:06:15.950601
# Unit test for function trange
def test_trange():
    import time
    for i in trange(4,
                    desc='Example',
                    leave=True,
                    bar_format='{desc}: {n:>2}/{total:>2} {percentage:3.0f}% {rate_fmt}'):
        time.sleep(0.5)

if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-24 10:06:18.622668
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """
    Unit test for method close of class tqdm_telegram
    """
    telegram_instance = tqdm_telegram(_range(10), leave = True, disable = True)
    telegram_instance.close()

# Generated at 2022-06-24 10:06:22.315665
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    with tqdm_telegram(total=1, file=TelegramIO(
            '0', '0' if not getenv('CI') else '-248670980')) as pbar:
        pbar.update(1)

# Generated at 2022-06-24 10:06:28.376201
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from time import sleep
    from requests import Session
    from tqdm.auto import tqdm
    from unittest import TestCase

    class tqdm_telegram(tqdm):
        def display(self, **kwargs):
            super(tqdm_telegram, self).display(**kwargs)
            assert self.format_dict['n'] == 100
            if self.format_dict['n'] == 100:
                raise AssertionError
            print(self.format_meter(**self.format_dict))

        def close(self):
            self.disable = True
            super(tqdm_telegram, self).close()

    token = '{token}'
    chat_id = '{chat_id}'

# Generated at 2022-06-24 10:06:35.721667
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from os import environ
    from random import random
    from hashlib import sha256

    # Given
    environ["TQDM_TELEGRAM_TOKEN"] = "1"
    environ["TQDM_TELEGRAM_CHAT_ID"] = "1"
    iteration_count = 1000

    # When
    with tqdm(total=iteration_count) as pbar:
        for i in range(iteration_count):
            pbar.update()
            pbar.set_description(str(random()))

    # Then

# Generated at 2022-06-24 10:06:38.331144
# Unit test for function trange
def test_trange():
    for _ in trange(5, token='512960251:AAGgTSQ_D1jH_dW7KSgwAedbDe7BM-KEaz0',
                    chat_id='-341119324'):
        pass


if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-24 10:06:40.321889
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    raise NotImplementedError


if __name__ == '__main__':
    from pytest import main
    main([__file__])

# Generated at 2022-06-24 10:06:45.495992
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    """Unit test for method clear of class tqdm_telegram.

    It's a simple case that it's easier to explain in docstring.
    """
    t = tqdm_telegram(total=100)
    t.update(40)
    t.clear()
    # Now bar should be in its initial state (i.e. blank)
    assert t._format_meter() == '|                                                                         |'
    t.close()


# Generated at 2022-06-24 10:06:50.873342
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    import pytest
    assert isinstance(TelegramIO(token='123:abcdefghijklmnopq', chat_id='12345').message_id, int), 'API for sending messages may be changed'

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-24 10:06:57.228006
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    for i in tqdm_telegram(range(3)):
        time.sleep(0.01)

if __name__ == '__main__':
    # Test
    from multiprocessing import Pool, current_process
    from time import sleep
    from tqdm import tqdm

    test_tqdm_telegram()

    print("\n*** BEGIN ***")
    # Test simple
    for i in tqdm(range(2)):
        sleep(0.25)

    # Test multi-threading
    def f(i):
        for _ in tqdm(range(100), leave=False, ascii=True):
            sleep(2e-2)

    with Pool(2) as p:
        p.map(f, range(10))

    # Test multi-processing

# Generated at 2022-06-24 10:07:06.746380
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import sys
    import time
    if sys.version_info[0] < 3:
        from cStringIO import StringIO
    else:
        from io import StringIO
    old_stderr, sys.stderr = sys.stderr, StringIO()
    try:
        a = tqdm_telegram(total=100)
        time.sleep(0.8)
        a.update(10)
        time.sleep(0.8)
        a.update(10)
        time.sleep(0.8)
        a.update(10)
        time.sleep(0.8)
        a.close()
        assert True
    except Exception as e:
        print(str(e))
    finally:
        sys.stderr = old_stderr
        del a

# Generated at 2022-06-24 10:07:08.013392
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    TelegramIO(token='token', chat_id='chat_id')

# Generated at 2022-06-24 10:07:18.850069
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import re
    try:
        if not getenv('TQDM_TELEGRAM_TOKEN'):
            raise ValueError()
        if not getenv('TQDM_TELEGRAM_CHAT_ID'):
            raise ValueError()
        t = tqdm_telegram(
            range(0, int(1e4)), total=int(1e4),
            token=getenv('TQDM_TELEGRAM_TOKEN'),
            chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'))
    except (ValueError, KeyError):
        raise unittest.SkipTest("Skipped Telegram test")
    t.refresh()
    assert re.match(r"\|{1,9}|$", t.tgio.text)
    t.update()
   

# Generated at 2022-06-24 10:07:25.382259
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    for leave in (False, None, 'auto'):
        for pos in range(2):
            t = tqdm_telegram(leave=leave, disable=False)
            t.pos = pos
            t.close()


if __name__ == "__main__":
    from doctest import testmod
    testmod(verbose=True)

# Generated at 2022-06-24 10:07:27.407945
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    tqdm_telegram = tqdm_telegram(total=10)
    with pytest.raises(StopIteration):
        next(tqdm_telegram)
    tqdm_telegram.clear()

# Generated at 2022-06-24 10:07:32.168416
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    text = '`' + TelegramIO.__name__ + '`' + '\n'
    with TelegramIO(token, chat_id) as tgio:
        assert tgio.write('`test_TelegramIO_write`')

# Generated at 2022-06-24 10:07:41.358533
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from os import close, unlink, write
    from tempfile import mkstemp

    for text in ["", [""], ("")]:
        for two_lines in [0, 1, 2]:
            fd, fname = mkstemp()
            try:
                close(fd)
                f = TelegramIO(token='', chat_id='')
                write(fname, '')
                f._message_id = 0
                f.write(text)
                if two_lines:
                    f.write('\n' * (two_lines - 1) + 'text')
            finally:
                unlink(fname)


if __name__ == "__main__":
    test_TelegramIO_write()

# Generated at 2022-06-24 10:07:43.490527
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from .tests_tqdm import test_clear
    test_clear(tqdm)

# Generated at 2022-06-24 10:07:46.754563
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    with TelegramIO(token=getenv('TQDM_TELEGRAM_TOKEN'), chat_id=getenv('TQDM_TELEGRAM_CHAT_ID')):
        pass

# Generated at 2022-06-24 10:07:49.931159
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from tqdm.contrib.telegram import tqdm_telegram
    for i in tqdm_telegram(range(10)):
        pass

# Python2.7 compatibility
if not hasattr(__builtins__, "get"):
    def get(obj, key, default=None):
        """
        Get an item from the object, or set and return a default value.
        """
        try:
            return obj[key]
        except KeyError:
            return default

# Generated at 2022-06-24 10:07:54.567735
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    class T(TelegramIO):
        pass

    t = T('', '')
    t._message_id = 3

    def post(*a, **k):
        print(a, k)
        return {'ok': True}
    t.session.post = post
    t.delete()

# Generated at 2022-06-24 10:08:03.545601
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    import tqdm.contrib.telegram as telegram
    t = telegram.tqdm(['a', 'b', 'c'], leave=True)
    assert t.leave
    t.close()
    assert t.tgio._message_id is not None

    t = telegram.tqdm(['a', 'b', 'c'], leave=False)
    assert not t.leave
    t.close()
    assert t.tgio._message_id is not None

    t = telegram.tqdm(['a', 'b', 'c'])
    assert t.leave is None
    t.close()
    assert t.tgio._message_id is None

# Generated at 2022-06-24 10:08:11.852288
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import sys
    from os import devnull
    from subprocess import Popen, PIPE
    from time import sleep

    io = TelegramIO('<token>', '<chat_id>')
    io.write("...")
    io.submit(sleep, 1)

    p = Popen([sys.executable, '-c', 'from __main__ import io; io.write("")'],
              bufsize=-1, stdin=PIPE, stdout=PIPE, stderr=PIPE, close_fds=True)
    out, err = p.communicate()
    assert out == err == b'', (out, err)
    assert p.wait() == 0

# Generated at 2022-06-24 10:08:16.202671
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from .tests_telegram_contrib import test_tqdm_telegram
    test_tqdm_telegram()(tqdm)


if __name__ == '__main__':
    from .tests_telegram_contrib import main_telegram_test
    main_telegram_test(tqdm)

# Generated at 2022-06-24 10:08:25.900515
# Unit test for function trange
def test_trange():
    """Test telegram trange"""
    from time import sleep
    try:
        import requests
    except ImportError:
        warn("Cannot test telegram: 'requests' not found!", TqdmWarning)
        return
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if not (token and chat_id):
        warn("Cannot test telegram: "
             "'TQDM_TELEGRAM_TOKEN' and 'TQDM_TELEGRAM_CHAT_ID' not defined!",
             TqdmWarning)
        return

    for _ in trange(5, token=token, chat_id=chat_id):
        sleep(1)



# Generated at 2022-06-24 10:08:34.560465
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import sys
    import json
    import subprocess
    import platform
    import random
    import time

    random.seed(0)
    python_ver = platform.python_version()
    print('platform.python_version(): %s'%python_ver)

    bot_id = '@tqdmTestBot'
    chat_id = '@TqdmBotTests'
    expected = 'tqdm test:|' # the expected output from tqdm

    if python_ver.startswith('2.7'):
        import urllib2
        url = 'https://api.telegram.org/bot' + \
            '${TQDM_TELEGRAM_TOKEN}/getUpdates'

# Generated at 2022-06-24 10:08:37.741986
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    io = TelegramIO('{token}', '{chat_id}')
    io.write("1")
    io.write("2")
    io.write("3")
    io.write("4")
    io.write("5")
    io.close()
    print("Unit test for method write of class TelegramIO: Successfully sent 5 posts")

# Generated at 2022-06-24 10:08:39.785675
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    for _ in tqdm(range(10), token='{token}', chat_id='{chat_id}'):
        pass



# Generated at 2022-06-24 10:08:42.933493
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    for i in tqdm(range(30), token='959222777:AAGm8ljWmYlJ5O5GCIoHl9XpWV7cz1FZkMQ', chat_id="-464396052"):
        if i == 10:
            tqdm.clear()
            tqdm.write(str(i))

# Generated at 2022-06-24 10:08:45.800279
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t_a = tqdm_telegram()
    t_b = tqdm_telegram()
    t_a.close()
    t_b.close()
    assert True

try:
    import pytest
    __all__ += ['pytest']
except ImportError:
    pass

# Generated at 2022-06-24 10:08:51.483083
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    t = TelegramIO("some_token", "some_chat_id")
    # should not raise any exception
    t.delete()

# Generated at 2022-06-24 10:08:55.974131
# Unit test for function trange
def test_trange():
    with tqdm(total=1, token='840935365:AAE4F4_BPY1q3N81Kf4P40zIKP5H5l5w5FY',
              chat_id='866679020') as pbar:
        pbar.update()

# Generated at 2022-06-24 10:08:58.547023
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    return TelegramIO(
        getenv('TQDM_TELEGRAM_TOKEN'), getenv('TQDM_TELEGRAM_CHAT_ID'))

# Generated at 2022-06-24 10:09:03.333649
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    assert TelegramIO('token', 'chat_id').message_id is not None

# Generated at 2022-06-24 10:09:10.483065
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    # test for method display of class tqdm_telegram
    from .test_tqdm import pretest_posttest  # NOQA
    from .utils import _range
    from tqdm.contrib.telegram import tqdm_telegram  # NOQA

    token = "{{token}}"
    chat_id = "{{chat_id}}"
    return pretest_posttest(tqdm_telegram(_range(1000), token=token,
                                          chat_id=chat_id))



# Generated at 2022-06-24 10:09:20.930618
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """test tqdm_telegram class close (delete message) method"""
    from os import getenv
    from time import sleep

    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if not token or not chat_id:
        raise AssertionError(
            "Telegram token and chat ID not available. "
            "Please set environment variables."
            )
    with tqdm_telegram(total=10, token=token, chat_id=chat_id,
                       mininterval=1e-10) as t:
        for i in range(10):
            assert t.tgio.message_id is not None
            sleep(.5)
            t.update()

# Generated at 2022-06-24 10:09:24.655588
# Unit test for function trange
def test_trange():
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    for _ in trange(2, token=token, chat_id=chat_id):
        pass

# Generated at 2022-06-24 10:09:28.708026
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram("", disable=True)
    assert hasattr(t, 'disable')
    session = Session()
    res = session.post("https://api.telegram.org/botXXXXXXXXXX/sendMessage", data={'text': 'None', 'chat_id': 'XXXXXXX', 'parse_mode': 'MarkdownV2'})
    assert 'error_code' in res.json()

# Generated at 2022-06-24 10:09:39.668033
# Unit test for function trange
def test_trange():
    "tests if trange works"
    try:
        # Remove env vars if they exist
        del os.environ['TQDM_TELEGRAM_TOKEN']
    except:
        pass
    try:
        # Remove env vars if they exist
        del os.environ['TQDM_TELEGRAM_CHAT_ID']
    except:
        pass

    telegram_token = 'TEST_TOKEN'
    telegram_chat_id = 'TEST_ID'

    # function trange has to be called with the two args
    for _ in trange(token=telegram_token, chat_id=telegram_chat_id, total=10):
        pass

if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 10:09:45.141699
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    # Just check it runs
    import time
    try:
        with tqdm(total=10, token='a', chat_id='b') as pbar:
            for i in range(10):
                pbar.update(1)
                time.sleep(1)
    except Exception as e:
        warn(str(e))
    else:
        print('Success!')


if __name__ == '__main__':
    test_tqdm_telegram_display()

# Generated at 2022-06-24 10:09:57.595864
# Unit test for function trange
def test_trange():
    """Test function `tqdm.contrib.telegram.trange`"""
    from time import sleep
    for _ in trange(5, desc='1st loop', leave=False, disable=False):
        for _ in trange(5, desc='2nd loop', leave=False, disable=False):
            sleep(.1)
    for _ in trange(5, desc='1st loop', leave=True, disable=False):
        for _ in trange(5, desc='2nd loop', leave=True, disable=False):
            sleep(.1)
    for _ in trange(5, desc='1st loop', leave=True, disable=False):
        for _ in trange(5, desc='2nd loop', leave=False, disable=False):
            sleep(.1)


# Generated at 2022-06-24 10:10:07.302563
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from unittest import TestCase
    from contextlib import ExitStack
    from io import StringIO
    from tempfile import NamedTemporaryFile
    from subprocess import Popen, PIPE
    from tqdm.contrib.telegram import TelegramIO
    from tqdm.tests._utils import _mock_popen, _mock_get_monitor_files

    class TestWrite(TestCase):
        def test_telegram_io_write(self):
            token = '23334545'
            chat_id = '23334545'
            t = TelegramIO(token=token, chat_id=chat_id)
            text = 'Hello World'
            with ExitStack() as stack:
                mock_popen = stack.enter_context(_mock_popen(Popen))

# Generated at 2022-06-24 10:10:17.539221
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    import tqdm.auto
    import os
    telegram_token = os.getenv('TQDM_TELEGRAM_TOKEN')
    telegram_chat_id = os.getenv('TQDM_TELEGRAM_CHAT_ID')

    from pytest import raises

    API = 'https://api.telegram.org/bot'
    with tqdm.auto.tqdm() as t:
        with raises(Exception):
            # this raises an Exception since there is no previous message to delete.
            session = Session()
            t._telegram_io = TelegramIO(telegram_token, telegram_chat_id)
            t._telegram_io._message_id = 10
            t._telegram_io.delete()

# Generated at 2022-06-24 10:10:19.873097
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    from _test_utils import FakeTqdmIO
    with FakeTqdmIO(isatty=True) as io:
        tqdm_telegram(total=10, file=io)

# Generated at 2022-06-24 10:10:28.891831
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from os import getenv
    from random import randint
    from time import sleep
    from requests import Session
    from tqdm.auto import tqdm

    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')

    message_ids_dict = dict()
    def telegram_post_send_message(text, chat_id=chat_id):
        """Post to Telegram API sendMessage."""

        url = 'https://api.telegram.org/bot%s/sendMessage' % token
        data = {'text': text, 'chat_id': chat_id, 'parse_mode': 'MarkdownV2'}
        session = Session()
        res = session.post(url, data=data)

        resjson

# Generated at 2022-06-24 10:10:36.607359
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    # check with invalid token & chat_id
    assert TelegramIO('', '').message_id is None
    assert TelegramIO(123, 'invalid').message_id is None
    assert TelegramIO('invalid', 123).message_id is None
    assert TelegramIO('invalid', 'invalid').message_id is None
    assert TelegramIO(
        'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
        'invalid').message_id is None
    assert TelegramIO(
        'invalid',
        'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA').message_id is None

# Generated at 2022-06-24 10:10:46.481748
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    import os

    class TestTelegramIO(TelegramIO):
        def delete(self):
            super(TestTelegramIO, self).delete()
            os.environ['TQDM_TELEGRAM_TEST_DELETE'] = 'OK'

    try:
        tt = TestTelegramIO('', '')
        tt.delete()
    finally:
        if 'TQDM_TELEGRAM_TEST_DELETE' in os.environ:
            assert os.environ['TQDM_TELEGRAM_TEST_DELETE'] == 'OK'
            del os.environ['TQDM_TELEGRAM_TEST_DELETE']


if __name__ == '__main__':
    from doctest import testmod
    testmod(verbose=True)

# Generated at 2022-06-24 10:10:54.011460
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm.auto import tqdm
    text = tqdm(range(10), bar_format="{l_bar}{bar:10u}{r_bar}",
                telegram_chat_id='-345454545', telegram_token='12345:ABCDEF')
    for i in text:
        text.set_description(str(i))


test_tqdm_telegram_display()

# Generated at 2022-06-24 10:10:59.800017
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tgio = TelegramIO(token='917367157:AAG5q3d3b_FJ-Lz5oeoLwH_JZtsfnTSde9M', chat_id=761033692)
    tgio.delete()

# Generated at 2022-06-24 10:11:08.933798
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    # init
    t = TelegramIO('{token}', '{chat_id}')
    # test empty string
    t.write("")
    # test duplicate string
    t.write("")
    t.write("")
    t.write("")
    t.write("")
    t.write("")
    t.write("")
    t.write("")
    t.write("")
    t.write("")
    t.write("")
    # test regular string
    t.write("test")
    # test string with markdown
    t.write("test\n\n*this*\n\n*this*")
    # test string with markdown and multiple lines
    t.write("\n\n*this*\n\n*this*")
    # close
    t.close()

# Generated at 2022-06-24 10:11:13.856224
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """Unit test for `tqdm.contrib.telegram.tqdm_telegram()`"""
    assert tqdm_telegram(total=10, disable=True).close() is None
    assert tqdm_telegram(total=10, leave=True).close() is None
    assert tqdm_telegram(total=10, disable=False).close() is None

# Generated at 2022-06-24 10:11:19.987230
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import sys
    sys.stderr.write('\n')
    # Up to 100 requests/sec, i.e. 10 secs - no more than 5 successful requests
    tgio = TelegramIO('123456789:', '1')
    try:
        for i in range(5):
            tgio.write('...')
            if i == 4:
                break
            tgio.write('')
    except Exception:
        return
    raise RuntimeError('Rate limit not checked')


if __name__ == '__main__':
    from doctest import testmod
    testmod(verbose=True)

# Generated at 2022-06-24 10:11:22.165126
# Unit test for function trange
def test_trange():
    with trange(10, token=tqdm_telegram.token, chat_id=tqdm_telegram.chat_id) as t:
        for i in t:  # NOQA
            sleep(0.1)

# Generated at 2022-06-24 10:11:29.332897
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import time
    import warnings
    import pytest
    try:
        time.sleep
        with pytest.warns(TqdmWarning):
            with warnings.catch_warnings():
                warnings.filterwarnings('ignore', category=TqdmWarning)
                with tqdm(total=1, ascii=True, disable=True) as t:
                    time.sleep(0.01)
                    t.update()
    except KeyboardInterrupt:
        pass

# Generated at 2022-06-24 10:11:39.040611
# Unit test for function trange
def test_trange():
    """Test trange function"""
    from time import sleep
    from sys import platform
    from .utils import _supports_unicode, _range

    def test_trange_unicode(desc=None):
        for _ in trange(5, token=u"✨⭐🌟💫💥", chat_id=u"🔥💥💫💦💧", desc=desc):
            sleep(0.01)

    if platform in {'win32', 'cygwin'}:
        if not _supports_unicode():
            raise unittest.SkipTest("unicode not supported on %s" % platform)
        test_trange_unicode()
        test_trange_unicode("unicode description")
    else:
        test_trange_unicode()


# Generated at 2022-06-24 10:11:49.209294
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    import os
    import sys
    from os import path
    from unittest import TestCase, main
    from datetime import datetime
    from requests import Session

    HERE = path.abspath(path.dirname(__file__))
    TOKEN = os.getenv('TQDM_TELEGRAM_TOKEN')
    CHAT_ID = os.getenv('TQDM_TELEGRAM_CHAT_ID')

    class MockResponse:
        def __init__(self, json_data, status_code):
            self.json_data = json_data
            self.status_code = status_code

        def json(self):
            return self.json_data

    class TestTelegramIO(TestCase):
        def setUp(self):
            self.old_argv = sys.argv
            self

# Generated at 2022-06-24 10:12:00.076651
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm.utils import _term_move_up
    from io import StringIO

    with StringIO() as f:
        tt = tqdm_telegram(range(3), file=f,
                           bar_format='{desc}{percentage:3.0f}%|{bar}|')
        tt.set_description("first")
        tt.update(1, dynamic_ncols=True)
        assert f.getvalue() == "first 0%|{bar:10u}|\n"
        tt.update(1)
        assert f.getvalue() == "first 0%|{bar:10u}|\n" + \
            _term_move_up() + "first 50%|#####      |\n"
        tt.set_description('new first')