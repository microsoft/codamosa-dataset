

# Generated at 2022-06-24 10:01:59.141338
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from .utils_test import _test_tqdm
    for file in [TelegramIO("", "")]:
        _test_tqdm(tqdm_telegram, file = file)

# Generated at 2022-06-24 10:02:04.650726
# Unit test for function trange
def test_trange():
    t = trange(5, token='1372923071:AAEw3qNb6pDU1JU5Q5hEG-9rZ7DU-_eJp7M', chat_id='-1001391024589')
    item_total = len(t)
    t.write("test")
    t.delete()
    assert item_total == 5

# Generated at 2022-06-24 10:02:13.283869
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    try:
        token = getenv('TQDM_TELEGRAM_TOKEN')
        chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    except Exception:
        return
    if token and chat_id:
        with TelegramIO(token, chat_id) as tgio:
            tgio.write("tqdm.contrib.telegram.TelegramIO write test")
            tgio.delete()

# Generated at 2022-06-24 10:02:18.150438
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    telegram = tqdm_telegram(["A", "B", "C"], disable=True)
    telegram2 = tqdm_telegram(["A", "B", "C"], leave=True)
    telegram3 = tqdm_telegram(["A", "B", "C"], position=3)
    telegram4 = tqdm_telegram(["A", "B", "C"])
    try:
        telegram.close()
        telegram2.close()
        telegram3.close()
        telegram4.close()
    except:
        assert False

# Generated at 2022-06-24 10:02:19.917760
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    io = TelegramIO("1", "1")
    io.close()
    io.delete()
    io.delete()

# Generated at 2022-06-24 10:02:29.614433
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    import requests
    from .utils_test import print

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    tg = TelegramIO('test_token', 'test_chat_id')
    tg._message_id = 'test_message_id'

    expected_json = {'ok': True, 'result': True}
    future = tg.delete()

    with patch.object(requests.Session, 'post') as mock:
        mock.return_value = type('MockResponse', (object,), {
            'json': lambda self: expected_json,
        })()
        future.result()

    print(mock.call_args[1]['data'])
    assert mock.called



# Generated at 2022-06-24 10:02:33.236898
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    # Initiate tqdm_telegram with disable=True so that it will not
    # terminate itself automatically
    tqdm_telegram(disable=True)


if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-24 10:02:40.038451
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    for _ in tqdm_telegram(["a", "b", "c"],
                           token=getenv('TQDM_TELEGRAM_TOKEN'),
                           chat_id=getenv('TQDM_TELEGRAM_CHAT_ID')):
        pass

if __name__ == '__main__':
    from os import getenv
    for _ in tqdm_telegram(["a", "b", "c"],
                           token=getenv('TQDM_TELEGRAM_TOKEN'),
                           chat_id=getenv('TQDM_TELEGRAM_CHAT_ID')):
        pass

# Generated at 2022-06-24 10:02:44.432138
# Unit test for function trange
def test_trange():
    iterable = trange(5, token='569312800:AAFYLB5-knw7hxBJyacV7yJ-kKjV7Jsd6hI',
                      chat_id='@tqdm_telegram_test', mininterval=0.1)
    for _ in iterable:
        pass


if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-24 10:02:46.953046
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    """Unit test for constructor of class tqdm_telegram"""
    t = tqdm(token='token', chat_id='id')
    t.close()

# Generated at 2022-06-24 10:02:53.495937
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    # Token & chat_id of testbot
    token = '554682193:AAHbTXSGZr1IxtETJYhqrpOoTRe-0L-TbHg'
    chat_id = '-1001233809529'

    # Test creation
    io = TelegramIO(token, chat_id)


if __name__ == '__main__':
    test_TelegramIO()

# Generated at 2022-06-24 10:03:02.409761
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    """
    It ensures that clear method of tqdm_telegram
    clears the stdout and telegram updates
    """
    # pylint: disable=unused-variable
    import io
    import sys
    from unittest.mock import patch

    # captures stdout from TelegramIO instance
    buf = io.StringIO()
    buf.write = lambda s: None
    # captures stdout from tqdm_telegram instance
    buf1 = io.StringIO()
    with patch("tqdm.auto.tqdm.write_no_catch", lambda s: buf1.write(s)):
        tqdm_telegram(range(1)).clear()
    clear_telegram = buf.getvalue()
    clear_stdout = buf1.getvalue()

    # ensure that stdout and telegram updates are removed

# Generated at 2022-06-24 10:03:10.703638
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import time
    import random
    import requests_mock


# Generated at 2022-06-24 10:03:16.825807
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    io = TelegramIO("API", "chat")
    io.message_id = "message"
    io.delete()
    assert io.session.method == "POST"
    assert io.session.url == "https://api.telegram.org/botAPI/deleteMessage"
    assert io.session.params == {}
    assert io.session.data == {"chat_id": "chat", "message_id": "message"}
    assert io.session.headers == {}
    return


# Generated at 2022-06-24 10:03:25.679053
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    import requests
    import tqdm

    # delete messages if they exist
    token = tqdm.contrib.telegram.tqdm.__all__.__doc__.split('=')[-1][1:-1]
    chat_id = '-1001383098981'
    for m in requests.get(
        f'https://api.telegram.org/bot{token}/getUpdates').json()['result']:
        requests.post(
            f'https://api.telegram.org/bot{token}/deleteMessage',
            data={'chat_id': chat_id, 'message_id': m['message']['message_id']})

    # test messages

# Generated at 2022-06-24 10:03:34.385553
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    """Test method display"""
    import sys
    import random
    random.seed(1)
    token = 'token'
    chat_id = 'chat_id'
    it = tqdm_telegram(random.random, total=10, token=token, chat_id=chat_id,
                       file=sys.stdout)
    for _ in it:
        pass


test_tqdm_telegram_display()



# Generated at 2022-06-24 10:03:40.704274
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import os
    try:
        if os.environ['TRAVIS']:
            return  # skip if on Travis (Travis does not like this test)
    except KeyError:
        pass

    def assertEqual(a, b):
        try:
            assert (a == b)
        except AssertionError:
            print('Failed')
            print('a =', a)
            print('b =', b)
            raise

    # Set up environment
    os.environ['COLUMNS'] = '80'
    os.environ['LINES'] = '40'

    # Tests
    assertEqual(str(tqdm(total=None)),
                '   0%|                                      | 0/?')

# Generated at 2022-06-24 10:03:48.890876
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    token = "123"
    chat_id = "456"
    class MySession:
        def post(self, url, **data):
            return "https://a.b?bot=%s&chat_id=%s" % (token, chat_id)
    class MyException(Exception):
        pass
    tgio = TelegramIO(token, chat_id)
    tgio.session = MySession()
    tgio.message_id = "123456"
    try:
        tgio.delete()
    except:
        pass
    else:
        assert False
    tgio = TelegramIO(token, chat_id)
    tgio.session = MySession()
    tgio.message_id = "123456"
    tgio.submit = lambda f, *a, **kw: f(*a, **kw)
   

# Generated at 2022-06-24 10:04:00.036001
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import os
    import textwrap
    import time

    from collections import namedtuple
    from tempfile import NamedTemporaryFile
    from unittest import TestCase
    from unittest.mock import patch

    from .telegram import (TelegramIO, tqdm, trange)

    class TqdmTelegramClearTest(TestCase):
        def test_tqdm_telegram_clear(self):
            with patch('tqdm.auto.tqdm.write') as mock_write, \
                    NamedTemporaryFile() as tmp:
                print('', file=tmp)
                for i in trange(4):
                    time.sleep(0.1)
                print('', file=tmp)
                for i in trange(2, file=tmp):
                    time.sleep(0.1)

# Generated at 2022-06-24 10:04:11.520666
# Unit test for function trange
def test_trange():
    from time import sleep
    from requests import Session, post
    # Clean up chats
    s = Session()

# Generated at 2022-06-24 10:04:17.051773
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    """Sends a message to a Telegram Bot and then deletes it."""
    tg = TelegramIO('{token}', '{chat_id}')
    if tg.message_id is None:
        print("TelegramIO was not able to create a message with the given "
              "`chat_id` & `token`, see the error above.")
        return
    try:
        tg.write("Test message to be deleted.")
        tg.delete()
    except Exception as e:
        print("TelegramIO was not able to delete the message, see the error "
              "above.")
    else:
        print("Test passed: the message was deleted.")

# Generated at 2022-06-24 10:04:26.119898
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    token = getenv('TQDM_TELEGRAM_TOKEN', '123')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID', '123')
    token2 = getenv('TQDM_TELEGRAM_TOKEN', '456')
    chat_id2 = getenv('TQDM_TELEGRAM_CHAT_ID', '456')
    token3 = getenv('TQDM_TELEGRAM_TOKEN', '789')
    chat_id3 = getenv('TQDM_TELEGRAM_CHAT_ID', '789')

    # Testing message sent with different tokens and chat_id
    pbar = tqdm_telegram(token=token, chat_id=chat_id)
    pbar.display()
    pbar.close()
    pbar

# Generated at 2022-06-24 10:04:37.569647
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    from nose.tools import assert_equal
    import sys

    class MockTelegramIO(TelegramIO):
        def __init__(self, *args, **kwargs):
            self.send = []
            self.delete = []
            super(MockTelegramIO, self).__init__(*args, **kwargs)

        def write(self, s):
            self.send.append(s)

        def delete(self):
            self.delete.append('delete')

    sys.stdout.write = lambda *_: None
    tr = trange(2, ascii=False, token='token', chat_id='chat_id')
    assert_equal(tr.tgio.__class__.__name__, 'MockTelegramIO')
    tr._decr_instances

# Generated at 2022-06-24 10:04:43.286978
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    # Create an iterable object
    iterable = list(range(3))
    # Create a tqdm_telegram object
    telegram_tqdm = tqdm_telegram(iterable)
    telegram_tqdm.close()
    # Check if the iterable has been used
    assert "0/3" in telegram_tqdm.format_dict['bar_format']
    # Check that the iterable has been used again
    telegram_tqdm.close()
    assert '3/3' in telegram_tqdm.format_dict['bar_format']

# Generated at 2022-06-24 10:04:51.620744
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    try:
        import pytest
    except ImportError as e:
        raise ImportError(e.__class__.__name__ + ": " + str(e) +
                          "\n`pip install tqdm[tests]` to enable!")
    pytest.main(['-svx', __file__, '-k', 'test_tqdm_telegram_display'])


if __name__ == "__main__":
    from tqdm.auto import tqdm
    from .utils_telegram import _print_version, _test_imports

    _print_version()  # print version information
    _test_imports()


# Generated at 2022-06-24 10:04:52.674879
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    io = TelegramIO('1', '2')
    io.write('3')

# Generated at 2022-06-24 10:04:58.381991
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    token = getenv('TQDM_TELEGRAM_TOKEN')
    if chat_id and token:
        tg = TelegramIO(token, chat_id)
        tg.delete()

if __name__ == '__main__':  # pragma: no cover
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 10:05:07.286545
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    tqdm(None, display_format=None)
    tqdm(None, display_format="{bar} {r_bar}")
    tqdm(None, display_format="{bar}")
    tqdm(None, display_format="{percentage:3.0f}%")
    tqdm(None, display_format="{percentage:3.0f}% {bar} {n_fmt}/{total_fmt}")
    tqdm(None, display_format="{n_fmt}/{total_fmt}")
    tqdm(None, display_format="{bar} {n_fmt}/{total_fmt}")
    tqdm(None, display_format="{bar} {rate_fmt}{postfix}")

# Generated at 2022-06-24 10:05:15.145732
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    """Test the constructor of class tqdm_telegram"""
    t = tqdm_telegram(token='token', chat_id='chat_id')
    assert t.tgio.token == 'token'
    assert t.tgio.chat_id == 'chat_id'
    assert t.disable == False

    t.close()

    t = tqdm_telegram(token='token', chat_id='chat_id', disable=True)
    assert t.tgio is None
    assert t.disable == True
    assert t.token == 'token'
    assert t.chat_id == 'chat_id'


# Generated at 2022-06-24 10:05:21.058160
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    t = tqdm_telegram(
        token=getenv('TQDM_TELEGRAM_TOKEN'), chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'))
    t.total = None
    t.display()
    t.n = 1000
    t.total = 2000
    t.display()
    t.close()



# Generated at 2022-06-24 10:05:24.054410
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    try:
        TelegramIO('', '')
    except:
        pass

if __name__ == '__main__':
    test_TelegramIO()

# Generated at 2022-06-24 10:05:31.599040
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    """Test whether a message is created."""
    from os import getenv
    from .utils_test import get_test_chat_id
    chat_id = get_test_chat_id()
    token = getenv('TQDM_TELEGRAM_TOKEN')
    # clear old messages
    TelegramIO(token, chat_id).delete()
    # create message & delete it
    TelegramIO(token, chat_id).delete().result()

# Generated at 2022-06-24 10:05:42.870373
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import io
    import sys

    with io.StringIO() as f, tqdm_telegram(
            total=None, file=f, ncols=0, ascii=None, disable=True,
            unit='foo', unit_scale=None, dynamic_ncols=False, miniters=0,
            mininterval=0.1, mininterval_dynamic=False,
            maxinterval=10.0, maxinterval_dynamic=False,
            smoothing=0.3, bar_format='{l_bar}{bar:10u}{r_bar}',
            initial=0, position=0, leave=False, postfix=None,
            unit_divisor=1000) as t:
        for i in range(4):
            t.display()


# Generated at 2022-06-24 10:05:52.515809
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    assert tqdm_telegram(1, token='X', chat_id='Y').token == 'X'
    assert tqdm_telegram(1, token='X', chat_id='Y').chat_id == 'Y'
    assert tqdm_telegram(1, token='X', chat_id='Y').tgio is not None
    assert tqdm_telegram(1, token='X', chat_id='Y').tgio.token == 'X'
    assert tqdm_telegram(1, token='X', chat_id='Y').tgio.chat_id == 'Y'
    assert tqdm_telegram('a', token='X').token == 'X'



# Generated at 2022-06-24 10:05:57.457858
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    try:
        # test class tqdm_telegram with no token or chat_id argument
        with tqdm_telegram(total=10, token=None, chat_id=None) as t:
            t.update()
        # test class tqdm_telegram with no token and chat_id argument
        with tqdm_telegram(total=10, disable=True) as t:
            t.update()
    except Exception:
        raise

# Generated at 2022-06-24 10:06:01.433862
# Unit test for function trange
def test_trange():
    for _ in trange(10, token='1234', chat_id='5678'):
        pass

# Generated at 2022-06-24 10:06:04.560522
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    tg = TelegramIO('{token}', '{chat_id}')
    tg.write("hello!")
    tg.write("goodbye!")
    tg.delete()

if __name__ == '__main__':
    test_TelegramIO()

# Generated at 2022-06-24 10:06:12.071399
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    # This is a unit test for the clear method of the tqdm_telegram class.
    # It checks whether the method is properly clearing the telegram progress
    # bar, by making sure the text at the end of the progress bar is an empty
    # string.
    tg_bar = tqdm_telegram(total=5, token='5G5fUbaywRdNRpN-ZL-NxyEqX3MgtiNy', chat_id='-513978302')

    tg_bar.update(5)
    tg_bar.clear()
    # check whether the text of the telegram progress bar is now the empty string
    assert("" == tg_bar.tgio.text)

    # make sure that the tqdm progress bar is now also cleared

# Generated at 2022-06-24 10:06:13.851511
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    try:
        TelegramIO('token', 'chat_id')
    except Exception as e:
        raise e

# Generated at 2022-06-24 10:06:20.436387
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    prev_token = getenv('TQDM_TELEGRAM_TOKEN')
    prev_chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    try:
        setenv('TQDM_TELEGRAM_TOKEN', '')
        setenv('TQDM_TELEGRAM_CHAT_ID', '')
        with tqdm_telegram(total=0):
            pass
    except:
        setenv('TQDM_TELEGRAM_TOKEN', prev_token)
        setenv('TQDM_TELEGRAM_CHAT_ID', prev_chat_id)
        raise

# Generated at 2022-06-24 10:06:27.587555
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import sys
    import math

    # Mock get_terminal_size(), so that we don't depend on the actual terminal
    # width (and make the test independent from the user's terminal size of the
    # moment).
    def get_terminal_size(fallback=(80, 24)):
        return (80, 24)
    tqdm_telegram.get_terminal_size = get_terminal_size

    # Mock the stream
    class _TestStream():
        def __init__(self):
            self._data = ""

        def write(self, data):
            self._data += data

        def flush(self):
            pass

    sys.stdout = _TestStream()
    io = TelegramIO("", "")


# Generated at 2022-06-24 10:06:39.063306
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm import tqdm
    from tqdm.contrib import telegram

    # Default bar_format
    tg = telegram.tqdm_telegram(
        total=100, miniters=10)
    tg.display()
    tg.close()

    # Custom bar_format
    tg = telegram.tqdm_telegram(
        total=100, miniters=10,
        bar_format='Test: {l_bar}{bar:10u}{r_bar}')
    tg.display()
    tg.close()

    # Non default bar_format with non default bar_format_dict

# Generated at 2022-06-24 10:06:43.772960
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    from os import path, mkdir

    if not path.exists('./cache'):
        mkdir('./cache')

    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')

    with open('./cache/tqdm.log', 'w') as f:
        with TelegramIO(token, chat_id) as tgio:
            for i in _range(10):
                f.write(str(i) + '\n')

# Generated at 2022-06-24 10:06:52.177573
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    assert tqdm_telegram(
        100, position=0, mininterval=0, miniters=1,
        token='SOME_TOKEN', chat_id='SOME_CHAT_ID',
        ascii=True, disable=True, unit='i', unit_scale=True,
        desc='des', leave=True, dynamic_ncols=True,
        file=None, bar_format='{l_bar}{bar:10u}{r_bar}',
        initial=0, total=None, maxinterval=None
    ).display() is None

# Generated at 2022-06-24 10:06:59.442077
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from . import _supports_unicode
    t = tqdm_telegram(total=10, unit='iB', unit_scale=True,
                      miniters=1, mininterval=0,
                      **({'desc': 'Tèst'} if _supports_unicode else {}))

    assert (t.format_dict['bar_format'] ==
            '{l_bar} {desc}{bar:10u}{percentage:3.0f}% {rate_fmt}'
            '{postfix_fmt}  {remaining:6}{r_bar}')

    t.display()
    assert t.tgio.text == 'Tèst   0  0%  0.00iB/s'

    t.update(1)

# Generated at 2022-06-24 10:07:05.177085
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    import time
    result = []
    with tqdm(total=None, disable=False, leave=False) as pbar:
        pbar.close()
        result.append(pbar.tgio.message_id is None)
    time.sleep(0.11)
    with tqdm(total=None, disable=False, leave=True) as pbar:
        pbar.close()
        result.append(pbar.tgio.message_id is None)
    time.sleep(0.11)
    with tqdm(total=None, disable=False, leave=None) as pbar:
        pbar.close()
        result.append(pbar.tgio.message_id is not None)
    time.sleep(0.11)

# Generated at 2022-06-24 10:07:08.308168
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tg = TelegramIO("12345:abcdefghijklmnopqrstuvwxyz012345", "12345678")
    tg.write("bla bla bla")


# Generated at 2022-06-24 10:07:17.266158
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    if 'TQDM_TELEGRAM_TOKEN' in globals() or \
       'TQDM_TELEGRAM_CHAT_ID' in globals():
        tg = TelegramIO(TQDM_TELEGRAM_TOKEN, TQDM_TELEGRAM_CHAT_ID)
        tg.write('`test_TelegramIO`')
        tg.delete()

if __name__ == '__main__':
    test_TelegramIO()

# Generated at 2022-06-24 10:07:27.571246
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    from os import environ
    # The following 2 lines allows the unit-test to only be performed
    # if the bot tqdm_beta is available (i.e. if the
    # corresponding environment variables are set)
    token, chat_id = (environ['TQDM_TELEGRAM_TOKEN'],
                      environ['TQDM_TELEGRAM_CHAT_ID'])
    tgio = TelegramIO(token, chat_id)
    # The following line allows to be sure that the first message
    # has been sent
    tgio.message_id
    # We then delete the message sent
    tgio.delete()
    assert tgio.message_id is None

# Generated at 2022-06-24 10:07:35.680764
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tg1 = TelegramIO('{token}', '{chat_id}')
    tg2 = TelegramIO('{token}', '{chat_id}')
    assert tg1.write('test_TelegramIO_write') == tg1.write('test_TelegramIO_write') and not tg1.write('test_TelegramIO_write') == tg2.write('test_TelegramIO_write')
    assert str(tg1.write('test_TelegramIO_write')) == str(tg2.write('test_TelegramIO_write')) and not str(tg1.write('test_TelegramIO_write')) == str(tg1.write('test_TelegramIO_write'))
    tg1.write('test_TelegramIO_write').result()

# Generated at 2022-06-24 10:07:44.218715
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    TelegramIO('123', '123').delete()


if __name__ == '__main__':
    from sys import argv
    from time import sleep
    if len(argv) > 1:
        tqdm_telegram(argv[1:], ncols=40).close()
    else:
        for _ in tqdm_telegram(ttgrange(50), desc='1st loop'):
            for _ in tqdm(ttgrange(10), desc='2nd loop', leave=False):
                sleep(1)
            sleep(0.5)

# Generated at 2022-06-24 10:07:48.590470
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    tgio = TelegramIO("{token}", "{chat_id}")
    assert tgio.token == "{token}"
    assert tgio.chat_id == "{chat_id}"
    assert tgio.session is not None
    assert tgio.text == "TelegramIO"
    assert tgio.message_id is not None
    tgio.write("Write")
    assert tgio.text == "Write"
    tgio.delete()

# Generated at 2022-06-24 10:07:51.521544
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    import sys
    with tqdm_telegram(total=10, leave=False) as pbar:
        for i in pbar:
            sys.stdout.write(str(i))

# Generated at 2022-06-24 10:08:01.072903
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import sys
    sys.stdout.write("Checking class TelegramIO.write() for syntax errors... ")
    tgio = TelegramIO("token", "chat_id")
    # noinspection PyBroadException
    try:
        tgio.write("")
        tgio.write("test")
    except Exception as e:
        from traceback import format_exc
        sys.stdout.write("\t\033[91mfailed\033[0m\n")
        sys.stdout.write("\ntraceback:\n")
        sys.stdout.write(format_exc())
        sys.exit(1)
    sys.exit(0)


if __name__ == "__main__":
    test_TelegramIO_write()

# Generated at 2022-06-24 10:08:05.369701
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    from .main_telegram import test_tqdm_telegram_close
    test_tqdm_telegram_close()


if __name__ == '__main__':
    test_TelegramIO_delete()

# Generated at 2022-06-24 10:08:09.694488
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    message1 = "This is a test message"
    message2 = "This is another test message"

    token = None
    chat_id = None

    tgio = TelegramIO(token=token, chat_id=chat_id)
    tgio.write(message1)
    tgio.write(message2)

# Generated at 2022-06-24 10:08:14.325709
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tgio = TelegramIO('token', 'chat_id')
    assert tgio.message_id == 1345
    tgio.delete()

if __name__ == '__main__':
    import doctest
    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-24 10:08:16.764556
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    assert TelegramIO('tocken', 'chat_id').delete() == None

test_TelegramIO_delete()

# Generated at 2022-06-24 10:08:28.860921
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    assert (tqdm_telegram('100').total == 100)
    assert (tqdm_telegram('100', total=150).total == 100)
    assert (tqdm_telegram('100', total=50).total == 50)
    assert (tqdm_telegram(['1', '2']).total == 2)
    assert (tqdm_telegram(['1', '2'], dynamic_ncols=True).total == 2)
    assert (tqdm_telegram(iterable='123').total == 3)
    assert (tqdm_telegram(iterable='123', ncols=999).total == 3)
    assert (tqdm_telegram(iterable='123', ncols=80).total == 3)

# Generated at 2022-06-24 10:08:35.315003
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    control = ' '
    t = tqdm_telegram(range(1, 10), token='1234567890:AAECDEFG', chat_id='0', bar_format='{l_bar}{bar}{r_bar} ',
                      )
    t.write(control)
    t.clear()
    t.write(control)
    t.close()
    t.write(control)



# Generated at 2022-06-24 10:08:42.087147
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """
    Unit test for method close of class tqdm_telegram

    This test also serves as an example of how to use tqdm_telegram.
    """
    td_tg = tqdm_telegram(range(20), token='{token}', chat_id='{chat_id}')
    for i in td_tg:
        pass
    td_tg.close()

    td_tg = tqdm_telegram(range(20), token='{token}', chat_id='{chat_id}', leave=False)
    for i in td_tg:
        pass
    td_tg.close()

    td_tg = tqdm_telegram(range(20), token='{token}', chat_id='{chat_id}', leave=True)
    for i in td_tg:
        pass

# Generated at 2022-06-24 10:08:48.375761
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    """
    Performs unit test for method delete of class TelegramIO
    """
    from subprocess import run, PIPE
    command = """from pprint import pprint
from os import environ
from requests import Session
from tqdm.contrib.telegram import TelegramIO

# Init TelegramIO
tgio = TelegramIO(environ['TQDM_TELEGRAM_TOKEN'], environ['TQDM_TELEGRAM_CHAT_ID'])

# Send message, get message_id
tgio.write("Test tqdm.contrib.telegram.test_TelegramIO_delete()")
pprint(tgio.message_id)

# Delete message
tgio.delete()

# Print message_id
tgio.clear()
pprint(tgio.message_id)
"""
    # Run

# Generated at 2022-06-24 10:08:49.812434
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    ti = TelegramIO('', '')
    ti.write('hello')

# Generated at 2022-06-24 10:09:00.144610
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from os import environ
    from time import sleep
    from requests import Session
    token = environ.get('TQDM_TELEGRAM_TOKEN', '{token}')
    chat_id = environ.get('TQDM_TELEGRAM_CHAT_ID', '{chat_id}')
    s = Session()
    s.post('https://api.telegram.org/bot%s/sendMessage' % token,
           data={'text': 'Test started.', 'chat_id': chat_id})
    sleep(1)
    tgio = TelegramIO(token, chat_id)
    tgio.text = 'Test'
    tgio.write('Testing...')
    sleep(1)
    tgio.write('Testing...')
    sleep(1)
    tgio.write('Testing...')

# Generated at 2022-06-24 10:09:04.421331
# Unit test for function trange
def test_trange():
    for _ in trange(4, 4):
        pass


if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-24 10:09:11.789729
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    """Test class TelegramIO"""
    tg = TelegramIO('asdf', 'asdf')
    assert tg.message_id is None
    # with patch('tqdm._tqdm.tqdm_telegram.tgio.message_id') as mock:
    #     tg.delete()
    #     mock.assert_not_called()
    # with patch('tqdm._tqdm.tqdm_telegram.tgio.message_id') as mock:
    #     mock.return_value = 1234
    #     tg.delete()
    #     mock.assert_called_with(self=tg)

# Generated at 2022-06-24 10:09:17.440950
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    _telegramio = TelegramIO("token", "chat_id")
    assert hasattr(_telegramio, "token")
    assert hasattr(_telegramio, "chat_id")
    assert hasattr(_telegramio, "session")
    assert hasattr(_telegramio, "text")
    assert hasattr(_telegramio, "message_id")


# Generated at 2022-06-24 10:09:27.369176
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    # Test 1: Test that creating a tqdm_telegram object with no token and chat_id will result in a terminal output.
    try:
        from io import StringIO
        from sys import stdout
        from requests import RequestException
        pbar = tqdm_telegram(total=12, file=StringIO())
        pbar.write('Hello World!')
        pbar.close()

        pbar = tqdm_telegram(total=12, file=stdout)
        pbar.write('Hello World!')
        pbar.close()
        assert True
    except Exception as e:
        assert type(e) == RequestException

    # Test 2: Test that creating a tqdm_telegram object with a token and chat_id will not result in a terminal output.

# Generated at 2022-06-24 10:09:32.792692
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    # Test case for non-existent token.
    token = 'non-existent-token'
    chat_id = 'non-existent-chat_id'
    try:
        TelegramIO(token, chat_id).delete()
    except Exception as e:
        assert str(e) == '400 Client Error: Bad Request for url: https://api.telegram.org/bot{b}/deleteMessage?chat_id=non-existent-chat_id&message_id=None'.format(b=token)
    else:
        assert False, "Exception not raised"

# Generated at 2022-06-24 10:09:42.922613
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import pickle,  io

    with io.BytesIO() as f:
        for i in tqdm([1, 2, 3], file=f, desc='test'):
            pass

        f.seek(0)
        p = pickle.load(f)
        assert p.bar_format == '{l_bar}{bar:10u}{r_bar}'
        assert p.desc == 'test'


# Generated at 2022-06-24 10:09:47.096532
# Unit test for function trange
def test_trange():  # pragma: no cover
    io = TelegramIO(getenv('TQDM_TELEGRAM_TOKEN'),
                    getenv('TQDM_TELEGRAM_CHAT_ID'))
    io.write("tqdm_telegram function test...")
    for i in ttgrange(10):
        io.write("tqdm_telegram: %04i" % i)
    io.delete()

# Generated at 2022-06-24 10:09:51.573777
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    """ Checks if the method tqdm_telegram.display works correctly """

    # Check if the method works:
    # - when total not in kwargs
    # - when unit in kwargs
    # - when unit not in kwargs:
    tg = tqdm_telegram(total=100)
    tg.display(n=25, unit="")
    tg.display(n=25, unit="test")
    tg.display(n=25)



# Generated at 2022-06-24 10:09:54.734983
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    t1 = TelegramIO('token', 'chat_id')
    assert t1.message_id is not None
    t1.write('text1')
    assert t1.text == 'text1'
    t1.write('text2')
    assert t1.text == 'text2'
    t1.close()
    assert t1.message_id is None

# Generated at 2022-06-24 10:09:58.338762
# Unit test for function trange
def test_trange():
    """Unit test for trange"""
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    list(trange(3, token=token, chat_id=chat_id))

# Generated at 2022-06-24 10:10:07.639365
# Unit test for function trange
def test_trange():
    """Test for trange()"""
    import sys
    import os
    # Use `echo $TQDM_TELEGRAM_TOKEN $TQDM_TELEGRAM_CHAT_ID` on Travis CI
    if (os.getenv('TRAVIS') == 'true'
            and not os.getenv('TQDM_TELEGRAM_TOKEN')
            and not os.getenv('TQDM_TELEGRAM_CHAT_ID')):
        return

# Generated at 2022-06-24 10:10:16.043868
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    # Test defaults
    t = tqdm_telegram()
    assert t.tgio.token == getenv('TQDM_TELEGRAM_TOKEN')
    assert t.tgio.chat_id == getenv('TQDM_TELEGRAM_CHAT_ID')
    # Test initialization
    t = tqdm_telegram('a', 'b', 'c', 'd', token='a', chat_id='b', c='d')
    assert t.tgio.token == 'a'
    assert t.tgio.chat_id == 'b'
    assert t.kwargs['c'] == 'd'
    # Test unit test itself
    assert ttgrange(1, 5) == [1, 2, 3, 4]

# Generated at 2022-06-24 10:10:27.176540
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import doctest
    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-24 10:10:32.304846
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    with tqdm_telegram(10, token='TOKEN', chat_id='CHAT_ID') as t:
        for elem in t:
            t.update()
    with tqdm_telegram(10, token='TOKEN', chat_id='CHAT_ID', leave=False) as t:
        for elem in t:
            t.update()
    with tqdm_telegram(10, token='TOKEN', chat_id='CHAT_ID', leave=True) as t:
        for elem in t:
            t.update()

# Generated at 2022-06-24 10:10:36.648995
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id= getenv('TQDM_TELEGRAM_CHAT_ID')
    io = TelegramIO(token=token,chat_id=chat_id)
    io.message_id
    io.delete()

# Generated at 2022-06-24 10:10:39.327238
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    assert TelegramIO(getenv('TQDM_TELEGRAM_TOKEN'), getenv('TQDM_TELEGRAM_CHAT_ID')).delete() is not None

# Generated at 2022-06-24 10:10:43.088680
# Unit test for function trange
def test_trange():
    """Test unitary function trange"""
    with trange(10, token='{token}', chat_id='{chat_id}') as t:
        for i in t:  # loop with trange object
            pass
        assert len(t) == 10

# Generated at 2022-06-24 10:10:54.811598
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from time import sleep
    from tqdm.contrib.telegram import tqdm, trange
    from io import StringIO

    class StringIO(StringIO):
        def __init__(self, *args, **kwargs):
            super(StringIO, self).__init__(*args, **kwargs)
            self._last = 0

        def write(self, *args, **kwargs):
            super(StringIO, self).write(*args, **kwargs)
            self._last = self.tell() - 1

        def check(self, stream, last=None):
            assert self.getvalue()[last or self._last] == stream.read(1)
            assert self.getvalue()[last or self._last] == stream.read(1)


# Generated at 2022-06-24 10:10:56.660509
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    a = tqdm(range(10, 20), token='test', chat_id='test')
    for i in a:  # this loop is required for a.disable to become false
        pass
    a.close()
    assert a.tgio.write("") is not None

# Generated at 2022-06-24 10:11:04.584941
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if token and chat_id:
        tgio = TelegramIO(token, chat_id)
        tgio.write("Testing 1 2 3...")
    else:
        warn("Cannot test TelegramIO: `TQDM_TELEGRAM_TOKEN` or"
             " `TQDM_TELEGRAM_CHAT_ID` not set.", TqdmWarning)

# Generated at 2022-06-24 10:11:15.473378
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from time import sleep
    from pytest import raises

    def check_tqdm_telegram_close(leave):
        with tqdm(leave=leave, token=getenv('TQDM_TELEGRAM_TOKEN'),
                  chat_id=getenv('TQDM_TELEGRAM_CHAT_ID')) as t:
            for i in range(4):
                t.update()
                sleep(0.5)

    check_tqdm_telegram_close(leave=True)
    with raises(RuntimeError):  # t.delete() runtime error
        check_tqdm_telegram_close(leave=False)


# Test tqdm_telegram
if __name__ == "__main__":
    from time import sleep

# Generated at 2022-06-24 10:11:17.392327
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    for _ in tqdm_telegram(range(3), ncols=0, desc='test',
                           token=getenv('TQDM_TELEGRAM_TOKEN'),
                           chat_id=getenv('TQDM_TELEGRAM_CHAT_ID')):
        pass

# Generated at 2022-06-24 10:11:28.016539
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from datetime import datetime
    from time import sleep
    from unittest import TestCase, main
    from unittest.mock import patch

    import requests

    class tqdm_telegram_display_Tests(TestCase):
        def mock_get(url, timeout):
            sleep(.01)
            return dict(json=lambda: dict(result=dict(message_id="12345")))

        @patch('requests.Session')
        @patch('requests.get', side_effect=mock_get)
        def test_tqdm_telegram_display(self, mock_get, mock_session):
            tg = tqdm_telegram(total=1000, smoothing=0.0, desc="Test", unit="B")
            tg.refresh()
            tg.display()
           

# Generated at 2022-06-24 10:11:34.668920
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    with getenv('TQDM_TELEGRAM_TOKEN') as token, \
            getenv('TQDM_TELEGRAM_CHAT_ID') as chat_id:
        try:
            TelegramIO(token, chat_id)
        except Exception as e:
            warn("Failed! %s" % str(e), TqdmWarning)
        else:
            warn("Ok. Check Telegram Bot.", TqdmWarning)

# Generated at 2022-06-24 10:11:37.483941
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    io = TelegramIO('token', 'chat_id')
    io.delete()


if __name__ == '__main__':
    from doctest import testmod
    testmod(verbose=True)

# Generated at 2022-06-24 10:11:42.710919
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    try:
        t = tqdm_telegram(range(10), disable=True)
        t.close()
    except Exception as e:
        print(repr(e))

if __name__ == '__main__':
    test_tqdm_telegram_clear()

# Generated at 2022-06-24 10:11:49.968998
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    import io
    import sys
    sys.stderr = io.StringIO()
    t = tqdm_telegram(_range(10), desc='DESC', token='TOKEN', chat_id='ID')
    try:
        t.start()
    except Exception as e:
        tqdm_auto.write(str(e))


if __name__ == "__main__":
    test_tqdm_telegram()

# Generated at 2022-06-24 10:12:00.098690
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from io import StringIO
    import sys
    f = StringIO()