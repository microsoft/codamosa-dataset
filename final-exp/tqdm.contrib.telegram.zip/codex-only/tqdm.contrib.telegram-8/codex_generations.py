

# Generated at 2022-06-24 10:01:50.648187
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    TelegramIO(getenv('TQDM_TELEGRAM_TOKEN'), getenv('TQDM_TELEGRAM_CHAT_ID'))

# Generated at 2022-06-24 10:01:54.281364
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    """
    Check if method write is working properly.
    """
    token = '{token}'
    chat_id = '{chat_id}'
    telegram_io = TelegramIO(token, chat_id)
    sample_str = telegram_io.write("This is a test")
    assert len(sample_str) == 0

# Generated at 2022-06-24 10:02:00.757752
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    t = tqdm_telegram(total=100)
    t.display()
    assert '\r' not in t.format_dict['bar_format']
    assert 'bar>' not in t.format_dict['bar_format']
    assert '{bar}' not in t.format_dict['bar_format']
    assert '{bar:10u}' in t.format_dict['bar_format']

# Generated at 2022-06-24 10:02:02.851837
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    assert TelegramIO("", "").delete() is None

# Generated at 2022-06-24 10:02:12.488316
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm._utils import _term_move_up

    class FakeTqdmTelegram(tqdm_telegram):
        def __init__(self, *args, **kwargs):
            super(FakeTqdmTelegram, self).__init__(*args, **kwargs)
            self._instances = []

        def write(self, line):
            self._instances.append(line)

        @property
        def ncols(self):
            return 80

    ftg = FakeTqdmTelegram(range(7))
    ftg.refresh()
    assert ftg._instances[-1] == _term_move_up() + '\r' + \
        '  0%|          | 0/7 [00:00<?, ?it/s]\x1b[A'
    ft

# Generated at 2022-06-24 10:02:19.459190
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import json
    from copy import copy
    from requests import Response
    from unittest.mock import MagicMock

    class Response200(Response):
        status_code = 200

    class Response400(Response):
        status_code = 400

    session_mock = MagicMock()

# Generated at 2022-06-24 10:02:20.348826
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    TelegramIO(None, None)

# Generated at 2022-06-24 10:02:30.064958
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import re
    import random
    from io import StringIO
    from tqdm import tqdm as tqdm_normal

    def get_from_stdout(str_func):
        """
        Get a string from str_func
        """
        stdout_old = tqdm_normal.monitor_interval
        tqdm_normal.monitor_interval = 0
        stdout = StringIO()
        with tqdm_normal.hooks.make_visible():
            with tqdm_normal.std_write_mode(stdout):
                str_func()
        tqdm_normal.monitor_interval = stdout_old
        return stdout.getvalue().replace('\r', '')

    # Get token and chat_id
    token = getenv('TQDM_TELEGRAM_TOKEN')

# Generated at 2022-06-24 10:02:38.794197
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    """
    Unit test for method delete of class TelegramIO

    See https://docs.python.org/3/library/unittest.html for more info.
    """
    import unittest

    class TestTelegramIO(unittest.TestCase):
        """Test class for the method delete of class TelegramIO"""

        def test_delete_method_for_unset_message_id(self):
            """
            Test the method delete of class TelegramIO when
            the attribute message_id is not set.
            """
            tg_io = TelegramIO(token='any_token', chat_id='any_chat_id')
            self.assertEqual(tg_io.delete(), None)


# Generated at 2022-06-24 10:02:46.590064
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    try:
        from pytest import approx
    except ImportError:
        approx = lambda x, y: abs(x - y) < 1e-6

    t = tqdm(total=9)  # noqa
    t.update(3)  # noqa
    t.display()  # noqa
    t.n = 5  # noqa
    t.smoothing = 0.5  # noqa
    t.display()  # noqa
    t.n = 4  # noqa
    t.smoothing = 1.0  # noqa
    t.display()  # noqa
    t.n = 5  # noqa
    t.smoothing = 0.5  # noqa
    t.display()  # noqa
    t.n = 6  # noqa
    t.smoot

# Generated at 2022-06-24 10:02:51.087127
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tg = TelegramIO('446622242:AAFIbU6d_uVn2_FYZgI6xBxkpjJ6TJSdCpM', '-248901369')
    tg.delete()
    tg.close()

# Generated at 2022-06-24 10:02:56.933980
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    i = TelegramIO('TOKEN', 'CHAT_ID')
    assert i.write('') is None
    assert i.write('a_')
    assert i.close()
    assert i.write('b_') is None



# Generated at 2022-06-24 10:02:59.528225
# Unit test for function trange
def test_trange():
    for _ in trange(5, token=getenv('TQDM_TELEGRAM_TOKEN'),
                    chat_id=getenv('TQDM_TELEGRAM_CHAT_ID')):
        pass

# Generated at 2022-06-24 10:03:03.240720
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(total=10, leave=False)
    t.close()


# Generated at 2022-06-24 10:03:05.375715
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    io = TelegramIO('tok', 'chat')
    io.message_id
    io.write('t1\n')
    io.write('t1')
    io.write('t2')
    io.write('t3')

# Generated at 2022-06-24 10:03:11.161058
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from io import StringIO
    from sys import version_info

    class CustomIO(StringIO):
        """File-like IO that records write operations"""
        writes = []

        def write(self, s):
            self.writes.append(s)

        def clear(self):
            self.writes = []

    class TqdmMock(tqdm_telegram):
        """tqdm_telegram with a mocked file object"""
        def __init__(self, *args, **kwargs):
            super(TqdmMock, self).__init__(*args, **kwargs)
            self.fo = CustomIO()
            self.file = self.fo

    tm = TqdmMock(total=10, miniters=1)
    for i in range(tm.total + 1):
        t

# Generated at 2022-06-24 10:03:13.718966
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    import os
    import time
    # TODO: write unit test

if __name__ == '__main__':
    test_TelegramIO_delete()

# Generated at 2022-06-24 10:03:16.865781
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tg = TelegramIO(token='', chat_id='')
    assert tg.write('test') is None
    assert tg.write('') is None
    assert tg._message_id is None


# Generated at 2022-06-24 10:03:25.716814
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    # Test Base Case
    example_token = "1234"
    example_chat_id = "5678"
    tqdm_telegram(token=example_token, chat_id=example_chat_id)
    # Test failure, missing token
    try:
        tqdm_telegram(chat_id=example_chat_id)
    except IOError as e:
        print(e)
        pass
    # Test failure, missing chat_id
    try:
        tqdm_telegram(token=example_token)
    except IOError as e:
        print(e)
        pass
    # Test failure, missing both
    try:
        tqdm_telegram()
    except IOError as e:
        print(e)
        pass

test_tqdm_telegram()

# Generated at 2022-06-24 10:03:37.815531
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    """Test method `delete` of class `TelegramIO`."""
    import time
    from os import environ

    token = environ.get('TQDM_TELEGRAM_TOKEN', 'FAKE_TOKEN')
    chat_id = environ.get('TQDM_TELEGRAM_CHAT_ID', 'FAKE_CHAT_ID')

# Generated at 2022-06-24 10:03:45.742025
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    try:
        from unittest.mock import MagicMock, patch
    except ImportError:
        # python 2
        from mock import MagicMock, patch
    tg = TelegramIO("FAKE_TOKEN", "FAKE_CHAT_ID")
    tg.session.post = MagicMock()
    tg.message_id = "FAKE_MESSAGE_ID"
    tg.delete()
    assert tg.session.post.call_count == 1, "Error in TelegramIO delete"

# Generated at 2022-06-24 10:03:50.452143
# Unit test for function trange
def test_trange():
    from .tests_telegram import test_trange as _test_trange
    with tqdm(total=100) as pbar:
        for i in trange(_test_trange,
                        token=getenv('TQDM_TELEGRAM_TOKEN'),
                        chat_id=getenv('TQDM_TELEGRAM_CHAT_ID')):
            pbar.update()

# Generated at 2022-06-24 10:04:01.209258
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from requests import Session
    from .tests_telegram import MOCK_TOKEN, MOCK_CHAT_ID
    from .mocking import TqdmMock

    class MockTelegramIO(TelegramIO):
        def __init__(self, *args, **kwargs):
            self.session = Session()
            self.session.sendMessage = lambda *args, **kwargs: (200, {})

    class MockTqdmTelegram(tqdm_telegram):
        def __init__(self, *args, **kwargs):
            self.tgio = MockTelegramIO(*args, **kwargs)

        def display(self, **kwargs):
            self.format_meter(self.format_dict)

    def __mock_tqdm(*args, **kwargs):
        kwargs["session"] = Session

# Generated at 2022-06-24 10:04:04.525435
# Unit test for function trange
def test_trange():  # pragma: no cover
    from .tests_telegram import test_trange
    test_trange()


if __name__ == '__main__':  # pragma: no cover
    test_trange()

# Generated at 2022-06-24 10:04:10.844842
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from . tqdm_ref import tqdm as tqdm_ref
    for position in [0, 2]:
        for leave in [True, False]:
            for disable in [True, False]:
                tqdm_reference = tqdm_ref(range(3), position=position,
                                          leave=leave, disable=disable)
                tqdm_telegram_obj = tqdm_telegram(range(3), position=position,
                                                  leave=leave, disable=disable)
                tqdm_reference.clear()
                tqdm_telegram_obj.clear()

# Generated at 2022-06-24 10:04:22.148001
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from unittest import TestCase
    from io import StringIO

    class TqdmTelegramTest(TestCase):
        @staticmethod
        def sample_progressbar(bar_format, **kwargs):
            bar_format = bar_format.replace('<bar/>', '{bar}')
            return tqdm_telegram(
                **kwargs,
                file=StringIO(),
                bar_format=bar_format,
                disable=True)

        def test_bar(self):
            pbar = self.sample_progressbar('{bar}')
            pbar.total = 4
            pbar.pos = 2
            pbar.display()
            self.assertEqual(
                pbar.file.getvalue(),
                "|##                                                                 |"
            )


# Generated at 2022-06-24 10:04:28.830367
# Unit test for function trange
def test_trange():
    # Define constants
    try:
        import pytest
    except ImportError:
        return

    s = ('TEST' + (' ' * 200)).encode('utf-8')

    def test_rep():
        """Check trange repetition"""
        for _ in trange(3):
            pass

    def test_rep2():
        """Check trange repetition"""
        for _ in trange(3, desc='TEST', leave=True):
            pass

    # Run tests
    for test_func in [test_rep, test_rep2]:
        with tqdm(total=3) as t:
            original_write = tqdm.write

            def noop(*args, **kwargs):
                pass
            tqdm.write = noop
            try:
                test_func()
            finally:
                t

# Generated at 2022-06-24 10:04:32.803111
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    io = TelegramIO('token', 'chat_id')
    io.write('test')
    io.delete()

# Generated at 2022-06-24 10:04:41.965201
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    import requests
    import os

    os.environ["TQDM_TELEGRAM_TOKEN"] = os.environ.get("TQDM_TELEGRAM_TOKEN")
    os.environ["TQDM_TELEGRAM_CHAT_ID"] = os.environ.get("TQDM_TELEGRAM_CHAT_ID")

    token = os.environ['TQDM_TELEGRAM_TOKEN']
    chat_id = os.environ['TQDM_TELEGRAM_CHAT_ID']

    TelegramIO(token, chat_id).delete()

    pbar = tqdm(total=100, leave=False, disable=False,
                token=token, chat_id=chat_id)

# Generated at 2022-06-24 10:04:48.415032
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    message_id = TelegramIO(getenv('TQDM_TELEGRAM_TOKEN'), getenv('TQDM_TELEGRAM_CHAT_ID')).message_id
    tqdm_telegram(range(100), token=getenv('TQDM_TELEGRAM_TOKEN'), chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'), unit='B', unit_scale=True, unit_divisor=1024, miniters=1).delete()
    assert isinstance(message_id, int)

# Generated at 2022-06-24 10:04:51.490069
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from time import sleep

    with tqdm_telegram(total=100,
                       token='{token}', chat_id='{chat_id}') as pbar:
        for i in range(10):
            pbar.update(10)
            sleep(0.5)

# Generated at 2022-06-24 10:04:59.514437
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    __class__ = tqdm_telegram
    from tqdm.auto import tqdm_instances
    # with all defaults
    with __class__(total=100, leave=False, disable=False):
        pass
    # with all non-defaults
    __class__(total=100, leave=False, disable=True)
    __class__(total=100, leave=True, disable=False)
    __class__(total=100, leave=True, disable=True)
    # not nested
    for inst in tqdm_instances:
        assert not hasattr(inst, 'tgio')

# Generated at 2022-06-24 10:05:01.073098
# Unit test for function trange
def test_trange():
    from time import sleep
    n = 5
    for i in trange(n, desc='trange'):
        sleep(0.5)

# Generated at 2022-06-24 10:05:10.563379
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    # env var not set, won't work
    t = tqdm(total=10)
    assert t.tgio.message_id is None
    assert t.leave is True
    t.close()

    # env var correctly set, should work
    t = tqdm(total=10, token='123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11',
             chat_id='123456789')
    assert t.tgio.message_id == 123456789
    assert t.leave is False
    t.close()

# Generated at 2022-06-24 10:05:21.720957
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    def format_dict(**kwargs):
        return {key.replace("format", "fmt"): value
                for key, value in kwargs.items()}
    t = tqdm_telegram(total=2, desc="test", ncols=1,
                      mininterval=.05, miniters=1)
    assert not t.leave

# Generated at 2022-06-24 10:05:31.878932
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import unittest
    import sys

    class TestTqdmTelegramClearTest(unittest.TestCase):
        def test_tqdm_telegram_clear(self):
            def testfn(std, tgt):
                with tqdm(total=5, file=std) as prg:
                    prg.clear()
                    self.assertEqual(std.getvalue(), tgt)
            testfn(sys.stdout, '\n')
            testfn(sys.stderr, '\n')
            testfn(sys.stdout, '\r\r')
            testfn(sys.stderr, '\r\r')

    unittest.main(module=__name__, argv=['ignored'], exit=False, verbosity=0)

# Generated at 2022-06-24 10:05:38.149858
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm.auto import tqdm
    from time import sleep
    for i in tqdm(range(2), total=2, desc='Downloading',
                  bar_format='{l_bar}{bar}| {n_fmt}/{total_fmt} ['
                             'Rate:{rate_fmt}{postfix}]'):
        sleep(.5)
        tqdm.write('Downloaded %d files' % i)

# Generated at 2022-06-24 10:05:41.707922
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .tests_tqdm import pretest_posttest_print
    with pretest_posttest_print():
        tqdm_telegram(range(3)).display()

# Generated at 2022-06-24 10:05:44.119198
# Unit test for function trange
def test_trange():
    with tqdm(total=10, token='{token}', chat_id='{chat_id}') as pbar:
        for i in trange(10):
            pbar.update()

# Generated at 2022-06-24 10:05:52.928750
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import os
    telegram_token = os.getenv('TQDM_TELEGRAM_TOKEN')
    telegram_chat_id = os.getenv('TQDM_TELEGRAM_CHAT_ID')

    if not (telegram_token or telegram_chat_id):
        return None

    from .utils_sig_test import test_block_print
    with test_block_print():
        tg = TelegramIO(telegram_token, telegram_chat_id)
        tg.write('Checking unit test for TelegramIO...')
        return "TelegramIO unit test successful!"


# Generated at 2022-06-24 10:06:00.840321
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    # https://pytest.org/latest/assert.html
    import pytest

    t = tqdm_telegram(total=10)
    fmt = t.format_dict
    if fmt.get('bar_format', None):
        fmt['bar_format'] = fmt['bar_format'].replace('<bar/>', '{bar:10u}').replace('{bar}', '{bar:10u}')
    else:
        fmt['bar_format'] = '{l_bar}{bar:10u}{r_bar}'
    t.display(**fmt)
    assert t.tgio.text == t.format_meter(**fmt)

# Generated at 2022-06-24 10:06:06.000580
# Unit test for function trange
def test_trange():
    '''
    Tests whether ttgrange works.

    Uses environment variables "TQDM_TELEGRAM_TOKEN" and "TQDM_TELEGRAM_CHAT_ID"
    '''
    from .utils import _term_move_up
    for _ in trange(5, desc="test", postfix={"done": "?"}):
        _term_move_up()

# Generated at 2022-06-24 10:06:12.574218
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    assert list(ttgrange(3)) == [0, 1, 2]
    assert list(ttgrange(1, 3)) == [1, 2]
    assert list(ttgrange(1, 3, 2)) == [1]
    assert list(ttgrange(3, 1)) == []
    assert list(ttgrange(3, 1, -1)) == [3, 2, 1]
    assert list(ttgrange(3, 1, -2)) == [3]
    assert list(ttgrange(3, 5)) == []
    assert list(ttgrange(3, 5, 3)) == [3]
    assert list(ttgrange(3, 5, 2)) == [3]

# Generated at 2022-06-24 10:06:20.497485
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    '''
    unit test: test if tqdm_telegram method 'clear' behaves correctly
    '''
    from os import getenv
    from time import sleep

    test_telegram_token = getenv('TEST_TELEGRAM_TOKEN')
    test_telegram_chat_id = getenv('TEST_TELEGRAM_CHAT_ID')

    if test_telegram_token is None or test_telegram_chat_id is None:
        print('Skipping unit test of tqdm_telegram method "clear"\n'
              'because either TEST_TELEGRAM_TOKEN or TEST_TELEGRAM_CHAT_ID\n'
              'is not set.\n')

# Generated at 2022-06-24 10:06:23.290167
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    tqdm_telegram(total=10, disable=True)

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-24 10:06:29.821786
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    tgio = TelegramIO(token, chat_id)
    assert tgio.token == token
    assert tgio.chat_id == chat_id
    assert tgio.tgio.token == token
    assert tgio.tgio.chat_id == chat_id
    assert tgio.tgio.message_id is not None
    assert tgio.message_id is not None

# Generated at 2022-06-24 10:06:31.799733
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    t = TelegramIO('foo', 'bar')
    assert t.delete()
    t._message_id = 123
    assert t.delete()

# Generated at 2022-06-24 10:06:34.067004
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    assert True



# Generated at 2022-06-24 10:06:36.984781
# Unit test for function trange
def test_trange():
    for _ in trange(4, token='{token}', chat_id='{chat_id}'):
        pass


# Generated at 2022-06-24 10:06:39.403843
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    # Check HTTPS connection to Telegram
    try:
        TelegramIO(token='', chat_id='').write('Hello World')
    except Exception as e:
        raise e

# Generated at 2022-06-24 10:06:43.747796
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    with tqdm_telegram(range(0), mininterval=0, miniters=0.01, disable=False) as t:
        t.tgio.write('test')
        t.close()
    # Test if the message was deleted
    api_call = "https://api.telegram.org/bot%s/getUpdates" % t.tgio.token
    req = requests.get(api_call)
    assert not 'message_id' in str(req.content)

# Generated at 2022-06-24 10:06:49.505017
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    import sys
    stdout = sys.stdout
    sys.stdout = TqdmTelegramTestIO()
    with tqdm_telegram(total=10) as t:
        for i in _range(10):
            t.update()
    sys.stdout = stdout


# Test TelegramIO class independently of tqdm

# Generated at 2022-06-24 10:06:54.062131
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    try:
        for i in tqdm_telegram(["a", "b", "c"], bar_format="{desc}: {bar} |{n_fmt}/{total_fmt} [{elapsed}<{remaining}]"):
            pass
    except KeyError:
        raise AssertionError("There is an error in the code of class tqdm_telegram: method clear")



# Generated at 2022-06-24 10:07:04.248013
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tgio = TelegramIO('a', 'b')
    tgio._message_id = 'c'
    # check for adding delete task to the queue
    assert tgio.delete().done() is False
    assert tgio.tg.tasks
    # test for TelegramIO.delete() which is used for close()
    tgio._message_id = 'd'
    tgio.leave = True
    tgio.pos = 0
    tgio.close()
    assert tgio.tg.tasks
    # test for TelegramIO.delete() which is used for close()
    tgio._message_id = 'd'
    tgio.leave = False
    tgio.pos = 0
    tgio.close()
    assert not tgio.tg.tasks

# Unit test

# Generated at 2022-06-24 10:07:10.212534
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    tgio = TelegramIO(token, chat_id)
    res = tgio.write("test_TelegramIO")
    assert res.result().json().get('result').get('message_id') != None



# Generated at 2022-06-24 10:07:11.657070
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    tqdm_telegram("hello")

# Generated at 2022-06-24 10:07:22.125679
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import string
    from random import choice
    from unittest import TestCase
    from inspect import isgenerator

    class TelegramIOTest(TestCase):
        def setUp(self):
            self.token = 'TOKEN'
            self.chat_id = 'CHAT_ID'
            self.file = TelegramIO(self.token, self.chat_id)

        def test_write(self):
            write = self.file.write
            self.assertTrue(isgenerator(write("abc")))
            self.assertTrue(isgenerator(write("")))
            self.assertTrue(isgenerator(write("    ")))
            self.assertTrue(isgenerator(write("hijklmnopqrstuvwxyz")))
            self.assertTrue(isgenerator(write(str(12345))))
           

# Generated at 2022-06-24 10:07:27.141405
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import string
    for each in string.ascii_letters:
        tqdm_telegram(range(10), token='{token}', chat_id='{chat_id}')
        tqdm_telegram(range(10), bar_format=each, token='{token}', chat_id='{chat_id}')

# Generated at 2022-06-24 10:07:33.624362
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    from os import environ

    if not (environ.get('TQDM_TELEGRAM_TOKEN', '') and
            environ.get('TQDM_TELEGRAM_CHAT_ID', '')):
        return

    from tqdm.contrib.telegram import TelegramIO
    tgio = TelegramIO(environ['TQDM_TELEGRAM_TOKEN'],
                      environ['TQDM_TELEGRAM_CHAT_ID'])
    tgio.write(__file__ + " testing deletion at ")
    tgio.delete()

test_TelegramIO_delete()

# Generated at 2022-06-24 10:07:40.856195
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    try:
        TelegramIO(token=None, chat_id=None)
    except ValueError as e:
        # Should throw ValueError
        assert 'token' in str(e) and 'chat_id' in str(e)
    try:
        TelegramIO(token='token', chat_id=None)
    except ValueError as e:
        # Should throw ValueError
        assert 'token' in str(e) and 'chat_id' in str(e)
    try:
        TelegramIO(token=None, chat_id='chat_id')
    except ValueError as e:
        # Should throw ValueError
        assert 'token' in str(e) and 'chat_id' in str(e)

# Generated at 2022-06-24 10:07:52.252104
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from sys import platform
    from time import sleep
    from random import random
    try:
        import pytest
        tqdm_test = pytest.importorskip('tqdm.auto.test_tqdm')
    except ImportError:
        pass
    else:
        tqdm_test.unit_tests(tqdm_telegram)
    if platform == "win32":
        return  # skip timing tests on windows
    with tqdm_telegram(total=100, token='{token}', chat_id='{chat_id}') \
            as pbar:
        for i in range(0, 100):
            pbar.set_description("test_tqdm_telegram: "
                                 "this is only a test")
            sleep(0.01 * (1 + random()))
            p

# Generated at 2022-06-24 10:08:01.642356
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    """Ensure that tqdm_telegram.display works"""
    import sys
    from shutil import rmtree
    try:
        from tempfile import TemporaryDirectory
    except ImportError:  # python2
        TemporaryDirectory = None

    def nothing(it):
        """Iterator which does nothing"""
        for _ in it:
            yield

    with TemporaryDirectory() as tmpdir:
        with tqdm_telegram(total=10, file=sys.stdout,
                           miniters=0, mininterval=0, disable=False,
                           token=token, chat_id=chat_id) as t:  # noqa
            for i in nothing(range(10)):
                t.update()
    # Test deprecated args

# Generated at 2022-06-24 10:08:07.266343
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    with tqdm_telegram(token='token', chat_id='chat_id',
                       total=10, unit='B', unit_scale=True, unit_divisor=1024) as t:
        for i in t:
            sleep(0.1)
            t.set_description('%d' % i)
            t.update()

# Generated at 2022-06-24 10:08:10.914364
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import pytest
    tgIO = TelegramIO('token', 'chat_id')
    tgIO.message_id = 5
    with pytest.raises(Exception):
        tgIO.write('')



# Generated at 2022-06-24 10:08:20.801140
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """Test the tqdm_telegram.close() method."""
    # Test the case that tqdm_telegram.leave is False and tqdm_telegram.pos != 0
    t = tqdm_telegram(total=10, leave=False)
    for i in t:
        pass
    t.close()
    assert t.tgio.message_id != None
    assert t.tgio.write.calls == len([i for i in range(11)])
    assert t.tgio.delete.calls == 1
    t2 = tqdm_telegram(total=10, leave=False, mininterval=0, maxinterval=0)
    with t2:
        for i in range(10):
            t2.update()
    assert t2.tgio.message_id != None


# Generated at 2022-06-24 10:08:28.211237
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    with tqdm_telegram(token='TOKEN', chat_id='CHATID') as t:
        for i in _range(10):
            t.update()
            t.refresh()
    # Test leave
    with tqdm_telegram(token='TOKEN', chat_id='CHATID', leave=True) as t:
        for i in _range(10):
            t.update()
        assert t.n == 10
    with tqdm_telegram(token='TOKEN', chat_id='CHATID', leave=True) as t:
        for i in _range(10):
            t.update(2)
        assert t.n == 10

# Generated at 2022-06-24 10:08:35.208793
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    # Method display
    t = tqdm_telegram(ascii=True, unit='iB', unit_scale=True)
    t.total = 1000

    t.update(1)
    t.display()
    assert str(t) == "0.00it [00:00, ?it/s]\n"

    t.update(10)
    t.display()
    assert str(t) == "10.0it [00:00, ?it/s]\n"

    t.update(100)
    t.display()
    assert str(t) == "110.0it [00:00, ?it/s]\n"

    t.update(1000)
    t.display()

# Generated at 2022-06-24 10:08:43.160283
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from re import search
    li = list(range(10))
    with tqdm_telegram(li) as t:
        li = [0] * 10
        for i in t:
            li[i] += 5
            t.set_postfix(li=li)
    assert str(t) == '10it [00:00, ?it/s]'
    assert search(r'^\[0{2,}\] 5/10\n$', t.format_dict['postfix'])
    assert not t.leave
    t.close()
    assert t.leave
    assert t.tgio.text == str(t)
    t = tqdm_telegram(4, 10)
    assert t.total == 10
    assert t.n == 4
    assert t.last_print_n == 4
   

# Generated at 2022-06-24 10:08:46.452762
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    i = tqdm(iterable, token='{token}', chat_id='{chat_id}')
    assert isinstance(i, tqdm_telegram)
    return i

if getenv('TRAVIS_PYTHON_VERSION') is not None:
    tqdm_telegram = tqdm_telegram.__class__(disable=True)

# Generated at 2022-06-24 10:08:54.042394
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    try:
        with tqdm_telegram(total=1, token='fake', chat_id='fake') as t:
            pass
    except Exception as e:
        print(e)
        assert str(e) == "No message_id: try increasing `miniters`"
    else:
        assert False, "should fail with no message_id"

# Generated at 2022-06-24 10:08:58.201415
# Unit test for function trange
def test_trange():
    with trange(3, token=getenv('TQDM_TELEGRAM_TOKEN'),
                chat_id=getenv('TQDM_TELEGRAM_CHAT_ID')) as t:
        for i in t:
            t.set_description("Test %i" % i)
            assert i >= 0

# Generated at 2022-06-24 10:09:02.754281
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from . import tqdm_telegram
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    assert token is not None and chat_id is not None, \
        "Required environment variables are not found"
    return tqdm_telegram(token=token, chat_id=chat_id, desc="test", total=10)

# Generated at 2022-06-24 10:09:08.256387
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    from os import environ

    tg = TelegramIO(environ['TQDM_TELEGRAM_TOKEN'], environ['TQDM_TELEGRAM_CHAT_ID'])
    tqdm_auto.write(tg.message_id)

    future = tqdm_auto.write(tg.delete())
    future.result()

# Generated at 2022-06-24 10:09:17.049756
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    try:
        import requests
    except ImportError:
        return  # skip test

# Generated at 2022-06-24 10:09:27.001427
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():

    # Set token and chat_id to environment variables
    set_token = os.environ.setdefault('TQDM_TELEGRAM_TOKEN', '{token}')
    set_chat = os.environ.setdefault('TQDM_TELEGRAM_CHAT_ID', '{chat_id}')
    tgio = TelegramIO(token=set_token, chat_id=set_chat)
    message_id = tgio.message_id

# Generated at 2022-06-24 10:09:36.390423
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if token is None or chat_id is None:
        warn("Telegram token or chat_id is not setup.")
        return
    io = TelegramIO(token, chat_id)
    io.write("test")
    io.delete()
    del io

if __name__ == '__main__':
    test_TelegramIO_delete()

# Generated at 2022-06-24 10:09:45.658294
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from os import getenv, setenv

    def token(token=None, chat_id=None):
        if token is None:
            token = getenv("TQDM_TELEGRAM_TOKEN")
        if chat_id is None:
            chat_id = getenv("TQDM_TELEGRAM_CHAT_ID")
        if token is None:
            raise Exception("No token, please set TQDM_TELEGRAM_TOKEN")
        if chat_id is None:
            raise Exception("No chat_id, please set TQDM_TELEGRAM_CHAT_ID")
        return token, chat_id

    def set_token(token=None, chat_id=None):
        if token is not None:
            setenv("TQDM_TELEGRAM_TOKEN", token)

# Generated at 2022-06-24 10:09:56.976267
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    """
    Unit test for method delete of class TelegramIO

    """
    io = TelegramIO('', '')

    io.delete()
    io.session.post.assert_called_once_with(
        io.API + '%s/deleteMessage' % io.token,
        data={'chat_id': io.chat_id, 'message_id': io.message_id})

    io.delete()
    io.session.post.assert_called_with(
        io.API + '%s/deleteMessage' % io.token,
        data={'chat_id': io.chat_id, 'message_id': io.message_id})
    assert io.session.post.call_count == 2



# Generated at 2022-06-24 10:10:04.149737
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from os import getenv
    if getenv("CI"):
        return
    for _ in tqdm_telegram(iterable=range(10), token=getenv("TQDM_TELEGRAM_TOKEN"), chat_id=getenv("TQDM_TELEGRAM_CHAT_ID")):
        pass

if __name__ == '__main__':
    test_tqdm_telegram()

# Generated at 2022-06-24 10:10:06.174982
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    t = tqdm([1,2,3])
    t.display()

if __name__ == "__main__":
    test_tqdm_telegram_display()

# Generated at 2022-06-24 10:10:13.728351
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from time import sleep
    from numpy.random import rand

    for i in range(5):
        l = rand(10)
        for j in tqdm(l, token='1250757608:AAG5_X8WOcZ0vJ2QzrOtGk-_rEjwv-gs0Jw',
                      chat_id='344524302', desc='foo bar'):
            sleep(j / 100.0)
        sleep(10 * rand())
    assert hasattr(tqdm, 'n')


if __name__ == '__main__':
    test_tqdm_telegram()

# Generated at 2022-06-24 10:10:17.766329
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    tgr = tqdm_telegram(iterable=range(3), token='1069305922:AAGvaV7X8-LlU6hL-6DCCuV7zKhTmyTzTBo', chat_id='382654877')
    tgr.update()
    tgr.clear()
    tgr.close()

# Generated at 2022-06-24 10:10:19.557317
# Unit test for function trange
def test_trange():
    """Test function `trange`"""
    trange(10, token='{token}', chat_id='{chat_id}')


if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-24 10:10:22.383172
# Unit test for function trange
def test_trange():
    from time import sleep
    for _ in trange(4, token='123456789:AAAAAAAAAAAAAAAAAAAAAAAA',
                    chat_id='123456789'):
        sleep(.5)

# Generated at 2022-06-24 10:10:27.727846
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    tqdm_telegram.write = lambda self, s: None
    tqdm_telegram.format_dict = {'l_bar': 'left', 'r_bar': 'right'}
    tgio = TelegramIO('123', '456')
    tgio.write = lambda s: None
    tg = tqdm_telegram([1, 2, 3], tgio=tgio)
    tg.display()
    tg.clear()

# Generated at 2022-06-24 10:10:38.544864
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    __main__ = sys.modules['__main__']
    __main__.__version__ = "2.0.1"

    def _main(stdin=None, stdout=None):
        "Takes input arguments for testing"
        with closing(StringIO()) as our_file:
            for _ in tqdm([1, 2, 3], file=our_file):
                sleep(0.01)
        return our_file.getvalue()

    assert_equal(_main(),
        "100%|██████████| 3/3 [00:00<00:00, 29.44it/s]\n")

    # test the telegram constructor

# Generated at 2022-06-24 10:10:47.787912
# Unit test for function trange
def test_trange():
    """Unit test for tqdm_telegram.trange"""
    from sys import version_info
    from subprocess import call
    from time import sleep

    for _ in trange(3, token='865575306:AAG-BwCJZn0GjKlS2dpGnHvX9QDgHir-tEs',
                    chat_id='-1001348925231'):
        sleep(.5)


# Generated at 2022-06-24 10:10:57.945887
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import html
    import re

# Generated at 2022-06-24 10:11:03.016250
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from io import StringIO  # Python 3
    import sys
    import tempfile
    from tqdm import tnrange
    from tqdm.contrib.telegram import tqdm, ttgrange
    from tqdm.auto import trange

    # Manually test token and chat_id below
    token = None
    chat_id = None

    if all(token, chat_id):
        sys.stderr = StringIO()

# Generated at 2022-06-24 10:11:12.821705
# Unit test for function trange
def test_trange():
    """
    Unit tests to check the `trange` function (and its shortcut `tqdm`).
    """
    from os import getenv
    from time import sleep
    from tqdm import trange
    # Create a Telegram bot <https://core.telegram.org/bots#6-botfather>
    # and obtain a `token` and `chat_id`:
    # - create a bot <https://core.telegram.org/bots#6-botfather>
    # - copy its `{token}`
    # - add the bot to a chat and send it a message such as `/start`
    # - go to <https://api.telegram.org/bot`{token}`/getUpdates> to find out
    #   the `{chat_id}`
    # - paste the `{token}` &

# Generated at 2022-06-24 10:11:20.835403
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    # get a pair (token, chat_id)
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')

    # create TelegramIO object
    tgio = TelegramIO(token, chat_id)

    # test if the TelegramIO object is created
    assert(tgio.message_id)
    message_id_init = tgio.message_id

    # changes the text for the TelegramIO object
    assert(tgio.write('test_method_delete'))

    # retrieve the message_id of the new message
    message_id_new = tgio.message_id

    # compare the new message_id with the old one
    assert(message_id_new != message_id_init)

    # delete the new message

# Generated at 2022-06-24 10:11:24.851254
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tio = TelegramIO("FAKE_TOKEN", "FAKE_CHAT_ID")
    tio.submit_name = "_submit_name"
    new_fut = tio.delete()
    assert new_fut.args[0] == tio._submit_name
    assert new_fut.args[1][0] == tio.session.post
    assert tio._message_id != None

# Generated at 2022-06-24 10:11:28.108276
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import io
    from tqdm._tqdm_tqdm import _decr_instances  # noqa
    tqdm_tqdm = _decr_instances(tqdm_telegram, [], _range(0, 10),
                                file=io.BytesIO(), ncols=100)
    tqdm_tqdm.clear()

# Generated at 2022-06-24 10:11:32.004731
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    token = '1'
    chat_id = '2'
    tgio = TelegramIO(token, chat_id)
    assert (tgio.API + '%s/sendMessage' % token) in str(tgio.submit.__self__)

# Generated at 2022-06-24 10:11:35.785667
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    t = tqdm_telegram(total=10, desc='testing', bar_format='{bar:10u}')
    t.display()


if __name__ == '__main__':
    from doctest import testmod
    testmod()

# Generated at 2022-06-24 10:11:39.820418
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    assert callable(tqdm_telegram), "tqdm_telegram is not defined or not a callable"


# Generated at 2022-06-24 10:11:45.062419
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    for leave in [None, False, True]:
        assert tqdm_telegram(total=1, leave=leave).close() == leave
        assert tqdm_telegram(total=0, leave=leave).close() is True

test_tqdm_telegram_close()

# Generated at 2022-06-24 10:11:49.331409
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    TelegramIO('', '')