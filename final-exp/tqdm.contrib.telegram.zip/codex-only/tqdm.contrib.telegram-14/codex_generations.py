

# Generated at 2022-06-24 10:01:51.843654
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    tgio = TelegramIO({}, {})
    assert str(tgio.message_id) == "None"
    tgio.write("")
    assert tgio.message_id is not None
    tgio.delete()

# Generated at 2022-06-24 10:01:58.835213
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    """Tests the delete method of TelegramIO class."""
    chat_id = '-1001404300443'
    token = '1114332276:AAHzIjEujBcox1mn_AJXdNpmkmMB2CKbMr8'
    tgio = TelegramIO(token, chat_id)
    tgio.delete()

if __name__ == "__main__":
    test_TelegramIO_delete()

# Generated at 2022-06-24 10:02:02.625880
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    pass

# Generated at 2022-06-24 10:02:05.012716
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(total=1)
    t.close()
    t.close()

# Generated at 2022-06-24 10:02:12.335700
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from .utils import pretest
    t = tqdm_telegram(total=5, disable=True, leave=False)
    t.write("test")
    pretest()
    t = tqdm_telegram(total=5, disable=True, leave=True)
    t.write("test")
    pretest()
    t = tqdm_telegram(total=5, disable=False, leave=False)
    t.write("test")
    t.close()
    pretest()
    t = tqdm_telegram(total=5, disable=False, leave=True)
    t.write("test")
    t.close()
    pretest()

# Generated at 2022-06-24 10:02:15.136623
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    try:
        raise OSError('test_tqdm_telegram_clear')
    except OSError as e:
        ttgrange(5, disable=False)
        tqdm_auto.write(str(e))

# Generated at 2022-06-24 10:02:16.300238
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tg = TelegramIO('lorem', 'ipsum')
    tg.delete()

# Generated at 2022-06-24 10:02:19.199922
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tio = TelegramIO(getenv('TQDM_TELEGRAM_TOKEN'),
                     getenv('TQDM_TELEGRAM_CHAT_ID'))
    tio.write("test_TelegramIO_write")
    assert(tio.message_id > 0)

# Generated at 2022-06-24 10:02:23.892762
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    try:
        TelegramIO(token=4, chat_id=4)
    except requests.exceptions.ConnectionError as e:
        tqdm_auto.write("You need to connect to the internet for these tests")
        tqdm_auto.write("Error: %s" % e)

# Generated at 2022-06-24 10:02:30.254244
# Unit test for function trange
def test_trange():
    import sys
    import time

    for _ in trange(int(sys.argv[1]), token=sys.argv[2], chat_id=sys.argv[3]):
        time.sleep(0.01)


if __name__ == '__main__':
    import sys
    n, token, chat_id = sys.argv[1:]
    with tqdm(total=n, token=token, chat_id=chat_id) as pbar:
        for i in _range(int(n)):
            pbar.update(1)

# Generated at 2022-06-24 10:02:38.757381
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from time import sleep
    from tqdm.auto import tqdm as tqdm_auto

    token = '{token}'
    chat_id = '{chat_id}'
    i = 0
    for i in tqdm_telegram(range(10), token=token, chat_id=chat_id):
        sleep(1)
    for i in tqdm_telegram(range(10), token=token, chat_id=chat_id):
        sleep(1)
    for i in tqdm_auto(range(10)):
        sleep(1)
    for i in tqdm_telegram(range(10), token=token, chat_id=chat_id):
        sleep(1)
    assert i == 9


# Example

# Generated at 2022-06-24 10:02:44.536506
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from io import StringIO
    from tqdm.auto import tqdm as tqdm_auto
    from tqdm._tqdm import FormatCustomText, format_dict
    out = StringIO()
    pbar = tqdm_telegram(range(3), file=out, ncols=10,
                         miniters=0, bytes=True)
    pbar.update()
    if pbar.n > 0:
        pbar.write(" ")
    pbar.close()
    assert out.getvalue().strip() == ""

# Generated at 2022-06-24 10:02:48.090835
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from .tests_tqdm import _test_clear, FakePyIn
    t = tqdm_telegram(["a", "list"], file=FakePyIn())
    _test_clear(t)

# Generated at 2022-06-24 10:02:52.150466
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    try:
        tgrange = ttgrange(3)
    except Exception:
        assert False, "TelegramIO.delete test - ttgrange failed"
    assert True, "TelegramIO.delete test - ttgrange success"


# Generated at 2022-06-24 10:02:54.213344
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    token = ''
    chat_id = ''
    tt = TelegramIO(token, chat_id)
    tt.delete()

# Generated at 2022-06-24 10:03:08.349790
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm.contrib.test_utils import DiscreteTimer

    # Create a dummy tqdm_telegram instance
    t = tqdm([1, 2, 3])
    t.n = 3
    t.disable = False
    t.dynamic_miniters = False
    t.desc = "test"
    t.format_dict = {"desc": "test"}

    t.clear(nolock=True)

    # Call `t.tgio.write` with a fake timer
    class FakeTimer(DiscreteTimer):

        def __init__(self, *args, **kwargs):
            self.write_called = False
            super(FakeTimer, self).__init__(*args, **kwargs)

        def time(self):
            return self.start + 0.1


# Generated at 2022-06-24 10:03:10.818252
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tgio = TelegramIO('test', 'test')
    tgio.write('test')
    assert tgio.text == 'test'


# Generated at 2022-06-24 10:03:13.995264
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    tgio = TelegramIO('{token}', '{chat_id}')
    tgio.message_id
    tgio.write('test')
    tgio.delete()

# Generated at 2022-06-24 10:03:17.032069
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tgio = TelegramIO('{token}', '{chat_id}')
    tgio.message_id
    tgio.delete()
    tgio.message_id
    tgio.delete()

# Generated at 2022-06-24 10:03:20.831268
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import io
    with io.StringIO() as f:
        with tqdm_telegram(range(3), file=f, leave=False) as pbar:
            pbar.write('foo')
            pbar.clear()
            pbar.close()
        assert len(f.getvalue()) == 0

# Generated at 2022-06-24 10:03:28.405701
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if not (token and chat_id):
        warn("Telegram test disabled as neither `token` nor `chat_id` "
             "defined (set ${TQDM_TELEGRAM_TOKEN} and "
             "${TQDM_TELEGRAM_CHAT_ID} to enable test)", TqdmWarning)
        return
    try:
        TelegramIO(token, chat_id)
    except Exception as e:
        warn("Telegram test failed: %s" % e, TqdmWarning)

# Generated at 2022-06-24 10:03:38.999868
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import sys
    from contextlib import contextmanager
    from .utils import _io

    @contextmanager
    def captured_output():
        new_out, new_err = _io.StringIO(), _io.StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err


# Generated at 2022-06-24 10:03:45.951138
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    """
    This test is non-deterministic, it relies on the user response.
    """
    import time
    import tqdm.contrib.telegram
    try:
        tqdm.contrib.telegram.TelegramIO.test_write()
    except (EOFError, KeyboardInterrupt):
        print("Test passed")
    else:
        raise AssertionError("Test failed")


if __name__ == '__main__':
    test_TelegramIO_write()

# Generated at 2022-06-24 10:03:49.335118
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    for i in tqdm_telegram(range(3), token='{token}', chat_id='{chat_id}'):
        pass

# Generated at 2022-06-24 10:03:51.176269
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    for i in tqdm_telegram(range(10), token='{token}', chat_id='{chat_id}'):
        pass

# Generated at 2022-06-24 10:03:53.033570
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    s = Sessions()
    fmt = FormatStr('%s')
    s.close()
    fmt.close()

# Generated at 2022-06-24 10:03:58.825579
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tgio = TelegramIO(token=getenv('TQDM_TELEGRAM_TOKEN'),
                      chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'))
    tgio.write("test_TelegramIO_write")

if __name__ == '__main__':
    test_TelegramIO_write()

# Generated at 2022-06-24 10:04:01.880360
# Unit test for function trange
def test_trange():
    """Test for trange"""
    list(tqdm(range(1000)))


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 10:04:11.555531
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    """Test tqdm_telegram (only constructor)"""
    tqdm_telegram(total=10, desc="Test", ascii=True, disable=True)
    tqdm_telegram(total=10, desc="Test", disable=False)
    tqdm_telegram(total=10, desc="Test", postfix="X")
    tqdm_telegram(total=10, desc="Test", position=10)
    tqdm_telegram(total=10, desc="Test", unit="unit")
    tqdm_telegram(total=10, desc="Test", bar_format="X")
    tqdm_telegram(total=10, desc="Test", initial=5)
    tqdm_telegram(total=10, desc="Test", mininterval=1)
    tqdm_

# Generated at 2022-06-24 10:04:16.789811
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    with tqdm_telegram(token='00000000:00000000000000000000000000000000',
                       chat_id='00000000',
                       total=0, unit='B',
                       unit_scale=True,
                       ncols=60,
                       ascii=True) as t:
        t.update(10)

# Generated at 2022-06-24 10:04:25.562193
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from os import getenv
    from time import sleep
    try:
        tqdm_telegram(disable=False, token=getenv('TQDM_TELEGRAM_TOKEN'),
                      chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'))
        sleep(0.1)
        tqdm_telegram(disable=False, token=getenv('TQDM_TELEGRAM_TOKEN'),
                      chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'),
                      desc='Unit test')
        sleep(0.1)
    except Exception as e:
        tqdm_auto.write(str(e))

if __name__ == '__main__':
    test_tqdm_telegram()

# Generated at 2022-06-24 10:04:27.220799
# Unit test for function trange
def test_trange():
    trange(3)


if __name__ == '__main__':
    from os import system

    system('python setup.py test --addopts -vv --tb=short')

# Generated at 2022-06-24 10:04:35.271054
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    try:
        t = tqdm(xrange(10), token='{token}', chat_id='{chat_id}')
        t.close()
    except Exception as e:
        print("Error in test_tqdm_telegram_close: {}".format(e))
        raise

if __name__ == '__main__':
    test_tqdm_telegram_close()

# Generated at 2022-06-24 10:04:42.027435
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    tgio = TelegramIO(
        getenv('TQDM_TELEGRAM_TOKEN'),
        getenv('TQDM_TELEGRAM_CHAT_ID'))
    if tgio.message_id is None:
        warn("Telegram bot is not available. No internet or invalid token/id?")
    else:
        tgio.delete()


if __name__ == '__main__':
    from os import environ
    for i in ttgrange(10, token=environ['TQDM_TELEGRAM_TOKEN'],
                      chat_id=environ['TQDM_TELEGRAM_CHAT_ID']):
        pass

# Generated at 2022-06-24 10:04:49.091703
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    """Tests the method delete() of class TelegramIO"""
    # Create a fake class
    class TelegramIOFake:
        """Fake class to test the method delete() of class TelegramIO"""
        def __init__(self):
            self.token = "token"
            self.chat_id = "chat_id"
            self.message_id = "message_id"
            self.session = type("", (), {
                "post": lambda *x, **y: None # noqa
            })

    # Call the method delete()
    TelegramIO.delete(TelegramIOFake())

# Generated at 2022-06-24 10:04:52.739433
# Unit test for function trange
def test_trange():
    __test__ = True  # to be able to import this function

    from time import sleep
    wait = 0.001
    total = 10
    desc = "test"
    for _ in trange(total, desc=desc, token=getenv('TQDM_TEST_TOKEN'),
                    chat_id=getenv('TQDM_TEST_CHAT_ID')):
        sleep(wait)

# Generated at 2022-06-24 10:05:00.028878
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    from os import environ
    from time import sleep

    session = Session()
    token = environ.get('TQDM_TELEGRAM_TOKEN')
    chat_id = environ.get('TQDM_TELEGRAM_CHAT_ID')
    tgio = TelegramIO(token, chat_id)
    msg = tgio.write("i am")
    sleep(5)
    tgio.write("i am TQDM")
    sleep(5)
    tgio.write("i am TQDM_TELEGRAM")
    sleep(5)
    tgio.delete()

# Generated at 2022-06-24 10:05:02.614168
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():

    from tqdm.contrib.telegram import tqdm_telegram

    for j in range(2):
        for i in tqdm_telegram(range(3), total=3, token='1', chat_id='1'):
            pass
        tqdm_telegram.clear()

# Generated at 2022-06-24 10:05:12.463830
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import pytest

    class MockTelegramIO(TelegramIO):
        def __init__(self, token, chat_id):
            super(MockTelegramIO, self).__init__(token, chat_id)
            self.message_id = '123123'
            self.write_call_count = 0
            self.submitted_futures = []

        def write(self, s):
            self.write_call_count += 1
            self.submitted_futures.append(super(MockTelegramIO, self).write(s))
            return self.submitted_futures[-1]

    with pytest.raises(Exception) as e:
        MockTelegramIO('token', 'chat_id')

# Generated at 2022-06-24 10:05:24.397407
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from collections import namedtuple
    from io import StringIO

    from .utils import closing, _term_move_up

    class _IO(StringIO):
        """Mock class for testing writing to file objects.

        Here we replace the method `StringIO.write` with a custom function.
        """
        def __init__(self, *args, **kwargs):
            super(_IO, self).__init__(*args, **kwargs)
            # Store the method for later use
            self.old_write = self.write
            # Replace the method with a custom function
            self.write = self.custom_write

        def custom_write(self, s):
            """Custom write function for testing.

            Attempts to mimic the behavior of `tqdm.auto.tqdm.write`.
            """
            # Replace `\r`

# Generated at 2022-06-24 10:05:26.710988
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    assert TelegramIO("TEST_TOKEN", "TEST_CHAT_ID").message_id

# Generated at 2022-06-24 10:05:30.233417
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    import os
    tg = TelegramIO(os.getenv('TQDM_TELEGRAM_TOKEN'),
                    os.getenv('TQDM_TELEGRAM_CHAT_ID'))
    tg.close()

# Generated at 2022-06-24 10:05:41.796945
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import time, sys
    # cleaning stdout
    for i in range(100):
        sys.stdout.write("\x1b[1A")
        sys.stdout.write("\x1b[2K")
    # test
    with tqdm_telegram(total=11,
               disable=False,
               bar_format='{postfix[0]} {postfix[1]} {postfix[2]} {bar}',
               ncols=80,
               postfix=[{}, {'x': 'y_'}, {'a': 'b'}]) as pbar:
        time.sleep(1)
        pbar.update(2)
        pbar.clear(postfix={"a": "c"})
        pbar.update(3)

# Generated at 2022-06-24 10:05:45.251246
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """Test tqdm_telegram close method: add tests to ensure delete method is called"""
    io = TelegramIO("", "")
    io.write("")
    assert io.tgio == None

# Generated at 2022-06-24 10:05:47.586596
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    TelegramIO('', '')

if __name__ == "__main__":
    test_TelegramIO()
    from doctest import testmod
    testmod()

# Generated at 2022-06-24 10:05:57.119216
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    tgr = tqdm(total=20)
    tgr2 = tqdm(total=20)
    assert (tgr.tgio.token == tgr2.tgio.token), "Token not assigned correctly"
    assert (tgr.tgio.chat_id == tgr2.tgio.chat_id), "Chat ID not assigned correctly"
    tgr2.close()
    assert tgr.tgio.message_id != tgr2.tgio.message_id, "Message ID is not unique"
    tgr.close()


# Generated at 2022-06-24 10:05:58.223064
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():  
    TIO = TelegramIO("", "")
    TIO.write("Test")


# Generated at 2022-06-24 10:06:01.259788
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    try:
        io = TelegramIO(token='', chat_id='')
    except Exception as e:
        if e.args[0] == 'Telegram Token not found':
            pass
        else:
            raise
    else:
        raise Exception(
            'Expected an Exception but did not get any '
            'for class TelegramIO constructor')

# Generated at 2022-06-24 10:06:06.299128
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import sys
    import contextlib
    tmp_file = sys.stderr
    sys.stderr = sys.stdout
    with contextlib.redirect_stdout(None):
        with tqdm_telegram(total=2) as pbar:
            pbar.update(1)
            pbar.clear()
            pbar.close()
    sys.stderr = tmp_file

# Generated at 2022-06-24 10:06:13.286333
# Unit test for function trange
def test_trange():
    """Test function trange."""
    from itertools import chain, repeat
    from sys import version_info
    from time import sleep
    from traceback import format_exc
    from warnings import catch_warnings
    if version_info[0] >= 3:
        from pickle import dumps
    else:
        from pickle import dumps, HIGHEST_PROTOCOL

    with catch_warnings(record=True) as w:
        t0 = ttgrange(10)
        for char in chain([' '] * 4, list('clse')):
            t0.write(char)
            sleep(0.1)
        t0.close()
    assert not w
    assert not t0.n

    t1 = ttgrange(10)
    assert t1.write('test') is None
    assert t

# Generated at 2022-06-24 10:06:17.979905
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from random import randint
    from time import sleep
    from tqdm.contrib.telegram.tqdm_telegram import tqdm_telegram as tt
    for _ in tt(range(10), token='564493385:AAF8PXZ-gLZn1Sk3qGxKjbU6r1u6dvU2nFc', chat_id='175253260'):
        l = randint(1, 100)
        sleep(l / 10)
        tt.clear()
        tt.write('hello')
        sleep(l / 10)

# Generated at 2022-06-24 10:06:24.235863
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    try:
        import tkinter
        tkinter.Tk()
    except ImportError:
        # Mocking Tk() is non trivial
        pass
    except Exception:
        pass
    else:
        from tqdm.auto import trange
        from tqdm.contrib.telegram import tqdm_telegram
        from tqdm.contrib.telegram import ttgrange

        # Test tqdm_telegram
        assert tqdm_telegram(range(0)).__class__ == tqdm_telegram

        # Test ttgrange
        assert ttgrange(0).__class__ == tqdm_telegram

        # Test tqdm
        assert tqdm(range(0)).__class__ == tqdm_telegram

        # Test trange

# Generated at 2022-06-24 10:06:31.753903
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """Test for the close method of the tqdm_telegram class"""
    from tqdm import tqdm
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.utils import _environ_cols_wrapper
    from pytest import raises
    
    # Case 1
    with _environ_cols_wrapper(80):
        with raises(KeyError, message="PyPI 'KeyError' expected."):
            with tqdm_telegram(token='some-token', chat_id='some-chat-id') as t:
                for i in range(10):
                    pass

# Generated at 2022-06-24 10:06:38.546715
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from os import getenv
    from sys import version_info

    # prints a sample Telegram bot error message
    if version_info[0] >= 3:
        from io import StringIO
    else:
        from io import BytesIO as StringIO
    from unittest import TestCase
    from warnings import catch_warnings

    class UnitTest(TestCase):
        @staticmethod
        def read():
            import sys
            return sys.stdout.getvalue().splitlines()

    with catch_warnings(record=True) as cw, UnitTest.assertRaises(KeyError):
        tqdm_telegram()
    UnitTest.assertEqual(len(cw), 2)

# Generated at 2022-06-24 10:06:45.136481
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from io import StringIO
    io = StringIO()
    tqdm_auto.write = io.write
    io_t = TelegramIO('123', '456')
    io_t.write('abc')
    assert io.getvalue() == ''
    io_t.write('abc')
    assert io.getvalue() == ''
    io_t.write('def')
    assert "Could not find message" in io.getvalue()
    io_t.submit(lambda: None).result()
    assert "Trouble removing previous message" in io.getvalue()

# Generated at 2022-06-24 10:06:47.171459
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    with tqdm_telegram(total=2, disable=True) as t:
        t.write("hello")
        t.clear()
        assert len(list(t.sp(it=_range(t.total)))) == 0



# Generated at 2022-06-24 10:06:49.827469
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    tt = tqdm_telegram()
    tt.close()
    tt.leave = False    
    tt.close()
    print("\n")



# Generated at 2022-06-24 10:06:54.343158
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    tgr = tqdm_telegram(xrange(3), token='{token}', chat_id='{chat_id}')
    tgr.update(0)
    tgr.clear()
    tgr.close()


if __name__ == '__main__':
    from sys import version_info
    from time import sleep

    print(__doc__.format(token='TOKEN', chat_id='CHAT_ID'))

    for i in ttgrange(10, token='TOKEN', chat_id='CHAT_ID'):
        sleep(0.01)
    print("Done")

    if version_info[0] >= 3:
        for i in tqdm(range(10), token='TOKEN', chat_id='CHAT_ID'):
            sleep(.01)

    test_tqdm_

# Generated at 2022-06-24 10:06:58.164872
# Unit test for function trange
def test_trange():
    with trange(10) as t:
        for i in t:
            assert i == t.n
            t.set_description("step %i" % i)

if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-24 10:07:03.427032
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(total=1, disable=True)
    t.close()
    t = tqdm_telegram(total=1, leave=True)
    t.close()
    t = tqdm_telegram(total=1, pos=0)
    t.close()
    t = tqdm_telegram(total=1, pos=1)
    t.close()

# Generated at 2022-06-24 10:07:06.953673
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    io = TelegramIO(token='{token}', chat_id='{chat_id}')
    io.write('Testing...')
    io.write('This is a test')
    io.write('This is a test')
    io.write('This is a test 2')

# Generated at 2022-06-24 10:07:18.003831
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from pytest import raises
    from tqdm._utils import _term_move_up
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    with raises(AssertionError):
        with StringIO() as f:
            t = tqdm_telegram(total=2, file=f, desc='telegram')
        # should have consumed tqdm_telegram_clear exception
        with StringIO() as f:
            t = tqdm_telegram(total=2, file=f, desc='telegram')
            t.clear()
            f.seek(0)
            assert f.read() == '%s%s\r' % (_term_move_up(), ' ' * len('telegram'))
        # should have consumed tqdm_telegram_clear exception

# Generated at 2022-06-24 10:07:23.141553
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(total=100)
    for i in range(100):
        t.update(i)
    t.close()


# Generated at 2022-06-24 10:07:32.573824
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm.auto import trange
    from io import StringIO
    import sys
    # Check the clear method is correctly executed on a single line
    fd = StringIO()
    sys.stdout = fd
    for i in trange(1):
        pass
    out = fd.getvalue()
    for i in trange(1, disable=True):
        pass
    out_n = fd.getvalue()
    # Check the clear method is correctly executed on multiple lines
    fd = StringIO()
    sys.stdout = fd
    for i in trange(10, desc="foobar"):
        pass
    out += fd.getvalue()
    for i in trange(10, desc="foobar", disable=True):
        pass
    out_n = out_n + fd.get

# Generated at 2022-06-24 10:07:40.367000
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .utils_mock import StringIO
    from collections import namedtuple
    from progress.bar import PixelBar, FillingSquaresBar, ChargingBar
    from progress.counter import Counter
    from progress.spinner import Spinner
    from progress.helpers import Screen
    from progress.helpers import Stream
    from progress.helpers import percentage
    from progress.helpers import reverse_chars
    from progress.helpers import takewhile
    from progress.helpers import unicode_width
    from progress.history import History
    from progress.timer import Timer
    from progress.bar import Bar

    # Test without bar_format
    with StringIO() as io:
        t = tqdm(iterable=range(10))

# Generated at 2022-06-24 10:07:51.521079
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    """
    test tqdm_telegram.display() method
    """

    # Imports
    import io
    import os
    import sys
    import pytest
    from tqdm import tqdm
    from tqdm.contrib.telegram import tqdm_telegram

    # Initialize
    tqdm._instances.clear()
    
    # Test tqdm_telegram.display()
    def test_display():
        """test tqdm_telegram.display() method"""

# Generated at 2022-06-24 10:07:53.436482
# Unit test for function trange
def test_trange():
    """Test Telegram trange function"""
    assert trange(0, 10, token='dummy', chat_id='1') is None

# Generated at 2022-06-24 10:08:04.538645
# Unit test for function trange
def test_trange():
    import sys

    try:
        import requests
    except ImportError:
        return False

    with open(sys.argv[0], 'r') as f:
        sourcelines = f.readlines()
    testlines = [l for l in sourcelines if l.startswith("# UNIT")]

    if len(testlines) > 0:
        token = testlines[0].split('"')[1]
        chat_id = testlines[1].split('"')[1]
        for i in trange(4, token=token, chat_id=chat_id):
            assert i >= 0
    return True

# UNIT TEST: "823758114:AAGRfBX9MhW-s8s0sBfzlZXCYmRzA8hHz4c"
# UNIT TEST

# Generated at 2022-06-24 10:08:08.923332
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tg_token = getenv('TQDM_TELEGRAM_TOKEN')
    tg_chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    tg = TelegramIO(tg_token, tg_chat_id)
    tg.submit(tg.delete)

# Generated at 2022-06-24 10:08:15.643827
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import re
    # requests.exceptions.HTTPError: 400 Client Error: Bad Request
    f = TelegramIO("a" * 30, "b" * 30)
    try:
        f.write("")
        f.write("")
        f.write("hello")
    except Exception:
        pass
    finally:
        assert re.search(r"Message to edit not found", f.text)



# Generated at 2022-06-24 10:08:17.068693
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
  TelegramIO('', '')


# Generated at 2022-06-24 10:08:19.758875
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    tio = TelegramIO('token', 'chat_id')
    assert tio.token == 'token'
    assert tio.chat_id == 'chat_id'

# Generated at 2022-06-24 10:08:28.108309
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    from datetime import datetime
    from os import environ
    from unittest import TestCase, main
    class TestTelegramIO(TestCase):

        def test_delete(self):
            try:
                now = datetime.now().strftime('%H%M%S')
                msg = '{} Test message #invalid!' + now
                token = environ['TQDM_TELEGRAM_TOKEN']
                chat_id = environ['TQDM_TELEGRAM_CHAT_ID']
                io = TelegramIO(token, chat_id)
                io.write(msg)
                io.delete()
            except Exception as e:
                self.fail(str(e))

    main()



# Generated at 2022-06-24 10:08:35.169672
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from requests import post
    from time import sleep
    from os import getenv
    from tqdm import tqdm

    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if not (token and chat_id):
        raise ImportError(__doc__)

    # Clean up
    sleep(1)
    post(TelegramIO.API + '%s/deleteMessage' % token,
         data={'chat_id': chat_id, 'message_id': 123456789})  # Telegram
    # error if `message_id` does not exist

    # Create message
    t = tqdm(token=token, chat_id=chat_id, mininterval=0)

    # Test write
    t

# Generated at 2022-06-24 10:08:41.934807
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    """
    Test tqdm_telegram.clear()
    """
    import time
    try:
        import numpy as np
    except ImportError:
        return None
    from .utils_tqdm_telegram import tqdm_telegram
    token = "763676649:AAEPWq0kTAg2P9iZH4F4f0kGw0pz7jEnMdI"
    chat_id = '626096120'
    x = np.arange(100)
    with tqdm_telegram(x, desc='With', unit="obj", token=token, chat_id=chat_id) as t:
        for i in t:
            t.set_description("Desc %i" % i)
            time.sleep(0.01)

# Generated at 2022-06-24 10:08:47.719334
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    t = tqdm_telegram(list(range(3)), token='{token}', chat_id='{chat_id}')
    assert len(list(t)) == 3



# Generated at 2022-06-24 10:08:51.174486
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    try:
        tqdm_telegram(token='123', chat_id='-123')
    except:
        pass

# Generated at 2022-06-24 10:08:54.239087
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from .tests_telegram import test_tqdm_telegram_clear
    test_tqdm_telegram_clear(TelegramIO, tqdm_telegram)

# Generated at 2022-06-24 10:08:56.848204
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    try:
        token = getenv('TQDM_TELEGRAM_TOKEN')
        chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
        tgio = TelegramIO(token=token, chat_id=chat_id)
        tgio.delete()
    except Exception:
        pass

# Generated at 2022-06-24 10:08:58.606228
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    with tqdm(desc='test', leave=False, disable=False, token='', chat_id='') as t:
        t.update(5)

# Generated at 2022-06-24 10:09:01.070544
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    token = '{token}'
    chat_id = '{chat_id}'
    tg = TelegramIO(token, chat_id)
    tg.delete()



# Generated at 2022-06-24 10:09:04.512146
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tgio = TelegramIO('{token}', '{chat_id}')
    tgio.write("test")
    tgio.delete()

# Generated at 2022-06-24 10:09:09.160177
# Unit test for function trange
def test_trange():
    from time import sleep

    for _ in trange(5, token='282435821:AAHMaI_dM_USM8JNb-kX9QQ1N1KBJgNdG1c', chat_id='302066694'):
        sleep(0.5)

# Generated at 2022-06-24 10:09:12.579575
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tgio = TelegramIO('', '')
    class val:
        x = 0
    def callback(x):
        val.x = x
    tgio.write('test').add_done_callback(lambda x: callback(x))
    assert val.x == None


# Generated at 2022-06-24 10:09:15.973131
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    tgio = TelegramIO('{token}', '{chat_id}')
    tgio.write("test123")
    tgio.write("")

test_tqdm_telegram_clear()

# Generated at 2022-06-24 10:09:25.160142
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    import sys
    # testing `tqdm_telegram` constructor
    assert (tqdm(range(3), file=sys.stdout, miniters=1, mininterval=1.1,
                 smoothing=0.0, ascii=True).__repr__() ==
            '  0%|          | 0/3 [00:00<?, ?it/s]\n'
            '100%|##########| 3/3 [00:02<00:00,  1.04s/it]\n')


if __name__ == '__main__':
    from .utils_test import run_tests
    run_tests(__doc__)

# Generated at 2022-06-24 10:09:30.385782
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    """Tests the TelegramIO constructor."""
    tg = TelegramIO("token", "chat_id")
    assert tg.token == "token"
    assert tg.chat_id == "chat_id"
    assert tg.message_id is not None

# Generated at 2022-06-24 10:09:36.491749
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from .utils import hidden_cursor, _range

    with hidden_cursor():
        for i in trange(10, leave=False, token='{token}', chat_id='{chat_id}'):
            pass
        for i in trange(10, leave=True, token='{token}', chat_id='{chat_id}'):
            pass

# Generated at 2022-06-24 10:09:39.236577
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    telegram_io = TelegramIO('', '')
    class Test:
        def display(self, **kwargs):
            telegram_io.write("")
    assert isinstance(Test, tqdm_telegram)

# Generated at 2022-06-24 10:09:44.376683
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    telegramIO = TelegramIO(
        token='1032715533:AAG_elw_iZz7McZj0X0p_r-IMrEPRCgKcvg',
        chat_id='@testing_tqdm')
    telegramIO.write('Hello world')
    return 0


if __name__ == '__main__':
    test_TelegramIO_write()

# Generated at 2022-06-24 10:09:52.880871
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    """Test `TelegramIO` tqdm warning message."""
    with warn(record=True) as w:
        TelegramIO('', '@')
    # self._message_id is created on __init__()
    # warn message
    assert len(w) == 1
    assert issubclass(w[-1].category, TqdmWarning)

# Generated at 2022-06-24 10:10:02.819473
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    try:
        from requests import Session
    except ImportError:
        class Session(object):
            def __init__(self):
                self.func = None
                self.data = None

            def post(self, func, data):
                self.func = func
                self.data = data
                return {'result': {'message_id': 1}}

    class TestTelegramIO(TelegramIO):
        def __init__(self):
            self.session = Session()
            self.chat_id = 1
            self.token = 1

    test_tgio = TestTelegramIO()

    @test_tgio.write("")
    def test_write():
        pass

    assert test_tgio._message_id == 1

# Generated at 2022-06-24 10:10:11.272646
# Unit test for function trange
def test_trange():
    TelegramIO.API = 'http://localhost:5000/telegram.org/bot'
    list(trange(10, token='token', chat_id='123'))
    list(trange(10, disable=True, token='token', chat_id='123'))
    try:
        list(trange(10, token='token', chat_id='123',
                    bar_format='{desc} {bar} {rate_fmt}{postfix}'))
    except:
        pass

# Generated at 2022-06-24 10:10:17.808675
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from .utils_test import _is_in
    from .tests_telegram import token, chat_id
    for s in ["", " ", "\n\r", "foo"]:
        with tgrange(3, desc=s, token=token, chat_id=chat_id) as pbar:
            assert _is_in(s, pbar)
            pbar.clear()
            assert _is_in(s, pbar)
            pbar.close()
    return True

# Generated at 2022-06-24 10:10:24.504126
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from re import match
    t = tqdm_telegram(total=100, desc='desc')
    assert match(r"\A\[(\d+/100)?.?\]", t.format_meter(**t.format_dict))
    t.update(70)
    assert match(r"\A\[70/100.?\]", t.format_meter(**t.format_dict))
    t.update(100)
    assert match(r"\A\[100/100.?\]", t.format_meter(**t.format_dict))


if __name__ == '__main__':
    from doctest import testmod
    testmod(verbose=True)

# Generated at 2022-06-24 10:10:28.211126
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    """
    >>> from tqdm.contrib.telegram import tqdm, trange
    >>> assert token:
    >>> assert chat_id:
    >>> for i in tqdm(iterable, token=token, chat_id=chat_id):
    ...     ...
    """
    pass

# Generated at 2022-06-24 10:10:30.803112
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    with tqdm_telegram(total=10, token="123", chat_id="456") as t:
        for i in range(10):
            t.update()
            time.sleep(0.1)

# Generated at 2022-06-24 10:10:36.607845
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tgio = TelegramIO('574040207:AAFdgEHk-P_X8V7sdfsdfsdfsdfsdfsdfsdfsdfs',
                      '-1000000000')
    tgio.write('test')
    tgio.flush()
    tgio.close()

test_TelegramIO_write()

# Generated at 2022-06-24 10:10:43.170351
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    assert TelegramIO(
        token='123456789:AAAABBCCDD1-0000000000_AAAAAAAAAA',
        chat_id='123456789').message_id == 65


if __name__ == '__main__':  # pragma: no cover
    from .utils_test import test_telegram
    test_telegram()

# Generated at 2022-06-24 10:10:54.810962
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    import time
    # sleep to let tgio.write(self.format_meter(**fmt)) perform
    time.sleep(0.01)
    token = "{token}"
    chat_id = "{chat_id}"
    tg = tqdm_telegram(iterable,token=token,chat_id=chat_id)
    tg.close()
    # sleep to let tgio.write("") perform
    time.sleep(0.01)
    tg = tqdm_telegram(iterable,token=token,chat_id=chat_id,leave=True)
    tg.close()
    # sleep to let tgio.delete() perform
    time.sleep(0.01)

if __name__ == '__main__':
    test_tqdm_telegram_close()

# Generated at 2022-06-24 10:10:59.872393
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from .utils_test import with_mixin
    from .utils_test import hidden_cursor, window_width

    # Test for empty iterator
    with hidden_cursor():
        with with_mixin(tqdm_telegram, 'display'):
            with with_mixin(tqdm_telegram, 'format_dict') as fd:
                t = tqdm_telegram(token='token', chat_id='chat_id', desc='Testing:')
                fd['total'] = 0
                fd['elapsed'] = 0
                t.display()
                assert(window_width() == 0)

# Generated at 2022-06-24 10:11:05.348925
# Unit test for function trange
def test_trange():
    """
    Unit test for tqdm.contrib.telegram.trange
    """
    from ..utils import _term_move_up

    with ttgrange(10, token='{token}', chat_id='{chat_id}') as t:
        for i in t:
            t.set_description("testing trange (please wait)")
            if i >= 8:
                break


# Generated at 2022-06-24 10:11:16.008791
# Unit test for function trange
def test_trange():
    """Unit test for `tqdm.contrib.telegram.trange`"""
    import sys
    sys.stderr = sys.stdout
    from .utils import _test_gen
    from .utils_repr import format_dict

    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if not all([token, chat_id]):
        raise Exception("environment variables TQDM_TELEGRAM_TOKEN and "
                        "TQDM_TELEGRAM_CHAT_ID must be set")

    # Test trange
    format_dict['bar_format'] = '{l_bar}{bar:10u}{r_bar}'

# Generated at 2022-06-24 10:11:26.239411
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import time
    import json
    import os
    import pytest
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    TEXTS = ["Hello world! 🐍🐍🐍", "", "...", "", "Bye Bye 🐍🐍🐍"]
    METHOD = "POST"
    URL = "http://www.google.com"
    HEADERS = {"Header1": "Value1", "Header2": "Value2"}
    JSON_DATA = {"Test": "Test2"}
    FILES = {
        "Foo": ("Foo.txt", "Hello!"),
        "Bar": ("Bar.txt", open("Bar.txt", "rb"), "image/png", {"Foo": "Bar"})}
    RESPONSE_

# Generated at 2022-06-24 10:11:35.913203
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    from requests.exceptions import HTTPError
    t = TelegramIO('q','q')
    t.session.post = lambda *i,**k: {'error_code':429}.iteritems()
    t.message_id
    t = TelegramIO('123','123')
    t.session.post = lambda *i,**k: []
    try:
        t.message_id
    except HTTPError:
        pass
    t.session.post = lambda *i,**k: [('error_code',123)]
    t.message_id
    t.session.post = lambda *i,**k: [('result', {'message_id': 1234})].iteritems()
    assert t.message_id == 1234

# Generated at 2022-06-24 10:11:39.194307
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    tgio = TelegramIO('1234567890', '9876543210')
    assert tgio.token == '1234567890'
    assert tgio.chat_id == '9876543210'
    assert tgio._message_id == tgio.message_id

# Generated at 2022-06-24 10:11:45.540793
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    """
    >>> from tqdm.contrib.telegram import TelegramIO
    >>> tg = TelegramIO('123456789:AAEbiHs2sRwTzT_TU6p0MNxjZb6L_U6aYnc', 0)
    >>> print(tg.write("Teste"))
    None
    """
    pass


# Generated at 2022-06-24 10:11:56.713761
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    from os import environ
    from time import sleep
    from types import SimpleNamespace
    from unittest.mock import patch

    # Skip test if the environment variables are not set
    token = environ.get('TQDM_TELEGRAM_TOKEN')
    chat_id = environ.get('TQDM_TELEGRAM_CHAT_ID')
    if token is None or chat_id is None:
        return

    tgio = TelegramIO(token, chat_id)
    class Response(SimpleNamespace):
        status_code = 200
        json = lambda self: {'ok': True, 'result': True}
    with patch.object(tgio.session, 'post') as mock_post:
        mock_post.return_value = Response()
        future = tgio.delete()