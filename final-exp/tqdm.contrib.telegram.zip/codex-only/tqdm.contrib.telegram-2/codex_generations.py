

# Generated at 2022-06-24 10:01:55.656633
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm._utils import _term_move_up
    try:
        TelegramIO(getenv('TQDM_TELEGRAM_TOKEN'),
                   getenv('TQDM_TELEGRAM_CHAT_ID')).write("foo" + _term_move_up() + "bar")
    except:
        # TODO: remove this
        warn("Unit test for tqdm_telegram.clear failed. Skipping.", TqdmWarning)

# Generated at 2022-06-24 10:01:58.025073
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from .utils_test import _test_close

    _test_close(tqdm_telegram)



# Generated at 2022-06-24 10:02:05.144213
# Unit test for function trange
def test_trange():
    """Test function `trange`."""
    from random import random
    from time import sleep
    with trange(10, token='1263707645:AAHf9OzH_8iidxCxOdcglIQZfA0wQY-kaug',
                chat_id='628529755') as t:
        for i in t:
            sleep(random() / 5.)
    assert t.n == 10


if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-24 10:02:16.884298
# Unit test for function trange
def test_trange():
    from sys import version_info
    from time import sleep

    if version_info[0] >= 3:
        range = _range

    try:
        with trange(10, token='{token}', chat_id='{chat_id}') as t:
            for i in t:
                sleep(0.001)
    except Exception:
        pass
    else:
        raise RuntimeError("TEST FAIL")

    try:
        with trange(10, token='{token}', chat_id='{chat_id}', disable=None) as t:
            for i in t:
                if i == 5:
                    t.close()
                    break
                sleep(0.001)
    except Exception:
        pass
    else:
        raise RuntimeError("TEST FAIL")


# Generated at 2022-06-24 10:02:27.221251
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from ..tqdm_gui import tqdm_gui
    from ..utils import _supports_unicode
    for cls in [tqdm, trange]:
        # check_gui_exception=True should not raise
        # assert tqdm(..., gui=True)
        assert tqdm(total=2, gui=True, check_gui_exception=True)
        assert not hasattr(tqdm, '_instances')
        # check_gui_exception=False should raise
        # assert tqdm(..., gui=False)
        tqdm(total=2, gui=False, check_gui_exception=False)
        assert hasattr(tqdm, '_instances')
        # check_gui_exception=False should raise
        # assert tqdm(..., gui=None

# Generated at 2022-06-24 10:02:33.143565
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    print("Testing `tqdm.contrib.telegram.TelegramIO` ...")
    t = TelegramIO("123", "123")
    assert t.token == "123"
    assert t.chat_id == "123"
    assert t.token == "123"
    assert t.chat_id == "123"
    assert t.text == "TelegramIO"
    assert t.tgio is t
    del t
    print("done.")
# /Unit test

# Generated at 2022-06-24 10:02:35.540710
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    try:
        TelegramIO('', '')
    except Exception as e:
        print(str(e))


if __name__ == '__main__':
    test_TelegramIO()

# Generated at 2022-06-24 10:02:39.004419
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tgio = TelegramIO('fake_token', 'fake_chat_id')
    tgio.write('first')
    assert tgio.text == 'first'
    tgio.write('second')
    assert tgio.text == 'second'
    tgio.write('third')
    assert tgio.text == 'third'
    tgio.close()



# Generated at 2022-06-24 10:02:42.283354
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    t = tqdm_telegram(['a', 'b', 'c'], token='{token}', chat_id='{chat_id}')
    assert not t.disable
    t.close()
    assert t.disable

# Generated at 2022-06-24 10:02:50.505697
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import sys
    from contextlib import contextmanager

    @contextmanager
    def stdout_redirected(where):
        sys.stdout = where
        try:
            yield where
        finally:
            sys.stdout = sys.__stdout__

    with stdout_redirected(TelegramIO('', '')):
        t = tqdm_telegram(_range(0))
        t.display()
        assert t.tgio.text == 'tqdm_telegram'
        t.close()

# Generated at 2022-06-24 10:02:59.977385
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from io import StringIO
    from time import sleep

    io = StringIO()
    cls = TelegramIO(token='bot123456789:abcdefz-qwertyz-aBcDefG',
                     chat_id=123456789, file=io)
    cls.write("start")
    sleep(5)
    cls.write("end")
    assert io.getvalue() == "start\nend\n"

    io = StringIO()
    cls = TelegramIO(token='botabcdefz-qwertyz-aBcDefG', chat_id=123456789,
                     file=io)
    cls.write("start")
    sleep(5)
    cls.write("end")
    assert io.getvalue() == "start\nend\n"

# Generated at 2022-06-24 10:03:10.582876
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from os import environ as env
    from unittest import TestCase
    from mock import patch

    with patch.dict(env, {'TQDM_TELEGRAM_TOKEN': 'token',
                          'TQDM_TELEGRAM_CHAT_ID': 'chat_id'}):
        t = ttgrange(1, leave=False)
        t.close()
        assert t.tgio.message_id is None

        t = ttgrange(1, leave=False)
        t.refresh()
        t.close()
        assert t.tgio.message_id is not None

if __name__ == '__main__':
    from sys import argv

# Generated at 2022-06-24 10:03:15.994148
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    tt = tqdm_telegram(range(3), token='{token}', chat_id='{chat_id}')
    assert tt.token == '{token}'
    assert tt.chat_id == '{chat_id}'


if __name__ == '__main__':
    from .utils import _test  # pylint: disable=import-error

    _test()

# Generated at 2022-06-24 10:03:17.890939
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    """Test above tqdm_telegram"""
    from .utils_test import _test_telegram
    _test_telegram(tqdm)

# Generated at 2022-06-24 10:03:25.503582
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from tqdm.auto import _range
    from os import remove

    with tqdm(_range(10), token='dummy', chat_id='dummy') as pbar:
        for _ in pbar:
            pass


if __name__ == '__main__':
    from .utils_testing import TestingIO
    test_tqdm_telegram()
    with TestingIO() as test:
        with tqdm_telegram(test, token='dummy', chat_id='dummy') as pbar:
            pbar.update(2)
            pbar.display()
            pbar.update()
            pbar.display()
            pbar.close()
            pbar.close()

# Generated at 2022-06-24 10:03:32.705870
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from os import getenv
    from random import randint

    message_list = []

    class TelegramIO(MonoWorker):
        API = 'https://api.telegram.org/bot'

        def __init__(self, token, chat_id):
            super(TelegramIO, self).__init__()
            self.token = token
            self.chat_id = chat_id
            self.session = Session()
            self.text = self.__class__.__name__
            self.message_id

        @property
        def message_id(self):
            if hasattr(self, '_message_id'):
                return self._message_id

# Generated at 2022-06-24 10:03:35.086948
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    message_id = TelegramIO(token, chat_id).delete()
    assert message_id is None

# Generated at 2022-06-24 10:03:39.044986
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    tg = TelegramIO(
        token=getenv('TQDM_TELEGRAM_TOKEN'),
        chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'))
    tg.write('---')
    tg.write('---')

# Generated at 2022-06-24 10:03:43.558673
# Unit test for function trange
def test_trange():
    import os
    import re
    import string
    import sys
    import time
    import inspect
    import subprocess

    TEST_TEMPLATE = """
        import sys
        from tqdm.contrib.telegram import ttgrange, trange
        __name__ = __file__
        if __name__ == %(__name__)r:
            for i in trange(*{args!r}, **{kwargs!r}):
                time.sleep(0.01)
    """

    if sys.version_info >= (3, 0):
        from importlib import reload  # NOQA, to avoid warning on 2.6

    from .utils import _test_importable, _test_python
    from .utils_telegram import _test_telegram_py


# Generated at 2022-06-24 10:03:47.268112
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    assert tqdm(total=100).clear() is None

# Generated at 2022-06-24 10:03:52.094044
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from glob import glob
    from random import random
    from time import sleep

    try:
        with tqdm(total=10, token='{token}', chat_id='{chat_id}') as pbar:
            for filename in glob(__file__):
                sleep(random() / 2)
                pbar.update()
    except Exception as e:
        warn(str(e))

# Generated at 2022-06-24 10:03:57.115898
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    tgio = TelegramIO(
        token=getenv('TQDM_TELEGRAM_TOKEN'),
        chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'))
    tgio.close()


# Generated at 2022-06-24 10:03:58.736010
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from .tests import tests
    return tests(tqdm_telegram)

# Generated at 2022-06-24 10:04:02.492736
# Unit test for function trange
def test_trange():
    for _ in tqdm_telegram(ttgrange(10), leave=False, token='1234567890',
                           chat_id='123456789'):
        pass

# Generated at 2022-06-24 10:04:10.163694
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    '''
    Test to ensure the display of tqdm_telegram function is correct
    '''
    from os import remove
    from tqdm import tnrange
    import json
    import re

    class TestClass:
        def __init__(self, token, chat_id):
            self.token = token
            self.chat_id = chat_id
            self.session = Session()
            self.text = self.__class__.__name__
            self.message_id

        @property
        def message_id(self):
            if hasattr(self, '_message_id'):
                return self._message_id

# Generated at 2022-06-24 10:04:22.108443
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():

    # Test with token and chat_id of @tqdmtestbot
    tg = TelegramIO(
        "1020265965:AAFYrHc6j5U6vtX9XLBp_vSLjKfJhx6e7IU", "-1001388175692")
    assert tg.write("Write this") == None
    assert tg.write("Then this") == None
    assert tg.write("") == None
    assert tg.write("") == None
    tg.session.close()

    # Test with wrong token and chat_id
    tg = TelegramIO(
        "1020265965:AAFYrHc6j5U6vtX9XLBp_vSLjKfJhx6e7IU1", "-10013881756921")
    assert tg

# Generated at 2022-06-24 10:04:29.500541
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    tgio = TelegramIO('{token}', '{chat_id}')
    tgio.write('test')
    tgio.delete()
    assert isinstance(tgio, TelegramIO)
    assert isinstance(tgio.message_id, int)
    assert isinstance(tgio.write('test'), tqdm_auto.Future)
    assert isinstance(tgio.delete(), tqdm_auto.Future)

# Generated at 2022-06-24 10:04:38.385552
# Unit test for function trange
def test_trange():
    from .utils_test import verify_instances
    from .utils_test import _no_output_context

    assert trange == ttgrange
    # Test basic instance
    with _no_output_context():
        r = ttgrange(4)
        verify_instances(r, tqdm_telegram)
        list(r)

    # Test disable
    with _no_output_context():
        r = ttgrange(4, disable=True)
        verify_instances(r, tqdm_auto)
        list(r)

# Generated at 2022-06-24 10:04:45.619607
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from requests import Session
    import tempfile
    import time
    with tempfile.NamedTemporaryFile(mode='a+') as f:
        with Session() as s:
            f.write('a\n')
            f.flush()
            f.seek(0)
            with tqdm_auto(iterable=f, desc='descr', file=s, unit='b') as t:
                assert t.write('e') is None
                assert t.write('g') is None
                f.write('b\n')  # simulate readline
                f.flush()
                f.seek(0)
                assert t.write('d') is None
                f.write('c\n')  # simulate readline
                f.flush()
                f.seek(0)
                time.sleep(1)
                assert t

# Generated at 2022-06-24 10:04:50.408223
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    print("TelegramIO.write")
    import os
    tqdm_auto.write = print
    tqdm_auto.file = TelegramIO(
        os.getenv('TQDM_TELEGRAM_TOKEN'),
        os.getenv('TQDM_TELEGRAM_CHAT_ID'))
    tqdm_auto.display()
    tqdm_auto.display()  # second write
    tqdm_auto.write("")  # empty write
    tqdm_auto.display()  # back to previous write
    tqdm_auto.write("hop", file=tqdm_auto)  # change from default file
    tqdm_auto.display()  # change from default file
    tqdm_auto.file.write("hey")  # change from default file
    tqdm

# Generated at 2022-06-24 10:04:55.371406
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    from os import environ
    try:
        if ('TQDM_TELEGRAM_TOKEN' not in environ
                or 'TQDM_TELEGRAM_CHAT_ID' not in environ):
            return None
        test = TelegramIO('TQDM_TELEGRAM_TOKEN', 'TQDM_TELEGRAM_CHAT_ID')
        assert 'message_id' in test.__dict__
    except Exception:
        return None

# Generated at 2022-06-24 10:05:00.063699
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    # Test case 1
    t = tqdm_telegram(1)
    t.total = 1
    t.n = 1
    t.leave = False
    t.close()
    assert t.leave == False

    # Test case 2
    t = tqdm_telegram(1)
    t.total = 1
    t.n = 1
    t.leave = True
    t.close()
    assert t.leave == True

# Generated at 2022-06-24 10:05:03.670163
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    with tqdm_telegram(10, disable=True) as t:
        for i in t:
            t.display(l_bar="", bar_format='{bar}')
            if i == 5:
                t.display(l_bar="")
                t.display(bar_format='{bar}')
                t.display(bar_format='{bar:10u}')
            if i == 7:
                t.display(bar_format='')

# Generated at 2022-06-24 10:05:09.041712
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from time import time
    from .utils_test import closing

    with closing(tqdm_telegram(total=100, unit='B', unit_scale=True,
                               miniters=0, mininterval=0, desc='test', leave=True)) as pbar:
        for i in range(10):
            pbar.update(10)
            time()  # Make sure time actually changes between iterations
            pbar.refresh()

# Generated at 2022-06-24 10:05:14.314703
# Unit test for function trange
def test_trange():
    iterable = trange(2, 3, 0.1, token='{token}', chat_id='{chat_id}')
    try:
        assert iterable.__self__.tgio.chat_id == '{chat_id}'
    finally:
        try:
            iterable.close()
        except Exception:
            pass

# Generated at 2022-06-24 10:05:18.031232
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm(total=100, leave=False)
    t.close()
    t = tqdm(total=0, leave=False)
    t.close()

# Generated at 2022-06-24 10:05:21.755720
# Unit test for function trange
def test_trange():
    from .utils_tests import _test_trange
    _test_trange(trange, __file__)


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 10:05:27.277169
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    # The test part starts
    from ..tqdm import tqdm_telegram as tt
    from time import sleep

    for i in tt(range(10), total=10, delete=False):
        sleep(0.1)
        tt.write("Message {}".format(i))
    tt.clear()
    # End of test part


# Generated at 2022-06-24 10:05:37.832891
# Unit test for function trange
def test_trange():
    """Test telegram tqdm"""
    from os import remove
    from tempfile import mkstemp

    from re import search
    from sys import version_info
    from .utils import _range, IS_PYTHON, IS_WINDOWS
    from .tests_telegram import _get_telegram_token, _get_telegram_chat_id
    from .tests_env import slow

    token = _get_telegram_token()
    chat_id = _get_telegram_chat_id()

    with tqdm(token=token, chat_id=chat_id) as t:
        t.write("test")
        t.update(10)
        t.update(100)
        t.n = 200
        t.refresh()
        t.update(10)
        t.update(50)
        t

# Generated at 2022-06-24 10:05:43.525977
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    try:
        with tqdm_telegram(total=100) as pbar:
            for i in _range(10):
                pbar.update(10)
    except Exception as e:
        tqdm_auto.write(str(e))
    else:
        pbar.close()


if __name__ == "__main__":
    test_tqdm_telegram()

# Generated at 2022-06-24 10:05:48.601765
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from re import match
    with tqdm_telegram(0, token='1234567890', chat_id='9876543210') as t:
        t.write("Hello World!")
        txt = t.text
        t.close()
    assert match("Hello World! \[ *\]", txt)

# Generated at 2022-06-24 10:05:55.125733
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from tqdm._tqdm_gui import _GUI
    from time import sleep
    text = 'test'
    sleep(0.5)
    obj = TelegramIO(token='989878402:AAF-8NNH9E-pGZ77FJz6aFi8Rr5U6m2wIc', chat_id='819989684')
    obj.write(text)
    sleep(0.5)
    obj.write('change')
    sleep(0.5)
    obj.clear()
    sleep(0.5)
    obj.write(text)
    sleep(0.5)
    obj.close()
    sleep(0.5)

# Generated at 2022-06-24 10:06:03.667355
# Unit test for function trange
def test_trange():
    n = 100
    out = []
    for i in trange(n, token='{token}', chat_id='{chat_id}'):
        out += [i]
        if i >= n / 2:
            break
    assert out == list(range(n))
    del trange.monitor
    out = []
    for i in tqdm(range(n), token='{token}', chat_id='{chat_id}'):
        if i >= n / 2:
            break
        out += [i]
    assert out == list(range(n))

# Generated at 2022-06-24 10:06:04.652333
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    TelegramIO('token', 'chat_id')

# Generated at 2022-06-24 10:06:07.632263
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    error, token, chat_id = "", "11111", "22222"
    assert TelegramIO(error, chat_id).message_id is None
    assert TelegramIO(token, error).message_id is None
    assert TelegramIO(token, chat_id).message_id is not None

# Generated at 2022-06-24 10:06:09.384014
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tg = TelegramIO('token', 'chat_id')
    tg.write('test text')

# Generated at 2022-06-24 10:06:18.441144
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    print('Testing TelegramIO constructor...')
    from os import environ
    from random import randint
    token, chat_id = environ.get('TQDM_TELEGRAM_TOKEN'), environ.get(
        'TQDM_TELEGRAM_CHAT_ID')
    for _ in _range(4):
        tgio = TelegramIO(token=token, chat_id=chat_id)
        tgio.write('Testing `%s`.' % __file__)
        tgio.write(''.join(chr(randint(0, 25) + 97)
                           for _ in _range(randint(1, 10))))
        tgio.delete()

if __name__ == "__main__":
    test_TelegramIO()

# Generated at 2022-06-24 10:06:21.732126
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    class tqdm(tqdm_telegram):
        def display(*args, **kwargs):
            pass
    t = tqdm(total=1)
    t.update(1)

# Generated at 2022-06-24 10:06:26.047853
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from .test_tqdm import pretest_posttest
    pretest_posttest(tqdm_telegram)



# Generated at 2022-06-24 10:06:33.067410
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():

    try:
        import pytest
        # Skip this function if pytest doesn't exist
        pytest.skip()
    except:
        pass

    # Check if `token` is required
    with pytest.raises(ValueError):
        tqdm(chat_id="{chat_id}")

    # Check if `chat_id` is required
    with pytest.raises(ValueError):
        tqdm(token="{token}")

    # Check if default `token` and `chat_id` aren't accepted
    with pytest.raises(ValueError):
        tqdm()

# Generated at 2022-06-24 10:06:36.460434
# Unit test for function trange
def test_trange():
    for i in trange(10, token='XXXXXXXXX:XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX',
                    chat_id='@XXXXXXXXX'):
        pass



# Generated at 2022-06-24 10:06:45.101408
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    # From constructor
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    pbar = tqdm_telegram(range(1, 5), token=token, chat_id=chat_id)
    assert pbar
    assert pbar.format_dict['bar_format'] == '{l_bar}{bar:10u}{r_bar}'
    pbar.close()

    # From environment variables
    pbar = tqdm_telegram(range(1, 5), disable=False)
    assert pbar
    assert pbar.format_dict['bar_format'] == '{l_bar}{bar:10u}{r_bar}'
    pbar.close()

# Generated at 2022-06-24 10:06:52.099181
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import sys
    sys.modules['msgpack'] = type('MockMsgPack', (), {'packb': lambda x: x,
                                                      'unpackb': lambda x: x})
    assert hasattr(tqdm_telegram.display, '__call__')


# Need to mock msgpack because tqdm_telegram uses
# tqdm_telegram.display() in __init__ where msgpack is not available
# in the environment that currently runs our tests.

# Generated at 2022-06-24 10:06:59.374160
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    print("Testing TelegramIO")
    print("If your Telegram token and chat_id are not set, testing will fail.")
    print("Please set your Telegram token and chat_id as environment variables:")
    print(" - TQDM_TEST_TELEGRAM_TOKEN")
    print(" - TQDM_TEST_TELEGRAM_CHAT_ID")
    print("You can do that with the following command:")
    print(" - export TQDM_TEST_TELEGRAM_TOKEN={your_token}")
    print(" - export TQDM_TEST_TELEGRAM_CHAT_ID={your_chat_id}")
    token = getenv('TQDM_TEST_TELEGRAM_TOKEN')

# Generated at 2022-06-24 10:07:03.841340
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    t = tqdm_telegram(1)
    t.close()



# Generated at 2022-06-24 10:07:05.853382
# Unit test for function trange
def test_trange():
    """Test trange."""
    from .utils_telegram import test_trange
    test_trange(tqdm, trange)

# Generated at 2022-06-24 10:07:15.716408
# Unit test for function trange
def test_trange():
    import os
    import random
    import string

    l = [random.choice(string.ascii_letters) for _ in range(100000)]
    os.environ.update(
        {'TQDM_TELEGRAM_TOKEN': 'found_token', 'TQDM_TELEGRAM_CHAT_ID': '123'})
    for _ in trange(len(l)):
        pass


if __name__ == '__main__':
    from .utils_test import TestIO, _test_cls
    with TestIO():
        _test_cls(tqdm)
        _test_cls(trange)

# Generated at 2022-06-24 10:07:22.632896
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import sys
    import time
    import nose

    with nose.tools.assert_raises(AttributeError):
        test_tqdm = tqdm_telegram(range(3), disable=True)
        test_tqdm.clear(nolock=True)

    test_tqdm = tqdm_telegram(range(3), disable=False)
    test_tqdm.update(2)
    with nose.tools.assert_raises(KeyError):
        test_tqdm.clear(nolock=True)

    test_tqdm.update(3)
    with nose.tools.assert_raises(AttributeError):
        test_tqdm.clear()


# Generated at 2022-06-24 10:07:25.160661
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import time

    with tqdm_telegram(
            total=1, token='{token}', chat_id='{chat_id}') as pbar:
        time.sleep(0.1)
        pbar.n = 0.5
        pbar.display()
        time.sleep(0.1)
        pbar.clear()


# Generated at 2022-06-24 10:07:33.552081
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """
    Uses tqdm.contrib.telegram.tqdm to test its method close.
    The test is performed by running tqdm with tgrange from 0 to 5,
    both with and without specifying the `leave` parameter.
    The output is evaluated for differences between the two cases
    and the test is considered passed if both outputs are equivalent.
    """
    try:
        from requests import Session
    except ImportError:
        return True

    class FakeTelegramIO(MonoWorker):
        def __init__(self):
            super().__init__()
            self.session = Session()
            self.tgio_str = ''

        @property
        def message_id(self):
            return None

        def write(self, s):
            self.tgio_str += s

# Generated at 2022-06-24 10:07:40.556228
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    t = tqdm_telegram(
        iterable=range(1000),
        mininterval=0.001,
        miniters=1,
        ncols=55,
        disable=False,
        desc="tqdm_telegram")

    # Set private variable _message_id
    t.tgio._message_id = 1

    # Test display with bar_format
    t.bar_format = "|{desc:>5s}|{percentage:3.0f}%|{bar}|"
    t.display(postfix=None, n=2, n_fmt=2)

    # Test display without bar_format
    t.bar_format = None
    t.display(postfix=None, n=2, n_fmt=2)

# Generated at 2022-06-24 10:07:42.634285
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tg = TelegramIO('123', '456')
    tg.write('test')
    tg.delete()

# Generated at 2022-06-24 10:07:53.663426
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    out = tqdm([1, 2, 3], disable=True)
    assert out.ascii == False
    assert len(out.format_dict) == 7
    assert out.format_dict['unit'] == 'it'
    assert out.format_dict['unit_scale'] == True
    assert out.format_dict['bar_format'] == '{l_bar}{bar}{r_bar}'
    assert out.format_dict['postfix'] == None
    assert out.format_dict['desc'] == None
    assert out.format_dict['position'] == 0
    assert out.format_dict['ascii'] == False

    out = tqdm([1, 2, 3], disable=False)
    assert out.ascii == False
    assert len(out.format_dict) == 7
    assert out.format

# Generated at 2022-06-24 10:08:03.472553
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from os import environ
    from time import sleep
    from tqdm import tqdm
    token = environ.get("TQDM_TELEGRAM_TOKEN")
    chat_id = environ.get("TQDM_TELEGRAM_CHAT_ID")
    if not token or not chat_id:
        return None

    with tqdm(total=10, token=token, chat_id=chat_id,
              bar_format="{l_bar}{bar:10u}{r_bar}",
              mininterval=1) as pbar:
        for i in range(10):
            pbar.update(1)
            sleep(0.5)

# Generated at 2022-06-24 10:08:12.928117
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    try:
        token = getenv('TQDM_TELEGRAM_TOKEN')
        chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    except:
        token = None
        chat_id = None

    tqdm(token=token, chat_id=chat_id)
    tqdm(token=token, chat_id=chat_id)
    tqdm(token=token, chat_id=chat_id)
    tqdm(token=token, chat_id=chat_id)
    tqdm(token=token, chat_id=chat_id)
    tqdm(token=token, chat_id=chat_id)
    tqdm(token=token, chat_id=chat_id)

# Generated at 2022-06-24 10:08:22.869621
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from os import environ
    from sys import version_info, stderr
    from unittest import TestCase, main

    def write_in_bg(tgio, text):
        tgio.submit(tgio.write, text)

    class Tests(TestCase):
        # FIXME: what is this exactly?
        # @classmethod
        # def setUpClass(cls):
        #     if version_info[0] >= 3:
        #         cls.assertTrue = cls.assertIs

        def test_write(self):
            tgio = TelegramIO(
                environ.get('TQDM_TELEGRAM_TOKEN'),
                environ.get('TQDM_TELEGRAM_CHAT_ID'))
            tgio.start()

# Generated at 2022-06-24 10:08:31.591139
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    io = TelegramIO('123456789:abcdefghijklmnopqrstuvwxyz123456789',
                    '123456789')
    t = tqdm_telegram(
        iterable=None, token='123456789:abcdefghijklmnopqrstuvwxyz123456789',
        chat_id='123456789', disable=True)
    t.tgio = io
    t.close()
    io.close()

# Generated at 2022-06-24 10:08:35.971911
# Unit test for function trange
def test_trange():
    from time import sleep
    try:
        for i in trange(2, token='539668108:AAEPZ4zEZGm_Px9Ce4SV5Y5oQP7VhF5iHjs',
                        chat_id='418978280'):
            sleep(.5)
    except Exception:
        pass  # run repeatedly from the command line

# Generated at 2022-06-24 10:08:42.484769
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    """
    Unit test for method clear of class tqdm_telegram
    """
    dataset = [i for i in range(100)]
    for i in tqdm(dataset, desc='test clear'):
        time.sleep(0.01)
        if i == 20:
            tqdm.clear()
        # else:
        #     tqdm.close()


if __name__ == '__main__':
    from time import time
    from .tests_telegram_token import TEST_TOKEN, TEST_CHAT_ID
    for i in ttgrange(100, desc='test', unit='B', unit_scale=True,
                      miniters=1, mininterval=0.1,
                      token=TEST_TOKEN, chat_id=TEST_CHAT_ID):
        pass
   

# Generated at 2022-06-24 10:08:49.897617
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .tests_tqdm import TestTqdmIO

    TestTqdmIO.extra__init__(
        **{"token": getenv('TQDM_TELEGRAM_TOKEN'),
           "chat_id": getenv('TQDM_TELEGRAM_CHAT_ID')})
    TestTqdmIO.extra_set_up()
    TestTqdmIO.test_display()
    TestTqdmIO.extra_tear_down()

# Generated at 2022-06-24 10:09:00.024393
# Unit test for function trange
def test_trange():
    from tqdm import __version__
    from .utils_locking import _lock_get_tqdm
    with _lock_get_tqdm(block=True):
        tqdm._instances.clear()

    try:
        # basic
        for _ in trange(10,
                        token='000000000000000000000000000000000',
                        chat_id='000000000000000000000000000000000'):
            pass
        # kwargs
        for _ in trange(10, mininterval=0.01,
                        token='000000000000000000000000000000000',
                        chat_id='000000000000000000000000000000000'):
            pass
        # nested
        with trange(10,
                    token='000000000000000000000000000000000',
                    chat_id='000000000000000000000000000000000') as t:
            with t:
                pass
    except Exception as e:
        import traceback
       

# Generated at 2022-06-24 10:09:11.653478
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    try:
        import requests
    except ImportError:
        tqdm_auto.write("Please install `requests`.")
    else:
        import io
        import os
        from time import sleep
        from .utils import _start_new_thread, get_lock

        token = os.getenv('TQDM_TELEGRAM_TOKEN')
        chat_id = os.getenv('TQDM_TELEGRAM_CHAT_ID')

        if token is None:
            tqdm_auto.write("No Telegram token found. Aborting test.")
            return

        if chat_id is None:
            tqdm_auto.write("No Telegram chat ID found. Aborting test.")
            return

        iterable = _range(10)


# Generated at 2022-06-24 10:09:17.329796
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    """
    >>> from tqdm.contrib.telegram import tqdm, trange
    >>> for i in tqdm(iterable, token='{token}', chat_id='{chat_id}'):
    ...     ...
    """
    pass


if __name__ == "__main__":
    from doctest import testmod
    testmod()

# Generated at 2022-06-24 10:09:20.158068
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import pytest
    io = TelegramIO("000", "111")
    io.write("test")
    assert "test" == io.text


# Generated at 2022-06-24 10:09:21.675560
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    telegramIO = TelegramIO('token', 'chat_id')
    telegramIO.text = 'text'
    telegramIO.write('text')


# Generated at 2022-06-24 10:09:26.433593
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    """
    >>> tg = TelegramIO(token='12345:ABCDE', chat_id='-12345678')
    >>> tg.write('test')
    >>> tg.write('test')
    """
    from doctest import testmod as test
    report, _ = test(optionflags=+doctest.REPORT_NDIFF,)
    assert report.failed == 0

# Generated at 2022-06-24 10:09:32.489244
# Unit test for function trange
def test_trange():
    trange(10, token='{token}', chat_id='{chat_id}')
    trange(5, desc='foo', token='{token}', chat_id='{chat_id}')

# Generated at 2022-06-24 10:09:34.434479
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    telegram_io = TelegramIO(..., ...)
    for i in ttgrange(100):
        telegram_io.write(f"Current Progress is {i}")

# Generated at 2022-06-24 10:09:37.313708
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    assert TelegramIO(getenv('TQDM_TELEGRAM_TOKEN'),
                      getenv('TQDM_TELEGRAM_CHAT_ID'))

# Generated at 2022-06-24 10:09:39.720680
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tg = TelegramIO(getenv('TQDM_TELEGRAM_TOKEN'),
                    getenv('TQDM_TELEGRAM_CHAT_ID'))
    tg.write("???")
    tg.delete()

# Generated at 2022-06-24 10:09:48.079594
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    if getenv('TRAVIS'):
        return  # too slow
    from time import sleep
    from io import StringIO
    from contextlib import redirect_stdout

    print('\nStarting tests . . .')

# Generated at 2022-06-24 10:09:52.805415
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    import time
    import random
    import numpy as np

    # Initialize the global variables
    # using the environment variables
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    token = getenv('TQDM_TELEGRAM_TOKEN')

    # Set the random seed and set the number of iterations
    random.seed(42)
    n = 11

    # Define the list of elements to iterate upon
    a = np.linspace(0, 1, n)

    # For each value in the list, sleep for a random amount of time, and print
    # the value
    for i in tqdm(a, chat_id=chat_id, token=token):
        time.sleep(random.random())
        print(i)

    # Close the request
    tqdm

# Generated at 2022-06-24 10:10:02.478144
# Unit test for function trange
def test_trange():
    """Unit test"""
    import time, sys
    token, chat_id = getenv('TQDM_TELEGRAM_TOKEN'), getenv('TQDM_TELEGRAM_CHAT_ID')
    if not (token and chat_id):
        print("""
            Please re-run the unit test with the following environment variables:
            $ TQDM_TELEGRAM_TOKEN=<your token> TQDM_TELEGRAM_CHAT_ID=<your chat_id> python -m tqdm.contrib.telegram
            Get a token with https://core.telegram.org/bots#6-botfather
            Get a chat_id with https://api.telegram.org/bot<token>/getUpdates
            """)
        sys.exit(0)


# Generated at 2022-06-24 10:10:09.542687
# Unit test for function trange
def test_trange():
    """Test that ttgrange doesn't fail to iterate"""
    trange(1)


if __name__ == '__main__':
    from time import sleep
    for i in ttgrange(10, token='{token}', chat_id='{chat_id}'):
        sleep(0.1)

# Generated at 2022-06-24 10:10:12.135111
# Unit test for function trange
def test_trange():
    import time
    with trange(1) as t:
        time.sleep(1)
        t.update()

if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-24 10:10:20.488894
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    message = 'Hello World'
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    tgio = TelegramIO(token, chat_id)
    tgio.submit(tgio.session.post, tgio.API + '%s/sendMessage' % tgio.token,
                data={'text': '`' + message + '`',
                      'chat_id': int(tgio.chat_id),
                      'parse_mode': 'MarkdownV2'})
    tgio.wait()

# Generated at 2022-06-24 10:10:28.413897
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import os
    import io
    import sys
    import io
    import tempfile
    import tqdm
    tqdm.tqdm = tqdm_telegram
    with tempfile.NamedTemporaryFile('w', delete=False) as tmp:
        h = tqdm.tqdm(io.StringIO(),
                file=tmp)
        h.display(bar_format='{bar}')
        h.close()
        assert os.path.getsize(tmp.name) > 0
    os.unlink(tmp.name)
    sys.stderr = stderr = io.StringIO()
    with tqdm.tqdm(file=stderr) as h:
        h.set_description("test")
        h.update(1)

# Generated at 2022-06-24 10:10:35.457132
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    # Test if leave is set correctly
    # The return of close should be the same as `self.leave`
    for leave in [True, False, None]:
        test = tqdm_telegram(iterable=[],leave=leave)
        assert test.close() == leave

    # Test if leave is None and pos is 0 (i.e. the bar is not finished)
    test = tqdm_telegram(iterable=[],leave=None)
    test.pos = 0
    assert test.close() == False

# Generated at 2022-06-24 10:10:42.534172
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
  t = tqdm_telegram(range(3), token='@bot', chat_id='/bot')
  assert not hasattr(t, '_io')
  assert t.render_pos == 0
  t.close()
  assert not hasattr(t, '_io')
  assert t.render_pos == 0
  t.render_pos += 1
  t.close()
  assert not hasattr(t, '_io')
  assert t.render_pos == 1
  t.render_pos += 1
  t.close()
  assert not hasattr(t, '_io')
  assert t.render_pos == 1
  t.render_pos += 1
  t.close()
  assert not hasattr(t, '_io')
  assert t.render_pos == 2

# Generated at 2022-06-24 10:10:43.731347
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    assert tqdm_telegram(disable=True).clear() is None


# Generated at 2022-06-24 10:10:49.954140
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    io = TelegramIO('{token}', '{chat_id}')
    io.close()


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 10:10:52.686020
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    assert "rate{rate_fmt}" in tqdm_telegram(10, unit='B', unit_scale=True).format_dict  # noqa

# Generated at 2022-06-24 10:11:01.920406
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    chat_id = '@tqdm'
    token = '123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghi'
    tlg_io = TelegramIO(token, chat_id)
    tlg_io._message_id = '25375677'
    assert tlg_io.delete(), print('delete method is not working')

# Generated at 2022-06-24 10:11:10.397515
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    t = TelegramIO("test_token", "test_chat_id")
    assert t.text == "TelegramIO"
    t.write("")
    assert t.text == "..."
    t.write("Hi")
    assert t.text == "Hi"
    t.write("\n")
    assert t.text == "..."
    t.write("Hello, World!")
    assert t.text == "Hello, World!"


# Generated at 2022-06-24 10:11:17.474081
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    """
    Test unit method display of class tqdm_telegram
    """
    obj = tqdm_telegram(
        desc='test',
        total=100,
        ncols=100,
        mininterval=0.01,
        smoothing=0.5,
        ascii=True,
        disable=False
    )

    obj.update()
    obj.display()

    obj.update(50)
    obj.display()

    obj.update(50)
    obj.display()

    obj.close()



# Generated at 2022-06-24 10:11:22.346715
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from .utils_telegram import TelegramIO
    tgio = TelegramIO(token='example', chat_id='example')
    tgio.write('hello')
    assert tgio.text == 'hello'
    tgio.text = 'world'
    message_id = tgio.message_id
    tgio.delete()
    assert tgio.message_id is None
    # ...

# Generated at 2022-06-24 10:11:32.622040
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from pytest import mark
    from .utils_test import TestTqdmIO

    @mark.parametrize('leave', [True, False, None])
    def test_display(leave):
        with TestTqdmIO() as io:
            t = tqdm_telegram(
                range(3), file=io, desc="hi!",
                total=3, leave=leave, dynamic_ncols=True, disable=True)
            t.display()
            t.clear()
            t.close()

        assert "hi!\n0/3 100%" in io.getvalue()
        assert "\n\n" in io.getvalue()

    test_display()

# Generated at 2022-06-24 10:11:41.117952
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    try:
        import matplotlib as plt
        plt.use('Agg')
        import matplotlib.pyplot as plt
    except ImportError:
        plt.ion()

    # Create a figure with one axes
    fig = plt.figure(0)
    
    # Plot some data 
    fig.clear()
    plt.plot([0, 100],[0, 100])


# Generated at 2022-06-24 10:11:48.755437
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    token = getenv('TQDM_TELEGRAM_TOKEN')
    assert token is not None, "No Telegram token provided"
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    assert chat_id is not None, "No Telegram chat provided"
    assert not tqdm_telegram(range(3), token=token, chat_id=chat_id,
                             desc="test_tqdm_telegram").n, \
        "tqdm_telegram failed test"


if __name__ == '__main__':
    from doctest import testmod
    testmod(verbose=True)

# Generated at 2022-06-24 10:11:54.716325
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    from .utils_test import sleep, _range
    for i in _range(tqdm(sleep(0.1), token='{token}', chat_id='{chat_id}')):
        pass  # noqa
    sleep(1)