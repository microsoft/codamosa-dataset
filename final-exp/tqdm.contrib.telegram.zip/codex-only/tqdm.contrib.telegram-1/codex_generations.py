

# Generated at 2022-06-24 10:01:46.806188
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    return TelegramIO(
        token=getenv('TQDM_TELEGRAM_TOKEN'),
        chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'))

# Generated at 2022-06-24 10:01:50.030105
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    tqdm_telegram(range(3)).close()
    tqdm_telegram(range(3), disable=True).close()


if __name__ == '__main__':
    test_tqdm_telegram_clear()

# Generated at 2022-06-24 10:01:55.682138
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from os import remove
    with tqdm(0, file=open('/tmp/tqdm_telegram.test', 'w')) as pbar:
        pbar.update(42)
        pbar.close()
        with tqdm_telegram(0, token=getenv('TQDM_TELEGRAM_TOKEN'),
                                 chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'),
                                 bar_format='{n:.3f}') as pbar:
            pbar.update(42)
            pbar.close()
    remove('/tmp/tqdm_telegram.test')

# Generated at 2022-06-24 10:01:58.995891
# Unit test for function trange
def test_trange():
    for _ in trange(10, token=getenv('TQDM_TELEGRAM_TOKEN'),
                    chat_id=getenv('TQDM_TELEGRAM_CHAT_ID')):
        pass

# Generated at 2022-06-24 10:02:05.745624
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    # Null test without bot
    tqdm(token=None, chat_id=None, disable=True).display()

    # Unit test
    try:
        from tests_tqdm import pretest
        pretest()
        t = tqdm(total=10, token='123', chat_id='0')
        t.display()
    except Exception as e:
        print("\n\nERROR: unit test failed:", str(e))
        raise
    finally:
        t.close()

# Generated at 2022-06-24 10:02:10.145175
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    # Basic usage test
    list(tqdm_telegram(range(10)))

if __name__ == '__main__':
    test_tqdm_telegram()

# Generated at 2022-06-24 10:02:10.777997
# Unit test for constructor of class tqdm_telegram

# Generated at 2022-06-24 10:02:12.576031
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(0, disable=True)
    t.close()


# Generated at 2022-06-24 10:02:14.135624
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    assert TelegramIO("Mock", "Mock").close()

# Generated at 2022-06-24 10:02:18.216028
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    # test at least one method just to have something tested in this file
    tqdm(1).display()

# Export all methods for use in tqdm/__init__.py
all_methods = list(filter(lambda s: not s.startswith('_'), dir(tqdm)))
__all__ += all_methods
globals().update({k: getattr(tqdm, k) for k in all_methods})

# Generated at 2022-06-24 10:02:24.045479
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    TelegramIO.API = 'https://api.telegram.org/bot'
    # No token
    token = ''
    chat_id = '0'
    telegram_io = TelegramIO(token, chat_id)
    expected = ''
    telegram_io.text = 'test_text'
    telegram_io.write(expected)
    assert expected == telegram_io.text, \
        'Wrong output for token: %s, chat_id: %s' % (token, chat_id)

    # No chat_id
    token = '0'
    chat_id = ''
    telegram_io = TelegramIO(token, chat_id)
    expected = ''
    telegram_io.text = 'test_text'
    telegram_io.write(expected)
    assert expected == telegram_io

# Generated at 2022-06-24 10:02:30.821348
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from os import environ
    from tqdm.contrib.telegram import TelegramIO
    from time import sleep, time
    environ['TQDM_TELEGRAM_TOKEN'] = '1234567890:ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    environ['TQDM_TELEGRAM_CHAT_ID'] = '12345678'
    tgio = TelegramIO(token=None, chat_id=None)
    time_end = time() + 1
    while time() < time_end:
        assert tgio.message_id

# Generated at 2022-06-24 10:02:33.695821
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    """Get actual tqdm_telegram display text"""
    display = tqdm_telegram(total=10, position=1, leave=False)
    r = display.display()
    assert (not r)

# Generated at 2022-06-24 10:02:39.849887
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    def tqdm_close(leave=False):
        with tqdm(total=1000, disable=True, leave=leave) as t:
            assert t.n == 0
            assert not t.leave
            t.close()
        with tqdm(total=1000, disable=False, leave=leave) as t:
            assert t.n == 0
            assert not t.leave
            t.close()

    tqdm_close(True)
    tqdm_close(False)
    tqdm_close(None)
    print('Test Passed')

# Generated at 2022-06-24 10:02:46.951332
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from os import environ
    environ['TQDM_TELEGRAM_TOKEN'] = '9'
    environ['TQDM_TELEGRAM_CHAT_ID'] = '1'
    assert(tqdm_telegram(total=100).disable is False)
    assert(tqdm_telegram(total=100).disable is False)
    assert(tqdm_telegram(total=100).disable is False)
    assert(tqdm_telegram(total=100).disable is False)
    assert(tqdm_telegram(total=100).disable is False)
    assert(tqdm_telegram(total=100).disable is False)
    assert(tqdm_telegram(total=100).disable is False)

# Generated at 2022-06-24 10:02:49.763599
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    x = TelegramIO('{token}', '{chat_id}')
    x.message_id
    x.delete()

# Generated at 2022-06-24 10:02:59.148947
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    # Create a file in a temporary directory, to be written
    # to and read from
    import tempfile
    with tempfile.NamedTemporaryFile() as f:
        # Write a message
        tqdm_telegram(["This is a test"], file=f)
        # Delete the message
        f.close()


# the following code is only executed if the module was *not* imported
if __name__ == '__main__':
    for i in tqdm_telegram(range(50), token="YOUR_TELEGRAM_TOKEN_HERE",
                           chat_id="YOUR_TELEGRAM_CHAT_ID_HERE"):
        # do something
        import time
        time.sleep(0.1)

# Generated at 2022-06-24 10:03:09.882216
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from contextlib import contextmanager

    @contextmanager
    def mock_get_write_and_close(mocked_close):
        @contextmanager
        def mock_get_write(mocked_close):
            @contextmanager
            def mock_write_value(mocked_close):
                yield mocked_close
            with mock_write_value(mocked_close) as write_value:
                yield write_value
        with mock_get_write(mocked_close) as mocked_write:
            with mock_get_write(mocked_close) as mocked_close:
                yield (mocked_write, mocked_close)

    assert hasattr(tqdm_telegram, "close")


# Generated at 2022-06-24 10:03:14.424008
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    with tqdm(total=4) as pbar:
        for i in _range(4):
            pbar.update()
    del pbar
    import time
    with tqdm(total=4, mininterval=2) as pbar:
        for i in _range(4):
            time.sleep(1)
            pbar.update()

# Generated at 2022-06-24 10:03:19.457087
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    # create a message
    tgio = TelegramIO('123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11', '123456789')
    message_id = tgio.message_id
    # delete the message
    tgio.delete()


if __name__ == '__main__':
    from .__main__ import _test_TelegramIO_delete
    _test_TelegramIO_delete()

# Generated at 2022-06-24 10:03:25.530504
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    """
    Checks if deleting message before first use works as expected.
    """
    with tqdm_telegram(total=1, leave=True) as pbar:
        pbar.close()


if __name__ == '__main__':
    from time import sleep

    with tqdm(total=10, token=getenv('TQDM_TELEGRAM_TOKEN'),
              chat_id=getenv('TQDM_TELEGRAM_CHAT_ID')) as pbar:
        for _ in pbar:
            sleep(0.2)

# Generated at 2022-06-24 10:03:31.628735
# Unit test for function trange
def test_trange():
    # Remove `file` before running the unit test
    if 'file' in globals():
        del file
    try:
        import io as StringIO
    except ImportError:
        from io import StringIO
    with StringIO() as f:
        with tqdm(f, ascii=True) as pbar:
            for i in trange(10):
                pbar.update()
            pbar.write("finished")
            assert (f.getvalue().replace(u'\x1b[A', u'\n')
                    == '100%|##########| 10/10 [00:00<?, ?it/s]finished\n')

# Generated at 2022-06-24 10:03:35.228479
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tgio = TelegramIO("token", "chat_id")
    tgio.message_id
    tgio.write("Hello World!")
    tgio.close()

# Generated at 2022-06-24 10:03:46.053633
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():

    def _test_msg(**x):
        x['file'] = TelegramIO('', '')
        tqdm_telegram.display(**x)

    # Test the case ncols changed
    x = dict(ncols=80)
    _test_msg(**x)
    _test_msg(**x)
    _test_msg(ncols=79, **x)
    _test_msg(ncols=79, **x)
    _test_msg(ncols=79, **x)

    # Test the case unit changed
    x = dict(unit='it')
    _test_msg(**x)
    _test_msg(**x)
    _test_msg(unit='it/s', **x)
    _test_msg(unit='it/s', **x)
   

# Generated at 2022-06-24 10:03:49.198402
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    t = tqdm(
        ['a', 'b', 'c', 'd'],
        token='6a8c6209e9aaceaa7430812021b7c8e8',
        chat_id='-1001129557982',
        leave=True,
        desc='test_tqdm_telegram_display')
    for i in t:
        pass
    t.close()

# Generated at 2022-06-24 10:03:50.753953
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    telegram_io = TelegramIO(token="", chat_id="")
    telegram_io.write("test")

# Generated at 2022-06-24 10:03:56.419873
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    io = io = TelegramIO('1', '1')
    with io:
        pbar = tqdm(range(10), disable=False, desc='tqdm_telegram_clear',
                    position=0)
        pbar.update(1)
        pbar.clear()
        pbar.close()

# Generated at 2022-06-24 10:04:05.937658
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from unittest import TestCase, mock
    from os import getenv

    token = getenv("TQDM_TELEGRAM_TOKEN")
    chat_id = getenv("TQDM_TELEGRAM_CHAT_ID")
    if not token or not chat_id:
        raise ValueError("Please provide a valid TQDM_TELEGRAM_TOKEN and "
                         "TQDM_TELEGRAM_CHAT_ID to test TelegramIO.write")
    print("Testing TelegramIO.write with token %s and chat_id %s..." % (
        token, chat_id))

    class TelegramIOTester(TestCase):
        def setUp(self):
            self.tgio = TelegramIO(token, chat_id)

        def tearDown(self):
            self.tgio.delete()


# Generated at 2022-06-24 10:04:07.082301
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    TelegramIO('token_test', 'chat_id_test')

# Generated at 2022-06-24 10:04:14.249659
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm(iterable=[])
    t.close()
    t.pos = t.total + 1
    t.close()
    t.disable = True
    t.close()



# Generated at 2022-06-24 10:04:20.994550
# Unit test for function trange
def test_trange():

    t = trange(10, token='377863852:AAE6u8-YrI1rqx5C5D5JtKWo_tJM7R-0LOQ', chat_id='-10000000')
    assert isinstance(t, tqdm)
    list(t)

if __name__ == "__main__":
    r"""
    CommandLine:
        python -um tqdm.contrib.telegram
    """
    test_trange()

# Generated at 2022-06-24 10:04:30.612001
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    if __name__ == "__main__":
        from tqdm.auto import tqdm
        from time import sleep

        try:
            from python_telegram_bot import Bot
        except ImportError:
            raise RuntimeError("This test requires `python-telegram-bot`.")

        token = "99999:XXXXXXXXXXXXXXXXXXXXXXXXX"
        chat_id = "-999999999"
        bot = Bot(token=token, base_url="https://api.telegram.org/bot")
        bot.send_message(chat_id=chat_id, text="/start")

        # test 1
        t = tqdm(token=token, chat_id=chat_id, total=10)
        for i in t:
            t.set_description("Test 1")
            sleep(.1)
        # test 2

# Generated at 2022-06-24 10:04:40.743866
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from io import StringIO
    import sys

    class TestTelegramIO(StringIO, TelegramIO):
        """
        Test class Telegram, in particular method write.
        """
        def __init__(self, token, chat_id):
            """
            Creates a new message in the given `chat_id`.
            """
            super(TestTelegramIO, self).__init__()
            TelegramIO.__init__(self, token, chat_id)

        def write(self, s):
            """
            Writes `s` to `self`,
            and replaces internal `message_id`'s text with `s`.
            """
            super(TestTelegramIO, self).write(s)
            TelegramIO.write(self, s)

        def delete(self):
            """Deletes internal `message_id`."""


# Generated at 2022-06-24 10:04:49.611242
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import time

# Generated at 2022-06-24 10:04:54.423168
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    t = tqdm_telegram(["a", "b"], token='123456', chat_id='123456', mininterval=0.01)
    t.display()

    t = tqdm_telegram(["a", "b"], token='123456', chat_id='123456', mininterval=0.01)
    t.display()
    t.total = 2
    t.display()


# Generated at 2022-06-24 10:05:02.327977
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from io import StringIO
    with StringIO() as f:
        with tqdm_telegram(unit='B', unit_scale=True,
                           miniters=1, mininterval=0.,
                           file=f, leave=False) as pbar:
            pbar.update(10)  # 1
            pbar.clear()
            pbar.update(5)  # 1+5 => 6
            pbar.clear()
            pbar.update(10)  # 6+10 => 16
            pbar.clear()
            pbar.update(5)  # 16+5 => 21
            pbar.clear()
            pbar.update(10)  # 21+10 => 31
            pbar.clear()
            pbar.update(5)  # 31+5 => 36



# Generated at 2022-06-24 10:05:04.187543
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    TelegramIO('token', 'chat_id')


# Generated at 2022-06-24 10:05:07.321738
# Unit test for function trange
def test_trange():
    from time import sleep
    with trange(10, token='{token}', chat_id='{chat_id}') as t:  # pragma: no cover
        for i in t:
            sleep(0.01)



# Generated at 2022-06-24 10:05:11.023959
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    TelegramIO('380784749:AAEJWpPc-Lb0YpJUc0XjVPD2E6lWWUf0G0w',
               '-1001069142386').write('\r')

# Generated at 2022-06-24 10:05:15.836752
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    test_instance = tqdm_telegram(100, token='1234', chat_id='5678')
    test_instance.display()


# Generated at 2022-06-24 10:05:26.194978
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    # coverage: ignore
    from os import getenv
    from re import match
    from time import sleep
    token = getenv("TQDM_TELEGRAM_TOKEN")
    chat_id = getenv("TQDM_TELEGRAM_CHAT_ID")
    if token and chat_id:
        with tqdm(total=10, file=TelegramIO(token, chat_id)) as pbar:
            for char in pbar:
                pass
            assert match(r"^Getting Started", pbar.format_dict['postfix'])
            sleep(0.1)  # wait for async posting
            assert match(r"^Done", pbar.format_dict['postfix'])

# Generated at 2022-06-24 10:05:35.941163
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    """Test `tqdm.contrib.telegram.tqdm.clear`.

    Method clear() of class tqdm_telegram is patched in order
    to allow testing the call of method `write` (it is assumed
    that if `write` is called then `clear` is also called).

    """
    for clear_on_interrupt in [True, False]:
        # test 1
        t = tqdm_telegram(total=10, clear_on_interrupt=clear_on_interrupt)
        t.update(5)
        t.close()
        assert t.n == t.total == 10
        assert t.tgio.text == '10/10'
        # test 2
        t = tqdm_telegram(total=10, clear_on_interrupt=clear_on_interrupt)
       

# Generated at 2022-06-24 10:05:37.856403
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .tests_tqdm import pretest_posttest, TestTqdmIO
    pretest_posttest(tqdm_telegram, TestTqdmIO)

# Generated at 2022-06-24 10:05:39.734816
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    TelegramIO('123456789:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
               '-123456789').message_id

# Generated at 2022-06-24 10:05:46.195977
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    try:
        for i in tqdm_telegram(range(10), token='{token}', chat_id='{chat_id}'):
            pass
    except requests.exceptions.ConnectionError:
        pass
    else:
        raise Exception("test_tqdm_telegram_close failed")

# Generated at 2022-06-24 10:05:48.854848
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    with tqdm_telegram(total=4, disable=True) as pbar:
        pbar.close()
        pbar.close()
        pbar.close()
        pbar.close()
        assert pbar.disable

# Generated at 2022-06-24 10:05:49.822331
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    pass

# Generated at 2022-06-24 10:05:53.214627
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    a = TelegramIO("token", "chat_id")
    assert(a.message_id is not None)
    assert(a.message_id != 0)
    a.session.close()

# Generated at 2022-06-24 10:06:01.922836
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    """
    This unit test can be run by executing `python -m tqdm._tqdm`.

    NB: If this is not run as a module, you need to add the following lines
        to the head of the file:
        >>> import sys, os
        >>> sys.path.insert(0, os.getcwd())
    If you get:
        >>> AttributeError: module 'tqdm' has no attribute '_tqdm'
    then remove the `_` from ``_tqdm.py`` and try again.
    """
    import sys
    import os
    if not os.environ.get('TQDM_TELEGRAM_TOKEN') and not sys.argv[1:]:
        sys.argv.append('skip')

    from .utils_telegram import token, chat_id

    import un

# Generated at 2022-06-24 10:06:10.234909
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from tqdm.auto import tqdm
    from os import environ
    from time import sleep
    from requests import get
    from json import loads
    from signal import signal, SIGINT, default_int_handler
    signal(SIGINT, default_int_handler)

    # get test token
    TOKEN = environ.get('TQDM_TELEGRAM_TOKEN')
    CHAT_ID = environ.get('TQDM_TELEGRAM_CHAT_ID')

    if TOKEN is not None and CHAT_ID is not None:
        print("test `TelegramIO` write method")
        print("press Ctrl-C (KeyboardInterrupt) to break " +
              "(or wait ~20 seconds)")
        # test TelegramIO

# Generated at 2022-06-24 10:06:14.333087
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    from tqdm import trange
    from os import environ
    environ['TQDM_TELEGRAM_TOKEN'] = ''
    environ['TQDM_TELEGRAM_CHAT_ID'] = ''
    for _ in trange(1):
        pass
    TelegramIO(token=None, chat_id=None)

# Generated at 2022-06-24 10:06:18.064853
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    with tqdm_telegram(token='xxx', chat_id='xxx') as tb:
        tb.set_description('my progress')
        for i in range(100):
            # Do stuff
            pass


if __name__ == '__main__':
    test_tqdm_telegram()

# Generated at 2022-06-24 10:06:20.683245
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    # pylint: disable=unreachable
    tio = TelegramIO('token', 'chat_id')  # noqa: F841
    # tio.write('sample')

# Generated at 2022-06-24 10:06:24.699808
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    for leave in [True, False]:
        for pos in range(3):
            t = tqdm_telegram(total=3, leave=leave, pos=pos)
            assert t.leave == leave
            assert t.pos == pos
            t.close()

# Test the methods of class tqdm_telegram

# Generated at 2022-06-24 10:06:32.189939
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import re
    tqdm_telegram(disable=True)
    t = tqdm_telegram(disable=False)
    t.clear()
    t.close()

    t = tqdm_telegram(disable=False)
    t.write("")
    t.close()

    t = tqdm_telegram(disable=False)
    t.write("foo")
    t.close()

    t = tqdm_telegram(disable=False)
    t.write("bar")
    t.close()

if __name__ == '__main__':
    test_tqdm_telegram_clear()

# Generated at 2022-06-24 10:06:38.523586
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import sys
    class fake_session(object):
        def __init__(self):
            self.res = {"result": {"message_id": 123},
                        "ok": True,
                        "error_code": 0}
            self.post_arguments = []

        def post(self, *args, **kwargs):
            self.post_arguments.append((args, kwargs))
            return self.res

    fake_session = fake_session()
    my_token = "my_token"
    my_id = "my_id"
    f = TelegramIO(token=my_token, chat_id=my_id)
    f.session = fake_session
    assert(f.message_id == 123)

# Generated at 2022-06-24 10:06:40.838865
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    with ttgrange(1) as t:
        pass
    if t.tgio.text != "":
        raise AssertionError()

# Generated at 2022-06-24 10:06:47.853328
# Unit test for constructor of class TelegramIO

# Generated at 2022-06-24 10:06:52.479459
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from .utils_test import TestIO
    from tqdm.utils import _term_move_up
    from time import sleep

    with TestIO():
        for n in tqdm_telegram(range(10),
                               bar_format='{postfix[0]} {postfix[1]} |{bar}|',
                               token='the_token',
                               chat_id='the_chat_id'):
            sleep(1)
            tqdm_telegram.write('%s\n' % (n, ))
            tqdm_telegram.write(
                '\r' * 5 + _term_move_up() + _term_move_up())
            tqdm_telegram.write(
                '%s\n' % (n, ))

# Generated at 2022-06-24 10:06:53.746941
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    tqdm_telegram()


# Custom Examples

# Generated at 2022-06-24 10:06:57.341090
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    for leave in [True, False, None]:
        for pos in [0, 0.5, 1]:
            t = tqdm(leave=leave, pos=pos)
            t.disable = False
            t.close()

# Generated at 2022-06-24 10:07:02.385069
# Unit test for function trange
def test_trange():
    r = trange(10, token='{token}', chat_id='{chat_id}')
    r.__next__()
    r.close()
    # tqdm(r)
    # trange(10, bar_format='{l_bar}{bar:10u}{r_bar}',
    #        token='{token}', chat_id='{chat_id}')

# Generated at 2022-06-24 10:07:10.569276
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    class MockRequests:
        def post(s, url, data):
            if 'sendMessage' in url:
                return MockResponse(ok=True, data={'result': {'message_id': 123}})
            if 'deleteMessage' in url:
                assert 123 == data['message_id']
                return MockResponse(ok=True)
            return MockResponse(ok=False)
    class MockResponse:
        def __init__(self, ok, data={}):
            self.ok = ok
            self.json = lambda: data
    with MockTelegramIO(MockRequests) as tgio:
        tgio.delete()

# Generated at 2022-06-24 10:07:13.003236
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():

    pass

if __name__ == '__main__':
    test_TelegramIO_delete()

# Generated at 2022-06-24 10:07:21.052660
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    io = TelegramIO('telegram_token', 'chat_id')
    io.write("test1")
    print("test2")
    io.write("test3")
    print("test4")
    import time; time.sleep(0.1)
    io.write("test5")
    print("test6")
    import time; time.sleep(0.1)
    io.delete()
    io.delete()
    io.write("test7")
    print("test8")
    io.close()
    io.close()
    io.write("test9")
    print("test10")
    io.close()
    io.close()

# Generated at 2022-06-24 10:07:28.919701
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    try:
        from requests.packages.urllib3.exceptions import InsecureRequestWarning
        import requests
    except ImportError:
        return

    tg = TelegramIO('', '')
    tg.session.post = lambda *a, **kw: 1 / 0  # Exception Error
    tg.delete()
    tg.session.post = lambda *a, **kw: requests.Response()
    tg.delete()
    requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
    tg.delete()

# Generated at 2022-06-24 10:07:36.461716
# Unit test for function trange
def test_trange():
    """Test trange function"""
    import sys
    if sys.version_info[:2] < (2, 7):
        return  # Tested on python 2.7+ (and 3.2+)

    import os
    test_token = os.getenv('TQDM_TELEGRAM_TOKEN')
    if test_token is None:
        raise RuntimeError(
            "Please set a TQDM_TELEGRAM_TOKEN environment variable to run "
            "the tests (eg: export TQDM_TELEGRAM_TOKEN=1234567890:MyToken123456)")
    test_chat_id = os.getenv('TQDM_TELEGRAM_CHAT_ID')

# Generated at 2022-06-24 10:07:47.838111
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from requests.exceptions import ConnectionError
    import tqdm.contrib
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if token is None or chat_id is None:
        print('Test tqdm_telegram.close: Environment variable TQDM_TELEGRAM_TOKEN or TQDM_TELEGRAM_CHAT_ID is not defined, skipping test...')
    else:
        tqdm_telegram(range(1), token=token, chat_id=chat_id, desc='test_tqdm_telegram_close').close()
        # invalid token should raise ConnectionError when trying to delete message

# Generated at 2022-06-24 10:07:49.971298
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    with tqdm_telegram([], disable=True) as t:
        t.tgio



# Generated at 2022-06-24 10:07:54.494709
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    with tqdm_telegram(total=10, disable=False, leave=False,
            token=getenv('TQDM_TELEGRAM_TOKEN'), chat_id=getenv('TQDM_TELEGRAM_CHAT_ID')) as t:
        t.clear()
        t.write("tqdm_telegram clear() test passed")

# Generated at 2022-06-24 10:08:01.199160
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    ti = TelegramIO("token", "chat_id")
    assert tqdm_auto.format_interval(ti.mininterval) == '0.00s'
    assert tqdm_auto.format_interval(ti.miniters) == '1000'
    assert ti.session != None
    assert ti.text != None

if __name__ == "__main__":
    test_TelegramIO()

# Generated at 2022-06-24 10:08:11.890875
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    # noinspection PyUnusedLocal
    def dummy_session_post(url, data):
        # noinspection PyUnusedLocal
        def MockResponse(json_data, status_code):
            # noinspection PyUnusedLocal
            def mock_json():
                return json_data
            # noinspection PyUnusedLocal
            def mock_status_code():
                return status_code
            return MockResponse

        if data['text'] == '`...`':
            return MockResponse({"error_code": 429}, 429)
        elif data['text'] == '`fff`':
            return MockResponse({"error_code": 429}, 429)
        else:
            return MockResponse({"error_code": 429,
                                 "ok": True,
                                 "result": {"message_id": 15}}, 200)

   

# Generated at 2022-06-24 10:08:18.910233
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    first_run = tqdm_telegram(iterable=range(1,6), token='{token}', chat_id='{chat_id}', leave=None)
    first_run.close()
    second_run = tqdm_telegram(iterable=range(1,6), token='{token}', chat_id='{chat_id}', leave=None)
    second_run.close()
    assert first_run.pos == 0 and second_run.pos == 0
    assert first_run.leave == None and second_run.leave == None

# Generated at 2022-06-24 10:08:27.299952
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    f = '{l_bar}{bar:10u}{r_bar}{postfix}'
    fd = {'bar': '1', 'postfix': '2'}
    expected_f = '{l_bar}{bar:10u}{r_bar}{postfix}'
    expected_fd = {'bar': '1', 'postfix': '2'}

    t = tqdm_telegram(total=0)

    t.bar_format = f
    t.format_dict = fd

    t.display(bar_format=None, format_dict=None)

    assert t.bar_format == expected_f
    assert t.format_dict == expected_fd



# Generated at 2022-06-24 10:08:31.774665
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    # Parameters
    token = 1234567890
    chat_id = 1234567890
    disable = 0
    # Code
    tg = tqdm_telegram(xrange(10), token=token, chat_id=chat_id, disable=disable)
    # Assert
    assert not tg.disable


# Generated at 2022-06-24 10:08:33.854793
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    TelegramIO('{token}', '{chat_id}')
    TelegramIO('{token}', '{chat_id}', session=Session())

# Generated at 2022-06-24 10:08:35.583079
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    assert TelegramIO('my_token', 'my_id').write('my_text')


# Generated at 2022-06-24 10:08:42.370272
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import json
    class MockResponse:
        def __init__(self, json_data, status_code):
            self.json_data = json_data
            self.status_code = status_code
            self.json = lambda **kwargs: self.json_data

    expected = json.loads('{"ok":true,"result":{"message_id":2,"from":{"id":159327002,"is_bot":false,"first_name":"tqdm","username":"tqdm_bot"},"chat":{"id":-1001457686076,"title":"tqdm","username":"tqdm_chat","type":"supergroup"},"date":1593270033,"text":"\u2063`tqdm_telegram`"}}')


# Generated at 2022-06-24 10:08:43.405870
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    TelegramIO("dummy_token", "dummy_chat_id")

# Generated at 2022-06-24 10:08:45.707235
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    bar = tqdm_telegram(desc='mybar', ncols=10)
    bar.display(pos=1)
    bar.display(pos=1)
    bar.clear()
    bar.close()

# Generated at 2022-06-24 10:08:59.373933
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    tg = TelegramIO('token', 'chat_id')
    assert tg.message_id is None
    assert tg.delete() is None
    assert tg.write("...") is None
    assert tg.write("") is None
    assert tg.delete() is None
    assert tg.write("a"*5) is None
    assert tg.write("a"*500) is None
    assert tg.write("b"*500) is None
    assert tg.write("c"*500) is None
    assert tg.write("d"*500) is None
    assert tg.write("e"*500) is None
    assert tg.write("f"*500) is None
    assert tg.write("g"*500) is None

# Generated at 2022-06-24 10:09:05.240657
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    # Method display exists
    assert(hasattr(tqdm_telegram, 'display'))
    # Method write exists
    assert(hasattr(TelegramIO, 'write'))
    # Method display calls write
    class DummyTelegramIO:
        def __init__(self):
            self.write_counter = 0
        def write(self, s):
            self.write_counter += 1
    dtio = DummyTelegramIO()
    tt = tqdm_telegram([], write=dtio.write)
    tt.display()
    assert(dtio.write_counter == 1)


# Generated at 2022-06-24 10:09:13.469948
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from io import StringIO

    io = StringIO()
    msg = {
        'chat_id': 0,
        'message_id': 0,
        'text': ''
    }

    tgm = TelegramIO('', 0)
    tgm.session.post = lambda url, data: 0
    try:
        tgm.write('Hello')
        assert False, "No warning"
    except Exception:
        assert True
    try:
        tgm.write('Hello')
        assert False, "No warning"
    except Exception:
        assert True

    tgm.session.post = lambda url, data: msg
    tgm.write('Hello')
    assert tgm.text == 'Hello', "Not updated text"
    assert tgm.message_id == 0, "Not updated message_id"


# Generated at 2022-06-24 10:09:21.795945
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    pass

if __name__ == '__main__':
    from doctest import testmod
    from os import environ

    environ['PYTHONHASHSEED'] = str(0)
    environ['TQDM_TELEGRAM_TOKEN'] = '571013737:AAGI1nbWZszHRvwvrVhD_2Qj6AE11Pr6eQs'
    environ['TQDM_TELEGRAM_CHAT_ID'] = '123456789'
    testmod(verbose=True)

# Generated at 2022-06-24 10:09:29.868765
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from os import devnull
    from shutil import rmtree
    from tempfile import gettempdir, mkdtemp
    from multiprocessing.pool import ThreadPool
    from time import sleep

    import requests

    with open(devnull, 'w') as devnull:
        with tqdm(total=10, file=devnull, mininterval=0) as pbar:
            pbar.n = 5
            tmpd = gettempdir()
            # tmpd = mkdtemp("tqdm_test_")
            pids = set()

            def target(i):
                sleep(0.5)

# Generated at 2022-06-24 10:09:36.288446
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    # Give the token of your Telegram bot and chat ID
    tg = TelegramIO(token="<YOUR_TOKEN>", chat_id="<YOUR_CHAT_ID>")
    tg.write("Do you receive this message?")
    tg.close()
    assert tg.message_id is not None
    assert tg.tgio.delete() is None
    assert tg.message_id is None

# Generated at 2022-06-24 10:09:42.454799
# Unit test for function trange
def test_trange():
    import time
    n = 100
    var = "10"
    lst = [1, 2, 3]
    trange(var)
    trange(lst)
    var = int(var)
    assert 8 <= ttgrange(var).sum() <= var * (var + 1)
    assert ttgrange(var).sum() == ttgrange(lst).sum()
    assert ttgrange(
        *list(ttgrange(var))).sum() == ttgrange(
            *lst).sum() == ttgrange(var * 2).sum(
                ) == ttgrange(range(var)).sum()
    for j in trange(n, total=n):
        for i in trange(n, desc="test", leave=False, total=n):
            time.sleep

# Generated at 2022-06-24 10:09:49.296660
# Unit test for function trange
def test_trange():
    """Run test on trange."""
    # init
    tgr = ttgrange(1000)
    hdr = tqdm_telegram(1000)
    # fake data
    data = _range(1000)
    # test
    for d in tgr(data):
        hdr.update()
    # closing
    tgr.close()
    hdr.close()
    time.sleep(0.1)
    # assert
    assert tgr.n == hdr.n
    assert tgr.pbar.total == hdr.pbar.total


if __name__ == "__main__":
    # run unit-test
    from .main import _test
    _test(__file__)

# Generated at 2022-06-24 10:09:56.221114
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    ttg = tqdm_telegram(iterable=[1,2,3], leave=True)
    ttg.close()
    ttg = tqdm_telegram(iterable=[1,2,3], leave=False)
    ttg.close()
    ttg = tqdm_telegram(iterable=[1,2,3], leave=None)
    ttg.close()
    ttg = tqdm_telegram(iterable=[1,2,3], leave=None)
    ttg.n = 4
    ttg.close()

# Generated at 2022-06-24 10:10:03.854194
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    import gc

    pbar = tqdm_telegram(total=10,
                         token=getenv('TQDM_TELEGRAM_TOKEN'),
                         chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'))
    for i in range(10):
        pbar.update()
    pbar.close()
    del pbar
    assert gc.collect() == 0


# Generated at 2022-06-24 10:10:14.631849
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    from os import environ
    from os.path import exists
    from requests import HTTPError
    from requests.exceptions import ConnectionError
    from tempfile import TemporaryDirectory
    from unittest import TestCase

    from .utils_test import _imap_safe
    from .utils_test import get_random_chat_id, get_random_token

    class TelegramIOTest(TestCase):
        def test_good_init(self):
            # Ensure that the token and chat_id of the test case are valid
            try:
                TelegramIO(
                    get_random_token(), get_random_chat_id()).write("init")
            except (HTTPError, ConnectionError) as e:
                warn("Test skipped: %r" % e, TqdmWarning)
                return
            # Init without raising errors

# Generated at 2022-06-24 10:10:17.600293
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    print('testing delete method of class TelegramIO')
    tg = TelegramIO('1298042638:AAHET9aTv2QW1hJ3Gs2Ki_7VxvD8nPdYkdo',
                    '919441427')
    tg.delete()


if __name__ == '__main__':
    if __doc__ is not None:  # untested
        test_TelegramIO_delete()

# Generated at 2022-06-24 10:10:20.646857
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    t = TelegramIO('token','chat_id')

# Generated at 2022-06-24 10:10:29.947242
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    """Test TelegramIO constructor."""
    from os import environ
    from subprocess import call
    for i in tqdm(_range(2), desc="test_TelegramIO()", leave=True,
                  disable=getenv("CI") is not None):
        if 'TQDM_TELEGRAM_TOKEN' in environ and 'TQDM_TELEGRAM_CHAT_ID' in environ:
            # test constructor and delete
            tgio = TelegramIO(getenv("TQDM_TELEGRAM_TOKEN"), getenv("TQDM_TELEGRAM_CHAT_ID"))
            assert tgio.message_id is not None
            tgio.delete()
        else:
            assert call(['python', '-c', 'import tqdm.contrib.telegram']) == 1

# Generated at 2022-06-24 10:10:40.001325
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    """
    Tests for method write of class TelegramIO.
    Runs only if environment variable TQDM_TELEGRAM_TOKEN is defined.
    """
    import os
    from tqdm.contrib.telegram import TelegramIO as tg
    if os.getenv('TQDM_TELEGRAM_TOKEN', None):
        t = tg('TQDM_TELEGRAM_TOKEN', 'TQDM_TELEGRAM_CHAT_ID')
        t.write('\nHello world!')
        t.delete()
        t.write('\nHello world!')
        t.delete()
        t.write('\nHello world!')
        t.delete()
        t.write('\nHello world!')
        t.delete()
        t.write('\nHello world!')


# Generated at 2022-06-24 10:10:41.816661
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    assert ttgrange(1, disable=True).close() is None

# Generated at 2022-06-24 10:10:43.006615
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    assert TelegramIO("token", "chat").delete() is None


# Generated at 2022-06-24 10:10:50.195104
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    """Unit test for TelegramIO.write"""
    import pytest
    tio = TelegramIO(token='', chat_id='')
    with pytest.raises(NotImplementedError):
        tio.write('')

# Generated at 2022-06-24 10:10:51.950801
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    """Unit test for class TelegramIO"""
    pass

# Generated at 2022-06-24 10:11:06.041741
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from requests import Session
    from requests.exceptions import ConnectionError
    try:
        Session().get('https://api.telegram.org')
    except ConnectionError:
        warn("You are offline: skipping Telegram tests")
        return
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if token is None or chat_id is None:
        warn("Telegram credentials not found: skipping Telegram tests")
        return
    try:
        tqdm_telegram([0], token=token, chat_id=chat_id,
                      bar_format='{bar}', leave=False).close()
    except Exception as e:
        warn(str(e))
        return
    import time

# Generated at 2022-06-24 10:11:11.592576
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    # delete a message
    with tqdm_telegram(disable=True) as t:
        assert t.tgio.message_id
        t.tgio.delete()
    # do not delete a non-existing message
    with tqdm_telegram(leave=True, disable=True) as t:
        assert t.tgio.message_id
        t.tgio.delete()

# Generated at 2022-06-24 10:11:16.984910
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    """
    Test the method clear for tqdm_telegram class.
    """
    import sys
    import io

    # Capture stdout during testing
    sys.stdout = io.StringIO()
    # Test clear()
    to = tqdm_telegram(['a', 'b', 'c']).clear()
    sys.stdout = sys.__stdout__
    assert to._io.closed

# Generated at 2022-06-24 10:11:20.647036
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """Test"""
    import warnings
    warnings.filterwarnings("ignore", category=TqdmWarning)
    for _ in tqdm(range(10), token='{token}', chat_id='{chat_id}'):
        pass
    for _ in tqdm(range(10), token='{token}', chat_id='{chat_id}'):
        pass



# Generated at 2022-06-24 10:11:26.517794
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from unittest import TestCase, main
    from subprocess import Popen, PIPE
    from time import sleep

    class TestTqdmTelegramClose(TestCase):
        def test_close(self):
            # Test if a global option is set properly
            global tqdm
            tqdm = tqdm_telegram(disable=True)
            with tqdm_telegram(total=100) as pbar_a:
                self.assertIs(pbar_a.tgio, None)
                self.assertTrue(pbar_a.disable)
            # Re-init the global option
            tqdm = tqdm_telegram
            # Test a new method delete from class TelegramIO

# Generated at 2022-06-24 10:11:37.484684
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from datetime import datetime
    import logging
    try:
        import pytest
    except ImportError:
        try:
            import py.test as pytest
        except ImportError:
            logging.warn("Please install pytest or py.test")
    try:
        import mock
    except ImportError:
        try:
            from unittest import mock
        except ImportError:
            logging.warn("Please install mock")
    try:
        import xdist
    except ImportError:
        logging.warn("Please install xdist")

# Generated at 2022-06-24 10:11:42.659218
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    for f in [False, None, True]:
        for p in [1, 0]:
            for l in [False, None, True]:
                # pylint: disable=cell-var-from-loop
                tqdm_auto.write(
                    'tqdm(leave=%s, position=%s, leave_position=%s) =>'
                    % (l, p, f))
                tgr = tqdm_telegram(_range(p), leave=f, position=p,
                                    leave_position=l)
                # pylint: enable=cell-var-from-loop
                assert not tgr.tgio.message_id is None, tgr.tgio.message_id
                tgr.close()
                if (p != 0 and l != False):
                    assert tgr.tgio.message_

# Generated at 2022-06-24 10:11:49.265598
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    from os import getenv
    from warnings import warn

    token, chat_id = getenv('TQDM_TELEGRAM_TOKEN'), getenv('TQDM_TELEGRAM_CHAT_ID')
    warn("Sending test messages to Telegram, please ignore them.")
    io = TelegramIO(token, chat_id)
    io.write("Test message")
    io.delete()