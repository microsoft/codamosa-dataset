

# Generated at 2022-06-24 10:01:52.709243
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    io = TelegramIO('mytoken', 'mychat_id')
    io.write('hello')

# Generated at 2022-06-24 10:01:56.731587
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    tgio = TelegramIO(None, None)
    assert tgio.message_id is None



# Generated at 2022-06-24 10:02:02.849928
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    """Tests clear() method of tqdm_telegram class."""
    from os import getenv
    assert getenv('TQDM_TELEGRAM_TOKEN')
    assert getenv('TQDM_TELEGRAM_CHAT_ID')
    for _ in tqdm([], token='TQDM_TELEGRAM_TOKEN',
                  chat_id='TQDM_TELEGRAM_CHAT_ID'):
        pass


# Generated at 2022-06-24 10:02:03.710653
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    pass



# Generated at 2022-06-24 10:02:11.248074
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    try:
        TelegramIO('', '')
        assert False, "Should have raised an exception"
    except:
        pass
    try:
        TelegramIO('foo', 'bar')
        assert False, "Should have raised an exception"
    except:
        pass

# Generated at 2022-06-24 10:02:17.041544
# Unit test for function trange
def test_trange():
    """Test function."""
    l = [0 for _ in trange(4, token=getenv('TQDM_TELEGRAM_TOKEN'),
                           chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'))]
    assert len(l) == 4
    l = [0 for _ in trange(4, token=getenv('TQDM_TELEGRAM_TOKEN'),
                           chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'),
                           disable=True)]
    assert len(l) == 4

# Generated at 2022-06-24 10:02:27.421559
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if not (token and chat_id):
        import sys
        sys.exit("Telegram token or chat id not found")

    with TelegramIO(token, chat_id) as tgio:
        tgio.write('Deleting tgio.message_id (1/3)')
        tgio.delete()
        tgio.write('Deleting tgio.message_id (2/3)')
        tgio.delete()
        tgio.write('Deleting tgio.message_id (3/3)')
        tgio.delete()


if __name__ == "__main__":
    test_TelegramIO_delete()

# Generated at 2022-06-24 10:02:29.434515
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tgio = TelegramIO('token', 'chat_id')
    assert tgio.write("text") is None

# Generated at 2022-06-24 10:02:35.299616
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    """Test tqdm"""
    from os import devnull
    from sys import stdout

    x = tqdm(
        ["a", "b", "c", "d"], token='{token}', chat_id='{chat_id}',
        file=open(devnull, 'w'))
    with open(devnull, 'w') as f:
        try:
            x.update(4)
        except TypeError:
            return True
        else:
            return False



# Generated at 2022-06-24 10:02:42.504886
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .tests_tqdm import pretest_posttest_monkeypatch, closing, \
        UnicodeIO, _range


# Generated at 2022-06-24 10:02:54.215880
# Unit test for method close of class tqdm_telegram

# Generated at 2022-06-24 10:02:57.297218
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    t = tqdm_telegram(range(10), token='123456:ABCDEFG', chat_id='123456789')
    t.clear()
    t.close()

# Generated at 2022-06-24 10:03:04.662719
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    """Unit test for constructor of class TelegramIO"""
    print('Testing TelegramIO constructor...')
    token = '123'
    chat_id = '234'
    assert TelegramIO(token, chat_id).token == token
    assert TelegramIO(token, chat_id).chat_id == chat_id
    TelegramIO(token, chat_id).close()
    print('-> ok')


# Generated at 2022-06-24 10:03:06.834605
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    assert(tqdm_telegram.display(tqdm_telegram(),"test")) is None


# Generated at 2022-06-24 10:03:13.298942
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .tests_tqdm import pretest_posttest, new_tqdm

    t = new_tqdm(token='', chat_id='')
    pretest_posttest(t)

    with new_tqdm(disable=True) as t:
        pretest_posttest(t)

    t = new_tqdm(token='', chat_id='')
    with t:
        pretest_posttest(t)
    t.close()

# Generated at 2022-06-24 10:03:22.385256
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from nose.tools import assert_equal, assert_true
    from sys import version_info
    from time import sleep

    class MockSession(object):
        def __init__(self):
            self.post_count = 0
            self.res = {"ok": True, "result": {"message_id": "123"}}

        def post(self, *args, **kwargs):
            sleep(0.2)
            self.post_count += 1
            return self

        def json(self):
            return self.res

    session = MockSession()
    tgio = TelegramIO('token', 'chat_id', session)
    tgio.text = 'text'

    # test the creation of message_id
    assert_equal(tgio.message_id, 123)
    assert_equal(session.post_count, 1)

# Generated at 2022-06-24 10:03:30.606703
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """
    Test method close
    """
    class Testtqdm_telegram(tqdm_telegram):
        def __init__(self, *args, **kwargs):
            self.leave = kwargs.pop('leave', False)
            super(Testtqdm_telegram, self).__init__(*args, **kwargs)

    class TesttelegramIO(TelegramIO):
        def delete(self):
            self.session.post(self.API + '%s/deleteMessage' % self.token,
                              data={'chat_id': self.chat_id,
                                    'message_id': self.message_id})

    test_pos = [0, 1]
    test_leave = [True, False]
    for pos, leave in zip(test_pos, test_leave):
        t

# Generated at 2022-06-24 10:03:38.212401
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    import sys
    import io

    # Placeholder for stdout
    class StreamStdout(io.TextIOBase):
        def write(self, s):
            pass

    sys.stdout = io.TextIOWrapper(StreamStdout())

    # tqdm_telegram
    with tqdm_telegram(10, leave=True) as t:
        for i in t:
            pass

    # The attribute _instances of tqdm_telegram should be empty
    assert not tqdm_telegram._instances

# Generated at 2022-06-24 10:03:40.596948
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    assert TelegramIO("token", "chat_id")

# Generated at 2022-06-24 10:03:48.963745
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    # pylint: disable=no-member
    import sys
    import time
    import unittest
    from tqdm import __version__ as tqdm_version
    from tqdm.contrib.telegram import tqdm, ttgrange

    class Tests(unittest.TestCase):
        """Tests for `tqdm_telegram.tqdm`.
        Note:
            Unfortunately this test is not reliable.
        """
        def test_tqdm(self):
            """Just make sure it doesn't error"""
            for _ in tqdm(ttgrange(3)):
                time.sleep(0.01)

    unit_test_suite = unittest.TestSuite()
    unit_test_suite.addTest(unittest.makeSuite(Tests))

    runner

# Generated at 2022-06-24 10:03:50.865976
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    with tqdm_telegram(total=10, token="", chat_id="") as t:
        t.clear()



# Generated at 2022-06-24 10:04:01.878008
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    for error in [None, '', '"ok"', '{"error_code": 400, "description": "Bad Request: message to delete not found"}']:
        tg = TelegramIO(None, None)
        tg.write = lambda s: None
        tg._message_id = 0
        tg.session.post = lambda api, data: error
        tg.delete()


if __name__ == '__main__':
    import sys
    import time

    for i in ttgrange(10, desc='Example', token=sys.argv[1], chat_id=sys.argv[2]):
        time.sleep(0.1)
        if i > 4:
            tqdm.write("Writing the standard output")

# Generated at 2022-06-24 10:04:10.224889
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    """Unit test for constructor of class tqdm_telegram"""
    # Test with ipython
    try:
        ip = get_ipython()
    except NameError:
        ip = None

    if ip is not None:
        ip.run_line_magic('load_ext', 'pycodestyle')
        ip.run_line_magic('pycodestyle', __file__)
        ip.run_line_magic('flake8', __file__)
        ip.run_line_magic('load_ext', 'pylint')
        ip.run_line_magic('pylint', __file__)
    else:
        warn("Ipython not loaded!", TqdmWarning)

if __name__ == '__main__':
    test_tqdm_telegram()

# Generated at 2022-06-24 10:04:12.426870
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    for i in tqdm_telegram("Hello", token='{token}',
                           chat_id='{chat_id}'):
        tqdm_auto.sleep(0.01)

# Generated at 2022-06-24 10:04:23.091826
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    # Case when leave is True
    try:
        t = tqdm_telegram(xrange(10), position=0, disable=True, leave=True)
        t.close()
    except Exception as e:
        print("Error occurred when leave is True: ", e)

    # Case when leave is False and position is 0
    try:
        t = tqdm_telegram(xrange(10), position=0, disable=True, leave=False)
        t.close()
    except Exception as e:
        print("Error occurred when leave is False and position is 0: ", e)

    # Case when leave is False and position is not 0

# Generated at 2022-06-24 10:04:29.095750
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    test_token = '833238041:AAEoPDGd_W8_WrH1taUi26w4Y4Y4W1Zjp2Q'
    test_chat_id = '781116'
    tqdm_telegram._instances.clear()
    tqdm_telegram(range(5), token=test_token, chat_id=test_chat_id)
    tqdm_telegram._instances[0].close()

# Generated at 2022-06-24 10:04:40.534732
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    with tqdm(total=1, disable=False) as pbar:
        assert pbar.disable is False
        assert pbar.leave is False
        assert pbar.pos == 0
        assert pbar.n == 1
        pbar.n = 0
        pbar.close()
        assert pbar.leave is False
        assert pbar.pos == 0
        with tqdm(total=1, disable=False, leave=True) as pbar:
            assert pbar.disable is False
            assert pbar.leave is True
            assert pbar.pos == 0
            assert pbar.n == 1
            pbar.n = 0
            pbar.close()
            assert pbar.leave is True
            assert pbar.pos == 0

# Generated at 2022-06-24 10:04:46.759675
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .tests import TestTqdm_telegram, TestTqdm_telegramNoTqdm
    from .utils_test import pretest_posttest

    with pretest_posttest():
        TestTqdm_telegram.test_display()
        TestTqdm_telegramNoTqdm.test_display()
        TestTqdm_telegram.test_nocache()
        TestTqdm_telegramNoTqdm.test_nocache()



# Generated at 2022-06-24 10:04:50.723963
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from time import time
    t0 = time()
    io = TelegramIO("123", "123")
    io.write("test")
    io.close()
    t1 = time()
    assert (t1 - t0) < 2, "write took too long: %d" % (t1 - t0)



# Generated at 2022-06-24 10:04:54.353189
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    try:
        from .utils import closing

        with closing(TelegramIO('1', '1')) as f:  # doctest: +SKIP
            f.write('test')  # doctest: +SKIP
            f.delete()  # doctest: +SKIP
    except IOError:
        pass

# Generated at 2022-06-24 10:04:57.454396
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from os import devnull
    with open(devnull, 'w') as fd:
        io = tqdm_telegram(fd=fd)
        assert io.tgio.token
        assert io.tgio.chat_id


# Generated at 2022-06-24 10:05:01.012740
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    with tqdm_telegram(total=1, unit='B', unit_scale=True) as t:
        t.clear()
        assert t.total == 1
        assert t.unit == 'B'
        assert t.unit_scale
        assert t.desc == ""

# Generated at 2022-06-24 10:05:10.794078
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from os import getenv

    io = tqdm_telegram(disable=False, token=getenv('TQDM_TELEGRAM_TOKEN'), chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'))
    assert io.disable == False
    assert io.tgio.token == getenv('TQDM_TELEGRAM_TOKEN')
    assert io.tgio.chat_id == getenv('TQDM_TELEGRAM_CHAT_ID')

    io2 = tqdm_telegram(disable=True, token=getenv('TQDM_TELEGRAM_TOKEN'), chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'))
    assert io2.disable == True

# Generated at 2022-06-24 10:05:22.080328
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    """Unit tests for TelegramIO.delete method."""
    from random import randint
    try:
        tgio = TelegramIO('123:abc', '-123456789')
    except Exception:
        tqdm_auto.write(
            "Failed import: TelegramIO.delete will be tested only partially.")
        return
    from time import sleep

# Generated at 2022-06-24 10:05:25.418937
# Unit test for function trange
def test_trange():
    with trange(0, 1, token='{token}', chat_id='{chat_id}') as t:
        for i in range(2):
            t.update()

# Generated at 2022-06-24 10:05:35.615544
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from io import StringIO
    from os import environ
    from .utils_test import test_kwargs_time_format

    environ['TQDM_TELEGRAM_TOKEN'] = 'token'
    environ['TQDM_TELEGRAM_CHAT_ID'] = 'chat_id'

    kwargs = {}
    for i in test_kwargs_time_format:
        kwargs[i] = getattr(tqdm_telegram, i)

    f = StringIO()

    with tqdm_telegram(disable=True, file=f, **kwargs) as pbar:
        pbar.display(pos=pbar.total)

    f.seek(0)
    assert '' == f.read().rstrip()

    f = StringIO()

# Generated at 2022-06-24 10:05:44.530930
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    try:
        import pytest
    except ImportError:
        return None  # skip test

    def _test_close(leave, pos, expected_leave, expected_pos):
        t = tqdm_telegram(total=10)
        t.leave = leave
        t.pos = pos
        t.close()
        assert t.leave == expected_leave
        assert t.pos == expected_pos

    tests = [
        (None, 0, True, 0),
        (None, 10, True, 10),
        (False, 0, False, 0),
        (False, 10, False, 10),
        (True, 0, True, 0),
        (True, 10, True, 10),
    ]

# Generated at 2022-06-24 10:05:54.185856
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import time
    import random
    from tqdm import tqdm
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    assert token is not None and chat_id is not None
    TelegramIO(token, chat_id).write("start test")
    for i in tqdm(range(10), file=TelegramIO(token, chat_id),
                  disable=False, unit='KB', unit_scale=1024):
        time.sleep(random.random() * 0.1)
        assert 0 <= i <= 10
    tqdm(range(10), file=TelegramIO(token, chat_id),
         disable=False, unit='KB', unit_scale=1024).write("end test")

# Generated at 2022-06-24 10:05:59.546444
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    try:
        with tqdm(total=3, token='{token}', chat_id='{chat_id}') as pbar:
            pbar.update(1)
    except Exception as e:
        tqdm_auto.write(str(e))
        warn("Telegram API rate limit: skipping test", TqdmWarning)

# Generated at 2022-06-24 10:06:05.308568
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    try:
        for i in tqdm_telegram(
                _range(10), token='766452321:AAG5epYW5A5SO5mX9iQjyhW8--',
                chat_id='-10011999999', ncols=200, leave=True):
            pass
    except Exception as e:
        assert e.__class__.__name__ == 'KeyError'
        print(str(e))
    else:
        assert False

# Generated at 2022-06-24 10:06:06.692169
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    """Test if TelegramIO works"""
    assert TelegramIO('_token', '_chat_id').message_id is not None

# Generated at 2022-06-24 10:06:14.033777
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from time import sleep
    from os import environ
    token = "<TOKEN>"
    chat_id = "<CHAT_ID>"
    environ['TQDM_TELEGRAM_TOKEN'] = token
    environ['TQDM_TELEGRAM_CHAT_ID'] = chat_id
    assert tqdm_telegram(range(3), token=token, chat_id=chat_id).total == 3
    try:
        tqdm_telegram(range(3), token="", chat_id=chat_id)
    except KeyError:
        pass
    else:
        raise Exception("Expected KeyError!")
    try:
        tqdm_telegram(range(3), token=token, chat_id="")
    except KeyError:
        pass

# Generated at 2022-06-24 10:06:17.530284
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    with tqdm_telegram(total=1000, unit='B', unit_scale=True) as t:
        for i in ttgrange(len(t)):
            t.update(50)

if __name__ == '__main__':
    test_tqdm_telegram()

# Generated at 2022-06-24 10:06:23.922157
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    # Without Telegram API
    tg = tqdm_telegram(disable=True, leave=False)
    tg.close()
    del tg
    tg = tqdm_telegram(disable=True, leave=True)
    tg.close()
    del tg

    # With Telegram API
    tg = tqdm_telegram(total=0, leave=False)
    tg.close()
    tg.tgio.close()
    del tg
    tg = tqdm_telegram(total=0, leave=True)
    tg.close()
    tg.tgio.close()
    del tg
    tg = tqdm_telegram()
    tg.close()
    tg.tgio.close()
    del tg
    tg = t

# Generated at 2022-06-24 10:06:31.380533
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    # tqdm_telegram must close without error when leave is true
    with tqdm(total=1, leave=True) as mt:
        mt.update(1)

    # tqdm_telegram must close without error when leave is false but pos is not
    # zero
    with tqdm(total=1, leave=False) as mt:
        mt.update(1)

    # tqdm_telegram must close without error when leave is None and pos is non
    # zero
    with tqdm(total=1, leave=None) as mt:
        mt.update(1)

# Generated at 2022-06-24 10:06:42.888828
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .tests_tqdm import FakeTTY, _range

    # PATCH `tqdm.std.os.dupterm`
    FakeTTY.encoding = "UTF-8"
    try:
        from tqdm.std import os
        orig_dupterm = os.dupterm
        if hasattr(os, '_dupterm'):
            orig_dupterm = os._dupterm
        os.dupterm = lambda: FakeTTY(encoding=FakeTTY.encoding)
        from .tests_tqdm import cleanup_instance
    except ImportError:
        pass
    # END PATCH


# Generated at 2022-06-24 10:06:51.306970
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(range(15), 'bla', leave=True, disable=True)
    assert t.close() is None
    t = tqdm_telegram(range(15), 'bla', leave=False, disable=True)
    assert t.close() is None
    t = tqdm_telegram(range(15), 'bla', disable=True)
    assert t.close() is None
    t = tqdm_telegram(range(15), 'bla', leave=False, disable=False)
    assert t.close() is None

# Generated at 2022-06-24 10:07:01.312754
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    from unittest import TestCase, main
    from unittest.mock import patch
    from requests import RequestException

    class TestTelegramIO_delete(TestCase):
        @patch('requests.Session.post')
        def test_without_raise(self, mock_post):
            """Test the method delete without raise an exception"""
            session = Session()
            token = '00000000:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
            chat_id = '222222222'
            message_id = '123456789'
            res_json = {'ok': True, 'result': True}
            mock_post.return_value.json.return_value = res_json
            tg_io = TelegramIO(token, chat_id)
            tg_io._message_id = message_id

# Generated at 2022-06-24 10:07:04.247890
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    # assertEqual(expected, tqdm_telegram(iterable, token, chat_id).close())
    raise SkipTest  # TODO: implement your test here


# Generated at 2022-06-24 10:07:07.825488
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    io = TelegramIO(getenv('TQDM_TELEGRAM_TOKEN'), getenv('TQDM_TELEGRAM_CHAT_ID'))
    io.write("hello world!")
    io.delete()
    io.__del__()

# Generated at 2022-06-24 10:07:10.745089
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from .utils_test import ismain, _test_clear
    if ismain():
        _test_clear(tqdm, ttgrange, "Telegram")

# Generated at 2022-06-24 10:07:22.125997
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """
    Tests method close of class tqdm_telegram.
    """
    test_tqdm = tqdm_telegram(total=10, leave=False)
    assert test_tqdm.tgio.message_id is None
    test_tqdm.close()
    assert test_tqdm.tgio.message_id is None
    test_tqdm = tqdm_telegram(total=10, leave=True)
    assert test_tqdm.tgio.message_id is None
    test_tqdm.close()
    assert test_tqdm.tgio.message_id is None
    test_tqdm = tqdm_telegram(total=0, leave=None)
    assert test_tqdm.tgio.message_id is None
    test_tq

# Generated at 2022-06-24 10:07:28.568962
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    # Test with non-blocking (default)
    with tqdm_telegram(total=2, ascii=True, desc="non-blocking") as pbar:
        for _ in _range(2):
            pbar.update()


if __name__ == "__main__":
    from doctest import testmod
    from os import getenv
    testmod(verbose=getenv("TEST_VERBOSE", False))

# Generated at 2022-06-24 10:07:37.744098
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """Verifies that tqdm_telegram sends a delete message to Telegram when
    called.
    """

    t = tqdm_telegram(disable=True, leave=False, unit='it', total=10)
    t.close()
    assert t.tgio.message_id is None

    t = tqdm_telegram(disable=True, leave=True, unit='it', total=0)
    t.close()
    assert t.tgio.message_id is None

    t = tqdm_telegram(disable=True, leave=False, unit='it', total=0)
    t.close()
    assert t.tgio.message_id is None

    t = tqdm_telegram(disable=False, leave=False, unit='it', total=10)
    t.close()

# Generated at 2022-06-24 10:07:49.343663
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    import os
    from time import sleep

    # Telegram token
    token = getenv('TQDM_TELEGRAM_TOKEN')
    if not token:
        return

    # Telegram chat ID
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if not chat_id:
        return

    # Sending message without close()
    sleep(0.05)
    pbar = tqdm_telegram(total=100, token=token, chat_id=chat_id, leave=True)
    assert pbar.disable is False
    pbar.update(10)
    sleep(1)

    # Sending message after calling close()
    sleep(0.05)

# Generated at 2022-06-24 10:07:52.451492
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    T = TelegramIO('', '')
    assert T.write('') is None

# Generated at 2022-06-24 10:08:00.532909
# Unit test for function trange
def test_trange():
    import time
    with trange(10, token='*', chat_id='*') as t:
        for i in t:
            time.sleep(0.01)
            t.set_description("nums %i" % i)
            t.update()

if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-24 10:08:04.543668
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    io = TelegramIO('test', '123')
    io.delete()


if __name__ == '__main__':
    from .utils import _test_argv
    _test_argv()

# Generated at 2022-06-24 10:08:05.746771
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm import trange
    for i in trange(4):
        pass

# Generated at 2022-06-24 10:08:09.440667
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    try:
        TelegramIO(token=getenv('TQDM_TELEGRAM_TOKEN'),
                   chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'))
    except:
        pass
    else:
        assert True

# Generated at 2022-06-24 10:08:20.249811
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    def test_func():
        """Make sure tqdm_telegram.close() works properly"""
        tt = tqdm_telegram(range(100), total=100)
        tt.update(1)
        tt.close()
        assert tt.n == 100
        assert tt.total == 100
        assert tt.last_print_n == 100
        assert tt.tgio.message_id == tt.tgio._message_id
        tt.disable = True
        tt.close()
        assert tt.n == 100
        assert tt.total == 100
        assert tt.last_print_n == 100

    test_func()
    tt = tqdm_telegram(range(100), total=100, leave=False)
    tt.close()
    # make

# Generated at 2022-06-24 10:08:28.670766
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import sys
    from os import getenv, unsetenv
    from io import StringIO
    from tempfile import NamedTemporaryFile
    token = '1234'
    chat_id = '5678'

    with NamedTemporaryFile('w') as f:
        with tqdm_auto(range(5), disable=True, file=f) as bar:
            bar.update(1)
            bar.update(1)

        # Test terminal printing
        with tqdm_auto(range(5), token=token, chat_id=chat_id,
                       disable=False, file=sys.stdout
                       ) as bar:
            bar.update(1)
            bar.update(1)

        # Test file printing

# Generated at 2022-06-24 10:08:32.197760
# Unit test for function trange
def test_trange():
    with trange(0) as t:
        assert t.total == 0
        t.update(2)
        assert t.n == 2
        assert t.format_dict["n"] == 2
        assert t.format_dict["n_fmt"] == "2"

test_trange()

# Generated at 2022-06-24 10:08:39.970816
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    """
    Unit test for constructor of class `TelegramIO`.

    - create a bot <https://core.telegram.org/bots#6-botfather>
    - copy its `{token}`
    - add the bot to a chat and send it a message such as `/start`
    - go to <https://api.telegram.org/bot`{token}`/getUpdates> to find out
      the `{chat_id}`
    - paste the `{token}` & `{chat_id}` below

    >>> from tqdm.contrib import TelegramIO
    >>> tg = TelegramIO('{token}', '{chat_id}')
    >>> tg.write('This is a test')
    >>> tg.delete()
    """
    pass

# Generated at 2022-06-24 10:08:42.852403
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    with tqdm_telegram(total=10, token='998865789:AAG_Zre-XstK9oK0BhYTlQO1r4x-JwEbIF4',
                       chat_id='-1001380102729') as tgr:
        for i in range(10):
            tgr.update()

# Generated at 2022-06-24 10:08:50.652056
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from time import sleep

    io = TelegramIO('telegram_token', chat_id='telegram_chat_id')
    io.write('start')
    sleep(3.5)
    io.write('0')
    sleep(1)
    io.write('1')
    sleep(1)
    io.write('2')
    sleep(1)
    io.write('3')
    sleep(1)
    io.write('4')
    sleep(1)
    io.write('5')
    sleep(1)
    io.write('6')

# Generated at 2022-06-24 10:08:56.678279
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    import gc
    for i in range(10):  # Warm-up
        rdr = TelegramIO('', '')
        rdr.delete()
    try:
        for i in range(5):
            rdr = TelegramIO('', '')
            rdr.delete()
            gc.collect()
    except:
        raise AssertionError("TelegramIO.delete() didn't work consistently")

# Generated at 2022-06-24 10:09:04.665698
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    """
    Test for method display of class tqdm_telegram
    """
    from sys import version_info
    from re import match

    class Testclass:
        def __init__(self):
            self.total = None
            self.n = None
            self.desc = None

# Generated at 2022-06-24 10:09:08.132829
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    """
    Test case for class tqdm_telegram
    """
    ttg = tqdm_telegram(total=100, desc='test')
    ttg.close()



# Generated at 2022-06-24 10:09:17.492027
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    """Tests that write is changing the text of the message_id."""
    from unittest import TestCase, main
    import re

    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    class TestTelegramIO(TestCase):
        """Unit test for method write of class TelegramIO."""
        def setUp(self):
            """Setup a new tqdm_telegram."""
            self.token = getenv('TQDM_TELEGRAM_TOKEN')
            self.chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')

# Generated at 2022-06-24 10:09:21.233391
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(position=1, total=1, leave=True)
    t.close()
    t = tqdm_telegram(position=1, total=1, leave=False)
    t.close()

# Generated at 2022-06-24 10:09:24.485317
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    a = tqdm_telegram(
        total=100, mininterval=0, leave=True, file=TelegramIO('', ''))
    a.close()
    a.close()

# Generated at 2022-06-24 10:09:33.940928
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import tempfile
    import time

    tg = TelegramIO('123', '456')
    assert str(tg.write('hi')) == '<Future at 0x0>'
    assert str(tg.write('')) == '<Future at 0x0>'
    assert str(tg.write(' ')) is None
    assert str(tg.write('yy')) == '<Future at 0x0>'
    assert str(tg.write('')) == '<Future at 0x0>'
    assert str(tg.write(' ')) is None
    assert str(tg.write(None)) == '<Future at 0x0>'
    assert str(tg.write('cc')) == '<Future at 0x0>'

if __name__ == "__main__":  # pragma: no cover
    __test

# Generated at 2022-06-24 10:09:40.076355
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    """Test tqdm_telegram constructor with mock TelegramIO."""
    from six import StringIO
    from io import UnsupportedOperation
    from tqdm.auto import tqdm as tqdm_auto

    class my_tqdm(tqdm_telegram):
        _instances = tqdm_auto._instances

    class my_TelegramIO(TelegramIO):
        def __init__(self, token, chat_id):
            super(my_TelegramIO, self).__init__(token, chat_id)
            self.out = StringIO()

        def write(self, data):
            self.out.write(data)

        def delete(self): pass

        def __getattr__(self, key):
            def empty_func(*args, **kwargs): pass
            return empty_func

   

# Generated at 2022-06-24 10:09:44.876160
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import io
    import sys

    buf = io.StringIO()
    buf.encoding = 'utf-8'
    t = tqdm_telegram(range(10), file=buf, disable=True)
    t.refresh()
    assert t.format_dict['bar_format'] == '{l_bar}{bar:10u}{r_bar}'
    buf.close()



# Generated at 2022-06-24 10:09:52.371488
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import platform
    if platform.system() == 'Windows':
        return
    import re
    import requests
    from os import environ

    def get_last_message_id(chat_id):
        res = requests.get(
            'https://api.telegram.org/bot%s/getUpdates' % environ['TQDM_TELEGRAM_TOKEN'])
        res.raise_for_status()
        last_message_id = None
        for message in reversed(res.json()['result']):
            try:
                if message['message']['chat']['id'] == chat_id:
                    last_message_id = message['message']['message_id']
                    break
            except KeyError:
                # skip typing notifications
                pass
        return last_message_id


# Generated at 2022-06-24 10:09:58.476573
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import io
    import sys
    from requests.exceptions import ChunkedEncodingError

    # Make sure to delete the message in the Telegram chat at the end of the
    # test, in case the test is not successful
    token = 'token'
    chat_id = 'chat_id'
    old_out = sys.stdout
    sys.stdout = io.StringIO()

# Generated at 2022-06-24 10:10:01.404555
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    assert TelegramIO('123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11',
                      12345678).delete() == None

# Generated at 2022-06-24 10:10:11.494152
# Unit test for function trange
def test_trange():
    from os import environ
    with ttgrange(1, 1, bar_format='{l_bar}{bar}|{n_fmt}/{total_fmt}{r_bar}',
                  unit_scale=1, unit='it', leave=False,
                  token=environ.get('TQDM_TELEGRAM_TOKEN'),
                  chat_id=environ.get('TQDM_TELEGRAM_CHAT_ID')) as pbar:
        pbar.update()
    return True

# Generated at 2022-06-24 10:10:14.070594
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    """Unit tests for TelegramIO"""
    assert TelegramIO(chat_id='123', token='123')

# Generated at 2022-06-24 10:10:22.119988
# Unit test for function trange
def test_trange():
    """Tests telegram trange"""
    from .utils_test import _test_trange
    with tqdm(total=10000,
              token=getenv('TQDM_TELEGRAM_TOKEN'),
              chat_id=getenv('TQDM_TELEGRAM_CHAT_ID')) as pbar:
        _test_trange(pbar)

    # Test `position` & `leave`
    with tqdm(total=10000, position=5, leave=False,
              token=getenv('TQDM_TELEGRAM_TOKEN'),
              chat_id=getenv('TQDM_TELEGRAM_CHAT_ID')) as pbar:
        _test_trange(pbar)



# Generated at 2022-06-24 10:10:27.113845
# Unit test for function trange
def test_trange():
    from os import getenv
    token = getenv("TQDM_TELEGRAM_TOKEN", None)
    chat_id = getenv("TQDM_TELEGRAM_CHAT_ID", None)
    if not token or not chat_id:
        return

    with tqdm(trange(100), token=token, chat_id=chat_id) as t:
        for i in t:
            t.set_description("TEST %s" % i)
            t.sleep(0.01)

# Generated at 2022-06-24 10:10:34.884723
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    """Unit test for constructor of class tqdm_telegram"""
    def check_tqdm_telegram(**kwargs):
        """Verify that tqdm_telegram() is working"""
        with tqdm_telegram(**kwargs) as t:
            for _ in t:
                pass

    for tepar in (
        dict(),
        dict(token="123"),
        dict(chat_id="123"),
        dict(token="123", chat_id="123"),
    ):
        check_tqdm_telegram(**tepar)

# Generated at 2022-06-24 10:10:39.017030
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    """Unit test for method delete of class TelegramIO"""

    tgm = TelegramIO(token='', chat_id='')
    assert(tgm.delete() is None)
    tgm._message_id = 1
    assert(tgm.delete() is not None)


if __name__ == "__main__":
    test_TelegramIO_delete()

# Generated at 2022-06-24 10:10:44.939802
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    t = tqdm_telegram(disable=True)
    assert t.disable
    # If we are here, it means that the bot was not running
    # (otherwise an exception is raised before)
    with tqdm_telegram(disable=False, token=t.tgio.token,
                       chat_id=t.tgio.chat_id) as t:
        t.update(3)
        assert t.total == 3

# Generated at 2022-06-24 10:10:51.465473
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import responses

    TOKEN = 'bot123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11'
    CHAT_ID = '1234567890'


# Generated at 2022-06-24 10:10:56.849754
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    io = TelegramIO('dummy', 'dummy')
    io.close()

# Generated at 2022-06-24 10:11:07.124988
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    # pytest.skip("Skip TelegramIO test")
    # Tests: monowidth characters, non-unicode characters and Unicode.
    # Probably best to only use monowidth characters (e.g. ASCII) to be safe.
    for s in ['123...', 'ABC...', '\u0394...']: # noqa
        # Need to create new TelegramIO instance everytime.
        chat_id=getenv('TQDM_TELEGRAM_CHAT_ID')
        token=getenv('TQDM_TELEGRAM_TOKEN')
        with TelegramIO(token=token, chat_id=chat_id) as tgio:
            assert tgio.message_id is not None
            assert tgio.message_id is not None
            future = tgio.write(s)
            future.result()


# Generated at 2022-06-24 10:11:12.005918
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm import _version
    tqdm._version.__version__ = '4.23.0'  # No tqdm.__version__
    tio = TelegramIO(token="", chat_id="")
    try:
        tio.write(tqdm_telegram(token="", chat_id="").display())
    except Exception:
        pass

# Generated at 2022-06-24 10:11:14.791290
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    with tqdm_telegram(10) as t:
        t.write('')
    assert t.tgio.text == ''

# Generated at 2022-06-24 10:11:21.755950
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    tgi = TelegramIO(token='', chat_id='')

    # TelegramIO.write
    tgi.write('123456789')
    tgi.close()

    # tqdm_telegram.write
    tqdm_telegram(iterable=['bar'], token='', chat_id='').write('123456789')

    # tqdm_telegram.display
    t = tqdm_telegram(iterable=['bar'], token='', chat_id='')
    t.display()

    # tqdm_telegram.clear
    tqdm_telegram(iterable=['bar'], token='', chat_id='').clear()
    t.clear()

    # tqdm_telegram.close

# Generated at 2022-06-24 10:11:33.120968
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    tqdm_bar = tqdm_telegram(total=100)
    tqdm_bar.close()
    assert tqdm_bar.tgio.write("") is None
    tqdm_bar = tqdm_telegram(total=100)
    tqdm_bar.update(99)
    tqdm_bar.close()
    tqdm_bar = tqdm_telegram(total=0)
    tqdm_bar.close()
    assert tqdm_bar.tgio.write("") is None
    tqdm_bar = tqdm_telegram(total=0)
    tqdm_bar.update()
    tqdm_bar.close()
    assert tqdm_bar.tgio.write("") is None

# Generated at 2022-06-24 10:11:36.723959
# Unit test for constructor of class TelegramIO
def test_TelegramIO():
    tio = TelegramIO('...', '...')
    tio.message_id

if __name__ == '__main__':
    from pytest import main
    main([__file__.replace('.pyc', '.py')])

# Generated at 2022-06-24 10:11:40.278154
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tg_chat_id = '-1001234567890'  # CHANGE HERE to your chat ID
    TelegramIO('<TOKEN>', tg_chat_id).delete()

# Generated at 2022-06-24 10:11:45.926565
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from os import devnull
    with open(devnull, 'w') as f:
        with tqdm(total=10, file=f, miniters=100, mininterval=0,
                  disable=None, token=('0000')) as pbar:
            assert pbar.tgio is not None



# Generated at 2022-06-24 10:11:53.773930
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import sys
    sys.argv = ["dummy", "--disable"]
    with tqdm_telegram(total=100, token='371293728:AAHoVNxJg2Dy0YNSd3qHAAV86F_69QPnBfo', chat_id='27644722') as pbar:
        for i in range(100):
            pbar.update(1)
            pbar.clear()
