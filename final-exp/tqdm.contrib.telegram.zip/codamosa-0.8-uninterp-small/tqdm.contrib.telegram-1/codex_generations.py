

# Generated at 2022-06-26 09:39:34.705015
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    var_0 = TelegramIO()
    var_1 = ''
    var_0.write(var_1)


# Generated at 2022-06-26 09:39:45.053148
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():

    with pytest.raises(TypeError):
        var_0 = tqdm_telegram(iterable=42)
    with pytest.raises(TypeError):
        var_0 = tqdm_telegram(total=42)
    with pytest.raises(TypeError):
        var_0 = tqdm_telegram(total=42, iterable=42)
    with pytest.raises(TypeError):
        var_0 = tqdm_telegram(iterable=42, bar_format='42')
    with pytest.raises(TypeError):
        var_0 = tqdm_telegram(iterable=42, bar_format='42', miniters=42)

# Generated at 2022-06-26 09:39:52.759491
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    from requests.exceptions import ConnectionError
    from .utils_worker import NotStartedWarning
    var_0 = TelegramIO()
    try:
        raise ConnectionError('Delete method test: No connection adapters were found for "{}"'.format('https://api.telegram.org/botNone/deleteMessage'))
    except ConnectionError:
        pass
    var_0 = TelegramIO(token = 'token', chat_id = 'chat_id')
    try:
        raise ConnectionError('Delete method test: No connection adapters were found for "{}"'.format('https://api.telegram.org/bottoken/deleteMessage'))
    except ConnectionError:
        pass


# Generated at 2022-06-26 09:40:01.680764
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    var_0 = TelegramIO(1,1)
    var_0.delete()

    # Check if expected call of _delete_message_text was called
    assert var_0.submit.call_count == 1

    # Check first call arguments for _delete_message_text
    assert var_0.submit.call_args_list[0][0][2]['chat_id'] == 1
    assert var_0.submit.call_args_list[0][0][2]['message_id'] == 1


# Generated at 2022-06-26 09:40:05.114079
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    # Init tqdm_telegram
    t = tqdm_telegram()
    # Call method display
    return t.display()


# Generated at 2022-06-26 09:40:10.695624
# Unit test for constructor of class tqdm_telegram

# Generated at 2022-06-26 09:40:12.651581
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    tqdm_telegram().display()


# Generated at 2022-06-26 09:40:16.009235
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    with tqdm_telegram(total=1) as var_0:
        var_0.display()

    # Unit test for method write of class tqdm_telegram

# Generated at 2022-06-26 09:40:17.015871
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    pass


# Generated at 2022-06-26 09:40:20.149519
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    var_4 = tqdm_telegram()
    var_4.display()


# Generated at 2022-06-26 09:41:43.595205
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tqdm_telegram_1 = tqdm_telegram()
    tqdm_telegram_1.tgio.delete()


# Generated at 2022-06-26 09:41:47.191386
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    telegramIO = TelegramIO(None, None)
    telegramIO.write(None)

if __name__ == '__main__':
    test_case_0()
    pass

# Generated at 2022-06-26 09:41:51.014190
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    tqdm_telegram_clear_0 = tqdm_telegram()
    tqdm_telegram_clear_0.close()
    tqdm_telegram_clear_0.clear()
    tqdm_telegram_clear_0.close()


# Generated at 2022-06-26 09:41:52.971910
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    pass


# Generated at 2022-06-26 09:42:04.658735
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    tqdm_telegram_0 = tqdm_telegram()
    tqdm_telegram_0.n = 100
    tqdm_telegram_0.total = 100
    tqdm_telegram_0.dynamic_ncols = None
    tqdm_telegram_0.ncols = 80
    tqdm_telegram_0.smoothing = 0.3
    tqdm_telegram_0.avg_time = 0.2
    tqdm_telegram_0.bar_format = None
    tqdm_telegram_0.desc = None
    tqdm_telegram_0.unit = None
    tqdm_telegram_0.unit_scale = 1
    tqdm_telegram_0.ascii = False
    tqdm_

# Generated at 2022-06-26 09:42:07.500185
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tgio = TelegramIO("token", "chat_id")
    tgio.write("")



# Generated at 2022-06-26 09:42:11.142896
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    with tqdm_telegram(range(100)) as t:
        for i in t:
            t.display(nolock=True)


# Generated at 2022-06-26 09:42:14.950231
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    tqdm_telegram_0 = tqdm_telegram()
    # Calling clear method of class tqdm_telegram with args is mocked 
    tqdm_telegram_0.clear()

# Generated at 2022-06-26 09:42:23.975539
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from os import environ
    environ['TQDM_TELEGRAM_TOKEN'] = '{token}'
    environ['TQDM_TELEGRAM_CHAT_ID'] = '{chat_id}'
    tqdm_telegram_1 = tqdm_telegram()
    try:
        TelegramIO.write()
        assert False
    except:
        assert True
    try:
        TelegramIO.write(self)
        assert False
    except:
        assert True


# Generated at 2022-06-26 09:42:29.143960
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    test_case_0()
    print("Unit test for tqdm_telegram is completed!")

if __name__ == "__main__":
    test_tqdm_telegram()