

# Generated at 2022-06-26 09:40:04.907997
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    tqdm_telegram_0 = tqdm_telegram()
    tqdm_telegram_0.close()


# Generated at 2022-06-26 09:40:07.986411
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tgio_0 = TelegramIO(token=getenv('TQDM_TELEGRAM_TOKEN'),chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'))
    tgio_0.delete()


# Generated at 2022-06-26 09:40:18.894117
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tqdm_telegram_1 = tqdm_telegram(token='', chat_id='', disable=True)
    tgio = TelegramIO(token='0', chat_id='0')
    tgio.write(s='')
    tgio.write(s='1')
    tgio.write(s='1234567890')
    tgio.session.post = lambda *args,**kwargs: True
    tqdm_telegram_1.tgio.message_id = 1
    tgio.write(s='1234567890')
    tqdm_telegram_1.tgio.message_id = None
    tgio.write(s='1234567890')
    tgio.write(s='1234567890')


# Generated at 2022-06-26 09:40:26.227329
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from random import randrange
    from tqdm import trange
    from time import sleep

    with trange(10) as t:
        for i in t:
            sleep(0.1)

            # update_to() should cause instant refresh
            t.set_description(str(i))
            t.update(randrange(5))



# Generated at 2022-06-26 09:40:28.070242
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    tqdm_telegram_0 = tqdm_telegram()


# Generated at 2022-06-26 09:40:33.564948
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    tqdm_telegram_0 = tqdm_telegram()
    tqdm_telegram_0.desc = 'tqdm_telegram_0'
    tqdm_telegram_0.display()


# Generated at 2022-06-26 09:40:36.610160
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    tqdm_telegram_0 = tqdm_telegram()
    tqdm_telegram_0.close()
    


# Generated at 2022-06-26 09:40:40.637614
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    tqdm_telegram_0 = tqdm_telegram()
    tqdm_telegram_0.display()


# Generated at 2022-06-26 09:40:48.611831
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    # Test a basic case
    class_TelegramIO = TelegramIO('{token}', '{chat_id}')
    assert isinstance(class_TelegramIO.write('s'), None)
    # Test a case where the TelegramIO instance is created without a message
    assert isinstance(class_TelegramIO.write('s'), None)
    # Test a case where the TelegramIO instance is created without a message
    class_TelegramIO = TelegramIO('{token}', '{chat_id}')
    assert isinstance(class_TelegramIO.write('s'), None)


# Generated at 2022-06-26 09:40:52.652284
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    f = tqdm_telegram()
    f.display()
    f.display(nolock=False)


# Generated at 2022-06-26 09:42:39.863273
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tio = TelegramIO('token', 'chat_id')
    assert(tio.write('a') is None)


# Generated at 2022-06-26 09:42:47.809985
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    tqdm_telegram_display = tqdm_telegram()
    tqdm_telegram_display.disable = False

# Generated at 2022-06-26 09:42:51.077536
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    tqdm_telegram_0 = tqdm_telegram()
    tqdm_telegram_0.close()



# Generated at 2022-06-26 09:42:54.569339
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tqdm_telegram_0 = tqdm_telegram()
    tqdm_telegram_0.tgio.write({1:1})


# Generated at 2022-06-26 09:42:58.970700
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    objTelegramIO_write = TelegramIO("TelegramIO_write","TelegramIO_write")
    objTelegramIO_write.write("TelegramIO_write")


# Generated at 2022-06-26 09:43:05.690608
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    tqdm_telegram_0 = tqdm_telegram()
    try:
        tqdm_telegram_0.close()
    except:
        print('Error: method close close of class tqdm_telegram was not called')
        raise

if __name__ == "__main__":
    test_case_0()
    # Test for method close of class tqdm_telegram
    test_tqdm_telegram_close()

# Generated at 2022-06-26 09:43:11.266732
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tqdm_telegram_0 = tqdm_telegram()
    tqdm_telegram_0.tgio.close()
