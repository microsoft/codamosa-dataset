

# Generated at 2022-06-26 09:40:56.206268
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    # Method was not called
    pass


# Generated at 2022-06-26 09:40:58.012338
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    var_0 = tqdm_telegram()
    assert 1


# Generated at 2022-06-26 09:40:59.188305
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    var_0 = tqdm_telegram()
    var_0.close()


# Generated at 2022-06-26 09:41:02.285030
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    var_1 = TelegramIO(1, 2)
    assert var_1 is not None


# Generated at 2022-06-26 09:41:04.770074
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    var_0 = tqdm_telegram()
    var_0.close()


# Generated at 2022-06-26 09:41:07.451849
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    var_1 = TelegramIO()
    var_1.delete()


# Generated at 2022-06-26 09:41:08.714498
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    var_0 = tqdm_telegram(30, 5)
    var_0.display()


# Generated at 2022-06-26 09:41:18.521965
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    for i in range(5):
        for var_0 in tqdm_telegram(range(5), token='833137724:AAHcL-bJWRTzVlZrRK1BVpIh9JyHSxCNVTc', chat_id='795880450', file=None, miniters=1, mininterval=0.1, mininterval=0.1, maxinterval=10.0, miniters=1):
            pass

# Generated at 2022-06-26 09:41:20.845732
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    var_2 = ttgrange()
    var_2.display()


# Generated at 2022-06-26 09:41:24.841358
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm.contrib.telegram import tqdm_telegram
    var_1 = tqdm_telegram()
    var_1.display()
