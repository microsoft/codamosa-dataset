

# Generated at 2022-06-26 09:40:59.245308
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    test_case_0()

if __name__ == "__main__":
    test_tqdm_telegram_display()

# Generated at 2022-06-26 09:41:08.597420
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from random import randint
    from time import sleep
    from tqdm.contrib.telegram import tqdm_telegram

    for i in tqdm_telegram(ttgrange(randint(2, 10))):
        sleep(0.1)


if __name__ == "__main__":
    print("Running Tests...")
    # Run unit tests
    test_case_0()
    test_tqdm_telegram_close()

# Generated at 2022-06-26 09:41:12.691085
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from tqdm.contrib.telegram import ttgrange
    for _ in ttgrange():
        pass


# Generated at 2022-06-26 09:41:16.615085
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    obj = tqdm_telegram('1', miniters=1, mininterval=0, leave=True)
    obj.close()
    obj.close()
    obj.close()


# Generated at 2022-06-26 09:41:18.916312
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    var_0 = TelegramIO(token=None, chat_id=None)
    var_0.delete()



# Generated at 2022-06-26 09:41:22.867165
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    try:
        var_0 = ttgrange(100)
    except Exception:
        return False
    var_0.clear()
    return True


# Generated at 2022-06-26 09:41:26.791611
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    var_0=ttgrange()
    try:
        var_1=var_0.close()
    except Exception as e:
        print(str(e))


# Generated at 2022-06-26 09:41:28.420530
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    var_1 = tqdm_telegram()
    var_1.close()


# Generated at 2022-06-26 09:41:33.822629
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    # The call tqdm_telegram(__)
    var_1 = tqdm_telegram()
    # The call tqdm_telegram.close(var_1)
    var_1.close()

# Generated at 2022-06-26 09:41:38.556851
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    var_0 = tqdm_telegram()
    var_0.close()
