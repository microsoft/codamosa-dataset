

# Generated at 2022-06-26 09:41:08.728866
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tqdm_telegram_0 = tqdm_telegram()
    tqdm_telegram_0.tgio.write('abc')


# Generated at 2022-06-26 09:41:13.888920
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    import unittest
    
    class tqdm_telegram_test(unittest.TestCase):
        def close(self):
            return
    return unittest.main()


# Generated at 2022-06-26 09:41:16.735966
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    tqdm_telegram_1 = tqdm_telegram()
    tqdm_telegram_1.clear()


# Generated at 2022-06-26 09:41:22.208270
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    try:
        tqdm_telegram_0 = tqdm_telegram()
        tqdm_telegram_0.total = 100
        tqdm_telegram_0.close()
    except Exception as e:
        print('Exception: ' + str(e))


# Generated at 2022-06-26 09:41:25.379339
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    tqdm_telegram_obj = tqdm_telegram()
    tqdm_telegram_obj.close()

# Generated at 2022-06-26 09:41:29.643148
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    token = 'token'
    chat_id = 'chat_id'
    tgio = TelegramIO(token, chat_id)
    s = 's'
    tgio.write(s)

# Generated at 2022-06-26 09:41:36.390386
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    tqdm_telegram_0 = tqdm_telegram()
    try:
        tqdm_telegram_0.close()
    except:
        print('An exception is raised by the method close of class tqdm_telegram')
        print(sys.exc_info()[1])

# Generated at 2022-06-26 09:41:39.385303
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    try:
        tqdm_telegram_1 = tqdm_telegram()
        tqdm_telegram_1.display()
    except:
        pass


# Generated at 2022-06-26 09:41:50.699752
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    tqdm_telegram_0 = tqdm_telegram(
        ncols= 150,
        desc= 'test_tqdm_telegram_close desc',
        total= 100,
        bar_format= '{l_bar}{bar}|<{n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}{postfix}]'
    )
    tqdm_telegram_0.close()

if __name__ == '__main__':
    test_case_0()
    test_tqdm_telegram_close()

# Generated at 2022-06-26 09:41:57.698866
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    # Set arguments
    # Create an instance of class tqdm_telegram
    tqdm_telegram_1 = tqdm_telegram()
    args = {}
    tqdm_telegram_1.display(*args.values())
