

# Generated at 2022-06-26 09:42:55.486658
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    # Tests if case 0 works correctly

    tqdm_telegram_0 = create_tqdm_telegram(leave=False)
    var_0 = tqdm_telegram_0.close()



# Generated at 2022-06-26 09:43:06.939241
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    tqdm_telegram_0 = tqdm_telegram()
    tqdm_telegram_0.close()
    tqdm_telegram_0.tgio = TelegramIO()
# Initialize tqdm_telegram_0.tgio with the first item of ["https://api.telegram.org/bot`{token}`/getUpdates"]
    tqdm_telegram_0.tgio.token = "https://api.telegram.org/bot`{token}`/getUpdates"
    tqdm_telegram_0.tgio.chat_id = "https://api.telegram.org/bot`{token}`/getUpdates"