

# Generated at 2022-06-26 09:39:24.461632
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    TelegramIO_0 = TelegramIO(token = 0, chat_id = 0)
    TelegramIO_0.delete()


# Generated at 2022-06-26 09:39:31.121868
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    TelegramIO1 = TelegramIO('123456789:abcdefghijklmnopqrstuvwxyz', '123')
    assert 0 == TelegramIO1.write(
        'x=1')
    with open('test_cases/test_TelegramIO_write.txt', 'r') as f:
        assert f.read() == TelegramIO1.telegramio_out.getvalue()

# Generated at 2022-06-26 09:39:34.837964
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    tqdm_telegram_close = tqdm_telegram()
    assert tqdm_telegram_close.close() == None



# Generated at 2022-06-26 09:39:45.091817
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from random import randint
    from sys import stderr
    from threading import Thread, Event
    from time import sleep

    def thread_function(telegramIO):
        stderr.write('Starting thread...\n')
        for i in tqdm(range(4), desc='progress thread test'):
            sleep(1)
            telegramIO.write('i={}'.format(randint(1, 100000)))
        stderr.write('Finished thread...\n')

    thread = Thread(target=thread_function, args=(TelegramIO(token='1047141417:AAE7rEagt0lztA1SG2l-h7spnZFwcNn59W8', chat_id='-1001448098176'),))
    thread.start()
    thread.join()


# Generated at 2022-06-26 09:39:48.210313
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    # No KeyboardInterrupt was raised
    try:
        TelegramIO().delete()
    except KeyboardInterrupt as e:
        print("KeyboardInterrupt was raised", e)
    else:
        print("No KeyboardInterrupt was raised")


# Generated at 2022-06-26 09:39:51.535030
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    telgram = TelegramIO()
    res = telgram.delete()
    assert res == None


# Generated at 2022-06-26 09:39:53.643816
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    # Create instance.
    tgio = TelegramIO('TOKEN', 'CHAT_ID')

    # Call method write.
    #tgio.write('_')


# Generated at 2022-06-26 09:39:55.604656
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    TelegramIO_0 = TelegramIO()
    try:
        TelegramIO_0.delete()
    except Exception:
        pass



# Generated at 2022-06-26 09:40:00.903519
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    telegram_io = TelegramIO(token, chat_id)
    telegram_io.delete()


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 09:40:05.845599
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tgio = TelegramIO('', '1')
    # tgio.message_id = 12345
    tgio.delete()

if __name__ == '__main__':
    test_case_0()
    test_TelegramIO_delete()

# Generated at 2022-06-26 09:42:16.872252
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    # Arrange
    tqdm_telegram_disp = tqdm_telegram()
    tqdm_telegram_disp.format_dict = {'bar_format': '<bar/>'}
    
    # Act
    display = tqdm_telegram_disp.format_dict
    
    # Assert
    assert display['bar_format'] == '{l_bar}{bar:10u}{r_bar}'


# Generated at 2022-06-26 09:42:21.700492
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tqdm_telegram_1 = tqdm_telegram()
    s = "Test"
    tqdm_telegram_1.tgio.write(s)


# Generated at 2022-06-26 09:42:24.030304
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    tqdm_telegram_0 = tqdm_telegram()
    tqdm_telegram_0.clear()
    tqdm_telegram_0.close()


# Generated at 2022-06-26 09:42:28.663448
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tqdm_telegram_0 = tqdm_telegram()
    return tqdm_telegram_0.tgio.delete()


# Generated at 2022-06-26 09:42:32.013807
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    tqdm_telegram_0 = tqdm_telegram()
    tqdm_telegram_0.close()



# Generated at 2022-06-26 09:42:34.042010
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    t_send = TelegramIO()
    t_send.write(1)


# Unit test to delete a message of class TelegramIO

# Generated at 2022-06-26 09:42:43.871505
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    token = "793830427:AAH0IyYtr1ZRz-R_XcXNpFCZa8WbylRKjxA"
    chat_id = "-281568169"
    tqdm_telegram_1 = tqdm_telegram(iterable=range(5), token=token, chat_id=chat_id)
    tqdm_telegram_1.update()
    tqdm_telegram_1.close()


# Generated at 2022-06-26 09:42:48.753487
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """
    Test method close of class tqdm_telegram
    """
    test_case_0()
    try:
        tqdm_telegram(disable=True).close()
    except SystemExit:
        pass


# Generated at 2022-06-26 09:42:56.172156
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    tqdm_telegram_close_0 = tqdm_telegram()
    tqdm_telegram_close_0.close()
    # In case of exception
    tqdm_telegram_close_1 = tqdm_telegram()
    tqdm_telegram_close_1.disable = True
    tqdm_telegram_close_1.close()
    tqdm_telegram_close_1.disable = False
    tqdm_telegram_close_1.close()


# Generated at 2022-06-26 09:42:59.670256
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    result = TelegramIO(token='', chat_id='').write(s='')
    assert result is None

