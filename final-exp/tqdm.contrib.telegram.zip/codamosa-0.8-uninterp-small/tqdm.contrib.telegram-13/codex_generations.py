

# Generated at 2022-06-26 09:42:31.739243
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm.auto import trange
    tqdm_telegram_0 = tqdm_telegram()
    tqdm_telegram_0.reset()
    tqdm_telegram_0.update()
    tqdm_telegram_0.display()
    pass


# Generated at 2022-06-26 09:42:34.178221
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tqdm_telegram_1 = tqdm_telegram()
    tgio = TelegramIO('TOKEN', 'CHAT_ID')
    tgio.write('to be tested')

# Generated at 2022-06-26 09:42:39.110852
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    tqdm_telegram_0 = tqdm_telegram()
    if (tqdm_telegram_0.disable):
        return
    tqdm_telegram_0.close()


# Generated at 2022-06-26 09:42:41.860827
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    for _ in test_case_0():
        test_case_0().clear()


# Generated at 2022-06-26 09:42:48.248133
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    file_token = open("./testToken.txt", "r")
    file_chat_id = open("./testChatId.txt", "r")
    token = file_token.read()
    chat_id = file_chat_id.read()
    file_token.close()
    file_chat_id.close()
    for i in tqdm_telegram(_range(100), token=token, chat_id=chat_id):
        pass
    for i in ttgrange(100, token=token, chat_id=chat_id):
        pass
    for i in ttgrange(100, mininterval=0, token=token, chat_id=chat_id):
        pass

# Generated at 2022-06-26 09:42:51.548895
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    tqdm_telegram_0 = tqdm_telegram()
    tqdm_telegram_0.close()


# Generated at 2022-06-26 09:42:55.696830
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    tqdm_telegram_1 = tqdm_telegram()
    tqdm_telegram_1.disable = False
    tqdm_telegram_1.leave = True
    tqdm_telegram_1.pos = 0
    tqdm_telegram_1.close()


# Generated at 2022-06-26 09:42:59.253038
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    tqdm_telegram_close = tqdm_telegram()
    tqdm_telegram_close.close()


# Generated at 2022-06-26 09:43:02.766023
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    tqdm_telegram_0 = tqdm_telegram()
    assert tqdm_telegram_0.clear() == None


# Generated at 2022-06-26 09:43:05.689965
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tqdm_telegram_write = TelegramIO(token='token_test_case_write', chat_id='chat_id_test_case_write')
    tqdm_telegram_write.write("test_write")
