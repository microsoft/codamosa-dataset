

# Generated at 2022-06-26 09:41:31.305871
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    tqdm_telegram_0 = tqdm_telegram(disable=False)
    tqdm_telegram_0.clear()
    tqdm_telegram_0.disable = True
    tqdm_telegram_0.clear()


# Generated at 2022-06-26 09:41:34.918341
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    tqdm_telegram_0 = tqdm_telegram()
    tqdm_telegram_0.close()


# Generated at 2022-06-26 09:41:39.347837
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    TelegramIO_object = TelegramIO("token", "chat_id")
    result = TelegramIO_object.delete()
    assert result is not None


# Generated at 2022-06-26 09:41:44.321978
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    with tqdm_telegram(total=1000) as pbar:
        pbar.write("Testing closing...")
        pbar.close()
    

# Generated at 2022-06-26 09:41:47.321014
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tqdm_telegram_0 = tqdm_telegram()
    tqdm_telegram_0.tgio.delete()


# Generated at 2022-06-26 09:41:52.439438
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import os
    import tqdm.contrib.telegram as tg

    # Instantiate TelegramIO object
    tgr = tg.TelegramIO(os.getenv('TQDM_TELEGRAM_TOKEN'),
                        os.getenv('TQDM_TELEGRAM_CHAT_ID'))

    # Get message_id
    msg_id = tgr.message_id

    # Send test message
    tgr.write("This is a test message")

    # Delete test message
    tgr.delete()

# Generated at 2022-06-26 09:41:57.264912
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    tqdm_telegram_0 = tqdm_telegram()
    with pytest.raises(Exception):
        tqdm_telegram_0.close()


# Generated at 2022-06-26 09:42:05.710937
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    tqdm_telegram_close = tqdm_telegram()
    tqdm_telegram_close.close()

if __name__ == '__main__':
     telegram_token = "911420296:AAFNDy7n4l_F2n7oYzYTZiLtT0dHvQc0L-8"
     telegram_chat_id = "849707711"

     # Code to test a few iterations of the tqdm loop

# Generated at 2022-06-26 09:42:09.117659
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    tqdm_telegram_0 = tqdm_telegram()
    tqdm_telegram_0.clear()


# Generated at 2022-06-26 09:42:12.170202
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    tqdm_telegram_ = tqdm_telegram()
    tqdm_telegram_.clear()
