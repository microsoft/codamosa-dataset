

# Generated at 2022-06-26 09:42:57.690041
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    tqdm_telegram_0 = tqdm_telegram()
    var_0 = tqdm_telegram_0.display()


# Generated at 2022-06-26 09:43:01.829909
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    tqdm_telegram_0 = tqdm_telegram()
    var_0 = tqdm_telegram_0.clear()


# Generated at 2022-06-26 09:43:03.294125
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    test_case_0()


# Generated at 2022-06-26 09:43:08.862061
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    import sys
    from io import StringIO
    from contextlib import contextmanager
    from tqdm import tqdm_telegram

    @contextmanager
    def capture_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with capture_output() as (out, err):
        test_case_0()
        output = out.getvalue().strip().split('\n')
    assert len(output) == 2

# Generated at 2022-06-26 09:43:15.463956
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    for _ in tqdm(range(100), token='674366128:AAE_Jv7I5RB5a5VlUOz6ICbJ6Uw0cPdbV6A', chat_id='-1001379598606'):
        pass
