

# Generated at 2022-06-12 14:45:54.196696
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """Note that this is not a regular unit test because it uses
    network resources.
    """
    t = tqdm_telegram(token=getenv('TQDM_TELEGRAM_TOKEN'),
                      chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'))
    try:
        t.close()
    finally:
        del(t)
    from time import sleep
    sleep(1)

# Generated at 2022-06-12 14:45:57.985338
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    assert TelegramIO(token='', chat_id='').write('Hello World')

if __doc__ is not None:
    __doc__ += TelegramIO.__doc__
    __doc__ += tqdm_telegram.__doc__
    __doc__ += ttgrange.__doc__

# Generated at 2022-06-12 14:46:01.101581
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    f = TelegramIO("", "")

    # Test of situation where size is -1 when the message is created
    f.write("20/0 [0:00:00<?, ?")
    assert("20/0 [0:00:00<?, ?" == f.text)

    # Test of situation where size is not -1 when the message is created
    f.write("10/10 [00:00<00:00, ?")
    assert("10/10 [00:00<00:00, ?" == f.text)

# Generated at 2022-06-12 14:46:05.214077
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm import trange
    for _ in trange(2, disable=True):
        with tqdm_telegram(total=10, token='1234567890:aBcDeFgHiJkLmNoPqRsTuVwXyZ', chat_id='1234567890') as t:
            for i in t:  # noqa: F841
                pass
            t.clear()

# Generated at 2022-06-12 14:46:10.329727
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    class TestTelegramIO(TelegramIO):
        def __init__(self):
            self._message_id = 1
            self.session = None
            self.text = self.__class__.__name__
            self.arg_data_for_delete = None
            self.arg_data_for_write = None

        def write(self, s):
            self.arg_data_for_write = s

        def delete(self):
            self.arg_data_for_delete = True

    inp = TestTelegramIO()
    t = tqdm_telegram(total=10, disable=False, file=inp)
    t.refresh()
    assert inp.arg_data_for_write == "   10%|█         | 1/10 [00:00<?, ?it/s]"
    t

# Generated at 2022-06-12 14:46:12.190532
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    t = TelegramIO(getenv('TQDM_TELEGRAM_TOKEN'), getenv('TQDM_TELEGRAM_CHAT_ID'))
    t.write("test_TelegramIO_delete")
    t.message_id
    t.delete()
    t.shutdown()

# Generated at 2022-06-12 14:46:16.725512
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    import time
    with tqdm_telegram(
            iterable=range(1, 10), disable=False, token=None,
            chat_id=None) as t:
        # HERE we should wait for a longer time to raise the warning.
        time.sleep(0.1)
        for i in t:
            pass

# Generated at 2022-06-12 14:46:20.165494
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    for leave in [True, False, None]:
        for pos in [0, 1]:
            t = tqdm_telegram(disable=False, leave=leave, unit='B')
            t.pos = pos
            t.close()

# Generated at 2022-06-12 14:46:29.833960
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from .utils import _minimal_emulator
    from os import getenv
    from time import sleep

    class tqdmWithMinimal(tqdm_telegram):
        def __init__(self, *args, **kwargs):
            super(tqdmWithMinimal, self).__init__(*args, **kwargs)
            self.miniters = _minimal_emulator(self)

    import warnings
    warnings.simplefilter("always", TqdmWarning)

    # Test if class tqdm_telegram.close() works without an active bot
    inp = range(10)
    t = tqdmWithMinimal(inp, disable=True)
    # check if disable is correctly set
    assert t.disable == True

    # check if close() works
    t.close()
    # check if close

# Generated at 2022-06-12 14:46:30.661169
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from .tests import tests
    tests.test_tqdm_telegram(tqdm)


# Generated at 2022-06-12 14:48:32.506777
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    """Unit test for `tqdm_telegram.display()`"""
    from os import getenv
    from time import sleep
    tqdm_auto.write = tqdm_auto.write
    tio = TelegramIO(getenv('TQDM_TELEGRAM_TOKEN'), getenv('TQDM_TELEGRAM_CHAT_ID'))
    tio.write("This is a test.")
    tio.tgio.clear()
    # print(TelegramIO.__dict__)
    for i in tqdm(range(3), token=getenv('TQDM_TELEGRAM_TOKEN'), chat_id=getenv('TQDM_TELEGRAM_CHAT_ID')):
        sleep(1)

# Generated at 2022-06-12 14:48:35.617736
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    sys_stdout = sys.stdout
    sys.stdout = io.StringIO()
    try:
        with tqdm_telegram(['1', '2'], leave=False, disable=True) as t:
            t.display()
        assert sys.stdout.getvalue() == '0/2 |##############| 100%'
    finally:
        sys.stdout = sys_stdout

# Generated at 2022-06-12 14:48:39.735234
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    """Ensure that tqdm_telegram.clear() does not lead to a duplicate message error
    from the Telegram bot (issue #599)"""
    with tqdm(range(10), token='{token}', chat_id='{chat_id}') as obj:
        obj.clear()

test_tqdm_telegram_clear()

# Generated at 2022-06-12 14:48:45.707314
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    tgio = TelegramIO(token, chat_id)
    tgio.delete()
    tgio.stop()


if __name__ == '__main__':
    from sys import argv
    if len(argv) > 1 and argv[1] == '--test':
        test_TelegramIO_delete()

# Generated at 2022-06-12 14:48:49.229378
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import os
    token = os.environ.get('TQDM_TELEGRAM_TOKEN', 'token')
    chat_id = os.environ.get('TQDM_TELEGRAM_CHAT_ID', 'chat_id')
    TelegramIO(token, chat_id).write('test')

# Generated at 2022-06-12 14:48:55.309733
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from os import environ
    from unittest import TestCase, main

    try:
        from .utils_test import setup_environment, test_environment
    except (ImportError, SyntaxError):
        # Don't raise unittest.SkipTest as Python2.6 does not recognize it
        return

    class TelegramTest(TestCase):
        @setup_environment(TQDM_TELEGRAM_TOKEN='fake',
                           TQDM_TELEGRAM_CHAT_ID='fake')
        def test_tqdm_telegram_token_environment(self):
            with self.assertRaises(ValueError):
                tqdm_telegram(token='fake', chat_id='fake')
            with self.assertRaises(ValueError):
                tqdm_telegram(token=None, chat_id='fake')

# Generated at 2022-06-12 14:48:58.981266
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """
    Test close method of class tqdm_telegram

    On Python3+, `range` is used instead of `xrange`.
    """
    tg = tqdm_telegram(xrange(10), leave=False)
    tg.close()



# Generated at 2022-06-12 14:49:04.374517
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from tqdm import tqdm
    from random import randint

    io = io = TelegramIO(token=getenv('TQDM_TELEGRAM_TOKEN'),
                         chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'))

    for i in tqdm(list(range(50))):
        io.write('%d' % randint(1, 9))

    io.write('{0}'.format('<EOF>'))
    io.close()


if __name__ == "__main__":
    test_TelegramIO_write()

# Generated at 2022-06-12 14:49:14.081599
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    # Setup
    import re

    # First test
    tg = tqdm_telegram(iterable=range(10), token='1234', chat_id='5678')
    res = tg.display()
    assert re.fullmatch(
        r"00:00:00|========10/10\|00000000? 1/?>?", tg.tgio.text)

    # Second test
    tg = tqdm_telegram(iterable=range(10), token='abcd', chat_id='efgh',
                       leave=False,
                       bar_format='{l_bar}|{bar}|{n_fmt}/{total_fmt}{percentage:3.0f}%{r_bar}>#')
    res = tg.display()

# Generated at 2022-06-12 14:49:23.772788
# Unit test for method write of class TelegramIO

# Generated at 2022-06-12 14:51:25.959776
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import requests, unittest
    from os import environ

    token = environ['TQDM_TELEGRAM_TOKEN']
    chat_id = environ['TQDM_TELEGRAM_CHAT_ID']

    def isSendMessage(update):
        return update.get('message', {}).get('text', '').endswith('...')

    # Get current updates
    endUpdate = requests.get(f'https://api.telegram.org/bot{token}/getUpdates').json()
    endUpdate = endUpdate['result'][-1]['update_id']

    # Delete messages created during previous tests

# Generated at 2022-06-12 14:51:32.244192
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    # kwargs.leave == False, closer.pos != 0
    t = tqdm(1, disable=True, leave=False)
    try:
        t.close()
    except Exception:
        assert False, 'expected: no exception'

    # kwargs.leave == False, closer.pos == 0
    t = tqdm(1, disable=True, leave=False)
    t.n = 1
    try:
        t.close()
    except Exception:
        assert False, 'expected: no exception'

    # kwargs.leave == None, closer.pos != 0
    t = tqdm(1, disable=True)
    t.n = 1
    try:
        t.close()
    except Exception:
        assert False, 'expected: no exception'

    # kwargs.leave == None

# Generated at 2022-06-12 14:51:41.279266
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """
    Unit test for method close of class tqdm_telegram,
    This test is meant to validate the telegram message is deleted
    when the tqdm instance reaches 100% and the leave parameter is set to False
    """
    import sys
    import mock
    import requests

    token = 'token'
    chat_id = 'chat_id'
    tqdm_obj = tqdm(total=100, leave=False, disable=False, token=token, chat_id=chat_id)
    tqdm_obj.update(100)
    tqdm_obj.close()
    # Check if the tqdm_obj.tgio.delete function got called with the correct arguments
    tqdm_obj.tgio.delete.assert_called_with()
    # Clear the mock to make sure it doesn't stay in memory

# Generated at 2022-06-12 14:51:48.137357
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    o = tqdm_telegram(total=200, disable=True)
    # set leave to True
    o.leave = True
    # pos = 200
    o.pos = 200
    # close
    o.close()
    # should not delete the message
    assert o.tgio.delete.mock_calls == 0
    # reset leave to False
    o.leave = False
    # close
    o.close()
    # should delete the message
    assert o.tgio.delete.mock_calls == 1
    # pos = 0
    o.pos = 0
    # close
    o.close()
    # should not delete the message
    assert o.tgio.delete.mock_calls == 1
    # leave is None, pos = 0
    o.leave = None
    # close
   

# Generated at 2022-06-12 14:51:56.406106
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import os
    import sys
    from .tests_tqdm import pretest_posttest

    # Hack to avoid starting worker thread.
    # We don't want to create any real telegram bot
    def get_tgio(self):
        return
    tqdm_telegram.get_tgio = get_tgio

    # Code under test
    with pretest_posttest(sys):
        # Case 1: no output in Jupyter notebook
        os.environ['_TELEGRAM_TEST_JUPYTER'] = ''
        with tqdm_telegram(total=None, desc="tqdm", leave=False, disable=False) \
                as t:
            t.display()
        assert t.leave is False
        assert t.disable is False

# Generated at 2022-06-12 14:52:02.437561
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from .utils_test import has_telegram
    if has_telegram():
        try:
            t = tqdm_telegram(total=10, unit="it", file=TelegramIO(
                getenv('TQDM_TELEGRAM_TOKEN'), getenv('TQDM_TELEGRAM_CHAT_ID')))
            t.close()
        except:
            raise AssertionError("method close of class tqdm_telegram failed")
    else:
        raise AssertionError("no token and chat_id")

# Generated at 2022-06-12 14:52:12.588410
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import sys
    from .utils_test import no_leave, no_sp
    with no_leave():
        with no_sp():
            t = tqdm_telegram(4, ncols=20,
                              token='583139162:AAEMLX9pvfxmVGyKSYeJsZOwYjKpJZLD0Ig',
                              chat_id='9139362',
                              unit='it', unit_scale=True, unit_divisor=1024)
            try:
                for i in t:
                    t.set_postfix(i=i)
            finally:
                t.close()
            if t.n != t.total:
                raise AssertionError()

# Generated at 2022-06-12 14:52:18.876373
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    """ test run for method display of class tqdm_telegram """
    import sys
    import time
    for i in tqdm(range(10)):
        time.sleep(0.2)
        if i == 5:
            sys.stderr.flush()
            sys.stderr.write('Aborted\n')
            tqdm.write('OK')
            break
    sys.stderr.flush()
    sys.stderr.write('Done\n')


if __name__ == '__main__':
    # simple helper test
    ttgrange(100, token='bot_token', chat_id='chat_id')

# Generated at 2022-06-12 14:52:24.409578
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    t = tqdm_telegram()
    t.total = 100
    t.display()
    assert t.tgio.text == '    9%|#         [elapsed: 00:00 left: 00:00,  0.00 iters/sec]'
    t.update(10)
    t.display()
    assert t.tgio.text == '   19%|##        [elapsed: 00:00 left: 00:00,  0.00 iters/sec]'
    t.update(10)
    t.display()
    assert t.tgio.text == '   29%|###       [elapsed: 00:00 left: 00:00,  0.00 iters/sec]'
    t.update(10)
    t.display()

# Generated at 2022-06-12 14:52:29.859780
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    with tqdm(total=100, unit='B', unit_scale=True, leave=False,
              mininterval=0, miniters=1, dynamic_ncols=True) as t:
        t.update(5)
        assert t.miniters == 1, \
            'tqdm.contrib.telegram: test_tqdm_telegram_close() failed'
        t.close()

