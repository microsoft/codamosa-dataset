

# Generated at 2022-06-12 14:45:19.557425
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    assert tqdm_telegram(range(10))

# Generated at 2022-06-12 14:45:26.511286
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    token = "123"
    chat_id = "456"
    ti = TelegramIO(token, chat_id)
    import requests_mock
    with requests_mock.Mocker() as m:
        test_text = "HelloWorld"
        m.put(ti.API + '%s/sendMessage' % ti.token, json={'result':{'message_id': 0}})
        m.put(ti.API + '%s/editMessageText' % ti.token, json={'ok': True})
        ti.write(test_text)


# Generated at 2022-06-12 14:45:32.690303
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    clear = tqdm_telegram.clear
    t = tqdm_telegram(disable=True)
    t.n = 1
    t.pos = 1
    clear(t, 0, 1)
    clear(t, 0, 1, True)
    t.n = 1
    t.pos = 1
    clear(t, 0, 1, True)

# Generated at 2022-06-12 14:45:36.719472
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    """
    Test delete method of class TelegramIO.
    This method deletes the message containing the status
    of the process.
    """
    with TelegramIO('215801178:AAHdDpyk4BH4q4q3zKpCX761Xa8W6UocP6o', '77023141') as tg:
        tg.delete()

# Generated at 2022-06-12 14:45:40.175680
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    t = TelegramIO('', '')
    t.write('write test')
    t.write('')
    t.write('write test2')
    t.close()
    t.tgio.close()


# Generated at 2022-06-12 14:45:44.220762
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import re
    from io import StringIO
    io = StringIO()
    t = tqdm_telegram(10, file=io)
    t.display()
    assert re.search(r'0% {0}\d{2}\/10\s+100%', io.getvalue())

# Generated at 2022-06-12 14:45:49.414076
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    import time
    x_len = 100
    with tqdm_telegram(total=x_len, token='1478489446:AAGd-kIjFaY1_s3s3D8AjOed1TjTc0QXRJ8', chat_id='-1001319623832') as t:
        for x in range(x_len):
            t.update(1)
            time.sleep(0.01)

# Generated at 2022-06-12 14:45:54.985989
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    t = tqdm_telegram(total=10)
    t.update(3)
    t._format_meter(0, 0, 0, 0, 0, 0, 0, 0, 0)  # test all options
    t.close()
    t = tqdm_telegram(total=10, bar_format='{l_bar}{bar}|{n_fmt}')
    t.display(1, 1, 1, 1, 1)
    t.close()

# Generated at 2022-06-12 14:46:03.613804
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    # Default args:
    with tqdm(total=10) as pbar:
        for i in _range(10):
            pbar.update()
    # Add a (useless) `iterable`:
    with tqdm(total=10, iterable=_range(10)) as pbar:
        for i in pbar:
            pbar.update()
    # With using `ascii`:
    with tqdm(total=10, ascii=True) as pbar:
        for i in _range(10):
            pbar.update()
    # With using `ascii` and `desc`:
    with tqdm(total=10, ascii=True, desc='desc') as pbar:
        for i in _range(10):
            pbar.update()
    # With

# Generated at 2022-06-12 14:46:06.409346
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(10, position=1)
    t.close()
    t = tqdm_telegram(10, position=1, leave=True)
    t.close()
    t = tqdm_telegram(10, position=1, disable=True)
    t.close()

# Generated at 2022-06-12 14:49:35.329090
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from os import environ, unsetenv
    from unittest import mock
    from requests.models import Response

    tqdm_auto.close()

    environ['TQDM_TELEGRAM_TOKEN'] = '1'

    with mock.patch('requests.Session.post', return_value=Response()) as m:
        with tqdm_telegram(disable=False, leave=False) as t:
            t.close()

    m.assert_called_once()
    assert m.call_args[0][0] == 'https://api.telegram.org/bot1/deleteMessage'
    assert m.call_args[1]['data']['message_id'] == \
        t.tgio.message_id


# Generated at 2022-06-12 14:49:43.780066
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import io
    import sys
    import unittest

    class TestTelegramIO(unittest.TestCase):
        def setUp(self):
            self.out = io.BytesIO()
            self.token = 'TEST_TOKEN'
            self.chat_id = 'TEST_CHAT_ID'
            self.original_stderr = sys.stderr
            sys.stderr = self.out

        def tearDown(self):
            sys.stderr = self.original_stderr

        def test_write_invalid_token(self):
            tg = TelegramIO('invalid_token', self.chat_id)
            tg.submit.stop()
            tg.write('test')

# Generated at 2022-06-12 14:49:45.930813
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    for leave in [False, True, None]:
        with tqdm(leave=leave, total=1) as pbar:
            pbar.update(1)
            pbar.close()

# Generated at 2022-06-12 14:49:47.261037
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    instance = tqdm_telegram(iterable=[1, 2])
    instance.total = 2
    instance.close()

# Generated at 2022-06-12 14:49:49.475854
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    TelegramIO(token=getenv('TQDM_TELEGRAM_TOKEN'), chat_id=getenv('TQDM_TELEGRAM_CHAT_ID')).write('test')

# Generated at 2022-06-12 14:49:52.258541
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm.auto import tqdm
    for line in tqdm(["a", "b", "c", "d"], desc="my tqdm loop"):
        pass
    for line in tqdm(["e", "f", "g", "h"], desc="my tqdm loop"):
        pass

if __name__ == '__main__':
  test_tqdm_telegram_display()

# Generated at 2022-06-12 14:49:53.575175
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    m = tqdm(total=10)
    m.display(**m.format_dict)
    m.close()

# Generated at 2022-06-12 14:49:56.077323
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    io = TelegramIO(token="",chat_id="")
    io.delete()

if __name__ == "__main__":
    test_TelegramIO_delete()

# Generated at 2022-06-12 14:50:04.946583
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from shutil import rmtree
    from tempfile import mkdtemp
    from .utils_test import with_setup

    test_dir = mkdtemp()


# Generated at 2022-06-12 14:50:05.958749
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    test_tqdm_auto_clear(tqdm_telegram)

# Generated at 2022-06-12 14:51:53.685087
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    io = TelegramIO('TOKEN', 'CHAT_ID')
    assert io.message_id is None
    io._message_id = 1  # directly skip message creation
    io.text = 'text'
    assert io.write('new text') is not None  # execution succeeds

# Unit tests for class tqdm_telegram

# Generated at 2022-06-12 14:52:00.204124
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    kwargs = {'disable': True} if getenv('TRAVIS') else {}
    print('TRAVIS' if getenv('TRAVIS') else 'NOT TRAVIS')
    for total in (100, None):
        for miniters in (0, 20, None):
            for smoothing in (None, .5):
                for unit_scale in (None, .1):
                    for unit in ('', 'units'):
                        kwargs['total'] = total
                        kwargs['miniters'] = miniters
                        kwargs['smoothing'] = smoothing
                        kwargs['unit_scale'] = unit_scale
                        kwargs['unit'] = unit
                        kwargs['desc'] = kwargs.get('desc', '') or 'testing...'

# Generated at 2022-06-12 14:52:04.774152
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    from time import sleep
    from sys import stderr
    from contextlib import closing
    with closing(tqdm(range(10), ncols=90, file=stderr)) as t:
        for i in t:
            sleep(.1)
            stderr.write(str(i))
    stderr.write('\n')

# Generated at 2022-06-12 14:52:07.606834
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from ._tqdm_gui import _test_closing
    _test_closing(tqdm_telegram)

# Generated at 2022-06-12 14:52:13.644631
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    """
    Test the clear method of class tqdm_telegram.
    """
    from tqdm.contrib import telegram

    with telegram.tqdm(range(10), disable=False,
                       token='1234567890:AAG90e14-0mTxUwD5p6Hmoq6B9JqyMO4zqU',
                       chat_id='-289096376') as pbar:
        for i in pbar:
            if i == 5:
                pbar.clear()
                break


if __name__ == '__main__':
    test_tqdm_telegram_clear()

# Generated at 2022-06-12 14:52:18.238239
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    try:
        import requests
        import os
        token = os.environ.get('TQDM_TELEGRAM_TOKEN')
        chat_id = os.environ.get('TQDM_TELEGRAM_CHAT_ID')
        TelegramIO(token, chat_id).delete()
    except requests.exceptions.ConnectionError:
        warn("Must be connected to the Internet to run this test", TqdmWarning)


# Generated at 2022-06-12 14:52:20.764686
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    """Unit test for method delete() of class TelegramIO"""
    tgio = TelegramIO('1','1')
    tgio.message_id = 2
    assert tgio.message_id == 2
    assert tgio.delete() == None
    assert tgio.message_id == 2

# Generated at 2022-06-12 14:52:30.084216
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    s = Session()
    t = TelegramIO(token="1089308790:AAH_W9h9Xkxnvp6rq3onTnY6pOFU6wZU6fg", chat_id="@sensorstest")
    t.message_id
    res = s.post(
        t.API + '%s/sendMessage' % t.token,
        data={'text': '`' + t.text + '`', 'chat_id': t.chat_id, 'parse_mode': 'MarkdownV2'}).json()
    t._message_id = res['result']['message_id']
    t.delete()

# Generated at 2022-06-12 14:52:38.120977
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import copy
    # from tqdm.auto import tqdm
    from tqdm._version import __version__ as tqdm_version

    io = TelegramIO(
        token=getenv('TQDM_TELEGRAM_TOKEN'),
        chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'))
    io.text = "%d | %d" % (0, 0)
    io.write(io.text)
    io.message_id
    pbar = {'desc': 'Test_Telegram_Class'}
    # Non-ASCII characters to test:
    # pbar['desc'] = 'ASCII: aÀɑΑаАåÅäÄãÃæÆǽǼçÇɔƆєЄё