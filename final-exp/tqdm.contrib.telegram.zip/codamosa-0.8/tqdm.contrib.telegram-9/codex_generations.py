

# Generated at 2022-06-12 14:45:26.512546
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from .utils_test import _test_clear
    _test_clear(tqdm_telegram)

if __name__ == '__main__':
    from sys import argv
    if len(argv) == 1:
        for i in tqdm(range(10)):
            pass
        print('\r')
        for i in tqdm(range(10)):
            pass
    elif len(argv) == 3:
        # Unit test for TelegramIO
        if argv[1] != "TelegramIO":
            raise SystemExit
        io = TelegramIO(argv[2], argv[3])
        io.write("TEST")
        io.delete()

# Generated at 2022-06-12 14:45:29.627835
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    import os
    assert os.system('python -m tqdm.contrib.test --tgrm_delete') == 0

# Generated at 2022-06-12 14:45:31.420791
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    assert tqdm_telegram(total=None, disable=True).display() is None



# Generated at 2022-06-12 14:45:33.378459
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram('')
    t.close()
    t.close()

# Generated at 2022-06-12 14:45:35.774714
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    assert TelegramIO("123456789:abcdefgHIJKLMNOPQRSTUVWXYZabcdefghi", "1234567").write("Test") is None


# Generated at 2022-06-12 14:45:41.890704
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tio = TelegramIO('123', '456')
    tio.write('a')
    assert tio.message_id is not None
    tio.write('a')
    tio.write('a')
    tio.write('a')
    tio.write('a')
    tio.write('a')
    tio.write('a')
    tio.write('a')
    tio.write('a')
    tio.write('a')
    tio.delete()



# Generated at 2022-06-12 14:45:47.193684
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    for _ in tqdm_telegram(range(2), token='Tqdm', chat_id='1234'):
        assert tqdm_telegram.format_meter.bar_fmt_kws['ncols'] == 10
        tqdm_telegram.clear()
        assert tqdm_telegram.format_meter.bar_fmt_kws['ncols'] == 80


# Generated at 2022-06-12 14:45:50.061973
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    tqdm(total=3, leave=False)
    tqdm(total=3, leave=True)
    tqdm(total=0, leave=False)
    tqdm(total=0, leave=True)

# Generated at 2022-06-12 14:45:58.649458
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    try:
        tio = TelegramIO('token', 'chat_id')
    except Exception as e:
        print(' '.join(e.args))
        return

    import time

    def test_write(s):
        time.sleep(2)
        tio.write(s)
        tio.delete()
        time.sleep(1)
    test_write('...')
    test_write('This is a test')
    test_write('This is also a test')
    test_write('This is yet another test')
    test_write('Another test. Not the last one, I promise.')
    test_write('OK, this is the last one.')
    test_write('(rate limit: 10 msgs per second)')

# Generated at 2022-06-12 14:46:03.094239
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from io import StringIO
    from tqdm.auto import tqdm
    from .utils import _test_cls_display
    _test_cls_display(tqdm, tqdm_telegram,
                      attrname='tgio',
                      expected="",
                      ncols=95,  # for travis-ci (c.f. #541)
                      )



# Generated at 2022-06-12 14:48:00.397994
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tg = TelegramIO("12345:toto", "toto")
    assert tg.token == "12345:toto"
    assert tg.chat_id == "toto"
    assert tg.message_id == None

    # Only test write, nothing else because it will trigger an internal call to
    # __post_request and that method is already tested.

    tg.write("Test")
    assert tg.message_id == None

    tg.teardown()
    assert tg._session == None
    assert tg._pool == None
    assert tg._done == None

if __name__ == "__main__":
    test_TelegramIO_write()

# Generated at 2022-06-12 14:48:08.376455
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    from time import sleep
    from multiprocessing import Value, Process
    from random import randint
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')

    # Create a message with tqdm
    with tqdm_telegram(10, token=token, chat_id=chat_id) as progressbar:
        # Check if it is the same message
        assert progressbar.tgio.message_id == progressbar.tgio.message_id
        # Update the progress
        for _ in range(10):
            sleep(randint(0, 1))
            progressbar.update()
        # Check if the message is not updated
        assert progressbar.tgio.message_id == progressbar.tgio.message_id

# Generated at 2022-06-12 14:48:09.639730
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from ..std import tqdm as _tqdm
    assert isinstance(_tqdm, tqdm_telegram)

# Generated at 2022-06-12 14:48:19.488464
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import sys
    import os
    test_file = os.path.join(sys.path[0], 'test_tqdm_telegram_display.txt')
    sys.argv[:] = [sys.argv[0]]
    with open(test_file, 'w') as f:
        f.write('')
    sys.argv.append('-p')
    sys.argv.append(test_file)
    sys.argv.append('-t')
    sys.argv.append('{token}')
    sys.argv.append('-c')
    sys.argv.append('{chat_id}')
    import tqdm.contrib.tests
    tqdm.contrib.tests.test_tqdm_telegram_display()
    os.remove(test_file)

# Generated at 2022-06-12 14:48:22.031903
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tgio = TelegramIO('token', 'chat_id')
    assert tgio.message_id is not None
    tgio.delete()
    tgio.close()

# Generated at 2022-06-12 14:48:29.676001
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm import tqdm_telegram
    from unittest import TestCase
    from tqdm.tests._utils import _mock_gui

    class TqdmTest(TestCase):
        def test_tqdm_telegram_clear(self):
            with _mock_gui():
                t = tqdm_telegram(total=1, file=None)
                t.write('MOCK_GUI_TEXT')
                t.clear()
                t.close()
    t = TqdmTest()
    t.test_tqdm_telegram_clear()


if __name__ == "__main__":
    from ._main import _test_example
    _test_example(__file__)

# Generated at 2022-06-12 14:48:35.285981
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    s = ["", "", "", "", "", "", "", "", ""]
    tg = TelegramIO("", "")
    tg.message_id
    tg.write(s[0])
    tg.write(s[1])
    tg.write(s[2])
    tg.write(s[3])
    tg.write(s[4])
    tg.write(s[5])
    tg.write(s[6])
    tg.write(s[7])
    tg.write(s[8])

# Generated at 2022-06-12 14:48:38.344798
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    try:
        telegramIO = TelegramIO(token='token', chat_id='chat_id')
        telegramIO.write('test')
    except Exception as e:
        print(str(e))


# Generated at 2022-06-12 14:48:43.311852
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm.utils import _term_move_up
    from sys import stderr
    with stderr:
        b = tqdm_telegram(None)
        x = [' '] * 10
        b.write(''.join(x))
        b.clear()
        x = ['a'] * 20
        b.write(''.join(x))
        b.clear()
        x = ['b'] * 30
        b.write(''.join(x))

# Generated at 2022-06-12 14:48:44.879221
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .utils_test import tqdm_telegram_test_display
    tqdm_telegram_test_display()