

# Generated at 2022-06-12 14:48:53.059181
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """
    Unit test for tqdm.contrib.telegram.tqdm.close() function.
    """
    t = tqdm_telegram(range(2), disable=False)
    t.close()
    t.close()
    t.close()
    t = tqdm_telegram(range(2), disable=False, ncols=40)
    t.close()
    t.close()
    t.close()
    t = tqdm_telegram(range(2), disable=False, ncols=80)
    t.close()
    t.close()
    t.close()
    t = tqdm_telegram(range(2), disable=False, mininterval=0)
    t.close()
    t.close()
    t.close()
    t = t

# Generated at 2022-06-12 14:48:56.508667
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    with tqdm_telegram(total=1, dynamic_ncols=True, disable=False) as t:
        t.clear()
        t.refresh()
        t.refresh()

# Generated at 2022-06-12 14:48:58.659609
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    t = tqdm(total=1)
    assert t.format_dict['bar_format'] == '{l_bar}{bar}{r_bar}'
    t.close()

# Generated at 2022-06-12 14:49:01.298385
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from io import StringIO
    from tqdm import tqdm
    out = StringIO()
    for i in tqdm(range(1000), file=out):
        pass
    assert "10/1000" in out.getvalue()


# Generated at 2022-06-12 14:49:03.348872
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from ..std import tqdm as std_tqdm
    from .utils_test import _test_tqdm_display
    _test_tqdm_display(tqdm_telegram, std_tqdm)

# Generated at 2022-06-12 14:49:13.651932
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    with open("test_telegram_display.txt") as f:
        output_test = f.read()
    stdout_backup = tqdm_telegram.file
    tqdm_telegram.file = open("test_telegram_display_output.txt", "w", encoding='utf-8')
    with tqdm_telegram(total=5) as t:
        t.postfix["x"] = "y"
        t.display()
        t.update()
        t.set_postfix({"x": "yy"})
        t.display()
        t.update()
        t.display()
        t.display()
        t.update()
        t.display()
        t.update()
        t.display()
        t.display()
        t.display()
        t.display()

# Generated at 2022-06-12 14:49:23.404252
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from io import StringIO
    import sys

    sys.stdout = StringIO()

    try:
        tqdm_telegram(0, leave=True, disable=False)
    except Exception as e:
        assert (e.__class__ == RuntimeError and
                str(e) == 'You need to specify both "token" and "chat_id" '
                'arguments')
    else:
        raise AssertionError('"RuntimeError" not raised')

    try:
        tqdm_telegram(0, token='{token}', disable=False)
    except Exception as e:
        assert (e.__class__ == RuntimeError and
                str(e) == 'You need to specify both "token" and "chat_id" '
                'arguments')

# Generated at 2022-06-12 14:49:31.910811
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    import os
    import time
    import requests

    import tqdm
    from tqdm.contrib.telegram import tqdm_telegram
    from tqdm.contrib.telegram import ttgrange

    token = os.environ.get('TQDM_TELEGRAM_TOKEN')
    chat_id = os.environ.get('TQDM_TELEGRAM_CHAT_ID')

    # ensure that tqdm and tqdm_telegram work
    for i in tqdm(range(10), token=token, chat_id=chat_id):
        time.sleep(0.1)

    # our test for tqdm_telegram.close

# Generated at 2022-06-12 14:49:40.622112
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    """
    Test method display of class tqdm_telegram.
    """

    class Info:
        pass
    info = Info()
    info.total = None
    info.n = 0
    info.avg_time = 0.0001
    info.dynamic_ncols = False
    info.miniters = 1
    info.avg_size = None
    info.last_print_n = None

    fmt = {}
    fmt['bar_format'] = '{l_bar}{bar}{r_bar}'
    fmt['pos'] = '%5.2f'
    fmt['avg'] = '%5.2f'
    fmt['n'] = '%5.2f'
    fmt['n_fmt'] = '%5d'
    fmt['desc'] = '{desc}'


# Generated at 2022-06-12 14:49:42.684821
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    t = tqdm_telegram(["a", "b"], token='{token}', chat_id='{chat_id}')
    t.clear()
    t.close

# Generated at 2022-06-12 14:51:26.370427
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tgio = TelegramIO('token', 'chat_id')
    tgio.write('test message')
    tgio.write('test message')

# Generated at 2022-06-12 14:51:32.319555
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    with tqdm_telegram(total=10, token='foo1', chat_id='foo2') as pbar:
        pass
    if getenv('TQDM_TELEGRAM_TOKEN') is not None and \
       getenv('TQDM_TELEGRAM_CHAT_ID') is not None:
        with tqdm_telegram(total=10) as pbar:
            pass
        with tqdm_telegram(total=10, token=getenv('TQDM_TELEGRAM_TOKEN')) as \
             pbar:
            pass
        with tqdm_telegram(total=10, chat_id=getenv('TQDM_TELEGRAM_CHAT_ID')) \
             as pbar:
            pass

# Generated at 2022-06-12 14:51:40.214670
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm.auto import tqdm as tqdm_auto

    save_after = 3
    total = 5
    with tqdm_telegram(total=total,
                       bar_format="{l_bar}{bar}|{n_fmt}/{total_fmt}[{remaining}]",
                       token='755348076:AAHhDJZbozQ1NwRJARmiyc7l1Q2f8V4DWWg',
                       chat_id='-369959107') as pbar:
        for i in pbar:
            if i == save_after:
                pbar.clear()
            pbar.update(1)

# Generated at 2022-06-12 14:51:44.135047
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tgio = TelegramIO(getenv('TQDM_TELEGRAM_TOKEN'),
                      getenv('TQDM_TELEGRAM_CHAT_ID'))
    tgio.write("bar")
    tgio.delete()
    tgio.tgio.close()

test_TelegramIO_delete()

# Generated at 2022-06-12 14:51:45.567264
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    for i in ttgrange(5, disable=True):
        pass
    for i in ttgrange(5, disable=False):
        pass

# Generated at 2022-06-12 14:51:53.721059
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import time
    with tqdm_telegram(
            total=100,
            unit_scale=False,
            postfix={"a": 1, "b": 1, "c": 1, "d": 1},
            bar_format='{postfix}{n_fmt}/{total_fmt} '
                       '{l_bar}{bar:10u}{r_bar} ',
            token='{token}',
            chat_id='{chat_id}') as t:
        for _ in t:
            t.set_postfix(a=(t.n*t.n), b=t.n, c=t.n, d=(t.n*t.n))
            time.sleep(0.01)



# Generated at 2022-06-12 14:51:58.338006
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from time import sleep, time
    from random import random

    for _ in tqdm(range(3), desc='test', disable=False):
        sleep(random() *.0001)
    if time() % 2:
        tqdm.clear(True)
        tqdm.close()
    else:
        # create new pbar
        for _ in tqdm(range(2), desc='test1', disable=False):
            sleep(random() *.0001)
        tqdm.close()

# Generated at 2022-06-12 14:52:03.080162
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    import sys
    from contextlib import contextmanager
    from io import StringIO
    import re

    @contextmanager
    def captured(command, *args, **kwargs):
        try:
            out, sys.stdout = sys.stdout, StringIO()
            command(*args, **kwargs)
            sys.stdout.seek(0)
            yield sys.stdout.read()
        finally:
            sys.stdout = out

    token = '123456789:AAHft-L8y25Wli7v0QNTD1_Et_fHtWji0vI'
    chat_id = '12345678'
    tgio = TelegramIO(token, chat_id)

    m = re.compile('`(.*)`')

# Generated at 2022-06-12 14:52:07.211032
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    telegram_token = '***'
    telegram_chat_id = '***'
    tqdm_instance = tqdm(token=telegram_token, chat_id=telegram_chat_id)
    tqdm_instance.close()

# Generated at 2022-06-12 14:52:09.952061
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    try:
        io = TelegramIO('123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11', '87654321')
        io.delete()
    except Exception as e:
        tqdm_auto.write(str(e))