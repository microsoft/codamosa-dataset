

# Generated at 2022-06-12 14:45:14.027211
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    return tqdm_telegram

# Generated at 2022-06-12 14:45:18.572448
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from tqdm.test import _supports_unicode, _range
    for unit in [None, '', '1', 'foo', '-']:
        for n in [0, 5, 10]:
            t = tqdm_telegram(_range(n), leave=True, unit=unit)
            t.__exit__(None, None, None)
            t = tqdm_telegram(_range(n), leave=False, unit=unit)
            t.__exit__(None, None, None)

# Generated at 2022-06-12 14:45:23.334661
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from .utils_test import PatchIO
    token = chat_id = 'TEST'
    with PatchIO('trange', 'twrite') as (_, write):
        for i in trange(2, token=token, chat_id=chat_id):
            write("message")
            assert 'message' in write.contents
            if i == 1:
                with write.patch_output() as out:
                    trange.clear()
                    assert ('message' not in write.contents
                            and out.getvalue() == '')

# Generated at 2022-06-12 14:45:33.834184
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    tq = tqdm_telegram(range(10), disable=True)
    tq.close()
    tq = tqdm_telegram(range(10), disable=False, leave=True)
    tq.close()
    tq = tqdm_telegram(range(10), disable=False, leave=False)
    tq.close()
    tq = tqdm_telegram(range(0), disable=False, leave=False)
    tq.close()
    tq = tqdm_telegram(range(10), disable=False, leave=True)
    tq.close()
    tq = tqdm_telegram(range(10), disable=False, leave=None)
    tq.close()

# Generated at 2022-06-12 14:45:35.295476
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    with ttgrange(10) as t:
        for i in t:
            pass



# Generated at 2022-06-12 14:45:37.658256
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    with tqdm(10, token='{token}', chat_id='{chat_id}') as t:
        for i in t:
            t.close()

# Generated at 2022-06-12 14:45:47.308401
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    """
    Unit test for constructor of class tqdm_telegram.
    """
    from requests import Session
    from ..std import FakeIO

    # Start a session

# Generated at 2022-06-12 14:45:49.564233
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    with tqdm_telegram(total=2, leave=True) as t:
        t.update(2)
        t.close()


# Generated at 2022-06-12 14:45:50.707259
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    tio = TelegramIO('', '')
    assert tio.delete() is None

# Generated at 2022-06-12 14:45:52.397770
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """
    Unit test for method close of class tqdm_telegram
    """
    assert tqdm_telegram.close('self')

# Generated at 2022-06-12 14:47:22.621655
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    telegram_tqdm = tqdm_telegram(total = 1)
    telegram_tqdm.close()

# Generated at 2022-06-12 14:47:23.976168
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .utils import _range, format_dict
    s = tqdm_telegram(_range(1), disable=True)
    assert s.format_dict == format_dict
    s.display()

# Generated at 2022-06-12 14:47:27.484971
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    # set `mininterval` to 0 to avoid flaky tests
    t = tqdm_telegram(range(10), mininterval=0,
                      token=getenv('TQDM_TELEGRAM_TOKEN'),
                      chat_id=getenv('TQDM_TELEGRAM_CHAT_ID'))
    for i in t:
        t.display()
    t.close()


# Generated at 2022-06-12 14:47:33.467923
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    with tqdm_telegram(disable=True) as t:
        assert t.disable
        t.close()
    with tqdm_telegram(ascii=True, disable=False) as t:
        assert not t.disable
        t.close()
    with tqdm_telegram(ascii=True, leave=True, disable=False) as t:
        assert not t.disable
        t.close()
    with tqdm_telegram(ascii=True, leave=False, disable=False) as t:
        assert not t.disable
        t.close()
    with tqdm_telegram(ascii=True, leave=None, disable=False) as t:
        assert not t.disable
        t.close()

# Generated at 2022-06-12 14:47:43.602586
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from unittest import TestCase, main

    class TestTelegramIOOut(TestCase):
        def setUp(self):
            self.tio = TelegramIO('test_token', 'test_chat_id')

        def tearDown(self):
            del self.tio
            self.tio = None

        def test_message_id(self):
            self.assertEqual(self.tio.message_id, None)
            self.tio._message_id = 1234
            self.assertEqual(self.tio.message_id, 1234)

        def test_write(self):
            self.assertEqual(self.tio.write(""), None)
            self.assertEqual(self.tio.write("\r"), None)

# Generated at 2022-06-12 14:47:45.205889
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    with tqdm(total=10) as t:
        t.update()
        t.clear()
        t.clear()

# Generated at 2022-06-12 14:47:53.232930
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from os import getenv
    from time import sleep, time
    from tqdm import tqdm as tqdm_auto
    from .utils_test import common_telegram_test

    def _run_TelegramIO_write(token, chat_id):
        io = TelegramIO(token, chat_id)
        start = time()
        with tqdm_auto(total=50, file=io, miniters=1,
                       disable=False, unit="min", unit_scale=True) as pbar:
            for i in pbar:
                pbar.set_description('processing %d' % i)
                sleep(0.5)
        return time() - start

    if getenv('CI') not in ('', 'true'):
        return  # skip Telegram test on Travis CI


# Generated at 2022-06-12 14:47:54.828667
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .utils_test import _test_display
    _test_display(tqdm_telegram)

# Generated at 2022-06-12 14:47:57.522204
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .tests_tqdm import pretest_posttest_monkeypatch
    pretest_posttest_monkeypatch()

    # Setup
    t = tqdm(total=1000, bar_format='{bar}|')
    t.update(900)

    # Actual test for `display`
    t.display()

# Generated at 2022-06-12 14:48:00.678605
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    # Given
    tgio = TelegramIO("abc","def")
    # When
    tgio.write("Testing tgio")
    # Then
    assert tgio.text == "Testing tgio"


# Generated at 2022-06-12 14:51:12.346314
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    tgio = TelegramIO(token=token, chat_id=chat_id)
    assert tgio.message_id is not None
    tgio.write('test write')

# Generated at 2022-06-12 14:51:16.715786
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    telegram_io = TelegramIO(getenv('TQDM_TELEGRAM_TOKEN'),getenv('TQDM_TELEGRAM_CHAT_ID'))
    telegram_io.write('1')
    telegram_io.write('2')
    telegram_io.write('3')
    telegram_io.delete()

# Generated at 2022-06-12 14:51:25.788482
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from os import devnull
    from sys import stdout
    from time import sleep
    from .utils_fake import mono_fake_pandas
    from .utils_fake import mono_fake_pandas_error
    from .utils_fake import mono_fake_pandas_warning
    from .utils_fake import mono_fake_pandas_custom
    from .utils_fake import mono_fake_nested
    for cls in (tqdm_telegram, ttgrange):
        with open(devnull, 'w') as fobj:
            # tgrange
            cls(5).close()
            cls(5, file=fobj).close()
            cls(5, file=fobj).start_tgrange().close()
            assert cls.write == tqdm_telegram.write


# Generated at 2022-06-12 14:51:27.229497
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from .utils_test import _test_clear
    _test_clear(tqdm_telegram)

# Generated at 2022-06-12 14:51:28.703192
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    t = tqdm_telegram(total=1)
    t.refresh()
    t.close()
    assert t._instances == []

# Generated at 2022-06-12 14:51:30.762091
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .test_tqdm import pretest_posttest, TestMonitor
    with TestMonitor(leave=True) as mon:
        pretest_posttest(lambda: tqdm(total=4, file=mon))



# Generated at 2022-06-12 14:51:34.198598
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    token = "123456789:XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
    chat_id = "01234567890123456789"
    tgout = TelegramIO(token, chat_id)
    tgout.write('hello')
    assert tgout._message_id is not None
    tgout.write('world')
    assert tgout.text == 'world'
    # Test duplicate message Bot error
    tgout.write('world')
    assert tgout.text == 'world'
    tgout.delete()

# Generated at 2022-06-12 14:51:36.855139
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .utils_test import _test_tqdm_display

    _test_tqdm_display(tqdm_telegram, __file__)


# Generated at 2022-06-12 14:51:42.125096
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import pytest
    msg = (
        "Arguments `total` and `position` must be "
        "either both specified or both unspecified.")
    with pytest.raises(ValueError) as excinfo:
        tqdm_telegram()
        assert str(excinfo.value) == msg
        with pytest.raises(ValueError) as excinfo:
            tqdm_telegram(total=3)
            assert str(excinfo.value) == msg

# Generated at 2022-06-12 14:51:53.251637
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    import pytest