

# Generated at 2022-06-12 14:45:03.890677
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from sys import stdout
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch
    with patch('tqdm.auto._tqdm_gui.tqdm_write') as mock_write:
        with patch('tqdm.auto._tqdm_gui.tqdm_sleep'):
            test = tqdm_telegram(total=0, file=stdout, leave=True)
            test.display()
            # mock_write.assert_called_with('\x1b[K\r')
            # https://github.com/tqdm/tqdm/pull/741#issuecomment-331030001
            mock_write.assert_called_with(b'\x1b[1A\x1b[K\r')
            test

# Generated at 2022-06-12 14:45:05.512412
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    """No-op test"""
    pass

# Generated at 2022-06-12 14:45:14.068297
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .utils_test import assertRaises
    with assertRaises(ValueError):
        f = tqdm_telegram.display(
            token="token", chat_id="chat_id", bar_format="{bar:10u}")
    f = tqdm_telegram.display(
        token="token", chat_id="chat_id", bar_format="<bar/>")
    f = tqdm_telegram.display(
        token="token", chat_id="chat_id", bar_format="{bar}")


# Generated at 2022-06-12 14:45:21.220483
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm.contrib import telegram
    import tempfile
    import os
    telegram._ENV_TEST = "TEST"
    temp = tempfile.mktemp()

    class MockFile(object):
        def __init__(self, fname):
            self.fname = fname

        def write(self, str):
            with open(self.fname, 'a') as fd:
                fd.write(str)

        def flush(self):
            pass

    with open(temp, "w") as fd:
        fd.write("")

    pbars = telegram.tqdm(["a", "b", "c"], file=MockFile(temp), leave=True)
    for char in pbars:
        # we are not testing `write`, here
        pass


# Generated at 2022-06-12 14:45:30.225086
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    """Tests tqdm_telegram"""
    # There is no way to test `tqdm_telegram` without a valid Telegram Bot and
    # chat id
    import os
    if os.getenv("TQDM_TELEGRAM_TOKEN") is not None and \
            os.getenv("TQDM_TELEGRAM_CHAT_ID") is not None:
        from .utils import SlowTestException
        raise SlowTestException("Live Telegram Bot test is not accurate")


if __name__ == '__main__':
    from doctest import testmod
    testmod()

# Generated at 2022-06-12 14:45:32.031019
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    t = tqdm_telegram(total=2)
    t.display()


# Generated at 2022-06-12 14:45:38.772791
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from requests_mock import Mocker
    from io import StringIO
    from random import random
    with Mocker() as m:
        m.post('https://api.telegram.org/bot{b}/sendMessage', [
            {'json': {'ok': True, 'result': {'message_id': 1}}},
            {'json': {'ok': True, 'result': {'message_id': 2}}},
        ])
        m.post('https://api.telegram.org/bot{b}/deleteMessage', [
            {'json': {'ok': True, 'result': {}}},
            {'json': {'ok': True, 'result': {}}},
        ])

# Generated at 2022-06-12 14:45:48.129174
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    message = "delete test"
    t = TelegramIO(getenv('TQDM_TELEGRAM_TOKEN'),
                   getenv('TQDM_TELEGRAM_CHAT_ID'))
    t.session.post(t.API + '%s/sendMessage' % t.token,
                   data={'text': message, 'chat_id': t.chat_id,
                         'parse_mode': 'MarkdownV2'}).json()
    t.delete()
    # check if delete message is successful
    response = t.session.post(t.API + '%s/sendMessage' % t.token,
                              data={'text': message, 'chat_id': t.chat_id,
                                    'parse_mode': 'MarkdownV2'}).json()

# Generated at 2022-06-12 14:45:50.869398
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from tqdm.test import TqdmSynchronise, closing
    with closing(TqdmSynchronise()) as t:
        for i in tqdm(t, total=4, leave=False):
            t.update(4)

# Generated at 2022-06-12 14:45:53.232507
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    t = tqdm_telegram(token='{token}', chat_id='{chat_id}')
    del t

# Generated at 2022-06-12 14:49:01.348079
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    t = TelegramIO('123', '456')
    t.write('test')
    tqdm_auto.write('test')
    tqdm_auto.write('test')
    tqdm_auto.write('test')
    t.delete()
    t.close()
    tqdm_auto.write('test')
    tqdm_auto.write('test')
    tqdm_auto.write('test')
    tqdm_auto.write('test')

# Generated at 2022-06-12 14:49:03.853605
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    try:
        tio = TelegramIO('', '')
    except Exception as e:
        tqdm_auto.write(str(e))
    else:
        tio.delete()

# Generated at 2022-06-12 14:49:14.058503
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    t = tqdm_telegram(token=38321, chat_id="4")
    t.n = 100

# Generated at 2022-06-12 14:49:20.011785
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    text = "test_tqdm_telegram_display"
    tg = tqdm_telegram(token='1', chat_id='1')
    tg.n = 4
    tg.desc = text
    tg.display()
    assert text in tg.text
    text = "test_tqdm_telegram_display_2"
    tg.display(desc=text)
    assert text in tg.text

# Generated at 2022-06-12 14:49:22.029994
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from . import tqdm_telegram
    from .tests import tests
    tests.test_tqdm_display(lambda **kwargs: tqdm_telegram(**kwargs))

# Generated at 2022-06-12 14:49:25.947804
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from time import sleep
    for i in tqdm(range(3), desc='test'):
        for j in tqdm(range(3), desc='inner'):
            sleep(0.01)
        tqdm.clear(inner=True)

# Generated at 2022-06-12 14:49:33.550196
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    import time
    assert tqdm_telegram(total=1, disable=False, leave=False).close()
    assert tqdm_telegram(total=1, disable=False, leave=True).close()
    assert tqdm_telegram(total=1, disable=False, leave=None).close()
    assert tqdm_telegram(total=0, disable=False, leave=False).close()
    assert not tqdm_telegram(total=0, disable=False, leave=True).close()
    assert not tqdm_telegram(total=0, disable=False, leave=None).close()
    t = tqdm_telegram(total=6, disable=False, leave=False)
    for i in range(1, 5):
        t.update()
        time.sleep(0.1)

# Generated at 2022-06-12 14:49:42.397689
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    if tqdm_telegram is tqdm_auto:
        warn('It looks like tqdm_telegram is not available. Skipping test',
             TqdmWarning)
        return

    def _test(kwargs):
        """
        Returns True if the close method of the object returns True and False
        if the close method of the object returns False
        """
        t = tqdm_telegram(**kwargs)
        return t.close()

    def _test_leave(kwargs):
        """
        Returns True if the close method of the object returns True and False
        if the close method of the object returns False.
        """
        t = tqdm_telegram(leave=True, **kwargs)
        return t.close()

    assert not _test({'disable': True})

# Generated at 2022-06-12 14:49:45.209115
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from sys import stderr
    from time import sleep
    for _ in tqdm(["a", "b"], file=stderr, miniters=1):
        sleep(.5)
        stderr.flush()

# Generated at 2022-06-12 14:49:47.694819
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    """Unit test for method delete of class TelegramIO."""
    tg = TelegramIO(getenv('TQDM_TELEGRAM_TOKEN'),
                    getenv('TQDM_TELEGRAM_CHAT_ID'))
    tg.delete()

# Generated at 2022-06-12 14:51:43.444641
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    """
    Test method display of class tqdm_telegram > subclasses tqdm_gui.
    The test class is instantiated without displaying the bar and without
    calling the parent class display method since these are covered
    by the subclasses tqdm_gui and tqdm_notebook.
    The only functionality tested is the functionality added by the
    subclass tqdm_telegram.
    """
    import sys
    import time
    from .tqdm_telegram import tqdm_telegram, TelegramIO
    from .tqdm_gui import tqdm_gui
    from .tests_tqdm import pretest_posttest  # noqa: F811
    from tqdm import tqdm

    # Test display
    # instantiate test class, inherit tqdm_gui display method

# Generated at 2022-06-12 14:51:49.295955
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    import pytest
    with pytest.raises(SystemExit):
        tqdm_telegram = tqdm_telegram(xrange(1), disable=True)
        tqdm_telegram.close()
    with pytest.raises(SystemExit):
        tqdm_telegram = tqdm_telegram(xrange(1), disable=False)
        tqdm_telegram.close()

# Generated at 2022-06-12 14:51:56.504900
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    # Unit test for method display of class tqdm_telegram
    from os import getenv
    from .utils_filesysobjects import normalize_path
    from .utils_testing import _osx_popen
    import sysconfig

    pyexe = normalize_path(sysconfig.get_paths()['scripts'] + "/python")

    try:
        cmd = ('%s -m tqdm -t %s -c %s --range 10'
               % (pyexe, getenv('TQDM_TELEGRAM_TOKEN'),
                  getenv('TQDM_TELEGRAM_CHAT_ID')))
        _osx_popen(cmd)
    except TypeError:
        pass

# Generated at 2022-06-12 14:51:58.226963
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    tt = tqdm_telegram(["hi"])
    tt.display()
    tt.clear()
    assert True

# Generated at 2022-06-12 14:52:04.137381
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    with tqdm_telegram(total=2, token="token", chat_id="chat_id") as t:
        assert (t.pos == 0 and t.n == 2 and t.closed is False and
                t.dynamic_ncols is True and t.desc is None)
        t.clear()
        assert (t.pos == 0 and t.n == 2 and t.closed is False and
                t.dynamic_ncols is True and t.desc is None)


# Generated at 2022-06-12 14:52:13.906656
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    """
    The code to test `tqdm_telegram.close`.

    Returns
    -------
    bool
        True if `tqdm_telegram.close` works as expected, False otherwise.
    """
    from sys import stderr
    from io import StringIO
    import tqdm.contrib.test_utils as test_utils

    tqdm._instances.clear()
    io = StringIO()
    stderr = stderr, sys.stderr, sys.stderr = sys.stderr, io, io

    # Test disable
    sys.stderr = stderr
    test_utils.print_reset(file=io)
    tgr = tqdm_telegram(range(5), disable=True)
    tgr.close()

# Generated at 2022-06-12 14:52:21.128670
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tgio = TelegramIO(token='',chat_id='')
    tgio.text = 'test'
    # Test 1
    assert tgio.write('test')

    # Test 2
    assert tgio.write('test a')

    # Test 3
    assert tgio.write('test a b')

    # Test 4
    assert tgio.write('test a b')

    # Test 5
    assert tgio.write('test a b c')

    # Test 6
    assert tgio.write('test a b c d')

    # Test 7
    assert tgio.write('test a b c d e')

    # Test 8
    assert tgio.write('test a b c d e f')

    # Test 9

# Generated at 2022-06-12 14:52:26.094548
# Unit test for constructor of class tqdm_telegram
def test_tqdm_telegram():
    with tqdm_telegram(token='token', chat_id='chat_id', total=100,
                       desc='Tarrytown') as t:
        for i in _range(100):
            t.update()
            assert t.n == i + 1
            assert t.format_dict['dynamic_ncols'] == (i + 1) * 2
            assert t.format_dict['n'] == i + 1
            assert t.format_dict['total'] == 100
            assert t.format_dict['bar_format'] == "{l_bar}Tarrytown{bar:10u}{r_bar}"
            t.set_description('Sleepy Hollow')
            assert t.format_dict['bar_format'] == "{l_bar}Sleepy Hollow{bar:10u}{r_bar}"
            t.set_postfix_

# Generated at 2022-06-12 14:52:27.472170
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    tgr = tqdm_telegram(iterable=range(1), leave=False, token="yourtoken",
                        chat_id="yourchat")
    tgr.clear()
    tgr.close()

# Generated at 2022-06-12 14:52:30.431165
# Unit test for method delete of class TelegramIO
def test_TelegramIO_delete():
    """
    Unit testing for method delete of class TelegramIO
    """
    tg_sample = TelegramIO(token='1179391738:AAHZKy-Lhc1VX9MHLFzEM01yRwYdYgKQ2cA', chat_id='-1001285181273')
    assert tg_sample.delete() == None