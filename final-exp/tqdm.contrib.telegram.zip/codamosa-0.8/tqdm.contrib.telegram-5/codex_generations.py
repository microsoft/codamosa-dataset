

# Generated at 2022-06-12 14:47:10.030274
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    with tqdm_telegram(total=5) as pbar:
        for i in range(5):
            pbar.display()
            pbar.update()


if __name__ == '__main__':
    from .tests import test_tqdm
    import sys
    sys.exit(test_tqdm(__file__, monitoring=False))

# Generated at 2022-06-12 14:47:16.772773
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    """Unit test for method display of class tqdm_telegram"""
    from os import getenv
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    if token and chat_id:
        from requests import Session
        sess = Session()
        q = tqdm_telegram(desc='testing tqdm_telegram display', total=10,
                          leave=True, position=0, token=token, chat_id=chat_id,
                          disable=True)  # disable=True avoids new message

# Generated at 2022-06-12 14:47:24.738505
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import time
    import re
    from tqdm.contrib.telegram import tqdm_telegram, TelegramIO
    from .utils import _environ
    with _environ(TQDM_TELEGRAM_TOKEN='542508514:AAE5Dff8o9p9bbZ1QLq-Bn0H1L-lxKjnPwA',
                  TQDM_TELEGRAM_CHAT_ID='69706665'):
        tgio = TelegramIO('542508514:AAE5Dff8o9p9bbZ1QLq-Bn0H1L-lxKjnPwA',
                          '69706665')
        tgio.message_id

# Generated at 2022-06-12 14:47:30.819214
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    tgio = TelegramIO(None, None)
    # Test if write method handles messages in unicode characters
    tgio.write("\x80")


if __name__ == '__main__':
    # Unit test
    import argparse

    # Test if argument `chat_id` and `token` is required
    # Test if `tgrange` accepts parameters of `range`
    parser = argparse.ArgumentParser()
    parser.add_argument("--token", default="", help="Telegram token")
    parser.add_argument("--chat_id", default="", help="Telegram chat ID")
    args = parser.parse_args()

    if args.chat_id and args.token:
        test_TelegramIO_write()

# Generated at 2022-06-12 14:47:36.293243
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import sys
    import colorama
    from tqdm.auto import tqdm
    # NOTE: `with` makes the terminal green after the test,
    #       so we use the pre-0.7 style here
    orig_out = sys.stdout
    sys.stdout = colorama.AnsiToWin32(orig_out).stream
    print('\033[92m', end='')
    try:
        for i in tqdm(range(10)):
            sys.stdout.write('\033[F\033[K')
    finally:
        sys.stdout.flush()
        sys.stdout.write('\n')
        sys.stdout.flush()
        sys.stdout = orig_out


if __name__ == '__main__':
    test_tqdm_telegram_

# Generated at 2022-06-12 14:47:41.668919
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    """
    >>> from tqdm.contrib import TelegramIO
    >>> s = TelegramIO('casperdcl', '243327750')
    >>> s.write('Hello')
    >>> s.close()
    """
    pass


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 14:47:48.118423
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from unittest import TestCase
    from unittest.mock import MagicMock
    from ..utils import FormatCustomTextType
    tqdm_telegram.write = MagicMock()
    tqdm_telegram.clear()
    tqdm_telegram.write.assert_called_with(FormatCustomTextType(''))
    tqdm_telegram.update(0)
    tqdm_telegram.write.assert_any_call(FormatCustomTextType('  0%| | 0/1 '))
    tqdm_telegram.close()
    tqdm_telegram.write.assert_any_call(FormatCustomTextType('\n'))

# Generated at 2022-06-12 14:47:56.242097
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():

    import time
    import numpy as np
    import random
    try:
        from cStringIO import StringIO
    except ImportError:
        from io import StringIO

    # Just to get the telegram bot token and chat id
    expected_token = getenv('TQDM_TELEGRAM_TOKEN')
    expected_chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')

    # Some variables
    N = np.random.randint(1, 5)
    sleep = np.random.uniform(0, 0.01)
    pos = np.random.randint(1, N)
    ncols = np.random.randint(1, 20)
    bar_format = "{l_bar} {bar}"
    iteration_file = StringIO()
    disable = False
    leave

# Generated at 2022-06-12 14:48:03.697958
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from copy import copy
    from requests import Session
    token, chat_id = '{token}', '{chat_id}'
    tgio = TelegramIO(token, chat_id)
    tgio.session = Session()

    # test for the case of empty format_dict
    fmt = copy(tgio.format_dict)
    tgio.write(tgio.format_meter(**fmt))
    tgio.session.close()
    assert True


if __name__ == "__main__":
    from doctest import testmod
    from os import unsetenv
    unsetenv("COLUMNS")
    testmod(name="telegram")

# Generated at 2022-06-12 14:48:09.225558
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    obj = tqdm_telegram(disable=True)
    obj.leave = True
    assert obj.close() == None
    obj.leave = None
    obj.pos = 1
    assert obj.close() == None
    obj.leave = None
    obj.pos = 0
    assert obj.close() == None
    obj.leave = False
    obj.pos = 0
    assert obj.close() == None
    obj = tqdm_telegram()
    obj.pos = 1
    assert obj.close() == None
    obj.pos = 0
    assert obj.close() == None

# Generated at 2022-06-12 14:50:19.220575
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    def suppress_stdout():
        """Decorator to suppress stdout of decorated function."""
        import contextlib
        import io
        import os

        @contextlib.contextmanager
        def stdoutIO(stdout=None):
            """ Supress stdout for desired function."""
            old = sys.stdout
            if stdout is None:
                stdout = io.StringIO()
            sys.stdout = stdout
            yield stdout
            sys.stdout = old

        def wrap(func):
            """ Wrap the desired method to suppress stdout."""
            def wrapped_func(*args, **kwargs):
                with stdoutIO() as s:
                    func(*args, **kwargs)

            return wrapped_func

        return wrap


# Generated at 2022-06-12 14:50:23.819207
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from .tests_tqdm import pretest_posttest_monkeypatch
    from .tests_tqdm import __test_cls

    t = __test_cls(tqdm_telegram, None, 0.01)
    with pretest_posttest_monkeypatch(t, 'display'):
        with t.temporary_file() as fname:
            t.__init__(tqdm(t.iterable, file=fname))
            t.start()
            l = fname.read().strip().splitlines()
        assert len(l) == len(t.iterable) + 1

# Generated at 2022-06-12 14:50:31.178853
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import os

# Generated at 2022-06-12 14:50:37.784725
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    # NB: while the tqdm instance is being closed, the TelegramIO is used to
    #    send a message to the Telegram bot specified in the environment
    # variables TQDM_TELEGRAM_TOKEN and TQDM_TELEGRAM_CHAT_ID
    # The test will pass only if the Telegram bot does not address errors
    #    messages such as "Timeout" to the tqdm instance
    with tqdm_telegram(total=5) as t:
        for i in range(5):
            t.update()

# Generated at 2022-06-12 14:50:45.363612
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    import os
    import sys
    s = ""
    try:
        fd = sys.stderr.fileno()
        if os.isatty(fd):
            orig = sys.stdout
            sys.stdout = os.fdopen(os.dup(fd), 'w')
            t = tqdm_telegram(["a", "b", "c"],
                              file=orig,
                              disable=False)
            t.write("")
            s = sys.stderr.getvalue()
    finally:
        sys.stdout = orig
    assert s == "\r                                                 \r"


if __name__ == "__main__":
    from doctest import testmod
    testmod(verbose=True)

# Generated at 2022-06-12 14:50:56.698070
# Unit test for method write of class TelegramIO
def test_TelegramIO_write():
    from time import sleep
    from requests import Session
    from tqdm.contrib.telegram import TelegramIO, tqdm_telegram
    token = "123456789:AAHdqTcvCH1vGWJxfSeofSAs0K5PALDsaw"
    chat_id = "1234567"
    #
    io = TelegramIO(token, chat_id)
    print("Initial message should've been sent...")
    sleep(3)
    assert io.message_id is not None
    io.write("foo")
    print("First message update should've been sent...")
    sleep(3)
    assert io.message_id is not None
    io.write("foo")
    print("Second message update should've been sent...")
    sleep(3)
    assert io.message_id is not None


# Generated at 2022-06-12 14:51:04.034177
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    t = tqdm(['a', 'b', 'c'], token='', chat_id='')
    assert t.format_dict['bar_format'] == '{l_bar}{bar:10u}{r_bar}'
    assert t.format_dict['postfix']['smoothing']['total'] == t.total
    t.close()  # avoid exception due to missing IO
    tqdm_telegram(['a', 'b', 'c'], token='', chat_id='', disable=True)
    tqdm_telegram(['a', 'b', 'c'], token='', chat_id='', disable=True).close()
    tqdm_telegram(['a', 'b', 'c'], token='', chat_id='', disable=True).display()

# Generated at 2022-06-12 14:51:08.997814
# Unit test for method close of class tqdm_telegram
def test_tqdm_telegram_close():
    token = getenv('TQDM_TELEGRAM_TOKEN')
    chat_id = getenv('TQDM_TELEGRAM_CHAT_ID')
    # check if envars are set
    if token is None or chat_id is None:
        raise Exception("Missing envars `TQDM_TELEGRAM_TOKEN` and/or `TQDM_TELEGRAM_CHAT_ID`")
    # check if TelegramIO object can be created
    try:
        tgio = TelegramIO(token, chat_id)
    except:
        raise Exception("Failed to create a TelegramIO object.")
    # test tqdm_telegram close on leave

# Generated at 2022-06-12 14:51:12.535182
# Unit test for method clear of class tqdm_telegram
def test_tqdm_telegram_clear():
    from .utils_test import _test_clear

    with _test_clear(tqdm_telegram(disable=True)) as progressbar:
        progressbar.update(1)


# Generated at 2022-06-12 14:51:22.414800
# Unit test for method display of class tqdm_telegram
def test_tqdm_telegram_display():
    from requests_mock import Mocker
    with Mocker() as m:
        m.post('https://api.telegram.org/bot{token}/sendMessage', [
            {'json': {'result': {'message_id': 1}}},
            {'json': {'error_code': 429}}])
        m.post('https://api.telegram.org/bot{token}/editMessageText', [
            {'json': {'result': True}},
            {'json': {'result': True, 'message': {'text': '`foo`'}}}])
        m.post('https://api.telegram.org/bot{token}/deleteMessage',
               {'json': {'result': True}})