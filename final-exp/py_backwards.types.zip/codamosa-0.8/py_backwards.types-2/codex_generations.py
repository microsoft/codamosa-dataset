

# Generated at 2022-06-12 04:25:25.415042
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("x = 4")
    res = TransformationResult(tree, False, [])
    assert isinstance(res.tree, ast.AST), "tree is not ast.AST: {}".format(type(res.tree))
    assert not res.tree_changed, "expecting tree_changed == False"
    assert len(res.dependencies) == 0, "expecting no dependencies"

# Generated at 2022-06-12 04:25:28.990756
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    t = ast.parse('import math')
    tr = TransformationResult(t, False, [])
    assert tr.tree is t
    assert tr.tree_changed is False
    assert tr.dependencies == []


# Generated at 2022-06-12 04:25:33.579001
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=2,
                               target=(3, 4),
                               dependencies=['a', 'b', 'c'])
    assert result.files == 1
    assert result.time == 2
    assert result.target == (3, 4)
    assert result.dependencies == ['a', 'b', 'c']



# Generated at 2022-06-12 04:25:34.484373
# Unit test for constructor of class InputOutput
def test_InputOutput():
    ast.Str()


# Generated at 2022-06-12 04:25:38.590941
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c1 = CompilationResult(1, 2, (3, 4), [])
    c2 = CompilationResult(1, 2, (3, 4), [])
    c3 = CompilationResult(1, 2, (3, 4), [])
    assert (c1 == c2)
    assert (c2 == c3)
    assert (c1 == c3)


# Generated at 2022-06-12 04:25:41.027177
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 2.0, (3, 4), ['a']) == \
           CompilationResult(1, 2.0, (3, 4), ['a'])



# Generated at 2022-06-12 04:25:42.853705
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path('input'), Path('output'))
    assert io.input == Path('input')
    assert io.output == Path('output')

# Generated at 2022-06-12 04:25:46.577025
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=123,
                      time=1.0,
                      target=(3, 6),
                      dependencies=['dep1', 'dep2'])


# Generated at 2022-06-12 04:25:53.951219
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=1,
                          time=0.1,
                          target=(3, 3),
                          dependencies=['foo', 'bar'])
    assert c.files == 1
    assert c.time == 0.1
    assert c.target == (3, 3)
    assert c.dependencies == ['foo', 'bar']
    assert str(c) == 'CompilationResult(files=1, time=0.1, target=(3, 3), ' \
                     'dependencies=[\'foo\', \'bar\'])'



# Generated at 2022-06-12 04:25:55.740846
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input.py')
    output = Path('output.py')
    assert InputOutput(input, output).input == input
    assert InputOutput(input, output).output == output


# Generated at 2022-06-12 04:25:59.942611
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = 'input'
    output = 'output'
    res = InputOutput(input=input_, output=output)
    assert res.input == input_
    assert res.output == output


# Generated at 2022-06-12 04:26:01.440367
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.AST(), True, ['example.py']).dependencies == ['example.py']

# Generated at 2022-06-12 04:26:06.777452
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(1, 2, (3, 4), [])
    assert len(res) == 4
    assert res[0] == 1
    assert res[1] == 2
    assert res[2] == (3, 4)
    assert res[3] == []


# Generated at 2022-06-12 04:26:09.948110
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    file_number = 12
    time = 0.34
    version = (3, 7)
    dependencies = ['foo', 'bar']

    result = CompilationResult(files=file_number, time=time,
                               target=version, dependencies=dependencies)
    assert result.files == file_number
    assert result.time == time
    assert result.target == version
    assert result.dependencies == dependencies


# Generated at 2022-06-12 04:26:11.995496
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse('pass').body, True, ['xyz']).\
           dependencies == ['xyz']

# Function that runs a transformation

# Generated at 2022-06-12 04:26:19.645438
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io1 = InputOutput(Path('input1'), Path('output1'))
    assert io1.input == Path('input1')
    assert io1.output == Path('output1')
    io2 = InputOutput(Path('input2'), Path('output2'))
    assert io2.input == Path('input2')
    assert io2.output == Path('output2')
    io3 = InputOutput(input=Path('input3'), output=Path('output3'))
    assert io3.input == Path('input3')
    assert io3.output == Path('output3')


# Generated at 2022-06-12 04:26:22.504896
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('/tmp/foo'),
                       Path('/tmp/bar')).input == Path('/tmp/foo')
    assert InputOutput(Path('/tmp/foo'),
                       Path('/tmp/bar')).output == Path('/tmp/bar')


# Generated at 2022-06-12 04:26:26.594336
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/name')
    output = Path('/output/tmp')
    pair = InputOutput(input, output)
    assert input == pair.input
    assert output == pair.output



# Generated at 2022-06-12 04:26:29.440756
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(None, True, [])
    assert (tr.tree_changed is True)
    assert (tr.tree is None)
    assert (tr.dependencies == [])

# Generated at 2022-06-12 04:26:32.669142
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = InputOutput(Path("abcde"), Path("fgh"))
    assert i.input == Path("abcde")
    assert i.output == Path("fgh")

# Generated at 2022-06-12 04:26:43.634326
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1, time=1.0,
                                           target=(3,6),
                                           dependencies=set(['file1.py', 'file2.py']))
    assert compilation_result.files == 1
    assert compilation_result.time == 1.0
    assert compilation_result.target == (3, 6)
    assert compilation_result.dependencies == ['file1.py', 'file2.py']


# Generated at 2022-06-12 04:26:48.296531
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Type checking
    a = InputOutput(Path('test.py'), Path('test.pyc'))
    assert type(a.input) == Path
    assert type(a.output) == Path

    # Value checking
    a = InputOutput(Path('test.py'), Path('test.pyc'))
    assert a.input == Path('test.py')
    assert a.output == Path('test.pyc')


# Generated at 2022-06-12 04:26:54.660725
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(tree=None, tree_changed=False, dependencies=[])
    assert result.tree is None
    assert not result.tree_changed
    assert len(result.dependencies) == 0


# Result of transformer execution
ExecutionResult = NamedTuple('ExecutionResult',
                             [('code', str),
                              ('changed', bool),
                              ('dependencies', List[str])])


# Generated at 2022-06-12 04:27:04.841962
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Test InputOutput with Paths
    a = Path('a')
    b = Path('b')
    x = InputOutput(a, b)
    assert x.input is a
    assert x.output is b
    # Test InputOutput with strings
    x = InputOutput('a', 'b')
    assert x.input == a
    assert x.output == b
    # Test with invalid arguments
    with pytest.raises(TypeError) as excinfo:
        x = InputOutput(1, 2)
    assert 'must be str, Path or None' in str(excinfo.value)

    with pytest.raises(TypeError) as excinfo:
        x = InputOutput(a, 2)
    assert 'must be str, Path or None' in str(excinfo.value)


# Generated at 2022-06-12 04:27:11.008298
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_dict = {'input': 'f1.py', 'output': 'f1.pyc'}
    tmp_pair = InputOutput(**test_dict)
    assert tmp_pair.input.name == 'f1.py'
    assert tmp_pair.output.name == 'f1.pyc'
    assert len(tmp_pair) == 2

# Generated at 2022-06-12 04:27:14.022652
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput('some input', 'some output')
    assert input_output.input == 'some input'
    assert input_output.output == 'some output'

if __name__ == '__main__':
    test_InputOutput()

# Generated at 2022-06-12 04:27:16.305991
# Unit test for constructor of class TransformationResult
def test_TransformationResult(): # type: () -> None
    assert TransformationResult(ast.parse('1'), False, ['foo', 'bar'])

# Generated at 2022-06-12 04:27:18.814366
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = InputOutput(Path("in"), Path("out"))
    assert input.input == Path("in")
    assert input.output == Path("out")

# Generated at 2022-06-12 04:27:21.123379
# Unit test for constructor of class CompilationResult
def test_CompilationResult():  # type: () -> None
    assert CompilationResult(1, 2.0, (3, 4), ['a'])


# Generated at 2022-06-12 04:27:25.977553
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # static typing for CompilationResult class
    res = CompilationResult(0, 0, (3, 6), [])
    assert res.files == 0
    assert res.time == 0.0
    assert res.target == (3, 6)
    assert res.dependencies == []
    assert 'target' in res._fields
    assert 'dependencies' in res._fields

# Generated at 2022-06-12 04:27:38.152044
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=10, time=1.0, target=(3, 7), dependencies=[])
    assert c.files == 10
    assert c.time == 1.0
    assert c.target == (3, 7)
    assert c.dependencies == []


# Generated at 2022-06-12 04:27:40.014455
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=0.5, target=(1, 2), dependencies=[])



# Generated at 2022-06-12 04:27:42.485808
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(5, 0.5, (3, 7), ['foo', 'bar'])
    assert res.target == (3, 7)
    assert res.time == 0.5


# Generated at 2022-06-12 04:27:46.057326
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = 'x.py'
    b = 'y.py'
    input_output = InputOutput(Path(a), Path(b))
    assert input_output.input.name == a
    assert input_output.output.name == b


# Generated at 2022-06-12 04:27:49.971013
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1,
                           time=10,
                           target=(3, 6),
                           dependencies=[])
    assert cr.files == 1
    assert cr.time == 10
    assert cr.target == (3, 6)
    assert not cr.dependencies


# Generated at 2022-06-12 04:27:51.320303
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=None, tree_changed=False, dependencies=[])

# Generated at 2022-06-12 04:27:56.129400
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # type: () -> None
    i, o = InputOutput(Path('input.py'), Path('output.py'))
    assert str(i) == 'input.py'
    assert str(o) == 'output.py'
    assert i.samefile(Path('input.py'))
    assert o.samefile(Path('output.py'))

# Generated at 2022-06-12 04:27:59.001599
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('in')
    output = Path('out')
    pair = InputOutput(input_, output)
    assert pair.input == input_ and pair.output == output


# Generated at 2022-06-12 04:28:03.526104
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    inp = ast.parse('''
    def foo(x, y):
        pass
    ''')

    res = TransformationResult(inp, True, ['test'])
    assert res.__doc__ == 'Result of transformers transformation'
    assert res.tree is inp
    assert res.tree_changed is True
    assert res.dependencies == ['test']

# Generated at 2022-06-12 04:28:05.605502
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # pylint: disable=no-member
    assert InputOutput(input=Path('a'), output=Path('b')) == InputOutput(Path('a'), Path('b'))



# Generated at 2022-06-12 04:28:26.542980
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(1, 1.0, (2, 3), ["a"])
    assert res.files == 1
    assert res.time == 1.0
    assert res.target == (2, 3)
    assert res.dependencies == ["a"]


# Generated at 2022-06-12 04:28:30.939954
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr1 = TransformationResult(None, False, None)
    assert tr1.tree is None
    assert tr1.tree_changed == False
    assert tr1.dependencies is None

    tr2 = TransformationResult(None, True, ['foo'])
    assert tr2.tree is None
    assert tr2.tree_changed
    assert tr2.dependencies == ['foo']

# Generated at 2022-06-12 04:28:33.535358
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path = Path('/tmp/foo')
    input_output = InputOutput(input=path,
                               output=path)
    assert(input_output.input == path and
           input_output.output == path)


# Generated at 2022-06-12 04:28:36.855656
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(ast.parse('a = 2'),
                                  True,
                                  ['b', 'c'])

    assert result.tree.body[0].value.n == 2
    assert result.tree_changed == True
    assert result.dependencies == ['b', 'c']

# Generated at 2022-06-12 04:28:38.851697
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.Name(id="foo", ctx=ast.Load()), tree_changed=True, dependencies=[])


# Generated at 2022-06-12 04:28:40.566015
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 0.2, (3, 5), [])


# Generated at 2022-06-12 04:28:45.133994
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(files=0, time=0, target=(3, 5), dependencies=[])
    assert r.files == 0
    assert r.time == 0
    assert r.target == (3, 5)
    assert r.dependencies == []


# Generated at 2022-06-12 04:28:45.941253
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.parse('pass'), True, ['some.py'])

# Generated at 2022-06-12 04:28:49.498762
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(1, 2.0, (3, 4), ['a', 'b'])
    assert c.files == 1
    assert c.time == 2.0
    assert c.target == (3, 4)
    assert c.dependencies == ['a', 'b']


# Generated at 2022-06-12 04:28:55.070738
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    tree_changed = True
    dependencies = ['a.py']

    o = TransformationResult(tree, tree_changed, dependencies)

    assert o.tree == tree
    assert o.tree_changed == tree_changed
    assert o.dependencies == dependencies


# Result of checkers verification
VerificationResult = NamedTuple('VerificationResult',
                                [('tree_changed', bool),
                                 ('violations', List[str])])


# Generated at 2022-06-12 04:29:17.512127
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i_o = InputOutput(Path('/tmp/input'), Path('/tmp/output'))
    assert i_o.input == Path('/tmp/input')
    assert i_o.output == Path('/tmp/output')


# Generated at 2022-06-12 04:29:20.699996
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1337, 42.0, (3, 7), [])
    assert result.files == 1337
    assert result.time == 42.0
    assert result.target == (3, 7)
    assert result.dependencies == []


# Generated at 2022-06-12 04:29:23.440920
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=123, time=12.34, target=(3, 4), dependencies=['a', 'b'])

# Generated at 2022-06-12 04:29:27.994299
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=1,
                          time=0.2,
                          target=(3, 7),
                          dependencies=['module.py'])
    assert c.files == 1
    assert c.time == 0.2
    assert c.target == (3, 7)
    assert c.dependencies == ['module.py']


# Unit tests for constructor of class InputOutput

# Generated at 2022-06-12 04:29:28.919144
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.parse(''), False, [])

# Generated at 2022-06-12 04:29:36.070716
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('test_input.py')
    output = Path('test_output.py')
    assert InputOutput(input, output) == InputOutput(input, output)
    assert InputOutput(input, output) != InputOutput(input, input)
    assert InputOutput(input, output) != InputOutput(output, output)
    assert InputOutput(input, output) != object()
    assert InputOutput(input, output) != None
    assert InputOutput(input, output) == eval(repr(InputOutput(input, output)))
    assert str(InputOutput(input, output)) == "InputOutput(input='%s', output='%s')" % (str(input), str(output))


# Generated at 2022-06-12 04:29:38.623018
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=5, time=0.5, target=(3,7),
                      dependencies=['/tmp/test/test.py',
                                    '/tmp/test/test2.py'])


# Generated at 2022-06-12 04:29:39.724272
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast.parse('')
    TransformationResult(ast.parse(''), False, [])

# Generated at 2022-06-12 04:29:42.035294
# Unit test for constructor of class InputOutput
def test_InputOutput():
  input = Path('foo')
  output = Path('bar')
  foo = InputOutput(input, output)
  assert foo.input == input
  assert foo.output == output


# Generated at 2022-06-12 04:29:45.472011
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert sum(x.tree_changed for x in [TransformationResult(ast.parse('1 + 1'), True, []),
                                        TransformationResult(ast.parse('1 + 1'), False, [])]) == 1


# Result of analysis
AnalysisResult = NamedTuple('AnalysisResult',
                            [('usage', Dict[str, List[str]]),
                             ('dependencies', List[str])])


# Generated at 2022-06-12 04:30:34.881562
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.parse('pass'),
                         True, ['a.py', 'b.py', 'c.py'])
                        

# Generated at 2022-06-12 04:30:38.397767
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=5, time=5.5, target=(3, 6), dependencies=[])
    assert c.files == 5
    assert c.time == 5.5
    assert c.target == (3, 6)
    assert c.dependencies == []


# Generated at 2022-06-12 04:30:43.066609
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=5,
                            time=2.5,
                            target=(2, 7),
                            dependencies=['a.py', 'b.py'])
    assert res.files == 5
    assert res.time == 2.5
    assert res.target == (2, 7)
    assert res.dependencies == ['a.py', 'b.py']



# Generated at 2022-06-12 04:30:45.117957
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('input'), Path('output')).input == Path('input')
    assert InputOutput(Path('input'), Path('output')).output == Path('output')


# Generated at 2022-06-12 04:30:49.106947
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Arrange
    input_path = Path('a/b.c')
    output_path = Path('a/b.d')

    # Act
    input_output = InputOutput(input_path, output_path)

    # Assert
    assert input_output.input == input_path
    assert input_output.output == output_path

# Generated at 2022-06-12 04:30:50.881140
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=1, time=1.5,
                             target=(2, 7), dependencies=['/tmp/f'])



# Generated at 2022-06-12 04:30:54.531076
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 0')
    tree_changed = True
    dependencies = []
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-12 04:30:57.888231
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: ignore
    tree = ast.AST()
    tree_changed = True
    dependencies = []

    t = TransformationResult(tree, tree_changed, dependencies)

    assert t.tree == tree
    assert t.tree_changed == tree_changed
    assert t.dependencies == dependencies

# Generated at 2022-06-12 04:31:02.166344
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 1
    time = 2
    target = (3, 4)
    dependencies = ["a", "b"]
    cr = CompilationResult(files, time, target, dependencies)
    assert cr.files == files
    assert cr.time == time
    assert cr.target == target
    assert cr.dependencies == dependencies

# Generated at 2022-06-12 04:31:05.532496
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    x = InputOutput(input, output)
    assert x.input == input
    assert x.output == output
    assert str(x) == "InputOutput(input=PosixPath('input'), output=PosixPath('output'))"

# Generated at 2022-06-12 04:32:56.835157
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2, (3, 4), ['5', '6'])


# Generated at 2022-06-12 04:32:58.653123
# Unit test for constructor of class InputOutput
def test_InputOutput():
    with pytest.raises(AssertionError):
        InputOutput(Path('nonexistent'), Path('nonexistent2'))



# Generated at 2022-06-12 04:33:06.037922
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=2, target=(3, 4), dependencies=['1', '2', '3'])
    assert result.files == 1
    assert result.time == 2
    assert result.target == (3, 4)
    assert result.dependencies == ['1', '2', '3']

    # Check if tuple constructor is exist
    assert result == result._make((1, 2, (3, 4), ['1', '2', '3']))

    # Check if tuple can be converted to dict
    assert dict(result._asdict()) == {'time': 2,
                                      'target': (3, 4),
                                      'dependencies': ['1', '2', '3'],
                                      'files': 1}

    # Check if serialization/deserialization works
    assert CompilationResult._make

# Generated at 2022-06-12 04:33:07.754057
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('inp')
    out = Path('out')
    InputOutput(inp, out)


# Generated at 2022-06-12 04:33:09.296251
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(tree=None, tree_changed=False, dependencies=None)
    assert result

# Generated at 2022-06-12 04:33:11.622425
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    i_o = InputOutput(input, output)
    assert i_o.input == input
    assert i_o.output == output

# Generated at 2022-06-12 04:33:17.967671
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Should work
    CompilationResult(files=1, time=1.1, target=(3,7), dependencies=['foo'])

    # Should fail
    try:
        CompilationResult(files=1, time=-1, target=(3,7), dependencies=['foo'])
    except TypeError as e:
        assert 'unexpected keyword argument' in str(e)

    try:
        CompilationResult(files=1, time=1.1, target=(3,7), dependencies=42)
    except TypeError as e:
        assert 'unexpected keyword argument' in str(e)


# Generated at 2022-06-12 04:33:20.753971
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path('toto.py')
    path2 = Path('titi.py')
    io = InputOutput(path1, path2)
    assert io.input == path1
    assert io.output == path2

# Generated at 2022-06-12 04:33:25.014605
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    obj = CompilationResult(files=10, time=12.3, target=(3, 6), dependencies=['a.py'])
    assert obj.files == 10
    assert obj.time == 12.3
    assert obj.target == (3, 6)
    assert obj.dependencies == ['a.py']


# Generated at 2022-06-12 04:33:27.655766
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('__init__.py')
    output = Path('__init__.pyc')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output

