

# Generated at 2022-06-12 04:25:24.224507
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert isinstance(CompilationResult(0, 0.0, (3, 5), []), CompilationResult)
    assert CompilationResult(0, 0.0, (3, 5), []) == CompilationResult(0, 0.0, (3, 5), [])
    assert CompilationResult(0, 0.0, (3, 5), []) != CompilationResult(0, 0.0, (3, 5), ['foo'])


# Generated at 2022-06-12 04:25:28.342447
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    import ast
    import os

    os.environ['PYTHONPATH'] = '.'
    test_tree = ast.parse('import os')

    assert TransformationResult(test_tree,
                                True,
                                ['os']) == TransformationResult(test_tree,
                                                                True,
                                                                ['os'])

# Generated at 2022-06-12 04:25:30.383245
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('/tmp/in'), Path('/tmp/out'))

# Test for constructor of class TransformationResult

# Generated at 2022-06-12 04:25:33.838336
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('/a/b.py'), Path('/c.py')).input == Path('/a/b.py')
    assert InputOutput(Path('/a/b.py'), Path('/c.py')).output == Path('/c.py')


# Generated at 2022-06-12 04:25:39.561848
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    args = 5, 2.0, (3, 6), ['foo', 'bar']
    compilation_result = CompilationResult(*args)
    files, time, target, dependencies = args
    assert compilation_result.files == files
    assert compilation_result.time == time
    assert compilation_result.target == target
    assert compilation_result.dependencies == dependencies
    assert str(compilation_result) == '<CompilationResult: 5 files, 2.0s, Python 3.6, {\'bar\', \'foo\'}>'


# Generated at 2022-06-12 04:25:42.014565
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('test_in')
    outp = Path('test_out')
    p = InputOutput(inp, outp)
    assert p.input == inp
    assert p.output == outp

# Generated at 2022-06-12 04:25:45.435224
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # type: () -> None
    a = InputOutput(Path("abc"), Path("def"))
    assert str(a.input) == "abc"
    assert str(a.output) == "def"

# Generated at 2022-06-12 04:25:48.545161
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('tmp/input.py')
    output = Path('tmp/output.py')
    assert (input == InputOutput(input, output).input)
    assert (output == InputOutput(input, output).output)

# Generated at 2022-06-12 04:25:49.568538
# Unit test for constructor of class TransformationResult

# Generated at 2022-06-12 04:25:51.363276
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(2, 3, (3, 4), [])


# Generated at 2022-06-12 04:25:55.334944
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=2, time=0.1,
                      target=(3, 5), dependencies=['a', 'b'])

# Generated at 2022-06-12 04:25:57.979228
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('/directory/source.py')
    out = Path('/directory/source.pyc')

    pair = InputOutput(input=inp, output=out)
    assert pair.input == inp
    assert pair.output == out

# Generated at 2022-06-12 04:26:00.377393
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("def fn(): pass")
    result = TransformationResult(tree, True, ["a", "b"])
    assert(result.tree_changed)
    assert(result.tree == tree)
    assert(result.dependencies == ["a", "b"])

# Generated at 2022-06-12 04:26:04.463915
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Arrange
    input = Path('/input')
    output = Path('/output')

    # Act
    input_output = InputOutput(input, output)

    # Assert
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-12 04:26:07.444946
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(
        tree=ast.parse("4 + 5"),
        tree_changed=False,
        dependencies=[]
    )

# Generated at 2022-06-12 04:26:09.195999
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path("test/input")
    output = Path("test/output")
    test_data = InputOutput(input, output)
    assert test_data.input == input
    assert test_data.output == output

# Generated at 2022-06-12 04:26:12.018233
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = '/tmp/input.py'
    output = '/tmp/output.py'
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-12 04:26:15.142825
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=3,
                             time=1.12,
                             target=(3, 7),
                             dependencies=['mod1', 'mod2'])


# Generated at 2022-06-12 04:26:15.713812
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert False

# Generated at 2022-06-12 04:26:23.605365
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from datetime import datetime
    from node_visitor.visitor import extract_dependencies

    assert TransformationResult(tree='<ast>', tree_changed=True,
                                dependencies=['a.py']).dependencies == ['a.py']
    assert TransformationResult(tree='<ast>', tree_changed=True,
                                dependencies=['a.py']).tree_changed is True
    assert TransformationResult(tree='<ast>', tree_changed=False,
                                dependencies=['a.py']).tree_changed is False
    assert TransformationResult(tree='<ast>', tree_changed=True,
                                dependencies=['a.py']).tree == '<ast>'

    with open('a.py') as f:
        tree = ast.parse(f.read())

    tree = ast.fix_missing_locations

# Generated at 2022-06-12 04:26:32.797783
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Type check
    CompilationResult(0, 0, (3, 7), [])

    # Value check
    assert CompilationResult(0, 0, (3, 7), []).files == 0
    assert CompilationResult(0, 0, (3, 7), []).time == 0
    assert CompilationResult(0, 0, (3, 7), []).target == (3, 7)
    assert CompilationResult(0, 0, (3, 7), []).dependencies == []


# Generated at 2022-06-12 04:26:35.195578
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input.txt')
    output = Path('output.txt')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output

# Generated at 2022-06-12 04:26:43.419050
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    source_py_file = Path(__file__).parent / 'test' / 'test_source.py'
    assert source_py_file.exists()
    assert source_py_file.is_file()
    source_py = source_py_file.read_bytes().decode('utf-8')
    source_ast = ast.parse(source_py)
    source_ast_modified = source_ast
    transformed = TransformationResult(source_ast_modified, True, [])
    assert transformed.tree is source_ast_modified
    assert transformed.tree_changed
    assert transformed.dependencies is not None

# Generated at 2022-06-12 04:26:47.035749
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    comp = CompilationResult(files=10, time=20.0, target=(3, 5), dependencies=[])
    assert comp.files == 10
    assert comp.time == 20.0
    assert comp.target == (3, 5)
    assert comp.dependencies == []


# Generated at 2022-06-12 04:26:56.236680
# Unit test for constructor of class CompilationResult
def test_CompilationResult():  # type: () -> None
    """
    >>> CompilationResult(files = 1, time = 0.1, target = (3, 6), dependencies = []).files
    1
    >>> CompilationResult(files = 1, time = 0.1, target = (3, 6), dependencies = []).time
    0.1
    >>> CompilationResult(files = 1, time = 0.1, target = (3, 6), dependencies = []).target
    (3, 6)
    >>> CompilationResult(files = 1, time = 0.1, target = (3, 6), dependencies = []).dependencies
    []
    """
    pass


# Generated at 2022-06-12 04:26:57.733295
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(Path('input'), Path('output'))



# Generated at 2022-06-12 04:27:03.336490
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    a = ('tree', ast.AST, ast3.AST)
    b = ('tree_changed', ast.AST, ast3.AST)
    c = ('dependencies', List[str])
    d = TransformationResult(a, b, c)
    assert isinstance(d.tree, ast.AST)
    assert isinstance(d.tree_changed, ast.AST)
    assert isinstance(d.dependencies, List)

# Generated at 2022-06-12 04:27:08.197370
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 2')
    tree_changed = True
    dependencies = ['foo', 'bar']
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree is tree
    assert result.tree_changed is tree_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-12 04:27:13.244999
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(
        files=1,
        time=2,
        target=(3, 4),
        dependencies=['a', 'b', 'c'])
    assert result.files == 1
    assert result.time == 2
    assert result.target == (3, 4)
    assert result.dependencies == ['a', 'b', 'c']


# Generated at 2022-06-12 04:27:19.198553
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    _, _, _ = TransformationResult(ast.AST(), True, [])

# Type of transformation function
TransformationFunction = Tuple[ast.AST, Callable]

# Type of predicated transformation function
TransformationPredicatedFunction = Tuple[ast.AST, Callable, Callable]

# Type of external transformation function
ExternalTransformationFunction = Callable[[InputOutput], InputOutput]


# Generated at 2022-06-12 04:27:28.256675
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    path = Path('a.py')
    compilation_result = CompilationResult(files=1, time=3.4, target=(3, 7),
                                           dependencies=[path.as_posix()])
    assert compilation_result.files == 1
    assert compilation_result.time == 3.4
    assert compilation_result.target == (3, 7)
    assert compilation_result.dependencies == [path.as_posix()]



# Generated at 2022-06-12 04:27:31.511458
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test_tree = ast.parse('x = 1')
    test_tree_changed = True
    test_dependencies = ['one', 'two', 'three']
    TransformationResult(test_tree,
                         test_tree_changed,
                         test_dependencies)

# Generated at 2022-06-12 04:27:34.406527
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('/path/to/input')
    output = Path('/path/to/output')

    predicate = lambda x: isinstance(x, InputOutput)

    assert predicate(InputOutput(input_, output))


# Generated at 2022-06-12 04:27:39.134543
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=100,
                               time=3.14,
                               target=(3, 7),
                               dependencies=['f1', 'f2'])
    assert result.files == 100
    assert result.time == 3.14
    assert result.target == (3, 7)
    assert result.dependencies == ['f1', 'f2']


# Generated at 2022-06-12 04:27:42.215123
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    r = TransformationResult(ast.Module([]), False, [])
    assert isinstance(r.tree, ast.AST)
    assert isinstance(r.tree_changed, bool)
    assert isinstance(r.dependencies, list)


# Generated at 2022-06-12 04:27:47.494202
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = 'input'
    output = 'output'
    assert InputOutput(input, output) == InputOutput(input, output)
    assert InputOutput(input, output) != InputOutput('x', 'y')

    assert InputOutput(input, output).input == input
    assert InputOutput(input, output).output == output

    assert repr(InputOutput(input, output)) == \
        "InputOutput(input='input', output='output')"


# Generated at 2022-06-12 04:27:53.895798
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse("x = 3")
    r = TransformationResult(tree=t, tree_changed=False, dependencies=[])
    assert r.tree == t
    assert r.tree_changed == False
    assert r.dependencies == []


# Result of evaluator
EvaluationResult = NamedTuple('EvaluationResult',
                              [('top_level_variable_names', List[str]),
                               ('top_level_variable_values', List[str])])


# Generated at 2022-06-12 04:27:59.655606
# Unit test for constructor of class InputOutput
def test_InputOutput():
    try:
        InputOutput('test', 'test')
        assert False
    except TypeError:
        pass

    try:
        InputOutput(Path('test'), 'test')
        assert False
    except TypeError:
        pass

    try:
        InputOutput('test', Path('test'))
        assert False
    except TypeError:
        pass

    assert InputOutput(Path('test'), Path('test'))



# Generated at 2022-06-12 04:28:06.166046
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    path = './test'
    result = TransformationResult(tree=tree, tree_changed=True,
                                  dependencies=[path])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == [path]

# Result of transformers.Transformer.rename_module()
RenameResult = NamedTuple('RenameResult',
                          [('tree', ast.AST),
                           ('original_module_name', str),
                           ('new_module_name', str),
                           ('dependencies', List[str])])


# Generated at 2022-06-12 04:28:11.047498
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(1, 2.0, (3, 4), ['a', 'b', 'c'])
    assert compilation_result.files == 1
    assert compilation_result.time == 2.0
    assert compilation_result.target == (3, 4)
    assert compilation_result.dependencies == ['a', 'b', 'c']


# Generated at 2022-06-12 04:28:24.599347
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1, time=2.0, target=(3, 4),
                                           dependencies=['1.py', '2.py'])
    assert compilation_result.files == 1
    assert compilation_result.time == 2.0
    assert compilation_result.target == (3, 4)
    assert compilation_result.dependencies == ['1.py', '2.py']


# Generated at 2022-06-12 04:28:26.661403
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # type: () -> None
    CompilationResult(1, 2.0, (3, 4), [])


# Generated at 2022-06-12 04:28:31.013571
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c_result = CompilationResult(files=1, time=0.1, target=(3, 5),
                                 dependencies=['a', 'b'])
    assert c_result.files == 1
    assert c_result.time == 0.1
    assert c_result.target == (3, 5)
    assert c_result.dependencies == ['a', 'b']


# Generated at 2022-06-12 04:28:33.603826
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = 'input'
    output_ = 'output'
    io = InputOutput(input=input_, output=output_)
    assert io.input == input_
    assert io.output == output_


# Generated at 2022-06-12 04:28:35.637906
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    TransformationResult(tree=ast.parse('pass'),
                         tree_changed=True,
                         dependencies=['/some/file'])

# Generated at 2022-06-12 04:28:37.875549
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert (InputOutput(Path('input'), Path('output')) ==
            InputOutput(input=Path('input'), output=Path('output')))



# Generated at 2022-06-12 04:28:40.428145
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    "Unit test for TransformationResult"
    tree = ast.parse("pass")
    assert TransformationResult(tree, False, [])
    assert TransformationResult(tree, True, [])
    assert TransformationResult(tree, True, ["foo.py"])


# Generated at 2022-06-12 04:28:44.046702
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('')
    output = Path('')
    pair = InputOutput(input, output)

    assert pair.input == input
    assert pair.output == output

# Generated at 2022-06-12 04:28:47.641114
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=2, time=2.1,
                                           target=(3, 4),
                                           dependencies=['a', 'b'])
    assert compilation_result.files == 2
    assert compilation_result.time == 2.1
    assert compilation_result.target == (3, 4)
    assert compilation_result.dependencies == ['a', 'b']


# Generated at 2022-06-12 04:28:51.827356
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1,
                               target=(3, 6), dependencies=[])
    assert isinstance(result, CompilationResult)
    assert result.files == 1
    assert result.time == 1
    assert result.target == (3, 6)
    assert result.dependencies == []


# Generated at 2022-06-12 04:29:15.183393
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(2, 3), dependencies=list())
    assert result.files == 1
    assert result.time >= 0.0
    assert result.target == (2, 3)
    assert result.dependencies == list()


# Generated at 2022-06-12 04:29:16.704252
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 1.0, (3, 6), ["dep1", "dep2"])


# Generated at 2022-06-12 04:29:19.589671
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_tree = ast.parse("1+1")
    result = TransformationResult(ast_tree, True, [])
    assert result.tree == ast_tree
    assert result.tree_changed
    assert result.dependencies == []

# Generated at 2022-06-12 04:29:20.799421
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, False, []) == TransformationResult(None, False, [])

# Generated at 2022-06-12 04:29:24.449372
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path('path1')
    path2 = Path('path2')
    input_output = InputOutput(input=path1, output=path2)
    assert input_output.input == path1
    assert input_output.output == path2

# Generated at 2022-06-12 04:29:25.859057
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # pragma: no cover
    assert TransformationResult(ast.parse('1'), False, ['a'])

# Generated at 2022-06-12 04:29:27.872690
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("1+2")
    tr = TransformationResult(tree, False, ['a.py'])



# Generated at 2022-06-12 04:29:32.126653
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 42
    time = 1.1
    target = (3, 5)
    dependencies = []

    res = CompilationResult(files, time, target, dependencies)
    assert res.files == files
    assert res.time == time
    assert res.target == target
    assert res.dependencies == dependencies
    assert res.dependencies is dependencies


# Generated at 2022-06-12 04:29:36.645761
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # successful
    input_output = InputOutput(input=Path("test.py"), output=Path("test.pyc"))
    assert input_output.input == Path("test.py")
    assert input_output.output == Path("test.pyc")

    # failed
    try:
        InputOutput(input="test.py", output="test.pyc")
    except TypeError:
        pass
    else:
        # this should not run
        assert False

# Generated at 2022-06-12 04:29:39.762795
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    tree_changed = True
    dependencies = []
    tr = TransformationResult(tree, tree_changed, dependencies)
    assert tr.tree == tree
    assert tr.tree_changed == tree_changed
    assert tr.dependencies == dependencies

# Generated at 2022-06-12 04:30:35.197136
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=42, time=3.14, target=(3, 5), dependencies=['a/b/c', 'd/e/f']) == \
           CompilationResult(files=42, time=3.14, target=(3, 5), dependencies=['a/b/c', 'd/e/f'])
    assert not (CompilationResult(files=42, time=3.14, target=(3, 5), dependencies=['a/b/c', 'd/e/f']) ==
                CompilationResult(files=42, time=3.14, target=(3, 6), dependencies=['a/b/c', 'd/e/f']))


# Generated at 2022-06-12 04:30:38.675607
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(5, 10.5, (3, 7), [])
    assert res.time == 10.5
    assert res.target == (3, 7)
    assert res.dependencies == []

# Unit tests for constructor of class InputOutput

# Generated at 2022-06-12 04:30:45.222400
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("print('Hello world')")
    result = TransformationResult(tree=tree,
                                  tree_changed=True,
                                  dependencies=[])
    assert isinstance(result, TransformationResult)
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == []

# Result of transformers processing
ProcessingResult = NamedTuple('ProcessingResult',
                              [('input_and_transformed_output', InputOutput),
                               ('input_and_untransformed_output', InputOutput),
                               ('was_unnecessary', bool)])


# Generated at 2022-06-12 04:30:46.812203
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 0.1, (3, 5), [])


# Generated at 2022-06-12 04:30:49.143016
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("pass")
    dependencies = ["1", "2"]
    TransformationResult(tree, True, dependencies)
    TransformationResult(tree, False, dependencies)


# Generated at 2022-06-12 04:30:52.185514
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(1, 2, (3, 4), ['A', 'B'])
    assert c.files == 1
    assert c.time == 2
    assert c.target == (3, 4)
    assert c.dependencies == ['A', 'B']

# Generated at 2022-06-12 04:30:57.052976
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(files=2,
                          time=3.0,
                          target=(3, 5),
                          dependencies=['./foo', './bar'])
    assert r.files == 2
    assert r.time == 3.0
    assert r.target == (3, 5)
    assert r.dependencies == ['./foo', './bar']


# Generated at 2022-06-12 04:31:01.385755
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    dependencies = ['a.py', 'b.py']
    result = CompilationResult(1, 0.1, (3, 7), dependencies)
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 7)
    assert result.dependencies == dependencies


# Generated at 2022-06-12 04:31:02.200152
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('1'), Path('2'))

# Generated at 2022-06-12 04:31:03.577108
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(Path('inputs/example.py'), Path('outputs/example.py'))

# Generated at 2022-06-12 04:32:51.392795
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    class FakeTree(ast.AST): pass
    tr = TransformationResult(tree=FakeTree(),
                              tree_changed=True,
                              dependencies=[])
    assert isinstance(tr.tree, FakeTree)
    assert isinstance(tr.tree_changed, bool)
    assert isinstance(tr.dependencies, list)

# Generated at 2022-06-12 04:32:54.964794
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    target = 3, 7
    dependencies = ['a', 'b']
    cr = CompilationResult(files=1, time=0.2, target=target,
                           dependencies=dependencies)
    assert cr.files == 1
    assert cr.time == 0.2
    assert cr.target == target
    assert cr.dependencies == dependencies


# Generated at 2022-06-12 04:32:59.794348
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Success
    assert InputOutput(input=Path('a.py'), output=Path('b.py'))

    # Failure
    with pytest.raises(AttributeError) as e_info:
        InputOutput(input=Path('a.py'))
        assert "missing 2 required positional arguments" in str(e_info.value)

# Unit tests for constructor of class TransformationResult

# Generated at 2022-06-12 04:33:02.986479
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res: TransformationResult = TransformationResult(tree=ast.Module(),
                                                      tree_changed=False,
                                                      dependencies=[])
    res.tree_changed
    res.dependencies
    res.tree

# Generated at 2022-06-12 04:33:05.418553
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 2.0, (3, 4), ['foo', 'bar'])


# Generated at 2022-06-12 04:33:13.748411
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('print "Hello World!"')
    tr = TransformationResult(tree, True, [])
    assert tr
    assert isinstance(tr.tree, ast.AST)
    assert tr.tree_changed
    assert tr.dependencies == []
    tr2 = TransformationResult(tree, False, [])
    assert not tr2.tree_changed
    tr3 = TransformationResult(tree, True, ['a', 'b', 'c'])
    assert tr3.dependencies == ['a', 'b', 'c']

# Generated at 2022-06-12 04:33:17.485945
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('foo/bar/bash.py')
    output = Path('foo/bar/baz.py')
    input_output = InputOutput(input, output)
    assert isinstance(input_output.input, Path)
    assert isinstance(input_output.output, Path)

# Constructor of class TransformationResult

# Generated at 2022-06-12 04:33:20.270135
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # pylint: disable=C0103
    assert InputOutput('input', 'output').input == Path('input')
    assert InputOutput('input', 'output').output == Path('output')


# Generated at 2022-06-12 04:33:23.089783
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('in.txt')
    output = Path('out.txt')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output

# Generated at 2022-06-12 04:33:30.819135
# Unit test for constructor of class InputOutput
def test_InputOutput():
    with pytest.raises(TypeError, match="__new__() missing 2 required positional arguments"):
        InputOutput()
    with pytest.raises(TypeError, match="__new__() missing 1 required positional argument"):
        InputOutput(1)
    with pytest.raises(TypeError, match="__new__() takes exactly 3 arguments"):
        InputOutput(1, 2, 3)
    with pytest.raises(TypeError, match="__new__() got multiple values for argument 'input'"):
        InputOutput(1, 2, output=1)
    with pytest.raises(TypeError, match="__new__() got multiple values for argument 'output'"):
        InputOutput(1, input=1, output=1)