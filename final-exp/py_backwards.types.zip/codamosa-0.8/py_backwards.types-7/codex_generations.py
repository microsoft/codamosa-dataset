

# Generated at 2022-06-12 04:25:16.441854
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=0,
                                           time=0.0,
                                           target=(3, 7),
                                           dependencies=["foo", "bar"])
    CompilationResult(**compilation_result._asdict())


# Generated at 2022-06-12 04:25:20.551720
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path(__file__)
    path2 = Path('{0}.pyc'.format(__file__))

    input_output = InputOutput(path1, path2)
    assert input_output.input == path1
    assert input_output.output == path2

    input_output = InputOutput(input=path1, output=path2)
    assert input_output.input == path1
    assert input_output.output == path2

# Generated at 2022-06-12 04:25:23.534445
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=[])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 6)
    assert result.dependencies == []


# Generated at 2022-06-12 04:25:26.835325
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(0, 0.0, (0, 0), [])
    assert result.files == 0
    assert result.time == 0.0
    assert result.target == (0, 0)
    assert result.dependencies == []


# Generated at 2022-06-12 04:25:30.788702
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path(__file__)
    output_path = input_path.parent / (input_path.name + '.pyc')
    obj = InputOutput(input=input_path,
                      output=output_path)
    assert obj.input == input_path
    assert obj.output == output_path

# Generated at 2022-06-12 04:25:34.881325
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Python code
    code1 = Path('/tmp/dir1')
    code2 = Path('/tmp/dir2')

    # Construct
    input_output = InputOutput(code1, code2)

    # Check
    assert input_output.input == code1
    assert input_output.output == code2



# Generated at 2022-06-12 04:25:40.867389
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # example InputOutput
    a = InputOutput(Path('a.py'), Path('b.py'))
    # __eq__
    assert a == InputOutput(Path('a.py'), Path('b.py'))
    # __ne__
    assert a != InputOutput(Path('x.py'), Path('b.py'))
    assert a != InputOutput(Path('a.py'), Path('x.py'))

# Generated at 2022-06-12 04:25:43.655568
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path("test1.py")
    path2 = Path("test2.py")
    test = InputOutput(path1, path2)
    assert test.input == path1
    assert test.output == path2


# Generated at 2022-06-12 04:25:46.769159
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast.parse('pass')
    TransformationResult(tree=None, tree_changed=False, dependencies=[])

# Generated at 2022-06-12 04:25:51.906141
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(
        files=4,
        time=1.0,
        target=(8, 0),
        dependencies=['foo', 'bar'])
    assert r.files == 4
    assert r.time == 1.0
    assert r.target == (8, 0)
    assert r.dependencies == ['foo', 'bar']


# Generated at 2022-06-12 04:25:56.941401
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Create InputOutput object
    obj = InputOutput(Path('input.py'), Path('output.py'))
    assert isinstance(obj.input, Path)
    assert isinstance(obj.output, Path)


# Generated at 2022-06-12 04:25:59.130428
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path('input')
    path2 = Path('output')
    result = InputOutput(path1, path2)
    assert result.input == path1
    assert result.output == path2

# Generated at 2022-06-12 04:26:01.479486
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(tree=None,
                             tree_changed=False,
                             dependencies=None)
    assert t.tree is None
    assert t.tree_changed is False
    assert t.dependencies is None

# Generated at 2022-06-12 04:26:03.869578
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from typed_ast import ast3 as ast
    n = ast.Name()
    TransformationResult(n, True, [])

# Generated at 2022-06-12 04:26:09.186916
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=42,
                               time=3.14,
                               target=(3, 6),
                               dependencies=['foo', 'bar'])
    assert result.files == 42
    assert result.time == 3.14
    assert result.target == (3, 6)
    assert result.dependencies == ['foo', 'bar']


# Generated at 2022-06-12 04:26:10.453048
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2, (3, 4), 5)


# Generated at 2022-06-12 04:26:12.159503
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(input=Path("/some/input/file.py"),
                output=Path("/some/output/file.py"))

# Generated at 2022-06-12 04:26:14.753798
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('input')
    o = Path('output')
    s = InputOutput(i, o)
    assert s.input == i
    assert s.output == o

# Generated at 2022-06-12 04:26:19.208686
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('test.py'), Path('test.pyc'))
    assert input_output.input == Path('test.py')
    assert input_output.output == Path('test.pyc')
    assert input_output.input.name == 'test.py'
    assert input_output.output.name == 'test.pyc'

# Generated at 2022-06-12 04:26:20.738816
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(Path('input.py'), Path('output.py'))  # type: ignore



# Generated at 2022-06-12 04:26:29.440728
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=2, target=(3, 4), dependencies=['5', '6'])
    assert cr.files == 1
    assert cr.time == 2
    assert cr.target == (3, 4)
    assert cr.dependencies == ['5', '6']


# Generated at 2022-06-12 04:26:32.668376
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    dependencies = ['a', 'b', 'c']
    result = TransformationResult(tree=None, tree_changed=False, dependencies=dependencies)
    assert result.dependencies == dependencies

# Generated at 2022-06-12 04:26:42.223822
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i_o_pairs = [
        InputOutput(Path('/a/b/c.py'), Path('/a/b/c.py.out')),
        InputOutput(Path('c.py'), Path('c.py.out')),
        InputOutput(Path('Guido'), Path('van/Rossum')),
        InputOutput(Path('/a/b'), Path('/a/c')),
    ]

    for i_o_pair in i_o_pairs:
        # Check properties
        assert i_o_pair.input != i_o_pair.output

        # Check constuctor
        assert i_o_pair == InputOutput(i_o_pair.input, i_o_pair.output)


# Generated at 2022-06-12 04:26:44.482260
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = True')
    tree_changed = True
    dependencies = ['a']
    TransformationResult(tree, tree_changed, dependencies)

# Generated at 2022-06-12 04:26:48.501986
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    import time
    res = CompilationResult(
        files=2,
        time=time.time() - time.time(),
        target=(2, 7),
        dependencies=['foo', 'bar'])
    assert res.files == 2
    assert res.time >= 0
    assert res.target == (2, 7)
    assert res.dependencies == ['foo', 'bar']


# Generated at 2022-06-12 04:26:51.115656
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('1+1')
    dependencies = ['a', 'b', 'c']
    TransformationResult(tree, True, dependencies)

# Generated at 2022-06-12 04:26:55.977023
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse("1+1"), True, []).tree == ast.parse("1+1")
    assert TransformationResult(ast.parse("1+1"), True, []).tree_changed == True
    assert TransformationResult(ast.parse("1+1"), True, []).dependencies == []



# Generated at 2022-06-12 04:26:59.442994
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> Unit
    tr = TransformationResult(ast.AST(), False, [])
    assert tr.tree is not None
    assert tr.tree_changed is False
    assert tr.dependencies is not None
    assert len(tr.dependencies) == 0

# Generated at 2022-06-12 04:27:07.018735
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Test the simplest possible case
    assert InputOutput('abc', 'def')

    # Test that both arguments can be strings
    assert InputOutput('abc', Path('def'))
    assert InputOutput(Path('abc'), 'def')

    # Test that both arguments can be pathlib.Path
    assert InputOutput(Path('abc'), Path('def'))

    # Test that both arguments must be strings or pathlib.Path
    with pytest.raises(AssertionError):
        InputOutput(1, 'def')
    with pytest.raises(AssertionError):
        InputOutput('abc', 2)
    with pytest.raises(AssertionError):
        InputOutput(1, 2)


# Generated at 2022-06-12 04:27:14.208889
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    data = [('tree', ast.parse("42")),
            ('tree_changed', True),
            ('dependencies', ['foo'])]
    result = TransformationResult(*data)
    for (field, value) in zip(result._fields, data):
        assert getattr(result, field) == value

# Result of non-transformers transformation
DirectTransformationResult = NamedTuple('DirectTransformationResult',
                                        [('output', str),
                                         ('output_changed', bool),
                                         ('dependencies', List[str])])

# Generated at 2022-06-12 04:27:25.169496
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # type: () -> None

    CompilationResult(0, 0, (0, 0), [])

# Generated at 2022-06-12 04:27:27.343818
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = InputOutput(Path("foo.py"), Path("bar.js"))
    assert (i.input.name == 'foo.py')
    assert (i.output.name == 'bar.js')


# Generated at 2022-06-12 04:27:29.980687
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path = Path('test.py')
    input_output = InputOutput(path, path)
    assert isinstance(input_output, InputOutput)
    assert input_output.input is input_output.output

# Generated at 2022-06-12 04:27:33.408288
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('3+3')
    result = TransformationResult(tree, False, ['dep1', 'dep2'])
    assert result.tree == tree
    assert result.tree_changed is False
    assert result.dependencies == ['dep1', 'dep2']

# Generated at 2022-06-12 04:27:35.965606
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput('input', 'output')
    assert isinstance(io.input, Path)
    assert isinstance(io.output, Path)


# Generated at 2022-06-12 04:27:39.977128
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.AST(), False, [])

# Result of running test cases
TestResult = NamedTuple('TestResult',
                                [('run_time', float),
                                 ('error', str),
                                 ('inputs', List[Path]),
                                 ('outputs', List[Path])])

# Generated at 2022-06-12 04:27:42.788440
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 2.0, (3, 4), [])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == []

# Generated at 2022-06-12 04:27:44.625411
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(2, 3.5, (2, 7), ['a', 'b'])

# Generated at 2022-06-12 04:27:46.952725
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 0, (2, 3), ['f1']) == CompilationResult(1, 0, (2, 3), ['f1'])


# Generated at 2022-06-12 04:27:52.110329
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1,
                                           time=1.1,
                                           target=(0, 0),
                                           dependencies=['a.py'])
    assert compilation_result.files == 1
    assert compilation_result.time == 1.1
    assert compilation_result.target == (0, 0)
    assert compilation_result.dependencies == ['a.py']


# Generated at 2022-06-12 04:28:02.204543
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult()



# Generated at 2022-06-12 04:28:04.178082
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Just execute constructor, this test doesn't verify anything
    CompilationResult(0, 0.0, (3, 8), [])


# Generated at 2022-06-12 04:28:08.066247
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path_in = Path('abc')
    path_out = Path('bca')

    io = InputOutput(path_in, path_out)
    assert io.input == path_in
    assert io.output == path_out

# Generated at 2022-06-12 04:28:11.166283
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_node = ast.Str('foo')
    tr = TransformationResult(ast_node, True, ['foo', 'bar'])
    assert tr.tree is ast_node
    assert tr.tree_changed is True
    assert tr.dependencies == ['foo', 'bar']

# Generated at 2022-06-12 04:28:15.752786
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    test_cr = CompilationResult(files=8, time=2.2,
                                target=(3, 7),
                                dependencies=['a', 'b'])
    assert test_cr.files == 8
    assert test_cr.time == 2.2
    assert test_cr.target == (3, 7)
    assert test_cr.dependencies == ['a', 'b']

# Unit tests for constructor of class InputOutput

# Generated at 2022-06-12 04:28:20.729423
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_input = Path("input.txt")
    test_output = Path("output.txt")
    test_io = InputOutput(test_input, test_output)
    assert test_io.input == Path("input.txt")
    assert test_io.output == Path("output.txt")
    assert isinstance(test_io.input, Path)
    assert isinstance(test_io.output, Path)



# Generated at 2022-06-12 04:28:24.137474
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('/a/b/c/d.txt')
    out = Path('/a/b/c/e.txt')
    inout = InputOutput(inp, out)
    assert inout.input == inp
    assert inout.output == out


# Generated at 2022-06-12 04:28:26.462644
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    assert InputOutput(input, output).input == input
    assert InputOutput(input, output).output == output


# Generated at 2022-06-12 04:28:29.052139
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path("inp")
    outp = Path("outp")
    inp_outp = InputOutput(input=inp, output=outp)
    assert inp_outp == (inp, outp)

# Generated at 2022-06-12 04:28:31.052058
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.AST(), True, [])
    tr.tree
    tr.tree_changed
    tr.dependencies


# Generated at 2022-06-12 04:28:54.772446
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=1.0, target=(3, 5), dependencies=['foo'])
    assert cr.files == 1
    assert cr.time == 1.0
    assert cr.target == (3, 5)
    assert cr.dependencies == ['foo']


# Generated at 2022-06-12 04:28:56.132754
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    r = TransformationResult(tree=None, tree_changed=False, dependencies=[])
    assert r is not None

# Generated at 2022-06-12 04:28:59.212402
# Unit test for constructor of class InputOutput
def test_InputOutput():
    file = Path('/tmp/input.py')
    output_file = Path('/tmp/output.py')
    input_output = InputOutput(input=file, output=output_file)
    assert input_output.input == file
    assert input_output.output == output_file

# Generated at 2022-06-12 04:29:06.384346
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(
        files=1,
        time=2,
        target=(3, 4),
        dependencies=['a']
    ) == CompilationResult(
        files=1,
        time=2,
        target=(3, 4),
        dependencies=['a']
    )
    assert CompilationResult(
        files=2,
        time=2,
        target=(3, 4),
        dependencies=['a']
    ) != CompilationResult(
        files=1,
        time=2,
        target=(3, 4),
        dependencies=['a']
    )

# Generated at 2022-06-12 04:29:09.106785
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path_in = Path('in.txt')
    path_out = Path('out.txt')
    io = InputOutput(input=path_in, output=path_out)
    assert io.input == path_in
    assert io.output == path_out

# Generated at 2022-06-12 04:29:12.687955
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=3, time=0.1, target=(3, 7),
                               dependencies=[])
    assert result.files == 3
    assert result.time == 0.1
    assert result.target == (3, 7)
    assert result.dependencies == []


# Generated at 2022-06-12 04:29:15.986751
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("a = 1")
    tree_changed = True
    dependencies = ['dependencies']

    tr = TransformationResult(tree, tree_changed, dependencies)

    assert tr.tree == tree
    assert tr.tree_changed == tree_changed
    assert tr.dependencies == dependencies

# Generated at 2022-06-12 04:29:18.175593
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('foo')
    out = Path('bar')
    io = InputOutput(inp, out)
    assert io.input == inp
    assert io.output == out

# Generated at 2022-06-12 04:29:19.311733
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(tree=None, tree_changed=None, dependencies=None)

# Generated at 2022-06-12 04:29:23.127747
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path('path1')
    path2 = Path('path2')
    i1 = InputOutput(path1, path2)
    i2 = InputOutput(path1, path2)
    assert i1 == i2



# Generated at 2022-06-12 04:30:15.910270
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path = Path('/home/user')
    input_output = InputOutput(path, path)
    assert path == input_output.input
    assert path == input_output.output

# Generated at 2022-06-12 04:30:19.160270
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path('/tmp/test1')
    path2 = Path('/tmp/test2')
    result = InputOutput(input=path1, output=path2)
    assert result.input == path1
    assert result.output == path2


# Generated at 2022-06-12 04:30:23.850647
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(1, 2.0, (3, 4), ['a', 'b'])
    assert res.files == 1
    assert res.time == 2.0
    assert res.target == (3, 4)
    assert res.dependencies == ['a', 'b']



# Generated at 2022-06-12 04:30:27.847136
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("")
    tree_changed = True
    dependencies = ["a", "b"]
    expected = TransformationResult(tree, tree_changed, dependencies)

    actual = TransformationResult(tree=tree,
                                  tree_changed=tree_changed,
                                  dependencies=dependencies)

    assert expected == actual


# Generated at 2022-06-12 04:30:29.270072
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=None, tree_changed=False, dependencies=[])
    assert isinstance(tr, TransformationResult)

# Generated at 2022-06-12 04:30:31.621843
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.Expression(None), True, [])
    assert tr.tree_changed == True
    assert isinstance(tr.dependencies, list)

# Generated at 2022-06-12 04:30:38.540290
# Unit test for constructor of class InputOutput
def test_InputOutput():
    try:
        InputOutput(None, None)
        assert False
    except TypeError:
        pass
    path1 = 'path1'
    path2 = 'path2'
    i1 = InputOutput(input=path1, output=path2)
    assert i1.input == path1
    assert i1.output == path2
    i2 = InputOutput(input=path2, output=path1)
    assert i1 != i2
    i3 = InputOutput(input=path1, output=path2)
    assert i1 == i3


# Generated at 2022-06-12 04:30:46.536167
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    """
    Test for the constructor of class `CompilationResult`.

    """
    number_of_files = 5
    total_time = 0.18
    target = (3, 7)

    result = CompilationResult(number_of_files,
                               total_time,
                               target,
                               ['/usr/lib/python3.7/os.py'])

    assert isinstance(result.files, int)
    assert isinstance(result.time, float)
    assert isinstance(result.target, CompilationTarget)
    assert result.files == number_of_files
    assert result.time == total_time
    assert result.target == target
    assert result.dependencies == ['/usr/lib/python3.7/os.py']


# Generated at 2022-06-12 04:30:48.972958
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=ast.parse('1 + 1'),
                                tree_changed=True,
                                dependencies=['foo', 'bar']).tree_change

# Generated at 2022-06-12 04:30:53.099545
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('in.py')
    output = Path('out.py')
    p = InputOutput(input=input, output=output)
    assert p.input == input
    assert p.output == output
    assert repr(p) == "InputOutput(input=PosixPath('in.py'), " \
        "output=PosixPath('out.py'))"


# Generated at 2022-06-12 04:31:49.946650
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=None, tree_changed=False, dependencies=[])

# Generated at 2022-06-12 04:31:52.807713
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_tree = ast.parse('1+1')
    dependencies = []
    result = TransformationResult(ast_tree, True, dependencies)
    assert result.tree == ast_tree
    assert result.tree_changed
    assert result.dependencies == dependencies

from .compiler import *
from .transformers import *

# Generated at 2022-06-12 04:31:56.731803
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Code of ast
    code = '''if a:
    print('yes')
else:
    print('no')'''

    # Dependencies
    dependencies = ['yes.py', 'no.py']

    # Test assertion
    assert TransformationResult(ast.parse(code), True, dependencies)


# Aps transformers
ApsTransformerMap = Dict[str, Callable[[ast.AST], TransformationResult]]

# Generated at 2022-06-12 04:32:00.680753
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(0, 1.23, (3, 4), ['foo', 'bar'])
    assert c.files == 0
    assert c.time == 1.23
    assert c.target == (3, 4)
    assert c.dependencies == ['foo', 'bar']


# Generated at 2022-06-12 04:32:03.184501
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    check_FunctionDef_tree()
    check_ClassDef_tree()
    check_Module_tree()


# Testing helper:
# - check that the type of the tree is ast.FunctionDef

# Generated at 2022-06-12 04:32:04.889415
# Unit test for constructor of class InputOutput
def test_InputOutput():
    t = InputOutput("inp", "outp")
    assert t.input == "inp"
    assert t.output == "outp"



# Generated at 2022-06-12 04:32:06.494168
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=0, time=0.0, target=(0, 0), dependencies=[])


# Generated at 2022-06-12 04:32:08.497099
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('foo.py')
    output = Path('bar.py')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-12 04:32:09.153962
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(None, False, [])

# Generated at 2022-06-12 04:32:12.526650
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/home/user/input/')
    output = Path('/home/user/output/')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-12 04:34:05.959355
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path('a/b.py'), Path('a/b.pyc'))
    assert io.input == Path('a/b.py')
    assert io.output == Path('a/b.pyc')
    assert io.input != io.output


# Generated at 2022-06-12 04:34:07.612249
# Unit test for constructor of class InputOutput
def test_InputOutput():
    file_a = Path('file_a')
    file_b = Path('file_b')
    pair = InputOutput(file_a, file_b)
    assert pair.input == file_a
    assert pair.output == file_b

# Generated at 2022-06-12 04:34:09.159722
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    d = TransformationResult(ast.parse('a'),
                             True,
                             ['dep1', 'dep2'])
    assert d.tree_changed
    assert len(d.dependencies) == 2

# Generated at 2022-06-12 04:34:09.926842
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=0, time=1, target=(2, 3), dependencies=[])



# Generated at 2022-06-12 04:34:11.528410
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    x = InputOutput(input, output)
    assert x.input == input
    assert x.output == output


# Generated at 2022-06-12 04:34:14.848642
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1, time=1.4, target=(3, 7), dependencies=["x.py", "y.py"])
    assert compilation_result.files == 1
    assert compilation_result.time == 1.4
    assert compilation_result.target == (3, 7)
    assert compilation_result.dependencies == ["x.py", "y.py"]


# Generated at 2022-06-12 04:34:15.638975
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2.0, (3, 4), ['a'])

# Generated at 2022-06-12 04:34:21.276257
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=2,
                               time=3.4,
                               target=(3, 6),
                               dependencies=['a', 'b'])
    assert result.files == 2
    assert result.time == 3.4
    assert result.target == (3, 6)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-12 04:34:22.298823
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(tree=1, tree_changed=True, dependencies=[])

# Generated at 2022-06-12 04:34:27.830443
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input=Path('input'), output=Path('output'))
    assert InputOutput(input=Path('input'), output=Path('output')) == \
           InputOutput(input=Path('input'), output=Path('output'))
    assert InputOutput(input=Path('input'), output=Path('output')) != \
           InputOutput(input=Path('input'), output=Path('output2'))
    assert InputOutput(input=Path('input'), output=Path('output')) \
        is not InputOutput(input=Path('input'), output=Path('output'))