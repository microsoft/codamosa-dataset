

# Generated at 2022-06-12 04:25:15.047674
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=1, time=2.0, target=(3, 4),
                             dependencies=['a', 'b'])

# Generated at 2022-06-12 04:25:18.057175
# Unit test for constructor of class InputOutput
def test_InputOutput():  # type: () -> None
    # typecheck gives the error:
    #   Cannot instantiate abstract class InputOutput with abstract attribute input
    # This is because NamedTuple does not implement class attributes
    # But it is correct because it is just for documentation purposes
    InputOutput(input=Path("/home"), output=Path("/tmp"))


# Generated at 2022-06-12 04:25:21.450062
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=['a', 'b'])
    assert cr.files == 1
    assert cr.time == 2.0
    assert cr.target == (3, 4)
    assert cr.dependencies == ['a', 'b']


# Generated at 2022-06-12 04:25:30.013052
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    import astor
    from os.path import join
    from ..utils import inout
    from ..transformer import Transformer

    r = TransformationResult(ast.parse('1'), False, [])
    print(r.tree)
    print(r.tree_changed)
    print(r.dependencies)

    # Obtain all test files
    inout_ = inout.get_in_out_pairs(join('test', 'tests'))
    for input_, output in inout_:
        transformer = Transformer(input_, output)
        r = transformer.process()
        print('Changed: {}'.format(r.tree_changed))
        print(astor.dump(r.tree))
        print(r.dependencies)

# Message in case of errors

# Generated at 2022-06-12 04:25:38.698415
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Simple
    io = InputOutput(input='path1', output='path2')
    assert io.input == 'path1'
    assert io.output == 'path2'
    # Path object
    io2 = InputOutput(input=Path('path3'), output=Path('path4'))
    assert io2.input == 'path3'
    assert io2.output == 'path4'
    # Mixed
    io3 = InputOutput(input='path5', output=Path('path6'))
    assert io3.input == 'path5'
    assert io3.output == 'path6'
    io4 = InputOutput(input=Path('path7'), output='path8')
    assert io4.input == 'path7'
    assert io4.output == 'path8'


# Generated at 2022-06-12 04:25:40.184830
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input=Path('foo.py'), output=Path('bar'))


# Generated at 2022-06-12 04:25:43.929155
# Unit test for constructor of class InputOutput
def test_InputOutput():

    # Correct initialization
    input_output = InputOutput('input', 'output')
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')

    # Fails on invalid argument
    try:
        assert InputOutput(1, 'output')
        assert False
    except ValueError:
        pass

# Generated at 2022-06-12 04:25:47.753838
# Unit test for constructor of class CompilationResult
def test_CompilationResult(): # type: () -> None
    CompilationResult(files=1, time=1.0,
                      target=(3, 6),
                      dependencies=["dependency.py"])


# Generated at 2022-06-12 04:25:52.186789
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_tree = ast.parse('0')
    t = TransformationResult(
        tree_changed=True,
        tree=ast_tree,
        dependencies=['test'])
    assert t.tree_changed is True
    assert t.tree == ast_tree
    assert t.dependencies == ['test']



# Generated at 2022-06-12 04:25:55.851571
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(1, 1.0, (3, 7), ['a', 'b'])
    assert cr.files == 1
    assert cr.time == 1.0
    assert cr.target == (3, 7)
    assert cr.dependencies == ['a', 'b']



# Generated at 2022-06-12 04:26:02.010018
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test_dir = Path("test")
    inp = InputOutput(test_dir / "a", test_dir / "b")
    res = TransformationResult(ast.parse("def f():pass"),
                               False,
                               [])
    assert res.tree is not None
    assert res.tree_changed is False
    assert res.dependencies == []


# Generated at 2022-06-12 04:26:05.459024
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = InputOutput(Path("a"), Path("b"))
    assert a.input == Path("a")
    assert a.output == Path("b")


# Generated at 2022-06-12 04:26:08.617995
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # pylint: disable=unused-variable
    result = CompilationResult(files=3, time=1.2, target=(3, 6), dependencies=["dep1", "dep2"])


# Generated at 2022-06-12 04:26:11.539844
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse('a = 0'), False, []).__dict__ == \
           {'tree': ast.parse('a = 0'),
            'dependencies': [],
            'tree_changed': False}



# Generated at 2022-06-12 04:26:14.842577
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path("test")
    path2 = Path("test")
    inout = InputOutput(path1, path2)

    assert inout.input.name == 'test'
    assert inout.output.name == 'test'


# Generated at 2022-06-12 04:26:23.103352
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # pylint: disable=too-many-locals
    input_tree = ast.parse('a = 1')
    output_tree = ast.parse('a = 1')
    output_changed_tree = ast.parse('a = 1\n')
    deps = ['a.py']
    TransformationResult(input_tree, False, deps)
    TransformationResult(output_tree, True, deps)
    TransformationResult(output_changed_tree, True, deps)
    try:
        TransformationResult('', False, deps)
    except TypeError:
        pass
    try:
        TransformationResult(input_tree, True, [1])
    except TypeError:
        pass
    try:
        TransformationResult(input_tree, True, None)
    except TypeError:
        pass

# Generated at 2022-06-12 04:26:27.981194
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(tree=ast.parse("1+1"), tree_changed=False,
                             dependencies=[])
    assert t.tree is not None
    assert not t.tree_changed
    assert len(t.dependencies) == 0

# Check whether files are a/b

# Generated at 2022-06-12 04:26:29.273776
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse(''), True, []).dependencies == []

# Generated at 2022-06-12 04:26:36.093939
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert len(TransformationResult.__annotations__) == 3
    assert TransformationResult.__annotations__['tree'] == ast.AST
    assert TransformationResult.__annotations__['tree_changed'] == bool
    assert TransformationResult.__annotations__['dependencies'] == List[str]
    assert TransformationResult(tree=ast.Module(),
                                tree_changed=True,
                                dependencies=['a', 'b']).tree_changed

# Status of compilation process
CompilationStatus = NamedTuple('CompilationStatus',
                               [('status', str),
                                ('reason', str),
                                ('errors', List[str]),
                                ('result', CompilationResult)])


# Generated at 2022-06-12 04:26:37.111109
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(None, None, None)

# Generated at 2022-06-12 04:26:43.464699
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p = Path('/tmp')
    q = Path('/tmp/foo')
    io = InputOutput(p, q)
    assert io.input == p
    assert io.output == q
    assert io.input != io.output

# Generated at 2022-06-12 04:26:46.793734
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    tr = TransformationResult(tree, True, ['foo.py'])
    assert tr.tree == tree
    assert tr.tree_changed is True
    assert tr.dependencies == ['foo.py']


# Generated at 2022-06-12 04:26:50.663181
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(0, 0, (10, 4), [])
    assert cr.files == 0
    assert cr.time == 0.0
    assert cr.target == (10, 4)
    assert cr.dependencies == []


# Generated at 2022-06-12 04:27:01.159403
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = None
    tree_changed = False
    dependencies = []
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree is tree
    assert result.tree_changed is tree_changed
    assert result.dependencies == dependencies


# Structure that holds a transformer
PythonTransformer = NamedTuple('PythonTransformer',
                               [('transform',
                                 Callable[[ast.AST, List[str]], TransformationResult]),
                                ('dependencies', List[str])])

# Holds inputs and outputs of a transformer
TransformationIO = NamedTuple('TransformationIO',
                              [('input', Path),
                               ('pipeline_changed', bool),
                               ('output', Path)])

# Unit test of constructor of class TransformationIO

# Generated at 2022-06-12 04:27:05.644454
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    test = CompilationResult(files=123, time=3.14, target=(3, 7), dependencies=['foo.py', 'bar.py'])
    assert test.files == 123
    assert test.time == 3.14
    assert test.target == (3, 7)
    assert test.dependencies == ['foo.py', 'bar.py']



# Generated at 2022-06-12 04:27:09.161506
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(None, True, None)
    assert res.tree is None
    assert res.tree_changed is True
    assert res.dependencies is None

# Generated at 2022-06-12 04:27:10.485950
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.parse('x = 1'), True, ['foo.py'])

# Generated at 2022-06-12 04:27:12.721815
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # pylint: disable=unused-variable
    cr = CompilationResult(0, 0.0, (3, 7), [])


# Generated at 2022-06-12 04:27:16.078860
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.AST(), False, [])
    TransformationResult(ast.AST(), True, [])


# Result of transformers.transform
TransformationResult2 = NamedTuple('TransformationResult2',
                                   [('input_output', InputOutput),
                                    ('result', TransformationResult)])


# Generated at 2022-06-12 04:27:21.382858
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    def f():
        return CompilationResult(files=2,
                                 time=1.1,
                                 target=(3, 4),
                                 dependencies=["a"])
    assert f().files == 2
    assert f().time == 1.1
    assert f().target == (3, 4)
    assert f().dependencies == ["a"]


# Generated at 2022-06-12 04:27:29.116882
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('A')
    o = Path('B')
    a = InputOutput(i, o)
    # Check fields
    assert a.input == i
    assert a.output == o
    # Test str
    assert str(a) == 'A -> B'



# Generated at 2022-06-12 04:27:31.627058
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    try:
        res = CompilationResult(34, 0.1234, (3, 6), [])
    except Exception as e:
        pytest.fail(e)


# Generated at 2022-06-12 04:27:40.931929
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(
        ast.parse('print 1'), True, [])
    TransformationResult(
        ast.parse('print 1'), False, [])
    TransformationResult(
        ast.parse('print 1'), True, ['test.py'])
    TransformationResult(
        ast.parse('print 1'), False, ['test.py'])

    TransformationResult(
        ast.parse('print 1'), 'a', [])
    TransformationResult(
        ast.parse('print 1'), True, ['a'])
    TransformationResult(
        ast.parse('print 1'), False, ['a', 1])

    TransformationResult(
        'a', True, [])
    TransformationResult(
        ast.parse('print 1'), True, ['a'])
    TransformationResult(
        ast.parse('print 1'), False, ['a', 1])


# Generated at 2022-06-12 04:27:43.747784
# Unit test for constructor of class InputOutput
def test_InputOutput():
    x = InputOutput(Path("input.txt"), Path("output.txt"))
    assert x.input == Path("input.txt")
    assert x.output == Path("output.txt")


# Generated at 2022-06-12 04:27:49.011957
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    import astor
    tree = astor.code_to_ast.parse_file('tests/test_transformer.py')
    res = TransformationResult(tree=tree, tree_changed=True,
                               dependencies=['tests/test_reducer.py'])
    assert len(res.dependencies) == 1

# Result of reducers reduction
ReductionResult = NamedTuple('ReductionResult', [('tree', ast.AST)])


# Generated at 2022-06-12 04:27:51.100828
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=['a'])


# Generated at 2022-06-12 04:27:55.562235
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=100, time=100.0, target=(3, 6),
                          dependencies=['example'])
    assert c.files == 100
    assert c.time == 100.0
    assert c.target == (3, 6)
    assert c.dependencies == ['example']


# Generated at 2022-06-12 04:27:58.842823
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c_r = CompilationResult(1, 2.4, (3, 4), ['foo'])
    assert tuple.__eq__(c_r, (1, 2.4, (3, 4), ['foo']))



# Generated at 2022-06-12 04:28:01.562214
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('input.txt'), Path('output.txt'))
    assert input_output.input == Path('input.txt')
    assert input_output.output == Path('output.txt')

# Generated at 2022-06-12 04:28:05.514422
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path_in = Path('/dir1/dir2/dir3/file.py')
    path_out = Path('/dir1/dir2/dir3/file.pyc')
    input_output = InputOutput(path_in, path_out)
    assert input_output.input == path_in
    assert input_output.output == path_out


# Generated at 2022-06-12 04:28:20.467040
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = \
        CompilationResult(files=1,
                          time=0.1,
                          target=(3, 7),
                          dependencies=['file1', 'file2'])

    # Check files
    assert compilation_result.files == 1

    # Check time
    assert compilation_result.time == 0.1

    # Check target
    assert compilation_result.target == (3, 7)

    # Check dependencies
    assert compilation_result.dependencies == ['file1', 'file2']



# Generated at 2022-06-12 04:28:23.569104
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(4, 0.5, (3, 5), [])
    assert result.files == 4
    assert result.time == 0.5
    assert result.target == (3, 5)
    assert result.dependencies == []


# Generated at 2022-06-12 04:28:26.536916
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('.')
    output_path = Path('..')
    input_output = InputOutput(input_path, output_path)

    assert input_output.input == input_path
    assert input_output.output == output_path

# Generated at 2022-06-12 04:28:29.143418
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input')
    output = Path('/tmp/output')
    pair = InputOutput(input, output)
    assert pair.input == input
    assert pair.output == output


# Generated at 2022-06-12 04:28:31.784058
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('input.py'), Path('output.py')) == \
           InputOutput(input=Path('input.py'), output=Path('output.py'))



# Generated at 2022-06-12 04:28:36.448124
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('./input')
    output = Path('./output')
    assert InputOutput(input_, output) == InputOutput(input_, output)
    assert InputOutput(input_, output) != InputOutput(input_, None)
    assert InputOutput(input_, output) != InputOutput(None, output)
    assert InputOutput(input_, output) != InputOutput(None, None)


# Generated at 2022-06-12 04:28:39.611059
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # pylint: disable=unused-variable
    # pylint: disable=expression-not-assigned
    CompilationResult(files=100,
                      time=2.5,
                      target=(3, 6),
                      dependencies=[])


# Generated at 2022-06-12 04:28:43.834710
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path("test.txt")
    output = Path("test.txt")
    input_output = InputOutput(input, output)
    assert(input_output.input == input)
    assert(input_output.output == output)

# Generated at 2022-06-12 04:28:47.511216
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=10, time=2.1, target=(3, 6),
                            dependencies=['a', 'b', 'c'])

    assert(res.files == 10)
    assert(res.time == 2.1)
    assert(res.target == (3, 6))
    assert(res.dependencies == ['a', 'b', 'c'])


# Generated at 2022-06-12 04:28:50.074943
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    r = TransformationResult(ast.parse(""), True, [])
    assert r.tree is not None
    assert r.tree_changed is True
    assert r.dependencies == []

# Generated at 2022-06-12 04:29:04.358754
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('/tmp/foo.py')
    output_ = Path('/tmp/result/foo.py')
    io = InputOutput(input_, output_)

    assert io.input == input_
    assert io.output == output_


# Generated at 2022-06-12 04:29:05.739983
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert(InputOutput('in', 'out') == InputOutput(Path('in'), Path('out')))



# Generated at 2022-06-12 04:29:08.682286
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.parse('pass'), False, ['dep1', 'dep2'])
    assert tr.tree
    assert tr.tree_changed is False
    assert tr.dependencies == ['dep1', 'dep2']
    return


# Generated at 2022-06-12 04:29:12.128233
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(1, 2.0, (3, 4), ['foo', 'bar'])
    assert cr.files == 1
    assert cr.time == 2.0
    assert cr.target == (3, 4)
    assert cr.dependencies == ['foo', 'bar']


# Generated at 2022-06-12 04:29:16.147065
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    try:
        result = TransformationResult(None, None, None)
        assert result.tree is None
        assert result.tree_changed is None
        assert result.dependencies is None
    except AssertionError:
        assert False, "TransformationResult constructor test failed"
    else:
        assert True, "TransformationResult constructor test succeeded"

# Generated at 2022-06-12 04:29:18.007228
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = InputOutput(Path('a'), Path('a'))
    b = InputOutput(Path('a'), Path('b'))
    assert a != b

# Generated at 2022-06-12 04:29:21.583117
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("pass")
    tree_changed = True
    dependencies = []
    result = TransformationResult(tree, tree_changed, dependencies)
    assert(result.tree == tree)
    assert(result.tree_changed == tree_changed)
    assert(result.dependencies == dependencies)

# Generated at 2022-06-12 04:29:26.158247
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    module = ast.parse('asdf = 1')
    dependencies = ['asdf.py', 'module.py']
    tr = TransformationResult(tree=module,
                              tree_changed=True,
                              dependencies=dependencies)
    assert tr.tree == module
    assert tr.tree_changed
    assert tr.dependencies == dependencies

# Generated at 2022-06-12 04:29:27.913798
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("")
    # No assert because this would raise an exception
    TransformationResult(tree, True, [])

# Generated at 2022-06-12 04:29:32.440208
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input')
    output = Path('/tmp/output')
    pair = InputOutput(input=input, output=output)
    assert pair.input == input
    assert pair.output == output
    assert pair == InputOutput(input=input, output=output)
    assert pair != InputOutput(input=output, output=output)
    assert pair != InputOutput(input=input, output=input)

# Generated at 2022-06-12 04:29:48.500747
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(42, 3.14, (3, 7), ['a.py', 'b.py'])
    assert c.files == 42
    assert c.time == 3.14
    assert c.target == (3, 7)
    assert c.dependencies == ['a.py', 'b.py']


# Generated at 2022-06-12 04:29:53.025560
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input=Path('input.txt'),
                       output=Path('output.txt')) == \
        InputOutput(input=Path('input.txt'),
                    output=Path('output.txt'))

    assert InputOutput(input=Path('input.txt'),
                       output=Path('output.txt')) != \
        InputOutput(input=Path('input123.txt'),
                    output=Path('output.txt'))


# Generated at 2022-06-12 04:30:03.236234
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    f = ast.parse("4 + 4")
    res1 = TransformationResult(f, True, [])
    res2 = TransformationResult(f, False, ["my_dep"])
    res3 = TransformationResult(f, False, ["my_dep", "my_dep2"])
    assert res1.tree == f
    assert res2.tree == f
    assert res3.tree == f
    assert res1.tree_changed == True
    assert res2.tree_changed == False
    assert res3.tree_changed == False
    assert res1.dependencies == []
    assert res2.dependencies == ["my_dep"]
    assert res3.dependencies == ["my_dep", "my_dep2"]

# Generated at 2022-06-12 04:30:06.391183
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Initialize paths
    path1 = Path("/tmp/input.py")
    path2 = Path("/tmp/output.py")

    # Create InputOutput
    pair = InputOutput(path1, path2)

    # Check that the pair is correct
    assert pair.input == path1
    assert pair.output == path2


# Generated at 2022-06-12 04:30:08.173716
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1,
                      time=0.5,
                      target=(3, 4),
                      dependencies=['foo', 'bar'])

# Generated at 2022-06-12 04:30:11.977872
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_node = ast.parse('')
    res = TransformationResult(tree=ast_node,
                               tree_changed=True,
                               dependencies=['a', 'b'])
    assert res.tree == ast_node
    assert res.tree_changed
    assert res.dependencies == ['a', 'b']

# Generated at 2022-06-12 04:30:13.539478
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(input=Path('input.py'), output=Path('output.py'))


# Generated at 2022-06-12 04:30:15.732854
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    ast.parse('a = 1')
    tree = TransformationResult(ast.parse('a = 1'), True, ['a'])



# Generated at 2022-06-12 04:30:17.297946
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path("a"), Path("b")) == InputOutput(Path("a"), Path("b"))

# Generated at 2022-06-12 04:30:20.710653
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(1, 1.1, (3, 2), [])
    assert cr.files == 1
    assert cr.time == 1.1
    assert cr.target == (3, 2)
    assert cr.dependencies == []


# Generated at 2022-06-12 04:30:48.102836
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=42, time=0, target=(3, 7), dependencies=[])


# Generated at 2022-06-12 04:30:53.835323
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('a = 1')
    tr = TransformationResult(t, True, [])
    assert(tr.tree == t and tr.tree_changed == True and tr.dependencies == [])


# Result of transformer application
TransformerResult = NamedTuple('TransformerResult',
                               [('code', str),
                                ('sourceToTarget', InputOutput),
                                ('targetToObject', List[InputOutput]),
                                ('objectToC', List[InputOutput]),
                                ('result', CompilationResult)])


# Generated at 2022-06-12 04:30:57.502565
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(files=42, time=42.0,
                          target=(3, 8),
                          dependencies=[])
    assert r.files == 42
    assert r.time == 42.0
    assert r.target == (3, 8)
    assert r.dependencies == []


# Generated at 2022-06-12 04:30:58.515744
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, False, None)

# Generated at 2022-06-12 04:31:00.426781
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.Module([]), True,
                                ['dependencies']).dependencies == \
        ['dependencies']


# Generated at 2022-06-12 04:31:02.851743
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    try:
        TransformationResult('foo', 'bar', 'baz')
    except Exception as e:
        assert False, e.message

# Generated at 2022-06-12 04:31:07.304344
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    def identity(tree, dependencies):
        return TransformationResult(tree, False, dependencies)
    assert identity(ast.mod(), ['a']).tree_changed is False
    assert identity(ast.mod(), ['a']).dependencies == ['a']
    assert identity(ast.mod(), []).dependencies == []


# Result of transformers check
CheckResult = NamedTuple('CheckResult',
                         [('dependencies', List[str]),
                          ('should_transformation_happen', bool)])


# Generated at 2022-06-12 04:31:09.849817
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input=Path('foo'),
                       output=Path('bar')).input.name == 'foo'
    assert InputOutput(input=Path('foo'),
                       output=Path('bar')).output.name == 'bar'


# Generated at 2022-06-12 04:31:12.565373
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cres = CompilationResult(2, 3, (4, 5), ['a'])
    assert cres.files == 2
    assert cres.time == 3
    assert cres.target == (4, 5)
    assert cres.dependencies == ['a']

# Generated at 2022-06-12 04:31:13.943990
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(0, 0.0, (3, 5), [])


# Generated at 2022-06-12 04:32:12.830998
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('test'), Path('test2'))



# Generated at 2022-06-12 04:32:14.452641
# Unit test for constructor of class InputOutput
def test_InputOutput():
    result = InputOutput(Path('a'), Path('b'))
    assert result.input == Path('a')
    assert result.output == Path('b')


# Generated at 2022-06-12 04:32:16.116629
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert(CompilationResult(files=0, time=0.0, target=(0, 0), dependencies=[])
           is not None)


# Generated at 2022-06-12 04:32:16.947788
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.parse('a'), True, [])

# Generated at 2022-06-12 04:32:20.476120
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Given
    a_path = Path('/tmp')
    expected_input = InputOutput(a_path, a_path)

    # When
    actual_input = InputOutput(a_path, a_path)
    actual_input1 = InputOutput(a_path, a_path)

    # Then
    assert expected_input == actual_input
    assert expected_input == actual_input1


# Generated at 2022-06-12 04:32:22.559084
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('print(5)')
    assert TransformationResult(tree, True, ["/tmp/somefile.py", "/tmp/other_file.py"])

# Generated at 2022-06-12 04:32:24.829846
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.AST(), False, ["dep1", "dep2"])
    assert tr.tree is not None
    assert tr.tree_changed is False
    assert tr.dependencies == ["dep1", "dep2"]

# Generated at 2022-06-12 04:32:27.321022
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult((ast.parse(""), True, []))

# Result of start function execution
StartResult = NamedTuple('StartResult',
                         [('result', CompilationResult),
                          ('out_path', str)])


# Generated at 2022-06-12 04:32:33.282781
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c1 = CompilationResult(files=1, time=0.0, target=(3, 6),
                           dependencies=['a', 'b', 'c'])
    assert repr(c1) == ("CompilationResult(files=1, time=0.0, target=(3, 6), "
                            "dependencies=['a', 'b', 'c'])")
    assert isinstance(c1.files, int)
    assert isinstance(c1.time, float)
    assert isinstance(c1.target, tuple)
    assert isinstance(c1.dependencies, list)


# Generated at 2022-06-12 04:32:35.612928
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(Path('/a/b/c'), Path('/d/e/f'))
    assert False  # TODO: implement your test here

# Generated at 2022-06-12 04:33:34.779010
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = 'in.py'
    output_ = 'out.js'
    pair = InputOutput(input_, output_)
    assert pair.input == input_
    assert pair.output == output_


# Generated at 2022-06-12 04:33:36.252019
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    node = ast.parse('a = b')
    assert isinstance(node, ast.AST)
    assert node.body[0].value.id == 'b'

# Generated at 2022-06-12 04:33:39.007801
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/home/logilab/path.py')
    output = Path('/var/log/path.py')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-12 04:33:41.455553
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(tree=None, tree_changed=False,
                                  dependencies=["a"])
    assert result.tree is None
    assert not result.tree_changed
    assert ["a"] == result.dependencies

# Generated at 2022-06-12 04:33:44.008709
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = 'input_path'
    output_ = 'output_path'
    i_o = InputOutput(input_, output_)
    assert i_o.input == Path(input_)
    assert i_o.output == Path(output_)

# Generated at 2022-06-12 04:33:47.089966
# Unit test for constructor of class InputOutput
def test_InputOutput():
    result = InputOutput(Path('a.py'), Path('b.py'))
    assert result.input == Path('a.py') and result.output == Path('b.py')


# Generated at 2022-06-12 04:33:52.677775
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_targets = [(2, 6), (2, 7), (3, 5), (3, 6), (3, 7)]
    for target in compilation_targets:
        try:
            CompilationResult(1, 2.0, target, ["foo.py"])
        except TypeError:
            assert False, ("CompilationResult({0}, {1}, {2}, {3}) "
                           "should be fine".format(1, 2.0, target,
                                                   ["foo.py"]))

# Generated at 2022-06-12 04:33:55.165885
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(tree=None, tree_changed=False, dependencies=None)
    assert res == TransformationResult(None, False, None)
    assert res != TransformationResult(None, True, None)
    assert res != TransformationResult(ast.Module(), False, None)

# Generated at 2022-06-12 04:33:58.580250
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: ignore
    t = ast.Name(id='a', ctx=ast.Load())
    tr = TransformationResult(tree=t, tree_changed=False, dependencies=[])
    assert tr.tree == t
    assert tr.tree_changed == False
    assert tr.dependencies == []


# Possible errors in handling of AST

# Generated at 2022-06-12 04:34:01.581869
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 1
    time = 1.0
    target = (3, 7)
    dependencies = ["dep1", "dep2"]
    compilation_result = CompilationResult(files, time, target, dependencies)
    assert files == compilation_result.files
    assert time == compilation_result.time
    assert target == compilation_result.target
    assert dependencies == compilation_result.dependencies

