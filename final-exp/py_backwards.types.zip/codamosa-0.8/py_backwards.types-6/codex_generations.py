

# Generated at 2022-06-12 04:25:17.085684
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('./input')
    o = Path('./output')
    io = InputOutput(i, o)
    assert io.input == i
    assert io.output == o

# Generated at 2022-06-12 04:25:20.973690
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1,
                                           time=15.0,
                                           target=(3, 5),
                                           dependencies=["foo"])
    assert compilation_result.files == 1
    assert compilation_result.time == 15.0
    assert compilation_result.target == (3, 5)
    assert compilation_result.dependencies == ["foo"]



# Generated at 2022-06-12 04:25:24.288617
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result1 = CompilationResult(1, 2.0, (3, 4), ['d1', 'd2'])
    compilation_result2 = CompilationResult(files=1, time=2.0, target=(3, 4),
                                            dependencies=['d1', 'd2'])
    compilation_result3 = CompilationResult(1, 2.0, (3, 4), ['d1', 'd2'])
    assert compilation_result1 == compilation_result2
    assert compilation_result1 == compilation_result3
    assert compilation_result2 == compilation_result3

# Generated at 2022-06-12 04:25:26.596497
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformer = ast.parse('pass')
    tree = ast.Module()
    TransformationResult(tree, True, [])
    TransformationResult(tree, False, [])

# Generated at 2022-06-12 04:25:28.296703
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(123, 1.5, (3, 6), ["a", "b"])


# Generated at 2022-06-12 04:25:33.221942
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(
        files=2,
        time=1.0,
        target=(3, 4),
        dependencies=['a', 'b', 'c']
    )
    assert result.files == 2
    assert result.time == 1.0
    assert result.target == (3, 4)
    assert set(result.dependencies) == {'a', 'b', 'c'}

# Generated at 2022-06-12 04:25:36.709185
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/usr/src/input.py')
    output = Path('/usr/src/output.py')
    input_output = InputOutput(input=input, output=output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-12 04:25:38.221400
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(0, 0.0, (3, 6), [])



# Generated at 2022-06-12 04:25:42.296977
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    """
    Check that CompilationResult is correctly constructed
    """
    result = CompilationResult(1, 2.3, (3, 4), ['dep1', 'dep2'])
    assert result.files == 1
    assert result.time == 2.3
    assert result.target == (3, 4)
    assert result.dependencies == ['dep1', 'dep2']


# Generated at 2022-06-12 04:25:47.040031
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=0, time=0., target=(3, 5), dependencies=[])
    assert (result.files, result.time, result.target, result.dependencies) == (0, 0., (3, 5), [])


# Generated at 2022-06-12 04:25:52.561603
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('inp')
    out = Path('out')

    io = InputOutput(inp, out)

    eq_(io.input, inp)
    eq_(io.output, out)

# Generated at 2022-06-12 04:25:56.171444
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_file = Path('./input.py')
    output_file = Path('./output.py')

    input_output = InputOutput(input=input_file, output=output_file)
    assert input_output.input == input_file
    assert input_output.output == output_file


# Generated at 2022-06-12 04:25:58.671369
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    actual = CompilationResult(1, 2, (3, 4), ['foo', 'bar'])
    expected = CompilationResult(files=1, time=2, target=(3, 4),
                                 dependencies=['foo', 'bar'])
    assert actual == expected


# Generated at 2022-06-12 04:26:08.576472
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    a = ast.parse('a')
    b = TransformationResult(tree=a, tree_changed=True, dependencies=['b'])
    assert b.tree == a and b.tree_changed and b.dependencies == ['b']
    c = TransformationResult(tree=a, tree_changed=False, dependencies=['b'])
    assert c.tree == a and not c.tree_changed and c.dependencies == ['b']
    d = TransformationResult(tree=a, tree_changed=True, dependencies=[])
    assert d.tree == a and d.tree_changed and not d.dependencies
    e = TransformationResult(tree=a, tree_changed=False, dependencies=[])
    assert e.tree == a and not e.tree_changed and not e.dependencies

# Generated at 2022-06-12 04:26:10.872117
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(None, False, [])
    assert t.tree is None
    assert not t.tree_changed
    assert isinstance(t.dependencies, list)

# Generated at 2022-06-12 04:26:15.990647
# Unit test for constructor of class InputOutput
def test_InputOutput():
    def _test(input_, output):
        input_output = InputOutput(input_, output)
        assert input_output.input == input_
        assert input_output.output == output

    _test(Path('a'), Path('b'))
    _test('a', Path('b'))
    _test(Path('a'), 'b')
    _test('a', 'b')


# Generated at 2022-06-12 04:26:18.142681
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(Path("a.in"), Path("a.out"))
    InputOutput(input="a.in", output="a.out")


# Generated at 2022-06-12 04:26:19.802966
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(0, 0.0, (0, 0), [])


# Generated at 2022-06-12 04:26:29.877582
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr1 = CompilationResult(files=1, time=2.0, target=(3, 4),
                            dependencies=['a', 'b'])
    assert cr1.files == 1
    assert cr1.time == 2.0
    assert cr1.target == (3, 4)
    assert cr1.dependencies == ['a', 'b']
    cr2 = CompilationResult(files=1, time=2.0, target=(3, 4),
                            dependencies=['a', 'b'])
    # Two compilation results are equal if all fields are equal
    assert cr1 == cr2
    cr3 = CompilationResult(files=2, time=2.0, target=(3, 4),
                            dependencies=['a', 'b'])
    assert cr1 != cr3

# Generated at 2022-06-12 04:26:31.540961
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    pass



# Generated at 2022-06-12 04:26:40.870949
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.AST(), False, [])
    assert tr.tree
    assert not tr.tree_changed
    assert tr.dependencies == []


# Result of running transformer
TransformerResult = NamedTuple('TransformerResult',
                               [('result', TransformationResult),
                                ('info', str)])

# A test input file and the output of the compiler
TestCase = NamedTuple('TestCase', [('input', ast.AST),
                                   ('output', ast.AST)])

# Generated at 2022-06-12 04:26:45.566846
# Unit test for constructor of class CompilationResult
def test_CompilationResult():

    res = CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=['a', 'b'])
    assert res.files == 1
    assert res.time == 1.0
    assert res.target == (3, 6)
    assert res.dependencies == ['a', 'b']



# Generated at 2022-06-12 04:26:51.251224
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(1, 2.5, (3, 4), ['a', 'b'])
    assert c.files == 1
    assert c.time == 2.5
    assert c.target == (3, 4)
    assert c.dependencies == ['a', 'b']


# Generated at 2022-06-12 04:26:53.959406
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(
        files=1,
        time=5.5,
        target=(3, 7),
        dependencies=['a', 'b'])

# Generated at 2022-06-12 04:26:55.509973
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Type check
    InputOutput(input='hello', output='world')



# Generated at 2022-06-12 04:26:56.973172
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(input=Path("foo"), output=Path("bar"))

# Generated at 2022-06-12 04:27:02.473607
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result1 = CompilationResult(1, 2.0, (3, 4), ['file1', 'file2'])
    result2 = CompilationResult(1, 2.0, (3, 4), ['file1', 'file2'])
    result3 = CompilationResult(2, 3.0, (3, 4), ['file1', 'file2'])
    assert result1 == result2
    assert result1 != result3

# Generated at 2022-06-12 04:27:08.236847
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    a = TransformationResult(ast.parse('x = 1'), True, ['a', 'b', 'c'])
    b = TransformationResult(ast.parse('x = 1'), False, ['b', 'a', 'c'])
    c = TransformationResult(ast.parse('x = 1'), True, ['d', 'e', 'f'])
    assert a == a
    assert a != b
    assert a != c
    assert b != c
    x = set([a, b, c])
    assert x == set([a, b, c])
    assert x == set([b, a, c])
    assert len(x) == 3



# Generated at 2022-06-12 04:27:09.425067
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(None, False, [])

# Generated at 2022-06-12 04:27:12.104478
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path = Path('foo.txt')
    input_output = InputOutput(path, path)
    assert input_output.input == path
    assert input_output.output == path

# Generated at 2022-06-12 04:27:20.685993
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=1.0,
                           target=(3, 6),
                           dependencies=[])
    assert cr.files == 1
    assert cr.time == 1.0
    assert cr.target == (3, 6)



# Generated at 2022-06-12 04:27:24.691982
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # pylint: disable=invalid-name
    """ Unit test for constructor of class TransformationResult """
    tree = ast.parse('a = 1')
    assert TransformationResult(tree=tree, tree_changed=True, dependencies=[]) == \
        TransformationResult(tree=tree, tree_changed=True, dependencies=[])

# Generated at 2022-06-12 04:27:27.315412
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/a')
    output = Path('/tmp/b')

    iot = InputOutput(input=input, output=output)
    assert iot.input == input
    assert iot.output == output



# Generated at 2022-06-12 04:27:30.279543
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('a.py')
    output_path = Path('a.pyc')
    io = InputOutput(input_path, output_path)
    assert io.input == input_path
    assert io.output == output_path

# Generated at 2022-06-12 04:27:34.723957
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # All fields are set
    input_output = InputOutput('in', 'out')
    assert input_output.input == Path('in')
    assert input_output.output == Path('out')

    # Only input is set
    input_output = InputOutput('in')
    assert input_output.input == Path('in')
    assert input_output.output is None



# Generated at 2022-06-12 04:27:36.936195
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, False, []) == TransformationResult(
        tree=None,
        tree_changed=False,
        dependencies=[])

# Generated at 2022-06-12 04:27:40.848215
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path("/import/python/code/file.py"), Path("/import/python/code/file.py.bk"))
    assert io.input == Path("/import/python/code/file.py")
    assert io.output == Path("/import/python/code/file.py.bk")

# Generated at 2022-06-12 04:27:43.026164
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input, output = 'foo', 'bar'
    pair = InputOutput(input, output)
    assert pair.input == input
    assert pair.output == output



# Generated at 2022-06-12 04:27:45.569251
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i, o = Path("src"), Path("bin")
    io = InputOutput(i, o)
    assert io.input == i
    assert io.output == o

# Generated at 2022-06-12 04:27:47.494107
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('')
    assert TransformationResult(tree, False, []) == TransformationResult(tree, False, [])

# Generated at 2022-06-12 04:27:58.385357
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse('pass', mode='exec'),
                                True,
                                []).tree_changed

# Generated at 2022-06-12 04:28:01.459891
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('test.input')
    output = Path('test.output')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-12 04:28:03.798073
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=2,
                             time=0.1,
                             target=(3, 6),
                             dependencies=['hello'])


# Generated at 2022-06-12 04:28:05.810701
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('/tmp/i')
    o = Path('/tmp/o')
    pair = InputOutput(i, o)
    assert pair.input == i
    assert pair.output == o

# Generated at 2022-06-12 04:28:14.091176
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 2')
    result = TransformationResult(tree, False, [])
    assert result.tree == tree
    assert not result.tree_changed
    assert result.dependencies == []

# Example of transformation result
transformation_result = TransformationResult(ast.parse('a = 3'),
                                             True, ['example.py'])

# Configurations for python compilation
# We could have general ones, but for now let it be hard-coded

# (target_version, optimization_level)
CompilationConfigurations = List[CompilationTarget]

# List of configs to use
default_compilation_configurations = [(3, 0), (3, 1), (3, 2)]

# Generated at 2022-06-12 04:28:17.911219
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=[])
    assert c.files == 1
    assert c.time == 2.0
    assert c.target[0] == 3
    assert c.target[1] == 4
    assert c.dependencies == []


# Generated at 2022-06-12 04:28:21.000103
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/')
    output = Path('/')
    input_output = InputOutput(input, output)
    assert isinstance(input_output, InputOutput)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-12 04:28:23.497237
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('x=1')
    result = TransformationResult(t, True, [])
    assert result.tree == t
    assert result.tree_changed == True
    assert result.dependencies == []

# Generated at 2022-06-12 04:28:27.787160
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=5,
                               time=0.2,
                               target=(3, 4),
                               dependencies=['foo', 'bar'])
    assert result.files == 5
    assert result.time == 0.2
    assert result.target == (3, 4)
    assert result.dependencies == ['foo', 'bar']


# Generated at 2022-06-12 04:28:30.392725
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_file = Path("/tmp/input_file")
    output_file = Path("/tmp/output_file")
    assert InputOutput(input_file, output_file)


# Generated at 2022-06-12 04:28:51.908519
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(ast.AST(), True, [])
    assert t.tree is not None
    assert t.tree_changed
    assert t.dependencies == []

# Generated at 2022-06-12 04:28:59.108685
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # The type should work fine
    CompilationResult(5, 2.5, (3, 7), ['foo', 'bar'])

    # And should fail where expected
    with pytest.raises(TypeError):
        CompilationResult('foo', 2.5, (3, 7), ['foo', 'bar'])
    with pytest.raises(TypeError):
        CompilationResult(5, 'foo', (3, 7), ['foo', 'bar'])
    with pytest.raises(TypeError):
        CompilationResult(5, 2.5, 2, ['foo', 'bar'])
    with pytest.raises(TypeError):
        CompilationResult(5, 2.5, (3, 7), 2)

# Generated at 2022-06-12 04:29:01.806269
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # type: () -> None
    io = InputOutput(input=Path('input'), output=Path('output'))

    assert io.input.name == 'input'
    assert io.output.name == 'output'


# Generated at 2022-06-12 04:29:03.272765
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(3, 4), dependencies=[])



# Generated at 2022-06-12 04:29:05.705493
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inputPath = Path('.')
    outputPath = Path('..')
    inputOutput = InputOutput(inputPath, outputPath)
    assert inputOutput.input == inputPath
    assert inputOutput.output == outputPath

# Generated at 2022-06-12 04:29:06.736752
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(3, 0, (3, 6), None)


# Generated at 2022-06-12 04:29:10.449395
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=None,
                                tree_changed=False,
                                dependencies=[]) == (None, False, [])


# Result of reading of .dep file
DependencyFileResult = NamedTuple('DependencyFileResult',
                                  [('dependencies', List[str]),
                                   ('changed', bool)])


# Generated at 2022-06-12 04:29:14.375366
# Unit test for constructor of class CompilationResult
def test_CompilationResult():  # type: () -> None
    # pylint: disable=redundant-keyword-arg
    assert CompilationResult(files=0,
                             time=0.0,
                             target=(0, 0),
                             dependencies=[])
    # pylint: enable=redundant-keyword-arg


# Generated at 2022-06-12 04:29:17.287554
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(input=Path('input'),
                               output=Path('output'))
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')



# Generated at 2022-06-12 04:29:20.949305
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=2.2, target=(3, 0),
                               dependencies=['a'])
    assert result.files == 1
    assert result.time == 2.2
    assert result.target == (3, 0)
    assert result.dependencies == ['a']


# Generated at 2022-06-12 04:30:13.540465
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(files=1,
                          time=2,
                          target=(3, 4),
                          dependencies=['5', '6', '7'])
    assert r.files == 1
    assert r.time == 2
    assert r.target == (3, 4)
    assert r.dependencies == ['5', '6', '7']


# Generated at 2022-06-12 04:30:16.089981
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('file')
    o = Path('directory')
    inout = InputOutput(i, o)
    assert inout.input == i
    assert inout.output == o

# Generated at 2022-06-12 04:30:17.260110
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input=None,output='aaa')



# Generated at 2022-06-12 04:30:22.664645
# Unit test for constructor of class TransformationResult
def test_TransformationResult(): # type: () -> None
    pass

# Error in program
Error = NamedTuple('Error', [('source', Path),
                             ('position', Tuple[int, int]),
                             ('message', str),
                             ('filename', Path),
                             ('line', int),
                             ('column', int),
                             ('offset', int)])


# Generated at 2022-06-12 04:30:26.674396
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('a/b')
    o = Path('c/d')
    a = InputOutput(i, o)
    b = InputOutput(i, o)
    assert a == b
    assert hash(a) == hash(b)
    assert repr(InputOutput(i, o)) == "InputOutput('a/b', 'c/d')"

# Generated at 2022-06-12 04:30:31.822287
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('foo.in')
    outp = Path('foo.out')
    iopair = InputOutput(inp, outp)
    assert iopair.input == inp
    assert iopair.output == outp

    iopair2 = InputOutput(inp, outp)
    assert iopair == iopair2

    iopair3 = iopair.replace(input=Path('bar.in'))
    assert iopair != iopair3

# Generated at 2022-06-12 04:30:34.795935
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(None, True, [])
    assert result.tree_changed == True


# Two functions should be changed to be compatible with typing api
# (for py2 type checker)

# Generated at 2022-06-12 04:30:38.875043
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(files=1,
                          time=0.1,
                          target=(3, 7),
                          dependencies=['lib.py'])
    assert r.files == 1
    assert r.time == 0.1
    assert r.target == (3, 7)
    assert r.dependencies == ['lib.py']

# Generated at 2022-06-12 04:30:42.661602
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    """Test constructor from TransformationResult class."""
    tree = ast.Module()
    dependencies = ['foo', 'bar']
    res = TransformationResult(tree, True, dependencies)
    assert res.tree is tree
    assert res.tree_changed is True
    assert res.dependencies == dependencies

# Generated at 2022-06-12 04:30:45.083712
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse("pass"), False, ["a", "b"]) is not None
    assert TransformationResult(ast.parse("pass"), True, ["a", "b"]) is not None

# Generated at 2022-06-12 04:32:34.158399
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    """Test constructor of class CompilationResult"""
    try:
        _ = CompilationResult(0, 0.0, (3, 7), [])
    except TypeError as ex:
        pytest.fail(str(ex))


# Generated at 2022-06-12 04:32:39.326982
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1, time=2, target=(3, 4), dependencies=['a'])
    assert compilation_result is not None
    assert compilation_result.files == 1
    assert compilation_result.time == 2
    assert compilation_result.target == (3, 4)
    assert compilation_result.dependencies == ['a']

# Generated at 2022-06-12 04:32:43.781448
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=None, tree_changed=False, dependencies=None)
    assert tr.tree is None
    assert not tr.tree_changed
    assert tr.dependencies is None


TransformationRequest = NamedTuple('TransformationRequest',
                                   [('tree', ast.AST),
                                    ('dependencies', List[str])])


# Generated at 2022-06-12 04:32:48.451620
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a.in'), Path('b.out')) == \
        InputOutput(Path('a.in'), Path('b.out'))

    assert InputOutput(Path('a.in'), Path('b.out')) != \
        InputOutput(Path('b.in'), Path('b.out'))

    assert InputOutput(Path('a.in'), Path('b.out')) != \
        InputOutput(Path('a.in'), Path('a.out'))


# Generated at 2022-06-12 04:32:50.051236
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    name_of_class = CompilationResult.__name__
    name_of_class2 = CompilationResult(1, 2, (3, 4), ['a', 'b']).__class__.__name__
    assert name_of_class == name_of_class2


# Generated at 2022-06-12 04:32:52.335818
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("pass")
    tr = TransformationResult(tree, False, [])
    assert isinstance(tr, TransformationResult)
    assert isinstance(tr.tree, ast.AST)


# Generated at 2022-06-12 04:32:54.302466
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.Module([])
    tree_changed = False
    dependencies = []
    TransformationResult(tree, tree_changed, dependencies)

# Generated at 2022-06-12 04:32:57.792274
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_io = InputOutput('input', 'output')
    assert input_io.input == 'input'
    assert input_io.output == 'output'
    assert isinstance(input_io.input, Path)
    assert isinstance(input_io.output, Path)

# Generated at 2022-06-12 04:32:59.879118
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a'), Path('b')) == \
           InputOutput(input=Path('a'), output=Path('b'))

# Generated at 2022-06-12 04:33:02.471213
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.Name('1', ast.Load()),
                                True, ['a', 'b', 'c'])