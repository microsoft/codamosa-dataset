

# Generated at 2022-06-12 04:25:24.050928
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path("input")
    output = Path("output")
    io = InputOutput(input=input, output=output)

    assert io.input == input
    assert io.input == "input"
    assert io.output == output
    assert io.output == "output"


# Generated at 2022-06-12 04:25:25.571129
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=1, time=0.0, target=(0, 0), dependencies=[])



# Generated at 2022-06-12 04:25:28.436670
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/abc')
    output = Path('/tmp/def')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output

# Generated at 2022-06-12 04:25:30.102122
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 1.0, (3, 5), ['1.py'])


# Generated at 2022-06-12 04:25:33.223147
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path.home()
    s = Path('/tmp')
    i_to_s = InputOutput(i, s)
    assert i_to_s.input == i
    assert i_to_s.output == s



# Generated at 2022-06-12 04:25:36.020549
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path_a = Path('a')
    path_b = Path('b')
    input_output = InputOutput(path_a, path_b)
    assert input_output.input == path_a
    assert input_output.output == path_b

# Generated at 2022-06-12 04:25:37.662004
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(
        ast.parse('print("no change")'), False, ['a', 'b'])

# Generated at 2022-06-12 04:25:42.375923
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.Num(0), True, ['one', 'two'])
    assert ast.dump(tr.tree) == 'Num(n=0)'
    assert tr.tree_changed
    assert tr.dependencies == ['one', 'two']

# Directory with the provided code examples
CODE_EXAMPLES_DIR = Path(__file__).parent

# Default target for compilation
DEFAULT_TARGET = (3, 6)

# Generated at 2022-06-12 04:25:49.828207
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("""1+2""")
    t = TransformationResult(tree, True, [])
    assert t.tree is tree
    assert t.tree_changed is True
    assert t.dependencies == []

# Result of SingleFileTransformer.transform method
SingleFileTransformationResult = NamedTuple('SingleFileTransformationResult',
                                            [('transformed_path', Path),
                                             ('tree_changed', bool),
                                             ('dependencies', List[str])])


# Generated at 2022-06-12 04:25:51.452241
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(tree=None, tree_changed=False,
                         dependencies=[])

# Generated at 2022-06-12 04:25:56.170063
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 0.1, (3, 5), ['foo', 'bar'])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 5)
    assert result.dependencies == ['foo', 'bar']



# Generated at 2022-06-12 04:25:58.450006
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1, time=0.1, target=(2, 7),
                                           dependencies=['file1'])

    assert(1 == compilation_result.files)

# Generated at 2022-06-12 04:25:59.850730
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(123, 42.0, (3, 6), [])


# Generated at 2022-06-12 04:26:04.198221
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p = Path('a')
    i = InputOutput(p, p)
    assert i.input == p
    assert i.output == p
    assert i.input == i.output

    i2 = InputOutput(Path('b'), Path('c'))
    assert i2.input != i2.output


# Generated at 2022-06-12 04:26:08.120272
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/home/stefan/input')
    output = Path('/home/stefan/output')

    assert InputOutput(input, output).input == input
    assert InputOutput(input, output).output == output


# Generated at 2022-06-12 04:26:11.725396
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('pass')
    result = TransformationResult(tree=t,
                                  tree_changed=True,
                                  dependencies=['1', '2'])
    assert result.tree == t
    assert result.tree_changed
    assert result.dependencies == ['1', '2']


# Generated at 2022-06-12 04:26:16.267760
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Type checks
    i = InputOutput(Path("foo.py"), Path("bar.py"))
    assert isinstance(i.input, Path)
    assert isinstance(i.output, Path)

    # Arguments are maintained
    assert i.input.name == "foo.py"
    assert i.output.name == "bar.py"

# Generated at 2022-06-12 04:26:17.668731
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 0.0, (3, 7), ['sys'])

# Generated at 2022-06-12 04:26:21.559706
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    transformation_result = TransformationResult(
        tree=tree, tree_changed=False, dependencies=[])
    assert isinstance(transformation_result, TransformationResult)
    assert transformation_result.tree == tree
    assert transformation_result.tree_changed is False
    assert transformation_result.dependencies == []

# Generated at 2022-06-12 04:26:26.876537
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=5,
                               target=(3, 7), dependencies=[])
    assert isinstance(result, CompilationResult)
    assert result.files == 1
    assert result.time == 5
    assert result.target == (3, 7)
    assert result.dependencies == []


# Generated at 2022-06-12 04:26:32.957086
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('x = 42')
    d = ['foo.py']
    x = TransformationResult(t, True, d)
    assert x.tree        == t
    assert x.tree_changed == True
    assert x.dependencies == d

# Generated at 2022-06-12 04:26:35.774012
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/foo/')
    output = Path('/foo/')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-12 04:26:38.195323
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1,
                      time=1.0,
                      target=(3, 6),
                      dependencies=['example.py'])


# Generated at 2022-06-12 04:26:39.919333
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 1.1, (2, 7), ['a', 'b'])


# Generated at 2022-06-12 04:26:41.698964
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.Module(), False, ['1'])

# Generated at 2022-06-12 04:26:44.238654
# Unit test for constructor of class InputOutput
def test_InputOutput():
    x = InputOutput(input='test1', output='test2')
    assert x.input == Path('test1')
    assert x.output == Path('test2')

# Generated at 2022-06-12 04:26:50.008204
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    with pytest.raises(TypeError):
        CompilationResult(input_files=1, time=0.1, target=(3, 6),
                          dependencies=['/etc/hosts'])

    with pytest.raises(TypeError):
        CompilationResult(files=1, input_time=0.1, target=(3, 6),
                          dependencies=['/etc/hosts'])

    with pytest.raises(TypeError):
        CompilationResult(files=1, time=0.1, target_python=(3, 6),
                          dependencies=['/etc/hosts'])

    with pytest.raises(TypeError):
        CompilationResult(files=1, time=0.1, target=(3, 6),
                          dependencies_list=['/etc/hosts'])


# Generated at 2022-06-12 04:26:53.647126
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("pass")
    tr = TransformationResult(tree, False, [])
    assert tr.tree == tree
    assert tr.tree_changed == False
    assert tr.dependencies == []

# Generated at 2022-06-12 04:26:57.331169
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p1 = Path('input')
    p2 = Path('output')
    io = InputOutput(p1, p2)
    assert io.input == 'input'
    assert io.output == 'output'


# Generated at 2022-06-12 04:26:59.549223
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('foo'), Path('bar')) == \
        InputOutput(input=Path('foo'), output=Path('bar'))

# Generated at 2022-06-12 04:27:03.956262
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    return TransformationResult(
        tree=ast.parse('a = 1'),
        tree_changed=True,
        dependencies=['b']
    )

# Generated at 2022-06-12 04:27:10.021039
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # type: () -> None
    result = CompilationResult(files=10, time=0.1, target=(3, 5), dependencies=['foo', 'bar'])
    assert result.files == 10
    assert result.time == 0.1
    assert result.target == (3, 5)
    assert result.dependencies == ['foo', 'bar']



# Generated at 2022-06-12 04:27:14.284240
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=2.0, target=(3, 4),
                               dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-12 04:27:16.170142
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(0, 0.0, (3, 5), [])

# Generated at 2022-06-12 04:27:20.782431
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_input = Path('test_input')
    test_output = Path('test_output')
    test_io = InputOutput(test_input, test_output)
    assert test_io.input == Path('test_input')
    assert test_io.output == Path('test_output')


# Generated at 2022-06-12 04:27:25.623898
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    ints = 10
    flts = 2.0
    tpl = (10, 10)
    lst = []
    res = CompilationResult(ints, flts, tpl, lst)
    assert res.files == ints
    assert res.time == flts
    assert res.target == tpl
    assert res.dependencies == lst


# Generated at 2022-06-12 04:27:29.668587
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=10, time=2.54, target=(3, 0),
                               dependencies=['some_file.py'])

    assert result.files == 10
    assert result.time == 2.54
    assert result.target == (3, 0)
    assert result.dependencies == ['some_file.py']


# Generated at 2022-06-12 04:27:33.769064
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(1, 2.0, (3, 4), ["a", "b"])
    assert compilation_result.files == 1
    assert compilation_result.time == 2.0
    assert compilation_result.target == (3, 4)
    assert compilation_result.dependencies == ["a", "b"]


# Generated at 2022-06-12 04:27:37.412385
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_node = ast.Name('x', ast.Load())
    result = TransformationResult(ast_node, True, ['module.foo'])
    assert result.tree is ast_node
    assert result.tree_changed is True
    assert result.dependencies[0] == 'module.foo'

# Generated at 2022-06-12 04:27:41.983414
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    target = (3, 7)
    result = CompilationResult(1, 2, target, [])
    assert isinstance(result.files, int)
    assert isinstance(result.time, float)
    assert isinstance(result.target, CompilationTarget)
    assert result.files == 1
    assert result.time == 2
    assert result.target == target



# Generated at 2022-06-12 04:27:50.663709
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=10, time=5.2,
                               target=(3, 6), dependencies=['a', 'b'])
    assert result.files == 10
    assert result.time == 5.2
    assert result.target == (3, 6)
    assert result.dependencies == ['a', 'b']



# Generated at 2022-06-12 04:27:52.959048
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    """Test the constructor for the TransformationResult NamedTuple."""
    TransformationResult(tree=None, tree_changed=False, dependencies=[])

# Generated at 2022-06-12 04:28:02.325934
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(ast.parse("3 + 4"),
                                  True,
                                  ['a', 'b'])
    assert result.tree is not None
    assert result.tree_changed is True
    assert result.dependencies == ['a', 'b']

# Result of type inferencer
InferringResult = NamedTuple('InferringResult',
                             [('tree', ast.AST),
                              ('dependencies', List[str])])

# Result of the processing
ProcessingResult = NamedTuple('ProcessingResult',
                              [('tree', ast.AST),
                               ('tree_changed', bool),
                               ('dependencies', List[str]),
                               ('target', CompilationTarget)])


# Generated at 2022-06-12 04:28:08.314059
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    def f(): return 0
    tree = ast.parse(inspect.getsource(f))
    tr = TransformationResult(tree, True, ['foo'])
    assert tr.tree is tree
    assert tr.tree_changed is True
    assert tr.dependencies == ['foo']


# Result of analysis of imports
ImportAnalysisResult = NamedTuple('ImportAnalysisResult',
                                  [('imports', int),
                                   ('from_imports', int)])

# Result of distribution of code for explicitness
ExplicitnessResult = NamedTuple('ExplicitnessResult',
                                [('explicit', int),
                                 ('implicit', int)])

# Result of distribution of code for implicitness

# Generated at 2022-06-12 04:28:12.300260
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(Path('/tmp/a'), Path('/tmp/b'))
    InputOutput(input=Path('/tmp/a'), output=Path('/tmp/b'))
    InputOutput(Path('/tmp/a'), output=Path('/tmp/b'))
    InputOutput(input=Path('/tmp/a'), output=Path('/tmp/b'))


# Generated at 2022-06-12 04:28:13.834188
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=None,
                                tree_changed=False,
                                dependencies=[])

# Generated at 2022-06-12 04:28:15.523016
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # type: () -> None
    CompilationResult(2, 3, (2, 7), ['dep'])


# Generated at 2022-06-12 04:28:23.989653
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    d1 = CompilationResult(10, 0.2, (2, 7), ['a', 'b'])
    d2 = CompilationResult(10, 0.2, (2, 7), ['c', 'd'])
    assert d1 == d2
    assert d1 != 'a'
    assert d1 == CompilationResult(10, 0.2, (2, 7), ['c', 'd'])
    assert CompilationResult(10, 0.2, (2, 7), ['c', 'd']) == CompilationResult(10, 0.2, (2, 7), ['c', 'd'])
    assert CompilationResult(10, 0.2, (2, 7), ['c', 'd']) != CompilationResult(10, 0.2, (2, 7), ['c'])

# Generated at 2022-06-12 04:28:26.959529
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tran = TransformationResult(ast.Name("a", ast.Load()), True, [])
    assert tran.tree.id == "a"
    assert tran.tree_changed == True
    assert tran.dependencies == []


# Generated at 2022-06-12 04:28:30.234987
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = 'tree'
    tree_changed = True
    dependencies = 'dependencies'
    tr = TransformationResult(tree, tree_changed, dependencies)
    assert tr.tree == tree
    assert tr.tree_changed == tree_changed
    assert tr.dependencies == dependencies

# Generated at 2022-06-12 04:28:44.137853
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    result = TransformationResult(tree, True, ['c', 'd'])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == ['c', 'd']

# Generated at 2022-06-12 04:28:46.806866
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Arrange
    input_ = 'input'
    output = 'output'

    # Act
    actual = InputOutput(input_, output)

    # Assert
    assert actual.input == Path(input_)
    assert actual.output == Path(output)


# Generated at 2022-06-12 04:28:53.067891
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=10,
                            time=3.14159,
                            target=(3, 4),
                            dependencies=['foo', 'bar'])
    assert res.files == 10, 'files should be 10'
    assert res.time == 3.14159, 'time should be 3.14159'
    assert res.target == (3, 4), 'target should be 3.4'
    assert res.dependencies == ['foo', 'bar'], \
        'dependencies should contain foo, bar'


# Generated at 2022-06-12 04:28:56.064215
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 0.1, (3, 5), [])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 5)
    assert len(result.dependencies) == 0



# Generated at 2022-06-12 04:29:01.653786
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(None, False, [])
    TransformationResult(None, False, None)
    TransformationResult(None, True, [])
    TransformationResult(None, True, None)

# Result of transformers visibility_scope_analysis
ScopeAnalysisResult = NamedTuple('ScopeAnalysisResult',
                                 [('tree', ast.AST),
                                  ('tree_changed', bool),
                                  ('dependencies', List[str]),
                                  ('scope_structure', List[int]),
                                  ('functions', List[str])])


# Generated at 2022-06-12 04:29:07.432946
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    not_compiled = CompilationResult(files=0,
                                     time=0,
                                     target=(0, 0),
                                     dependencies=[])

    compiled = CompilationResult(files=42,
                                 time=23.4,
                                 target=(2, 7),
                                 dependencies=['foo', 'bar'])

    assert (compiled.files, compiled.time, compiled.target,
            compiled.dependencies) == (42, 23.4, (2, 7), ['foo', 'bar'])

    assert (not_compiled.files, not_compiled.time, not_compiled.target,
            not_compiled.dependencies) == (0, 0, (0, 0), [])



# Generated at 2022-06-12 04:29:15.910767
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(None, False, [])
    assert isinstance(result, TransformationResult), \
        'TransformationResult() should create an instance of TransformationResult'
    assert result.tree is None, \
        'TransformationResult() should use the specified positional argument for `tree`'
    assert result.tree_changed is False, \
        'TransformationResult() should use the specified positional argument for `tree_changed`'
    assert result.dependencies == [], \
        'TransformationResult() should use the specified positional argument for `dependencies`'

    result = TransformationResult(tree=None, tree_changed=False, dependencies=[])
    assert isinstance(result, TransformationResult), \
        'TransformationResult() should create an instance of TransformationResult'

# Generated at 2022-06-12 04:29:18.499419
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree={}, tree_changed=True, dependencies=[])
    assert tr.tree == {}
    assert tr.tree_changed is True
    assert tr.dependencies == []


# Generated at 2022-06-12 04:29:23.522347
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(None, False, [])
    assert tr.tree is None
    assert tr.tree_changed is False
    assert tr.dependencies == []

    tr = TransformationResult(ast.Module(), True, ['a', 'b'])
    assert tr.tree is not None
    assert tr.tree_changed is True
    assert tr.dependencies == ['a', 'b']

# Generated at 2022-06-12 04:29:31.837887
# Unit test for constructor of class TransformationResult

# Generated at 2022-06-12 04:30:06.207503
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # type: () -> None
    i1 = InputOutput(input=Path('input'),
                     output=Path('output')) # type: InputOutput
    i2 = InputOutput(input=Path('input'),
                     output=Path('output')) # type: InputOutput

    # check the hash
    assert(hash(i1) == hash(i2))

    # check the equality
    assert(i1 == i2)

    # check the inequality
    assert(not (i1 != i2))

    # check comparison
    assert(i1 < i2)
    assert(not (i1 <= i2))
    assert(not (i1 > i2))
    assert(i1 >= i2)

    # check string
    assert(str(i1) == "{input: 'input', output: 'output'}")

    # check

# Generated at 2022-06-12 04:30:08.277425
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('input'), Path('output')).input == Path('input')
    assert InputOutput(Path('input'), Path('output')).output == Path('output')

# Generated at 2022-06-12 04:30:17.141891
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # all fields are correctly set
    input_path = Path('/test/test.py')
    output_path = Path('/test/test.output')
    a = InputOutput(input_path, output_path)
    assert isinstance(a.input, Path)
    assert isinstance(a.output, Path)
    assert a.input == input_path
    assert a.output == output_path

    # cannot set empty input path
    with pytest.raises(ValueError):
        a = InputOutput(Path(''), output_path)

    # cannot set input path which isn't a file
    with pytest.raises(ValueError):
        a = InputOutput(Path('/'), output_path)

    # cannot set empty output path

# Generated at 2022-06-12 04:30:23.204193
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1,
                                           time=1.0,
                                           target=(3, 5),
                                           dependencies=['{}'])

    assert isinstance(compilation_result.files, int)
    assert isinstance(compilation_result.time, float)
    assert isinstance(compilation_result.target, tuple)
    assert isinstance(compilation_result.dependencies, list)



# Generated at 2022-06-12 04:30:26.947500
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    time = 0.1
    files = 1
    target = (3, 8)
    dependencies = []
    cr = CompilationResult(files, time, target, dependencies)
    assert cr.files == files
    assert cr.time == time
    assert cr.target == target
    assert cr.dependencies == dependencies

# Generated at 2022-06-12 04:30:32.846737
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    ast_node = ast.parse('"Hello"')
    try:
        TransformationResult(ast_node, False, [])
        TransformationResult(ast_node, True, [])
    except TypeError as exc:
        assert False, str(exc)
    try:
        TransformationResult(ast_node, False, ['a', 'b'])
        TransformationResult(ast_node, True, ['a', 'b'])
    except TypeError as exc:
        assert False, str(exc)


# Generated at 2022-06-12 04:30:37.075369
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Test fields of the InputOutput class
    inputOutput = InputOutput(input=Path('input.py'), output=Path('output.py'))
    assert(inputOutput.input == Path('input.py'))
    assert(inputOutput.output == Path('output.py'))



# Generated at 2022-06-12 04:30:42.092009
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_target = (3, 7)
    compilation_result = CompilationResult(files=1,
                                           time=5.0,
                                           target=compilation_target,
                                           dependencies=['a','b','c'])
    assert compilation_result.files == 1
    assert compilation_result.time == 5.0
    assert compilation_result.target == compilation_target
    assert compilation_result.dependencies == ['a','b','c']


# Generated at 2022-06-12 04:30:44.628507
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.Module()
    result = TransformationResult(tree, False, [])
    assert result.tree == tree
    assert result.tree_changed == False
    assert result.dependencies == []

# Generated at 2022-06-12 04:30:48.835728
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.AST(), False, [])
    assert tr == TransformationResult(tr.tree, tr.tree_changed, tr.dependencies)
    assert tr != TransformationResult(ast.AST(), False, [])
    assert tr != TransformationResult(ast.AST(), True, tr.dependencies)
    assert tr != TransformationResult(ast.AST(), False, [])

# Generated at 2022-06-12 04:31:43.029775
# Unit test for constructor of class InputOutput
def test_InputOutput():
    ip = Path('../python-input.txt')
    op = Path('../python-output.txt')
    input_output = InputOutput(ip, op)
    assert input_output.input == ip
    assert input_output.output == op


# Generated at 2022-06-12 04:31:45.088680
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(ast.AST(), False, [])
    assert res.tree_changed == False
    assert res.dependencies == []
    assert res.tree == ast.AST()

# Generated at 2022-06-12 04:31:45.949846
# Unit test for constructor of class InputOutput
def test_InputOutput():
    _ = InputOutput(Path('a'), Path('b'))


# Generated at 2022-06-12 04:31:50.343459
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    input = Path('input.txt')
    output = Path('output.txt')
    result = CompilationResult(files=1, time=1.0,
                               target=(3, 7),
                               dependencies=['foo.py'])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 7)
    assert result.dependencies == ['foo.py']


# Generated at 2022-06-12 04:31:52.961031
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a + 1')
    tree_changed = True
    dependencies = []
    tr = TransformationResult(tree, tree_changed, dependencies)
    assert tr == TransformationResult(tree, tree_changed, dependencies)
    assert tr != None
    assert tr != object()

# Generated at 2022-06-12 04:31:55.274789
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i1 = InputOutput('a', 'b')
    assert (i1.input == Path('a')) and i1.output == Path('b')

# Unit test

# Generated at 2022-06-12 04:31:56.928265
# Unit test for constructor of class InputOutput
def test_InputOutput():
    try:
        InputOutput(Path('test_input.py'),
                    Path('test_output.py'))
    except Exception as e:
        raise AssertionError(e)



# Generated at 2022-06-12 04:31:59.923814
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Asserts
    i1 = '../corpus/a/a.py'
    o1 = '../corpus/a/bin/a.py'
    assert InputOutput(Path(i1), Path(o1))


# Generated at 2022-06-12 04:32:03.302020
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(input = Path('/dev/null'),
                               output = Path('/dev/null'))

    assert input_output.input == Path('/dev/null')
    assert input_output.output == Path('/dev/null')


# Generated at 2022-06-12 04:32:04.744330
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput("input", "output")
    assert input_output.input == "input"
    assert input_output.output == "output"

# Generated at 2022-06-12 04:33:01.746195
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    empty_nodes = []
    empty_dependencies = []
    assert TransformationResult(empty_nodes, True, empty_dependencies)


# Result of analysis
AnalysisResult = NamedTuple('AnalysisResult',
                            [('result', dict),
                             ('analyzed_files', int),
                             ('time', float),
                             ('target', CompilationTarget)])


# Generated at 2022-06-12 04:33:04.571503
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_tree = ast.parse('x = 10')
    changed = True
    dependencies = ['x10.py', 'y20.py']
    result = TransformationResult(ast_tree, changed, dependencies)
    assert result.tree == ast_tree
    assert result.tree_changed == changed
    assert result.dependencies == dependencies

# Generated at 2022-06-12 04:33:11.352134
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p1 = Path('a')
    p2 = Path('b')
    io = InputOutput(p1, p2)
    assert io.input == p1
    assert io.output == p2
    assert io != p1
    assert io != p2
    assert io != (p1, p2)
    assert io == InputOutput(p1, p2)
    assert io != InputOutput(p1, p1)
    assert io != InputOutput(p2, p2)
    assert io != InputOutput(p1, p2)
    assert hash(io) == hash(InputOutput(p1, p2))


# Generated at 2022-06-12 04:33:13.821171
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input=Path('input'), output=Path('output'))
    try:
        InputOutput(input='input', output='output')
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-12 04:33:17.031606
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(
        tree=None,
        tree_changed=True,
        dependencies=['a', 'b']
    )
    assert result.tree is None
    assert result.tree_changed is True
    assert result.dependencies == ['a', 'b']

# Generated at 2022-06-12 04:33:19.162064
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    """
    Constructor of class CompilationResult does not throw exception
    """
    CompilationResult(files=1, time=1.0, target=(3, 7), dependencies=['a', 'b'])


# Generated at 2022-06-12 04:33:24.413039
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(files=10, time=12.5, target=(3, 6),
                          dependencies=['a', 'b', 'c'])
    assert r.files == 10
    assert r.time == 12.5
    assert r.target == (3, 6)
    assert r.dependencies == ['a', 'b', 'c']


# Generated at 2022-06-12 04:33:26.194895
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(10, 2.3, (3, 7), ['/usr/bin/python3'])


# Generated at 2022-06-12 04:33:30.068864
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Test constructors
    input_output = InputOutput(Path('/tmp/input.py'),
                               Path('/tmp/output.py'))
    input_output = InputOutput(input=Path('/tmp/input.py'),
                               output=Path('/tmp/output.py'))

    # Test attributes
    input_output.input
    input_output.output


# Generated at 2022-06-12 04:33:34.639161
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/dummy.py')
    output = Path('/tmp/dummy.py.pyx')
    input_output = InputOutput(input=input, output=output)

    assert isinstance(input_output, InputOutput)
    assert input_output.input == input
    assert input_output.output == output

