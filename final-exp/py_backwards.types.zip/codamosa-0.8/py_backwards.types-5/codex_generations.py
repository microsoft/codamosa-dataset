

# Generated at 2022-06-12 04:25:24.077423
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(1, 2.0, (3, 4), ['foo', 'bar'])
    assert cr.files == 1
    assert cr.time == 2.0
    assert cr.target == (3, 4)
    assert cr.dependencies == ['foo', 'bar']


# Generated at 2022-06-12 04:25:27.435740
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path("/tmp/input")
    output = Path("/tmp/output")
    input_output = InputOutput(input=input_, output=output)
    assert input_output.input == input_
    assert input_output.output == output


# Generated at 2022-06-12 04:25:29.939669
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = TransformationResult(
        ast.parse(''), False, [])
    tree = TransformationResult(
        tree.tree, True, ['foo.py', 'bar.py'])

# Generated at 2022-06-12 04:25:32.680502
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Type check
    InputOutput('input', 'output')  # type: ignore
    # Field names check
    with pytest.raises(AttributeError):
        InputOutput('input', extra_field='output')

# Generated at 2022-06-12 04:25:33.973734
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path(''), Path(''))



# Generated at 2022-06-12 04:25:36.415706
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    res = TransformationResult(tree, True, [])

    assert res.tree_changed
    assert not res.dependencies
    assert res.tree == tree

# Generated at 2022-06-12 04:25:37.622820
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    TransformationResult(None, None, None)

# Generated at 2022-06-12 04:25:40.710503
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(10, 10.0, (2, 7), [])
    assert cr.files == 10
    assert cr.time == 10.0
    assert cr.target == (2, 7)
    assert cr.dependencies == []


# Generated at 2022-06-12 04:25:42.213457
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=None, tree_changed=False,
                                dependencies=[]).tree_changed == False

# Generated at 2022-06-12 04:25:43.358881
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    _ = TransformationResult(tree=None, tree_changed=False, dependencies=[])

# Generated at 2022-06-12 04:25:48.332674
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path('foo.py'), Path('bar.py'))
    assert io.input == Path('foo.py')
    assert io.output == Path('bar.py')


# Generated at 2022-06-12 04:25:51.701494
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('a')
    output = Path('b')

    iop = InputOutput(input, output)
    assert iop.input == input
    assert iop.output == output


# Generated at 2022-06-12 04:25:56.705439
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    # pylint: disable=no-init

    class SomeTree(object):
        pass

    some_tree = SomeTree()
    result = TransformationResult(some_tree, False, [])

    assert isinstance(result.tree, SomeTree)
    assert result.tree_changed is False
    assert result.dependencies == []

# Generated at 2022-06-12 04:25:57.802723
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input=Path('.'), output=Path('.'))


# Generated at 2022-06-12 04:26:00.736447
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=2,
                               time=0.01,
                               target=(3, 6),
                               dependencies=["utils.py"])
    assert result.files == 2
    assert result.time == 0.01
    assert result.target == (3, 6)
    assert result.dependencies == ["utils.py"]

# Generated at 2022-06-12 04:26:08.931443
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.Module([]),
                         True,
                         ['a', 'b', 'c'])

# Result of compiler transformation
CompilationTransformationResult = NamedTuple('CompilationTransformationResult',
                                             [('compilation_result', CompilationResult),
                                              ('tree', ast.AST)])

# Result of executor
ExecutorResult = NamedTuple('ExecutorResult',
                            [('exit', int),
                             ('stdout', bytes),
                             ('stderr', bytes),
                             ('time', float)])


# Generated at 2022-06-12 04:26:12.643633
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(5, 2.5, (3, 5), ['foo.py', 'bar.py'])
    assert res.files == 5
    assert res.time == 2.5
    assert res.target == (3, 5)
    assert res.dependencies == ['foo.py', 'bar.py']



# Generated at 2022-06-12 04:26:14.796652
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p = Path("/foo/bar")
    i = InputOutput(p, p)
    assert i.input is p
    assert i.output is p

# Generated at 2022-06-12 04:26:22.909071
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(
        ast.parse('x = 1'), True, ['a', 'b']) == TransformationResult(
            ast.parse('x = 1'), True, ['a', 'b'])
    assert TransformationResult(
        ast.parse('x = 1'), True, ['a', 'b']) != TransformationResult(
            ast.parse('x = 1'), False, ['a', 'b'])
    assert TransformationResult(
        ast.parse('x = 1'), True, ['a', 'b']) != TransformationResult(
            ast.parse('x = 2'), True, ['a', 'b'])
    assert TransformationResult(
        ast.parse('x = 1'), True, ['a', 'b']) != TransformationResult(
            ast.parse('x = 1'), True, ['a'])

# Generated at 2022-06-12 04:26:28.944949
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Check that data is stored
    io = InputOutput(Path('input'), Path('output'))
    assert io.input == Path('input')
    assert io.output == Path('output')
    # Check that input and output can be different object
    io = InputOutput('input', 'output')
    assert io.input == 'input'
    assert io.output == 'output'


# Generated at 2022-06-12 04:26:34.121174
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(
        ast.parse('pass'), True, ['foo.py', 'bar.py']
    )
    assert result.tree
    assert isinstance(result.tree, ast.AST)
    assert result.tree_changed is True
    assert result.dependencies == ['foo.py', 'bar.py']

# Generated at 2022-06-12 04:26:39.013555
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=0,
                               time=1.1,
                               target=(3, 5),
                               dependencies=['a', 'b'])
    assert result.files == 0
    assert result.time == 1.1
    assert result.target == (3, 5)
    assert result.dependencies == ['a', 'b']



# Generated at 2022-06-12 04:26:43.032425
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    r = TransformationResult(ast.AST(), False, [])
    assert isinstance(r.tree, ast.AST)
    assert isinstance(r.tree_changed, bool)
    assert isinstance(r.dependencies, list)

# Generated at 2022-06-12 04:26:45.028661
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(tree=None,
                             tree_changed=False,
                             dependencies=[])

# Generated at 2022-06-12 04:26:51.822581
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Constructor
    cr = CompilationResult(1, 0.1, CompilationTarget(3, 6), [])

    # Check type
    assert isinstance(cr, CompilationResult)  # type: ignore

    # Check attributes
    assert cr.files == 1
    assert cr.time == 0.1
    assert cr.target == (3, 6)
    assert cr.dependencies == []


# Generated at 2022-06-12 04:26:55.977075
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    import random
    _ = CompilationResult(random.randint(0, 100), random.random(),
                          (random.randint(0, 10), random.randint(0, 10)),
                          [])


# Generated at 2022-06-12 04:27:00.677559
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    a = CompilationResult(files=1, time=0.5,
                          target=(3, 5),
                          dependencies=['foo.py'])
    assert a.files == 1
    assert a.time == 0.5
    assert a.target == (3, 5)
    assert a.dependencies == ['foo.py']

# Generated at 2022-06-12 04:27:04.388960
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    assert len(TransformationResult._fields) == 3
    assert TransformationResult(None, None, None).tree is None
    assert TransformationResult(None, None, None).tree_changed is None
    assert TransformationResult(None, None, None).dependencies is None

# Generated at 2022-06-12 04:27:08.194236
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=0,
                               time=0.0,
                               target=(0, 0),
                               dependencies=[''])
    assert result


# Generated at 2022-06-12 04:27:11.773920
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("a = 1")
    dependencies = []
    res = TransformationResult(tree, False, dependencies)
    assert res.tree == tree
    assert res.tree_changed == False
    assert res.dependencies == dependencies

# Generated at 2022-06-12 04:27:18.617953
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = 'path/1.py'
    output = 'path/2.py'
    assert InputOutput(input_, output).input == 'path/1.py'
    assert InputOutput(input_, output).output == 'path/2.py'


# Generated at 2022-06-12 04:27:21.252949
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('test.py')
    output = Path('test.py')
    result = InputOutput(input, output)
    assert result.input == input
    assert result.output == output

# Generated at 2022-06-12 04:27:26.379682
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.AST(), False, [])


# Command line arguments
CommandLineArguments = NamedTuple('CommandLineArguments',
                                  [('num_threads', int),
                                   ('verbose', bool),
                                   ('source_path', Path),
                                   ('target_path', Path),
                                   ('target', CompilationTarget),
                                   ('use_cached', bool)])


# Generated at 2022-06-12 04:27:29.804874
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(
        tree=ast.AST(),
        tree_changed=False,
        dependencies=[]
    )
    assert res.tree is not None
    assert res.tree_changed is True or res.tree_changed is False
    assert isinstance(res.dependencies, list)

# Generated at 2022-06-12 04:27:32.270547
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # pylint: disable=R0913
    _ = TransformationResult(tree = None,
                             tree_changed = None,
                             dependencies = None)

# Generated at 2022-06-12 04:27:34.906928
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse('a = 1'), True, []) == TransformationResult(tree=ast.parse('a = 1'),
                                                                                       tree_changed=True,
                                                                                       dependencies=[])

# Generated at 2022-06-12 04:27:37.093350
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=2.0,
                      target=(3, 4), dependencies=['a'])


# Generated at 2022-06-12 04:27:40.374088
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    """
    Just check, if all values are properly assigned
    """
    result = TransformationResult(ast.parse('pass'), True, [])
    assert result.tree_changed == True
    assert len(result.dependencies) == 0

# Generated at 2022-06-12 04:27:43.244497
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    import ast
    r = TransformationResult(
        ast.parse('x'),
        False,
        ['a', 'b'])
    assert r.tree_changed == False
    assert r.dependencies == ['a', 'b']

# Generated at 2022-06-12 04:27:51.193737
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    tests = [
        CompilationResult(files=1,
                          time=1.0,
                          target=(3, 5),
                          dependencies=[]),
        CompilationResult(files=3,
                          time=3.0,
                          target=(3, 3),
                          dependencies=['a', 'b', 'c']),
    ]
    for t in tests:
        assert t.files == t.files
        assert t.time == t.time
        assert t.target[0] == t.target[0]
        assert t.target[1] == t.target[1]
        assert t.dependencies == t.dependencies


# Generated at 2022-06-12 04:28:01.960773
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    def assert_equals(actual, expected):
        assert actual == expected

    tf_res = TransformationResult(None, True, None)
    assert isinstance(tf_res, TransformationResult)
    assert_equals(tf_res, (None, True, None))

    tf_res = TransformationResult(1, True, 2)
    assert isinstance(tf_res, TransformationResult)
    assert_equals(tf_res, (1, True, 2))

    tf_res = TransformationResult(3, False, 4)
    assert isinstance(tf_res, TransformationResult)
    assert_equals(tf_res, (3, False, 4))


# Generated at 2022-06-12 04:28:04.780153
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_input = Path('test_input')
    test_output = Path('test_output')
    io = InputOutput(test_input, test_output)
    assert io.input == test_input and io.output == test_output


# Generated at 2022-06-12 04:28:10.424548
# Unit test for constructor of class CompilationResult
def test_CompilationResult():

    assert CompilationResult(1, 1.0, (3, 7), []).files == 1
    assert CompilationResult(1, 1.0, (3, 7), []).time == 1.0
    assert CompilationResult(1, 1.0, (3, 7), []).target == (3, 7)
    assert CompilationResult(1, 1.0, (3, 7), []).dependencies == []


# Generated at 2022-06-12 04:28:11.927977
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(42, 42.0, (3, 5), "Dependencies")


# Generated at 2022-06-12 04:28:15.293244
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput('input', 'output')

    assert isinstance(input_output.input, Path)
    assert isinstance(input_output.output, Path)
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')



# Generated at 2022-06-12 04:28:23.457583
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    import ast

    tree: ast.AST = ast.parse('def f(a):pass')
    result = TransformationResult(tree, True, ['foo/bar.py',
                                               'foo/baz/bar.py'])

    assert(result.tree is tree)
    assert(result.tree_changed == True)
    assert(result.dependencies == ['foo/bar.py', 'foo/baz/bar.py'])

    result = TransformationResult(tree, False, ['foo/baz.py',
                                                'foo/baz/bar.py'])
    assert(result.tree is tree)
    assert(result.tree_changed == False)
    assert(result.dependencies == ['foo/baz.py', 'foo/baz/bar.py'])

# Generated at 2022-06-12 04:28:29.801639
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Typical values
    input = Path("input")
    output = Path("output")
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output

    # Alternative input
    input = Path("/home/input/")
    del input_output
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output

    # Alternative output
    output = Path("output/")
    del input_output
    input_output = InputOu

# Generated at 2022-06-12 04:28:33.499813
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=42,
                               time=13.37,
                               target=(3, 7),
                               dependencies=[])
    assert result.files == 42
    assert result.time == 13.37
    assert result.target == (3, 7)
    assert result.dependencies == []



# Generated at 2022-06-12 04:28:35.192518
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=2, target=(3, 4), dependencies=[])
    assert True

# Generated at 2022-06-12 04:28:37.432654
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    r = TransformationResult(None, False, [])
    assert r.tree is None
    assert r.tree_changed is False
    assert len(r.dependencies) == 0

# Generated at 2022-06-12 04:28:47.210723
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=["hello.py"])
    assert cr.files == 1, "Wrong files count"
    assert cr.time == 1.0, "Wrong time"
    assert cr.target == (3, 6), "Wrong target"
    assert cr.dependencies == ["hello.py"], "Wrong dependencies"


# Generated at 2022-06-12 04:28:51.610348
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 1
    time = 1.2
    target = (3, 6)
    dependencies = ['a/b.py']

    result = CompilationResult(files, time, target, dependencies)

    assert result.files == files
    assert result.time == time
    assert result.target == target
    assert result.dependencies == dependencies

# Generated at 2022-06-12 04:28:54.818228
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inputs = [('input', 'output')]
    for input, output in inputs:
        pair = InputOutput(input, output)
        assert pair.input == input
        assert pair.output == output
        assert pair[0] == input
        assert pair[1] == output



# Generated at 2022-06-12 04:28:56.832494
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(ast.Module(), True, ['foo.py'])
    assert res.tree_changed == True
    assert res.dependencies == ['foo.py']



# Generated at 2022-06-12 04:28:59.541986
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    result = TransformationResult(tree, True, ['a', 'b'])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == ['a', 'b']

# Generated at 2022-06-12 04:29:03.836965
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    test_result = CompilationResult(files=1,
                                    time=0.1,
                                    target=(3, 0),
                                    dependencies=["libfoo.py"])
    assert test_result.files == 1
    assert test_result.time == 0.1
    assert test_result.target == (3, 0)
    assert test_result.dependencies == ['libfoo.py']


# Generated at 2022-06-12 04:29:07.778469
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=0,
                               time=0.0,
                               target=(3,5),
                               dependencies=[])
    assert isinstance(result.files, int)
    assert isinstance(result.time, float)
    assert isinstance(result.target, CompilationTarget)
    assert isinstance(result.dependencies, list)


# Generated at 2022-06-12 04:29:10.450646
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    import astor
    program = astor.to_source(ast.parse("x = 2"))
    tree = astor.code_to_ast.parse_string(program)
    assert TransformationResult(tree, False, []).dependencies == []

# Generated at 2022-06-12 04:29:16.147545
# Unit test for constructor of class InputOutput
def test_InputOutput():
    import pathlib
    io = InputOutput(pathlib.Path("/home/test/input.py"),
                     pathlib.Path("/home/test/output.py"))
    assert str(io) == "(input = /home/test/input.py, output = /home/test/output.py)"
    assert repr(io) == "InputOutput(input = pathlib.Path('/home/test/input.py'), \
output = pathlib.Path('/home/test/output.py'))"


# Generated at 2022-06-12 04:29:19.056504
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    import six
    import ast
    import inspect
    import sys

    assert isinstance(inspect.getmodule(TransformationResult), ast.Module)
    assert sys.version_info >= six.PY3_3


# Problems during transformation

# Generated at 2022-06-12 04:29:33.678487
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(3, 0.234, (3, 7), ['file1', 'file3'])
    assert result.files == 3
    assert result.time == 0.234
    assert result.target == (3, 7)
    assert result.dependencies == ['file1', 'file3']


# Generated at 2022-06-12 04:29:37.185549
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path('foo')
    path2 = Path('bar')
    io1 = InputOutput(input=path1, output=path2)
    io2 = InputOutput(path1, path2)
    io3 = InputOutput(['foo', 'bar'])
    assert io1 == io2 == io3


# Generated at 2022-06-12 04:29:39.689182
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput('input', 'output')
    assert input_output.input == 'input'
    assert input_output.output == 'output'


# Unit tests for constructor of class CompilationResult

# Generated at 2022-06-12 04:29:41.149260
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(3, 5), dependencies=[])



# Generated at 2022-06-12 04:29:43.033691
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.Constant(1),
                              True,
                              [])
    assert tr.tree_changed == True and tr.dependencies == []

# Generated at 2022-06-12 04:29:48.053886
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """Test constructor of InputOutput"""
    this_name = sys._getframe().f_code.co_name

    # Check constructor
    a = InputOutput(input=Path('/tmp'), output=Path('/tmp/a.py'))
    assert a.input == Path('/tmp')
    assert a.output == Path('/tmp/a.py')

    # Check constructor
    a = InputOutput(input='/tmp', output='/tmp/a.py')
    assert a.input == Path('/tmp')
    assert a.output == Path('/tmp/a.py')

    # Check invalid input
    with pytest.raises(TypeError):
        InputOutput(input=Path('/tmp'), output='/tmp/a.py')


# Generated at 2022-06-12 04:29:51.304813
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=ast.Module(), tree_changed=False,
                              dependencies=['file1.py', 'file2.py'])
    assert isinstance(tr.tree, ast.AST)
    assert isinstance(tr.tree_changed, bool)
    assert isinstance(tr.dependencies, list)

# Generated at 2022-06-12 04:29:55.186510
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(files=1,
                          time=1.23,
                          target=(3, 4),
                          dependencies=['file:///example/foo'])
    assert r.files == 1
    assert r.time == 1.23
    assert r.target == (3, 4)
    assert r.dependencies == ['file:///example/foo']


# Generated at 2022-06-12 04:30:03.683312
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # type: () -> None
    # creation
    assert InputOutput(input=Path('input'), output=Path('output'))
    # compare
    assert InputOutput(input=Path('input'), output=Path('output')) == InputOutput(input=Path('input'), output=Path('output'))
    # repr
    assert repr(InputOutput(input=Path('input'), output=Path('output'))) == "InputOutput(input=PosixPath('input'), output=PosixPath('output'))"


# Generated at 2022-06-12 04:30:06.207161
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(ast.Module([]), False, [])
    assert res
    assert isinstance(res, TransformationResult)
    res = TransformationResult(ast.Module([]), True, [])
    assert res
    assert isinstance(res, TransformationResult)

# Generated at 2022-06-12 04:30:35.674207
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(tree=ast.parse("a=b"),
                                  tree_changed=True,
                                  dependencies=["a", "b"])

    assert isinstance(result.tree, ast.AST)
    assert isinstance(result.tree_changed, bool)
    assert isinstance(result.dependencies, list)



# Generated at 2022-06-12 04:30:37.532269
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(3, 7), dependencies=[])



# Generated at 2022-06-12 04:30:43.606540
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(trees.parse('x=123'),
                                False,
                                ['abc']).dependencies == ['abc']

# Transformer of ast nodes. Accepts AST node and returns
# TransformationResult tuple
Transformer = Callable[[ast.AST], TransformationResult]

# List of transformers
Transformers = List[Transformer]

# List of InputOutput tuples
InputOutputs = List[InputOutput]



# Builds compilator
#
#   transformers - list of transformers
#   target       - target python version
#
# Returns compilator

# Generated at 2022-06-12 04:30:45.047904
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 1.0, (3, 7), ['a'])


# Generated at 2022-06-12 04:30:46.463262
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(0, 0.0, (3, 7), [])


# Generated at 2022-06-12 04:30:49.997066
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_file = Path("test_input")
    output_file = Path("test_output")
    input_output = InputOutput(input_file, output_file)

    assert(input_output.input == input_file)
    assert(input_output.output == output_file)


# Generated at 2022-06-12 04:30:53.063348
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('test.py'), Path('test.c'))
    assert input_output.input == Path('test.py')
    assert input_output.output == Path('test.c')


# Generated at 2022-06-12 04:30:57.194940
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=4, time=3.4, target=(3, 8), dependencies=['a', 'b'])
    assert c.files == 4
    assert c.time == 3.4
    assert c.target == (3, 8)
    assert c.dependencies == ['a', 'b']


# Generated at 2022-06-12 04:31:01.537520
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Test normal constructor
    CompilationResult(1, 2, (2, 3), ['a'])
    # Test that this should raise TypeError
    with pytest.raises(TypeError):
        CompilationResult(1, '2', (2, 3), ['a'])



# Generated at 2022-06-12 04:31:04.590251
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path("input")
    output_path = Path("output")
    input_output = InputOutput(input_path, output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path



# Generated at 2022-06-12 04:32:03.820115
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a'), Path('b')).input == Path('a')
    assert InputOutput(Path('a'), Path('b')).output == Path('b')


# Generated at 2022-06-12 04:32:05.517244
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path("file.py"), Path("file2.py")) == InputOutput("file.py", "file2.py")

# Generated at 2022-06-12 04:32:09.529910
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_file = Path('input')
    output_file = Path('output')
    io = InputOutput(input_file, output_file)
    assert io.input is input_file
    assert io.output is output_file
    assert io == InputOutput(input_file, output_file)
    assert io != InputOutput(input_file, input_file)
    assert io != InputOutput(output_file, output_file)
    assert io != 'test'


# Generated at 2022-06-12 04:32:12.909711
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path('some_file')
    path2 = Path('other_file')
    input_output = InputOutput(path1, path2)
    assert input_output.input == path1
    assert input_output.output == path2


# Generated at 2022-06-12 04:32:16.309388
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=1, time=1.0, target=(3, 8), dependencies=['a', 'b'])
    assert res.files == 1
    assert res.time == 1.0
    assert res.target[0] == 3
    assert res.target[1] == 8
    assert res.dependencies == ['a', 'b']


# Generated at 2022-06-12 04:32:20.284593
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # type: () -> None
    from typing import Any, Callable

    # Static type check
    def check(input_: Any, output: Any) -> None:
        # type: (Any, Any) -> None
        io = InputOutput(input_, output)
        assert io.input == input_
        assert io.output == output

    # Successful instantiation
    check('input', 'output')
    check(None, Path())

# Generated at 2022-06-12 04:32:21.394441
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=5, time=3.7, target=(2, 7))


# Generated at 2022-06-12 04:32:23.727397
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=None, tree_changed=False, dependencies=[])._asdict() == {
        'tree': None,
        'tree_changed': False,
        'dependencies': []
    }

# Generated at 2022-06-12 04:32:27.597487
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cmp = CompilationResult(
        files=1,
        time=2.2,
        target=(3, 4),
        dependencies=['a', 'b', 'c']
    )
    assert cmp.files == 1
    assert cmp.time == 2.2
    assert cmp.target == (3, 4)
    assert cmp.dependencies == ['a', 'b', 'c']



# Generated at 2022-06-12 04:32:33.572767
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    def check(obj, tree, tree_changed, dependencies):
        assert obj.tree == tree
        assert obj.tree_changed == tree_changed
        assert obj.dependencies == dependencies

    # Dummy AST object and dependency set
    obj = object()
    dependencies = {'foo', 'bar'}
    # Correct values
    check(TransformationResult(obj, True, dependencies), obj, True, dependencies)
    check(TransformationResult(obj, False, dependencies), obj, False, dependencies)
    # Incorrect value
    with pytest.raises(ValueError):
        TransformationResult(obj, '', dependencies)

# Generated at 2022-06-12 04:34:29.688719
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(ast.parse('if True: pass'), False, [])
    assert t.tree is not None
    assert not t.tree_changed
    assert len(t.dependencies) == 0

# Generated at 2022-06-12 04:34:31.987002
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Check that parameters are assigned to corresponding fields
    result = CompilationResult(files=1, time=2.3, target=(3, 4), dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 2.3
    assert r

# Generated at 2022-06-12 04:34:35.689833
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(1, 2.0, (3, 4), [])
    assert(compilation_result.files == 1)
    assert(compilation_result.time == 2.0)
    assert(compilation_result.target == (3, 4))
    assert(compilation_result.dependencies == [])


# Generated at 2022-06-12 04:34:38.209852
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=1, time=0.0,
                             target=(3, 7),
                             dependencies=["/path/to/dependency1.py"])


# Generated at 2022-06-12 04:34:40.177423
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(None, False, [])
    TransformationResult(None, True, [])
    TransformationResult(None, True, ["hello"])

# Generated at 2022-06-12 04:34:43.368584
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    module_substitute = ast.Module(body=[])
    tree_changed = True
    dependencies = ['/tmp/a.py', '/tmp/b.py']
    assert TransformationResult(module_substitute, tree_changed, dependencies)

# Generated at 2022-06-12 04:34:45.612272
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert isinstance(TransformationResult(None, None, None),
                      TransformationResult)

# Generated at 2022-06-12 04:34:51.491445
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x=2')
    tr = TransformationResult(tree=tree, tree_changed=True,
                              dependencies=['asdf'])
    assert tr.tree == tree
    assert tr.tree_changed
    assert tr.dependencies == ['asdf']


# A filename and what type of compilation is expected
CompilationInfo = NamedTuple('CompilationInfo', [('name', str),
                                                 ('target', CompilationTarget)])

# A test for the constructor of CompilationInfo

# Generated at 2022-06-12 04:34:56.876416
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cresult = CompilationResult(files=1, time=10.0, target=(3, 6),
                                dependencies=['a', 'b', 'c'])

    assert cresult.files == 1
    assert cresult.time == 10.0
    assert cresult.target == (3, 6)
    assert cresult.dependencies == ['a', 'b', 'c']


# Generated at 2022-06-12 04:34:59.662297
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Test default values
    result = CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=[])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == []

