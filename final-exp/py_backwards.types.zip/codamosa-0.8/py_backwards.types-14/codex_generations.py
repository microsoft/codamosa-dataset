

# Generated at 2022-06-12 04:25:23.726213
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('/etc/input')
    output = Path('/root/output')
    pair = InputOutput(input_, output)
    assert pair.input == input_
    assert pair.output == output

# Generated at 2022-06-12 04:25:27.388300
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('input.txt')
    output_path = Path('output/') / input_path.name
    input_output = InputOutput(input_path, output_path)

    assert input_output.input == input_path
    assert input_output.output == output_path


# Generated at 2022-06-12 04:25:31.325305
# Unit test for constructor of class TransformationResult
def test_TransformationResult():

    # Test simple instantiation
    ast_node = ast.parse('x = "a"')
    r = TransformationResult(ast_node, False, [])

    # Test access to fields
    assert r.tree == ast_node
    assert r.tree_changed == False
    assert r.dependencies == []

# Generated at 2022-06-12 04:25:32.635987
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(None, None)

# Unit tests for constructor of class TransformationResult

# Generated at 2022-06-12 04:25:34.920695
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = InputOutput(input=Path('input'), output=Path('output'))
    assert i.input == Path('input')
    assert i.output == Path('output')



# Generated at 2022-06-12 04:25:39.627082
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('tests/data/fixture1.py')
    output = Path('tests/data/fixture1_out.py')
    input_output = InputOutput(input=input, output=output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-12 04:25:46.162525
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=None,
                              tree_changed=False,
                              dependencies=['a', 'b'])
    assert tr.tree is None
    assert tr.tree_changed is False
    assert tr.dependencies == ['a', 'b']

# Result of transformers transformation
TextReplacement = NamedTuple('TextReplacement', [('offset', int),
                                                 ('length', int),
                                                 ('text', str)])


# Generated at 2022-06-12 04:25:48.168056
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = InputOutput(Path('i'), Path('o'))
    assert input.input == Path('i')
    assert input.output == Path('o')

# Generated at 2022-06-12 04:25:55.454784
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=1,
                                tree_changed=True,
                                dependencies=['a.py', 'b.py']) \
           == TransformationResult(tree=1,
                                   tree_changed=True,
                                   dependencies=['a.py', 'b.py'])

# Result of mode transformation
ModeTransformationResult = NamedTuple('ModeTransformationResult',
                                      [('tree', ast.AST),
                                       ('tree_changed', bool),
                                       ('dependencies', List[str]),
                                       ('intermediates', List[Path])])


# Generated at 2022-06-12 04:26:02.004936
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # pylint: disable=R0915
    """ Checks that TransformationResult constructor works by covering
    all branches of the code. """
    ast_tree = ast.parse('''def foo():      # pylint: disable=W0108
        a = 1
        return a''')
    # test all possible branches
    TransformationResult(ast_tree, False, [])
    TransformationResult(ast_tree, False, ['/a/b/c'])
    TransformationResult(ast_tree, True, [])
    TransformationResult(ast_tree, True, ['/a/b/c'])

# PEP 8 says that classes should have capital letters for names,
# but we want to use python conventions for variable names
# pylint: disable=C0103

# Generated at 2022-06-12 04:26:04.425825
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    T = TransformationResult(ast.parse('a = 1'), False, [])

# Generated at 2022-06-12 04:26:13.615842
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    for sample in [CompilationResult(files=0,
                                     time=0.0,
                                     target=(0, 0),
                                     dependencies=[]),
                   CompilationResult(files=2,
                                     time=3.0,
                                     target=(0, 0),
                                     dependencies=[]),
                   CompilationResult(files=2,
                                     time=3.0,
                                     target=(0, 0),
                                     dependencies=['foo']),
                   CompilationResult(files=2,
                                     time=3.0,
                                     target=(0, 0),
                                     dependencies=['foo', 'bar']),
                   CompilationResult(files=2,
                                     time=3.0,
                                     target=(0, 0),
                                     dependencies=['foo', 'bar', 'baz'])]:
        assert sample

# Generated at 2022-06-12 04:26:18.713633
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # pylint: disable=unused-variable; assertion only
    tr = TransformationResult(tree=None, tree_changed=True, dependencies=[])
    tr = TransformationResult(tree=None, tree_changed=False, dependencies=[])

# Result of compile stage
CompileResult = NamedTuple('CompileResult', [('result', bytes),
                                             ('dependencies', List[str])])


# Generated at 2022-06-12 04:26:21.488078
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a'), Path('b')) == InputOutput(Path('a'), Path('b'))
    assert InputOutput(Path('a'), Path('b')) != InputOutput(Path('c'), Path('d'))


# Generated at 2022-06-12 04:26:25.435243
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    args = (ast.AST(0), False, [])
    tr = TransformationResult(*args)
    assert tr.tree == args[0] and tr.tree_changed == args[1] and tr.dependencies == args[2]

# Generated at 2022-06-12 04:26:31.075879
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p1 = Path('foo')
    p2 = Path('bar')
    io = InputOutput(input=p1, output=p2)
    assert(io.input == p1)
    assert(io.output == p2)
    io = io._replace(input=p2)
    assert(io.input == p2)
    assert(io.output == p2)

# Generated at 2022-06-12 04:26:35.598905
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=None, tree_changed=False, dependencies=[])
    assert tr.tree is None
    assert tr.tree_changed is False
    assert tr.dependencies == []
    assert str(tr.tree) == 'None'


# Result of transformers compilation
CompilationResult = NamedTuple('CompilationResult',
                               [('files', int),
                                ('time', float),
                                ('target', CompilationTarget),
                                ('dependencies', List[str])])


# Generated at 2022-06-12 04:26:41.549277
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=2.0,
                               target=(3, 4),
                               dependencies=['/tmp/a', '/tmp/b'])

    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == ['/tmp/a', '/tmp/b']


# Generated at 2022-06-12 04:26:44.058150
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('input'), Path('output'))
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')

# Generated at 2022-06-12 04:26:47.483799
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(10, 10, (3, 7), ['a', 'b'])
    assert cr.files == 10
    assert cr.time == 10
    assert cr.target == (3, 7)
    assert cr.dependencies == ['a', 'b']


# Generated at 2022-06-12 04:26:56.133862
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('print(1)')

    t1 = TransformationResult(tree, False, [])
    assert isinstance(t1.tree, ast.Module)
    assert t1.tree_changed is False
    assert t1.dependencies == []

    t2 = TransformationResult(tree, True, ['import ast', 'import main'])

    assert isinstance(t2.tree, ast.Module)
    assert t2.tree_changed is True
    assert t2.dependencies == ['import ast', 'import main']

# Generated at 2022-06-12 04:26:58.792783
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path("input"), Path("output"))
    assert input_output.input.name == "input"
    assert input_output.output.name == "output"

# Generated at 2022-06-12 04:27:01.011224
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # type: () -> None
    CompilationResult(1, 1.0, (2, 5), [])


# Generated at 2022-06-12 04:27:06.284120
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 0.5, (3, 5), ['foo']).files == 1
    assert CompilationResult(1, 0.5, (3, 5), ['foo']).time == 0.5
    assert CompilationResult(1, 0.5, (3, 5), ['foo']).target == (3, 5)
    assert CompilationResult(1, 0.5, (3, 5), ['foo']).dependencies == ['foo']


# Generated at 2022-06-12 04:27:09.066413
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input=Path('input'), output=Path('output')) == InputOutput('input', 'output')


# Generated at 2022-06-12 04:27:15.186706
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # pylint: disable=invalid-name
    assert TransformationResult(None, None, None).tree is None
    assert TransformationResult(None, None, None).tree_changed is None
    assert TransformationResult(None, None, None).dependencies == []

# Result of compilation of a single file
FileCompilationResult = NamedTuple('FileCompilationResult',
                                   [('input_output', InputOutput),
                                    ('dependencies', List[str]),
                                    ('ast', ast.AST),
                                    ('result', CompilationResult)])


# Generated at 2022-06-12 04:27:18.765570
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.AST(), True, [])
    assert tr.tree
    assert isinstance(tr.tree_changed, bool)
    assert isinstance(tr.dependencies, list)

# Generated at 2022-06-12 04:27:23.942578
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    import astor
    input_tree = ast.parse("x+y")
    input_tree_changed = False
    input_dependencies = []
    result = TransformationResult(input_tree, input_tree_changed, input_dependencies)
    assert(input_tree == ast.parse(astor.to_source(result.tree)))
    assert(input_tree_changed == result.tree_changed)
    assert(input_dependencies == result.dependencies)

# Generated at 2022-06-12 04:27:28.137353
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    target = (3, 0)
    dependencies = ['foo.py', 'bar.py']
    compilation_result = CompilationResult(3, 3.1415926535, target, dependencies)
    # Check attributes
    assert compilation_result.files == 3
    assert compilation_result.time == 3.1415926535
    assert compilation_result.target == target
    assert compilation_result.dependencies == dependencies


# Generated at 2022-06-12 04:27:32.385219
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    a = CompilationResult(6, 10.6, (3, 7), ['a.py', 'b.py'])
    assert a.files == 6
    assert a.time == 10.6
    assert a.target == (3, 7)
    assert a.dependencies == ['a.py', 'b.py']


# Generated at 2022-06-12 04:27:37.214534
# Unit test for constructor of class InputOutput
def test_InputOutput():
    try:
        InputOutput(input='input', output='output')
    except TypeError as e:
        assert "NamedTuple subclass InputOutput has invalid keyword arguments" in str(e)

# Generated at 2022-06-12 04:27:40.166414
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # pylint: disable=unused-argument
    def make():
        return TransformationResult(tree=None, tree_changed=None, dependencies=None)
    # pylint: enable=unused-argument

# Generated at 2022-06-12 04:27:45.371186
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('None')
    assert TransformationResult(tree, True, []) == TransformationResult(tree, True, [])
    assert TransformationResult(tree, False, []) != TransformationResult(tree, True, [])
    assert TransformationResult(tree, True, ['a']) != TransformationResult(tree, True, [])
    assert TransformationResult(tree, False, ['a']) != TransformationResult(tree, True, ['a'])

# Generated at 2022-06-12 04:27:46.947276
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2.0, (3, 4), ['a', 'b'])


# Generated at 2022-06-12 04:27:53.008469
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_obj = ast.parse('x = 1')
    result = TransformationResult(ast_obj, True, ['foo.py'])

    assert(result.tree is ast_obj)
    assert(result.tree_changed is True)
    assert(result.dependencies == ['foo.py'])

# Result of transformers compile_transformation
CompileTransformationResult = NamedTuple('CompileTransformationResult',
                                         [('changed', bool),
                                          ('code', bytes)])


# Generated at 2022-06-12 04:27:56.586064
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path("input"), Path("output"))
    assert input_output.input == Path("input")
    assert input_output.output == Path("output")


# Generated at 2022-06-12 04:28:00.893475
# Unit test for constructor of class InputOutput
def test_InputOutput():
    try:
        InputOutput(Path('/input'), Path('/output'))
    except TypeError:
        assert False, "Constructor of InputOutput do not accept Path"

    try:
        InputOutput('/input', '/output')
    except TypeError:
        assert False, "Constructor of InputOutput do not accept str"


# Generated at 2022-06-12 04:28:04.812524
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result = TransformationResult(
        ast.parse("print('Hello, World!')"),
        True,
        [])
    assert(isinstance(transformation_result.tree, ast.AST))
    assert(isinstance(transformation_result.tree_changed, bool))
    assert(isinstance(transformation_result.dependencies, List))

# Generated at 2022-06-12 04:28:08.618605
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_file = Path('test')
    output_file = Path('test.pyi')
    pair = InputOutput(input_file, output_file)
    assert pair.input == input_file
    assert pair.output == output_file



# Generated at 2022-06-12 04:28:10.043710
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a'), Path('b')) == InputOutput('a', 'b')


# Generated at 2022-06-12 04:28:19.514834
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(files=100, time=1.0, target=(2, 7),
                          dependencies=['library.py', '__init__.py'])
    assert isinstance(r, CompilationResult)
    assert r.files == 100
    assert r.time == 1.0
    assert r.target == (2, 7)
    assert r.dependencies == ['library.py', '__init__.py']



# Generated at 2022-06-12 04:28:22.915054
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    data = CompilationResult(files=5, time=6.2,
                             target=(3, 7), dependencies=[])
    assert data.files == 5
    assert data.time == 6.2
    assert data.target == (3, 7)
    assert data.dependencies == []


# Generated at 2022-06-12 04:28:25.846566
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(0, 0.0, (3, 8), [])
    assert isinstance(r, CompilationResult)
    assert type(r.files) is int
    assert type(r.time) is float

# Generated at 2022-06-12 04:28:27.362263
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('x = 22\n')
    TransformationResult(t, t, [t, t])

# Generated at 2022-06-12 04:28:28.918235
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/')
    output = Path('/')
    InputOutput(input, output)


# Generated at 2022-06-12 04:28:31.606531
# Unit test for constructor of class InputOutput
def test_InputOutput():
    x = InputOutput(Path(__file__), Path(__file__))
    assert x.input == Path(__file__)
    assert x.output == Path(__file__)


# Generated at 2022-06-12 04:28:35.402549
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=0.5,
                               target=(3, 8),
                               dependencies=['foo'])

    assert result.files == 1
    assert result.time == 0.5
    assert result.target == (3, 8)
    assert result.dependencies == ['foo']


# Generated at 2022-06-12 04:28:37.911016
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = "input"
    o = "output"
    input_output = InputOutput(input=i, output=o)
    assert input_output.input == i
    assert input_output.output == o

# Generated at 2022-06-12 04:28:40.791521
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=0.0, target=(3, 5),
                           dependencies=['foo', 'bar'])
    assert cr.files == 1
    assert cr.time == 0.0
    assert cr.target == (3, 5)
    assert cr.dependencies == ['foo', 'bar']


# Generated at 2022-06-12 04:28:45.345323
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(1, 2.0, (3, 4), ["A"])
    assert cr.files == 1
    assert cr.time == 2.0
    assert cr.target == (3, 4)
    assert cr.dependencies == ["A"]


# Generated at 2022-06-12 04:29:00.123623
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=5,
                                           time=0.2,
                                           target=(3, 6),
                                           dependencies=['dep1', 'dep2'])
    assert compilation_result.files == 5
    assert compilation_result.time == 0.2
    assert compilation_result.target == (3, 6)
    assert compilation_result.dependencies == ['dep1', 'dep2']


# Generated at 2022-06-12 04:29:01.266256
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(0, 0, (0, 0), [])


# Generated at 2022-06-12 04:29:04.982026
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=1.1,
                               target=(3, 6),
                               dependencies=['abc.py'])
    assert result.files == 1
    assert result.time == 1.1
    assert result.target == (3, 6)
    assert result.dependencies == ['abc.py']


# Generated at 2022-06-12 04:29:08.760900
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    comp_result = CompilationResult(files=10,
                                    time=5.4,
                                    target=(3, 8),
                                    dependencies=[])
    assert comp_result.files == 10
    assert comp_result.time == 5.4
    assert comp_result.target == (3, 8)
    assert comp_result.dependencies == []


# Generated at 2022-06-12 04:29:10.932869
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=1,
                             time=10,
                             target=(3, 7),
                             dependencies=['foo.py'])


# Generated at 2022-06-12 04:29:14.774712
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=10, time=1.0, target=(3, 7),
                               dependencies=['foo', 'bar'])
    assert result.files == 10
    assert result.time == 1.0
    assert result.target == (3, 7)
    assert result.dependencies == ['foo', 'bar']



# Generated at 2022-06-12 04:29:17.362707
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('input.txt')
    output = Path('output.txt')
    io = InputOutput(input_, output)
    assert io.input == input_
    assert io.output == output

# Generated at 2022-06-12 04:29:19.275304
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('.')
    output = Path('.')
    InputOutput(input_, output)


# Generated at 2022-06-12 04:29:23.721077
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 2.0, (3, 4), ["file1", "file2"])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == ["file1", "file2"]


# Generated at 2022-06-12 04:29:27.261045
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 1.0, (3, 7), ['dep1', 'dep2'])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 7)
    assert result.dependencies == ['dep1', 'dep2']



# Generated at 2022-06-12 04:29:54.438344
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(ast.parse('a = 1'), True, [])
    assert t.tree != None
    assert t.tree_changed == True
    assert len(t.dependencies) == 0

# Generated at 2022-06-12 04:30:00.693038
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.Module()
    result = TransformationResult(tree, True, ['foo'])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == ['foo']

# Type to indicate that a transformation or a compilation is not
# supported.

# Generated at 2022-06-12 04:30:04.317488
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('1+1')
    t = TransformationResult(tree=tree,
                             tree_changed=True,
                             dependencies=['foo'])
    assert t.tree == tree
    assert t.tree_changed == True
    assert t.dependencies == ['foo']


# Generated at 2022-06-12 04:30:07.514836
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(1, 2.2, (2, 3), ['a', 'b'])

    assert cr.files == 1
    assert cr.time == 2.2
    assert cr.target == (2, 3)
    assert cr.dependencies == ['a', 'b']


# Generated at 2022-06-12 04:30:09.629005
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('/a/b'), Path('/c/d')) == InputOutput(input=Path('/a/b'), output=Path('/c/d'))

# Generated at 2022-06-12 04:30:14.611255
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Arrange
    tree = ast.parse('a=10')  # type: ast.AST
    tree_changed = True
    dependencies = ['hello']

    # Act
    result = TransformationResult(tree,
                                  tree_changed,
                                  dependencies)

    # Assert
    assert tree == result.tree
    assert tree_changed == result.tree_changed
    assert dependencies == result.dependencies

# Generated at 2022-06-12 04:30:17.181849
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("print('Hello world!')")
    assert TransformationResult(tree, True, ['foo']).tree_changed == True
    assert TransformationResult(tree, True, ['foo']).dependencies == ['foo']

# Generated at 2022-06-12 04:30:20.427421
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.Name(id='dummy', ctx=ast.Load())
    tr = TransformationResult(tree=t, tree_changed=False, dependencies=[])
    assert tr.tree == t
    assert tr.tree_changed == False
    assert tr.dependencies == []

# Generated at 2022-06-12 04:30:24.379574
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('')
    ast.dump(tree)
    result = TransformationResult(tree, False, [])
    assert result.tree == tree
    assert result.tree_changed == False
    assert result.dependencies == []

# Generated at 2022-06-12 04:30:27.132702
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path = Path('/some/path/to/file.txt')

    pair = InputOutput(path, path)

    assert pair.input == path
    assert pair.output == path


# Generated at 2022-06-12 04:31:24.080233
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 4.3, (3, 5), ['a']) == \
           CompilationResult(files=1, time=4.3, target=(3, 5),
                             dependencies=['a'])
    assert CompilationResult(1, 4.3, (3, 5), ['a']) != \
           CompilationResult(files=2, time=4.3, target=(3, 5),
                             dependencies=['a'])
    assert CompilationResult(1, 4.3, (3, 5), ['a']) != \
           CompilationResult(files=1, time=5.3, target=(3, 5),
                             dependencies=['a'])

# Generated at 2022-06-12 04:31:27.176180
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree = ast.AST(),
                              tree_changed = False,
                              dependencies = ["dependency1", "dependency2"])
    assert type(tr.tree) == ast.AST
    assert type(tr.tree_changed) == bool
    assert type(tr.dependencies) == list

# Generated at 2022-06-12 04:31:31.762125
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_tree = ast.parse('unparsed!')
    result = TransformationResult(ast_tree, True, [])
    assert result.tree == ast_tree
    assert result.dependencies == list()
    assert result.tree_changed is True

# Transformers for AST
Transformer = NamedTuple('Transformer', [('process', ast.AST),
                                         ('dependencies', List[str])])

# Apply all transformers to AST

# Generated at 2022-06-12 04:31:35.050823
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=0, time=0, target=(3, 8), dependencies=[])
    assert result.files == 0
    assert result.time == 0
    assert result.target == (3, 8)
    assert result.dependencies == []


# Generated at 2022-06-12 04:31:37.412779
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=10,
                               target=(3, 7), dependencies=['a'])

    assert result.files == 1
    assert result.time == 10
    assert result.target == (3, 7)
    assert result.dependencies == ['a']


# Generated at 2022-06-12 04:31:39.402381
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('a')
    output = Path('b')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output
    assert io.__doc__ == 'InputOutput(input, output)'

# Generated at 2022-06-12 04:31:41.555325
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    example = TransformationResult(tree=ast.parse("pass"),
                                   tree_changed=True,
                                   dependencies=['a', 'b'])
    assert example.tree is not None
    assert example.tree_changed
    assert example.dependencies == ['a', 'b']

# Generated at 2022-06-12 04:31:45.642871
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1,
                                           time=0.0123,
                                           target=(3, 6),
                                           dependencies=['a'])
    assert(compilation_result.files == 1)
    assert(compilation_result.time == 0.0123)
    assert(compilation_result.target == (3, 6))
    assert(compilation_result.dependencies == ['a'])


# Generated at 2022-06-12 04:31:46.983534
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path("/"), Path("/"))
    assert input_output.input
    assert input_output.output

# Generated at 2022-06-12 04:31:52.066204
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Test the constructor
    input_path = Path('input.json')
    output_path = Path('output.json')
    input_output = InputOutput(input_path, output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path
    assert input_output == InputOutput(input_path, output_path)
    assert input_output != InputOutput(output_path, input_path)
    assert input_output != [input_path, output_path]

# Generated at 2022-06-12 04:33:41.605141
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files = 1, time = 0.1, target = (2, 7), dependencies = [])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (2, 7)
    assert len(result.dependencies) == 0


# Generated at 2022-06-12 04:33:46.099288
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=5,
                               time=0.02,
                               target=(3, 4),
                               dependencies=['abc', 'def'])
    assert result.files == 5
    assert result.time == 0.02
    assert result.target == (3, 4)
    assert result.dependencies == ['abc', 'def']


# Generated at 2022-06-12 04:33:48.916489
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(123, 1.1, (3, 6), [])
    assert res.files == 123
    assert res.time == 1.1
    assert res.target == (3, 6)
    assert res.dependencies == []


# Generated at 2022-06-12 04:33:51.588202
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('print("hello")')
    n = TransformationResult(tree=t, tree_changed=False, dependencies=[])

    assert n.tree_changed is False
    assert n.dependencies == []

# Generated at 2022-06-12 04:33:53.901403
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('/tmp'), Path('/tmp'))

if __name__ == "__main__":
    # Run unit tests
    test_InputOutput()

# Generated at 2022-06-12 04:33:56.821322
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=0, time=0, target=(2, 7),
                           dependencies=["a", "b", "c"])
    assert cr.files == 0
    assert cr.time == 0
    assert cr.target == (2, 7)
    assert cr.dependencies == ["a", "b", "c"]


# Generated at 2022-06-12 04:33:58.743628
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p = Path("foobar")
    i = InputOutput(p, p)
    assert i.input == p
    assert i.output == p


# Generated at 2022-06-12 04:34:00.809493
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = "my_input_file"
    output = "my_output_file"
    io = InputOutput(input, output)
    assert io == (input, output)
    assert io.input == input
    assert io.output == output

# Generated at 2022-06-12 04:34:02.396784
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    tr = TransformationResult(tree, False, ['1'])
    assert tr.tree is tree
    assert tr.tree_changed is False
    assert tr.dependencies == ['1']

# Generated at 2022-06-12 04:34:05.057144
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = "test"')
    tr = TransformationResult(tree, True, ['dependency'])
    assert tr.tree is tree
    assert tr.tree_changed is True
    assert tr.dependencies == ['dependency']