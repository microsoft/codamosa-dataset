

# Generated at 2022-06-12 04:25:24.516963
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Type check
    TransformationResult(tree=ast.parse('1'), tree_changed=True, dependencies=[])  # type: ignore
    # Value check
    assert TransformationResult(tree=ast.parse('1'), tree_changed=True, dependencies=[]).tree_changed  # type: ignore

# Generated at 2022-06-12 04:25:27.121373
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(input=Path('foo.py'), output=Path('bar.py'))
    assert io.input.name == 'foo.py'
    assert io.output.name == 'bar.py'

# Generated at 2022-06-12 04:25:33.624599
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test_node = ast.Name(id='a', ctx=ast.Load())
    test_tree_changed = False
    test_dependencies = ['a', 'b', 'c']
    TransformationResult(test_node, test_tree_changed, test_dependencies)

# Result of evaluator transformation
EvaluationResult = NamedTuple('EvaluationResult',
                              [('evaluation', ast.expr),
                               ('tree_changed', bool),
                               ('dependencies', List[str])])


# Generated at 2022-06-12 04:25:36.416027
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.AST(), False, ['A', 'B'])

# Result of analyzer
AnalysisResult = NamedTuple('AnalysisResult',
                            [('tree', ast.AST),
                             ('dependencies', List[str])])

# Generated at 2022-06-12 04:25:38.893945
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('foo'), Path('bar'))

    assert input_output.input == Path('foo')
    assert input_output.output == Path('bar')



# Generated at 2022-06-12 04:25:42.014790
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('def f():\n    pass\n')
    res = TransformationResult(tree, True, ['abc'])
    assert res.tree == tree
    assert res.tree_changed == True
    assert res.dependencies == ['abc']



# Generated at 2022-06-12 04:25:48.877292
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=0, time=0.0,
                                           target=(3, 6), dependencies=[])
    assert(len(compilation_result) == 4)
    assert(compilation_result.files == 0)
    assert(compilation_result.time == 0.0)
    assert(compilation_result.target == (3, 6))
    assert(isinstance(compilation_result.dependencies, list))


# Generated at 2022-06-12 04:25:50.803389
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(None, False, None)

# Compression mode

# Generated at 2022-06-12 04:25:54.316679
# Unit test for constructor of class InputOutput
def test_InputOutput():
    try:
        InputOutput('hello.py', 'hello.pyc')
        assert False
    except TypeError:
        pass
    try:
        InputOutput(Path('hello.py'), Path('hello.pyc'))
        assert True
    except TypeError:
        assert False

# Generated at 2022-06-12 04:25:58.235905
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    target = (2, 7)
    filename = 'module'
    dependencies = ['module_1', 'module_2']
    c = CompilationResult(1, 10.1, target, dependencies)
    assert c.files == 1
    assert c.time == 10.1
    assert c.target == target
    assert c.dependencies == dependencies


# Generated at 2022-06-12 04:26:01.964892
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    instance = CompilationResult(0, 0.0, (0, 0), [])
    assert instance


# Generated at 2022-06-12 04:26:07.016933
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=ast.parse("x = 5"),
                              tree_changed=False,
                              dependencies=["test"])
    assert tr.tree is not None
    assert tr.tree_changed is False
    assert tr.dependencies == ["test"]

# Generated at 2022-06-12 04:26:14.233281
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.Noop(), False, []) == TransformationResult(ast.Noop(), False, [])
    assert TransformationResult(ast.Noop(), True, []) != TransformationResult(ast.Noop(), False, [])

    assert TransformationResult(ast.Noop(), False, ["test1"]) == TransformationResult(ast.Noop(), False, ["test1"])
    assert TransformationResult(ast.Noop(), False, ["test1"]) != TransformationResult(ast.Noop(), False, ["test2"])

    assert TransformationResult(ast.Name(id="test"), False, []) == TransformationResult(ast.Name(id="test"), False, [])
    assert TransformationResult(ast.Name(id="test1"), False, []) != TransformationResult(ast.Name(id="test2"), False, [])

# Generated at 2022-06-12 04:26:22.378739
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.Str(), True, ['a', 'b', 'c'])
    assert isinstance(tr, TransformationResult)
    assert isinstance(tr.tree, ast.Str)
    assert tr.tree_changed
    assert tr.dependencies == ['a', 'b', 'c']


# Return type of program_to_ast function
ProgramToASTResult = NamedTuple('ProgramToASTResult',
                                [('tree', ast.AST),
                                 ('source', Path)])

# Return type of io_pair_to_result function
IOPairToResultResult = NamedTuple('IOPairToResultResult',
                                  [('result', CompilationResult),
                                   ('src_files', List[Path])])

# Generated at 2022-06-12 04:26:28.771743
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('i')
    o = Path('o')
    assert InputOutput(i, o) == InputOutput(i, o)
    assert InputOutput(i, o) != InputOutput(Path('u'), o)
    assert InputOutput(i, o) != InputOutput(i, Path('u'))
    assert InputOutput(i, o) != InputOutput(Path('u'), Path('u'))


# Generated at 2022-06-12 04:26:33.862546
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert (0, 0.0) == CompilationResult(0, 0.0, (0, 0), [])[:2]
    assert (3.4, 1) == CompilationResult(1, 3.4, (0, 0), [])[1:3]
    assert ([], True) == TransformationResult(ast.AST(), True, [])[1:]


# Generated at 2022-06-12 04:26:38.704454
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    import unittest.mock as mock

    result = TransformationResult(tree=mock.Mock(ast.AST),
                                  tree_changed=False,
                                  dependencies=[])
    assert isinstance(result, TransformationResult)
    assert isinstance(result.tree, ast.AST)
    assert result.tree_changed is False
    assert isinstance(result.dependencies, list)

# Generated at 2022-06-12 04:26:41.195849
# Unit test for constructor of class InputOutput
def test_InputOutput():
    _ = InputOutput(input=Path('b'), output=Path('a'))


# Generated at 2022-06-12 04:26:47.642642
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    dependencies = ['a']
    result = TransformationResult(tree=tree, tree_changed=False,
                                  dependencies=dependencies)
    assert result.tree == tree
    assert result.tree_changed == False
    assert result.dependencies == dependencies

# Result of transpiler transformation
TranspilationResult = NamedTuple('TranspilationResult', [('path', Path),
                                                         ('tree_changed', bool),
                                                         ('dependencies', List[str])])


# Generated at 2022-06-12 04:26:58.940397
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    class MyClass:
        def __init__(self):
            pass
    def my_fun():
        pass
    ast_list = [MyClass, my_fun]
    for _ast in ast_list:
        res = TransformationResult(_ast, True, ['foo', 'bar'])
        assert res.tree == _ast
        assert res.tree_changed
        assert res.dependencies == ['foo', 'bar']

# Matches format of module name to contain a full path
# Examples: /tmp/foo/bar.py, /tmp/foo/bar
# TODO: find a better way
# TODO: should we use regex?
MODULE_NAME_PATTERN = re.compile(r'.+/.+')

# Default compilation timeout (in seconds)
TIMEOUT = 5

# Apply a function to a list and return

# Generated at 2022-06-12 04:27:06.383283
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input')
    output = Path('/tmp/output')
    pair = InputOutput(input, output)
    assert pair.input == input
    assert pair.output == output

# Generated at 2022-06-12 04:27:11.102790
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=['test'])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == ['test']


# Generated at 2022-06-12 04:27:18.476286
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    tr = TransformationResult(ast.AST(), True, [])
    assert tr.tree
    assert tr.tree_changed is True
    assert tr.dependencies == []

# Docstring for main transformer functions
TransformersDocstring = """
    :param tree: Abstract syntax tree of source code
    :param source: Source code
    :param path: Path to source code
    :returns: (tree, tree_changed, dependencies)
    """

# Info about transformer
TransformerInfo = NamedTuple('TransformerInfo',
                             [('name', str),
                              ('doc', str),
                              ('func', Callable[[ast.AST, str, str], TransformationResult])])

# Info about compilation target

# Generated at 2022-06-12 04:27:22.123192
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    tree = ast.parse('a=1')
    t = TransformationResult(tree, False, [])
    assert t.tree == tree
    assert t.tree_changed == False
    assert t.dependencies == []


# Generated at 2022-06-12 04:27:26.856732
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=10, time=2.0, target=(2, 7),
                           dependencies=['foo.py', 'foo.pyc'])
    assert cr.files == 10
    assert cr.time == 2.0
    assert cr.target == (2, 7)
    assert cr.dependencies == ['foo.py', 'foo.pyc']


# Generated at 2022-06-12 04:27:30.236503
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    par = CompilationResult(files=1, time=2, target=(3, 4),
                            dependencies=[])
    assert par.files == 1
    assert par.time == 2
    assert par.target == (3, 4)
    assert par.dependencies == []


# Generated at 2022-06-12 04:27:33.296352
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 200
    time = 0.023
    target = (3, 5)
    dependencies = ['a', 'b']
    CompilationResult(files, time, target, dependencies)


# Unit tests for constructor of class InputOutput

# Generated at 2022-06-12 04:27:37.969398
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=123.456,
                               target=(3, 7),
                               dependencies=['a', 'b'])

    assert result.files == 1
    assert result.time == 123.456
    assert result.target == (3, 7)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-12 04:27:42.448925
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input=Path('foo'), output=Path('bar')) == (Path('foo'), Path('bar'))
    assert InputOutput(input=Path('foo'), output=Path('bar')) != (Path('bar'), Path('foo'))
    assert InputOutput(input=Path('foo'), output=Path('foo')) != (Path('bar'), Path('bar'))

# Generated at 2022-06-12 04:27:45.364927
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('x = "test"')
    tr = TransformationResult(t, True, [])
    assert tr.tree is not None
    assert tr.tree_changed is True
    assert tr.dependencies == []

# Generated at 2022-06-12 04:27:56.124687
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input="/a/b.py", output="/a/b.c.py")



# Generated at 2022-06-12 04:27:59.616628
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=42.1, target=(2, 7), dependencies=[])
    assert result.files == 1
    assert result.time == 42.1
    assert result.target == (2, 7)
    assert result.dependencies == []



# Generated at 2022-06-12 04:28:01.325854
# Unit test for constructor of class InputOutput
def test_InputOutput():
    return InputOutput(input=Path('input.txt'), output=Path('output.txt'))


# Generated at 2022-06-12 04:28:04.319394
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/home/user/hello')
    output = Path('/home/user/hello_out')
    i_o = InputOutput(input, output)
    assert i_o.input == input
    assert i_o.output == output

# Generated at 2022-06-12 04:28:09.111277
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    AST = ast.Module(body=ast.Expr(value=ast.Name(id='None', ctx=ast.Load())))
    node = TransformationResult(tree=AST, tree_changed=False, dependencies=[])
    assert node.tree == AST
    assert node.tree_changed == False
    assert node.dependencies == []

# Generated at 2022-06-12 04:28:11.574834
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(tree=None,
                                  tree_changed=True,
                                  dependencies=[])
    assert result.tree is None
    assert result.tree_changed is True
    assert result.dependencies == []

# Generated at 2022-06-12 04:28:18.323955
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(0, 0, (3, 0), [])
    assert CompilationResult(1, 1, (3, 7), ["fixtures/test_data_common/test_1.py"])
    assert CompilationResult(1, 1, (3, 7), ["fixtures/test_data_common/test_1.py", "fixtures/test_data_common/test_2.py"])
    assert CompilationResult(5, 0.5, (3, 7), ["fixtures/test_data_common/test_1.py", "fixtures/test_data_common/test_2.py"])


# Generated at 2022-06-12 04:28:22.506490
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1,
                               target=(3, 7),
                               dependencies=['a', 'b', 'c'])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 7)
    assert result.dependencies == ['a', 'b', 'c']

# Generated at 2022-06-12 04:28:25.734216
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    test = CompilationResult(files = 13, time = 42.0, target = (3,7), dependencies = [])
    test.files == 13
    test.time == 42.0
    test.target == (3,7)
    test.dependencies == []


# Generated at 2022-06-12 04:28:28.558276
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=ast.parse(""), tree_changed=False,
                              dependencies=['foo', 'bar'])
    assert tr.tree_changed == False
    assert tr.dependencies == ['foo', 'bar']

# Generated at 2022-06-12 04:28:51.265182
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    trans_result = TransformationResult(tree=None,
                                        tree_changed=False,
                                        dependencies=None)
    assert trans_result
    assert trans_result.tree is None
    assert not trans_result.tree_changed
    assert trans_result.dependencies is None

# Generated at 2022-06-12 04:28:54.371920
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=0, time=0, target=(3, 7), dependencies=[])
    assert cr.files == 0
    assert cr.time == 0
    assert cr.target == (3, 7)
    assert cr.dependencies == []


# Generated at 2022-06-12 04:28:55.818464
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path("/dev/null"), Path("/dev/null"))



# Generated at 2022-06-12 04:28:59.178082
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    target = (3, 1)
    res = CompilationResult(1, 0.1, target, [])
    assert res.files == 1
    assert res.time >= 0.0 and res.time <= 1.0
    assert res.target == target
    assert isinstance(res.dependencies, list)



# Generated at 2022-06-12 04:29:03.534016
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    name_transformer = lambda tree: TransformationResult(tree, True, [])
    tr = TransformationResult(None, False, [])
    tr = TransformationResult(None, True, [])
    tr = TransformationResult(None, False, [])


# Result of preprocessing transformation
PreprocessingResult = NamedTuple('PreprocessingResult',
                                 [('inputs', List[InputOutput])])


# Generated at 2022-06-12 04:29:05.972466
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('1')
    result = TransformationResult(tree, True, [])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == []

# Generated at 2022-06-12 04:29:09.272944
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result = TransformationResult(ast.AST(),
                                                 False,
                                                 [])
    assert isinstance(transformation_result.tree, ast.AST)
    assert isinstance(transformation_result.tree_changed, bool)
    assert isinstance(transformation_result.dependencies, List)

# Generated at 2022-06-12 04:29:12.845714
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=["a"])
    assert cr.files == 1
    assert cr.time == 2.0
    assert cr.target == (3, 4)
    assert cr.dependencies == ["a"]


# Generated at 2022-06-12 04:29:19.453780
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse("")
    assert TransformationResult(t, True, []) == TransformationResult(t, True, [])
    assert TransformationResult(t, False, []) == TransformationResult(t, False, [])
    assert TransformationResult(t, True, ["a"]) != TransformationResult(t, True, [])
    assert TransformationResult(t, True, []) != TransformationResult(t, True, ["a"])
    assert TransformationResult(t, False, ["a"]) != TransformationResult(t, True, [])
    assert TransformationResult(t, False, []) != TransformationResult(t, True, ["a"])

# Generated at 2022-06-12 04:29:23.237488
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input.py')
    output = Path('/tmp/output.py')

    input_output = InputOutput(input, output)

    assert input_output.input == input
    assert input_output.output == output

# Generated at 2022-06-12 04:29:50.442646
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # pragma: no cover
    result = TransformationResult(tree=None,
                                  tree_changed=False,
                                  dependencies=['module1', 'module2'])
    assert result.tree is None
    assert not result.tree_changed
    assert result.dependencies == ['module1', 'module2']

# Generated at 2022-06-12 04:29:53.680045
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('/tmp/input')
    output_path = Path('/tmp/output')
    input_output = InputOutput(input_path, output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path


# Generated at 2022-06-12 04:29:56.916471
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('/home')
    out = Path('/out')
    assert InputOutput(input=inp, output=out) == InputOutput(inp, out)



# Generated at 2022-06-12 04:30:02.535547
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 2.0, (2, 3), ['a', 'b'])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (2, 3)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-12 04:30:05.545223
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(1, 2.0, (3, 4), ['a', 'b'])
    assert cr.files == 1
    assert cr.time == 2.0
    assert cr.target == (3, 4)
    assert cr.dependencies == ['a', 'b']


# Generated at 2022-06-12 04:30:07.348312
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(None, False, None)
    assert res.tree is None
    assert not res.tree_changed
    assert res.dependencies is None

# Generated at 2022-06-12 04:30:11.122009
# Unit test for constructor of class InputOutput
def test_InputOutput():
    result = InputOutput(input=Path("test.pyi"), output=Path("test.py"))
    assert result.input.name == "test.pyi"
    assert result.input.suffix == ".pyi"
    assert result.output.name == "test.py"
    assert result.output.suffix == ".py"

# Generated at 2022-06-12 04:30:17.025939
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_1 = InputOutput(input=Path('in'),
                         output=Path('out'))
    test_2 = InputOutput(input=Path('in_1'),
                         output=Path('out_1'))
    assert test_1.input == Path('in')
    assert test_1.output == Path('out')
    assert test_1 != test_2
    assert test_1 is not test_2
    assert test_1 == test_1
    assert test_1 is test_1


# Generated at 2022-06-12 04:30:22.010169
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    comp = CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=['a', 'b'])
    assert comp.files == 1
    assert comp.time == 2.0
    assert comp.target == (3, 4)
    assert comp.dependencies == ['a', 'b']


# Generated at 2022-06-12 04:30:28.261287
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # All arguments are set the same
    firstInputOutput = InputOutput(input=Path('dummy'),
                                   output=Path('dummy'))
    assert firstInputOutput.output == firstInputOutput.input == Path('dummy')
    # All arguments are set different
    secondInputOutput = InputOutput(input=Path('dummy1'),
                                    output=Path('dummy2'))
    assert secondInputOutput.output != secondInputOutput.input
    assert secondInputOutput.input == Path('dummy1')
    assert secondInputOutput.output == Path('dummy2')

# Generated at 2022-06-12 04:31:20.765961
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a'), Path('b')) == InputOutput('a', 'b')
    assert InputOutput('a', 'b') == InputOutput('a', 'b')
    assert InputOutput('a', 'b') != InputOutput('a', 'c')


# Generated at 2022-06-12 04:31:24.421893
# Unit test for constructor of class CompilationResult
def test_CompilationResult():  # type: () -> None
    compilation_result = CompilationResult(5, 10, (3, 5), ['a.py', 'b.py'])
    assert compilation_result.files == 5
    assert compilation_result.time == 10
    assert compilation_result.target == (3, 5)
    assert compilation_result.dependencies == ['a.py', 'b.py']


# Generated at 2022-06-12 04:31:26.801448
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.Module()
    TransformationResult(tree, True, ['foo.py', 'bar.py'])
    TransformationResult(tree, False, ['foo.py', 'bar.py'])

# Generated at 2022-06-12 04:31:28.748314
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(None, False, [])
    assert isinstance(tr.tree, ast.AST)
    assert isinstance(tr.tree_changed, bool)
    assert isinstance(tr.dependencies, list)

# Generated at 2022-06-12 04:31:33.498444
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/home/user')
    output = Path('/home/user2')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output
    assert repr(input_output) == "InputOutput(input=PosixPath('/home/user'), output=PosixPath('/home/user2'))"

# Generated at 2022-06-12 04:31:35.814799
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('bla.py'), Path('bla.pyc'))
    assert InputOutput(input=Path('bla.py'), output=Path('bla.pyc'))


# Generated at 2022-06-12 04:31:37.486260
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=None,
                              tree_changed=False,
                              dependencies=[])
    assert tr.tree is None
    assert tr.tree_changed is False
    assert tr.dependencies == []

# Generated at 2022-06-12 04:31:38.925025
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(input=Path("input"), output=Path("output"))
    assert input_output.input == Path("input")
    assert input_output.output == Path("output")

# Generated at 2022-06-12 04:31:41.919786
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 42')
    tree_changed = True
    dependencies = ['a', 'b', 'c']
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies
    assert isinstance(result, TransformationResult)


# Generated at 2022-06-12 04:31:44.580306
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_value = Path('input')
    output_value = Path('output')
    result = InputOutput(input_value, output_value)
    assert(result.input == input_value)
    assert(result.output == output_value)

# Generated at 2022-06-12 04:33:34.264171
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    tree_changed = True
    dependencies = []
    tr = TransformationResult(tree, tree_changed, dependencies)
    assert tr.tree is tree
    assert tr.tree_changed is tree_changed
    assert tr.dependencies == dependencies

# Generated at 2022-06-12 04:33:38.312737
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('')
    tree_changed = False
    dependencies = []
    tr = TransformationResult(tree, tree_changed, dependencies)
    assert tr.tree is tree
    assert tr.tree_changed is tree_changed
    assert tr.dependencies is dependencies
    tree, tree_changed, dependencies = tr
    assert tree is tr.tree
    assert tree_changed is tr.tree_changed
    assert dependencies is tr.dependencies
    assert tr == TransformationResult(tree, tree_changed, dependencies)
    assert tr != TransformationResult(tree, not tree_changed, dependencies)
    assert tr != TransformationResult(tree, tree_changed, not dependencies)
    assert tr != TransformationResult(not tree, tree_changed, dependencies)
    assert tr != TransformationResult(not tree, not tree_changed, dependencies)

# Generated at 2022-06-12 04:33:40.946154
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/home/user/input.py')
    output = Path('/home/user/output.py')

    io = InputOutput(input, output)

    assert io.input == input
    assert io.output == output


# Generated at 2022-06-12 04:33:48.219521
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    import unittest

    class TestTransformationResult(unittest.TestCase):

        def runTest(self):
            # type: () -> None
            tree = ast.parse('1+1', '.')
            dependencies = ['dependency']
            result = TransformationResult(tree, False, dependencies)
            self.assertEqual(result.tree, tree)
            self.assertFalse(result.tree_changed)
            self.assertEqual(result.dependencies, dependencies)

    test = TestTransformationResult()
    test.runTest()

if __name__ == "__main__":
    import unittest

    unittest.main()

# Generated at 2022-06-12 04:33:52.677576
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inputs = [Path('../a.py'), Path('../b.py')]
    outputs = [Path('../a.pyc'), Path('../b.pyc')]

    input_output = InputOutput(inputs[0], outputs[0])
    assert input_output.input == inputs[0]
    assert input_output.output == outputs[0]


# Generated at 2022-06-12 04:33:54.748559
# Unit test for constructor of class InputOutput
def test_InputOutput():
    iop = InputOutput(Path('a.py'), Path('b.pyc'))
    assert iop.input == 'a.py'
    assert iop.output == 'b.pyc'

# Generated at 2022-06-12 04:33:56.786061
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(tree=None,
                               tree_changed=False,
                               dependencies=[])
    assert res.tree is None
    assert not res.tree_changed
    assert res.dependencies == []

# Generated at 2022-06-12 04:34:01.355147
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    classobj = TransformationResult(ast.Module(), False, [])
    assert isinstance(classobj.tree, ast.AST)
    assert isinstance(classobj.tree_changed, bool)
    assert isinstance(classobj.dependencies, list)


# Result of the transformer
TransformerResult = NamedTuple('TransformerResult',
                               [('result', bool),
                                ('compiled_file', Path),
                                ('execution_time', float),
                                ('target', CompilationTarget),
                                ('dependencies', List[str])])


# Generated at 2022-06-12 04:34:04.532096
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("")
    tree_changed = True
    dependencies = ["a", "b"]
    transformation_result = TransformationResult(tree, tree_changed,
                                                 dependencies)
    assert transformation_result.tree == tree
    assert transformation_result.tree_changed == tree_changed
    assert transformation_result.dependencies == dependencies


# Matcher for transformation result

# Generated at 2022-06-12 04:34:06.350920
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(None, True, ["a", "b", "c"])
    assert(tr.tree is None)
    assert(tr.tree_changed is True)
    assert(tr.dependencies == ["a", "b", "c"])