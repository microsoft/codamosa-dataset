

# Generated at 2022-06-12 04:25:22.497493
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(
        ast.Module([]), False, []) == TransformationResult(
        ast.Module([]), False, [])

# Generated at 2022-06-12 04:25:24.077667
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=2., target=(2, 7), dependencies=['a'])


# Generated at 2022-06-12 04:25:28.203977
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(tree = ast.parse("print('hello world')"),
                                  tree_changed = True,
                                  dependencies = ['dependency1', 'dependency2'])
    assert result.tree is not None
    assert result.tree_changed is True
    assert result.dependencies == ['dependency1', 'dependency2']


# Generated at 2022-06-12 04:25:29.126528
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(None, None)


# Generated at 2022-06-12 04:25:34.356558
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 1.0, (3, 5), []).files == 1
    assert CompilationResult(1, 1.0, (3, 5), []).time == 1.0
    assert CompilationResult(1, 1.0, (3, 5), []).target == (3, 5)
    assert CompilationResult(1, 1.0, (3, 5), []).dependencies == []


# Generated at 2022-06-12 04:25:40.670236
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=10, time=42.0,
                               target=(3, 7), dependencies=[])
    assert result.files == 10 and result.time == 42.0 and \
           result.target == (3, 7) and result.dependencies == []
    result = CompilationResult(files=0, time=42.0,
                               target=(3, 5), dependencies=['a', 'b'])
    assert result.files == 0 and result.time == 42.0 and \
           result.target == (3, 5) and result.dependencies == ['a', 'b']


# Generated at 2022-06-12 04:25:45.387957
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=3, time=10.0,
                          target=(3, 3), dependencies=['foo', 'bar'])
    assert c.files == 3
    assert c.time == 10.0
    assert c.target == (3, 3)
    assert c.dependencies == ['foo', 'bar']


# Generated at 2022-06-12 04:25:49.349614
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    TransformationResult(ast.parse('a'), True, ['b'])
    TransformationResult(ast.parse('a'), False, ['b'])
    TransformationResult(ast.parse('a'), True, [])
    TransformationResult(ast.parse('a'), False, [])

# Generated at 2022-06-12 04:25:53.086676
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(None, False, [])
    assert isinstance(tr.tree, ast.AST)
    assert isinstance(tr.tree_changed, bool)
    assert isinstance(tr.dependencies, list)


# Generated at 2022-06-12 04:25:56.941422
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files = 1, time = 1.0, target = (2, 7),
                           dependencies = ['a'])
    assert cr.files == 1
    assert cr.time == 1.0
    assert cr.target == (2, 7)
    assert cr.dependencies == ['a']


# Generated at 2022-06-12 04:26:00.082023
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('input')
    output = Path('output')
    a = InputOutput(input_, output)
    assert a.input == input_
    assert a.output == output


# Generated at 2022-06-12 04:26:02.659972
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path('a'), Path('b'))
    assert io.input == Path('a')
    assert io.output == Path('b')



# Generated at 2022-06-12 04:26:06.071621
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('a'), Path('b'))
    assert input_output.input == Path('a')
    assert input_output.output == Path('b')

# Generated at 2022-06-12 04:26:10.242737
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(
        1, 5, (3, 3), ['dep1', 'dep2'])

    assert compilation_result.files == 1
    assert compilation_result.time == 5
    assert compilation_result.target == (3, 3)
    assert compilation_result.dependencies == ['dep1', 'dep2']



# Generated at 2022-06-12 04:26:11.960351
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=0.1, target=(3, 5), dependencies=['foo'])


# Generated at 2022-06-12 04:26:15.493513
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/test/input')
    output = Path('/test/output')
    io = InputOutput(input=input, output=output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-12 04:26:18.375835
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('foo')
    output = Path('bar')
    t = InputOutput(input, output)
    assert t.input == input
    assert t.output == output


# Generated at 2022-06-12 04:26:20.002992
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(None, None, None)
    assert isinstance(tr, TransformationResult)

# Generated at 2022-06-12 04:26:25.941247
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=0.1,
                               target=(3, 6),
                               dependencies=["/some/file.py"])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 6)
    assert isinstance(result.dependencies, list)
    assert len(result.dependencies) == 1


# Generated at 2022-06-12 04:26:33.532268
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    res = TransformationResult(tree, True, [])
    assert isinstance(res.tree, ast.AST) and isinstance(res.tree_changed, bool) \
        and isinstance(res.dependencies, list)
    assert res.tree_changed, 'Transformation was expected to change the code'
    assert not res.dependencies, 'Transformation was not expected to have any dependencies'

# Information about a transformation
TransformationInfo = NamedTuple('TransformationInfo',
                                [('name', str),
                                 ('config', dict)])

# Generated at 2022-06-12 04:26:38.078034
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(files=1, time=0, target=(2, 7), dependencies=[])
    assert isinstance(r, CompilationResult)


# Generated at 2022-06-12 04:26:45.119813
# Unit test for constructor of class InputOutput
def test_InputOutput():
    x = InputOutput(input=Path('input'), output=Path('output'))
    assert x.input == Path('input')
    assert x.output == Path('output')
    assert x == InputOutput(input=Path('input'), output=Path('output'))
    assert x != InputOutput(input=Path('input'), output=Path('output2'))
    assert x != InputOutput(input=Path('input2'), output=Path('output'))


# Generated at 2022-06-12 04:26:50.297631
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('input.py')
    output_path = Path('output.py')
    input_output = InputOutput(input_path, output_path)

    assert input_output.input == input_path
    assert input_output.output == output_path


# Generated at 2022-06-12 04:26:59.802464
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert 1 == CompilationResult(1, 3.2, (1, 2), ['/a/b']).files
    assert 3.2 == CompilationResult(1, 3.2, (1, 2), ['/a/b']).time
    assert (1, 2) == CompilationResult(1, 3.2, (1, 2), ['/a/b']).target
    assert ['/a/b'] == CompilationResult(1, 3.2, (1, 2), ['/a/b']).dependencies
    assert ('time', 3.2) in CompilationResult(1, 3.2, (1, 2), ['/a/b']).__dict__.items()

# Generated at 2022-06-12 04:27:03.030117
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('input.py')
    o = Path('output.py')
    assert (InputOutput(i, o).input == i and
            InputOutput(i, o).output == o)

# Generated at 2022-06-12 04:27:04.931775
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path("input")
    output = Path("output")

    assert InputOutput(input, output).input == input
    assert InputOutput(input, output).output == output


# Generated at 2022-06-12 04:27:11.507338
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(100, 0.5, (2, 7), [])

    assert(isinstance(result, CompilationResult))
    assert(result.files == 100)
    assert(result.time == 0.5)
    assert(result.target == (2, 7))
    assert(isinstance(result.dependencies, list))


# Generated at 2022-06-12 04:27:14.700611
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=1.0, target=(1, 2), dependencies=[])
    assert cr.files == 1
    assert cr.time == 1.0
    assert cr.target == (1, 2)
    assert cr.dependencies == []


# Generated at 2022-06-12 04:27:16.070464
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput('a', 'b')

# Generated at 2022-06-12 04:27:17.899613
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(input=Path('input.txt'), output=Path('output.txt'))



# Generated at 2022-06-12 04:27:26.443076
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    class Transformer(object):
        pass
    tree = ast.parse('1')
    tr = TransformationResult(tree, True, [])
    assert tr.tree == tree
    assert isinstance(tr.tree, ast.AST)
    assert tr.tree_changed is True
    assert tr.dependencies == []

# Generated at 2022-06-12 04:27:29.542183
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    res = TransformationResult(tree, False, ['math'])
    assert res.tree is not None
    assert not res.tree_changed
    assert res.dependencies == ['math']

# Generated at 2022-06-12 04:27:33.644274
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # pylint: disable=redefined-outer-name
    tree = ast.parse('1')  # type: ast.AST
    tresult = TransformationResult(tree, True, ['x/x.py'])
    assert tresult.tree == tree
    assert tresult.tree_changed
    assert tresult.dependencies == ['x/x.py']

# Generated at 2022-06-12 04:27:35.881068
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=1, time=1, target=(3, 6), dependencies=[])
    assert c


# Generated at 2022-06-12 04:27:38.229408
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=0, target=(3, 5), dependencies=[])
    assert isinstance(cr, CompilationResult)


# Generated at 2022-06-12 04:27:44.349163
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=2, time=1, target=(3, 7), dependencies=['dep1', 'dep2'])
    assert repr(result) == "CompilationResult(files=2, time=1, target=(3, 7), dependencies=['dep1', 'dep2'])"
    assert result.files == 2
    assert result.time == 1
    assert result.target == (3, 7)
    assert result.dependencies == ['dep1', 'dep2']


# Generated at 2022-06-12 04:27:51.531359
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input1 = Path('/foo/bar')
    output1 = Path('/baz/qux')
    io1 = InputOutput(input1, output1)
    assert input1 == io1.input
    assert output1 == io1.output
    io2 = InputOutput(input1, output1)
    assert hash(io1) == hash(io2)
    assert repr(io1) == repr(io2)
    assert io1 == io2
    io3 = io1._replace(output=Path('/baz/quxx'))
    assert io1 != io3


# Generated at 2022-06-12 04:27:53.488605
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=12, time=0.3, target=(3, 6), dependencies=['../a'])


# Generated at 2022-06-12 04:27:56.078175
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.2, target=(3, 7),
                      dependencies=['path1.py', 'path2.py'])

# Generated at 2022-06-12 04:27:59.264135
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('/tmp/a.py')
    output = Path('/tmp/b.py')
    test = InputOutput(input_, output)
    assert test.input == input_
    assert test.output == output

# Generated at 2022-06-12 04:28:11.999774
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path("a"), Path("b")) == InputOutput("a", "b")
    assert InputOutput("a", "b") == InputOutput("a", "b")
    assert InputOutput("a", "b") != InputOutput("a", "c")
    assert InputOutput("a", "b").input == "a"
    assert InputOutput("a", "b").output == "b"

# Generated at 2022-06-12 04:28:15.981157
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    input = TransformationResult(tree, True, [])
    expected = TransformationResult(tree, True, [])
    assert input == expected

# Type of transformation
Transformer = NamedTuple('Transformer', [('name', str),
                                         ('func', ast.AST),
                                         ('enabled', bool),
                                         ('kwargs', dict)])

# Generated at 2022-06-12 04:28:19.394788
# Unit test for constructor of class InputOutput
def test_InputOutput():
    file = 'input.py'
    input = Path(file)
    file_out = 'output.py'
    output = Path(file_out)
    assert InputOutput(input, output) == \
        InputOutput(input, output)


# Generated at 2022-06-12 04:28:23.421806
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=2, time=3.14, target=(3, 7), dependencies=['a', 'b', 'c'])
    assert result.files == 2
    assert result.time == 3.14
    assert result.target == (3, 7)
    assert result.dependencies == ['a', 'b', 'c']


# Generated at 2022-06-12 04:28:26.650399
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("print('Hello World!')")
    result = TransformationResult(tree, False, [])
    assert isinstance(result.tree, ast.AST)
    assert isinstance(result.tree_changed, bool)
    assert isinstance(result.dependencies, list)

# Generated at 2022-06-12 04:28:35.227294
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Check with pair of directories
    in_ = Path('/in')
    out = Path('/out')
    io = InputOutput(in_, out)
    assert io.input == in_
    assert io.output == out
    assert io.input.is_dir()
    assert io.output.is_dir()
    # Check with pair of files
    in_ = Path('/in')
    out = Path('/out')
    io = InputOutput(in_, out)
    assert io.input == in_
    assert io.output == out
    assert io.input.is_file()
    assert io.output.is_file()
    # Check with pair of directories with different paths
    in_ = Path('/in')
    out = Path('/out/out')
    io = InputOutput(in_, out)

# Generated at 2022-06-12 04:28:38.886599
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    inputfile = "test.txt"
    outputfile = "test.out"
    inputoutput = InputOutput(Path(inputfile), Path(outputfile))
    tree = ast.parse("x = '4'", inputfile, 'eval')
    transformationresult = TransformationResult(tree, False, None)
    assert transformationresult

# Generated at 2022-06-12 04:28:44.633825
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(
        files=1,
        time=0.5,
        target=(3, 6),
        dependencies=[]
    )
    assert result.files == 1
    assert result.time == 0.5
    assert result.target == (3, 6)
    assert result.dependencies == []

# Test for constructor of class InputOutput

# Generated at 2022-06-12 04:28:47.149555
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path = Path(__file__)
    input = Path(path.parent, 'input')
    output = Path(path.parent, 'output')
    i_o = InputOutput(input, output)
    assert i_o.input == input
    assert i_o.output == output


# Generated at 2022-06-12 04:28:51.566380
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    tree_changed = True
    deps = ['a.py', 'b.py']
    t = TransformationResult(tree, tree_changed, deps)
    assert t.tree == tree
    assert t.tree_changed == tree_changed
    assert t.dependencies == deps

# Generated at 2022-06-12 04:29:16.113112
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # pylint: disable=unused-variable
    # tree
    node = ast.parse('pass')
    # tree_changed
    changed = False
    # dependencies
    dependencies = []
    result = TransformationResult(node, changed, dependencies)
    assert result.tree is node
    assert result.tree_changed is changed
    assert result.dependencies is dependencies

# Generated at 2022-06-12 04:29:25.453079
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('foo = 42')
    dependencies = ['foo.py', 'bar.py']
    result = TransformationResult(tree, True, dependencies)
    assert result.tree is tree
    # No need to test tree_changed, which is a bool
    assert result.dependencies == dependencies

# Result of a transformation of a transformer
TransformationResultOfTransformer = NamedTuple('TransformationResultOfTransformer',
                                               [('transformer', Transformation),
                                                ('result', TransformationResult)])

# Result of a transformer, one file
TransformationResultSingleFile = NamedTuple('TransformationResultSingleFile',
                                            [('input', Path),
                                             ('output', Path),
                                             ('results', List[TransformationResultOfTransformer]),
                                             ('dependencies', List[str])])

#

# Generated at 2022-06-12 04:29:29.273780
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_file = Path('/foo/bar.txt')
    output_file = Path('/foo/baz.txt')
    in_out = InputOutput(input_file, output_file)
    assert in_out.input == input_file
    assert in_out.output == output_file

# Generated at 2022-06-12 04:29:31.484550
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files = 1,
                      time = 2.0,
                      target = (3, 4),
                      dependencies = ['a', 'b', 'c'])


# Generated at 2022-06-12 04:29:36.580105
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    import astor
    import os.path
    import tempfile

    t = ast.parse("a = 3")
    d = [os.path.join(tempfile.gettempdir(), "file_dep")]
    res = TransformationResult(tree=t, tree_changed=True, dependencies=d)
    assert astor.to_source(res.tree) == astor.to_source(t)
    assert res.tree_changed is True
    assert res.dependencies == d



# Generated at 2022-06-12 04:29:38.802494
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=123, time=12.3,
                             target=(3, 5),
                             dependencies=['foo', 'bar'])


# Generated at 2022-06-12 04:29:41.149326
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test_case = TransformationResult(tree = ast.parse(""),
                                     tree_changed = True,
                                     dependencies = [])
    assert(test_case.tree is not None)


# Generated at 2022-06-12 04:29:43.867722
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(tree_changed=True,
                             tree=ast.parse('1'),
                             dependencies=['test', 'test2'])
    assert t.tree_changed
    assert t.tree != None
    assert t.dependencies == ['test', 'test2']

# Generated at 2022-06-12 04:29:46.375108
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    import ast
    tree = ast.parse('x = 1')
    tree_changed = True
    dependencies = []
    TransformationResult(tree, tree_changed, dependencies)
    return

# Generated at 2022-06-12 04:29:49.914317
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=0,
                               time=0.0,
                               target=(3, 4),
                               dependencies=[])
    assert result.files == 0
    assert result.time == 0.0
    assert result.target == (3, 4)
    assert result.dependencies == []


# Generated at 2022-06-12 04:30:42.422920
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    assert InputOutput(input=input, output=output).input == input
    assert InputOutput(input=input, output=output).output == output

# Generated at 2022-06-12 04:30:46.763373
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('test')
    t1 = TransformationResult(tree, True, [])
    assert t1.tree is tree
    assert t1.tree_changed is True
    assert t1.dependencies == []

    t2 = TransformationResult(tree, False, ['foo', 'bar'])
    assert t2.tree_changed is False
    assert t2.dependencies == ['foo', 'bar']

# Generated at 2022-06-12 04:30:50.159293
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_node = ast.Module(body=[])
    result = TransformationResult(tree=ast_node,
                                  tree_changed=True,
                                  dependencies=['foo'])
    assert(result.tree == ast_node)
    assert(result.tree_changed)
    assert(result.dependencies == ['foo'])

# Generated at 2022-06-12 04:30:55.977249
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.Module(body=[])
    r = TransformationResult(t, True, [])
    # noinspection PyUnresolvedReferences
    assert r.tree == t
    assert r.tree_changed is True
    assert r.dependencies == []


# Result of analysis phase
AnalysisResult = NamedTuple('AnalysisResult', [('ast', ast.AST),
                                               ('target', CompilationTarget),
                                               ('dependencies', List[str])])


# Generated at 2022-06-12 04:31:00.392657
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 7
    time = 1.01
    target = (3, 6)
    dependencies = ['a.py', 'b.py']

    cr = CompilationResult(files=files, time=time, target=target,
                           dependencies=dependencies)

    assert cr.files == files
    assert cr.time == time
    assert cr.target == target
    assert cr.dependencies == dependencies


# Generated at 2022-06-12 04:31:04.291343
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Arrange
    test_tree = ast.Module()
    test_tree_changed = True
    test_dependencies = ['test']
    expected = (test_tree, test_tree_changed, test_dependencies)

    # Assert
    res = TransformationResult(*expected)
    assert res == expected

# Generated at 2022-06-12 04:31:06.897946
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    class Test(ast.AST):
        pass
    res = TransformationResult(Test(), True, [])
    assert isinstance(res.tree, Test)
    assert res.tree_changed
    assert res.dependencies == []

# Generated at 2022-06-12 04:31:08.691341
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path("input"), Path("output"))

    assert input_output.input == Path("input")
    assert input_output.output == Path("output")

# Generated at 2022-06-12 04:31:14.277941
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    """
    Constructor of class TransformationResult.
    """

    tree = ast.parse('')
    dependencies = []
    res1 = TransformationResult(tree, True, dependencies)
    res2 = TransformationResult(tree, False, dependencies)

    assert res1.tree == res2.tree
    assert res1.dependencies == res2.dependencies

    assert res1.tree_changed == True
    assert res2.tree_changed == False

    try:
        res1[0] = 'string'
        raise Exception('Must raise TypeError')
    except TypeError:
        pass



# Generated at 2022-06-12 04:31:15.730271
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=None,
                                tree_changed=False,
                                dependencies=None)

# Generated at 2022-06-12 04:33:13.277440
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=1,
                             time=0.3,
                             target=(9, 3),
                             dependencies=['dep1', 'dep2', 'dep3']).files == 1
    assert CompilationResult(files=42,
                             time=12.0,
                             target=(3, 10),
                             dependencies=['dep4', 'dep5']).time == 12.0
    assert CompilationResult(files=13,
                             time=5.0,
                             target=(3, 10),
                             dependencies=['depA', 'depZ']).target == (3, 10)

# Generated at 2022-06-12 04:33:15.556202
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = "input"
    output = "output"
    input_output = InputOutput(input, output)
    assert(input_output.input == input)
    assert(input_output.output == output)

# Generated at 2022-06-12 04:33:18.536143
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    tree = ast.parse('pass')
    TransformationResult(tree, True, [])
    TransformationResult(tree, False, [])
    TransformationResult(tree, True, ['a'])
    TransformationResult(tree, False, ['a'])

# Generated at 2022-06-12 04:33:21.818008
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    try:
        CompilationResult(1, 2.3, (3, 4), [5, '6'])
    except Exception:
        assert False



# Generated at 2022-06-12 04:33:22.693078
# Unit test for constructor of class InputOutput
def test_InputOutput():
    pass


# Generated at 2022-06-12 04:33:28.980771
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """Test that InputOutput is correct defined."""
    # Case 1
    input_path = Path('input.txt')
    output_path = Path('output.txt')
    input_output = InputOutput(input_=input_path,
                               output=output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path

    # Case 2
    input_path = Path('input.txt')
    output_path = Path('output.txt')
    input_output = InputOutput(input_path, output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path

# Generated at 2022-06-12 04:33:36.598166
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from pytypeutils import utils as utils
    from pypred import lalr1parser as lalr1parser
    from pypred.transformers import number as number
    import typed_ast.ast3 as ast3

    def assert_trans_result(src: str, exp: ast3.AST) -> None:
        tree, changed, depends = transformation_result(src)
        utils.assert_eq(exp, tree)
        utils.assert_eq(False, changed)
        utils.assert_eq(list(), depends)

    def transformation_result(src: str) -> TransformationResult:
        tree = lalr1parser.parse_string(src)
        number.NumberTransformer(False, None, {})(tree)
        return tree.as_transformation_result()


# Generated at 2022-06-12 04:33:43.975017
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Call constructor with correct values
    TransformationResult(ast.Module(),
                         True,
                         ['a.py', 'b.py'])

    # Call constructor with wrong values
    with pytest.raises(TypeError):
        TransformationResult(ast.Module(),
                             'abcd',
                             ['a.py', 'b.py'])
    with pytest.raises(TypeError):
        TransformationResult(ast.Module(),
                             True,
                             'abcd')
    with pytest.raises(TypeError):
        TransformationResult(ast.Module(),
                             123,
                             ['a.py', 'b.py'])
    with pytest.raises(TypeError):
        TransformationResult(ast.Module(),
                             True,
                             123)

# Generated at 2022-06-12 04:33:52.197219
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path("/1"), Path("/2")).input == Path("/1")
    assert InputOutput(Path("/1"), Path("/2")).output == Path("/2")

    assert InputOutput("/1", "/2").input == Path("/1")
    assert InputOutput("/1", "/2").output == Path("/2")

    assert InputOutput("/1", Path("/2")).input == Path("/1")
    assert InputOutput("/1", Path("/2")).output == Path("/2")

    assert InputOutput(Path("/1"), "/2").input == Path("/1")
    assert InputOutput(Path("/1"), "/2").output == Path("/2")


# Generated at 2022-06-12 04:33:55.653042
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=5, time=5.6, target=(3, 0),
                          dependencies=["a.py", "b.py"])
    assert c.files == 5 and c.time == 5.6 and c.target == (3, 0)
    assert c.dependencies == ["a.py", "b.py"]
