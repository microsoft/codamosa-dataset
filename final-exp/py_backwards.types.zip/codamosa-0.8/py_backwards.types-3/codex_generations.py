

# Generated at 2022-06-12 04:25:25.303537
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    a1 = ast.parse('a = 1')
    a2 = ast.parse('a = 1')
    a3 = ast.parse('a = 2')
    assert TransformationResult(a1, True, ['a1']).tree_changed
    assert not TransformationResult(a1, False, ['a1']).tree_changed
    assert TransformationResult(a1, True, ['a1']) == TransformationResult(a2, True, ['a1'])
    assert TransformationResult(a1, True, ['a1', 'a2']) == TransformationResult(a2, True, ['a1', 'a2'])
    assert TransformationResult(a1, True, ['a1']) != TransformationResult(a3, True, ['a1'])

# Generated at 2022-06-12 04:25:32.182661
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("import os")
    tr = TransformationResult(tree, False, [])
    assert(tr.tree_changed == False)
    tr = TransformationResult(tree, True, [])
    assert(tr.tree_changed == True)
    tr = TransformationResult(tree, False, ["file1", "file2"])
    assert(tr.dependencies == ["file1", "file2"])
    tr = TransformationResult(tree, True, ["file1", "file2"])
    assert(tr.dependencies == ["file1", "file2"])


# Generated at 2022-06-12 04:25:33.838322
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Type checking
    t = TransformationResult(tree=ast.parse('a = 2'), tree_changed=False, dependencies=[])

# Generated at 2022-06-12 04:25:36.283471
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(input=Path('a'), output=Path('b'))
    assert input_output.input == Path('a')
    assert input_output.output == Path('b')



# Generated at 2022-06-12 04:25:39.102063
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = Path('input')
    b = Path('output')
    io = InputOutput(a, b)

    assert io.input == a
    assert io.output == b
    assert str(io) == 'input -> output'

# Generated at 2022-06-12 04:25:43.473091
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(
        tree = ast.Module(body = []),
        tree_changed = True,
        dependencies = ["/tmp/dep_1", "/tmp/dep_2"]
    )
    assert result.tree == ast.Module(body=[])
    assert result.tree_changed == True
    assert result.dependencies == ["/tmp/dep_1", "/tmp/dep_2"]

# Generated at 2022-06-12 04:25:48.627794
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Arrange
    input = Path('input.py')
    output = Path('output.py')

    # Act
    input_output = InputOutput(input, output)

    # Assert
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-12 04:25:52.001910
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path('a')
    path2 = Path('b')
    pair = InputOutput(path1, path2)
    assert pair.input == path1
    assert pair.output == path2

# Generated at 2022-06-12 04:25:57.245788
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=1, time=2.0, target=(3, 4),
                          dependencies=['a', 'b'])
    nt.assert_equal(c.files, 1)
    nt.assert_equal(c.time, 2.0)
    nt.assert_equal(c.target, (3, 4))
    nt.assert_equal(c.dependencies, ['a', 'b'])


# Generated at 2022-06-12 04:25:59.371362
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('x.py')
    output = Path('x.py')

    result = InputOutput(input=input, output=output)
    assert result.input == input
    assert result.output == output



# Generated at 2022-06-12 04:26:06.002307
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=5, time=5.5, target=(3, 5), dependencies=['a', 'b'])
    assert result.files == 5
    assert result.time == 5.5
    assert result.target == (3, 5)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-12 04:26:08.447430
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('test.txt'), Path('test.txt')).input
    assert InputOutput(Path('test.txt'), Path('test.txt')).output


# Generated at 2022-06-12 04:26:10.410235
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input, output = Path('1'), Path('2')
    assert InputOutput(input, output) == InputOutput(input, output)



# Generated at 2022-06-12 04:26:16.868716
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('.')
    output = Path('.')
    # Standard constructor call
    assert InputOutput(input_, output) == InputOutput(input_, output)
    # Constructor with improper argument types
    with pytest.raises(AssertionError):
        InputOutput('.', output)
    with pytest.raises(AssertionError):
        InputOutput(input_, '.')
    with pytest.raises(AssertionError):
        InputOutput('.', '.')


# Generated at 2022-06-12 04:26:18.549417
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path(), Path()).input == Path()
    assert InputOutput(Path(), Path()).output == Path()

# Generated at 2022-06-12 04:26:21.667952
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path_input = Path('path/to/input')
    path_output = Path('path/to/output')
    io = InputOutput(path_input, path_output)
    assert io.input == path_input
    assert io.output == path_output


# Generated at 2022-06-12 04:26:25.762807
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    result = TransformationResult(tree, True, ['a.py'])
    assert result
    assert result.tree is tree
    assert result.tree_changed
    assert result.dependencies == ['a.py']

# Generated at 2022-06-12 04:26:33.148387
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=None, tree_changed=False, dependencies=None)
    assert isinstance(tr.tree, ast.AST)
    assert isinstance(tr.tree_changed, bool)
    assert isinstance(tr.dependencies, list)
    assert tr.dependencies is not None

# - NodeVisitor
#   - Visitor # TODO
#     - Visitor2 # TODO
#   - NodeTransformer # TODO
#     - NodeTransformer2 # TODO
#   - Walker # TODO


# Generated at 2022-06-12 04:26:38.232667
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """Unit test for InputOutput constructor"""
    # pylint: disable=missing-docstring
    input_path = Path('/path/to/input')
    output_path = Path('/path/to/output')
    input_output = InputOutput(input_path, output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path


# Generated at 2022-06-12 04:26:39.920779
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 0.1, (3, 5), [])


# Generated at 2022-06-12 04:26:46.672899
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1,
                                           time=1.0,
                                           target=(3, 5),
                                           dependencies=['foo', 'bar'])
    assert compilation_result.files == 1
    assert compilation_result.time == 1.0
    assert compilation_result.target == (3, 5)
    assert compilation_result.dependencies == ['foo', 'bar']


# Generated at 2022-06-12 04:26:54.710635
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path("/a/b/c"), Path("/d/e/f")) == \
           InputOutput(input=Path("/a/b/c"), output=Path("/d/e/f"))
    assert InputOutput(Path("/a/b/c"), Path("/d/e/f")).input == Path("/a/b/c")
    assert InputOutput(Path("/a/b/c"), Path("/d/e/f")).output == Path("/d/e/f")


# Generated at 2022-06-12 04:27:04.878988
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from typed_ast import ast3 as ast
    t = ast.AST()
    assert TransformationResult(
        t, True, ["a"]) == TransformationResult(t, True, ["a"])
    assert TransformationResult(
        t, False, ["a"]) != TransformationResult(t, True, ["a"])

    assert TransformationResult(
        t, True, ["a"]) != TransformationResult(t, True, ["b"])
    assert TransformationResult(
        t, True, ["a"]) != TransformationResult(t, False, ["b"])
    assert TransformationResult(
        t, True, ["a"]) != TransformationResult(t, False, ["a"])
    assert TransformationResult(
        t, True, ["a"]) != TransformationResult(t, False, ["b"])


# Generated at 2022-06-12 04:27:11.417638
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path('tests/files/ex1.py')
    path2 = Path('tests/files/ex1.py.unpythonic')

    io = InputOutput(path1, path2)

    assert io.input == path1
    assert io.output == path2
    assert io == (path1, path2)

# Constructor of class InputOutput

# Generated at 2022-06-12 04:27:15.936065
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1,
                                           time=2.0,
                                           target=(3, 4),
                                           dependencies=['a'])
    assert compilation_result.files == 1
    assert compilation_result.time == 2.0
    assert compilation_result.target == (3, 4)
    assert compilation_result.dependencies == ['a']


# Generated at 2022-06-12 04:27:20.862137
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    target = CompilationResult(files=10,
                               time=1,
                               target=(3, 7),
                               dependencies=['a', 'b'])

    assert target.files == 10
    assert target.time == 1
    assert target.target == (3, 7)
    assert target.dependencies == ['a', 'b']



# Generated at 2022-06-12 04:27:26.304987
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_file = Path('input_file.py')
    output_file = Path('output_file.py')
    input_output = InputOutput(input=input_file, output=output_file)
    assert isinstance(input_output, InputOutput)
    assert isinstance(input_output.input, Path)
    assert input_output.input == input_file
    assert input_output.output == output_file



# Generated at 2022-06-12 04:27:29.005497
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path("/input")
    output = Path("/output")
    input_output = InputOutput(input_, output)

    assert input_output.input == input_
    assert input_output.output == output

# Generated at 2022-06-12 04:27:31.822012
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('foo')
    output = Path('bar')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output



# Generated at 2022-06-12 04:27:36.764174
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=7, time=6.9, target=(3, 5),
                            dependencies=["/usr/bin/python3", "numpy"])
    assert res.files == 7
    assert res.time == 6.9
    assert res.target == (3, 5)
    assert res.dependencies == ["/usr/bin/python3", "numpy"]


# Generated at 2022-06-12 04:27:42.671520
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Arrange
    tran = None
    changed = 'a'
    deps = None

    # Act
    try:
        tran = TransformationResult(tran, changed, deps)
    except TypeError as e:
        pass

    # Assert
    assert isinstance(tran, TransformationResult)

# Generated at 2022-06-12 04:27:47.589209
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_tree = ast.AST()
    tree_changed = False
    dependencies = ['a', 'bb', 'ccc']
    transformation_result = TransformationResult(
        tree=ast_tree,
        tree_changed=tree_changed,
        dependencies=dependencies)
    assert transformation_result.tree == ast_tree
    assert transformation_result.tree_changed == tree_changed
    assert transformation_result.dependencies == dependencies

# Generated at 2022-06-12 04:27:48.614086
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.Module(), True, [])

# Generated at 2022-06-12 04:27:51.459093
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('INPUT')
    output = Path('OUTPUT')
    io = InputOutput(input_, output)
    assert io.input == input_
    assert io.output == output


# Generated at 2022-06-12 04:27:56.276407
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_tree = ast.parse('1+1')
    ast_tree_changed = True
    dependencies = ['test', 'test1']
    transformation_result = TransformationResult(ast_tree, ast_tree_changed, dependencies)
    assert transformation_result.tree
    assert transformation_result.tree_changed
    assert transformation_result.dependencies

# Generated at 2022-06-12 04:28:00.560366
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(
        files=1,
        time=42.0,
        target=(3, 8),
        dependencies=['foo', 'bar']
    )
    assert result.files == 1
    assert result.time == 42.0
    assert result.target == (3, 8)
    assert result.dependencies == ['foo', 'bar']

# Generated at 2022-06-12 04:28:03.956398
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(tree=None,  tree_changed=False, dependencies=[])
    TransformationResult(tree=ast.parse('pass'),  tree_changed=False, dependencies=[])
    TransformationResult(tree=ast.parse('pass'),  tree_changed=True, dependencies=['a', 'b'])

# Generated at 2022-06-12 04:28:06.523042
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # type: () -> None
    assert CompilationResult(files=0, time=0.0, target=(3, 7), dependencies=[]).time == 0.0



# Generated at 2022-06-12 04:28:09.736418
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=0,
                               time=0.0,
                               target=(3, 7),
                               dependencies=[])  # type: CompilationResult


# Generated at 2022-06-12 04:28:13.834044
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("print('hello')")
    tree_changed = True
    dependencies = ['a', 'b']
    tr = TransformationResult(tree, tree_changed, dependencies)
    assert tr.tree == tree and tr.tree_changed == tree_changed and tr.dependencies == dependencies

# Transform a string into a list of strings (one for each line)

# Generated at 2022-06-12 04:28:21.113546
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("xyz = 'abc'")
    result = TransformationResult(tree, True, ['a', 'b'])
    assert result.tree == tree
    assert result.tree_changed
    assert result.dependencies == ['a', 'b']

# Generated at 2022-06-12 04:28:22.084657
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path(''), Path(''))

# Generated at 2022-06-12 04:28:26.885567
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    try:
        t = TransformationResult('tree', 'tree_changed', 'dependencies')
        assert False
    except TypeError:
        assert True
    try:
        t = TransformationResult(1, 2, 3)
        assert False
    except TypeError:
        assert True
    try:
        t = TransformationResult(AstStub(), True, [])
        assert True
    except TypeError:
        assert False
    


# Generated at 2022-06-12 04:28:31.603397
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=1,
                            time=0.1,
                            target=(2, 5),
                            dependencies=['a.py', 'b.py'])
    assert res.files == 1
    assert res.time == 0.1
    assert res.target == (2, 5)
    assert res.dependencies == ['a.py', 'b.py']


# Generated at 2022-06-12 04:28:35.635755
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 100
    time = 42.0
    target = (3, 5)
    dependencies = ['a.py', 'b.py', 'c.py']
    r = CompilationResult(files, time, target, dependencies)
    assert r.files == files
    assert r.time == time
    assert r.target == target
    assert r.dependencies == dependencies


# Generated at 2022-06-12 04:28:37.841309
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path('foo.txt'), Path('bar.txt'))
    assert io.input == Path('foo.txt')
    assert io.output == Path('bar.txt')

# Generated at 2022-06-12 04:28:40.230926
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('.')
    output = input
    io = InputOutput(input=input, output=output)
    assert io == InputOutput(input=input, output=output)
    assert io.input == input
    assert io.output == output

# Generated at 2022-06-12 04:28:43.834438
# Unit test for constructor of class InputOutput
def test_InputOutput():
    with pytest.raises(TypeError):
        assert InputOutput('a', 'b')
    assert InputOutput(Path('a'), Path('b'))


# Generated at 2022-06-12 04:28:48.657415
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a'), Path('b')) == InputOutput(Path('a'), Path('b'))
    assert InputOutput(Path('a'), Path('b')) != InputOutput(Path('a'), Path('c'))
    assert InputOutput(Path('a'), Path('b')) != InputOutput(Path('c'), Path('b'))
    assert InputOutput(Path('a'), Path('b')) != InputOutput(Path('c'), Path('d'))
    assert repr(InputOutput(Path('a'), Path('b'))) == "InputOutput(input=Path('a'), output=Path('b'))"



# Generated at 2022-06-12 04:28:52.463862
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a + b', '<test>', 'eval')
    assert TransformationResult(tree, True, ['a'])[0] == tree
    assert TransformationResult(tree, True, ['a'])[1]
    assert TransformationResult(tree, True, ['a'])[2] == ['a']

# Generated at 2022-06-12 04:28:59.177834
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('input'), Path('output'))

# Generated at 2022-06-12 04:29:00.956064
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse("")
    dummy = TransformationResult(t, False, [])
    assert dummy is not None

# Transformer interface

# Generated at 2022-06-12 04:29:02.078621
# Unit test for constructor of class InputOutput
def test_InputOutput():
    _ = InputOutput('input', 'output')


# Generated at 2022-06-12 04:29:04.651341
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_stub = ast.Module(body=[])
    tr = TransformationResult(ast_stub, True, [])
    assert tr.tree == ast_stub
    assert tr.tree_changed
    assert not tr.dependencies

# Generated at 2022-06-12 04:29:07.151300
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.parse("pass"), True, [])

    assert isinstance(tr.tree, ast.AST)
    assert isinstance(tr.tree_changed, bool)
    assert isinstance(tr.dependencies, list)

# Generated at 2022-06-12 04:29:11.136688
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0,
                               target=(3, 6),
                               dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 6)
    assert result.dependencies == ['a', 'b']



# Generated at 2022-06-12 04:29:14.336366
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Arrange
    input = Path('x.py')
    output = Path('x.out.py')

    # Act
    result = InputOutput(input, output)

    # Assert
    assert result.input == input
    assert result.output == output


# Generated at 2022-06-12 04:29:18.751931
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    AstType = type(ast.Str(s='str'))
    res = TransformationResult(tree=AstType,
                               tree_changed=True,
                               dependencies=['A', 'B', 'C'])
    assert isinstance(res.tree, AstType)
    assert res.tree_changed is True
    assert res.dependencies == ['A', 'B', 'C']

# Generated at 2022-06-12 04:29:24.384217
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=12.3,
                               target=(3, 5),
                               dependencies=['foo.py', 'bar/baz.py'])
    assert result.files == 1
    assert result.time == 12.3
    assert result.target == (3, 5)
    assert result.dependencies == ['foo.py', 'bar/baz.py']


# Generated at 2022-06-12 04:29:28.561847
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    x = CompilationResult(files=1,
                          time=2.0,
                          target=(3, 4),
                          dependencies=['A', 'B'])
    assert x.files == 1
    assert x.time == 2.0
    assert x.target == (3, 4)
    assert x.dependencies == ['A', 'B']


# Generated at 2022-06-12 04:29:47.172551
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, False, None) \
           == TransformationResult(None, False, None)
    assert TransformationResult(None, False, None) \
           != TransformationResult(ast.Module(), False, None)
    assert TransformationResult(None, False, None) \
           != TransformationResult(None, True, None)
    assert TransformationResult(None, False, None) \
           != TransformationResult(None, False, [])

assert TransformationResult(ast.Module(), False, None) \
       != TransformationResult(ast.Module(), True, None)
assert TransformationResult(ast.Module(), False, None) \
       != TransformationResult(ast.Module(), False, [])
assert TransformationResult(ast.Module(), False, None) \
       != TransformationResult(ast.Module(), True, [])

# Options for transformation

# Generated at 2022-06-12 04:29:47.981649
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, False, None) is not None

# Generated at 2022-06-12 04:29:50.934749
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cres = CompilationResult(1, 1, (1, 1), [])
    assert cres.files == 1
    assert cres.time == 1
    assert cres.target == (1, 1)
    assert cres.dependencies == []


# Generated at 2022-06-12 04:29:55.421589
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c_res = CompilationResult(files=1,
                              time=0.1,
                              target=CompilationTarget(3, 1),
                              dependencies=['foo', 'bar'])
    assert c_res.files == 1
    assert c_res.time == 0.1
    assert c_res.target == CompilationTarget(3, 1)
    assert c_res.dependencies == ['foo', 'bar']


# Generated at 2022-06-12 04:30:00.398822
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path("input"), Path("output"))
    assert input_output.input == Path("input")
    assert input_output.output == Path("output")

# Generated at 2022-06-12 04:30:02.816372
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a'), Path('b')) == InputOutput(input=Path('a'),
                                                            output=Path('b'))


# Generated at 2022-06-12 04:30:07.759581
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(files=1, time=1.0, target=(3, 7), dependencies=['a'])
    assert isinstance(r.files, int)
    assert isinstance(r.time, float)
    assert isinstance(r.target, CompilationTarget)
    assert isinstance(r.target[0], int)
    assert isinstance(r.target[1], int)
    assert isinstance(r.dependencies, List)
    assert len(r.dependencies) == 1
    assert r.dependencies == ['a']
    assert isinstance(r.dependencies[0], str)


# Generated at 2022-06-12 04:30:11.769899
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 2.0, (3, 4), ['a', 'b', 'c'])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == ['a', 'b', 'c']


# Generated at 2022-06-12 04:30:16.707803
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = InputOutput(Path('./1.py'), Path('./1.pyi'))
    assert a.input == Path('./1.py')
    assert a.output == Path('./1.pyi')

    a = InputOutput(Path('1.py'), Path('1.pyi'))
    assert a.input == Path('1.py')
    assert a.output == Path('1.pyi')

# Generated at 2022-06-12 04:30:18.153322
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2.0, (3, 4), [])


# Generated at 2022-06-12 04:30:47.403045
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=1.0,
                               target=(3, 5),
                               dependencies=['foo.py', 'bar.py'])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 5)
    assert result.dependencies == ['foo.py', 'bar.py']


# Generated at 2022-06-12 04:30:48.931020
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path("sdfsdfs"), Path("sdfsdfs2"))


# Generated at 2022-06-12 04:30:51.948462
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    io = InputOutput(input, output)
    assert io.input == Path('input')
    assert io.output == Path('output')
    assert io == InputOutput(Path('input'), Path('output'))


# Generated at 2022-06-12 04:30:56.609912
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=4, time=0.4,
                               target=(3, 7),
                               dependencies=['library.py', 'another_library.py'])

    assert result.files == 4
    assert result.time == 0.4
    assert result.target == (3, 7)
    assert result.dependencies == ['library.py', 'another_library.py']

# Generated at 2022-06-12 04:30:59.614038
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 1.0, (3, 5), [])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 5)
    assert result.dependencies == []


# Generated at 2022-06-12 04:31:04.874061
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(
        files = 10,
        time = 0.01,
        target = (3, 7),
        dependencies = ['a', 'b', 'c'],
    )
    assert c.files == 10
    assert c.time == 0.01
    assert c.target == (3, 7)
    assert c.dependencies == ['a', 'b', 'c']


# Generated at 2022-06-12 04:31:06.897555
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(tree=ast.parse("1 + 1"), tree_changed=True, dependencies=[])
    t.tree_changed
    t.dependencies

# Generated at 2022-06-12 04:31:09.894275
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """Test InputOutput."""
    # pylint: disable=unused-variable
    # pylint: disable=redefined-outer-name
    input_ = Path('Input.py')
    output = Path('Output.py')
    try:
        InputOutput(input_, output)
    except TypeError:
        assert False



# Generated at 2022-06-12 04:31:14.697722
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    target = (3, 6)

    # Create a new CompilationResult by constructor
    compilation_result = CompilationResult(files=2, time=0.4,
                                           target=target,
                                           dependencies=['path/to/foo'])

    # Test fields
    assert compilation_result.files == 2
    assert compilation_result.time == 0.4
    assert compilation_result.target == target
    assert compilation_result.dependencies == ['path/to/foo']


# Generated at 2022-06-12 04:31:17.697684
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    tree_changed = True
    dependencies = []
    res = TransformationResult(tree, tree_changed, dependencies)
    assert res.tree is tree
    assert res.tree_changed is tree_changed
    assert res.dependencies is dependencies

# Generated at 2022-06-12 04:32:14.005059
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=1, time=0.0, target=(3, 7), dependencies=["foo"])

# Generated at 2022-06-12 04:32:15.960032
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    cell = InputOutput(input, output)

    assert cell.input == input
    assert cell.output == output

# Generated at 2022-06-12 04:32:17.758285
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    my_transform_result = TransformationResult(None, False, [])
    assert my_transform_result.tree_changed is False
    assert len(my_transform_result.dependencies) == 0

# Generated at 2022-06-12 04:32:20.802227
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(10, 3.2, (3, 2), ["file.py", "file2.py"])
    assert cr.files == 10
    assert cr.time == 3.2
    assert cr.dependencies == ["file.py", "file2.py"]
    assert cr.target == (3, 2)



# Generated at 2022-06-12 04:32:24.482635
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=5, time=10.0,
                           target=(3, 6),
                           dependencies=['a', 'b'])
    assert cr.files == 5
    assert cr.time == 10.0
    assert cr.target == (3, 6)
    assert cr.dependencies == ['a', 'b']


# Generated at 2022-06-12 04:32:26.557016
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output

# Generated at 2022-06-12 04:32:32.618554
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_a = ast.parse("x = 0")
    ast_b = ast.parse("x = 1")
    tr_a = TransformationResult(ast_a, False, ["foo", "bar"])
    tr_b = TransformationResult(ast_b, True, ["foo", "bar"])
    assert tr_a.tree == ast_a
    assert tr_a.tree_changed == False
    assert tr_a.dependencies == ["foo", "bar"]
    assert tr_b.tree == ast_b
    assert tr_b.tree_changed == True
    assert tr_b.dependencies == ["foo", "bar"]

# Generated at 2022-06-12 04:32:36.429599
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=0.1, target=(3, 7),
                           dependencies=[foo])
    assert cr.files == 1
    assert cr.time == 0.1
    assert cr.target == (3, 7)
    assert cr.dependencies == [foo]


# Generated at 2022-06-12 04:32:39.680981
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output: InputOutput = InputOutput(Path('a'), Path('b'))
    assert input_output.input.name == 'a'
    assert input_output.output.name == 'b'


# Generated at 2022-06-12 04:32:42.064556
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(None, None, None)
    assert tr.tree is None
    assert tr.tree_changed is None
    assert tr.dependencies is None

# Generated at 2022-06-12 04:33:36.140349
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(0, 0.0, (0, 0), [])

# Generated at 2022-06-12 04:33:39.148471
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # type: () -> None
    cr = CompilationResult(0, 0.0, (3, 0), set())
    assert cr.files == 0
    assert cr.time == 0.0
    assert cr.target == (3, 0)
    assert cr.dependencies == set()


# Generated at 2022-06-12 04:33:42.273300
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    tree_changed = True
    dependencies = ['foo.py']
    tr = TransformationResult(tree, tree_changed, dependencies)
    assert tr.tree == tree
    assert tr.tree_changed == True
    assert tr.dependencies == dependencies

# Generated at 2022-06-12 04:33:44.168425
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # pylint: disable=R0201
    assert TransformationResult(ast.parse('1'), True, [])._fields == \
        ('tree', 'tree_changed', 'dependencies')

# Generated at 2022-06-12 04:33:48.622040
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=1, time=2.0, target=(3, 4),
                            dependencies=['spam', 'eggs'])
    assert res.files == 1
    assert res.time == 2.0
    assert res.target == (3, 4)
    assert res.dependencies == ['spam', 'eggs']


# Generated at 2022-06-12 04:33:50.766626
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i, o = Path('input'), Path('output')
    assert InputOutput(i, o) == InputOutput(*[i, o])

# Generated at 2022-06-12 04:33:52.162087
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=2, time=1.0, target=(3,6), dependencies=[])


# Generated at 2022-06-12 04:33:55.164582
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=0, time=0, target=(0, 0), dependencies=[])
    assert compilation_result.files == 0
    assert compilation_result.time == 0
    assert compilation_result.target == (0, 0)
    assert compilation_result.dependencies == []


# Generated at 2022-06-12 04:33:57.839990
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p1 = Path('test_1')
    p2 = Path('test_2')
    io1 = InputOutput(input=p1, output=p2)
    assert io1.input == p1
    assert io1.output == p2


# Generated at 2022-06-12 04:33:59.571047
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Arrange
    # Act
    tr = TransformationResult(ast.AST(), False, ['dep1', 'dep2'])

    # Assert
    assert isinstance(tr, TransformationResult)