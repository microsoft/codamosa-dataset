

# Generated at 2022-06-12 04:25:22.690931
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input.py')
    output = Path('/tmp/output.py')
    pair = InputOutput(input=input, output=output)
    assert pair.input == input
    assert pair.output == output


# Generated at 2022-06-12 04:25:26.079855
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = InputOutput(Path('/tmp/foo.py'), Path('/tmp/bar.py'))
    assert isinstance(i, InputOutput)
    assert i.input == Path('/tmp/foo.py')
    assert i.output == Path('/tmp/bar.py')

# Generated at 2022-06-12 04:25:31.016574
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    d = ['/home/vagrant/test1.py',
         '/home/vagrant/test2.py']
    r = CompilationResult(files=2, time=0.14, target=(3, 7), dependencies=d)
    assert r.files == 2
    assert r.time == 0.14
    assert r.target == (3, 7)
    assert r.dependencies == d

# Generated at 2022-06-12 04:25:33.038704
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    module = ast.Module(body=[])
    result = TransformationResult(tree=module, tree_changed=True,
                                  dependencies=[])

# Generated at 2022-06-12 04:25:39.146238
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Test without any arguments
    io = InputOutput()

    # Test with bad arguments
    with pytest.raises(TypeError):
        io = InputOutput('foo', 'bar')
    with pytest.raises(TypeError):
        io = InputOutput(Path('foo'), 'bar')
    with pytest.raises(TypeError):
        io = InputOutput('foo', Path('bar'))

    # Test with good arguments
    io = InputOutput(Path('foo'), Path('bar'))
    assert io.input == Path('foo')
    assert io.output == Path('bar')

# Generated at 2022-06-12 04:25:41.305880
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path("input")
    o = Path("output")
    t = InputOutput(i, o)
    assert t.input == i
    assert t.output == o

# Generated at 2022-06-12 04:25:43.739892
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(tree=None,
                                  tree_changed=False,
                                  dependencies=[])
    assert result.tree == None
    assert result.tree_changed == False
    assert result.dependencies == []

# Generated at 2022-06-12 04:25:51.060031
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1,
                                           time=3.14,
                                           target=(3, 8),
                                           dependencies=['foo', 'bar'])

    assert compilation_result.files == 1
    assert compilation_result.time == 3.14
    assert compilation_result.target == (3, 8)
    assert compilation_result.dependencies == ['foo', 'bar']


# Generated at 2022-06-12 04:25:58.814794
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, True, [])


# Metadata to launch program
ProgramLaunch = NamedTuple('ProgramLaunch',
                           [('file', Path),
                            ('args', List[str])])

# Class that stores all needed data about program during it's launch
# It's intended to be used as a means of communication between
# various stages of launching process
ProgramInfo = NamedTuple('ProgramInfo',
                         [('file', Path),
                          ('program_launch', ProgramLaunch),
                          ('compilation_result', CompilationResult),
                          ('transformation_result', TransformationResult),
                          ('execution_result', InputOutput),
                          ('file_input_output', InputOutput),
                          ('target', CompilationTarget)])


# Generated at 2022-06-12 04:26:04.278326
# Unit test for constructor of class TransformationResult
def test_TransformationResult(): # type: () -> None
    trans_result = TransformationResult(tree=ast.AST(),
                                        tree_changed=True,
                                        dependencies=['file1', 'file2'])
    assert isinstance(trans_result.tree, ast.AST)
    assert trans_result.tree_changed
    assert trans_result.dependencies == ['file1', 'file2']

# List of input/output files
IOList = List[InputOutput]

# Generated at 2022-06-12 04:26:09.484293
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=1.0,
                               target=(3, 6),
                               dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 6)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-12 04:26:12.233615
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('test_input.py')
    output = Path('test_output.py')
    pair = InputOutput(input, output)
    assert pair.input == input
    assert pair.output == output


# Generated at 2022-06-12 04:26:16.357718
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(2, 3.0, (3, 1), ['a.py'])
    assert result.files == 2
    assert result.time == 3.0
    assert result.target == (3, 1)
    assert result.dependencies == ['a.py']


# Generated at 2022-06-12 04:26:23.512823
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_tree = ast.parse("import os")
    tree_changed = True
    dependencies = ["os"]
    result = TransformationResult(ast_tree, tree_changed, dependencies)
    assert result.tree == ast.parse("import os")
    assert result.tree_changed == True
    assert result.dependencies == dependencies
    assert str(result) == "TransformationResult(tree=<_ast.Module object at 0x7f6f902b7b00>, tree_changed=True, dependencies=['os'])" # noqa
    assert repr(result) == "TransformationResult(tree=<_ast.Module object at 0x7f6f902b7b00>, tree_changed=True, dependencies=['os'])" # noqa

# Generated at 2022-06-12 04:26:32.840749
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from datetime import datetime
    from . import const
    from .source import Source

    src = Source(Path(__file__), Path('.'))
    src.read()

    tr = TransformationResult(tree=src.tree,
                              tree_changed=True,
                              dependencies=[])

    assert tr.tree
    assert tr.tree_changed
    assert tr.dependencies

    src2 = Source.from_string(src.get_value())
    tr = TransformationResult(tree=src2.tree,
                              tree_changed=True,
                              dependencies=[])

    assert tr.tree
    assert tr.tree_changed
    assert tr.dependencies

# Generated at 2022-06-12 04:26:36.425450
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(0, 3.2, (3, 2), [])
    assert res.files == 0
    assert res.time == 3.2
    assert res.target == (3, 2)
    assert isinstance(res.dependencies, list)


# Generated at 2022-06-12 04:26:38.041831
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 0.5, (3, 6), [])


# Generated at 2022-06-12 04:26:42.495894
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(3, 5), dependencies=[])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 5)
    assert result.dependencies == []


# Generated at 2022-06-12 04:26:47.248024
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # GIVEN
    tree: ast.AST = ast.parse('x = 0')
    tree_changed = True
    dependencies = ['lib/foo.py']

    # WHEN
    transformation = TransformationResult(tree, tree_changed, dependencies)

    # THEN
    assert transformation.tree == tree
    assert transformation.tree_changed == tree_changed
    assert transformation.dependencies == dependencies

# Generated at 2022-06-12 04:26:51.715662
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('test.py')
    output_path = Path('test.lua')
    input_output = InputOutput(input_path, output_path)

    # Validate arguments
    assert input_output.input == input_path
    assert input_output.output == output_path


# Generated at 2022-06-12 04:26:57.836760
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=1, time=1.0, target=(3, 8), dependencies=[])


# Generated at 2022-06-12 04:27:00.081114
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=10, time=10.1, target=(3, 6),
                      dependencies=['abc', 'def'])


# Generated at 2022-06-12 04:27:03.590417
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input.txt')
    output = Path('output.txt')

    input_output = InputOutput(input, output)

    assert input_output.input == input
    assert input_output.output == output



# Generated at 2022-06-12 04:27:06.797391
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path("input"), Path("output")).input == Path("input")
    assert InputOutput(Path("input"), Path("output")).output == Path("output")

# Generated at 2022-06-12 04:27:09.601347
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = InputOutput(Path('aaa'), Path('bbb'))
    assert a.input.name == 'aaa'
    assert a.output.name == 'bbb'


# Generated at 2022-06-12 04:27:13.328535
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(0, 0.0, (0, 0), [])
    assert c.files == 0
    assert c.time == 0.0
    assert c.target == (0, 0)
    assert c.dependencies == []



# Generated at 2022-06-12 04:27:14.180409
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.Module(), True, [])

# Generated at 2022-06-12 04:27:23.792377
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from datetime import datetime
    from random import random
    from six import PY3

    if PY3:
        from ast import parse as ast_parse
    else:
        from typed_ast import ast3 as ast_parse

    r = random()
    rt = TransformationResult(tree = ast_parse("1+2"),
                              tree_changed = True,
                              dependencies = ['a', 'b', 'c'])

    assert rt.tree is not None
    assert rt.tree_changed == True
    assert rt.dependencies == ['a', 'b', 'c']

    assert r != rt.tree
    assert r != rt.tree_changed
    assert r != rt.dependencies


# Generated at 2022-06-12 04:27:25.372796
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('test'), Path('test'))

# Generated at 2022-06-12 04:27:31.118484
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # GIVEN target, time and files
    target = (3, 6)
    time = 0.123
    files = 2

    # WHEN we create a new result
    compilation_result = CompilationResult(files=files,
                                           time=time,
                                           target=target,
                                           dependencies=[])

    # THEN assert that we have correct results
    assert compilation_result.files == files
    assert compilation_result.time == time
    assert compilation_result.target == target


# Generated at 2022-06-12 04:27:40.970837
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    comp_res = CompilationResult(files=100, time=1.0,
                                 target=(3, 7),
                                 dependencies=['a', 'b', 'c'])

    assert comp_res.files == 100
    assert isclose(comp_res.time, 1.0)
    assert comp_res.target == (3, 7)
    assert comp_res.dependencies == ['a', 'b', 'c']


# Generated at 2022-06-12 04:27:45.160038
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=10.0, target=(3, 5),
                           dependencies=["a", "b"])
    assert cr.files == 1
    assert cr.time == 10.0
    assert cr.target == (3, 5)
    assert cr.dependencies == ["a", "b"]


# Generated at 2022-06-12 04:27:46.394400
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 1.0, (2, 7), [])

# Generated at 2022-06-12 04:27:51.058284
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    a = ast.parse('')
    TransformationResult(a, True, [])
    TransformationResult(a, False, [])
    TransformationResult(a, True, ['a'])
    TransformationResult(a, False, ['b'])
    TransformationResult(a, True, ['c', 'd'])
    TransformationResult(a, False, ['e', 'f'])

# Generated at 2022-06-12 04:27:55.896601
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(
        files=0,
        time=0.0,
        target=(3, 6),
        dependencies=[]
    )
    assert result.files == 0
    assert result.time == 0.0
    assert result.target == (3, 6)
    assert result.dependencies == []


# Generated at 2022-06-12 04:27:58.786372
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p1 = Path('foo')
    p2 = Path('bar')
    io = InputOutput(p1, p2)
    assert io.input is p1
    assert io.output is p2

# Generated at 2022-06-12 04:28:03.684994
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p1 = Path('a/b/c')
    p2 = Path('d/e/f')
    inp = InputOutput(p1, p2)
    assert inp.input == p1
    assert inp.output == p2
    inp.input = p2
    inp.output = p1
    assert inp.input == p2
    assert inp.output == p1


# Generated at 2022-06-12 04:28:06.565534
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    actual = CompilationResult(
        files=1, time=1.1, target=(3, 5), dependencies=['test'])
    expect = 'CompilationResult(files=1, time=1.1, target=(3, 5), ' \
             'dependencies=[\'test\'])'
    assert actual.__repr__() == expect


# Generated at 2022-06-12 04:28:09.429298
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = "input"
    output = "output"
    x = InputOutput(input=input, output=output)
    assert x.input == input
    assert x.output == output

# Generated at 2022-06-12 04:28:11.241469
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=2.0, target=(3, 4),
                      dependencies=['a'])


# Generated at 2022-06-12 04:28:24.026249
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(0, 0.0, (3, 0), [])
    assert len(result) == 4
    assert result.files == 0
    assert result.time == 0.0
    assert result.target == (3, 0)
    assert result.dependencies == []
    assert result.dependencies is not result[3]


# Generated at 2022-06-12 04:28:28.693710
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 1
    time = 1.0
    target = (3, 7)
    dependencies = ['a']
    compilation_result = CompilationResult(files, time, target, dependencies)
    assert compilation_result.files == 1
    assert compilation_result.time == 1.0
    assert compilation_result.target == (3, 7)
    assert compilation_result.dependencies == ['a']


# Generated at 2022-06-12 04:28:31.425212
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/a/path')
    output = Path('/another/path')

    io = InputOutput(input, output)

    assert io.input == input
    assert io.output == output


# Generated at 2022-06-12 04:28:33.704905
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('foo')
    output = Path('bar')
    test = InputOutput(input, output)
    assert test.input == input
    assert test.output == output


# Generated at 2022-06-12 04:28:37.483053
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(3, 5),
                               dependencies=[])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 5)
    assert result.dependencies == []



# Generated at 2022-06-12 04:28:40.378500
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=None, tree_changed=False, dependencies=[])

# Result of transformers execution
ExecutionResult = NamedTuple('ExecutionResult',
                             [('files', int),
                              ('time', float),
                              ('dependencies', List[str])])


# Generated at 2022-06-12 04:28:45.241552
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("")
    tree_changed = False
    dependencies = []

    assert TransformationResult(tree, tree_changed, dependencies).tree == tree
    assert TransformationResult(tree, tree_changed, dependencies).tree_changed == tree_changed
    assert TransformationResult(tree, tree_changed, dependencies).dependencies == dependencies

# Generated at 2022-06-12 04:28:47.339770
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('import numpy as np')
    result = TransformationResult(tree, False, ['numpy'])
    assert result.tree == tree
    assert not result.tree_changed
    assert result.dependencies == ['numpy']

# Generated at 2022-06-12 04:28:51.365896
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=2, time=0.1, target=(3, 0), dependencies=['foo'])
    assert result.files == 2
    assert result.time == 0.1
    assert result.target == (3, 0)
    assert result.dependencies == ['foo']


# Generated at 2022-06-12 04:28:52.541463
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path("input"), Path("output"))



# Generated at 2022-06-12 04:29:15.606825
# Unit test for constructor of class InputOutput
def test_InputOutput():
    pair = InputOutput(Path('/tmp/file.py'), Path('/tmp/file.pyc'))
    assert pair.input == Path('/tmp/file.py')
    assert pair.output == Path('/tmp/file.pyc')


# Generated at 2022-06-12 04:29:18.095066
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('foo')
    out = Path('bar')
    assert InputOutput(inp, out).input == inp
    assert InputOutput(inp, out).output == out


# Generated at 2022-06-12 04:29:21.284305
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=0, time=0.0, target=(3, 7), dependencies=[])
    assert res.files == 0
    assert res.time == 0
    assert res.target == (3, 7)
    assert res.dependencies == []



# Generated at 2022-06-12 04:29:25.045650
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    n = ast.Num(42)
    res = TransformationResult(n, True, [])
    assert res.tree == n and res.tree_changed and len(res.dependencies) == 0


# Printer of errors

# Generated at 2022-06-12 04:29:27.993796
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    constructed = TransformationResult(
        ast.AST(),
        not True,
        ['ast3', 'typing']
    )
    assert constructed.tree_changed == False
    assert constructed.dependencies == ['ast3', 'typing']
    assert constructed.tree

# Generated at 2022-06-12 04:29:31.660244
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('/project/test.py')
    output_path = Path('/project/test_out.py')
    input_output = InputOutput(input_path, output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path


# Generated at 2022-06-12 04:29:36.750838
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('')
    tree_changed = True
    dependencies = ['a.py', 'b.py']
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree is tree
    assert result.tree_changed is True
    assert result.dependencies == dependencies


# Information about compilation of one file
FileCompilationResult = NamedTuple('FileCompilationResult',
                                   [('output_file', Path),
                                    ('success', bool)])


# Generated at 2022-06-12 04:29:41.400430
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(10, 10.0, (3, 5), ['d1', 'd2'])
    assert cr.time == 10.0
    if sys.version_info.major != 3:
        assert cr.target[0] == 3
        assert cr.target[1] == 5
    assert cr.dependencies[0] == 'd1'
    assert cr.dependencies[1] == 'd2'


# Generated at 2022-06-12 04:29:42.689827
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert not TransformationResult(None, None, None).tree_changed
    assert TransformationResult(None, True, None).tree_changed

# Generated at 2022-06-12 04:29:44.001701
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert isinstance(TransformationResult(None, False, []),
                      TransformationResult)

# Generated at 2022-06-12 04:30:38.136473
# Unit test for constructor of class InputOutput
def test_InputOutput():
    class IO(InputOutput):
        def __repr__(self):
            return 'IO("{}", "{}")'.format(repr(self.input), repr(self.output))
    assert str(IO('file.py', 'file.c')) == 'IO("file.py", "file.c")'

# Generated at 2022-06-12 04:30:42.013078
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # type: () -> None
    """
    Unit test for constructor of class CompilationResult
    """
    cr = CompilationResult(files = 1,
                           time = 1.0,
                           target = (3, 5),
                           dependencies = []) # type: CompilationResult
    assert cr.files == 1


# Generated at 2022-06-12 04:30:43.848608
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test = InputOutput('input', 'output')
    assert test.input is 'input'
    assert test.output is 'output'



# Generated at 2022-06-12 04:30:47.703511
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path("app/app.py")
    output = Path("app/app.pyc")
    in_out = InputOutput(input, output)

    assert in_out.input == input
    assert in_out.output == output
    assert in_out == InputOutput("app/app.py", "app/app.pyc")

# Generated at 2022-06-12 04:30:56.387947
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(10, 1.5, (3, 5), ['file1.py', 'file2.py'])
    res1 = CompilationResult(10, 1.5, (3, 5), ['file1.py', 'file2.py'])
    res2 = CompilationResult(10, 1.5, (3, 6), ['file1.py', 'file2.py'])
    res3 = CompilationResult(10, 1.5, (3, 5), ['file1.py', 'file2.py',
                                               'file3.py'])
    assert res == res1
    assert res != res2
    assert res < res2
    assert res <= res2
    assert res2 > res
    assert res2 >= res
    assert res3 > res
    assert res3 >= res

# Generated at 2022-06-12 04:31:00.535272
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=2,
                               time=0.5,
                               target=(3, 5),
                               dependencies=["file1", "file2"])

    assert result.files == 2
    assert result.time == 0.5
    assert result.target == (3, 5)
    assert result.dependencies == ["file1", "file2"]


# Generated at 2022-06-12 04:31:02.850708
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(None, False, [])
    assert res.tree is None
    assert not res.tree_changed
    assert res.dependencies == []

# Generated at 2022-06-12 04:31:05.865662
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    a = CompilationResult(files=0, time=0.0, target=(0, 1), dependencies=[])
    assert a.files == 0
    assert a.time == 0.0
    assert a.target == (0, 1)
    assert a.dependencies == []



# Generated at 2022-06-12 04:31:08.913213
# Unit test for constructor of class CompilationResult
def test_CompilationResult():  # type: () -> None
    i = CompilationResult(1, 2.34, (2, 7), [])
    assert i.files == 1
    assert i.time == 2.34
    assert i.target == (2, 7)
    assert i.dependencies == []



# Generated at 2022-06-12 04:31:12.320826
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput('input', 'output') == InputOutput('input', 'output')
    assert InputOutput('input', 'output1') != InputOutput('input', 'output2')
    assert InputOutput('input1', 'output') != InputOutput('input2', 'output')
    assert InputOutput('input1', 'output1') != InputOutput('input2', 'output2')

# Generated at 2022-06-12 04:33:03.896300
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path('x'), Path('y'))
    assert io.input == Path('x')
    assert io.output == Path('y')

# Generated at 2022-06-12 04:33:07.682003
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse('""'), True, []).tree == ast.parse('""')
    assert TransformationResult(ast.parse('""'), True, []).tree_changed == True
    assert TransformationResult(ast.parse('""'), True, []).dependencies == []

# Generated at 2022-06-12 04:33:10.848372
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert len(TransformationResult._fields) == 3
    tree = ast.parse("class Foo: pass")
    result = TransformationResult(tree, True, [])
    assert result.tree == tree
    assert result.tree_changed
    assert result.dependencies == []

# Generated at 2022-06-12 04:33:14.485656
# Unit test for constructor of class InputOutput
def test_InputOutput():
    file_in = Path('/a/b/c/d/1.py')
    file_out = Path('/a/b/c/d/1.pyc')
    assert InputOutput(file_in, file_out) == InputOutput(input=file_in,
                                                         output=file_out)


# Generated at 2022-06-12 04:33:16.795611
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(1, 2) == InputOutput(1, 2)
    assert InputOutput(1, 2) != InputOutput(2, 3)


# Generated at 2022-06-12 04:33:20.356528
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 2.0, (3, 4), ['d1', 'd2'])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == ['d1', 'd2']



# Generated at 2022-06-12 04:33:22.870676
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.Name('test')
    r = TransformationResult(tree=t, tree_changed=False, dependencies=[])
    assert r.tree == t

# Generated at 2022-06-12 04:33:25.597082
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Simple test with empty path
    InputOutput(Path(''), Path(''))
    # Test with non-empty path
    InputOutput(Path('example/input.txt'), Path('example/output.py'))
    

# Generated at 2022-06-12 04:33:27.309192
# Unit test for constructor of class CompilationResult

# Generated at 2022-06-12 04:33:30.406408
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files = 2, time = 0.01, target = (2, 7), dependencies = ['foo'])
    assert cr.files == 2
    assert cr.time == 0.01
    assert cr.target == (2, 7)
    assert cr.dependencies == ['foo']
