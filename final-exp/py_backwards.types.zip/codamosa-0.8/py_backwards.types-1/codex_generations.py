

# Generated at 2022-06-12 04:25:18.482178
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(42, 3.1415, (2, 7), [])


# Generated at 2022-06-12 04:25:20.615197
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('foo.txt')
    output = Path('bar.txt')
    in_out = InputOutput(input, output)
    assert in_out.input == input
    assert in_out.output == output

# Generated at 2022-06-12 04:25:23.880815
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=1, time=1.0,
                            target=(3, 0), dependencies=[])

    assert res.files == 1
    assert res.time == 1.0
    assert res.target == (3, 0)
    assert res.dependencies == []


# Generated at 2022-06-12 04:25:24.759179
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(None, None)



# Generated at 2022-06-12 04:25:29.311286
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('input'), Path('output')) == InputOutput(Path('input'), Path('output'))
    assert InputOutput(Path('input'), Path('output')) != InputOutput(Path('INPUT'), Path('output'))
    assert InputOutput(Path('input'), Path('output')) != InputOutput(Path('input'), Path('OUTPUT'))



# Generated at 2022-06-12 04:25:32.090833
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("1 + 2")
    res = TransformationResult(tree, True, [])
    assert res.tree is tree
    assert res.tree_changed is True
    assert res.dependencies == []

# Generated at 2022-06-12 04:25:36.322151
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('/Users/baris.urhan/test'),
                               Path('/Users/baris.urhan/test.py'))
    assert input_output.input == Path('/Users/baris.urhan/test')
    assert input_output.output == Path('/Users/baris.urhan/test.py')



# Generated at 2022-06-12 04:25:38.816290
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('asd')
    outp = Path('asd')
    tr = InputOutput(inp, outp)
    assert tr.input == inp
    assert tr.output == outp

# Generated at 2022-06-12 04:25:42.257575
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(ast.parse("a = 'foo'"),
                               True,
                               ['foo1', 'foo2'])
    assert res.tree is not None
    assert res.tree_changed is True
    assert res.dependencies == ['foo1', 'foo2']


# Generated at 2022-06-12 04:25:44.043183
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1,
                      time=1.0,
                      target=(3, 5),
                      dependencies=['a'])


# Generated at 2022-06-12 04:25:49.213006
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('/home/user/input.txt')
    o = Path('/home/user/output.txt')
    in_out = InputOutput(i, o)
    assert in_out.input == i and in_out.output == o



# Generated at 2022-06-12 04:25:58.415846
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    def fun(x: int) -> int:
        """Docstring for function."""
        return x + 1
    fun.__module__ = 'module'
    fun.__name__ = 'fun'
    fun.__qualname__ = 'module.fun'
    fun.__doc__ = 'Docstring for function.'
    fun_tree = ast.parse(inspect.getsource(fun))
    module_tree = ast.Module(body=[fun_tree])
    module_tree.filename = '/a/b/c'
    module_tree_changed = ast.Module(body=[fun_tree])
    module_tree_changed.filename = '/a/b/c'
    result = TransformationResult(tree=module_tree,
                                  tree_changed=False,
                                  dependencies=[])
    assert result.tree == module_tree


# Generated at 2022-06-12 04:25:59.864015
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(10, 1000, (3, 5), ['foo'])  # type: ignore


# Generated at 2022-06-12 04:26:04.508510
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r1 = CompilationResult(10, 3.14, (3, 6), ['/some/path'])
    assert r1.files == 10
    assert r1.time == 3.14
    assert r1.target == (3, 6)
    assert r1.dependencies == ['/some/path']


# Generated at 2022-06-12 04:26:07.445961
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.Name('ast', ast.Load())
    tree_changed = True
    dependencies = []
    TransformationResult(tree, tree_changed, dependencies)

# Generated at 2022-06-12 04:26:08.353698
# Unit test for constructor of class InputOutput
def test_InputOutput():
    with pytest.raises(TypeError):
        InputOutput('foo', 'bar')

# Generated at 2022-06-12 04:26:11.270855
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/file1.py')
    output = Path('/tmp/file1.py.new')
    pair = InputOutput(input, output)
    assert pair.input == input
    assert pair.output == output


# Generated at 2022-06-12 04:26:13.818445
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input=Path('input'),
                       output=Path('output'))
    assert InputOutput(input=None,
                       output=None)


# Generated at 2022-06-12 04:26:18.228995
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('input'), Path('output')) == InputOutput(Path('input'), Path('output'))
    assert InputOutput(Path('input'), Path('input')) == InputOutput(Path('input'), Path('input'))
    assert InputOutput(Path('input'), Path('input')) != InputOutput(Path('output'), Path('output'))

# Generated at 2022-06-12 04:26:19.125355
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(None, None, None)

# Generated at 2022-06-12 04:26:25.822524
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    tree = ast.parse("1", "<string>", "eval")
    res = TransformationResult(tree, True, ['a', 'b'])
    assert res.tree == tree
    assert res.tree_changed == True
    assert res.dependencies == ['a', 'b']

# Generated at 2022-06-12 04:26:28.114727
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1,
                      time=0,
                      target=(0, 0),
                      dependencies=[])


# Generated at 2022-06-12 04:26:31.285004
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput('input', 'output')
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')

# Generated at 2022-06-12 04:26:35.839019
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=100, time=1.0, target=(3, 4),
                            dependencies=['lib_a', 'lib_b'])

    if res.files != 100:
        raise AssertionError()
    if res.time != 1.0:
        raise AssertionError()
    if res.target != (3, 4):
        raise AssertionError()
    if res.dependencies != ['lib_a', 'lib_b']:
        raise AssertionError()



# Generated at 2022-06-12 04:26:38.702254
# Unit test for constructor of class InputOutput
def test_InputOutput():
    data = {'input': Path('path/to/input'),
            'output': Path('path/to/output')}

    assert InputOutput(**data) == InputOutput(**data)


# Generated at 2022-06-12 04:26:43.554126
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('tests/examples/mkdir.py')
    output_path = Path('tests/output/mkdir.py')
    input_output = InputOutput(input_path, output_path)

    assert input_output.input == input_path
    assert input_output.output == output_path

# Generated at 2022-06-12 04:26:47.642642
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=3,
                            time=123.456,
                            target=(3, 7),
                            dependencies=["foo.py"])

    assert res.files == 3
    assert res.time == 123.456
    assert res.target == (3, 7)
    assert res.dependencies == ["foo.py"]

# Generated at 2022-06-12 04:26:51.070186
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('input')
    output = Path('output')
    x = InputOutput(input_, output)
    assert x.input == input_
    assert x.output == output


# Generated at 2022-06-12 04:26:54.610776
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('foo'), Path('bar'))
    assert input_output.input == Path('foo')
    assert input_output.output == Path('bar')


# Generated at 2022-06-12 04:26:58.988620
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('path/to/input')
    output_path = Path('path/to/output')
    input_output = InputOutput(input_path, output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path


# Generated at 2022-06-12 04:27:04.964673
# Unit test for constructor of class InputOutput
def test_InputOutput():
    f = InputOutput(Path('foo'), Path('bar'))
    assert f.input == Path('foo')
    assert f.output == Path('bar')


# Generated at 2022-06-12 04:27:09.468259
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    node = ast.Constant()
    result = TransformationResult(node, True, [])
    assert result.tree == node
    assert result.tree_changed == True
    assert result.dependencies == []

# Generated at 2022-06-12 04:27:11.372668
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=None, tree_changed=True,
                                dependencies=[]).tree_changed

# Generated at 2022-06-12 04:27:12.370288
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput('input', 'output')



# Generated at 2022-06-12 04:27:15.845879
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(3, 0.5, (3, 6), ['a', 'b'])
    assert res.files == 3
    assert res.time == 0.5
    assert res.target == (3, 6)
    assert res.dependencies == ['a', 'b']


# Generated at 2022-06-12 04:27:17.756402
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(ast.AST(), True, [])
    assert t.tree_changed



# Generated at 2022-06-12 04:27:21.383276
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/foo/bar')
    output = Path('/fizz/buzz')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-12 04:27:24.735387
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=None,
                              tree_changed=False,
                              dependencies=[])
    assert tr.tree is None
    assert not tr.tree_changed
    assert tr.dependencies == []


# Generated at 2022-06-12 04:27:26.092615
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.Module(), True, [])


# Generated at 2022-06-12 04:27:30.236381
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(input=Path('input'), output=Path('output'))
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')
    assert str(input_output.input) == 'input'
    assert str(input_output.output) == 'output'


# Generated at 2022-06-12 04:27:42.788283
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 10
    time = 2.0
    target = (3, 5)
    dependencies = []
    res = CompilationResult(files, time, target, dependencies)
    assert res.files == 10
    assert res.time == 2.0
    assert res.target == (3, 5)
    assert res.dependencies == dependencies


# Generated at 2022-06-12 04:27:46.393810
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation = CompilationResult(files=32, time=66.0, target=(2, 7), dependencies=[])
    assert compilation.files == 32
    assert compilation.time == 66.0
    assert compilation.target == (2, 7)
    assert compilation.dependencies == []


# Generated at 2022-06-12 04:27:52.814157
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('file.py')
    output = Path('file.json')
    io = InputOutput(input=input, output=output)
    assert io.input == input
    assert io.output == output

    # Assert that __repr__ and __str__ are working
    assert repr(io) == "InputOutput(input=Path('file.py'), output=Path('file.json'))"
    assert str(io) == "InputOutput(input=Path('file.py'), output=Path('file.json'))"



# Generated at 2022-06-12 04:27:54.717392
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(Path('input'), Path('output'))



# Generated at 2022-06-12 04:27:58.832867
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(2, 3.5, (3, 4), ["abc.py"])
    assert r.files == 2
    assert r.time == 3.5
    assert r.target == (3, 4)
    assert r.dependencies == ["abc.py"]


# Generated at 2022-06-12 04:28:01.199211
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('foo')
    output = Path('bar')
    assert InputOutput(input, output).input == input
    assert InputOutput(input, output).output == output

# Generated at 2022-06-12 04:28:06.393405
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path_in = Path('in.py')
    path_out = Path('out.py')
    assert InputOutput(path_in, path_out) == InputOutput(path_in, path_out)
    assert InputOutput(path_in, path_out) != InputOutput(path_out, path_out)
    assert (InputOutput(path_in, path_out) !=
            InputOutput(path_in, path_in))
    assert (InputOutput(path_in, path_out) !=
            InputOutput(path_out, path_in))

# Generated at 2022-06-12 04:28:09.663505
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inout = InputOutput(Path('a.py'), Path('a.js'))
    assert inout.input == Path('a.py')
    assert inout.output == Path('a.js')



# Generated at 2022-06-12 04:28:13.761549
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    """
    Testing the constructor of CompilationResult
    """
    result = CompilationResult(5, 3.5, (2, 7), ['dep1', 'dep2'])
    assert result.files == 5
    assert result.time == 3.5
    assert result.target == (2, 7)
    assert result.dependencies == ['dep1', 'dep2']


# Generated at 2022-06-12 04:28:15.749164
# Unit test for constructor of class CompilationResult
def test_CompilationResult():

    CompilationResult(1, 2.1, (3, 4))
    CompilationResult(1, 2.1, (3, 4), ['a', 'b'])


# Generated at 2022-06-12 04:28:33.846315
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2.0, (3, 4), ['a', 'b'])



# Generated at 2022-06-12 04:28:36.121885
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('foo')
    o = Path('bar')
    io = InputOutput(i, o)
    assert io.input == i
    assert io.output == o

# Generated at 2022-06-12 04:28:39.642656
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test_tree = ast.parse('a = 1')
    test_dep = ['test.py']
    res = TransformationResult(test_tree, False, test_dep)
    assert res.tree is test_tree
    assert res.tree_changed is False
    assert res.dependencies == test_dep

# Generated at 2022-06-12 04:28:46.224124
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.Module(), False, []) == TransformationResult(ast.Module(), False, [])
    assert TransformationResult(ast.Module(), True, []) != TransformationResult(ast.Module(), False, [])


# AST node representation
NodeRepresentation = NamedTuple('NodeRepresentation', [('path', str),
                                                       ('type', type),
                                                       ('line', int),
                                                       ('column', int),
                                                       ('context', ast.AST)])


# Generated at 2022-06-12 04:28:54.903150
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result_1 = CompilationResult(files=1, time=1.0, target=(2, 7), dependencies=['a'])
    result_2 = CompilationResult(files=1, time=1.0, target=(2, 7), dependencies=['a'])
    result_3 = CompilationResult(files=2, time=1.0, target=(2, 7), dependencies=['a'])
    result_4 = CompilationResult(files=1, time=1.1, target=(2, 7), dependencies=['a'])
    result_5 = CompilationResult(files=1, time=1.0, target=(2, 6), dependencies=['a'])
    assert result_1 == result_2
    assert result_1 != result_3
    assert result_1 != result_4
    assert result_1 != result_5

# Generated at 2022-06-12 04:28:57.853183
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=10, time=123.0, target=(1, 2), dependencies=['a', 'b']) == \
        CompilationResult(files=10, time=123.0, target=(1, 2), dependencies=['a', 'b'])



# Generated at 2022-06-12 04:28:59.927548
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('in')
    o = Path('out')
    io = InputOutput(i, o)
    assert io.input == i
    assert io.output == o

# Generated at 2022-06-12 04:29:02.002336
# Unit test for constructor of class InputOutput
def test_InputOutput():
    in_ = Path('input')
    out = Path('output')
    io = InputOutput(in_, out)
    assert io.input == in_
    assert io.output == out

# Generated at 2022-06-12 04:29:05.069066
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Valid constructor
    inp = Path('/tmp/input.py')
    out = Path('/tmp/output.py')
    constructor = InputOutput(input=inp, output=out)
    assert constructor is not None
    assert constructor.input == inp
    assert constructor.output == out

# Generated at 2022-06-12 04:29:09.190730
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(files=3,
                          time=1.2,
                          target=(3, 4),
                          dependencies=['main.py', 'dep.py'])
    assert r.files == 3
    assert r.time == 1.2
    assert r.target == (3, 4)
    assert r.dependencies == ['main.py', 'dep.py']


# Generated at 2022-06-12 04:29:53.504574
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('path1'), Path('path2')) == \
        InputOutput(Path('path1'), Path('path2'))
    assert InputOutput(Path('path1'), Path('path2')) != \
        InputOutput(Path('path1'), Path('path2'), 'extra')



# Generated at 2022-06-12 04:29:59.267176
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    a = CompilationResult(5, 6.5, (3, 4), ['b', 'c'])
    assert a.files == 5
    assert a.time == 6.5
    assert a.target == (3, 4)
    assert a.dependencies == ['b', 'c']


# Generated at 2022-06-12 04:30:02.037093
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    actual = InputOutput(input=input, output=output)
    assert actual.input == input
    assert actual.output == output

# Generated at 2022-06-12 04:30:05.950511
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1, time=0.1,
                                           target=(3, 7),
                                           dependencies=['a.py'])
    assert compilation_result.files == 1
    assert compilation_result.time == 0.1
    assert compilation_result.target == (3, 7)
    assert compilation_result.dependencies == ['a.py']


# Generated at 2022-06-12 04:30:08.344523
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse('print("hello")'),
                                True,
                                []) == TransformationResult(ast.parse('print("hello")'),
                                                            True,
                                                            [])


# Generated at 2022-06-12 04:30:09.797673
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse("pass")
    assert t == TransformationResult(tree=t, tree_changed=False, dependencies=[])

# Generated at 2022-06-12 04:30:14.071201
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    t = CompilationResult(files=1, time=1.0, target=(3, 7), dependencies=['a', 'b'])
    assert t.files == 1
    assert t.time == 1.0
    assert t.target == (3, 7)
    assert t.dependencies == ['a', 'b']


# Generated at 2022-06-12 04:30:18.273081
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1,
                                           time=1.0,
                                           target=(2, 7),
                                           dependencies=[])
    assert compilation_result.files == 1
    assert compilation_result.time == 1.0
    assert compilation_result.target == (2, 7)
    assert compilation_result.dependencies == []


# Generated at 2022-06-12 04:30:20.709550
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.Module()
    tr = TransformationResult(tree, True, [])
    assert tr.tree == tree
    assert tr.tree_changed
    assert tr.d

# Generated at 2022-06-12 04:30:26.098095
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 2
    time = 0.23
    target = (2, 7)
    dependencies = ['a', 'b', 'c']
    result = CompilationResult(files, time, target, dependencies)
    assert result.files == files
    assert result.time == time
    assert result.target == target
    assert result.dependencies == dependencies


# Generated at 2022-06-12 04:32:08.667229
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(10, 0.0, (3, 6), ['some module'])
    assert result.files == 10
    assert result.time == 0.0
    assert result.target == (3, 6)
    assert result.dependencies == ['some module']


# Generated at 2022-06-12 04:32:11.474379
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a'), Path('b')) == InputOutput(Path('a'), Path('b'))
    assert InputOutput(Path('a'), Path('b')) != InputOutput(Path('b'), Path('b'))


# Generated at 2022-06-12 04:32:13.812438
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path = "foo"
    input_output = InputOutput(Path(path), Path(path + ".py"))

    assert input_output.input == Path(path)
    assert input_output.output == Path(path + ".py")

# Generated at 2022-06-12 04:32:15.500692
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2.1,
                      (3, 4),
                      ['a', 'b', 'c'])


# Generated at 2022-06-12 04:32:17.815804
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse("x = 1")
    r = TransformationResult(t, False, ['a', 'b'])
    assert r.tree == t
    assert not r.tree_changed
    assert r.dependencies == ['a', 'b']

# Generated at 2022-06-12 04:32:21.337617
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=1,
                          time=0.1,
                          target=CompilationTarget((3, 7)),
                          dependencies=['dep1', 'dep2'])
    assert c.files == 1
    assert c.time == 0.1
    assert c.target == CompilationTarget((3, 7))
    assert c.dependencies == ['dep1', 'dep2']

# Generated at 2022-06-12 04:32:22.966301
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('input.py'), Path('output.py'))


# Generated at 2022-06-12 04:32:25.818287
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_input = '/a/b/c'
    test_output = '/d/e/f'
    io = InputOutput(test_input, test_output)
    assert io.input == Path(test_input)
    assert io.output == Path(test_output)


# Generated at 2022-06-12 04:32:30.352039
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from inspect import signature


# Generated at 2022-06-12 04:32:33.682115
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path_in, path_out = Path('a/b/c.pyi'), Path('d/e/f.pyi')
    pair = InputOutput(path_in, path_out)
    assert (pair.input, pair.output) == (path_in, path_out)



# Generated at 2022-06-12 04:34:21.826349
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(None, False, [])
    assert res.tree is None
    assert not res.tree_changed
    assert res.dependencies == []

# Generated at 2022-06-12 04:34:23.935793
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p1, p2 = Path('p1'), Path('p2')
    io = InputOutput(p1, p2)
    assert io.input == p1
    assert io.output == p2


# Generated at 2022-06-12 04:34:26.391090
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    d = {"files": 4,
         "time": 100.0,
         "target": (3, 5),
         "dependencies": ['C', 'D', 'B', 'A']}
    assert CompilationResult(**d) == d



# Generated at 2022-06-12 04:34:30.346680
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=42,
                               time=123.456,
                               target=(3, 6),
                               dependencies=[])
    assert result.files == 42
    assert result.time == 123.456
    assert result.target == (3, 6)
    assert result.dependencies == []


# Generated at 2022-06-12 04:34:32.825922
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.AST(), False, [])

# Result of compiling
CompilingResult = NamedTuple('CompilingResult',
                             [('result', CompilationResult),
                              ('input', Path),
                              ('output', Path)])


# Generated at 2022-06-12 04:34:35.896291
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Arrange
    i = Path('/foo/bar')
    o = Path('/bar/bar')
    # Act
    pair = InputOutput(i, o)
    # Assert
    assert pair.input == i
    assert pair.output == o


# Generated at 2022-06-12 04:34:39.269984
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=10, time=0.01, target=(3, 5), dependencies=[])
    assert cr.files == 10
    assert cr.time == 0.01
    assert cr.target == (3, 5)
    assert cr.dependencies == []



# Generated at 2022-06-12 04:34:42.701328
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=None, tree_changed=False, dependencies=None)

# Result of executing a test file
TestExecutionResult = NamedTuple('TestExecutionResult',
                                 [('time', float),
                                  ('return_code', int)])

# Generated at 2022-06-12 04:34:45.613373
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # pylint: disable=unused-variable
    tree = ast.AST()
    tree_changed = False
    dependencies = []

    TransformationResult(tree, tree_changed, dependencies)

# Generated at 2022-06-12 04:34:49.567225
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(ast.parse(""), False, [])
    res = TransformationResult(ast.parse(""), True, [])
    res = TransformationResult(ast.parse(""), False, ["a"])
    res = TransformationResult(ast.parse(""), True, ["a"])
