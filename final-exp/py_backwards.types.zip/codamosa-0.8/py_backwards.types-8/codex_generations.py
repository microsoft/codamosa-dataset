

# Generated at 2022-06-12 04:25:23.688262
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(3, 5), dependencies=[])


# Generated at 2022-06-12 04:25:25.491471
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a'), Path('b')) == \
        InputOutput(input=Path('a'), output=Path('b'))

# Generated at 2022-06-12 04:25:27.575171
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    inputs = [x for x in [1, 2, 3]]
    CompilationResult(1, 2, (3, 4), inputs)


# Generated at 2022-06-12 04:25:31.142530
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("")
    result = TransformationResult(tree=tree,
                                  tree_changed=True,
                                  dependencies=[])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == []


# Generated at 2022-06-12 04:25:33.535372
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a.py'), Path('b.py')) == InputOutput(Path('a.py'), Path('b.py'))



# Generated at 2022-06-12 04:25:41.858641
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    import unittest

    class TestCompilationResult(unittest.TestCase):
        def test_it(self):
            try:
                CompilationResult(1, 1.0, (3, 5), ['/a/b/c', 'd/e/f'])
            except Exception as e:
                self.fail(str(e))
            with self.assertRaises(TypeError):
                CompilationResult(1, 1.0, (3, 5), ['/a/b/c', 1])
            with self.assertRaises(TypeError):
                CompilationResult(1, 1.0, (3, 5), None)
            with self.assertRaises(TypeError):
                CompilationResult(1, 1.0, (3, 5))

    unittest.main()


# Generated at 2022-06-12 04:25:48.290934
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
        result = CompilationResult(files=0, time=0.0,
                                   target=(0, 0), dependencies=[])
        assert isinstance(result.files, int)
        assert isinstance(result.time, float)
        assert isinstance(result.target, tuple)
        assert len(result.target) == 2
        assert isinstance(result.dependencies, list)
        assert len(result.dependencies) == 0


# Generated at 2022-06-12 04:25:52.808473
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path_in = Path('foo.py')
    path_out = Path('foo.c')
    in_out = InputOutput(input=path_in, output=path_out)
    assert in_out.input == path_in
    assert in_out.output == path_out


# Generated at 2022-06-12 04:25:55.415553
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(input=Path('input'), output=Path('output'))

    assert input_output.input == Path('input')
    assert input_output.output == Path('output')



# Generated at 2022-06-12 04:25:57.766629
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('a'), Path('b'))

    assert input_output.input == Path('a')
    assert input_output.output == Path('b')


# Generated at 2022-06-12 04:26:03.195356
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path = Path('foo')
    io = InputOutput(path, path)

    assert io.input == path
    assert io.output == path
    assert io.input == io.output


# Generated at 2022-06-12 04:26:06.717079
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    X = TransformationResult(None, False, [])
    assert type(X.tree) is ast.AST
    assert not X.tree_changed
    assert len(X.dependencies) == 0



# Generated at 2022-06-12 04:26:09.119806
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 2, (3, 4), ['a'])
    assert result.files is 1
    assert result.time is 2
    assert result.target == (3, 4)
    assert result.dependencies == ['a']


# Generated at 2022-06-12 04:26:13.281906
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(
        files=4,
        time=3.14,
        target=(3, 7),
        dependencies=['a', 'b', 'c']
    )
    assert cr.files == 4
    assert cr.time == 3.14
    assert cr.target == (3, 7)
    assert cr.dependencies == ['a', 'b', 'c']


# Generated at 2022-06-12 04:26:17.389121
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    tr = TransformationResult(tree=ast.parse("a = 1", "<string>"), tree_changed=True, dependencies=[])
    assert tr.tree == ast.parse("a = 1", "<string>")
    assert tr.tree_changed is True
    assert tr.dependencies == []

# Generated at 2022-06-12 04:26:21.042377
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('input/path')
    output_path = Path('output/path')
    input_output = InputOutput(input = input_path, output = output_path)

    assert input_output.input == input_path
    assert input_output.output == output_path


# Generated at 2022-06-12 04:26:24.377997
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = "foo"
    output_path = "bar"
    inputoutput = InputOutput(input_path, output_path)
    assert inputoutput.input == input_path
    assert inputoutput.output == output_path


# Generated at 2022-06-12 04:26:28.901435
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from typed_ast import ast3 as ast
    tree = ast.parse('x = 3', mode='eval')
    dependencies = []
    r = TransformationResult(tree, True, dependencies)
    assert r.tree == tree
    assert r.tree_changed == True
    assert r.dependencies == dependencies


# Generated at 2022-06-12 04:26:32.838802
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p = Path('foo.py')
    q = Path('bar.py')
    assert InputOutput(p, q) == InputOutput(p, q)
    assert InputOutput(p, q) != InputOutput(q, p)



# Generated at 2022-06-12 04:26:36.426078
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=10, target=(2, 7), dependencies=[])
    assert result.files == 1
    assert result.time == 10
    assert result.target == (2, 7)
    assert result.dependencies == []



# Generated at 2022-06-12 04:26:42.815723
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=None,
                              tree_changed=True,
                              dependencies=['a', 'b', 'c'])
    assert tr.tree is None
    assert tr.tree_changed is True
    assert tr.dependencies == ['a', 'b', 'c']

# Generated at 2022-06-12 04:26:47.483532
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    class DummyModule(ast.AST):
        _fields = []

    dummy = DummyModule()

    t = TransformationResult(tree=dummy,
                             tree_changed=True,
                             dependencies=['a', 'b'])

    assert t.tree is dummy
    assert t.tree_changed
    assert t.dependencies == ['a', 'b']

# Generated at 2022-06-12 04:26:51.298078
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('foo.py')
    o = Path('foo_out.py')
    io = InputOutput(input = i, output = o)
    assert io.input == i and io.output == o


# Generated at 2022-06-12 04:26:54.427683
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """
    >>> InputOutput(Path(), Path())
    InputOutput(input=PosixPath('.'), output=PosixPath('.'))
    """



# Generated at 2022-06-12 04:26:58.037492
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(10, 12.3, (3, 5), [])
    assert result.files == 10
    assert result.time == 12.3
    assert result.target == (3, 5)
    assert result.dependencies == []

# Generated at 2022-06-12 04:27:01.066629
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path = '/some/path'
    io = InputOutput(path, path)
    assert io.input == path
    assert io.output == path
    assert io.input == io.output



# Generated at 2022-06-12 04:27:04.116753
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilationResult = CompilationResult(files=1, time=1, target=(1, 1), dependencies=['test'])
    assert isinstance(compilationResult, CompilationResult)


# Generated at 2022-06-12 04:27:07.800624
# Unit test for constructor of class InputOutput
def test_InputOutput():
    obj = InputOutput(Path('foo'), Path('bar'))
    assert isinstance(obj.input, Path)
    assert isinstance(obj.output, Path)



# Generated at 2022-06-12 04:27:10.482390
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i_o = InputOutput(Path('input'), Path('output'))
    assert i_o.input == Path('input')
    assert i_o.output == Path('output')

# Generated at 2022-06-12 04:27:13.068334
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=3,
                      time=2.0,
                      target=(3, 6),
                      dependencies=['sources/a.py', 'sources/b.py'])

# Generated at 2022-06-12 04:27:17.339184
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2.0, (3, 4), ['a', 'b'])


# Generated at 2022-06-12 04:27:21.714847
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse('2+3'),
                                False,
                                None) == \
               TransformationResult(ast.parse('2+3'),
                                    False,
                                    None)
    assert TransformationResult(ast.parse('2+3'),
                                False,
                                    []).dependencies == []

# Generated at 2022-06-12 04:27:23.405736
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(5, 130.5, (3, 6), ['lib1.py', 'lib2.py'])


# Generated at 2022-06-12 04:27:25.349918
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('input.py')
    out = Path('output.py')
    pair = InputOutput(inp, out)
    assert pair.input == inp
    assert pair.output == out



# Generated at 2022-06-12 04:27:26.338551
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("1")
    TransformationResult(ast, False)

# Generated at 2022-06-12 04:27:29.759851
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    tree = ast.parse('print(1)')
    trans_res = TransformationResult(tree, True, [])
    assert trans_res.tree == tree
    assert trans_res.tree_changed
    assert trans_res.dependencies == []

# Generated at 2022-06-12 04:27:33.215104
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(2, 3.14, (3, 5), [])
    assert r.files == 2
    assert r.time == 3.14
    assert r.target == (3, 5)
    assert r.dependencies == []


# Generated at 2022-06-12 04:27:39.290700
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1,
                                           time=1,
                                           target=(2, 7),
                                           dependencies=['stdlib/1.txt', 'stdlib/2.txt'])
    assert compilation_result.files == 1
    assert compilation_result.time == 1
    assert compilation_result.target == (2, 7)
    assert compilation_result.dependencies == ['stdlib/1.txt', 'stdlib/2.txt']


# Generated at 2022-06-12 04:27:42.671710
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result = TransformationResult(
        tree=None,
        tree_changed=False,
        dependencies=[]
    )
    assert transformation_result.tree is None
    assert transformation_result.tree_changed is False
    assert transformation_result.dependencies == []

# Generated at 2022-06-12 04:27:46.954955
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(ast.Module(), True, [])
    assert result.tree_changed
    assert [] == result.dependencies
    assert ast.Module() == result.tree

# Information about file
FileInfo = NamedTuple('FileInfo', [('source', Path),
                                   ('bytecode', Path),
                                   ('dependencies', List[Path])])

# Generated at 2022-06-12 04:27:55.387614
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    trans_result = TransformationResult(ast.parse('pass'),
                                        True,
                                        [])  # type: TransformationResult

    assert trans_result.tree is not None
    assert trans_result.tree_changed
    assert trans_result.dependencies == []

# Generated at 2022-06-12 04:27:59.655010
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(
        ast.parse('a = 1'), True, ['b'])


# Result of compilation
Compilation = NamedTuple('Compilation',
                         [('compilation', CompilationResult),
                          ('signatures', TransformationResult),
                          ('annotations', TransformationResult),
                          ('rewrite', TransformationResult)])


# Generated at 2022-06-12 04:28:03.219163
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=2, time=1.2, target=(2, 3), dependencies=[])
    assert res.files == 2
    assert res.time == 1.2
    assert res.target == (2, 3)
    assert res.dependencies == []


# Generated at 2022-06-12 04:28:05.380963
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/home/test')
    output = Path('/tmp/ast')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output

# Generated at 2022-06-12 04:28:13.431702
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Type checking
    TransformationResult(tree=ast.parse('1'),
                         tree_changed=True,
                         dependencies=['a.py'])
    # pylint: disable=unused-variable
    with pytest.raises(TypeError):
        TransformationResult(tree=1, tree_changed=True, dependencies=['a.py'])
    with pytest.raises(TypeError):
        TransformationResult(tree=ast.parse('1'), tree_changed=1,
                             dependencies=['a.py'])
    with pytest.raises(TypeError):
        TransformationResult(tree=ast.parse('1'), tree_changed=True,
                             dependencies=1)

# Generated at 2022-06-12 04:28:17.445199
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(1,
                                           1.0,
                                           (3, 5),
                                           ['somefile'])
    assert compilation_result.files == 1
    assert compilation_result.time == 1.0
    assert compilation_result.target == (3, 5)
    assert compilation_result.dependencies == ['somefile']


# Generated at 2022-06-12 04:28:20.052077
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput("input.txt", "output.txt")
    assert(input_output.input == Path("input.txt"))
    assert(input_output.output == Path("output.txt"))


# Generated at 2022-06-12 04:28:23.155893
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Type check
    InputOutput(Path('in'), Path('out'))
    # Create
    io = InputOutput(Path('in'), Path('out'))
    assert io.input.name == 'in'
    assert io.output.name == 'out'


# Generated at 2022-06-12 04:28:26.384763
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Normal case
    io = InputOutput('a', 'b')
    assert io.input == Path('a')
    assert io.output == Path('b')

    # Paths are not strings
    with pytest.raises(AssertionError):
        InputOutput(1, 2)

# Generated at 2022-06-12 04:28:29.668553
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=[])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 6)
    assert result.dependencies == []


# Generated at 2022-06-12 04:28:45.910089
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=ast.Name, tree_changed=True,
                              dependencies=['foo.py'])
    assert tr == TransformationResult(tree=ast.Name, tree_changed=True,
                                      dependencies=['foo.py'])
    assert tr != TransformationResult(tree=ast.Name, tree_changed=False,
                                      dependencies=['foo.py'])
    assert tr != TransformationResult(tree=ast.Name, tree_changed=False,
                                      dependencies=['bar.py'])

# Generated at 2022-06-12 04:28:49.498306
# Unit test for constructor of class InputOutput
def test_InputOutput():
    if1: Path = Path('input_file.py')
    of1: Path = Path('output_file.py')

    i1: InputOutput = InputOutput(if1, of1)

    assert i1.input == if1
    assert i1.output == of1


# Generated at 2022-06-12 04:28:52.696303
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('input.py')
    output_path = Path('output.py')
    input_output = InputOutput(input=input_path, output=output_path)

    assert input_output.input == input_path
    assert input_output.output == output_path

# Generated at 2022-06-12 04:28:54.943628
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(input=Path('a.py'), output=Path('a.out'))
    assert isinstance(input_output, InputOutput)



# Generated at 2022-06-12 04:28:58.552387
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1,
                               target=(3, 5), dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 1
    assert result.target == (3, 5)
    assert result.dependencies == ['a', 'b']



# Generated at 2022-06-12 04:29:02.155430
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=2.0,
                               target=(3, 4),
                               dependencies=['test'])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == ['test']


# Generated at 2022-06-12 04:29:06.252978
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    """
    Test constructor of CompilationResult class.
    """

    checker = CompilationResult(files=3,
                                time=5.5,
                                target=(3, 4),
                                dependencies=['a', 'b', 'c'])
    assert checker.files == 3
    assert checker.time == 5.5
    assert checker.target == (3, 4)
    assert checker.dependencies == ['a', 'b', 'c']


# Generated at 2022-06-12 04:29:10.265956
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=2,
                               target=(3, 4),
                               dependencies=['a'])
    assert (result.files == 1)
    assert (result.time == 2)
    assert (result.target == (3, 4))
    assert (result.dependencies == ['a'])


# Generated at 2022-06-12 04:29:12.089297
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # noinspection PyTypeChecker
    assert InputOutput(input=Path('test'), output=Path('test2')) is not None

# Generated at 2022-06-12 04:29:14.613253
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = Path('a')
    b = Path('b')

    i = InputOutput(a, b)

    assert i.input == a
    assert i.output == b


# Generated at 2022-06-12 04:29:39.285388
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    """
    Tests the constructor of class TransformationResult.
    """
    ast_module = ast.parse("1 + 1")
    ast_module.body[0].value.left.n = 2
    TransformationResult(ast_module, True, [])
    TransformationResult(ast_module, False, [])

# Generated at 2022-06-12 04:29:43.000449
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1,
                                           time=1.1,
                                           target=(3, 4),
                                           dependencies=[])
    assert compilation_result.files == 1
    assert compilation_result.time == 1.1
    assert compilation_result.target == (3, 4)
    assert compilation_result.dependencies == []



# Generated at 2022-06-12 04:29:44.291892
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2, (3, 4), ['a', 'b'])


# Generated at 2022-06-12 04:29:47.059190
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # pylint: disable=C0103
    assert InputOutput(Path('a'), Path('b')) == InputOutput(input=Path('a'),
                                                            output=Path('b'))


# Generated at 2022-06-12 04:29:49.658964
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path("path1")
    path2 = Path("path2")
    input_output = InputOutput(path1, path2)
    assert input_output.input == path1
    assert input_output.output == path2


# Generated at 2022-06-12 04:29:51.066918
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    output = TransformationResult(tree=None, tree_changed=False,
                                  dependencies=[])



# Generated at 2022-06-12 04:29:55.588675
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_node = ast.parse('pass')
    tree_changed = True
    dependencies = ['']
    x = TransformationResult(ast_node, tree_changed, dependencies)
    assert isinstance(x.tree, ast.AST)
    assert x.tree_changed == tree_changed
    assert isinstance(x.dependencies, list)
    assert all(isinstance(depend, str) for depend in x.dependencies)



# Generated at 2022-06-12 04:30:01.798603
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    test_result = TransformationResult(tree, True, ['test'])
    assert test_result.tree == tree
    assert test_result.tree_changed == True
    assert test_result.dependencies == ['test']


# Generated at 2022-06-12 04:30:03.934655
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('foo'), Path('bar')) == \
        InputOutput(input=Path('foo'), output=Path('bar'))


# Generated at 2022-06-12 04:30:09.000310
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Just instantiate
    result = CompilationResult(files = 1,
                               time = 0.5,
                               target = (3, 7),
                               dependencies = ['a.py'])

    # Check that fields are correct
    assert result.files == 1
    assert result.time == 0.5
    assert result.target == (3, 7)
    assert result.dependencies == ['a.py']

    # Check that we can't set fields
    with pytest.raises(AttributeError):
        result.files = 2

    # But we can override them in constructor
    result2 = result._replace(files = 2)

    # Check that override has been done
    assert result2.files == 2
    assert result2.time == 0.5
    assert result2.target == (3, 7)
    assert result2.depend

# Generated at 2022-06-12 04:31:03.507032
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Test values creation
    input_arg = Path('input')
    output_arg = Path('output')
    # Create instance
    io = InputOutput(input_arg, output_arg)
    # Test
    assert io.input == input_arg
    assert io.output == output_arg
    # Test repr
    assert repr(io) == 'InputOutput(input=%r, output=%r)' % (input_arg, output_arg)


# Generated at 2022-06-12 04:31:06.781844
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 1.0, (3, 0), ['f1'])
    CompilationResult(2, 2.0, (3, 1), ['f1', 'f2'])
    CompilationResult(3, 3.0, (3, 2), ['f1', 'f2', 'f3'])


# Generated at 2022-06-12 04:31:09.097752
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = 'input.txt'
    out = 'output.txt'

    input_output = InputOutput(inp, out)

    assert input_output.input == inp
    assert input_output.output == out



# Generated at 2022-06-12 04:31:16.551271
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from typed_ast.ast3 import FunctionDef
    from typing import List

    tr1 = TransformationResult(FunctionDef(name='f',
                                           args=ast.arguments(args=[],
                                                              vararg=None,
                                                              kwonlyargs=[],
                                                              kw_defaults=[],
                                                              kwarg=None,
                                                              defaults=[]),
                                           body=[],
                                           decorator_list=[],
                                           returns=None),
                              True,
                              [])
    assert tr1.tree.name == 'f'
    assert tr1.tree_changed
    assert isinstance(tr1.dependencies, List) and len(tr1.dependencies) == 0


# Generated at 2022-06-12 04:31:19.468865
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=1, time=1.0, target=(3, 5), dependencies=[])
    assert res.files == 1
    assert res.time == 1.0
    assert res.target == (3, 5)


# Generated at 2022-06-12 04:31:21.935582
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(input=Path('input.py'),
                               output=Path('output.py'))
    assert input_output.input == Path('input.py')
    assert input_output.output == Path('output.py')


# Generated at 2022-06-12 04:31:23.167203
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2.0, (3, 4), ['file1', 'file2'])


# Generated at 2022-06-12 04:31:29.216683
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # No argument
    try:
        InputOutput()
        assert False
    except TypeError:
        assert True

    # Regular usage
    try:
        res = InputOutput(Path("/tmp/foo.py"), Path("/tmp/bar.py"))
        assert res.input == Path("/tmp/foo.py")
        assert res.output == Path("/tmp/bar.py")
    except:
        assert False

    # Argument number
    try:
        InputOutput(Path("/tmp/foo.py"), Path("/tmp/bar.py"), Path("/tmp/baz.py"))
        assert False
    except TypeError:
        assert True

    # Argument types
    try:
        InputOutput("/tmp/foo.py", "/tmp/bar.py")
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-12 04:31:33.125808
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    dummy_t = ast.Module()
    dummy_d = ['dep']
    res = TransformationResult(dummy_t, True, dummy_d)
    assert res.tree is dummy_t
    assert res.tree_changed is True
    assert res.dependencies is dummy_d

# Generated at 2022-06-12 04:31:35.897231
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('in')
    o = Path('out')
    assert InputOutput(i, o).input is i
    assert InputOutput(i, o) == InputOutput(i, o)
    assert InputOutput(i, o) != InputOutput(o, i)



# Generated at 2022-06-12 04:33:25.940886
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=0, time=0.0,
                             target=(3, 6), dependencies=[])


# Generated at 2022-06-12 04:33:26.806503
# Unit test for constructor of class CompilationResult

# Generated at 2022-06-12 04:33:30.487198
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # pylint: disable=invalid-name
    r = TransformationResult(tree=None, tree_changed=False, dependencies=None)
    assert isinstance(r, TransformationResult)
    assert isinstance(r.tree, ast.AST)
    assert isinstance(r.tree_changed, bool)
    assert isinstance(r.dependencies, List)

# Generated at 2022-06-12 04:33:34.074781
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('foo.py')
    output = Path('bar.py')
    io = InputOutput(input=input, output=output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-12 04:33:36.512752
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=0,
                               time=42.0,
                               target=(3, 7),
                               dependencies=[])
    assert result.files == 0
    assert result.time == 42.0
    assert result.target == (3, 7)
    assert result.dependencies == []



# Generated at 2022-06-12 04:33:38.464571
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(0, 0.0, (2, 7), [])
    CompilationResult(0, 0.0, (3, 6), [])


# Generated at 2022-06-12 04:33:42.928936
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path(__file__)
    path2 = Path(__file__ + '.swp')
    io = InputOutput(path1, path2)
    assert io.input == path1
    assert io.output == path2
    assert io.input != io.output
    new_io = InputOutput(io.output, io.input)
    assert new_io.input == io.output
    assert new_io.output == io.input

# Generated at 2022-06-12 04:33:46.267344
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    dependencies = ['pass']
    t = TransformationResult(tree, True, dependencies)
    assert t.tree is tree
    assert t.tree_changed is True
    assert t.dependencies == dependencies
    assert t

# Generated at 2022-06-12 04:33:49.726426
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    import time
    result = CompilationResult(1, time.time(), (3, 5), [])
    assert type(result.files) is int
    assert type(result.time) is float
    assert type(result.target) is CompilationTarget
    assert type(result.dependencies) is list


# Generated at 2022-06-12 04:33:53.028425
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(10, 0.0, (3, 6), [])
    assert res.files == 10
    assert res.time == 0.0
    assert res.target == (3, 6)
    assert res.dependencies == []

