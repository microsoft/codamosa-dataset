

# Generated at 2022-06-12 04:25:16.011178
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(5, 0.5, (3, 4), [])
    assert cr.files == 5
    assert cr.time == 0.5
    assert cr.target == (3, 4)
    assert cr.dependencies == []


# Generated at 2022-06-12 04:25:18.026505
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=ast.parse('a'), tree_changed=True, dependencies=['a', 'b'])
    assert tr.tree_changed == True
    assert tr.dependencies == ['a', 'b']

# Generated at 2022-06-12 04:25:21.450489
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path("foo1"), Path("bar1")).input == Path("foo1")
    assert InputOutput(Path("foo1"), Path("bar1")).output == Path("bar1")

    # Check that Path is only acceptable argument
    with pytest.raises(ValueError):
        InputOutput("foo2", "bar2")


# Generated at 2022-06-12 04:25:22.536439
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(input='a', output='b')


# Generated at 2022-06-12 04:25:26.881651
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=3,
                           time=15.3,
                           target=(3, 6),
                           dependencies=['abc', 'def'])
    assert cr.files == 3
    assert cr.time == 15.3
    assert cr.target == (3, 6)
    assert cr.dependencies == ['abc', 'def']


# Generated at 2022-06-12 04:25:28.990545
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=0, time=0.0, target=(3,7),
                      dependencies=[])


# Generated at 2022-06-12 04:25:33.928055
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.AST(),
                                False,
                                []) == TransformationResult.__new__(TransformationResult,
                                                                    ast.AST(),
                                                                    False,
                                                                    [])

# Input/output/changed pair
InputOutputChanged = NamedTuple('InputOutputChanged',
                                [('input', Path),
                                 ('output', Path),
                                 ('changed', bool)])

# Generated at 2022-06-12 04:25:37.379507
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    out = CompilationResult(files=1, time=0.1, target=(3, 6), dependencies=['.'])
    assert out.files == 1
    assert out.time == 0.1
    assert out.target == (3, 6)
    assert out.dependencies == ['.']


# Generated at 2022-06-12 04:25:41.111257
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.Module()
    TransformationResult(tree=tree,
                         tree_changed=False,
                         dependencies=[])

# Result of transformers transformation
TryToCompileResult = NamedTuple('TryToCompileResult',
                                [('compile_attempted', bool),
                                 ('compilation', CompilationResult)])


# Generated at 2022-06-12 04:25:47.473091
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=0.5,
                           target=(3, 7), dependencies=["foo"])
    assert cr.files == 1, "files was not set"
    assert cr.time == 0.5, "time was not set"
    assert cr.target == (3, 7), "target was not set"
    assert cr.dependencies == ["foo"], "dependencies was not set"



# Generated at 2022-06-12 04:25:58.086804
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test_target = Path('/tmp') / 'test_target.py'

    assert TransformationResult(None, None, None).tree is None
    assert TransformationResult(None, None, None).tree_changed is None
    assert TransformationResult(None, None, None).dependencies is None

    assert TransformationResult(test_target, True, []).tree == test_target
    assert TransformationResult(test_target, False, []).tree == test_target
    assert TransformationResult(test_target, True, []).tree_changed is True
    assert TransformationResult(test_target, False, []).tree_changed is False
    assert TransformationResult(test_target, True, []).dependencies == []
    assert TransformationResult(test_target, False, []).dependencies == []

# Generated at 2022-06-12 04:25:59.827401
# Unit test for constructor of class TransformationResult
def test_TransformationResult():

    # Nothing to do
    TransformationResult(None, None, None)

# This is used to verify that the transformers module contains at least one
# function named transformer_test

# Generated at 2022-06-12 04:26:04.159884
# Unit test for constructor of class InputOutput
def test_InputOutput():
    example_input = Path('foo/bar/baz.py')
    example_output = Path('foo/bar/baz.pyc')
    pair = InputOutput(example_input, example_output)
    assert pair.input == example_input
    assert pair.output == example_output


# Generated at 2022-06-12 04:26:08.079798
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path("test.py")
    o = Path("test.pyc")
    test_io = InputOutput(i, o)

    assert(test_io.input == i)
    assert(test_io.output == o)


# Generated at 2022-06-12 04:26:10.069676
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('input = 0')
    assert TransformationResult(tree, False, [])
    assert TransformationResult(tree, True, [])

# Generated at 2022-06-12 04:26:12.922343
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(
        ast.parse('a + b', '<str>', 'eval'), True, ['foo.py'])
    assert result.tree_changed
    assert result.tree
    assert result.dependencies == ['foo.py']

# Generated at 2022-06-12 04:26:15.255803
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=0, target=(3, 6),
                      dependencies=['a', 'b'])


# Generated at 2022-06-12 04:26:19.550646
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 100
    time = 1.0
    target = (3, 6)
    dependencies = ['foo.py']
    res = CompilationResult(files, time, target, dependencies)
    assert res.files == files
    assert res.time == time
    assert res.target == target
    assert res.dependencies == dependencies


# Generated at 2022-06-12 04:26:20.972317
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # for test coverage
    TransformationResult(tree=None, tree_changed=False, dependencies=[])

# Generated at 2022-06-12 04:26:22.805242
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path = Path.cwd()
    input_output = InputOutput(input=path, output=path)
    assert input_output.input == input_output.output


# Generated at 2022-06-12 04:26:26.271886
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput('input', 'output')



# Generated at 2022-06-12 04:26:31.815314
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(
        files=1,
        time=1.0,
        target=(3, 8),
        dependencies=['foo'])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target[0] == 3
    assert result.target[1] == 8
    assert result.dependencies == ['foo']


# Generated at 2022-06-12 04:26:33.234825
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(input=Path('some_input.py'), output=Path('some_output.py'))

# Generated at 2022-06-12 04:26:34.359350
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input=Path(),
                       output=Path())


# Generated at 2022-06-12 04:26:39.284525
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cpl = CompilationResult(4, 0.4, (3, 7), ['dependency1', 'dependency2'])
    assert cpl.files == 4
    assert cpl.time == 0.4
    assert cpl.target == (3, 7)
    assert cpl.dependencies == ['dependency1', 'dependency2']


# Generated at 2022-06-12 04:26:42.539029
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(
        files=1,
        time=2.1,
        target=(3, 4),
        dependencies=['foo', 'bar'])


# Generated at 2022-06-12 04:26:47.000961
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(10, 5.5, (3, 8), ['math', 'os', 'sys'])
    assert res.files == 10
    assert res.time == 5.5
    assert res.target == (3, 8)
    assert res.dependencies == ['math', 'os', 'sys']


# Generated at 2022-06-12 04:26:51.512272
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # type: () -> None
    """Unit test for constructor of class InputOutput"""
    input = Path('input.py')
    output = Path('output.py')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-12 04:26:59.273730
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(1, 2.0, (3, 4), ['foo', 'bar'])
    assert c.files == 1
    assert c.time == 2.0
    assert c.target == (3, 4)
    assert c.dependencies == ['foo', 'bar']
    assert c.dependencies != ['bar', 'foo']
    assert repr(c) == "CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=['foo', 'bar'])"


# Generated at 2022-06-12 04:27:03.293194
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('/home/me/meme.md')
    output = Path('/home/me/meme.html')
    io = InputOutput(input_, output)
    assert io.input == input_
    assert io.output == output


# Generated at 2022-06-12 04:27:10.443046
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('input'), Path('output'))
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')

# Generated at 2022-06-12 04:27:12.370564
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=0, time=0, target=(2,7), deps=[])


# Generated at 2022-06-12 04:27:14.765813
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('/tmp/i')
    output = Path('/tmp/o')
    io = InputOutput(input_, output)
    assert io.input == input_
    assert io.output == output

# Generated at 2022-06-12 04:27:19.148317
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(1, 2, (3, 4), ['5', '6'])
    c.files == 1
    c.time == 2
    c.target == (3, 4)
    c.dependencies == ['5', '6']


# Generated at 2022-06-12 04:27:27.316050
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    imports = ['sys', 'os', 'shutil']
    target = (3, 5)
    import time
    assert CompilationResult(files=99, time=1.234, target=target,
                             dependencies=imports) == \
        CompilationResult(files=99, time=1.234, target=target,
                          dependencies=imports)
    off_time = time.time() - 2
    assert CompilationResult(files=99, time=off_time, target=target,
                             dependencies=imports) != \
        CompilationResult(files=99, time=off_time, target=target,
                          dependencies=imports)

# Generated at 2022-06-12 04:27:30.666502
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(0, 0.0, (3, 5), []) == CompilationResult(files=0,
                                                                      time=0.0,
                                                                      target=(3,5),
                                                                      dependencies=[])


# Generated at 2022-06-12 04:27:40.127265
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    from functools import reduce
    from operator import add
    from itertools import chain
    from time import time

    files = 10
    time_elapsed_input = 0.5
    time_elapsed_output = 0.5
    target_input = (3, 6)
    target_output = (3, 6)
    dependencies_input = ['a', 'b']
    dependencies_output = ['a', 'b']

    r = CompilationResult(files, time_elapsed_input, target_input, dependencies_input)
    assert r.files == files
    assert r.time == time_elapsed_input + time_elapsed_output
    assert r.target == target_output

# Generated at 2022-06-12 04:27:45.326938
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(tree=None, tree_changed=False, dependencies=[])
    assert result.tree is None
    assert not result.tree_changed
    assert result.dependencies == []

# Result of transformers backtransformation
BacktransformationResult = NamedTuple('BacktransformationResult',
                                      [('tree', ast.AST),
                                       ('tree_changed', bool),
                                       ('dependencies', List[str])])


# Generated at 2022-06-12 04:27:48.836853
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('print(1)', '<input>', 'exec')
    r = TransformationResult(tree, True, [])
    assert isinstance(r, TransformationResult)
    assert r.tree is tree
    assert r.tree_changed is True
    assert not r.dependencies

# Generated at 2022-06-12 04:27:52.958739
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input="foo", output="bar") == InputOutput(input="foo", output="bar")
    assert not InputOutput(input="foo", output="bar") == InputOutput(input="foo", output="xxx")
    assert not InputOutput(input="foo", output="bar") == InputOutput(input="xxx", output="bar")

# Generated at 2022-06-12 04:28:05.839116
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 20
    time = 200.0
    target = (3, 6)
    dependencies = ['a', 'b', 'c']
    cr = CompilationResult(files, time, target, dependencies)
    assert cr.files == files
    assert cr.time == time
    assert cr.target == target
    assert cr.dependencies == dependencies


# Generated at 2022-06-12 04:28:10.234730
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("pass")
    result = TransformationResult(tree=tree,
                                  tree_changed=True,
                                  dependencies=["a", "b"])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == ["a", "b"]

# Generated at 2022-06-12 04:28:14.604303
# Unit test for constructor of class InputOutput
def test_InputOutput():
    files_dir = Path('test_files')
    file_tuple = InputOutput(Path(files_dir, 'input.py'),
                             Path(files_dir, 'input_backwarded.py'))
    assert file_tuple.input == Path(files_dir, 'input.py')
    assert file_tuple.output == Path(files_dir, 'input_backwarded.py')


# Generated at 2022-06-12 04:28:19.246630
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # type: () -> None
    cr = CompilationResult(files=13, time=0.333, target=(3, 7),
                           dependencies=['foo.py', 'bar.py'])
    assert cr.files == 13
    assert cr.time == 0.333
    assert cr.target == (3, 7)
    assert cr.dependencies == ['foo.py', 'bar.py']


# Generated at 2022-06-12 04:28:20.350775
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.AST(), True, ["a", "b"])

# Generated at 2022-06-12 04:28:24.066437
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    comp_res = CompilationResult(files=1, time=1.0,
                                 target=(3,6),
                                 dependencies=[])
    assert comp_res.files == 1
    assert comp_res.time == 1.0
    assert comp_res.target == (3,6)
    assert comp_res.dependencies == []


# Generated at 2022-06-12 04:28:27.400686
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 2.0, (3, 4), [])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == []


# Generated at 2022-06-12 04:28:30.006754
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    i = InputOutput(input, output)
    assert i.input == input
    assert i.output == output



# Generated at 2022-06-12 04:28:33.045751
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    tree_changed = True
    dependencies = []
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-12 04:28:36.929049
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # test with strings
    assert InputOutput('input', 'output') \
           == InputOutput(input=Path('input'), output=Path('output'))

    # test with paths
    assert InputOutput(Path('input'), Path('output')) \
           == InputOutput(input=Path('input'), output=Path('output'))


# Generated at 2022-06-12 04:28:59.381773
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = InputOutput(input=Path('foo'), output=Path('bar'))
    assert i.input == Path('foo')
    assert i.output == Path('bar')

# Generated at 2022-06-12 04:29:03.039569
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(42, 1337.0, (2, 7), ['dep1', 'dep2'])
    assert result.files == 42
    assert result.time == 1337.0
    assert result.target == (2, 7)
    assert result.dependencies == ['dep1', 'dep2']


# Generated at 2022-06-12 04:29:04.394834
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('print()')
    TransformationResult(tree, True, ['file1'])

# Generated at 2022-06-12 04:29:06.886907
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(files=1, time=1.0, target=(3, 7), dependencies=[])
    assert r.files == 1
    assert r.time == 1.0
    assert r.target == (3, 7)


# Generated at 2022-06-12 04:29:09.994245
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/path/to/input.py')
    output = Path('/path/to/output.py')

    pair = InputOutput(input=input, output=output)
    assert pair.input == input
    assert pair.output == output



# Generated at 2022-06-12 04:29:13.521532
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    r = TransformationResult(tree=1, tree_changed=True, dependencies=['a'])
    assert r.tree == 1
    assert r.tree_changed == True
    assert r.dependencies == ['a']


if __name__ == '__main__':
    test_TransformationResult()

# Generated at 2022-06-12 04:29:17.115195
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=0, time=0.0,
                               target=(3, 6), dependencies=[])
    assert result.files == 0
    assert result.time == 0.0
    assert result.target == (3, 6)
    assert result.dependencies == []


# Generated at 2022-06-12 04:29:19.418205
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(None, False, [])
    assert result.tree is None
    assert not result.tree_changed
    assert len(result.dependencies) == 0

# Generated at 2022-06-12 04:29:23.521890
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Just create an instance of InputOutput
    input_output = InputOutput(input=Path('input'), output=Path('output'))
    # And check its values
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')


# Generated at 2022-06-12 04:29:26.232085
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input.txt')
    output = Path('output.txt')
    input_output = InputOutput(input, output)

    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-12 04:30:16.787809
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.Str('Test')
    TransformationResult(t, True, ['test_dependency.py'])

# Generated at 2022-06-12 04:30:20.351308
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.Expr(None), False, [])


# Result of writing bytecode to file
WriteByteCodeResult = NamedTuple('WriteByteCodeResult',
                                 [('source_size', int),
                                  ('bytecode_size', int),
                                  ('time', float)])

# Generated at 2022-06-12 04:30:23.690872
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = 'test.py'
    output = 'test.pyc'
    assert InputOutput(input, output) == InputOutput(Path(input), Path(output))

# Generated at 2022-06-12 04:30:27.696553
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('foo')
    output_path = Path('bar')
    input_output = InputOutput(input_path, output_path)
    assert input_output.input == input_path  # pylint: disable=no-member
    assert input_output.output == output_path  # pylint: disable=no-member

# Generated at 2022-06-12 04:30:33.905680
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    target_tree = ast.parse('x = 0', mode='eval')
    tree_changed = True
    dependencies = []
    res = TransformationResult(target_tree, tree_changed, dependencies)
    assert type(res.tree) is ast.Expression
    assert res.tree_changed is True
    assert res.dependencies == []

# Result of test_transformer
TestResult = NamedTuple('TestResult', [('result', CompilationResult),
                                       ('input', Path),
                                       ('output', Path)])


# Generated at 2022-06-12 04:30:34.923111
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(None, True, [])

# Generated at 2022-06-12 04:30:38.965720
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=10, time=123.456, target=(3, 4), dependencies=["foo", "bar"])
    assert result.files == 10
    assert result.time == 123.456
    assert result.target == (3, 4)
    assert result.dependencies == ["foo", "bar"]


# Generated at 2022-06-12 04:30:41.782775
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(input='/tmp/a', output='/tmp/b')
    assert io.input == Path('/tmp/a')
    assert io.output == Path('/tmp/b')

# Generated at 2022-06-12 04:30:44.910239
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(1, 1.0, (3, 5), ['a'])
    assert res.files == 1
    assert res.time == 1.0
    assert res.target == (3, 5)
    assert res.dependencies == ['a']


# Generated at 2022-06-12 04:30:46.609321
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('in'), Path('out')) == \
        InputOutput(input=Path('in'), output=Path('out'))

# Generated at 2022-06-12 04:32:37.961604
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path(__file__)
    output = Path('/tmp/file.out')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output

# Generated at 2022-06-12 04:32:43.590936
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Create object
    obj = CompilationResult(files=1, time=1.1, target=(3, 7),
                            dependencies=[])
    # Test repr
    assert repr(obj) == "CompilationResult(files=1, time=1.1, target=(3, 7), dependencies=[])"
    # Test str
    assert str(obj) == "Files: 1, Time: 1.1, Target: (3, 7), Dependencies: []"


# Generated at 2022-06-12 04:32:44.582618
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 1, (3, 5), [])


# Generated at 2022-06-12 04:32:47.435886
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.Constant(value=0)
    result = TransformationResult(tree=tree, tree_changed=True,
                                  dependencies=['mylib'])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == ['mylib']

# Generated at 2022-06-12 04:32:50.015054
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.4, target=(3, 7), dependencies=['foo'])
    assert result.files == 1
    assert result.time == 0.4
    assert result.target == (3, 7)
    assert result.dependencies == ['foo']


# Generated at 2022-06-12 04:32:53.551673
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=ast.parse('x'),
                              tree_changed=False,
                              dependencies=['a', 'b', 'c'])
    assert tr.tree is not None
    assert tr.tree_changed is False
    assert tr.dependencies == ['a', 'b', 'c']

# Generated at 2022-06-12 04:32:57.555197
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # import module under test
    from auto_py_to_exe.transformation_result import TransformationResult

    # create instance
    tr = TransformationResult(tree=None, tree_changed=None, dependencies=None)

    # test
    assert tr.tree is None
    assert tr.tree_changed is None
    assert tr.dependencies is None

# Generated at 2022-06-12 04:32:58.773899
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(Path('a'), Path('b'))



# Generated at 2022-06-12 04:33:03.086866
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(1, 1, (3, 7), ['foo'])
    eq_(r.files, 1)
    eq_(r.time, 1)
    eq_(r.target, (3, 7))
    eq_(r.dependencies, ['foo'])


# Generated at 2022-06-12 04:33:07.645248
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = "string"
    tree_changed = True
    dependencies = ["test_dependencies.py", "test.py"]
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == dependencies

# Generated at 2022-06-12 04:35:06.832661
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=None, tree_changed=False, dependencies=[])

# Generated at 2022-06-12 04:35:09.658280
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(123, 456.789, (3, 6), ['spam'])
    assert res.files == 123
    assert res.time == 456.789
    assert res.target == (3, 6)
    assert res.dependencies == ['spam']


# Generated at 2022-06-12 04:35:10.600928
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(input=Path('input'), output=Path('output'))


# Generated at 2022-06-12 04:35:12.086840
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.AST('ast'), False, [])
    assert tr.tree
    assert tr.tree_changed == False
    assert tr.dependencies
