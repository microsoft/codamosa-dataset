

# Generated at 2022-06-12 04:25:18.969802
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(0, 0.0, (2, 7), [])
    assert result.files == 0
    assert result.time == 0.0
    assert result.target == (2, 7)
    assert result.dependencies == []


# Generated at 2022-06-12 04:25:21.484334
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=42, time=12.7, target=(3, 5),
                           dependencies=[])
    assert cr.files == 42
    assert cr.time == 12.7
    assert cr.target == (3, 5)
    assert cr.dependencies == []

# Generated at 2022-06-12 04:25:23.962705
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    r = TransformationResult(ast.parse('pass'), True, [])
    assert isinstance(r.tree, ast.AST)
    assert r.tree_changed is True
    assert isinstance(r.dependencies, list)

# Generated at 2022-06-12 04:25:25.454100
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('./in'), Path('./out'))


# Generated at 2022-06-12 04:25:30.878878
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # noinspection PyTypeChecker
    InputOutput(input='a', output='b') # type: ignore
    # noinspection PyTypeChecker
    InputOutput(input=Path('a'), output='b') # type: ignore
    # noinspection PyTypeChecker
    InputOutput(input='a', output=Path('b')) # type: ignore
    InputOutput(input=Path('a'), output=Path('b'))


# Generated at 2022-06-12 04:25:33.623430
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    f = ast.parse("s = 'abc'\nprint(s)").body[0]
    assert TransformationResult(f, True, []) == \
        TransformationResult(f, True, [])

# Generated at 2022-06-12 04:25:37.739102
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    import ast

    class A(object):
        def __init__(self, a, b, c):
            self.a = a # type: int
            self.b = b # type: str
            self.c = c # type: ast.AST

    aaa = A(1, 'foo', ast.Name())
    assert aaa.b == 'foo'

# Generated at 2022-06-12 04:25:40.185229
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('file1')
    out = Path('file2')
    assert InputOutput(inp, out).input == inp
    assert InputOutput(inp, out).output == out

# Generated at 2022-06-12 04:25:42.968226
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Valid input/output pair
    io = InputOutput(Path('foo/bar'), Path('baz/qux'))
    assert io.input == Path('foo/bar')
    assert io.output == Path('baz/qux')

# Generated at 2022-06-12 04:25:44.120643
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(Path('input.txt'), Path('output.txt'))


# Generated at 2022-06-12 04:25:51.191110
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=0,
                               time=0.0,
                               target=(3, 6),
                               dependencies=[])
    assert result.files == 0
    assert result.time == 0.0
    assert result.target == (3, 6)
    assert result.dependencies == []


# Generated at 2022-06-12 04:25:54.354556
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """test_InputOutput"""
    IO = InputOutput(input=Path("input"), output=Path("output"))
    assert (IO.input.name == "input")
    assert (IO.output.name == "output")


# Generated at 2022-06-12 04:25:59.309842
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_target = (3, 7)
    dependencies = ['/usr/lib/python3.7/os.py']
    compilation_result = CompilationResult(files=1,
                                           time=0.0,
                                           target=compilation_target,
                                           dependencies=dependencies)
    assert compilation_result.files == 1
    assert compilation_result.time == 0.0
    assert compilation_result.target == compilation_target
    assert compilation_result.dependencies == dependencies


# Generated at 2022-06-12 04:26:01.353506
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(files=1,
                          time=1.0,
                          target=(3, 6),
                          dependencies=["foo", "bar"])


# Generated at 2022-06-12 04:26:04.078066
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0,
                      target=(3, 5), dependencies=[])



# Generated at 2022-06-12 04:26:07.313044
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = "foo"
    output = "bar"
    result = InputOutput(input, output)
    assert result.input == input
    assert result.output == output

# Generated at 2022-06-12 04:26:09.485561
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.Module(), True, [])
    assert(isinstance(tr, TransformationResult))
    assert(isinstance(tr.tree, ast.AST))
    assert(isinstance(tr.tree_changed, bool))
    assert(isinstance(tr.dependencies, list))

# Generated at 2022-06-12 04:26:13.527995
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(1, 2.0, (3, 4), ['5', '6'])
    assert c == (1, 2.0, (3, 4), ['5', '6'])
    assert c.files == 1
    assert c.time == 2.0
    assert c.target == (3, 4)
    assert c.dependencies == ['5', '6']



# Generated at 2022-06-12 04:26:16.357560
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(input=Path("foo.txt"), output=Path("bar.txt"))
    assert io.input == Path("foo.txt")
    assert io.output == Path("bar.txt")

# Generated at 2022-06-12 04:26:19.168821
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = InputOutput(Path('foo'), Path('bar'))
    b = InputOutput(Path('foo'), Path('bar'))
    assert a == b
    assert hash(a) == hash(b)



# Generated at 2022-06-12 04:26:28.159867
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = 'test/test.py'
    output = '/home/user/test/test.js'
    input_output = InputOutput(input, output)
    assert isinstance(input_output.input, Path)
    assert isinstance(input_output.output, Path)

# Generated at 2022-06-12 04:26:32.798293
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from typed_ast import ast3 as ast

    t1 = ast.parse('a = 0')
    tr = TransformationResult(tree=t1, tree_changed=True, dependencies=[])

    assert tr.tree == t1
    assert tr.tree_changed == True
    assert tr.dependencies == []

# Generated at 2022-06-12 04:26:36.377575
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('__init__.py')
    output = Path('marshmallow_dynamo.py')
    result = InputOutput(input=input, output=output)
    assert result.input == input
    assert result.output == output



# Generated at 2022-06-12 04:26:39.552595
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('input')
    output = Path('output')
    io = InputOutput(input=input_, output=output)
    assert(io.input == input_)
    assert(io.output == output)



# Generated at 2022-06-12 04:26:44.011569
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result1 = TransformationResult(ast.parse('x=1'), True, ['foo', 'bar'])
    assert result1.tree == ast.parse('x=1')
    assert result1.tree_changed == True
    assert result1.dependencies == ['foo', 'bar']

# Generated at 2022-06-12 04:26:47.922143
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    try:
        TransformationResult(1, 2, 3)
        raise RuntimeError('expected TypeError')
    except TypeError:
        pass

    tr = TransformationResult(ast.AST(lineno=1), True, [])
    assert tr.tree.lineno == 1
    assert tr.tree_changed
    assert tr.dependencies == []

# Generated at 2022-06-12 04:26:50.342865
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult()
    CompilationResult(files=1, time=2, target=(3, 4), dependencies=[])


# Generated at 2022-06-12 04:26:55.242459
# Unit test for constructor of class TransformationResult
def test_TransformationResult():    
    t = TransformationResult(tree=None, tree_changed=True, dependencies=None)
    assert isinstance(t.tree, (type(None), ast.AST))
    assert isinstance(t.tree_changed, bool)
    assert isinstance(t.dependencies, (type(None), list))

# Generated at 2022-06-12 04:26:59.135843
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_node = ast.Str("test")
    result = TransformationResult(tree=ast_node, tree_changed=True, dependencies=['foo'])
    assert result.tree is ast_node and result.tree_changed and result.dependencies[0] == 'foo'

# Generated at 2022-06-12 04:27:03.204557
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('a = 1')
    r = TransformationResult(t, True, ['test', 'bla'])
    assert r.tree is t
    assert r.tree_changed is True
    assert r.dependencies == ['test', 'bla']

# Generated at 2022-06-12 04:27:14.097672
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(None, False, [])
    assert tr.tree is None
    assert not tr.tree_changed
    assert tr.dependencies == []

# Generated at 2022-06-12 04:27:19.439716
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('/some/path/input.py')
    output_path = Path('/some/path/output.py')
    input_output = InputOutput(input_path, output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path


# Generated at 2022-06-12 04:27:21.339749
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 1.0, (3, 5), [])


# Generated at 2022-06-12 04:27:25.067173
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    a = CompilationResult(files=1, time=1.0, target=(2, 5), dependencies=[])
    assert a.files == 1
    assert a.time == 1.0
    assert a.target == (2, 5)
    assert a.dependencies == []


# Generated at 2022-06-12 04:27:27.286908
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = 'a'
    outp = 'b'
    iop = InputOutput(inp, outp)
    assert iop.input == inp
    assert iop.output == outp


# Generated at 2022-06-12 04:27:29.190415
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    Tree = ast.Name
    TreeChanged = bool
    Dependencies = List[str]
    TransformationResult(Tree, TreeChanged, Dependencies)

# Generated at 2022-06-12 04:27:33.065796
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Checking trivial case
    inp = InputOutput(Path('foo'), Path('bar'))
    assert inp.input == Path('foo')
    assert inp.output == Path('bar')

    # Checking container
    assert inp in {inp}
    assert inp in [inp]

# Generated at 2022-06-12 04:27:36.976699
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.AST(), True, ['foo.py'])

# Result of compilation of one file
CompilationUnit = NamedTuple('CompilationUnit', [('input', Path),
                                                 ('code', str),
                                                 ('time', float),
                                                 ('error', bool)])


# Generated at 2022-06-12 04:27:41.204549
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("def foo(): pass")
    tr = TransformationResult(tree, True, ["some_lib.py"])
    assert tr == ("""def foo():
    pass""", True, ["some_lib.py"])

# Generated at 2022-06-12 04:27:49.101449
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    try:
        TransformationResult(2, True, [])  # type: ignore
        assert False
    except TypeError:
        assert True

    try:
        TransformationResult(ast.parse("pass"), 1, [])  # type: ignore
        assert False
    except TypeError:
        assert True

    try:
        TransformationResult(ast.parse("pass"), True, "Some string")  # type: ignore
        assert False
    except TypeError:
        assert True

    try:
        TransformationResult(ast.parse("pass"), True, [1, 2, 3])  # type: ignore
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-12 04:28:09.384466
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/home/michal/input')
    output = Path('/home/michal/output')
    InputOutput(input, output)

# Generated at 2022-06-12 04:28:12.112105
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path("/tmp/input"), Path("/tmp/output"))
    assert input_output.input == Path("/tmp/input")
    assert input_output.output == Path("/tmp/output")


# Generated at 2022-06-12 04:28:15.836083
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    t = TransformationResult(tree=ast.parse(''),
                             tree_changed=False,
                             dependencies=[])


# Result of type checker
TypeCheckResult = NamedTuple('TypeCheckResult',
                             [('tree', ast.AST),
                              ('errors', List[TypeError])])


# Generated at 2022-06-12 04:28:20.768016
# Unit test for constructor of class InputOutput
def test_InputOutput():
    in_ = Path('foo/bar.txt')
    out_ = Path('baz/buz.txt')

    pair = InputOutput(in_, out_)

    assert isinstance(pair, InputOutput)
    assert isinstance(pair.input, Path)
    assert isinstance(pair.output, Path)
    assert pair.input.absolute() == in_.absolute()
    assert pair.output.absolute() == out_.absolute()


# Generated at 2022-06-12 04:28:27.672469
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # pylint: disable=missing-docstring
    tree = ast.parse('')
    TransformationResult(tree=tree, tree_changed=True, dependencies=[])
    TransformationResult(tree=tree, tree_changed=False, dependencies=[])
    TransformationResult(tree=tree, tree_changed=True, dependencies=None)
    TransformationResult(tree=tree, tree_changed=False, dependencies=None)
    # pylint: enable=missing-docstring

# Information about file
FileInfo = NamedTuple('FileInfo',
                      [('name', str),
                       ('last_changed', float),
                       ('last_processed', float)])

# Generated at 2022-06-12 04:28:31.677137
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a'), Path('b')).input == Path('a')
    assert InputOutput(Path('a'), Path('b')).output == Path('b')
    assert InputOutput(input='a', output='b').input == Path('a')
    assert InputOutput(input='a', output='b').output == Path('b')



# Generated at 2022-06-12 04:28:33.045053
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(0, 0.0, (0, 0), [])



# Generated at 2022-06-12 04:28:35.049898
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('foo'), Path('bar')) == InputOutput(Path('foo'), Path('bar'))


# Generated at 2022-06-12 04:28:39.723330
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(1, 1.0, (3, 6), ['foo'])
    assert(cr.files == 1)
    assert(cr.time == 1.0)
    assert(cr.target == (3, 6))
    assert(cr.dependencies == ['foo'])
    assert(str(cr) == "1 files compiled in 1.0s for python 3.6 with dependencies ['foo']")


# Generated at 2022-06-12 04:28:42.284818
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=10, time=2.5,
                             target=(3, 7), dependencies=['a', 'b'])


# Generated at 2022-06-12 04:29:26.120329
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 10.2, (2, 7), [])
    assert CompilationResult(1, 10.2, (3, 1), ['/tests/test.py'])
    assert CompilationResult(1, 10.2, (3, 2), [])

# Generated at 2022-06-12 04:29:28.828338
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-12 04:29:34.467425
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """Test constructor for InputOutput class."""
    # Check with correct inputs
    input_output = InputOutput('input.txt', 'output.txt')
    assert input_output.input == Path('input.txt')
    assert input_output.output == Path('output.txt')
    # Check with incorrect inputs
    with pytest.raises(TypeError):
        input_output = InputOutput(1, 'output.txt')
    with pytest.raises(TypeError):
        input_output = InputOutput('input.txt', 1)


# Generated at 2022-06-12 04:29:37.413921
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('/tmp/input')
    output_path = Path('/tmp/output')
    i_o = InputOutput(input_path, output_path)
    assert i_o.input == input_path
    assert i_o.output == output_path

# Generated at 2022-06-12 04:29:40.616083
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(4, 2.3, (3, 5), [])
    assert result.files == 4
    assert result.time == 2.3
    assert result.target == (3, 5)
    assert result.dependencies == []


# Generated at 2022-06-12 04:29:44.386520
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Given
    module = ast.parse("x = 1")
    dependencies = ['a.py']

    # When
    transformation_result = TransformationResult(module,
                                                  True,
                                                  dependencies)

    # Then
    assert isinstance(transformation_result.tree, ast.Module)
    assert transformation_result.tree_changed
    assert transformation_result.dependencies == dependencies

# Generated at 2022-06-12 04:29:46.155501
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(5, 6.3, (3, 5), ['a', 'b'])


# Generated at 2022-06-12 04:29:50.403253
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=10, time=12.0,
                                           target=(3, 5),
                                           dependencies=['a', 'b'])
    assert compilation_result.files == 10
    assert compilation_result.time == 12.0
    assert compilation_result.target == (3, 5)
    assert compilation_result.dependencies == ['a', 'b']


# Generated at 2022-06-12 04:29:53.610050
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    tr = TransformationResult(tree=ast.AST(), tree_changed=True,
                              dependencies=['a', 'b'])
    assert isinstance(tr.tree, ast.AST)
    assert tr.tree_changed is True
    assert isinstance(tr.dependencies, list)

# Generated at 2022-06-12 04:29:58.289087
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(ast.parse(''), False, [])
    assert isinstance(result.tree, ast.AST)
    assert isinstance(result.tree_changed, bool)
    assert isinstance(result.dependencies, List)

# Generated at 2022-06-12 04:31:49.805908
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    a = ast.parse('x = 1')
    assert TransformationResult(a, False, []) == TransformationResult(a, False, [])

assert TransformationResult(ast.parse('x = 1'), False, []) == TransformationResult(ast.parse('x = 1'), False, [])

# Generated at 2022-06-12 04:31:53.936153
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    dummy_target = (3, 10)
    dummy_deps = ['d1', 'd2']
    result = CompilationResult(1, 0.1, dummy_target, dummy_deps)
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == dummy_target
    assert result.dependencies == dummy_deps


# Generated at 2022-06-12 04:31:57.021945
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 9999
    time = 12345678
    target = (3, 7)
    dependencies = [
        'a',
        'b',
        'c',
    ]
    cr = CompilationResult(files, time, target, dependencies)
    assert cr.files == files
    assert cr.time == time
    assert cr.target == target
    assert cr.dependencies == dependencies



# Generated at 2022-06-12 04:32:00.721524
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # type: () -> None
    target = CompilationTarget(3, 5)
    result = CompilationResult(1, 1.0, target, ["foo"])

    assert result.files == 1
    assert result.time == 1.0
    assert result.target == target
    assert result.dependencies == ["foo"]

# Generated at 2022-06-12 04:32:05.002566
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Arrange
    files = 1
    time = 0.3
    target = (2, 3)
    dependencies = ['a', 'b']

    # Act
    result = CompilationResult(files, time, target, dependencies)

    # Assert
    assert type(result) == CompilationResult
    assert result.files == files
    assert result.time == time
    assert result.target == target
    assert result.dependencies == dependencies


# Generated at 2022-06-12 04:32:07.674226
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # create an instance
    input_output = InputOutput(input=Path('input'), output=Path('output'))

    # check values
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')

# Generated at 2022-06-12 04:32:12.496083
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    dependencies = []
    tree = ast.Name('some', ast.Load())
    res = TransformationResult(tree, True, dependencies)
    assert res.tree is tree
    assert res.tree_changed is True
    assert res.dependencies == dependencies


# Result of Transformers.apply
ApplyResult = NamedTuple('ApplyResult',
                         [('io_pair', InputOutput),
                          ('result', TransformationResult),
                          ('target', CompilationTarget)])


# Generated at 2022-06-12 04:32:15.602551
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=1,
                            time=2,
                            target=(3, 4),
                            dependencies=['a', 'b'])
    assert res.files == 1
    assert res.time == 2
    assert res.target == (3, 4)
    assert res.dependencies == ['a', 'b']


# Generated at 2022-06-12 04:32:19.306185
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Example Path
    example_path = Path('example_path')

    # Create default object
    default = InputOutput(input=example_path,
                          output=example_path)

    # Create sample object
    sample = InputOutput(input=example_path,
                         output=example_path)

    # Check if fields match
    assert default.input == sample.input
    assert default.output == sample.output

# Generated at 2022-06-12 04:32:20.255394
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('in'), Path('out'))


# Generated at 2022-06-12 04:34:20.319409
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    t = CompilationResult(1, 2, (3, 4), ['a', 'b'])
    assert t.files == 1
    assert t.time == 2
    assert t.target == (3, 4)
    assert t.dependencies == ['a', 'b']
    assert t._fields == ('files', 'time', 'target', 'dependencies')

# Generated at 2022-06-12 04:34:22.578773
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(
        files=1,
        time=0.0,
        target=(3, 7),
        dependencies=[]
    )


# Generated at 2022-06-12 04:34:25.767318
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result = TransformationResult(tree=None,
                                                 tree_changed=False,
                                                 dependencies=['.'])
    assert transformation_result.tree
    assert transformation_result.tree_changed
    assert transformation_result.dependencies

# Result of a single transformer
Result = NamedTuple('Result', [('input_output', InputOutput),
                               ('result', TransformationResult)])


# Generated at 2022-06-12 04:34:29.715539
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('1 + 1')
    tr = TransformationResult(tree=tree,
                              tree_changed=False,
                              dependencies=['test.py'])
    assert tr.tree is tree
    assert tr.tree_changed is False
    assert tr.dependencies == ['test.py']

# Generated at 2022-06-12 04:34:35.763514
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Type information
    assert isinstance(CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=[]), CompilationResult)
    # Content information
    assert CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=[]) == CompilationResult(files=1, time=1.0, target=(3, 6),
                                                                                                     dependencies=[])
    assert CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=[]) != CompilationResult(files=1, time=1.0, target=(3, 7),
                                                                                                      dependencies=[])



# Generated at 2022-06-12 04:34:39.417902
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=None,
                              tree_changed=True,
                              dependencies=['file_1', 'file_2'])
    assert tr.tree is None
    assert tr.tree_changed is True
    assert tr.dependencies == ['file_1', 'file_2']

# Generated at 2022-06-12 04:34:42.214441
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp')
    output = Path('/tmp2')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output



# Generated at 2022-06-12 04:34:45.719017
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('x')
    output_path = Path('y')
    io = InputOutput(input=input_path, output=output_path)
    assert io.input == input_path
    assert io.output == output_path

# Generated at 2022-06-12 04:34:47.724930
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = InputOutput(Path('.'), Path('.'))
    assert isinstance(i.input, Path)
    assert isinstance(i.output, Path)


# Generated at 2022-06-12 04:34:57.472629
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(ast.AST, True, ['a.py'])
    assert t.tree
    assert isinstance(t.tree, ast.AST)
    assert t.tree_changed is True
    assert isinstance(t.dependencies, List)
    assert isinstance(t.dependencies[0], str)

# Information about a test
TestResult = NamedTuple('TestResult', [('passed', bool),
                                       ('test_type', str),
                                       ('test_name', str),
                                       ('log', str),
                                       ('output', str),
                                       ('expected_output', str)])

# Result of testing