

# Generated at 2022-06-25 23:03:37.531469
# Unit test for constructor of class TransformationResult
def test_TransformationResult():

    dependencies = [str(i) for i in range(0, 100)]
    tree = ast.parse("while True:pass")

    result = TransformationResult(tree, False, dependencies)



# Generated at 2022-06-25 23:03:40.327453
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result_0 = TransformationResult(None, True, ["a.py", "b.py"])
    result_1 = TransformationResult(ast.parse("import sys"), False, [])
    pass



# Generated at 2022-06-25 23:03:41.952338
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 0.1, (3, 5), [])


# Generated at 2022-06-25 23:03:46.294037
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 1.0, (2,2), ['a', 'b'])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (2,2)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-25 23:03:48.781527
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    x = TransformationResult(ast.AST(), True, [])
    assert x.tree is not None
    assert x.tree_changed == True
    assert x.dependencies == []



# Generated at 2022-06-25 23:03:53.823097
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(
                                           files=1,
                                           time=0.1,
                                           target=(3, 8),
                                           dependencies=['a', 'b']
                                           )

    assert (compilation_result.files == 1)
    assert (compilation_result.time == 0.1)
    assert (compilation_result.target == (3, 8))
    assert (compilation_result.dependencies == ['a', 'b'])

# Generated at 2022-06-25 23:03:58.353052
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(0, 0.0, (3, 7), [])
    assert compilation_result_0.files == 0
    assert compilation_result_0.time == 0.0
    assert compilation_result_0.target == (3, 7)
    assert compilation_result_0.dependencies == []


# Generated at 2022-06-25 23:03:59.856125
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.AST(), False, []) == TransformationResult(ast.AST(), False, [])

# Generated at 2022-06-25 23:04:02.182930
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    input_output = None
    compilation_result = None
    t = TransformationResult(input_output, compilation_result)
    assert isinstance(t, TransformationResult)



# Generated at 2022-06-25 23:04:10.803452
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Construction with file name
    test_input = 'test_input.py'
    test_output = 'test_output.py'
    input_output = InputOutput(test_input, test_output)
    assert input_output.input == 'test_input.py'
    assert input_output.output == 'test_output.py'
    # Construction with path
    test_input = Path('test_input.py')
    test_output = Path('test_output.py')
    input_output = InputOutput(test_input, test_output)
    assert input_output.input == Path('test_input.py')
    assert input_output.output == Path('test_output.py')
    # Type checking

# Generated at 2022-06-25 23:04:17.698171
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(0, 1.0,
                             (2, 3),
                             ['dependency_0', 'dependency_1'])\
        == CompilationResult(files=0,
                             time=1.0,
                             target=(2, 3),
                             dependencies=['dependency_0', 'dependency_1'])



# Generated at 2022-06-25 23:04:21.099158
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult()
    assert(result.files == 0)
    assert(result.time == 0.0)
    assert(result.target == (0, 0))
    assert(result.dependencies == [])


# Generated at 2022-06-25 23:04:22.608530
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(1, 1.0, (1, 1), [])


# Generated at 2022-06-25 23:04:23.904790
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io1 = InputOutput(Path('input'), Path('output'))


# Generated at 2022-06-25 23:04:28.186757
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.AST()
    tree_changed = False
    dependencies = []
    transformation_result = TransformationResult(tree,
                                                 tree_changed,
                                                 dependencies)
    assert transformation_result.tree == tree
    assert transformation_result.tree_changed == tree_changed
    assert transformation_result.dependencies == dependencies

# Generated at 2022-06-25 23:04:29.399812
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_0 = Path('/opt')
    output_0 = Path('/usr')
    result_inputoutput = InputOutput(input_0, output_0)

# Generated at 2022-06-25 23:04:29.911669
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult()

# Generated at 2022-06-25 23:04:33.480044
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    mock_tree = ast.AST()
    mock_tree_changed = True
    mock_dependencies = []
    res = TransformationResult(mock_tree, mock_tree_changed,
                               mock_dependencies)
    assert res.tree == mock_tree
    assert res.tree_changed == mock_tree_changed
    assert res.dependencies == mock_dependencies

# Generated at 2022-06-25 23:04:38.782589
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    """
    Check if constructor of TransformationResult works as expected
    """
    exp_tree = ast.Assign()
    exp_changed = True
    exp_dependencies = ["my.py"]

    tr = TransformationResult(exp_tree, exp_changed, exp_dependencies)

    assert tr.tree == exp_tree
    assert tr.tree_changed == exp_changed
    assert tr.dependencies == exp_dependencies

# Generated at 2022-06-25 23:04:46.045200
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(1, 0.1, (3,4), [])
    print(compilation_result)

    tmp = CompilationResult(1, 0.1, (3,4), [])
    tmp2 = CompilationResult(1, 0.1, (3,4), [])
    tmp_hash = hash(tmp)
    print(tmp_hash)
    print(tmp2)
    print(hash(tmp2))


# Generated at 2022-06-25 23:04:55.925001
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1,
                                           time=0.1,
                                           target=(3, 7),
                                           dependencies=['/foo/bar/baz.py'])
    assert compilation_result.files == 1
    assert compilation_result.time == 0.1
    assert compilation_result.target == (3, 7)
    assert compilation_result.dependencies == ['/foo/bar/baz.py']



# Generated at 2022-06-25 23:05:01.682527
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult()
    assert compilation_result_0.files == 0
    assert compilation_result_0.time == 0
    assert compilation_result_0.target == (3, 5)
    assert compilation_result_0.dependencies == ['./examples/lib/__init__.py', './examples/lib/foo.py']



# Generated at 2022-06-25 23:05:04.826764
# Unit test for constructor of class InputOutput
def test_InputOutput():
    try:
        # Here we expect "TypeError: __new__() missing 2 required positional arguments: 'input' and 'output'"
        a = InputOutput()
    except TypeError:
        return True
    return False


# Generated at 2022-06-25 23:05:08.648770
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = 2
    output = 3
    a = InputOutput(input, output)


# Generated at 2022-06-25 23:05:13.736388
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1, time=1.0, target=(3, 7), dependencies=[""])

    assert(compilation_result.files) == 1

# Generated at 2022-06-25 23:05:19.315314
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    print("Test for constructor of class TransformationResult ==========================================================")
    print()
    #print("test_case_1")
    test_case_1()
    #print("test_case_2")
    test_case_2()
    #print("test_case_3")
    test_case_3()
    #print("test_case_4")
    test_case_4()

# Test case 1

# Generated at 2022-06-25 23:05:23.014653
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Setup
    input_0 = Path()
    output_0 = Path()
    # Exercise
    input_output_0 = InputOutput(input_0, output_0)
    # Verify
    input = input_output_0.input
    output = input_output_0.output

# Generated at 2022-06-25 23:05:27.178226
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(tree=ast.AST(), tree_changed=True, dependencies=[])
    assert isinstance(result.tree, ast.AST)
    assert isinstance(result.tree_changed, bool)
    assert isinstance(result.dependencies, list)

# Generated at 2022-06-25 23:05:28.068018
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_case_0()


# Generated at 2022-06-25 23:05:30.808640
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path_str = "/usr/bin/"
    path = Path(path_str)

    input_output = InputOutput(path, path)
    assert input_output.input == path
    assert input_output.output == path



# Generated at 2022-06-25 23:05:37.674972
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_file = Path("hello.py")
    output_file = Path("hello_transformed.py")
    input_output = InputOutput(input_file, output_file)


# Generated at 2022-06-25 23:05:41.922497
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1, time=0.1, target=(3, 5), dependencies=['foo.py'])
    assert compilation_result.files == 1
    assert compilation_result.time == 0.1
    assert compilation_result.target == (3, 5)
    assert compilation_result.dependencies == ['foo.py']


# Generated at 2022-06-25 23:05:46.502690
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree_0 = ast.AST()
    tree_changed_0 = bool()
    dependencies_0 = list()
    transformation_result_0 = TransformationResult(tree_0,
                                                    tree_changed_0,
                                                    dependencies_0)

# Generated at 2022-06-25 23:05:50.176491
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput(Path(), Path())
    assert isinstance(input_output_0, InputOutput)


# Generated at 2022-06-25 23:05:59.657439
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(files=0, time=.0, target=(2, 7),
                                             dependencies=[])
    assert compilation_result_0.files == 0
    assert compilation_result_0.time == .0
    assert compilation_result_0.target == (2, 7)
    assert compilation_result_0.dependencies == []

    compilation_result_1 = CompilationResult(files=5, time=1.1, target=(3, 7),
                                             dependencies=["0.py"])
    assert compilation_result_1.files == 5
    assert compilation_result_1.time == 1.1
    assert compilation_result_1.target == (3, 7)
    assert compilation_result_1.dependencies == ["0.py"]



# Generated at 2022-06-25 23:06:04.197416
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult()
    assert tr.tree is None
    assert tr.tree_changed is False
    assert tr.dependencies == []

    t = ast.parse("2 + 2")
    tr = TransformationResult(t, True, [])
    assert tr.tree.body[0].value.left.n == 2
    assert tr.tree_changed is True
    assert tr.dependencies == []



# Generated at 2022-06-25 23:06:06.277172
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    assert InputOutput(input, output).input == input
    assert InputOutput(input, output).output == output


# Generated at 2022-06-25 23:06:10.021721
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult()
    compilation_result_1 = CompilationResult(
        files=0,
        time=3.141592653589793,
        target=(2, 7),
        dependencies=[]
    )
    # TODO: Make a __eq__() method!


# Generated at 2022-06-25 23:06:11.055107
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(pathlib.Path(), pathlib.Path())


# Generated at 2022-06-25 23:06:12.505448
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_0 = '/home/user/input'
    output_0 = '/home/user/output'
    input_output_0 = InputOutput(input_0, output_0)


# Generated at 2022-06-25 23:06:25.432837
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult()
    assert compilation_result_0.files == 0
    assert compilation_result_0.time == 0
    assert compilation_result_0.target == (0, 0)
    assert compilation_result_0.dependencies == []

# Generated at 2022-06-25 23:06:26.537572
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput()


# Generated at 2022-06-25 23:06:30.535151
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 0
    time = 0.0
    target = (3, 7)
    dependencies = []
    compilation_result = CompilationResult(files, time, target, dependencies)
    assert compilation_result.files == files
    assert compilation_result.time == time
    assert compilation_result.target == target
    assert compilation_result.dependencies == dependencies


# Generated at 2022-06-25 23:06:31.521082
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput(Path(), Path())


# Generated at 2022-06-25 23:06:32.912378
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput("","") == InputOutput("","")
    

# Generated at 2022-06-25 23:06:38.510318
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_pypath0 = Path('./input1.py')
    output_pypath0 = Path('./output1.py')
    input_output0 = InputOutput(input_pypath0, output_pypath0)
    assert input_output0.input == Path('./input1.py')
    assert input_output0.output == Path('./output1.py')


# Generated at 2022-06-25 23:06:41.713069
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("print('testing...')")
    dependencies = []
    result = TransformationResult(tree, False, dependencies)
    assert result.tree == tree
    assert result.tree_changed == False
    assert result.dependencies == []

# Generated at 2022-06-25 23:06:42.809796
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult
    assert callable(CompilationResult)


# Generated at 2022-06-25 23:06:44.228675
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    try:
        _ = TransformationResult()
    except Exception:
        assert True


# Generated at 2022-06-25 23:06:48.437892
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Create a TransformationResult object
    transformation_result_0_obj = TransformationResult(
        # place holders
        ast.AST(),
        # place holders
        True,
        # place holders
        ['xyzzy'])
    # Assert type of object
    assert isinstance(transformation_result_0_obj, TransformationResult)


# Generated at 2022-06-25 23:07:07.501327
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(1, 1.1, (1, 1), [])


# Generated at 2022-06-25 23:07:15.293310
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast0_0 = ast.AST()
    list_0_0 = ["string0_0", "string0_1", "string0_2"]
    transformation_result_0_0 = TransformationResult(
        ast0_0, False, list_0_0)
    assert transformation_result_0_0.tree == ast0_0
    assert transformation_result_0_0.tree_changed is False
    assert transformation_result_0_0.dependencies == list_0_0
    ast0_1 = ast.AST()
    list_0_1 = ["string0_0", "string0_1", "string0_2"]
    transformation_result_0_1 = TransformationResult(
        ast0_1, True, list_0_1)
    assert transformation_result_0_1.tree == ast0_1


# Generated at 2022-06-25 23:07:19.758775
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Asserting attributes has correct type
    assert isinstance(TransformationResult(tree=ast.parse(''), tree_changed=True, dependencies=[]).tree, ast.AST)
    assert isinstance(TransformationResult(tree=ast.parse(''), tree_changed=True, dependencies=[]).tree_changed, bool)
    assert isinstance(TransformationResult(tree=ast.parse(''), tree_changed=True, dependencies=[]).dependencies, list)


# Generated at 2022-06-25 23:07:30.053023
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(files=1, time=0.0, target=(2, 5), dependencies=['foo.py'])
    compilation_result_1 = CompilationResult(files=1, time=0.0, target=(3, 2), dependencies=['foo.py'])
    compilation_result_2 = CompilationResult(files=1, time=0.0, target=(2, 5), dependencies=['bar.py'])

    assert compilation_result_0 == compilation_result_0
    assert compilation_result_0 != compilation_result_1
    assert compilation_result_0 != compilation_result_2
    assert compilation_result_1 != compilation_result_2


# Generated at 2022-06-25 23:07:32.952095
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert (InputOutput(Path("foo") , Path("bar")) == InputOutput(Path("foo"), Path("bar")))
    assert (InputOutput(Path("foo"), Path("bar")) != InputOutput(Path("bar"), Path("foo")))



# Generated at 2022-06-25 23:07:34.466824
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.AST(), True, []) == TransformationResult(ast.AST(), True, [])

# Generated at 2022-06-25 23:07:38.874591
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(files=0, time=0.0,
                                             target=(0, 0), dependencies=[])
    assert compilation_result_0.files == 0
    assert compilation_result_0.time == 0.0
    assert compilation_result_0.target == (0, 0)
    assert compilation_result_0.dependencies == []


# Generated at 2022-06-25 23:07:49.715270
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    import unittest
    import datetime
    class TestClass(unittest.TestCase):
        def test_constructor(self):
            try:
                self.assertEqual(CompilationResult(0, 1, (3, 4), [1, 2, '3']),
                                 CompilationResult(files = 0,
                                                   time = 1,
                                                   target = (3, 4),
                                                   dependencies = [1, 2, '3']))
            except AttributeError:
                self.assertEqual(CompilationResult(0, 1, (3, 4), [1, 2, '3']),
                                 CompilationResult._make([0, 1, (3, 4), [1, 2, '3']]))

# Generated at 2022-06-25 23:07:51.617242
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """
    Test for the constructor for input output
    """
    assert InputOutput(Path('/a'), Path('/b')).input == Path('/a')


# Generated at 2022-06-25 23:07:53.204463
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(None, None, None)
    assert isinstance(res, TransformationResult)


# Generated at 2022-06-25 23:08:16.628060
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree_0 = ast.parse('print(42)')
    test_result = TransformationResult(tree=tree_0,
                                       tree_changed=True,
                                       dependencies=['abc'])
    assert test_result.tree == tree_0
    assert test_result.tree_changed == True
    assert test_result.dependencies == ['abc']

# Generated at 2022-06-25 23:08:19.834246
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Given this input, provide this output
    test_case_0 = InputOutput(input=Path('./path/to/input.txt'),
                              output=Path('./path/to/output.txt'))


# Generated at 2022-06-25 23:08:22.875184
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    compilation_result_0 = CompilationResult()
    compilation_result_1 = CompilationResult(1,2,3,4)

# Generated at 2022-06-25 23:08:27.565510
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    a = ast.AST()
    b = ast.AST()
    l = ['a', 'b', 'c']
    t1 = TransformationResult(a, True, l)
    t2 = TransformationResult(b, False, l)
    t3 = TransformationResult(b, False, [])
    assert t1 == t1
    assert t1 != t2
    assert t2 == t2
    assert t3 != t2

# Generated at 2022-06-25 23:08:29.384503
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_0 = Path("black")
    output_0 = Path("white")
    input_output_0 = InputOutput(input_0, output_0)

# Generated at 2022-06-25 23:08:31.693912
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result = TransformationResult(tree=1, tree_changed=False, dependencies=["a", "b"])
    assert transformation_result.tree != ""
    assert transformation_result.tree_changed != ""
    assert transformation_result.dependencies != ""

# Generated at 2022-06-25 23:08:33.806194
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Check if the constructor of class InputOutput is working
    # as expected
    input_output = InputOutput(Path('../'), Path('../'))
    assert input_output.input == Path('../')
    assert input_output.output == Path('../')



# Generated at 2022-06-25 23:08:36.980556
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(1, 2, (3, 4), ['a', 'b'])

    # Test fields
    assert compilation_result.files == 1
    assert compilation_result.time == 2
    assert compilation_result.target == (3, 4)
    assert compilation_result.dependencies == ['a', 'b']



# Generated at 2022-06-25 23:08:39.617136
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(
        files=3, time=14.8, target=(3, 6), dependencies=['math', 'requests']
    )
    assert compilation_result.time == 14.8


# Generated at 2022-06-25 23:08:40.393126
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult()


# Generated at 2022-06-25 23:09:28.519256
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input_file')
    output = Path('output_file')
    io = InputOutput(input, output)
    assert io.input == input and io.output == output


# Generated at 2022-06-25 23:09:30.667746
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = InputOutput(input=Path("input"),
                    output=Path("output"))
    assert a.input == Path("input")
    assert a.output == Path("output")



# Generated at 2022-06-25 23:09:34.828200
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('../data/files/file_0.py')
    output = Path('../data/files/file_0.py.c')
    result = InputOutput(input, output)
    assert result.input == '../data/files/file_0.py'
    assert result.output == '../data/files/file_0.py.c'



# Generated at 2022-06-25 23:09:37.382465
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    try:
        TransformationResult(
            tree = ast.AST(),
            tree_changed = False,
            dependencies = ['', '', '', ''])
    except TypeError:
        raise TypeError("test failed, TransformationResult constructor didn't accept the input")
    else:
        print("test succeeded, TransformationResult constructor accepted the input")

# Generated at 2022-06-25 23:09:41.014469
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test_Tree = ast.Num()
    test_Tree_changed = True
    test_Dependencies = ['test']

    result = TransformationResult(test_Tree, test_Tree_changed, test_Dependencies)
    assert result.tree is test_Tree
    assert result.tree_changed is True
    assert result.dependencies is test_Dependencies

# Unit test constructor of class CompilationResult

# Generated at 2022-06-25 23:09:44.478212
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(0, 3.2, (3, 6), ["abc", "def"])
    assert isinstance(compilation_result_0, CompilationResult)
    assert repr(compilation_result_0) == "CompilationResult(files=0, time=3.2, target=(3, 6), dependencies=['abc', 'def'])"


# Generated at 2022-06-25 23:09:49.519163
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_1 = CompilationResult(files=1,
                                             time=2.0,
                                             target=(3, 4),
                                             dependencies=['a', 'b'])

    assert compilation_result_1.files == 1
    assert compilation_result_1.time == 2.0
    assert compilation_result_1.target == (3, 4)
    assert compilation_result_1.dependencies == ['a', 'b']


# Generated at 2022-06-25 23:09:52.300085
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result = TransformationResult(ast.AST(), True, ['a', 'b'])
    assert transformation_result.tree == ast.AST()
    assert transformation_result.tree_changed == True
    assert transformation_result.dependencies == ['a', 'b']

# Generated at 2022-06-25 23:09:55.180331
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(
        tree=ast.Module(),
        tree_changed=True,
        dependencies=['a','b'])
    assert(isinstance(tr.tree, ast.Module))
    assert(tr.tree_changed)
    assert(isinstance(tr.dependencies, list))


# Generated at 2022-06-25 23:09:56.788968
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('test_input')
    output_path = Path('test_output')
    input_output = InputOutput(input_path, output_path)



# Generated at 2022-06-25 23:11:46.360117
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Constructor call with minimal arguments
    transform_result = TransformationResult(tree=None,
                                            tree_changed=True,
                                            dependencies=[''])
    # Check the attributes
    assert transform_result.tree == None
    assert transform_result.tree_changed == True
    assert transform_result.dependencies == ['']

    # Constructor call with all arguments
    transform_result = TransformationResult(tree=None,
                                            tree_changed=False,
                                            dependencies=['test/dep_file'])
    # Check the attributes
    assert transform_result.tree == None
    assert transform_result.tree_changed == False
    assert transform_result.dependencies == ['test/dep_file']

    # Constructor call without arguments
    transform_result = TransformationResult()
    # Check the attributes
    assert transform_

# Generated at 2022-06-25 23:11:52.274358
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_1 = InputOutput('dummy_1', 'dummy_2')
    assert input_output_1.input == 'dummy_1'
    assert input_output_1.output == 'dummy_2'
    input_output_2 = InputOutput(os.path.join(INPUTS_DIR, "input_file.txt"), os.path.join(OUTPUTS_DIR, "output_file.txt"))
    assert input_output_2.input == os.path.join(INPUTS_DIR, "input_file.txt")
    assert input_output_2.output == os.path.join(OUTPUTS_DIR, "output_file.txt")



# Generated at 2022-06-25 23:11:54.155604
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inputoutput = InputOutput(pathlib.Path("input"), pathlib.Path("output"))
    assert inputoutput.input == pathlib.Path("input")
    assert inputoutput.output == pathlib.Path("output")



# Generated at 2022-06-25 23:11:56.664357
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_0 = Path('test')
    output_0 = Path('test')
    input_output_0 = InputOutput(input_0, output_0)
    assert input_output_0.input == input_0
    assert input_output_0.output == output_0


# Generated at 2022-06-25 23:11:58.993894
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_0 = InputOutput(input=Path('../test_data/test.py'),output=Path('../test_data/test.mq3'))
    assert input_0.input == Path('../test_data/test.py')
    assert input_0.output == Path('../test_data/test.mq3')


# Generated at 2022-06-25 23:11:59.937149
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-25 23:12:02.781130
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(1, 2, (3, 4), [])
    assert compilation_result.files == 1
    assert compilation_result.time == 2
    assert compilation_result.target == (3, 4)
    assert compilation_result.dependencies == []


# Generated at 2022-06-25 23:12:03.390655
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test_case_0()

# Generated at 2022-06-25 23:12:10.367700
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Getting instance of class ast.Module
    class_ast_Module = ast.Module()

    # Creating instance of class TransformationResult
    class_TransformationResult_instance = TransformationResult(tree=class_ast_Module,
                                                               tree_changed=False,
                                                               dependencies=[])

    # Getting class TransformationResult instance variables
    class_TransformationResult_tree = class_TransformationResult_instance.tree
    class_TransformationResult_dependencies = class_TransformationResult_instance.dependencies
    class_TransformationResult_tree_changed = class_TransformationResult_instance.tree_changed

    # Testing class TransformationResult instance variables
    assert class_TransformationResult_tree == class_ast_Module
    assert class_TransformationResult_dependencies == []
    assert class_TransformationResult_tree_changed == False


# Unit test

# Generated at 2022-06-25 23:12:11.214926
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result_0 = TransformationResult(ast.AST(), bool(), list())