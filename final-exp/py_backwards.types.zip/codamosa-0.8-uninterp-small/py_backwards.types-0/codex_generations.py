

# Generated at 2022-06-25 23:03:41.748070
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    input_0 = Path('.')
    input_1 = ast.parse('')
    input_2 = True
    input_3 = []
    assert isinstance(input_0, Path)
    assert isinstance(input_1, ast.AST)
    assert isinstance(input_2, bool)
    assert isinstance(input_3, list)
    # TODO: Test of constructor of class TransformationResult
    result = TransformationResult(input_0, input_1, input_2, input_3)
    assert isinstance(result, TransformationResult)


# Generated at 2022-06-25 23:03:46.737568
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_0 = Path('input')
    output_0 = Path('output')

    input_output_0 = InputOutput(input_0, output_0)

    assert isinstance(input_output_0, InputOutput)
    assert input_output_0.input == Path('input')
    assert input_output_0.output == Path('output')



# Generated at 2022-06-25 23:03:53.168640
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    try:
        compilation_result_0 = CompilationResult(files=2,
                                                 time=1.0,
                                                 target=(3, 6),
                                                 dependencies=['a', 'b'])
        # Printing attributes
        print("Number of files = ", compilation_result_0.files)
        print("Time = ", compilation_result_0.time)
        print("Target = ", compilation_result_0.target)
        print("List of dependencies = ", compilation_result_0.dependencies)
    except Exception as e:
        print("Exception caught: " + str(e))



# Generated at 2022-06-25 23:03:55.889015
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """Constructor InputOutput test case."""
    input_output = InputOutput(Path(__file__), Path(__file__))
    assert input_output.input == Path(__file__)


# Generated at 2022-06-25 23:03:58.568960
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.AST()
    tree_changed = True
    dependencies = ['unicode']
    result = TransformationResult(tree, tree_changed, dependencies)



# Generated at 2022-06-25 23:04:01.877071
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    a = ast.AST()
    b = [True]
    c = [True]
    res = TransformationResult(a,b,c)
    assert res.tree == a
    assert res.tree_changed == b
    assert res.dependencies == c

# Generated at 2022-06-25 23:04:06.593897
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('./')
    output = Path('./')
    input_output_0 = InputOutput(input, output)
    assert isinstance(input_output_0.input, Path)
    assert input_output_0.input.as_posix() == './'
    assert isinstance(input_output_0.output, Path)
    assert input_output_0.output.as_posix() == './'


# Generated at 2022-06-25 23:04:08.740239
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert isinstance(TransformationResult(ast.AST(),
                                           True,
                                           ['foo.py']), TransformationResult)



# Generated at 2022-06-25 23:04:10.889597
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path('/a'), Path('/b'))
    assert io.input == Path('/a')
    assert io.output == Path('/b')


# Generated at 2022-06-25 23:04:18.664698
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    print("Testing CompilationResult constructor")
    compilation_result_0 = CompilationResult()
    compilation_result_1 = CompilationResult(0, 0.0, (0, 0), [""])
    assert compilation_result_0.files == 0
    assert compilation_result_0.time == 0.0
    assert compilation_result_0.target == (0, 0)
    assert compilation_result_0.dependencies == list()
    assert compilation_result_1.files == 0
    assert compilation_result_1.time == 0.0
    assert compilation_result_1.target == (0, 0)
    assert compilation_result_1.dependencies == [""]


# Generated at 2022-06-25 23:04:23.180004
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult.__new__(CompilationResult,
                                     files=0,
                                     time=0.0,
                                     target=(1, 1),
                                     dependencies=[]
                                     )._fields == ('files', 'time', 'target', 'dependencies')


# Generated at 2022-06-25 23:04:26.434513
# Unit test for constructor of class InputOutput
def test_InputOutput():
    '''
    testing constructor.
    :return:
    '''
    io = InputOutput(Path("B"), Path("B"))
    assert (io.input == Path("B"))
    assert (io.output == Path("B"))



# Generated at 2022-06-25 23:04:27.642103
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult()



# Generated at 2022-06-25 23:04:30.405250
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path(__file__)
    o = Path(__file__).with_suffix('.pyc')
    io = InputOutput(i, o)
    assert io.input == i
    assert io.output == o


# Generated at 2022-06-25 23:04:33.148119
# Unit test for constructor of class InputOutput
def test_InputOutput():
    first_path = Path('first_path')
    second_path = Path('second_path')
    input_output = InputOutput(first_path, second_path)
    assert input_output.input == first_path
    assert input_output.output == second_path


# Generated at 2022-06-25 23:04:37.450099
# Unit test for constructor of class TransformationResult
def test_TransformationResult():

    # Create a instance of TransformationResult
    test_result = TransformationResult(tree = 'ast_tree', tree_changed = True, dependencies = [])

    # Assert
    assert test_result.tree == 'ast_tree'
    assert test_result.tree_changed == True
    assert test_result.dependencies == []



# Generated at 2022-06-25 23:04:39.203895
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path("input")
    output = Path("output")
    assert InputOutput(input, output)



# Generated at 2022-06-25 23:04:41.403249
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path(''), Path(''))
    assert io.input == Path('')
    assert io.output == Path('')

# Generated at 2022-06-25 23:04:49.982134
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    original_tree = ast.parse('print(str(1+1))')
    transformed_tree = ast.parse('print(str(2))')
    transformation_result = TransformationResult(transformed_tree,
                                                  True,
                                                  [])
    assert transformation_result.tree_changed and\
           original_tree != transformed_tree
    assert not transformation_result.dependencies
    transformation_result = TransformationResult(transformed_tree,
                                                  False,
                                                  [])
    assert not transformation_result.tree_changed and\
           original_tree == transformed_tree
    assert not transformation_result.dependencies



# Generated at 2022-06-25 23:04:54.106387
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.AST(), False, []) == TransformationResult(ast.AST(), False, [])
    assert TransformationResult(ast.AST(), False, []) != TransformationResult(ast.AST(), True, [])
    assert TransformationResult(ast.AST(), False, []) != TransformationResult(ast.AST(), False, ["test"])


# Generated at 2022-06-25 23:05:00.665578
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult()
    assert compilation_result_0.files == 0
    assert compilation_result_0.time == 0.0
    assert compilation_result_0.target == (0, 0)
    assert compilation_result_0.dependencies == []



# Generated at 2022-06-25 23:05:01.873585
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput('input', 'output')


# Generated at 2022-06-25 23:05:05.344679
# Unit test for constructor of class InputOutput
def test_InputOutput():
    FileOne = Path('FileOne.py')
    FileTwo = Path('FileTwo.py')
    InputOutputOne = InputOutput(FileOne,FileTwo)
    assert(InputOutputOne.input == FileOne)
    assert(InputOutputOne.output == FileTwo)

# Generated at 2022-06-25 23:05:12.706392
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path("input.txt")
    output = Path("output.txt")
    io_pair = InputOutput(input_, output)

    assert io_pair.input == "input.txt"
    assert io_pair.output == "output.txt"
    return


# Generated at 2022-06-25 23:05:15.972194
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree_0 = ast.Module()

    transformation_result = TransformationResult(tree_0, False, list())

    assert transformation_result.tree is tree_0
    assert not transformation_result.tree_changed
    assert len(transformation_result.dependencies) == 0


# Generated at 2022-06-25 23:05:20.069629
# Unit test for constructor of class InputOutput
def test_InputOutput():
    try:
        input_0 = './__init__.py'
        output_0 = './__init__.py'
        input_output_0 = InputOutput(input_0, output_0)
    except Exception:
        assert False


# Generated at 2022-06-25 23:05:29.281972
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert(CompilationResult(1, 2.0, (3, 4), ['a', 'b', 'c']).files == 1)
    assert(CompilationResult(1, 2.0, (3, 4), ['a', 'b', 'c']).time == 2.0)
    assert(CompilationResult(1, 2.0, (3, 4), ['a', 'b', 'c']).target == (3, 4))
    assert(CompilationResult(1, 2.0, (3, 4), ['a', 'b', 'c']).dependencies == ['a', 'b', 'c'])


# Generated at 2022-06-25 23:05:30.069598
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert isinstance(1, int)

# Generated at 2022-06-25 23:05:35.811897
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files = 1,
                                           time = 2,
                                           target = (3, 4),
                                           dependencies = ['a', 'b', 'c'])
    assert (compilation_result.files == 1)
    assert (compilation_result.time == 2)
    assert (compilation_result.target == (3, 4))
    assert (compilation_result.dependencies == ['a', 'b', 'c'])


# Generated at 2022-06-25 23:05:39.547762
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_0 = Path("input.py")
    output_0 = Path("output.py")
    input_output_0 = InputOutput(input_0, output_0)
    input_output_0 = InputOutput(input_0, output_0)
    return input_output_0


# Generated at 2022-06-25 23:05:47.398548
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from astor.astor import code_to_ast

    code = '''
    def foo():
        x = 4
    '''
    tree = code_to_ast(code)
    transformation_result = TransformationResult(tree, False, [])
    assert transformation_result.tree is tree
    assert transformation_result.tree_changed is False
    assert transformation_result.dependencies == []

# Generated at 2022-06-25 23:05:52.103356
# Unit test for constructor of class InputOutput
def test_InputOutput():
	assert (InputOutput(Path('/home/user/b.py'), Path('/home/user/backup/b.py')) == InputOutput(Path('/home/user/b.py'), Path('/home/user/backup/b.py')))


# Generated at 2022-06-25 23:06:01.499086
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    line1 = ast.parse('x = 1')
    line2 = ast.parse('y = 1')
    line1_1_tree = ast.fix_missing_locations(line1)
    line2_1_tree = ast.fix_missing_locations(line2)
    line1_1_tree_changed = True
    line2_1_tree_changed = False
    #print(line1_1_tree)
    line2_1_tree = ast.fix_missing_locations(line2)
    line1_1_dependencies = ["inner"]
    line2_1_dependencies = ["outer"]
    line1_1_result = TransformationResult(line1_1_tree,
                                line1_1_tree_changed,
                                line1_1_dependencies)
    line2_1_

# Generated at 2022-06-25 23:06:04.619259
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast = None
    tree_changed = True
    dependencies = []

    transformation_result = TransformationResult(ast, tree_changed,
                                                 dependencies)

    assert transformation_result.tree is None
    assert transformation_result.tree_changed is True
    assert transformation_result.dependencies == []

# Generated at 2022-06-25 23:06:08.729320
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    trans_result = TransformationResult(
        tree=ast.AST(),
        tree_changed=False,
        dependencies=['a.py', 'b.py']
    )
    assert trans_result.tree
    assert not trans_result.tree_changed
    assert trans_result.dependencies == ['a.py', 'b.py']


# Generated at 2022-06-25 23:06:11.906197
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    expected = CompilationResult(0, 92.0, (3, 6), ["../foo.py", "../bar.py"])
    actual = CompilationResult(0, 92.0, (3, 6), ["../foo.py", "../bar.py"])
    assert expected == actual
    

# Generated at 2022-06-25 23:06:17.020076
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t_tree = ast.AST()
    t_tree_changed = True
    t_dependencies = ["asd"]
    t_transformation_result = TransformationResult(t_tree, t_tree_changed, t_dependencies)
    assert t_transformation_result.tree == t_tree
    assert t_transformation_result.tree_changed == t_tree_changed
    assert t_transformation_result.dependencies == t_dependencies


# Generated at 2022-06-25 23:06:21.357117
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1, time=2, target=(3, 4), dependencies=['5', '6'])
    assert compilation_result.files == 1
    assert compilation_result.time == 2
    assert compilation_result.target == (3, 4)
    assert compilation_result.dependencies == ['5', '6']


# Generated at 2022-06-25 23:06:24.534545
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_0 = Path('')
    output_0 = Path('')
    input_output_0 = InputOutput(input=input_0, output=output_0)



# Generated at 2022-06-25 23:06:29.318436
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_1 = CompilationResult(files=2, time=1, target=(3, 4), dependencies=['a', 'b'])
    assert compilation_result_1.files == 2
    assert compilation_result_1.time == 1
    assert compilation_result_1.target == (3, 4)
    assert compilation_result_1.dependencies == ['a', 'b']


# Generated at 2022-06-25 23:06:39.298087
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(files=0,
                                             time=0.0,
                                             target=(2, 6),
                                             dependencies=['foo'])
    assert isinstance(compilation_result_0, CompilationResult)
    assert isinstance(compilation_result_0.files, int)
    assert isinstance(compilation_result_0.time, float)
    assert isinstance(compilation_result_0.target, CompilationTarget)
    assert isinstance(compilation_result_0.dependencies, list)


# Generated at 2022-06-25 23:06:40.869763
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_case_1 = InputOutput(input = Path('path1'), output = Path('path2'))


# Generated at 2022-06-25 23:06:41.674666
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test_case_0()



# Generated at 2022-06-25 23:06:43.700031
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Test with the default parameters
    r = TransformationResult()
    assert r.tree is None
    assert r.tree_changed is False
    assert r.dependencies is None

# Generated at 2022-06-25 23:06:46.238180
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('')
    assert TransformationResult(tree=tree, tree_changed=False,
                                dependencies=[]).tree_changed is False


# Generated at 2022-06-25 23:06:50.201319
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 1
    time = 2.0
    target = (3, 4)
    dependencies = ["a", "b"]
    c_res = CompilationResult(files, time, target, dependencies)
    assert c_res.files == files
    assert c_res.time == time
    assert c_res.target == target
    assert c_res.dependencies == dependencies

# Generated at 2022-06-25 23:06:53.019565
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result = TransformationResult(tree=3, tree_changed=True, dependencies=['c1', 'c2'])
    assert(transformation_result.tree == 3)
    assert(transformation_result.tree_changed == True)
    assert(transformation_result.dependencies == ['c1', 'c2'])

# Generated at 2022-06-25 23:06:57.637106
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    try:
        compilation_result = CompilationResult(0, 0.0, (3, 6), [])
    except ValueError:
        compilation_result = CompilationResult(0., 0.0, (3, 6), [])
    assert compilation_result.files == 0
    assert compilation_result.time == 0.0
    assert compilation_result.target == (3, 6)
    assert compilation_result.dependencies == []


# Generated at 2022-06-25 23:06:59.762749
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_1 = Path('some')
    output_1 = Path('file')
    input_output_1 = InputOutput(input_1, output_1)



# Generated at 2022-06-25 23:07:03.971011
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(1, 2.0, (3, 4), [''])
    assert compilation_result.files == 1
    assert compilation_result.time == 2.0
    assert compilation_result.target == (3, 4)
    assert compilation_result.dependencies == ['']

# Generated at 2022-06-25 23:07:11.026455
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=ast.Module, tree_changed=True, dependencies=list())
    assert(isinstance(tr, TransformationResult))


# Generated at 2022-06-25 23:07:12.630283
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = InputOutput("input", "output")
    assert i.input == "input"
    assert i.output == "output"


# Generated at 2022-06-25 23:07:15.127554
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test_tree = ast.parse("import datetime")
    test_tree_changed = False
    test_dependencies = ["datetime"]

    TransformationResult(test_tree, test_tree_changed, test_dependencies)

# Generated at 2022-06-25 23:07:16.147740
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()


# Generated at 2022-06-25 23:07:17.387031
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input, output = InputOutput.__annotations__
    assert input is Path
    assert output is Path



# Generated at 2022-06-25 23:07:19.624391
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input0 = Path('test.py')
    output0 = Path('test.pyc')
    a = InputOutput(input0, output0)
    assert a.input == input0
    assert a.output == output0

# Generated at 2022-06-25 23:07:30.602452
# Unit test for constructor of class InputOutput
def test_InputOutput():

    # Case 0: No arguments
    try:
        io_0 = InputOutput()
        assert (io_0.input == None and io_0.output == None)
    except:
        assert False

    # Case 1: Argument with pathlib.Path
    try:
        input_path_0 = Path("test_input.py")
        output_path_0 = Path("test_output.py")
        io_1 = InputOutput(input_path_0, output_path_0)
        assert (io_1.input == input_path_0 and io_1.output == output_path_0)
    except:
        assert False

    # Case 2: Argument with str

# Generated at 2022-06-25 23:07:33.616706
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(ast.Module(), False, [])
    assert(t.tree is not None)
    assert(isinstance(t.tree, ast.Module))
    assert(t.tree_changed is False)
    assert(t.dependencies == [])

# Generated at 2022-06-25 23:07:37.569776
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult()
    assert compilation_result_0.files == 0
    assert compilation_result_0.time == 0.0
    assert compilation_result_0.target == (0, 0)
    assert compilation_result_0.dependencies == []


# Generated at 2022-06-25 23:07:40.712411
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 1.0, (3, 6))
    assert CompilationResult(1, 1.0, (3, 6), ['sys', 'string', 'abc'])
    assert not CompilationResult()


# Generated at 2022-06-25 23:07:52.486797
# Unit test for constructor of class InputOutput
def test_InputOutput():
    arg_input = "a"
    arg_output = "b"
    input_output = InputOutput(arg_input, arg_output)
    assert input_output.input == arg_input
    assert input_output.output == arg_output


# Generated at 2022-06-25 23:07:55.715346
# Unit test for constructor of class InputOutput
def test_InputOutput():
    target_0 = CompilationTarget
    input_0 = Path
    output_0 = Path
    input_output_0 = InputOutput(input_0, output_0, target_0)


# Generated at 2022-06-25 23:07:56.560288
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput()

# Generated at 2022-06-25 23:07:58.455770
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(None, None, None)
    assert result.tree == None
    assert result.tree_changed == None
    assert result.dependencies == None


# Generated at 2022-06-25 23:08:02.121014
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("a = 1")
    tree_changed = False
    dependencies = ["a", "b"]
    res = TransformationResult(tree, tree_changed, dependencies)
    assert res.tree == tree
    assert res.tree_changed == tree_changed
    assert res.dependencies == dependencies

# Generated at 2022-06-25 23:08:05.388684
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    actual = TransformationResult(ast.parse('name = "Gongjiaoshou"'),
                                  True,
                                  ['test'])
    expected = TransformationResult(ast.parse('name = "Gongjiaoshou"'),
                                    True,
                                    ['test'])
    assert actual == expected

# Generated at 2022-06-25 23:08:10.519114
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(files=0, time=0.0, target=(0,0), dependencies=[])
    assert isinstance(compilation_result_0, CompilationResult)
    assert isinstance(compilation_result_0, NamedTuple)
    assert isinstance(compilation_result_0.files, int)
    assert isinstance(compilation_result_0.time, float)
    assert isinstance(compilation_result_0.target, CompilationTarget)
    assert isinstance(compilation_result_0.dependencies, list)


# Generated at 2022-06-25 23:08:12.749589
# Unit test for constructor of class InputOutput
def test_InputOutput():
    result = InputOutput(Path('path'), Path('path'))
    assert isinstance(result, InputOutput)
    assert result.input == Path('path')
    assert result.output == Path('path')


# Generated at 2022-06-25 23:08:15.810815
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('path/to/input.py'), Path('path/to/output.py')).input == Path('path/to/input.py')
    assert InputOutput(Path('path/to/input.py'), Path('path/to/output.py')).output == Path('path/to/output.py')


# Generated at 2022-06-25 23:08:19.246658
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/home/user/sample.py')
    output = Path('/home/user/output.py')
    input_output = InputOutput(input, output)
    assert input_output.input == input and input_output.output == output


# Generated at 2022-06-25 23:08:33.631360
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree_0 = ast.parse('print("Hello!")')
    tree_changed_0 = True
    dependencies_0 = ['stdlib']
    transformation_result_0 = TransformationResult(tree_0, tree_changed_0, dependencies_0)



# Generated at 2022-06-25 23:08:36.179337
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.Module()
    td = [str]
    tr = TransformationResult(tree, False, td)
    assert tr.tree == tree
    assert tr.tree_changed == False
    assert tr.dependencies == td


# Generated at 2022-06-25 23:08:36.911726
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr0 = TransformationResult()

# Generated at 2022-06-25 23:08:39.547982
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result = TransformationResult(
        tree=None, tree_changed=True, dependencies=None)
    assert transformation_result.tree is None
    assert transformation_result.tree_changed is True
    assert transformation_result.dependencies is None


# Generated at 2022-06-25 23:08:40.314986
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_case_0()


# Generated at 2022-06-25 23:08:47.929491
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Check default constructor value
    assert TransformationResult(tree=None, tree_changed=None,
                                dependencies=[]).tree is None
    assert TransformationResult(tree=None, tree_changed=None,
                                dependencies=[]).tree_changed is None
    assert TransformationResult(tree=None, tree_changed=None,
                                dependencies=[]).dependencies == []

    tree = ast.parse("x = 1+2")
    assert TransformationResult(tree=tree, tree_changed=False,
                                dependencies=["dep_0", "dep_1"]).tree == tree
    assert TransformationResult(tree=tree, tree_changed=False,
                                dependencies=["dep_0", "dep_1"]).tree_changed is False

# Generated at 2022-06-25 23:08:51.282680
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(1, 1.0, (1, 2), [])
    assert compilation_result_0.files == 1
    assert compilation_result_0.time == 1.0
    assert compilation_result_0.target == (1, 2)
    assert compilation_result_0.dependencies == []


# Generated at 2022-06-25 23:08:57.277447
# Unit test for constructor of class InputOutput
def test_InputOutput():
    with pytest.raises(ValueError) as err:
        input_output = InputOutput(None, None)
    with pytest.raises(ValueError) as err:
        input_output = InputOutput(Path('/file/in'), None)
    with pytest.raises(ValueError) as err:
        input_output = InputOutput(None, Path('/file/out'))
    input_output = InputOutput(Path('/file/in'), Path('/file/out'))
    assert input_output.input == Path('/file/in')
    assert input_output.output == Path('/file/out')



# Generated at 2022-06-25 23:08:59.901233
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path("input")
    output_path = Path("output")
    input_output = InputOutput(input_path, output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path


# Generated at 2022-06-25 23:09:01.905061
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult()
    assert result.files == 0
    assert result.time == 0.0
    assert result.target == (0, 0)
    assert result.dependencies == []

# Generated at 2022-06-25 23:09:16.123379
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input.txt')
    output = Path('output.txt')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-25 23:09:19.170501
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert compilation_result_0.files == 0
    assert compilation_result_0.time == 0
    assert compilation_result_0.target == 3
    assert compilation_result_0.dependencies == []

# Generated at 2022-06-25 23:09:26.828260
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_1 = CompilationResult(300, 0.5, (3, 2), ['a', 'b'])
    compilation_result_2 = CompilationResult(301, 0.5, (3, 2), ['a', 'b'])
    compilation_result_3 = CompilationResult(300, 0.5, (3, 2), ['a', 'b'])
    compilation_result_4 = CompilationResult(300, 0.6, (3, 2), ['a', 'b'])
    compilation_result_5 = CompilationResult(300, 0.5, (3, 3), ['a', 'b'])
    compilation_result_6 = CompilationResult(300, 0.5, (3, 2), ['a', 'b', 'c'])

    assert compilation_result_1 != compilation_result_2

# Generated at 2022-06-25 23:09:29.277314
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    node = ast.Module([])
    result = TransformationResult(node, False, [])
    assert result.tree == node
    assert not result.tree_changed
    assert result.dependencies == []



# Generated at 2022-06-25 23:09:30.519521
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result = TransformationResult(ast.Module, True, [])
    assert isinstance(transformation_result, TransformationResult)

# Generated at 2022-06-25 23:09:32.442256
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """
    >>> InputOutput(Path('test'), Path('test'))
    InputOutput(input=PosixPath('test'), output=PosixPath('test'))
    """
    pass


# Generated at 2022-06-25 23:09:34.572537
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path = Path('abcd')
    inputoutput = InputOutput(path, path)


# Generated at 2022-06-25 23:09:37.386976
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(ast.AST(), True, [])
    assert t.tree != None
    assert t.tree_changed == True
    assert t.dependencies == []
    assert type(t.tree) == ast.AST
    assert type(t.tree_changed) == bool
    assert type(t.dependencies) == list


# Generated at 2022-06-25 23:09:39.150191
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inputOutput = InputOutput(Path("input"), Path("output"))
    assert isinstance(inputOutput.input, Path)
    assert isinstance(inputOutput.output, Path)



# Generated at 2022-06-25 23:09:41.864559
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("pass")
    tree_changed = False
    dependencies = ['pass']
    res = TransformationResult(tree, tree_changed, dependencies)
    assert res.tree == tree
    assert res.tree_changed == tree_changed
    assert res.dependencies == dependencies

# Generated at 2022-06-25 23:09:56.363104
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=1, time=23.0, target=(2, 7), dependencies=[])


# Generated at 2022-06-25 23:10:00.674923
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('foo'), Path('bar')) == \
           InputOutput(Path('foo'), Path('bar'))
    assert InputOutput(Path('foo'), Path('bar')) != \
           InputOutput(Path('bar'), Path('foo'))
    assert InputOutput(Path('foo'), Path('foo')) != \
           InputOutput(Path('foo'), Path('bar'))


# Generated at 2022-06-25 23:10:04.932089
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Call constructor
    result = CompilationResult(files=1,
                               time=15.0,
                               target=(3, 4),
                               dependencies=['stdlib', 'numpy'])
    # Check values
    assert result.files == 1
    assert result.time == 15.0
    assert result.target == (3, 4)
    assert result.dependencies == ['stdlib', 'numpy']

# Generated at 2022-06-25 23:10:07.155076
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=5, time=5.5, target=(2, 7), dependencies=[])
    assert cr.files == 5
    assert cr.time == 5.5
    assert cr.target == (2, 7)
    assert cr.dependencies == []



# Generated at 2022-06-25 23:10:11.295523
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Test sample input/output pair
    sample = InputOutput('a.py', 'b.py')
    assert sample.input == 'a.py'
    assert sample.output == 'b.py'

    # Test getter for input file
    assert sample.input_file.name == 'a.py'
    assert sample.input_file.is_file()

    # Test getter for output file
    assert sample.output_file.name == 'b.py'
    assert not sample.output_file.is_file()



# Generated at 2022-06-25 23:10:15.118228
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1,
                           time=2.0,
                           target=(33, 44),
                           dependencies=['file1.py', 'file2.py'])
    assert cr.files == 1
    assert cr.time == 2.0
    assert cr.target == (33, 44)
    assert cr.dependencies == ['file1.py', 'file2.py']


# Generated at 2022-06-25 23:10:17.590950
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path('/test/path')
    path2 = Path('/test2/path')
    try:
        InputOutput(path1, path2)
        assert True
    except:
        assert False


# Generated at 2022-06-25 23:10:20.592576
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path_1 = Path('foo')
    path_2 = Path('bar')
    input_output = InputOutput(path_1, path_2)
    assert input_output.input == path_1
    assert input_output.output == path_2
    assert str(input_output) == 'foo -> bar'


# Generated at 2022-06-25 23:10:22.791800
# Unit test for constructor of class InputOutput
def test_InputOutput():
    pair = InputOutput("/a/b", "/c/d")
    assert pair.input == Path("/a/b")
    assert pair.output == Path("/c/d")


# Generated at 2022-06-25 23:10:24.651256
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(1, 1, (3, 4), [])
    assert c.files == 1
    assert c.time == 1
    assert c.target == (3, 4)
    assert c.dependencies == []


# Generated at 2022-06-25 23:10:54.979998
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/a.py')
    output = Path('/tmp/b.py')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-25 23:11:01.947162
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    a = ast.parse('x = 2 + 3')
    r = TransformationResult(a, True, ['file1', 'file2'])
    assert r.tree == a
    assert r.tree_changed
    assert r.dependencies == ['file1', 'file2']

# Generated at 2022-06-25 23:11:04.680394
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=None, tree_changed=True,
                              dependencies=['foo.py'])
    assert tr == TransformationResult(tree=None, tree_changed=True,
                                      dependencies=['foo.py'])

# Generated at 2022-06-25 23:11:07.773737
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(3, 5.3, (2, 5), ['foo', 'bar'])
    assert result.files == 3
    assert result.time == 5.3
    assert result.target == (2, 5)
    assert result.dependencies == ['foo', 'bar']



# Generated at 2022-06-25 23:11:09.642493
# Unit test for constructor of class InputOutput
def test_InputOutput():
    from pathlib import Path
    test = InputOutput(Path('a'), Path('b'))
    assert test.input == Path('a')
    assert test.output == Path('b')

# Generated at 2022-06-25 23:11:12.801576
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/cov_check.py')
    output = Path('/tmp/cov_check.pyc')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output

# Generated at 2022-06-25 23:11:15.419711
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=0, time=0, target=(2, 7), dependencies=[])
    assert res.files == 0
    assert res.time == 0
    assert res.target == (2, 7)
    assert res.dependencies == []


# Generated at 2022-06-25 23:11:17.988816
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test = ast.parse('')
    TransformationResult(test, False, [])
    TransformationResult(test, True, [])
    TransformationResult(test, True, ['1'])
    TransformationResult(test, True, ['1', '2'])

# Generated at 2022-06-25 23:11:20.865043
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('test_input')
    output = Path('test_output')
    p = InputOutput(input, output)
    assert p.input == input, 'input was not correctly set'
    assert p.output == output, 'output was not correctly set'



# Generated at 2022-06-25 23:11:26.296162
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from datetime import datetime

    # Create dummy AST
    ast_tree = ast.parse(datetime.now().isoformat())

    # Create TransformationResult and check if it has the structure defined in
    # the type signature
    transformation_result = TransformationResult(ast_tree, True, [])
    assert transformation_result.tree == ast_tree
    assert transformation_result.tree_changed == True
    assert transformation_result.dependencies == []

# Generated at 2022-06-25 23:12:23.631576
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 2.0, (3, 4), []) == CompilationResult(1, 2.0, (3, 4), [])


# Generated at 2022-06-25 23:12:24.104752
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, None, None)

# Generated at 2022-06-25 23:12:26.568741
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(tree=None,
                                  tree_changed=True,
                                  dependencies=['foo_module', 'bar_module'])
    assert result.tree_changed
    assert 'foo_module' in result.dependencies
    assert 'baz_module' not in result.dependencies

# Generated at 2022-06-25 23:12:29.000711
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1,
                                           time=1.1,
                                           target=(3, 7),
                                           dependencies=['a.py'])
    assert compilation_result.files == 1
    assert compilation_result.time == 1.1
    assert compilation_result.target == (3, 7)
    assert compilation_result.dependencies == ['a.py']


# Generated at 2022-06-25 23:12:32.278745
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    target = CompilationResult(files=42, time=1.0,
                               target=(3, 5),
                               dependencies=['foo.py'])
    assert target.files == 42
    assert target.time == 1.0
    target.target = (2, 7)
    target.dependencies = ['bar.py']
    assert target.target == (2, 7)
    assert target.dependencies == ['bar.py']


# Generated at 2022-06-25 23:12:34.397102
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_data = Path('input.txt')
    output_data = Path('output.txt')
    InputOutput(input_data, output_data)

# Generated at 2022-06-25 23:12:37.050241
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    tree = ast.parse('x = 10')
    assert TransformationResult(tree, True, []).tree_changed is True
    assert TransformationResult(tree, False, []).tree_changed is False
    assert TransformationResult(tree, False, ['a.py']).dependencies == ['a.py']

# Generated at 2022-06-25 23:12:38.731968
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('a')
    out = Path('b')
    p = InputOutput(input=inp, output=out)
    assert p.input == inp
    assert p.output == out

# Generated at 2022-06-25 23:12:42.033432
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('num = 0', '<string>')
    tree_changed = True
    dependencies = []
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies


# Plain string as a name of transformer, to be used in assert statements
TransformerName = str

# Generated at 2022-06-25 23:12:44.155973
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=None, tree_changed=False, dependencies=None)
    assert tr.tree is None
    assert not tr.tree_changed
    assert tr.dependencies is None

# Initializer of class TransformationResult