

# Generated at 2022-06-25 23:03:32.892132
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert(TransformationResult((ast.AST, True, ['dep1', 'dep2'])).tree == ast.AST)
    assert(TransformationResult((ast.AST, True, ['dep1', 'dep2'])).tree_changed == True)
    assert(TransformationResult((ast.AST, True, ['dep1', 'dep2'])).dependencies == ['dep1', 'dep2'])

# Generated at 2022-06-25 23:03:37.208555
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(
        files=3,
        time=2.2,
        target=(2, 3),
        dependencies=['a', 'b', 'c'])
    assert result.files == 3
    assert result.time == 2.2
    assert result.target == (2, 3)
    assert result.dependencies == ['a', 'b', 'c']

# Generated at 2022-06-25 23:03:40.741543
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result = TransformationResult(tree=ast.AST,
                                                 tree_changed=False,
                                                 dependencies=['a', 'b'])
    assert transformation_result.tree_changed == False
    assert transformation_result.dependencies == ['a', 'b']

# Generated at 2022-06-25 23:03:49.942803
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    correct_compilation_result_0 = CompilationResult(5, 3.14, (2, 7), [])
    correct_compilation_result_1 = CompilationResult(75, 0.0001, (3, 6), ['foo.py', 'bar.py'])

    compilation_result_0 = CompilationResult(1, 2, (3, 4), [])
    compilation_result_1 = CompilationResult(1.0, 2.0, (3.0, 4.0), ["foo.py"])
    compilation_result_2 = CompilationResult(1.0, 2, (3.0, 4), ["foo.py", "bar.py"])
    compilation_result_3 = CompilationResult(1, 2.0, (3, 4.0), [])

# Generated at 2022-06-25 23:03:51.301494
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult()


# Generated at 2022-06-25 23:03:53.433830
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    input_output_0 = InputOutput()
    # Type error
    try:
        input_output_0 = InputOutput(input='string')
    except (TypeError):
        pass

# Generated at 2022-06-25 23:04:02.670302
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(0, 0.0, (3, 7), [])
    assert compilation_result_0.files == 0
    assert compilation_result_0.time == 0.0
    assert compilation_result_0.target == (3, 7)
    assert compilation_result_0.dependencies == []
    compilation_result_1 = CompilationResult(0, 0.0, (3, 7), [])
    assert compilation_result_1.files == 0
    assert compilation_result_1.time == 0.0
    assert compilation_result_1.target == (3, 7)
    assert compilation_result_1.dependencies == []
    compilation_result_2 = compilation_result_1
    assert compilation_result_2.files == 0
    assert compilation_result_2.time == 0.0


# Generated at 2022-06-25 23:04:06.025333
# Unit test for constructor of class InputOutput
def test_InputOutput():
    in_0 = InputOutput()
    out_0 = InputOutput(Path("a"), Path("b"))
    assert out_0.input == Path("a")
    assert out_0.output == Path("b")
    assert in_0.input == None
    assert in_0.output == None

# Generated at 2022-06-25 23:04:08.574406
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(
        files=0,
        time=0.0,
        target=(3, 6),
        dependencies=[]
    )


# Generated at 2022-06-25 23:04:09.749690
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult()
    print(compilation_result)

# Generated at 2022-06-25 23:04:16.123577
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result_0 = CompilationResult(0, 0.0, (0, 0), [])
    assert result_0.files == 0
    assert result_0.time == 0.0
    assert result_0.target == (0, 0)
    assert result_0.dependencies == []


# Generated at 2022-06-25 23:04:23.541536
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput(Path('/home/benjamin/workspace/typed_python_compiler/test/'), Path('/home/benjamin/workspace/typed_python_compiler/test/'))
    assert type(input_output_0.input) is Path
    assert input_output_0.input == Path('/home/benjamin/workspace/typed_python_compiler/test/')
    assert type(input_output_0.output) is Path
    assert input_output_0.output == Path('/home/benjamin/workspace/typed_python_compiler/test/')



# Generated at 2022-06-25 23:04:26.182706
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()

    assert input_output_0.input is None
    assert input_output_0.output is None


# Generated at 2022-06-25 23:04:30.592977
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result_0 = CompilationResult(files=1,
                                 time=10,
                                 target=(0, 1),
                                 dependencies=['1', '2'])
    assert result_0.files == 1
    assert result_0.time == 10
    assert result_0.target == (0, 1)
    assert result_0.dependencies == ['1', '2']


# Generated at 2022-06-25 23:04:31.132908
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    test_case_0()

# Generated at 2022-06-25 23:04:40.000154
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput
    assert InputOutput is not None
    assert isinstance(InputOutput, type)
    assert issubclass(InputOutput, tuple)
    assert len(InputOutput.__slots__) == 0
    assert hasattr(InputOutput, '__getitem__')
    assert InputOutput.__doc__ == 'NamedTuple(input, output)'
    assert InputOutput.input.__doc__ == 'Alias for field number 0'
    assert InputOutput.output.__doc__ == 'Alias for field number 1'
    assert InputOutput._fields == ('input', 'output')
    assert InputOutput._field_types == (Path, Path)
    assert InputOutput._field_defaults == (None, None)

    input_output_0 = InputOutput()
    assert input_output_0.input is None
    assert input_output_0

# Generated at 2022-06-25 23:04:49.260971
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 1
    time = 1.1
    target = CompilationTarget(3, 7)
    dependencies = ['a.py', 'b.py', 'c.py']
    result = CompilationResult(files, time, target, dependencies)
    assert isinstance(result, CompilationResult)
    assert result.files == files
    assert result.time == time
    assert result.target == target
    assert result.dependencies == dependencies
    assert result._fields == ['files', 'time', 'target', 'dependencies']
    assert result[0] == files
    assert result[1] == time
    assert result[2] == target
    assert result[3] == dependencies


# Generated at 2022-06-25 23:04:51.875258
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()
    assert input_output_0.input is None
    assert input_output_0.output is None


# Generated at 2022-06-25 23:04:56.863712
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult()
    compilation_result_1 = CompilationResult(
        files=0, time=0.0, target=(0, 0), dependencies=list([]))

    assert compilation_result_0.files == 0
    assert compilation_result_0.time == 0.0
    assert compilation_result_0.target == (0, 0)
    assert compilation_result_0.dependencies == list([])

# Generated at 2022-06-25 23:05:08.744568
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_1 = InputOutput(input=Path('/home/peter/PycharmProjects/compilable/__init__.py'),
                                 output=Path('/tmp/__init__.py'))
    input_output_2 = InputOutput(input=Path('/home/peter/PycharmProjects/compilable/__init__.py'),
                                 output=Path('/tmp/__init__.py'))
    assert input_output_1 == input_output_2
    assert not (input_output_1 != input_output_2)

# Generated at 2022-06-25 23:05:21.497367
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput is not None and InputOutput(input = Path('/Users/dshkolnyy/Documents/python-to-java/pythons/python_samples/input/0.py'), output = Path('/Users/dshkolnyy/Documents/python-to-java/pythons/python_samples/output_java/0.java')) == test_case_0(input = Path('/Users/dshkolnyy/Documents/python-to-java/pythons/python_samples/input/0.py'), output = Path('/Users/dshkolnyy/Documents/python-to-java/pythons/python_samples/output_java/0.java'))

# Generated at 2022-06-25 23:05:27.491350
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult()
    assert isinstance(compilation_result_0, NamedTuple)
    assert compilation_result_0.time == 0.0
    assert compilation_result_0.target == (0,0)
    assert compilation_result_0.files == 0
    assert compilation_result_0.dependencies == []



# Generated at 2022-06-25 23:05:29.317459
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput()
    assert input_output.input is None
    assert input_output.output is None



# Generated at 2022-06-25 23:05:30.501223
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert test_case_0() is not None


# Generated at 2022-06-25 23:05:33.056673
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()
    assert input_output_0.input == None
    assert input_output_0.output == None


# Generated at 2022-06-25 23:05:35.767424
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(
        files=1,
        time=1.0,
        target=(1, 0),
        dependencies=['dep']
    )



# Generated at 2022-06-25 23:05:37.675301
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert hasattr(InputOutput, '__new__')
    instance = InputOutput()
    assert isinstance(instance, InputOutput)


# Generated at 2022-06-25 23:05:41.583964
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    comp = CompilationResult(files=1, time=1.0, target=(1, 1),
                             dependencies=["a", "b"])
    assert comp.files == 1
    assert comp.time == 1.0
    assert comp.target == (1, 1)
    assert comp.dependencies == ["a", "b"]


# Generated at 2022-06-25 23:05:44.482012
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()


# Generated at 2022-06-25 23:05:52.339374
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    comp = CompilationResult(1, 1.0, (3, 7), ["work.py", "cond.py"])
    assert comp.files == 1
    assert comp.time == 1.0
    assert comp.target == (3, 7)
    assert comp.dependencies == ["work.py", "cond.py"]


# Generated at 2022-06-25 23:06:03.018249
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    expected_output_0 = TransformationResult()
    result_0 = TransformationResult()
    assert expected_output_0 == result_0


# Generated at 2022-06-25 23:06:04.160579
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()


# Generated at 2022-06-25 23:06:09.528398
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    input_output_0 = InputOutput()
    source_file_0 = source_file_0 = TransformationResult()
    assert source_file_0.tree == input_output_0
    source_file_0 = source_file_0 = TransformationResult()
    assert source_file_0.tree_changed == input_output_0
    source_file_0 = source_file_0 = TransformationResult()
    assert source_file_0.dependencies == input_output_0

# Generated at 2022-06-25 23:06:10.756102
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert (CompilationResult(0, 0, (3, 4), []) ==
            CompilationResult(0, 0, target=(3, 4), dependencies=[]))


# Generated at 2022-06-25 23:06:14.544804
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(1, 2.0, (3, 4), ['a', 'b'])
    assert c.files == 1
    assert c.time == 2.0
    assert c.target == (3, 4)
    assert c.dependencies == ['a', 'b']


# Generated at 2022-06-25 23:06:15.764883
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()


# Generated at 2022-06-25 23:06:20.611693
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Testing constructor with keyword arguments
    test_obj = CompilationResult(files=1, time=1.0, target=(1, 2), dependencies=['test_file'])
    # test_obj.files     is   1
    # test_obj.time      is   1.0
    # test_obj.target    is   (1, 2)
    # test_obj.dependencies is ['test_file']


# Generated at 2022-06-25 23:06:22.073473
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 1.0, (2, 7), [])


# Generated at 2022-06-25 23:06:27.969624
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Test attributes
    TransformationResult.tree  # type: ast.AST
    TransformationResult.tree_changed  # type: bool
    TransformationResult.dependencies  # type: List[str]

    # Test constructor
    result = TransformationResult(ast.parse('None'),
                                  False,
                                  [])
    assert result.tree is not None
    assert not result.tree_changed
    assert result.dependencies == []



# Generated at 2022-06-25 23:06:29.310296
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    try:
        result = TransformationResult(ast.parse('3 * 4', '<ast>'), True, [])
    except Exception:
        assert False
    finally:
        assert True



# Generated at 2022-06-25 23:06:48.400621
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()


# Generated at 2022-06-25 23:06:52.993190
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=None, tree_changed=True, dependencies=[])
    assert isinstance(TransformationResult(tree=None, tree_changed=True, dependencies=[]), TransformationResult)
    assert TransformationResult(tree=None, tree_changed=True, dependencies=[]).tree == None
    assert TransformationResult(tree=None, tree_changed=True, dependencies=[]).tree_changed == True
    assert TransformationResult(tree=None, tree_changed=True, dependencies=[]).dependencies == []


# Generated at 2022-06-25 23:06:53.710751
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult()


# Generated at 2022-06-25 23:06:55.590434
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-25 23:06:58.558818
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilationResult = CompilationResult(
        files=1, time=2.2, target=(3, 4), dependencies=['file1.py', 'file2.py']
    )
    assert compilationResult


# Generated at 2022-06-25 23:07:02.801531
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0,
                               target=(3, 7),
                               dependencies=['file.py'])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 7)
    assert result.dependencies == ['file.py']



# Generated at 2022-06-25 23:07:06.222034
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert isinstance(test_case_0().input, Path)
    assert test_case_0().input == Path('')
    assert isinstance(test_case_0().output, Path)
    assert test_case_0().output == Path('')

# Test for constructor of class TransformationResult

# Generated at 2022-06-25 23:07:07.976000
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Generate instance of class InputOutput
    input_output_0 = InputOutput()
    assert isinstance(input_output_0, InputOutput)



# Generated at 2022-06-25 23:07:11.583733
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    input_output_0 = InputOutput()
    input_output_0.input = Path('/usr/local/bin')
    input_output_0.output = Path('/usr/local/lib')
    transformation_result_0 = TransformationResult(
        input_output_0.input, True, [])

# Generated at 2022-06-25 23:07:13.448147
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree_0 = TransformationResult((ast.parse, False, 'dependencies_0'))
    assert tree_0 == (ast.parse, False, 'dependencies_0')


# Generated at 2022-06-25 23:07:37.084387
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput(Path(""), Path(""))
    assert_equal(input_output_0.input, Path(""))
    assert_equal(input_output_0.output, Path(""))
    return


# Generated at 2022-06-25 23:07:47.738289
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Check proper initialization
    tree_0 = ast.parse('a = 1', '<string>', 'exec')
    assert TransformationResult(tree_0, True, ['b']).tree == tree_0
    assert TransformationResult(tree_0, True, ['b']).tree_changed == True
    assert TransformationResult(tree_0, True, ['b']).dependencies == ['b']

    # Check for default values of optional arguments
    assert TransformationResult(tree_0, True, ['b']).tree == tree_0
    assert TransformationResult(tree_0, True, ['b']).tree_changed == True
    assert TransformationResult(tree_0, True, ['b']).dependencies == ['b']



# Generated at 2022-06-25 23:07:51.418689
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(2, 3.1, (0, 1), ['a', 'b'])
    assert compilation_result_0.files == 2
    assert compilation_result_0.time == 3.1
    assert compilation_result_0.target == (0, 1)
    assert compilation_result_0.dependencies == ['a', 'b']


# Generated at 2022-06-25 23:07:53.310406
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()
    assert input_output_0.input == None
    assert input_output_0.output == None


# Generated at 2022-06-25 23:07:56.199379
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    """
    Test the constructor of class TransformationResult
    """
    result = TransformationResult(ast.AST(), True, [])
    assert(result.tree_changed is True)


# Generated at 2022-06-25 23:07:57.278758
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()


# Generated at 2022-06-25 23:08:01.506704
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Instantiate an object of class CompilationResult
    compilation_result_0 = CompilationResult()
    # Access its attribute files
    compilation_result_0.files
    # Access its attribute time
    compilation_result_0.time
    # Access its attribute target
    compilation_result_0.target
    # Access its attribute dependencies
    compilation_result_0.dependencies


# Generated at 2022-06-25 23:08:08.843203
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Example of a.py file
    a_code = '''def go(a): print(a)'''
    # Extracting AST tree
    a_tree = ast.parse(a_code)
    # Example of source code in b.py
    b_code = '''from a import go
          go(1)'''
    b_tree = ast.parse(b_code)
    # Example of the compilation result
    compilation_result = CompilationResult(
        files=2,
        time=0.5,
        target=(3, 6),
        dependencies=["a.py"]
    )
    out_file = open("out_test.py", "w")
    ast.fix_missing_locations(a_tree)
    ast.fix_missing_locations(b_tree)
    out_file.write

# Generated at 2022-06-25 23:08:10.229367
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()
    assert isinstance(input_output_0, InputOutput)

# Generated at 2022-06-25 23:08:14.269192
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_1 = InputOutput(Path('.'), Path('.'))
    assert input_output_1.input == Path('.')
    assert input_output_1.output == Path('.')

    input_output_2 = InputOutput(Path('.'), Path('.'))
    assert input_output_2.input == Path('.')
    assert input_output_2.output == Path('.')


# Generated at 2022-06-25 23:09:03.482135
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()


# Generated at 2022-06-25 23:09:08.772389
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    module_0 = ast.Module()
    tree_0 = TransformationResult(tree=module_0, tree_changed=True, dependencies=list())
    assert tree_0.tree == module_0
    assert tree_0.tree_changed == True
    assert tree_0.dependencies == list()
    module_1 = ast.Module()
    tree_1 = TransformationResult(tree=module_1, tree_changed=False, dependencies=list())
    assert tree_1.tree == module_1
    assert tree_1.tree_changed == False
    assert tree_1.dependencies == list()

# Generated at 2022-06-25 23:09:15.571965
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    import ast
    import typed_ast.ast3 as ast3
    assert ast3.TransformationResult is TransformationResult
    assert issubclass(TransformationResult, NamedTuple)
    input_output_0 = InputOutput(input=Path('/tmp/py3/test.py'), output=Path('/tmp/py3/test.pyc'))
    input_output_1 = InputOutput(input=Path('/tmp/py3/test.py'), output=Path('/tmp/py3/test.pyc'))
    input_output_2 = InputOutput(input=Path('/tmp/py3/test.py'), output=Path('/tmp/py3/test.pyc'))

# Generated at 2022-06-25 23:09:18.283673
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert test_case_0().input_output_0.input.is_file()
    assert test_case_0().input_output_0.output.is_file()

# Generated at 2022-06-25 23:09:22.451918
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput(input=Path("compiler/tests/0/input.py"), output=Path("compiler/tests/0/output.py"))
    assert_that(input_output_0.input, is_(Path("compiler/tests/0/input.py")))
    assert_that(input_output_0.output, is_(Path("compiler/tests/0/output.py")))



# Generated at 2022-06-25 23:09:23.680839
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()


# Generated at 2022-06-25 23:09:25.852010
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path("123"), Path("456"))
    assert input_output.input == Path("123")
    assert input_output.output == Path("456")



# Generated at 2022-06-25 23:09:30.699348
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(1,
                                             1.1,
                                             (2, 3),
                                             ['string_0',
                                              'string_1'])

    assert compilation_result_0.files == 1
    assert compilation_result_0.time == 1.1
    assert compilation_result_0.target == (2, 3)
    assert compilation_result_0.dependencies == ['string_0',
                                                 'string_1']



# Generated at 2022-06-25 23:09:33.485206
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    module = ast.parse('import sys')
    tree = TreeModule(ast.AST)
    tree_changed = bool
    dependencies = List[str]
    result = TransformationResult(module, tree_changed, dependencies)
    assert result.tree == module


# Generated at 2022-06-25 23:09:34.643166
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult()


# Generated at 2022-06-25 23:11:23.438230
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(
        files=0,
        time=0.0,
        target=(1, 0),
        dependencies=[]
    )


# Generated at 2022-06-25 23:11:31.974142
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Test 1: with no parameters
    res = CompilationResult()
    assert res.files == 0
    assert res.time == 0
    assert res.target == (3, 7)
    assert res.dependencies == []

    # Test 2: only files
    res = CompilationResult(1)
    assert res.files == 1
    assert res.time == 0
    assert res.target == (3, 7)
    assert res.dependencies == []

    # Test 3: only files and time
    res = CompilationResult(1, 0.12)
    assert res.files == 1
    assert res.time == 0.12
    assert res.target == (3, 7)
    assert res.dependencies == []

    # Test 4: only files, time and target

# Generated at 2022-06-25 23:11:35.701108
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(1, 0.0, (3, 5), ['python', 'ast'])
    assert compilation_result_0[0] == 1
    assert compilation_result_0[1] == 0.0
    assert compilation_result_0[2] == (3, 5)
    assert compilation_result_0[3] == ['python', 'ast']


# Generated at 2022-06-25 23:11:37.854171
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert_equal(InputOutput().__class__, InputOutput)
    assert_equal(InputOutput('').__class__, InputOutput)
    assert_equal(InputOutput('foo').__class__, InputOutput)


# Generated at 2022-06-25 23:11:42.213030
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    input_output_0 = InputOutput()
    transformation_result_0 = TransformationResult(
        input_output_0, bool, list(str))
    tree = transformation_result_0.tree
    tree_changed = transformation_result_0.tree_changed
    dependencies = transformation_result_0.dependencies
    assert isinstance(tree, Path)
    assert isinstance(tree_changed, bool)
    assert isinstance(dependencies, List[str])


test_TransformationResult()


# Generated at 2022-06-25 23:11:45.509311
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    import unittest

    class TestCompilationResult(unittest.TestCase):
        def test_constructor(self):
            CompilationResult(1, 1.0, (1,2), ["foo"])
    unittest.main()


# Generated at 2022-06-25 23:11:48.932083
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr_0 = CompilationResult(files=1, time=1.1, target=(3, 4), dependencies=["str_0"])
    assert cr_0.files == 1
    assert cr_0.time == 1.1
    assert cr_0.target == (3, 4)
    assert cr_0.dependencies == ["str_0"]


# Generated at 2022-06-25 23:11:51.788795
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    a = CompilationResult(files=1, time=1, target=(1,1), dependencies=['a'])
    assert a.files == 1
    assert a.time == 1
    assert a.target == (1, 1)
    assert a.dependencies == ['a']


# Generated at 2022-06-25 23:11:56.484953
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    """Test for constructor of class TransformationResult
    """
    # Parameters
    tree = "ast"
    tree_changed = True
    dependencies = [
        "test1",
        "test2",
        "test3"
    ]
    # Object creation
    obj = TransformationResult(
        tree = tree,
        tree_changed = tree_changed,
        dependencies = dependencies
    )
    # Asserts
    assert obj.tree == "ast"
    assert obj.tree_changed == True
    assert obj.dependencies == [
        "test1",
        "test2",
        "test3"
    ]


# Generated at 2022-06-25 23:11:57.055994
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()

