

# Generated at 2022-06-25 23:03:37.365090
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    input_output_0 = InputOutput(Path('.'), Path('/tmp'))
    input_outputs = [input_output_0]
    result = CompilationResult(100, 1.0, (39, 0), ['bz2'])
    assert result.files == 100
    assert result.time == 1.0
    assert result.target == (39, 0)
    assert result.dependencies == ['bz2']


# Generated at 2022-06-25 23:03:45.269066
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=0,
                               time=0,
                               target=(0, 0),
                               dependencies=[])

    assert isinstance(result.files, int), \
           "The type of instance variable result.files should be int"

    assert isinstance(result.time, float), \
           "The type of instance variable result.time should be float"

    assert isinstance(result.target, CompilationTarget), \
           "The type of instance variable result.target should be CompilationTarget"

    assert isinstance(result.dependencies, list), \
           "The type of instance variable result.dependencies should be list"



# Generated at 2022-06-25 23:03:46.570620
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()


# Generated at 2022-06-25 23:03:48.388112
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 1, (3, 6), ["dep1", "dep2"]) is not None


# Generated at 2022-06-25 23:03:56.334187
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Test for different value types
    with pytest.raises(TypeError):
        result = TransformationResult('abc', 1.5, [])
    with pytest.raises(TypeError):
        result = TransformationResult(ast.Str('abc'), 'a', [])
    with pytest.raises(TypeError):
        result = TransformationResult(ast.Str('abc'), 1.5, {})
    with pytest.raises(TypeError):
        result = TransformationResult(ast.Str('abc'), 1.5, 1)

    # Test for value correctness
    result = TransformationResult(ast.Str('abc'), 1, [])

    assert result.tree_changed is True and result.dependencies == [] and result.tree.s == 'abc'


# Generated at 2022-06-25 23:04:00.556746
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput(Path(""), Path(""))
    input_output_0 = InputOutput(Path(""), (Path("")))  # type: ignore
    input_output_0 = InputOutput(Path(""), Path(""))
    input_output_0 = InputOutput(Path(""), Path(""))


# Generated at 2022-06-25 23:04:06.790748
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    input_output_1 = InputOutput(input=Path('/home/pktm/Projects/python-conditional-compilation/tests/test.py'), output=Path('/home/pktm/Projects/python-conditional-compilation/tests/test.py'))
    test_case_1 = TransformationResult(tree=ast.parse(input_output_1.input.read_text()), tree_changed=False, dependencies=['/home/pktm/Projects/python-conditional-compilation/tests/test.py'])


# Generated at 2022-06-25 23:04:10.500706
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # test constructor
    try:
        compilation_result_0 = CompilationResult(1, 5.0, (3, 7), [])
        pass
    except NameError as e:
        print('Exception : ' + str(e))
        error = True
    assert(error is False)


# Generated at 2022-06-25 23:04:12.274168
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()
    assert input_output_0.input == None
    assert input_output_0.output == None


# Generated at 2022-06-25 23:04:14.148029
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(tree=None, tree_changed=True, dependencies=[])


# Generated at 2022-06-25 23:04:17.237406
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert(True)


# Generated at 2022-06-25 23:04:21.982376
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Creating object
    obj = TransformationResult(tree = ast.Module(body = []),
                               tree_changed = False,
                               dependencies = [])

    # Checking types
    assert isinstance(obj.tree, ast.AST)
    assert isinstance(obj.tree_changed, bool)
    assert isinstance(obj.dependencies, list)



# Generated at 2022-06-25 23:04:28.633236
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result_0 = CompilationResult()
    assert result_0.files == 0
    assert result_0.time == 0
    assert result_0.target == (0, 0)
    assert result_0.dependencies == []
    result_1 = CompilationResult(files = 1, time = 1.1, target = (3, 4), dependencies = ["abc"])
    assert result_1.files == 1
    assert result_1.time == 1.1
    assert result_1.target == (3, 4)
    assert result_1.dependencies == ["abc"]


# Generated at 2022-06-25 23:04:32.983834
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    input_output_0 = InputOutput(
        input='/a/path',
        output='/a/path/'
    )

    try:
        TransformationResult(
            tree=ast.parse(open(input_output_0.input).read()),
            tree_changed=False,
            dependencies=[]
        )
    except Exception:
        raise AssertionError('transformer.TransformationResult constructor raised Exception unexpectedly!')



# Generated at 2022-06-25 23:04:34.636017
# Unit test for constructor of class InputOutput
def test_InputOutput():
    s = InputOutput(Path('/'), Path('/'))
    assert isinstance(s, InputOutput)


# Generated at 2022-06-25 23:04:39.324365
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("print(1)")
    tree_changed = True
    dependencies = []
    res = TransformationResult(tree = tree, tree_changed = tree_changed, dependencies = dependencies)
    assert res.tree == tree
    assert res.tree_changed == tree_changed
    assert res.dependencies == dependencies


# Generated at 2022-06-25 23:04:49.699773
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    target_1 = (3, 5)
    dependencies_1 = ['dependency 1', 'dependency 2']
    input_output_0 = CompilationResult(2, 1, target_1, dependencies_1)
    input_output_1 = CompilationResult(2, 1, target_1, dependencies_1)
    input_output_2 = CompilationResult(2, 1, target_1, dependencies_1)
    input_output_3 = CompilationResult(2, 1, target_1, dependencies_1)
    input_output_4 = CompilationResult(2, 1, target_1, dependencies_1)
    input_output_5 = CompilationResult(2, 1, target_1, dependencies_1)
    input_output_6 = CompilationResult(2, 1, target_1, dependencies_1)
    input_output

# Generated at 2022-06-25 23:04:52.910360
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test_vars = []
    for test_var in [test_case_0()]:
        test_vars.append(test_var)
    for input_output in test_vars:
        TransformationResult(*input_output)

# Generated at 2022-06-25 23:04:56.619049
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    input_output_0 = InputOutput()
    result = TransformationResult(input_output_0.output, False, ["Hello"])
    assert result.tree==input_output_0.output
    assert result.tree_changed==False
    assert result.dependencies==["Hello"]


# Generated at 2022-06-25 23:04:58.918258
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_1 = InputOutput(Path('input'), Path('output'))


# Generated at 2022-06-25 23:05:11.250495
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Type check
    TransformationResult(tree=ast.parse(''),
                         tree_changed=False,
                         dependencies=[])

    # Value check
    assert TransformationResult(tree=ast.parse(''),
                                tree_changed=False,
                                dependencies=[]) \
        == TransformationResult(tree=ast.parse(''),
                                tree_changed=False,
                                dependencies=[])
    assert TransformationResult(tree=ast.parse(''),
                                tree_changed=False,
                                dependencies=[]) \
        != TransformationResult(tree=ast.parse('pass'),
                                tree_changed=False,
                                dependencies=[])

# Generated at 2022-06-25 23:05:15.239457
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path("/path/to/input")
    output = Path("/path/to/output")
    input_output = InputOutput(input, output)

    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-25 23:05:18.887052
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path("input")
    output = Path("output")
    input_output = InputOutput(input_, output)

    assert input_output.input == input_
    assert input_output.output == output


# Generated at 2022-06-25 23:05:23.203869
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, True, None).tree is None
    assert TransformationResult(None, True, None).tree_changed is True
    assert TransformationResult(None, True, None).dependencies is None


# Results of compilation of each file
Results = NamedTuple('Results', [('succeeded', List[CompilationResult]),
                                 ('failed', List[CompilationResult])])

# Generated at 2022-06-25 23:05:26.634083
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('i_path')
    output = Path('o_path')
    test = InputOutput(input, output)
    assert test.input == input
    assert test.output == output

# Generated at 2022-06-25 23:05:30.606123
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation = CompilationResult(1, 1.1, (3, 5), [])
    assert isinstance(compilation.files, int)
    assert isinstance(compilation.time, float)
    assert isinstance(compilation.target, CompilationTarget)
    assert isinstance(compilation.dependencies, List[str])


# Generated at 2022-06-25 23:05:31.421675
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    pass


# Generated at 2022-06-25 23:05:36.260349
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=1.0, target=(3, 5), dependencies=[])
    assert cr.files == 1
    assert cr.time == 1.0
    assert cr.target == (3, 5)
    assert cr.dependencies == []
    with pytest.raises(AttributeError):
        cr.non_existent


# Generated at 2022-06-25 23:05:39.950586
# Unit test for constructor of class InputOutput
def test_InputOutput():
    in_file = Path.cwd() / "file.py"
    out_file = Path.cwd() / "file.pyi"
    t = InputOutput(in_file, out_file)
    assert t.input == in_file
    assert t.output == out_file



# Generated at 2022-06-25 23:05:40.780649
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.AST(), False, [])

# Generated at 2022-06-25 23:05:47.991058
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(Path(), Path())


# Generated at 2022-06-25 23:05:53.469248
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=2.3, target=(3, 4),
                               dependencies=["a", "b"])
    assert(result.files == 1)
    assert(result.time == 2.3)
    assert(result.target == (3, 4))
    assert(result.dependencies == ["a", "b"])



# Generated at 2022-06-25 23:05:57.306937
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(input=Path('input.py'), output=Path('output.py'))
    assert input_output.input == Path('input.py')
    assert input_output.output == Path('output.py')

# Generated at 2022-06-25 23:06:01.080342
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    def test():
        x = Path('a')
        y = Path('b')
        r = TransformationResult(x, y, [])
        assert r.tree == x and r.tree_changed == y and r.dependencies == []
        return True


if __name__ == '__main__':
    test_TransformationResult()

# Generated at 2022-06-25 23:06:03.325945
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert isinstance(TransformationResult.tree, ast.AST)
    assert isinstance(TransformationResult.tree_changed, bool)
    assert isinstance(TransformationResult.dependencies, list)

# Generated at 2022-06-25 23:06:07.155584
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(2, 0.05, (3, 7), ['random.py', 'foo.py'])
    assert cr.files == 2
    assert cr.time == 0.05
    assert cr.target == (3, 7)
    assert cr.dependencies == ['random.py', 'foo.py']


# Generated at 2022-06-25 23:06:10.986059
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    comp = CompilationResult(files=1,
                             time=1.2,
                             target=(3, 4),
                             dependencies=['foo'])
    assert comp.files == 1
    assert comp.time == 1.2
    assert comp.target == (3, 4)
    assert comp.dependencies == ['foo']


# Generated at 2022-06-25 23:06:14.955570
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    t = CompilationResult(1, 2.0, (3, 4), ['a', 'b'])
    assert t.files == 1
    assert t.time == 2.0
    assert t.target == (3, 4)
    assert t.dependencies == ['a', 'b']


# Generated at 2022-06-25 23:06:16.874634
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(tree=None, tree_changed=False, dependencies=[])
    assert result.tree is None
    assert result.tree_changed == False
    assert result.dependencies == []

# Generated at 2022-06-25 23:06:21.522283
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('foo/bar')
    output = Path('baz/qux')
    io = InputOutput(input_, output)
    assert io.input == input_
    assert io.output == output
    with pytest.raises(TypeError):
        InputOutput(output, input_)
    with pytest.raises(TypeError):
        InputOutput(output, input_)

# Generated at 2022-06-25 23:06:31.953817
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(Path('in'), Path('out'))
    assert True

if __name__ == "__main__":
    import subprocess
    subprocess.call(['pytest', __file__])

# Generated at 2022-06-25 23:06:34.099931
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('foo/foo.py'), Path('foo/__pycache__/foo.pyc'))


# Generated at 2022-06-25 23:06:36.030096
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=None, tree_changed=False, dependencies=None)
    assert isinstance(tr, TransformationResult)

# Generated at 2022-06-25 23:06:45.956129
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Type checks
    CompilationResult(files=0, time=0.0, target=(3, 5), dependencies=[])
    CompilationResult(files=0, time=0.0, target=(3, 5), dependencies=['a', 'b'])
    CompilationResult(files=0, time=0.0, target=(3, 5), dependencies=None)
    # Value checks
    with pytest.raises(TypeError):
        CompilationResult(files='a', time=0.0, target=(3, 5), dependencies=[])
    with pytest.raises(ValueError):
        CompilationResult(files=-1, time=0.0, target=(3, 5), dependencies=[])

# Generated at 2022-06-25 23:06:47.115759
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput('foo', 'bar') == ('foo', 'bar')


# Generated at 2022-06-25 23:06:49.259837
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a'), Path('b')).input == Path('a')
    assert InputOutput(Path('a'), Path('b')).output == Path('b')


# Generated at 2022-06-25 23:06:55.094824
# Unit test for constructor of class InputOutput
def test_InputOutput():
    import tempfile
    import os
    input_ = Path(tempfile.mkstemp()[1])
    output = Path(tempfile.mkstemp()[1])
    assert not os.path.exists(input_)
    assert not os.path.exists(output)
    with open(input_, 'w') as f:
        f.write('0')
    with open(output, 'w') as f:
        f.write('1')
    x = InputOutput(input_, output)
    assert x.input.suffix == '.py'
    assert x.output.suffix == '.py'
    assert os.path.exists(x.input)
    assert os.path.exists(x.output)
    os.remove(x.input)
    os.remove(x.output)
   

# Generated at 2022-06-25 23:06:59.246892
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('a'), Path('b'))
    assert input_output.input == Path('a')
    assert input_output.output == Path('b')

    input_output = InputOutput(1, 2)
    assert input_output.input == 1
    assert input_output.output == 2


# Generated at 2022-06-25 23:07:00.992585
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(
        tree=ast.parse('def f(): pass'), tree_changed=False,
        dependencies=['a', 'b'])

# Generated at 2022-06-25 23:07:04.860500
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 1.0, (3, 4), [])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 4)
    assert result.dependencies == []


# Generated at 2022-06-25 23:07:31.757531
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    tr = TransformationResult(tree, False, ['b'])
    assert tr.tree == tree
    assert tr.tree_changed == False
    assert tr.dependencies == ['b']

# Generated at 2022-06-25 23:07:34.410932
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_ = ast.parse("1+1")
    result = TransformationResult(ast_, True, [])
    assert result.tree == ast_
    assert result.tree_changed == True
    assert result.dependencies == []


# Generated at 2022-06-25 23:07:38.207982
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(ast.Expr(), True, [])
    assert result.tree_changed


# Result of transformer creating
TransformerCreateResult = NamedTuple('TransformerCreateResult',
                                     [('transformer', ast.AST),
                                      ('dependencies', List[str])])


# Generated at 2022-06-25 23:07:39.894988
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # pylint: disable=C0111
    TransformationResult(ast.parse('pass'), True, [])

# Generated at 2022-06-25 23:07:49.241171
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res1 = TransformationResult(tree=None, tree_changed=False, dependencies=[])
    assert len(res1.dependencies) == 0
    assert res1.tree is None
    assert res1.tree_changed is False

    res2 = TransformationResult(tree=ast.Name(id='test'), tree_changed=True, dependencies=['dep1'])
    assert len(res2.dependencies) == 1
    assert res2.dependencies[0] == 'dep1'
    assert isinstance(res2.tree, ast.AST)
    assert res2.tree_changed is True

# Compiles input-output pairs with given target

# Generated at 2022-06-25 23:07:51.149764
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    x = TransformationResult(tree, True, [])
    x = TransformationResult(tree, False, [])


# Generated at 2022-06-25 23:07:52.342487
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input=Path('foo'), output=Path('bar'))

# Generated at 2022-06-25 23:07:59.479617
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    a = ast.AST()
    a.body = [ast.Expr(ast.Call(ast.Name('print', ast.Load()), [ast.Str('Hello')], []))]
    a.body.append(ast.Expr(ast.Call(ast.Name('print', ast.Load()), [a.body[0].value.args[0]], [])))

    tr = TransformationResult(a, False, ['tmp', '/some/file'])
    assert tr.tree is not None
    assert tr.tree_changed is False
    assert tr.dependencies == ['tmp', '/some/file']



# Generated at 2022-06-25 23:08:01.055164
# Unit test for constructor of class InputOutput
def test_InputOutput():
    Path = Path
    assert isinstance(InputOutput(Path('a'), Path('b')), InputOutput)

# Generated at 2022-06-25 23:08:02.711934
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(1, 1), dependencies=['a'])


# Generated at 2022-06-25 23:08:52.738014
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/a.py')
    output = Path('/tmp/a.pyc')
    pair = InputOutput(input, output)
    assert pair.input == input
    assert pair.output == output
    assert pair == InputOutput(input, output)
    assert pair != InputOutput(output, input)
    assert pair != OutputOutput(input, output)
    assert hash(pair)

# Generated at 2022-06-25 23:08:56.788537
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    """
    Checks that constructor of class TransformationResult works.
    """
    # pylint: disable=protected-access
    result = TransformationResult(
        ast.Module([]), True, ['a.py', 'b.py'])
    assert result.tree_changed is True
    assert isinstance(result.tree, ast.Module)
    assert result.dependencies == ['a.py', 'b.py']

# Generated at 2022-06-25 23:08:59.216064
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('input')
    output_path = Path('output')
    io = InputOutput(input_path, output_path)
    assert io.input == input_path
    assert io.output == output_path


# Generated at 2022-06-25 23:09:01.233868
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('foo')
    output = Path('bar')
    pair = InputOutput(input, output)

    assert input == pair.input
    assert output == pair.output


# Generated at 2022-06-25 23:09:07.589880
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('self'), Path('other')) == \
           InputOutput(Path('self'), Path('other'))

    assert InputOutput(Path('self'), Path('other')) != \
           InputOutput(Path('self'), Path('self'))

    assert InputOutput(Path('self'), Path('other')) != \
           InputOutput(Path('other'), Path('other'))

    assert InputOutput(Path('self'), Path('other')) != \
           InputOutput(Path('other'), Path('self'))

    assert InputOutput(Path('self'), Path('other')) != \
           InputOutput(Path('other'), Path('another'))


# Generated at 2022-06-25 23:09:08.872695
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert isinstance(TransformationResult(ast.AST(),
                                           False,
                                           []),
                      TransformationResult)

# Generated at 2022-06-25 23:09:10.907793
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(tree=None,
                                  tree_changed=False,
                                  dependencies=[])
    assert result.tree is None
    assert not result.tree_changed
    assert result.dependencies == []

# Generated at 2022-06-25 23:09:12.789461
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(None, True, [])
    assert res.tree is None
    assert res.tree_changed is True
    assert res.dependencies == []

# Generated at 2022-06-25 23:09:15.539809
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=0, time=0.0, target=(0, 0),
                               dependencies=[])
    assert result.files == 0
    assert result.time == 0.0
    assert result.target == (0, 0)
    assert result.dependencies == []


# Generated at 2022-06-25 23:09:16.515769
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(Path('foo'), Path('bar'))


# Generated at 2022-06-25 23:11:02.788168
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=0, time=0, target=(3, 7), dependencies=None)


# Generated at 2022-06-25 23:11:06.901065
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=0.1, target=(2, 7), dependencies=['file.py'])
    expected = """
    CompilationResult(files=1,
                      time=0.1,
                      target=(2, 7),
                      dependencies=['file.py'])
    """
    assert  str(cr) == textwrap.dedent(expected).lstrip()

# Generated at 2022-06-25 23:11:10.707867
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # CompilationResult has fields 'files', 'time', 'target', 'dependencies'
    res = CompilationResult(files=123,
                            time=0.1,
                            target=(3, 7),
                            dependencies=[])
    assert res.files == 123
    assert res.time == 0.1
    assert res.target == (3, 7)
    assert res.dependencies == []


# Generated at 2022-06-25 23:11:14.325027
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1,
                               target=(3, 6),
                               dependencies=['test.txt'])

    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 6)
    assert result.dependencies == ['test.txt']


# Generated at 2022-06-25 23:11:17.701500
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files = 1,
                           time = 0.1,
                           target = (3, 5),
                           dependencies = ['foo', 'bar'])
    assert cr.files == 1
    assert cr.time == 0.1
    assert cr.target == (3, 5)
    assert cr.dependencies == ['foo', 'bar']


# Generated at 2022-06-25 23:11:20.604801
# Unit test for constructor of class InputOutput
def test_InputOutput():
    in_ = Path('/home/user') / 'file.py'
    out = Path('/home/user') / 'file.pyc'
    assert InputOutput(in_, out).input == in_
    assert InputOutput(in_, out).output == out


# Generated at 2022-06-25 23:11:22.334777
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # pylint: disable=unused-argument
    CompilationResult(42, 42.0, (3, 6), [])


# Generated at 2022-06-25 23:11:24.828873
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('i'), Path('o'))
    assert input_output.input == Path('i')
    assert input_output.output == Path('o')


# Generated at 2022-06-25 23:11:27.377934
# Unit test for constructor of class InputOutput
def test_InputOutput():
    try:
        InputOutput()
    except Exception:
        pass
    else:
        assert False, 'InputOutput should be a namedtuple'


# Generated at 2022-06-25 23:11:29.710474
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files = 0,
                           time = 0.0,
                           target = (3, 6),
                           dependencies = [])
    assert isinstance(cr, CompilationResult)
