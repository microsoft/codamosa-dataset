

# Generated at 2022-06-25 23:03:33.728759
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput(Path('input_path_0.py'), Path('output_path_0.py'))
    assert input_output_0.input == Path('input_path_0.py')
    assert input_output_0.output == Path('output_path_0.py')


# Generated at 2022-06-25 23:03:35.721764
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    input_output_0 = InputOutput()
    ast.AST()
    TransformationResult(input_output_0, 1, input_output_0)


# Generated at 2022-06-25 23:03:37.533647
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    input_output_0 = test_case_0()
    assert (input_output_0.input == input_output_0.output)


# Generated at 2022-06-25 23:03:39.670276
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()
    assert input_output_0.input is None
    assert input_output_0.output is None



# Generated at 2022-06-25 23:03:43.258666
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    input_output_0 = InputOutput()
    arg_0 = 'foo'
    arg_1 = 'foo'
    arg_2 = 'foo'
    # No exception
    TransformationResult(arg_0, arg_1, arg_2)
    TransformationResult(input_output_0)



# Generated at 2022-06-25 23:03:45.228107
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()


# Generated at 2022-06-25 23:03:46.213569
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_1 = InputOutput()

# Generated at 2022-06-25 23:03:47.380904
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()
    

# Generated at 2022-06-25 23:03:50.857306
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.AST()
    tree_changed = True
    dependencies = list()

    transformation_result = TransformationResult(tree, tree_changed, dependencies)
    assert transformation_result.tree == tree
    assert transformation_result.tree_changed == tree_changed
    assert transformation_result.dependencies == dependencies


# Generated at 2022-06-25 23:03:53.631144
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree_0 = ast.AST()
    tree_changed_0 = bool()
    dependencies_0 = List[str]()
    tmp_var_0 = TransformationResult(tree_0, tree_changed_0, dependencies_0)

# Generated at 2022-06-25 23:04:04.672186
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Check constructor with all NamedTuple inputs
    test_result_0 = CompilationResult(files=2, time=2.0, target=(1, 2),
                                      dependencies=["a/b", "a/c/d"])

    if (test_result_0.files != 2
            or test_result_0.time != 2.0
            or test_result_0.target != (1, 2)
            or test_result_0.dependencies != ["a/b", "a/c/d"]):
        raise AssertionError

    # Check constructor with all NamedTuple inputs that are empty
    test_result_1 = CompilationResult()


# Generated at 2022-06-25 23:04:05.800436
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
  assert CompilationResult(1, 1, (1, 1), ['1']).time == 1

# Generated at 2022-06-25 23:04:07.282733
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Execute constructor
    test_case_0()


# Generated at 2022-06-25 23:04:12.111578
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_1 = InputOutput(Path('samples', 'samples_input_0.py'),
                                 Path('samples', 'samples_output_0.py'))
    input_output_2 = InputOutput(input=Path('samples', 'samples_input_0.py'),
                                 output=Path('samples', 'samples_output_0.py'))
    if input_output_1 != input_output_2:
        raise RuntimeError



# Generated at 2022-06-25 23:04:15.689610
# Unit test for constructor of class InputOutput
def test_InputOutput():
    files = 0
    time = 0.0
    target = (0, 0)
    dependencies = []
    input_ = Path()
    output = Path()
    input_output = InputOutput(input_, output)


# Generated at 2022-06-25 23:04:18.457155
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    input_output_0 = InputOutput()


if __name__ == "__main__":
    # importing with renaming for testing root package
    from anpy import *
    import unittest
    unittest.main(exit=False)

# Generated at 2022-06-25 23:04:20.141502
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()



# Generated at 2022-06-25 23:04:25.438964
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Example: test for equality
    assert (CompilationResult(
        files=11,
        time='12:05:32',
        target=CompilationTarget(
            major=2,
            minor=7),
        dependencies=['xyz']) == CompilationResult(
            files=11,
            time='12:05:32',
            target=CompilationTarget(
                major=2,
                minor=7),
            dependencies=['xyz']))



# Generated at 2022-06-25 23:04:27.767698
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert type(test_case_0().input) == Path
    assert type(test_case_0().output) == Path


# Generated at 2022-06-25 23:04:34.598474
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    input_output_0 = InputOutput()
    result = TransformationResult(input_output_0.input, input_output_0.input,
                                  [])

# In transformation result, the tree can be anything of type AST
    result.tree = "ast"
    result.tree = ast.AST()
    result.tree = ast.Expression()

# In transformation result, the tree_changed can only be of type bool
    result.tree_changed = "bool"
    result.tree_changed = True
    result.tree_changed = False

# In transformation result, the dependencies can be anything of type List
    result.dependencies = "bool"
    result.dependencies = [1, 2, 3]
    result.dependencies = [Path("/boo"), Path("/foo")]

# Generated at 2022-06-25 23:04:42.571020
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('print("test_case")')
    tree_changed = True
    dependencies = []
    transformation_result = TransformationResult(tree, tree_changed, dependencies)
    assert transformation_result.tree is tree
    assert transformation_result.tree_changed is tree_changed
    assert transformation_result.dependencies is dependencies



# Generated at 2022-06-25 23:04:43.403857
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult()



# Generated at 2022-06-25 23:04:52.465627
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=ast.AST(), tree_changed=bool(), dependencies=list()).tree == ast.AST()
    assert TransformationResult(tree=ast.AST(), tree_changed=bool(), dependencies=list()).tree_changed == bool()
    assert TransformationResult(tree=ast.AST(), tree_changed=bool(), dependencies=list()).dependencies == list()


# Generated at 2022-06-25 23:04:57.406106
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # kwargs
    # print('**kwargs')
    test_case_0()
    # args
    # print('*args')
    # test_case_1()
    # no args
    # print('no args')
    # test_case_2()
    # Exception
    # print('Exception')
    # test_case_3()
    print('Finished testing constructor')

if __name__ == '__main__':
    test_TransformationResult()

# Generated at 2022-06-25 23:05:01.523273
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput((Path("dummy_input_path"), Path("dummy_output_path")))
    assert input_output_0.input == Path("dummy_input_path")
    assert input_output_0.output == Path("dummy_output_path")


# Generated at 2022-06-25 23:05:05.306760
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()
    assert input_output_0.input == None
    assert input_output_0.output == None
    input_output_1 = InputOutput(None, None)
    assert input_output_1.input == None
    assert input_output_1.output == None


# Generated at 2022-06-25 23:05:11.588601
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert type(input_output_0) == InputOutput
    assert input_output_0.input == None
    assert input_output_0.output == None
    input_output_1 = InputOutput(input=None, output=None)


# Generated at 2022-06-25 23:05:13.520171
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult()


# Generated at 2022-06-25 23:05:16.057732
# Unit test for constructor of class InputOutput
def test_InputOutput():
    result = test_case_0()
    assert result.input.__class__ == Path
    assert result.output.__class__ == Path

test_case_1 = test_case_0().input


# Generated at 2022-06-25 23:05:21.273845
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(0, 0, (0, 0), List[str](['test']))
    assert(compilation_result.files == 0)
    assert(compilation_result.time == 0)
    assert(compilation_result.target == (0, 0))
    assert(compilation_result.dependencies == ["test"])



# Generated at 2022-06-25 23:05:30.694711
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()



# Generated at 2022-06-25 23:05:37.796428
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Test whether initialization works correctly
    assert CompilationResult(files=1, time=1,
                             target=(3, 0),
                             dependencies=['a.py']) is not None

    # Test whether all parameters gets assigned correctly
    compilation_result = CompilationResult(files=1, time=1,
                                           target=(3, 0),
                                           dependencies=['a.py'])
    assert compilation_result.files == 1
    assert compilation_result.time == 1
    assert compilation_result.target == (3, 0)
    assert compilation_result.dependencies == ['a.py']


# Generated at 2022-06-25 23:05:38.819097
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    pass



# Generated at 2022-06-25 23:05:39.710614
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput()


# Generated at 2022-06-25 23:05:48.537405
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(files = 1, time = 7.4, target = (3, 0), dependencies = ['3', '5', '8'])
    compilation_result_1 = CompilationResult(files = 2, time = 4.6, target = (2, 7), dependencies = ['2', '7', '11'])

    assert compilation_result_0.files == 1
    assert compilation_result_0.time == 7.4
    assert compilation_result_0.target == (3, 0)
    assert compilation_result_0.dependencies == ['3', '5', '8']
    assert compilation_result_1.files == 2
    assert compilation_result_1.time == 4.6
    assert compilation_result_1.target == (2, 7)

# Generated at 2022-06-25 23:05:50.336405
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput



# Generated at 2022-06-25 23:05:58.118847
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    target = (2, 4)
    dependencies = ['stdlib.py']
    compilation_result = CompilationResult(1, 11.0, target, dependencies)
    assert (compilation_result.files, compilation_result.time,
            compilation_result.target, compilation_result.dependencies) \
        == (1, 11.0, target, dependencies)
    compilation_result = CompilationResult(1, 11.0, target, dependencies)
    assert (compilation_result.files, compilation_result.time,
            compilation_result.target, compilation_result.dependencies) \
        == (1, 11.0, target, dependencies)


# Generated at 2022-06-25 23:05:59.348677
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()


# Generated at 2022-06-25 23:06:06.556718
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult is not None
    input_output_0 = InputOutput(input=Path(), output=Path())
    input_output_1 = InputOutput(input=Path('qOIoBj.fJd'), output=Path('/QGJSC/sMg'))
    feedback_0 = TransformationResult(tree=None, tree_changed=True, dependencies=[str(input_output_1.input), str(input_output_0.output)])
    assert feedback_0.tree == None and feedback_0.tree_changed == True and feedback_0.dependencies == [str(input_output_1.input), str(input_output_0.output)]



# Generated at 2022-06-25 23:06:11.368271
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Arrange
    input_path_str = './test_input.py'
    output_path_str = './test_output.py'

    # Act
    input_output_0 = InputOutput(input_path_str, output_path_str)

    # Assert
    assert input_output_0.input == input_path_str
    assert input_output_0.output == output_path_str



# Generated at 2022-06-25 23:06:25.113361
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr1 = CompilationResult(files=1, time=2.0,
                            target=(3, 4),
                            dependencies=['foo.py'])
    assert cr1.files == 1
    assert cr1.time == 2.0
    assert cr1.target == (3, 4)
    assert cr1.dependencies == ['foo.py']


# Generated at 2022-06-25 23:06:28.383338
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(
        tree=ast.parse('1+1', filename='foo.py'),
        tree_changed=True,
        dependencies=['foo.py'])
    assert tr.tree_changed


# Generated at 2022-06-25 23:06:29.706028
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 0.5, (3, 7), ['foo', 'bar'])


# Generated at 2022-06-25 23:06:31.596703
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path("/a/b/c.py")
    output = Path("/a/b/c.pyc")
    pair = InputOutput(input, output)
    assert pair.input == input
    assert pair.output == output


# Generated at 2022-06-25 23:06:33.363529
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p = Path('/tmp/foo.txt')
    _ = InputOutput(p, p)


# Generated at 2022-06-25 23:06:37.289397
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    arg = 123, 1.23, (2, 7), ['foo', 'bar']
    assert CompilationResult(*arg) == CompilationResult(123, 1.23,
                                                         (2, 7),
                                                         ['foo', 'bar'])


# Generated at 2022-06-25 23:06:41.562448
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_outout = InputOutput('input.txt', 'input.out')
    assert isinstance(input_outout.input, Path)
    assert isinstance(input_outout.output, Path)
    assert input_outout.input.name == 'input.txt'
    assert input_outout.output.name == 'input.out'

# Generated at 2022-06-25 23:06:50.058936
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.Module([]), False, []) == TransformationResult(
        tree=ast.Module([]), tree_changed=False, dependencies=[])
    assert TransformationResult(ast.Module([]), True, []) == TransformationResult(
        tree=ast.Module([]), tree_changed=True, dependencies=[])
    assert TransformationResult(ast.Module([]), False, ['foo/bar/baz.py']) == TransformationResult(
        tree=ast.Module([]), tree_changed=False, dependencies=['foo/bar/baz.py'])
    assert TransformationResult(ast.Module([ast.Pass()]), False, ['foo/bar/baz.py']) == TransformationResult(
        tree=ast.Module([ast.Pass()]), tree_changed=False, dependencies=['foo/bar/baz.py'])

# Generated at 2022-06-25 23:06:53.342916
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Instance of class CompilationResult
    result = CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=['a', 'b'])

    # Asserts
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 6)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-25 23:06:55.200274
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    r = TransformationResult(None, True, [])
    assert r.tree is None
    assert r.tree_changed is True
    assert r.dependencies == []

# Generated at 2022-06-25 23:07:16.791671
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_test = ast.AST()
    res = TransformationResult(ast_test, False, [])
    assert res.tree == ast_test
    assert res.tree_changed == False
    assert res.dependencies == []

# Translation of python function
TranslationResult = NamedTuple('TranslationResult',
                               [('tree', ast.AST),
                                ('dependencies', List[str])])

# Generated at 2022-06-25 23:07:22.867837
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=42,
                               time=1.2345,
                               target=(3, 7),
                               dependencies=[])
    assert 42 == result.files
    assert 1.234 == round(result.time, 3)
    assert (3, 7) == result.target
    assert [] == result.dependencies
    assert 'files=42, time=1.234, target=(3, 7), dependencies=[]' == \
           str(result)


# Generated at 2022-06-25 23:07:25.928389
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = "/hello/world.py"
    output = "/hey/world.py"

    io = InputOutput(input=input_, output=output)
    assert io.input == input_
    assert io.output == output



# Generated at 2022-06-25 23:07:33.350901
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # type: () -> None
    result = CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=['foo', 'bar'])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == ['foo', 'bar']


# Generated at 2022-06-25 23:07:36.963285
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(0, 0.0, (3, 5), [])
    assert result.files == 0
    assert result.time == 0.0
    assert result.target == (3, 5)
    assert result.dependencies == []


# Generated at 2022-06-25 23:07:41.348273
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 1
    time = 0.009
    target = (2, 7)
    dependencies = ['foo']

    cr = CompilationResult(files, time, target, dependencies)

    assert(cr.files == files)
    assert(cr.time == time)
    assert(cr.target == target)
    assert(cr.dependencies == dependencies)


# Generated at 2022-06-25 23:07:47.776038
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 2.0, (3, 4), ['a', 'b'])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == ['a', 'b']



# Generated at 2022-06-25 23:07:50.571029
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('foo/bar.py'), Path('bar/bar.py'))
    assert input_output.input == Path('foo/bar.py')
    assert input_output.output == Path('bar/bar.py')


# Generated at 2022-06-25 23:07:52.991397
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    a = ast.AST()
    b = TransformationResult(a, True, ['a', 'b'])
    assert b.tree is a and b.tree_changed and b.dependencies == ['a', 'b']

# Generated at 2022-06-25 23:07:58.525373
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a'), Path('b')) == InputOutput(Path('a'), Path('b'))
    assert InputOutput(Path('a'), Path('b')) != InputOutput(Path('a'), Path('c'))
    assert InputOutput(Path('a'), Path('b')) != InputOutput(Path('c'), Path('b'))
    assert InputOutput(Path('a'), Path('b')) != InputOutput(Path('c'), Path('d'))


# Generated at 2022-06-25 23:08:45.376658
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput('test/in.py', 'test/out.py')
    assert(io.input == Path('test/in.py'))
    assert(io.output == Path('test/out.py'))

# Generated at 2022-06-25 23:08:47.698321
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('/inp')
    outp = Path('/outp')
    pair = InputOutput(inp, outp)

    assert pair.input == inp
    assert pair.output == outp


# Generated at 2022-06-25 23:08:48.964280
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 1.0, (3, 7), [])


# Generated at 2022-06-25 23:08:51.754875
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=1.0, target=(2, 7), dependencies=[])
    assert cr.files == 1
    assert cr.time == 1.0
    assert cr.target == (2, 7)
    assert cr.dependencies == []



# Generated at 2022-06-25 23:08:54.287074
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    comp = CompilationResult(0, 0.01, (3, 4), [])

    assert comp.files == 0
    assert comp.time == 0.01
    assert comp.target == (3, 4)
    assert comp.dependencies == []


# Generated at 2022-06-25 23:08:57.456803
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # pylint: disable=unused-variable
    ast_node = ast.parse('foo', mode='eval')
    dependencies = ['foo.py', 'bar.py']
    result = TransformationResult(ast_node, True, dependencies)
    # pylint: enable=unused-variable

# Generated at 2022-06-25 23:09:00.796708
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=3.14,
                                target=(3, 4),
                                dependencies=['t1', 't2'])
    assert result.files == 1
    assert result.time == 3.14
    assert result.target == (3, 4)
    assert result.dependencies == ['t1', 't2']



# Generated at 2022-06-25 23:09:03.115337
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=None,
                              tree_changed=True,
                              dependencies=[])
    assert tr.tree == None
    assert tr.tree_changed == True
    assert tr.dependencies == []

# Generated at 2022-06-25 23:09:09.472395
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("x = 3")
    r = TransformationResult(tree, True, ['x.py'])
    assert r.tree == tree
    assert r.tree_changed == True
    assert r.dependencies == ['x.py']

# Result of pre_process_file transformer
PreProcessFileResult = NamedTuple('PreProcessFileResult',
                                  [('transformation', TransformationResult),
                                   ('filename', str),
                                   ('text', str),
                                   ('filepath', Path),
                                   ('encoding', str),
                                   ('mode', str),
                                   ('flags', int),
                                   ('newline', str),
                                   ('open_hook', object)])


# Generated at 2022-06-25 23:09:11.994287
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 1.0, (2, 4), ['dep1'])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (2, 4)
    assert result.dependencies == ['dep1']


# Generated at 2022-06-25 23:10:54.266053
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input, output = InputOutput('input', 'output')
    assert input.input == Path('input')
    assert input.output == Path('output')
    assert input == InputOutput('input', 'output')


# Generated at 2022-06-25 23:11:04.646556
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Input/Output, correct values
    assert InputOutput(input=Path('input'), output=Path('output'))

    # Input/Output, wrong values
    with pytest.raises(TypeError):
        InputOutput(input=1, output=Path('output'))
    with pytest.raises(TypeError):
        InputOutput(input=Path('input'), output='output')

    # Input/Output, missing values
    with pytest.raises(TypeError):
        InputOutput(input=Path('input'))
    with pytest.raises(TypeError):
        InputOutput(output=Path('output'))


# Generated at 2022-06-25 23:11:06.760143
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('a'), Path('b'))
    assert input_output.input.name == 'a'
    assert input_output.output.name == 'b'

# Generated at 2022-06-25 23:11:08.644370
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path('foo'),
                     Path('bar'))
    assert io.input == Path('foo')
    assert io.output == Path('bar')

# Generated at 2022-06-25 23:11:15.289497
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Since InputOutput is just a NamedTuple, it should be created
    # with arguments.
    try:
        InputOutput()
    except TypeError:
        pass
    else:
        assert False, 'InputOutput() does not raise TypeError'

    # Input/output should be paths
    try:
        InputOutput('', '')
    except TypeError:
        pass
    else:
        assert False, 'InputOutput("", "") does not raise TypeError'

    # Empty inputs/outputs are not allowed
    try:
        InputOutput(Path(), Path())
    except ValueError:
        pass
    else:
        assert False, 'InputOutput(Path(), Path()) does not raise ValueError'


# Generated at 2022-06-25 23:11:17.337880
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input, output = Path('foo'), Path('bar')
    io = InputOutput(input=input, output=output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-25 23:11:25.965498
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Test with no dependencies
    input_output = InputOutput('test_input.py', 'test_output.py')
    assert(TransformationResult(input_output.input,
                                input_output.output,
                                None,
                                False,
                                None) ==
           TransformationResult(input_output.input,
                                input_output.output,
                                None,
                                False,
                                []))
    # Test with empty list of dependencies
    assert(TransformationResult(input_output.input,
                                input_output.output,
                                None,
                                False,
                                []) ==
           TransformationResult(input_output.input,
                                input_output.output,
                                None,
                                False,
                                []))
    # Test with list of dependencies

# Generated at 2022-06-25 23:11:27.597129
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # type: () -> None
    CompilationResult(1, 1, (1, 1), ['a', 'b'])


# Generated at 2022-06-25 23:11:29.675945
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.Module('x=1', type_ignores=[]),
                                True,
                                ['foo.py', 'bar.py'])

# Generated at 2022-06-25 23:11:33.744398
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    import typed_ast
    l = TransformationResult(
        tree = typed_ast.ast3.Module([]),
        tree_changed = True,
        dependencies = ['f1', 'f2'])
    assert l[0] == typed_ast.ast3.Module([])
    assert l[1] == True
    assert l[2] == ['f1', 'f2']
