

# Generated at 2022-06-25 23:03:36.722633
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()


# Generated at 2022-06-25 23:03:42.574245
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = os.path.join(os.path.dirname(__file__),
                              'packages', 'tensorflow', 'hello_world.py')
    output_path = os.path.join(os.path.dirname(__file__),
                               'packages', 'tensorflow', 'hello_world.py')
    input_output = InputOutput(input_path, output_path)
    assert isinstance(input_output.input, Path)
    assert isinstance(input_output.output, Path)

# Generated at 2022-06-25 23:03:44.471393
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test = TransformationResult()
    assert isinstance(test, TransformationResult)



# Generated at 2022-06-25 23:03:49.982413
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(files=1,
                                             time=2.0,
                                             target=(3, 4),
                                             dependencies=['a', 'b', 'c'])
    assert compilation_result_0.files == 1
    assert compilation_result_0.time == 2.0
    assert compilation_result_0.target == (3, 4)
    assert compilation_result_0.dependencies == ['a', 'b', 'c']


# Generated at 2022-06-25 23:03:59.478337
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_cases = [['',''], ['abcd', 'edf'], ['~/test', '~/test_t'],
                  ['./test', './test_t']]
    # Test constructor with no arguments
    try:
        input_output_0 = InputOutput()
    except TypeError:
        pass

    # Test constructor with one argument
    try:
        input_output_1 = InputOutput('a')
    except TypeError:
        pass

    # Test constructor with two arguments
    for test_case in test_cases:
        input_output = InputOutput(test_case[0], test_case[1])
        assert input_output.input == test_case[0]
        assert input_output.output == test_case[1]

    # Test constructor with three arguments

# Generated at 2022-06-25 23:04:02.468890
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('./input')
    output = Path('./output')
    input_output = InputOutput(input_, output)

    assert input_output.input == input_
    assert input_output.output == output



# Generated at 2022-06-25 23:04:05.838428
# Unit test for constructor of class InputOutput
def test_InputOutput():
    try:
        input_0 = Path("input.txt")
        output_0 = Path("output.txt")
        input_output_0 = InputOutput(input_0, output_0)
        file_system_path = input_output_0.input
    except:
        pass


# Generated at 2022-06-25 23:04:09.988250
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files = 1, time = 10, target = (3, 5), dependencies = ["test.py"])

    assert compilation_result.files == 1
    assert compilation_result.time == 10
    assert compilation_result.target == (3, 5)
    assert compilation_result.dependencies == ["test.py"]


# Generated at 2022-06-25 23:04:10.595636
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result_0 = TransformationResult(None, None, None)



# Generated at 2022-06-25 23:04:11.111679
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult()

# Generated at 2022-06-25 23:04:21.236884
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = "Input"
    output = "Output"
    input_output = InputOutput("Input", "Output")
    assert input_output.input == "Input"
    assert input_output.output == "Output"
    assert input_output.input.__class__.__name__ == "Path"
    assert input_output.output.__class__.__name__ == "Path"
    assert input_output.input.__class__.is_file() == True
    assert input_output.output.__class__.is_file() == True
    assert input_output.input.exists() == True
    assert input_output.output.exists() == True


# Generated at 2022-06-25 23:04:24.800742
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test_tree = ast.parse("print('hello world')")
    test_dependencies = []
    result = TransformationResult(test_tree, True, test_dependencies)
    assert result.tree == test_tree
    assert result.tree_changed == True
    assert result.dependencies == test_dependencies


# Generated at 2022-06-25 23:04:25.865960
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult()



# Generated at 2022-06-25 23:04:30.749148
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(1,
                                             "1",
                                             (2, 3),
                                             ["a", "b"])
    assert compilation_result_0.files == 1
    assert compilation_result_0.time == "1"
    assert compilation_result_0.target == (2, 3)
    assert compilation_result_0.dependencies == ["a", "b"]


# Generated at 2022-06-25 23:04:33.867405
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("a = 5")
    tree_changed = True
    dependencies = ["a", "b", "c"]
    result = TransformationResult(tree, tree_changed, dependencies)
    assert isinstance(result, TransformationResult)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-25 23:04:39.801790
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(
        5, 1.5, (2, 7), ['dep_1', 'dep_2', 'dep_3'])
    assert compilation_result_0.files == 5
    assert compilation_result_0.time == 1.5
    assert compilation_result_0.target == (2, 7)
    assert compilation_result_0.dependencies == ['dep_1', 'dep_2', 'dep_3']


# Generated at 2022-06-25 23:04:46.500247
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x=1', '<string>', 'single')
    tree_changed = True
    dep = ['a']
    a = TransformationResult(tree, tree_changed, dep)
    assert a.tree == ast.parse('x=1', '<string>', 'single')
    assert a.tree_changed == True
    assert a.dependencies == ['a']



# Generated at 2022-06-25 23:04:48.981687
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(None, None, None)


# Generated at 2022-06-25 23:04:52.986519
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.AST()
    tree_changed = True
    dependencies = ['dependency_1']
    transformation_result = TransformationResult(tree, tree_changed, dependencies)
    assert transformation_result.tree == tree
    assert transformation_result.tree_changed == tree_changed
    assert transformation_result.dependencies == dependencies

# Generated at 2022-06-25 23:04:54.144495
# Unit test for constructor of class InputOutput
def test_InputOutput():
  input_output_0 = InputOutput(Path(""), Path(""))

# Generated at 2022-06-25 23:05:00.624585
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result = TransformationResult(tree=None, tree_changed=True, dependencies=[])
    result = transformation_result
    assert result == transformation_result

# Generated at 2022-06-25 23:05:01.524256
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    pass


# Generated at 2022-06-25 23:05:08.600263
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree_0 = ast.AST()
    tree_1 = ast.AST()
    dependencies_0 = []
    dependencies_1 = []
    transformation_result_0 = TransformationResult(tree_0, False, dependencies_0)
    transformation_result_1 = TransformationResult(tree_1, True, dependencies_1)
    transformation_result_2 = TransformationResult(tree_0, False, dependencies_1)


# Generated at 2022-06-25 23:05:14.395299
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files = 1,
                                           time = 2.4,
                                           target = (3, 4),
                                           dependencies = [])
    assert compilation_result.files == 1
    assert compilation_result.time == 2.4
    assert compilation_result.target == (3, 4)
    assert compilation_result.dependencies == []



# Generated at 2022-06-25 23:05:15.926178
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_0 = InputOutput(input=Path('input.py'), output=Path('output.py'))


# Generated at 2022-06-25 23:05:20.776186
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(0, 3.2, (3, 1), [])
    assert compilation_result_0.files == 0
    assert compilation_result_0.time == 3.2
    assert compilation_result_0.target == (3, 1)
    assert compilation_result_0.dependencies == []


# Generated at 2022-06-25 23:05:23.161582
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(0, 0.0, (0, 0), [])


# Generated at 2022-06-25 23:05:26.589132
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(0, 0, (0, 0), [])
    assert isinstance(compilation_result_0, CompilationResult)


# Generated at 2022-06-25 23:05:30.372150
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(
        files=0, 
        time=0.0, 
        target=(3,5), 
        dependencies=['/C/Users/nicol/OneDrive/Documents/GitHub/typeguard/typeguard/compiler/test/test_case_0.py'])


# Generated at 2022-06-25 23:05:32.939497
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Input/output pair
    InputOutput(Path('/some/path/some_file.py'),
                Path('/another/path/another_file.py'))

# Generated at 2022-06-25 23:05:38.907692
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(42, 1.0, (3, 7), ['foo', 'bar'])


# Generated at 2022-06-25 23:05:45.461119
# Unit test for constructor of class CompilationResult
def test_CompilationResult():  # type: () -> None
    # Given
    files = 1
    time = 1.0
    target = (3, 8)
    dependencies = ['dependency1', 'dependency2']

    # When
    actual = CompilationResult(files, time, target, dependencies)

    # Then
    assert actual.files == files
    assert actual.time == time
    assert actual.target == target
    assert actual.dependencies == dependencies



# Generated at 2022-06-25 23:05:47.556009
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('test.py')
    output = Path('test.cpp')
    pair: InputOutput = InputOutput(input, output)
    assert pair.input == input and pair.output == output

# Generated at 2022-06-25 23:05:52.879969
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    obj = CompilationResult(files=1, time=1.7, target=(3, 7), dependencies=["a", "b"])
    assert obj['files'] == 1
    assert obj['time'] == 1.7
    assert obj['target'] == (3, 7)
    assert obj['dependencies'] == ["a", "b"]



# Generated at 2022-06-25 23:05:57.345766
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(24, 10.5, (3, 4), ["foo1", "bar2"])
    assert cr.files == 24
    assert cr.time == 10.5
    assert cr.target == (3, 4)
    assert cr.dependencies == ["foo1", "bar2"]


# Generated at 2022-06-25 23:05:59.463715
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=3,
                      time=0.2,
                      target=(3, 5),
                      dependencies=['a.py', 'b.py'])


# Generated at 2022-06-25 23:06:02.751042
# Unit test for constructor of class InputOutput
def test_InputOutput():
    name_in = "bar"
    name_out = "faz"
    res = InputOutput(Path(name_in), Path(name_out))
    assert res.input.name == name_in
    assert res.output.name == name_out


# Generated at 2022-06-25 23:06:04.808297
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files = 1, time = 0.0,
                      target = (2, 6),
                      dependencies = ['file1.py', 'file2.py'])


# Generated at 2022-06-25 23:06:08.969687
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=1, time=1.0, target=(3, 7), dependencies=['a.py'])
    assert c.files == 1
    assert c.time == 1.0
    assert c.target == (3, 7)
    assert c.dependencies == ['a.py']


# Generated at 2022-06-25 23:06:10.949168
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('input')
    output = Path('output')
    InputOutput(input_, output)
    # It should not raise an exception


# Generated at 2022-06-25 23:06:25.929415
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # pylint: disable=too-few-public-methods
    class CompilationResultMock(CompilationResult):
        pass

    assert CompilationResultMock(files=100,
                                 time=2.0,
                                 target=(3, 7),
                                 dependencies=['a', 'b', 'c'])
    assert not CompilationResultMock(files=100,
                                     time=2.0,
                                     target=(3, 7))


# Generated at 2022-06-25 23:06:29.188249
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('test', 'file', 'path')
    output = Path('test', 'file', 'output')
    result = InputOutput(input, output)
    assert result.input == input
    assert result.output == output

# Test for constructor of class TransformationResult

# Generated at 2022-06-25 23:06:31.031133
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = InputOutput(Path('a'), Path('b'))
    assert i.input == Path('a')
    assert i.output == Path('b')

# Generated at 2022-06-25 23:06:32.214259
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 1.1, (2, 3), [])


# Generated at 2022-06-25 23:06:35.846125
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(1, 1.1, (3, 6), [])
    assert compilation_result.files == 1
    assert compilation_result.time == 1.1
    assert compilation_result.target == (3, 6)
    assert not compilation_result.dependencies


# Generated at 2022-06-25 23:06:42.502624
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    class Var:
        pass

    source = Source(ast.FunctionDef(name='foo', body=[], args=ast.arguments(args=[],
                      vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, default=[])), [])
    tr = TransformationResult(source.tree, True, ['a.py'])
    assert tr.tree is source.tree
    assert tr.tree_changed is True
    assert tr.dependencies == ['a.py']


# Generated at 2022-06-25 23:06:46.922517
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(10, 2.35, (2, 3), ['a', 'b', 'c'])
    assert(res.files == 10)
    assert(res.time == 2.35)
    assert(res.target == (2, 3))
    assert(res.dependencies == ['a', 'b', 'c'])


# Generated at 2022-06-25 23:06:49.361175
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('test.py')
    output = Path('test.pyc')
    pair = InputOutput(input, output)
    assert pair.input == input
    assert pair.output == output

# Generated at 2022-06-25 23:06:51.872269
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path('hello')
    path2 = Path('world')
    input_output = InputOutput(path1, path2)
    assert input_output.input == path1
    assert input_output.output == path2


# Generated at 2022-06-25 23:06:53.146073
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2.0, (3, 4), ['test'])



# Generated at 2022-06-25 23:07:14.102562
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('a = 1')
    r = TransformationResult(t, True, [])
    assert r.tree is t
    assert r.tree_changed is True
    assert r.dependencies == []

# Generated at 2022-06-25 23:07:15.628940
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(1, 0.1, (3, 5), ['file1', 'file2'])
    assert res.files == 1
    assert res.time == 0.1
    assert res.target == (3, 5)
    assert res.dependencies == ['file1', 'file2']


# Generated at 2022-06-25 23:07:19.262106
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    ast_tree = ast.parse("")  # Empty module
    t = TransformationResult(ast_tree, True, [])
    assert isinstance(t, TransformationResult)
    assert isinstance(t, tuple)
    assert t.tree is ast_tree
    assert t.tree_changed is True
    assert t.dependencies == []
    assert t == (ast_tree, True, [])

# Generated at 2022-06-25 23:07:23.600858
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input.txt')
    output = Path('output.txt')
    pair = InputOutput(input, output)
    assert(pair.input == input)
    assert(pair.output == output)


# Generated at 2022-06-25 23:07:25.238884
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=0,
                             time=0,
                             target=(3, 7),
                             dependencies=[])


# Generated at 2022-06-25 23:07:32.674108
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1, target=(3, 7),
                               dependencies=[])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 7)
    assert result.dependencies == []


# Generated at 2022-06-25 23:07:36.533960
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 1.2, (3, 5), ['a.py'])
    assert result.files == 1
    assert result.time == 1.2
    assert result.target == (3, 5)
    assert result.dependencies == ['a.py']


# Generated at 2022-06-25 23:07:38.607388
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('x = 5')
    x = TransformationResult(tree = t, tree_changed = True, dependencies = ['foo'])
    assert repr(x)

# Generated at 2022-06-25 23:07:40.864722
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path('in'), Path('out'))
    assert io.input == Path('in')
    assert io.output == Path('out')

# Generated at 2022-06-25 23:07:48.421650
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    expected_tree = ast.parse('x = 2')
    expected_tree_changed = True
    expected_dependencies = ['foo', 'bar']
    t = TransformationResult(expected_tree,
                             expected_tree_changed,
                             expected_dependencies)
    assert isinstance(t.tree, ast.AST)
    assert t.tree_changed is True
    assert t.dependencies == expected_dependencies

# Generated at 2022-06-25 23:08:33.784721
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    ast_tree = ast.parse('')
    dependencies = ['foo', 'bar']
    res = TransformationResult(ast_tree, True, dependencies)
    assert res.tree == ast_tree
    assert res.tree_changed
    assert res.dependencies == dependencies

# Generated at 2022-06-25 23:08:34.595103
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, False, [])

# Generated at 2022-06-25 23:08:41.773225
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # GIVEN
    # Simple content for CompilationResult
    files = 4
    time = 2.3
    target = (3, 5)
    dependencies = [str(Path('foo/bar/baz'))]
    content = (files, time, target, dependencies)

    # WHEN
    # CompilationResult is created
    result = CompilationResult(*content)

    # THEN
    # Result is properly filled
    for field, value in zip(result._fields, content):
        assert getattr(result, field) == value
    assert result.files == 4
    assert result.time == 2.3
    assert result.target == (3, 5)
    assert result.dependencies == [str(Path('foo/bar/baz'))]


# Generated at 2022-06-25 23:08:43.597026
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    d = TransformationResult(ast.AST(''), False, [])
    assert d.tree is not None
    assert not d.tree_changed
    assert d.dependencies == []

# Generated at 2022-06-25 23:08:45.894476
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('in')
    output = Path('out')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-25 23:08:48.997496
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = 'a'
    output = 'b'
    inputoutput = InputOutput(input=input_, output=output)
    assert inputoutput.input == input_
    assert inputoutput.output == output
    assert inputoutput.input is not input_
    assert inputoutput.output is not output

# Generated at 2022-06-25 23:08:51.789754
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast.parse('1 + 1')
    res = TransformationResult(tree=None,
                               tree_changed=None,
                               dependencies=[])
    assert res.tree is None
    assert res.tree_changed is None
    assert len(res.dependencies) == 0

# Generated at 2022-06-25 23:08:53.572556
# Unit test for constructor of class InputOutput
def test_InputOutput():
    x = InputOutput(input=Path("a"), output=Path("b"))
    assert x.input == Path("a")
    assert x.output == Path("b")


# Generated at 2022-06-25 23:09:00.962641
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input='path/to/input',
                       output='path/to/output') == \
            InputOutput(input=Path('path/to/input'),
                        output=Path('path/to/output'))
    assert (InputOutput(input='path/to/input',
                        output='path/to/output') !=
            InputOutput(input='path/to/input',
                        output='path/to/output/2'))
    assert InputOutput(input='path/to/input',
                       output='path/to/output')._asdict() == \
            {'input': 'path/to/input', 'output': 'path/to/output'}

# Generated at 2022-06-25 23:09:03.822993
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(1, 2.0, (3, 4), [])
    assert c.files == 1
    assert c.time == 2.0
    assert c.target == (3, 4)
    assert c.dependencies == []


# Generated at 2022-06-25 23:10:46.448949
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    None  # untestable because of NamedTuples



# Generated at 2022-06-25 23:10:50.051536
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    file1 = Path('./file1.py')
    file2 = Path('./file2.py')
    my_asdl_ast_node = ast.Module(body=[])
    transformation_result_1 = TransformationResult(my_asdl_ast_node, True, [file1, file2])
    assert transformation_result_1.tree == my_asdl_ast_node
    assert transformation_result_1.tree_changed == True
    assert transformation_result_1.dependencies == [file1, file2]

    transformation_result_2 = TransformationResult(my_asdl_ast_node, False, [file2])
    assert transformation_result_2.tree == my_asdl_ast_node
    assert transformation_result_2.tree_changed == False

# Generated at 2022-06-25 23:10:53.894204
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    with pytest.raises(TypeError):
        r = CompilationResult(files='foo',
                              time=1.0,
                              target=(3, 5),
                              dependencies=['a', 'b'])
        print(r)

    r = CompilationResult(files=3,
                          time=1.0,
                          target=(3, 5),
                          dependencies=['a', 'b'])
    print(r)

    r = CompilationResult(files=1, time=1.0, target=(3, 5), dependencies=[])
    print(r)

# Generated at 2022-06-25 23:11:01.175357
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    comp_res = CompilationResult(files=1, time=1.0, target=(3, 5),
                                 dependencies=[])
    assert comp_res.files == 1
    assert comp_res.time == 1.0
    assert comp_res.target == (3, 5)
    assert comp_res.dependencies == []


# Generated at 2022-06-25 23:11:05.594125
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    dummy_target = (0, 0)
    dummy_dependencies = []

    res = CompilationResult(files=42, time=42.42,
                            target=dummy_target,
                            dependencies=dummy_dependencies)
    assert res.files == 42
    assert res.time == 42.42
    assert res.target == dummy_target
    assert res.dependencies == dummy_dependencies



# Generated at 2022-06-25 23:11:09.075599
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Success
    InputOutput(input="foo", output="bar")
    # Failure
    with pytest.raises(TypeError):
        InputOutput(input=123, output="bar")
    # Failure
    with pytest.raises(TypeError):
        InputOutput(input="foo", output=123)


# Generated at 2022-06-25 23:11:10.707576
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p = InputOutput(Path("test"), Path("test2"))
    assert p.input == Path("test")
    assert p.output == Path("test2")

# Generated at 2022-06-25 23:11:14.889179
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from astunparse import unparse
    from ast import parse
    from pytypes.transformer import Transformations
    tree = parse('1 + 2')
    t = Transformations(0, 0)
    t.transform(tree)
    r = TransformationResult(tree, False, [])
    assert r.tree_changed == False
    assert r.dependencies == []
    assert r.tree == parse(unparse(tree))

# Generated at 2022-06-25 23:11:22.201497
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=10,
                                           time=42.0,
                                           target=(2,7),
                                           dependencies=["a", "b", "c"])
    expected_compilation_result = CompilationResult(files=10,
                                                    time=42.0,
                                                    target=(2,7),
                                                    dependencies=["a", "b", "c"])
    assert expected_compilation_result == compilation_result

    compilation_result_without_dependencies = CompilationResult(files=10,
                                                                time=42.0,
                                                                target=(2,7),
                                                                dependencies=None)

# Generated at 2022-06-25 23:11:23.556005
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('input.py'), Path('output.py'))
