

# Generated at 2022-06-25 23:03:45.071404
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result_0 = TransformationResult(
        ast.Module(),
        False,
        ['requirements_path_0']
    )
    assert isinstance(transformation_result_0, TransformationResult)
    assert (transformation_result_0.tree == ast.Module())
    assert (transformation_result_0.tree_changed == False)
    assert (transformation_result_0.dependencies == ['requirements_path_0'])
    transformation_result_0 = TransformationResult(
        ast.Module(),
        False,
        ['requirements_path_1']
    )
    assert isinstance(transformation_result_0, TransformationResult)
    assert (transformation_result_0.tree == ast.Module())
    assert (transformation_result_0.tree_changed == False)

# Generated at 2022-06-25 23:03:53.518289
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Construction with a valid path
    base_path = Path('.')
    input_path = base_path / 'file_input.py'
    output_path = base_path / 'file_output.py'
    io_0 = InputOutput(input_path, output_path)
    assert io_0.input == input_path
    assert io_0.output == output_path
    # Construction with invalid paths
    # Both paths not instances of Path
    invalid_input = 'string_input.py'
    invalid_output = 'string_output.py'
    try:
        io_1 = InputOutput(invalid_input, invalid_output)
        assert False
    except AssertionError:
        assert True
    # Only the output path is not an instance of Path

# Generated at 2022-06-25 23:04:02.742037
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Test with default values
    compilation_result_0 = CompilationResult()
    assert compilation_result_0.files == 0
    assert compilation_result_0.time == 0.0
    assert compilation_result_0.target == (0, 0)
    assert compilation_result_0.dependencies == []

    # Test with custom values
    target = (2, 7)
    dependencies = ['1', '2', '3']
    compilation_result_1 = CompilationResult(files=1,
                                             time=3.0,
                                             target=target,
                                             dependencies=dependencies)
    assert compilation_result_1.files == 1
    assert compilation_result_1.time == 3.0
    assert compilation_result_1.target == target
    assert compilation_result_1.dependencies == dependencies


#

# Generated at 2022-06-25 23:04:11.315311
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path("/some/folder/some/file.py")
    output = Path("/some/other/folder/file.py")
    input_output = InputOutput(input, output)

    assert input_output.input == Path("/some/folder/some/file.py")
    assert input_output.output == Path("/some/other/folder/file.py")

    path_list = [Path("/some/folder/some/file.py"), Path("/some/other/folder/file.py")]
    input_output2 = InputOutput(*path_list)
    input_output3 = InputOutput(path_list[0], path_list[1])

    assert input_output2.input == Path("/some/folder/some/file.py")

# Generated at 2022-06-25 23:04:14.188403
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(files=0, time=0.0, target=(3, 5),
                                             dependencies=['dep'])



# Generated at 2022-06-25 23:04:17.975807
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_0 = Path('input_0')
    output_0 = Path('output_0')

    input_output_0 = InputOutput(input=input_0, output=output_0)
    assert input_output_0.input == input_0
    assert input_output_0.output == output_0


# Generated at 2022-06-25 23:04:21.738786
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult()
    assert compilation_result_0.files == 0
    assert compilation_result_0.time == 0
    assert compilation_result_0.target == (0, 0)
    assert compilation_result_0.dependencies == []


# Generated at 2022-06-25 23:04:23.656194
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=0, time=0, target=(3, 6), dependencies=[])


# Generated at 2022-06-25 23:04:27.936275
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=0, time=0.0, target=(0, 0), dependencies=[])
    assert compilation_result.files == 0
    assert compilation_result.time == 0.0
    assert compilation_result.target == (0, 0)
    assert compilation_result.dependencies == []


# Generated at 2022-06-25 23:04:31.267769
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/a/b/c.py')
    output = Path('/a/b/compiled/c.pyc')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-25 23:04:39.885462
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    target = CompilationTarget(0, 0)
    dependencies = []

    # Test case: no parameters
    try:
        compilation_result_0 = CompilationResult()
        assert False
    except TypeError:
        pass

    # Test case: all parameters are given
    compilation_result_1 = CompilationResult(0, 0, target, dependencies)

    # Test case: all arguments are given by keyword
    compilation_result_1 = CompilationResult(time=0, files=0, target=target,
                                             dependencies=dependencies)


# Generated at 2022-06-25 23:04:41.441759
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=-1, tree_changed=-1, dependencies=-1)



# Generated at 2022-06-25 23:04:46.937349
# Unit test for constructor of class InputOutput
def test_InputOutput():
    example_input = Path('')
    example_output = Path('')
    result = InputOutput(example_input, example_output)

    assert(result.input == example_input)
    assert(result.output == example_output)



# Generated at 2022-06-25 23:04:56.959909
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Input
    files_0: int = 1
    time_0: float = 0.1
    target_0: CompilationTarget = (3, 7)
    dependencies_0: List[str] = ['foo.bar']

    # Expected
    expected_0: CompilationResult = CompilationResult(files_0,
                                                      time_0,
                                                      target_0,
                                                      dependencies_0)
    # Actual
    actual_0: CompilationResult = CompilationResult(files_0,
                                                    time_0,
                                                    target_0,
                                                    dependencies_0)

    # Assert
    assert expected_0 == actual_0
    assert expected_0.files == actual_0.files
    assert expected_0.time == actual_0.time

# Generated at 2022-06-25 23:04:59.576130
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    inputoutput = InputOutput(input, output)



# Generated at 2022-06-25 23:05:00.471857
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, None, None)



# Generated at 2022-06-25 23:05:07.730605
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = transformers.TransformationResult()
    assert(result.tree == None)
    assert(result.tree_changed == False)
    assert(result.dependencies == [])
    result = transformers.TransformationResult(ast.Module(), True, ['a'])
    assert(isinstance(result.tree, ast.Module))
    assert(result.tree_changed == True)
    assert(result.dependencies == ['a'])

# Generated at 2022-06-25 23:05:14.202505
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(1, 2.0, (3, 4), ['a', 'b', 'c'])

    assert isinstance(compilation_result.files, int)
    assert isinstance(compilation_result.time, float)
    assert isinstance(compilation_result.target, CompilationTarget)
    assert isinstance(compilation_result.dependencies, list)



# Generated at 2022-06-25 23:05:15.314846
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult()



# Generated at 2022-06-25 23:05:18.969562
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result_0 = TransformationResult(tree=None, tree_changed=None, dependencies=None)
    assert transformation_result_0 is not None
    assert isinstance(transformation_result_0, TransformationResult)



# Generated at 2022-06-25 23:05:27.951418
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Checking for one parameter
    inputoutput_oneparameter = InputOutput('input')
    assert inputoutput_oneparameter.input == 'input'
    assert inputoutput_oneparameter.output == None

    # Checking for two parameters
    inputoutput_twoparameter = InputOutput('input', 'output')
    assert inputoutput_twoparameter.input == 'input'
    assert inputoutput_twoparameter.output == 'output'


# Generated at 2022-06-25 23:05:29.425433
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 1.0, (3, 6), ['a.py'])



# Generated at 2022-06-25 23:05:34.340753
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result = TransformationResult(ast.parse('1 + 2'), True, ['a', 'b', 'c'])
    assert len(transformation_result) == 3
    assert isinstance(transformation_result, tuple)
    assert transformation_result.tree == ast.parse('1 + 2')
    assert transformation_result.tree_changed == True
    assert transformation_result.dependencies == ['a', 'b', 'c']

# Generated at 2022-06-25 23:05:35.270187
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert test_case_0()



# Generated at 2022-06-25 23:05:36.916538
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_0 = InputOutput(input=Path('.'), output=Path('.'))
    pass


# Generated at 2022-06-25 23:05:45.238718
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1, time=2, target=(3, 4), dependencies=['a', 'b'])
    assert isinstance(compilation_result.files, int)
    assert isinstance(compilation_result.time, float)
    assert isinstance(compilation_result.target, tuple)
    assert isinstance(compilation_result.dependencies, list)
    assert compilation_result.files == 1
    assert compilation_result.time == 2
    assert compilation_result.target == (3, 4)
    assert compilation_result.dependencies == ['a', 'b']



# Generated at 2022-06-25 23:05:57.872209
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result_0 = TransformationResult()
    assert transformation_result_0.tree is None
    assert transformation_result_0.tree_changed is False
    assert transformation_result_0.dependencies == []
    tree = ast.parse('')
    transformation_result_0 = TransformationResult(tree)
    assert transformation_result_0.tree is tree
    assert transformation_result_0.tree_changed is False
    assert transformation_result_0.dependencies == []
    tree = ast.parse('')
    transformation_result_0 = TransformationResult(tree, True)
    assert transformation_result_0.tree is tree
    assert transformation_result_0.tree_changed is True
    assert transformation_result_0.dependencies == []
    tree = ast.parse('')

# Generated at 2022-06-25 23:05:58.755662
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert isinstance(test_case_0(), TransformationResult)

# Generated at 2022-06-25 23:06:02.982508
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result_0 = TransformationResult(
        tree=ast.AST(),
        tree_changed=True,
        dependencies=['b', 'c']
    )
    assert transformation_result_0.tree == ast.AST()
    assert transformation_result_0.tree_changed == True
    assert transformation_result_0.dependencies == ['b', 'c']


# Generated at 2022-06-25 23:06:04.464535
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(None, None) == \
        InputOutput(Path(None), Path(None))


# Generated at 2022-06-25 23:06:10.236233
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=None, tree_changed=False, dependencies=None) is not None


# Generated at 2022-06-25 23:06:13.012332
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result_0 = TransformationResult()
    assert transformation_result_0.tree is None, "Expected: None. Actual: {}".format(transformation_result_0.tree)
    assert transformation_result_0.tree_changed is False, "Expected: False. Actual: {}".format(transformation_result_0.tree_changed)
    assert transformation_result_0.dependencies == [], "Expected: []. Actual: {}".format(transformation_result_0.dependencies)

# Generated at 2022-06-25 23:06:14.337656
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()


# Generated at 2022-06-25 23:06:16.734250
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path("/input")
    output = Path("/output")

    Io = InputOutput(input, output)

    assert Io.input == input
    assert Io.output == output


# Generated at 2022-06-25 23:06:17.771277
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert isinstance(transformation_result_0, TransformationResult)


# Generated at 2022-06-25 23:06:20.611559
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, False, [])
    assert TransformationResult(None, True, [])
    assert TransformationResult(None, False, ['a'])
    assert TransformationResult(None, True, ['a'])

# Generated at 2022-06-25 23:06:22.984983
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_0 = Path("/foo/bar.py")
    output_0 = Path("/foo/bar.pyc")
    input_output_0 = InputOutput(input_0, output_0)


# Generated at 2022-06-25 23:06:26.215636
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()
    assert input_output_0.input == None
    assert input_output_0.output == None


# Generated at 2022-06-25 23:06:27.280853
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()

# Generated at 2022-06-25 23:06:30.162349
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(1, 2, (3, 4), ['a', 'b'])
    assert c.files == 1
    assert c.time == 2
    assert c.target == (3, 4)
    assert c.dependencies == ['a', 'b']


# Generated at 2022-06-25 23:06:43.621447
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    input_val_1 = ast.Module()
    input_val_2 = True
    input_val_3 = ['a-input']
    expected_val = TransformationResult(input_val_1, input_val_2, input_val_3)
    actual_val = TransformationResult(input_val_1, input_val_2, input_val_3)
    assert actual_val == expected_val


# Generated at 2022-06-25 23:06:51.925698
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(
        files=1, time=1.2, target=(3, 7), dependencies=['foo', 'bar'])
    assert compilation_result.files == 1
    assert compilation_result.time == 1.2
    assert compilation_result.target == (3, 7)
    assert compilation_result.dependencies == ['foo', 'bar']
    assert str(compilation_result) == ('Files: 1.0\n'
                                       'Time: 1.2\n'
                                       'Target: (3, 7)\n'
                                       'Dependencies: foo, bar')
    # Test that we can access fields as attributes
    assert compilation_result.files == compilation_result[0]
    assert compilation_result.time == compilation_result[1]

# Generated at 2022-06-25 23:06:53.679242
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result = TransformationResult()
    assert transformation_result.tree == None
    assert transformation_result.tree_changed == False
    assert transformation_result.dependencies == None


# Generated at 2022-06-25 23:06:58.024473
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result_0 = TransformationResult(tree = ast.parse("while True: pass"), tree_changed = True, dependencies = list([""]))
    assert isinstance(transformation_result_0.tree, ast.AST)
    assert transformation_result_0.tree_changed == True
    assert transformation_result_0.dependencies == list([""])



# Generated at 2022-06-25 23:07:01.281264
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(1, 2.0, (3, 4), [])
    assert compilation_result.files == 1
    assert compilation_result.time == 2.0
    assert compilation_result.target == (3, 4)
    assert compilation_result.dependencies == []



# Generated at 2022-06-25 23:07:05.754180
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1, target=(3, 7), dependencies=[])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 7)
    assert result.dependencies == []
    assert not hasattr(result, 'not_defined')



# Generated at 2022-06-25 23:07:08.568632
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_0 = Path()
    output_0 = Path()
    input_output_0 = InputOutput()
    input_output_1 = InputOutput(input_0, output_0)

    assert input_output_1 is not None


# Generated at 2022-06-25 23:07:10.593494
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput('input','output')
    assert io.input == 'input'
    assert io.output == 'output'


# Generated at 2022-06-25 23:07:13.840922
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1, time=0.0, target=(3, 6), dependencies=list())
    assert compilation_result.files == 1
    assert compilation_result.time == 0.0
    assert compilation_result.target == (3, 6)
    assert len(compilation_result.dependencies) == 0


# Generated at 2022-06-25 23:07:16.825253
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result_0 = TransformationResult(tree=None,tree_changed=False, dependencies=['foo', 'bar'])
    assert transformation_result_0.tree == None
    assert transformation_result_0.tree_changed == False
    assert transformation_result_0.dependencies == ['foo', 'bar']


# Generated at 2022-06-25 23:07:39.424270
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result_0 = TransformationResult(tree=ast.AST(),
                                                    tree_changed=True,
                                                    dependencies=['b'])
    assert transformation_result_0.tree is not None
    assert transformation_result_0.tree_changed is not None
    assert transformation_result_0.dependencies is not None

# Generated at 2022-06-25 23:07:42.777672
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input_file.py')
    output = Path('output_file.py')

    input_output_0 = InputOutput(input, output)
    assert input_output_0.input == input
    assert input_output_0.output == output


# Generated at 2022-06-25 23:07:47.865298
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    target = CompilationTarget
    result = CompilationResult(files = 0,
                               time = 0.0,
                               target = target,
                               dependencies = [])


# Generated at 2022-06-25 23:07:50.335520
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path('a')
    path2 = Path('b')
    test = InputOutput(path1, path2)
    assert test.input == path1
    assert test.output == path2
    assert test.input is path1



# Generated at 2022-06-25 23:07:57.857788
# Unit test for constructor of class CompilationResult
def test_CompilationResult():

    a0 = CompilationResult(files=4, time=3.0, target=(3, 3), dependencies=['a', 'b'])

    try:
        assert a0.files == 4
        assert a0.time == 3.0
        assert a0.target == (3, 3)
        assert a0.dependencies == ['a', 'b']

        print(a0.files)
        print(a0.time)
        print(a0.target)
        print(a0.dependencies)
    except AssertionError as e:
        print(e)
        print("\nFailed test CompilationResult")
        exit(1)


# Generated at 2022-06-25 23:08:06.023860
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(files=1,
                                             time=0.1,
                                             target=(3, 7),
                                             dependencies=['string'])
    assert(compilation_result_0.files == 1)
    assert(compilation_result_0.time == 0.1)
    assert(compilation_result_0.target == (3, 7))
    assert(compilation_result_0.dependencies == ['string'])
    compilation_result_0 = CompilationResult(1, 0.1, (3, 7), ['string'])
    assert(compilation_result_0.files == 1)
    assert(compilation_result_0.time == 0.1)
    assert(compilation_result_0.target == (3, 7))

# Generated at 2022-06-25 23:08:07.035249
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result_0 = TransformationResult(None, None, None)


# Generated at 2022-06-25 23:08:09.057992
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_0 = Path('/tmp/input')
    output_0 = Path('/tmp/output')
    input_output_0 = InputOutput(input_0, output_0)


# Generated at 2022-06-25 23:08:11.646219
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(input=Path(), output=Path())
    if input_output.input is None or input_output.output is None:
        raise AssertionError("Constructor of class InputOutput is broken")


# Generated at 2022-06-25 23:08:14.744491
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("1")
    tree_changed = True
    dependencies = []

    transformation_result = TransformationResult(tree, tree_changed, dependencies)

    assert transformation_result.tree == tree
    assert transformation_result.tree_changed == tree_changed
    assert transformation_result.dependencies == dependencies


# Generated at 2022-06-25 23:09:02.610877
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult()


# Generated at 2022-06-25 23:09:03.917081
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=2, time=3, target=(3, 4), dependencies=['a', 'b'])

# Generated at 2022-06-25 23:09:05.950097
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_0 = Path('/foo/bar.txt')
    output_0 = Path('/baz.txt')
    input_output_0 = InputOutput(input_0, output_0)


# Generated at 2022-06-25 23:09:09.439626
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test_case_0()


if __name__ == '__main__':
    import sys
    import unittest

    suite = unittest.TestLoader().loadTestsFromTestCase(globals()[sys.argv[1]])
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-25 23:09:11.191772
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput("", "")
    assert input_output_0.input == ""
    assert input_output_0.output == ""


# Generated at 2022-06-25 23:09:13.843164
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path("input")
    o = Path("output")
    input_output = InputOutput(i, o)
    assert isinstance(input_output, InputOutput)
    assert input_output.input == i
    assert input_output.output == o


# Generated at 2022-06-25 23:09:21.738393
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformataion_result_0 = TransformationResult(tree=None, tree_changed=False, dependencies=[])
    transformataion_result_1 = TransformationResult(tree=None, tree_changed=False, dependencies=[])
    transformataion_result_2 = TransformationResult(tree=None, tree_changed=False, dependencies=[])
    transformataion_result_3 = TransformationResult(tree=None, tree_changed=False, dependencies=[])
    transformataion_result_4 = TransformationResult(tree=None, tree_changed=False, dependencies=[])
    transformataion_result_5 = TransformationResult(tree=None, tree_changed=False, dependencies=[])
    transformataion_result_6 = TransformationResult(tree=None, tree_changed=False, dependencies=[])

# Generated at 2022-06-25 23:09:24.119697
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result_0 = TransformationResult()

    assert transformation_result_0.tree is None
    assert transformation_result_0.tree_changed is False
    assert transformation_result_0.dependencies is None


# Generated at 2022-06-25 23:09:29.006488
# Unit test for constructor of class InputOutput
def test_InputOutput():
    first_input_output = InputOutput("input_0", "output_0")
    assert first_input_output.input.stem == "input_0"
    assert first_input_output.output.stem == "output_0"

    second_input_output = InputOutput("input_1", "output_1")
    assert second_input_output.input.stem == "input_1"
    assert second_input_output.output.stem == "output_1"


# Generated at 2022-06-25 23:09:30.296544
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(0, 0.0, (0, 0), [])


# Generated at 2022-06-25 23:11:20.995491
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(0, 0.0, (0, 0), [])
    # Test attribute: files
    assert isinstance(compilation_result.files, int)
    assert compilation_result.files == 0
    # Test attribute: time
    assert isinstance(compilation_result.time, float)
    assert compilation_result.time == 0.0
    # Test attribute: target
    assert isinstance(compilation_result.target, CompilationTarget)
    assert compilation_result.target == (0, 0)
    # Test attribute: dependencies
    assert isinstance(compilation_result.dependencies, List[str])
    assert compilation_result.dependencies == []


# Generated at 2022-06-25 23:11:27.528316
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult()
    assert compilation_result_0.files == 0
    assert compilation_result_0.time == 0
    assert compilation_result_0.target == (3, 7)
    assert len(compilation_result_0.dependencies) == 0
    compilation_result_1 = CompilationResult()
    assert compilation_result_0 == compilation_result_1
    compilation_result_1 = CompilationResult(1, 2, (3, 7), ['a'])
    assert compilation_result_0 != compilation_result_1


# Generated at 2022-06-25 23:11:31.646252
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=10.0, target=CompilationTarget(3, 5), dependencies=['abc', 'def'])
    assert(result.files == 1)
    assert(result.time == 10.0)
    assert(result.target == CompilationTarget(3, 5))
    assert(result.dependencies == ['abc', 'def'])


# Generated at 2022-06-25 23:11:35.161182
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """
    Test the constructor of class InputOutput.
    """
    input_0 = Path("input_0")
    output_0 = Path("output_0")
    input_output_0 = InputOutput(input_0, output_0)
    assert input_output_0.input == input_0
    assert input_output_0.output == output_0


# Generated at 2022-06-25 23:11:37.999447
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result_0 = TransformationResult(tree = ast.Module(), tree_changed = True, dependencies = ['ast'])
    assert(transformation_result_0.tree == ast.Module())
    assert(transformation_result_0.tree_changed == True)
    assert(transformation_result_0.dependencies == ['ast'])


# Generated at 2022-06-25 23:11:40.550437
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/a')
    output = Path('/tmp/b')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-25 23:11:42.774865
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(files=0, time=0.0, target=(3, 5), dependencies=[])
    if not isinstance(compilation_result_0, CompilationResult):
        raise RuntimeError('Constructor of class CompilationResult is broken.')


# Generated at 2022-06-25 23:11:48.605449
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=1, target=(3,6), dependencies=['a','b'])
    assert cr.files == 1
    assert cr.time == 1
    assert cr.target == (3,6)
    assert cr.dependencies == ['a','b']

    cr = CompilationResult(files=1, time=1, target=(3,6), dependencies=[])
    assert cr.files == 1
    assert cr.time == 1
    assert cr.target == (3,6)
    assert cr.dependencies == []



# Generated at 2022-06-25 23:11:51.709278
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(1, 0.1, (3, 7), ['test_dependency'])
    assert compilation_result.files == 1
    assert compilation_result.time == 0.1
    assert compilation_result.target == (3, 7)
    assert compilation_result.dependencies == ['test_dependency']


# Generated at 2022-06-25 23:11:53.474806
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    with pytest.raises(TypeError):
        transformation_result_0 = TransformationResult(
            'test_ast', True, 'test_dependencies')


test_case_0()

