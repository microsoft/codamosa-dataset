

# Generated at 2022-06-25 23:03:40.246930
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(0, 0.0, (0,0), []).files == 0
    assert CompilationResult(0, 0.0, (0,0), []).time == 0.0
    assert CompilationResult(0, 0.0, (0,0), []).target == (0,0)
    assert CompilationResult(0, 0.0, (0,0), []).dependencies == []


# Generated at 2022-06-25 23:03:41.879021
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(1, 1.0, (1, 1), [])



# Generated at 2022-06-25 23:03:46.214711
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(0, 0, (0, 0), [])
    assert compilation_result.files == 0
    assert compilation_result.time == 0
    assert compilation_result.target == (0, 0)
    assert compilation_result.dependencies == []

# Unit tests for constructor of class TransformationResult

# Generated at 2022-06-25 23:03:50.981044
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files = 5,
                                           time = 5.0,
                                           target = (2, 7),
                                           dependencies = [])
    assert(compilation_result.files == 5)
    assert(compilation_result.time == 5.0)
    assert(compilation_result.target == (2, 7))
    assert(compilation_result.dependencies == [])


# Generated at 2022-06-25 23:03:51.816329
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert test_case_0()



# Generated at 2022-06-25 23:03:54.581860
# Unit test for constructor of class InputOutput
def test_InputOutput():
    try:
        input_output_0 = InputOutput()
    except Exception:
        assert False
    
    assert input_output_0.input == None
    assert input_output_0.output == None
    

# Generated at 2022-06-25 23:03:58.511706
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(1, 1, (1, 1), [])

    assert compilation_result.files == 1
    assert compilation_result.time == 1
    assert compilation_result.target == (1, 1)
    assert compilation_result.dependencies == []


# Generated at 2022-06-25 23:04:00.014349
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_0 = CompilationResult(0, 0, (0, 0), [])



# Generated at 2022-06-25 23:04:01.339524
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult()


# Generated at 2022-06-25 23:04:02.549515
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result_0 = TransformationResult()



# Generated at 2022-06-25 23:04:06.555073
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_0 = Path("input")
    output_0 = Path("output")
    InputOutput(input_0, output_0)

# Generated at 2022-06-25 23:04:09.343187
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult()
    assert compilation_result.files == 0
    assert compilation_result.time == 0.0
    assert compilation_result.target == (3, 6)


# Generated at 2022-06-25 23:04:11.138612
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result_0 = TransformationResult(tree=None,
                                                   tree_changed=None,
                                                   dependencies=None)


# Generated at 2022-06-25 23:04:14.065715
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result = TransformationResult()
    assert transformation_result.tree == None
    assert transformation_result.tree_changed == False
    assert transformation_result.dependencies == None


# Generated at 2022-06-25 23:04:16.869681
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert isinstance(transformation_result_0, TransformationResult)
    assert transformation_result_0.tree == None
    assert transformation_result_0.tree_changed == None
    assert transformation_result_0.dependencies == None


# Generated at 2022-06-25 23:04:21.937925
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result = TransformationResult(ast.AST(),
                                                 True,
                                                 List[str]())
    assert isinstance(transformation_result, TransformationResult)
    assert isinstance(transformation_result.tree, ast.AST)
    assert isinstance(transformation_result.tree_changed, bool)
    assert isinstance(transformation_result.dependencies, List[str])


# Generated at 2022-06-25 23:04:24.188342
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    try:
        result = CompilationResult(0, 0.0, (0, 0), [])
    except Exception:
        assert True
    else:
        assert False


# Generated at 2022-06-25 23:04:25.936415
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult()


# Module test for constructor of class CompilationResult

# Generated at 2022-06-25 23:04:29.198647
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(2, 3.3, (3, 6), ['test'])
    assert result.files == 2
    assert result.time == 3.3
    assert result.target == (3, 6)
    assert result.dependencies == ['test']


# Generated at 2022-06-25 23:04:31.524173
# Unit test for constructor of class InputOutput
def test_InputOutput():

    # Test initialization with empty object
    try:
        inputOutput = InputOutput({}, {})
    except TypeError as err:
        assert(str(err) == 'invalid input/output pair')


# Generated at 2022-06-25 23:04:38.655796
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    input_output_0 = InputOutput()
    transformation_result_0 = TransformationResult(tree=input_output_0.input, tree_changed=False, dependencies=None)
    assert transformation_result_0.tree is input_output_0.input
    assert not transformation_result_0.tree_changed
    assert transformation_result_0.dependencies is None


# Generated at 2022-06-25 23:04:40.177187
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(0, 1, (1, 1), ["a"])


# Generated at 2022-06-25 23:04:49.842674
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result_0 = TransformationResult()
    transformation_result_1 = TransformationResult(tree = None)
    transformation_result_2 = TransformationResult(tree_changed = False)
    transformation_result_3 = TransformationResult(dependencies = None)
    transformation_result_4 = TransformationResult()
    transformation_result_5 = TransformationResult()
    assert transformation_result_4.tree is None
    assert not transformation_result_4.tree_changed
    assert transformation_result_4.dependencies is None
    assert transformation_result_5.tree == transformation_result_4.tree
    assert transformation_result_5.tree_changed == transformation_result_4.tree_changed
    assert transformation_result_5.dependencies == transformation_result_4.dependencies

# Generated at 2022-06-25 23:04:51.225894
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path("input")
    output = Path("output")

# Generated at 2022-06-25 23:04:54.969000
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(1, 0.1, (0, 1), [])
    assert compilation_result.files == 1
    assert compilation_result.time == 0.1
    assert compilation_result.target == (0, 1)
    assert compilation_result.dependencies == []


# Generated at 2022-06-25 23:05:00.943500
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inputOutput = InputOutput(Path('foo'), Path('bar'))
    assert inputOutput.input == Path('foo')
    assert inputOutput.output == Path('bar')
    inputOutput.input = Path('baz')
    inputOutput.output = Path('oof')
    assert inputOutput.input == Path('baz')
    assert inputOutput.output == Path('oof')


# Generated at 2022-06-25 23:05:04.281380
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result = TransformationResult((ast.AST(),True,["fake.py","fake2,py"]))
    assert transformation_result.tree is not None
    assert transformation_result.tree_changed is True
    assert transformation_result.dependencies is not None


# Generated at 2022-06-25 23:05:10.528078
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result_0 = TransformationResult(tree=ast.parse('import sys'),
                                                   tree_changed=True,
                                                   dependencies=['sys'])
    assert(transformation_result_0.tree != None)
    assert(transformation_result_0.tree_changed == True)
    assert(transformation_result_0.dependencies == ['sys'])

# Generated at 2022-06-25 23:05:12.651142
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert isinstance(test_case_0(), TransformationResult)


# Generated at 2022-06-25 23:05:14.241844
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path("/tmp/foo"), Path("/tmp/bar")) is not None


# Generated at 2022-06-25 23:05:25.363765
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result_0 = TransformationResult()
    assert transformation_result_0.tree is None
    assert transformation_result_0.tree_changed is False
    assert transformation_result_0.dependencies == []
    transformation_result_1 = TransformationResult(
        ast.parse('pass'), False)
    assert transformation_result_1.dependencies == []
    transformation_result_2 = TransformationResult(
        ast.parse('pass'), 'False')
    assert transformation_result_2.dependencies == []
    transformation_result_3 = TransformationResult(
        ast.parse('pass'), False, [])
    assert transformation_result_3.dependencies == []
    transformation_result_4 = TransformationResult(
        ast.parse('pass'), tree_changed=True, dependencies=[])
    assert transformation_result_4.dependencies == []


compilation

# Generated at 2022-06-25 23:05:28.655097
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = InputOutput(input = '/a/b/c', output = '/a/b/c')
    assert a.input == '/a/b/c'
    assert a.output == '/a/b/c'


# Generated at 2022-06-25 23:05:32.398659
# Unit test for constructor of class InputOutput
def test_InputOutput():
  test_input_output = InputOutput(input=Path('input.py'), output=Path('output.cpython-36.pyc'))
  assert test_input_output.input == Path('input.py')
  assert test_input_output.output == Path('output.cpython-36.pyc')


# Generated at 2022-06-25 23:05:36.916362
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result_0 = TransformationResult()
    assert transformation_result_0.tree == None
    tree_changed_0 = False
    assert transformation_result_0.tree_changed == tree_changed_0
    dependencies_0 = []
    assert transformation_result_0.dependencies == dependencies_0


if __name__ == '__main__':
    test_TransformationResult()

# Generated at 2022-06-25 23:05:39.228929
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result_0 = TransformationResult(tree=ast.AST(), tree_changed=True, dependencies=['ast'])
    assert transformation_result_0.dependencies == ['ast']


# Generated at 2022-06-25 23:05:41.345885
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result_1 = TransformationResult(1, 2, 3)
    assert transformation_result_1.tree == 1
    assert transformation_result_1.tree_changed == 2

# Generated at 2022-06-25 23:05:45.983211
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path("in.py")
    output = Path("out.py")
    test_case = InputOutput(input, output)
    assert test_case.input == input
    assert test_case.output == output


# Generated at 2022-06-25 23:05:47.255503
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert isinstance(TransformationResult(ast.parse('a=1'), True, []), TransformationResult)


# Generated at 2022-06-25 23:05:52.995444
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(0, 0.0, (3, 5), [])
    assert isinstance(compilation_result.files, int)
    assert isinstance(compilation_result.time, float)
    assert isinstance(compilation_result.target, CompilationTarget)
    assert isinstance(compilation_result.dependencies, tuple)


# Generated at 2022-06-25 23:05:54.862428
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert True



# Generated at 2022-06-25 23:06:03.254831
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=1, time=1.0, target=(3, 7),
                            dependencies=['a', 'b/c/d'])
    assert res.files == 1
    assert res.time == 1.0
    assert res.target == (3, 7)
    assert res.dependencies == ['a', 'b/c/d']


# Generated at 2022-06-25 23:06:06.746521
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_file = Path('test.py')
    output_file = Path('test_compiled.py')
    io_pair = InputOutput(input_file, output_file)
    assert io_pair.input == input_file
    assert io_pair.output == output_file



# Generated at 2022-06-25 23:06:08.812822
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.AST(), False, ['1', '2', '2'])
    assert isinstance(tr, TransformationResult)

# Generated at 2022-06-25 23:06:11.090002
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=0,
                           time=0,
                           target=(0, 0),
                           dependencies=[])
    assert isinstance(cr, CompilationResult)


# Generated at 2022-06-25 23:06:12.037917
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path("foo.py"), Path("bar.js")) is not None


# Generated at 2022-06-25 23:06:15.407539
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path("path/to/input")
    out = Path("path/to/output")
    iop = InputOutput(inp, out)
    assert iop.input == inp
    assert iop.output == out


# Generated at 2022-06-25 23:06:20.533581
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    a = TransformationResult(ast.Module([]), True, [])
    b = TransformationResult(ast.Module([]), False, [])
    c = TransformationResult(ast.Module([]), True, [])
    if a != c or a == b or b == c or hash(a) != hash(c) or hash(a) == hash(b) or hash(b) == hash(c):
        raise ValueError
    print("test_TransformationResult finished successfully")


# Generated at 2022-06-25 23:06:22.901750
# Unit test for constructor of class InputOutput
def test_InputOutput():
    source = Path('source')
    output = Path('output')
    input_output = InputOutput(source, output)
    assert input_output.input == source
    assert input_output.output == output

# Generated at 2022-06-25 23:06:27.281012
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(5, 0.5, (3, 5), ['urllib.request'])
    CompilationResult(files=5,
                      time=0.5,
                      target=(3, 5),
                      dependencies=['urllib.request'])


# Generated at 2022-06-25 23:06:30.272403
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    r = TransformationResult(
        tree = ast.AST(),
        tree_changed = True,
        dependencies = ['foo', 'bar']
    )
    assert r.tree != None
    assert r.tree_changed == True
    assert r.dependencies == ['foo', 'bar']

# Result of transformers.transformation
CompilationResult = NamedTuple('CompilationResult',
                               [('files', int),
                                ('time', float),
                                ('target', CompilationTarget),
                                ('dependencies', List[str])])

# Generated at 2022-06-25 23:06:42.810800
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path("/test/input")
    output = Path("/test/output")
    path = InputOutput(input_, output)
    assert path.input == input_
    assert path.output == output
    assert str(path) == "InputOutput(input='/test/input', output='/test/output')"


# Generated at 2022-06-25 23:06:46.276113
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1, target=(3, 7), dependencies=[])
    assert result.files == 1
    assert result.time == 1
    assert result.target == (3, 7)
    assert result.dependencies == []


# Generated at 2022-06-25 23:06:53.348193
# Unit test for constructor of class InputOutput
def test_InputOutput():
    with pytest.raises(TypeError):
        InputOutput([], [])
    with pytest.raises(TypeError):
        InputOutput('a', 'b')

    path1 = InputOutput(Path('a'), Path('b'))
    path2 = InputOutput(Path('a'), Path('b'))
    path3 = InputOutput(Path('a'), Path('c'))
    assert path1 == path2
    assert path1 != path3

    assert hash(path1) == hash(path2)
    assert hash(path1) != hash(path3)

    assert repr(path1) == "InputOutput(input=PosixPath('a'), output=PosixPath('b'))"
    assert str(path1) == "a -> b"


# Generated at 2022-06-25 23:06:56.335637
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p1 = Path("/a/b/a.py")
    p2 = Path("/c/d/e/a.pyc")
    x = InputOutput(input=p1, output=p2)
    assert x.input == p1
    assert x.output == p2

# Generated at 2022-06-25 23:07:01.492268
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Arrange
    dummy_tree = ast.Module()
    dummy_tree_changed = True
    dummy_dependencies = ['foo.py']

    # Act
    result = TransformationResult(dummy_tree, dummy_tree_changed, dummy_dependencies)

    # Assert
    assert result.tree == dummy_tree
    assert result.tree_changed == dummy_tree_changed
    assert result.dependencies == dummy_dependencies

# Generated at 2022-06-25 23:07:05.645048
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=2, time=0.4, target=(3, 7), dependencies=['foo'])
    assert result.files == 2
    assert result.time == 0.4
    assert result.target == (3, 7)
    assert result.dependencies == ['foo']


# Generated at 2022-06-25 23:07:09.197495
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_input = Path('test1.py')
    test_output = Path('modules/test1.py')
    input_output = InputOutput(test_input, test_output)
    assert input_output.input == test_input
    assert input_output.output == test_output



# Generated at 2022-06-25 23:07:12.382199
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(42, 42.0, (3, 8), ['foo', 'bar'])
    assert cr.files == 42
    assert cr.time == 42.0
    assert cr.target == (3, 8)
    assert cr.dependencies == ['foo', 'bar']


# Generated at 2022-06-25 23:07:13.697156
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 0.5, (3, 7), ['file1', 'file2'])

# Generated at 2022-06-25 23:07:15.842042
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = 'abc'
    outp = 'def'
    iop = InputOutput(inp, outp)
    assert iop.input == 'abc'
    assert iop.output == 'def'

# Generated at 2022-06-25 23:07:39.387400
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    instance = CompilationResult(files=10,
                                 time=0.1,
                                 target=(3, 6),
                                 dependencies=['foo'])
    assert(instance.files == 10)
    assert(instance.time == 0.1)
    assert(instance.target == (3, 6))
    assert(instance.dependencies == ['foo'])


# Generated at 2022-06-25 23:07:42.776215
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path('path1')
    path2 = Path('path2')
    input_output = InputOutput(input=path1, output=path2)
    assert input_output.input == path1
    assert input_output.output == path2


# Generated at 2022-06-25 23:07:48.627633
# Unit test for constructor of class InputOutput
def test_InputOutput():
    t = InputOutput(Path('foo'), Path('bar'))
    assert t.input == Path('foo')
    assert t.output == Path('bar')
    assert str(t.input) == 'foo'
    assert str(t.output) == 'bar'

# Generated at 2022-06-25 23:07:55.716866
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(
        1, 0.1, (3, 5), ['a.py', 'b.py']).files == 1
    assert CompilationResult(
        1, 0.1, (3, 5), ['a.py', 'b.py']).time == 0.1
    assert CompilationResult(
        1, 0.1, (3, 5), ['a.py', 'b.py']).target == (3, 5)
    assert CompilationResult(
        1, 0.1, (3, 5), ['a.py', 'b.py']).dependencies == ['a.py', 'b.py']


# Generated at 2022-06-25 23:08:00.545020
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = InputOutput(Path('test1.py'), Path('test2.py'))
    assert i.input == Path('test1.py') and i.output == Path('test2.py')

    # Check that named constructor abbreviate the code
    i = InputOutput(input='test1.py', output='test2.py')
    assert i.input == Path('test1.py') and i.output == Path('test2.py')

# Generated at 2022-06-25 23:08:04.322346
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    dep = ['type_comment']
    o = CompilationResult(files=1, time=1.0, target=(3, 0),
                          dependencies=dep)
    assert o.files == 1
    assert o.time == 1.0
    assert o.target == CompilationTarget(3, 0)
    assert o.dependencies == dep, o.dependencies


# Generated at 2022-06-25 23:08:05.497661
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.AST(), True, ['foo', 'bar'])

# Generated at 2022-06-25 23:08:07.631260
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('/tmp/a'), Path('/tmp/b')) == (
        InputOutput(Path('/tmp/a'), Path('/tmp/b')))



# Generated at 2022-06-25 23:08:09.819155
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p1 = Path('foo')
    p2 = Path('bar')
    inout = InputOutput(p1, p2)
    assert inout.input == p1
    assert inout.output == p2


# Generated at 2022-06-25 23:08:15.024996
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.AST(),
                         tree_changed=True,
                         dependencies=['a'])
    TransformationResult(ast.AST(),
                         tree_changed=False,
                         dependencies=['a'])

# Result of file transformations
FileTransformationResult = NamedTuple('FileTransformationResult',
                                      [('tree', ast.AST),
                                       ('input_output', InputOutput)])


# Result of the compilation process
Compilation = NamedTuple('Compilation',
                         [('result', CompilationResult),
                          ('tree', ast.AST)])

# Generated at 2022-06-25 23:09:04.170962
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=1,
                             time=2.34,
                             target=(3, 4),
                             dependencies=['a', 'b', 'c'])

    assert CompilationResult(files=1,
                             time=2.34,
                             target=(3, 4),
                             dependencies=[])


# Generated at 2022-06-25 23:09:05.139344
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(tree=None, tree_changed=False, dependencies=[])

# Generated at 2022-06-25 23:09:08.081433
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # pylint: disable=bad-whitespace
    _ = CompilationResult( files=1, time=1, target=(3,5), dependencies=['a','b','c'])
    # pylint: enable=bad-whitespace


# Generated at 2022-06-25 23:09:09.894299
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.AST(), True, [])
    TransformationResult(ast.AST(), False, [])
    TransformationResult(ast.AST(), True, ['a'])

# Generated at 2022-06-25 23:09:13.573623
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Create compilation result
    comp_res = CompilationResult(files=1, time=3.44, target=(3, 4), dependencies=['a.py'])
    assert comp_res.files == 1
    assert comp_res.time == 3.44
    assert comp_res.target == (3, 4)
    assert comp_res.dependencies == ['a.py']


# Generated at 2022-06-25 23:09:18.355633
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(5, 1.3, (3, 8), []).files == 5
    assert CompilationResult(5, 1.3, (3, 8), []).time == 1.3
    assert CompilationResult(5, 1.3, (3, 8), []).target == (3, 8)
    assert CompilationResult(5, 1.3, (3, 8), []).dependencies == []


# Generated at 2022-06-25 23:09:21.058659
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=0, time=0, target=(3, 7),
                               dependencies=[])
    assert result.files == 0
    assert result.time == 0
    assert result.target == (3, 7)
    assert result.dependencies == []


# Generated at 2022-06-25 23:09:24.042535
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 0.1, (3, 5), [])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 5)
    assert result.dependencies == []


# Generated at 2022-06-25 23:09:28.938914
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Creation with Path objects
    _input = Path('input')
    _output = Path('output')
    path_input_output = InputOutput(_input, _output)
    assert path_input_output.input == _input
    assert path_input_output.output == _output

    # Creation with strings
    string_input_output = InputOutput('input', 'output')
    assert string_input_output.input == _input
    assert string_input_output.output == _output

# Generated at 2022-06-25 23:09:31.758903
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = "/tmp/test.txt"
    output = "/tmp/test2.txt"
    io = InputOutput(input=Path(input_), output=Path(output))
    io1 = InputOutput(input=input_, output=output)
    assert io1 == io



# Generated at 2022-06-25 23:11:16.387215
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_input = Path('a')
    test_output = Path('b')
    a = InputOutput(test_input, test_output)
    assert a.input == test_input
    assert a.output == test_output


# Generated at 2022-06-25 23:11:18.457603
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output

# Generated at 2022-06-25 23:11:19.599842
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=None, tree_changed=False, dependencies=None)

# Generated at 2022-06-25 23:11:23.023578
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    """CompilationResult should have:
    - files: int
    - time: float
    - target: CompilationTarget
    - dependencies: List[str]
    """
    assert CompilationResult(files=1,
                             time=1.0,
                             target=(3, 6),
                             dependencies=['abc.py'])


# Generated at 2022-06-25 23:11:26.608007
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('1 + 1')
    tr = TransformationResult(t, False, ['a', 'b'])
    assert tr.tree == t
    assert tr.tree_changed == False
    assert tr.dependencies == ['a', 'b']

# Generated at 2022-06-25 23:11:29.778242
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Given
    input = Path('/a/b/c.py')
    output = Path('/d/e/f.py')

    # When
    c = InputOutput(input, output)

    # Then
    assert c.input == input
    assert c.output == output


# Generated at 2022-06-25 23:11:32.769561
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(42, 3.14, (3, 4), ["foo", "bar"])
    assert result.files == 42
    assert result.time == 3.14
    assert result.target == (3, 4)
    assert result.dependencies == ["foo", "bar"]


# Generated at 2022-06-25 23:11:35.560034
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(10, 50, (2, 7), ['a', 'b', 'c'])
    assert result.files == 10
    assert result.time == 50
    assert result.target == (2, 7)
    assert result.dependencies == ['a', 'b', 'c']


# Generated at 2022-06-25 23:11:37.684709
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('input')
    o = Path('output')
    input_output = InputOutput(input=i, output=o)
    assert input_output.input == i
    assert input_output.output == o


# Generated at 2022-06-25 23:11:39.471061
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, False, [])


# Exception raised by UndecoratedTransformer, when it fails to transform file