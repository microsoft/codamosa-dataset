

# Generated at 2022-06-25 23:03:38.343078
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_target_0 = CompilationTarget()
    compilation_result_0 = CompilationResult(files=1234, time=3.141592653589793, target=compilation_target_0, dependencies=['hello'])


# Generated at 2022-06-25 23:03:40.166778
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()
    assert isinstance(input_output_0, InputOutput)


# Generated at 2022-06-25 23:03:41.124895
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_case_0()


# Generated at 2022-06-25 23:03:42.978356
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()
    assert input_output_0.input == None
    assert input_output_0.output == None

# Generated at 2022-06-25 23:03:47.622400
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.AST()
    tree_changed = bool()
    dependencies = List[str]()

    # Constructor without argument
    transformation_result_0 = TransformationResult()

    # Constructor with argument
    transformation_result_1 = TransformationResult(tree=tree, tree_changed=tree_changed,
                                                   dependencies=dependencies)


# Generated at 2022-06-25 23:03:49.143336
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(1, 2, (3, 4), ['dependency_0'])



# Generated at 2022-06-25 23:03:52.930147
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_1 = InputOutput(Path('input'), Path('output'))
    assert input_output_1.input == Path('input')
    assert input_output_1.output == Path('output')


# Generated at 2022-06-25 23:04:02.143155
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(0, 0.0, (0, 0), [])
    # print(compilation_result_0)
    compilation_result_1 = CompilationResult(0, 0.0, (0, 0), [])
    # print(compilation_result_1)
    assert compilation_result_0.files == 0
    assert compilation_result_0.time == 0.0
    assert compilation_result_0.target == (0, 0)
    assert compilation_result_0.dependencies == []
    compilation_result_2 = CompilationResult(3, 2.0, (0, 0), ['test/test_file.py'])
    # print(compilation_result_2)

# Generated at 2022-06-25 23:04:03.303246
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()



# Generated at 2022-06-25 23:04:04.478492
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult()
    

# Generated at 2022-06-25 23:04:13.144139
# Unit test for constructor of class CompilationResult
def test_CompilationResult():

    # Define some data
    files_0: int = 3
    time_0: float = 2.0
    target_0: CompilationTarget = (2, 7)
    dependencies_0: List[str] = []

    # Construct the object
    obj_0 = CompilationResult(files_0, time_0, target_0, dependencies_0)

    # Check the type annotations
    assert(isinstance(obj_0.files, int))
    assert(isinstance(obj_0.time, float))
    assert(isinstance(obj_0.target, CompilationTarget))
    assert(isinstance(obj_0.dependencies, List[str]))



# Generated at 2022-06-25 23:04:15.767831
# Unit test for constructor of class InputOutput
def test_InputOutput():
    result = InputOutput(Path("a"), Path("b"))
    assert result.input == "a"
    assert result.output == "b"


# Generated at 2022-06-25 23:04:18.542678
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_1 = InputOutput(input=Path("input"), output=Path("output"))
    assert input_output_1.input == Path("input")
    assert input_output_1.output == Path("output")


# Generated at 2022-06-25 23:04:20.229969
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    input_output_0 = InputOutput()
    transformation_result_0 = TransformationResult()

# Generated at 2022-06-25 23:04:29.281285
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    input_output_0 = InputOutput()
    assert input_output_0.input is None
    assert input_output_0.output is None
    input_output_1 = InputOutput(input='', output='', )
    assert input_output_1.input == ''
    assert input_output_1.output == ''
    input_output_2 = InputOutput(input='input', output='input')
    assert input_output_2.input == 'input'
    assert input_output_2.output == 'input'
    input_output_3 = InputOutput(input='input', output='input', )
    assert input_output_3.input == 'input'
    assert input_output_3.output == 'input'
    input_output_4 = InputOutput(input='input', output='input', )
    assert input_output_4

# Generated at 2022-06-25 23:04:30.627058
# Unit test for constructor of class InputOutput
def test_InputOutput():


    input_output_0 = InputOutput(input=Path(),
                                 output=Path())
    assert input_output_0.input == Path()
    assert input_output_0.output == Path()


# Generated at 2022-06-25 23:04:35.236914
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Constructor without parameters
    t_0 = TransformationResult()
    assert t_0.tree is None
    assert t_0.tree_changed is False
    assert t_0.dependencies == list()

    # Constructor with parameters
    l_0 = list()
    t_0 = TransformationResult(ast.AST(), True, l_0)
    assert t_0.tree is not None
    assert t_0.tree_changed is True
    assert t_0.dependencies == l_0


# Generated at 2022-06-25 23:04:39.647064
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(
        files=0,
        time=0.0,
        target=(2, 7),
        dependencies=[]
    ) == CompilationResult(
        files=0,
        time=0.0,
        target=(2, 7),
        dependencies=[]
    )


# Generated at 2022-06-25 23:04:43.404297
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_1 = CompilationResult(0, 0.0, (0, 0), [])
    assert compilation_result_1.files == 0
    assert compilation_result_1.time == 0.0
    assert compilation_result_1.target == (0, 0)
    assert compilation_result_1.dependencies == []



# Generated at 2022-06-25 23:04:56.903062
# Unit test for constructor of class InputOutput
def test_InputOutput():
    c0 = InputOutput()
    assert isinstance(c0, NamedTuple), "Wrong type: InputOutput=%r" % (type(c0))
    assert c0.input is None, "Wrong value: InputOutput.input=%r" % (c0.input,)
    assert c0.output is None, "Wrong value: InputOutput.output=%r" % (c0.output,)
    c1 = InputOutput(input=Path('input.py'), output=Path('output.py'))
    assert isinstance(c1, NamedTuple), "Wrong type: InputOutput=%r" % (type(c1))
    assert isinstance(c1.input, Path), "Wrong type: InputOutput.input=%r" % (type(c1.input))

# Generated at 2022-06-25 23:05:03.752541
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()
    assert(input_output_0.input == None)
    assert(input_output_0.output == None)


# Generated at 2022-06-25 23:05:08.313382
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree_0 = ast.AST()
    dependencies_0 = list()
    res_0 = TransformationResult(tree_0, True, dependencies_0)


# Generated at 2022-06-25 23:05:11.996186
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()
    assert isinstance(input_output_0, InputOutput)
    assert input_output_0.input is None
    assert input_output_0.output is None


# Generated at 2022-06-25 23:05:13.223233
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert True



# Generated at 2022-06-25 23:05:14.443505
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()


# Generated at 2022-06-25 23:05:18.284641
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Test the functionality of the constructor of class CompilationResult
    compilation_result_0 = CompilationResult()
    assert isinstance(compilation_result_0, CompilationResult)
    assert isinstance(compilation_result_0, NamedTuple)


# Generated at 2022-06-25 23:05:21.899886
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result0 = TransformationResult(
        ast.AST(body=[]),
        True,
        ["file0"]
    )
    assert result0.tree_changed == True
    assert result0.dependencies == ["file0"]
    assert result0.tree.body == []

# Generated at 2022-06-25 23:05:24.441689
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(1, 1.1, (3, 4), [])
    


# Generated at 2022-06-25 23:05:26.444656
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult()


# Generated at 2022-06-25 23:05:28.634361
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    comp_result_0 = CompilationResult(
        files=0,
        time=0,
        target=(0, 0),
        dependencies=['a']
    )


# Generated at 2022-06-25 23:05:37.197532
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=0.123,
                               target=(3, 2),
                               dependencies=[])
    assert result.files == 1
    assert result.time == 0.123
    assert result.target == (3, 2)
    assert result.dependencies == []


# Generated at 2022-06-25 23:05:38.043796
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(input, output)



# Generated at 2022-06-25 23:05:41.303179
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 2.0, (3, 4), ['a', 'b'])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == ['a', 'b']

# Generated at 2022-06-25 23:05:47.313098
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    transformation_result = TransformationResult(tree=ast.parse('a=1'),
                                                  tree_changed=True,
                                                  dependencies=['foo'])
    assert transformation_result.tree_changed
    assert transformation_result.dependencies == ['foo']
    # test that we can unpickle the namedtuple
    assert pickle.loads(pickle.dumps(transformation_result))

# Generated at 2022-06-25 23:05:57.933501
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('0')
    f1 = ast.FunctionDef(name='f1', args=ast.arguments(args=[], vararg=None, kwarg=None, defaults=[]),
                         body=[], decorator_list=[], returns=None)
    f2 = ast.FunctionDef(name='f2', args=ast.arguments(args=[], vararg=None, kwarg=None, defaults=[]),
                         body=[], decorator_list=[], returns=None)
    tr = TransformationResult(tree, True, ['a', str(f1), str(f2)])
    assert tr.tree is tree
    assert tr.tree_changed is True
    assert tr.dependencies == ['a', str(f1), str(f2)]

# Generated at 2022-06-25 23:06:01.814353
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    path = Path('test')
    compilation_result = CompilationResult(1, 1.1, (0, 0), [path])
    assert compilation_result.files == 1
    assert compilation_result.time == 1.1
    assert compilation_result.target == (0, 0)
    assert compilation_result.dependencies == [path]



# Generated at 2022-06-25 23:06:03.364330
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2.0, (3, 4), ['foo', 'bar'])


# Generated at 2022-06-25 23:06:06.009231
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse('pass'), False, []).tree_changed
    assert not TransformationResult(ast.parse('pass'), False, []).tree_changed
    assert TransformationResult(ast.parse('pass'), False, []).dependencies == []

# Generated at 2022-06-25 23:06:14.255665
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # pylint: disable=redefined-outer-name
    from datetime import date

    # pylint: disable=invalid-name
    def Assert(expected_tree,
               expected_tree_changed,
               expected_dependencies,
               actual_tree,
               actual_tree_changed,
               actual_dependencies):
        assert expected_tree == actual_tree
        assert expected_tree_changed == actual_tree_changed
        assert expected_dependencies == actual_dependencies
    tree = date
    dependencies = ['x', 'y', 'z']
    Assert(tree, False, dependencies,
           TransformationResult(tree, False, dependencies))
    Assert(tree, True, dependencies,
           TransformationResult(tree, True, dependencies))
    return

# Generated at 2022-06-25 23:06:17.241287
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/home/user/test.py')
    output = Path('/home/user/test_compiled.py')
    in_out = InputOutput(input, output)
    assert in_out.input == input
    assert in_out.output == output

# Generated at 2022-06-25 23:06:33.266803
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Normal constructor
    result = CompilationResult(1, 2.0, (3, 7), [])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 7)
    assert result.dependencies == []

    # Bad constructor
    with pytest.raises(TypeError):
        CompilationResult("1", 2.0, (3, 7), [])
    with pytest.raises(TypeError):
        CompilationResult(1, "2.0", (3, 7), [])
    with pytest.raises(TypeError):
        CompilationResult(1, 2.0, [3, 7], [])
    with pytest.raises(TypeError):
        CompilationResult(1, 2.0, (3, 7), "")

# Unit test

# Generated at 2022-06-25 23:06:38.704331
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=1.0,
                               target=(3, 5),
                               dependencies=['foo', 'bar'])
    assert isinstance(result.files, int)
    assert isinstance(result.time, float)
    assert isinstance(result.target, tuple)
    assert isinstance(result.dependencies, list)


# Generated at 2022-06-25 23:06:41.822925
# Unit test for constructor of class InputOutput
def test_InputOutput():
    with pytest.raises(TypeError):
        InputOutput(input=0, output=1)
    with pytest.raises(TypeError):
        InputOutput(input=Path('.'), output=0)


# Generated at 2022-06-25 23:06:43.238068
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.Module(), True, ['__future__']).dependencies == ['__future__']

# Generated at 2022-06-25 23:06:45.227361
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    try:
        _ = TransformationResult(ast.AST(), False, [])
    except TypeError:
        assert False, 'TypeError was raised'

# Generated at 2022-06-25 23:06:47.939625
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput('input', 'output')
    assert str(input_output.input) == 'input'
    assert str(input_output.output) == 'output'


# Generated at 2022-06-25 23:06:51.336275
# Unit test for constructor of class InputOutput
def test_InputOutput():
    Path = __import__('pathlib').Path
    input_path = Path('input.txt')
    output_path = Path('output.txt')
    input_output = InputOutput(input_path, output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path


# Generated at 2022-06-25 23:06:53.280477
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Check that TransformationResult constructor works without fail
    t = TransformationResult(0, False, [])
    assert t.tree == 0
    assert t.tree_changed == False
    assert t.dependencies == []

# Generated at 2022-06-25 23:06:57.333443
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    dummy_result = CompilationResult(1, 1, (2, 3), ['a', 'b'])
    assert isinstance(dummy_result.files, int)
    assert isinstance(dummy_result.time, float)
    assert isinstance(dummy_result.target, CompilationTarget)
    assert isinstance(dummy_result.dependencies, List)


# Generated at 2022-06-25 23:06:59.834973
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 1.0, (3, 5), []) is not None
    assert CompilationResult(1, 1.0, (3, 5), []) != None


# Generated at 2022-06-25 23:07:23.790916
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    p = InputOutput(input, output)

    assert p.input == input
    assert p.output == output


# Generated at 2022-06-25 23:07:29.512778
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=1, time=0.0, target=(3, 6), dependencies=[])
    assert res.files == 1
    assert res.time == 0.0
    assert res.target == (3, 6)
    assert res.dependencies == []

if __name__ == '__main__':
    test_CompilationResult()

# Generated at 2022-06-25 23:07:31.607791
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=2,
                      time=3.1,
                      target=(3, 4),
                      dependencies=['module.py', 'module'])

# Generated at 2022-06-25 23:07:35.239235
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(files=1, time=1.0,
                          target=(3, 6), dependencies=['a'])
    assert r.files == 1
    assert r.time == 1.0
    assert r.target == (3, 6)
    assert r.dependencies == ['a']


# Generated at 2022-06-25 23:07:41.703206
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    class Dep(object):   # noqa
        def __init__(self, i: int):
            self.i = i

        def __eq__(self, other):
            return self.i == other.i

        def __repr__(self):
            return 'Dep(%d)' % self.i

    tree = ast.parse('1')
    t = TransformationResult(tree, True, [Dep(1), Dep(2)])
    assert t.tree == tree
    assert t.tree_changed is True
    assert t.dependencies == [Dep(1), Dep(2)]

# Generated at 2022-06-25 23:07:48.387820
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=10,
                               time=10.0,
                               target=(3, 3),
                               dependencies=[])
    assert result.files == 10
    assert result.time == 10.0
    assert result.target == (3, 3)
    assert result.dependencies == []



# Generated at 2022-06-25 23:07:50.535727
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # type: () -> None
    assert CompilationResult(files=1,
                             time=2.0,
                             target=(3, 4),
                             dependencies=['abc', 'xyz']) is not None

# Generated at 2022-06-25 23:07:52.636045
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('./foo'), Path('./bar')) == \
           InputOutput(input=Path('./foo'), output=Path('./bar'))

# Generated at 2022-06-25 23:07:56.201181
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    TransformationResult(ast.AST(), False, [])
    TransformationResult(ast.AST(), False,
                         ['/home/john/t.py', '/home/john/b.py'])


# Generated at 2022-06-25 23:07:58.134614
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path('a'), Path('b'))
    assert io.input == Path('a')
    assert io.output == Path('b')


# Generated at 2022-06-25 23:08:46.228349
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('input'), Path('output'))


# Generated at 2022-06-25 23:08:52.769552
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = InputOutput(Path('/a.txt'), Path('b.txt'))
    assert a.input == '/a.txt'
    assert repr(a) == "InputOutput(input='/a.txt', output='b.txt')"
    assert str(a) == "a.txt -> b.txt"
    assert a == InputOutput(Path('/a.txt'), Path('b.txt'))
    assert a != InputOutput(Path('/a.txt'), Path('c.txt'))
    assert a != InputOutput(Path('/c.txt'), Path('b.txt'))
    assert a != InputOutput(Path('/c.txt'), Path('c.txt'))


# Generated at 2022-06-25 23:08:56.007298
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 0.1, (3, 5), ["a.py"])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 5)
    assert result.dependencies == ["a.py"]



# Generated at 2022-06-25 23:09:00.602892
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('./X'), Path('./Y')) == \
        InputOutput(str(Path('./X')), str(Path('./Y')))
    assert InputOutput(Path('./X'), Path('./Y')) != \
        InputOutput(Path('./X'), str(Path('./Y')))
    assert InputOutput(Path('./X'), Path('./Y')) != \
        InputOutput(str(Path('./X')), Path('./Y'))

# Generated at 2022-06-25 23:09:03.744203
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 0.02, (3, 7), ['a', 'b.py'])
    assert result.files == 1
    assert result.time == 0.02
    assert result.target == (3, 7)
    assert result.dependencies == ['a', 'b.py']



# Generated at 2022-06-25 23:09:10.874806
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('a=1', mode='eval')
    r = TransformationResult(tree=t, tree_changed=False, dependencies=[])
    assert r.tree == t
    assert r.tree_changed == False
    assert r.dependencies == []

# Result of transformation context
Transformation = NamedTuple('Transformation',
                            [('tree', ast.AST),
                             ('tree_changed', bool),
                             ('dependencies', List[str])])

# Function that run transformer
Transformer = NamedTuple('Transformer',
                         [('transform_fun', callable),
                          ('dependencies', List[str])])

# Information about multi-transformer

# Generated at 2022-06-25 23:09:13.021498
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    x = TransformationResult(tree=None, tree_changed=True, dependencies=[])
    assert x.tree == None
    assert x.tree_changed == True
    assert x.dependencies == []


# Generated at 2022-06-25 23:09:14.547919
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # type: () -> None
    CompilationResult(1, 1.1, (3, 5), ['foo', 'bar'])



# Generated at 2022-06-25 23:09:18.864621
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=1,
                               target=CompilationTarget(3, 6),
                               dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 1
    assert result.target == CompilationTarget(3, 6)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-25 23:09:22.133134
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input='in', output='out') == ('in', 'out')


if __name__ == '__main__':
    import sys
    if len(sys.argv) > 1:
        exec(sys.argv[1])
    else:
        from pytest import main
        main([__file__])

# Generated at 2022-06-25 23:11:13.516026
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=2, target=(3, 4), dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 2
    assert result.target == (3, 4)
    assert result.dependencies == ['a', 'b']

# Generated at 2022-06-25 23:11:16.119941
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('a = 1')
    r = TransformationResult(t, True, ['file1', 'file2'])
    assert r.tree == t
    assert r.tree_changed == True
    assert r.dependencies == ['file1', 'file2']

# Generated at 2022-06-25 23:11:20.332212
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # should require Path objects in constructor
    with pytest.raises(AssertionError):
        InputOutput(Path(), [])
    # should have expected constructor values
    Path('/tmp/x').touch()
    i = Path('/tmp/x')
    o = Path('/tmp/y')
    iot = InputOutput(input=i, output=o)
    assert iot.input == i
    assert iot.output == o

# Generated at 2022-06-25 23:11:22.924080
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('print(1)')
    result = TransformationResult(tree, True, [])
    assert result.tree is tree
    assert result.tree_changed is True
    assert len(result.dependencies) == 0

# Generated at 2022-06-25 23:11:26.504561
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    dependencies = ['a', 'b']
    result = TransformationResult(tree, True, dependencies)
    assert result.tree is tree
    assert result.tree_changed is True
    assert result.dependencies == dependencies

# Generated at 2022-06-25 23:11:31.455088
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=5, time=3.5, target=(3, 6),
                           dependencies=['a', 'b'])
    assert cr.files == 5
    assert cr.time == 3.5
    assert cr.target == (3, 6)
    assert cr.dependencies == ['a', 'b']
    assert str(cr) == "files = 5, time = 3.5, target = (3, 6), dependencies = ['a', 'b']"


# Generated at 2022-06-25 23:11:32.434450
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert(TransformationResult(tree=None, tree_changed=False, dependencies=[]))

# Generated at 2022-06-25 23:11:34.633452
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path("/tmp"), Path("/tmp/1")).input == Path("/tmp")
    assert InputOutput(Path("/tmp"), Path("/tmp/1")).output == Path("/tmp/1")

# Generated at 2022-06-25 23:11:36.978500
# Unit test for constructor of class InputOutput
def test_InputOutput():
    tmp0 = Path('/tmp/path/to/file')
    tmp1 = Path('/tmp/path/to/file2')
    inout = InputOutput(tmp0, tmp1)
    assert inout.input == tmp0
    assert inout.output == tmp1

# Generated at 2022-06-25 23:11:38.117194
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2.0, (3, 4), ['foo', 'bar'])
