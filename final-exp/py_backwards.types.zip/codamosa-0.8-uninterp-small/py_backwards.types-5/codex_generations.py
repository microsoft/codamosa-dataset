

# Generated at 2022-06-25 23:03:32.127865
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input.py')
    output = Path('output.py')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output

# Generated at 2022-06-25 23:03:33.874733
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult()
    print (compilation_result_0)


# Generated at 2022-06-25 23:03:34.691457
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.AST, bool, List[str])

# Generated at 2022-06-25 23:03:39.336227
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(
        files=2,
        time=1,
        target=(3,7),
        dependencies=['a','b','c','d']
    )
    assert compilation_result.files == 2
    assert compilation_result.time == 1
    assert compilation_result.target == (3,7)
    assert compilation_result.dependencies == ['a','b','c','d']


# Generated at 2022-06-25 23:03:40.956267
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert '/home/user/file.py' in test_case_0(compilation_result_0)

# Generated at 2022-06-25 23:03:50.122892
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inputoutput_0 = InputOutput(Path('/tmp/code_gen_temp_0.py'),
                                Path('/tmp/code_gen_temp_0.py'))
    inputoutput_1 = InputOutput(Path('/tmp/code_gen_temp_1.py'),
                                Path('/tmp/code_gen_temp_1.py'))
    inputoutput_2 = InputOutput(Path('/tmp/code_gen_temp_2.py'),
                                Path('/tmp/code_gen_temp_2.py'))
    assert inputoutput_0.input.name == 'code_gen_temp_0.py'
    assert inputoutput_0.output.name == 'code_gen_temp_0.py'

# Generated at 2022-06-25 23:03:51.615762
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.AST(), True, [])



# Generated at 2022-06-25 23:03:53.433029
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult() == TransformationResult(tree=None,
                                                           tree_changed=False,
                                                           dependencies=[])

# Generated at 2022-06-25 23:03:56.174095
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = "in"
    output = "out"
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-25 23:03:58.801718
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # TransformationResult declares a constructor,
    # so we check that it can be created
    assert TransformationResult((ast.Module, False, ["abc.py"])) != None


# Generated at 2022-06-25 23:04:09.629375
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # check that the namedtuple has the right class name
    assert CompilationResult.__name__ == 'CompilationResult'
    # check that the namedtuple has the right attributes
    assert 'files' in CompilationResult._fields
    assert 'time' in CompilationResult._fields
    assert 'target' in CompilationResult._fields
    assert 'dependencies' in CompilationResult._fields

    # check that the argument names are the same
    assert CompilationResult.__new__.__defaults__ == ()
    # check that the arguments have the right types
    assert CompilationResult.__annotations__['files'] == int
    assert CompilationResult.__annotations__['time'] == float
    assert CompilationResult.__annotations__['target'] == CompilationTarget

# Generated at 2022-06-25 23:04:11.384376
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path('input.py'), Path('output.py'))
    assert io.input is not None
    assert io.output is not None

# Generated at 2022-06-25 23:04:16.831137
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test_tree = ast.Num(n=1)
    test_dependencies = ['a.pyc']
    test_transform_result = TransformationResult(tree=test_tree,
                                                 tree_changed=True,
                                                 dependencies=test_dependencies)
    assert test_tree == test_transform_result.tree
    assert test_dependencies == test_transform_result.dependencies
    assert True == test_transform_result.tree_changed

# Generated at 2022-06-25 23:04:26.346736
# Unit test for constructor of class InputOutput
def test_InputOutput():
    paths = [('/home/user/b', 'b'), ('/home/user/a', 'a')]
    paths_input = []
    paths_output = []
    for (input, output) in paths:
        paths_input.append(input)
        paths_output.append(output)
    p1 = Path(paths_input[0])
    p2 = Path(paths_input[1])
    i1 = InputOutput(p1, paths_output[0])
    i2 = InputOutput(p2, paths_output[1])
    assert str(i1.input) == str(p1)
    assert i1.output == paths_output[0]
    assert str(i2.input) == str(p2)
    assert i2.output == paths_output[1]

# Unit test

# Generated at 2022-06-25 23:04:30.144222
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree_0 = TransformationResult()
    tree_1 = TransformationResult(tree=None, tree_changed=None, dependencies=None)
    assert tree_0.tree == tree_1.tree
    assert tree_0.tree_changed == tree_1.tree_changed
    assert tree_0.dependencies == tree_1.dependencies



# Generated at 2022-06-25 23:04:31.808348
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput('input', 'output') == InputOutput(Path('input'),
                                                         Path('output'))



# Generated at 2022-06-25 23:04:33.115306
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(0, 0.0, (3,5), [])

# Generated at 2022-06-25 23:04:36.738405
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_0 = Path('/foo/bar')
    inout_0 = InputOutput(input=input_0, output=Path('baz'))
    assert inout_0.input == input_0
    assert inout_0.output == Path('baz')



# Generated at 2022-06-25 23:04:37.842250
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result = TransformationResult(None, None, None)

# Generated at 2022-06-25 23:04:41.726653
# Unit test for constructor of class InputOutput
def test_InputOutput():

    # Data
    input = Path('test/test_file.txt')
    output = Path('test/test_file_0.txt')
    input_output = InputOutput(input, output)

    # Assertion
    assert type(input_output.input) == Path
    assert type(input_output.output) == Path


# Generated at 2022-06-25 23:04:50.206062
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert issubclass(TransformationResult, NamedTuple)
    assert TransformationResult.tree is None
    assert TransformationResult.tree_changed is None
    assert TransformationResult.dependencies is None

# Generated at 2022-06-25 23:04:54.432186
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    x = CompilationResult(files=1,
                          time=0.0,
                          target=(3, 7),
                          dependencies=[])
    assert x.files == 1
    assert x.time == 0.0
    assert x.target == (3, 7)
    assert x.dependencies == []



# Generated at 2022-06-25 23:04:59.754297
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(1, 1.0, (2, 7), [])
    assert cr.files == 1
    assert cr.time == 1.0
    assert cr.target == (2, 7)
    assert cr.dependencies == []


# Generated at 2022-06-25 23:05:04.414449
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=5,
                               time=0.01,
                               target=(3, 6),
                               dependencies=['a', 'b'])

    assert result.files == 5
    assert result.time == 0.01
    assert result.target == (3, 6)
    assert result.dependencies == ['a', 'b']

# Unit test fo constructor of class InputOutput

# Generated at 2022-06-25 23:05:09.662159
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('foo/bar.py')
    out = Path('foo/bar.pyc')
    x = InputOutput(input=inp, output=out)
    assert x.input == inp
    assert x.output == out

# Generated at 2022-06-25 23:05:13.647950
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse("1 + 2"), False, ["abc"])
    assert TransformationResult(ast.parse("1 + 2"), True, ["abc"])
    assert TransformationResult(ast.parse("1 + 2"), True, [])

# Generated at 2022-06-25 23:05:17.739807
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(2, 5.0, (3, 5), ['module1', 'module2'])
    assert result.files == 2
    assert result.time == 5.0
    assert result.target == (3, 5)
    assert result.dependencies == ['module1', 'module2']


# Generated at 2022-06-25 23:05:22.085357
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.Expr()
    tree_changed = True
    dependencies = ['abc.py']
    result = TransformationResult(tree=tree,
                                  tree_changed=tree_changed,
                                  dependencies=dependencies)

    assert result.tree is tree
    assert result.tree_changed is True
    assert result.dependencies == ['abc.py']

# Generated at 2022-06-25 23:05:24.989033
# Unit test for constructor of class CompilationResult
def test_CompilationResult():  # type: () -> None
    assert CompilationResult(files=0, time=0.0, target=(2, 7), dependencies=[])


# Generated at 2022-06-25 23:05:29.013882
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 1.0, (3, 0), ['foo.py'])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 0)
    assert result.dependencies == ['foo.py']


# Generated at 2022-06-25 23:05:34.748906
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=['a'])

# Generated at 2022-06-25 23:05:37.764834
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(0, 0, (3, 7), [])
    assert r.files == 0
    assert r.time == 0
    assert r.target == (3, 7)
    assert r.dependencies == []



# Generated at 2022-06-25 23:05:41.345096
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    pass


# Result of linting
LinterResult = NamedTuple('LinterResult', [('ast', ast.AST),
                                           ('report', str),
                                           ('linter', str),
                                           ('lint_time', float),
                                           ('fixed', bool)])


# Generated at 2022-06-25 23:05:45.008345
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1,
                      time=2.0,
                      target=(2, 3),
                      dependencies=['a'])


# Generated at 2022-06-25 23:05:51.307443
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('./a.py')
    output = Path('./a.py')
    pair = InputOutput(input, output)
    assert pair.input == input
    assert pair.output == output


# Generated at 2022-06-25 23:05:57.159064
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input=Path("foo"), output=Path("bar")) == \
           InputOutput(input=Path("foo"), output=Path("bar"))
    assert InputOutput(input=Path("foo"), output=Path("bar")) != \
           InputOutput(input=Path("bar"), output=Path("bar"))
    assert InputOutput(input=Path("foo"), output=Path("bar")) != \
           InputOutput(input=Path("foo"), output=Path("foo"))

# Generated at 2022-06-25 23:05:59.275166
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.parse('2'), True, ['1', '2', '3'])
    assert isinstance(tr, TransformationResult)
    assert tr.tree_changed == True

# Generated at 2022-06-25 23:06:02.559155
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.5, target=(3, 7), dependencies=['a'])
    assert result.files == 1 and result.time == 0.5 and result.target == (3, 7) and result.dependencies == ['a']



# Generated at 2022-06-25 23:06:05.521518
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from tests.transformer_util import ast_fake
    tr = TransformationResult(tree=ast_fake(),
                              tree_changed=True,
                              dependencies=['a', 'b'])
    assert tr.tree_changed == True
    assert tr.dependencies == ['a', 'b']

# Generated at 2022-06-25 23:06:08.729064
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    import ast
    tree = ast.parse('x = 1')
    res = TransformationResult(tree=tree, tree_changed=True, dependencies=[])
    assert res.tree == tree
    assert res.tree_changed == True
    assert res.dependencies == []

# Generated at 2022-06-25 23:06:18.962592
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 2.3, (3, 4), ['foo', 'bar'])



# Generated at 2022-06-25 23:06:22.941433
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=5,
                           time=42,
                           target=(3, 8),
                           dependencies=['a', 'b'])
    assert cr.files == 5
    assert cr.time == 42
    assert cr.target == (3, 8)
    assert cr.dependencies == ['a', 'b']

# Generated at 2022-06-25 23:06:31.900046
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Test init with less argument
    _ = CompilationResult(0, 0.1, (3, 4), [])
    # Test init with more argument
    _ = CompilationResult(0, 0.1, (3, 4), [], 1)
    # Test init with wrong type of argument
    with pytest.raises(TypeError):
        _ = CompilationResult(0, 0.1, (3, 4), 1)
    # Test init with wrong value of argument
    with pytest.raises(TypeError):
        _ = CompilationResult(0, 0.1, (3, 4), 1)
    # Test init with wrong value of argument
    with pytest.raises(ValueError):
        _ = CompilationResult(-1, 0.1, (3, 4), [])

# Generated at 2022-06-25 23:06:34.920527
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1,
                      time=0.5,
                      target=(2, 7),
                      dependencies=["foo/bar", "baz/qux"])



# Generated at 2022-06-25 23:06:39.919668
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 1.1, (2, 7), ['a'])
    assert len(CompilationResult(1, 1.1, (2, 7), ['a'])) == 4
    assert isinstance(CompilationResult(1, 1.1, (2, 7), ['a']), tuple)


# Generated at 2022-06-25 23:06:42.693405
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # pylint: disable=unused-variable
    CompilationResult(
        files=1,
        time=0.5,
        target=(3, 3),
        dependencies=['a', 'b', 'c']
    )


# Generated at 2022-06-25 23:06:47.116284
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=2, time=0.1, target=(3, 5),
                           dependencies=['dependency1', 'dependency2'])
    assert cr.files == 2
    assert cr.time == 0.1
    assert cr.target == (3, 5)
    assert cr.dependencies == ['dependency1', 'dependency2']


# Generated at 2022-06-25 23:06:49.875536
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('input.py'), Path('output.py'))
    assert input_output == InputOutput(input=Path('input.py'),
                                       output=Path('output.py'))


# Generated at 2022-06-25 23:06:52.711284
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=3, time=1.0,
                            target=(0, 0),
                            dependencies=["file1", "file2"])
    assert res.files == 3
    assert res.time == 1.0
    assert res.target == (0, 0)
    assert res.dependencies == ["file1", "file2"]


# Generated at 2022-06-25 23:06:55.058278
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(input=Path('/input'),
                               output=Path('/output'))
    assert input_output.input == Path('/input')
    assert input_output.output == Path('/output')


# Generated at 2022-06-25 23:07:15.982332
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    dependencies = ['foo.py']
    res = TransformationResult(tree, True, dependencies)
    assert res.tree is tree
    assert res.tree_changed is True
    assert res.dependencies is dependencies

# Generated at 2022-06-25 23:07:20.991236
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.Module()
    res = TransformationResult(tree=tree,
                               tree_changed=True,
                               dependencies=["test.py"])
    assert res.tree is tree
    assert res.tree_changed is True
    assert res.dependencies == ["test.py"]

# Result of transformers transformation
CompilationFailure = NamedTuple('CompilationFailure',
                                [('filename', str),
                                 ('reason', str)])


# Error type

# Generated at 2022-06-25 23:07:28.062106
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files = 1,
                               time = 2,
                               target = (3, 4),
                               dependencies = ["a.exp", "b.py"])
    assert result.files == 1
    assert result.time == 2
    assert result.target == (3, 4)
    assert result.dependencies == ["a.exp", "b.py"]


# Generated at 2022-06-25 23:07:36.726118
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inputs = ("somedir/somemod.py", "somedir/somemod.py")
    outputs = ("somedir/somemod_target.py", "somedir/somemod_target.py")
    for input_, output in zip(inputs, outputs):
        F = InputOutput(input=Path(input_), output=Path(output))
        assert F.output == Path(output)
        assert F.input == Path(input_)
        assert str(F) == "InputOutput(input='somedir/somemod.py', " + \
                         "output='somedir/somemod_target.py')"

# Generated at 2022-06-25 23:07:42.056975
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=0, time=0, target=(1, 0), dependencies=[])
    assert isinstance(result.files, int)
    assert isinstance(result.time, float)
    assert isinstance(result.target, CompilationTarget)
    assert isinstance(result.dependencies, list)
    assert result.files == 0
    assert result.time == 0
    assert result.target == (1, 0)
    assert result.dependencies == []


# Generated at 2022-06-25 23:07:47.221366
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('a'), Path('b'))
    assert input_output.input == Path('a')
    assert input_output.output == Path('b')

# Generated at 2022-06-25 23:07:51.670516
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    t = CompilationResult(files=1, time=2.0, target=(3, 4),
                          dependencies=['a', 'b'])
    assert t.files == 1
    assert t.time == 2.0
    assert t.target == (3, 4)
    assert t.dependencies == ['a', 'b']

    t2 = CompilationResult(**t._asdict())
    assert t == t2


# Generated at 2022-06-25 23:07:54.553504
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input.txt')
    output = Path('output.txt')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-25 23:08:02.746345
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Create CompilationResult object
    compilation_result = CompilationResult(files=1,
                                           time=0.5,
                                           target=(3, 6),
                                           dependencies=['test.py'])

    # Check that all fields is correct
    files = 1
    assert compilation_result.files == files, 'Files number is not correct'
    time = 0.5
    assert compilation_result.time == time, 'Time is not correct'
    target = (3, 6)
    assert compilation_result.target == target, \
        'Target python version is not correct'
    dependencies = ['test.py']
    assert compilation_result.dependencies == dependencies, \
        'Dependency list is not correct'


# Generated at 2022-06-25 23:08:05.424345
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path_input, path_output = './path/to/input', './path/to/output'
    assert InputOutput(path_input, path_output) == InputOutput(Path(path_input), Path(path_output))

# Generated at 2022-06-25 23:08:53.738532
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.parse('1'), True, ['foo.py'])
    assert tr.tree is not None
    assert tr.tree_changed
    assert tr.dependencies == ['foo.py']

# Generated at 2022-06-25 23:08:57.769870
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    for valid_n in range(0, 100):
        for valid_time in range(0, 100):
            for valid_target in [(3, 4), (3, 5), (3, 6), (3, 7)]:
                CompilationResult(files=valid_n,
                                  time=valid_time,
                                  target=valid_target,
                                  dependencies=[])


# Generated at 2022-06-25 23:08:58.785823
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert isinstance(InputOutput('a', 'b'), InputOutput)


# Generated at 2022-06-25 23:09:02.106609
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=0, time=0.0,
                          target=(0, 0), dependencies=[])
    assert c.files == 0
    assert c.time == 0.0
    assert c.target[0] == 0
    assert c.target[1] == 0
    assert c.dependencies == []


# Generated at 2022-06-25 23:09:04.439771
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('input.py')
    output_path = Path('output.py')
    io = InputOutput(input_path, output_path)
    assert io.input == 'input.py'
    assert io.output == 'output.py'

# Generated at 2022-06-25 23:09:07.889069
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    t = CompilationResult(files=0, time=0, target=CompilationTarget(3, 5),
                          dependencies=['a'])
    assert t.files == 0
    assert t.time == 0
    assert t.target == CompilationTarget(3, 5)
    assert t.dependencies == ['a']


# Generated at 2022-06-25 23:09:12.401828
# Unit test for constructor of class TransformationResult
def test_TransformationResult(): # type: () -> None
    test_tree_changed = True
    test_dependencies = ["/path/to/module.py"]
    test_tree = ast.parse("print('Hello world!')")

    test_res = TransformationResult(test_tree, test_tree_changed,
                                    test_dependencies)

    assert test_res.tree is test_tree
    assert test_res.tree_changed is True
    assert test_res.dependencies == ["/path/to/module.py"]

# Generated at 2022-06-25 23:09:14.644376
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path("foo")
    output = Path("bar")
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output
    assert io.output == output


# Generated at 2022-06-25 23:09:15.604261
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 3.2, (2, 7), 'foo')

# Generated at 2022-06-25 23:09:19.738184
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_input = Path('test_input')
    test_output = Path('test_output')
    test_input_output = InputOutput(input=test_input, output=test_output)

    # Test field access
    assert test_input_output.input == test_input
    assert test_input_output.output == test_output


# Generated at 2022-06-25 23:11:02.868860
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.parse('pass'), False, ['1', '2'])

# Generated at 2022-06-25 23:11:05.391412
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(5, 1, (3, 7), [])
    assert result.files == 5
    assert result.time == 1
    assert result.target == (3, 7)
    assert result.dependencies == []


# Generated at 2022-06-25 23:11:09.045770
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(files=2,
                          time=24.0,
                          target=(3, 8),
                          dependencies=['bar', 'foo'])
    assert r.files == 2
    assert r.time == 24.0
    assert r.target == (3, 8)
    assert r.dependencies == ['bar', 'foo']


# Generated at 2022-06-25 23:11:13.614825
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=42,
                                           time=3.1415,
                                           target=(3, 5),
                                           dependencies=['a', 'b'])

    assert compilation_result.files == 42
    assert compilation_result.time == 3.1415
    assert compilation_result.target == (3, 5)
    assert compilation_result.dependencies == ['a', 'b']


# Generated at 2022-06-25 23:11:17.010685
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(
        ast.AST(), False, ['file1', 'file2']).tree_changed is False
    assert TransformationResult(
        ast.AST(), True, ['file1', 'file2']).tree_changed is True
    assert TransformationResult(
        ast.AST(), True, ['file1', 'file2']).dependencies == ['file1', 'file2']

# Generated at 2022-06-25 23:11:19.332453
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('/a/b')
    output = Path('/c/d')

    result = InputOutput(input_, output)

    assert result.input == input_
    assert result.output == output

# Generated at 2022-06-25 23:11:21.193081
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("print('foo')")
    dependencies = []
    tr = TransformationResult(tree, True, dependencies)
    assert tr == TransformationResult(tree, True, dependencies)

# Generated at 2022-06-25 23:11:26.901175
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(ast.parse('1+1'), False, [])
    assert result.tree.body[0].value.n == 2
    assert result.tree_changed is False
    assert result.dependencies == []

# Result of transformers transformation
OptimizationResult = NamedTuple('OptimizationResult',
                                [('bytecode', object),
                                 ('bytecode_changed', bool),
                                 ('dependencies', List[str])])


# Generated at 2022-06-25 23:11:29.061574
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(input="/etc/foo", output="/tmp/bar")
    assert input_output.input == Path("/etc/foo")
    assert input_output.output == Path("/tmp/bar")

# Generated at 2022-06-25 23:11:31.221389
# Unit test for constructor of class InputOutput
def test_InputOutput():
    x = InputOutput(input='a', output='b')
    assert x.input == Path('a')
    assert x.output == Path('b')
