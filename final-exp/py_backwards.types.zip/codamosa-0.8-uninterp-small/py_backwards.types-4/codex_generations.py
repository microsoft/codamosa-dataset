

# Generated at 2022-06-25 23:03:36.646434
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()


# Generated at 2022-06-25 23:03:42.220446
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    import sys
    compilation_result = CompilationResult(3, 7.3, sys.version_info[:2], ['lib/enum', 'lib/typing'])
    assert(compilation_result.files == 3)
    assert(compilation_result.time == 7.3)
    assert(compilation_result.target == sys.version_info[:2])
    assert(compilation_result.dependencies == ['lib/enum', 'lib/typing'])


# Generated at 2022-06-25 23:03:51.415096
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    a = ast.parse('print("a")')
    a1 = ast.parse('print("a1")')
    a2 = ast.parse('print("a2")')
    a3 = ast.parse('print("a3")')
    a4 = ast.parse('print("a4")')
    a5 = ast.parse('print("a5")')

    b = TransformationResult(a1, False, [])
    c = TransformationResult(a2, [])
    d = TransformationResult(a3, True, [])
    e = TransformationResult(a4, True, ['1', '2'])
    f = TransformationResult(a5, True, [])
    g = TransformationResult(a, ['a', 'b'])
    h = TransformationResult(a, ['c', 'd'])

    # Checking the result


# Generated at 2022-06-25 23:03:52.599168
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result_0 = TransformationResult(None, None, None)



# Generated at 2022-06-25 23:04:01.783994
# Unit test for constructor of class CompilationResult
def test_CompilationResult():

    # Test with nothing
    compilation_result_0 = CompilationResult()

    # Test with fields:
    # Every field is specified
    compilation_result_0 = CompilationResult(
        files=0,
        time=0.0,
        target=(2, 7),
        dependencies=[]
    )

    # Test without field:
    # files is not specified
    compilation_result_0 = CompilationResult(
        time=0.0,
        target=(2, 7),
        dependencies=[]
    )

    # time is not specified
    compilation_result_0 = CompilationResult(
        files=0,
        target=(2, 7),
        dependencies=[]
    )

    # target is not specified

# Generated at 2022-06-25 23:04:03.585237
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert isinstance(CompilationResult(1, 2, (3, 4), 5), CompilationResult)

# Test for getters of CompilationResult

# Generated at 2022-06-25 23:04:06.714453
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result = TransformationResult(
        tree = None,
        tree_changed = False,
        dependencies = list()
    )

    assert transformation_result.tree is None
    assert not transformation_result.tree_changed
    assert transformation_result.dependencies == list()



# Generated at 2022-06-25 23:04:12.732366
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    dependencies = []
    tree = ast.FunctionDef(name='a', args=ast.arguments(args=[], kwonlyargs=[], defaults=[], kw_defaults=[], kwarg=None, vararg=None),
                           body=[ast.Pass()], decorator_list=[], returns=None)
    
    tr1 = TransformationResult(tree, True, dependencies)
    assert(isinstance(tr1.tree, ast.FunctionDef))
    assert(isinstance(tr1.tree_changed, bool))
    assert(isinstance(tr1.dependencies, list))


# Generated at 2022-06-25 23:04:20.367517
# Unit test for constructor of class InputOutput
def test_InputOutput():
    ns = {}
    exec('''class InputOutput:
    def __init__(self, input, output):
        self.input = input
        self.output = output
''')
    exec('input = Path("foo")', ns)
    exec('output = Path("bar")', ns)
    exec('''io = InputOutput(input, output)''', ns)
    assert ns['input'] == Path("foo")
    assert ns['output'] == Path("bar")
    assert ns['io'].input == Path("foo")
    assert ns['io'].output == Path("bar")


# Generated at 2022-06-25 23:04:27.768597
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from pytype.pyc import pyc_utils
    from pytype import pyc_eval_support
    mod = pyc_utils.load_module('pyi_not_compiled', pyi_path=str(pyc_eval_support.PYI_PATH))

    assert type(mod) is pyc_utils.PycModule
    assert len(mod.module.body) == 0

    from pytype.pyc_eval import eval_func
    res = eval_func(mod.module.body)

    assert res.tree is mod.module
    assert res.tree_changed is True
    assert len(res.dependencies) == 0

# Generated at 2022-06-25 23:04:33.664386
# Unit test for constructor of class CompilationResult
def test_CompilationResult():

    assert CompilationResult(1, 0.1, (3, 5), ['dependency']).files == 1
    assert CompilationResult(1, 0.1, (3, 5), ['dependency']).time == 0.1
    assert CompilationResult(1, 0.1, (3, 5), ['dependency']).target == (3, 5)
    assert CompilationResult(1, 0.1, (3, 5),
                             ['dependency']).dependencies == ['dependency']



# Generated at 2022-06-25 23:04:42.882853
# Unit test for constructor of class CompilationResult
def test_CompilationResult():

    # Test with all arguments
    compilation_result_1 = CompilationResult(files=1,
                                             time=1.1,
                                             target=(3, 5),
                                             dependencies=['test_dep'])

    # Test with all arguments, when files argument is None
    compilation_result_2 = CompilationResult(files=None,
                                             time=1.1,
                                             target=(3, 5),
                                             dependencies=['test_dep'])

    # Test with all arguments, when time argument is None
    compilation_result_3 = CompilationResult(files=1,
                                             time=None,
                                             target=(3, 5),
                                             dependencies=['test_dep'])

    # Test with all arguments, when target argument is None

# Generated at 2022-06-25 23:04:50.370161
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    import astor
    tree = astor.parse_file("/home/mariar/Learn/Java/code/src/main/java/ch/usi/dag/disl/test/suite/exception/ExceptionTest1.java")
    result_0 = TransformationResult(tree, True, ['dep_0', 'dep_1'])

    assert result_0.tree == tree
    assert result_0.tree_changed == True
    assert result_0.dependencies == ['dep_0', 'dep_1']


# Generated at 2022-06-25 23:04:51.483581
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()

# Generated at 2022-06-25 23:04:52.387051
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    test_case_0()



# Generated at 2022-06-25 23:04:56.999523
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 2
    time = 0.5
    target = (3, 5)
    dependencies = []
    compilation_result = CompilationResult(files=files, time=time, target=target, dependencies=dependencies)
    assert compilation_result.files == files
    assert compilation_result.time == time
    assert compilation_result.target == target
    assert compilation_result.dependencies == dependencies



# Generated at 2022-06-25 23:05:00.905789
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(ast.parse("print('Hi!')"), False, ["a.py"])
    assert t.tree == ast.parse("print('Hi!')")
    assert not t.tree_changed
    assert t.dependencies == ["a.py"]

# Generated at 2022-06-25 23:05:04.280041
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Constructor with arguments
    path1 = Path('in')
    path2 = Path('out')
    input_output = InputOutput(input=path1, output=path2)
    assert input_output.input == path1
    assert input_output.output == path2

# Generated at 2022-06-25 23:05:10.735821
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path("D:/Python/Tests/0")
    output_path = Path("D:/Python/Tests/1")
    input_output = InputOutput(input_path, output_path)

    # Test for input path
    assert(input_path == input_output.input)

    # Test for output path
    assert(output_path == input_output.output)


# Generated at 2022-06-25 23:05:13.520416
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io0 = InputOutput(Path('~/Desktop/input.txt'), Path('~/Desktop/output.txt'))


# Generated at 2022-06-25 23:05:19.689833
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path("words.txt")
    output = Path("words3.txt")
    inputOutput = InputOutput(input, output)
    assert inputOutput.input.name == input.name \
            and inputOutput.output.name == output.name



# Generated at 2022-06-25 23:05:24.343928
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    expected_result = TransformationResult(None, False, [])
    assert (expected_result == TransformationResult())
    assert (expected_result == TransformationResult(False, [], None))



# Generated at 2022-06-25 23:05:26.403270
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result = TransformationResult(None, False, [])


# Generated at 2022-06-25 23:05:29.913556
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('test_input')
    output = Path('test_output')
    input_output = InputOutput(input_, output)
    assert input_output.input == input_, 'InputOutput constructor is invalid'
    assert input_output.output == output, 'InputOutput constructor is invalid'

# Generated at 2022-06-25 23:05:32.358961
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inputPath = Path("/path/to/input")
    inputOutput = InputOutput(inputPath, None)
    assert inputOutput.input == inputPath


# Generated at 2022-06-25 23:05:35.148369
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('foo')
    output = Path('bar')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-25 23:05:37.752588
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert isinstance(CompilationResult(
        files=0,
        time=3.14159,
        target=(1, 2),
        dependencies=['a', 'b', 'c']), CompilationResult)



# Generated at 2022-06-25 23:05:40.153761
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    try:
        transformation_result_0 = TransformationResult(2.3, True, list(['1']))
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-25 23:05:42.390339
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    target = ast.NodeTransformer()
    transformer = target.visit(ast.Name())
    transformer_name = transformer[0]
    assert transformer_name == 'Name'

# Generated at 2022-06-25 23:05:44.866188
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test_case_0()

# Generated at 2022-06-25 23:05:59.019118
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test0 = InputOutput(Path(''),Path(''))
    test1 = InputOutput(Path('a'),Path('a'))
    test2 = InputOutput(Path('a/b/c'), Path('a/b/c'))
    test3 = InputOutput(Path('a/b/c/d/e/f'), Path('a/b/c/d/e/f'))
    test4 = InputOutput(Path('a/b/c/d/e/f/g/h/i/j/k/l'), Path('a/b/c/d/e/f/g/h/i/j/k/l'))
    assert test0.input == Path(''), "First attribure for InputOutput should be a Path object"

# Generated at 2022-06-25 23:05:59.839235
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    test_case_0()


# Generated at 2022-06-25 23:06:06.745718
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    class TransformationResult():
        def __init__(self, tree: ast.AST=None,
                     tree_changed: bool=False,
                     dependencies: List[str]=[]):
            self.tree = tree
            self.tree_changed = tree_changed
            self.dependencies = dependencies

    # Test 0
    tree = ast.AST
    tree_changed = bool
    dependencies = List[str]
    expected_instance = True
    instance = TransformationResult(tree, tree_changed, dependencies)
    if expected_instance != isinstance(instance, TransformationResult):
        raise AssertionError(str(instance) + ' is not an instance of TransformationResult')

# Generated at 2022-06-25 23:06:09.760255
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("for x in range(3): print(x)")
    tree_changed = True
    dependencies = ['1', '2', '3']
    TransformationResult(tree, tree_changed, dependencies)


# Generated at 2022-06-25 23:06:13.545518
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files = 0, time = 0.0, target = (3, 5), dependencies = [])
    assert compilation_result.files == 0
    assert compilation_result.time == 0.0
    assert compilation_result.target == (3, 5)
    assert compilation_result.dependencies == []



# Generated at 2022-06-25 23:06:18.962620
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_0 = Path('C:\\Users\\daniel\\PycharmProjects\\cpptoml\\cpptoml\\cpptoml.cpp')
    output_0 = Path('C:\\Users\\daniel\\PycharmProjects\\cpptoml\\cpptoml\\cpptoml.cpp')
    io_0 = InputOutput(input_0, output_0)
    assert io_0

# Generated at 2022-06-25 23:06:20.780381
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-25 23:06:24.164215
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('input.txt'), Path('output.json')).input == Path('input.txt')
    assert InputOutput(Path('input.txt'), Path('output.json')).output == Path('output.json')


# Generated at 2022-06-25 23:06:26.898545
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_1 = CompilationResult(1, 1, (1, 1), [])
    compilation_result_2 = CompilationResult(2, 2, (2, 2), [])


# Generated at 2022-06-25 23:06:29.351118
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result_0 = TransformationResult(tree = ast.AST(),
                            tree_changed = True,
                            dependencies = ["asd"])
    assert_that(transformation_result_0.tree, instance_of(ast.AST))
    assert_that(transformation_result_0.tree_changed, equal_to(True))
    assert_that(transformation_result_0.dependencies, equal_to(["asd"]))


# Generated at 2022-06-25 23:06:38.237767
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path("input.py")
    output = Path("output.py")
    io = InputOutput(input, output)

    assert io.input == input, "Input is wrong"
    assert io.output == output, "Output is wrong"


# Generated at 2022-06-25 23:06:43.277148
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_1 = CompilationResult(files=1,
                                             time=2,
                                             target=(3, 4),
                                             dependencies=['a', 'b'])
    assert compilation_result_1.files == 1
    assert compilation_result_1.time == 2
    assert compilation_result_1.target == (3, 4)
    assert compilation_result_1.dependencies == ['a', 'b']


# Generated at 2022-06-25 23:06:47.078660
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(10, 5.0, (3, 5), [])
    assert compilation_result.files == 10
    assert compilation_result.time == 5.0
    assert compilation_result.target == (3, 5)
    assert compilation_result.dependencies == []


# Generated at 2022-06-25 23:06:50.947842
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('')
    assert tree is not None
    assert isinstance(tree, ast.Module)
    transformation_result = TransformationResult(tree, True, [])
    assert transformation_result is not None
    assert transformation_result.tree == tree
    assert transformation_result.tree_changed == True
    assert transformation_result.dependencies == []


# Generated at 2022-06-25 23:06:52.310389
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=None, tree_changed=True, dependencies=None) is not None


# Generated at 2022-06-25 23:07:00.446088
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult()
    assert(isinstance(compilation_result_0, CompilationResult))
    compilation_result_1 = CompilationResult(files=30, time=0.0, target=(2, 7), dependencies=['utils', 'ast', 'parser'])
    assert(isinstance(compilation_result_1, CompilationResult))
    assert(hasattr(compilation_result_1, 'files'))
    assert(hasattr(compilation_result_1, 'time'))
    assert(hasattr(compilation_result_1, 'target'))
    assert(hasattr(compilation_result_1, 'dependencies'))
    assert compilation_result_1.files == 30
    assert compilation_result_1.time == 0.0
    assert compilation_result_1.target[0]

# Generated at 2022-06-25 23:07:01.531539
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path("input"), Path("output")) != None


# Generated at 2022-06-25 23:07:03.079455
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult()


# Generated at 2022-06-25 23:07:05.538286
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(
        None,
        False,
        [])
    assert res.tree is None
    assert not res.tree_changed
    assert res.dependencies == []


# Generated at 2022-06-25 23:07:10.243595
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult()

    expected_files = 0
    assert compilation_result_0.files == expected_files

    expected_time = 0.0
    assert compilation_result_0.time == expected_time

    expected_target = (0, 0)
    assert compilation_result_0.target == expected_target

    expected_dependencies = []
    assert compilation_result_0.dependencies == expected_dependencies


# Generated at 2022-06-25 23:07:29.284877
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Object should be created
    input_output = InputOutput(Path('.'), Path('.'))

    # Input and output should be equal to input and output in constructor
    assert input_output.input == Path('.')
    assert input_output.output == Path('.')

    # Object attributes should not be modifiable
    with pytest.raises(AttributeError):
        input_output.input = Path('./some_directory')

    with pytest.raises(AttributeError):
        input_output.output = Path('./some_directory')


# Generated at 2022-06-25 23:07:32.143110
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path_0 = Path('/tmp/path_0')
    path_1 = Path('/tmp/path_1')
    input_output_0 = InputOutput(path_0, path_1)

# Generated at 2022-06-25 23:07:35.942252
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    try:
        compilation_result = CompilationResult(files=0, time=0.0,
                                               target=(3, 6),
                                               dependencies=[])
    except:
        assert False, "pylint caught error"
    else:
        assert True, "pylint successfully ran"


# Generated at 2022-06-25 23:07:40.128172
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=ast.parse(''), tree_changed=True, dependencies=[]).tree == ast.parse('')
    assert TransformationResult(tree=ast.parse(''), tree_changed=True, dependencies=[]).tree_changed == True
    assert TransformationResult(tree=ast.parse(''), tree_changed=True, dependencies=[]).dependencies == []

# Generated at 2022-06-25 23:07:50.279485
# Unit test for constructor of class CompilationResult

# Generated at 2022-06-25 23:07:54.003356
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.Module([])
    tree_changed = True
    dependencies = ["/test.py"]
    transformation_result = TransformationResult(
        tree, tree_changed, dependencies)
    assert transformation_result.tree == tree
    assert transformation_result.tree_changed == tree_changed
    assert transformation_result.dependencies == dependencies



# Generated at 2022-06-25 23:07:59.048359
# Unit test for constructor of class InputOutput
def test_InputOutput():

    case_0 = InputOutput(None, None)
    assert isinstance(case_0, InputOutput)

    case_1 = InputOutput('/tmp', '/tmp/filedb.json')
    assert isinstance(case_1, InputOutput)

    case_2 = InputOutput(Path('/tmp'), '/tmp/filedb.json')
    assert isinstance(case_2, InputOutput)



# Generated at 2022-06-25 23:08:00.981480
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(
        files=1, time=0.1, target=(3, 4), dependencies=[]).files == 1


# Generated at 2022-06-25 23:08:04.701642
# Unit test for constructor of class InputOutput
def test_InputOutput():
    filename = Path("/")
    filename = filename / "home" / "xiaojun" / "test.py"
    filename_out = Path("/")
    filename_out = filename_out / "home" / "xiaojun" / "test.py"
    io = InputOutput(filename, filename_out)
    assert isinstance(io, InputOutput)



# Generated at 2022-06-25 23:08:05.915713
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = InputOutput(input = '', output = '')


# Generated at 2022-06-25 23:08:32.343263
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(input=Path("input.txt"), output=Path("output.txt"))
    assert input_output.input == Path("input.txt")
    assert input_output.output == Path("output.txt")


# Generated at 2022-06-25 23:08:35.229384
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("x=5")
    tree_changed = True
    dependencies = ["a.py"]
    transformation_result = TransformationResult(tree, tree_changed, dependencies)
    assert transformation_result.tree == tree
    assert transformation_result.tree_changed == tree_changed
    assert transformation_result.dependencies == dependencies


# Generated at 2022-06-25 23:08:37.564143
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('./input')
    output = Path('./output')
    in_out = InputOutput(input_, output)

    assert in_out.input == input_
    assert in_out.output == output


# Generated at 2022-06-25 23:08:42.072262
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 1
    time = 2.0
    target = (3, 4)
    dependencies = ['a', 'b', 'c']
    compilation_result = CompilationResult(files,
                                           time,
                                           target,
                                           dependencies)
    assert compilation_result.files == files
    assert compilation_result.time == time
    assert compilation_result.target == target
    assert compilation_result.dependencies == dependencies


# Generated at 2022-06-25 23:08:43.082619
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_0 = InputOutput(Path("."),Path("."))


# Generated at 2022-06-25 23:08:44.362211
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(0,0.0,0,0)
    assert cr


# Generated at 2022-06-25 23:08:47.697579
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Check that a named tuple is created
    tree = ast.parse("")
    dependencies = ['a']
    transformation_result = TransformationResult(tree, True, dependencies)
    assert transformation_result[0] == tree
    assert transformation_result[1] == True
    assert transformation_result[2] == dependencies

# Generated at 2022-06-25 23:08:50.255101
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_0 = Path("/home/project/home")
    output_0 = Path("/home/project/out")
    assert isinstance(input_0, Path)
    assert isinstance(output_0, Path)


# Generated at 2022-06-25 23:08:52.683438
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Constructor should initialize input and output fields
    input = Path('input')
    output = Path('output')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output



# Generated at 2022-06-25 23:08:56.800658
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(1, 1.0, (3, 4), [])
    assert type(compilation_result_0) == CompilationResult
    assert compilation_result_0.files == 1
    assert compilation_result_0.time == 1.0
    assert compilation_result_0.target == (3, 4)
    assert compilation_result_0.dependencies == []


# Generated at 2022-06-25 23:09:23.343159
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = './test_0.py'
    output = './test_0.result.py'
    input_output = InputOutput(input_, output)
    assert input_output.input == input_
    assert input_output.output == output


# Generated at 2022-06-25 23:09:25.586254
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilationResult = CompilationResult(
        files=0,
        time=0.0,
        target=(0, 0),
        dependencies=[]
    )


# Generated at 2022-06-25 23:09:26.607039
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(ast.AST(), True, [])


# Generated at 2022-06-25 23:09:30.140995
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=0, time=0, target=(3, 8), dependencies=[__file__,])
    assert compilation_result.files == 0
    assert compilation_result.time == 0
    assert compilation_result.target == (3, 8)
    assert compilation_result.dependencies == [__file__,]


# Generated at 2022-06-25 23:09:32.086874
# Unit test for constructor of class InputOutput
def test_InputOutput():
    try:
        InputOutput(input=1, output=2)
    except TypeError:
        pass
    else:
        assert False, 'Did not check for invalid input.'



# Generated at 2022-06-25 23:09:34.427166
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('./test/test_files/test.py'),
                       Path('test/test_files/test.pyc'))

# Generated at 2022-06-25 23:09:37.013528
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # assert that the constructor can be called
    input = Path('path/to/input.txt')
    output = Path('path/to/output.txt')
    io = InputOutput(input, output)
    # assert that there are no type errors
    assert io.input == input
    assert io.output == output

# Generated at 2022-06-25 23:09:38.733688
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
   result = TransformationResult(ast.AST(), True, [])
   assert result.tree == ast.AST()
   assert result.tree_changed
   assert result.dependencies == []


# Generated at 2022-06-25 23:09:40.773244
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult("Test", True, ["Test2"])
    assert tr.tree == "Test"
    assert tr.tree_changed == True
    assert tr.dependencies == ["Test2"]

# Generated at 2022-06-25 23:09:42.913515
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input0 = Path('/path/to/input')
    output0 = Path('/path/to/output')
    input_output0 = InputOutput(input0, output0)


# Generated at 2022-06-25 23:10:42.324451
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    input_0 = int()
    input_1 = float()
    input_2 = Tuple[int]
    input_3 = List[str]
    output = CompilationResult(input_0, input_1, input_2, input_3)
    assert isinstance(output, CompilationResult)


# Generated at 2022-06-25 23:10:49.831777
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_file_path_0 = Path('/home/alice/test.py')
    test_file_path_1 = Path('/home/bob/test.py')
    input_output_0 = InputOutput(test_file_path_0,
                                 test_file_path_1)

# Generated at 2022-06-25 23:10:51.948087
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result = TransformationResult(None, False, None)
    assert transformation_result.tree is None
    assert transformation_result.tree_changed is False
    assert transformation_result.dependencies == []



# Generated at 2022-06-25 23:10:52.952876
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput('input', 'output')



# Generated at 2022-06-25 23:10:56.980530
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(
        files=1,
        time=0.0,
        target=(3, 7),
        dependencies=[]
    )
    assert compilation_result_0.files == 1
    assert compilation_result_0.time == 0.0
    assert compilation_result_0.target == (3, 7)
    assert compilation_result_0.dependencies == []


# Generated at 2022-06-25 23:11:01.834360
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    test_case_0()

# Generated at 2022-06-25 23:11:09.403287
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult().tree_changed == False
    assert TransformationResult().tree == None
    assert TransformationResult().dependencies == []

    tree = ast.parse("# hello world")
    assert TransformationResult(tree, True, ['a.py','b.py','c.py']).tree_changed == True
    assert TransformationResult(tree, True, ['a.py','b.py','c.py']).tree.body[0].value.s == 'hello world'
    assert TransformationResult(tree, True, ['a.py','b.py','c.py']).dependencies == ['a.py','b.py','c.py']

    assert TransformationResult(tree, False, ['a.py','b.py','c.py']).tree_changed == False

# Generated at 2022-06-25 23:11:10.232100
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result_0 = TransformationResult()

# Generated at 2022-06-25 23:11:11.266535
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, None, None)


# Generated at 2022-06-25 23:11:18.868810
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput(input=Path("inputs/input0.py"),
                                 output=Path("outputs/output0.py"))
    assert input_output_0.input.name == "input0.py"
    assert input_output_0.output.name == "output0.py"

    input_output_1 = InputOutput(input=Path("inputs/input1.py"),
                                 output=Path("outputs/output0.py"))
    assert input_output_1.input.name == "input1.py"
    assert input_output_1.output.name == "output0.py"

    input_output_2 = InputOutput(input=Path("inputs/input0.py"),
                                 output=Path("outputs/output1.py"))
    assert input_output_2.input

# Generated at 2022-06-25 23:13:15.276456
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.AST(), False, [])


# Generated at 2022-06-25 23:13:17.439864
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    input_output = InputOutput(input=input,
                               output=output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-25 23:13:21.027272
# Unit test for constructor of class CompilationResult
def test_CompilationResult():

    new_CompilationResult = CompilationResult(2, 3.14, (3, 4), ['5'])
    assert isinstance(new_CompilationResult, CompilationResult)
    assert new_CompilationResult.files == 2
    assert new_CompilationResult.time == 3.14
    assert new_CompilationResult.target == (3, 4)
    assert new_CompilationResult.dependencies == ['5']


# Generated at 2022-06-25 23:13:22.784486
# Unit test for constructor of class InputOutput
def test_InputOutput():
    try:
        InputOutput(Path("input/"), Path("output/"))
    except TypeError:
        assert False
    except:
        assert True
    else:
        assert False


# Generated at 2022-06-25 23:13:25.067754
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(0, 0, (1, 2), [])
    assert compilation_result_0.files == 0
    assert compilation_result_0.time == 0
    assert compilation_result_0.target == (1, 2)
    assert compilation_result_0.dependencies == []


# Generated at 2022-06-25 23:13:28.296101
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(files=0, time=0.0, target=(3, 0), dependencies=[])
    assert compilation_result_0.files==0
    assert compilation_result_0.time==0.0
    assert compilation_result_0.target==(3,0)
    assert compilation_result_0.dependencies==[]


# Generated at 2022-06-25 23:13:34.848414
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Test for class fields
    compilation_result_0 = CompilationResult()
    assert compilation_result_0.files == 0
    assert compilation_result_0.time == 0
    assert compilation_result_0.target[0] == 0
    assert compilation_result_0.target[1] == 0

    # Test for class fields with arguments
    compilation_result_1 = CompilationResult(files=1, time=0.1, target=(1, 1), dependencies=['file_0', 'file_1'])

    assert compilation_result_1.files == 1
    assert compilation_result_1.time == 0.1
    assert compilation_result_1.target[0] == 1
    assert compilation_result_1.target[1] == 1
    # Test for equality of class fields with arguments
    assert compilation_result_0.files