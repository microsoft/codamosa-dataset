

# Generated at 2022-06-25 23:03:37.860136
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(4, 4.4, (4, 4), ["file1", "file2"])
    assert compilation_result_0.files == 4
    assert compilation_result_0.time == 4.4
    assert compilation_result_0.target == (4, 4)
    assert compilation_result_0.dependencies == ["file1", "file2"]


# Generated at 2022-06-25 23:03:41.084519
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult()
    assert compilation_result == CompilationResult(files=0,
                                                   time=0.0,
                                                   target=(0, 0),
                                                   dependencies=[])


# Generated at 2022-06-25 23:03:42.614160
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    a=TransformationResult()
    assert isinstance(a,TransformationResult)


# Generated at 2022-06-25 23:03:44.863724
# Unit test for constructor of class InputOutput
def test_InputOutput():
    transformation_result_0 = TransformationResult(ast.AST(), False, [])
    test_case_0()

# Generated at 2022-06-25 23:03:49.101443
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    comp_result = CompilationResult(1, 2.0, (3, 4), ['dep_0', 'dep_1'])
    assert comp_result.files == 1
    assert comp_result.time == 2.0
    assert comp_result.target == (3, 4)
    assert comp_result.dependencies == ['dep_0', 'dep_1']


# Generated at 2022-06-25 23:03:59.478088
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput('/home/benjamin/Pulpit/pypi-packages-iata/test/test01', '/home/benjamin/Pulpit/pypi-packages-iata/test/test01.c')
    assert isinstance(input_output_0, InputOutput)
    assert input_output_0.input == '/home/benjamin/Pulpit/pypi-packages-iata/test/test01'
    assert input_output_0.output == '/home/benjamin/Pulpit/pypi-packages-iata/test/test01.c'

# Generated at 2022-06-25 23:04:03.094271
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Test constructors
    input_output = InputOutput(Path('a'), Path('b'))
    input_output = InputOutput(input=Path('a'), output=Path('b'))
    assert input_output.input == Path('a')
    assert input_output.output == Path('b')



# Generated at 2022-06-25 23:04:10.421461
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result_0 = TransformationResult()
    transformation_result_1 = TransformationResult(__tree=None, __tree_changed=True, __dependencies=None)
    transformation_result_2 = TransformationResult(__tree=ast.AST(body=[ast.stmt(value=ast.Expr(value=ast.Num(n=3)))]), __tree_changed=True, __dependencies=None)
    transformation_result_3 = TransformationResult(__tree=None, __tree_changed=False, __dependencies=None)
    transformation_result_4 = TransformationResult(__tree=None, __tree_changed=True, __dependencies=['1'])


# Generated at 2022-06-25 23:04:13.025557
# Unit test for constructor of class InputOutput
def test_InputOutput():
    in_0 = './test_data/test_case_0_input.txt'
    out_0 = './test_data/test_case_0_output.txt'
    input_output_0 = InputOutput(Path(in_0),
                                 Path(out_0))


# Generated at 2022-06-25 23:04:14.767360
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # without parameter
    test_case_0()



# Generated at 2022-06-25 23:04:23.737198
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result_0 = TransformationResult()
    try:
        assert transformation_result_0.tree == None
    except AssertionError:
        raise AssertionError('Tree was not correctly initialized')
    try:
        assert transformation_result_0.tree_changed == 0
    except AssertionError:
        raise AssertionError('Tree_changed was not correctly initialized')
    try:
        assert transformation_result_0.dependencies == None
    except AssertionError:
        raise AssertionError('Dependencies was not correctly initialized')


# Generated at 2022-06-25 23:04:24.586718
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()

# Generated at 2022-06-25 23:04:27.219965
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert 'tree' in transformation_result_0._fields
    assert 'tree_changed' in transformation_result_0._fields
    assert 'dependencies' in transformation_result_0._fields

# Generated at 2022-06-25 23:04:31.232131
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Create a compilation result
    cr = CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=['foo.py'])
    # Check the fields
    assert cr.files == 1
    assert cr.time == 2.0
    assert cr.target == (3, 4)
    assert cr.dependencies == ['foo.py']



# Generated at 2022-06-25 23:04:35.199385
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    global transformation_result_0
    assert transformation_result_0.tree == None, "Expected 'transformation_result_0.tree = None'"
    assert transformation_result_0.tree_changed == False, "Expected 'transformation_result_0.tree_changed = False'"
    assert transformation_result_0.dependencies == [], "Expected 'transformation_result_0.dependencies = []'"


# Generated at 2022-06-25 23:04:40.291402
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.1, target=(3,4), dependencies=['a', 'b'])
    assert( result.files == 1 )
    assert( result.time == 1.1 )
    assert( result.target == (3,4) )
    assert( result.dependencies == ['a', 'b'] )


# Generated at 2022-06-25 23:04:42.456645
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_0 = Path('.')
    output_0 = Path('.')
    input_output_0 = InputOutput(input_0, output_0)


# Generated at 2022-06-25 23:04:48.586855
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(10, 0.5, (3, 6), ['foo', 'bar'])
    assert compilation_result.files == 10
    assert compilation_result.time == 0.5
    assert compilation_result.target == (3, 6)
    assert compilation_result.dependencies == ['foo', 'bar']



# Generated at 2022-06-25 23:04:51.695057
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path(__file__)
    output_path = Path('./test1')
    io = InputOutput(input_path, output_path)
    assert io.input == input_path



# Generated at 2022-06-25 23:04:55.069357
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CR = CompilationResult(2, 3.14, (3, 6), [])
    assert CR.files == 2
    assert CR.time == 3.14
    assert CR.target == (3, 6)
    assert CR.dependencies == []



# Generated at 2022-06-25 23:05:03.006687
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=10,
                               time=42.42,
                               target=(3, 5),
                               dependencies=['a', 'b', 'c'])
    assert isinstance(result, CompilationResult)
    assert result.files == 10
    assert result.time == 42.42
    assert result.target == (3, 5)
    assert result.dependencies == ['a', 'b', 'c']


# Generated at 2022-06-25 23:05:05.265121
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=3, time=1.2, target=(3, 6),
                             dependencies=['a', 'b'])



# Generated at 2022-06-25 23:05:10.611289
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p1 = Path('a')
    p2 = Path('b')
    assert InputOutput(p1, p2) == InputOutput('a', 'b')
    assert InputOutput(p1, p2).input == p1
    assert InputOutput(p1, p2).output == p2


# Generated at 2022-06-25 23:05:18.422598
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input1 = Path(r"C:\workspace\tests\foo.py")
    input2 = Path(r"C:\workspace\tests\bar.py")
    output = Path(r"C:\workspace\tests\out")

    input_output = InputOutput(input=input1,
                               output=output)
    assert input_output.input == input1
    assert input_output.output == output

    # change the output
    input_output = input_output._replace(output=input2)
    assert input_output.output == input2


# Generated at 2022-06-25 23:05:22.314661
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(42, 0.0, (3, 4), [])
    assert(c.files == 42)
    assert(c.time == 0.0)
    assert(c.target == (3, 4))
    assert(c.dependencies == [])



# Generated at 2022-06-25 23:05:27.051534
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    tree_changed = True
    dependencies = []
    res = TransformationResult(tree, tree_changed, dependencies)
    assert res.tree == tree
    assert res.tree_changed == tree_changed
    assert res.dependencies == dependencies

# Generated at 2022-06-25 23:05:33.521137
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    import sys
    res = CompilationResult(1, 0.1, sys.version_info[:2], [])
    assert res.files == 1
    assert res.time == 0.1
    assert res.target == sys.version_info[:2]
    assert res.dependencies == []
    res = CompilationResult(2, 0.2, (3, 8), ['a'])
    assert res.files == 2
    assert res.time == 0.2
    assert res.target == (3, 8)
    assert res.dependencies == ['a']


# Generated at 2022-06-25 23:05:35.092229
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=2, time=3.4, target=(3, 5), dependencies=['one', 'two'])

# Generated at 2022-06-25 23:05:39.547836
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # GIVEN
    tree = ast.parse('1')
    tree_changed = True
    dependencies = ['a', 'b']

    # WHEN
    res = TransformationResult(tree=tree, tree_changed=tree_changed,
                               dependencies=dependencies)

    # THEN
    assert res.tree is tree
    assert res.tree_changed is True
    assert res.dependencies is dependencies

# Generated at 2022-06-25 23:05:45.415889
# Unit test for constructor of class InputOutput
def test_InputOutput():
    name = "test.py"
    inp = Path(name)
    outp = Path("__" + name)
    v = InputOutput(inp, outp)
    assert v.input == inp
    assert v.output == outp
    assert v.input.name == "test.py"
    assert v.output.name == "__test.py"


# Generated at 2022-06-25 23:05:51.856190
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr1 = TransformationResult(ast.parse(''), False, [])
    assert tr1.tree is not None
    asse

# Generated at 2022-06-25 23:05:56.672902
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = '/a/b/c/input.py'
    output_path = '/a/b/c/output.py'

    input_output = InputOutput(input_path, output_path)

    assert input_output.input == input_path
    assert input_output.output == output_path


# Generated at 2022-06-25 23:05:58.755974
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('a'), Path('b'))
    assert input_output.input == Path('a')
    assert input_output.output == Path('b')

# Generated at 2022-06-25 23:06:02.239958
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = InputOutput('input', 'output')
    assert a.input == Path('input')
    assert a.output == Path('output')
    a = InputOutput(Path('input'), Path('output'))
    assert a.input == Path('input')
    assert a.output == Path('output')

# Generated at 2022-06-25 23:06:04.307121
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('foo')
    output = Path('bar')
    instance = InputOutput(input, output)
    assert instance.input == input
    assert instance.output == output

# Generated at 2022-06-25 23:06:06.046203
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('input.txt')
    output_path = Path('output.txt')
    InputOutput(input_path, output_path)

# Generated at 2022-06-25 23:06:07.694527
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 2, (3, 4), ['dep']) is not None


# Generated at 2022-06-25 23:06:10.667242
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse("a=1")
    r = TransformationResult(t, True, ['dep1', 'dep2'])
    assert isinstance(r.tree, ast.AST) and r.tree_changed and len(r.dependencies) == 2

# Generated at 2022-06-25 23:06:12.382070
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('in')
    o = Path('out')
    assert InputOutput(i, o) == InputOutput(i, o)



# Generated at 2022-06-25 23:06:16.344972
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test_tree = ast.parse('pass')
    assert TransformationResult(test_tree,
                                False,
                                []).tree_changed == False
    assert TransformationResult(test_tree,
                                True,
                                []).tree_changed == True

# Generated at 2022-06-25 23:06:28.636754
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    info = CompilationResult(1, 2.0, (3, 4), [])
    assert info.files == 1
    assert info.time == 2.0
    assert info.target == (3, 4)
    assert info.dependencies == []


# Generated at 2022-06-25 23:06:29.646723
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input=Path("input"),
                       output=Path("output")) ==\
        InputOutput("input", "output")


# Generated at 2022-06-25 23:06:32.974782
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1,
                                           time=2.5,
                                           target=(3, 4),
                                           dependencies=['foo'])
    assert compilation_result.files == 1
    assert compilation_result.time == 2.5
    assert compilation_result.target == (3, 4)
    assert compilation_result.dependencies == ['foo']


# Generated at 2022-06-25 23:06:42.774478
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    try:
        CompilationResult(files=1, time=0.1, target=(0, 0), dependencies=[])
    except Exception as e:    # type: ignore
        assert False, e
    try:
        CompilationResult(files='haha', time=0.1, target=(0, 0), dependencies=[])
        assert False
    except:
        pass
    try:
        CompilationResult(files=1, time='haha', target=(0, 0), dependencies=[])
        assert False
    except:
        pass
    try:
        CompilationResult(files=1, time=0.1, target=(0, 'haha'), dependencies=[])
        assert False
    except:
        pass

# Generated at 2022-06-25 23:06:47.613204
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(
        files=2,
        time=1.2,
        target=(3, 5),
        dependencies=['foo.py', 'bar.py'])

    assert r.files == 2
    assert r.time == 1.2
    assert r.target == (3, 5)
    assert r.dependencies == ['foo.py', 'bar.py']


# Generated at 2022-06-25 23:06:51.336758
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """
    Test constructor of InputOutput class.
    """
    input_path = Path('file.txt')
    output_path = Path('output.txt')

    # Test constructor
    input_output = InputOutput(input_path, output_path)

    # Access
    assert input_output.input == input_path
    assert input_output.output == output_path

# Generated at 2022-06-25 23:06:55.269357
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Test with strings
    a = InputOutput(input="a", output="b")
    assert isinstance(a.input, Path)
    assert isinstance(a.output, Path)
    assert str(a.input) == "a"
    assert str(a.output) == "b"
    # Test with Path objects
    b = InputOutput(input=Path("a"), output=Path("b"))
    assert isinstance(b.input, Path)
    assert isinstance(b.output, Path)
    assert str(b.input) == "a"
    assert str(b.output) == "b"

# Generated at 2022-06-25 23:06:59.429644
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cmp_result = CompilationResult(0, 0.0, (3, 6), [])
    assert cmp_result.files == 0
    assert cmp_result.time == 0.0
    assert cmp_result.target == (3, 6)
    assert cmp_result.dependencies == []


# Generated at 2022-06-25 23:07:04.267202
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    t = CompilationResult(files=1, time=1.0, target=(2, 3, 4),
                          dependencies=['dep1', 'dep2'])
    assert t.files == 1
    assert t.time == 1.0
    assert t.target == (2, 3, 4)
    assert t.dependencies == ['dep1', 'dep2']


# Generated at 2022-06-25 23:07:07.794751
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(tree=None, tree_changed=False, dependencies=[])

# Result of serialization
SerializationResult = NamedTuple('SerializationResult',
                                 [('tree', ast.AST),
                                  ('code', str),
                                  ('tree_changed', bool),
                                  ('dependencies', List[str])])


# Generated at 2022-06-25 23:07:31.869672
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("a = 1")
    tr = TransformationResult(tree, True, [])
    assert tr.tree == tree
    assert tr.tree_changed == True
    assert tr.dependencies == []

# Generated at 2022-06-25 23:07:35.618577
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_node = ast.parse('pass', '<unknown>', 'exec')
    res = TransformationResult(tree=ast_node, tree_changed=True,
                               dependencies=['test'])
    assert res.tree == ast_node
    assert res.tree_changed
    assert res.dependencies == ['test']

# Generated at 2022-06-25 23:07:38.672625
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 5')
    result = TransformationResult(tree=tree, tree_changed=True, dependencies=['foo'])
    assert result.tree is tree
    assert result.tree_changed is True
    assert result.dependencies == ['foo']

# Generated at 2022-06-25 23:07:42.424503
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    source_path = 'source'
    mod = ast.parse('pass')
    changed = False
    dependencies = ['dep.py']
    r = TransformationResult(mod, changed, dependencies)
    assert r.tree is mod
    assert r.tree_changed == changed
    assert r.dependencies == dependencies

# Generated at 2022-06-25 23:07:49.134472
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(
        files=5,
        time=0.05,
        target=(3, 7),
        dependencies=['a', 'b']
    )
    assert result.files == 5
    assert result.time == 0.05
    assert result.target == (3, 7)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-25 23:07:51.923082
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # ARRANGE
    i = Path('/tmp/input')
    o = Path('/tmp/output')

    # ACT
    result = InputOutput(i, o)

    # ASSERT
    assert result.input == i
    assert result.output == o


# Generated at 2022-06-25 23:07:58.524918
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    files = ['file1', 'file2']
    tr = TransformationResult(tree, True, files)
    assert tr[0] == tree
    assert tr[1]
    assert tr[2] == files
    assert tr.tree == tree
    assert tr.tree_changed
    assert tr.dependencies == files


# Result of transformers action
TransformationAction = NamedTuple('TransformationResult',
                                  [('name', str),
                                   ('input_outputs', List[InputOutput]),
                                   ('result', TransformationResult)])

# Generated at 2022-06-25 23:08:02.746117
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    from datetime import datetime
    result = CompilationResult(files=1, time=datetime.now() - datetime.now(),
                               target=(3, 4), dependencies=['hello', 'world'])
    assert result.files == 1
    assert result.time == 0.0
    assert result.target == (3, 4)
    assert result.dependencies == ['hello', 'world']

# Generated at 2022-06-25 23:08:04.730811
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # type: () -> None
    try:
        p1 = InputOutput(Path(__file__), "")
    except TypeError:
        pass
    assert True


# Generated at 2022-06-25 23:08:08.872369
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test_ast = ast.parse("print('Hello')")
    test_tree_changed = True
    test_dependencies = ['foo', 'bar']
    test_result = TransformationResult(
        test_ast, test_tree_changed, test_dependencies)

    assert test_ast == test_result.tree
    assert test_tree_changed == test_result.tree_changed
    assert test_dependencies == test_result.dependencies

# Generated at 2022-06-25 23:08:57.069425
# Unit test for constructor of class InputOutput
def test_InputOutput():
    t = InputOutput('input1', 'output1')
    assert t.input == 'input1'
    assert t.output == 'output1'


# Generated at 2022-06-25 23:09:00.000522
# Unit test for constructor of class InputOutput
def test_InputOutput():
    _input = Path('input')
    _output = Path('output')
    i = InputOutput(_input, _output)
    assert isinstance(i.input, Path)
    assert isinstance(i.output, Path)
    assert i.input == _input
    assert i.output == _output



# Generated at 2022-06-25 23:09:04.171938
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    from datetime import datetime
    now = datetime.now()
    timestamp = now.timestamp()
    compilation = CompilationResult(1, timestamp, (3, 5), ['__init__.py'])
    assert(compilation.files == 1)
    assert(compilation.time == timestamp)
    assert(compilation.target == (3, 5))
    assert(compilation.dependencies == ['__init__.py'])

# Generated at 2022-06-25 23:09:06.665553
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x')
    result = TransformationResult(tree, True, ['dependency'])
    assert result.tree is tree
    assert result.tree_changed is True
    assert result.dependencies == ['dependency']

# Generated at 2022-06-25 23:09:09.731846
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    t = CompilationResult(files=0, time=0.0, target=(3, 7),
                          dependencies=[])
    assert t.files == 0
    assert t.time == 0.0
    assert t.target == (3, 7)
    assert t.dependencies == []


# Generated at 2022-06-25 23:09:11.454330
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('in'), Path('out'))
    assert input_output.input == Path('in')
    assert input_output.output == Path('out')

# Generated at 2022-06-25 23:09:14.355767
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path.home()
    output = Path.home()

    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output
    assert str(io) == 'input: %s, output: %s' % (input, output)


# Generated at 2022-06-25 23:09:18.925288
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files = 10,
                               time = 123.0,
                               target = (3,6),
                               dependencies = ['a.py', 'b.py'])
    assert result.files == 10
    assert result.time == 123.0
    assert result.target == (3,6)
    assert result.dependencies == ['a.py', 'b.py']



# Generated at 2022-06-25 23:09:24.119444
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('print("hello, world!")')
    r = TransformationResult(tree=t, tree_changed=True, dependencies=[])
    if sys.version_info > (3, 5):
        assert isinstance(r, tuple)
    assert r.tree == t
    assert r.tree_changed == True
    assert r.dependencies == []

# Result of interpreter transformation
InterpreterResult = NamedTuple('InterpreterResult',
                               [('result', object),
                                ('dependencies', List[str])])


# Generated at 2022-06-25 23:09:29.585432
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Type annotations
    tree: ast.AST
    tree_changed: bool
    dependencies: List[str]
    # Assign values
    tree = ast.parse('')
    tree_changed = True
    dependencies = []
    # Construct object
    result = TransformationResult(tree, tree_changed, dependencies)
    # Test attribute values
    assert id(result.tree) == id(tree)
    assert result.tree_changed is tree_changed
    assert id(result.dependencies) == id(dependencies)

# Test constructor only

# Generated at 2022-06-25 23:11:15.668948
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = 'path1/path2/file.py'
    path2 = 'path1/path2/file.pyx'
    d = InputOutput(path1, path2)
    assert d.input.name == 'file.py'
    assert d.input.parent.name == 'path2'
    assert d.output.name == 'file.pyx'
    assert d.output.parent.name == 'path2'


# Generated at 2022-06-25 23:11:17.205308
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result: TransformationResult = TransformationResult(None,
                                                         True,
                                                         [])
    assert isinstance(result, TransformationResult)

# Generated at 2022-06-25 23:11:24.424119
# Unit test for constructor of class InputOutput
def test_InputOutput():
    directory = Path('.')
    inputfile = 'input.txt'
    outputfile = 'output.txt'
    expectedinput = Path(inputfile)
    expectedoutput = Path(outputfile)

    # Constructor doesn't check that files exist
    inputoutput = InputOutput(input=inputfile, output=outputfile)
    assert inputoutput.input == expectedinput
    assert inputoutput.output == expectedoutput

    # Input can be a string or a path
    inputoutput = InputOutput(directory / inputfile, outputfile)
    assert inputoutput.input == expectedinput
    assert inputoutput.output == expectedoutput

    # Output can be a string or a path
    inputoutput = InputOutput(inputfile, directory / outputfile)
    assert inputoutput.input == expectedinput
    assert inputoutput.output == expectedoutput

# Generated at 2022-06-25 23:11:28.996297
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(3, 10.1, (3, 7), ['a', 'b', 'c'])
    expected = CompilationResult(
        files=3,
        time=10.1,
        target=(3, 7),
        dependencies=['a', 'b', 'c']
    )
    assert compilation_result == expected



# Generated at 2022-06-25 23:11:31.419403
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('foo')
    out = Path('bar')
    io = InputOutput(input=inp, output=out)
    assert io.input == inp
    assert io.output == out

# Generated at 2022-06-25 23:11:38.060468
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert str(
        InputOutput(input=Path('/a/b/c.py'), output=Path('/a/b/c_compiled.py'))) == 'InputOutput(input=/a/b/c.py, output=/a/b/c_compiled.py)'

    assert str(
        InputOutput(input='/a/b/c.py', output=Path('/a/b/c_compiled.py'))) == 'InputOutput(input=/a/b/c.py, output=/a/b/c_compiled.py)'

    assert str(
        InputOutput(input=Path('/a/b/c.py'), output='/a/b/c_compiled.py')) == 'InputOutput(input=/a/b/c.py, output=/a/b/c_compiled.py)'

# Generated at 2022-06-25 23:11:40.604220
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = '/path/to/input'
    output = '/path/to/output'

    io = InputOutput(input, output)
    assert io.input == Path(input) and io.output == Path(output)



# Generated at 2022-06-25 23:11:42.155377
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path("/a"), Path("/b"))
    assert input_output.input == '/a'
    assert input_output.output == '/b'

# Generated at 2022-06-25 23:11:49.688783
# Unit test for constructor of class InputOutput
def test_InputOutput():
    Path('foo').mkdir()
    Path('foo/bar').mkdir()
    Path('foo/bar/baz').mkdir()
    Path('foo/bar/baz/buz.txt').touch()

    io = InputOutput('foo/bar/baz/buz.txt', 'foo/bar/buz2.txt')
    assert io.input == Path('foo/bar/baz/buz.txt')
    assert io.output == Path('foo/bar/buz2.txt')

    io = InputOutput(Path('foo/bar/baz/buz.txt'), Path('foo/bar/buz2.txt'))
    assert io.input == Path('foo/bar/baz/buz.txt')
    assert io.output == Path('foo/bar/buz2.txt')


# Generated at 2022-06-25 23:11:51.572729
# Unit test for constructor of class InputOutput
def test_InputOutput():
    r = InputOutput(input=Path('a'), output=Path('b'))
    assert r.input == Path('a')
    assert r.output == Path('b')