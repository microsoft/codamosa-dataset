

# Generated at 2022-06-25 23:03:35.644348
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tranformation_result_0 = TransformationResult(tree=ast.parse('''test_docstring
    class test_class:
        'test_class_docstring'
        attr = 1
        def __init__(self):
            pass
        def test_method(self):
            pass
    def test_function():
        'test_function_docstring'
        return 1
    test_int = 1
    test_float = 1.1
    test_list = [1, 2]
    test_tuple = (1, 2)
    test_dict = {1: 2}
    test_str = '1'
    test_set = {1, 2}
    test_bool = True
    test_none = None
    '''), tree_changed=True, dependencies=[])

# Generated at 2022-06-25 23:03:44.822084
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Test for default constructors
    transformation_result_0 = TransformationResult()
    transformation_result_1 = TransformationResult(None, None, None)
    transformation_result_2 = TransformationResult((ast.AST)(), False, [])

    # Test for fields
    assert transformation_result_0.tree == None
    assert transformation_result_0.tree_changed == None
    assert transformation_result_0.dependencies == None
    assert transformation_result_1.tree == None
    assert transformation_result_1.tree_changed == None
    assert transformation_result_1.dependencies == None
    assert transformation_result_2.tree == (ast.AST)()
    assert transformation_result_2.tree_changed == False
    assert transformation_result_2.dependencies == []


# Generated at 2022-06-25 23:03:46.137835
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Test class InputInput
    input_output_0 = InputOutput()


# Generated at 2022-06-25 23:03:50.154818
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=0, time=10.0, target=(3, 5), dependencies=['1', '2', '3'])
    assert result.files == 0
    assert result.time == 10.0
    assert result.target == (3, 5)
    assert result.dependencies == ['1', '2', '3']


# Generated at 2022-06-25 23:03:53.898869
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=1, time='test', target=(1, 2), dependencies=['test'])
    assert res.files == 1
    assert res.time == 'test'
    assert res.target == (1, 2)
    assert res.dependencies == ['test']


# Generated at 2022-06-25 23:04:03.135199
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # TestCase 0
    input_output_0 = InputOutput(input=Path('/tmp/iue7fnuwiz.py'),
                                 output=Path('/tmp/iue7fnuwiz.pyc'))
    input_output_1 = InputOutput(input=Path('/tmp/iue7fnuwiz.py'),
                                 output=Path('/tmp/iue7fnuwiz.pyc'))
    input_output_2 = InputOutput(input=Path('/tmp/iue7fnuwiz.py'),
                                 output=Path('/tmp/iue7fnuwiz.pyc'))
    files_0 = 3
    time_0 = 1.461561e+09
    target_0 = (3, 6)

# Generated at 2022-06-25 23:04:03.973915
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test_case_0()



# Generated at 2022-06-25 23:04:05.455360
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    global input_output_0
    assert input_output_0.input == input_output_0.output

# Generated at 2022-06-25 23:04:10.226796
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Assert type of instance attributes
    assert hasattr(TransformationResult(tree_changed=True, tree=ast.AST(), dependencies=[]), 'tree')
    assert hasattr(TransformationResult(tree_changed=True, tree=ast.AST(), dependencies=[]), 'tree_changed')
    assert hasattr(TransformationResult(tree_changed=True, tree=ast.AST(), dependencies=[]), 'dependencies')


# Generated at 2022-06-25 23:04:14.911291
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1, time=1.1, target=(3, 7), dependencies=['a'])
    assert isinstance(compilation_result, CompilationResult), 'compilation_result is of type CompilationResult'
    assert compilation_result.files == 1, 'compilation_result.files is 1'
    assert compilation_result.time == 1.1, 'compilation_result.time is 1.1'
    assert compilation_result.target == (3, 7), 'compilation_result.target is (3, 7)'
    assert compilation_result.dependencies == ['a'], 'compilation_result.dependencies is ["a"]'



# Note: we test more than the definition of OutputSuite

# Generated at 2022-06-25 23:04:17.537062
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(10, 10.0, (3, 7), ["hello", "dolly"])

# Generated at 2022-06-25 23:04:27.098246
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(tree=None, tree_changed=True, dependencies=[])
    assert result.tree is None
    assert result.tree_changed == True
    assert result.dependencies == []


# Result of single transformer
TransformationResultPerTransformer = NamedTuple('TransformationResultPerTransformer',
                                                [('input', TransformationResult),
                                                 ('output', TransformationResult)])

# Result of single transformer
TransformationResultPerTransformer = NamedTuple('TransformationResultPerTransformer',
                                                [('input', TransformationResult),
                                                 ('output', TransformationResult)])

# Result of single transformer
TransformationResultPerTransformer = NamedTuple('TransformationResultPerTransformer',
                                                [('input', TransformationResult),
                                                 ('output', TransformationResult)])

# Result of single transformer
Trans

# Generated at 2022-06-25 23:04:28.954040
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files = 1, time = 100,
                      target = (3, 7),
                      dependencies = ['a', 'b'])


# Generated at 2022-06-25 23:04:31.595282
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('foo/bar/baz.py')
    output = Path('foo/bar/baz.pyc')
    x = InputOutput(input, output)
    assert x.input == input
    assert x.output == output



# Generated at 2022-06-25 23:04:33.639922
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    p = InputOutput(input, output)
    assert p.input == input
    assert p.output == output


# Generated at 2022-06-25 23:04:35.690774
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    assert InputOutput(input, output).input == input
    assert InputOutput(input, output).output == output


# Generated at 2022-06-25 23:04:40.131738
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """Test constructor of InputOutput class."""
    inp = 'some_file.py'
    out = 'some_file.js'
    inp_out = InputOutput(inp, out)
    assert inp_out.input == inp
    assert inp_out.output == out


# Generated at 2022-06-25 23:04:46.098507
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=0,
                               time=0.0,
                               target=(0, 0),
                               dependencies=[])
    assert (result.files == 0 and
            result.time == 0.0 and
            result.target == (0, 0) and
            result.dependencies == [])



# Generated at 2022-06-25 23:04:50.964972
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(
        ast.parse('x = 1'),
        True,
        ['stdlib'])
    assert t.tree
    assert t.tree_changed
    assert t.dependencies[0] == 'stdlib'

# Generated at 2022-06-25 23:04:55.949381
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = InputOutput(Path('/tmp/input.py'), Path('/tmp/output.py'))
    assert i.input == Path('/tmp/input.py')
    assert i.output == Path('/tmp/output.py')
    assert i.input.suffix == '.py'
    assert i.output.suffix == '.py'

# unit test for constructor of class TransformationResult

# Generated at 2022-06-25 23:05:02.241029
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path('/home/foo/bar/input.py'),
                     Path('/home/foo/bar/output.py'))
    assert io.input == Path('/home/foo/bar/input.py')
    assert io.output == Path('/home/foo/bar/output.py')


# Generated at 2022-06-25 23:05:03.674485
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(tree=None, tree_changed=False, dependencies=[])

# Generated at 2022-06-25 23:05:08.217464
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.AST(), True, [])
    assert tr
    assert tr.tree
    assert tr.tree_changed
    assert tr.dependencies

# Generated at 2022-06-25 23:05:13.394736
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(1, 2.0, (3, 4), ["test.py"])
    assert res.files == 1
    assert res.time == 2.0
    assert res.target == (3, 4)
    assert res.dependencies == ["test.py"]



# Generated at 2022-06-25 23:05:18.969033
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # pylint: disable=unused-variable
    files, time, target, dependencies = \
        (1, 2.0, (3, 4), ['a', 'b'])
    compile_result = CompilationResult(files, time, target, dependencies)
    assert compile_result.files == files
    assert compile_result.time == time
    assert compile_result.target == target
    assert compile_result.dependencies == dependencies


# Generated at 2022-06-25 23:05:23.010513
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=5,
                            time=0.1,
                            target=(3, 7),
                            dependencies=['a', 'b'])
    assert res.files == 5
    assert res.time == 0.1
    assert res.target == (3, 7)
    assert res.dependencies == ['a', 'b']

# Generated at 2022-06-25 23:05:25.430349
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result = TransformationResult(None, False, list())
    assert transformation_result is not None



# Generated at 2022-06-25 23:05:27.358836
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a'), Path('b')).input == Path('a')
    asse

# Generated at 2022-06-25 23:05:28.818974
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input=Path('input.txt'), output=Path('output.txt'))


# Generated at 2022-06-25 23:05:32.645629
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("")
    assert TransformationResult(tree=tree, tree_changed=False,
                                dependencies=[]) == \
        TransformationResult(tree, False, [])

# Default compilation target version
DEFAULT_TARGET = (3, 7)

# Create an empty module

# Generated at 2022-06-25 23:05:41.119433
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    a = CompilationResult(files=2, time=1.0, target=(3, 7),
                          dependencies=['foo.py', 'bar.py'])
    assert a.files == 2
    assert a.time == 1.0
    assert a.target == (3, 7)
    assert a.dependencies == ['foo.py', 'bar.py']


# Generated at 2022-06-25 23:05:44.674433
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    assert TransformationResult(tree=None,
                                tree_changed=False,
                                dependencies=[])

# Generated at 2022-06-25 23:05:52.022689
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path('/tmp')
    path2 = Path('/var')

    inputOutput = InputOutput(input = path1,
                              output = path2)

    assert inputOutput.input == path1, 'Invalid input'
    assert inputOutput.output == path2, 'Invalid output'


# Generated at 2022-06-25 23:05:54.863166
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path = Path('/test/path')
    io = InputOutput(path, path)
    assert io.input == path
    assert io.output == path

# Generated at 2022-06-25 23:05:58.481749
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_input = '/Users/abc/abc.1'
    test_output = '/Users/abc/abc.2'
    pair = InputOutput(input=Path(test_input), output=Path(test_output))
    assert pair.input == Path(test_input)
    assert pair.output == Path(test_output)


# Generated at 2022-06-25 23:05:59.922385
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=0, time=0.0, target=(0, 0), dependencies=[])


# Generated at 2022-06-25 23:06:02.941901
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = InputOutput(Path(__file__), Path(__file__))
    assert isinstance(i.input, Path)
    assert isinstance(i.output, Path)
    assert i.output == i.input



# Generated at 2022-06-25 23:06:05.295538
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/in')
    output = Path('/tmp/out')

    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output

# Generated at 2022-06-25 23:06:07.889399
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('a/b')
    output = Path('output')
    a = InputOutput(input, output)
    assert a.input == input
    assert a.output == output



# Generated at 2022-06-25 23:06:10.737969
# Unit test for constructor of class InputOutput
def test_InputOutput():
    files = ['/foo/file1', '/foo/file2']
    input_output = InputOutput(files[0], files[1])

    assert(input_output.input == files[0])
    assert(input_output.output == files[1])

# Generated at 2022-06-25 23:06:21.474085
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=10,
                      time=5.5,
                      target=(3, 5),
                      dependencies=['stdlib', 'numpy'])

# Generated at 2022-06-25 23:06:23.201235
# Unit test for constructor of class TransformationResult
def test_TransformationResult(): # type: () -> None
    def hoge(x):
        return TransformationResult(ast.parse(x), True, [])
    hoge('')

# Generated at 2022-06-25 23:06:27.592890
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse("pass")
    r = TransformationResult(tree=t, tree_changed=True, dependencies=['a', 'b'])
    assert r.tree is t
    assert r.tree_changed is True
    assert r.dependencies == ['a', 'b']

# Generated at 2022-06-25 23:06:30.434337
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(
            ast.AST(), False, []).tree is not None
    assert TransformationResult(
            ast.AST(), False, []).tree_changed is False
    assert TransformationResult(
            ast.AST(), False, []).dependencies == []

# Generated at 2022-06-25 23:06:33.096940
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(
        files=2,
        time=3.,
        target=(3, 4),
        dependencies=['A', 'b'])
    assert res.files == 2
    assert res.time == 3.
    assert res.target == (3, 4)
    assert res.dependencies == ['A', 'b']



# Generated at 2022-06-25 23:06:34.883387
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from compile_all import TransformationResult
    TransformationResult(ast.AST(), True, ["a", "b", "c"])

# Generated at 2022-06-25 23:06:39.592008
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.AST(), True, ['File1', 'File2'])

# Result of the merge of two files
MergedFileResult = NamedTuple('MergedFileResult', [('file', str),
                                                   ('text', str),
                                                   ('success', bool)])


# Generated at 2022-06-25 23:06:43.278771
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('foo')
    output = Path('bar')
    io = InputOutput(input, output)

    assert io.input == input
    assert io.output == output
    assert io._field_types['input'] == Path
    assert io._field_types['output'] == Path
    assert io._fields == ('input', 'output')


# Generated at 2022-06-25 23:06:44.683903
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=None,tree_changed=False,dependencies=[])

# Generated at 2022-06-25 23:06:48.368673
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1,
                           time=1,
                           target=(1, 1),
                           dependencies=[])
    assert cr.files == 1
    assert cr.time == 1
    assert cr.target == (1, 1)
    assert cr.dependencies == []


# Generated at 2022-06-25 23:07:09.228565
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 2.0, (3, 4), ['a', 'b'])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-25 23:07:12.135227
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a=1')
    deps = ['hello.py']

    t = TransformationResult(tree, True, deps)

    assert t.tree == tree
    assert t.tree_changed == True
    assert t.dependencies == deps


# Generated at 2022-06-25 23:07:14.798785
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # pylint: disable=missing-docstring
    wi = InputOutput(Path('input.py'), Path('output.py'))
    assert wi.input == Path('input.py')
    assert wi.output == Path('output.py')


# Generated at 2022-06-25 23:07:16.433170
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=0.1, target=(2, 7),
                      dependencies=['one', 'two'])

# Generated at 2022-06-25 23:07:17.930893
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path('foo'), Path('bar'))
    assert io.input == Path('foo')
    assert io.output == Path('bar')

# Generated at 2022-06-25 23:07:19.198215
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=0.0, target=(3, 7), dependencies=[])



# Generated at 2022-06-25 23:07:22.616829
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=None,
                              tree_changed=True,
                              dependencies=["file.txt"])
    assert tr is not None

# Generated at 2022-06-25 23:07:24.630973
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input.py')
    output = Path('output.py')
    pair = InputOutput(input, output)
    assert pair.input == input
    assert pair.output == output

# Generated at 2022-06-25 23:07:28.920451
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('input')
    o = Path('output')
    j = InputOutput(i, o)
    assert j.input == i
    assert j.output == o

# Generated at 2022-06-25 23:07:32.251297
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.parse('a = 1'), True, [])
    assert type(tr.tree) == ast.Module
    assert tr.tree_changed == True
    assert tr.dependencies == []


# Generated at 2022-06-25 23:08:09.702126
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1,
                      time=1.1,
                      target=(2, 3),
                      dependencies=['a', 'b'])

# Generated at 2022-06-25 23:08:13.570163
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=2.0,
                           target=(3, 4),
                           dependencies=['a', 'b', 'c'])
    assert cr.files == 1
    assert cr.time == 2.0
    assert cr.target == (3, 4)
    assert cr.dependencies == ['a', 'b', 'c']

# Generated at 2022-06-25 23:08:16.564282
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Arrange
    input_ = 'input'
    output = 'output'

    # Act
    input_output = InputOutput(input_, output)

    # Assert
    assert input_output.input == Path(input_)
    assert input_output.output == Path(output)



# Generated at 2022-06-25 23:08:19.758284
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/foo/bar.py')
    output = Path('/foo/baz.py')

    input_output = InputOutput(input, output)

    assert input_output.input == input
    assert input_output.output == output

# Generated at 2022-06-25 23:08:24.353791
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('input')
    output = Path('output')
    io = InputOutput(input_, output)
    assert io.input == input_
    assert io.output == output
    assert io.input is not input_
    assert io.output is not output


# Generated at 2022-06-25 23:08:27.123711
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    try:
        TransformationResult(
            tree=ast.parse('1+1'),
            tree_changed=False,
            dependencies=[])
        assert True
    except:
        assert False, 'TransformationResult class does not work'

# Generated at 2022-06-25 23:08:31.604554
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    a = TransformationResult(None, False, [])
    b = TransformationResult(None, False, [])
    assert a == b
    c = TransformationResult(None, True, [])
    assert a != c
    d = TransformationResult(None, False, ['f'])
    assert a != d
    e = TransformationResult(ast.parse('pass'), False, [])
    assert a != e
    assert c != e
    assert d != e
    assert e.tree_changed
    assert not a.tree_changed

# Generated at 2022-06-25 23:08:33.907785
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(3, 2.0, (3, 5), ['a', 'b'])
    assert result.files == 3
    assert result.time == 2.0
    assert result.target == (3, 5)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-25 23:08:34.864977
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.parse('x = 1'), True, ['a', 'b'])

# Generated at 2022-06-25 23:08:36.113999
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2.0, (3, 4), [])


# Generated at 2022-06-25 23:10:09.439104
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, None, None)


# Generated at 2022-06-25 23:10:11.718813
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('/in')
    output_path = Path('/out')
    assert InputOutput(input_path, output_path).input == input_path
    assert InputOutput(input_path, output_path).output == output_path

# Generated at 2022-06-25 23:10:15.949997
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=2,
                                           time=14.5,
                                           target=(3,1),
                                           dependencies=['a', 'b'])
    assert compilation_result.files == 2
    assert compilation_result.time == 14.5
    assert compilation_result.target == (3,1)
    assert compilation_result.dependencies == ['a', 'b']


# Generated at 2022-06-25 23:10:18.060168
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = 'input'
    output = 'output'
    i_o = InputOutput(input_, output)
    assert i_o.input == input_
    assert i_o.output == output

# Generated at 2022-06-25 23:10:22.595319
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=10,
                           time=5.1,
                           target=(3, 5),
                           dependencies=['foo', 'bar'])
    
    # test fields
    assert cr.files == 10
    assert cr.time == 5.1
    assert cr.target == (3, 5)
    assert cr.dependencies[0] == 'foo'
    assert cr.dependencies[1] == 'bar'
    assert len(cr.dependencies) == 2


# Generated at 2022-06-25 23:10:26.106000
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=0,
                          time=1.0,
                          target=(2, 3),
                          dependencies=[])
    assert c.files == 0
    assert c.time == 1.0
    assert c.target == (2, 3)
    assert c.dependencies == []


# Generated at 2022-06-25 23:10:27.655403
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2.0, (3, 4), ['a', 'b', 'c'])

# Generated at 2022-06-25 23:10:29.914061
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('test_input')
    output = Path('test_output')
    result = InputOutput(input=input, output=output)
    assert result.input == input
    assert result.output == output



# Generated at 2022-06-25 23:10:32.581510
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = "~/some_path/some_file.py"
    path2 = "~/some_path/some_file_trans.py"
    input_output = InputOutput(input=Path(path1), output=Path(path2))
    assert input_output.input == Path(path1)
    assert input_output.output == Path(path2)

# Generated at 2022-06-25 23:10:37.284487
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(4, 0.1, (3, 5), [])
    actual_module_name = result.__class__.__module__
    assert actual_module_name == 'py2py3'
    actual_class_name = result.__class__.__name__
    assert actual_class_name == 'CompilationResult'
    actual_files = result.files
    assert actual_files == 4
    actual_time = result.time
    assert actual_time == 0.1
    actual_target = result.target
    assert actual_target == (3, 5)
    actual_dependencies = result.dependencies
    assert actual_dependencies == []
