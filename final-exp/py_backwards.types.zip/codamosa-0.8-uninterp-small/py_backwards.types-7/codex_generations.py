

# Generated at 2022-06-25 23:03:35.722077
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Should have the right type of tree
    result = TransformationResult(ast.parse('1'), False, ['blah'])
    assert isinstance(result.tree, ast.AST)
    # Should be false if tree changed
    assert result.tree_changed == False
    # Should be true if tree changed
    result = TransformationResult(ast.parse('1'), True, ['blah'])
    assert result.tree_changed == True
    # Should be a list of strings
    for dep in result.dependencies:
        assert isinstance(dep, str)


# Generated at 2022-06-25 23:03:41.542414
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(1, 0.0, (3, 6), [])
    assert compilation_result_0.files == 1
    assert compilation_result_0.time == 0.0
    assert compilation_result_0.target == (3, 6)
    assert isinstance(compilation_result_0.target, tuple)
    assert compilation_result_0.dependencies == []
    assert isinstance(compilation_result_0.dependencies, list)



# Generated at 2022-06-25 23:03:48.469593
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test_node = ast.Parse('''x = 4''', mode='exec')
    test_deps = ['all']
    test_case_0 = TransformationResult(test_node, True, test_deps)
    test_case_1 = TransformationResult(test_node, False, test_deps)
    assert test_case_0.tree == test_node
    assert test_case_0.tree_changed == True
    assert test_case_0.dependencies == test_deps
    assert test_case_1.tree_changed == False


# Generated at 2022-06-25 23:03:49.861787
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult()
    assert isinstance(result, TransformationResult)


# reduce the number of levels of directory nesting

# Generated at 2022-06-25 23:03:55.453203
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # case 0
    tree_node_0 = ast.Module([])
    dependency_list_0 = ["a", "b", "c"]
    transformation_result_0 = TransformationResult(tree=tree_node_0, tree_changed=False, dependencies=dependency_list_0)

    # assert
    assert transformation_result_0.tree == tree_node_0
    assert transformation_result_0.tree_changed == False


# Generated at 2022-06-25 23:03:58.392375
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult()
    compilation_result_1 = CompilationResult(files=0, time=0.0,
                                             target=(2, 7), dependencies=[])


# Generated at 2022-06-25 23:04:01.661201
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inputPath = Path("test_input.py")
    outputPath = Path("test_output.py")
    inputOutput = InputOutput(inputPath, outputPath)
    assert inputOutput.input == inputPath
    assert inputOutput.output == outputPath


# Generated at 2022-06-25 23:04:03.817791
# Unit test for constructor of class InputOutput
def test_InputOutput():
    testIO = InputOutput('input', 'output')
    assert testIO.input == 'input'
    assert testIO.output == 'output'


# Generated at 2022-06-25 23:04:04.994191
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult()


# Generated at 2022-06-25 23:04:11.029037
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('/home/kolya/RISCV/VM/examples/python_implementation/add.py'),
                      Path('/home/kolya/RISCV/VM/examples/python_implementation/add.rpy')) == \
           InputOutput(Path('/home/kolya/RISCV/VM/examples/python_implementation/add.py'),
                       Path('/home/kolya/RISCV/VM/examples/python_implementation/add.rpy'))

# Generated at 2022-06-25 23:04:18.341097
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_1 = CompilationResult(33,
                                             0.123,
                                             (3, 8),
                                             ['a'])
    assert type(compilation_result_1.files) == int
    assert type(compilation_result_1.time) == float
    assert type(compilation_result_1.target) == tuple
    assert type(compilation_result_1.dependencies) == list



# Generated at 2022-06-25 23:04:22.410097
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    test_case_0()

# data type definition of class CompilationResult
# the data type of 'files' is int
# the data type of 'time' is float
# the data type of 'target' is CompilationTarget
# the data type of 'dependencies' is List[str]



# Generated at 2022-06-25 23:04:25.320625
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path("Input.txt")
    output = Path("Output.txt")
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-25 23:04:27.979844
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.AST()
    tree_changed = False
    dependencies = []
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result



# Generated at 2022-06-25 23:04:30.716394
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    i = ast.parse("a")
    result1 = TransformationResult(i, True, ["a"])
    assert result1.tree == i
    assert result1.tree_changed
    assert result1.dependencies == ["a"]

# Generated at 2022-06-25 23:04:34.183252
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(files=1, time=0.0, target=(2,
                                             7), dependencies=[])
    assert compilation_result_0.files == 1
    assert compilation_result_0.time == 0.0
    assert compilation_result_0.target == (2, 7)
    assert compilation_result_0.dependencies == []


# Generated at 2022-06-25 23:04:39.483632
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(
        files=10, time=3.4, target=(3, 6), dependencies=['compilation_result.py'])
    assert compilation_result.files == 10
    assert compilation_result.time == 3.4
    assert compilation_result.target == (3, 6)
    assert compilation_result.dependencies == ['compilation_result.py']

# Generated at 2022-06-25 23:04:40.761502
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Test 0
    input_output_0 = InputOutput()


# Generated at 2022-06-25 23:04:41.597257
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult()



# Generated at 2022-06-25 23:04:45.837345
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = InputOutput(input="input", output="output")
    assert a.input == "input"
    assert a.output == "output"


# Generated at 2022-06-25 23:04:53.877297
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult()
    assert compilation_result.files == 0
    assert compilation_result.time == 0.0
    assert compilation_result.target == (-1, -1)
    assert compilation_result.dependencies == []


input_output_0 = InputOutput()


# Generated at 2022-06-25 23:04:56.619501
# Unit test for constructor of class InputOutput
def test_InputOutput():
    try:
        assert InputOutput(Path('data/input.txt'), Path('data/output.txt'))
    except AssertionError:
        raise AssertionError()


# Generated at 2022-06-25 23:05:08.600092
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # usage:
    # compilation_result = CompilationResult(9, 3.2, (2, 7))
    compilation_result_0 = CompilationResult(9, 3.2, (2, 7))
    compilation_result_1 = CompilationResult(4, 3.4, (3, 4), ['fake_dependency_1', 'fake_dependency_2'])
    #assert compilation_result_0.files == 9
    #assert compilation_result_0.time == 3.2
    #assert compilation_result_0.target == (2, 7)
    #assert compilation_result_0.dependencies == []
    #assert compilation_result_1.files == 4
    #assert compilation_result_1.time == 3.4
    #assert compilation_result_1.target == (3, 4)
    #assert compilation_

# Generated at 2022-06-25 23:05:13.393631
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path('input.txt')
    path2 = Path('output.txt')
    input_ouput = InputOutput(path1, path2)
    assert input_ouput.input == path1
    assert input_ouput.output == path2


# Generated at 2022-06-25 23:05:18.970374
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_1 = CompilationResult(files=0,
                                             time=0.0,
                                             target=(3, 0),
                                             dependencies=["abc.py"])

    assert compilation_result_1.files == 0
    assert compilation_result_1.time == 0.0
    assert compilation_result_1.target == (3, 0)
    assert compilation_result_1.dependencies == ["abc.py"]



# Generated at 2022-06-25 23:05:23.719460
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1,
                                           time=0.1,
                                           target=(3, 6),
                                           dependencies=['foo', 'bar'])
    assert compilation_result.files == 1
    assert compilation_result.time == 0.1
    assert compilation_result.target == (3, 6)
    assert compilation_result.dependencies == ['foo', 'bar']



# Generated at 2022-06-25 23:05:28.369193
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_0 = Path("/usr/lib")
    output_0 = Path("/usr/local/bin")
    input_output = InputOutput(input_0, output_0)
    assert input_0 == input_output.input
    assert output_0 == input_output.output


# Generated at 2022-06-25 23:05:32.860436
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # test if the constructor is correct
    # test arguments: [tree, tree_changed, dependencies]
    tree = None
    tree_changed = None
    dependencies = ['a.py']
    transformation_result = TransformationResult(tree,
                                                  tree_changed,
                                                  dependencies)
    assert isinstance(transformation_result, TransformationResult)


# Generated at 2022-06-25 23:05:36.259776
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult()
    assert compilation_result_0.files == 0
    assert compilation_result_0.time == 0
    assert compilation_result_0.target == (0, 0)
    assert compilation_result_0.dependencies == []




# Generated at 2022-06-25 23:05:37.479977
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.AST(), True, ['a/b'])

# Generated at 2022-06-25 23:05:47.761215
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput('input', 'output')
    assert input_output_0.input is 'input'
    assert input_output_0.output is 'output'


# Generated at 2022-06-25 23:05:52.021124
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(
        files=0,
        time=0,
        target=(1, 0),
        dependencies=[])
    assert isinstance(compilation_result_0, CompilationResult)


# Generated at 2022-06-25 23:05:57.160520
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    a = TransformationResult(tree=None, tree_changed=True, dependencies=[])
    assert a.tree_changed == True
    assert a.dependencies == []
    b = TransformationResult(tree=ast.parse(""), tree_changed=False, dependencies=["a","b"])
    assert b.tree_changed == False
    assert b.dependencies == ["a","b"]

# Generated at 2022-06-25 23:05:59.543447
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()
    assert isinstance(input_output_0.input, Path) is True
    assert isinstance(input_output_0.output, Path) is True


# Generated at 2022-06-25 23:06:02.079282
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result_0 = TransformationResult()

    assert transformation_result_0.tree is None
    assert transformation_result_0.tree_changed is None
    assert transformation_result_0.dependencies == []



# Generated at 2022-06-25 23:06:03.362987
# Unit test for constructor of class TransformationResult
def test_TransformationResult():

    ast.parse('x==x+1')



# Generated at 2022-06-25 23:06:06.823847
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # create an instance of TransformationResult class
    res = TransformationResult('tree', 'tree_changed', 'dependencies')
    # check if the instance correctly initialized
    assert res.tree == 'tree'
    assert res.tree_changed == 'tree_changed'
    assert res.dependencies == 'dependencies'

# Generated at 2022-06-25 23:06:09.833170
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult().files == 0
    assert CompilationResult().time == 0
    assert CompilationResult().target == (0, 0)
    assert CompilationResult().dependencies == []

# Unit tests for constructor of class InputOutput

# Generated at 2022-06-25 23:06:11.454364
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.AST()
    dependencies = ['1', '2', '3']
    result = TransformationResult(tree, False, dependencies)
    assert result.tree == tree
    assert result.tree_changed == False
    assert result.dependencies == dependencies

# Generated at 2022-06-25 23:06:15.949566
# Unit test for constructor of class TransformationResult
def test_TransformationResult():

    transfo_result = TransformationResult(ast.Expr(value=ast.Num(n=42)), True, ["test1", "test2"])

    assert transfo_result.tree == ast.Expr(value=ast.Num(n=42))
    assert transfo_result.tree_changed == True
    assert transfo_result.dependencies == ["test1", "test2"]

# Generated at 2022-06-25 23:06:40.769405
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(
        # files
        23,
        # time
        0.1,
        # target
        (3, 6),
        # dependencies
        ["/home/alice/.local/lib/python3.6/site-packages/future/types/newobject.py",
         "/home/alice/.local/lib/python3.6/site-packages/future/utils/__init__.py",
         "/home/alice/.local/lib/python3.6/site-packages/future/standard_library/__init__.py"])

# Generated at 2022-06-25 23:06:45.758267
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_1 = CompilationResult(
        10,
        12.3,
        (3, 5),
        ['dep1', 'dep2'])
    assert compilation_result_1.files == 10
    assert compilation_result_1.time == 12.3
    assert compilation_result_1.target == (3, 5)
    assert compilation_result_1.dependencies == ['dep1', 'dep2']



# Generated at 2022-06-25 23:06:46.610321
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult()



# Generated at 2022-06-25 23:06:51.088844
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("print ('Hello, World')")
    transformed_tree = ast.parse("print ('Hello, World')")
    tree_changed = True
    dependencies = ['BeautifulSoup']
    transformation = TransformationResult(tree, transformed_tree, tree_changed, dependencies)
    assert isinstance(transformation, TransformationResult)
    assert transformation.tree == tree
    assert transformation.tree_changed == tree_changed
    assert transformation.dependencies == dependencies

# Generated at 2022-06-25 23:06:52.128777
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()


# Generated at 2022-06-25 23:06:54.988513
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("def print_example():\n    print 'Test'")
    dependencies = ['dep1', 'dep2']
    tr = TransformationResult(tree, True, dependencies)
    assert tr.tree is tree
    assert tr.tree_changed is True
    assert tr.dependencies is dependencies


# Generated at 2022-06-25 23:06:56.760502
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path()
    output = Path()
    assert isinstance(InputOutput(input, output), InputOutput)


# Generated at 2022-06-25 23:07:01.457981
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 2, (3, 4), ['test']).files == 1
    assert CompilationResult(1, 2, (3, 4), ['test']).time == 2
    assert CompilationResult(1, 2, (3, 4), ['test']).target == (3, 4)
    assert CompilationResult(1, 2, (3, 4), ['test']).dependencies == ['test']


# Generated at 2022-06-25 23:07:09.300546
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t1 = ast.parse('a = 1')
    t2 = ast.parse('b = 2')
    result1 = TransformationResult(t1, False, ['a'])
    result2 = TransformationResult(t2, True, ['b', 'c'])
    assert (isinstance(result1.tree, ast.AST))
    assert (isinstance(result1.tree_changed, bool))
    assert (isinstance(result1.dependencies, list))
    assert (isinstance(result2.tree, ast.AST))
    assert (isinstance(result2.tree_changed, bool))
    assert (isinstance(result2.dependencies, list))


# Generated at 2022-06-25 23:07:12.242384
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path("/tmp/input.txt")
    output = Path("/tmp/output.txt")
    input_output = InputOutput(input, output)

    assert input_output.input == input
    assert input_output.output == output



# Generated at 2022-06-25 23:07:53.925603
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=15, time=7.12,
                                           target=(2, 1),
                                           dependencies=['file1', 'file2'])
    assert compilation_result.files == 15
    assert compilation_result.time == 7.12
    assert compilation_result.target == (2, 1)
    assert compilation_result.dependencies == ['file1', 'file2']


# Generated at 2022-06-25 23:07:57.314888
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('.')
    output = Path('.')
    input_output = InputOutput(input, output)
    assert_equals(input_output.input, input)
    assert_equals(input_output.output, output)

# Generated at 2022-06-25 23:07:58.662225
# Unit test for constructor of class InputOutput
def test_InputOutput():
    out = InputOutput(input = Path('input.py'),
                      output = Path('output.py'))



# Generated at 2022-06-25 23:08:01.337937
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast = ast.AST()
    tree_changed = False
    dependencies = []

    new_TransformationResult = TransformationResult(ast, tree_changed, dependencies)
    assert new_TransformationResult.tree == ast
    a

# Generated at 2022-06-25 23:08:03.095210
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # test
    compilation_result = CompilationResult(1, 2.0, (3, 4), ["abc"])


# Generated at 2022-06-25 23:08:06.001213
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(
        ast.AST, False, []).tree is ast.AST
    assert TransformationResult(
        ast.AST, False, []).tree_changed is False
    assert TransformationResult(
        ast.AST, False, []).dependencies == []


# Generated at 2022-06-25 23:08:08.578626
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """Assert InputOutput constructor."""
    input_output = InputOutput(Path('input.py'), Path('output.py'))
    assert input_output.input == Path('input.py')
    assert input_output.output == Path('output.py')


# Generated at 2022-06-25 23:08:10.195474
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_0 = '.'
    output_0 = '.'
    InputOutput(input_0, output_0)



# Generated at 2022-06-25 23:08:13.068393
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(1, 1.0, (3, 7), [])
    assert compilation_result.files == 1
    assert compilation_result.time == 1.0
    assert compilation_result.target == (3, 7)
    assert compilation_result.dependencies == []

# Generated at 2022-06-25 23:08:14.173863
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path("foo"), Path("bar"))


# Generated at 2022-06-25 23:09:05.366248
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("a = 1")
    tree_changed = True
    dependencies = []
    transformation_result = TransformationResult(tree=tree,
                                                 tree_changed=tree_changed,
                                                 dependencies=dependencies)
    assert transformation_result.tree == tree
    assert transformation_result.tree_changed == tree_changed
    assert transformation_result.dependencies == dependencies


# Generated at 2022-06-25 23:09:08.847765
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from pytoda.transformation_result import TransformationResult
    tree = ast.parse("")
    tree_changed = True
    dependencies = []
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == ast.parse("")
    assert result.tree_changed == True
    assert result.dependencies == []


# Generated at 2022-06-25 23:09:09.872815
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()


# Generated at 2022-06-25 23:09:14.031912
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 2.0, (1, 2), ["a"]).files == 1
    assert CompilationResult(1, 2.0, (1, 2), ["a"]).time == 2.0
    assert CompilationResult(1, 2.0, (1, 2), ["a"]).target == (1, 2)
    assert CompilationResult(1, 2.0, (1, 2), ["a"]).dependencies == ["a"]


# Generated at 2022-06-25 23:09:19.701932
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.AST()
    dependency = "dependency"
    input = "input"
    output = "output"
    compilation = "target"
    tree_changed = "tree_changed"
    result = TransformationResult(tree, tree_changed, dependency)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependency
    result = TransformationResult(input, output, compilation)
    assert result.tree == input
    assert result.tree_changed == output
    assert result.dependencies == compilation

# Generated at 2022-06-25 23:09:25.704057
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input0 = Path('dummy_input')
    output0 = Path('dummy_output')
    input_output_0 = InputOutput(input=input0, output=output0)
    input_output_1 = InputOutput(dummy_input, dummy_output)
    input_output_2 = InputOutput(dummy_input, input_output_0.output)
    input_output_3 = InputOutput(input_output_0.input, dummy_output)
    input_output_4 = InputOutput(input_output_0.input, input_output_0.output)


# Generated at 2022-06-25 23:09:28.062432
# Unit test for constructor of class InputOutput
def test_InputOutput():
    from pathlib import Path
    i = 'input'
    o = 'output'
    assert InputOutput(input='input', output='output').input == i
    assert InputOutput(input='input', output='output').output == o


# Generated at 2022-06-25 23:09:31.504678
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(0, 0.0, (0, 0), [""])

    assert compilation_result_0.files == 0
    assert compilation_result_0.time == 0.0
    assert compilation_result_0.target == (0, 0)
    assert compilation_result_0.dependencies == [""]



# Generated at 2022-06-25 23:09:34.644161
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input, output = 'input', 'output'
    test_input_output = InputOutput(input, output)
    assert test_input_output.input == input
    assert test_input_output.output == output


# Generated at 2022-06-25 23:09:36.752012
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path_0 = Path('C:\\sample_input1.txt')
    path_1 = Path('C:\\sample_output.txt')
    input_output_0 = InputOutput(path_0, path_1)


# Generated at 2022-06-25 23:11:21.942327
# Unit test for constructor of class InputOutput
def test_InputOutput():
    c = InputOutput('/home/input', '/home/output')
    if c.input == '/home/input':
        print('Success')
    else:
        print('Failure')


# Generated at 2022-06-25 23:11:23.920598
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test_result_0 = TransformationResult(tree=ast.parse('x=1'),
                                         tree_changed=False,
                                         dependencies=['foo.py', 'bar.py'])

# Generated at 2022-06-25 23:11:30.307572
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test_tree = ast.AST()
    test_changed = True
    test_dependencies = []

    assert (TransformationResult(test_tree, test_changed, test_dependencies) ==
            TransformationResult(test_tree, test_changed, test_dependencies))

    assert (TransformationResult(test_tree, test_changed, test_dependencies) is not
            TransformationResult(test_tree, test_changed, test_dependencies))


# Generated at 2022-06-25 23:11:37.070234
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    tree_0 = ast.AST()
    tree_1 = ast.AST()
    tree_2 = ast.AST()
    compilation_result_0 = CompilationResult(0, 0.0, (0, 0), [])
    assert (compilation_result_0.files == 0)
    assert (compilation_result_0.time == 0.0)
    assert (compilation_result_0.target == (0, 0))
    assert (compilation_result_0.dependencies == [])
    compilation_result_1 = CompilationResult(0, 0.0, (0, 0), ['', '', ''])
    assert (compilation_result_1.files == 0)
    assert (compilation_result_1.time == 0.0)
    assert (compilation_result_1.target == (0, 0))

# Generated at 2022-06-25 23:11:43.455813
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(1, 1.0, (1, 1), [])
    assert isinstance(compilation_result_0.files, int)
    assert isinstance(compilation_result_0.time, float)
    assert isinstance(compilation_result_0.target, tuple)
    assert isinstance(compilation_result_0.dependencies, list)
    assert compilation_result_0.files == 1
    assert compilation_result_0.time == 1.0
    assert compilation_result_0.target == (1, 1)
    assert compilation_result_0.dependencies == []
    compilation_result_1 = CompilationResult(1, 1.0, (1, 1), [])
    assert isinstance(compilation_result_1.files, int)

# Generated at 2022-06-25 23:11:47.074917
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(1, 0.1, (3, 7), [])
    assert 1 == compilation_result.files
    assert 0.1 == compilation_result.time
    assert (3, 7) == compilation_result.target
    assert [] == compilation_result.dependencies


# Generated at 2022-06-25 23:11:48.869915
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult()
    print(compilation_result_0.files)
    assert (compilation_result_0.files == 0)


# Generated at 2022-06-25 23:11:50.290834
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result_0 = TransformationResult()

# Unit tests for constructor of class CompilationResult

# Generated at 2022-06-25 23:11:51.196504
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inputoutput_0 = InputOutput(Path(), Path())


# Generated at 2022-06-25 23:11:53.834996
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.AST()
    tree_changed = True
    dependencies = ['dependency_a']

    transformation_result = TransformationResult(tree, tree_changed, dependencies)

    assert transformation_result.tree == tree
    assert transformation_result.tree_changed == tree_changed
    assert transformation_result.dependencies == dependencies
