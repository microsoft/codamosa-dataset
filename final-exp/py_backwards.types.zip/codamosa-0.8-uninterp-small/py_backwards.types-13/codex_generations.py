

# Generated at 2022-06-25 23:03:38.589371
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 2.3, (3, 4), ['a', 'b']) == CompilationResult(1, 2.3, (3, 4), ['a', 'b']), \
        "Unit test for constructor of class CompilationResult failed"



# Generated at 2022-06-25 23:03:40.834431
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert transformation_result_0.tree == None
    assert transformation_result_0.tree_changed == False
    assert transformation_result_0.dependencies == None

# Generated at 2022-06-25 23:03:43.019877
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result = TransformationResult()
    assert transformation_result.tree == None
    assert transformation_result.tree_changed == None
    assert transformation_result.dependencies == None

# Generated at 2022-06-25 23:03:45.271095
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result_0 = TransformationResult(ast.AST(), False, str())


# Generated at 2022-06-25 23:03:49.179233
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result = TransformationResult(tree=ast.AST(), tree_changed=True, dependencies=["test"])
    assert transformation_result.tree == ast.AST()
    assert transformation_result.tree_changed == True
    assert transformation_result.dependencies == ["test"]
    assert isinstance(transformation_result, TransformationResult)


# Generated at 2022-06-25 23:03:53.241499
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(input=Path("input.txt"), output=Path("output.txt"))
    assert input_output.input == Path("input.txt")
    assert input_output.output == Path("output.txt")


# Generated at 2022-06-25 23:03:56.946233
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_1 = Path('/var')
    output_1 = Path('/usr')
    test_pair_1 = InputOutput(input=input_1, output=output_1)
    assert test_pair_1 == NamedTuple(input='/var', output='/usr')


# Generated at 2022-06-25 23:04:00.518059
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Check properties
    input_output = InputOutput(Path('foo.bar'), Path('bar.baz'))
    assert input_output.input == Path('foo.bar')
    assert input_output.output == Path('bar.baz')


# Generated at 2022-06-25 23:04:02.229170
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2, (3, 4), ["a", "b", "c"])


# Generated at 2022-06-25 23:04:03.384841
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()



# Generated at 2022-06-25 23:04:08.307907
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(0, 1.0, (3, 7), ['/tmp/path'])
    assert not result.files
    assert result.time == 1.0
    assert result.target == (3, 7)
    assert result.dependencies == ['/tmp/path']


# Generated at 2022-06-25 23:04:11.869388
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(tree=1,
                                  tree_changed=True,
                                  dependencies=["a"])
    assert(result.tree==1)
    assert(result.tree_changed)
    assert(result.dependencies==["a"])
    assert(isinstance(result, NamedTuple))


# Generated at 2022-06-25 23:04:15.076641
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(ast.Module([]), True, [])
    assert res.tree == ast.Module([])
    assert res.tree_changed == True
    assert res.dependencies == []


# Generated at 2022-06-25 23:04:20.320684
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Check that types are correct
    result = CompilationResult(1, 2.5, (3, 4), ['a'])
    assert isinstance(result.files, int)
    assert isinstance(result.time, float)
    assert isinstance(result.target, CompilationTarget)
    assert isinstance(result.dependencies, List[str])
    assert isinstance(result.dependencies[0], str)


# Generated at 2022-06-25 23:04:23.985896
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('/home/user/file.py')  # type: ignore
    out = Path('/home/user/file.pyc')  # type: ignore
    res = InputOutput(input=inp, output=out)
    assert res.input == inp
    assert res.output == out

# Generated at 2022-06-25 23:04:29.241138
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # GIVEN
    tree = ast.parse('1 + 1')
    tree_changed = True
    dependencies = ['/path/to/foo.py', '/path/to/bar.py']

    # WHEN
    result = TransformationResult(tree, tree_changed, dependencies)

    # THEN
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies



# Generated at 2022-06-25 23:04:31.166643
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(1, 1.0, (3, 6), ['a', 'b'])
    assert len(cr) == 4
    assert cr.files == 1
    assert cr.time == 1.0
    assert cr.target == (3, 6)
    assert cr.dependencies == ['a', 'b']


# Generated at 2022-06-25 23:04:35.935749
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    import pytest
    from typed_ast.ast3 import Module, parse
    res = TransformationResult(tree=Module(),
                               tree_changed=True,
                               dependencies=['a', 'b', 'c'])
    assert len(res.dependencies) == 3
    assert res.dependencies == ['a', 'b', 'c']
    assert res.tree_changed
    assert isinstance(res.tree, ast.AST)
    assert 'tree' in res._fields
    assert 'dependencies' in res._fields
    assert 'tree_changed' in res._fields

    with pytest.raises(TypeError):
        TransformationResult(tree=parse('name = 1'),
                             tree_changed=False,
                             dependencies=['a', 'b', 'c'])

# Generated at 2022-06-25 23:04:41.203687
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(
        files=1,
        time=0.1,
        target=(3, 6),
        dependencies=['0.py', '1.py']
    )
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 6)
    assert result.dependencies == ['0.py', '1.py']


# Generated at 2022-06-25 23:04:47.029473
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(1, 2.0, (3, 4), ['a', 'b'])
    assert res.files == 1
    assert res.time == 2.0
    assert res.target == (3, 4)
    assert res.dependencies == ['a', 'b']


# Generated at 2022-06-25 23:04:52.502970
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/dev/null')
    output = Path('/dev/random')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-25 23:04:55.594309
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(None, None, None)
    assert(tr.tree is None)
    assert(tr.tree_changed is None)
    assert(tr.dependencies is None)

# Constructor for class TransformationResult

# Generated at 2022-06-25 23:05:00.784914
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(
        tree=ast.parse('def foo(): pass'),
        tree_changed=True,
        dependencies=['foo'])
    assert result.tree_changed
    assert [node.name for node in ast.walk(result.tree)] == ['foo']
    assert result.dependencies == ['foo']

# Generated at 2022-06-25 23:05:07.730624
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Arrange
    files = 1
    time = 5.5
    target = (3, 2)
    dependencies = ['file1', 'file2']

    # Act
    result = CompilationResult(files, time, target, dependencies)

    # Assert
    assert result.files == files
    assert result.time == time
    assert result.target == target
    assert result.dependencies == dependencies


# Generated at 2022-06-25 23:05:09.745079
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(0, 0, (3, 5), [])


# Generated at 2022-06-25 23:05:13.350021
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(ast.Annotation(None, None, None),
                                  True, [])
    assert result.tree_changed is True
    assert result.tree.value is None
    assert result.dependencies == []

# Generated at 2022-06-25 23:05:14.850769
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2, (2, 3), ['a', 'b'])


# Generated at 2022-06-25 23:05:19.142695
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('tests/test_data/input.txt')
    output = Path('tests/test_data/output.txt')
    input_output = InputOutput(input_, output)

    assert input_output.input == input_
    assert input_output.output == output


# Generated at 2022-06-25 23:05:22.314500
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 2')
    res = TransformationResult(tree, True, ['test'])
    assert res.tree == tree
    assert res.tree_changed == True
    assert res.dependencies == ['test']

# Generated at 2022-06-25 23:05:28.035705
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    # Arrange
    # Act
    actual = TransformationResult(ast.Name(), True, [])  # type: TransformationResult
    # Assert
    # noinspection PyTypeChecker
    assert actual.tree is not None
    assert isinstance(actual, TransformationResult)
    assert actual.tree_changed is True
    assert len(actual.dependencies) == 0

# Generated at 2022-06-25 23:05:35.047764
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    a = TransformationResult(tree=None, tree_changed=False, dependencies=[])
    assert a.tree is None
    assert not a.tree_changed
    assert a.dependencies == []



# Generated at 2022-06-25 23:05:36.702291
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    r = TransformationResult(None, True, None)
    t: TransformationResult = r
    assert t == r

# Generated at 2022-06-25 23:05:38.706389
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('x')
    TransformationResult(t, True, [])
    TransformationResult(t, False, ['a.py'])

# Generated at 2022-06-25 23:05:41.159129
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input.py')
    output = Path('/tmp/output.py')

    result = InputOutput(input, output)

    assert result.input == input
    assert result.output == output

# Generated at 2022-06-25 23:05:46.096020
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('', '', 'exec')
    res = TransformationResult(tree, True, ['a', 'b'])
    assert res.tree is tree
    assert res.tree_changed is True
    assert res.dependencies == ['a', 'b']

# Generated at 2022-06-25 23:05:47.572892
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    a = ast.parse('a')
    t = TransformationResult(a, True, [])
    assert all(t)
    assert len(t) == 3

# Generated at 2022-06-25 23:05:49.339635
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(10, 1.2, (2, 7), ['a', 'b'])
    assert result.files == 10
    assert result.time == 1.2
    assert result.target == (2, 7)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-25 23:05:51.218099
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2.0, (3, 4), [])


# Generated at 2022-06-25 23:05:52.800301
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(1, 2.0, (3, 4), ['foo', 'bar'])
  

# Generated at 2022-06-25 23:05:58.155300
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert (TransformationResult(tree=None,
                                 tree_changed=False,
                                 dependencies=[]).tree is None and
            TransformationResult(tree=None,
                                 tree_changed=False,
                                 dependencies=[]).tree_changed is False and
            TransformationResult(tree=None,
                                 tree_changed=False,
                                 dependencies=[]).dependencies == [])

# Generated at 2022-06-25 23:06:08.333322
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(0, 0.0, (3, 5), [])


# Generated at 2022-06-25 23:06:09.488165
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(Path('temp'), Path('tmp'))



# Generated at 2022-06-25 23:06:10.173623
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(0, 0, (0, 0), [])


# Generated at 2022-06-25 23:06:14.235634
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, None, None)

# Result of debug pipeline
DebugResult = NamedTuple('DebugResult',
                         [('input_output', InputOutput),
                          ('target', CompilationTarget),
                          ('message', str),
                          ('error', str),
                          ('warnings', List[str])])


# Generated at 2022-06-25 23:06:15.185662
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    _ = TransformationResult(None, None, None)

# Generated at 2022-06-25 23:06:18.247030
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('1 + 2')
    tree_changed = True
    dependencies = ['a', 'b']
    tr = TransformationResult(tree, tree_changed, dependencies)
    assert tr.tree == tree
    assert tr.tree_changed == tree_changed
    assert tr.dependencies == dependencies

# Generated at 2022-06-25 23:06:19.895175
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2.0, (3, 4), [])

# Generated at 2022-06-25 23:06:22.593632
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Given
    input_ = Path('input')
    out = Path('output')

    # When
    pair = InputOutput(input_, out)

    # Then
    assert pair.input == input_
    assert pair.output == out


# Generated at 2022-06-25 23:06:25.548989
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(ast.parse('x=1'), True, [])
    assert result.tree
    assert result.tree_changed == True
    assert result.dependencies == []

# Generated at 2022-06-25 23:06:31.954421
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(
        ast.Module([]),
        True,
        [])

    assert isinstance(tr.tree, ast.AST)
    assert isinstance(tr.tree_changed, bool)
    assert isinstance(tr.dependencies, list)


# Result of parsing
ParseResult = NamedTuple('ParseResult',
                         [('tree', ast.AST),
                          ('dependencies', List[str])])

# Result of parsing of a file
FileParseResult = NamedTuple("FileParseResult",
                             [("filename", Path),
                              ("parse_result", ParseResult)])


# Generated at 2022-06-25 23:06:51.960410
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.AST()
    dependencies = list()
    t = TransformationResult(tree=tree, tree_changed=True,
                             dependencies=dependencies)
    assert t.tree is tree
    assert t.tree_changed is True
    assert t.dependencies is dependencies

# Generated at 2022-06-25 23:06:53.179697
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(
        tree=ast.parse(''), tree_changed=True, dependencies=[])

# Generated at 2022-06-25 23:06:57.520921
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    x = TransformationResult(ast.AST(), False, [])
    assert isinstance(x, TransformationResult)

# Result of compiling a single file
CompilationUnitResult = NamedTuple('CompilationUnitResult',
                                   [('input_filename', str),
                                    ('output_filename', str),
                                    ('tree_changed', bool),
                                    ('filesize_difference', int)])


# Generated at 2022-06-25 23:07:01.292504
# Unit test for constructor of class InputOutput
def test_InputOutput():
    file_a = Path('/tmp/file-a')
    file_b = Path('/tmp/file-b')
    io = InputOutput(input=file_a, output=file_b)
    assert io.input == file_a
    assert io.output == file_b
    assert io.input != io.output


# Generated at 2022-06-25 23:07:06.042919
# Unit test for constructor of class CompilationResult
def test_CompilationResult(): # type: () -> None
    result = CompilationResult(files=2, time=2.0, target=(2, 2), dependencies=['test1', 'test2'])
    assert result.files == 2
    assert result.time == 2.0
    assert result.target == (2, 2)
    assert result.dependencies == ['test1', 'test2']


# Generated at 2022-06-25 23:07:07.549815
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(0, 0, (3, 7), [])
    assert cr is not None


# Generated at 2022-06-25 23:07:11.169224
# Unit test for constructor of class TransformationResult
def test_TransformationResult(): # type: () -> None
    tree = ast.parse('''
    def f():
        pass
    ''')
    res = TransformationResult(tree, True, [])
    assert len(res) == 3
    assert res.tree == tree
    assert res.tree_changed is True
    assert res.dependencies == []

# Generated at 2022-06-25 23:07:14.701323
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=0.123,
                               target=(2, 7),
                               dependencies=['foo', 'bar'])

    assert result.files == 1
    assert result.time == 0.123
    assert result.target == (2, 7)
    assert result.dependencies == ['foo', 'bar']



# Generated at 2022-06-25 23:07:16.869880
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('input'), Path('output'))
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')


# Generated at 2022-06-25 23:07:19.144345
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i1 = Path('/a/b')
    o1 = Path('/c/d')
    io1 = InputOutput(i1, o1)
    assert i1 == io1.input
    assert o1 == io1.output

# Generated at 2022-06-25 23:07:56.451716
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(tree=None,
                         tree_changed=False,
                         dependencies=[])

# Generated at 2022-06-25 23:08:01.506998
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=10, time=123.0,
                                           target=(3, 5),
                                           dependencies=['d1', 'd2', 'd3'])
    assert compilation_result.files == 10
    assert compilation_result.time == 123.0
    assert compilation_result.target == (3, 5)
    assert compilation_result.dependencies == ['d1', 'd2', 'd3']


# Generated at 2022-06-25 23:08:02.537626
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(10, 123.456, (3, 2), [])



# Generated at 2022-06-25 23:08:05.086203
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 1, (2, 3), [])
    assert not CompilationResult(1, 1, (2, 3), []) == \
           CompilationResult(1, 1, (2, 2), [])


# Generated at 2022-06-25 23:08:07.299578
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse('pass'), False, []) == TransformationResult(tree=ast.parse('pass'),
                                                                                       tree_changed=False,
                                                                                       dependencies=[])



# Generated at 2022-06-25 23:08:09.541436
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(0, 0, (3, 6), [])
    assert result.files == 0
    assert result.time == 0
    assert result.target == (3, 6)
    assert result.dependencies == []


# Generated at 2022-06-25 23:08:15.754244
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    try:
        CompilationResult(1, 2.0, (3, 4), ['a', 'b'])
        assert False
    except TypeError:
        assert True
    res = CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=['a', 'b'])
    assert res.files == 1
    assert res.time == 2.0
    assert res.target[0] == 3
    assert res.target[1] == 4
    assert len(res.dependencies) == 2
    assert res.dependencies[0] == 'a'
    assert res.dependencies[1] == 'b'


# Generated at 2022-06-25 23:08:18.159332
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.parse(""), True, [])
    assert tr.tree_changed == True
    assert tr.dependencies == []

# Generated at 2022-06-25 23:08:19.494870
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('a/b.c')
    output = Path('c/b.d')
    pair = Inp

# Generated at 2022-06-25 23:08:24.079039
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(2, 3.0, (3, 5), [])
    assert result.files == 2
    assert result.time == 3.0
    assert result.target == (3, 5)
    assert result.dependencies == []



# Generated at 2022-06-25 23:09:56.008268
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('x')
    o = Path('y')
    io = InputOutput(i, o)
    assert io.input == i
    assert io.output == o


# Generated at 2022-06-25 23:10:03.950527
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, None, None).tree is None
    assert TransformationResult(None, None, None).tree_changed is None
    assert TransformationResult(None, None, None).dependencies is None

    assert TransformationResult(ast.Module([]), True, None).tree == ast.Module([])
    assert TransformationResult(ast.Module([]), True, None).tree_changed is True
    assert TransformationResult(ast.Module([]), True, None).dependencies is None

    assert TransformationResult(ast.Module([]), True, ['file.py']).tree == ast.Module([])
    assert TransformationResult(ast.Module([]), True, ['file.py']).tree_changed is True
    assert TransformationResult(ast.Module([]), True, ['file.py']).dependencies == ['file.py']



# Generated at 2022-06-25 23:10:05.586555
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    _ = CompilationResult(files=1, time=1, target=(4, 7), dependencies=['A', 'B'])


# Generated at 2022-06-25 23:10:08.084908
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=1.0, target=(3, 7), dependencies=['a'])
    assert cr.files == 1
    assert cr.time == 1.0
    assert cr.target == (3, 7)
    assert cr.dependencies == ['a']


# Generated at 2022-06-25 23:10:09.135018
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(0, 0.0, (3, 5), [])


# Generated at 2022-06-25 23:10:12.406440
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1,
                           time=2,
                           target=(3, 4),
                           dependencies=[])
    assert isinstance(cr, CompilationResult)
    assert cr.files == 1
    assert cr.time == 2
    assert cr.target == (3, 4)
    assert cr.dependencies == []



# Generated at 2022-06-25 23:10:16.107904
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=10,
                               time=1.1,
                               target=(3, 4),
                               dependencies=['foo', 'bar'])
    assert result.files == 10
    assert result.time == 1.1
    assert result.target == (3, 4)
    assert result.dependencies == ['foo', 'bar']



# Generated at 2022-06-25 23:10:18.196366
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = InputOutput(Path('foo.py'), Path('bar.py'))
    assert inp.input == Path('foo.py')
    assert inp.output == Path('bar.py')

# Generated at 2022-06-25 23:10:20.750473
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a'), Path('b')) == InputOutput('a', 'b')
    assert InputOutput(None, Path('b')) == InputOutput(None, 'b')
    assert InputOutput(Path('a'), None) != InputOutput('a', 'b')

# Generated at 2022-06-25 23:10:23.603563
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.0,
                               target=(3, 7), dependencies=['foo'])
    assert result.files == 1
    assert result.time == 0.0
    assert result.target == (3, 7)
    assert result.dependencies == ['foo']
