

# Generated at 2022-06-25 23:03:36.172865
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()

# Generated at 2022-06-25 23:03:37.736134
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()
    assert isinstance(input_output_0, InputOutput)


# Generated at 2022-06-25 23:03:39.877065
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 2.7, (3, 4), ["a", "b"]) is not None


# Generated at 2022-06-25 23:03:42.815873
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 3.1415, (3, 7), ['a', 'b', 'c']) == CompilationResult(1, 3.1415, (3, 7), ['a', 'b', 'c'])


# Generated at 2022-06-25 23:03:51.377562
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Check that field tree is assignable
    input_output_0 = InputOutput()
    input_output_0.tree = ast.AST()
    # Check that field tree_changed is assignable
    input_output_1 = InputOutput()
    input_output_1.tree_changed = True
    # Check that field dependencies is assignable
    input_output_2 = InputOutput()
    input_output_2.dependencies.append("")
    # Make sure that we can construct an instance of this class
    input_output_3 = InputOutput(tree=input_output_0.tree,
                                 tree_changed=input_output_1.tree_changed,
                                 dependencies=input_output_2.dependencies)


# Generated at 2022-06-25 23:03:54.774826
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result_0 = CompilationResult(files=1, time=2, target=(3, 4), dependencies=[])
    assert result_0.files == 1
    assert result_0.time == 2
    assert result_0.target == (3, 4)
    assert result_0.dependencies == []


# Generated at 2022-06-25 23:03:56.906088
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=ast.parse("pass"), tree_changed=True, dependencies=["test"]).tree == ast.parse("pass")


# Generated at 2022-06-25 23:04:02.263517
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()
    # Testing attribute "input"
    try:
        input_output_0.input = "I1zf|"
        assert False
    except AttributeError:
        pass
    # Testing attribute "output"
    try:
        input_output_0.output = "5Z5>#w^"
        assert False
    except AttributeError:
        pass


# Generated at 2022-06-25 23:04:10.879237
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result_0 = CompilationResult()
    assert result_0.files == 0
    assert result_0.time == 0.0
    assert result_0.target[0] == 3
    assert result_0.target[1] == 8
    assert result_0.dependencies == []
    files_val = 7
    time_val = 10.0
    target_val = CompilationTarget(3, 8)
    dependencies_val = ['ABC', 'XYZ']
    result_1 = CompilationResult(files=files_val,
                                 time=time_val,
                                 target=target_val,
                                 dependencies=dependencies_val)
    assert result_1.files == files_val
    assert result_1.time == time_val
    assert result_1.target[0] == target_val[0]
   

# Generated at 2022-06-25 23:04:15.075808
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(ast.Module(), False, ["dependency1", "dependency2"])
    # Check if the class fields were correctly instantiated
    assert result.tree == ast.Module()
    assert result.tree_changed == False
    assert result.dependencies == ["dependency1", "dependency2"]



# Generated at 2022-06-25 23:04:20.919101
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # InputOutput
    input_output_0 : CompilationResult
    assert isinstance(input_output_0, CompilationResult)
    # InputOutput
    input_output_1 : CompilationResult
    assert isinstance(input_output_1, CompilationResult)


# Generated at 2022-06-25 23:04:26.266226
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_0 = CompilationResult(files=1, time=10.0,
                                      target=(3, 6),
                                      dependencies=['a', 'b', 'c'])
    assert compilation_0.files == 1
    assert compilation_0.time == 10.0
    assert compilation_0.target == (3, 6)
    assert compilation_0.dependencies == ['a', 'b', 'c']


# Generated at 2022-06-25 23:04:28.141681
# Unit test for constructor of class InputOutput
def test_InputOutput():
    global input_output_0
    input_output_0 = InputOutput()
    assert isinstance(input_output_0, InputOutput)



# Generated at 2022-06-25 23:04:30.555370
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    print('test_TransformationResult...')
    input_output_0 = InputOutput()
    transformation_result = TransformationResult(input_output_0.input, input_output_0.output)


# Generated at 2022-06-25 23:04:33.718893
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(None, None, None)
    assert isinstance(t.tree, ast.AST) or t.tree is None
    assert isinstance(t.tree_changed, bool) or t.tree_changed is None
    assert isinstance(t.dependencies, list) or t.dependencies is None
    


# Generated at 2022-06-25 23:04:35.765484
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()
    assert input_output_0.input == None
    assert input_output_0.output == None


# Generated at 2022-06-25 23:04:40.881606
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    input_output_0 = test_case_0()
    if isinstance(input_output_0, InputOutput):
        ast_0 = ast.AST()
        tree_changed_0 = False
        dependencies_0 = []
        transformation_result_0 = (
            TransformationResult(ast_0, tree_changed_0, dependencies_0))


# Generated at 2022-06-25 23:04:50.631908
# Unit test for constructor of class InputOutput
def test_InputOutput():
# Test 1: Try to create InputOutput with untyped input, expect exception
    try:
        input_output_1 = InputOutput(1, "output")
    except TypeError as e:
        assert("InputOutput" in e.message)

# Test 2: Try to create InputOutput with untyped output, expect exception
    try:
        input_output_2 = InputOutput("input", 1)
    except TypeError as e:
        assert("InputOutput" in e.message)

# Test 3: Try to create InputOutput with untyped input and output, expect exception
    try:
        input_output_3 = InputOutput(1, 1)
    except TypeError as e:
        assert("InputOutput" in e.message)

# Test 4: Try to create InputOutput with no input and output, expect exception

# Generated at 2022-06-25 23:04:55.591037
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(
        files=1,
        time=0.1,
        target=(3, 6),
        dependencies=['a.py'])
    assert compilation_result.files == 1
    assert compilation_result.time == 0.1
    assert compilation_result.target == (3, 6)
    assert compilation_result.dependencies == ['a.py']



# Generated at 2022-06-25 23:04:59.433274
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()
    assert input_output_0.input == None
    assert input_output_0.output == None


# Generated at 2022-06-25 23:05:05.068160
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(None, None, None)


# Generated at 2022-06-25 23:05:08.154953
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert(InputOutput())


# Generated at 2022-06-25 23:05:14.663959
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 1
    time = 3.5
    target = (3, 0)
    dependencies = ["stdlib", "otherdependency"]
    result = CompilationResult(files, time, target, dependencies)
    assert isinstance(result.files, int)
    assert isinstance(result.time, float)
    assert isinstance(result.target, CompilationTarget)
    assert isinstance(result.dependencies, list)


# Generated at 2022-06-25 23:05:17.418327
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()
    assert input_output_0.input is None
    assert input_output_0.output is None


# Generated at 2022-06-25 23:05:18.796749
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert_instance_of(InputOutput)


# Generated at 2022-06-25 23:05:23.825352
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    print(
        'Testing constructor for module test_data.transformation_result.',
        'test_TransformationResult')
    tree = ast.Module()
    tree = ast.AST()
    tree_changed = True
    dependencies = []
    transformation_result = TransformationResult(tree, tree_changed,
                                                 dependencies)
    assert transformation_result.tree == tree
    assert transformation_result.tree_changed == tree_changed
    assert transformation_result.dependencies == dependencies


# Generated at 2022-06-25 23:05:30.690751
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert (TransformationResult(tree=None, tree_changed=True, dependencies=None) ==
            TransformationResult(tree=None, tree_changed=True, dependencies=None))
    assert (TransformationResult(tree=None, tree_changed=True, dependencies=None) !=
            TransformationResult(tree=None, tree_changed=False, dependencies=None))
    assert (TransformationResult(tree=None, tree_changed=True, dependencies=None) !=
            TransformationResult(tree=ast.AST(), tree_changed=True, dependencies=None))



# Generated at 2022-06-25 23:05:34.672470
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()
    assert isinstance(input_output_0.input, Path)
    assert input_output_0.input == None

    assert isinstance(input_output_0.output, Path)
    assert input_output_0.output == None


# Generated at 2022-06-25 23:05:45.145629
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    input_output_0 = InputOutput()
    input_output_0 = InputOutput(
        input=Path('/Users/einarvalgardsson/Projects/Pythran/tests/orgtests/test_union_of_typed_collections.py'),
        output=Path('/Users/einarvalgardsson/Projects/Pythran/tests/orgtests/test_union_of_typed_collections.py'))
    input_output_0.input = Path('/Users/einarvalgardsson/Projects/Pythran/tests/orgtests/test_union_of_typed_collections.py')
    input_output_0.output = Path('/Users/einarvalgardsson/Projects/Pythran/tests/orgtests/test_union_of_typed_collections.py')


# Generated at 2022-06-25 23:05:50.948396
# Unit test for constructor of class InputOutput
def test_InputOutput():
    try:
        test_case_0()
    except Exception as e:
        assert str(e) == "__new__() missing 2 required positional arguments: 'input' and 'output'"


# Generated at 2022-06-25 23:05:57.121262
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cc = CompilationResult(files=1, time=0.1, target=(3, 8), dependencies=[])



# Generated at 2022-06-25 23:05:58.479114
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Some tests
    assert InputOutput() == InputOutput(input=None, output=None)



# Generated at 2022-06-25 23:05:59.920879
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(1, 1.1, (1, 1), [])



# Generated at 2022-06-25 23:06:08.753617
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()
    assert input_output_0.input is None
    assert input_output_0.output is None
    input_output_1 = InputOutput(input='filename.txt', output='filename.txt')
    assert input_output_1.input == 'filename.txt'
    assert input_output_1.output == 'filename.txt'
    input_output_2 = InputOutput(input=None, output='filename.txt')
    assert input_output_2.input is None
    assert input_output_2.output == 'filename.txt'
    input_output_3 = InputOutput(input='filename.txt', output=None)
    assert input_output_3.input == 'filename.txt'
    assert input_output_3.output is None


# Generated at 2022-06-25 23:06:11.055130
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    actual = TransformationResult(ast.AST(), True, [])
    assert actual.tree == ast.AST()
    assert actual.tree_changed
    assert actual.dependencies == []



# Generated at 2022-06-25 23:06:15.623292
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    expected_0 = TransformationResult(tree=[], tree_changed=True, dependencies=["dependency_0", "dependency_1", "dependency_2"])
    actual_0 = TransformationResult(tree=[], tree_changed=True, dependencies=["dependency_0", "dependency_1", "dependency_2"])
    assert expected_0 == actual_0



# Generated at 2022-06-25 23:06:19.682639
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=2, time=23.6, target=(3, 6), dependencies=['foo', 'bar', 'baz'])
    assert c.files == 2
    assert c.time == 23.6
    assert c.target == (3, 6)
    assert c.dependencies == ['foo', 'bar', 'baz']


# Generated at 2022-06-25 23:06:23.030248
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Default constructor
    try:
        input_output_0 = InputOutput()
    except TypeError:
        print('Failed to create InputOutput: no input/output')

    # input/output constructor
    input_output_0 = InputOutput(Path('input.py'), Path('output.py'))


# Generated at 2022-06-25 23:06:26.254600
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(0,0.0,(3,4),[]) == CompilationResult(0,0.0,(3,4),[])


# Generated at 2022-06-25 23:06:31.097770
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    param_0 = ast.parse('2**5').body[0]
    param_1 = True
    param_2 = ['file_0.py']
    obj_0 = TransformationResult(param_0, param_1, param_2)
    output = (obj_0.tree, obj_0.tree_changed, obj_0.dependencies)
    expected = (param_0, param_1, param_2)
    assert output == expected


# Generated at 2022-06-25 23:06:42.774130
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput(Path(''), Path(''))
    assert input_output_0.input == Path('')
    assert input_output_0.output == Path('')


# Generated at 2022-06-25 23:06:43.890814
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Test of default constructor
    test_case_0()


# Generated at 2022-06-25 23:06:46.156532
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()
    input_output_1 = InputOutput(input=Path, output=Path)


# Generated at 2022-06-25 23:06:47.731434
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    try:
        result_0 = TransformationResult()
    except Exception:
        pass


# Generated at 2022-06-25 23:06:49.730448
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()
    assert input_output_0.input == None
    assert input_output_0.output == None


# Generated at 2022-06-25 23:06:50.282557
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult()


# Generated at 2022-06-25 23:06:50.816563
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert test_case_0() is None

# Generated at 2022-06-25 23:06:58.672892
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Create empty instance of TransformationResult
    empty_instance_of_TransformationResult = TransformationResult()
    # Create instance of TransformationResult with fields tree and tree_changed
    instance_of_TransformationResult_tree_tree_changed = TransformationResult(tree=empty_instance_of_TransformationResult.tree, tree_changed=empty_instance_of_TransformationResult.tree_changed)
    # Create instance of TransformationResult with fields tree and dependencies
    instance_of_TransformationResult_tree_dependencies = TransformationResult(tree=empty_instance_of_TransformationResult.tree, dependencies=empty_instance_of_TransformationResult.dependencies)
    # Create instance of TransformationResult with fields tree_changed and dependencies

# Generated at 2022-06-25 23:07:00.443927
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=0,
                               time=0,
                               target=(0, 0),
                               dependencies=[])



# Generated at 2022-06-25 23:07:09.445889
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result_0 = TransformationResult(None, None, None)
    result_1 = TransformationResult(None, None, [])
    result_2 = TransformationResult(None, None, ['a', 'b'])
    assert result_0.tree == None
    assert result_0.tree_changed == None
    assert result_0.dependencies == None
    assert result_1.tree == None
    assert result_1.tree_changed == None
    assert result_1.dependencies == []
    assert result_2.tree == None
    assert result_2.tree_changed == None
    assert result_2.dependencies == ['a', 'b']


# Generated at 2022-06-25 23:07:22.199565
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult.__doc__ is not None

# Generated at 2022-06-25 23:07:23.717519
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.AST(), True, [])


# Test suite for class TransformationResult

# Generated at 2022-06-25 23:07:29.190009
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput(Path('/path/to/my/file.py'), Path('file.py'))
    assert input_output_0.input == Path('/path/to/my/file.py')
    assert input_output_0.output == Path('file.py')


# Generated at 2022-06-25 23:07:38.214446
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    input_output_1 = InputOutput()
    input_output_2 = InputOutput()
    input_output_3 = InputOutput()

    # assert TransformationResult(input_output_0.tree, input_output_0.tree_changed, input_output_0.dependencies) is not None
    # assert TransformationResult(input_output_1.tree, input_output_1.tree_changed, input_output_1.dependencies) is not None
    # assert TransformationResult(input_output_2.tree, input_output_2.tree_changed, input_output_2.dependencies) is not None
    # assert TransformationResult(input_output_3.tree, input_output_3.tree_changed, input_output_3.dependencies) is not None

    # The line below is skipped because TransformationResult does not have an attribute 'tree'.

# Generated at 2022-06-25 23:07:39.612797
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult()


# Generated at 2022-06-25 23:07:46.671235
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.AST()
    tree_changed = 1
    dependencies = ['x']
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree, 'incorrect tree'
    assert result.tree_changed == tree_changed, 'incorrect tree_changed'
    assert result.dependencies == dependencies, 'incorrect dependencies'


# Generated at 2022-06-25 23:07:47.961123
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_1 = InputOutput()


# Generated at 2022-06-25 23:07:48.791688
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    input_output_0 = InputOutput()

# Generated at 2022-06-25 23:07:51.216361
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_0 = InputOutput()
    assert input_output_0.__fields__ == ('input', 'output')
    assert input_output_0.input is None
    assert input_output_0.output is None


# Generated at 2022-06-25 23:08:00.179095
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(files=1, time=1.0, target=(3, 8), dependencies=['test'])
    assert (compilation_result_0.files == 1)
    assert (compilation_result_0.time == 1.0)
    assert (compilation_result_0.target == (3, 8))
    assert (compilation_result_0.dependencies == ['test'])

    # Test for updating of objects of class CompilationResult
    compilation_result_0 = CompilationResult(files=2, time=2.0, target=(2, 7), dependencies=['test2'])
    assert (compilation_result_0.files == 2)
    assert (compilation_result_0.time == 2.0)
    assert (compilation_result_0.target == (2, 7))

# Generated at 2022-06-25 23:08:18.270429
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # pylint: disable=line-too-long
    TransformationResult(
        tree = ast.Module(body = []),
        tree_changed = False,
        dependencies = []
    )
    # pylint: enable=line-too-long

# A single source file
Source = Path

# A single dependency
Dependency = Path

# A list of source files
Sources = List[Source]

# A list of dependencies
Dependencies = List[Dependency]

# A list of source files and a list of dependencies
DependencyMap = List[Tuple[Sources, Dependencies]]

# A Python AST
PythonAST = ast.AST

# A source file containing a Python AST
PythonSourceFile = Tuple[Source, PythonAST]


# Generated at 2022-06-25 23:08:20.338694
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = InputOutput(input=Path('input'), output=Path('output'))
    assert i.input == Path('input') and i.output == Path('output')

# Generated at 2022-06-25 23:08:25.010921
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('a'), Path('b'))
    assert input_output.input == Path('a')
    assert input_output.output == Path('b')
    assert str(input_output.input) == 'a'


# Generated at 2022-06-25 23:08:27.124299
# Unit test for constructor of class InputOutput
def test_InputOutput():
    result = InputOutput(Path('input.txt'), Path('output.txt'))
    assert result.input == Path('input.txt')
    assert result.output == Path('output.txt')

# Generated at 2022-06-25 23:08:29.222257
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=2,
                      time=1.1,
                      target=(3, 6),
                      dependencies=['File1.py', 'File2.py'])

# Generated at 2022-06-25 23:08:31.781295
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from test.test_utils import _transformed_nodes
    tree = ast.parse('x = 1')
    ret = TransformationResult(tree, True, ['x', 'y'])
    assert ret.tree == tree
    assert ret.tree_changed
    assert ret.dependencies == ['x', 'y']

# Generated at 2022-06-25 23:08:33.145831
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files = 1,
                      time = 1.0,
                      target = (3, 6),
                      dependencies = ['foo'])

# Generated at 2022-06-25 23:08:35.455937
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(tree=None, tree_changed=False, dependencies=[])
    assert result.tree is None
    assert not result.tree_changed
    assert len(result.dependencies) == 0



# Generated at 2022-06-25 23:08:40.242119
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('test.py'), Path('test.py'))
    assert input_output.input.as_posix() == 'test.py'
    assert input_output.output.as_posix() == 'test.py'

    input_output = InputOutput('test.py', 'test.py')
    assert input_output.input.as_posix() == 'test.py'
    assert input_output.output.as_posix() == 'test.py'

# Generated at 2022-06-25 23:08:43.665061
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(1,
                          1.5,
                          (3, 6),
                          ['one', 'two'])
    assert c.files == 1
    assert c.time == 1.5
    assert c.target == (3, 6)
    assert c.dependencies == ['one', 'two']


# Generated at 2022-06-25 23:09:11.486601
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=2, time=9, target=(3, 5),
                               dependencies=['foo', 'bar'])
    assert isinstance(result, CompilationResult)
    assert isinstance(result.files, int)
    assert isinstance(result.time, float)
    assert isinstance(result.target, CompilationTarget)
    assert isinstance(result.dependencies, list)


# Generated at 2022-06-25 23:09:13.623611
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('test/test_file.in')
    out = Path('test/test_file.out')
    assert InputOutput(inp, out) == InputOutput(inp, out)



# Generated at 2022-06-25 23:09:18.146229
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.Name(id='foo', ctx=ast.Load(), lineno=1, col_offset=2)
    assert TransformationResult(tree=tree,
                                tree_changed=False,
                                dependencies=[]).dependencies == []
    assert TransformationResult(tree=tree,
                                tree_changed=True,
                                dependencies=['foo.py']).dependencies == ['foo.py']

# Generated at 2022-06-25 23:09:20.584556
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 0')
    res = TransformationResult(tree, False, ['b.py'])
    assert res.tree is tree
    assert res.tree_changed is False
    assert res.dependencies == ['b.py']

# Generated at 2022-06-25 23:09:23.456786
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input')
    output = Path('/tmp/output')
    input_output = InputOutput(input, output)

    assert input_output.input.absolute() == input.absolute()
    assert input_output.output.absolute() == output.absolute()

# Generated at 2022-06-25 23:09:25.664639
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=10, time=42.0,
                      target=(3, 7),
                      dependencies=['foo', 'bar'])


# Generated at 2022-06-25 23:09:27.739352
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('input'), Path('output'))
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')


# Generated at 2022-06-25 23:09:29.415693
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=10, time=0.1, target=(3, 5), dependencies=['x1'])

# Generated at 2022-06-25 23:09:31.133498
# Unit test for constructor of class InputOutput
def test_InputOutput():
    iop = InputOutput(input=Path('foo'), output=Path('bar'))
    assert iop.input == Path('foo')
    assert iop.output == Path('bar')

# Generated at 2022-06-25 23:09:33.050695
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input, output = "foo.py", "bar.py"
    io = InputOutput(input, output)
    assert str(io.input) == input
    assert str(io.output) == output


# Generated at 2022-06-25 23:10:30.399094
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = InputOutput(input=Path('input.txt'), output=Path('output.txt'))
    assert i.input == Path('input.txt')
    assert i.output == Path('output.txt')
    assert i == InputOutput(input=Path('input.txt'), output=Path('output.txt'))
    assert i != InputOutput(input=Path('input.txt'), output=Path('input.txt'))

# Generated at 2022-06-25 23:10:32.677557
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 1.5, (2, 7), ['foo', 'bar'])
    assert result.files == 1
    assert result.time == 1.5
    assert result.target == (2, 7)
    assert result.dependencies == ['foo', 'bar']


# Generated at 2022-06-25 23:10:33.610234
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2, (3, 4), [])

# Generated at 2022-06-25 23:10:34.265114
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('input'), Path('output'))

# Generated at 2022-06-25 23:10:35.903489
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    try:
        TransformationResult(tree=None, tree_changed=False, dependencies=[])
    except TypeError:
        raise AssertionError("Failed to create instance of TransformationResult")


# Generated at 2022-06-25 23:10:37.678094
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(1, 2, (3, 4), [])
    assert c.files == 1
    assert c.time == 2
    assert c.target == (3, 4)
    assert c.dependencies == []


# Generated at 2022-06-25 23:10:39.505004
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files = 10, time = 0.1,
                            target = (3, 6), dependencies = [])

    assert res.files == 10
    assert res.time == 0.1
    assert res.target == (3, 6)
    assert res.dependencies == []


# Generated at 2022-06-25 23:10:42.491970
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = InputOutput(input=Path('a/b/c.txt'), output=Path('a/b/c.py'))
    assert a.input == Path('a/b/c.txt')
    assert a.output == Path('a/b/c.py')


# Generated at 2022-06-25 23:10:49.364390
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('input')
    out = Path('output')

    assert inp == InputOutput(input=inp, output=out).input
    assert out == InputOutput(input=inp, output=out).output

# Generated at 2022-06-25 23:10:51.422219
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(
        ast.parse('1 + 1'),
        False,
        []
    )

# Type of function that implements custom transformer
Transformer = Callable[[ast.AST], TransformationResult]


# Generated at 2022-06-25 23:12:43.428737
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('/tmp/test.py'), Path('/tmp/test.py.cached'))
    should_be = InputOutput(Path('/tmp/test.py'), Path('/tmp/test.py.cached'))
    assert input_output == should_be

# Unit tests for constructor of class TransformationResult

# Generated at 2022-06-25 23:12:46.831187
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # type: () -> None
    cr = CompilationResult(files=1, time=1.1, target=(2, 7), dependencies=[])
    assert cr.files == 1
    assert cr.time == 1.1
    assert cr.target == (2, 7)
    assert cr.dependencies == []
    assert cr._asdict() == {'files': 1, 'time': 1.1, 'target': (2, 7), 'dependencies': []}


# Generated at 2022-06-25 23:12:49.606493
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = "/path/to/test.c"
    output_path = "/path/to/test.py"
    io = InputOutput(input_path, output_path)
    assert io.input == input_path
    assert io.output == output_path


# Generated at 2022-06-25 23:12:52.002520
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(1, 1.5, (3, 4), ['a'])
    assert cr == CompilationResult(1, 1.5, (3, 4), ['a'])
    assert cr != CompilationResult(1, 1.5, (3, 4), ['b'])


# Generated at 2022-06-25 23:12:55.625265
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=2, time=10.1, target=(3, 7), dependencies=['a.py'])
    assert result.files == 2
    assert result.time == 10.1
    assert result.target == (3, 7)
    assert result.dependencies == ['a.py']

# Generated at 2022-06-25 23:12:56.903798
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(10, 0.1, (3, 5), [])
    assert CompilationResult(10, 0.1, (3, 5), ["./my_mod.py"])
    

# Generated at 2022-06-25 23:12:58.937539
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(
        files=3,
        time=2.5,
        target=(3, 5),
        dependencies=['foo', 'bar'])
    assert cr.files == 3
    assert cr.time == 2.5
    assert cr.target == (3, 5)
    assert cr.dependencies == ['foo', 'bar']


# Generated at 2022-06-25 23:13:00.359252
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('in.py'), Path('out.py'))
    assert input_output.input.name == 'in.py'
    assert input_output.output.name == 'out.py'

# Generated at 2022-06-25 23:13:02.310989
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('foo')
    outp = Path('bar')
    io = InputOutput(inp, outp)

    assert inp == io.input
    assert outp == io.output
    assert io != Path('foo')
    assert io != Path('bar')


# Generated at 2022-06-25 23:13:05.611563
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('2 + 3')
    tree_changed = True
    dependencies = ['a.py', 'b.py']
    res = TransformationResult(tree=tree,
                               tree_changed=tree_changed,
                               dependencies=dependencies)
    assert res.tree is tree
    assert res.tree_changed is tree_changed
    assert res.dependencies == dependencies

