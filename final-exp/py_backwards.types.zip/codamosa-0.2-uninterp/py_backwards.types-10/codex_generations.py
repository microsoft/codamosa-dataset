

# Generated at 2022-06-18 00:52:24.382188
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('/tmp/input'), Path('/tmp/output'))
    assert input_output.input == Path('/tmp/input')
    assert input_output.output == Path('/tmp/output')

# Generated at 2022-06-18 00:52:28.664266
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1, target=(3, 5), dependencies=[])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 5)
    assert result.dependencies == []


# Generated at 2022-06-18 00:52:33.100621
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1, target=(3, 5), dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 5)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-18 00:52:36.029234
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input')
    output = Path('/tmp/output')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output

# Generated at 2022-06-18 00:52:40.928757
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('input'), Path('output'))
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')


# Generated at 2022-06-18 00:52:42.905706
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output

# Generated at 2022-06-18 00:52:45.921127
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    tree_changed = True
    dependencies = ['a', 'b']
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-18 00:52:47.702205
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    pair = InputOutput(input, output)
    assert pair.input == input
    assert pair.output == output


# Generated at 2022-06-18 00:52:54.556664
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse('pass'), True, [])

# Result of transformers transformation
TransformationResultWithInputOutput = NamedTuple('TransformationResultWithInputOutput',
                                                 [('tree', ast.AST),
                                                  ('tree_changed', bool),
                                                  ('dependencies', List[str]),
                                                  ('input', Path),
                                                  ('output', Path)])


# Generated at 2022-06-18 00:52:57.703307
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(3, 7), dependencies=[])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 7)
    assert result.dependencies == []


# Generated at 2022-06-18 00:53:04.089977
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input')
    output = Path('/tmp/output')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-18 00:53:07.358218
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input')
    output = Path('/tmp/output')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-18 00:53:10.009610
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input')
    output = Path('/tmp/output')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-18 00:53:10.912744
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, False, None)

# Generated at 2022-06-18 00:53:12.615415
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(3, 7), dependencies=[])


# Generated at 2022-06-18 00:53:15.381899
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    result = TransformationResult(tree, True, ['a', 'b'])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == ['a', 'b']

# Generated at 2022-06-18 00:53:16.816295
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=[])


# Generated at 2022-06-18 00:53:19.429576
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('/tmp/input')
    output_path = Path('/tmp/output')
    input_output = InputOutput(input_path, output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path

# Generated at 2022-06-18 00:53:21.724886
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, False, [])

# Generated at 2022-06-18 00:53:25.953252
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=[])
    assert c.files == 1
    assert c.time == 1.0
    assert c.target == (3, 6)
    assert c.dependencies == []


# Generated at 2022-06-18 00:53:33.152499
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(3, 5), dependencies=[])


# Generated at 2022-06-18 00:53:35.925223
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1, target=(3, 6), dependencies=[])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 6)
    assert result.dependencies == []


# Generated at 2022-06-18 00:53:41.256910
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=[])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 6)
    assert result.dependencies == []


# Generated at 2022-06-18 00:53:44.376962
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-18 00:53:46.378063
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=[])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 6)
    assert result.dependencies == []


# Generated at 2022-06-18 00:53:50.510797
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    result = TransformationResult(tree, True, ['a.py'])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == ['a.py']

# Generated at 2022-06-18 00:53:53.450835
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(3, 5), dependencies=['a'])



# Generated at 2022-06-18 00:53:57.831265
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1, target=(3, 5), dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 5)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-18 00:54:01.302990
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input')
    output = Path('/tmp/output')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output

# Generated at 2022-06-18 00:54:04.310823
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=[])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 6)
    assert result.dependencies == []


# Generated at 2022-06-18 00:54:14.825198
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=[])


# Generated at 2022-06-18 00:54:16.702970
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-18 00:54:22.706493
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=2.0, target=(3, 4),
                               dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-18 00:54:26.358704
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    tree_changed = True
    dependencies = ['a', 'b']
    tr = TransformationResult(tree, tree_changed, dependencies)
    assert tr.tree == tree
    assert tr.tree_changed == tree_changed
    assert tr.dependencies == dependencies

# Generated at 2022-06-18 00:54:30.281372
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-18 00:54:34.531304
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(3, 7), dependencies=[])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 7)
    assert result.dependencies == []


# Generated at 2022-06-18 00:54:41.607821
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a'), Path('b')) == InputOutput(Path('a'), Path('b'))
    assert InputOutput(Path('a'), Path('b')) != InputOutput(Path('a'), Path('c'))
    assert InputOutput(Path('a'), Path('b')) != InputOutput(Path('c'), Path('b'))
    assert InputOutput(Path('a'), Path('b')) != InputOutput(Path('c'), Path('d'))


# Generated at 2022-06-18 00:54:50.125049
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    assert TransformationResult(tree, False, []) == TransformationResult(tree, False, [])
    assert TransformationResult(tree, False, []) != TransformationResult(tree, True, [])
    assert TransformationResult(tree, False, []) != TransformationResult(tree, False, ['a'])
    assert TransformationResult(tree, False, []) != TransformationResult(tree, True, ['a'])
    assert TransformationResult(tree, False, ['a']) != TransformationResult(tree, True, ['a'])
    assert TransformationResult(tree, False, ['a']) != TransformationResult(tree, False, ['b'])
    assert TransformationResult(tree, False, ['a']) != TransformationResult(tree, True, ['b'])

# Generated at 2022-06-18 00:54:56.571541
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a'), Path('b')) == InputOutput(Path('a'), Path('b'))
    assert InputOutput(Path('a'), Path('b')) != InputOutput(Path('b'), Path('a'))
    assert InputOutput(Path('a'), Path('b')) != InputOutput(Path('a'), Path('a'))
    assert InputOutput(Path('a'), Path('b')) != InputOutput(Path('b'), Path('b'))


# Generated at 2022-06-18 00:54:57.871597
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(3, 7), dependencies=[])


# Generated at 2022-06-18 00:55:22.240773
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=[])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 6)
    assert result.dependencies == []


# Generated at 2022-06-18 00:55:24.558761
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=1.0, target=(3, 6),
                           dependencies=['a', 'b'])
    assert cr.files == 1
    assert cr.time == 1.0
    assert cr.target == (3, 6)
    assert cr.dependencies == ['a', 'b']


# Generated at 2022-06-18 00:55:27.503393
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('/tmp/input')
    output_path = Path('/tmp/output')
    input_output = InputOutput(input_path, output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path

# Generated at 2022-06-18 00:55:30.882907
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse('x = 1'), True, ['a', 'b'])

# Generated at 2022-06-18 00:55:32.400790
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2.0, (3, 4), ['a', 'b'])


# Generated at 2022-06-18 00:55:35.663984
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("a = 1")
    result = TransformationResult(tree, True, [])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == []

# Generated at 2022-06-18 00:55:38.410968
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    result = TransformationResult(tree, True, ['a.py'])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == ['a.py']

# Generated at 2022-06-18 00:55:41.998240
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('input')
    output_path = Path('output')
    input_output = InputOutput(input_path, output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path


# Generated at 2022-06-18 00:55:43.075743
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse('pass'), True, [])

# Generated at 2022-06-18 00:55:47.652522
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(3, 5),
                               dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 5)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-18 00:56:39.580171
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 2.0, (3, 4), ['a', 'b'])


# Generated at 2022-06-18 00:56:42.495625
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1, target=(3, 7), dependencies=[])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 7)
    assert result.dependencies == []


# Generated at 2022-06-18 00:56:45.340154
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=[])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 6)
    assert result.dependencies == []


# Generated at 2022-06-18 00:56:50.805737
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    result = TransformationResult(tree, True, ['a', 'b'])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == ['a', 'b']

# Generated at 2022-06-18 00:56:51.921259
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse('1'), True, ['a', 'b'])

# Generated at 2022-06-18 00:56:57.061816
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=0.1, target=(3, 5), dependencies=[])
    assert cr.files == 1
    assert cr.time == 0.1
    assert cr.target == (3, 5)
    assert cr.dependencies == []


# Generated at 2022-06-18 00:57:00.913740
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    result = TransformationResult(tree, True, ['a.py'])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == ['a.py']

# Generated at 2022-06-18 00:57:05.077943
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    tree_changed = True
    dependencies = ['a', 'b']
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-18 00:57:06.924582
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse('1'), True, ['a', 'b'])

# Generated at 2022-06-18 00:57:09.530686
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    tr = TransformationResult(tree, True, ['a.py'])
    assert tr.tree == tree
    assert tr.tree_changed
    assert tr.dependencies == ['a.py']

# Generated at 2022-06-18 00:59:02.948345
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=0.1,
                               target=(3, 7),
                               dependencies=['foo', 'bar'])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 7)
    assert result.dependencies == ['foo', 'bar']


# Generated at 2022-06-18 00:59:04.233475
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(3, 5), dependencies=[])


# Generated at 2022-06-18 00:59:08.293313
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    result = TransformationResult(tree, True, ['a', 'b'])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == ['a', 'b']

# Generated at 2022-06-18 00:59:12.757469
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input.py')
    output = Path('output.py')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-18 00:59:14.999759
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('input'), Path('output'))
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')


# Generated at 2022-06-18 00:59:18.259790
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    tree_changed = True
    dependencies = ['foo', 'bar']
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-18 00:59:24.078797
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    res = TransformationResult(tree, True, [])
    assert res.tree == tree
    assert res.tree_changed == True
    assert res.dependencies == []

# Result of transformer
TransformerResult = NamedTuple('TransformerResult',
                               [('tree', ast.AST),
                                ('tree_changed', bool),
                                ('dependencies', List[str])])


# Generated at 2022-06-18 00:59:26.369715
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    result = TransformationResult(tree, True, [])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == []

# Generated at 2022-06-18 00:59:30.035166
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=['a', 'b'])
    assert cr.files == 1
    assert cr.time == 2.0
    assert cr.target == (3, 4)
    assert cr.dependencies == ['a', 'b']


# Generated at 2022-06-18 00:59:32.899600
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=0.1, target=(3, 5), dependencies=[])
    assert cr.files == 1
    assert cr.time == 0.1
    assert cr.target == (3, 5)
    assert cr.dependencies == []
