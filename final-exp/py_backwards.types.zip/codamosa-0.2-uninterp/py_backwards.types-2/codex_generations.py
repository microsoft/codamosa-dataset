

# Generated at 2022-06-18 00:52:23.688279
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=[])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 6)
    assert result.dependencies == []


# Generated at 2022-06-18 00:52:28.217366
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    tree_changed = True
    dependencies = ['a', 'b']
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-18 00:52:30.953484
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('/tmp/input')
    output_path = Path('/tmp/output')
    input_output = InputOutput(input_path, output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path

# Generated at 2022-06-18 00:52:35.402406
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    tree_changed = True
    dependencies = ['foo', 'bar']
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-18 00:52:40.968178
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input')
    output = Path('/tmp/output')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output

# Generated at 2022-06-18 00:52:43.810027
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=[])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 6)
    assert result.dependencies == []


# Generated at 2022-06-18 00:52:45.397756
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=['a'])


# Generated at 2022-06-18 00:52:48.579530
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 6)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-18 00:52:53.131495
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    result = TransformationResult(tree, True, ['a', 'b'])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == ['a', 'b']

# Generated at 2022-06-18 00:52:55.113369
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(3, 5), dependencies=['a'])


# Generated at 2022-06-18 00:52:58.559472
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse('1'), True, ['a', 'b'])

# Generated at 2022-06-18 00:53:03.715541
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    result = TransformationResult(tree, True, ['a', 'b'])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == ['a', 'b']

# Generated at 2022-06-18 00:53:07.036171
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    tr = TransformationResult(tree, True, ['a', 'b'])
    assert tr.tree == tree
    assert tr.tree_changed == True
    assert tr.dependencies == ['a', 'b']

# Generated at 2022-06-18 00:53:09.476971
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    tree_changed = True
    dependencies = ['a', 'b']
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-18 00:53:11.230253
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=['a'])


# Generated at 2022-06-18 00:53:19.113681
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse('1'), False, []) == TransformationResult(ast.parse('1'), False, [])
    assert TransformationResult(ast.parse('1'), False, []) != TransformationResult(ast.parse('2'), False, [])
    assert TransformationResult(ast.parse('1'), False, []) != TransformationResult(ast.parse('1'), True, [])
    assert TransformationResult(ast.parse('1'), False, []) != TransformationResult(ast.parse('1'), False, ['a'])
    assert TransformationResult(ast.parse('1'), False, []) != TransformationResult(ast.parse('1'), False, ['a', 'b'])
    assert TransformationResult(ast.parse('1'), False, ['a']) != TransformationResult(ast.parse('1'), False, ['a', 'b'])

# Generated at 2022-06-18 00:53:24.437586
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input')
    output = Path('/tmp/output')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output

# Generated at 2022-06-18 00:53:27.186567
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('/tmp/input')
    output_path = Path('/tmp/output')
    input_output = InputOutput(input_path, output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path

# Generated at 2022-06-18 00:53:31.796310
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input')
    output = Path('/tmp/output')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-18 00:53:34.927070
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    tr = TransformationResult(tree, True, ['a', 'b'])
    assert tr.tree == tree
    assert tr.tree_changed == True
    assert tr.dependencies == ['a', 'b']

# Generated at 2022-06-18 00:53:43.928644
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-18 00:53:47.218225
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-18 00:53:51.370186
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    tree_changed = True
    dependencies = ['a', 'b']
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-18 00:53:53.167430
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.AST(), True, [])

# Generated at 2022-06-18 00:53:56.705413
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=0.1, target=(3, 6), dependencies=[])
    assert cr.files == 1
    assert cr.time == 0.1
    assert cr.target == (3, 6)
    assert cr.dependencies == []


# Generated at 2022-06-18 00:53:58.351898
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=[])


# Generated at 2022-06-18 00:54:01.935969
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(3, 7), dependencies=[])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 7)
    assert result.dependencies == []


# Generated at 2022-06-18 00:54:07.161335
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('input'), Path('output'))
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')


# Generated at 2022-06-18 00:54:11.561604
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('/home/user/test.py')
    output_path = Path('/home/user/test.pyc')
    input_output = InputOutput(input_path, output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path


# Generated at 2022-06-18 00:54:14.091668
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    result = TransformationResult(tree, True, ['a.py'])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == ['a.py']

# Generated at 2022-06-18 00:54:29.050917
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("pass")
    result = TransformationResult(tree, False, [])
    assert result.tree == tree
    assert result.tree_changed == False
    assert result.dependencies == []

# Result of transformers transformation
TransformationResultWithInputOutput = NamedTuple('TransformationResultWithInputOutput',
                                                [('input_output', InputOutput),
                                                 ('tree', ast.AST),
                                                 ('tree_changed', bool),
                                                 ('dependencies', List[str])])


# Generated at 2022-06-18 00:54:32.848132
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    tr = TransformationResult(tree, True, [])
    assert tr.tree == tree
    assert tr.tree_changed == True
    assert tr.dependencies == []

# Generated at 2022-06-18 00:54:36.706358
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    tree_changed = True
    dependencies = ['a', 'b']
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-18 00:54:43.316834
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1, target=(3, 5),
                               dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 5)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-18 00:54:46.490214
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('input'), Path('output'))
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')


# Generated at 2022-06-18 00:54:51.672839
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=0.1, target=(3, 7), dependencies=[])
    assert cr.files == 1
    assert cr.time == 0.1
    assert cr.target == (3, 7)
    assert cr.dependencies == []


# Generated at 2022-06-18 00:54:55.969254
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.Module(), False, [])
    assert TransformationResult(ast.Module(), True, [])
    assert TransformationResult(ast.Module(), False, ['a'])
    assert TransformationResult(ast.Module(), True, ['a'])

# Generated at 2022-06-18 00:54:57.452405
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse('pass'), True, []).tree_changed
    assert not TransformationResult(ast.parse('pass'), False, []).tree_changed

# Generated at 2022-06-18 00:54:59.533755
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input')
    output = Path('/tmp/output')
    pair = InputOutput(input, output)
    assert pair.input == input
    assert pair.output == output


# Generated at 2022-06-18 00:55:02.168542
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    result = TransformationResult(tree, True, ['a', 'b'])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == ['a', 'b']

# Generated at 2022-06-18 00:55:27.503067
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    tree_changed = True
    dependencies = ['a', 'b']
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-18 00:55:32.819751
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('/tmp/input')
    output_path = Path('/tmp/output')
    input_output = InputOutput(input_path, output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path

# Generated at 2022-06-18 00:55:36.270005
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('1 + 2')
    result = TransformationResult(tree, True, ['a', 'b'])
    assert result.tree == tree
    assert result.tree_changed
    assert result.dependencies == ['a', 'b']

# Generated at 2022-06-18 00:55:37.191929
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, False, [])

# Generated at 2022-06-18 00:55:38.303494
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse('pass'), True, [])

# Generated at 2022-06-18 00:55:41.272133
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input')
    output = Path('/tmp/output')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-18 00:55:43.280676
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('a'), Path('b'))
    assert input_output.input == Path('a')
    assert input_output.output == Path('b')

# Generated at 2022-06-18 00:55:47.166689
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=[])
    assert cr.files == 1
    assert cr.time == 1.0
    assert cr.target == (3, 6)
    assert cr.dependencies == []


# Generated at 2022-06-18 00:55:49.432595
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input')
    output = Path('/tmp/output')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output

# Generated at 2022-06-18 00:55:51.576835
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-18 00:56:44.610984
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2, (3, 4), ['a', 'b'])


# Generated at 2022-06-18 00:56:51.673085
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('/home/user/input.py')
    output_path = Path('/home/user/output.py')
    input_output = InputOutput(input_path, output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path


# Generated at 2022-06-18 00:56:56.261238
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    result = TransformationResult(tree, True, ['a', 'b'])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == ['a', 'b']

# Generated at 2022-06-18 00:57:00.170924
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    res = TransformationResult(tree, True, ['a', 'b'])
    assert res.tree == tree
    assert res.tree_changed
    assert res.dependencies == ['a', 'b']

# Generated at 2022-06-18 00:57:03.857571
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(3, 5), dependencies=[])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 5)
    assert result.dependencies == []


# Generated at 2022-06-18 00:57:07.863122
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('input.py'), Path('output.py'))
    assert input_output.input == Path('input.py')
    assert input_output.output == Path('output.py')


# Generated at 2022-06-18 00:57:13.212319
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('1')
    tree_changed = True
    dependencies = ['a', 'b']
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-18 00:57:16.010600
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output

# Generated at 2022-06-18 00:57:18.636916
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    result = TransformationResult(tree, True, ['foo', 'bar'])
    assert result.tree == tree
    assert result.tree_changed
    assert result.dependencies == ['foo', 'bar']

# Generated at 2022-06-18 00:57:22.677951
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input')
    output = Path('/tmp/output')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output

# Generated at 2022-06-18 00:59:18.189121
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    result = TransformationResult(tree, True, ['a', 'b'])
    assert result.tree == tree
    assert result.tree_changed
    assert result.dependencies == ['a', 'b']

# Generated at 2022-06-18 00:59:21.504779
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=[])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 6)
    assert result.dependencies == []


# Generated at 2022-06-18 00:59:25.468715
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    tree_changed = True
    dependencies = ['a', 'b']
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-18 00:59:28.053750
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-18 00:59:30.613935
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    result = TransformationResult(tree, True, ['a', 'b'])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == ['a', 'b']

# Generated at 2022-06-18 00:59:36.251425
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse('x = 1'), True, []) == TransformationResult(ast.parse('x = 1'), True, [])
    assert TransformationResult(ast.parse('x = 1'), True, []) != TransformationResult(ast.parse('x = 2'), True, [])
    assert TransformationResult(ast.parse('x = 1'), True, []) != TransformationResult(ast.parse('x = 1'), False, [])
    assert TransformationResult(ast.parse('x = 1'), True, []) != TransformationResult(ast.parse('x = 1'), True, ['a'])
    assert TransformationResult(ast.parse('x = 1'), True, []) != TransformationResult(ast.parse('x = 1'), True, ['a', 'b'])

# Generated at 2022-06-18 00:59:37.998081
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1, target=(3, 6), dependencies=[])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 6)
    assert result.dependencies == []


# Generated at 2022-06-18 00:59:39.892986
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-18 00:59:44.535782
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a'), Path('b')) == InputOutput(Path('a'), Path('b'))
    assert InputOutput(Path('a'), Path('b')) != InputOutput(Path('a'), Path('c'))
    assert InputOutput(Path('a'), Path('b')) != InputOutput(Path('c'), Path('b'))
    assert InputOutput(Path('a'), Path('b')) != InputOutput(Path('c'), Path('d'))


# Generated at 2022-06-18 00:59:47.129867
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input.py')
    output = Path('/tmp/output.py')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output
