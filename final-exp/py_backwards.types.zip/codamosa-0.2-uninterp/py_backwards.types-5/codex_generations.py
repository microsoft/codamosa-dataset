

# Generated at 2022-06-18 00:52:23.488404
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=1, time=1.0, target=(3, 7), dependencies=['a'])



# Generated at 2022-06-18 00:52:25.977021
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    result = TransformationResult(tree, False, [])
    assert result.tree == tree
    assert result.tree_changed == False
    assert result.dependencies == []

# Generated at 2022-06-18 00:52:29.920203
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.AST(), True, [])
    assert TransformationResult(ast.AST(), False, [])
    assert TransformationResult(ast.AST(), True, ['a', 'b'])
    assert TransformationResult(ast.AST(), False, ['a', 'b'])

# Generated at 2022-06-18 00:52:33.590149
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input')
    output = Path('/tmp/output')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-18 00:52:35.835320
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=['a'])


# Generated at 2022-06-18 00:52:40.890302
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("1 + 1")
    result = TransformationResult(tree, True, [])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == []

# Generated at 2022-06-18 00:52:43.162861
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('a'), Path('b'))
    assert input_output.input == Path('a')
    assert input_output.output == Path('b')


# Generated at 2022-06-18 00:52:46.342957
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    result = TransformationResult(tree, True, [])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == []

# Generated at 2022-06-18 00:52:47.917847
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=['a', 'b'])


# Generated at 2022-06-18 00:52:53.088580
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    result = TransformationResult(tree, True, ['a.py'])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == ['a.py']

# Generated at 2022-06-18 00:52:57.826878
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(input=Path('input'), output=Path('output'))
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')

# Generated at 2022-06-18 00:53:00.360707
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    tree_changed = True
    dependencies = ['a', 'b']
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-18 00:53:05.615534
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1, target=(3, 7),
                               dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 7)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-18 00:53:10.214406
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=0.1,
                               target=(3, 7),
                               dependencies=['foo', 'bar'])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 7)
    assert result.dependencies == ['foo', 'bar']


# Generated at 2022-06-18 00:53:13.536692
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(3, 7), dependencies=[])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 7)
    assert result.dependencies == []


# Generated at 2022-06-18 00:53:16.586836
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=1.0, target=(3, 7), dependencies=[])
    assert cr.files == 1
    assert cr.time == 1.0
    assert cr.target == (3, 7)
    assert cr.dependencies == []


# Generated at 2022-06-18 00:53:19.271533
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('input')
    output_path = Path('output')
    input_output = InputOutput(input_path, output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path


# Generated at 2022-06-18 00:53:25.444917
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x=1')
    tree_changed = True
    dependencies = ['a', 'b']
    res = TransformationResult(tree, tree_changed, dependencies)
    assert res.tree == tree
    assert res.tree_changed == tree_changed
    assert res.dependencies == dependencies

# Generated at 2022-06-18 00:53:27.214933
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, False, None)

# Generated at 2022-06-18 00:53:29.826081
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=[])


# Generated at 2022-06-18 00:53:37.979271
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(3, 5), dependencies=['a'])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 5)
    assert result.dependencies == ['a']


# Generated at 2022-06-18 00:53:41.765463
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-18 00:53:45.097666
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input')
    output = Path('/tmp/output')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-18 00:53:49.868805
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(3, 5), dependencies=[])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 5)
    assert result.dependencies == []


# Generated at 2022-06-18 00:53:52.923609
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=0.1, target=(3, 6), dependencies=[])


# Generated at 2022-06-18 00:53:55.381929
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=1,
                             time=1.0,
                             target=(3, 5),
                             dependencies=['a', 'b'])


# Generated at 2022-06-18 00:54:00.434103
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-18 00:54:03.027261
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    pair = InputOutput(input, output)
    assert pair.input == input
    assert pair.output == output


# Generated at 2022-06-18 00:54:07.462883
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(input=Path('input'), output=Path('output'))
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')


# Generated at 2022-06-18 00:54:09.722896
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(3, 7), dependencies=[])


# Generated at 2022-06-18 00:54:20.821145
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1, target=(3, 6), dependencies=[])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 6)
    assert result.dependencies == []


# Generated at 2022-06-18 00:54:23.640767
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('input'), Path('output'))
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')


# Generated at 2022-06-18 00:54:26.735362
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(input=Path('input'), output=Path('output'))
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')

# Generated at 2022-06-18 00:54:31.510674
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(input=Path('/tmp/input'),
                               output=Path('/tmp/output'))
    assert input_output.input == Path('/tmp/input')
    assert input_output.output == Path('/tmp/output')


# Generated at 2022-06-18 00:54:34.067369
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=['a'])


# Generated at 2022-06-18 00:54:37.662678
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1, target=(3, 5), dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 5)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-18 00:54:41.882783
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('input'), Path('output'))
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')


# Generated at 2022-06-18 00:54:44.402168
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=2.0,
                               target=(3, 4),
                               dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-18 00:54:45.956668
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('/tmp/input.py'), Path('/tmp/output.py'))
    assert input_output.input == Path('/tmp/input.py')
    assert input_output.output == Path('/tmp/output.py')

# Generated at 2022-06-18 00:54:50.548373
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('foo'), Path('bar'))
    assert input_output.input == Path('foo')
    assert input_output.output == Path('bar')


# Generated at 2022-06-18 00:55:12.850802
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input')
    output = Path('/tmp/output')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output

# Generated at 2022-06-18 00:55:16.433857
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('x = 1')
    d = ['a', 'b']
    r = TransformationResult(t, True, d)
    assert r.tree == t
    assert r.tree_changed == True
    assert r.dependencies == d

# Generated at 2022-06-18 00:55:20.758858
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(3, 7), dependencies=[])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 7)
    assert result.dependencies == []


# Generated at 2022-06-18 00:55:25.985015
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=1.0,
                               target=(3, 6),
                               dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 6)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-18 00:55:28.206524
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('input'), Path('output'))
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')


# Generated at 2022-06-18 00:55:33.006410
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1, target=(3, 6), dependencies=[])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 6)
    assert result.dependencies == []


# Generated at 2022-06-18 00:55:36.173126
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output

# Generated at 2022-06-18 00:55:39.797132
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=1.0, target=(3, 5), dependencies=[])
    assert cr.files == 1
    assert cr.time == 1.0
    assert cr.target == (3, 5)
    assert cr.dependencies == []


# Generated at 2022-06-18 00:55:42.226074
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    result = TransformationResult(tree, True, [])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == []

# Generated at 2022-06-18 00:55:45.942489
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    result = TransformationResult(tree, True, ['a.py'])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == ['a.py']

# Generated at 2022-06-18 00:56:36.401387
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('input'), Path('output'))
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')


# Generated at 2022-06-18 00:56:39.831853
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1, target=(3, 5), dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 5)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-18 00:56:43.043534
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    tree_changed = True
    dependencies = ['a', 'b']
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-18 00:56:45.785645
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(3, 5), dependencies=[])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 5)
    assert result.dependencies == []


# Generated at 2022-06-18 00:56:50.808688
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('a'), Path('b'))
    assert input_output.input == Path('a')
    assert input_output.output == Path('b')


# Generated at 2022-06-18 00:56:53.214697
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input')
    output = Path('/tmp/output')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-18 00:56:57.895290
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input')
    output = Path('/tmp/output')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output

# Generated at 2022-06-18 00:57:00.994007
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('input'), Path('output'))
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')


# Generated at 2022-06-18 00:57:03.983202
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input')
    output = Path('/tmp/output')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output

# Generated at 2022-06-18 00:57:07.677462
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(input=Path('input'), output=Path('output'))
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')


# Generated at 2022-06-18 00:58:53.132267
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('foo'), Path('bar'))
    assert input_output.input == Path('foo')
    assert input_output.output == Path('bar')


# Generated at 2022-06-18 00:58:54.932320
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-18 00:58:58.087587
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    result = TransformationResult(tree, True, ['foo', 'bar'])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == ['foo', 'bar']

# Generated at 2022-06-18 00:59:00.295804
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    result = TransformationResult(tree, False, [])
    assert result.tree == tree
    assert result.tree_changed == False
    assert result.dependencies == []

# Generated at 2022-06-18 00:59:02.622913
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1, target=(3, 6), dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 6)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-18 00:59:06.341959
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1, target=(3, 6), dependencies=[])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 6)
    assert result.dependencies == []


# Generated at 2022-06-18 00:59:09.266725
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=[])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 6)
    assert result.dependencies == []


# Generated at 2022-06-18 00:59:13.177415
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-18 00:59:15.467535
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    result = TransformationResult(tree, True, ['a', 'b'])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == ['a', 'b']

# Generated at 2022-06-18 00:59:19.512024
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=0.1,
                               target=(3, 6),
                               dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 6)
    assert result.dependencies == ['a', 'b']
