

# Generated at 2022-06-18 00:52:18.917713
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-18 00:52:23.906621
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    result = TransformationResult(tree, True, [])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == []

# Generated at 2022-06-18 00:52:27.543290
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('input'), Path('output'))
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')


# Generated at 2022-06-18 00:52:29.384711
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(3, 5), dependencies=[])


# Generated at 2022-06-18 00:52:33.635033
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(3, 5), dependencies=['a'])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 5)
    assert result.dependencies == ['a']


# Generated at 2022-06-18 00:52:35.233495
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=None, tree_changed=False, dependencies=[])

# Generated at 2022-06-18 00:52:40.891163
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('a'), Path('b'))
    assert input_output.input == Path('a')
    assert input_output.output == Path('b')


# Generated at 2022-06-18 00:52:44.313457
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1, target=(3, 6), dependencies=['foo', 'bar'])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 6)
    assert result.dependencies == ['foo', 'bar']


# Generated at 2022-06-18 00:52:46.272885
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output

# Generated at 2022-06-18 00:52:47.853121
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=['a', 'b'])


# Generated at 2022-06-18 00:52:54.905150
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=2.0,
                               target=(3, 4),
                               dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-18 00:52:57.045988
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    pair = InputOutput(input, output)
    assert pair.input == input
    assert pair.output == output

# Generated at 2022-06-18 00:52:59.603055
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    tr = TransformationResult(tree, True, ['a', 'b'])
    assert tr.tree == tree
    assert tr.tree_changed == True
    assert tr.dependencies == ['a', 'b']

# Generated at 2022-06-18 00:53:04.844972
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    tree_changed = True
    dependencies = ['a', 'b']
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-18 00:53:07.035547
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=['a', 'b'])


# Generated at 2022-06-18 00:53:09.056334
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    result = TransformationResult(tree, True, ['a', 'b'])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == ['a', 'b']

# Generated at 2022-06-18 00:53:11.440618
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output

# Generated at 2022-06-18 00:53:15.265703
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-18 00:53:18.732932
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-18 00:53:24.346919
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    result = TransformationResult(tree, True, [])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == []

# Generated at 2022-06-18 00:53:31.876322
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output

# Generated at 2022-06-18 00:53:36.220478
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    result = TransformationResult(tree, True, [])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == []

# Generated at 2022-06-18 00:53:38.300488
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    result = TransformationResult(tree, True, [])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == []

# Generated at 2022-06-18 00:53:41.805696
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output

# Generated at 2022-06-18 00:53:44.065133
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 1.0, (3, 5), ['a', 'b'])


# Generated at 2022-06-18 00:53:49.069756
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1, target=(3, 5), dependencies=['a'])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 5)
    assert result.dependencies == ['a']


# Generated at 2022-06-18 00:53:53.960646
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input')
    output = Path('/tmp/output')
    pair = InputOutput(input, output)
    assert pair.input == input
    assert pair.output == output

# Generated at 2022-06-18 00:53:57.165965
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    result = TransformationResult(tree, True, ['a', 'b'])
    assert result.tree == tree
    assert result.tree_changed
    assert result.dependencies == ['a', 'b']

# Generated at 2022-06-18 00:54:02.050388
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(3, 6),
                               dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 6)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-18 00:54:07.191508
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('input'), Path('output'))
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')


# Generated at 2022-06-18 00:54:19.899506
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=['a'])


# Generated at 2022-06-18 00:54:23.155577
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    res = TransformationResult(tree, True, ['a'])
    assert res.tree == tree
    assert res.tree_changed == True
    assert res.dependencies == ['a']

# Generated at 2022-06-18 00:54:26.440215
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    tree_changed = True
    dependencies = ['a', 'b']
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-18 00:54:27.761965
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse('pass'), True, [])

# Generated at 2022-06-18 00:54:30.634523
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(3, 5), dependencies=[])


# Generated at 2022-06-18 00:54:34.394293
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    result = TransformationResult(tree, True, ['a.py'])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == ['a.py']

# Generated at 2022-06-18 00:54:36.511419
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-18 00:54:41.338195
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('1')
    result = TransformationResult(tree, True, [])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == []

# Generated at 2022-06-18 00:54:46.300387
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-18 00:54:49.054718
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    result = TransformationResult(tree, True, ['a', 'b'])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == ['a', 'b']

# Generated at 2022-06-18 00:55:09.756809
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    result = TransformationResult(tree, True, ['a', 'b'])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == ['a', 'b']

# Generated at 2022-06-18 00:55:12.327510
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=0.1, target=(3, 6), dependencies=['a'])


# Generated at 2022-06-18 00:55:14.944868
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    result = TransformationResult(tree, True, ['a', 'b'])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == ['a', 'b']

# Generated at 2022-06-18 00:55:16.312248
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=[])


# Generated at 2022-06-18 00:55:20.705090
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=[])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 6)
    assert result.dependencies == []


# Generated at 2022-06-18 00:55:23.329896
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(3, 5),
                               dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 5)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-18 00:55:28.470327
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    res = TransformationResult(tree, True, ['a', 'b'])
    assert res.tree == tree
    assert res.tree_changed == True
    assert res.dependencies == ['a', 'b']

# Result of transformer
TransformerResult = NamedTuple('TransformerResult',
                               [('result', TransformationResult),
                                ('time', float)])


# Generated at 2022-06-18 00:55:33.355114
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1, target=(3, 6),
                               dependencies=[])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 6)
    assert result.dependencies == []


# Generated at 2022-06-18 00:55:36.889226
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    tree_changed = True
    dependencies = ['a', 'b']
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-18 00:55:39.849134
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('input'), Path('output'))
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')


# Generated at 2022-06-18 00:56:28.554141
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    tree_changed = True
    dependencies = ['a', 'b']
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Result of transformers transformation
TransformationResultWithDependencies = NamedTuple('TransformationResultWithDependencies',
                                                 [('tree', ast.AST),
                                                  ('tree_changed', bool),
                                                  ('dependencies', List[str]),
                                                  ('dependencies_changed', bool)])


# Generated at 2022-06-18 00:56:32.738216
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    tr = TransformationResult(tree, True, ['a', 'b'])
    assert tr.tree == tree
    assert tr.tree_changed == True
    assert tr.dependencies == ['a', 'b']

# Generated at 2022-06-18 00:56:36.628595
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.5, target=(3, 6), dependencies=[])
    assert result.files == 1
    assert result.time == 0.5
    assert result.target == (3, 6)
    assert result.dependencies == []


# Generated at 2022-06-18 00:56:39.190250
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    tr = TransformationResult(tree, True, ['a', 'b'])
    assert tr.tree == tree
    assert tr.tree_changed == True
    assert tr.dependencies == ['a', 'b']

# Generated at 2022-06-18 00:56:42.064609
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1, target=(3, 5), dependencies=[])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 5)
    assert result.dependencies == []


# Generated at 2022-06-18 00:56:44.400670
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-18 00:56:45.746263
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 2.0, (3, 4), ['a', 'b']) == \
        CompilationResult(1, 2.0, (3, 4), ['a', 'b'])


# Generated at 2022-06-18 00:56:50.767295
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('input')
    o = Path('output')
    io = InputOutput(i, o)
    assert io.input == i
    assert io.output == o


# Generated at 2022-06-18 00:56:53.182996
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    result = TransformationResult(tree, True, ['a', 'b'])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == ['a', 'b']

# Generated at 2022-06-18 00:56:57.848596
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('input'), Path('output'))
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')


# Generated at 2022-06-18 00:58:36.068470
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=[])


# Generated at 2022-06-18 00:58:38.996631
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('/tmp/input')
    output_path = Path('/tmp/output')
    input_output = InputOutput(input_path, output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path


# Generated at 2022-06-18 00:58:42.590861
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=[])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 6)
    assert result.dependencies == []


# Generated at 2022-06-18 00:58:45.983229
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('input.py'), Path('output.py'))
    assert input_output.input == Path('input.py')
    assert input_output.output == Path('output.py')


# Generated at 2022-06-18 00:58:47.778739
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input')
    output = Path('/tmp/output')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-18 00:58:50.635686
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    tree_changed = True
    dependencies = ['a', 'b']
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-18 00:58:53.208426
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input')
    output = Path('/tmp/output')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-18 00:58:54.988167
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-18 00:58:57.118811
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=[])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 6)
    assert result.dependencies == []


# Generated at 2022-06-18 00:58:59.209653
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('input'), Path('output'))
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')
