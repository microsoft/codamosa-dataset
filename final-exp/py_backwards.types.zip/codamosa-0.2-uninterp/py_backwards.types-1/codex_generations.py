

# Generated at 2022-06-18 00:52:20.053018
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-18 00:52:25.234151
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(3, 5),
                               dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 5)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-18 00:52:28.634547
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(3, 7), dependencies=[])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 7)
    assert result.dependencies == []


# Generated at 2022-06-18 00:52:33.060207
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=2.0, target=(3, 4),
                               dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-18 00:52:36.288093
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    result = TransformationResult(tree, True, ['a', 'b'])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == ['a', 'b']

# Generated at 2022-06-18 00:52:41.606989
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(3, 7), dependencies=[])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 7)
    assert result.dependencies == []


# Generated at 2022-06-18 00:52:44.735813
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    tree_changed = True
    dependencies = ['a', 'b']
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-18 00:52:47.006960
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    result = TransformationResult(tree, True, ['a', 'b'])
    assert result.tree is tree
    assert result.tree_changed is True
    assert result.dependencies == ['a', 'b']

# Generated at 2022-06-18 00:52:51.810883
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-18 00:52:54.904768
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input')
    output = Path('/tmp/output')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-18 00:52:59.869042
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1, target=(3, 6), dependencies=[])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 6)
    assert result.dependencies == []


# Generated at 2022-06-18 00:53:02.951411
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=[])


# Generated at 2022-06-18 00:53:04.196390
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('a')
    output = Path('b')
    pair = InputOutput(input, output)
    assert pair.input == input
    assert pair.output == output


# Generated at 2022-06-18 00:53:07.866677
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1, target=(3, 5), dependencies=[])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 5)
    assert result.dependencies == []



# Generated at 2022-06-18 00:53:10.414218
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    result = TransformationResult(tree, True, [])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == []

# Generated at 2022-06-18 00:53:13.130031
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-18 00:53:16.472145
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    tree_changed = True
    dependencies = ['a', 'b']
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-18 00:53:19.214370
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1, target=(3, 6), dependencies=[])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 6)
    assert result.dependencies == []


# Generated at 2022-06-18 00:53:22.459093
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=[])


# Generated at 2022-06-18 00:53:26.942942
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1, target=(3, 6), dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 6)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-18 00:53:34.438358
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    pair = InputOutput(input, output)
    assert pair.input == input
    assert pair.output == output


# Generated at 2022-06-18 00:53:38.042352
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('/tmp/input')
    output_path = Path('/tmp/output')
    input_output = InputOutput(input_path, output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path

# Generated at 2022-06-18 00:53:42.073749
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('1 + 2')
    result = TransformationResult(tree, True, ['a', 'b'])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == ['a', 'b']

# Generated at 2022-06-18 00:53:45.212962
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input')
    output = Path('/tmp/output')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-18 00:53:47.071028
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1, target=(3, 7), dependencies=[])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 7)
    assert result.dependencies == []


# Generated at 2022-06-18 00:53:50.965638
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1, target=(3, 6), dependencies=[])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 6)
    assert result.dependencies == []


# Generated at 2022-06-18 00:53:55.384402
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1, target=(3, 6), dependencies=[])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 6)
    assert result.dependencies == []


# Generated at 2022-06-18 00:53:58.224848
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    result = TransformationResult(tree, True, [])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == []

# Generated at 2022-06-18 00:54:00.821696
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=[])


# Generated at 2022-06-18 00:54:04.484568
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 6)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-18 00:54:15.329446
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('input'), Path('output'))
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')


# Generated at 2022-06-18 00:54:18.041589
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(3, 5), dependencies=[])


# Generated at 2022-06-18 00:54:21.718061
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('input'), Path('output'))
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')


# Generated at 2022-06-18 00:54:23.373618
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 1.0, (3, 5), [])


# Generated at 2022-06-18 00:54:25.988794
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-18 00:54:30.784375
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    tree_changed = True
    dependencies = ['a', 'b']
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-18 00:54:35.178393
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    tree_changed = True
    dependencies = ['a', 'b']
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-18 00:54:37.585581
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=1, time=1.0, target=(3, 5),
                             dependencies=['foo', 'bar'])


# Generated at 2022-06-18 00:54:41.881887
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('a'), Path('b'))
    assert input_output.input == Path('a')
    assert input_output.output == Path('b')


# Generated at 2022-06-18 00:54:43.979056
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('/tmp/input')
    output_path = Path('/tmp/output')
    input_output = InputOutput(input_path, output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path

# Generated at 2022-06-18 00:55:06.548632
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1, target=(3, 7), dependencies=[])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 7)
    assert result.dependencies == []


# Generated at 2022-06-18 00:55:08.898226
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    result = TransformationResult(tree, False, [])
    assert result.tree == tree
    assert result.tree_changed == False
    assert result.dependencies == []

# Generated at 2022-06-18 00:55:12.366722
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    result = TransformationResult(tree, True, ['a.py'])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == ['a.py']

# Generated at 2022-06-18 00:55:16.187525
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    result = TransformationResult(tree, True, ['a.py'])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == ['a.py']

# Generated at 2022-06-18 00:55:20.127484
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('1')
    result = TransformationResult(tree, True, [])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == []

# Generated at 2022-06-18 00:55:23.517691
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=[])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 6)
    assert result.dependencies == []


# Generated at 2022-06-18 00:55:26.597473
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    tr = TransformationResult(tree, True, [])
    assert tr.tree == tree
    assert tr.tree_changed == True
    assert tr.dependencies == []

# Generated at 2022-06-18 00:55:28.943794
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('a'), Path('b'))
    assert input_output.input == Path('a')
    assert input_output.output == Path('b')


# Generated at 2022-06-18 00:55:30.221410
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=0.1, target=(3, 7), dependencies=[])


# Generated at 2022-06-18 00:55:32.557338
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('/tmp/input')
    output_path = Path('/tmp/output')
    input_output = InputOutput(input_path, output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path

# Generated at 2022-06-18 00:56:16.149287
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('/tmp/input')
    output_path = Path('/tmp/output')
    input_output = InputOutput(input_path, output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path


# Generated at 2022-06-18 00:56:16.996065
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, False, [])

# Generated at 2022-06-18 00:56:21.392230
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1, target=(3, 7), dependencies=[])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 7)
    assert result.dependencies == []


# Generated at 2022-06-18 00:56:26.113378
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1, target=(3, 6), dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 6)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-18 00:56:28.088547
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    result = TransformationResult(tree, True, [])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == []

# Generated at 2022-06-18 00:56:33.761336
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1, target=(3, 6), dependencies=[])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 6)
    assert result.dependencies == []


# Generated at 2022-06-18 00:56:37.283496
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    tree_changed = True
    dependencies = ['a', 'b']
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-18 00:56:39.545634
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-18 00:56:42.457911
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1, target=(3, 6), dependencies=[])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 6)
    assert result.dependencies == []


# Generated at 2022-06-18 00:56:43.739581
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input')
    output = Path('/tmp/output')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-18 00:58:17.575813
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1, target=(3, 7), dependencies=[])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 7)
    assert result.dependencies == []


# Generated at 2022-06-18 00:58:22.201104
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse('pass'), True, [])
    assert TransformationResult(ast.parse('pass'), False, [])
    assert TransformationResult(ast.parse('pass'), True, ['a'])
    assert TransformationResult(ast.parse('pass'), False, ['a'])
    assert TransformationResult(ast.parse('pass'), True, ['a', 'b'])
    assert TransformationResult(ast.parse('pass'), False, ['a', 'b'])

# Generated at 2022-06-18 00:58:23.604115
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=0.1, target=(3, 7), dependencies=[])


# Generated at 2022-06-18 00:58:25.823762
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input')
    output = Path('/tmp/output')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output

# Generated at 2022-06-18 00:58:28.202710
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    result = TransformationResult(tree, True, ['a', 'b'])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == ['a', 'b']

# Generated at 2022-06-18 00:58:33.176408
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    assert TransformationResult(tree, True, []) == TransformationResult(tree, True, [])
    assert TransformationResult(tree, True, []) != TransformationResult(tree, False, [])
    assert TransformationResult(tree, True, []) != TransformationResult(tree, True, ['a'])
    assert TransformationResult(tree, True, []) != TransformationResult(tree, False, ['a'])
    assert TransformationResult(tree, True, ['a']) != TransformationResult(tree, False, ['a'])
    assert TransformationResult(tree, True, ['a']) != TransformationResult(tree, True, ['b'])
    assert TransformationResult(tree, True, ['a']) != TransformationResult(tree, False, ['b'])

# Generated at 2022-06-18 00:58:35.987338
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1, target=(3, 6), dependencies=['a'])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 6)
    assert result.dependencies == ['a']


# Generated at 2022-06-18 00:58:38.212392
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    result = TransformationResult(tree, True, [])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == []

# Generated at 2022-06-18 00:58:39.304879
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2.0, (3, 4), ['a', 'b'])


# Generated at 2022-06-18 00:58:41.767219
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=[])
