

# Generated at 2022-06-21 18:30:49.193514
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=0.1, target=(3, 4),
                           dependencies=['a', 'b', 'c'])
    assert cr.files == 1
    assert cr.time == 0.1
    assert cr.target == (3, 4)
    assert cr.dependencies == ['a', 'b', 'c']


# Generated at 2022-06-21 18:30:54.164900
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    from collections import namedtuple
    CompilationResult = namedtuple('CompilationResult',
                                   ['files', 'time', 'target',
                                    'dependencies'])
    result = CompilationResult(files=1, time=1.0,
                               target=(3, 7),
                               dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 7)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-21 18:30:56.295726
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 1.0, (3, 6), [])


# Generated at 2022-06-21 18:31:01.440003
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=0, time=0.0, target=(3, 5), dependencies=[])
    assert res.files == 0
    assert res.time == 0.0
    assert res.target[0] == 3
    assert res.target[1] == 5
    assert res.dependencies == []


# Generated at 2022-06-21 18:31:06.827677
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('1 + 1')
    TransformationResult(tree, True, ['test'])

# Options for a transformer
TransformerOptions = NamedTuple('TransformerOptions',
                                [('target', CompilationTarget),
                                 ('input_path', Path),
                                 ('output_path', Path)])

# Generated at 2022-06-21 18:31:12.775134
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(1, True, [])
    assert result.tree == 1, 'tree attribute initialized wrong'
    assert result.tree_changed == True, 'tree_changed attribute initialized wrong'
    assert result.dependencies == [], 'dependencies attribute initialized wrong'

# Input/output pair for transformer tests
InputOutputForTransformers = NamedTuple('InputOutputForTransformers',
                                        [('input', ast.AST),
                                         ('expected_output', ast.AST)])

# Generated at 2022-06-21 18:31:19.081387
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('')
    assert isinstance(tree, ast.AST)

    result = TransformationResult(tree, True, ['a.py'])
    assert result.tree_changed == True
    assert len(result.dependencies) == 1
    assert result.dependencies[0] == 'a.py'

if __name__ == '__main__':
    test_TransformationResult()

# Generated at 2022-06-21 18:31:26.036055
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 0.1, (3, 5), []) == CompilationResult(1, 0.1, (3, 5), [])
    assert CompilationResult(1, 0.1, (3, 5), []) != CompilationResult(2, 0.1, (3, 5), [])
    assert CompilationResult(1, 0.1, (3, 5), []) != CompilationResult(1, 0.2, (3, 5), [])


# Generated at 2022-06-21 18:31:29.615063
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('in')
    output = Path('out')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-21 18:31:34.704670
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_file = Path('/test/input_file.py')
    output_file = Path('/test/output_file.py')
    check_input_output = InputOutput(input_file, output_file)
    assert check_input_output.input == input_file
    assert check_input_output.output == output_file

# Generated at 2022-06-21 18:31:40.024350
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path.cwd(), Path.cwd())
    assert input_output.input == Path.cwd()
    assert input_output.output == Path.cwd()


# Generated at 2022-06-21 18:31:43.757866
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    transformation_result = TransformationResult(tree, True, ['module.pyth'])
    assert transformation_result.tree == tree
    assert transformation_result.tree_changed
    assert transformation_result.dependencies == ['module.pyth']

# Generated at 2022-06-21 18:31:49.123823
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('42')
    r = TransformationResult(tree=tree, tree_changed=True,
                             dependencies=['d1', 'd2'])
    assert r.tree is tree
    assert r.tree_changed is True
    assert r.dependencies == ['d1', 'd2']

# Result of transformers validation
ValidationResult = NamedTuple('ValidationResult',
                              [('input_output_pairs', List[InputOutput]),
                               ('dependencies', List[str])])


# Generated at 2022-06-21 18:31:52.778548
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    t = TransformationResult(tree, True, ['foo'])
    assert t.tree == tree
    assert t.tree_changed
    assert t.dependencies == ['foo']


# Generated at 2022-06-21 18:31:56.332745
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(ast.Module, False, [])
    assert t.tree == ast.Module
    assert t.tree_changed == False
    assert t.dependencies == []

# Generated at 2022-06-21 18:31:58.360120
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=2, target=(3, 4), dependencies=[])


# Generated at 2022-06-21 18:32:02.029634
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(input=Path('/input'), output=Path('/output'))
    assert io.input == Path('/input')
    assert io.output == Path('/output')


# Generated at 2022-06-21 18:32:05.462983
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(2, 3, (2, 7), [])
    assert res.files == 2
    assert res.time == 3
    assert res.target == (2, 7)
    assert res.dependencies == []


# Generated at 2022-06-21 18:32:07.834798
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=5,
                             time=1.0,
                             target=(3, 6),
                             dependencies=['a', 'b'])


# Generated at 2022-06-21 18:32:12.379627
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=4, time=0.2, target=(3, 6), dependencies=['hello', 'world'])
    assert result.files == 4
    assert result.time == 0.2
    assert result.target == (3, 6)
    assert result.dependencies == ['hello', 'world']


# Generated at 2022-06-21 18:32:19.661423
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/some/path/to/file.py')
    output = Path('/some/path/to/file.pyc')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Test for constructor of class TransformationResult

# Generated at 2022-06-21 18:32:24.849645
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path("foo/bar.py"), Path("/tmp/baz/qux"))
    assert io.input == Path("foo/bar.py")
    assert io.output == Path("/tmp/baz/qux")

if __name__ == '__main__':
    test_InputOutput()

# Generated at 2022-06-21 18:32:29.019393
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(2, 3.1, (3, 6), [])
    assert result.files == 2
    assert result.time == 3.1
    assert result.target == (3, 6)
    assert result.dependencies == []


# Generated at 2022-06-21 18:32:31.352312
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    try:
        result = CompilationResult(
            files=1,
            time=0.5,
            target=(3, 7),
            dependencies=['requests']
        )
        assert result.files == 1
        assert result.time == 0.5
        assert result.target == (3, 7)
        assert result.dependencies == ['requests']
    except Exception:
        assert False


# Generated at 2022-06-21 18:32:35.831344
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('input.py'), Path('output.py'))
    assert input_output.input.name == 'input.py'
    assert input_output.output.name == 'output.py'
    assert input_output.output != input_output.input


# Generated at 2022-06-21 18:32:38.740665
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.Module()
    res = TransformationResult(tree, True, [])
    assert res.tree is tree
    assert res.tree_changed == True
    assert res.dependencies == []

# Generated at 2022-06-21 18:32:42.222340
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput('foo', 'bar')
    assert input_output.input == 'foo'
    assert input_output.output == 'bar'

# Test compilation result from a target

# Generated at 2022-06-21 18:32:44.977292
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(files=42, time=2.5, target=(3, 7), dependencies=[])
    assert r.files == 42
    assert r.time == 2.5
    assert r.target == (3, 7)
    assert r.dependencies == []



# Generated at 2022-06-21 18:32:49.556436
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=ast.parse("pass"),
                              tree_changed=False,
                              dependencies=[])
    assert tr.tree
    assert not tr.tree_changed
    assert len(tr.dependencies) == 0

# Generated at 2022-06-21 18:32:52.258885
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.AST(), False, []).tree_changed == False
    assert TransformationResult(ast.AST(), True, []).tree_changed == True

# Generated at 2022-06-21 18:33:08.112886
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.parse('b = 30'), True, [])
    assert tr.dependencies == []
    assert tr.tree_changed == True
    assert tr.tree.body[0].target.id == 'b'

    tr1 = TransformationResult(ast.parse('b = 30'), False, ['foo'])
    assert tr1.dependencies == ['foo']
    assert tr1.tree_changed == False
    assert tr1.tree.body[0].target.id == 'b'

# Generated at 2022-06-21 18:33:11.759996
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(0, 0, (0, 0), [])
    assert compilation_result.files == 0
    assert compilation_result.time == 0
    assert compilation_result.target == (0, 0)
    assert compilation_result.dependencies == []


# Generated at 2022-06-21 18:33:14.205129
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = 'input'
    outp = 'output'
    ip = InputOutput(input=inp, output=outp)
    assert ip.input == inp
    assert ip.output == outp

# Generated at 2022-06-21 18:33:20.238547
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=4.0,
                               target=(2, 7),
                               dependencies=["foo.pz"])
    assert result.files == 1
    assert result.time == 4.0
    assert result.target == (2, 7)
    assert result.dependencies == ["foo.pz"]



# Generated at 2022-06-21 18:33:27.690305
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('1')
    result = TransformationResult(tree, True, ['foo', 'bar'])
    assert result.tree == tree
    assert result.tree_changed
    assert result.dependencies == ['foo', 'bar']

# Type of transformers

# Generated at 2022-06-21 18:33:31.457784
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=0, time=0.0, target=(3, 5), dependencies=[])
    assert cr.files == 0
    assert cr.time == 0.0
    assert cr.target == (3, 5)
    assert cr.dependencies == []



# Generated at 2022-06-21 18:33:38.678770
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, False, list()) == \
           TransformationResult(None, False, list())

    assert TransformationResult(None, False, list()) != \
           TransformationResult(None, True, list())

    assert TransformationResult(None, False, list()) != \
           TransformationResult(None, False, ['foo'])

    assert TransformationResult(None, True, ['foo']) != \
           TransformationResult(None, False, ['foo'])

# Generated at 2022-06-21 18:33:40.599789
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert(TransformationResult(ast.AST(), True, ['a', 'b']))

# Generated at 2022-06-21 18:33:44.259980
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=1, time=50.0, target=(3, 7), dependencies=[])
    assert res.files == 1
    assert res.time == 50.0
    assert res.target == (3, 7)
    assert res.dependencies == []

# Generated at 2022-06-21 18:33:49.401545
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 12.0, (3, 5), ['foo', 'bar'])
    assert result.files == 1
    assert result.time == 12.0
    assert result.target == (3, 5)
    assert result.dependencies == ['foo', 'bar']


# Generated at 2022-06-21 18:34:12.216445
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=3,
                               time=4.5,
                               target=(3, 5),
                               dependencies=['file1', 'file2'])
    assert result.files == 3
    assert result.time == 4.5
    assert result.target == (3, 5)
    assert list(result.dependencies) == ['file1', 'file2']


# Generated at 2022-06-21 18:34:16.864851
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # test constructor
    with pytest.raises(TypeError):
        InputOutput()
    with pytest.raises(TypeError):
        InputOutput(Path(__file__), Path(__file__), Path(__file__))
    with pytest.raises(TypeError):
        InputOutput(1, Path(__file__))
    with pytest.raises(TypeError):
        InputOutput(Path(__file__), 1)
    with pytest.raises(TypeError):
        InputOutput(Path(__file__), Path(__file__), 'str')

    # test namedtuple functionality
    pair = InputOutput(Path(__file__), Path(__file__))
    assert pair.input == Path(__file__)
    assert pair.output == Path(__file__)

# Generated at 2022-06-21 18:34:19.357708
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    """Unit test for CompilationResult."""
    CompilationResult(10, 10.0, (3, 5), ['file1.py', 'file2.py'])


# Generated at 2022-06-21 18:34:22.014942
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=30, time=0.12, target=(3, 7),
                      dependencies=['a', 'b'])



# Generated at 2022-06-21 18:34:27.101288
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=1, time=3.3, target=(3, 7),
                            dependencies=['some/path/to/file.py'])
    assert res.files == 1
    assert res.time == 3.3
    assert res.target == (3, 7)
    assert res.dependencies == ['some/path/to/file.py']


# Generated at 2022-06-21 18:34:30.387331
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(1, 0.7, (3, 7), ['foo'])
    assert res.files == 1
    assert res.time == 0.7
    assert res.target == (3, 7)
    assert res.dependencies == ['foo']


# Generated at 2022-06-21 18:34:32.738625
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path("a"), Path("b"))
    assert input_output.input == Path("a")
    assert input_output.output == Path("b")


# Generated at 2022-06-21 18:34:35.697878
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('test.py'),
                               Path('test.py.out'))
    assert input_output.input == Path('test.py')
    assert input_output.output == Path('test.py.out')

# Generated at 2022-06-21 18:34:45.870081
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # test data
    files = 100
    time = 100.1
    target = (3, 7)
    dependencies = ['a', 'b']

    # check correct arguments for correct input
    res = CompilationResult(files, time, target, dependencies)
    assert res.files == files
    assert res.time == time
    assert res.target == target
    assert res.dependencies == dependencies

    # check returned values after changing properties
    res.files = 200
    res.time = 200.2
    res.target = (3, 8)
    res.dependencies.append('c')

    assert res.files == 200
    assert res.time == 200.2
    assert res.target == (3, 8)
    assert res.dependencies == ['a', 'b', 'c']

    # check that instance is frozen after creation
   

# Generated at 2022-06-21 18:34:47.363321
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(None, None, None)

# Generated at 2022-06-21 18:35:11.477196
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    data = [1, 2.4, (3, 4), [5, 6, 7]]
    cr = CompilationResult(*data)
    assert cr.files == data[0]
    assert cr.time == data[1]
    assert cr.target == data[2]
    assert cr.dependencies == data[3]


# Generated at 2022-06-21 18:35:13.757105
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(100, 12.5, (3, 5), [])
    assert isinstance(result, CompilationResult)



# Generated at 2022-06-21 18:35:16.157905
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1337, time=3.14,
                      target=(3, 7), dependencies=["foo"])


# Generated at 2022-06-21 18:35:17.302923
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.parse("print('hello')"), True, [])

# Generated at 2022-06-21 18:35:25.551676
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_dir = Path("tests")
    for inp, outp in [("tests/inp.txt", "tests/outp.txt"),
                      (1, 2)]:
        with pytest.raises(TypeError):
            InputOutput(inp, outp)
    for inp, outp in [(test_dir / "inp.txt", test_dir / "outp.txt"),
                      ("inp.txt", "outp.txt")]:
        inp_outp = InputOutput(inp, outp)
        assert inp_outp.input == inp
        assert inp_outp.output == outp
    return


# Generated at 2022-06-21 18:35:29.868687
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(
        ast.AST(), True, ['module.py'])
    assert tr.tree
    assert tr.tree_changed is True
    assert tr.dependencies == ['module.py']

# Generated at 2022-06-21 18:35:32.801429
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('test_input')
    output = Path('test_output')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output



# Generated at 2022-06-21 18:35:37.492834
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    id_transformer = lambda obj: (obj, False, [])
    root = ast.parse('2 + 3')
    result = TransformationResult(*id_transformer(root))

    assert result.tree == root
    assert result.tree_changed == False
    assert result.dependencies == []

    # Test that we can compare tuples
    assert result == TransformationResult(*id_transformer(root))

# Generated at 2022-06-21 18:35:41.014419
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from ...test.test_type import gen_ast

    d = []
    tr = TransformationResult(gen_ast(), True, d)
    assert isinstance(tr.tree, ast.AST)
    assert tr.tree_changed is True
    assert tr.dependencies is d

# Generated at 2022-06-21 18:35:44.551742
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # type: () -> None
    assert InputOutput('foo', 'bar') == (Path('foo'), Path('bar'))


# Generated at 2022-06-21 18:36:10.696449
# Unit test for constructor of class TransformationResult
def test_TransformationResult():

    # Dummy values
    new_tree = ast.AST()
    new_dependencies = []

    # Inits
    transformation_result = TransformationResult(new_tree,
                                                  True,
                                                  new_dependencies)

    # Assertions
    assert(transformation_result.tree == new_tree)
    assert(transformation_result.tree_changed == True)
    assert(transformation_result.dependencies == new_dependencies)


# Generated at 2022-06-21 18:36:13.468190
# Unit test for constructor of class InputOutput
def test_InputOutput():
    result = InputOutput(input=Path('/input'), output=Path('/output'))
    assert isinstance(result.input, Path)
    assert isinstance(result.output, Path)


# Generated at 2022-06-21 18:36:17.519724
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files = 1,
                           time = 0.5,
                           target = (3, 7),
                           dependencies = ['a', 'b'])
    assert cr.files == 1
    assert cr.time == 0.5
    assert cr.target == (3, 7)
    assert cr.dependencies == ['a', 'b']


# Generated at 2022-06-21 18:36:19.396116
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = InputOutput(Path('a'), Path('b'))
    assert i.input == Path('a')
    assert i.output == Path('b')


# Generated at 2022-06-21 18:36:24.046362
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # pylint: disable=W0612
    ast_tree = ast.parse('print(\'hi\')')
    tree_changed = True
    dependencies = ['stdlib/pathlib.py']

    TransformationResult(ast_tree, tree_changed, dependencies)

# Generated at 2022-06-21 18:36:27.194859
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=10,
                      time=1.0,
                      target=(3, 5),
                      dependencies=["a", "b"])


# Generated at 2022-06-21 18:36:29.447230
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(0, 0.0, (3, 6), [])


# Generated at 2022-06-21 18:36:31.262140
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=0.42, target=(3, 5), dependencies=[])



# Generated at 2022-06-21 18:36:34.173941
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(ast.parse(""), False, ["a", "b"])
    assert res.tree
    assert not res.tree_changed
    assert res.dependencies == ["a", "b"]

# Generated at 2022-06-21 18:36:36.680767
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input='a', output='b') == \
           InputOutput(Path('a'), Path('b'))

# Generated at 2022-06-21 18:37:29.369781
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(tree=ast.parse("x"),
                                  tree_changed=True,
                                  dependencies=["a.js", "b.js"])

    assert result is not None
    assert result.tree is not None
    assert result.tree_changed is not None
    assert result.dependencies is not None

# Generated at 2022-06-21 18:37:32.963164
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(tree=ast.parse("x = 1"),
                             tree_changed=False,
                             dependencies=['foo.bar'])
    assert t.tree is not None
    assert t.tree_changed == False
    assert t.dependencies == ['foo.bar']

# Generated at 2022-06-21 18:37:38.066240
# Unit test for constructor of class InputOutput
def test_InputOutput():
    try:
        InputOutput('bad_input', 'bad_output')
    except TypeError:
        pass
    else:
        assert False

    try:
        InputOutput(Path('good_input'), 'bad_output')
    except TypeError:
        pass
    else:
        assert False

    try:
        InputOutput('bad_input', Path('good_output'))
    except TypeError:
        pass
    else:
        assert False

    try:
        InputOutput(Path('good_input'), Path('good_output'))
    except TypeError:
        assert False

# Generated at 2022-06-21 18:37:44.608698
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=0.4,
                               target=(3, 5),
                               dependencies=['dep1.py', 'dep2.py'])
    assert isinstance(result, CompilationResult)
    assert result.files == 1
    assert result.time == 0.4
    assert result.target == (3, 5)
    assert result.dependencies == ['dep1.py', 'dep2.py']


# Generated at 2022-06-21 18:37:50.908674
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=3, time=2.3,
                                           target=(3, 5),
                                           dependencies=['d', 'e', 'p'])

    assert compilation_result.files == 3
    assert compilation_result.time == 2.3
    assert compilation_result.target == (3, 5)
    assert compilation_result.dependencies == ['d', 'e', 'p']


# Generated at 2022-06-21 18:37:54.303239
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=None, tree_changed=False, dependencies=[])
    assert tr.tree is None
    assert tr.tree_changed is False
    assert tr.dependencies == []

# Generated at 2022-06-21 18:37:55.323405
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(Path('foo'), Path('bar'))

# Generated at 2022-06-21 18:37:58.202710
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=None,
                                tree_changed=False,
                                dependencies=[])
    assert TransformationResult(tree=None,
                                tree_changed=True,
                                dependencies=[])

# Generated at 2022-06-21 18:38:03.637607
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(1, 45.63, (3, 8), [])
    assert isinstance(compilation_result, CompilationResult)
    assert compilation_result.files == 1
    assert compilation_result.time == 45.63
    assert compilation_result.target == (3, 8)
    assert compilation_result.dependencies == []


# Generated at 2022-06-21 18:38:07.548825
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    import sys
    import os
    from pathlib import Path
    from typed_ast import ast3 as ast
    from typed_ast import parsetypes
    from auto_annotate.ast_transformation import EmptyTransformer, EmptyVisitor


# Generated at 2022-06-21 18:38:57.879030
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # given
    tree = ast.parse('import math')

    # when
    result = TransformationResult.__new__(TransformationResult,
                                          tree,
                                          False,
                                          [])

    # then
    assert result.tree is tree
    assert result.tree_changed is False
    assert result.dependencies == []

# Generated at 2022-06-21 18:39:03.415845
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test_tree = ast.parse('foo = 0')
    test_tree_changed = True
    test_dependencies = ['bar']
    test_transformation = TransformationResult(test_tree, test_tree_changed,
                                               test_dependencies)
    assert test_transformation.tree == test_tree
    assert test_transformation.tree_changed == test_tree_changed
    assert test_transformation.dependencies == test_dependencies

# Generated at 2022-06-21 18:39:05.638174
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('input'), Path('output'))

# Generated at 2022-06-21 18:39:11.771963
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 50
    time = 300
    target = (2, 7)
    dependencies = ["x.py", "y.py"]
    compilation = CompilationResult(files, time, target, dependencies)
    assert isinstance(compilation.files, int)
    assert isinstance(compilation.time, float)
    assert isinstance(compilation.target, CompilationTarget)
    assert isinstance(compilation.dependencies, list)
    assert len(compilation.dependencies) == 2


# Generated at 2022-06-21 18:39:13.779615
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=ast.parse('import os'),
                                tree_changed=False,
                                dependencies=['os'])

# Generated at 2022-06-21 18:39:17.682155
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 2, (1, 2), [])
    assert result.files == 1
    assert result.time == 2
    assert result.target == (1, 2)
    assert result.dependencies == []


# Generated at 2022-06-21 18:39:21.663728
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(tree = 'tree',
                                  tree_changed = True,
                                  dependencies = ['d1', 'd2'])
    assert result.tree == 'tree'
    assert result.tree_changed
    assert result.dependencies == ['d1', 'd2']

# Generated at 2022-06-21 18:39:24.333609
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("assert True")
    tree_changed = True
    dep = "tests/test_asttools.py"
    res = TransformationResult(tree, tree_changed, [dep])
    assert res.tree == tree
    assert res.tree_changed == True
    assert res.dependencies[0] == dep

# Generated at 2022-06-21 18:39:25.417479
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 1.0, (2, 7), ['test_dep'])


# Generated at 2022-06-21 18:39:28.791035
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # pylint: disable=invalid-name
    # pylint: disable=no-member
    # pylint: disable=protected-access
    t = ast.Module()
    r = TransformationResult(t, True, ["a", "b"])
    assert r.tree == t
    assert r.tree_changed == True
    assert r.dependencies == ["a", "b"]
    # pylint: enable=protected-access
    # pylint: enable=no-member
    # pylint: enable=invalid-name