

# Generated at 2022-06-21 18:30:43.390154
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1,
                      time=1.0,
                      target=(2, 7),
                      dependencies=['a'])


# Generated at 2022-06-21 18:30:46.431766
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree, tree_changed, dependencies = ast.parse('x=1'), True, ['my_file.py']
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-21 18:30:50.071264
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(ast.parse('1 + 2'), True, ['foo', 'bar'])
    assert(t.tree == ast.parse('1 + 2'))
    assert(t.tree_changed == True)
    assert(t.dependencies == ['foo', 'bar'])

# Generated at 2022-06-21 18:30:55.699603
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 2, (3, 4), ['3.4'])
    assert result.files == 1
    assert result.time == 2
    assert result.target == (3, 4)
    assert result.dependencies == ['3.4']

# Generated at 2022-06-21 18:31:00.391423
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    t = ast.parse('pass')
    r = TransformationResult(tree=t, tree_changed=True, dependencies=['foo'])
    assert r.tree is t
    assert r.tree_changed is True
    assert r.dependencies == ['foo']

# Generated at 2022-06-21 18:31:02.109791
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(0, 0.0, (0, 0), []) #pylint: disable=unused-variable

# Generated at 2022-06-21 18:31:08.454634
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Test valid constructor
    CompilationResult(1, 1, (1, 1), [])
    # Test invalid constructors
    with pytest.raises(TypeError):
        CompilationResult(1, 1, 1, [])
    with pytest.raises(TypeError):
        CompilationResult(1, 1, (1, 1), 1)


# Generated at 2022-06-21 18:31:18.479083
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Type checks
    CompilationResult(files=1, time=1.0, target=(1, 1),
                      dependencies=['a', 'b'])

    # Value checks
    assert CompilationResult(files=1, time=1.0, target=(1, 1),
                             dependencies=['a', 'b']).files == 1
    assert CompilationResult(files=1, time=1.0, target=(1, 1),
                             dependencies=['a', 'b']).time == 1.0
    assert CompilationResult(files=1, time=1.0, target=(1, 1),
                             dependencies=['a', 'b']).target == (1, 1)
    assert CompilationResult(files=1, time=1.0, target=(1, 1),
                             dependencies=['a', 'b']).dependencies

# Generated at 2022-06-21 18:31:22.717624
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult('123', '345', (), 'test')
    assert result.files == '123'
    assert result.time == '345'
    assert result.target == ()
    assert result.dependencies == 'test'


# Generated at 2022-06-21 18:31:27.991981
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=42.0,
                               target=(3, 4),
                               dependencies=['foo'])
    assert(result.files == 1)
    assert(result.time == 42.0)
    assert(result.target == (3, 4))
    assert(result.dependencies == ['foo'])


# Generated at 2022-06-21 18:31:35.762763
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(1, 2, 3)
    assert t.tree == 1
    assert t.tree_changed == 2
    assert t.dependencies == 3

OutputResult = NamedTuple('OutputResult',
                          [('input', InputOutput),
                           ('result', TransformationResult),
                           ('output', Path),
                           ('time', float)])

# Generated at 2022-06-21 18:31:38.734082
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('')
    result = TransformationResult(tree, False, [])
    assert result.tree_changed == False
    assert result.dependencies == []
    assert result.tree == tree

# Generated at 2022-06-21 18:31:43.144894
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(10, 1.34, (3, 8), ['a', 'b', 'c'])
    assert result.files == 10
    assert result.time == 1.34
    assert result.target == (3, 8)
    assert result.dependencies == ['a', 'b', 'c']


# Generated at 2022-06-21 18:31:46.733492
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(tree=None,
                               tree_changed=False,
                               dependencies=['a', 'b'])
    assert res.tree is None
    assert not res.tree_changed
    assert res.dependencies == ['a', 'b']

# Generated at 2022-06-21 18:31:52.468714
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p = Path('/foo/bar')
    i = InputOutput(p, p)
    assert i.input == p
    assert i.output == p

    i = InputOutput(Path('/foo/bar'), Path('/foo/bar'))
    assert i.input == p
    assert i.output == p


# Generated at 2022-06-21 18:31:56.143791
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = InputOutput(Path('./input'), Path('./output'))
    assert str(input_.input) == 'input'
    assert str(input_.output) == 'output'

# Generated at 2022-06-21 18:32:02.176494
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    from datetime import datetime
    from time import sleep
    start = datetime.now()
    sleep(0.1)
    end = datetime.now()
    assert CompilationResult(files=1, time=(end - start).total_seconds(), target=(2, 7),
                             dependencies=['/usr/include/stdlib.h'])


# Generated at 2022-06-21 18:32:10.974289
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    d = CompilationResult(10, 5.0, (3, 5), ['test.py', 'test2.py'])
    assert d.files == 10
    assert d.time == 5.0
    assert d.target == (3, 5)
    assert d.dependencies == ['test.py', 'test2.py']
    d = CompilationResult(files=10, time=5.0, target=(3, 5),
                          dependencies=['test.py', 'test2.py'])
    assert d.files == 10
    assert d.time == 5.0
    assert d.target == (3, 5)
    assert d.dependencies == ['test.py', 'test2.py']


# Generated at 2022-06-21 18:32:14.504761
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = '/tmp/foo.py'
    out = Path('/tmp/bar.py')
    iop = InputOutput(inp, out)
    assert iop.input == Path(inp)
    assert iop.output == out

# Generated at 2022-06-21 18:32:19.398416
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # GIVEN
    compilation_result_tuple = (5, 1.23, (3, 5), [])
    # WHEN
    compilation_result = CompilationResult(*compilation_result_tuple)
    # THEN
    assert compilation_result.files == 5
    assert compilation_result.time == 1.23
    assert compilation_result.target == (3, 5)
    assert compilation_result.dependencies == []
    assert compilation_result == CompilationResult(*compilation_result)


# Generated at 2022-06-21 18:32:29.310893
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    import astor
    astree = ast.parse('from foo import foo')
    astree.body.append(ast.parse('x = 10').body[0])
    transformation_result = TransformationResult(astree, True, ['foo'])
    assert transformation_result.dependencies == ['foo']
    assert transformation_result.tree_changed
    assert astor.to_source(transformation_result.tree) == 'from foo import foo\nx = 10\n'

# Generated at 2022-06-21 18:32:31.000108
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=12, time=0.0, target=(2, 3), dependencies=[])


# Generated at 2022-06-21 18:32:34.720299
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    s = ast.parse("y = x + 1")
    result = TransformationResult(s, False, [])
    assert result.tree.body[0].targets[0].id == "y"
    assert result.tree_changed == False
    assert result.dependencies == []

# Generated at 2022-06-21 18:32:38.780275
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(1, 2, (3, 4), ["foo", "bar"])
    assert cr.files == 1
    assert cr.time == 2
    assert cr.target == (3, 4)
    assert cr.dependencies == ["foo", "bar"]



# Generated at 2022-06-21 18:32:41.173529
# Unit test for constructor of class InputOutput
def test_InputOutput():
  assert InputOutput(Path('/a/b.py'), Path('/b/c.py'))

# Generated at 2022-06-21 18:32:43.565674
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path("in"), Path("out"))
    assert input_output.input == Path("in")
    assert input_output.output == Path("out")


# Generated at 2022-06-21 18:32:48.613825
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_file = Path('test_input.py')
    output_file = Path('test_output.py')
    i_o = InputOutput(input_file, output_file)
    assert i_o.input == input_file
    assert i_o.output == output_file

# Generated at 2022-06-21 18:32:52.113960
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = Path('/tmp/a')
    b = Path('/tmp/b')
    res = InputOutput(a, b)
    assert res.input == a
    assert res.output == b


# Generated at 2022-06-21 18:32:58.279676
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    comp_result = CompilationResult(files=1,
                                    time=2.2,
                                    target=(3, 4),
                                    dependencies=['A', 'B'])
    assert comp_result.files == 1
    assert comp_result.time == 2.2
    assert comp_result.target[0] == 3
    assert comp_result.target[1] == 4
    assert comp_result.dependencies[0] == 'A'
    assert comp_result.dependencies[1] == 'B'


# Generated at 2022-06-21 18:33:02.460039
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(input = Path("input"),
                               output = Path("output"))
    assert input_output.input.name == "input"
    assert input_output.output.name == "output"


# Generated at 2022-06-21 18:33:10.235411
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('inp')
    outp = Path('outp')
    pair = InputOutput(input=inp, output=outp)
    assert pair.input == inp
    assert pair.output == outp


# Generated at 2022-06-21 18:33:13.610371
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(1, 2.0, (3, 4), [])
    assert cr.files == 1
    assert cr.time == 2.0
    assert cr.target == (3, 4)
    assert cr.dependencies == []


# Generated at 2022-06-21 18:33:18.622842
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(1, 1.0, (3, 7), [])
    assert cr.files == 1
    assert cr.time == 1.0
    assert cr.target == (3, 7)
    assert cr.dependencies == []


# Generated at 2022-06-21 18:33:23.579951
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(files=1, time=1.1, target=(3, 7), dependencies=[])
    assert r.files == 1
    assert r.time == 1.1
    assert r.target == (3, 7)
    assert r.dependencies == []


# Generated at 2022-06-21 18:33:29.414153
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from typed_ast import ast3 as ast
    tr = TransformationResult(ast.Module(), True, ['dependency'])
    assert(tr.tree_changed)
    assert(tr.dependencies == ['dependency'])


# Compilation target for the files
CompilationTarget = NamedTuple('CompilationTarget', [('version', CompilationTarget),
                                                     ('output_dir', Path),
                                                     ('files', List[InputOutput]),
                                                     ('unused', List[InputOutput]),
                                                     ('transformers', List[str])])


# Generated at 2022-06-21 18:33:35.749022
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(0, 0, (0, 0), []).files == 0
    assert CompilationResult(0, 0, (0, 0), []).time == 0
    assert CompilationResult(0, 0, (0, 0), []).target == (0, 0)
    assert CompilationResult(0, 0, (0, 0), []).dependencies == []


# Generated at 2022-06-21 18:33:38.584551
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput('input.py', 'output.py')
    assert io.input == Path('input.py')
    assert io.output == Path('output.py')



# Generated at 2022-06-21 18:33:43.535192
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c1 = CompilationResult(12, 3.2, (3, 5), ['hello'])
    c2 = CompilationResult(12, 3.2, (3, 5), ['hello'])
    assert c1 == c2
    assert c1 != CompilationResult(13, 3.2, (3, 5), ['hello'])

# Generated at 2022-06-21 18:33:48.846581
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.AST()
    dependencies = []
    TransformationResult(tree, True, dependencies)

# Result of handlers transformation
HandlerResult = NamedTuple('HandlerResult',
                           [('handlers', List[str]),
                            ('handlers_changed', bool),
                            ('dependencies', List[str])])


# Generated at 2022-06-21 18:33:53.641449
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=2, time=3.0, target=(3, 7),
                               dependencies=['foo', 'bar'])
    assert result.files == 2
    assert result.time == 3
    assert result.target == (3, 7)
    assert result.dependencies == ['foo', 'bar']


# Generated at 2022-06-21 18:34:06.869327
# Unit test for constructor of class InputOutput
def test_InputOutput():

    # Empty
    assert InputOutput(None, None) == InputOutput(None, None)

    # Empty with both paths
    assert InputOutput(None, None) == InputOutput(Path(''), Path(''))

    # None, None
    assert InputOutput(Path('a'), Path('b')) != \
           InputOutput(Path('c'), Path('d'))

# Generated at 2022-06-21 18:34:09.794952
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('input')
    o = Path('output')
    x = InputOutput((i, o))
    assert x.input == i
    assert x.output == o

# Generated at 2022-06-21 18:34:13.910367
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    data = CompilationResult(files=79, time=89.7, target=(3, 7), dependencies=['c'])
    assert data.files == 79
    assert data.time == 89.7
    assert data.target == (3, 7)
    assert data.dependencies == ['c']


# Generated at 2022-06-21 18:34:14.843352
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(1, 0.0, (2, 7), [])


# Generated at 2022-06-21 18:34:25.338456
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    """
    Test if constructor of TransformationResult works correctly.
    """
    tree = ast.parse('print("Hello World!")')
    dependencies = ['example_dependency_1', 'example_dependency_2']
    ast_result = TransformationResult(tree, True, dependencies)
    # check if tree and dependencies are correct
    assert ast_result.tree == tree
    assert ast_result.dependencies == dependencies
    # check if tree_changed is correct
    assert ast_result.tree_changed == True

    # create another instance of TransformationResult
    tree = ast.parse('print("Hello World!")')
    dependencies = ['example_dependency_1', 'example_dependency_2']
    ast_result = TransformationResult(tree, False, dependencies)

    # check if tree and dependencies are correct

# Generated at 2022-06-21 18:34:28.494858
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """
    Basic test for InputOutput and InputOutput-related functions
    """
    a = InputOutput(Path('a'), Path('b'))
    assert a.input == Path('a')
    assert a.output == Path('b')



# Generated at 2022-06-21 18:34:30.916489
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('a'), Path('b'))

    # Check if fields are set
    assert input_output.input == Path('a')
    assert input_output.output == Path('b')

# Generated at 2022-06-21 18:34:33.761520
# Unit test for constructor of class InputOutput
def test_InputOutput():
    src_path = Path('./module.py')
    dst_path = Path('./module.min.py')
    in_out = InputOutput(src_path, dst_path)

    assert in_out.input == src_path
    assert in_out.output == dst_path

# Generated at 2022-06-21 18:34:40.583593
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    inputs = 1
    time = 1.0
    target = (3, 5)
    dependencies = ['a', 'b']
    result = CompilationResult(files=inputs,
                               time=time,
                               target=target,
                               dependencies=dependencies)
    assert result.files == inputs
    assert result.time == time
    assert result.target == target
    assert result.dependencies == dependencies


# Generated at 2022-06-21 18:34:45.126705
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # pylint: disable=redefined-outer-name
    from typed_ast import ast3 as ast

    tree = ast.Name(id='test')
    result = TransformationResult(
        tree=tree, tree_changed=True, dependencies=[]
    )
    assert result.tree == tree
    assert result.tree_changed is True
    assert result.dependencies == []

# Generated at 2022-06-21 18:35:09.584273
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(tree=ast.parse('x=1'),
                                  tree_changed=True,
                                  dependencies=['foo'])
    assert result.tree is not None
    assert result.tree_changed is not None
    assert result.dependencies is not None

# Generated at 2022-06-21 18:35:13.240217
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    tree = ast.parse('pass')
    res = TransformationResult(tree, True, [])
    assert res.tree is tree
    assert res.tree_changed is True
    assert res.dependencies == []

# Generated at 2022-06-21 18:35:15.371760
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert(TransformationResult(ast.AST(), True, ["foo"]) ==
           TransformationResult(ast.AST(), True, ["foo"]))

# Generated at 2022-06-21 18:35:16.920786
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.AST(), True, [])


# Generated at 2022-06-21 18:35:25.516976
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a'), Path('b')) == InputOutput(Path('a'),
                                                            Path('b'))
    assert InputOutput(Path('a/1'), Path('b/1')) != InputOutput(Path('a/2'),
                                                                Path('b/1'))
    assert InputOutput(Path('a/1'), Path('b/2')) != InputOutput(Path('a/1'),
                                                                Path('b/1'))
    assert InputOutput(Path('a/1'), Path('b/2')) == InputOutput(Path('a/1'),
                                                                Path('b/2'))



# Generated at 2022-06-21 18:35:28.144319
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path('a'), Path('b'))
    assert io.input == Path('a')
    assert io.output == Path('b')

# Generated at 2022-06-21 18:35:30.420657
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse('pass'), True, ['a'])

# Generated at 2022-06-21 18:35:35.551327
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    pair = InputOutput(input, output)
    assert pair.input == input
    assert pair.output == output
    assert pair == InputOutput(input, output)
    assert pair != InputOutput(output, input)
    assert pair != InputOutput(output, output)
    assert pair != InputOutput(input, input)
    assert pair != InputOutput(None, None)

# Generated at 2022-06-21 18:35:39.339990
# Unit test for constructor of class InputOutput
def test_InputOutput():
    import pytest
    i, o = InputOutput(Path('i'), Path('o'))
    for i_, o_ in [('i', 'o'), ('i', ('o',)), ('i', ('o', 'x')), ('i', ('o', 'o'))]:
        with pytest.raises(ValueError):
            InputOutput(i_, o_)


# Generated at 2022-06-21 18:35:42.884395
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path('foo')
    path2 = Path('bar')
    input_output = InputOutput(path1, path2)

    assert input_output.input == path1
    assert input_output.output == path2


# Generated at 2022-06-21 18:36:28.106590
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(1, 2.0, (2, 3), ['x'])
    assert res.files == 1
    assert res.time == 2.0
    assert res.target == (2, 3)
    assert res.dependencies == ['x']


# Generated at 2022-06-21 18:36:30.724485
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=3, time=4, target=(3, 2), dependencies=['a', 'b'])


# Generated at 2022-06-21 18:36:34.666691
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 1.1, (2, 2), [])
    assert result.files == 1
    assert abs(result.time - 1.1) < 0.001
    assert result.target == (2, 2)
    assert result.dependencies == []


# Generated at 2022-06-21 18:36:39.729216
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=1,
                            time=0.1,
                            target=(3, 5),
                            dependencies=['a', 'b'])
    assert res.files == 1
    assert res.time == 0.1
    assert res.target == (3, 5)
    assert res.dependencies == ['a', 'b']


# Generated at 2022-06-21 18:36:45.051714
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i1 = InputOutput(Path('/tmp/a.py'), Path('/tmp/b.py'))
    assert i1.input.name == 'a.py'
    assert i1.output.name == 'b.py'

    i2 = InputOutput('/tmp/c.py', '/tmp/d.py')
    assert i2.input.name == 'c.py'
    assert i2.output.name == 'd.py'

# Generated at 2022-06-21 18:36:46.441219
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput('foo', 'bar') == InputOutput(Path('foo'), Path('bar'))

# Generated at 2022-06-21 18:36:50.109475
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = y + z')
    tree_changed = True
    dependencies = ['a.py', 'b.py']

    TransformationResult(tree, tree_changed, dependencies)  # type: ignore


# Result of transformer/rewriter
TransformerResult = NamedTuple('TransformerResult',
                               [('code', str),
                                ('dependencies', List[str])])


# Generated at 2022-06-21 18:36:54.846855
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    try:
        TransformationResult()
        assert False
    except AssertionError:
        assert True
    except TypeError:
        assert False

    try:
        TransformationResult(tree=None)
        assert False
    except AssertionError:
        assert False
    except TypeError:
        assert True

    try:
        TransformationResult(tree=None, tree_changed=None)
        assert False
    except AssertionError:
        assert False
    except TypeError:
        assert True

    try:
        TransformationResult(tree=None, tree_changed=None, dependencies=None)
        assert False
    except AssertionError:
        assert False
    except TypeError:
        assert True

    try:
        TransformationResult(ast.Module(), False, [])
        assert True
    except TypeError:
        assert False



# Generated at 2022-06-21 18:36:58.705229
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('input')
    output_path = Path('output')
    assert InputOutput(input_path, output_path).input == input_path
    assert InputOutput(input_path, output_path).output == output_path

# Generated at 2022-06-21 18:37:01.859052
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    p = Path('/home/x/y/z.py')
    assert TransformationResult(tree=None, tree_changed=True, dependencies=[p])



# Generated at 2022-06-21 18:38:48.251976
# Unit test for constructor of class CompilationResult
def test_CompilationResult():  # noqa: D103
    result = CompilationResult(1, 2, (3,4), ['a', 'b'])
    assert result.files == 1
    assert result.time == 2
    assert result.target == (3,4)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-21 18:38:49.876407
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('pass')
    TransformationResult(t, True, ['foo', 'bar'])

# Generated at 2022-06-21 18:38:54.235677
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=2,
                               time=1.2,
                               target=(3, 5),
                               dependencies=["module1", "module2"])

    assert result.files == 2
    assert result.time == 1.2
    assert result.target == (3, 5)
    assert result.dependencies == ["module1", "module2"]


# Generated at 2022-06-21 18:38:57.750034
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('foo')
    output = Path('bar')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output

# Generated at 2022-06-21 18:39:01.337733
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('a')
    o = Path('b')
    x = InputOutput(i, o)
    assert isinstance(x, InputOutput)
    assert x.input == i
    assert x.output == o

# Generated at 2022-06-21 18:39:04.007390
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 2.4, (3, 4), ['./lala'])
    assert result.time == 2.4
    assert result.target == (3, 4)
    assert result.dependencies == ['./lala']


# Generated at 2022-06-21 18:39:06.110973
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.AST(), True, [])

# Generated at 2022-06-21 18:39:10.330473
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path("/tmp/input.pb.py")
    output_path = Path("/tmp/output.pb.py")
    io = InputOutput(input_path, output_path)
    assert io.input == input_path
    assert io.output == output_path


# Generated at 2022-06-21 18:39:13.500986
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.Str(s='hello')
    TransformationResult(t, False, [])  # type: ignore # https://github.com/python/mypy/issues/4282
    TransformationResult(t, True, ['path/to/file'])  # type: ignore

# Generated at 2022-06-21 18:39:20.581613
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("a + b")
    module_name = "math"
    dependencies = ["math"]

    tr = TransformationResult(tree, True, dependencies)
    assert isinstance(tr, TransformationResult)
    assert isinstance(tr.tree, ast.AST)
    assert isinstance(tr.dependencies, list)
    assert isinstance(tr.dependencies[0], str)
    assert tr.dependencies == dependencies
    assert tr.tree_changed == True