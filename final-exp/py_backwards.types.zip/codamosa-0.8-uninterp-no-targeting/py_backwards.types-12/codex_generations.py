

# Generated at 2022-06-21 18:30:41.995293
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path("/path/to/input.py")
    output = Path("/path/to/output.py")
    assert InputOutput(input=input, output=output).input == input
    assert InputOutput(input=input, output=output).output == output

# Generated at 2022-06-21 18:30:48.474373
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    from random import randint
    from time import time

    files_number = randint(1, 1000)
    compilation_time = time()
    target = (3, 6)
    dependencies = ["a", "b", "c"]

    compilation_result = CompilationResult(files_number,
                                           compilation_time,
                                           target,
                                           dependencies)

    assert compilation_result.files == files_number
    assert compilation_result.time == compilation_time
    assert compilation_result.target == target
    assert compilation_result.dependencies == dependencies



# Generated at 2022-06-21 18:30:59.373222
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput('a', 'b') == InputOutput(Path('a'), Path('b'))
    assert InputOutput(Path('a'), Path('b')) == InputOutput(Path('a'), Path('b'))
    assert InputOutput('a', 'b') == InputOutput(Path('a'), 'b')
    assert InputOutput(Path('a'), 'b') == InputOutput('b', Path('a'))
    with pytest.raises(TypeError):
        InputOutput('b', 'a') == 1
    with pytest.raises(TypeError):
        InputOutput('b', 'a') == (1, 2)
    with pytest.raises(TypeError):
        InputOutput('b', 'a') == ('b', 'a')

# Generated at 2022-06-21 18:31:04.123398
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    actual = CompilationResult(files=3,
                               time=0.29,
                               target=(3, 7),
                               dependencies=['/somewhere/my_python_file.py'])
    assert actual.files == 3
    assert actual.time == 0.29
    assert actual.target == (3, 7)
    assert actual.dependencies[0] == '/somewhere/my_python_file.py'


# Generated at 2022-06-21 18:31:08.171250
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('/')
    output_path = Path('/tmp/')

    iop = InputOutput(input_path, output_path)

    assert iop.input is input_path
    assert iop.output is output_path


# Generated at 2022-06-21 18:31:12.145198
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compiler_result = CompilationResult(1, 1.0, (3, 7), [])
    assert compiler_result.files == 1
    assert compiler_result.time == 1.0
    assert compiler_result.target == (3, 7)
    assert compiler_result.dependencies == []


# Generated at 2022-06-21 18:31:16.525040
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(1, 1.0, (3, 1), [])
    assert cr.files == 1, 'wrong files in CompilationResult'
    assert cr.time == 1.0, 'wrong time in CompilationResult'
    assert cr.target[0] == 3, 'wrong major version in CompilationResult'
    assert cr.target[1] == 1, 'wrong minor version in CompilationResult'
    assert cr.dependencies == [], 'wrong dependencies in CompilationResult'


# Generated at 2022-06-21 18:31:24.225833
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Empty list of dependencies
    InputOutput([], [])

    # Non-empty list of dependencies
    InputOutput(['input.py', 'output.py'], [])
    InputOutput(['input.pyc', 'output.pyc'], [])
    InputOutput(['input.py', 'output.pyc'], [])

    # With list of dependencies
    InputOutput(['input.py', 'output.py'], ['dep0.py', 'dep1.py'],)


# Generated at 2022-06-21 18:31:28.961548
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(tree=ast.parse('x = 1'),
                               tree_changed=True,
                               dependencies=['some_file'])
    assert res.tree is not None
    assert res.tree_changed is True
    assert isinstance(res.dependencies, list)
    assert isinstance(res.dependencies[0], str)

# Generated at 2022-06-21 18:31:39.710864
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse("abc"), True, []).tree_changed == True

# Marks for tree transformation
Mark = NamedTuple('Mark', [('name', str)])

# Status of magic constant
MagicConstantStatus = NamedTuple('MagicConstantStatus',
                                 [('msg', str),
                                  ('line', int)])

# Status of import
ImportBlock = NamedTuple('ImportBlock',
                         [('module', str),
                          ('names', List[str])])

# Number of lines in a file
NumberOfLines = NamedTuple('NumberOfLines', [('name', str),
                                             ('num', int)])

# Category of constant

# Generated at 2022-06-21 18:31:44.680412
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert isinstance(TransformationResult(ast.parse('print("hello world")'),
                                           True,
                                           ['some_dependency']),
                      TransformationResult)

# Generated at 2022-06-21 18:31:48.103040
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p = Path('/foo/bar/spam/eggs.txt')
    io = InputOutput(input = p, output = p)
    assert io.input == p
    assert io.output == p


# Generated at 2022-06-21 18:31:53.157527
# Unit test for constructor of class CompilationResult
def test_CompilationResult():

    c = CompilationResult(files=1, time=2.3, target=(3, 4), dependencies=['a', 'b'])

    assert c.files == 1
    assert c.time == 2.3
    assert c.target == (3, 4)
    assert c.dependencies == ['a', 'b']


# Generated at 2022-06-21 18:31:59.162298
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=0, time=0.0, target=(3, 6), dependencies=[])
    assert result.files == 0
    assert result.time == 0.0
    assert result.target == (3, 6)
    assert isinstance(result.dependencies, list)
    assert len(result.dependencies) == 0


# Generated at 2022-06-21 18:32:03.908488
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path(__file__)
    output_path = Path(__file__).with_suffix('.out')
    input_output = InputOutput(input_path, output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path


# Generated at 2022-06-21 18:32:07.049276
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    TransformationResult(tree=ast.parse("x=2"), tree_changed=True, dependencies=[])

# Number of sources to compile.
# If number_of_sources == None, all are compiled
number_of_sources: Optional[int] = None

# Generated at 2022-06-21 18:32:09.270609
# Unit test for constructor of class InputOutput
def test_InputOutput():
    x = InputOutput('input', 'output')
    assert x.input == Path('input')
    assert x.output == Path('output')

# Generated at 2022-06-21 18:32:13.227452
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    x = CompilationResult(files=1, time=1.0,
                          target=(3, 5), dependencies=[])
    assert x.files == 1
    assert x.time == 1.0
    assert x.target == (3, 5)
    assert x.dependencies == []


# Generated at 2022-06-21 18:32:18.763786
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io1 = InputOutput(input="foo", output="bar")
    io2 = InputOutput(input=Path("foo"), output=Path("bar"))
    io3 = InputOutput(input="foo", output=Path("bar"))
    io4 = InputOutput(input=Path("foo"), output="bar")

    assert io1.input == io2.input
    assert io2.output == io3.output
    assert io3.input == io4.input
    assert io1.output == io4.output

# Generated at 2022-06-21 18:32:21.559543
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('a.txt')
    o = Path('b.txt')
    assert InputOutput(i, o).input == i
    assert InputOutput(i, o).output == o


# Generated at 2022-06-21 18:32:27.502848
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("print('Hello')")
    result = TransformationResult(tree, tree_changed=True, dependencies=[])
    assert result.tree == tree
    assert result.tree_changed is True
    assert result.dependencies == []

# Generated at 2022-06-21 18:32:31.405917
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("pass", '<string>')
    res = TransformationResult(tree, True, ["foo", "bar"])
    assert res.tree == tree
    assert res.tree_changed == True
    assert res.dependencies == ["foo", "bar"]

# Generated at 2022-06-21 18:32:42.222709
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=2, time=3.3, target=(3, 5),
                          dependencies=['foo', 'bar'])
    assert c.files == 2
    assert c.time == 3.3
    assert c.target == (3, 5)
    assert c.dependencies == ['foo', 'bar']

    # Invalid field name
    try:
        c = CompilationResult(foo=2, time=3.3, target=(3, 5),
                              dependencies=['foo', 'bar'])
        assert False
    except TypeError:
        pass

    # Invalid types
    try:
        c = CompilationResult(files='a', time=3.3, target=(3, 5),
                              dependencies=['foo', 'bar'])
        assert False
    except TypeError:
        pass

# Generated at 2022-06-21 18:32:48.815623
# Unit test for constructor of class InputOutput
def test_InputOutput():
    foo = InputOutput(input=Path('foo'), output=Path('foo2'))
    assert isinstance(foo.input, Path)
    assert isinstance(foo.output, Path)
    assert foo.input == Path('foo')
    assert foo.output == Path('foo2')
    assert foo.input != Path('foo2')
    assert foo.output != Path('foo')
    assert foo.input != foo.output


# Generated at 2022-06-21 18:32:50.229644
# Unit test for constructor of class InputOutput
def test_InputOutput():
    _ = InputOutput(Path('input'), Path('output'))



# Generated at 2022-06-21 18:32:54.338930
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 2, (3, 4), ['a.py'])
    assert result.files == 1
    assert result.time == 2
    assert result.target == (3, 4)
    assert result.dependencies == ['a.py']


# Generated at 2022-06-21 18:32:57.011777
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=1,
                             time=2.0,
                             target=(3, 0),
                             dependencies=['dependency1.py'])


# Generated at 2022-06-21 18:32:59.594817
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse("pass"), False, []).tree_changed is False
    assert TransformationResult(ast.parse("pass"), True, ["a"]).dependencies == ["a"]

# Generated at 2022-06-21 18:33:02.508888
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=42, target=(2, 7), dependencies=['a', 'b'])



# Generated at 2022-06-21 18:33:08.064146
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1,
                           time=199.6,
                           target=(3, 7),
                           dependencies=['a', 'b', 'c'])
    assert cr.files == 1
    assert cr.time == 199.6
    assert cr.target == (3, 7)
    assert cr.dependencies == ['a', 'b', 'c']


# Generated at 2022-06-21 18:33:13.565887
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.AST(), True, None)

# Generated at 2022-06-21 18:33:15.296384
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input=Path("a"), output=Path("b")) == InputOutput(input=Path("a"), output=Path("b"))



# Generated at 2022-06-21 18:33:20.675592
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_file = Path('./input.py')
    output_file = Path('./output.py')
    input_output = InputOutput(input_file, output_file)
    assert input_output.input == input_file
    assert input_output.output == output_file


# Generated at 2022-06-21 18:33:23.198986
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 1.0, (2, 3), [])


# Generated at 2022-06-21 18:33:26.049954
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path(__file__)
    output = Path('output.py')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-21 18:33:29.813037
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('/tutorials/tutorials/tutorials.py')
    output_path = Path('tutorials.py')
    input_output = InputOutput(input_path, output_path)
    assert input_output.input == input_path, "Input not set"
    assert input_output.output == output_path, "Output not set"
    assert input_output.input != input_output.output, "Input and output should not be equal"

# Generated at 2022-06-21 18:33:42.034170
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(3, 2.0, (3, 6), ['foo', 'bar'])
    assert CompilationResult.__doc__ is not None
    assert CompilationResult._field_types is not None
    assert CompilationResult._field_defaults is not None
    assert CompilationResult._field_types['files'] is int
    assert CompilationResult._field_types['time'] is float
    assert CompilationResult._field_types['target'] is CompilationTarget
    assert CompilationResult._field_types['dependencies'] is List[str]
    assert CompilationResult._fields is not None
    assert CompilationResult._fields == ('files', 'time', 'target', 'dependencies')
    names = set()
    for key in CompilationResult.__dict__:
        names.add(key)

# Generated at 2022-06-21 18:33:43.449165
# Unit test for constructor of class InputOutput
def test_InputOutput():
    _ = InputOutput(input=Path("a"), output=Path("b"))

# Generated at 2022-06-21 18:33:45.266775
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    pass
    TransformationResult(ast.AST(), False, [])


# Generated at 2022-06-21 18:33:47.027429
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=0.1, target=(3, 8), dependencies=[])


# Generated at 2022-06-21 18:33:58.628000
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inputs = [('in', 'out'),
              ('in', Path('out')),
              (Path('in'), 'out'),
              (Path('in'), Path('out'))]
    outputs = [InputOutput('in', 'out'),
               InputOutput('in', Path('out')),
               InputOutput(Path('in'), 'out'),
               InputOutput(Path('in'), Path('out'))]

    for (a, b), out in zip(inputs, outputs):
        assert InputOutput(a, b) == out

if __name__ == '__main__':
    test_InputOutput()

# Generated at 2022-06-21 18:34:03.826574
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=3, time=3.3, target=(3, 1),
                            dependencies=['x', 'y'])
    assert res.files == 3
    assert res.time == 3.3
    assert res.target == (3, 1)
    assert res.dependencies == ['x', 'y']


# Generated at 2022-06-21 18:34:09.661642
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 3')
    tree_changed = True
    dependencies = ['test.c']
    r = TransformationResult(tree, tree_changed, dependencies)
    assert(r.tree == tree)
    assert(r.tree_changed == tree_changed)
    assert(r.dependencies == dependencies)

# Generated at 2022-06-21 18:34:10.348044
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    pass

# Generated at 2022-06-21 18:34:12.964758
# Unit test for constructor of class InputOutput
def test_InputOutput():
    result = InputOutput(Path('input'), Path('output'))
    assert result.input == Path('input')
    assert result.output == Path('output')



# Generated at 2022-06-21 18:34:18.281862
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path("a/b.py")
    output = Path("a2/b2.py")
    a = InputOutput(input_, output)
    assert a[0] == input_
    assert a[1] == output
    assert input_ in a
    assert output not in a
    assert a.input == input_
    assert a.output == output
    with pytest.raises(AttributeError):
        a.not_exist


# Generated at 2022-06-21 18:34:25.147154
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """
    Checks if InputOutput works correctly
    """
    current_directory = Path()
    first_module = current_directory / "first_module.py"
    first_module.touch()
    second_module = current_directory / "second_module.py"
    second_module.touch()

    input_output = InputOutput(first_module, second_module)
    assert input_output.input == first_module
    assert input_output.output == second_module

# Generated at 2022-06-21 18:34:28.285911
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('')
    tr = TransformationResult(tree, False, ['dep'])
    assert tr.tree == tree
    assert not tr.tree_changed
    assert tr.dependencies == ['dep']


# Generated at 2022-06-21 18:34:33.945751
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Empty result
    result = TransformationResult(None, False, [])
    assert isinstance(result.tree, ast.AST)
    assert result.tree is None
    assert not result.tree_changed
    assert len(result.dependencies) == 0

    # Full result
    result = TransformationResult(ast.parse('a = 1'), True, ['a', 'b'])
    assert isinstance(result.tree, ast.AST)
    assert not result.tree is None
    assert result.tree_changed
    assert len(result.dependencies) == 2


# Generated at 2022-06-21 18:34:37.451704
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('input')
    output_path = Path('output')
    input_output = InputOutput(input_path, output_path)

    assert input_output.input == input_path
    assert input_output.output == output_path

# Generated at 2022-06-21 18:34:44.003097
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, False, None)


# Generated at 2022-06-21 18:34:48.642567
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(2, 3.14, (3, 7), ['test'])
    assert res.files == 2
    assert res.time == 3.14
    assert res.target == (3, 7)
    assert res.dependencies == ['test']


# Generated at 2022-06-21 18:34:50.360657
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast.parse("ast.parse('print(\"ok\")')")
    TransformationResult(ast.AST(), False, [])

# Generated at 2022-06-21 18:34:53.161368
# Unit test for constructor of class InputOutput
def test_InputOutput():
    iop = InputOutput(Path('foo.py'), Path('bar.py'))

    assert iop.input.name == 'foo.py'
    assert iop.output.name == 'bar.py'

# Generated at 2022-06-21 18:34:55.922283
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(tree=ast.parse('a=1'),
                             tree_changed=True,
                             dependencies=[])
    assert t.tree_changed == True
    assert t.dependencies == []


# Generated at 2022-06-21 18:34:57.318150
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    assert isinstance(TransformationResult(tree, True, []), TransformationResult)

# Generated at 2022-06-21 18:35:00.103051
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(42, 50.0, (3, 5), [])
    assert result.files == 42
    assert result.time == 50.0
    assert result.target == (3, 5)
    assert result.dependencies == []


# Generated at 2022-06-21 18:35:03.846329
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(tree=ast.parse('x = 1'), tree_changed=True, dependencies=[])
    assert t.tree_changed == True


# Generated at 2022-06-21 18:35:07.362081
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path('test1')
    path2 = Path('test2')
    pair = InputOutput(path1, path2)
    assert pair.input == path1
    assert pair.output == path2

# Generated at 2022-06-21 18:35:18.023526
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    with pytest.raises(ValueError) as e:
        CompilationResult(files=1, time=1.0, target=(1, 2), dependencies=['foo'])
    assert 'must be a list' in str(e)

    with pytest.raises(ValueError) as e:
        CompilationResult(files=1, time=1.0, target=(1, 2), dependencies={'foo'})
    assert 'must be a list' in str(e)

    with pytest.raises(ValueError) as e:
        CompilationResult(files=1, time=1.0, target=(1, 2), dependencies=set(['foo']))
    assert 'must be a list' in str(e)


# Generated at 2022-06-21 18:35:34.311512
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.Transformer(), True, []).tree_changed \
        == True
    assert TransformationResult(ast.Transformer(), False, []).tree_changed \
        == False
    assert len(TransformationResult(ast.Transformer(), True,
                                    ["foo.py"]).dependencies) \
        == 1
    assert TransformationResult(ast.Transformer(), False,
                                []).dependencies == []

# Generated at 2022-06-21 18:35:36.439350
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    tr = TransformationResult(tree=None, tree_changed=True,
                              dependencies=None)
    assert tr

# Generated at 2022-06-21 18:35:40.786358
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input=Path(r'C:\test.py'),
                       output=Path(r'C:\test.c'))
    assert InputOutput(input=Path(r'C:\test.py'),
                       output=Path(r'C:\test.c')).input == Path(r'C:\test.py')
    assert InputOutput(input=Path(r'C:\test.py'),
                       output=Path(r'C:\test.c')).output == Path(r'C:\test.c')



# Generated at 2022-06-21 18:35:47.093045
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=5, time=1.5,
                               target=CompilationTarget(3, 6),
                               dependencies=['foo', 'bar'])
    assert result.files == 5
    assert result.time == 1.5
    assert result.target == (3, 6)
    assert result.dependencies == ['foo', 'bar']



# Generated at 2022-06-21 18:35:53.700808
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert not isinstance(TransformationResult(None, True, []), ast.AST)
    assert TransformationResult(None, True, []).tree is None
    assert TransformationResult(None, True, []).tree_changed
    assert not TransformationResult(None, True, []).dependencies
    assert TransformationResult(ast.parse(""), True, [""]).tree
    assert TransformationResult(ast.parse(""), True, [""]).dependencies

# Generated at 2022-06-21 18:35:55.956719
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(0, 0.0, (0, 0), [])


# Generated at 2022-06-21 18:35:58.841455
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path('foo'), Path('bar'))
    assert str(io.input) == 'foo'
    assert str(io.output) == 'bar'


# Generated at 2022-06-21 18:36:02.283051
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path("input")
    output = Path("output")
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-21 18:36:05.972298
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("1")
    assert isinstance(tree, ast.AST)
    tr = TransformationResult(tree, True, ["foo"])
    assert tr.tree_changed
    assert tr.dependencies == ["foo"]

# Generated at 2022-06-21 18:36:07.787764
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    print(TransformationResult(None, False, []))

# No operation

# Generated at 2022-06-21 18:36:31.633697
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('print(1 + 2)')
    result = TransformationResult(tree, True, ['foo.py'])
    assert result

# Test types of attributes

# Generated at 2022-06-21 18:36:36.108797
# Unit test for constructor of class InputOutput
def test_InputOutput():
    dummy_dummy = InputOutput(input=Path('dummy'), output=Path('dummy'))
    # noinspection PyTypeChecker
    dummy_real = InputOutput(input=Path('dummy'), output=Path('dummy/..'))

    assert(dummy_dummy.input == dummy_real.input)
    assert(dummy_dummy.output != dummy_real.output)



# Generated at 2022-06-21 18:36:38.723602
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree_changed = True
    dependencies = ['foo']
    tree = ast.parse('pass')

    TransformationResult(tree=tree,
                         tree_changed=tree_changed,
                         dependencies=dependencies)



# Generated at 2022-06-21 18:36:43.269101
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files = 1, time = 0.12345, target = (3, 6), dependencies = [])
    assert result.files == 1
    assert result.time == 0.12345
    assert result.target == (3, 6)
    assert result.dependencies == []

# Unit tests for constructor of class InputOutput

# Generated at 2022-06-21 18:36:45.799055
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    res = TransformationResult(tree, False, ['foo.py'])
    assert res.tree_changed == False
    assert res.dependencies == ['foo.py']

# Generated at 2022-06-21 18:36:49.139185
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=0,
                               time=0.0,
                               target=(3, 7),
                               dependencies=[])
    assert result.files == 0
    assert result.time == 0.0
    assert result.target == (3, 7)
    assert result.dependencies == []


# Generated at 2022-06-21 18:37:00.335020
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr_1 = CompilationResult(1, 2.0, (3, 4), ["a", "b"])
    assert cr_1.files == 1
    assert cr_1.time == 2.0
    assert cr_1.target == (3, 4)
    assert cr_1.dependencies == ["a", "b"]

    cr_2 = CompilationResult(files = 1,
                             time = 2.0,
                             target = (3, 4),
                             dependencies = ["a", "b"])
    assert cr_2.files == 1
    assert cr_2.time == 2.0
    assert cr_2.target == (3, 4)
    assert cr_2.dependencies == ["a", "b"]



# Generated at 2022-06-21 18:37:08.995894
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # pylint: disable=unused-variable
    # pylint: disable=too-many-function-args
    compilation_result = CompilationResult(files=10,
                                           time=1.0,
                                           target=(2, 7),
                                           dependencies=['foo.py'])

    assert isinstance(compilation_result.files, int)
    assert isinstance(compilation_result.time, float)
    assert isinstance(compilation_result.target, CompilationTarget)
    assert isinstance(compilation_result.dependencies, List)
    assert len(compilation_result.dependencies) == 1


# Generated at 2022-06-21 18:37:11.151709
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast.parse('pass')
    TransformationResult(ast.parse('pass'), True, ['a'])

# Generated at 2022-06-21 18:37:15.265998
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_file = Path('/a/b/c')
    output_file = Path('/d/e/f')
    io = InputOutput(input_file, output_file)
    assert io.input == input_file
    assert io.output == output_file


# Generated at 2022-06-21 18:38:11.140451
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(tree=None,
                               tree_changed=False,
                               dependencies=[])

    assert isinstance(res, TransformationResult)
    assert isinstance(res.tree, type(None))
    assert isinstance(res.tree_changed, bool)
    assert isinstance(res.dependencies, list)

# Generated at 2022-06-21 18:38:12.789802
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=11, time=3.4, target=(3, 6), dependencies=[])


# Generated at 2022-06-21 18:38:14.924551
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(ast.Module(body=[]),
                             True,
                             [])
    assert t.tree is not None
    assert t.tree_changed is True
    assert t.dependencies == []


# Generated at 2022-06-21 18:38:19.472857
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path('a'), Path('b'))
    assert io.input == Path('a')
    assert io.output == Path('b')


# Generated at 2022-06-21 18:38:22.393608
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path("input")
    output = Path("output")
    pair = InputOutput(input, output)
    assert pair.input == input
    assert pair.output == output


# Generated at 2022-06-21 18:38:24.993517
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(3, 0.3, (3, 4), ["a", "b"])


# Generated at 2022-06-21 18:38:29.344784
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    assert TransformationResult(tree, False, [])
    assert TransformationResult(tree, True, [])
    assert TransformationResult(tree, False, ['foo'])
    assert TransformationResult(tree, True, ['foo'])
    assert TransformationResult(tree, False, ['foo', 'bar'])
    assert TransformationResult(tree, True, ['foo', 'bar'])

# Generated at 2022-06-21 18:38:34.202224
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_node = ast.Module([ast.Expr(ast.Num(1))])
    tree, tree_changed, dependencies = TransformationResult(ast_node,
                                                             True,
                                                             ['foo'])
    assert tree.node == ast_node.node
    assert tree_changed is True
    assert dependencies == ['foo']

# Generated at 2022-06-21 18:38:45.174966
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=1,
                             time=0.123,
                             target=(3, 5),
                             dependencies=['foo']) \
        == CompilationResult(files=1,
                             time=0.123,
                             target=(3, 5),
                             dependencies=['foo'])

    assert CompilationResult(files=1,
                             time=0.123,
                             target=(3, 5),
                             dependencies=['foo']) \
        != CompilationResult(files=2,
                             time=0.123,
                             target=(3, 5),
                             dependencies=['foo'])


# Generated at 2022-06-21 18:38:49.954908
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('/home/user/file.py')
    output_path = Path('/home/user/file.pyc')
    input_output = InputOutput(input=input_path, output=output_path)
    assert input_path == input_output.input
    assert output_path == input_output.output
