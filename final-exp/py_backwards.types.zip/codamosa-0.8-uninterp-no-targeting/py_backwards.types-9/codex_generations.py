

# Generated at 2022-06-21 18:30:20.348685
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(None, True, None)

# Generated at 2022-06-21 18:30:23.833244
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0,
                      target=(3, 6), dependencies=['test.py'])
    CompilationResult(files=1, time=1.0,
                      target=(3, 6), dependencies=['test.py'])


# Generated at 2022-06-21 18:30:26.256392
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    a = CompilationResult(files=12, time=0.4, target=(2, 7), dependencies=[])
    assert a.files == 12
    assert a.time == 0.4
    assert a.target == (2, 7)
    assert a.dependencies == []


# Generated at 2022-06-21 18:30:29.084337
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inputs = [Path('/input'),   Path('input')]
    outputs = [Path('/output'), Path('output')]

    for input, output in zip(inputs, outputs):
        pair = InputOutput(input, output)
        assert pair.input == input
        assert pair.output == output

# Generated at 2022-06-21 18:30:30.850810
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # GIVEN
    input_ = Path('input')
    output = Path('output')

    # WHEN
    io = InputOutput(input_, output)

    # THEN
    assert io.input == input_
    assert io.output == output



# Generated at 2022-06-21 18:30:35.070398
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path = Path('/test')
    result = InputOutput(input=path, output=path)
    assert result.input == path
    assert result.output == path

if __name__ == '__main__':
    test_InputOutput()

# Generated at 2022-06-21 18:30:38.820534
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/foo/bar')
    output = Path('/baz')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-21 18:30:43.002774
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Default constructor
    CompilationResult()

    # Parametrized constructor
    CompilationResult(files=1, time=2, target=(3, 4), dependencies=['5', '6'])

    # Another parametrized constructor
    CompilationResult(time=1)

    # Skip constructor with defaulted parameters
    CompilationResult(10)



# Generated at 2022-06-21 18:30:47.337431
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=1, time=1000,
                            target=(2, 3),
                            dependencies=['a.py'])
    assert res.files == 1
    assert res.time == 1000
    assert res.target == (2, 3)
    assert res.dependencies == ['a.py']


# Generated at 2022-06-21 18:30:50.854534
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path("/")
    o = Path("/")
    pair = InputOutput(i, o)
    assert pair.input == i
    assert pair.output == o
    assert pair.input != i
    assert pair.output != o


# Generated at 2022-06-21 18:30:55.730709
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.AST(), False, [])

# Result of transformer
TransformerResult = NamedTuple('TransformerResult',
                               [('result', ast.AST),
                                ('dependencies', List[str])])

# Generated at 2022-06-21 18:30:58.842011
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = 'test.py'
    output = 'compat.py'
    assert InputOutput(Path(input), Path(output))


# Generated at 2022-06-21 18:31:02.392269
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    tree_changed = False
    dependencies = []
    res = TransformationResult(tree, tree_changed, dependencies)
    assert res.tree is tree
    assert res.tree_changed is tree_changed
    assert res.dependencies is dependencies

# Generated at 2022-06-21 18:31:08.892947
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(
        files=10,
        time=10.0,
        target=(3, 7),
        dependencies=['a.py', 'b.py']
    )

    assert result.files == 10
    assert result.time == 10.0
    assert result.target == (3, 7)
    assert result.dependencies == ['a.py', 'b.py']



# Generated at 2022-06-21 18:31:12.038201
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    import tests.test_types
    import tests.test_source_finder
    result = CompilationResult(
        files=1,
        time=1.0,
        target=(3,7),
        dependencies=[tests.test_types, tests.test_source_finder])


# Generated at 2022-06-21 18:31:16.434647
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_name = 'input.py'
    output_name = 'output.py'
    input_output = InputOutput(Path(input_name), Path(output_name))

    assert input_output.input == input_name
    assert input_output.output == output_name

# Generated at 2022-06-21 18:31:27.940524
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    from typing import Any, Dict
    from collections import namedtuple
    from pykaraoke.utils.compilation import CompilationResult
    import sys

    # Create test data
    named_tuple = namedtuple('CompilationResult',
                             ['files', 'time', 'target', 'dependencies'])
    target = sys.version_info.major, sys.version_info.minor
    data: Dict[str, Any] = {'files': 0,
                            'time': 0.0,
                            'target': target,
                            'dependencies': []}

    # Checking the initial state
    assert named_tuple(**data) == CompilationResult(**data)
    assert CompilationResult(**data) == named_tuple(**data)
    assert CompilationResult() == CompilationResult(**data)

# Generated at 2022-06-21 18:31:28.914367
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(None, None, None)

# Generated at 2022-06-21 18:31:37.197495
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('[1, 2, 3]')
    tr = TransformationResult(tree, False, ['foo', 'bar'])
    assert tr.tree == tree
    assert not tr.tree_changed
    assert tr.dependencies == ['foo', 'bar']


# Parameters of transformer to transform input files
TransformerParameters = NamedTuple('TransformerParameters',
                                   [('tree', ast.AST),
                                    ('dependencies', List[str]),
                                    ('input_file', Path),
                                    ('output_file', Path),
                                    ('target', CompilationTarget)])


# Generated at 2022-06-21 18:31:41.631562
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=5, time=2.5, target=(3, 5), dependencies=['a.py'])
    assert result.files == 5
    assert result.time == 2.5
    assert result.target == (3, 5)
    assert result.dependencies == ['a.py']


# Generated at 2022-06-21 18:31:49.511823
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.Module()
    tree_changed = True
    dependencies = []
    res = TransformationResult(tree, tree_changed, dependencies)
    assert res.tree == tree
    assert res.tree_changed == tree_changed
    assert res.dependencies == dependencies
    assert res[0] == tree
    assert res[1] == tree_changed
    assert res[2] == dependencies
    assert res[:2] == (tree, tree_changed)
    assert res[1:] == (tree_changed, dependencies)
    assert res[:1] == (tree,)
    assert res[2:] == (dependencies,)


# Test for the modification of the field

# Generated at 2022-06-21 18:31:51.078102
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('input'),
                       Path('output'))


# Generated at 2022-06-21 18:31:57.954769
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=1.0,
                               target=(3, 7),
                               dependencies=['module.py'])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 7)
    assert result.dependencies == ['module.py']


# Generated at 2022-06-21 18:32:01.737920
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = Path('a.txt')
    b = Path('b.txt')
    InputOutput(a, b)
    InputOutput(input=a, output=b)
    InputOutput(a, b)

# Generated at 2022-06-21 18:32:07.309966
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(
        files=1,
        time=1.1,
        target=(2, 3),
        dependencies=['A.py', 'B.py']
    )
    assert compilation_result.files == 1
    assert compilation_result.time == 1.1
    assert compilation_result.target == (2, 3)
    assert compilation_result.dependencies == ['A.py', 'B.py']


# Generated at 2022-06-21 18:32:12.204685
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1 + 2')
    dependencies = ['file1', 'file3']
    tr = TransformationResult(tree=tree, tree_changed=True,
                              dependencies=dependencies)

    assert isinstance(tr, TransformationResult)
    assert tr.tree == tree
    assert tr.tree_changed == True
    assert tr.dependencies == dependencies

# Generated at 2022-06-21 18:32:16.174789
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_input = Path('test.py')
    test_output = Path('test.out')
    test_inputoutput = InputOutput(test_input, test_output)
    assert test_inputoutput.input == test_input
    assert test_inputoutput.output == test_output



# Generated at 2022-06-21 18:32:19.759133
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    time = 0.123
    target = (3, 5)
    dependencies = ['a', 'b']
    r = CompilationResult(files=2, time=time, target=target,
                          dependencies=dependencies)
    assert r.files == 2
    assert r.time == time
    assert r.target == target
    assert r.dependencies == dependencies


# Generated at 2022-06-21 18:32:22.513130
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    trans_result = TransformationResult(tree={}, tree_changed=False,
                                        dependencies=[])
    assert isinstance(trans_result, TransformationResult)

# Generated at 2022-06-21 18:32:27.908790
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(None, None, None)
    assert t.tree == None
    assert t.tree_changed == None
    assert t.dependencies == None

    t = TransformationResult(1, 2, 3)
    assert t.tree == 1
    assert t.tree_changed == 2
    assert t.dependencies == 3

# Generated at 2022-06-21 18:32:31.593584
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2, (3, 4), [5])

# Generated at 2022-06-21 18:32:34.157135
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(0, 0.0, (3, 6), [])
    assert CompilationResult.__doc__
    assert CompilationResult.__annotations__

# Generated at 2022-06-21 18:32:37.849233
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/usr/local')
    output = Path('/usr/local/bin')
    input_output = InputOutput(input, output)

    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-21 18:32:43.040857
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # type: () -> None
    """
    Tests construction of CompilationResult
    """
    try:
        compilation_result = CompilationResult(1, 1.0,
                                               (2, 3),
                                               ['foo', 'bar'])
        assert isinstance(compilation_result, CompilationResult)
    except Exception:
        assert False


# Generated at 2022-06-21 18:32:45.479762
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1,
                           time=1.0,
                           target=(3, 7),
                           dependencies=['A', 'B'])


# Generated at 2022-06-21 18:32:48.867850
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(None, False, [])
    assert res.tree_changed is False
    assert res.dependencies == []

# Generated at 2022-06-21 18:32:54.190505
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=123, time=456, target=(3, 4),
                           dependencies=['a', 'b', 'c'])
    assert cr.files == 123
    assert cr.time == 456
    assert cr.target == (3, 4)
    assert cr.dependencies == ['a', 'b', 'c']



# Generated at 2022-06-21 18:32:57.511107
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('test_input'), Path('test_output'))
    assert input_output.input.name == 'test_input'
    assert input_output.output.name == 'test_output'



# Generated at 2022-06-21 18:33:00.824340
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('a.py')
    output = Path('a.pyc')
    InputOutput(input, output)

    output = Path('a.pyx')
    InputOutput(input, output)



# Generated at 2022-06-21 18:33:03.066890
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(ast.parse("True"), True, [])
    assert result.tree is not None

# Generated at 2022-06-21 18:33:10.368004
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path('input.py'), Path('output.py'))
    assert io.input == Path('input.py')
    assert io.output == Path('output.py')


# Generated at 2022-06-21 18:33:12.129620
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=2, time=3.0, target=(3, 6), dependencies=[])


# Generated at 2022-06-21 18:33:14.540369
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path("a.py"), Path("b.py"))
    assert io.input == Path("a.py")
    assert io.output == Path("b.py")


# Generated at 2022-06-21 18:33:17.189202
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.,
                               target=(3, 7),
                               dependencies=['foo'])
    assert result.files == 1
    assert result.time == 0.
    assert result.target == (3, 7)
    assert result.dependencies == ['foo']


# Generated at 2022-06-21 18:33:19.220223
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    a = TransformationResult(tree=None, tree_changed=False, dependencies=[])

# Generated at 2022-06-21 18:33:22.798869
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = InputOutput(input=Path('foo'), output=Path('bar'))
    assert i.input == Path('foo')
    assert i.output == Path('bar')


# Generated at 2022-06-21 18:33:26.050265
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('/a/b')
    outp = Path('/c/d')
    io = InputOutput(inp, outp)
    assert io.input == inp
    assert io.output == outp


# Generated at 2022-06-21 18:33:27.652278
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert isinstance(TransformationResult(ast.Module()), TransformationResult)

# Generated at 2022-06-21 18:33:33.132743
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=2, time=33.0, target=(3, 2),
                               dependencies=['foo', 'bar'])
    assert result.files == 2
    assert result.time == 33.0
    assert result.target == (3, 2)
    assert result.dependencies == ['foo', 'bar']



# Generated at 2022-06-21 18:33:37.853517
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    class TestModule(ast.Module):
        _fields = ['body']

    assert isinstance(TransformationResult(TestModule([ast.Expr(ast.Name('a', ast.Load()))]),
                                           True,
                                           ['dep1', 'dep2']),
                      TransformationResult)

# Generated at 2022-06-21 18:33:50.828036
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('/in/foo.py')
    output = Path('/out/foo.py')
    io = InputOutput(input_, output)
    assert io.input == input_
    assert io.output == output

# Generated at 2022-06-21 18:33:55.858659
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=10,
                           time=3.14,
                           target=(3, 7),
                           dependencies=['a', 'b'])
    assert cr.files == 10
    assert cr.time == 3.14
    assert cr.target == (3, 7)
    assert cr.dependencies == ['a', 'b']


# Generated at 2022-06-21 18:33:57.994077
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=0, time=0.0, target=(0, 0), dependencies=[])


# Generated at 2022-06-21 18:33:59.621996
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path(__file__), Path(__file__))



# Generated at 2022-06-21 18:34:03.725684
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """Unit test for constructor of class InputOutput
    """
    i = InputOutput("1", "2")
    assert i.input == "1"
    assert i.output == "2"
    assert i == InputOutput(i.input, i.output)


# Generated at 2022-06-21 18:34:07.954511
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.AST(), False, [])
    assert tr.tree is not None
    assert tr.tree_changed is False
    assert tr.dependencies == []



# Generated at 2022-06-21 18:34:08.627894
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.A

# Generated at 2022-06-21 18:34:10.520635
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2.0, (3, 4), ["foo", "bar"])


# Generated at 2022-06-21 18:34:13.540441
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("pass")
    result = TransformationResult(tree, True, [])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == []

# Generated at 2022-06-21 18:34:15.475500
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('print(1)')
    result = TransformationResult(tree, True, ['abc', 'xyz'])
    assert result.tree == tree
    assert result.tree_changed is True
    assert result.dependencies == ['abc', 'xyz']

# Generated at 2022-06-21 18:34:37.079126
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('my', 'input')
    output_path = Path('my', 'output')
    io_pair = InputOutput(input_path, output_path)
    assert io_pair.input == input_path
    assert io_pair.output == output_path

# Generated at 2022-06-21 18:34:41.824142
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(0, 0.0, (0, 0), [])
    assert result.files == 0
    assert result.time == 0.0
    assert result.target == (0, 0)
    assert result.dependencies == []


# Generated at 2022-06-21 18:34:43.694954
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('foo'), Path('bar')) == InputOutput(Path('foo'), Path('bar'))

# Generated at 2022-06-21 18:34:49.289223
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(1, 3.2, (2, 6), ["a.py", "b.py"])
    assert c.files == 1
    assert c.time == 3.2
    assert c.target == (2, 6)
    assert c.dependencies == ["a.py", "b.py"]

# Generated at 2022-06-21 18:34:51.866801
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('/tmp')
    o = Path('/tmp/hello')
    pair = InputOutput(i, o)
    assert pair.input == i
    assert pair.output == o

# Generated at 2022-06-21 18:34:55.048911
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(1, 2.3, (3, 4), [])
    assert c.files == 1
    assert c.time == 2.3
    assert c.target == (3, 4)
    assert c.dependencies == []



# Generated at 2022-06-21 18:34:56.973706
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(input=Path('1'), output=Path('2'))
    assert io.input == Path('1') and io.output == Path('2')

# Generated at 2022-06-21 18:34:59.523435
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path("/bar/foo.py")
    output = Path("/bar/foo.pyc")
    io = InputOutput(input_, output)
    assert io.input == input_
    assert io.output == output

# Generated at 2022-06-21 18:35:02.025801
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.parse(""), False, [])

# Generated at 2022-06-21 18:35:03.503882
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    try:
        TransformationResult(tree=None, tree_changed=None, dependencies=None)
        print('test_TransformationResult OK')
    except:
        print('test_TransformationResult FAIL')


# Generated at 2022-06-21 18:35:47.051674
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 2.0, (3, 4), ['a'])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == ['a']


# Generated at 2022-06-21 18:35:50.101678
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # type: () -> ()
    Path('a1.py')
    Path('a2.py')
    i = InputOutput(Path('a1.py'), Path('a2.py'))
    assert i.input == Path('a1.py')
    assert i.output == Path('a2.py')

# Generated at 2022-06-21 18:35:59.112826
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.AST(), True,
                                []) == TransformationResult(ast.AST(),
                                                            True,
                                                            [])
    assert TransformationResult(ast.AST(), True,
                                []) != TransformationResult(ast.AST(),
                                                            False,
                                                            [])
    assert TransformationResult(ast.AST(), True,
                                []) != TransformationResult(ast.AST(),
                                                            True,
                                                            ['a'])
    assert TransformationResult(ast.AST(), True,
                                ['d']).dependencies == ['d']

# Generated at 2022-06-21 18:36:01.575851
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_input = Path('test_input')
    test_output = Path('test_output')
    input_output = InputOutput(test_input, test_output)
    assert (input_output.input == test_input) and \
           (input_output.output == test_output)
    

# Generated at 2022-06-21 18:36:07.217708
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a'), Path('b')) == InputOutput(Path('a'), Path('b'))
    assert InputOutput(Path('a'), Path('c')) != InputOutput(Path('a'), Path('b'))
    assert InputOutput(Path('c'), Path('b')) != InputOutput(Path('a'), Path('b'))
    assert str(InputOutput(Path('a'), Path('b'))) == "(a, b)"
    assert repr(InputOutput(Path('a'), Path('b'))) == "InputOutput(input=Path('a'), output=Path('b'))"

# Generated at 2022-06-21 18:36:16.401656
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("True")
    tree_changed = True
    dependencies = []
    tr = TransformationResult(tree, tree_changed, dependencies)
    assert tr.tree == tree
    assert tr.tree_changed == tree_changed
    assert tr.dependencies == dependencies

# Filename of the source code
SourceFile = Path

# Filename of the transformed source code
TransformedSourceFile = Path

# Filename pair
SourceFilePair = Tuple[SourceFile, TransformedSourceFile]

# Input/output path pair
Pair = NamedTuple('Pair', [('input_path', Path),
                           ('output_path', Path)])

# Pair of directory with source files and directory for transformed files
DirectoryPair = NamedTuple('DirectoryPair', [('input', Path),
                                             ('output', Path)])



# Generated at 2022-06-21 18:36:19.957366
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('foo')
    output = Path('bar')
    in_out = InputOutput(input, output)
    assert in_out.input == input
    assert in_out.output == output

# Generated at 2022-06-21 18:36:21.339485
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.Module([]), True, [])

# Generated at 2022-06-21 18:36:25.647677
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    actual = TransformationResult(tree=None, tree_changed=False, dependencies=['foo', 'bar'])
    assert actual.tree is None
    assert not actual.tree_changed
    assert actual.dependencies == ['foo', 'bar']



# Generated at 2022-06-21 18:36:29.401656
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input1 = Path('foo.py')
    output1 = Path('bar.py')

    pair1 = InputOutput(input1, output1)
    assert pair1.input == input1
    assert pair1.output == output1


# Generated at 2022-06-21 18:38:09.747773
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('5')
    res = TransformationResult(t, False, ['a', 'b'])
    assert res == TransformationResult(t, False, ['a', 'b'])
    assert res.tree == t
    assert not res.tree_changed
    assert res.dependencies == ['a', 'b']

# Generated at 2022-06-21 18:38:12.789700
# Unit test for constructor of class InputOutput
def test_InputOutput():
    (input, output) = InputOutput(Path('input.py'), Path('output.py'))
    assert input.name == 'input.py'
    assert output.name == 'output.py'


# Generated at 2022-06-21 18:38:22.671806
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    initial_tree = ast.parse("a = 1")
    assert TransformationResult(initial_tree, True, []) == \
           TransformationResult(initial_tree, True, [])

    assert TransformationResult(initial_tree, True, []) != \
           TransformationResult(initial_tree, False, [])

    assert TransformationResult(initial_tree, True, []) != \
           TransformationResult(initial_tree, True, ["other.py"])

# Configuraton of source files
Config = NamedTuple('Config', [('targets', List[CompilationTarget]),
                               ('inputs', List[InputOutput]),
                               ('transformers', List[str])])

# Generated at 2022-06-21 18:38:28.057760
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(
        files=1,
        time=2,
        target=(3, 4),
        dependencies=['a', 'b', 'c'])

    assert result.files == 1
    assert result.time == 2
    assert result.target[0] == 3
    assert result.target[1] == 4
    assert result.dependencies == ['a', 'b', 'c']


# Generated at 2022-06-21 18:38:31.875408
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=3,
                               time=0.1,
                               target=(3, 5),
                               dependencies=['a.py', 'b.py'])
    assert result.files == 3
    assert result.time == 0.1
    assert result.target == (3, 5)
    assert result.dependencies == ['a.py', 'b.py']


# Generated at 2022-06-21 18:38:36.910728
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=5, time=0.12,
                               target=(2, 6),
                               dependencies=['/module.py'])
    assert result.files == 5
    assert result.time == 0.12
    assert result.target == (2, 6)
    assert result.dependencies == ['/module.py']

# Generated at 2022-06-21 18:38:43.218879
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    foo = TransformationResult(ast.Module(body=[]), False, [])
    assert len(foo.dependencies) == 0
    foo.dependencies.append('foo.py')
    assert len(foo.dependencies) == 1

# Result of a transformer transformation
TransformerResult = NamedTuple('TransformerResult',
                               [('input', InputOutput),
                                ('result', TransformationResult)])


# Generated at 2022-06-21 18:38:46.789086
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=10, time=3.1415, target=(2, 5), dependencies=["/usr/bin/python"])
    assert len(result) == 4
    assert result.files == 10
    assert result.time == 3.1415
    assert result.target == (2, 5)
    assert result.dependencies == ["/usr/bin/python"]


# Generated at 2022-06-21 18:38:51.866536
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Arrange
    tree: ast.AST = ast.parse("f()")
    tree_changed = True
    dependencies = ['foo.py']

    # Act
    tr = TransformationResult(tree, tree_changed, dependencies)

    # Assert
    assert tr.tree == tree
    assert tr.tree_changed == tree_changed
    assert tr.dependencies == dependencies

# Generated at 2022-06-21 18:38:54.584363
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Create
    input_output = InputOutput(Path('input'), Path('output'))
    # Check
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')
