

# Generated at 2022-06-21 18:30:40.596516
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=0, time=0, target=(2, 7), dependencies=[])
    assert isinstance(res, CompilationResult)


# Generated at 2022-06-21 18:30:44.293155
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1, target=(3, 5),
                               dependencies=['./data/example.py'])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 5)
    assert result.dependencies == ['./data/example.py']


# Generated at 2022-06-21 18:30:48.707720
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=1, time=1.5, target=(3, 5), dependencies=['a'])
    assert res.files == 1
    assert res.time == 1.5
    assert res.target == 3, 5
    assert res.dependencies == ['a']


# Generated at 2022-06-21 18:30:54.470941
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1,
                                           time=12.34,
                                           target=(3, 5),
                                           dependencies=["f.py", "g.py"])
    assert compilation_result.files == 1
    assert compilation_result.time == 12.34
    assert compilation_result.target == (3, 5)
    assert compilation_result.dependencies == ["f.py", "g.py"]


# Generated at 2022-06-21 18:30:57.422181
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0,
                      target=(3, 7), dependencies=[])



# Generated at 2022-06-21 18:31:00.016954
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io1 = InputOutput(input="input", output="output")
    assert isinstance(io1.input, Path)
    assert io1.input == "input"
    assert isinstance(io1.output, Path)
    assert io1.output == "output"

# Generated at 2022-06-21 18:31:04.603193
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.Name('tree')
    tree_changed = True
    dependencies = []
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Result of transformer's transformation
TransformationResults = NamedTuple('TransformationResults',
                                   [('results', List[TransformationResult]),
                                    ('dependencies', List[str])])


# Generated at 2022-06-21 18:31:08.219014
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('')
    r = TransformationResult(t, True, ['a'])
    assert r.tree == t
    assert r.tree_changed == True
    assert r.dependencies == ['a']

# Generated at 2022-06-21 18:31:10.984146
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # type: () -> None
    path = Path('__init__.py')
    CompilationResult(
        files=1,
        time=1.0,
        target=(3, 6),
        dependencies=[str(path)]
    )


# Generated at 2022-06-21 18:31:12.440795
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=[])


# Generated at 2022-06-21 18:31:16.635006
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=2, target=(3, 4), dependencies=['foo'])



# Generated at 2022-06-21 18:31:22.681128
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.parse(""), True, [])
    assert tr.tree is not None, "tree is None"
    assert tr.tree_changed is True, "tree_changed is not set to True"
    assert tr.dependencies is not None, "dependencies is None"
    assert len(tr.dependencies) == 0, "wrong number of dependencies"


# Generated at 2022-06-21 18:31:24.617964
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input='a', output='b') == ('a', 'b')

# Generated at 2022-06-21 18:31:28.556553
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input.py')
    output = Path('/tmp/output.py')

    input_output = InputOutput(input, output)

    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-21 18:31:33.144282
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=1, time=1.0, target=(3, 5), dependencies=[])
    assert res.files == 1
    assert res.time == 1.0
    assert res.target == (3, 5)
    assert len(res.dependencies) == 0


# Generated at 2022-06-21 18:31:36.777203
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=2, time=10, target=(3, 7), dependencies=[])
    assert cr.files == 2
    assert cr.time == 10
    assert cr.target == (3, 7)
    assert cr.dependencies == []

# Generated at 2022-06-21 18:31:40.832962
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = '/test/input/'
    outp = '/test/output/'
    io_pair = InputOutput(Path(inp), Path(outp))
    assert io_pair.input == Path(inp)
    assert io_pair.output == Path(outp)


# Generated at 2022-06-21 18:31:43.523102
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput('input.py', 'output.py')
    assert input_output.input == 'input.py'
    assert input_output.output == 'output.py'

# Generated at 2022-06-21 18:31:45.949276
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.Module(body=[])
    assert TransformationResult(tree, True, []) is not None

# Generated at 2022-06-21 18:31:52.061701
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    """
    Test, that TransformationResult is created successfully
    """
    _, tree, _ = ast.parse("a = 0")
    _, res, _ = ast.parse("b = 1")
    TransformationResult(tree, True, ["A", "B"])
    TransformationResult(tree, False, ["A", "B"])
    TransformationResult(res, True, ["A", "B"])
    TransformationResult(res, False, ["A", "B"])
    TransformationResult(tree, True, [])
    TransformationResult(tree, False, [])
    TransformationResult(res, True, [])
    TransformationResult(res, False, [])
    TransformationResult(tree, False, ["A", "B"])

# Generated at 2022-06-21 18:32:01.397885
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=2, time=4.0, target=(3, 6), dependencies=[])
    assert(result.files == 2)
    assert(result.time == 4.0)
    assert(result.target == (3, 6))
    assert(result.dependencies == [])



# Generated at 2022-06-21 18:32:03.115297
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput('test', 'other') == InputOutput(Path('test'), Path('other'))


# Generated at 2022-06-21 18:32:06.146062
# Unit test for constructor of class InputOutput
def test_InputOutput():
    pi = Path('input')
    po = Path('output')
    io = InputOutput(input=pi, output=po)
    assert io.input is pi
    assert io.output is po


# Generated at 2022-06-21 18:32:10.207358
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(1, 3.2, (3, 7), ['blah'])
    assert(res.files == 1)
    assert(res.time == 3.2)
    assert(res.target == (3, 7))
    assert(res.dependencies == ['blah'])


# Generated at 2022-06-21 18:32:14.785833
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(1, 0.01, (3, 5), ['foo.py', 'bar.py'])
    assert c[0] == 1
    assert c[1] == 0.01
    assert c[2] == (3, 5)
    assert c[3] == ['foo.py', 'bar.py']


# Generated at 2022-06-21 18:32:15.900273
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(0, 0, (3, 0), [])


# Generated at 2022-06-21 18:32:16.709467
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, None, None) is not None

# Generated at 2022-06-21 18:32:22.560228
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.parse('1'), False, [])
    assert isinstance(tr, tuple) and len(tr) == 3

# Class to define a transformer (name, execution mode, constructor)
TransformerDescription = NamedTuple(
    'TransformerDescription', [('name', str),
                               ('mode', str),
                               ('constructor', 'Callable[[], BaseTransformer]')])


# Generated at 2022-06-21 18:32:28.769104
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test_tree = ast.parse('1 + 1')
    expected_tree = ast.parse('1 + 1')
    res = TransformationResult(test_tree, False, ['test_dependency'])
    assert(res.tree == expected_tree)
    assert(res.tree_changed == False)
    assert(res.dependencies == ['test_dependency'])

# Generated at 2022-06-21 18:32:30.603785
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path_in = Path('path')
    path_out = Path('other_path')
    input_output = InputOutput(path_in, path_out)
    assert input_output.input == path_in
    assert input_output.output == path_out

# Unit test of constructor of class TransformationResult

# Generated at 2022-06-21 18:32:37.353741
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('foo'), Path('bar')) == InputOutput(Path('foo'), Path('bar'))


# Generated at 2022-06-21 18:32:42.008813
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    tree_changed = True

    res = TransformationResult(tree=tree,
                               tree_changed=tree_changed,
                               dependencies=[])
    assert res.tree == tree
    assert res.tree_changed == tree_changed
    assert res.dependencies == []


# Generated at 2022-06-21 18:32:44.062375
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path = Path('/path/to/file')
    inout = InputOutput(path, path)
    assert inout.input == path
    assert inout.output == path

# Generated at 2022-06-21 18:32:45.914688
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput('a', 'b') == InputOutput(Path('a'), Path('b'))

# Generated at 2022-06-21 18:32:49.747738
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 1.2, (3, 6), []) == CompilationResult(1, 1.2, (3, 6), [])


# Generated at 2022-06-21 18:32:53.903395
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(1, 5.5, (3, 7), ['a', 'b'])
    assert cr.files == 1
    assert cr.time == 5.5
    assert cr.target == (3, 7)
    assert cr.dependencies == ['a', 'b']

# Generated at 2022-06-21 18:32:55.486423
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    _ = CompilationResult(0, 0, (3, 4), [])

# Generated at 2022-06-21 18:32:57.955979
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Creating the object
    io = InputOutput(Path('a'), Path('b'))
    # Checking data
    assert io.input == Path('a')
    assert io.output == Path('b')



# Generated at 2022-06-21 18:33:00.879271
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=5, time=0.5, target=(2, 7),
                      dependencies=['path1', 'path2'])


# Generated at 2022-06-21 18:33:05.375239
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_tree = ast.parse('a = 1')
    tree = TransformationResult(ast_tree, True, ['foo', 'bar'])
    assert tree.tree == ast_tree
    assert tree.tree_changed is True
    assert tree.dependencies == ['foo', 'bar']

# Generated at 2022-06-21 18:33:10.934633
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, False, None)


# Generated at 2022-06-21 18:33:12.768383
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from ast import parse
    from .transformers import Transformer

# Generated at 2022-06-21 18:33:15.149196
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path(__file__), Path(__file__))
    assert input_output.input == Path(__file__) and input_output.output == Path(__file__)

# Generated at 2022-06-21 18:33:18.621085
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput('dir/input', 'dir/output')
    assert io.input == Path('dir/input')
    assert io.output == Path('dir/output')



# Generated at 2022-06-21 18:33:25.815757
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from random import random
    from ast_transformer.ast_tools.utils import parse_file
    dir_path = Path(__file__).parent
    tree = parse_file(dir_path / 'resources/empty.py')
    tr = TransformationResult(tree, bool(random()), [])
    assert isinstance(tr.tree, ast.AST)
    assert isinstance(tr.tree_changed, bool)
    assert isinstance(tr.dependencies, List)


# Generated at 2022-06-21 18:33:28.824368
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """Test the constructor of class InputOutput"""

    test_input = Path(__file__)
    test_output = Path(__file__) + '.out'
    iopair = InputOutput(test_input, test_output)

    assert iopair.input == test_input
    assert iopair.output == test_output



# Generated at 2022-06-21 18:33:31.355893
# Unit test for constructor of class InputOutput
def test_InputOutput():
    in_file_path = Path("in.txt")
    out_file_path = Path("out.txt")

    io = InputOutput(input=in_file_path, output=out_file_path)

    assert io.input == in_file_path
    assert io.output == out_file_path


# Generated at 2022-06-21 18:33:33.143544
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/some/path/to/my/file.py')
    output = Path('/other/path/to/my/file.py')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-21 18:33:35.134716
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p = Path('foo')
    io = InputOutput(input=p, output=p)
    assert io.i

# Generated at 2022-06-21 18:33:40.501148
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('/home/user/input.py')
    output_path = Path('/home/user/output.py')

    pair = InputOutput(input=input_path,
                       output=output_path)

    assert pair.input == input_path
    assert pair.output == output_path


# Generated at 2022-06-21 18:33:50.196869
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=20, target=(3, 5),
                               dependencies=['a', 'b', 'c'])
    assert result.files == 1
    assert result.time == 20
    assert result.target == (3, 5)
    assert result.dependencies == ['a', 'b', 'c']



# Generated at 2022-06-21 18:33:53.175483
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_tree = ast.parse('a = 1 + 2')
    res = TransformationResult(ast_tree, True, [])
    assert res.tree_changed == True
    assert res.dependencies == []

    res = TransformationResult(ast_tree, False, ['a.py'])
    assert res.tree_changed == False
    assert res.dependencies == ['a.py']

# Generated at 2022-06-21 18:33:55.157978
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    class Dummy(ast.AST):
        pass

    t = TransformationResult(Dummy(), False, [])



# Generated at 2022-06-21 18:34:00.304207
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree: ast.AST = ast.parse("")
    TransformationResult(tree, True, [])
    TransformationResult(tree, False, [])

# The position of node in the source
Position = NamedTuple('Position',
                      [('line', int),
                       ('col', int),
                       ('absolute', int)])


# Generated at 2022-06-21 18:34:03.574772
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = 'input'
    output = 'output'
    ioutput = InputOutput(input, output)
    assert ioutput.input == input
    assert ioutput.output == output



# Generated at 2022-06-21 18:34:11.549982
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path = Path('a/b/c.py')
    input_output = InputOutput(path, path / '__pycache__' / 'c.cpython-36.pyc')
    assert input_output.input.name == 'c.py'
    assert input_output.input.suffix == '.py'
    assert input_output.output.name == 'c.cpython-36.pyc'
    assert input_output.output.suffix == '.pyc'


# Generated at 2022-06-21 18:34:14.561882
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a'), Path('b')).input.name == 'a'
    assert InputOutput(Path('a'), Path('b')).output.name == 'b'


# Generated at 2022-06-21 18:34:25.052233
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result1 = CompilationResult(files=1, time=0., target=(3, 8),
                                dependencies=['foo'])
    result2 = CompilationResult(files=1, time=0., target=(3, 8),
                                dependencies=['foo'])
    result3 = CompilationResult(files=2, time=0., target=(3, 8),
                                dependencies=['foo'])
    result4 = CompilationResult(files=1, time=1., target=(3, 8),
                                dependencies=['foo'])
    result5 = CompilationResult(files=1, time=0., target=(3, 7),
                                dependencies=['foo'])
    result6 = CompilationResult(files=1, time=0., target=(3, 8),
                                dependencies=['bar'])
    assert result1 == result2

# Generated at 2022-06-21 18:34:28.579940
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(10, 20, (3,7), ["a", "b"])
    assert res.files == 10
    assert res.time == 20
    assert res.target == (3,7)
    assert res.dependencies == ["a", "b"]


# Generated at 2022-06-21 18:34:31.598258
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('a/b/c')
    output_path = Path('a/b/d')
    input_output = InputOutput(input_path, output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path

# Generated at 2022-06-21 18:34:43.543584
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("1+1")
    result = TransformationResult(tree, False, [])
    assert result.tree == tree
    assert result.tree_changed == False
    assert result.dependencies == []

# Generated at 2022-06-21 18:34:45.848035
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 1.0, (1, 1), [])

# Test __repr__ method

# Generated at 2022-06-21 18:34:51.121770
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('')
    t_changed = True
    class_deps = ['a', 'b']
    tr = TransformationResult(t, t_changed, class_deps)
    assert tr.tree == t
    assert tr.tree_changed == t_changed
    assert tr.dependencies == class_deps

# Generated at 2022-06-21 18:34:53.008828
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p = Path(".")

    assert InputOutput(p, p)
    assert InputOutput(p, p).input == p
    assert InputOu

# Generated at 2022-06-21 18:34:54.551932
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(Path('/tmp/foo.py'), Path('/tmp/bar.py'))


# Generated at 2022-06-21 18:34:57.973844
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=0,
                            time=0,
                            target=(3, 6),
                            dependencies=['a'])
    assert res.files == 0
    assert res.time == 0
    assert res.target == (3, 6)
    assert res.dependencies == ['a']


# Generated at 2022-06-21 18:34:59.585596
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(0, 0, (0, 0), []) == CompilationResult(0, 0, (0, 0), [])


# Generated at 2022-06-21 18:35:01.615008
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('aaa/bbb')
    output = Path('aaa/eee')
    input_output = InputOutput(input, output)
    assert input_output.input is input and input_output.output is output


# Generated at 2022-06-21 18:35:04.672809
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(None, None) == InputOutput(None, None)
    assert InputOutput('', '') == InputOutput('', '')
    assert InputOutput(Path(''), Path('')) == InputOutput('', '')



# Generated at 2022-06-21 18:35:10.837952
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=2.0,
                           target=(3, 4), dependencies=['a', 'b'])
    assert cr.files == 1
    assert cr.time == 2.0
    assert cr.target == (3, 4)
    assert cr.dependencies == ['a', 'b']


# Generated at 2022-06-21 18:35:32.578077
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/foo.py')
    output = Path('/tmp/bar.py')
    io = InputOutput(input=input, output=output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-21 18:35:34.678040
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(None, False, None)
    assert res.dependencies is None
    assert res.tree is None
    assert not res.tree_changed

# Generated at 2022-06-21 18:35:35.596711
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(Path('a'), Path('b'))

# Generated at 2022-06-21 18:35:38.925144
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input='1', output='2').input == '1'
    assert InputOutput(input='1', output='2').output == '2'
    assert len(InputOutput('1', '2')) == 2
    assert len(InputOutput(input='1', output='2')) == 2


# Generated at 2022-06-21 18:35:44.154127
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=2.34, target=(3, 4), dependencies=["test"])
    assert cr.files == 1
    assert cr.time == 2.34
    assert cr.target == (3, 4)
    assert cr.dependencies == ["test"]


# Generated at 2022-06-21 18:35:47.688200
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(1, 0.5, (3, 5), [])
    assert cr.files == 1
    assert cr.time == 0.5
    assert cr.target == (3, 5)
    assert cr.dependencies == []

# Generated at 2022-06-21 18:35:52.370318
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('x/y/z.txt')
    output = Path('a/b/c.txt')
    inout = InputOutput(input_, output)
    assert inout.input == input_
    assert inout.output == output

# Generated at 2022-06-21 18:35:56.005675
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # When constructing
    a = InputOutput(Path('a'), Path('b'))
    # Then there must be no error
    assert a.input == Path('a')
    assert a.output == Path('b')

# Generated at 2022-06-21 18:36:02.586978
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a'), Path('b')) == InputOutput('a', 'b')
    assert InputOutput(Path('a/b'), Path('c/d')) == InputOutput('a/b', 'c/d')
    assert InputOutput('a', 'b') == InputOutput('a', 'b')
    assert InputOutput('a/b', 'c/d') == InputOutput('a/b', 'c/d')

# Generated at 2022-06-21 18:36:04.115129
# Unit test for constructor of class CompilationResult
def test_CompilationResult():  # type: () -> None
    CompilationResult(1, 2.0, (3, 4), [])


# Generated at 2022-06-21 18:36:51.073309
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(4, 5.0, (3, 7), ['a', 'b'])
    assert res.files == 4
    assert res.time == 5.0
    assert res.target == (3, 7)
    assert res.dependencies == ['a', 'b']


# Generated at 2022-06-21 18:36:53.404815
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path = Path('.')
    input_output = InputOutput(path, path)
    assert input_output.input == path
    assert input_output.output == path


# Generated at 2022-06-21 18:36:59.113936
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(1, 2.0, (3, 4), ['d1', 'd2'])
    assert compilation_result.files == 1
    assert compilation_result.time == 2.0
    assert compilation_result.target == (3, 4)
    assert compilation_result.dependencies == ['d1', 'd2']



# Generated at 2022-06-21 18:37:09.157478
# Unit test for constructor of class InputOutput
def test_InputOutput():
    with pytest.raises(AssertionError):
        InputOutput('a', 'b')
    with pytest.raises(AssertionError):
        InputOutput(Path('a'), 'b')
    with pytest.raises(AssertionError):
        InputOutput('a', Path('b'))
    with pytest.raises(AssertionError):
        InputOutput(Path('a'), 'b')
    i, o = InputOutput(Path('a'), Path('b'))
    assert i.__eq__(Path('a'))
    assert o.__eq__(Path('b'))
    assert i.__class__ is Path
    assert o.__class__ is Path


# Generated at 2022-06-21 18:37:14.978586
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1,
                               target=(3, 7),
                               dependencies=['readme.txt'])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 7)
    assert result.dependencies == ['readme.txt']



# Generated at 2022-06-21 18:37:17.813654
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 1.1, (3, 7), []) == \
           CompilationResult(1, 1.1, (3, 7), [])

# Generated at 2022-06-21 18:37:19.854474
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert isinstance(CompilationResult(0, 0.0, (3, 7), []), CompilationResult)


# Generated at 2022-06-21 18:37:24.660599
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Prepare data
    input_path = Path('input/path')
    output_path = Path('output/path')
    # Execute
    result = InputOutput(input_path, output_path)
    # Verify
    assert result.input == input_path
    assert result.output == output_path


# Generated at 2022-06-21 18:37:30.613168
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Arrange
    tree = ast.parse('x=0')
    tree_changed = False
    dependencies = ['foo1', 'foo2']

    # Act
    tr = TransformationResult(tree, tree_changed, dependencies)

    # Assert
    assert tr.tree == tree
    assert tr.tree_changed == tree_changed
    assert tr.dependencies == dependencies

# Generated at 2022-06-21 18:37:36.124380
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = 'a/b/c'
    out = 'd/e/f'
    res = InputOutput(input=Path(inp), output=Path(out))
    assert res.input.name == 'c'
    assert res.input.parent.name == 'b'
    assert res.input.parent.parent.name == 'a'

    assert res.output.name == out
    assert res.output.parent.name == 'e'
    assert res.output.parent.parent.name == 'd'

# Generated at 2022-06-21 18:39:13.733381
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.Module()
    result = TransformationResult(tree, True, [])
    assert result.tree == tree
    assert result.tree_changed
    assert result.dependencies == []

# Generated at 2022-06-21 18:39:17.640946
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('a.py')
    output_path = Path('b.py')
    io = InputOutput(input_path, output_path)
    assert io.input == input_path
    assert io.output == output_path

# Generated at 2022-06-21 18:39:23.690539
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse(""), True, []).tree_changed

# Result of transformation of file
TransformationFileResult = NamedTuple('TransformationFileResult',
                                      [('tuples', List[InputOutput]),
                                       ('target', CompilationTarget),
                                       ('dependencies', List[str])])

# Result of transformation of all files in directory
TransformationDirectoryResult = NamedTuple('TransformationDirectoryResult',
                                           [('tuples', List[TransformationFileResult]),
                                            ('dependencies', List[str])])

# Generated at 2022-06-21 18:39:25.231232
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('input.txt')
    o = Path('output.txt')
    io = InputOutput(i, o)

    assert io.input is i
    assert io.output is o

# Generated at 2022-06-21 18:39:26.028773
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(tree=None, tree_changed=False, dependencies=[])



# Generated at 2022-06-21 18:39:31.450528
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # pylint: disable=unnecessary-lambda
    path = lambda f: (Path.cwd() / f)
    # pylint: enable=unnecessary-lambda
    io = InputOutput(input=path('input.py'), output=path('output.py'))
    assert io.input == path('input.py')
    assert io.output == path('output.py')


# Generated at 2022-06-21 18:39:38.392340
# Unit test for constructor of class CompilationResult
def test_CompilationResult():

    assert CompilationResult(3, 7.5, (3, 6), ['file1', 'file2']).files == 3
    assert CompilationResult(3, 7.5, (3, 6), ['file1', 'file2']).time == 7.5
    assert CompilationResult(3, 7.5, (3, 6), ['file1', 'file2']).target == (3, 6)
    assert CompilationResult(3, 7.5, (3, 6), ['file1', 'file2']).dependencies == ['file1', 'file2']


# Generated at 2022-06-21 18:39:40.221924
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.Module()
    result = TransformationResult(tree, False, ['abc', 'def'])
    assert result.tree == tree
    assert result.tree_changed == False
    assert result.dependencies == ['abc', 'def']

# Generated at 2022-06-21 18:39:42.790581
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    tree = ast.parse('pass')
    target = (3, 0)
    result = CompilationResult(files=1,
                               time=0.0,
                               target=target,
                               dependencies=[])
    assert result.files == 1
    assert result.time == 0.0
    assert result.target == target
    assert result.dependencies == []


# Generated at 2022-06-21 18:39:47.616995
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=10, time=2.3, target=(3, 7),
                          dependencies=['a', 'b'])
    
    assert c.files == 10
    assert c.time == 2.3
    assert c.target == (3, 7)
    assert c.dependencies == ['a', 'b']
