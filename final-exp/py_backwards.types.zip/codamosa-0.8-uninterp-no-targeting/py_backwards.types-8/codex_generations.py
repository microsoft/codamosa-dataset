

# Generated at 2022-06-21 18:30:41.447165
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse('pass'), False, [])
    assert TransformationResult(ast.parse('pass'), True, [])
    assert TransformationResult(ast.parse('pass'), False, ['a', 'b'])
    assert TransformationResult(ast.parse('pass'), True, ['a', 'b'])

# Generated at 2022-06-21 18:30:42.796735
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    T = TransformationResult
    t = T(tree=None, tree_changed=True, dependencies=[])

# Generated at 2022-06-21 18:30:46.010598
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    tree_changed = True
    dependencies = ['a.py']
    tr = TransformationResult(tree, tree_changed, dependencies)
    assert tr.tree == tree
    assert tr.tree_changed == tree_changed
    assert tr.dependencies == dependencies

# Generated at 2022-06-21 18:30:50.576446
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t_result = TransformationResult(tree=object(),
                                    tree_changed=False,
                                    dependencies=[])
    assert t_result.tree != None
    assert t_result.tree_changed == False
    assert t_result.dependencies == []

# Check if compilation target is 2.7

# Generated at 2022-06-21 18:30:53.765240
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files = 1,
                      time = 1.0,
                      target = (3, 6),
                      dependencies = [])


# Generated at 2022-06-21 18:30:59.612203
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(ast.parse('x = 2'),
                                  False,
                                  ['module1', 'module2'])
    assert isinstance(result, NamedTuple)
    assert isinstance(result.tree, ast.AST)
    assert isinstance(result.tree_changed, bool)
    assert isinstance(result.dependencies, list)

# Generated at 2022-06-21 18:31:04.017360
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Arrange
    files = 10
    time = 0.15
    target = (2, 7)
    dependencies = ['foo', 'bar']

    # Act
    c = CompilationResult(files, time, target, dependencies)

    # Assert
    assert c.files == files
    assert c.time == time
    assert c.target == target
    assert c.dependencies == dependencies


# Generated at 2022-06-21 18:31:08.564907
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    import astor
    tree = ast.parse('x = 2')

    res = TransformationResult(tree, False, ['a', 'b'])

    assert res.tree == tree
    assert res.tree_changed == False
    assert res.dependencies == ['a', 'b']

# Generated at 2022-06-21 18:31:10.727792
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input='foo', output='bar') == \
           InputOutput(input=Path('foo'), output=Path('bar'))

# Generated at 2022-06-21 18:31:14.668681
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Given
    input_path = Path(__file__).parent.joinpath('input')
    output_path = Path(__file__).parent.joinpath('output')

    # When
    result = InputOutput(input_path, output_path)
    # Then
    assert result.input == input_path
    assert result.output == output_path


# Generated at 2022-06-21 18:31:22.213917
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 0.1, (0, 0), [])
    assert CompilationResult(1, 0.1, (0, 0), ['a'])
    assert CompilationResult(1, 0.1, (0, 0), ['a', 'b'])


# Generated at 2022-06-21 18:31:26.076274
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=2,
                               target=(3, 4),
                               dependencies=['file1.py'])
    assert isinstance(result, CompilationResult), \
        "Class CompilationResult wrongly defined"


# Generated at 2022-06-21 18:31:37.021537
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    class TDummy(ast.AST):
        pass

    dummy_tree = TDummy()

    # Test that a dummy tree can be cast to TransformationResult
    tr = TransformationResult(tree=dummy_tree, tree_changed=True, dependencies=[])
    assert tr.tree == dummy_tree

    tr = TransformationResult(tree=dummy_tree, tree_changed=False, dependencies=[])
    assert tr.tree == dummy_tree

    tr = TransformationResult(tree=dummy_tree, tree_changed=False, dependencies=['a', 'b'])
    assert tr.tree == dummy_tree

    tr = TransformationResult(tree=dummy_tree, tree_changed=True, dependencies=['a', 'b'])
    assert tr.tree == dummy_tree

# Transformation of a file

# Generated at 2022-06-21 18:31:42.185176
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1,
                                           time=1,
                                           target=(3, 7),
                                           dependencies=['a.py'])
    assert compilation_result.files == 1
    assert compilation_result.time == 1
    assert compilation_result.target == (3, 7)
    assert compilation_result.dependencies == ['a.py']


# Generated at 2022-06-21 18:31:45.123690
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    assert input != output
    assert InputOutput(input, output).input == input
    assert InputOutput(input, output).output == output


# Generated at 2022-06-21 18:31:47.794700
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('/a'), Path('/b')) == InputOutput(input=Path('/a'),
                                                              output=Path('/b'))


# Generated at 2022-06-21 18:31:53.113517
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c1 = CompilationResult(5, 5.5, (3, 7), [])
    c2 = CompilationResult(5, 5.5, (3, 7), [])
    c3 = CompilationResult(5, 5.5, (3, 6), [])
    assert c1 == c2
    assert c1 != c3
    assert hash(c1) == hash(c2)
    assert hash(c1) != hash(c3)
    assert repr(c1) == "CompilationResult(files=5, time=5.5, target=(3, 7), dependencies=[])"
    assert str(c1) == "CompilationResult(files=5, time=5.5, target=(3, 7), dependencies=[])"


# Generated at 2022-06-21 18:32:00.090130
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Create instance of TransformationResult
    tr = TransformationResult(ast.parse('pass', '', 'exec'),
                              True,
                              [])
    # Check structure
    assert tr.tree_changed == True
    assert tr.dependencies == []
    assert hasattr(tr.tree, 'body')
    # Check that the tree is the right type
    assert isinstance(tr.tree, ast.AST)


# Generated at 2022-06-21 18:32:05.070986
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 2 + 3')
    dependencies = ['a', 'b', 'c']

    tr = TransformationResult(tree, True, dependencies)
    assert isinstance(tr.tree_changed, bool)
    assert isinstance(tr.tree, ast.AST)
    assert isinstance(tr.dependencies, List[str])

# Generated at 2022-06-21 18:32:09.035154
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(2, 3.14, (3, 7), ['a', 'b'])
    assert cr.files == 2
    assert cr.time == 3.14
    assert cr.target == (3, 7)
    assert cr.dependencies == ['a', 'b']


# Generated at 2022-06-21 18:32:15.811673
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 2.0, (3, 4), ['a', 'b'])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == ['a', 'b']



# Generated at 2022-06-21 18:32:19.200565
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    import time
    cres = CompilationResult(2, time.time(), (2, 7), ['a', 'b'])
    assert cres.files == 2
    assert isinstance(cres.time, float)
    assert cres.target == (2, 7)
    assert cres.dependencies == ['a', 'b']


# Generated at 2022-06-21 18:32:28.769402
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from dataclasses import _MISSING_TYPE

    assert TransformationResult(
        tree=_MISSING_TYPE,
        tree_changed=True,
        dependencies=['path']).tree_changed
    assert not TransformationResult(
        tree=_MISSING_TYPE,
        tree_changed=False,
        dependencies=['path']).tree_changed


# Result of compilation of single file
FileCompilationResult = NamedTuple('FileCompilationResult',
                                   [('input', Path),
                                    ('output', Path),
                                    ('succesful', bool),
                                    ('time', float)])


# Generated at 2022-06-21 18:32:30.109893
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(0, 0, (0, 0), [])


# Generated at 2022-06-21 18:32:31.682620
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path_input = '/home/user/input.py'
    path_output = '/home/user/output.py'
    in_out = InputOutput(path_input, path_output)
    assert in_out.input == path_input
    assert in_out.output == path_output

# Generated at 2022-06-21 18:32:38.140840
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(Path('input'), Path('output'))
    try:
        InputOutput(str('input'), str('output'))
        assert False
    except TypeError:
        pass
    try:
        InputOutput(Path('input'), str('output'))
        assert False
    except TypeError:
        pass
    try:
        InputOutput(str('input'), Path('output'))
        assert False
    except TypeError:
        pass


# Generated at 2022-06-21 18:32:39.931358
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_input = "test_input"
    test_output = "test_output"
    input_output = InputOutput(test_input, test_output)
    assert input_output.input == test_input
    assert input_output.output == test_output

# Generated at 2022-06-21 18:32:41.424124
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2, 3, [])


# Generated at 2022-06-21 18:32:42.586780
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 1, (3, 5), [])


# Generated at 2022-06-21 18:32:43.704929
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('./input'), Path('./output'))

# Generated at 2022-06-21 18:32:56.772712
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_input = Path('test_input.py')
    test_output = Path('test_output.py')
    test_pair = InputOutput(input=test_input, output=test_output)
    assert test_pair.output == test_output
    assert test_pair.input == test_input



# Generated at 2022-06-21 18:33:00.377198
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_tree = ast.parse("A = 2")
    tr = TransformationResult(ast_tree, False, ["A"])
    assert tr.tree is ast_tree
    assert tr.tree_changed is False
    assert tr.dependencies == ["A"]

# Generated at 2022-06-21 18:33:02.658201
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2.0, (2, 3), ['test'])


# Generated at 2022-06-21 18:33:04.665647
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    import numpy as np
    TransformationResult(np.array([]), True, [])

# Generated at 2022-06-21 18:33:08.762982
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    x = CompilationResult(100, 1.0, (3, 4), ['a', 'b'])
    assert x.files == 100
    assert x.time == 1.0
    assert x.target == (3, 4)
    assert x.dependencies == ['a', 'b']


# Generated at 2022-06-21 18:33:13.289436
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_tree = ast.parse('foo')
    trans_res = TransformationResult(tree=ast_tree,
                                     tree_changed=True,
                                     dependencies=['foo', 'bar'])
    assert trans_res.tree is ast_tree
    assert trans_res.tree_changed is True
    assert trans_res.dependencies == ['foo', 'bar']

# Generated at 2022-06-21 18:33:18.251459
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(
                        files = 10,
                        time = 0.0,
                        target = (3, 6),
                        dependencies = ['a', 'b', 'c']
    )
    assert isinstance(compilation_result, CompilationResult)


# Generated at 2022-06-21 18:33:24.796328
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_input = Path('input')
    test_output = Path('output')
    input_output = InputOutput(test_input, test_output)
    assert input_output.input == test_input
    assert str(input_output.input) == str(test_input)
    assert input_output.output == test_output
    assert str(input_output.output) == str(test_output)


# Generated at 2022-06-21 18:33:28.310336
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=None,
                                tree_changed=False,
                                dependencies=[])


# Result of runner transformation
RunResult = NamedTuple('RunResult',
                       [('time', float),
                        ('output', str),
                        ('return_code', int)])

# Generated at 2022-06-21 18:33:36.241937
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput("input", "output") == InputOutput(Path("input"),
                                                         Path("output"))
    with pytest.raises(AssertionError):
        InputOutput("input", 1)
    with pytest.raises(AssertionError):
        InputOutput(1, "output")
    with pytest.raises(AssertionError):
        InputOutput()
    with pytest.raises(AssertionError):
        InputOutput(None, "output")


# Generated at 2022-06-21 18:33:57.756655
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = _CompilationResult(1, 2.0, (3, 4), [])
    assert compilation_result.files == 1
    assert compilation_result.time == 2.0
    assert compilation_result.target == (3, 4)
    assert compilation_result.dependencies == []


# Generated at 2022-06-21 18:34:03.776581
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('1 + 2')
    tree_changed = True
    dependencies = ['a.py']
    transformation_result = TransformationResult(tree=tree,
                                                  tree_changed=tree_changed,
                                                  dependencies=dependencies)
    assert transformation_result.tree == tree
    assert transformation_result.tree_changed == tree_changed
    assert transformation_result.dependencies == dependencies

# Generated at 2022-06-21 18:34:10.150909
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(100, 1.0, (3, 4), ['a', 'b'])
    assert compilation_result.files == 100
    assert compilation_result.time == 1.0
    assert compilation_result.target == (3, 4)
    assert compilation_result.dependencies == ['a', 'b']

# Generated at 2022-06-21 18:34:19.661100
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('inp.txt')
    out = Path('out.txt')
    a = InputOutput(inp, out)
    assert a.input == inp
    assert a.output == out
    assert InputOutput(inp, out) == InputOutput(inp, out)
    assert InputOutput(inp, out) != InputOutput(Path('N.inp'), out)
    assert InputOutput(inp, out) != InputOutput(inp, Path('N.out'))
    assert InputOutput(inp, out) != InputOutput(Path('N.inp'), Path('N.out'))
    assert str(InputOutput(inp, out)) == 'InputOutput(input=inp.txt, ' \
                                         'output=out.txt)'

# Generated at 2022-06-21 18:34:25.517572
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=1,
                            time=0.0001,
                            target=(3, 7),
                            dependencies=['file.py'])
    assert res.files == 1
    assert res.time == 0.0001
    assert res.target == (3, 7)
    assert res.dependencies == ['file.py']


# Generated at 2022-06-21 18:34:26.794425
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput('input', 'output')  # type: ignore


# Generated at 2022-06-21 18:34:28.556277
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=10, time=2.2, target=(3, 5), dependencies=["a", "b"])

# Generated at 2022-06-21 18:34:31.507998
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(
        input=Path("C:\\source\\input_file.py"),
        output=Path("C:\\source\\compiled\\output_file.py"))
    assert input_output.input == Path("C:\\source\\input_file.py")
    assert input_output.output == Path("C:\\source\\compiled\\output_file.py")

# Generated at 2022-06-21 18:34:34.230253
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_input = Path("test/foo.py")
    test_output = Path("test/bar.py")
    assert test_input == InputOutput(test_input, test_output).input
    assert test_output == InputOutput(test_input, test_output).output

# Generated at 2022-06-21 18:34:41.050831
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree={}, tree_changed=True, dependencies=['a', 'b'])
    tr.tree
    tr.tree_changed
    tr.dependencies
    assert 'tree' in str(tr)
    assert 'tree_changed' in str(tr)
    assert 'dependencies' in str(tr)

# Set of paths
PathSet = NamedTuple('PathSet', [('paths', List[Path])])


# Generated at 2022-06-21 18:35:22.000791
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    trans_res = TransformationResult(ast.AST(), False, [])
    assert trans_res.tree is not None
    assert trans_res.tree_changed is False
    assert trans_res.dependencies is not None


# Generated at 2022-06-21 18:35:26.138045
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=['a', 'b'])
    assert cr.files == 1
    assert cr.time == 2.0
    assert cr.target == (3, 4)
    assert cr.dependencies == ['a', 'b']


# Generated at 2022-06-21 18:35:32.109321
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 42.0, (3, 7), ["/tmp/abc/def.py"])
    assert result.files == 1
    assert result.time == 42.0
    assert result.target == (3, 7)
    assert result.dependencies == ["/tmp/abc/def.py"]


# Generated at 2022-06-21 18:35:35.323359
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = 'input'
    output = 'output'
    input_output = InputOutput(input, output)
    assert input_output.input == 'input'
    assert input_output.output == 'output'


# Generated at 2022-06-21 18:35:39.841597
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1, 
                                           time=2.3,
                                           target=(3, 4),
                                           dependencies=['a.py', 'b.py'])
    assert compilation_result.files == 1
    assert compilation_result.time == 2.3
    assert compilation_result.target == (3, 4)
    assert compilation_result.dependencies == ['a.py', 'b.py']


# Generated at 2022-06-21 18:35:44.152490
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path(__file__)
    output = Path('/tmp/test.py')
    inout = InputOutput(input=input, output=output)
    assert inout.input == input
    assert inout.output == output

# Generated at 2022-06-21 18:35:47.333660
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path_input = Path('input')
    path_output = Path('output')

    io = InputOutput(path_input, path_output)

    assert io.input == path_input
    assert io.output == path_output

# Generated at 2022-06-21 18:35:50.998291
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(0, 0, (0, 0), [])
    assert result.target == (0, 0)



# Generated at 2022-06-21 18:35:55.529262
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = 'path1'
    path2 = 'path2'
    input_output = InputOutput(input=path1, output=path2)
    assert input_output.input == path1
    assert input_output.output == path2


# Generated at 2022-06-21 18:35:59.569039
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=[])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == []


# Generated at 2022-06-21 18:36:46.572457
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path(__file__)
    output_path = input_path.with_suffix('.pyc')
    input_output = InputOutput(input_path, output_path)
    assert input_output.input == input_path and input_output.output == output_path


# Generated at 2022-06-21 18:36:49.506565
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Arrange
    tree = ast.AST()
    tree_changed = True
    dependencies = []

    # Act
    t = TransformationResult(tree, tree_changed, dependencies)

    # Assert
    assert t.tree == tree
    assert t.tree_changed == tree_changed
    assert t.dependencies == dependencies

# Generated at 2022-06-21 18:36:51.942981
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2.3, (3, 4), ['a', 'b'])



# Generated at 2022-06-21 18:36:57.917992
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1,
                           time=.5,
                           target=(3, 5),
                           dependencies=['a', 'b', 'c'])
    assert cr.files == 1
    assert cr.time == .5
    assert cr.target == (3, 5)
    assert set(cr.dependencies) == {'a', 'b', 'c'}


# Generated at 2022-06-21 18:37:02.778463
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0,
                               target=(3, 6), dependencies=[])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 6)
    assert result.dependencies == []



# Generated at 2022-06-21 18:37:04.980740
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Create InputOutput instance
    input_output = InputOutput(input=Path('input'), output=Path('output'))
    # Check
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')

# Generated at 2022-06-21 18:37:08.831952
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Default constructor
    assert InputOutput(Path('foo'), Path('bar')) == InputOutput(Path('foo'), Path('bar'))

    # Constructor
    assert InputOutput('foo', 'bar') == InputOutput(Path('foo'), Path('bar'))

# Generated at 2022-06-21 18:37:18.418660
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    module = ast.parse('print(2)')
    tree = TransformationResult(tree=module, tree_changed=False,
                                dependencies=[])
    assert (tree.tree, tree.tree_changed, tree.dependencies) == (module, False, [])

# Class of type commands
Commands = NamedTuple('Commands',
                      [('import_modules', List[str]),
                       ('make_tree', Callable),
                       ('modify_tree', Callable),
                       ('make_code', Callable),
                       ('modify_code', Callable),
                       ('get_target', CompilationTarget)])


# Generated at 2022-06-21 18:37:22.147678
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('print(1)')
    result = TransformationResult(tree, True, ['dep1', 'dep2'])
    assert (result.tree == tree)
    assert (result.tree_changed == True)
    assert (result.dependencies == ['dep1', 'dep2'])


# Generated at 2022-06-21 18:37:24.289583
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 42.0, (3, 4), ['foo', 'bar'])

# Generated at 2022-06-21 18:38:22.353115
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p1 = Path('/tmp/a')
    p2 = Path('/tmp/b')
    assert InputOutput(p1, p2) == InputOutput(p1, p2)
    assert InputOutput(p1, p2) != InputOutput(p2, p1)
    assert InputOutput(p1, p2) == InputOutput(Path('/tmp/a'), Path('/tmp/b'))

# Generated at 2022-06-21 18:38:26.339622
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    a = TransformationResult(ast.Module([]), True, [])
    b = TransformationResult(ast.Module([]), True, [])
    print('a == b', a == b)
    assert a == b

# PEP 0448 syntax

# Generated at 2022-06-21 18:38:28.491845
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(tree=123, tree_changed=True, dependencies=[])
    assert result.tree == 123 and result.tree_changed == True and result.dependencies == []

# Generated at 2022-06-21 18:38:32.000499
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=0,
                                           time=0.0,
                                           target=(3, 0),
                                           dependencies=[])

    assert compilation_result.files == 0
    assert compilation_result.time == 0.0
    assert compilation_result.target == (3, 0)
    assert compilation_result.dependencies == []


# Generated at 2022-06-21 18:38:34.059269
# Unit test for constructor of class InputOutput
def test_InputOutput():
    import tempfile
    tf = tempfile.NamedTemporaryFile()
    i = InputOutput(Path('1'), Path('2'))
    assert i.input == Path('1')
    assert i.output == Path('2')

# Generated at 2022-06-21 18:38:41.451765
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1,
                               target=(3, 8),
                               dependencies=['one', 'two'])

    assert result.files == 1
    assert result.time == 0.1
    assert result.target[0] == 3
    assert result.target[1] == 8
    assert len(result.dependencies) == 2
    assert result.dependencies[0] == 'one'
    assert result.dependencies[1] == 'two'


# Generated at 2022-06-21 18:38:42.034142
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    pass

# Generated at 2022-06-21 18:38:43.646815
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path.cwd(), Path.cwd())


# Generated at 2022-06-21 18:38:47.695339
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('t.py')
    output = Path('t.pyo')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output
    assert io.input != io.output
    assert io.input != io.output

# Generated at 2022-06-21 18:38:51.105939
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = InputOutput(Path('a'), Path('b'))
    assert inp.input == Path('a')
    assert inp.output == Path('b')
    assert inp.input == str(inp.input)
    assert inp.output == str(inp.output)

# Generated at 2022-06-21 18:39:53.333920
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult((None, False, []))

# Result of the parsing phase
ParseResult = NamedTuple('ParseResult', [('tree', ast.AST),
                                         ('fname', str)])

# Result of transformers analysis
TransformationAnalysisResult = NamedTuple('TransformationAnalysisResult',
                                          [('tree', ast.AST),
                                           ('tree_changed', bool),
                                           ('dependencies', List[str])])


# Generated at 2022-06-21 18:39:55.380387
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # type: () -> None
    CompilationResult(files=1, time=1.0, target=(3, 5), dependencies=['a', 'b'])



# Generated at 2022-06-21 18:39:59.037504
# Unit test for constructor of class InputOutput
def test_InputOutput():
    files = [InputOutput(Path('input'), Path('output')),
             InputOutput(input=Path('input'), output=Path('output')),
             InputOutput(Path('input'), output=Path('output')),
             InputOutput(input=Path('input'), output=Path('output'))]

    assert all(f.input.name == 'input' for f in files)
    assert all(f.output.name == 'output' for f in files)

# Generated at 2022-06-21 18:40:04.758171
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_value = Path('/home/user/file.py')
    output_value = Path('/home/user/file.pyc')

    input_output = InputOutput(input_value, output_value)

    assert input_output.input == input_value
    assert input_output.output == output_value



# Generated at 2022-06-21 18:40:11.185650
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = [
        InputOutput(Path('foo.py'), Path('foo.py.out')),
        InputOutput(Path('/bar/bar.py'), Path('/bar/bar.py.out')),
        InputOutput(Path('/bar/baz'), Path('/bar/baz')),
        InputOutput(Path('/bar/baz/'), Path('/bar/baz/'))
    ]
    for io in input_output:
        assert io.input != io.output, str(io)
    assert True, 'Everything is fine.'



# Generated at 2022-06-21 18:40:14.141357
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    fake_tree = ast.parse('x = 1')
    fake_dependencies = ['a.py']
    tr = TransformationResult(tree=fake_tree, tree_changed=True,
                              dependencies=fake_dependencies)
    assert tr.tree is fake_tree
    assert tr.tree_changed is True
    assert tr.dependencies == fake_dependencies


# Generated at 2022-06-21 18:40:16.888477
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input.py')
    output = Path('/tmp/output.py')

    io = InputOutput(input, output)

    assert io.input == input
    assert io.output == output

# Generated at 2022-06-21 18:40:23.212851
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult.__doc__ == 'Information about compilation'
    assert CompilationResult.files.__doc__ == 'files: Number of files'
    assert CompilationResult.time.__doc__ == 'time: Comilation time'
    assert CompilationResult.target.__doc__ == 'target: Compilation target'
    assert CompilationResult.dependencies.__doc__ == 'dependencies: External dependencies'


# Generated at 2022-06-21 18:40:26.643252
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path('file1')
    path2 = Path('file2')
    input_output = InputOutput(path1, path2)
    assert input_output.input is path1
    assert input_output.output is path2


# Generated at 2022-06-21 18:40:29.812571
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_ = ast.parse('pass')
    transformation_result = TransformationResult(ast_, False, [])
    assert isinstance(transformation_result.tree, ast.AST)
    assert not transformation_result.tree_changed
    assert isinstance(transformation_result.dependencies, list)