

# Generated at 2022-06-21 18:30:34.143294
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(0, 0.0, (3, 7), [])

# Generated at 2022-06-21 18:30:36.293800
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inputoutput = InputOutput(Path('input'), Path('output'))
    assert inputoutput.input == Path('input')
    assert inputoutput.output == Path('output')


# Generated at 2022-06-21 18:30:40.026367
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('/tmp/in.txt')
    output = Path('/tmp/out.txt')
    input_output = InputOutput(input_, output)
    assert input_output.input == input_
    assert input_output.output == output

# Generated at 2022-06-21 18:30:42.867894
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('test')
    output = Path('test.pyc')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output



# Generated at 2022-06-21 18:30:48.282403
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    a = CompilationResult(files=1, time=1.0, target=(3, 0),
                          dependencies=['a.py'])
    assert a.files == 1
    assert a.time == 1.0
    assert a.target == (3, 0)
    assert a.dependencies == ['a.py']
    assert a == CompilationResult(1, 1.0, (3, 0), ['a.py'])


# Generated at 2022-06-21 18:30:51.313287
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=None, tree_changed=False, dependencies=None).tree is None
    assert TransformationResult(tree=None, tree_changed=False, dependencies=None).tree_changed is False
    assert TransformationResult(tree=None, tree_changed=False, dependencies=None).dependencies is None

# Generated at 2022-06-21 18:31:00.485341
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    dummy_tree = ast.AST()
    dummy_dependencies = ['a', 'b']
    test_case = TransformationResult(dummy_tree, False, dummy_dependencies)
    assert test_case.tree is dummy_tree
    assert test_case.tree_changed is False
    assert test_case.dependencies is dummy_dependencies


# Entry point for preprocessor
# based on the input file
# it creates an output file
# which imports all required modules
# and consists of inlined parts
# of the original source code

# Generated at 2022-06-21 18:31:02.818730
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    TransformationResult(tree = ast.Str(s = "str"),
                         tree_changed = True,
                         dependencies = [])


# Generated at 2022-06-21 18:31:05.579222
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 1.5, (3, 5), ['list.py', 'math.py'])



# Generated at 2022-06-21 18:31:10.317798
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Given
    input_path = 'input.txt'
    output_path = 'output.txt'

    # When
    io_pair = InputOutput(input=input_path,
                          output=output_path)

    # Then
    assert io_pair.input == input_path
    assert io_pair.output == output_path

# Generated at 2022-06-21 18:31:13.291123
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(Path('foo'), Path('bar'))

# Generated at 2022-06-21 18:31:19.947818
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=4, time=3.14, target=(3, 6),
                                           dependencies=['foo', 'bar'])
    assert compilation_result.files == 4
    assert compilation_result.time == 3.14
    assert compilation_result.target == (3, 6)
    assert compilation_result.dependencies == ['foo', 'bar']


# Generated at 2022-06-21 18:31:23.977133
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('input').with_suffix('.js')
    actual = InputOutput(input, output)
    assert actual.input == input
    assert actual.output == output


# Generated at 2022-06-21 18:31:26.628275
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 2.0, (3, 4),
                             ['test_CompilationResult_1.py',
                              'test_CompilationResult_2.py'])

# Generated at 2022-06-21 18:31:28.467734
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(42, 42.0, (3, 6), [])


# Generated at 2022-06-21 18:31:32.075978
# Unit test for constructor of class InputOutput
def test_InputOutput():
    dummy_input = Path('dummy')
    dummy_output = Path('dummy')
    assert (dummy_input, dummy_output) == InputOutput(dummy_input, dummy_output).input, InputOutput(dummy_input, dummy_output).output

# Generated at 2022-06-21 18:31:42.282461
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.parse('a = 1'),
                              True,
                              ['a.py', 'b.py', 'c.py'])
    assert tr == TransformationResult(ast.parse('a = 1'),
                                      True,
                                      ['a.py', 'b.py', 'c.py'])
    assert not tr == TransformationResult(ast.parse('a = 1'),
                                          False,
                                          ['a.py', 'b.py', 'c.py'])
    assert not tr == TransformationResult(ast.parse('a = 2'),
                                          True,
                                          ['a.py', 'b.py', 'c.py'])

# Generated at 2022-06-21 18:31:48.958096
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("pass")
    assert TransformationResult(tree, True, []) == TransformationResult(tree, True, [])
    assert TransformationResult(tree, True, []) != TransformationResult(tree, False, [])
    assert TransformationResult(tree, True, []) != TransformationResult(tree, True, ["a_dependency"])
    assert TransformationResult(tree, True, []) == TransformationResult(tree, True, [])
    assert TransformationResult(tree, True, []) != TransformationResult(tree, False, [])
    assert TransformationResult(tree, True, []) != TransformationResult(tree, True, ["a_dependency"])

# Generated at 2022-06-21 18:31:50.995311
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput([], [])  # type: ignore


# Generated at 2022-06-21 18:31:54.138468
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1,
                           time=2,
                           target=(3, 4),
                           dependencies=['a', 'b'])
    assert cr.files == 1
    assert cr.time == 2
    assert cr.target == (3, 4)
    assert cr.dependencies == ['a', 'b']


# Generated at 2022-06-21 18:31:58.436450
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1337, 420.0, (3, 7), ['foo', 'bar'])

# Generated at 2022-06-21 18:32:02.417514
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    result = TransformationResult(tree, True, ['foo.py'])
    assert result.tree is tree
    assert result.tree_changed is True
    assert result.dependencies == ['foo.py']

# Generated at 2022-06-21 18:32:05.870702
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('input_file')
    o = Path('output_file')
    io = InputOutput(input=i, output=o)
    assert io.input == i
    assert io.output == o
    assert io == io

# Generated at 2022-06-21 18:32:09.131418
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('input')
    o = Path('output')
    assert InputOutput(input=i, output=o) == InputOutput(input=i, output=o)

# Unit tests for method is_invalid_compilation_target

# Generated at 2022-06-21 18:32:10.854792
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 1.2, (3, 4), ['a', 'b'])


# Generated at 2022-06-21 18:32:14.032348
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.AST(), False, []).tree
    assert not TransformationResult(ast.AST(), False, []).tree_changed
    assert TransformationResult(ast.AST(), False, []).dependencies == []

# Generated at 2022-06-21 18:32:16.445840
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input.py')
    output = Path('output.py')
    inout = InputOutput(input, output)
    assert inout.input == input
    assert inout.output == output

# Generated at 2022-06-21 18:32:19.209044
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(ast.Module(), True, [])
    assert result.tree is not None
    assert result.tree_changed is not None
    assert result.dependencies is not None

# Generated at 2022-06-21 18:32:24.747497
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(1, 5, (3, 7), ['./one', './two'])
    assert compilation_result.files == 1
    assert compilation_result.time == 5
    assert compilation_result.target == (3, 7)
    assert compilation_result.dependencies == ['./one', './two']


# Generated at 2022-06-21 18:32:27.409206
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('input'), Path('output'))
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')

# Generated at 2022-06-21 18:32:34.772016
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path('foo/bar')
    path2 = Path('baz/qux')
    input_output = InputOutput(path1, path2)

    assert input_output.input == path1
    assert input_output.output == path2


# Generated at 2022-06-21 18:32:39.574989
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    tr = TransformationResult(ast.parse("def foo(x): pass"), True, ['foo'])
    assert tr.tree_changed
    assert tr.dependencies == ['foo']
    tr = TransformationResult(ast.parse("def foo(x): pass"), False, [])
    assert not tr.tree_changed

# Generated at 2022-06-21 18:32:44.128223
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    code = 'pass'
    tree = ast.parse(code)
    tree_changed = True
    dependencies = []
    transformation_result = TransformationResult(tree, tree_changed, dependencies)

    assert transformation_result.tree == tree
    assert transformation_result.tree_changed == tree_changed
    assert transformation_result.dependencies == dependencies


# Generated at 2022-06-21 18:32:50.935139
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.Module(body=[])
    r = TransformationResult(
        tree,
        tree_changed=True,
        dependencies=['/a/b/c', '/d/e/f'])
    assert r.tree == tree
    assert r.tree_changed == True
    assert r.dependencies == ['/a/b/c', '/d/e/f']


# Generated at 2022-06-21 18:32:54.071695
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('foo')
    out = Path('bar')
    pair = InputOutput(inp, out)
    assert pair.input == inp
    assert pair.output == out


# Generated at 2022-06-21 18:32:57.154653
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("a = 1")
    TransformationResult(tree, True, [])
    TransformationResult(tree, False, [])
    TransformationResult(tree, False, ["dependency"])

# Generated at 2022-06-21 18:33:02.056102
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    example = CompilationResult(1, 0.1, (3, 5), ['foo/bar'])
    assert example.files == 1
    assert example.time == 0.1
    assert example.target == (3, 5)
    assert example.dependencies == ['foo/bar']


# Generated at 2022-06-21 18:33:03.457232
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('input'), Path('output'))


# Generated at 2022-06-21 18:33:08.036883
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1\n', mode='eval')
    assert isinstance(tree, ast.Expression)

    res = TransformationResult(tree=tree, tree_changed=True, dependencies=[])
    assert res.tree == tree
    assert res.tree_changed == True
    assert res.dependencies == []

# Generated at 2022-06-21 18:33:12.332309
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    path = Path("test")
    result = TransformationResult(
        tree = ast.parse("pass"), tree_changed = False, dependencies = [str(path)]
    )
    assert(isinstance(result.tree, ast.AST))
    assert(result.tree_changed == False)
    assert (result.dependencies == [str(path)])

# Generated at 2022-06-21 18:33:27.226841
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(
        files=1,
        time=1.5,
        target=(2, 7),
        dependencies=['a', 'b']
    )

    assert cr.files == 1
    assert cr.time == 1.5
    assert cr.target == (2, 7)
    assert cr.dependencies == ['a', 'b']


# Generated at 2022-06-21 18:33:29.887329
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = 'input'
    output = 'output'
    pair = InputOutput(input, output)
    assert pair.input == input
    assert pair.output == output


# Generated at 2022-06-21 18:33:35.856152
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 23
    time = 0.5
    target = (2, 3)
    dependencies = ['bla', 'bla/bla']
    r = CompilationResult(files, time, target, dependencies)
    assert r.files == files
    assert r.time == time
    assert r.target == target
    assert r.dependencies == dependencies

# Generated at 2022-06-21 18:33:39.400730
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert len(TransformationResult._fields) == 3
    assert TransformationResult._fields[0] == 'tree'
    assert TransformationResult._fields[1] == 'tree_changed'
    assert TransformationResult._fields[2] == 'dependencies'

# Generated at 2022-06-21 18:33:41.682512
# Unit test for constructor of class TransformationResult
def test_TransformationResult(): # type: () -> None
    assert isinstance(TransformationResult(ast.AST(), False, []),
                      TransformationResult)

# Generated at 2022-06-21 18:33:45.415242
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('a.txt')
    out = Path('b.txt')

    input_output = InputOutput(inp, out)

    assert input_output.input == inp
    assert input_output.output == out


# Generated at 2022-06-21 18:33:51.853850
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=5, time=0.5,
                                           target=(3, 5),
                                           dependencies=['a', 'b', 'c'])
    assert compilation_result.files == 5
    assert compilation_result.time == 0.5
    assert compilation_result.target == (3, 5)
    assert compilation_result.dependencies == ['a', 'b', 'c']


# Generated at 2022-06-21 18:33:55.670757
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=0, time=0.0, target=(3, 6), dependencies=[])
    assert cr.files == 0
    assert cr.time == 0.0
    assert cr.target == (3, 6)
    assert cr.dependencies == []

# Generated at 2022-06-21 18:33:58.963625
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('')

    t = TransformationResult(tree, False, [])

    assert t.tree == tree
    assert not t.tree_changed
    assert t.dependencies == []


# Generated at 2022-06-21 18:34:01.921398
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(None, True, None)
    assert res.tree is None
    assert res.tree_changed == True
    assert res.dependencies is None

# Generated at 2022-06-21 18:34:24.291496
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.FunctionDef()
    tr = TransformationResult(tree=t, tree_changed=True, dependencies=[])
    assert tr.tree == t
    assert tr.tree_changed == True
    assert tr.dependencies == []

# Generated at 2022-06-21 18:34:27.058487
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    def f():
        pass
    t = ast.parse(textwrap.dedent(f.__doc__))
    assert TransformationResult(t, True, []) == TransformationResult(t, True, [])

# Generated at 2022-06-21 18:34:31.598795
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Verify that a pair of paths is correctly
    # extracted from a tuple of paths
    path_input = Path("input_path")
    path_output = Path("output_path")
    pair_path = (path_input, path_output)
    pair_input_output = InputOutput(*pair_path)
    assert pair_input_output.input == path_input
    assert pair_input_output.output == path_output

# Generated at 2022-06-21 18:34:35.489895
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path("test.py")
    output = Path("test.json")
    iopair = InputOutput(input, output)

    assert iopair.input == input
    assert iopair.output == output

# Generated at 2022-06-21 18:34:37.591806
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path = Path("/home/test/test.py")
    InputOutput(path, path)


# Generated at 2022-06-21 18:34:43.893485
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    a = TransformationResult(tree=ast.parse('1'), tree_changed=False, dependencies=[])
    assert a.tree_changed == False
    assert len(a.dependencies) == 0


# Result of analyzers analysis
AnalysisResult = NamedTuple('AnalysisResult', [('tree', ast.AST),
                                               ('analysis', str),
                                               ('dependencies', List[str])])



# Generated at 2022-06-21 18:34:50.108660
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # noinspection PyUnresolvedReferences
    import ast
    res = TransformationResult(tree=ast.parse('1 + 2'),
                               tree_changed=True,
                               dependencies=['/tmp/a', '/tmp/b'])
    assert isinstance(res.tree, ast.AST)
    assert res.tree_changed is True
    assert res.dependencies == ['/tmp/a', '/tmp/b']

# Generated at 2022-06-21 18:34:51.951361
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=10, time=0.5, target=(3, 6), dependencies=[])


# Generated at 2022-06-21 18:34:54.067003
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(
        tree=None,
        tree_changed=False,
        dependencies=[]
    )
    assert tr == TransformationResult(None, False, [])

# Generated at 2022-06-21 18:34:59.027173
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput("input", "output")
    assert type(input_output.input) is Path
    assert type(input_output.output) is Path

    input_output = InputOutput("input", "output")
    assert type(input_output.input) is Path
    assert type(input_output.output) is Path

    input_output = InputOutput(Path("input"), Path("output"))
    assert type(input_output.input) is Path
    assert type(input_output.output) is Path

# Generated at 2022-06-21 18:35:21.962092
# Unit test for constructor of class InputOutput
def test_InputOutput():
    f = Path('f')
    g = Path('g')
    inout = InputOutput(f, g)
    assert inout.input == f
    assert inout.output == g


# Generated at 2022-06-21 18:35:25.514299
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.AST()
    changed = True
    deps = ['dep1', 'dep2']
    res = TransformationResult(tree, changed, deps)
    assert res.tree == tree
    assert res.tree_changed == changed
    assert res.dependencies == deps

# Generated at 2022-06-21 18:35:29.389091
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a'), Path('b')).input == Path('a')
    assert InputOutput(Path('a'), Path('b')).output == Path('b')

# Generated at 2022-06-21 18:35:31.156021
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path(), Path())
    assert InputOutput(Path("/tmp"), Path("/tmp/1"))

# Generated at 2022-06-21 18:35:34.429242
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(input=Path('input'),
                               output=Path('output'))

    assert input_output.input == Path('input')
    assert input_output.output == Path('output')
    assert input_output.dependencies() == []

# Generated at 2022-06-21 18:35:37.853358
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=0.0, target=(3, 5), dependencies=[])
    assert cr.files == 1
    assert cr.time == 0.0
    assert cr.target == (3, 5)
    assert cr.dependencies == []


# Generated at 2022-06-21 18:35:40.699978
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = InputOutput(input=Path(__file__), output=Path('abc'))
    assert a.input.samefile(__file__)
    assert a.output.samefile('abc')

# Generated at 2022-06-21 18:35:45.682398
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(0, 1.0, (3, 5), [])
    assert result.files == 0
    assert result.time == 1.0
    assert result.target == (3, 5)
    assert result.dependencies == []


# Generated at 2022-06-21 18:35:50.718541
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = a + b - 1')
    result = TransformationResult(tree, True, ['a', 'b'])
    assert result.tree is tree
    assert result.tree_changed is True
    assert result.dependencies == ['a', 'b']


# Result of transformer transformation
TransformerResult = NamedTuple('TransformerResult',
                               [('tree', ast.AST),
                                ('tree_changed', bool),
                                ('dependencies', List[str])])


# Generated at 2022-06-21 18:35:53.079990
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    tr = TransformationResult(ast.parse('pass'), True, [])
    assert(isinstance(tr, TransformationResult))

# Generated at 2022-06-21 18:36:16.829999
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.Module(), True, [])
    assert isinstance(tr.tree, ast.AST), str(type(tr.tree))
    assert isinstance(tr.tree_changed, bool), str(type(tr.tree_changed))
    assert isinstance(tr.dependencies, list), str(type(tr.dependencies))
    return

# Generated at 2022-06-21 18:36:19.327728
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('2+2')
    t = TransformationResult(tree, True, ['a.py'])
    assert t.tree_changed
    assert t.tree == tree
    assert t.dependencies == ['a.py']

# Generated at 2022-06-21 18:36:25.740880
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(
        files=42,
        time=3.14,
        target=(3, 6),
        dependencies=['foo', 'bar'])
    assert res.files == 42
    assert res.time == 3.14
    assert res.target == (3, 6)
    assert res.dependencies == ['foo', 'bar']


# Generated at 2022-06-21 18:36:29.497400
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('inp')
    outp = Path('outp')
    iop = InputOutput(inp, outp)

    assert inp == iop.input
    assert outp == iop.output



# Generated at 2022-06-21 18:36:34.369471
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Instantiation
    instance = CompilationResult(files=1, time=1.23, target=(3, 7),
                                 dependencies=['foo', 'bar'])

    # Test attributes
    assert instance.files == 1
    assert instance.time == 1.23
    assert instance.target == (3, 7)
    assert instance.dependencies == ['foo', 'bar']


# Generated at 2022-06-21 18:36:37.164392
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.parse('a = 5'), True, ['filename'])
    assert isinstance(tr, TransformationResult)


# Generated at 2022-06-21 18:36:38.767760
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=15, time=0.1, target=(2, 3), dependencies=[])



# Generated at 2022-06-21 18:36:40.603396
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=None,
                                tree_changed=None,
                                dependencies=None)

# Generated at 2022-06-21 18:36:44.269004
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(3, 0.0, (3, 5), [])
    assert result.files == 3
    assert result.time == 0.0
    assert result.target == (3, 5)
    assert result.dependencies == []


# Generated at 2022-06-21 18:36:45.391829
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(Path('foo'), Path('bar'))


# Generated at 2022-06-21 18:37:38.176757
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path = Path('.')
    io = InputOutput(path, path)
    assert io.input == path
    assert io.output == path


# Generated at 2022-06-21 18:37:41.892235
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    result = TransformationResult(tree, True, [])
    assert result.tree == tree
    assert result.tree_changed is True
    assert result.dependencies == []

# Generated at 2022-06-21 18:37:44.191686
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('input.py')
    o = Path('output.py')
    pair = InputOutput(i, o)
    assert pair.input == i
    assert pair.output == o

# Generated at 2022-06-21 18:37:51.763601
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("")
    tree_changed = False
    dependencies = []
    TransformationResult(tree, tree_changed, dependencies)

# Information about codebase
CodebaseInfo = NamedTuple('CodebaseInfo', [('total_files', int),
                                           ('total_size', int),
                                           ('main_files', int),
                                           ('tests_files', int),
                                           ('benchmarks_files', int),
                                           ('other_files', int)])


# Generated at 2022-06-21 18:37:55.114137
# Unit test for constructor of class InputOutput
def test_InputOutput():
    obj = InputOutput(input='input.py',
                      output='output.py')
    assert obj.input.name == 'input.py'
    assert obj.output.name == 'output.py'

# Generated at 2022-06-21 18:37:57.345979
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1,
                      time=1.5,
                      target=(2, 7),
                      dependencies=['a.py', 'b.py'])


# Generated at 2022-06-21 18:38:01.943559
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # pylint: disable=unused-variable
    from tests.test_transformation.transformer.mock_ast import (
        MockTransformer, MockAST
    )
    mock_transformer = MockTransformer()
    mock_ast = MockAST()
    transformation_result = TransformationResult(
        tree=mock_ast,
        tree_changed=True,
        dependencies=['a_dependency'])
    assert transformation_result.dependencies == ['a_dependency']
    assert transformation_result.tree == mock_ast
    assert mock_transformer.tree_changed == True
    assert mock_transformer.dependencies == ['a_dependency']

# Generated at 2022-06-21 18:38:04.980430
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('/dir/input'), Path('/dir/output'))
    assert input_output.input == Path('/dir/input')
    assert input_output.output == Path('/dir/output')

# Generated at 2022-06-21 18:38:10.297055
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=2.0,
                               target=(3, 4),
                               dependencies=['a.py', 'b.py'])

    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == ['a.py', 'b.py']


# Generated at 2022-06-21 18:38:13.321716
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('input'), Path('output'))
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')


# Generated at 2022-06-21 18:39:09.518890
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files = 1, time = 1.0, target = (3, 5), dependencies = ['abc'])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 5)
    assert result.dependencies == ['abc']


# Generated at 2022-06-21 18:39:13.778596
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=4,
                            time=1.1,
                            target=(3, 7),
                            dependencies=['a', 'b', 'c'])
    
    assert res.files == 4
    assert res.time == 1.1
    assert res.target == (3, 7)
    assert res.dependencies == ['a', 'b', 'c']

# Generated at 2022-06-21 18:39:19.801248
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from ast_helpers import new_ast_node as new
    test_dependencies = ["import sys"]
    # noinspection PyTypeChecker
    t = TransformationResult(tree=new.Module([new.Expr(new.Name("my_var"))]),
                             tree_changed=True,
                             dependencies=test_dependencies)
    assert isinstance(t, TransformationResult)

# Generated at 2022-06-21 18:39:22.758537
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=1.0, target=(3, 7), dependencies=[])
    assert cr.files == 1
    assert cr.time == 1.0
    assert cr.target == (3, 7)
    assert cr.dependencies == []



# Generated at 2022-06-21 18:39:25.037572
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(input=Path('/some/path'),
                               output=Path('/some/path'))

    assert input_output.input == Path('/some/path')
    assert input_output.output == Path('/some/path')


# Generated at 2022-06-21 18:39:35.651502
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('', '')
    tr = TransformationResult(None, False, [])
    assert tr.tree == None
    assert tr.tree_changed == False
    assert tr.dependencies == []
    tr = TransformationResult(tree, True, [])
    assert tr.tree == tree
    assert tr.tree_changed == True
    assert tr.dependencies == []
    tr = TransformationResult(None, False, ['dep1'])
    assert tr.tree == None
    assert tr.tree_changed == False
    assert tr.dependencies == ['dep1']
    tr = TransformationResult(tree, True, ['dep1'])
    assert tr.tree == tree
    assert tr.tree_changed == True
    assert tr.dependencies == ['dep1']

# Generated at 2022-06-21 18:39:36.856314
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput('aaa', 'bbb') == InputOutput(Path('aaa'), Path('bbb'))



# Generated at 2022-06-21 18:39:39.790454
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('input')
    output = Path('output')
    i = InputOutput(input_, output)
    assert i.input == input_
    assert i.output == output



# Generated at 2022-06-21 18:39:42.910433
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(None, 'abc')
    io = InputOutput(Path('abc'), Path('abc'))
    io = InputOutput('abc', None)



# Generated at 2022-06-21 18:39:44.369240
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    import ast
    t = TransformationResult(ast.parse("pass"), False, [])
    assert t.tree != None
    assert not t.tree_changed
    assert t.dependencies == []

