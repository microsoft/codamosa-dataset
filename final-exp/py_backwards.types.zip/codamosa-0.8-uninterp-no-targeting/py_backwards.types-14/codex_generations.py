

# Generated at 2022-06-21 18:30:25.359246
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path(__file__), Path('/tmp')).input == Path(__file__)
    assert InputOutput(Path(__file__), Path('/tmp')).output == Path('/tmp')

# Generated at 2022-06-21 18:30:27.639757
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path('foo.py'),
                     Path('bar.py'))

    assert io.input == Path('foo.py')
    assert io.output == Path('bar.py')


# Generated at 2022-06-21 18:30:29.732318
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = '/foo/bar'
    output = '/foo/baz'
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-21 18:30:35.418542
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=1,
                            time=0.0,
                            target=(3, 5),
                            dependencies=['a', 'b'])
    assert res.files == 1
    assert res.time == 0.0
    assert res.target == (3, 5)
    assert res.dependencies == ['a', 'b']


# Generated at 2022-06-21 18:30:39.090293
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(None, False, [])
    assert isinstance(result, TransformationResult)
    assert isinstance(result.tree, ast.AST)
    assert result.tree_changed is False
    assert isinstance(result.dependencies, List)

# Generated at 2022-06-21 18:30:40.749800
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # GIVEN
    i = Path('/')
    o = Path('/')

    # WHEN
    io = InputOutput(i, o)

    # THEN
    assert io.input == i
    assert io.output == o



# Generated at 2022-06-21 18:30:44.033496
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input.py')
    output = Path('/tmp/output.py')
    p = InputOutput(input, output)
    assert p.input == input
    assert p.output == output


# Generated at 2022-06-21 18:30:49.771739
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_node = ast.parse('pass')
    tr = TransformationResult(ast_node, False, [])
    assert tr.tree == ast_node
    assert not tr.tree_changed
    assert tr.dependencies == []

    tr = TransformationResult(ast_node, True, ['foo'])
    assert tr.tree == ast_node
    assert tr.tree_changed
    assert tr.dependencies == ['foo']

# Generated at 2022-06-21 18:30:58.650611
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(0, 0.0, (0, 0), []).files == 0
    assert CompilationResult(0, 0.0, (0, 0), []).time == 0.0
    assert CompilationResult(0, 0.0, (0, 0), []).target == (0, 0)
    assert CompilationResult(0, 0.0, (0, 0), []).dependencies == []


# Generated at 2022-06-21 18:31:04.824606
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # pylint: disable=too-few-public-methods
    result = CompilationResult(
        files=1,
        time=0.2345,
        target=(3, 7),
        dependencies=['a', 'b', 'c']
    )
    assert result.files == 1
    assert result.time == 0.2345
    assert isinstance(result.time, float)
    assert result.target == (3, 7)
    assert isinstance(result.target, tuple)
    assert result.dependencies == ['a', 'b', 'c']
    assert isinstance(result.dependencies, list)



# Generated at 2022-06-21 18:31:07.705860
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert isinstance(CompilationResult(1, 1, (2, 3), ['a']),
                      CompilationResult)


# Generated at 2022-06-21 18:31:09.662758
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 1.0, (3, 6), ['os'])


# Generated at 2022-06-21 18:31:13.031925
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('input')
    o = Path('output')
    input_output = InputOutput(i, o)
    assert input_output.input == i
    assert input_output.output == o
    assert i == input_output[0]
    assert o == input_output[1]

# Generated at 2022-06-21 18:31:16.328783
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=1,
                             time=1.0,
                             target=(3, 7),
                             dependencies=['foo'])


# Generated at 2022-06-21 18:31:21.137554
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(100, 1.0, (2, 2), [])
    assert result.files == 100
    assert result.time == 1.0
    assert result.target == (2, 2)
    assert result.dependencies == []


# Generated at 2022-06-21 18:31:23.226655
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=0, time=0, target=(3, 7), dependencies=None)
    assert result.files == 0
    assert result.time == 0
    assert result.target == (3, 7)
    assert result.dependencies is None



# Generated at 2022-06-21 18:31:24.225962
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.AST(), True, [])

# Generated at 2022-06-21 18:31:25.501885
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    obj = TransformationResult(ast.AST(),
                               tree_changed=False,
                               dependencies=[])
    assert obj.tree_changed == False
    assert obj.dependencies == []

# Generated at 2022-06-21 18:31:27.895483
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=2, time=12.34, target=(2, 7),
                      dependencies=['a.py', 'b.py'])

# Generated at 2022-06-21 18:31:33.933015
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    comp = CompilationResult(files=1, time=1.0, target=(3, 6),
                             dependencies=['a/a.py',
                                           'b/b.py'])
    assert comp.files == 1
    assert comp.time == 1.0
    assert comp.target == (3, 6)
    assert comp.dependencies == ['a/a.py',
                                 'b/b.py']


# Generated at 2022-06-21 18:31:40.578641
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_value = 'a'
    input_path = Path(input_value)
    output_value = 'b'
    output_path = Path(output_value)
    pair = InputOutput(input=input_path, output=output_path)
    assert(pair.input == input_path)
    assert(pair.output == output_path)

# Generated at 2022-06-21 18:31:44.351196
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: ignore
    tree = ast.parse('')
    result = TransformationResult(
        tree=tree, tree_changed=False, dependencies=[])
    assert result.tree is tree
    assert result.tree_changed is False
    assert result.dependencies == []


# Generated at 2022-06-21 18:31:46.148908
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('input'), Path('output')) == \
        InputOutput(input=Path('input'), output=Path('output'))

# Generated at 2022-06-21 18:31:51.037938
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("y = 1")
    assert TransformationResult(tree, True, [])
    assert TransformationResult(tree, False, [])
    assert TransformationResult(tree, True, ["a", "b"])
    assert TransformationResult(tree, False, ["a", "b"])

# Generated at 2022-06-21 18:31:56.515326
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    info = CompilationResult(files=1, time=1.0, target=(3, 7), dependencies=[])
    assert info.files == 1
    assert info.time == 1.0
    assert info.target == (3, 7)
    assert info.dependencies == []


# Generated at 2022-06-21 18:32:00.139688
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input, output = Path('foo'), Path('bar')
    iop = InputOutput(input, output)
    assert iop.input == input
    assert iop.output == output


# Generated at 2022-06-21 18:32:01.716065
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 1.0, (3, 1), ['foo', 'bar'])



# Generated at 2022-06-21 18:32:05.194168
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('abs/path/file.py')
    output = Path('/tmp/123.tmp')
    assert InputOutput(input_, output).input == input_
    assert InputOutput(input_, output).output == output

# Generated at 2022-06-21 18:32:06.144416
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    pass


# Generated at 2022-06-21 18:32:11.715937
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1,
                                           time=0.0,
                                           target=(2, 7),
                                           dependencies=['a', 'b'])
    assert compilation_result.files == 1
    assert compilation_result.time == 0.0
    assert compilation_result.target == (2, 7)
    assert compilation_result.dependencies == ['a', 'b']


# Generated at 2022-06-21 18:32:17.081801
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    x = TransformationResult(ast.Module(), False, ['foo', 'bar'])
    assert isinstance(x, TransformationResult)
    assert x.tree is not None
    assert x.tree_changed is False
    assert x.dependencies == ['foo', 'bar']

# Generated at 2022-06-21 18:32:21.283935
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('/home/user/file.py')
    output_path = Path('/tmp/file.pyc')
    io = InputOutput(input_path, output_path)
    assert io.input == input_path
    assert io.output == output_path

# Generated at 2022-06-21 18:32:25.776032
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = '__main__.py'
    output = '__main__.pyc'
    obj = InputOutput(input_, output)
    assert obj.input == input_
    assert obj.output == output



# Generated at 2022-06-21 18:32:33.632015
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse('42'), True, ['a', 'b']) == \
        TransformationResult(ast.parse('42'), True, ['a', 'b'])
    assert TransformationResult(ast.parse('42'), False, []) == \
        TransformationResult(ast.parse('42'), False, [])
    assert TransformationResult(ast.parse('42'), False, []) == \
        TransformationResult(ast.parse('42'), False, [])
    assert TransformationResult(ast.parse('42'), False, []) != \
        TransformationResult(ast.parse('43'), False, [])

# Generated at 2022-06-21 18:32:36.517768
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
  # pylint: disable=unused-variable
  CompilationResult(files=0,
                    time=0,
                    target=(3, 6),
                    dependencies=[])


# Generated at 2022-06-21 18:32:40.789861
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=1, time=0.1, target=(2, 5), dependencies=[])
    assert c.files == 1
    assert c.time == 0.1
    assert c.target == (2, 5)
    assert not c.dependencies


# Generated at 2022-06-21 18:32:45.431403
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    t = ast.parse('x = 1')
    r = TransformationResult(tree=t,
                             tree_changed=True,
                             dependencies=['foo'])
    assert r == TransformationResult(t, True, ['foo'])
    assert r != TransformationResult(t, False, ['foo'])
    assert r != TransformationResult(t, True, [])
    assert r != TransformationResult(t, True, ['foo', 'bar'])

# Generated at 2022-06-21 18:32:52.855037
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.Module([])
    tree_changed = True
    dependencies = []
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree.body == []
    assert result.tree_changed
    assert result.dependencies == []

# Postprocessor part of the plugin configuration
PostprocessorConfig = NamedTuple('PostprocessorConfig', [('name', str),
                                                         ('arguments', dict)])


# Generated at 2022-06-21 18:32:57.077853
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """
    Test creating InputOutput object.
    """
    inp = Path('/tmp/inp')
    outp = Path('/tmp/outp')
    iop = InputOutput(inp, outp)
    assert iop.input == inp
    assert iop.output == outp


# Generated at 2022-06-21 18:32:58.385944
# Unit test for constructor of class InputOutput
def test_InputOutput():
    _ = InputOutput(Path('a'), Path('b'))



# Generated at 2022-06-21 18:33:06.969666
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    src = CompilationResult(10, 2.0, (3, 7), ['numpy'])

    assert src.files == 10
    assert src.time == 2.0
    assert src.target == (3, 7)
    assert src.dependencies == ['numpy']


# Generated at 2022-06-21 18:33:10.193132
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput('/tmp/a.py', '/tmp/b.py')
    assert io.input == Path('/tmp/a.py')
    assert io.output == Path('/tmp/b.py')


# Generated at 2022-06-21 18:33:13.249971
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse("2+2")
    tr = TransformationResult(t, True, [])
    assert tr.tree == t
    assert tr.tree_changed == True
    assert tr.dependencies == []


# Generated at 2022-06-21 18:33:14.996163
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=[])
    assert cr == cr


# Generated at 2022-06-21 18:33:19.013860
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('i')
    o = Path('o')
    io = InputOutput(i, o)
    assert io.input == i
    assert io.output == o


# Generated at 2022-06-21 18:33:22.649127
# Unit test for constructor of class InputOutput
def test_InputOutput():
    iop = InputOutput(input=Path('input.py'), output=Path('output.py'))
    assert iop.input.name == 'input.py'



# Generated at 2022-06-21 18:33:24.077614
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast.parse('print(1)')
    TransformationResult(None, False, [])

# Generated at 2022-06-21 18:33:27.804540
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(1, 1.0, (2, 6), [])
    assert cr.files == 1
    assert cr.time == 1.0
    assert cr.target == (2, 6)
    assert cr.dependencies == []


# Generated at 2022-06-21 18:33:29.467247
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('in.txt'), Path('out.txt')) != None


# Generated at 2022-06-21 18:33:39.259839
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    tr = TransformationResult(ast.AST(), False, [])
    assert tr.tree
    assert isinstance(tr.tree_changed, bool)
    assert isinstance(tr.dependencies, list)

# Represents a transformation from from input to output
# * input: Path to input file
# * output: Path to output file
# * status: Whether the file was successfully transformed
# * result: The result of the transformation
Transformation = NamedTuple('Transformation',
                            [('input', Path),
                             ('output', Path),
                             ('status', bool),
                             ('result', TransformationResult)])


# Generated at 2022-06-21 18:33:53.167575
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """Constructor of class InputOutput."""
    input_ = Path("input.txt")
    output = Path("output.txt")
    input_output = InputOutput(input_, output)
    assert input_output.input == input_
    assert input_output.output == output


# Generated at 2022-06-21 18:33:55.104595
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input='in', output='out') == InputOutput(input='in', output='out')

# Generated at 2022-06-21 18:33:56.538922
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.AST(), False, ["a", "b"])

# Generated at 2022-06-21 18:34:01.293098
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """
    Unit test for constructor of class InputOutput
    """
    p1 = Path('/1/')
    p2 = Path('/2/')
    x = InputOutput(input=p1, output=p2)
    assert x.input == p1
    assert x.output == p2


# Generated at 2022-06-21 18:34:01.994519
# Unit test for constructor of class InputOutput
def test_InputOutput():
    _ = InputOutput(Path('foo.py'), Path('bar.py'))



# Generated at 2022-06-21 18:34:03.973028
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=0, time=0, target=(3, 7), dependencies=[])



# Generated at 2022-06-21 18:34:08.541400
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.Module()
    assert TransformationResult(t, False, [])
    assert TransformationResult(t, True, [])
    assert TransformationResult(t, False, ["a/b/c"])
    asser

# Generated at 2022-06-21 18:34:13.190618
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    t = CompilationResult(files=3, time=3.0, target=(3, 4),
                          dependencies=['foo', 'bar'])
    assert t.files==3
    assert t.time==3.0
    assert t.target==(3, 4)
    assert t.dependencies==['foo', 'bar']


# Generated at 2022-06-21 18:34:14.868207
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(tree=ast.Expr(),
                         tree_changed=True,
                         dependencies=list())

# Generated at 2022-06-21 18:34:18.599085
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p1 = Path('/t1/t2')
    p2 = Path('/t3/t4')

    io = InputOutput(p1, p2)
    assert io.input == p1
    assert io.output == p2

    io2 = InputOutput(p1, p2)
    assert io == io2

    # different input
    io3 = InputOutput(Path('/t4/t4'), p2)
    assert io != io3

    # different output
    io4 = InputOutput(p1, Path('/t4/t4'))
    assert io != io4

# Generated at 2022-06-21 18:34:43.854163
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 123
    time = 3.14
    target = (3, 5)
    dependencies = ['spam', 'eggs']
    compilation_result = CompilationResult(
        files=files, time=time, target=target, dependencies=dependencies)
    assert compilation_result.files == files
    assert compilation_result.time == time
    assert compilation_result.target == target
    assert compilation_result.dependencies == dependencies


# Generated at 2022-06-21 18:34:49.328934
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(10, 23.2, (3, 4), ["a.py", "b.py"])
    assert cr.files == 10
    assert cr.time == 23.2
    assert cr.target == (3, 4)
    assert cr.dependencies == ["a.py", "b.py"]



# Generated at 2022-06-21 18:34:53.162002
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=2, time=0.5,
                           target=(3, 5), dependencies=['mod'])
    assert cr.files == 2
    assert cr.time == 0.5
    assert cr.target == (3, 5)
    assert cr.dependencies == ['mod']


# Generated at 2022-06-21 18:34:56.210668
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_node = ast.parse("import a")
    test_result = TransformationResult(ast_node, True, ["a"])
    assert test_result.tree == ast_node
    assert test_result.tree_changed is True
    assert test_result.dependencies == ["a"]

# Generated at 2022-06-21 18:34:58.549049
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput('test_input', 'test_output')
    assert input_output.input == Path('test_input')
    assert input_output.output == Path('test_output')

# Generated at 2022-06-21 18:35:04.386086
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(
        files=3,
        time=5.5,
        target=(3, 5),
        dependencies=['a.py', 'b.py']
    )
    assert cr.files == 3
    assert cr.time == 5.5
    assert cr.target == (3, 5)
    assert cr.dependencies == ['a.py', 'b.py']


# Generated at 2022-06-21 18:35:09.426454
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    val = CompilationResult(1, 2.0, (3, 4), [])
    assert val.files == 1
    assert val.time == 2.0
    assert val.target == (3, 4)
    assert val.dependencies == []



# Generated at 2022-06-21 18:35:15.057099
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0,
                               target=(3, 6),
                               dependencies=['a', 'b', 'c'])
    assert(result.files == 1)
    assert(result.time >= 1.0)
    assert(result.target == (3, 6))
    assert(result.dependencies == ['a', 'b', 'c'])


# Generated at 2022-06-21 18:35:22.497782
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # pylint: disable=unused-argument
    def transformation_result(tree, tree_changed, dependencies):
        return TransformationResult(tree, tree_changed, dependencies)

    class DummyNode(ast.AST):
        _fields = ('field',)  # type: Tuple[str, ...]

    dummy_node = DummyNode(field=None)
    dummy_boolean = True
    dummy_list = []  # type: List[str]
    transformation_result(dummy_node, dummy_boolean, dummy_list)

# Generated at 2022-06-21 18:35:24.606104
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('foo.py'), Path('foo.py')).input == Path('foo.py')


# Generated at 2022-06-21 18:36:09.778356
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=1, time=0, target=(3, 7),
                          dependencies=["first dependency"])
    assert c.files == 1
    assert c.time == 0
    assert c.target == (3, 7)
    assert c.dependencies == ["first dependency"]


# Generated at 2022-06-21 18:36:12.294661
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(4, 2.4, (3, 5), ['asd', 'qwe'])

# Generated at 2022-06-21 18:36:13.222669
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path(''), Path(''))

# Generated at 2022-06-21 18:36:17.589706
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('/tmp/input.py')
    out = Path('/tmp/output.py')
    assert InputOutput(inp, out) == InputOutput(inp, out)
    assert InputOutput(inp, out) != InputOutput(Path('/tmp/1.py'), Path('/tmp/2.py'))
    assert len(InputOutput(inp, out)) == 2



# Generated at 2022-06-21 18:36:22.849137
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.parse('a = 1'), True, ['foo', 'bar'])
    assert isinstance(tr.tree, ast.AST)
    assert tr.tree_changed
    assert tr.dependencies == ['foo', 'bar']

    tr = TransformationResult(tr.tree, False, [])
    assert isinstance(tr.tree, ast.AST)
    assert not tr.tree_changed
    assert tr.dependencies == []

    tr = TransformationResult(tr.tree, False, ['foo'])
    assert isinstance(tr.tree, ast.AST)
    assert not tr.tree_changed
    assert tr.dependencies == ['foo']


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        exec(sys.argv[1])
   

# Generated at 2022-06-21 18:36:27.455963
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.AST(), True, ['a']).tree_changed == True
    assert TransformationResult(ast.AST(), False, ['a']).dependencies == ['a']
    assert TransformationResult(ast.AST(), True, ['a']).tree_changed == True

# Generated at 2022-06-21 18:36:31.339689
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("print('hello world')")
    tr = TransformationResult(tree, tree_changed=True, dependencies=[])
    assert tr.tree is not None
    assert tr.tree_changed is True
    assert tr.dependencies == []

# Generated at 2022-06-21 18:36:35.392882
# Unit test for constructor of class TransformationResult
def test_TransformationResult(): # type: () -> None
    tr = TransformationResult(tree=ast.parse('a+b'),
                              tree_changed=False,
                              dependencies=['a', 'b'])
    assert tr.tree == ast.parse('a+b')
    assert tr.tree_changed == False
    assert tr.dependencies == ['a', 'b']

# Generated at 2022-06-21 18:36:39.356293
# Unit test for constructor of class InputOutput
def test_InputOutput():
    res = InputOutput(input=Path('a'),
                      output=Path('b'))
    assert isinstance(res.input, Path)
    assert isinstance(res.output, Path)
    assert res.input == Path('a')
    assert res.output == Path('b')


# Generated at 2022-06-21 18:36:42.272562
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    pair = InputOutput(input=input, output=output)
    assert(pair.input == input)
    assert(pair.output == output)

# Generated at 2022-06-21 18:38:22.897300
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    changed = True
    dependencies = ['x.py', 'y.py']
    TransformationResult(tree, changed, dependencies)

# Generated at 2022-06-21 18:38:27.055019
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(2, 3.4, (3, 5), ["a", "b"])
    assert result.files == 2
    assert result.time == 3.4
    assert result.target == (3, 5)
    assert result.dependencies == ["a", "b"]


# Generated at 2022-06-21 18:38:28.314118
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(100, 0.12, (3, 7), [])

# Generated at 2022-06-21 18:38:30.237242
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # noinspection PyTypeChecker
    CompilationResult(files=1, time=2.3, target=(3, 4), dependencies=['a', 'b'])



# Generated at 2022-06-21 18:38:32.083036
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=5,
                      time=5.5,
                      target=(3, 7),
                      dependencies=['foo.py'])


# Generated at 2022-06-21 18:38:38.467187
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cres = CompilationResult(files=100, time=100, target=(3, 4), dependencies=[])
    assert cres.files == 100, 'files should be 100'
    assert cres.time == 100, 'time should be 100'
    assert cres.target == (3, 4), 'target should be (3, 4)'
    assert cres.dependencies == []


# Generated at 2022-06-21 18:38:43.422362
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    target = CompilationResult(files=4, time=11.4, target=(3, 7),
                               dependencies=["lib1", "lib2"])
    assert target.files == 4
    assert target.time == 11.4
    assert target.target == (3, 7)
    assert target.dependencies == ["lib1", "lib2"]


# Generated at 2022-06-21 18:38:49.011668
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput('input', 'output') == InputOutput(Path('input'), Path('output'))
    assert InputOutput(Path('input'), Path('output')) == InputOutput('input', 'output')
    assert InputOutput('input', 'output') != InputOutput(Path('input1'), Path('output'))
    assert InputOutput('input', 'output') != InputOutput(Path('input'), Path('output1'))


# Generated at 2022-06-21 18:38:53.178122
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=['foo', 'bar'])
    assert cr.files == 1
    assert cr.time == 2.0
    assert cr.target == (3, 4)
    assert cr.dependencies == ['foo', 'bar']


# Generated at 2022-06-21 18:38:59.546504
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_input = Path('/path/to/input')
    test_output = Path('/path/to/output')

    test_io = InputOutput(input=test_input, output=test_output)

    assert test_io.input == test_input
    assert test_io.output == test_output