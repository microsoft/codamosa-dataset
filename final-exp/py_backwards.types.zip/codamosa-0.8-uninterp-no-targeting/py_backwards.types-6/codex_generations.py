

# Generated at 2022-06-21 18:30:41.307627
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=0.1, target=(3, 6), dependencies=[])


# Generated at 2022-06-21 18:30:42.970896
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert isinstance(CompilationResult(2, 3.14, (3, 6), ['test']),
                      CompilationResult)


# Generated at 2022-06-21 18:30:46.689089
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files = 1, time = 2.0, target = (3, 4), dependencies = ["a", "b"])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == ["a", "b"]


# Generated at 2022-06-21 18:30:48.021844
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    pass

# Generated at 2022-06-21 18:30:53.527167
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, None, None)
    assert TransformationResult(None, True, None)
    assert TransformationResult(None, False, None)
    assert TransformationResult(None, None, [])
    assert TransformationResult(None, True, [])
    assert TransformationResult(None, False, [])
    assert TransformationResult(None, None, ['file1'])
    assert TransformationResult(None, True, ['file1'])
    assert TransformationResult(None, False, ['file1'])

# Generated at 2022-06-21 18:30:56.387288
# Unit test for constructor of class InputOutput
def test_InputOutput():
    try:
        InputOutput('foo', 'bar')
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-21 18:31:00.779784
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cres = CompilationResult(0, 0.0, (0, 0), [])
    assert cres.files == 0
    assert cres.time == 0.0
    assert cres.target == (0, 0)
    assert cres.dependencies == []


# Generated at 2022-06-21 18:31:04.580327
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    check_TransformationResult = ast.parse('a = 1\n')
    check_TransformationResult_dependencies = ['b']

    check_TransformationResult = TransformationResult(check_TransformationResult,
                                                       False,
                                                       check_TransformationResult_dependencies)
    assert isinstance(check_TransformationResult, TransformationResult)

__all__ = ['TransformationResult', 'test_TransformationResult']

# Generated at 2022-06-21 18:31:11.753991
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    a.check_NamedTuple_constructor(TransformationResult,
                                   TransformationResult(tree=ast.AST(),
                                                        tree_changed=True,
                                                        dependencies=[]))


# Result of transformers.py diff_and_save_tree
DiffAndSaveTreeResult = NamedTuple('DiffAndSaveTreeResult',
                                   [('old_tree', ast.AST),
                                    ('new_tree', ast.AST),
                                    ('tree_changed', bool),
                                    ('dependencies', List[str])])


# Generated at 2022-06-21 18:31:14.922109
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(1, 1.0, (3, 5), ['foo', 'bar'])
    assert res.files == 1
    assert res.time == 1.0
    assert res.target == (3, 5)
    assert res.dependencies == ['foo', 'bar']


# Generated at 2022-06-21 18:31:25.519593
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(0, False, [])

# Result of module analyzer
ModuleUsage = NamedTuple('ModuleUsage', [('imports', List[str]),
                                         ('ast', ast.AST)])

# Result of transformer
TransformerResult = NamedTuple('TransformerResult',
                               [('ast', ast.AST),
                                ('imports', List[str])])


# Result of async transpilers
AsyncTranslatorResult = NamedTuple('AsyncResult',
        [('ast', ast.AST),
         ('imports', List[str]),
         ('async_func_args', List[str]),
         ])

# Generated at 2022-06-21 18:31:26.508214
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(3, 0.1, (3, 7), ['foo'])


# Generated at 2022-06-21 18:31:28.466444
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(tree=None,
                         tree_changed=False,
                         dependencies=['a', 'b'])

# Generated at 2022-06-21 18:31:32.991062
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('./input.txt')
    output_path = Path('./output.txt')

    input_output = InputOutput(input_path, output_path)

    assert input_path == input_output.input
    assert output_path == input_output.output


# Generated at 2022-06-21 18:31:36.937319
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # pylint: disable=unused-variable
    compilation_result = CompilationResult(files=1,
                                           time=1.0,
                                           target=(3, 5),
                                           dependencies=["a", "b"])


# Generated at 2022-06-21 18:31:40.665251
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(1, 1.7, (3, 6), ['foo'])
    assert c.files == 1
    assert c.time == 1.7
    assert c.target == (3, 6)
    assert c.dependencies == ['foo']


# Generated at 2022-06-21 18:31:43.412679
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    d = ['/a/b/c', '/a/b/c/d']
    t = ast.Module(body=[ast.ImportFrom(module='a',
                                        names=[ast.alias(name='b', asname='c')],
                                        level=0)])
    TransformationResult(t, True, d)

# Generated at 2022-06-21 18:31:50.093308
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=None,
                                tree_changed=True,
                                dependencies=[]).tree_changed == True
    assert TransformationResult(tree=None,
                                tree_changed=False,
                                dependencies=[]).tree_changed == False
    assert TransformationResult(tree=None,
                                tree_changed=False,
                                dependencies=[]).tree == None

# Generated at 2022-06-21 18:31:51.609228
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(tree=None, tree_changed=True, dependencies=None)

# Generated at 2022-06-21 18:31:58.199739
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path('foo'), Path('bar'))
    assert io.input == Path('foo')
    assert io.output == Path('bar')
    assert io.input.name == 'foo'
    assert io.output.name == 'bar'
    assert io.input.suffix == ''
    assert io.output.suffix == ''


# Generated at 2022-06-21 18:32:04.704218
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.Module()
    res = TransformationResult(tree, True, [])
    assert isinstance(res, TransformationResult)
    assert res.tree == tree
    assert res.tree_changed
    assert res.dependencies == []

# Result of compilation
CompilationResult = NamedTuple('CompilationResult',
                               [('files', int),
                                ('time', float),
                                ('target', CompilationTarget),
                                ('dependencies', List[str])])


# Generated at 2022-06-21 18:32:06.007203
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input=Path('input'), output=Path('output'))

# Generated at 2022-06-21 18:32:09.273757
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inputs = [
        InputOutput(input=Path('input'), output=Path('output')),
        InputOutput(input=Path('input'), output=Path('output')),
    ]
    assert inputs[0] == inputs[1]

# Generated at 2022-06-21 18:32:13.238467
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=0,
                               time=0.,
                               target=(3, 0),
                               dependencies=[])
    assert result.files == 0
    assert result.time == 0.
    assert result.target == (3, 0)
    assert result.dependencies == []


# Generated at 2022-06-21 18:32:17.044684
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    code = 'files = 0\ntarget = (2, 7)\ndependencies = []\n'
    exec(code)
    x = CompilationResult(files=files, time=1.2,
                          target=target, dependencies=dependencies)
    assert isinstance(x, tuple)


# Generated at 2022-06-21 18:32:21.491955
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 1.2, (2, 0), [])
    CompilationResult(1, 1.2, (2, 0), [''])
    CompilationResult(1, 1.2, (2, 0), ['', ''])

    try:
        CompilationResult(1, 1.2, (2, 0), [None])
        raise Exception()
    except Exception:
        pass

    try:
        CompilationResult(1, 1.2, (2, 0), [None, None])
        raise Exception()
    except Exception:
        pass


# Generated at 2022-06-21 18:32:26.835789
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(0, False, [])
    assert result.tree == 0
    assert result.tree_changed is False
    assert result.dependencies == []

# Result of running tests
TestResult = NamedTuple('TestResult', [('success', bool),
                                       ('time', float)])


# Generated at 2022-06-21 18:32:30.071483
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/root/dir')
    output = Path('/root/dir')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-21 18:32:31.180978
# Unit test for constructor of class InputOutput
def test_InputOutput():
    try:
        InputOutput(Path("First"), Path("Second"))
    except:
        assert False, "Should not raise"


# Generated at 2022-06-21 18:32:35.277139
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(1, 1.5, (3, 5), ['dep1', 'dep2'])
    assert cr.files == 1
    assert cr.time == 1.5
    assert cr.target == (3, 5)
    assert cr.dependencies == ['dep1', 'dep2']


# Generated at 2022-06-21 18:32:45.331246
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=123, time=100.0, target=(3, 6),
                            dependencies=['a', 'bc'])
    assert res.files == 123
    assert res.time == 100.0
    assert res.target == (3, 6)
    assert res.dependencies == ['a', 'bc']
    assert str(res) == '<CompilationResult time=100.00, files=123, target=(3, 6), ' \
                       'dependencies=a,bc>'


# Generated at 2022-06-21 18:32:49.910491
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.AST()
    res = TransformationResult(tree, True, ['some.py'])
    assert res.tree == tree
    assert res.tree_changed == True
    assert res.dependencies == ['some.py']


# Generated at 2022-06-21 18:32:52.628838
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path("input"), Path("output"))
    assert isinstance(io.input, Path)
    assert isinstance(io.output, Path)

# Generated at 2022-06-21 18:32:56.570601
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('1+2')
    tr: TransformationResult = TransformationResult(tree, True, ['a', 'b'])
    assert isinstance(tr, TransformationResult), \
        f'Expected TransformationResult, got {type(tr)}'



# Generated at 2022-06-21 18:33:00.114342
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path_in = Path('/tmp/input')
    path_out = Path('/tmp/output')
    io = InputOutput(path_in, path_out)
    assert io.input == path_in
    assert io.output == path_out

# Generated at 2022-06-21 18:33:05.010801
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.AST()
    tree_changed = True
    dependencies = ['a', 'b']
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree is tree
    assert result.tree_changed is tree_changed
    assert result.dependencies == dependencies


# Generated at 2022-06-21 18:33:08.349274
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path('/home/example.py')
    path2 = Path('/home/example.pyc')
    pair = InputOutput(path1, path2)
    assert pair.input == path1
    assert pair.output == path2

# Generated at 2022-06-21 18:33:12.570914
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(5, 2.0, (3, 6), ['a', 'b', 'c'])
    assert result.files == 5
    assert result.time == 2.0
    assert result.target == (3, 6)
    assert result.dependencies == ['a', 'b', 'c']


# Generated at 2022-06-21 18:33:15.545414
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(1, 2.0, (3, 4), [])
    assert r.files == 1
    assert r.time == 2.0
    assert r.target == (3, 4)
    assert r.dependencies == []


# Generated at 2022-06-21 18:33:27.652414
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from python_minifier.transformers.whitespace_removal import WhitespaceRemoval
    from python_minifier.transformers.decorators import Decorators
    from python_minifier.transformers.unnecessary_parentheses import UnnecessaryParentheses
    from python_minifier.transformers.docstrings import DocStrings
    from python_minifier.transformers.empty_parentheses_functions import EmptyParenthesesFunctions
    from python_minifier.transformers.empty_bodies import EmptyBodies
    from python_minifier.transformers.literals import Literals

    transformer = WhitespaceRemoval()
    t = TransformationResult(ast.parse('a = 1'), True, ['x'])
    tr = transformer(t.tree, t.dependencies)

    transformer = Decorators()

# Generated at 2022-06-21 18:33:47.171843
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    import astor
    import random
    import string
    import utils
    from transformers import IdentityTransformer

    # Generate tree
    tree = ast.parse("print 1")
    # Generate dependencies
    dependencies = ["".join(random.choice(string.ascii_letters) for _ in range(10))
                    for _ in range(5)]
    # Create result
    result = TransformationResult(tree, True, dependencies)
    # Check
    assert isinstance(result.tree, ast.AST)
    assert isinstance(result.tree_changed, bool)
    assert isinstance(result.dependencies, List)

    # Check that not changed result does not contain dependencies
    result = TransformationResult(tree, False, dependencies)
    assert result.dependencies == []

    # Check that result of transformation is equal to original tree

# Generated at 2022-06-21 18:33:49.514210
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2.0, (3, 4), ["foo"])


# Generated at 2022-06-21 18:33:52.647395
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('input.py')
    o = Path('output.py')
    x = InputOutput(i, o)
    assert x.input == i
    assert x.output == o


# Generated at 2022-06-21 18:33:55.002288
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.parse("pass"), False, [])
    assert tr.tree is not None
    assert tr.tree_changed == False

# Generated at 2022-06-21 18:33:56.801734
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(0, 0.0, (0, 0), [])


# Generated at 2022-06-21 18:34:02.475300
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(
        files=1,
        time=0,
        target=(3, 6),
        dependencies=['/tmp/a.py']
    )
    assert result.files == 1
    assert result.time == 0
    assert result.target == (3, 6)
    assert result.dependencies == ['/tmp/a.py']


# Generated at 2022-06-21 18:34:06.214063
# Unit test for constructor of class InputOutput
def test_InputOutput():

    # Arrange
    i = Path(r'/home/user/input.py')
    o = Path(r'/home/user/output.py')

    # Act
    io = InputOutput(i, o)

    # Assert
    assert io.input == i
    assert io.output == o

# Generated at 2022-06-21 18:34:09.795200
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    a = ast.parse('1 + 2')
    b = ast.parse('2 + 3')

    TransformationResult(a, False, [])
    TransformationResult(b, True, [])

# Generated at 2022-06-21 18:34:13.145967
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # pylint: disable=too-many-function-args
    assert isinstance(TransformationResult(
        ast.AST(None, None), True, ['test']), TransformationResult)
    # pylint: enable=too-many-function-args

# Generated at 2022-06-21 18:34:13.959876
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=0.1, target=(2, 7), dependencies=[])

# Generated at 2022-06-21 18:34:43.210155
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('')

    r1 = TransformationResult(t, False, [])
    r2 = TransformationResult(t, False, [])
    assert r1 == r2

    r1 = TransformationResult(t, True, [])
    r2 = TransformationResult(t, True, [])
    assert r1 == r2

    r1 = TransformationResult(t, False, ['A'])
    r2 = TransformationResult(t, False, ['A'])
    assert r1 == r2

    r1 = TransformationResult(t, True, ['A'])
    r2 = TransformationResult(t, True, ['A'])
    assert r1 == r2

# Result of transformers test

# Generated at 2022-06-21 18:34:48.037307
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Arrange
    input_ = Path('input')
    output = Path('output')

    # Act
    i = InputOutput(input_, output)

    # Assert
    assert i.input == input_
    assert i.output == output



# Generated at 2022-06-21 18:34:51.261166
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(tree=None,
                                  tree_changed=False,
                                  dependencies=[])
    assert result.tree == None
    assert result.tree_changed == False
    assert result.dependencies == []

# Generated at 2022-06-21 18:34:56.865743
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # pylint: disable=unused-variable
    # noinspection PyShadowingNames
    def test(files, time, target):
        CompilationResult(files, time, target, [])
    test(1, 0, (2, 7))
    test(2, 0.5, (2, 7))
    test(3, 2.3, (3, 5))
    test(4, -1, (3, 7))
    test(5, 10**5, (3, 9))
    assert True


# Generated at 2022-06-21 18:34:58.929437
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(input=Path('input'), output=Path('output'))
    assert io.input == Path('input')
    assert io.output == Path('output')

# Generated at 2022-06-21 18:35:01.487819
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    dummy_tree = ast.parse('pass', mode='exec')
    result = TransformationResult(tree=dummy_tree,
                                  tree_changed=False,
                                  dependencies=[])
    assert result.tree == dummy_tree
    assert result.tree_changed == False
    assert result.dependencies == []

# Generated at 2022-06-21 18:35:04.927020
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(None, False, [])
    assert tr.tree is None
    assert tr.tree_changed is False
    assert tr.dependencies == []

    tr_string = repr(tr)
    assert tr_string == "TransformationResult(None, False, [])"

# Generated at 2022-06-21 18:35:09.637053
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(tree=None, tree_changed=False, dependencies=[])
    assert t.tree_changed is False
    assert t.tree is None
    assert t.dependencies == []

# Test for constructor of class InputOutput

# Generated at 2022-06-21 18:35:14.096766
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(3, 0.01, (2, 7), ['a', 'b'])
    assert c.files == 3
    assert c.time == 0.01
    assert c.target == (2, 7)
    assert c.dependencies == ['a', 'b']


# Generated at 2022-06-21 18:35:18.098026
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, True, [])
    assert TransformationResult(None, False, [])


# Result of transformers post-transformation processing
PostProcessingResult = NamedTuple('PostProcessingResult',
                                  [('output', str),
                                   ('dependencies', List[str])])

# Generated at 2022-06-21 18:36:07.776444
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=42,
                           time=13.37,
                           target=(3, 6),
                           dependencies=['sample-dependency'])
    assert isinstance(cr.files, int)
    assert cr.files == 42
    assert isinstance(cr.time, float)
    assert cr.time == 13.37
    assert isinstance(cr.target[0], int)
    assert cr.target[0] == 3, cr.target[0]
    assert isinstance(cr.target[1], int)
    assert cr.target[1] == 6, cr.target[1]
    assert isinstance(cr.dependencies, list)
    assert len(cr.dependencies) == 1
    assert cr.dependencies[0] == 'sample-dependency'



# Generated at 2022-06-21 18:36:10.509845
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 0.1, (3, 5), []) == CompilationResult(1, 0.1, (3, 5), [])


# Generated at 2022-06-21 18:36:11.986076
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(tree=ast.parse('a=1'), tree_changed=True, dependencies=['a', 'b'])

# Generated at 2022-06-21 18:36:13.729686
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    """Constructor should create objects without errors."""
    TransformationResult(ast.AST(), False, [])

# Generated at 2022-06-21 18:36:16.278926
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    tr = TransformationResult(tree, False, [])
    assert isinstance(tr.tree, ast.AST)
    assert not tr.tree_changed
    assert tr.dependencies == []

# Generated at 2022-06-21 18:36:17.376467
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.parse("print(1)"), True, ["1", "2"])

# Generated at 2022-06-21 18:36:21.145576
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    tree = ast.parse("x is y") # type: ast.AST
    tr = TransformationResult(tree, False, [])
    assert tr.tree is tree
    assert tr.tree_changed == False
    assert tr.dependencies == []


Transformer = NamedTuple('Transformer', [('name', str),
                                         ('description', str),
                                         ('function', Callable[[ast.AST],
                                                               TransformationResult])])

# Generated at 2022-06-21 18:36:22.034651
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=None, tree_changed=False, dependencies=[])

# Generated at 2022-06-21 18:36:25.692972
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(None, False, [])
    assert t.tree == None
    assert t.tree_changed == False
    assert t.dependencies == []

# Generated at 2022-06-21 18:36:27.407932
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('./test.py'), Path('./test.py'))


# Generated at 2022-06-21 18:38:09.028417
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(input=Path("/tmp/1.py"),
                               output=Path("/tmp/2.py"))
    assert input_output.input == Path("/tmp/1.py")
    assert input_output.output == Path("/tmp/2.py")
    input_output = InputOutput(Path("/tmp/1.py"),
                               Path("/tmp/2.py"))
    assert input_output.input == Path("/tmp/1.py")
    assert input_output.output == Path("/tmp/2.py")



# Generated at 2022-06-21 18:38:10.254347
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test = TransformationResult(ast.parse('a = a'), False, [])

# Generated at 2022-06-21 18:38:13.248851
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('some path')
    output = Path('another path')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output

# Generated at 2022-06-21 18:38:18.152224
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('/foo/bar')
    output = Path('/bar/foo')

    input_output = InputOutput(input_, output)

    assert input_output.input == input_
    assert input_output.output == output

# Generated at 2022-06-21 18:38:21.009316
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(3, 4),
                               dependencies=['abc.txt'])



# Generated at 2022-06-21 18:38:25.469245
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult((3, 2), True, ['a', 'b'])
    assert len(TransformationResult((3, 2), True, ['a', 'b'])) == 3


# Result of both transformation and parsing
TransformationAndParsingResult = NamedTuple(
    'TransformationAndParsingResult',
    [('tree', ast.AST),
     ('tree_changed', bool),
     ('dependencies', List[str]),
     ('source_size', int)])


# Generated at 2022-06-21 18:38:28.350111
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.Str('a')
    tr = TransformationResult(tree=t, tree_changed=True, dependencies=[])
    assert tr.tree == t
    assert tr.tree_changed == True
    assert tr.dependencies == []

# Generated at 2022-06-21 18:38:31.332885
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('input')
    output_path = Path('output')
    input_output_pair = InputOutput(input=input_path,
                                    output=output_path)
    assert input_output_pair.input == input_path
    assert input_output_pair.output == output_path



# Generated at 2022-06-21 18:38:33.368563
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('input')
    output = Path('output')

    io = InputOutput(input=input_,
                     output=output)

    assert io.input == input_
    assert io.output == output

# Generated at 2022-06-21 18:38:35.630944
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path = Path('aaa')
    io = InputOutput(path, path)
    assert io.input.samefile(io.output)
