

# Generated at 2022-06-21 18:30:39.801846
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    import astor
    class DummyTransformer(ast.NodeTransformer):
        def visit_Expression(self, node):
            return node

    code = """
        x = 1
        y = 2
    """
    original_tree = astor.code_to_ast.parse_string(code)
    tree = ast.fix_missing_locations(ast.copy_location(
            ast.Module(body=[ast.FunctionDef(name='f', args=ast.arguments(), body=[]),
                             ast.Expr(value=ast.Num(1)),
                             ast.Expr(value=ast.BinOp(ast.Num(1), ast.Add(), ast.Num(2))),
                             ast.Return(ast.Num(123))                      
                            ]), original_tree
        ))
    result = Transformation

# Generated at 2022-06-21 18:30:41.107898
# Unit test for constructor of class InputOutput
def test_InputOutput():
    data = ('in.py', 'out.js')
    res = InputOutput(*data)
    assert res.input == Path(data[0])
    assert res.output == Path(data[1])

# Generated at 2022-06-21 18:30:44.576414
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('print("Hello world!")')
    transformation_result = TransformationResult(tree, False, [])
    assert transformation_result.tree == tree
    assert not transformation_result.tree_changed
    assert transformation_result.dependencies == []



# Generated at 2022-06-21 18:30:46.685941
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Required for mypy to recognize that test_case is an InputOutput
    test_case = InputOutput(Path('a'), Path('b'))
    test_case.input  # type: Path
    test_case.output  # type: Path



# Generated at 2022-06-21 18:30:51.530157
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=0.5, target=(3, 7), dependencies=['a', 'b'])
    assert cr.files == 1
    assert cr.time == 0.5
    assert cr.target == (3, 7)
    assert cr.dependencies == ['a', 'b']


# Generated at 2022-06-21 18:30:54.469705
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast.parse("foo()")
    TransformationResult(ast.parse("foo()"), False, [])

# Generated at 2022-06-21 18:30:59.560774
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(files=0, time=0, target=(1, 3), dependencies=['a'])
    assert r.files == 0
    assert r.time == 0
    assert r.target == (1, 3)
    assert r.dependencies == ['a']


# Generated at 2022-06-21 18:31:02.705402
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(0, 0, (3, 6), [])
    assert res.files == 0
    assert res.time == 0
    assert res.target == (3, 6)
    assert res.dependencies == []



# Generated at 2022-06-21 18:31:05.979512
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('a')
    output = Path('b')
    result = InputOutput(input, output)

    assert result.input == input
    assert result.output == output

# Generated at 2022-06-21 18:31:07.064069
# Unit test for constructor of class InputOutput
def test_InputOutput():
    _ = InputOutput(Path('foo.py'), Path('foo.cpp'))

# Generated at 2022-06-21 18:31:10.405598
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 2, (3, 4), [])


# Generated at 2022-06-21 18:31:13.479365
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path_input = Path('example_input.py')
    path_output = Path('example_output.py')
    io = InputOutput(path_input, path_output)
    assert io.input == path_input
    assert io.output == path_output

# Generated at 2022-06-21 18:31:16.380826
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(0, 0.0, (3, 6), [])
    assert(c)


# Generated at 2022-06-21 18:31:19.431434
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('a')
    out = Path('b')
    result = InputOutput(inp, out)
    assert result.input == inp
    assert result.output == out

# Generated at 2022-06-21 18:31:22.213936
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    assert TransformationResult(tree, False, []) == TransformationResult(tree, False, [])

# Generated at 2022-06-21 18:31:24.080558
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=1, time=2.0, target=(2, 7), dependencies=[])


# Generated at 2022-06-21 18:31:28.078853
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('/path/to/input')
    output = Path('/path/to/output')
    input_output = InputOutput(input_, output)

    assert input_output.input == input_
    assert input_output.output == output


# Generated at 2022-06-21 18:31:31.323328
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path_in = Path('.')
    path_out = Path('/')
    io = InputOutput(path_in, path_out)
    assert io.input == path_in
    assert io.output == path_out

# Generated at 2022-06-21 18:31:36.328123
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 1
    time = 0.0
    target = (3, 5)
    dependencies = []
    result = CompilationResult(files, time, target, dependencies)

    assert result.files == 1
    assert result.time == 0.0
    assert result.target == (3, 5)
    assert result.dependencies == []


# Generated at 2022-06-21 18:31:41.466626
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Basic usage
    CompilationResult(files=10, time=0.1, target=(3, 6), dependencies=[])

    # Error cases
    # noinspection PyTypeChecker
    try:
        CompilationResult(files=10, time=0.1, target=(3, 6), dependencies=0)
        assert False  # Throw error if here
    except TypeError:
        pass



# Generated at 2022-06-21 18:31:46.780248
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input=Path('input'), output=Path('output'))

# Generated at 2022-06-21 18:31:53.245632
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    test_result = CompilationResult(files=12,
                                    time=2.22,
                                    target=(3, 7),
                                    dependencies=['a.py', 'b.py'])
    assert test_result.files == 12
    assert test_result.time == 2.22
    assert test_result.target == (3, 7)
    assert test_result.dependencies == ['a.py', 'b.py']


# Generated at 2022-06-21 18:31:57.247385
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    test = InputOutput(input, output)

    assert test.input == input
    assert test.output == output


# Generated at 2022-06-21 18:32:02.322699
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # type: () -> None
    f_in = Path('/tmp/foo.in')
    f_out = Path('/tmp/foo.out')
    input_output = InputOutput(f_in, f_out)
    assert input_output.input == f_in
    assert input_output.output == f_out

# Generated at 2022-06-21 18:32:07.120742
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test_tree = ast.parse('print("Hello, World!")')
    test_dependencies = ['foo', 'bar', 'baz']
    test_result = TransformationResult(test_tree, True, test_dependencies)
    assert test_result.tree == test_tree
    assert test_result.tree_changed == True
    assert test_result.dependencies == test_dependencies

# Generated at 2022-06-21 18:32:10.921734
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    obj = CompilationResult(1, 2, (3, 4), ['a', 'b'])
    assert obj.files == 1
    assert obj.time == 2
    assert obj.target == (3, 4)
    assert obj.dependencies == ['a', 'b']


# Generated at 2022-06-21 18:32:12.559608
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.AST(), True, [])
    assert tr.tree is not None

# Generated at 2022-06-21 18:32:17.340660
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('/tmp')
    o = Path('/home')
    inout = InputOutput(i, o)
    assert(str(inout.input) == '/tmp')
    assert(str(inout.output) == '/home')
    assert(inout.input.exists)
    assert(not inout.output.exists)
    assert(len(inout) == 2)


# Generated at 2022-06-21 18:32:20.428309
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    target = (3, 5)
    result = CompilationResult(14, 33.6, target, ['math', 'os'])
    assert isinstance(result, CompilationResult)
    assert result.files == 14
    assert result.time == 33.6
    assert result.target == target
    assert result.dependencies == ['math', 'os']

# Generated at 2022-06-21 18:32:25.674613
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=None, tree_changed=False, dependencies=None).tree is None
    assert TransformationResult(tree=None, tree_changed=False, dependencies=None).tree_changed == False
    assert TransformationResult(tree=None, tree_changed=False, dependencies=None).dependencies is None

# Generated at 2022-06-21 18:32:39.183437
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    dependencies = ['foo', 'bar', 'python.so']
    cr = CompilationResult(files=1,
                           time=0.1,
                           target=(3, 5),
                           dependencies=dependencies)
    assert cr.files == 1
    assert cr.time == 0.1
    assert cr.target == (3, 5)
    assert cr.dependencies == dependencies



# Generated at 2022-06-21 18:32:41.171975
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('foo/bar.py'), Path('out/bar.py'))

# Generated at 2022-06-21 18:32:43.688438
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_node = ast.Module()
    res = TransformationResult(ast_node, True, [])
    assert res.tree == ast_node
    assert res.tree_changed
    assert res.dependencies == []

# Generated at 2022-06-21 18:32:48.342563
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_file = Path('input.py')
    output_file = Path('output.py')
    io = InputOutput(input=input_file, output=output_file)
    assert io.input == input_file
    assert io.output == output_file

# Generated at 2022-06-21 18:32:53.735236
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test_tree = ast.parse("x = 1")
    test_deps = ["test_dep_1", "test_dep_2"]
    test_result = TransformationResult(test_tree, False, test_deps)
    assert test_result.tree == test_tree
    assert test_result.tree_changed == False
    assert test_result.dependencies == test_deps

# Generated at 2022-06-21 18:32:56.571826
# Unit test for constructor of class InputOutput
def test_InputOutput():
    pair = InputOutput(input=Path('a'), output=Path('b'))
    assert pair.input == Path('a')
    assert pair.output == Path('b')

# Generated at 2022-06-21 18:33:02.605909
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=3, time=5.5, target=(3, 7),
                               dependencies=['/tmp/1.py', '/tmp/2.py'])
    assert result.files == 3
    assert result.time == 5.5
    assert result.target == (3, 7)
    assert result.dependencies == ['/tmp/1.py', '/tmp/2.py']


# Generated at 2022-06-21 18:33:06.220653
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('inp/ut')
    out = Path('out/ut')
    io = InputOutput(inp, out)
    assert io.input == inp
    assert io.output == out



# Generated at 2022-06-21 18:33:07.974226
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(3, 5.0, (3, 5), ['A'])



# Generated at 2022-06-21 18:33:10.750470
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    dep = ['A', 'B', 'C']
    result = TransformationResult(ast.FunctionDef(), True, dep)
    assert(result.tree_changed == True)
    assert(result.dependencies == dep)

# Generated at 2022-06-21 18:33:28.216907
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(0, 1, (2, 3), [])


# Generated at 2022-06-21 18:33:32.007698
# Unit test for constructor of class InputOutput
def test_InputOutput():
    class MyInputOutput(InputOutput):
        pass
    a = MyInputOutput(input=Path('a'), output=Path('b'))
    assert a.input == Path('a')
    assert a.output == Path('b')

# Generated at 2022-06-21 18:33:34.877714
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2.0, (3, 4), ["file1.py", "file2.py"])


# Generated at 2022-06-21 18:33:39.720419
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    """
    Test the constructor of CompilationResult
    """
    result = CompilationResult(files=5, time=5.5, target=(3, 1), dependencies=[])
    assert result.files == 5
    assert result.time == 5.5
    assert result.target == (3, 1)
    assert result.dependencies == []



# Generated at 2022-06-21 18:33:41.815797
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=42,
                           time=1.2,
                           target=(3, 5),
                           dependencies=['f1', 'f2'])
    assert cr.files == 42
    assert cr.time == 1.2
    assert cr.target == (3, 5)
    assert cr.dependencies == ['f1', 'f2']


# Generated at 2022-06-21 18:33:49.203822
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_tree = ast.parse("x")
    transformation_result = TransformationResult(ast_tree, False, [])
    assert transformation_result.tree == ast_tree
    assert not transformation_result.tree_changed
    assert transformation_result.dependencies == []


# Result of type checker transformation
TypeCheckResult = NamedTuple('TypeCheckResult',
                             [('success', bool),
                              ('modules', List[str]),
                              ('module_name', str)])


# Generated at 2022-06-21 18:33:52.738080
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.Module(), False, [])
    TransformationResult(ast.Module(), True, [])
    TransformationResult(ast.Module(), True, ['a'])
    TransformationResult(ast.Module(), False, ['a'])

# Generated at 2022-06-21 18:33:55.811110
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path(__file__)
    output = Path(__file__ + '.pyc')

    i = InputOutput(input, output)

    assert(i.input == input)
    assert(i.output == output)

# Generated at 2022-06-21 18:34:00.203861
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    test = CompilationResult(0, 0.0, (0, 0), [])
    assert test.files == 0
    assert test.time == 0.0
    assert test.target == (0, 0)
    assert test.dependencies == []


# Generated at 2022-06-21 18:34:03.874928
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('1+1')
    dependencies = ['test']
    result = TransformationResult(tree, False, dependencies)

    assert result.tree == tree
    assert result.tree_changed == False
    assert result.dependencies == dependencies

# Generated at 2022-06-21 18:34:23.557468
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_tree = ast.parse("x = 1")
    assert TransformationResult(ast_tree, True, []) == TransformationResult(ast_tree, True, [])

# Generated at 2022-06-21 18:34:26.201282
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    assert TransformationResult(tree, True, ['a']).__eq__(
        TransformationResult(tree, True, ['a'])
    )

# Generated at 2022-06-21 18:34:27.986287
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 2.1, (3, 4), ["extension", "python"])


# Generated at 2022-06-21 18:34:31.972080
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    p = ast.parse("1 + 1")
    t = TransformationResult(p, False, [])
    assert t == TransformationResult(p, False, [])
    t = TransformationResult(p, True, [])
    assert t == TransformationResult(p, True, [])


# Type of function that transforms AST
Transformer = Callable[[ast.AST, str],
                        TransformationResult]

# Generated at 2022-06-21 18:34:34.729317
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(1, 2.0, (3, 4), ['a', 'b'])
    assert cr.files == 1
    assert cr.time == 2.0
    assert cr.target == (3, 4)
    assert cr.dependencies == ['a', 'b']



# Generated at 2022-06-21 18:34:42.693399
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    """
    Tests constructor of CompilationResult.
    """
    compilation_result = CompilationResult(files=3,
                                           time=2.5,
                                           target=(3, 7),
                                           dependencies=['lib1', 'lib2'])
    assert compilation_result.files == 3
    assert compilation_result.time == 2.5
    assert compilation_result.target == (3, 7)
    assert compilation_result.dependencies == ['lib1', 'lib2']


# Generated at 2022-06-21 18:34:47.125275
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/test1')
    output = Path('/test2')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-21 18:34:49.890475
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    io = InputOutput(input, output)
    assert io[0] == input
    assert io[1] == output

# Generated at 2022-06-21 18:34:51.386808
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(input=Path("in"), output=Path("out"))



# Generated at 2022-06-21 18:34:55.522887
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=5,
                           time=1.2,
                           target=(2, 7),
                           dependencies=['a', 'b'])
    assert cr.files == 5
    assert cr.time == 1.2
    assert cr.target == (2, 7)
    assert cr.dependencies == ['a', 'b']



# Generated at 2022-06-21 18:35:32.451040
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = InputOutput(input=Path("input"), output=Path("output"))
    assert a.input.name == "input"
    assert a.output.name == "output"

# Generated at 2022-06-21 18:35:33.647204
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('input'), Path('output'))

# Generated at 2022-06-21 18:35:40.833151
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=None, tree_changed=False,
                              dependencies=[])
    assert isinstance(tr, TransformationResult)


# Type of the transformer function
Transformer = lambda *args, **kwargs: None  # type: ignore


# Type of the function which transforms the list
# of paths in the list of tuples of input/output path pairs
GetIOFiles = lambda *args, **kwargs: None  # type: ignore


# Type of the function which transforms the AST
# into the AST
Transformer = lambda *args, **kwargs: None  # type: ignore


# Type of the function which generates the AST
# from the byte-string
GetAST = lambda *args, **kwargs: None  # type: ignore


# Type of the function which generates the byte-code
# from the AST

# Generated at 2022-06-21 18:35:43.007511
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=2, target=(3, 4), dependencies=['a'])


# Generated at 2022-06-21 18:35:50.643367
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=2,
                            time=1.5,
                            target=(2, 7),
                            dependencies=['/path/to/module.py'])
    assert res.files == 2
    assert res.time == 1.5
    assert res.target == (2, 7)
    assert res.dependencies == ['/path/to/module.py']
    assert repr(res) == ("CompilationResult(files=2, "
                         "time=1.5, "
                         "target=(2, 7), "
                         "dependencies=['/path/to/module.py'])")


# Generated at 2022-06-21 18:35:55.669273
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=1, time=1.0, target=(3, 2), dependencies=[])
    assert type(res.files) is int
    assert type(res.time) is float
    assert type(res.target) is tuple
    assert type(res.dependencies) is list


# Generated at 2022-06-21 18:35:58.975091
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path("input")
    output = Path("output")
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-21 18:36:00.288995
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(1, 2, 3) == (1, 2, 3)

# Generated at 2022-06-21 18:36:11.253246
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from datetime import datetime
    from typed_ast import ast3
    t = ast3.parse(
        """
x = "hello"
""")
    assert TransformationResult(t, True, ["a", "b"]) == \
        TransformationResult(t, True, ["a", "b"])
    assert TransformationResult(t, True, ["a", "b"]) != \
        TransformationResult(t, True, ["a", "b", "c"])
    assert TransformationResult(t, True, ["a", "b"]) != \
        TransformationResult(t, False, ["a", "b"])
    assert TransformationResult(t, True, ["a", "b"]) != \
        TransformationResult(t, True, ["a", "b"])


# Which transformations should be applied

# Generated at 2022-06-21 18:36:15.295782
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=1.1,
                               target=(3, 4),
                               dependencies=[])
    assert result.files == 1
    assert result.time == 1.1
    assert result.target == (3, 4)
    assert result.dependencies == []


# Generated at 2022-06-21 18:37:43.518883
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    try:
        TransformationResult(None, None, None)  # type: ignore
    except Exception:
        assert False, 'TransformationResult constructor works not properly'
    else:
        assert True


test_TransformationResult()

# Generated at 2022-06-21 18:37:54.088312
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast1_tree = ast.parse('import random')
    ast2_tree = ast.parse('import random')
    TransformationResult(ast1_tree, True, [])
    TransformationResult(ast2_tree, False, [])
    assert TransformationResult(ast1_tree, True, []) == TransformationResult(ast2_tree, True, [])
    assert TransformationResult(ast1_tree, True, []) != TransformationResult(ast2_tree, False, [])
    assert TransformationResult(ast1_tree, True, []).tree == TransformationResult(ast2_tree, True, []).tree
    assert TransformationResult(ast1_tree, True, []).tree_changed == True
    assert TransformationResult(ast1_tree, True, []).dependencies == []

# Generated at 2022-06-21 18:37:57.141924
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(
        tree=ast.parse(""),
        tree_changed=True,
        dependencies=["foo", "bar"])
    assert result.tree
    assert result.tree_changed
    assert result.dependencies == ["foo", "bar"]

# Generated at 2022-06-21 18:37:58.349394
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=0, target=(3, 5), dependencies=[])

# Generated at 2022-06-21 18:38:02.666530
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput('a', 'b') == InputOutput(Path('a'), Path('b'))
    assert InputOutput('a', 'b') == (Path('a'), Path('b'))
    assert InputOutput('a', 'b') == (Path('a'), 'b')

# Generated at 2022-06-21 18:38:05.743132
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(2, 3.0, (3, 5), ['foo', 'bar']) == (2, 3.0, (3, 5), ['foo', 'bar'])


# Generated at 2022-06-21 18:38:08.574129
# Unit test for constructor of class InputOutput
def test_InputOutput():
    obj = InputOutput(Path('input.py'), Path('output.py'))
    assert obj.input == Path('input.py')
    assert obj.output == Path('output.py')

# Generated at 2022-06-21 18:38:10.463452
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=123, time=42.0, target=(3, 4), deps=['foo', 'bar'])

# Generated at 2022-06-21 18:38:12.490488
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert isinstance(TransformationResult(
        ast.Name('A', ast.Store()), True, []), TransformationResult)

# Generated at 2022-06-21 18:38:14.776743
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(ast.parse('pass'), False, [])
    assert result.tree is not None
    assert result.tree_changed == False
    assert isinstance(result.dependencies, list)

# The class provides storage and access to global parameters

# Generated at 2022-06-21 18:39:49.529381
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 42, (1, 7), [])

# Generated at 2022-06-21 18:39:53.733359
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_file = Path('input.py')
    output_file = Path('output.py')
    input_output = InputOutput(input_file, output_file)
    assert input_output.input == input_file
    assert input_output.output == output_file


# Generated at 2022-06-21 18:39:57.603901
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=42,
                               time=1.0,
                               target=(2, 7),
                               dependencies=['foo.py'])
    assert result.files == 42
    assert result.time == 1.0
    assert result.target == (2, 7)
    assert result.dependencies == ['foo.py']


# Generated at 2022-06-21 18:40:03.618472
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1, time=1.0, target=(3, 4), dependencies=[])
    assert compilation_result.files == 1
    assert compilation_result.time == 1.0
    assert compilation_result.target == (3, 4)
    assert compilation_result.dependencies == []


# Generated at 2022-06-21 18:40:04.882645
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(tree=None, tree_changed=False, dependencies=[])

# Generated at 2022-06-21 18:40:07.831081
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('print(1)')
    result = TransformationResult(tree, True, ['bar'])
    assert result.tree is tree
    assert result.tree_changed is True
    assert result.dependencies == ['bar']

# Generated at 2022-06-21 18:40:10.380746
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=1.0, target=(3, 2), dependencies=['hi'])
    assert cr.files == 1
    assert cr.time == 1.0
    assert cr.target == (3, 2)
    assert cr.dependencies == ['hi']


# Generated at 2022-06-21 18:40:12.648332
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.AST(), True, ['A','B']) == \
        TransformationResult(ast.AST(), True, ['A','B'])

# Generated at 2022-06-21 18:40:13.512848
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = _compilation_result()

# Perform unit tests for this module

# Generated at 2022-06-21 18:40:15.656891
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    res = TransformationResult(ast.AST(), False, ['d1', 'd2'])
    assert res.tree is not None
    assert res.tree_changed is False
    assert res.dependencies == ['d1', 'd2']