

# Generated at 2022-06-21 18:30:25.354255
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    r = TransformationResult(ast.AST(), True, [])
    assert r.tree is not None
    assert r.tree_changed is True
    assert r.dependencies == []


# Diagnostic message
Diagnostic = NamedTuple('Diagnostic', [('source_file', Path),
                                       ('diagnostic', str)])

# Result of transformation
TransformationStats = NamedTuple('TransformationStats',
                                 [('changed', int),
                                  ('unchanged', int),
                                  ('total', int)])


# Generated at 2022-06-21 18:30:27.384847
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = InputOutput(Path('x'), Path('y'))
    assert a.input.name == 'x'
    assert a.output.name == 'y'

# Generated at 2022-06-21 18:30:29.230560
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    o = CompilationResult(100, 2.3, (3, 5), [])
    assert o.files == 100
    assert o.time == 2.3
    assert o.target == (3, 5)
    assert o.dependencies == []


# Generated at 2022-06-21 18:30:30.866437
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input=Path('a'), output=Path('b')) == \
           InputOutput(input=Path('a'), output=Path('b'))

# Generated at 2022-06-21 18:30:35.379474
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('test_1.py')
    output = Path('test_1_ast.txt')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output



# Generated at 2022-06-21 18:30:42.334886
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    """Unit test for constructor of class TransformationResult.
    """
    import textwrap
    tree = ast.parse(textwrap.dedent(
        """
        from typing import List, Tuple
        import numpy as np
        from abc import ABCMeta, abstractmethod
        from numpy import linalg as LA
        def f(i):
            return float(i)
        """))
    # Assert type(tree) == ast.Module
    tr = TransformationResult(tree, False, ['abc'])
    assert tr.tree_changed == False
    assert tr.dependencies == ['abc']

# Generated at 2022-06-21 18:30:44.362791
# Unit test for constructor of class CompilationResult
def test_CompilationResult():

    # Build and validate an instance of CompilationResult
    _ = CompilationResult(files=0, time=0.0, target=(2, 7), dependencies=[])


# Generated at 2022-06-21 18:30:45.945090
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.Module()
    assert TransformationResult(tree, True, []).tree is tree
    assert TransformationResult(tree, False, []) == TransformationResult(tree, False, [])

# Generated at 2022-06-21 18:30:51.715327
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from typed_ast import ast3 as ast
    from typed_ast import typing3 as typing

    tree = ast.parse('x = 1\n')
    spec = TransformationResult(tree, True, ['a', 'b'])
    assert spec.tree           == ast.parse('x = 1\n')
    assert spec.tree_changed   == True
    assert spec.dependencies   == ['a', 'b']


# Generated at 2022-06-21 18:30:58.262703
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=2, time=0.5, target=(3, 7),
                           dependencies=['a', 'b'])
    assert cr.files == 2
    assert cr.time == 0.5
    assert cr.target == (3, 7)
    assert cr.dependencies == ['a', 'b']

# Generated at 2022-06-21 18:31:02.069027
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2.0, (3, 4), [])


# Generated at 2022-06-21 18:31:05.528994
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=3.14,
                      target=(3, 7), dependencies=['a', 'b'])


# Generated at 2022-06-21 18:31:09.482642
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('/path/to/input'), Path('/path/to/output'))
    assert input_output.input == Path('/path/to/input')
    assert input_output.output == Path('/path/to/output')


# Generated at 2022-06-21 18:31:13.757063
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    r = TransformationResult(ast.parse("1+2"), True, ["a.py"])
    assert isinstance(r.tree, ast.AST)
    assert r.tree_changed is True
    assert isinstance(r.dependencies, list)
    assert isinstance(r.dependencies[0], str)
    assert r.dependencies[0] == "a.py"

# Generated at 2022-06-21 18:31:17.997928
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree = ast.Module, tree_changed = True, dependencies = [])
    assert type(tr.tree) is ast.Module
    assert tr.tree_changed == True
    assert len(tr.dependencies) == 0


# Generated at 2022-06-21 18:31:23.532820
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(files=1, time=1.0, target=(3, 7),
                          dependencies=[])

    assert(r.files == 1)
    assert(r.time == 1.0)
    assert(r.target == (3, 7))
    assert(r.dependencies == [])


# Generated at 2022-06-21 18:31:30.921115
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # pylint: disable=protected-access
    cres = CompilationResult(files=1, time=0.1,
                             target=(2, 7),
                             dependencies=['a.py', 'b.py'])

    assert cres._fields == ('files', 'time', 'target', 'dependencies')
    assert cres.files == 1
    assert cres.time == 0.1
    assert cres.target == (2, 7)
    assert cres.dependencies == ['a.py', 'b.py']


# Generated at 2022-06-21 18:31:32.266862
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput('bar.txt', 'baz.txt')

# Generated at 2022-06-21 18:31:36.068187
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(5, 1.5, (3, 7), ['module1', 'module2'])
    assert r.files == 5
    assert r.time == 1.5
    assert r.target == (3, 7)
    assert r.dependencies == ['module1', 'module2']

# Generated at 2022-06-21 18:31:40.274653
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('in.py')
    output = Path('out.py')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output
    io.input = Path('sub/in.py')
    io.output = Path('sub/out.py')
    assert io.input != input
    assert io.output != output

# Generated at 2022-06-21 18:31:47.733410
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    """Test constructor of CompilationResult"""
    CompilationResult(files=1, time=123, target=(3, 7),
                      dependencies=['a', 'b'])


# Generated at 2022-06-21 18:31:51.407893
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=10,
                                           time=0.123,
                                           target=(3,7),
                                           dependencies=['a','b','c'])

    assert compilation_result.files == 10
    assert compilation_result.time == 0.123
    assert compilation_result.target == (3,7)
    assert compilation_result.dependencies == ['a','b','c']


# Generated at 2022-06-21 18:31:54.720896
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(None, None, None)
    assert tr.tree is None
    assert tr.tree_changed is None
    assert tr.dependencies is None


# Generated at 2022-06-21 18:32:03.907440
# Unit test for constructor of class InputOutput
def test_InputOutput():
    temp_dir = tempfile.mkdtemp()
    input_file = Path(temp_dir + '/input.py')
    output_file = Path(temp_dir + '/output.py')
    if not input_file.exists():
        input_file.touch()
    assert input_file.exists()
    assert not output_file.exists()
    input_output = InputOutput(input=input_file, output=output_file)
    assert input_output.input == input_file
    assert input_output.output == output_file


# Generated at 2022-06-21 18:32:11.019878
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    from datetime import datetime
    import time
    import random

    start_time = datetime.now()
    time.sleep(random.random())
    end_time = datetime.now()
    compilation_time = (end_time - start_time).total_seconds()
    time.sleep(random.random())
    CompilationResult(files=random.randrange(1, 10),
                      time=compilation_time,
                      target=(random.randrange(1, 10),
                              random.randrange(1, 10)),
                      dependencies=['a', 'b', 'c'])

# Generated at 2022-06-21 18:32:14.207444
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=10,
                             time=5.5,
                             target=(3, 4),
                             dependencies=['foo', 'bar'])

# Test-function for constructor of class InputOutput

# Generated at 2022-06-21 18:32:15.974360
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=ast.parse('pass'),
                                tree_changed=False,
                                dependencies=[]).tree_changed == False

# Generated at 2022-06-21 18:32:20.377791
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # type: () -> None
    assert CompilationResult(0, 0.0, (0, 0), []).files == 0
    assert CompilationResult(1, 0.0, (2, 3), []).target == (2, 3)
    assert CompilationResult(1, 0.0, (2, 3), []).dependencies == []


# Generated at 2022-06-21 18:32:22.801230
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('/tmp/input')
    output = Path('/tmp/output')
    InputOutput(input_, output)


# Generated at 2022-06-21 18:32:27.814070
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Test constructor
    assert InputOutput(Path('/home/user/input.txt'),
                       Path('/home/user/output.txt'))
    # Test invalid constructor
    with pytest.raises(TypeError):
        InputOutput(Path('/home/user/input.txt'), '/home/user/output.txt')

# Generated at 2022-06-21 18:32:34.606411
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from .types import TransformationResult
    tree = ast.AST()
    result = TransformationResult(tree, False, [])
    assert result.tree == tree
    assert result.tree_changed is False
    assert result.dependencies == []

# Generated at 2022-06-21 18:32:37.903223
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    arb_dependencies = list(range(3))
    arb_ast = ast.Module()
    assert TransformationResult(arb_ast, False, arb_dependencies)

# Generated at 2022-06-21 18:32:38.977882
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.AST(), False, []).__class__ is TransformationResult


# Generated at 2022-06-21 18:32:44.703701
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.parse('a=7'), True, ['a', 'b', 'c'])
    assert tr.tree == ast.parse('a=7')
    assert tr.tree_changed == True
    assert tr.dependencies == ['a', 'b', 'c']

# Information about a test
TestInfo = NamedTuple('TestInfo',
                      [('initial_module', str),
                       ('expected_module', str),
                       ('transformer', str)])

# Generated at 2022-06-21 18:32:47.959229
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(0, 0.0, (3, 7), [])
    assert c.time == 0.0


# Generated at 2022-06-21 18:32:52.760314
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree = None,
                                tree_changed = False,
                                dependencies = []) != None

# Result of transformer
TransformerResult = NamedTuple('TransformerResult',
                               [('changed', bool),
                                ('dependencies', List[str])])


# Generated at 2022-06-21 18:32:56.691995
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=5, time=0.5, target=(2, 7), dependencies=[])
    assert result.files == 5
    assert result.time == 0.5
    assert result.target == (2, 7)
    assert result.dependencies == []


# Generated at 2022-06-21 18:33:02.358127
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input.py')
    output = Path('output.py')

    assert InputOutput(input, output) == InputOutput(input, output)

    with pytest.raises(ValueError):
        InputOutput(str(input), str(output))

    with pytest.raises(ValueError):
        InputOutput(str(output), str(input))


# Generated at 2022-06-21 18:33:05.976058
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_pair = InputOutput(Path('hello.py'), Path('hello.py'))
    assert input_output_pair.input == Path('hello.py')
    assert input_output_pair.output == Path('hello.py')

# Generated at 2022-06-21 18:33:11.894747
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    dummy_tree = ast.AST()
    dummy_tree_changed = True
    dummy_dependencies = ['dummy dep 1', 'dummy dep 2']
    transformation_result = TransformationResult(dummy_tree,
                                                  dummy_tree_changed,
                                                  dummy_dependencies)
    assert transformation_result.tree == dummy_tree
    assert transformation_result.tree_changed == dummy_tree_changed
    assert transformation_result.dependencies == dummy_dependencies

# Generated at 2022-06-21 18:33:23.248320
# Unit test for constructor of class CompilationResult
def test_CompilationResult():  # noqa
    result = CompilationResult(files=1,
                               time=2.0,
                               target=(3, 4),
                               dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-21 18:33:25.032817
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    _ = CompilationResult(12, 3.14, (3, 6), [])


# Generated at 2022-06-21 18:33:28.713983
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tmp_tree = ast.parse('a=1')
    tmp_changed = True
    tmp_dependencies = ['aa', 'bb']
    tmp_t_r = TransformationResult(tmp_tree, tmp_changed, tmp_dependencies)
    assert tmp_t_r.tree == tmp_tree
    assert tmp_t_r.tree_changed == tmp_changed
    assert tmp_t_r.dependencies == tmp_dependencies

# Generated at 2022-06-21 18:33:30.657480
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.1, target=(3, 6), dependencies=[])
    assert result.files == 1
    assert result.time == 1.1
    assert result.target == (3, 6)


# Generated at 2022-06-21 18:33:33.632896
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 2.0, (3, 4), ['a', 'b'])


# Generated at 2022-06-21 18:33:37.508809
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('in')
    output = Path('out')
    pair = InputOutput(input, output)
    assert pair == InputOutput(input, output)
    assert pair.input == input
    assert pair.output == output



# Generated at 2022-06-21 18:33:39.264673
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(0, 0.0, (3, 6), [])


# Generated at 2022-06-21 18:33:45.414646
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(files=0, time=0.0, target=(0, 0), dependencies=[])
    # Check that the attributes are correct
    assert r.files == 0
    assert r.time == 0.0
    assert r.target == (0, 0)
    assert r.dependencies == []
    # Check that the result is hashable
    hash(r)


# Generated at 2022-06-21 18:33:54.360261
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse("x=1"), False, []).tree_changed == False
    assert TransformationResult(ast.parse("x=1"), True,  []).tree_changed == True
    assert TransformationResult(ast.parse("x=1"), False, ['a']).dependencies == ['a']
    assert TransformationResult(ast.parse("x=1"), True,  ['a']).dependencies == ['a']
    assert TransformationResult(ast.parse("x=1"), False, ['b']).dependencies == ['b']
    assert TransformationResult(ast.parse("x=1"), True,  ['b']).dependencies == ['b']



# Generated at 2022-06-21 18:33:57.729636
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=0, time=0.0, target=(3, 7), dependencies=[])

    assert result.files == 0
    assert result.time == 0.0
    assert result.target == (3, 7)
    assert result.dependencies == []


# Generated at 2022-06-21 18:34:08.541906
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.parse(""), True, [])
    assert tr.tree_changed is True

# Generated at 2022-06-21 18:34:14.331815
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
  # Arrange
  files = 1
  time = 0.1
  target = (3, 6)
  dependencies = ['foo.py']

  # Act
  comp_res = CompilationResult(files, time, target, dependencies)

  # Assert
  assert comp_res.files == files
  assert comp_res.time == time
  assert comp_res.target == target
  assert comp_res.dependencies == dependencies


# Generated at 2022-06-21 18:34:15.957400
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    result = TransformationResult(ast.AST(), True, ['foo', 'bar'])
    assert result.tree_changed == True
    assert result.dependencies == ['foo', 'bar']

# Generated at 2022-06-21 18:34:17.220387
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(None, False, None)
    assert result.tree is None
    assert not result.tree_changed
    assert result.dependencies is None

# Generated at 2022-06-21 18:34:26.367030
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('input/hey')
    o = Path('output/hey')

    # Hash
    assert hash(InputOutput(i, o)) == hash((i, o))

    # Equality
    a = InputOutput(i, o)
    b = InputOutput(i, o)
    assert a == b
    assert not a != b

    # Inequality
    c = InputOutput(i, Path('output/ho'))
    assert not a == c
    assert a != c

    # Representation
    assert repr(a) == "InputOutput(input=PosixPath('input/hey'), output=PosixPath('output/hey'))"


# Generated at 2022-06-21 18:34:28.109890
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 2.0, (3, 4), [])


# Generated at 2022-06-21 18:34:30.878078
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('y = 1', 'tmp.py')
    tr = TransformationResult(tree=t,
                              tree_changed=False,
                              dependencies=[])
    assert tr.tree_changed == False
    assert tr.dependencies == []

# Generated at 2022-06-21 18:34:31.973028
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('None')
    assert TransformationResult(tree, True, [])

# Generated at 2022-06-21 18:34:35.463318
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1,
                                           time=2.0,
                                           target=(3, 4),
                                           dependencies=['dependency1',
                                                         'dependency2'])
    assert compilation_result.files == 1
    assert compilation_result.time == 2.0
    assert compilation_result.target == (3, 4)
    assert compilation_result.dependencies == ['dependency1', 'dependency2']

# Generated at 2022-06-21 18:34:45.748528
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    tr = TransformationResult(tree, True, ['a.py', 'b.py'])
    assert tr.tree == tree
    assert tr.tree_changed == True
    assert tr.dependencies == ['a.py', 'b.py']

# Test variable name
TEST_VARIABLE_NAME = 'test'

# Default __init__ function name
__INIT__ = '__init__'

# Empty dict
EMPTY_DICT = '{}'

# Empty tuple
EMPTY_TUPLE = '()'

# Prefix of the debug log
DEBUG_PREFIX = '### DEBUG: '

# Allowed functions names in compilation result
COMPILATION_RESULT_ALLOWED_NAMES = ['files', 'time', 'target', 'dependencies']

# Generated at 2022-06-21 18:35:11.476841
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1,
                                           time=1.0,
                                           target=(3, 8),
                                           dependencies=["test1.py", "test2.py"])
    assert compilation_result.files == 1
    assert compilation_result.time == 1.0
    assert compilation_result.target == (3, 8)
    assert compilation_result.dependencies == ["test1.py", "test2.py"]


# Generated at 2022-06-21 18:35:17.946621
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Workflow:
    # - get initial data
    files = 2
    time = 0.1
    target = (2, 7)
    dependencies = ['x', 'y', 'z']
    # - invoke target constructor
    res = CompilationResult(files, time, target, dependencies)
    # - check that result is correct
    assert (res.files == files)
    assert (res.time == time)
    assert (res.target == target)
    assert (res.dependencies == dependencies)


# Generated at 2022-06-21 18:35:25.552667
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a'), Path('b')).input == Path('a')
    assert InputOutput(Path('a'), Path('b')).output == Path('b')
    assert InputOutput(Path('b'), Path('a')).input == Path('b')
    assert InputOutput(Path('b'), Path('a')).output == Path('a')
    # Test __repr__
    assert repr(InputOutput(Path('a'), Path('b'))) == \
        "InputOutput(input=PosixPath('a'), output=PosixPath('b'))"


# Generated at 2022-06-21 18:35:31.057979
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('path/to/input')
    output_path = Path('path/to/output')
    input_output = InputOutput(input_path, output_path)

    assert input_output.input == input_path
    assert input_output.output == output_path


# Generated at 2022-06-21 18:35:34.683673
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    TransformationResult(ast.AST(), True, ["d1", "d2"])


# Result of transformers transformation
CompilationError = NamedTuple('CompilationError',
                              [('tree', ast.AST),
                               ('error', ast.AST)])

# Generated at 2022-06-21 18:35:37.491911
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(None, None, None)
    assert result.tree is None
    assert result.tree_changed is None
    assert result.dependencies is None


# Gets the AST from file, with caching

# Generated at 2022-06-21 18:35:48.464642
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, False, []).tree is None

# Result of preprocessor processing
ProcessingResult = NamedTuple('ProcessingResult',
                              [('result', str),
                               ('changed', bool),
                               ('dependencies', List[str])])

# Comment inserted in place of preprocessor directives
CommentReplacement = NamedTuple('CommentReplacement',
                                [('comment', str),
                                 ('label', str),
                                 ('replacement', str)])

# Preprocessor configuration

# Generated at 2022-06-21 18:35:50.938627
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(Path('a.txt'), Path('b.txt'))


# Generated at 2022-06-21 18:35:55.012445
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.Module()
    transformation_result = TransformationResult(tree, False, [])
    assert transformation_result.tree is tree
    assert transformation_result.tree_changed is False
    assert transformation_result.dependencies == []

# Generated at 2022-06-21 18:35:57.588428
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = InputOutput(input=Path('a'), output='b')
    assert a.input == Path('a')
    assert a.output == Path('b')

# Generated at 2022-06-21 18:36:40.466931
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(tree=ast.parse('def foo(): print("foo")'),
                         tree_changed=False,
                         dependencies=[])


# Generated at 2022-06-21 18:36:44.462428
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=0, time=0.0, target=(3, 0),
                            dependencies=[])
    assert res.files == 0
    assert res.time == 0.0
    assert res.target == (3, 0)
    assert res.dependencies == []


# Generated at 2022-06-21 18:36:45.876228
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(0, 0, None, None)
    assert cr


# Generated at 2022-06-21 18:36:47.849815
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=None, tree_changed=False, dependencies=[])
    assert tr.tree is None
    assert tr.tree_changed is False
    assert tr.dependencies == []

# Generated at 2022-06-21 18:36:54.072101
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 42
    time = 73.0
    target: CompilationTarget = (3, 6)
    dependencies = ["a", "b", "c"]
    cr = CompilationResult(files, time, target, dependencies)
    assert cr.files == files
    assert cr.time == time
    assert cr.target == target
    assert cr.dependencies == dependencies


# Generated at 2022-06-21 18:36:58.386330
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(ast.Name('i', ast.Store()),
                             False,
                             ['one.py', 'two.py'])
    assert t.tree is not None
    assert not t.tree_changed
    assert len(t.dependencies) == 2

# Generated at 2022-06-21 18:37:01.859747
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(input=Path('/in'),
                     output=Path('/out'))
    assert io.input == Path('/in')
    assert io.output == Path('/out')

# Generated at 2022-06-21 18:37:04.819183
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("")
    tree_changed = True
    dependencies = ['abc.py']
    _ = TransformationResult(tree, tree_changed, dependencies)

# Result of processing a file
FileResult = NamedTuple('FileResult',
                        [('changed', bool),
                         ('dependencies', List[str])])


# Generated at 2022-06-21 18:37:09.826523
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/home/input.py')
    output = Path('/home/output.py')
    input_output = InputOutput(input, output)

    assert input_output.input == input
    assert input_output.output == output
    assert input_output.input.name == 'input.py'
    assert input_output.output.name == 'output.py'

# Generated at 2022-06-21 18:37:12.239385
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.Module(), True, ['a', 'b'])
    assert repr(tr) == 'TransformationResult'


# Generated at 2022-06-21 18:38:47.795164
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput == InputOutput((Path('input.py'), Path('output.py')))


# Generated at 2022-06-21 18:38:49.789318
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    r = TransformationResult(1, False, [])
    assert r.tree == 1
    assert not r.tree_changed
    assert r.dependencies == []

# Generated at 2022-06-21 18:38:57.472709
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from test import example_module
    tree = ast.parse(example_module.__doc__)
    assert isinstance(tree, ast.Module)
    assert len(tree.body) == 2
    assert isinstance(tree.body[0], ast.FunctionDef)
    assert isinstance(tree.body[1], ast.ClassDef)

    # Check successful parse
    result = TransformationResult(tree=tree,
                                  tree_changed=True,
                                  dependencies=['foo', 'bar'])
    assert isinstance(result.tree, ast.Module)
    assert result.tree is tree
    assert result.tree_changed
    assert result.dependencies == ['foo', 'bar']

    # Check that class is immutable
    with pytest.raises(AttributeError):
        result.tree = ast.parse('import bar')

# Generated at 2022-06-21 18:38:58.943504
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(None, False, None)
    assert tr.tree is None
    assert tr.tree_changed is False
    assert tr.dependencies is None

# Generated at 2022-06-21 18:39:00.859747
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree_changed = False
    dependencies = ["a", "b"]
    tree = ast.AST()
    tr = TransformationResult(tree, tree_changed, dependencies)
    assert tr.tree is tree
    assert tr.tree_changed is tree_changed
    assert tr.dependencies == dependencies

# Generated at 2022-06-21 18:39:02.346621
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path('input'), Path('output'))
    assert isinstance(io, InputOutput)
    assert io.input == Path('input')
    assert io.output == Path('output')


# Generated at 2022-06-21 18:39:10.659268
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p1 = Path('/hi')
    p2 = Path('/bye')
    io1 = InputOutput(p1, p2)
    assert io1.input == p1
    assert io1.output == p2
    assert io1.input == p1
    assert io1.output == p2

    io2 = InputOutput(p1, p2)
    assert io1 == io2
    assert io2 == io1
    assert io1 == io1

    io3 = InputOutput(p2, p1)
    assert io1 != io3
    assert io3 != io1



# Generated at 2022-06-21 18:39:13.575597
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inputoutput = InputOutput('input', 'output')
    assert isinstance(inputoutput.input, Path)
    assert isinstance(inputoutput.output, Path)
    assert inputoutput.input == Path('input')
    assert inputoutput.output == Path('output')

# Generated at 2022-06-21 18:39:17.480719
# Unit test for constructor of class InputOutput
def test_InputOutput():
    x = InputOutput(input=Path('src/a.py'), output=Path('out/a.py'))
    assert x.input == Path('src/a.py')
    assert x.output == Path('out/a.py')

# Generated at 2022-06-21 18:39:19.801813
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput('a', 'b') == InputOutput(Path('a'), Path('b'))