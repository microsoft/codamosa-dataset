

# Generated at 2022-06-21 18:31:01.771939
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('1 + 3')
    tree_changed = True
    dependencies = ['a.py']
    t = TransformationResult(tree, tree_changed, dependencies)
    assert t.tree is tree and t.tree_changed is True and t.dependencies == dependencies

# Generated at 2022-06-21 18:31:06.927702
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path("input.txt")
    output_path = Path("output.txt")
    input_output = InputOutput(input_path, output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path


# Generated at 2022-06-21 18:31:11.480630
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 1.0, (3, 1), [])
    CompilationResult(1, 1.0, (3, 1), list())
    CompilationResult(1, 1.0, (3, 1), ['dependency'])
    CompilationResult(1, 1.0, (3, 1), ['dependency'])


# Generated at 2022-06-21 18:31:13.435363
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    dependencies = []
    tree = ast.parse('2 + 3')
    TransformationResult(tree, True, dependencies)
    TransformationResult(tree, False, dependencies)

# Generated at 2022-06-21 18:31:15.429138
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output

# Generated at 2022-06-21 18:31:18.324119
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path = Path('foo')
    input_output = InputOutput(path, path)
    assert input_output.input == path
    assert input_output.output == path

# Generated at 2022-06-21 18:31:21.341858
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    r = TransformationResult(tree=None, tree_changed=False,
                             dependencies=['a', 'b', 'c'])
    assert r is not None

# Generated at 2022-06-21 18:31:22.361463
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tuple(TransformationResult)

# Generated at 2022-06-21 18:31:32.764470
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    name = 'CompilationResult'
    fields = CompilationResult._fields
    assert 2 <= len(fields) <= 4
    assert fields[0] == 'time'
    assert fields[1] == 'dependencies'
    if len(fields) > 2:
        assert fields[2] == 'target'
    if len(fields) > 3:
        assert fields[3] == 'files'
    assert CompilationResult._field_types[fields[0]] == float
    assert CompilationResult._field_types[fields[1]] == List[str]
    if len(fields) > 2:
        assert CompilationResult._field_types[fields[2]] == CompilationTarget
    if len(fields) > 3:
        assert CompilationResult._field_types[fields[3]] == int

# Generated at 2022-06-21 18:31:34.972161
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse("1"), False, []).tree_changed == False

# Base class for all transformations

# Generated at 2022-06-21 18:31:37.549684
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert isinstance(TransformationResult(None, False, None), TransformationResult)

# Generated at 2022-06-21 18:31:40.787711
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.Expr('hello world')
    t = TransformationResult(tree=tree, tree_changed=True, dependencies=[])
    assert t.tree == tree
    assert t.tree_changed == True
    assert t.dependencies == []

# Generated at 2022-06-21 18:31:44.217321
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    dependencies = ['test.py']
    result = TransformationResult(tree, False, dependencies)
    assert result.tree == tree
    assert result.tree_changed == False
    assert result.dependencies == dependencies

# Generated at 2022-06-21 18:31:49.152043
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("x = 1")
    tr = TransformationResult(tree, True, ["mod1", "mod2"])
    assert tr.tree is tree
    assert tr.tree_changed is True
    assert tr.dependencies == ["mod1", "mod2"]

# Generated at 2022-06-21 18:31:52.499065
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('parts/my_module.py')
    output = Path('parts/my_module.js')
    assert InputOutput(input, output) == InputOutput(input, output)


# Generated at 2022-06-21 18:31:57.997239
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(1, 0.5, (2, 7), ["foo"])
    assert compilation_result.files == 1
    assert compilation_result.time == 0.5
    assert compilation_result.target == (2, 7)
    assert compilation_result.dependencies == ["foo"]


# Generated at 2022-06-21 18:32:00.963319
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CR = CompilationResult(0, 0, (0, 0), [])
    assert isinstance(CR, CompilationResult)


# Generated at 2022-06-21 18:32:06.269320
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path('/a'), Path('/b'))
    assert io.input == Path('/a')
    assert io.output == Path('/b')
    assert io.input == Path('/a')
    assert io.output == Path('/b')
    assert io.input.as_posix() == "/a"
    assert io.output.as_posix() == "/b"


# Generated at 2022-06-21 18:32:09.973292
# Unit test for constructor of class InputOutput
def test_InputOutput():
    g = InputOutput(input=Path('/tmp/pip.tgz'), output=Path('/tmp/pip'))
    assert g.input == Path('/tmp/pip.tgz')
    assert g.output == Path('/tmp/pip')

# Generated at 2022-06-21 18:32:11.344434
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(None, False, [])
    assert type(tr) == TransformationResult

# Generated at 2022-06-21 18:32:14.450057
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.parse('1+1'), False, [])

# Generated at 2022-06-21 18:32:15.576613
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=None, tree_changed=True, dependencies=[])

# Generated at 2022-06-21 18:32:17.561615
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(0, False, [])
    assert tr.tree == 0
    assert tr.tree_changed is False
    assert tr.dependencies == []

# Generated at 2022-06-21 18:32:21.610388
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_target = (3, 4)
    compilation_result = CompilationResult(files=3, time=2.2,
                                           target=compilation_target,
                                           dependencies=['a', 'b', 'c'])
    assert(compilation_result.files == 3)
    assert(compilation_result.time == 2.2)
    assert(compilation_result.target == compilation_target)
    assert(compilation_result.dependencies == ['a', 'b', 'c'])


# Generated at 2022-06-21 18:32:25.674369
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, False, None).tree_changed == False
    assert TransformationResult(None, True, None).tree_changed == True
    assert TransformationResult(None, True, None).dependencies == None


# Generated at 2022-06-21 18:32:30.807108
# Unit test for constructor of class InputOutput
def test_InputOutput():
    '''Unit test for constructor of class InputOutput'''
    input_path = Path('test_path')
    output_path = Path('test_path')
    input_output = InputOutput(input_path, output_path)
    assert isinstance(input_output, InputOutput)
    assert input_output.input == input_path
    assert input_output.output == output_path

# Generated at 2022-06-21 18:32:36.379880
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=2.0, target=(3, 4),
                               dependencies=['a', 'b'])
    assert isinstance(result, CompilationResult)
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == ['a', 'b']



# Generated at 2022-06-21 18:32:39.269232
# Unit test for constructor of class InputOutput
def test_InputOutput():
    pth = Path('/foo/bar')
    i_o = InputOutput(pth, pth)
    assert i_o.input == pth
    assert i_o.output == pth

# Generated at 2022-06-21 18:32:45.356530
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree_new = ast.parse('x = a')
    tree_old = ast.parse('y = b')
    transformation_result = TransformationResult(
        tree=tree_new,
        tree_changed=True,
        dependencies=['a', 'b'])
    assert(transformation_result.tree == tree_new)
    assert(transformation_result.tree != tree_old)
    assert(transformation_result.tree_changed is True)
    assert(transformation_result.dependencies == ['a', 'b'])

# Generated at 2022-06-21 18:32:48.343258
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(0, 0.0, (2, 7), ["test"])


# Generated at 2022-06-21 18:32:53.165078
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(tree=ast.parse('1'),
                     tree_changed=True,
                     dependencies=['/a/b.py'])

# Generated at 2022-06-21 18:33:00.180705
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, False, None).tree is None
    assert TransformationResult(None, False, None).tree_changed is False
    assert TransformationResult(None, False, None).dependencies is None
    assert TransformationResult(None, True, None).tree is None
    assert TransformationResult(None, True, None).tree_changed is False
    assert TransformationResult(None, True, None).dependencies is None
    assert TransformationResult(None, False, []).tree is None
    assert TransformationResult(None, False, []).tree_changed is False
    assert TransformationResult(None, False, []).dependencies == []
    assert TransformationResult(None, True, []).tree is None
    assert TransformationResult(None, True, []).tree_changed is False
    assert TransformationResult(None, True, []).dependencies == []

# Generated at 2022-06-21 18:33:02.507697
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=[])


# Generated at 2022-06-21 18:33:04.555480
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    TransformationResult(ast.parse('a = 2'), True, [])


# Generated at 2022-06-21 18:33:07.165566
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(input='a', output='b')
    assert io.input == Path('a')
    assert io.output == Path('b')

# Generated at 2022-06-21 18:33:09.591131
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path("input.txt")
    output = Path("output.txt")
    assert_equal(InputOutput(input, output),
                 InputOutput(input, output))

# Generated at 2022-06-21 18:33:13.996931
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 100
    time = 0.1
    target = (3, 7)
    dependencies = ["a.py", "b.py"]
    c = CompilationResult(files, time, target, dependencies)
    assert c.files == files
    assert c.time == time
    assert c.target == target
    assert c.dependencies == dependencies


# Generated at 2022-06-21 18:33:15.405681
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput('a', 'b') == InputOutput(Path('a'), Path('b'))

# Generated at 2022-06-21 18:33:18.774821
# Unit test for constructor of class InputOutput
def test_InputOutput():
    in_ = Path('in')
    out = Path('out')
    io = InputOutput(in_, out)
    assert io.input == in_
    assert io.output == out

# Generated at 2022-06-21 18:33:24.794081
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(files=1, time=2.0, target=(3, 4),
                          dependencies=['a', 'b', 'c'])
    assert r.files == 1
    assert r.time == 2.0
    assert r.target == (3, 4)
    assert r.dependencies == ['a', 'b', 'c']


# Generated at 2022-06-21 18:33:34.686500
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=0, time=0, target=(2, 7), dependencies=[])
    assert result.files == 0
    assert result.time == 0
    assert result.target == (2, 7)
    assert result.dependencies == []



# Generated at 2022-06-21 18:33:41.294757
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('42')
    result = TransformationResult(tree, True, ['file1', 'file2'])
    assert result.tree == tree
    assert result.tree_changed
    assert result.dependencies == ['file1', 'file2']

__all__ = [
    'CompilationResult',
    'CompilationTarget',
    'InputOutput',
    'TransformationResult',
    'test_TransformationResult',
]

# Generated at 2022-06-21 18:33:43.073215
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path("input"), Path("output")) == InputOutput("input", "output")


# Generated at 2022-06-21 18:33:46.068091
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=0.1, target=(2, 7),
                      dependencies=['module1', 'module2'])



# Generated at 2022-06-21 18:33:47.991698
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path("a.py")
    output = Path("a.pyc")
    InputOutput(input, output)

# Generated at 2022-06-21 18:33:50.195532
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, False, []) == \
           TransformationResult(None, False, [])

# Generated at 2022-06-21 18:33:53.546830
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_file = Path('test_input')
    output_file = Path('test_output')

    io = InputOutput(input_file, output_file)

    assert io.input == input_file
    assert io.output == output_file

# Generated at 2022-06-21 18:33:57.877036
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    TransformationResult(ast.Module([]), False, [])

    TransformationResult(ast.Module([]), True, [])

    TransformationResult(ast.Module([]), False, ["module1", "module2"])

    TransformationResult(ast.Module([]), True, ["module1", "module2"])

# Generated at 2022-06-21 18:33:59.938775
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast.parse('1+1')
    TransformationResult(tree=None, tree_changed=True, dependencies=[])

# Generated at 2022-06-21 18:34:04.724864
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    x = ast.AST()
    y = TransformationResult(tree=x, tree_changed=True, dependencies=[])
    z = TransformationResult(tree=x, tree_changed=False, dependencies=[])
    assert y.tree_changed
    assert not z.tree_changed
    assert y.tree is x
    assert z.tree is x

# Generated at 2022-06-21 18:34:15.838683
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input='input', output='output')
    assert not InputOutput(input='input', output='output').tree_changed
    assert not InputOutput(input='input', output='output').dependencies

# Generated at 2022-06-21 18:34:18.430823
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=42,
                                           time=1.42,
                                           target=(3, 5),
                                           dependencies=[])
    assert compilation_result.files == 42
    assert compilation_result.time == 1.42
    assert compilation_result.target == (3, 5)
    assert compilation_result.dependencies == []

# Tests for constructor of class InputOutput

# Generated at 2022-06-21 18:34:22.230320
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('/some/path')
    output_path = Path('/other/path')
    p = InputOutput(input_path, output_path)
    assert p.input == input_path
    assert p.output == output_path

# Generated at 2022-06-21 18:34:26.877055
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=2, time=0.1, target=(3, 7), dependencies=['__future__'])
    assert cr.files == 2
    assert cr.time == 0.1
    assert cr.target == (3, 7)
    assert cr.dependencies == ['__future__']



# Generated at 2022-06-21 18:34:30.197755
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=1.0, target=(3, 7), dependencies=[])
    assert cr.files == 1
    assert cr.time == 1.0
    assert cr.target == (3, 7)
    assert cr.dependencies == []



# Generated at 2022-06-21 18:34:34.620267
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    class A(ast.AST):
        _fields = ('x',)
        _attributes = ('y',)

    a = A(None, y=0)
    assert TransformationResult(tree=a, tree_changed=False, dependencies=[]) == TransformationResult(tree=a, tree_changed=False, dependencies=[])


# Generated at 2022-06-21 18:34:36.487799
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(0, 0.3, (3, 7), [])


# Generated at 2022-06-21 18:34:41.775954
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    obj = CompilationResult(100, 3.5, (2, 7), ['a', 'b'])
    assert obj.files == 100
    assert obj.time == 3.5
    assert obj.target == (2, 7)
    assert obj.dependencies == ['a', 'b']


# Generated at 2022-06-21 18:34:44.852182
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = InputOutput(Path('input'), Path('input'))
    assert isinstance(i.input, Path)
    assert isinstance(i.output, Path)
    assert i.input == Path('input')
    assert i.output == Path('input')

# Generated at 2022-06-21 18:34:50.064403
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # pylint: disable=unused-variable
    tree = ast.parse("a = 1")
    tree_changed = False
    dependencies = []
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-21 18:35:04.242906
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('input')
    out = Path('output')
    io = InputOutput(input=inp,
                     output=out)
    assert io.input == inp and io.output == out

# Generated at 2022-06-21 18:35:06.082657
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    try:
        TransformationResult()  # type: ignore
    except TypeError:
        pass

# Generated at 2022-06-21 18:35:11.364746
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('/home/user/file.py')
    outp = Path('/home/user/file.py.orig')
    pair = InputOutput(input=inp, output=outp)
    assert pair.input == inp
    assert pair.output == outp


# Generated at 2022-06-21 18:35:13.238919
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=None,
                                tree_changed=False,
                                dependencies=None).tree_changed is False

# Generated at 2022-06-21 18:35:16.071900
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p1 = Path('/tmp/a')
    p2 = Path('/tmp/b')

    assert InputOutput(p1, p2)
    

# Generated at 2022-06-21 18:35:17.527374
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('in.txt'), Path('out.txt')) is not None


# Generated at 2022-06-21 18:35:19.140894
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Should not fail
    InputOutput(Path('a/b'), Path('x/y'))


# Generated at 2022-06-21 18:35:24.691550
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Arrange
    # Act
    r = CompilationResult(files=42, time=3.14, target=(3, 4), dependencies=['foo', 'bar'])

    # Assert
    assert r.files == 42
    assert r.time == 3.14
    assert r.target == (3, 4)
    assert r.dependencies == ['foo', 'bar']

# Generated at 2022-06-21 18:35:29.050825
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # pylint: disable=invalid-name
    IO = InputOutput('1', '2')
    assert IO.input == Path('1')
    assert IO.output == Path('2')
    # pylint: enable=invalid-name

# Generated at 2022-06-21 18:35:31.684183
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    n = CompilationResult(files=1, time=0.1,
                          target=(3, 0), dependencies=['a', 'b'])
    return n


# Generated at 2022-06-21 18:35:58.520339
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(1, 0.1, (2, 7), [])

    assert compilation_result.files == 1
    assert compilation_result.time == 0.1
    assert compilation_result.target == (2, 7)
    assert compilation_result.dependencies == []


# Generated at 2022-06-21 18:36:03.707006
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(42, 1.234, (3, 7), ['/path/to/dependency'])
    assert compilation_result.files == 42
    assert compilation_result.time == 1.234
    assert compilation_result.target == (3, 7)
    assert compilation_result.dependencies == ['/path/to/dependency']


# Generated at 2022-06-21 18:36:08.027518
# Unit test for constructor of class InputOutput
def test_InputOutput():
    result = InputOutput(Path('a.in'), Path('a.out'))

    assert(result.input == Path('a.in'))
    assert(result.output == Path('a.out'))

# Test transformation

# Generated at 2022-06-21 18:36:11.365483
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('a')
    output = Path('b')

    input_output = InputOutput(input=input, output=output)

    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-21 18:36:13.673865
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('aaa')
    o = Path('bbb')
    pair = InputOutput(i, o)
    assert pair.input == i
    assert pair.output == o

# Generated at 2022-06-21 18:36:16.251906
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('')
    result = TransformationResult(tree, True, [])
    assert result.tree == tree
    assert result.dependencies == []
    assert result.tree_changed == True

# Generated at 2022-06-21 18:36:17.624240
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, False, None) == \
        TransformationResult(None, False, None)

# Generated at 2022-06-21 18:36:21.523993
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('__init__.py')
    output = Path('__init__.pyc')

    io = InputOutput(input, output)

    assert io.input == input
    assert io.output == output


# Generated at 2022-06-21 18:36:24.477577
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('a')
    o = Path('b')
    io = InputOutput(i, o)
    assert io.input == i
    assert io.output == o


# Generated at 2022-06-21 18:36:28.617858
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(ast.AST(), True, [])
    res.tree_changed


# Result of generator
GenerationResult = NamedTuple('GenerationResult', [('code', str),
                                                   ('dependencies', List[str])])

# Generated at 2022-06-21 18:37:27.231757
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=10, time=1.5, target=(3, 5), dependencies=['file1.py', 'file2.py'])
    assert result.files == 10
    assert result.time == 1.5
    assert result.target == (3, 5)
    assert result.dependencies == ['file1.py', 'file2.py']



# Generated at 2022-06-21 18:37:32.804290
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    from testfixtures import compare
    from random import randint
    from time import time
    files, time_, target, deps = randint(10,1000), time(), (3, 5), [str(i) for i in range(randint(5,30))]
    compare(CompilationResult(files, time_, target, deps),
            CompilationResult(files, time_, target, deps))


# Generated at 2022-06-21 18:37:37.587624
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test_ast = ast.parse('pass')
    test_dependencies = []

    res = TransformationResult(test_ast, True, test_dependencies)

    assert res.tree == test_ast
    assert res.tree_changed == True
    assert res.dependencies == test_dependencies

# Result of code generation
CodeGenerationResult = NamedTuple('CodeGenerationResult',
                                  [('file_content', str),
                                   ('dependencies', List[str])])


# Generated at 2022-06-21 18:37:41.892984
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.AST()
    result = TransformationResult(t, True, ['1', '2'])
    assert result.tree_changed
    assert result.tree == t
    assert result.dependencies == ['1', '2']

# Generated at 2022-06-21 18:37:50.459869
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr1 = CompilationResult(files=1, time=0.0, target=(3, 4), dependencies=[])
    assert cr1.files == 1
    assert cr1.time == 0.0
    assert cr1.target == (3, 4)
    assert cr1.dependencies == []

    cr2 = CompilationResult(files=1,
                            time=0.0,
                            target=(3, 4),
                            dependencies=['abc'])
    assert cr2.files == 1
    assert cr2.time == 0.0
    assert cr2.target == (3, 4)
    assert cr2.dependencies == ['abc']



# Generated at 2022-06-21 18:37:55.240597
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    i = CompilationResult(1, 0.1, (3,7), ['a', 'b'])
    assert i.files == 1
    assert i.time == 0.1
    assert i.target == (3, 7)
    assert i.dependencies == ['a', 'b']

# Generated at 2022-06-21 18:37:57.430605
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    class NotAST(object):
        pass

    with pytest.raises(TypeError):
        #noinspection PyArgumentList
        TransformationResult(NotAST(), True, [])

# Generated at 2022-06-21 18:38:00.145547
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=0.25, target=(2, 7), dependencies=[])
    assert cr.files == 1
    assert cr.time == 0.25
    assert cr.target == (2, 7)
    assert cr.dependencies == []

# Generated at 2022-06-21 18:38:03.757415
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(input=Path('test.in'), output=Path('test.out'))
    assert io.input.name == 'test.in'
    assert io.output.name == 'test.out'

# Generated at 2022-06-21 18:38:08.405662
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(1, 2.0, (3, 4), ['a', 'b'])
    assert isinstance(res.files, int)
    assert isinstance(res.time, float)
    assert isinstance(res.target, CompilationTarget)
    assert isinstance(res.dependencies, List[str])


# Generated at 2022-06-21 18:40:04.925888
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=2, target=(3, 4), dependencies=['x', 'y'])
    assert result.files == 1 and result.time == 2 and result.target == (3, 4) and result.dependencies == ['x', 'y']


# Generated at 2022-06-21 18:40:06.505976
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('a.py'), Path('a.c'))
    assert input_output.input == Path('a.py')
    assert input_output.output == Path('a.c')


# Generated at 2022-06-21 18:40:07.807520
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input=Path('/home'), output=Path('/tmp')) is not None

# Generated at 2022-06-21 18:40:08.739920
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    _ = TransformationResult(tree=None, tree_changed=False, dependencies=[])

# Generated at 2022-06-21 18:40:12.398668
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=0, time=0.0, target=(3, 5),
                            dependencies=['foo', 'bar'])
    assert res.files == 0
    assert res.time == 0.0
    assert res.target == (3, 5)
    assert res.dependencies == ['foo', 'bar']


# Generated at 2022-06-21 18:40:15.069710
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('inp')
    out = Path('out')
    io_pair = InputOutput(inp, out)

    assert io_pair.input == inp
    assert io_pair.output == out



# Generated at 2022-06-21 18:40:17.076408
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(3, 5), dependencies = [])

# Generated at 2022-06-21 18:40:22.722039
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    target = CompilationTarget(3, 7)
    compilation_result = CompilationResult(8, 3, target, ['one', 'two'])
    assert compilation_result.files == 8
    assert compilation_result.time == 3
    assert compilation_result.target == target
    assert compilation_result.dependencies == ['one', 'two']


# Generated at 2022-06-21 18:40:29.003451
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_node = ast.parse("x = 1")
    tr = TransformationResult(tree=ast_node, tree_changed=True, dependencies=[])
    assert(tr.tree == ast_node)
    assert(tr.tree_changed == True)
    assert(tr.dependencies == [])

# Result of code generator
CodeGenerationResult = NamedTuple('CodeGenerationResult',
                                  [('code', str),
                                   ('code_changed', bool),
                                   ('dependencies', List[str])])


# Generated at 2022-06-21 18:40:35.020978
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    import inspect

    assert len(TransformationResult._field_types) == 3
    assert ast.AST in TransformationResult._field_types
    assert bool in TransformationResult._field_types
    assert List[str] in TransformationResult._field_types
    assert inspect.isgenerator(TransformationResult._make(inspect.getargspec(TransformationResult)))
