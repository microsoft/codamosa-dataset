

# Generated at 2022-06-21 18:31:02.231639
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(1, 2, (3, 4), ["a", "b"])
    assert res.files == 1
    assert res.time == 2
    assert res.target == (3, 4)
    assert res.dependencies == ["a", "b"]
    assert len(res) == 4
    assert list(res) == [1, 2, (3, 4), ["a", "b"]]


# Generated at 2022-06-21 18:31:06.779131
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input0 = Path("a")
    output0 = Path("b")
    i0 = InputOutput(input=input0, output=output0)
    assert input0 == i0.input
    assert output0 == i0.output


# Generated at 2022-06-21 18:31:11.359904
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=5, time=5.5, target=(3, 6), dependencies=['test.py'])
    assert result.files == 5
    assert result.time == 5.5
    assert result.target == (3, 6)
    assert result.dependencies == ['test.py']


# Generated at 2022-06-21 18:31:15.794614
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input1 = Path(__file__)
    input2 = Path('test.txt')
    output1 = Path('output1.txt')
    output2 = Path('output2.txt')
    io1 = InputOutput(input1, output1)
    io2 = InputOutput(input2, output2)
    assert io1.input == input1
    assert io1.output == output1
    assert io2.input == input2
    assert io2.output == output2



# Generated at 2022-06-21 18:31:20.102038
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(
        tree=ast.Module(),
        tree_changed=False,
        dependencies=['a', 'b', 'c'])
    assert result.tree
    assert result.tree_changed == False
    assert result.dependencies == ['a', 'b', 'c']

# Generated at 2022-06-21 18:31:24.570066
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Arrange
    input = 'foo.py'
    output = 'bar.py'

    # Act
    io_pair = InputOutput(input, output)

    # Assert
    assert io_pair.input == Path(input)
    assert io_pair.output == Path(input)

# Generated at 2022-06-21 18:31:28.871730
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(1, 2.0, (3, 4), ['a', 'b'])
    assert c.files == 1
    assert c.time == 2.0
    assert c.target == (3, 4)
    assert c.dependencies == ['a', 'b']


# Generated at 2022-06-21 18:31:35.805566
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.Module([])
    tree_changed = True
    dependencies = []
    TransformationResult(tree, tree_changed, dependencies)

# Result of compilation
CompilationStatus = NamedTuple('CompilationStatus',
                               [('source', InputOutput),
                                ('compilation_result', CompilationResult)])

# Result of compilation
CompilationError = NamedTuple('CompilationError',
                              [('source', InputOutput),
                               ('error', Exception)])

# Generated at 2022-06-21 18:31:37.146558
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(0, 0.0, (0, 0), [])



# Generated at 2022-06-21 18:31:41.882074
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # preparation
    files = 1
    time = 10.1
    target = (3, 6)
    dependencies = []
    # test
    result = CompilationResult(files, time, target, dependencies)
    # check
    assert result.files == files
    assert result.time == time
    assert result.target == target
    assert result.dependencies == dependencies



# Generated at 2022-06-21 18:31:46.534489
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse('a'), True, [])
    assert TransformationResult(ast.parse('a'), False, [])
    assert TransformationResult(ast.parse('a'), False, ['b'])

# Generated at 2022-06-21 18:31:49.760263
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=2, time=4.2, target=(3, 4),
                          dependencies=['a', 'b'])
    assert c.files == 2
    assert c.time == 4.2
    assert c.target == (3, 4)
    assert c.dependencies == ['a', 'b']


# Generated at 2022-06-21 18:31:53.305228
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=['a'])
    assert c.files == 1
    assert c.time == 1.0
    assert c.target == (3, 6)
    assert c.dependencies == ['a']


# Generated at 2022-06-21 18:31:57.696407
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result = TransformationResult(
        ast.AST(),
        False,
        []
    )
    assert all(isinstance(attr, type(value))
               for attr, value
               in vars(transformation_result).items())

# Generated at 2022-06-21 18:31:59.064586
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.AST(), True, ['foo'])

# Generated at 2022-06-21 18:32:09.179114
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p = Path('a/b/c.py')

    i = InputOutput(input = p, output = p)
    assert i.input == Path('a/b/c.py')
    assert i.output == Path('a/b/c.py')

    i = InputOutput(input = p, output = 'a/b/d.py')
    assert i.input == Path('a/b/c.py')
    assert i.output == Path('a/b/d.py')

    i = InputOutput(input = 'a/b/c.py', output = 'a/b/d.py')
    assert i.input == Path('a/b/c.py')
    assert i.output == Path('a/b/d.py')


# Generated at 2022-06-21 18:32:14.302868
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.0, target=(3, 5),
                               dependencies=['file1', 'file2'])
    assert result.files == 1
    assert result.time == 0.0
    assert result.target == (3, 5)
    assert result.dependencies == ['file1', 'file2']


# Generated at 2022-06-21 18:32:15.461009
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(0, 0, (0, 0), [])


# Generated at 2022-06-21 18:32:17.448139
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse("1+1")
    result = TransformationResult(t, False, [])
    assert result.tree_changed is False
    assert result.dependencies == []

# Generated at 2022-06-21 18:32:23.271368
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=0, time=42.0,
                               target=(3, 6),
                               dependencies=['foo', 'bar'])
    assert result.files == 0
    assert result.time == 42.0
    assert result.target == (3, 6)
    assert result.dependencies == ['foo', 'bar']



# Generated at 2022-06-21 18:32:30.491529
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('test_file')
    output = Path('test_dest_file')
    assert InputOutput(input, output) == InputOutput(input, output)

# Generated at 2022-06-21 18:32:32.224945
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 1.0, (2, 3), [])



# Generated at 2022-06-21 18:32:33.939247
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput('input', 'output')

# Unit test fro constructor of class CompilationResult

# Generated at 2022-06-21 18:32:38.049429
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    tree = ast.parse("print 'Hello world!'")
    tr = TransformationResult(tree, False, [])
    assert(tr.tree == tree)
    assert(tr.tree_changed == False)
    assert(tr.dependencies == [])

# Generated at 2022-06-21 18:32:39.471797
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = InputOutput(input='test', output='test2')
    assert a.input.name == 'test'
    assert a.output.name == 'test2'



# Generated at 2022-06-21 18:32:43.198295
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(
        tree=ast.parse(''),
        tree_changed=True,
        dependencies=['../lib/a.py', '../lib/b.py']
    )
    assert tr.tree is not None

# Generated at 2022-06-21 18:32:45.338868
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(1, 2), dependencies=["s"])


# Generated at 2022-06-21 18:32:49.509119
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.Module,
                                True,
                                []).tree_changed == True
    assert TransformationResult(ast.Module,
                                True,
                                []).dependencies == []

# Generated at 2022-06-21 18:32:53.289468
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('print("hi")')
    dependencies = ['one', 'two']
    result = TransformationResult(tree, False, dependencies)
    assert result.tree is tree
    assert not result.tree_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-21 18:32:56.487785
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('test.py')
    output = Path('test.py.out')
    pair = InputOutput(input, output)
    assert pair.input == input
    assert pair.output == output

# Generated at 2022-06-21 18:33:08.022061
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('.')
    out = Path('.')
    io = InputOutput(inp, out)
    assert inp == io.input
    assert out == io.output


# Generated at 2022-06-21 18:33:12.006873
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Prepare
    input_ = Path('/tmp/a.py')
    output = Path('/tmp/a.pyc')
    # Run
    input_output = InputOutput(input_, output)
    # Assert
    assert input_output.input == input_
    assert input_output.output == output

# Generated at 2022-06-21 18:33:18.637616
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    from collections import abc
    from datetime import datetime
    from io import StringIO
    from subprocess import run
    import pytest

    files = len(Path(__file__).parent.glob('*.py'))
    cmd = ['python',
           '--version']
    python_version = run(cmd,
                         stdout=PIPE,
                         universal_newlines=True).stdout.splitlines()[0].split()[1]
    target = tuple(map(int, python_version.split('.')[:2]))
    with StringIO() as csvfile:
        start = datetime.now()
        CompilationResult(files, 0, target, []).csv(csvfile)
        stop = datetime.now()

# Generated at 2022-06-21 18:33:24.416783
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('a=1', '<unknown>')
    tr = TransformationResult(t, True, [])
    assert isinstance(tr, TransformationResult)
    assert isinstance(tr.tree, ast.AST)
    assert tr.tree_changed == True
    assert isinstance(tr.dependencies, list)

# Generated at 2022-06-21 18:33:27.186591
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    _ = CompilationResult(
        files=0,
        time=10.0,
        target=(3, 7),
        dependencies=[]
    )


# Generated at 2022-06-21 18:33:29.887976
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(
        tree=ast.parse('pass'),  # type: ignore
        tree_changed=True,
        dependencies=['a', 'b'])

# Generated at 2022-06-21 18:33:33.630153
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # pylint: disable=invalid-name
    CompilationResult(1, 3.0, (3, 6), ['a', 'b'])


# Generated at 2022-06-21 18:33:37.899406
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('import os')
    result = TransformationResult(
        tree=tree, tree_changed=True, dependencies=['os'])
    assert result
    assert result.tree == tree
    assert result.tree_changed is True
    assert result.dependencies == ['os']

# Generated at 2022-06-21 18:33:42.416818
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 3')
    tree_changed = True
    dependencies = ['a', 'b', 'c']
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree is tree
    assert result.tree_changed is tree_changed
    assert result.dependencies is dependencies

# Generated at 2022-06-21 18:33:47.027693
# Unit test for constructor of class InputOutput
def test_InputOutput():  # type: () -> None
    input_fn = Path('1.py')
    output_fn = Path('2.py')
    input_output = InputOutput(input=input_fn, output=output_fn)
    assert input_output.input == input_fn
    assert input_output.output == output_fn

# Generated at 2022-06-21 18:33:58.192955
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=10, time=10.0, target=(3, 5),
                             dependencies=['a', 'b', 'c'])

# Generated at 2022-06-21 18:34:00.685672
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('input'), Path('output'))
    # TODO: add case when input/output are not paths or are not strings

# Generated at 2022-06-21 18:34:03.972506
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('i')
    o = Path('o')
    pair = InputOutput(i, o)
    assert pair.input == i
    assert pair.output == o


# Generated at 2022-06-21 18:34:09.002815
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path("/tmp/input.txt"), Path("/tmp/output.txt"))
    assert input_output.input == Path("/tmp/input.txt")
    assert input_output.output == Path("/tmp/output.txt")

# Generated at 2022-06-21 18:34:12.435845
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = '/input/path'
    output_path = '/output/path'

    result = InputOutput(input=input_path, output=output_path)

    assert result.input == input_path
    assert result.output == output_path

# Generated at 2022-06-21 18:34:16.883395
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1,
                           time=0.1,
                           target=(3, 7),
                           dependencies=['foo', 'bar'])
    assert cr.files == 1
    assert cr.time == 0.1
    assert cr.target == (3, 7)
    assert cr.dependencies == ['foo', 'bar']



# Generated at 2022-06-21 18:34:21.352974
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    data = CompilationResult(files = 8, time = 0.03, target = (3, 7), dependencies = [])
    assert data.files == 8
    assert data.time == 0.03
    assert data.target == (3, 7)
    assert data.dependencies == []


# Generated at 2022-06-21 18:34:25.476300
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('test_input')
    output_path = Path('test_output')
    pair = InputOutput(input_path, output_path)
    assert pair.input == input_path
    assert pair.output == output_path


# Generated at 2022-06-21 18:34:30.199827
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    import copy
    import ast

    tree = copy.deepcopy(ast.parse('print(1)'))
    tree_changed = False
    dependencies = []
    # test with tree_changed = True, dependencies = []
    assert TransformationResult(tree, True, dependencies)

    # test with tree_changed = False, dependencies = ['a', 'b']
    assert TransformationResult(tree, False, ['a', 'b'])

# Generated at 2022-06-21 18:34:33.448136
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = "foo/bar/baz.py"
    outp = "foo/baz.py"
    input_output = InputOutput(Path(inp), Path(outp))
    assert input_output.input == Path(inp)
    assert input_output.output == Path(outp)



# Generated at 2022-06-21 18:34:54.505477
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(0, 0.0, (0, 0), []);
    assert cr.files == 0
    assert cr.time == 0.0
    assert cr.target == (0, 0)
    assert cr.dependencies == []


# Generated at 2022-06-21 18:34:58.087054
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # pylint: disable=pointless-statement, pointless-string-statement
    """Unit test for constructor of class InputOutput"""
    assert InputOutput is not None
    # pylint: enable=pointless-statement, pointless-string-statement

# Generated at 2022-06-21 18:35:00.535374
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-21 18:35:05.089676
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(42, 3600.0, (3,8), ['foo', 'bar'])
    assert res.files == 42
    assert res.time == 3600.0
    assert res.target == (3,8)
    assert res.dependencies == ['foo', 'bar']


# Generated at 2022-06-21 18:35:08.935713
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.AST(), False, [])
    TransformationResult(ast.AST(), True, [])
    TransformationResult(ast.AST(), True, ['a', 'b', 'c'])

# Generated at 2022-06-21 18:35:10.985724
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    unused = CompilationResult(10, 0.1, (2, 3), [])


# Generated at 2022-06-21 18:35:13.657886
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=None, tree_changed=False, dependencies=[])
    assert tr.tree is None
    assert tr.tree_changed is False
    assert tr.dependencies == []

# Generated at 2022-06-21 18:35:18.672569
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=5,
                               time=10.1,
                               target=(2, 7),
                               dependencies=['x', 'y', 'z'])
    assert result.files == 5
    assert result.time == 10.1
    assert result.target == (2, 7)
    assert result.dependencies == ['x', 'y', 'z']


# Generated at 2022-06-21 18:35:22.822697
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path_in = Path('1')
    path_out = Path('2')
    inputoutput = InputOutput(path_in, path_out)
    assert inputoutput.input == path_in
    assert inputoutput.output == path_out


# Generated at 2022-06-21 18:35:26.402802
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(
        ast.parse(''), True, ['a', 'b']
    )


# Async result of transformers transformation
# (producer of the result is responsible to create transformation result and
# to close the queue - consumer only reads the queue)
TransformationAsyncResult = Queue[TransformationResult]

# Generated at 2022-06-21 18:35:49.182367
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('.')
    output = Path('/')
    result = InputOutput(input_, output)
    assert result.input == input_
    assert result.output == output



# Generated at 2022-06-21 18:35:52.418852
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('in.txt')
    out = Path('out.txt')
    io = InputOutput(inp, out)
    assert io == (inp, out)

# Generated at 2022-06-21 18:35:57.586725
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_, output = Path("c:/temp/input_file.txt"), Path("c:/temp/output_file.txt")
    io = InputOutput(input_, output)
    assert io.input == input_
    assert io.output == output


# Test for __repr__ of the class InputOutput

# Generated at 2022-06-21 18:36:01.198911
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=[])
    assert cr.files == 1
    assert cr.time == 2.0
    assert cr.target == (3, 4)
    assert cr.dependencies == []


# Generated at 2022-06-21 18:36:04.077678
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.parse(""), True, [])
    assert isinstance(tr.tree, ast.AST)
    assert tr.tree_changed
    assert tr.dependencies == []

# Generated at 2022-06-21 18:36:08.069343
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(ast.AST(), True, ['a', 'b', 'c'])
    assert result.tree_changed == True
    assert result.dependencies == ['a', 'b', 'c']

# Generated at 2022-06-21 18:36:09.391586
# Unit test for constructor of class TransformationResult

# Generated at 2022-06-21 18:36:12.225202
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult
    result = tr(tree=None, tree_changed=True, dependencies=[])
    assert result.tree is None
    assert result.tree_changed and not result.tree_changed
    assert result.dependencies == []


# Generated at 2022-06-21 18:36:20.084913
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    import astor
    tr = TransformationResult(astor.to_ast(
        'print(1)'), True, ['a.py'])
    assert isinstance(tr.tree, ast.AST)
    assert tr.tree_changed is True
    assert isinstance(tr.dependencies, list)


# Result of transpilers transformation
TranspilationResult = NamedTuple('TranspilationResult',
                                 [('tree', ast.AST),
                                  ('dependencies', List[str])])

# Data for simple_transpiler function
TranspilationData = NamedTuple('TranspilationData',
                               [('input', Path),
                                ('output', Path),
                                ('target', CompilationTarget),
                                ('transpiler', str),
                                ('dependencies', List[str])])

# Data for simple

# Generated at 2022-06-21 18:36:24.145413
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('a/b/c.html')
    o = Path('a/b/c.py')
    pair = InputOutput(input=i, output=o)
    assert pair.input == i
    assert pair.output == o

# Generated at 2022-06-21 18:37:20.310883
# Unit test for constructor of class InputOutput
def test_InputOutput():
    in_ = Path('input')
    out = Path('output')

    assert InputOutput(in_, out) == InputOutput(in_, out)
    assert InputOutput(in_, out) == InputOutput(in_, Path('output'))
    assert InputOutput(in_, out) == InputOutput(Path('input'), out)
    assert InputOutput(in_, out) == InputOutput(Path('input'),
                                                Path('output'))
    assert InputOutput(in_, out) != InputOutput('input', out)
    assert InputOutput(in_, out) != InputOutput(in_, 'output')
    assert InputOutput(in_, out) != InputOutput('input', 'output')

# Generated at 2022-06-21 18:37:24.285519
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('a')
    o = Path('b')
    res = InputOutput(i, o)
    assert res.input == i
    assert res.output == o


# Generated at 2022-06-21 18:37:31.359827
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    dummy_dependencies = [Path("/foo/bar.py")]
    initializer = dummy_dependencies + \
                  [ast.Module(body=[]), True]
    tr = TransformationResult(*initializer)
    assert tr.dependencies == dummy_dependencies, \
        "Constructor of TransformationResult does not set the dependencies attribute correctly"
    assert tr.tree_changed == True, \
        "Constructor of TransformationResult does not set the tree_changed attribute correctly"



# Generated at 2022-06-21 18:37:34.226533
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.AST(lineno=1, col_offset=1)
    trans = TransformationResult(t, False, [])
    assert trans.tree == t
    assert trans.tree_changed == False
    assert trans.dependencies == []

# Generated at 2022-06-21 18:37:36.576107
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree: ast.AST = ast.parse('42')
    res = TransformationResult(tree, True, [])
    assert res.tree == tree
    assert res.tree_changed is True
    assert res.dependencies == []

# Generated at 2022-06-21 18:37:38.528353
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(input=Path('x'), output=Path('y'))

# Generated at 2022-06-21 18:37:41.335671
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(None, False, None)
    assert tr.tree is None
    assert not tr.tree_changed
    assert tr.dependencies is None

# Generated at 2022-06-21 18:37:43.670645
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path('a.py'), Path('b.py'))
    assert io.input == Path('a.py')
    assert io.output == Path('b.py')

# Generated at 2022-06-21 18:37:47.936991
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('print("Hello world!")')
    result = TransformationResult(tree=tree,
                                  tree_changed=True,
                                  dependencies=['<temp>'])
    assert result.tree is tree
    assert result.tree_changed is True
    assert result.dependencies == ['<temp>']

# Constructor for class TransformationResult

# Generated at 2022-06-21 18:37:53.767059
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(1, 1.0, (3, 5), [])
    assert cr.files == 1
    assert cr.time == 1.0
    assert cr.target == (3, 5)
    assert cr.dependencies == []


# Generated at 2022-06-21 18:39:39.503432
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(123, 1234.12, (3, 7), [])
    assert cr.files == 123
    assert cr.time == 1234.12
    assert cr.target == (3, 7)
    assert cr.dependencies == []

# Generated at 2022-06-21 18:39:43.000130
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    data = [('tree', ast.AST),
            ('tree_changed', False),
            ('dependencies', [])]
    TransformationResult._make(data)

# The abstract base class

# Generated at 2022-06-21 18:39:43.950649
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('path')
    o = Path('path')
    InputOutput(i, o)


# Generated at 2022-06-21 18:39:48.930382
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=10, time=10.0, target=(2, 7), dependencies=['a', 'b'])
    assert c.files == 10
    assert c.time == 10.0
    assert c.target == (2, 7)
    assert c.dependencies == ['a', 'b']


# Generated at 2022-06-21 18:39:54.237958
# Unit test for constructor of class InputOutput
def test_InputOutput():
    f = Path(os.path.sep.join(
        ('Users', 'ilya', 'bar', 'foo.txt')))
    g = Path(os.path.sep.join(
        ('Users', 'ilya', 'bar', 'foo2.txt')))
    assert InputOutput(f, g) == InputOutput(f, g)


# Generated at 2022-06-21 18:39:57.259572
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # pylint: disable=redefined-outer-name

    input = Path('a')
    output = Path('output')
    path = InputOutput(input=input, output=output)

    assert path.input == 'a'
    assert path.output == 'output'

# Generated at 2022-06-21 18:40:03.193121
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=0, time=0.0, target=(3, 5), dependencies=[])

    assert result.files == 0
    assert result.time == 0.0
    assert result.target[0] == 3
    assert result.target[1] == 5


# Generated at 2022-06-21 18:40:04.532108
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('1')
    TransformationResult(tree, True, [])

# Generated at 2022-06-21 18:40:07.142581
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 5')
    res = TransformationResult(tree, False, [])
    assert res.tree == tree
    assert res.tree_changed == False
    assert res.dependencies == []

# Generated at 2022-06-21 18:40:11.712209
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # type: () -> None
    res = InputOutput(input=Path('input.txt'), output=Path('output.txt'))
    assert isinstance(res, InputOutput)
    assert res.input == Path('input.txt')
    assert res.output == Path('output.txt')
    assert res.input != Path('other.txt')
    assert res.output != Path('other.txt')
