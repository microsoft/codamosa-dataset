

# Generated at 2022-06-21 18:30:40.248354
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(input=Path('input'), output=Path('output'))
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')

# Generated at 2022-06-21 18:30:43.729897
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=10, time=0.1, target=(3, 5),
                               dependencies=['math', 'numpy'])
    assert result.files == 10
    assert result.time == 0.1
    assert result.target == (3, 5)
    assert result.dependencies == ['math', 'numpy']


# Generated at 2022-06-21 18:30:48.173662
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree_changed = False
    dependencies = []
    tree = ast.parse('def foo(x):'
                     '    return x + 1')
    test = TransformationResult(tree,
                                tree_changed,
                                dependencies)
    assert test.tree == tree
    assert test.tree_changed == tree_changed
    assert test.dependencies == dependencies

# Generated at 2022-06-21 18:30:52.329513
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    match = CompilationResult(files=0, time=0.0, target=(2, 7), dependencies=['foo'])
    assert match.files == 0
    assert match.time == 0.0
    assert match.target == (2, 7)
    assert match.dependencies == ['foo']


# Generated at 2022-06-21 18:30:57.298824
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(0, 0.0, (3, 6), [])
    assert result.files == 0
    assert result.time == 0.0
    assert result.target == (3, 6)
    assert result.dependencies == []


# Generated at 2022-06-21 18:31:01.201129
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_file = Path('/home/repo/foo')
    output_file = Path('/home/bin/foo')
    io = InputOutput(input_file, output_file)
    assert io.input == input_file
    assert io.output == output_file



# Generated at 2022-06-21 18:31:04.072163
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=0.0, target=(3, 6), dependencies=[])
    assert cr.files == 1
    assert cr.time == 0.0
    assert cr.target == (3, 6)
    assert cr.dependencies == []


# Generated at 2022-06-21 18:31:09.044314
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    comp_result = CompilationResult(1, 2.0, (3, 4), ["a", "b"])
    assert comp_result.files == 1
    assert comp_result.time == 2.0
    assert comp_result.target == (3, 4)
    assert comp_result.dependencies == ["a", "b"]


# Generated at 2022-06-21 18:31:19.740060
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_0 = CompilationResult(1, 42.0, (3, 7), ["aaa.py", "bbb.py"])
    compilation_result_1 = CompilationResult(1, 42.0, (3, 7), ["aaa.py", "bbb.py"])
    compilation_result_2 = CompilationResult(1, 42.0, (3, 7), ["aaa.py", "bbb.txt"])
    assert compilation_result_0 == compilation_result_1
    assert compilation_result_1 == compilation_result_0
    assert compilation_result_0 != compilation_result_2
    assert compilation_result_2 != compilation_result_0
    assert hash(compilation_result_0) == hash(compilation_result_1)

# Generated at 2022-06-21 18:31:24.618345
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('def foo(): pass')
    tr = TransformationResult(tree=t,
                              tree_changed=False,
                              dependencies=[])
    assert tr.tree == ast.parse('def foo(): pass')
    assert not tr.tree_changed
    assert tr.dependencies == []

# Generated at 2022-06-21 18:31:29.613044
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inputoutput = InputOutput(Path('input'), Path('output'))
    assert inputoutput.input == Path('input')
    assert inputoutput.output == Path('output')


# Generated at 2022-06-21 18:31:35.805180
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    input_tree = ast.parse("")
    input_tree_changed = True
    input_dependencies = ["a", "b", "c"]
    res = TransformationResult(tree=input_tree,
                               tree_changed=input_tree_changed,
                               dependencies=input_dependencies)
    assert res.tree == input_tree
    assert res.tree_changed == input_tree_changed
    assert res.dependencies == input_dependencies

# Generated at 2022-06-21 18:31:39.153723
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path('/foo/bar')
    path2 = Path('/baz/foo/bar')
    pair = InputOutput(path1, path2)
    assert pair.input == path1
    assert pair.output == path2


# Generated at 2022-06-21 18:31:43.615006
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=1, time=2.0,
                          target=(3, 4),
                          dependencies=['a'])
    assert c.files == 1
    assert c.time == 2.0
    assert c.target == (3, 4)
    assert c.dependencies == ['a']


# Generated at 2022-06-21 18:31:54.094273
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse("x = 2")
    res = TransformationResult(t, False, [])
    assert res.tree == t


# Information about a transformer
TransformationInfo = NamedTuple('TransformationInfo', [('tree', ast.AST),
                                                       ('tree_changed', bool)])

# A function that transforms a python file
TransformFcn = Tuple[str, Callable[[ast.AST, Path, TransformationInfo],
                                   TransformationResult]]

# A package
Package = NamedTuple('Package', [('name', str), ('version', str)])

# Information about a dependency
DependencyInfo = NamedTuple('DependencyInfo', [('package', Package),
                                               ('dependencies', List[Package]),
                                               ('modules', List[str])])
DependencyInfo.__new__.__

# Generated at 2022-06-21 18:32:01.254200
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=2.0, target=(3, 4),
                           dependencies=['a', 'b'])
    assert isinstance(cr, CompilationResult)
    assert cr.files == 1
    assert cr.time == 2.0
    assert cr.target == (3, 4)
    assert cr.dependencies == ['a', 'b']


# Generated at 2022-06-21 18:32:04.619448
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/an-input-file/')
    output = Path('/an-output-file/')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output

# Generated at 2022-06-21 18:32:07.391422
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.Str(s='foo')
    r = TransformationResult(t, False, ['x.py'])
    assert r == TransformationResult(t, False, ['x.py'])


# Generated at 2022-06-21 18:32:10.066051
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('input')
    output = Path('output')
    test = InputOutput(input_, output)
    assert test.input == input_ and test.output == output

# Generated at 2022-06-21 18:32:11.432595
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput("input.py", "output.py")



# Generated at 2022-06-21 18:32:20.453915
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """
    Example:
    >>> f = InputOutput(Path('input.py'), Path('output.py'))
    >>> print(f)
    InputOutput(input=PosixPath('input.py'), output=PosixPath('output.py'))
    >>> f = InputOutput('input.py', 'output.py')
    >>> print(f)
    InputOutput(input=PosixPath('input.py'), output=PosixPath('output.py'))
    """
    pass


# Generated at 2022-06-21 18:32:26.548904
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=10, time=2.0, target=(2, 7), dependencies=['a', 'b', 'c'])
    assert cr.files == 10
    assert cr.time == 2.0
    assert cr.target == (2, 7)
    assert cr.dependencies == ['a', 'b', 'c']


# Generated at 2022-06-21 18:32:29.673198
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('123')
    output = Path('123')
    pair = InputOutput(input, output)
    assert pair.input == input
    assert pair.output == output


# Generated at 2022-06-21 18:32:39.735360
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    result = TransformationResult(tree=None, tree_changed=None, dependencies=[])
    assert result.tree is None
    assert result.tree_changed is None
    assert result.dependencies == []


# Result of module transformers
ModuleTransformationResult = NamedTuple('ModuleTransformationResult',
                                        [('file', Path),
                                         ('result', TransformationResult)])

# Result of class transformers
ClassTransformationResult = NamedTuple('ClassTransformationResult',
                                       [('tree', ast.AST),
                                        ('tree_changed', bool),
                                        ('dependencies', List[str]),
                                        ('rename', str),
                                        ('docstring', ast.AST)])

# Result of function transformers

# Generated at 2022-06-21 18:32:45.004883
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1,
                                           time=0.1,
                                           target=(3, 8),
                                           dependencies=['/usr/bin/python3'])
    assert compilation_result.files == 1
    assert compilation_result.time == 0.1
    assert compilation_result.target == (3, 8)
    assert compilation_result.dependencies == ['/usr/bin/python3']


# Generated at 2022-06-21 18:32:48.815811
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from test.utils import get_sample_ast
    tree = get_sample_ast()
    res = TransformationResult(tree, False, [])
    assert res.tree_changed == False

# Generated at 2022-06-21 18:32:57.613914
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=0.2, target=(2, 7),
                           dependencies=['a', 'b'])
    assert cr.files == 1
    assert cr.time == 0.2
    assert  cr.target == (2, 7)
    assert cr.dependencies == ['a', 'b']
    cr = CompilationResult(files=1, time=0.2, target=(2, 7),
                           dependencies=['a', 'b'])
    assert cr.files == 1
    assert cr.time == 0.2
    assert  cr.target == (2, 7)
    assert cr.dependencies == ['a', 'b']


# Generated at 2022-06-21 18:33:01.716169
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path('./fake.py')
    path2 = Path('fake.pyc')
    pair = InputOutput(input = path1, output = path2)
    assert pair.input == path1
    assert pair.output == path2

# Generated at 2022-06-21 18:33:05.375310
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.parse("a = 1"), True, ["a"])
    assert tr.tree_changed == True
    assert tr.dependencies == ["a"]
    assert tr.tree.body[0].value.n == 1

# Generated at 2022-06-21 18:33:09.409838
# Unit test for constructor of class InputOutput
def test_InputOutput():
    pair = InputOutput(Path('/home/sbl/a.py'), Path('/home/sbl/a.pyc'))
    assert pair.input == Path('/home/sbl/a.py')
    assert pair.output == Path('/home/sbl/a.pyc')

# Generated at 2022-06-21 18:33:18.371452
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path('src/main.py'), Path('bin/main.py'))

    assert io.input.name == 'main.py'
    assert io.output.name == 'main.py'
    assert io.input.stem == 'main'
    assert io.output.stem == 'main'
    assert io.input.suffix == '.py'
    assert io.output.suffix == '.py'
    assert io.input.parent == Path('src/')
    assert io.output.parent == Path('bin/')

# Generated at 2022-06-21 18:33:22.897662
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    tree = ast.parse('a = 3 + 5')
    TransformationResult(tree, True, ['foo', 'bar'])
    TransformationResult(tree, False, ['foo', 'bar'])

# Generated at 2022-06-21 18:33:27.838342
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('example_module')
    unchanged_tree = ast.parse('example_module')
    assert TransformationResult(tree, True, []) == \
        TransformationResult(unchanged_tree, False, [])


# Information about trust based compilation
TrustResult = NamedTuple('TrustResult',
                         [('trust', bool),
                          ('info', str)])

# Generated at 2022-06-21 18:33:30.293641
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0, target=(3, 9),
                               dependencies=['foo', 'bar'])
    assert result.files == 1
    assert result.time == 0
    assert result.target == (3, 9)
    assert result.dependencies == ['foo', 'bar']

# Generated at 2022-06-21 18:33:35.033624
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('')
    transformation_result = TransformationResult(tree, True, [])
    assert transformation_result.tree == tree
    assert transformation_result.tree_changed == True
    assert transformation_result.dependencies == []

# Generated at 2022-06-21 18:33:37.950401
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('in')
    output = Path('out')
    inout = InputOutput(input, output)
    assert inout.input == input
    assert inout.output == output

# Generated at 2022-06-21 18:33:44.074247
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=10,
                           time=1.2,
                           target=(2, 7),
                           dependencies=['foo', 'bar'])
    assert cr.files == 10
    assert cr.time == 1.2
    assert cr.target == (2, 7)
    assert cr.dependencies == ['foo', 'bar']

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 18:33:48.034438
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('input'), Path('output'))
    assert InputOutput(Path('input'), Path('output')).input == Path('input')
    assert InputOutput(Path('input'), Path('output')).output == Path('output')


# Generated at 2022-06-21 18:33:51.997308
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.AST(), True, [])
    assert TransformationResult(ast.AST(), False, [])
    assert TransformationResult(ast.AST(), True, ['abc'])
    assert TransformationResult(ast.AST(), False, ['abc'])

# Generated at 2022-06-21 18:33:55.439223
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path('path1')
    path2 = Path('path2')
    input_output = InputOutput(path1, path2)
    assert input_output.input == path1
    assert input_output.output == path2


# Generated at 2022-06-21 18:34:11.100460
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1, target=(3, 7), dependencies=['a.py', 'b.py'])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 7)
    assert result.dependencies == ['a.py', 'b.py']


# Generated at 2022-06-21 18:34:13.722074
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('abc')
    output = Path('cde')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output

# Generated at 2022-06-21 18:34:15.669650
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(1, 2.0, (3, 4), ['a'])
    assert c.files == 1
    assert c.time == 2.0
    assert c.target == (3, 4)
    assert c.dependencies == ['a']


# Generated at 2022-06-21 18:34:17.596205
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1,
                      time=0.0,
                      target=(3, 6),
                      dependencies=["a"])



# Generated at 2022-06-21 18:34:19.399298
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=2, target=(3, 4), dependencies=[])


# Generated at 2022-06-21 18:34:23.031502
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    input_output = InputOutput(input, output)
    assert input_output.input is input
    assert input_output.output is output

# Generated at 2022-06-21 18:34:27.513857
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=42, time=42.0, target=(3, 4), dependencies=['A', 'B'])
    assert result.files == 42
    assert result.time == 42.0
    assert result.target == (3, 4)
    assert result.dependencies == ['A', 'B']


# Generated at 2022-06-21 18:34:29.485994
# Unit test for constructor of class CompilationResult
def test_CompilationResult():  # pylint: disable=redefined-outer-name
    _ = CompilationResult(42, 1.3, (3, 9), [])



# Generated at 2022-06-21 18:34:32.992670
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=['stdin'])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == ['stdin']


# Generated at 2022-06-21 18:34:34.985865
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(
        files=2,
        time=4.0,
        target=(3, 4),
        dependencies=['a'])

# Generated at 2022-06-21 18:34:55.369618
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.AST(), False, []) == \
        TransformationResult(ast.AST(), False, [])

# Generated at 2022-06-21 18:34:57.315807
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(ast.Module(), True, ["a", "b"])
    assert not t.tree_changed
    assert t.dependencies == ["a", "b"]

# Generated at 2022-06-21 18:35:05.667537
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_tree = ast.parse('a=1')
    ast_dependencies = ['a']
    result = TransformationResult(ast_tree, True, ast_dependencies)
    assert type(result.tree) == ast.Module
    assert result.tree_changed
    assert type(result.dependencies) == list
    assert result.dependencies == ast_dependencies

# Result of compilation of single file
FileCompilationResult = NamedTuple('FileCompilationResult',
                                   [('input', InputOutput),
                                    ('result', CompilationResult)])

# Result of compilation of multiple files
CompilationResultBatch = NamedTuple('CompilationResultBatch',
                                    [('results', List[FileCompilationResult])])

# Generated at 2022-06-21 18:35:12.232724
# Unit test for constructor of class InputOutput
def test_InputOutput():
    with pytest.raises(TypeError) as excinfo:
        InputOutput(Path('.'), '.')
    assert 'input should be a Path' in str(excinfo.value)
    with pytest.raises(TypeError) as excinfo:
        InputOutput('.', Path('.'))
    assert 'output should be a Path' in str(excinfo.value)


# Generated at 2022-06-21 18:35:17.188013
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    target = (3, 7)
    res = CompilationResult(files=1,
                            time=1.0,
                            target=target,
                            dependencies=['a', 'b'])
    assert res.files == 1
    assert res.time == 1.0
    assert res.target == target
    assert res.dependencies == ['a', 'b']



# Generated at 2022-06-21 18:35:22.125487
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(42, 3.14, (3, 8), ['dependency1', 'dependency2'])
    assert result.files == 42
    assert result.time == 3.14
    assert result.target == (3, 8)
    assert result.dependencies == ['dependency1', 'dependency2']


# Generated at 2022-06-21 18:35:26.464817
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(1, 1.2, (2, 0), [])
    assert isinstance(compilation_result, CompilationResult)
    assert compilation_result.files == 1
    assert compilation_result.time == 1.2
    assert compilation_result.target == (2, 0)
    assert compilation_result.dependencies == []


# Generated at 2022-06-21 18:35:31.107167
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    a = CompilationResult(1, 1, (1, 1), [])
    assert(a.files == 1)
    assert(a.time == 1)
    assert(a.target == (1, 1))
    assert(a.dependencies == [])

# Generated at 2022-06-21 18:35:34.714829
# Unit test for constructor of class InputOutput
def test_InputOutput():
    t = InputOutput('/a/b', '/a/c')
    assert t.input == Path('/a/b')
    assert t.output == Path('/a/c')
    assert t == ('/a/b', '/a/c')



# Generated at 2022-06-21 18:35:38.098024
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_tree = ast.parse('some code')
    result = TransformationResult(ast_tree, False, [])
    assert isinstance(result.tree, ast.AST)
    assert result.tree_changed == False
    assert isinstance(result.dependencies, list)

# Generated at 2022-06-21 18:36:23.285011
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 2')
    res = TransformationResult(tree, tree_changed=True, dependencies=[])
    assert res.tree == tree
    assert res.tree_changed is True
    assert res.dependencies == []

# Generated at 2022-06-21 18:36:31.074406
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    """
    This is a test for constructor of class CompilationResult.
    """
    compilation_result = CompilationResult(files=4,
                                           time=2.0,
                                           target=(3, 5),
                                           dependencies=['abc', 'def'])
    assert compilation_result.files == 4
    assert compilation_result.time == 2.0
    assert compilation_result.target == (3, 5)
    assert compilation_result.dependencies == ['abc', 'def']


# Generated at 2022-06-21 18:36:34.630413
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(3, 4), dependencies=[])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 4)
    assert result.dependencies == []


# Generated at 2022-06-21 18:36:41.730765
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # input
    files = 1
    time = 0.1
    target = (3, 7)
    dependencies = []
    # expected output
    expected_result = CompilationResult(files=1,
                                        time=0.1,
                                        target=(3, 7),
                                        dependencies=[])
    # result
    result = CompilationResult(files=files,
                               time=time,
                               target=target,
                               dependencies=dependencies)
    # compare
    assert expected_result == result


# Generated at 2022-06-21 18:36:44.816537
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # type: () -> None
    input = Path('/aaa')
    output = Path('/bbb.py')
    pair = InputOutput(input, output)
    assert pair.input == input
    assert pair.output == output



# Generated at 2022-06-21 18:36:47.398048
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.parse('1'), True, ['test_deps'])
    assert isinstance(tr.tree, ast.AST)
    assert tr.tree_changed
    assert tr.dependencies == ['test_deps']


# Generated at 2022-06-21 18:36:49.948761
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('/a/b/c'), Path('/d/e/f'))
    assert input_output.input == Path('/a/b/c')
    assert input_output.output == Path('/d/e/f')


# Generated at 2022-06-21 18:36:56.016058
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1,
                                           time=0.5,
                                           target=(3, 7),
                                           dependencies=['foo/bar'])
    assert compilation_result.files == 1
    assert compilation_result.time == 0.5
    assert compilation_result.target == (3, 7)
    assert compilation_result.dependencies == ['foo/bar']


# Generated at 2022-06-21 18:36:59.294233
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=None, tree_changed=True, dependencies=["foo", "bar"])._asdict() == \
            OrderedDict([('tree', None), ('tree_changed', True), ('dependencies', ["foo", "bar"])])

# Generated at 2022-06-21 18:37:07.845074
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, True, [])
    assert TransformationResult(ast.parse('def f(x): return x'), False, [])


# Result of transformers application
# (ast.AST, bool): modified AST and changed flag
ApplicationResult = List[TransformationResult]

# Result of code generation
GenerationResult = NamedTuple('GenerationResult',
                              [('code', bytes),
                               ('tree', ast.AST),
                               ('encoding', str)])

# Set of errors that may occur
CompilerErrors = Union[Exception, ValueError]

# Generated at 2022-06-21 18:38:54.033709
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(
        files=0,
        time=0.0,
        target=(3, 5),
        dependencies=[]
    ).files == 0


# Generated at 2022-06-21 18:38:55.871715
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output

# Generated at 2022-06-21 18:38:58.968578
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('./input')
    output_path = Path('./output')
    input_output = InputOutput(input_path, output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path
    input_output.input = Path('./input2')
    assert input_output.input != input_path


# Generated at 2022-06-21 18:39:00.964568
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast = TransformationResult(tree=None, tree_changed=False, dependencies=None)
    pass

# Generated at 2022-06-21 18:39:06.830513
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 0.23, (3, 6), ['a', 'b'])
    assert result.files == 1
    assert result.time == 0.23
    assert result.target == (3, 6)
    assert result.dependencies == ['a', 'b']
    with pytest.raises(TypeError):
        CompilationResult('1', None, None, None)
    with pytest.raises(TypeError):
        CompilationResult(1, '0.23', None, None)
    with pytest.raises(TypeError):
        CompilationResult(1, 0.23, 'None', None)
    with pytest.raises(TypeError):
        CompilationResult(1, 0.23, None, 'None')


# Generated at 2022-06-21 18:39:09.623326
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('foo')
    o = Path('bar')
    inout = InputOutput(i, o)
    assert inout.input == i
    assert inout.output == o

# Generated at 2022-06-21 18:39:13.899357
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    x = CompilationResult(files=42, time=0.5, target=(3, 7),
                          dependencies=['foo.py', 'bar.py'])
    assert x.files == 42
    assert x.time == 0.5
    assert x.target == (3, 7)
    assert x.dependencies == ['foo.py', 'bar.py']

# Generated at 2022-06-21 18:39:17.106189
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # pylint: disable=unused-variable
    res = CompilationResult(files=0, time=0., target=(3, 7), dependencies=[])
    assert True

# Generated at 2022-06-21 18:39:21.141373
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(42, 0.5, (3, 5), [])
    assert r.files == 42
    assert r.time == 0.5
    assert r.target == (3, 5)
    assert r.dependencies == []


# Generated at 2022-06-21 18:39:22.757840
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=2, time=1.2, target=(3, 6), dependencies=['foo.py'])