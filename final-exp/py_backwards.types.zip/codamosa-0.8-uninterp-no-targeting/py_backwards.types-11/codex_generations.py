

# Generated at 2022-06-21 18:30:40.898757
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    dummy_tree = ast.Module()
    dummy_dependencies = []
    ret = TransformationResult(dummy_tree, False, dummy_dependencies)
    assert ret.tree == dummy_tree
    assert not ret.tree_changed
    assert ret.dependencies == dummy_dependencies
    assert str(ret) == "TransformationResult(tree=Module(body=[]), " + \
        "tree_changed=False, dependencies=[])"


# Generated at 2022-06-21 18:30:46.309696
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i1 = Path('/home/user/my_input')
    o1 = Path('/home/user/my_output')
    io1 = InputOutput(i1, o1)

    i2 = Path('/home/user/other_input')
    o2 = Path('/home/user/other_output')
    io2 = InputOutput(i2, o2)

    assert str(io1) != str(io2)
    assert str(io1) == 'InputOutput(input = /home/user/my_input, output = /home/user/my_output)'

# Generated at 2022-06-21 18:30:48.856367
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input = Path('input'),
                       output = Path('output'))


# Generated at 2022-06-21 18:30:50.468253
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(10, 10.5, (3, 7), ['a', 'b'])


# Generated at 2022-06-21 18:30:54.991904
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    _ = TransformationResult(tree=None, tree_changed=False, dependencies=[])


# Abstract class for ast transformer that implements a common interface.
# The interface is inspired by pytest and py.test.

# Generated at 2022-06-21 18:30:57.963241
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(tree=None,
                               tree_changed=False,
                               dependencies=None)
    asser

# Generated at 2022-06-21 18:30:59.861714
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(3, 1.0, (3, 6), [])
    assert result.files == 3
    assert result.time == 1.0
    assert result.target == (3, 6)
    assert result.dependencies == []


# Generated at 2022-06-21 18:31:04.146968
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    mock_params = (1, 2.0, (1, 2), ['foo', 'bar'])
    compilation_result = CompilationResult(*mock_params)
    assert compilation_result.files == 1
    assert compilation_result.time == 2.0
    assert compilation_result.target == (1, 2)
    assert compilation_result.dependencies == ['foo', 'bar']


# Generated at 2022-06-21 18:31:09.905220
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(
            files=6, time=1.23, target=(3, 7),
            dependencies=['a', 'b', 'c'])
    assert c.files == 6
    assert c.time == 1.23
    assert c.target == (3, 7)
    assert c.dependencies == ['a', 'b', 'c']
    assert c == CompilationResult(*c)


# Generated at 2022-06-21 18:31:10.818471
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.Pass(), False, [])

# Generated at 2022-06-21 18:31:17.945325
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path.cwd() / 'input'
    output_path = Path.cwd() / 'output'
    pair = InputOutput(input_path, output_path)
    assert pair.input == input_path
    assert pair.output == output_path



# Generated at 2022-06-21 18:31:23.227008
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(5, 2.5, (3, 6), [])
    assert compilation_result.files == 5
    assert compilation_result.time == 2.5
    assert compilation_result.target == (3, 6)
    assert compilation_result.dependencies == []


# Generated at 2022-06-21 18:31:25.852614
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 1.0, (3, 2), []) == CompilationResult(1, 1.0, (3, 2), [])


# Generated at 2022-06-21 18:31:31.601611
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=3, time=3.14159,
                            target=(3, 4),
                            dependencies=['foo', 'bar', 'baz'])
    assert res.files == 3
    assert res.time == 3.14159
    assert res.target == (3, 4)
    assert res.dependencies == ['foo', 'bar', 'baz']


# Generated at 2022-06-21 18:31:33.478344
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=10, time=20.0, target=(2, 7),
                      dependencies=['d1', 'd2'])



# Generated at 2022-06-21 18:31:34.073551
# Unit test for constructor of class TransformationResult

# Generated at 2022-06-21 18:31:37.241058
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    tr = TransformationResult(ast.parse('x = 1'), True, ['dep1.py'])
    assert tr.tree_changed
    assert len(tr.dependencies) == 1

# Generated at 2022-06-21 18:31:39.937247
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = "hello.py"
    o = "hello.js"
    assert InputOutput(i, o) == InputOutput(Path(i), Path(o))

# Generated at 2022-06-21 18:31:41.876440
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput('input', 'output')
    assert io.input == Path('input')
    assert io.output == Path('output')



# Generated at 2022-06-21 18:31:44.925962
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('a/b'), Path('c/d'))
    assert str(input_output) == "astor.InputOutput(input='a/b', output='c/d')"

# Generated at 2022-06-21 18:31:54.404891
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    source = Path('source.py')
    source.write_text('class Name:\n'
                      '    def __init__(self):\n'
                      '        pass\n')
    tree = ast.parse(source.read_text())
    result = TransformationResult(tree, False, [])

    assert len(result.tree.body) == 1
    assert isinstance(result.tree.body[0], ast.ClassDef)
    assert result.tree_changed is False
    assert result.dependencies == []

# Generated at 2022-06-21 18:31:56.622996
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('test_input.txt')

# Generated at 2022-06-21 18:32:00.234606
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('')
    tr = TransformationResult(tree, True, [])
    assert tr.tree is tree
    assert tr.tree_changed is True
    assert tr.dependencies == []

# Generated at 2022-06-21 18:32:03.677948
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=42, time=42.24,
                                           target=(3, 5), dependencies=['foo', 'bar'])
    assert 42 == compilation_result.files
    assert 42.24 == compilation_result.time
    assert (3, 5) == compilation_result.target
    assert ['foo', 'bar'] == compilation_result.dependencies


# Generated at 2022-06-21 18:32:06.115527
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('foo'), Path('bar')) == \
           InputOutput(input=Path('foo'), output=Path('bar'))


# Generated at 2022-06-21 18:32:08.058698
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CR = CompilationResult
    result = CR(1, 1, (3, 7), [])
    assert isinstance(result, CR)

# Generated at 2022-06-21 18:32:11.153701
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # pylint: disable=unused-variable
    tree = ast.parse("pass")
    value = TransformationResult(tree, False, [])
    value.tree
    value.tree_changed
    value.dependencies

# Generated at 2022-06-21 18:32:18.800275
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    try:
        TransformationResult(None, None, None)
        assert False
    except Exception as e:
        assert isinstance(e, TypeError)

    tree = ast.parse("")
    try:
        TransformationResult(tree, None, None)
        assert False
    except Exception as e:
        assert isinstance(e, TypeError)

    try:
        TransformationResult(tree, True, None)
        assert False
    except Exception as e:
        assert isinstance(e, TypeError)

    transformed_tree = TransformationResult(tree, True, [])
    assert transformed_tree.tree == tree
    assert transformed_tree.tree_changed == True
    assert transformed_tree.dependencies == []


# Generated at 2022-06-21 18:32:24.299738
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.1, target=(3, 6),
                               dependencies=['module_1'])
    assert result.files == 1
    assert result.time == 1.1
    assert result.target == (3, 6)
    assert result.dependencies == ['module_1']


# Generated at 2022-06-21 18:32:27.358941
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = "input.json"
    output = "output.bin"

    io = InputOutput(input, output)

    assert io.input == input
    assert io.output == output


# Generated at 2022-06-21 18:32:35.950374
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Input/output
    input = Path('test.in')
    output = Path('test.out')

    # Test constructor
    pair = InputOutput(input, output)
    assert(pair.input == input)

# Generated at 2022-06-21 18:32:38.825842
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = Path('a')
    b = Path('b')
    io = InputOutput(a, b)
    assert io.input == a
    assert io.output == b


# Generated at 2022-06-21 18:32:42.643805
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('1 + 1', mode="eval")
    tr = TransformationResult(tree, True, ['mod1', 'mod2'])
    assert(tr.tree_changed)
    assert(len(tr.dependencies) == 2)

# Generated at 2022-06-21 18:32:44.542396
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/path/to/input')
    output = Path('/path/to/output')
    assert InputOutput(input, output)


# Generated at 2022-06-21 18:32:56.488767
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x+1')
    tree.body[0].body.value.left.id = 'x'
    tree.body[0].body.value.left.ctx.__class__ = ast.Load
    tree.body[0].body.value.right.n = 2

    res = TransformationResult(tree, False, ['dep1', 'dep2'])

    assert res.tree_changed == False
    assert res.dependencies == ['dep1', 'dep2']

    assert isinstance(res.tree, ast.AST)

    assert isinstance(res.tree.body[0].body.value, ast.BinOp)
    assert isinstance(res.tree.body[0].body.value.left, ast.Name)

# Generated at 2022-06-21 18:33:00.526910
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_tree = ast.parse('')
    changed = True
    dependencies = []
    result = TransformationResult(ast_tree, changed, dependencies)
    assert result.tree == ast_tree
    assert result.tree_changed == changed
    assert result.dependencies == dependencies

# Generated at 2022-06-21 18:33:06.627065
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree='tree', tree_changed=True,
                                dependencies=['a', 'b']).tree == 'tree'
    assert TransformationResult(tree='tree', tree_changed=True,
                                dependencies=['a', 'b']).tree_changed == True
    assert TransformationResult(tree='tree', tree_changed=True,
                                dependencies=['a', 'b']).dependencies == ['a', 'b']

# Generated at 2022-06-21 18:33:07.599402
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(None, False, None)

# Generated at 2022-06-21 18:33:11.256536
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=10, time=0.05, target=(3, 7), dependencies=[])
    assert cr.files == 10
    assert cr.time == 0.05
    assert cr.target == (3, 7)
    assert cr.dependencies == []

# Generated at 2022-06-21 18:33:13.529314
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/input/')
    output = Path('/output/')
    i = InputOutput(input, output)
    assert i.input == input
    assert i.output == output

# Generated at 2022-06-21 18:33:24.456416
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=0.3,
                      target=(3, 4),
                      dependencies=['A'])



# Generated at 2022-06-21 18:33:27.186758
# Unit test for constructor of class InputOutput
def test_InputOutput():
    real = InputOutput(Path('in.py'), Path('out.py'))
    assert real.input == Path('in.py')
    assert real.output == Path('out.py')

# Generated at 2022-06-21 18:33:34.687414
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    tree = ast.parse('x = 1', '<test>', 'eval')
    res = TransformationResult(tree, False, [])
    assert res.tree == tree
    assert not res.tree_changed
    assert res.dependencies == []

# Information about code generation
CodeGenerationResult = NamedTuple('CodeGenerationResult',
                                  [('input', Path),
                                   ('output', Path),
                                   ('time', float)])

# Generated at 2022-06-21 18:33:45.967732
# Unit test for constructor of class InputOutput
def test_InputOutput():
    with patch('os.path.isfile') as isfile_mock:
        isfile_mock.return_value = False
        with pytest.raises(AssertionError):
            InputOutput("foo", "bar")
        isfile_mock.assert_any_call("foo")
        isfile_mock.assert_any_call("bar")

        isfile_mock.reset_mock()
        isfile_mock.return_value = True
        with pytest.raises(AssertionError):
            InputOutput("foo", "bar")
        isfile_mock.assert_any_call("foo")
        isfile_mock.assert_any_call("bar")

    with patch('os.path.isfile') as isfile_mock:
        isfile_mock.return_value

# Generated at 2022-06-21 18:33:49.402810
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test = InputOutput(input=Path('./'), output=Path('./'))
    assert test.input == Path('./')
    assert test.output == Path('./')


# Generated at 2022-06-21 18:33:51.005972
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(input=Path('.'), output=Path.home())



# Generated at 2022-06-21 18:33:54.498800
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input.txt')
    output = Path('output.txt')
    test_pair = InputOutput(input, output)
    assert test_pair.input == input
    assert test_pair.output == output


# Generated at 2022-06-21 18:33:55.812840
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(Path('input'), Path('output'))

# Generated at 2022-06-21 18:33:57.754882
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 1, (2, 3), []) # should not raise exception


# Generated at 2022-06-21 18:34:02.846915
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compres = CompilationResult(1, 1.0, (3, 8), ['a', 'b'])
    assert compres.files == 1
    assert compres.time == 1.0
    assert compres.target == (3, 8)
    assert compres.dependencies == ['a', 'b']


# Generated at 2022-06-21 18:34:23.341723
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=2, time=2.0, target=(3, 7),
                               dependencies=['p1', 'p2'])
    assert result.files == 2
    assert result.time == 2.0
    assert result.target[0] == 3
    assert result.target[1] == 7
    assert result.target == (3, 7)
    assert result.dependencies[0] == 'p1'
    assert result.dependencies[1] == 'p2'

    assert repr(result) == '<2, 2.0, (3, 7), [\'p1\', \'p2\']>'
    assert str(result) == '<2, 2.0, (3, 7), [\'p1\', \'p2\']>'


# Generated at 2022-06-21 18:34:26.713575
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('a')
    out = Path('b')
    input_output = InputOutput(inp, out)
    assert input_output.input == inp
    assert input_output.output == out



# Generated at 2022-06-21 18:34:31.298027
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr1 = TransformationResult(tree=None, tree_changed=False,
                               dependencies=[])
    tr2 = TransformationResult(tree=None, tree_changed=False,
                               dependencies=[])
    assert tr1.tree_changed == tr2.tree_changed
    assert tr1.tree == tr2.tree
    assert tr1.dependencies == tr2.dependencies
    assert tr1 == tr2

# Generated at 2022-06-21 18:34:35.418420
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Good parameters
    assert InputOutput(Path('/tmp'), Path('/tmp'))
    # Bad parameters
    with pytest.raises(TypeError):
        InputOutput('/tmp', '/tmp')
    with pytest.raises(TypeError):
        InputOutput('/tmp', None)
    with pytest.raises(TypeError):
        InputOutput(None, '/tmp')
    with pytest.raises(TypeError):
        InputOutput(None, None)


# Generated at 2022-06-21 18:34:39.679133
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformer_result = TransformationResult(None, None, None)
    assert transformer_result.tree is None
    assert transformer_result.tree_changed is None
    assert transformer_result.dependencies is None

# Generated at 2022-06-21 18:34:42.465217
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    with pytest.raises(TypeError):
        TransformationResult(
            tree=ast.parse('1'),
            tree_changed=True,
            dependencies=['test.py']
        )

# Generated at 2022-06-21 18:34:45.155571
# Unit test for constructor of class InputOutput
def test_InputOutput():
    in_ = Path('in.txt')
    out = Path('out.txt')
    in_out = InputOutput(in_, out)
    assert in_out.input == in_
    assert in_out.output == out


# Generated at 2022-06-21 18:34:48.405595
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(None, None, None)
    assert result.tree == None
    assert result.tree_changed == None
    assert result.dependencies == None


# Generated at 2022-06-21 18:34:53.229501
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(None, None, None)
    assert result.tree is None
    assert result.tree_changed is None
    assert result.dependencies == []

# Result of compilation
Compilation = NamedTuple('Compilation', [('result', CompilationResult),
                                         ('source', InputOutput),
                                         ('target', InputOutput)])


# Generated at 2022-06-21 18:34:58.681617
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=0, time=0.0, target=(3, 4), dependencies=[])
    assert type(cr) == CompilationResult
    assert type(cr.files) == int
    assert cr.files == 0
    assert type(cr.time) == float
    assert cr.time == 0.0
    assert type(cr.target) == CompilationTarget
    assert cr.target == (3, 4)
    assert type(cr.dependencies) == list
    assert cr.dependencies == list()


# Generated at 2022-06-21 18:35:12.806892
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('a'), Path('b'))
    assert input_output.input == Path('a')
    assert input_output.output == Path('b')


# Generated at 2022-06-21 18:35:15.372082
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('input'), Path('output'))
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')

# Generated at 2022-06-21 18:35:24.152213
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('.')
    output = Path('.')
    assert InputOutput(input, output) == InputOutput(input, output)
    assert InputOutput(input, output) != InputOutput(None, output)
    assert InputOutput(input, output) != InputOutput(input, None)
    assert InputOutput(input, output) != InputOutput(None, None)
    assert InputOutput(input, output) != None
    assert InputOutput(input, output) != 'string'
    assert InputOutput(input, output) != 123
    assert str(InputOutput(input, output)) == "InputOutput(input=PosixPath('.'), output=PosixPath('.'))"

# Generated at 2022-06-21 18:35:28.075967
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # given
    files = 1
    time = 1
    target = (3, 8)
    dependencies = ['a', 'b', 'c']
    # when
    res = CompilationResult(files=files, time=time, target=target,
                            dependencies=dependencies)
    # then
    assert res.files == files
    assert res.time == time
    assert res.target == target
    assert res.dependencies == dependencies


# Generated at 2022-06-21 18:35:30.760591
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    import ast
    tree = ast.parse('4 + 3')
    TransformationResult(tree, False, [])

# Generated at 2022-06-21 18:35:34.106149
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 2, (3, 4), [])
    assert result.files == 1
    assert result.time == 2
    assert result.target == (3, 4)
    assert result.dependencies == []


# Generated at 2022-06-21 18:35:36.887774
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('a'), Path('b'))
    assert input_output.input == Path('a')
    assert input_output.output == Path('b')


# Generated at 2022-06-21 18:35:37.454946
# Unit test for constructor of class TransformationResult

# Generated at 2022-06-21 18:35:39.963183
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(input='foo.py', output='foo.pyc')
    assert io.input == Path('foo.py')
    assert io.output == Path('foo.pyc')

# Generated at 2022-06-21 18:35:41.222674
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path(), Path()) is not None


# Generated at 2022-06-21 18:36:07.477254
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    trans_result = TransformationResult(tree=None, tree_changed=False, dependencies=[])
    assert trans_result.tree is None
    assert trans_result.tree_changed is False
    assert trans_result.dependencies == []

# Context manager for file watch

# Generated at 2022-06-21 18:36:12.104932
# Unit test for constructor of class TransformationResult
def test_TransformationResult(): # type: () -> None
    ast1 = ast.parse('a=1')
    a = TransformationResult(ast1, 1, [])
    assert ast1 is a.tree

TransformationFunction = NamedTuple('TransformationFunction',
                                    [('function', callable),
                                     ('transformation_name', str),
                                     ('function_name', str)])


# Generated at 2022-06-21 18:36:20.058741
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=None,
                                tree_changed=True,
                                dependencies=['a', 'b']) == \
           TransformationResult(tree=None,
                                tree_changed=True,
                                dependencies=['a', 'b'])
    assert TransformationResult(tree=None,
                                tree_changed=True,
                                dependencies=['a', 'b']) == \
           TransformationResult(tree=None,
                                tree_changed=True,
                                dependencies=['b', 'a'])
    assert TransformationResult(tree=None,
                                tree_changed=True,
                                dependencies=[]) != \
           TransformationResult(tree=None,
                                tree_changed=True,
                                dependencies=['c'])


# Debug information about the end of tranformation

# Generated at 2022-06-21 18:36:26.730142
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=5,
                            time=3.2,
                            target=(3, 0),
                            dependencies=['a', 'b', 'c'])
    assert res.files == 5
    assert res.time == 3.2
    assert res.target == (3, 0)
    assert res.dependencies == ['a', 'b', 'c']


# Generated at 2022-06-21 18:36:32.365064
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from typed_ast import ast3 as ast
    from example_transformers.tests.utils import TransformationResult
    root = ast.parse('pass')
    tree_changed = True
    dependencies = ['a', 'b']
    tr = TransformationResult(root, tree_changed, dependencies)
    assert tr.tree is root
    assert tr.tree_changed is True
    assert tr.dependencies == ['a', 'b']

# Generated at 2022-06-21 18:36:35.085492
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse('1+2'), True, ['math']).dependencies == ['math']
    assert TransformationResult(ast.parse('1+2'), True, []).dependencies == []

# Generated at 2022-06-21 18:36:39.142416
# Unit test for constructor of class InputOutput
def test_InputOutput():
    some_path = Path("dummy")
    input_path = Path("input")
    output_path = Path("output")
    input_output = InputOutput(input_path, output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path


# Generated at 2022-06-21 18:36:42.762917
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_file = Path("./input.py")
    output_file = Path("./output.py")
    input_output = InputOutput(input_file, output_file)
    assert input_output.input == input_file
    assert input_output.output == output_file

# Generated at 2022-06-21 18:36:45.091369
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(
        ast.Module(),
        False,
        []
    ) == TransformationResult(
        ast.Module(),
        False,
        []
    )

# Generated at 2022-06-21 18:36:46.796569
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=0, target=(3, 5),
                      dependencies=['one', 'two'])


# Generated at 2022-06-21 18:37:48.148880
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('1+1')
    ast_changed = True
    dependencies = ['a', 'b']
    x = TransformationResult(tree, ast_changed, dependencies)
    assert len(x) == 3
    assert x.tree == tree
    assert x.dependencies == dependencies
    assert x.tree_changed == ast_changed
    y = TransformationResult(tree, ast_changed, dependencies)
    assert x == y
    assert x <= y
    assert x >= y
    assert x == y
    assert x <= y
    assert x >= y
    assert bool(x)
    assert len(y)



# Generated at 2022-06-21 18:37:53.109047
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input.txt')
    output = Path('output.txt')
    io = InputOutput(input=input, output=output)
    assert io.input == input
    assert io.output == output

# Generated at 2022-06-21 18:37:55.115857
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(0, 0.0, (3, 0), [])


# Generated at 2022-06-21 18:37:56.986222
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=['a'])


# Generated at 2022-06-21 18:38:00.284562
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(1, 1.0, (3, 7), ["first", "second"])
    assert len(res) == 4
    assert res.files == 1
    assert res.time == 1.0
    assert res.target == (3, 7)
    assert res.dependencies == ["first", "second"]
    

# Generated at 2022-06-21 18:38:03.218354
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(1, True, 2) ==\
           TransformationResult(1, True, 2)

# Functional test for constructor of class TransformationResult

# Generated at 2022-06-21 18:38:07.463251
# Unit test for constructor of class CompilationResult
def test_CompilationResult():  # type: () -> None
    result = CompilationResult(1, 1.0, (2, 3), [])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (2, 3)
    assert result.dependencies == []


# Generated at 2022-06-21 18:38:11.488366
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=0,
                           time=0,
                           target=(0, 0),
                           dependencies=[])
    assert cr.files == 0
    assert cr.time == 0
    assert cr.target == (0, 0)
    assert cr.dependencies == []



# Generated at 2022-06-21 18:38:13.393831
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, False, []).tree_changed == False
    assert TransformationResult(None, True, []).tree_changed == True

# Generated at 2022-06-21 18:38:20.487764
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # pylint: disable=unused-variable
    tree = ast.parse('print("hello")')
    changed = True
    dependencies = []
    res = TransformationResult(tree, changed, dependencies)
    assert isinstance(res.tree, ast.AST)
    assert res.tree_changed == True
    assert isinstance(res.dependencies, list)
    assert len(res.dependencies) == 0



# Generated at 2022-06-21 18:40:18.420144
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.AST(), True, ['a', 'b'])


# The type of visitor converter
Visitor = Tuple[str, bytes]

# Generated at 2022-06-21 18:40:20.841575
# Unit test for constructor of class InputOutput
def test_InputOutput():
    with pytest.raises(AssertionError):
        InputOutput(input='foobar', output='foobar')



# Generated at 2022-06-21 18:40:24.665339
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path('path/to/input.txt'), Path('path/to/output.txt'))
    assert io.input == Path('path/to/input.txt')
    assert io.output == Path('path/to/output.txt')

# Generated at 2022-06-21 18:40:26.365451
# Unit test for constructor of class InputOutput
def test_InputOutput():
    with raises(ValueError):
        InputOutput('', '')


# Generated at 2022-06-21 18:40:29.812644
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(10, 2.6, (3, 5), ['foo', 'bar'])
    assert result.files == 10
    assert result.time == 2.6
    assert result.target == (3, 5)
    assert result.dependencies == ['foo', 'bar']


# Generated at 2022-06-21 18:40:35.587190
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cmp1 = CompilationResult(5, 10, (3, 7), ['./a.py', './b.py'])
    assert cmp1.files == 5
    assert cmp1.time == 10
    assert cmp1.target == (3, 7)
    assert cmp1.dependencies == ['./a.py', './b.py']


# Generated at 2022-06-21 18:40:39.869051
# Unit test for constructor of class InputOutput
def test_InputOutput():
    name = 'test'
    input_dir = Path('test')
    output_dir = Path('test')

    input_file = Path(name + '.py')
    input = InputOutput(input=input_dir / input_file,
                        output=output_dir / input_file)
    assert input.input == input_dir / input_file
    assert input.output == output_dir / input_file
