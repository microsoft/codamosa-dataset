

# Generated at 2022-06-21 18:30:48.745155
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('input'), Path('output')) ==\
           InputOutput(input=Path('input'), output=Path('output'))

# Generated at 2022-06-21 18:30:51.043054
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1, target=(3, 7), dependencies=[])
    assert result.files == 1
    assert result.time == 1
    assert result.target == (3, 7)
    assert result.dependencies == []


# Generated at 2022-06-21 18:30:58.061828
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    fields = {'files': 1, 'time': 2.4, 'target': (2, 7),
              'dependencies': []}
    result = CompilationResult(**fields)
    assert result.files == 1
    assert result.time == 2.4
    assert result.target == (2, 7)
    assert result.dependencies == []


# Generated at 2022-06-21 18:31:02.706446
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=3,
                           time=3.14,
                           target=(3, 6),
                           dependencies=['foo', 'bar'])
    assert cr.files == 3
    assert cr.time == 3.14
    assert cr.target == (3, 6)
    assert cr.dependencies == ['foo', 'bar']


# Generated at 2022-06-21 18:31:07.625869
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files = 1,
                            time = 1.0,
                            target = (3, 5),
                            dependencies = [])
    assert res.files == 1
    assert res.time == 1.0
    assert res.target == (3, 5)
    assert res.dependencies == []

# Generated at 2022-06-21 18:31:10.318226
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert isinstance(CompilationResult(files=3, time=3.14,
                                        target=(3, 6), dependencies=[]),
                      CompilationResult)


# Generated at 2022-06-21 18:31:12.960758
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = InputOutput(input=Path('input'), output=Path('output'))
    assert(i.input == Path('input'))
    assert(i.output == Path('output'))


# Generated at 2022-06-21 18:31:14.271486
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result = TransformationResult(None, False, [])
    assert transformation_result is not None

# Generated at 2022-06-21 18:31:17.402398
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=100.0,
                      target=(3, 7), dependencies=['dependency1', 'dependency2'])



# Generated at 2022-06-21 18:31:21.449495
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    node = ast.Num(12)
    res = TransformationResult(node, False, [])
    assert res.tree == node
    assert not res.tree_changed
    assert res.dependencies == []

# Generated at 2022-06-21 18:31:25.570427
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=10, time=100.0, target=(3, 5), dependencies=[])


# Generated at 2022-06-21 18:31:28.243795
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1, time=2.0, target=(3,4), dependencies=['foo', 'bar'])
    assert compilation_result.files == 1
    assert compilation_result.time == 2.0
    assert compilation_result.target == (3, 4)
    assert compilation_result.dependencies == [ 'foo', 'bar' ]


# Generated at 2022-06-21 18:31:39.013630
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Try without giving values
    result = CompilationResult()

    # Check types and values
    assert type(result.files) is int
    assert result.files == 0
    assert type(result.time) is float
    assert result.time == 0.0
    assert type(result.target) is CompilationTarget
    assert result.target == (2, 7)
    assert type(result.dependencies) is list
    assert result.dependencies == []

    # Try giving values
    result = CompilationResult(1, 2.5, (3, 5), ['foo', 'bar'])

    # Check types and values
    assert type(result.files) is int
    assert result.files == 1
    assert type(result.time) is float
    assert result.time == 2.5
    assert type(result.target) is CompilationTarget

# Generated at 2022-06-21 18:31:41.479002
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(tree=ast.parse('a = 1'),
                         tree_changed=True,
                         dependencies=[])


# Generated at 2022-06-21 18:31:44.515464
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = InputOutput(Path('a.py'), Path('a.pyc'))
    assert i.input == Path('a.py')
    assert i.output == Path('a.pyc')

# Generated at 2022-06-21 18:31:50.266306
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(12, 13.37, (3, 10), ['a', 'b'])
    assert result.files == 12
    assert result.time == 13.37
    assert result.target == (3, 10)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-21 18:31:52.914163
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('input.py')
    output = Path('output.py')
    pair = InputOutput(input_, output)
    assert pair.input == input_
    assert pair.output == output

# Generated at 2022-06-21 18:31:59.013345
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = '/path/to/input'
    output = '/path/to/output'
    i = InputOutput(input, output)
    assert i.input == input
    assert i.output == output
    assert i.input == '/path/to/input'
    assert i.output == '/path/to/output'



# Generated at 2022-06-21 18:32:03.597607
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(10, 12.34, (3, 5), ['mod1', 'mod2'])
    assert r.files == 10
    assert r.time == 12.34
    assert r.target == (3, 5)
    assert r.dependencies == ['mod1', 'mod2']

# Generated at 2022-06-21 18:32:05.729353
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("x = 1")
    dep = []
    TransformationResult(tree, False, dep)
    TransformationResult(tree, True, dep)

# Generated at 2022-06-21 18:32:13.181996
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.parse('x=1'), True, [])

# Result of dependency analysis
DependenciesResult = NamedTuple('DependenciesResult',
                                [('dependencies', List[str])])


# Generated at 2022-06-21 18:32:15.789399
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = 'abc'
    output = 'def'

    io = InputOutput(input, output)

    assert io.input == input
    assert io.output == output


# Generated at 2022-06-21 18:32:18.347166
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/usr/local/bin/')
    output = Path('/tmp/output')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output



# Generated at 2022-06-21 18:32:19.628970
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    args = (ast.parse("pass"), True, ["path"])
    TransformationResult(*args)

# Generated at 2022-06-21 18:32:25.200615
# Unit test for constructor of class InputOutput
def test_InputOutput():
    with pytest.raises(TypeError):
        InputOutput()
    with pytest.raises(TypeError):
        InputOutput(Path('.'), '.')
    with pytest.raises(TypeError):
        InputOutput('.', Path('.'))
    InputOutput(Path('.'), Path('.'))


# Generated at 2022-06-21 18:32:35.374954
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Try not existing files
    with pytest.raises(ValueError):
        InputOutput(input=Path('not-existing-input.py'),
                    output=Path('not-existing-output.py'))
    # Try to assign existing file as input and not existing file as output
    Path('existing-input.py').write_text('')
    with pytest.raises(ValueError):
        InputOutput(input=Path('existing-input.py'),
                    output=Path('not-existing-output.py'))
    # Try to assign not existing file as input and existing file as output
    with pytest.raises(ValueError):
        InputOutput(input=Path('not-existing-input.py'),
                    output=Path('existing-input.py'))
    # Try to assign the same file for input and output

# Generated at 2022-06-21 18:32:42.565897
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('test'), Path('test_o')) == InputOutput('test', 'test_o')
    assert InputOutput(Path('test'), Path('test_o')) == InputOutput('test', Path('test_o'))
    assert InputOutput(Path('test'), Path('test_o')) == InputOutput(Path('test'), 'test_o')
    assert InputOutput(Path('test'), Path('test_o')) == InputOutput(Path('test'), Path('test_o'))

# Generated at 2022-06-21 18:32:45.202680
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('pass')
    x = TransformationResult(t, False, ['a', 'b'])
    assert x.tree == t
    assert x.tree_changed == False
    assert x.dependencies == ['a', 'b']



# Generated at 2022-06-21 18:32:50.229444
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("x = 2 + 2")
    result = TransformationResult(tree, False, [])
    assert type(result.tree) == ast.Module
    assert result.tree_changed == False
    assert type(result.dependencies) == list

# Generated at 2022-06-21 18:32:52.115172
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse('0'), True, []).tree is not None

# Generated at 2022-06-21 18:33:02.261590
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, None, None)

# Generated at 2022-06-21 18:33:07.458684
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cmp_result = CompilationResult(3, 4.56, (3, 7), ["foo", "bar"])
    assert cmp_result.files == 3
    assert cmp_result.time == 4.56
    assert cmp_result.target == (3, 7)
    assert cmp_result.dependencies == ["foo", "bar"]


# Generated at 2022-06-21 18:33:10.936965
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    r = TransformationResult(
        ast.parse('pass'),
        True,
        ['foo', 'bar']
    )

    assert isinstance(r.tree, ast.AST)
    assert isinstance(r.tree_changed, bool)
    assert isinstance(r.dependencies, list)

# Generated at 2022-06-21 18:33:13.600953
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult([], False, [])
    assert isinstance(result.tree, ast.AST)
    assert isinstance(result.tree_changed, bool)
    assert isinstance(result.dependencies, List[str])

# Generated at 2022-06-21 18:33:14.973419
# Unit test for constructor of class InputOutput
def test_InputOutput():
    pass


# Generated at 2022-06-21 18:33:19.826055
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path("/tmp")
    output = Path("/tmp/out.py")
    input_output = InputOutput(input, output)
    assert input_output.input == Path("/tmp")
    assert input_output.output == Path("/tmp/out.py")

# Generated at 2022-06-21 18:33:23.782522
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    a = TransformationResult(tree=None, tree_changed=False, dependencies=[])
    assert a.tree is None
    assert not a.tree_changed
    assert a.dependencies == []


# Generated at 2022-06-21 18:33:25.177287
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('input'), Path('output'))


# Generated at 2022-06-21 18:33:30.632876
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Normal use case
    input_output = InputOutput(Path("input.py"), Path("output.py"))
    assert input_output.input == Path("input.py")
    assert input_output.output == Path("output.py")

    # Test with different types of paths
    input_output = InputOutput("input.py", "output.py")
    assert input_output.input == Path("input.py")
    assert input_output.output == Path("output.py")

    input_output = InputOutput(b"input.py", b"output.py")
    assert input_output.input == Path("input.py")
    assert input_output.output == Path("output.py")



# Generated at 2022-06-21 18:33:33.329887
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=0, time=0, target=(2,6),
                          dependencies=['Dependency1', 'Dependency2'])
    assert isinstance(c.files, int)
    assert isinstance(c.time, float)
    assert isinstance(c.target, CompilationTarget)
    assert isinstance(c.dependencies, list)
    assert len(c.dependencies) == 2


# Generated at 2022-06-21 18:33:48.847265
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    n = ast.parse('x = 1')
    r = TransformationResult(n, True, ['a', 'b'])

    assert r.tree == n
    assert r.tree_changed == True
    assert r.dependencies == ['a', 'b']

# Result of running unit tests
TestResult = NamedTuple('TestResult',
                        [('name', str),
                         ('errors', int),
                         ('test_count', int),
                         ('time', float)])

# Generated at 2022-06-21 18:33:55.002383
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # pylint: disable=no-member
    # This tests that the constructor for TransformationResult doesn't
    # do anything funny like sorting the fields.
    assert TransformationResult._fields == (
        'tree',
        'tree_changed',
        'dependencies',
    )
    t = ast.parse('pass')
    assert TransformationResult(t, True, ['foo']) == (
        TransformationResult(t, True, ['foo'])
    )

# Generated at 2022-06-21 18:33:57.309697
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('input'), Path('output'))
    assert isinstance(input_output.input, Path)
    assert isinstance(input_output.output, Path)

# Generated at 2022-06-21 18:34:00.409261
# Unit test for constructor of class CompilationResult
def test_CompilationResult(): #type: ignore
    assert CompilationResult(files=2,
                             time=0.1,
                             target=(3, 7),
                             dependencies=['foo'])


# Generated at 2022-06-21 18:34:02.742025
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(3, 7),
                      dependencies=['a/b.py', 'c.py'])

# Generated at 2022-06-21 18:34:06.390114
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=2.45, target=(3, 6), dependencies=['a'])
    assert result.files == 1
    assert result.time == 2.45
    assert result.target == (3, 6)
    assert result.dependencies == ['a']



# Generated at 2022-06-21 18:34:13.817775
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(
        files=0, time=0, target=(1, 2), dependencies=[]).files == 0
    assert CompilationResult(
        files=0, time=0, target=(1, 2), dependencies=[]).time == 0
    assert CompilationResult(
        files=0, time=0, target=(1, 2), dependencies=[]).target == (1, 2)
    assert CompilationResult(
        files=0, time=0, target=(1, 2), dependencies=[]).dependencies == []


# Generated at 2022-06-21 18:34:17.196603
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """
    Test for constructor of class InputOutput.
    """
    input = Path('input')
    output = Path('output')
    i_o = InputOutput(input, output)
    assert i_o.input == input
    assert i_o.output == output

# Generated at 2022-06-21 18:34:23.249069
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 2
    time = 1.0
    target = (3, 7)
    dependencies = ['dep1.py', 'dep2.py']
    res = CompilationResult(files, time, target, dependencies)
    assert(res.files == files)
    assert(res.time == time)
    assert(res.target == target)
    assert(res.dependencies == dependencies)


# Generated at 2022-06-21 18:34:26.670316
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.Expr(ast.Constant(1)), True, [])

# Format for transformation result
TransformationResultFormat = NamedTuple('TransformationResultFormat',
                                        [('format', str),
                                         ('transformer', str)])

# Generated at 2022-06-21 18:34:50.232181
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=0.0,
                               target=(3, 5),
                               dependencies=['foo.py',
                                             'bar.py'])
    assert result.files == 1
    assert result.time == 0.0
    assert result.target == (3, 5)
    assert result.dependencies == ['foo.py', 'bar.py']

# Generated at 2022-06-21 18:34:52.413177
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1,
                      time=0.0,
                      target=(2, 7),
                      dependencies=['example'])


# Generated at 2022-06-21 18:34:55.485551
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path  = Path('foo.py')
    output_path = Path('bar')
    test_pair = InputOutput(input_path, output_path)
    assert test_pair.input  == input_path
    assert test_pair.output == output_path


# Generated at 2022-06-21 18:34:56.806150
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(0, 0.0, (3, 7), [])


# Generated at 2022-06-21 18:34:59.059197
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-21 18:35:01.379308
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 1.0, (3, 7), [])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 7)
    assert result.dependencies == []


# Generated at 2022-06-21 18:35:04.925856
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x=1\n', '<string>', 'exec')
    res = TransformationResult(tree, True, ['asd'])
    assert res.tree == tree
    assert res.tree_changed
    assert res.dependencies == ['asd']

# Generated at 2022-06-21 18:35:16.766604
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert (CompilationResult(0, 0.0, (3, 7), []) ==
            CompilationResult(0, 0.0, (3, 7), []))
    assert (CompilationResult(0, 0.0, (3, 7), []) !=
            CompilationResult(1, 0.0, (3, 7), []))
    assert (CompilationResult(0, 0.0, (3, 7), []) !=
            CompilationResult(0, 1.0, (3, 7), []))
    assert (CompilationResult(0, 0.0, (3, 7), []) !=
            CompilationResult(0, 0.0, (3, 6), []))

# Generated at 2022-06-21 18:35:21.616508
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a=0')
    tree_changed = False
    dependencies = ['./test1.py', './test2.py']

    tr = TransformationResult(tree, tree_changed, dependencies)

    assert tr.tree == tree
    assert tr.tree_changed == tree_changed
    assert tr.dependencies == dependencies

# Generated at 2022-06-21 18:35:23.694351
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert (CompilationResult(1, 1.0, (3, 6), []).__class__ ==
            CompilationResult)


# Generated at 2022-06-21 18:36:08.169989
# Unit test for constructor of class InputOutput
def test_InputOutput():

    # Get paths
    root = Path(os.path.dirname(os.path.abspath(__file__)))
    input_file = root / '../tests/stubs/hello.py'
    output_file = root / '../tests/stubs/hello_output.py'

    # Check paths
    assert input_file.exists()
    assert output_file.exists()

    # Create InputOutput
    io = InputOutput(input=input_file, output=output_file)

    # Check attributes
    assert isinstance(io.input, Path)
    assert isinstance(io.output, Path)

    # Is string representation correct?
    assert str(io)



# Generated at 2022-06-21 18:36:10.883282
# Unit test for constructor of class InputOutput
def test_InputOutput():
    t = InputOutput(input=Path('foo'), output=Path('bar'))
    assert t.input.name == 'foo'
    assert t.output.name == 'bar'

# Generated at 2022-06-21 18:36:13.848270
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = 'input'
    output = 'output'
    input_output = InputOutput(input_, output)
    assert input_output.input == Path(input_)
    assert input_output.output == Path(output)

# Generated at 2022-06-21 18:36:16.719816
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input=None, output=None).input is None
    assert InputOutput(input=None, output=None).output is None
    assert isinstance(InputOutput(input=None, output=None), InputOutput)


# Generated at 2022-06-21 18:36:20.351327
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("7 * 3")
    result = TransformationResult(tree, False, ['__future__'])
    assert result.tree == tree
    assert result.tree_changed == False
    assert result.dependencies == ['__future__']

# Generated at 2022-06-21 18:36:23.562406
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(
        tree=ast.Module(),
        tree_changed=True,
        dependencies=["Dependency 1", "Dependency 2"]
    )

# Generated at 2022-06-21 18:36:28.666580
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree_ = ast.parse("pass")
    transformer = ast.Module(body=[tree_])
    dependencies_ = ["foo.py"]

    result = TransformationResult(tree_, True, dependencies_)

    assert result[0] == tree_
    assert result[1] == True
    assert result[2] == dependencies_

# Generated at 2022-06-21 18:36:32.743904
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=1, time=0, target=(3, 5), dependencies=['a'])
    assert c.files == 1
    assert c.time == 0
    assert c.target == (3, 5)
    assert c.dependencies == ['a']


# Generated at 2022-06-21 18:36:35.909896
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 1.0, (3, 7), [])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 7)
    assert result.dependencies == []


# Generated at 2022-06-21 18:36:45.240625
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.parse("pass"), True, ["pass"])
    assert tr.tree is not None
    assert tr.tree_changed is True
    assert tr.dependencies == ["pass"]

# Result of source code parsing
SourceParseResult = NamedTuple('SourceParseResult',
                               [('tree', ast.AST),
                                ('cache_key', ast.AST)])

# Result of compilation of single source file
FileCompilationResult = NamedTuple('FileCompilationResult',
                                   [('input', Path),
                                    ('output', Path),
                                    ('time', float),
                                    ('failed', bool),
                                    ('target', CompilationTarget)])


# Generated at 2022-06-21 18:38:22.270282
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('/my/input'),
                       Path('/my/output'))


# Generated at 2022-06-21 18:38:24.954558
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: (...) -> None
    _ = TransformationResult(tree=None, tree_changed=False, dependencies=[])

# Generated at 2022-06-21 18:38:28.750897
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse("")

    t1 = TransformationResult(tree=t,
                              tree_changed=True,
                              dependencies=["a", "b", "c"])
    assert t1.tree == t
    assert t1.tree_changed
    assert t1.dependencies == ["a", "b", "c"]

# Generated at 2022-06-21 18:38:30.651965
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    entry = InputOutput(input, output)
    assert entry.input == 'input'
    assert entry.output == 'output'

# Generated at 2022-06-21 18:38:31.400207
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.AST(), False, [])

# Generated at 2022-06-21 18:38:34.233464
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    target = (3, 7)
    dependencies = ['a', 'b', 'c']
    result = CompilationResult(files=1, time=0.0, target=target,
                               dependencies=dependencies)
    assert result.files == 1
    assert result.time == 0.0
    assert result.target == target
    assert result.dependencies == dependencies

# Generated at 2022-06-21 18:38:36.818183
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(tree=None, tree_changed=True, dependencies=[])
    assert result.tree is None
    assert result.tree_changed
    assert result.dependencies == []

# Generated at 2022-06-21 18:38:40.746783
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = 'input'
    o = 'output'
    inout = InputOutput(i, o)
    assert inout.input == i
    assert inout.output == o


# Generated at 2022-06-21 18:38:45.257800
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    from compilertools import CompilationResult

    cr = CompilationResult(files=1, time=1.1, target=(1, 0), dependencies=['x'])
    assert cr.files == 1
    assert cr.time == 1.1
    assert cr.target == (1, 0)
    assert cr.dependencies == ['x']



# Generated at 2022-06-21 18:38:49.705100
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=0.0, target=(3, 0), dependencies=[
        'math'])
    assert cr.files == 1
    assert cr.time == 0.0
    assert cr.target == (3, 0)
    assert cr.dependencies == ['math']

