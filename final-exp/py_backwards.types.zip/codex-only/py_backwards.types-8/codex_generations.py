

# Generated at 2022-06-23 23:32:04.823112
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=10,
                            time=1.0,
                            target=(2, 3),
                            dependencies=['a', 'b'])
    assert res.files == 10
    assert res.time == 1.0
    assert res.target == (2, 3)
    assert res.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:32:07.749851
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("print('Hello')")
    result = TransformationResult(tree, True, ['dep1', 'dep2'])
    assert result.tree == tree
    assert result.tree_changed is True
    assert result.dependencies == ['dep1', 'dep2']


# Generated at 2022-06-23 23:32:11.684812
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input.py')
    output = Path('/tmp/output.py')
    result = InputOutput(input, output)
    assert result.input == input
    assert result.output == output

# Generated at 2022-06-23 23:32:18.871718
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i_o_1 = InputOutput(input=Path('f1.py'), output=Path('f1.pyc'))
    i_o_2 = InputOutput(input=Path('f2.py'), output=Path('f2.pyc'))
    assert i_o_1.input == Path('f1.py')
    assert i_o_1.output == Path('f1.pyc')
    assert i_o_2.input == Path('f2.py')
    assert i_o_2.output == Path('f2.pyc')


# Generated at 2022-06-23 23:32:21.071616
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("a = 1")
    tree_changed = True
    dependencies = ['a.py']
    assert TransformationResult(tree, tree_changed, dependencies)

# Generated at 2022-06-23 23:32:24.176806
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_ = ast.Module([])
    result = TransformationResult(tree=ast_, tree_changed=True, dependencies=[])
    assert result.tree is ast_
    assert result.tree_changed is True
    assert result.dependencies == []


# Source code of a file

# Generated at 2022-06-23 23:32:28.318296
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=None,
                              tree_changed=True,
                              dependencies=['abc', 'def'])
    assert tr.tree is None
    assert tr.tree_changed is True
    assert tr.dependencies == ['abc', 'def']


# Generated at 2022-06-23 23:32:29.495287
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.AST(), True, [])

# Generated at 2022-06-23 23:32:30.935253
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(0, 0, (0, 0), [])


# Generated at 2022-06-23 23:32:34.993090
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(1, 1.1, (3, 5), ['d1', 'd2'])
    assert c.files == 1
    assert c.time == 1.1
    assert c.target == (3, 5)
    assert c.dependencies == ['d1', 'd2']


# Generated at 2022-06-23 23:32:39.126974
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files = 2, time = 1.0, target = (3, 4), dependencies = [])
    assert c.files == 2
    assert c.time == 1.0
    assert c.target == (3, 4)
    assert c.dependencies == []


# Generated at 2022-06-23 23:32:42.021696
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput("input", "output")
    assert input_output.input == "input"
    assert input_output.output == "output"


# Generated at 2022-06-23 23:32:43.872880
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # type: () -> None
    assert len(InputOutput(Path('123'), Path('456')).dependencies) == 0

# Generated at 2022-06-23 23:32:47.798909
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(12, 0.2, (3, 0), ['a', 'b'])
    assert result.files == 12
    assert result.time == 0.2
    assert result.target == (3, 0)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:32:49.812771
# Unit test for constructor of class InputOutput
def test_InputOutput():
    try:
        InputOutput('a', 'b')
        assert False
    except:
        pass

    assert InputOutput(Path('a'), Path('b'))



# Generated at 2022-06-23 23:32:53.419793
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=1,
                            time=9,
                            target=(3, 6),
                            dependencies=["something"])
    assert res.files == 1
    assert res.time == 9
    assert res.target == (3, 6)
    assert res.dependencies == ["something"]

# Generated at 2022-06-23 23:32:59.247679
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    input_tree = ast.parse('import os')
    input_changed = 1
    input_dependencies = ['os']
    tr = TransformationResult(tree=input_tree,
                              tree_changed=input_changed,
                              dependencies=input_dependencies)
    assert tr.tree == input_tree
    assert tr.tree_changed == input_changed
    assert tr.dependencies == input_dependencies

# Result of tests
TestResult = NamedTuple('TestResult',
                        [('files', int),
                         ('time', float),
                         ('failures', int),
                         ('errors', int),
                         ('dependencies', List[str])])

# Generated at 2022-06-23 23:33:03.951374
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('1')
    r = TransformationResult(t, True, [])
    assert r.tree is t
    assert r.tree_changed is True
    assert r.dependencies == []


# Result of postprocessing
PostprocessingResult = NamedTuple('PostprocessingResult',
                                  [('result', str),
                                   ('dependencies', List[str])])


# Generated at 2022-06-23 23:33:06.642167
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    r = TransformationResult(tree=None, tree_changed=None, dependencies=[])
    assert r.tree is None
    assert r.tree_changed is None
    assert isinstance(r.dependencies, list)

# Generated at 2022-06-23 23:33:11.246129
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_file = Path("/tmp/input")
    output_file = Path("/tmp/output")

    io = InputOutput(input_file, output_file)
    assert io.input == input_file
    assert io.output == output_file


# Generated at 2022-06-23 23:33:14.754076
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('a', '<test>', 'exec')
    res = TransformationResult(t, True, ['1', '2'])
    assert res.tree_changed
    assert res.tree == t
    assert res.dependencies == ['1', '2']

# Generated at 2022-06-23 23:33:20.652866
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test_tree = ast.parse('x=0')
    test_tree_changed = True
    test_dependencies = ['dependency1', 'dependency2']
    test_result = TransformationResult(test_tree, test_tree_changed, test_dependencies)
    assert test_result.tree == test_tree
    assert test_result.tree_changed == test_tree_changed
    assert test_result.dependencies == test_dependencies

# Generated at 2022-06-23 23:33:24.719209
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path('/in/') / '1.py'
    path2 = Path('/out/') / '1.py'
    io = InputOutput(path1, path2)
    assert io.input == path1
    assert io.output == path2

# Generated at 2022-06-23 23:33:27.696100
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('input'), Path('output'))
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')


# Generated at 2022-06-23 23:33:30.702727
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 1, (1, 2), [])
    assert result.files == 1
    assert result.time == 1
    assert result.target == (1, 2)
    assert result.dependencies == []


# Generated at 2022-06-23 23:33:36.875544
# Unit test for constructor of class TransformationResult
def test_TransformationResult(): # pylint: disable=W0613
    TransformationResult(None, True, [])

# Results of a transformer on a given project
TransformationRun = NamedTuple('TransformationRun',
                               [('project_name', str),
                                ('transformer_name', str),
                                ('result', List[TransformationResult])])

# Result of a transformer on a given project
TransformationProjectResult = NamedTuple('TransformationProjectResult',
                                         [('project_name', str),
                                          ('transformer_name', str),
                                          ('result', TransformationResult)])


# Generated at 2022-06-23 23:33:39.821949
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('input'), Path('output'))
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')


# Generated at 2022-06-23 23:33:41.145406
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a'), Path('b'))


# Generated at 2022-06-23 23:33:43.642116
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a'), Path('b')).input == Path('a')
    assert InputOutput(Path('a'), Path('b')).output == Path('b')

# Generated at 2022-06-23 23:33:49.674237
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i1 = InputOutput(Path('input.py'), Path('output.py'))
    i2 = InputOutput('input.py', 'output.py')

    assert i1.input == i2.input and i1.output == i2.output

# Mapping from python version to its name
PYTHON_VERSIONS = {
    (3, 7): '3.7',
    (3, 6): '3.6',
    (3, 5): '3.5',
    (3, 4): '3.4',
    (2, 7): '2.7'
}

# Generated at 2022-06-23 23:33:51.303310
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files = 1, time = 5.0, target=(3, 5), dependencies=[])


# Generated at 2022-06-23 23:33:54.843906
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    x = CompilationResult(1, 2.0, (3, 4), ['a'])
    assert x.files == 1
    assert x.time == 2.0
    assert x.target == (3, 4)
    assert x.dependencies == ['a']


# Generated at 2022-06-23 23:33:57.157677
# Unit test for constructor of class InputOutput
def test_InputOutput():
    pairs = InputOutput(input='a', output='b')
    assert pairs.input == 'a'
    assert pairs.output == 'b'


# Generated at 2022-06-23 23:34:02.066660
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=0,
                           time=0.2,
                           target=(3, 6),
                           dependencies=['A.py'])

    assert(cr.files == 0)
    assert(cr.time == 0.2)
    assert(cr.target == (3, 6))
    assert(cr.dependencies == ['A.py'])


# Generated at 2022-06-23 23:34:05.013955
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    result = TransformationResult(tree, False, [])
    assert result.tree == tree
    assert result.tree_changed == False
    assert result.dependencies == []
    with pytest.raises(TypeError):
        TransformationResult(tree, False, [1, 2, 3])

# Generated at 2022-06-23 23:34:07.621278
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert isinstance(CompilationResult(files=1, time=2.0, target=(3, 4),
                                        dependencies=['a', 'b']), CompilationResult)


# Generated at 2022-06-23 23:34:10.126207
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = str(Path('1.py').resolve())
    output = str(Path('(1.py)').resolve())
    io = InputOutput(input, output)
    assert io.input == Path(input)
    assert io.output == Path(output)


# Generated at 2022-06-23 23:34:15.241551
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # TODO: test if input is checked correctly
    assert CompilationResult(1, 2.0, (3, 4), ['a', 'b']).files == 1
    assert CompilationResult(1, 2.0, (3, 4), ['a', 'b']).time == 2.0
    assert CompilationResult(1, 2.0, (3, 4), ['a', 'b']).target == (3, 4)
    assert CompilationResult(1, 2.0, (3, 4), ['a', 'b']).dependencies == ['a', 'b']


# Generated at 2022-06-23 23:34:20.708508
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=5,
                                           time=2.5,
                                           target=(2, 7),
                                           dependencies=['foo', 'bar'])
    assert compilation_result.files == 5
    assert compilation_result.time == 2.5
    assert compilation_result.target == (2, 7)
    assert compilation_result.dependencies == ['foo', 'bar']


# Generated at 2022-06-23 23:34:26.261036
# Unit test for constructor of class InputOutput
def test_InputOutput():

    # Check input/output pair is correct
    input_output = InputOutput(Path('/a/b/c.py'), Path('/b/c.py'))
    assert input_output.input == Path('/a/b/c.py')
    assert input_output.output == Path('/b/c.py')


# Generated at 2022-06-23 23:34:29.243195
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_path = Path('/test')
    i = InputOutput(input=test_path, output=test_path)
    assert i.input == i.output


# Generated at 2022-06-23 23:34:30.294736
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput('a', 'b')


# Generated at 2022-06-23 23:34:33.172580
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 1.0, (3, 5), [])
    CompilationResult(1, 1.0, (3, 5), ['abc.py'])
    CompilationResult(1, 1.0, (3, 5), ['abc.py', 'xyz.py'])



# Generated at 2022-06-23 23:34:38.560063
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=0.0,
                               target=(3, 7),
                               dependencies=['foo'])
    assert result.files == 1
    assert result.time == 0.0
    assert result.target == (3, 7)
    assert result.dependencies == ['foo']


# Generated at 2022-06-23 23:34:41.818438
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a=5; b=2; c=3;')
    tree_changed = True
    dependencies = ['test.py']
    result = TransformationResult(tree, tree_changed, dependencies)
    print(result)



# Generated at 2022-06-23 23:34:47.819880
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test_tree = ast.parse("print('test')")
    test_tree_changed = True
    test_dependencies = ['test']
    result = TransformationResult(tree=test_tree,
                                  tree_changed=test_tree_changed,
                                  dependencies=test_dependencies)
    assert result.tree is test_tree
    assert result.tree_changed is True
    assert result.dependencies == test_dependencies


# Generated at 2022-06-23 23:34:53.422752
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=5,
                                           time=25.0,
                                           target=(2, 7),
                                           dependencies=['foo.py', 'bar.py'])

    assert compilation_result.files == 5
    assert compilation_result.time == 25.0
    assert compilation_result.target == (2, 7)
    assert compilation_result.dependencies == ['foo.py', 'bar.py']


# Generated at 2022-06-23 23:34:56.045913
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass', 'func.py')
    result = TransformationResult(tree, True, [])
    assert result.tree_changed
    assert result.tree == tree
    assert result.dependencies == []

# Generated at 2022-06-23 23:34:59.997409
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path("/tmp/foo")
    output = Path("/tmp/bar")
    pair = InputOutput(input_, output)
    assert pair.input == input_
    assert pair.output == output


# Generated at 2022-06-23 23:35:03.232729
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # noinspection PyTypeChecker
    iop = InputOutput(input=Path('input'), output=Path('output'))
    assert iop.input == Path('input')
    assert iop.output == Path('output')


# Generated at 2022-06-23 23:35:07.069145
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 2.3, (3, 4), [])
    assert result.files == 1
    assert result.time == 2.3
    assert result.target == (3, 4)
    assert result.dependencies == []



# Generated at 2022-06-23 23:35:09.480759
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = InputOutput(Path(__file__), Path(__file__ + '.pyc'))
    assert i.input == Path(__file__)
    assert i.output == Path(__file__ + '.pyc')



# Generated at 2022-06-23 23:35:11.641229
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse("2+2")
    tr = TransformationResult(t, True, [])
    assert tr == TransformationResult(t, True, [])


Tree = ast.AST

# Generated at 2022-06-23 23:35:14.789272
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(tree=None,
                                  tree_changed=False,
                                  dependencies=[])
    assert result.tree == None
    assert not result.tree_changed
    assert result.dependencies == []


# Not a real test, just printing result
if __name__ == "__main__":
    print(TransformationResult(tree=None, tree_changed=False, dependencies=[]))

# Generated at 2022-06-23 23:35:19.224376
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 2.0, (3, 4), ['b.py', 'c.py']) \
        == CompilationResult(1, 2.0, (3, 4), ['b.py', 'c.py'])


# Generated at 2022-06-23 23:35:21.913844
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = InputOutput(Path('name.in'), Path('name.out'))
    assert input_.input == Path('name.in')
    assert input_.output == Path('name.out')

# Generated at 2022-06-23 23:35:23.523980
# Unit test for constructor of class InputOutput
def test_InputOutput():
    I = InputOutput(Path('foo'), Path('bar'))
    assert I.input == Path('foo')
    assert I.output == Path('bar')


# Generated at 2022-06-23 23:35:27.697992
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    for tree in [1, 2.0, []]:
        for tree_changed in [True, False]:
            for dependencies in [[], ['a', 'b']]:
                TransformationResult(tree, tree_changed, dependencies)
    for tree in [[], 1, 2.0]:
        assert False, "Should not be run"

# Generated at 2022-06-23 23:35:29.340706
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=5, time=1.5, target=(3, 0), dependencies=[])


# Generated at 2022-06-23 23:35:31.545822
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    result = TransformationResult(tree, True, ['foo'])
    assert result.tree is tree
    assert result.tree_changed
    assert result.dependencies == ['foo']

# Generated at 2022-06-23 23:35:33.417651
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 0.1, (1, 0), ["a", "b"])


# Generated at 2022-06-23 23:35:35.619130
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p = Path('foo')
    q = Path('bar')
    input_output = InputOutput(p, q)
    assert input_output.input == p
    assert input_output.output == q


# Generated at 2022-06-23 23:35:39.240999
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=100,
                                           time=2.0,
                                           target=(3, 4),
                                           dependencies=['abc', 'xyz'])
    assert compilation_result.files == 100
    assert compilation_result.time == 2.0
    assert compilation_result.target == (3, 4)
    assert compilation_result.dependencies == ['abc', 'xyz']


# Generated at 2022-06-23 23:35:45.988805
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.Module([]), True, [])

# Generic type for configuration options
# Supported types: str, int, float
Configuration = NamedTuple('Configuration',
                           [('key', str),
                            ('value', str),
                            ('type', str),
                            ('default', str),
                            ('help', str),
                            ('required', bool),
                            ('allowed', List[str]),
                            ('method', str)])


# Generated at 2022-06-23 23:35:47.809144
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # pylint: disable=unused-variable
    result = TransformationResult(None, False, [])

# Generated at 2022-06-23 23:35:49.168117
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path("1"), Path("2"))


# Generated at 2022-06-23 23:35:51.455161
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(3, 7), dependencies=['1', '2'])


# Generated at 2022-06-23 23:35:56.387826
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Arrange
    files = 1
    time = 12.34
    target = (3, 7)
    # Act
    r = CompilationResult(files=files, time=time, target=target,
                          dependencies=[])

    # Assert
    assert isinstance(r, CompilationResult)
    assert r.files == files
    assert r.time == time
    assert r.target == target


# Generated at 2022-06-23 23:35:58.854065
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.Module()
    t = TransformationResult(tree, True, ['foo.py'])
    assert t.tree == tree
    assert t.tree_changed
    assert t.dependencies == ['foo.py']


# Generated at 2022-06-23 23:36:08.409701
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast.parse("pass")
    TransformationResult(ast.parse("pass"), True, [])

import typing
assert typing.TYPE_CHECKING  # silence pyflakes

# PyPI doesn't support SemVer and we can't do exact version
# matching yet because we don't have a parser without use of
# regular expressions.
DependencySpecifier = str

# Input/dependency pair
DependencyInput = NamedTuple('DependencyInput', [('input', Path),
                                                 ('dependency', DependencySpecifier)])

# Compiler configuration
CompilerConfig = NamedTuple('CompilerConfig', [('files', List[InputOutput]),
                                               ('dependencies', List[DependencyInput])])


# Generated at 2022-06-23 23:36:10.804961
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = 'input.py'
    output = 'output.py'
    pair = InputOutput(input, output)
    assert pair.input == input
    assert pair.output == output

# Generated at 2022-06-23 23:36:15.685592
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_ = ast.parse("")
    test_ = TransformationResult(tree=ast_,
                                 tree_changed=True,
                                 dependencies=["a", "b"])
    assert test_.tree is ast_
    assert test_.tree_changed is True
    assert test_.dependencies == ["a", "b"]

# Generated at 2022-06-23 23:36:21.214624
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('foo')
    output = Path('bar')
    class_under_test = InputOutput(input, output)
    assert class_under_test.input == input
    assert class_under_test.output == output
    assert class_under_test[0] == input
    assert class_under_test[1] == output
    assert class_under_test[:] == (input, output)
    assert class_under_test[0:1] == (input,)


# Generated at 2022-06-23 23:36:24.223824
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    class TestAST(ast.AST):
        _fields = ()
    assert TransformationResult(TestAST(), False, [])

# Generated at 2022-06-23 23:36:27.828196
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("print('hello world')")
    assert TransformationResult(tree, True, []).tree == tree
    assert TransformationResult(tree, True, []).tree_changed == True
    assert TransformationResult(tree, True, []).dependencies == []

# Generated at 2022-06-23 23:36:30.146054
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('.')
    output = Path('.')
    pair = InputOutput(input, output)
    assert pair.input == input
    assert pair.output == output


# Generated at 2022-06-23 23:36:32.316769
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    class H:
        pass
    h = H()  # type: ignore
    TransformationResult(h, False, [])

# Generated at 2022-06-23 23:36:37.083927
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=['x', 'y'])
    assert res.files == 1
    assert res.time == 2.0
    assert res.target == (3, 4)
    assert res.dependencies == ['x', 'y']


# Generated at 2022-06-23 23:36:40.545346
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # given
    input_ = Path('foo')
    output = Path('bar')

    # when
    result = InputOutput(input_, output)

    # then
    assert result.input == input_
    assert result.output == output


# Generated at 2022-06-23 23:36:42.757331
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(None, False, [])
    assert result.tree is None
    assert result.tree_changed is False
    assert len(result.dependencies) == 0

# Generated at 2022-06-23 23:36:46.550161
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('[1, 2, 3]', mode='exec')
    t = TransformationResult(tree, True, ['dep1', 'dep2'])
    assert t.tree == tree
    assert t.tree_changed == True


# Generated at 2022-06-23 23:36:52.892084
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    io = InputOutput(input, output)

    assert isinstance(io.input, Path)
    assert input == io.input
    assert isinstance(io.output, Path)
    assert output == io.output

    # this will call the __str__() of Path, using the input's path
    assert str(io.input) == str(input)

    io = InputOutput(Path('input'), Path('output'))
    io = InputOutput('input', 'output')


# Generated at 2022-06-23 23:36:54.649467
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('input.py'), Path('output.py'))
    assert input_output.input == Path('input.py')
    assert input_output.output == Path('output.py')

# Generated at 2022-06-23 23:36:57.597427
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.AST()
    d = []
    res = TransformationResult(t, True, d)
    assert res.tree == t
    assert res.tree_changed == True
    assert res.dependencies == d
    pass

# Generated at 2022-06-23 23:36:58.806245
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.Module(), False, [])
    assert isinstance(tr, TransformationResult)

# Generated at 2022-06-23 23:37:05.248586
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    #pylint:disable=too-many-function-args
    result = CompilationResult(1, 23.259, (3, 7), ['tensorflow',
        'numpy', 'nltk'])

    assert result.files == 1
    assert result.time == 23.259
    assert result.target == (3, 7)
    assert result.dependencies == ['tensorflow', 'numpy', 'nltk']



# Generated at 2022-06-23 23:37:08.819088
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("x = 2")
    dependencies = []
    result = TransformationResult(tree=tree, tree_changed=True,
                                  dependencies=dependencies)
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == de

# Generated at 2022-06-23 23:37:10.158458
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    result = TransformationResult(tree, False, [])

# Generated at 2022-06-23 23:37:13.937661
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    expected_tree = ast.parse('pass')
    expected_tree_changed = True
    expected_dependencies = []

    r = TransformationResult(expected_tree, expected_tree_changed, expected_dependencies)

    assert r.tree == expected_tree
    assert r.tree_changed == expected_tree_changed
    assert r.dependencies == expected_dependencies

# Generated at 2022-06-23 23:37:17.577811
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    """
    The class TransformationResult has no methods, so this is just checking that it works.
    """
    t = TransformationResult(None, None, None)
    assert t.tree is None
    assert t.tree_changed is None
    assert t.dependencies is None


# Result of transformer
TransformerResult = NamedTuple('TransformerResult',
                               [('result', TransformationResult),
                                ('time', float)])


# Generated at 2022-06-23 23:37:28.364240
# Unit test for constructor of class InputOutput
def test_InputOutput():
    case = InputOutput(Path('directory/input.py'),
                       Path('directory/output.py'))
    assert case.input == Path('directory/input.py')
    assert case.output == Path('directory/output.py')

    case = InputOutput('directory/input.py',
                       'directory/output.py')
    assert case.input == Path('directory/input.py')
    assert case.output == Path('directory/output.py')

    case = InputOutput('input.py', 'output.py')
    assert case.input == Path('input.py')
    assert case.output == Path('output.py')

    case = InputOutput(Path('input.py'), Path('output.py'))
    assert case.input == Path('input.py')
    assert case.output == Path('output.py')


# Generated at 2022-06-23 23:37:32.484173
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_file = Path('.')
    output_file = Path('.')
    input_output = InputOutput(input_file, output_file)
    assert input_output == InputOutput(input_file, output_file)
    assert input_output != InputOutput(Path('..'), output_file)
    assert input_output != InputOutput(input_file, Path('..'))

# Generated at 2022-06-23 23:37:36.605589
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=0, time=0.0, target=(3, 5),
                               dependencies=[])
    assert result.files == 0
    assert result.time == 0.0
    assert result.target == (3, 5)
    assert result.dependencies == []


# Generated at 2022-06-23 23:37:37.389552
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, True, None).tree_changed



# Generated at 2022-06-23 23:37:42.538587
# Unit test for constructor of class CompilationResult
def test_CompilationResult():  # type: () -> None
    result = CompilationResult(files=3, time=2.3,
                               target=(3, 6), dependencies=['a', 'b'])
    assert result.files == 3
    assert result.time == 2.3
    assert result.target == (3, 6)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:37:44.196018
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_node = ast.Module()
    res = TransformationResult(ast_node, True, ['dependency'])
    res.tree == ast_node
    res.tree_changed == True
    res.dependencies == ['dependency']

# Generated at 2022-06-23 23:37:45.651187
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path("foo"), Path("bar")).input == Path("foo")


# Generated at 2022-06-23 23:37:48.309470
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('None', '<test>', 'eval')
    res = TransformationResult(tree, True, ['test'])
    assert res.tree == tree
    assert res.tree_changed
    assert res.dependencies == ['test']

# Generated at 2022-06-23 23:37:54.582448
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("2 + 3")
    tree_changed = False
    deps = ["stdlib.py", "external.py"]
    result = TransformationResult(tree, tree_changed, deps)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == deps

# Message and/or error code.
Message = NamedTuple('Message', [('message', str), ('code', int)])

# The names of all the output folders we generate
DESTINATION_FOLDERS = {"bytecode": "bytecode",
                       "ast"     : "ast",
                       "c"       : "c",
                       "run"     : "run"}

# C/C++ headers for generated code

# Generated at 2022-06-23 23:37:58.112394
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    res = TransformationResult(tree, True, [])
    assert res.tree == tree
    assert res.tree_changed == True
    assert res.dependencies == []

# Example of CompilationResult
compilation_result = CompilationResult(3, 0.3, (3, 5), [])


# Generated at 2022-06-23 23:38:04.203714
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Type check
    cr = CompilationResult(files=0,
                           time=0.1,
                           target=(3, 7),
                           dependencies=['sys', 're'])
    assert cr.files == 0
    assert cr.time == 0.1
    assert cr.target == (3, 7)
    assert cr.dependencies == ['sys', 're']

    # No need to test repr and str


# Generated at 2022-06-23 23:38:05.042665
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('foo'), Path('bar'))


# Generated at 2022-06-23 23:38:06.049564
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, False, None).tree_changed == False

# Helper functions

# Generated at 2022-06-23 23:38:10.240962
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('/root/dir1/dir2', 'filename.py')
    output = Path('/root/dir1', 'filename.pyc')
    nt = InputOutput(input_, output)
    assert nt.input == input_
    assert nt.output == output



# Generated at 2022-06-23 23:38:15.168842
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # type: () -> None
    cr = CompilationResult(files=1, time=0.4, target=(3, 5), dependencies=[])
    assert cr.files == 1
    assert cr.time == 0.4
    assert cr.target == (3, 5)
    assert cr.dependencies == []
    assert str(cr) == 'CompilationResult(files=1, time=0.4, target=(3, 5), dependencies=[])'


# Generated at 2022-06-23 23:38:19.993649
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=2, time=1.1, target=(3, 6),
                               dependencies=['foo', 'bar'])
    assert result.files == 2
    assert result.time == 1.1
    assert result.target == (3, 6)
    assert result.dependencies == ['foo', 'bar']


# Generated at 2022-06-23 23:38:23.110286
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('foo'), Path('bar'))
    assert input_output.input == Path('foo')
    assert input_output.output == Path('bar')


# Generated at 2022-06-23 23:38:25.154046
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    TransformationResult(tree=tree, tree_changed=True, dependencies=[])



# Generated at 2022-06-23 23:38:27.368164
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("")
    tree_changed = False
    dependencies = []
    TransformationResult(tree, tree_changed, dependencies)


# Generated at 2022-06-23 23:38:33.007167
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    """Unit test for constructor of class TransformationResult."""
    tree = ast.parse('x = 1')
    ast_changed = True
    dependencies = ['./my_package', './my_module']
    result = TransformationResult(tree=tree, tree_changed=ast_changed,
                                  dependencies=dependencies)
    assert isinstance(result, TransformationResult)
    assert result.tree is tree
    assert result.tree_changed is ast_changed
    assert result.dependencies is dependencies

# Generated at 2022-06-23 23:38:38.898129
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=0,
                             time=0,
                             target=(0, 0),
                             dependencies=[]).files == 0
    assert CompilationResult(files=0,
                             time=0,
                             target=(0, 0),
                             dependencies=[]).time == 0
    assert CompilationResult(files=0,
                             time=0,
                             target=(0, 0),
                             dependencies=[]).target == (0, 0)
    assert CompilationResult(files=0,
                             time=0,
                             target=(0, 0),
                             dependencies=[]).dependencies == []


# Generated at 2022-06-23 23:38:43.624429
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    t = TransformationResult(ast.parse("foo()"), True, ["bar.py"])
    assert t.tree == ast.parse("foo()")
    assert t.tree_changed is True
    assert t.dependencies == ["bar.py"]

# Generated at 2022-06-23 23:38:48.892334
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(1, 1.0, (3, 6), [])
    assert isinstance(compilation_result, CompilationResult)
    assert compilation_result.files == 1
    assert compilation_result.time == 1.0
    assert compilation_result.target == (3, 6)
    assert compilation_result.dependencies == []


# Generated at 2022-06-23 23:38:51.039244
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(None, None, None)
    assert tr.tree is None
    assert tr.tree_changed is None
    assert tr.dependencies is None
    return tr


# Generated at 2022-06-23 23:38:58.189171
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # test
    path0 = Path("a")
    path1 = Path("b")
    a = InputOutput(path0, path1)
    assert a.input == path0
    assert a.output == path1
    # test
    path0 = Path("a")
    path1 = None
    a = InputOutput(path0, path1)
    assert a.input == path0
    assert a.output is None
    # test
    path0 = Path("a")
    a = InputOutput(path0)
    assert a.input == path0
    assert a.output is None
    # test
    path0 = Path("a")
    path1 = Path("b")
    a = InputOutput([path0, path1])
    assert a.input == path0
    assert a.output == path1

# Unit test

# Generated at 2022-06-23 23:38:59.875973
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    a = TransformationResult(None, None, None)
    a.tree
    a.tree_changed
    a.dependencies

# Generated at 2022-06-23 23:39:05.982018
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 1
    time = 1
    target = (2, 1)
    deps = ['a', 'b', 'c']
    cr = CompilationResult(
        files=files,
        time=time,
        target=target,
        dependencies=deps)
    assert cr.files == files
    assert cr.time == time
    assert cr.target == target
    assert cr.dependencies == deps


# Generated at 2022-06-23 23:39:08.251522
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse('pass'),
                                False,
                                []).tree == ast.parse('pass')
    assert TransformationResult(ast.parse('pass'),
                                False,
                                ['a', 'b']).dependencies == ['a', 'b']
    assert TransformationResult(ast.parse('pass'),
                                True,
                                ['a', 'b']).tree_changed is True

# Generated at 2022-06-23 23:39:10.897046
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    a = ast.parse("pass")
    r = TransformationResult(tree=a,
                             tree_changed=True,
                             dependencies=[])

# Generated at 2022-06-23 23:39:18.710505
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path('abc')
    path2 = Path('def')

    io1 = InputOutput(path1, path2)
    io2 = InputOutput(path1, path2)
    io3 = InputOutput(path2, path1)
    assert io1 == io2
    assert io1 != io3
    assert '<InputOutput input:abc output:def>' == str(io1)
    assert {io1} == {io1, io2}
    assert {io1, io3} == {io1, io2, io3}


# Generated at 2022-06-23 23:39:23.479388
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=3, time=3.3,
                           target=(3,3), dependencies=["foo", "bar"])
    assert cr.files == 3
    assert cr.time == 3.3
    assert cr.target == (3,3)
    assert cr.dependencies == ["foo", "bar"]

    with pytest.raises(AttributeError):
        cr.files = 3



# Generated at 2022-06-23 23:39:30.833299
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass', '<string>')
    assert TransformationResult(tree=tree,
                                tree_changed=True,
                                dependencies=['x', 'y'])
    assert TransformationResult(tree=tree,
                                tree_changed=False,
                                dependencies=[])

# Results of transformers
TransformationResults = NamedTuple('TransformationResults',
                                   [('input_outputs', List[InputOutput]),
                                    ('compilation_result', CompilationResult)])

# Generated at 2022-06-23 23:39:32.727680
# Unit test for constructor of class InputOutput
def test_InputOutput():
    from inputoutput import InputOutput
    InputOutput(Path('/tmp/foo'), Path('/tmp/bar'))

# Generated at 2022-06-23 23:39:37.546360
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse('a=1'), False, [])
    assert TransformationResult(ast.parse('a=1'), True, [])
    assert TransformationResult(ast.parse('a=1'), False, ['a'])
    assert TransformationResult(ast.parse('a=1'), True, ['a'])



# Generated at 2022-06-23 23:39:41.343424
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=0.0, target=(2, 7), dependencies=[])
    assert cr.files == 1
    assert cr.time == 0.0
    assert cr.target == (2, 7)
    assert cr.dependencies == []


# Generated at 2022-06-23 23:39:42.923874
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input=Path('input'), output=Path('output'))
    assert InputOutput(Path('input'), Path('output'))



# Generated at 2022-06-23 23:39:46.138787
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Given
    input_path = "Foo.py"
    output_path = "Bar.py"
    # When
    io = InputOutput(input_path, output_path)
    # Then
    assert io.input == Path(input_path)
    assert io.output == Path(output_path)


# Generated at 2022-06-23 23:39:47.734940
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2.3, (3, 4), ['a', 'b'])


# Generated at 2022-06-23 23:39:50.646372
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input.py')
    output = Path('output.py')
    tuple = InputOutput(input, output)
    assert tuple.input == input
    assert tuple.output == output


# Generated at 2022-06-23 23:39:52.711262
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(42, 1.2, (2, 7), ['a', 'b']) == \
        CompilationResult(files=42, time=1.2, target=(2, 7), dependencies=['a', 'b'])


# Generated at 2022-06-23 23:39:56.376177
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('input.py'), Path('output.py'))
    assert input_output.input.name == 'input.py'
    assert input_output.output.name == 'output.py'


# Generated at 2022-06-23 23:39:57.698495
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from typed_ast import ast3 as ast
    ast.parse(buf='')

# Generated at 2022-06-23 23:39:59.138930
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    import _ast
    assert issubclass(TransformationResult.tree, _ast.AST)

# Generated at 2022-06-23 23:40:06.525816
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a=1', mode='exec')
    res1 = TransformationResult(tree, False, [])
    assert res1.tree is tree and res1.tree_changed is False and res1.dependencies == []
    res2 = TransformationResult(tree, True, [])
    assert res2.tree is tree and res2.tree_changed is True and res2.dependencies == []
    res3 = TransformationResult(tree, False, ['a.txt'])
    assert res3.tree is tree and res3.tree_changed is False and res3.dependencies == ['a.txt']
    res4 = TransformationResult(tree, True, ['a.txt'])
    assert res4.tree is tree and res4.tree_changed is True and res4.dependencies == ['a.txt']

# Threshold for version difference

# Generated at 2022-06-23 23:40:17.389649
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # pylint: disable=too-few-public-methods
    class Node(ast.AST):
        _fields = ()

    # pylint: enable=too-few-public-methods

    node = Node()
    tree = ast.Module(body=[node])
    tree_changed = True
    dependencies = []
    transformation_result = TransformationResult(tree, tree_changed, dependencies)
    assert transformation_result.tree == tree
    assert transformation_result.tree_changed == tree_changed
    assert transformation_result.dependencies == dependencies


# Information about executed test
TestResult = NamedTuple('TestResult',
                        [('test', str),
                         ('failed', bool),
                         ('compilation_result', CompilationResult)])

# Information about executed test

# Generated at 2022-06-23 23:40:20.293843
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from ast_transformer import ASTTransformer
    assert isinstance(
        TransformationResult(
            ASTTransformer('tests/testdata/test_ast_transformer_1.py'),
            True,
            []),
        TransformationResult)

# Generated at 2022-06-23 23:40:21.386668
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult.__new__(TransformationResult, ast.Module(), False, [])

# Generated at 2022-06-23 23:40:24.547381
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert isinstance(TransformationResult.tree, property)
    assert isinstance(TransformationResult.tree_changed, property)
    assert isinstance(TransformationResult.dependencies, property)

# Generated at 2022-06-23 23:40:34.189151
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a')
    res1 = TransformationResult(tree, True, ['b'])

    # Test that __eq__ and __hash__ work
    res2 = TransformationResult(tree, True, ['b'])
    res3 = TransformationResult(tree, False, ['b'])
    res4 = TransformationResult(tree, True, ['c'])
    res5 = TransformationResult(ast.parse('b'), True, ['b'])
    res6 = TransformationResult(tree, True, [])

    assert res1 == res2
    assert res1 == res1
    assert res1 != res3
    assert res1 != res4
    assert res1 != res5
    assert res1 != res6
    assert res1 != 'foo'
    assert hash(res1) == hash(res2)
    assert hash(res1)

# Generated at 2022-06-23 23:40:37.581357
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('in'), Path('out'))
    assert isinstance(InputOutput(Path('in'), Path('out')).input, Path)
    assert isinstance(InputOutput(Path('in'), Path('out')).output, Path)



# Generated at 2022-06-23 23:40:39.810362
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=42,
                                tree_changed=True,
                                dependencies=[]) == \
        TransformationResult(tree=42,
                             tree_changed=True,
                             dependencies=[])

# Generated at 2022-06-23 23:40:41.539480
# Unit test for constructor of class InputOutput
def test_InputOutput():
    '''Test for constructor of class InputOutput'''
    InputOutput('input', 'output')



# Generated at 2022-06-23 23:40:48.536485
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    """Unit test for constructor of class TransformationResult"""
    _tree = ast.parse('foo = 3')
    _tree_changed = True
    _dependencies = ['a', 'b', 'c']
    _result = TransformationResult(tree=_tree, tree_changed=_tree_changed,
                                   dependencies=_dependencies)
    assert _result.tree == _tree
    assert _result.tree_changed == _tree_changed
    assert _result.dependencies == _dependencies

# Generated at 2022-06-23 23:40:52.613036
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=1, time=0, target=(3, 5), dependencies=[])
    assert c.files == 1
    assert c.time == 0
    assert c.target == (3, 5)
    assert c.dependencies == []


# Generated at 2022-06-23 23:40:55.245155
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('')
    tr = TransformationResult(tree, True, [])
    assert tr.tree_changed == True
    assert tr.tree == tree


# Generated at 2022-06-23 23:41:00.025955
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=0,
                               time=0,
                               target=(3, 7),
                               dependencies=['test.py', 'file.py'])

    assert result.files == 0
    assert result.time == 0
    assert result.target == (3, 7)
    assert result.dependencies == ['test.py', 'file.py']


# Generated at 2022-06-23 23:41:02.562016
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('input'), Path('output')).output.name == 'output'
    assert InputOutput(Path('input'), Path('output')).input.name == 'input'

# Generated at 2022-06-23 23:41:07.929484
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=8, time=3.2, target=(3, 4), dependencies=[])
    assert cr.files == 8
    assert cr.time == 3.2
    assert cr.target[0] == 3
    assert cr.target[1] == 4
    assert cr.dependencies == []


# Generated at 2022-06-23 23:41:11.742855
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(12, 42, (42, 42), ['foo'])
    assert result.files == 12
    assert result.time == 42
    assert result.target == (42, 42)
    assert result.dependencies == ['foo']


# Generated at 2022-06-23 23:41:15.111206
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None

    # construct instance
    x = TransformationResult(tree=None, tree_changed=False, dependencies=['hello'])

    # assert types and values
    assert x.tree is None
    assert not x.tree_changed
    assert x.dependencies == ['hello']

# Generated at 2022-06-23 23:41:19.702074
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('src'), Path('dst')) == (Path('src'), Path('dst'))
    assert InputOutput(Path('src'), Path('dst')) != (Path('src'), Path('dst'),)
    assert InputOutput(Path('src'), Path('dst')) != (Path('src2'), Path('dst2'))


# Generated at 2022-06-23 23:41:20.573997
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('/tmp'), Path('/tmp2'))



# Generated at 2022-06-23 23:41:21.725705
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse(""), True, []).tree_changed

# Generated at 2022-06-23 23:41:23.615031
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path('a/b/c')
    path2 = Path('d/e/f')

    input_output = InputOutput(path1, path2)
    assert input_output.input == path1
    assert input_output.output == path2

# Generated at 2022-06-23 23:41:25.741577
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('inp')
    outp = Path('outp')
    iop = InputOutput(inp, outp)
    assert iop.input == inp
    assert iop.output == outp


# Generated at 2022-06-23 23:41:36.712591
# Unit test for constructor of class TransformationResult
def test_TransformationResult():

    # Syntax tree of input file
    tree = ast.parse("")

    # Construct values of type TransformationResult
    transformation_result_1 = TransformationResult(tree, False, [])
    transformation_result_2 = TransformationResult(tree, True, [])
    transformation_result_3 = TransformationResult(tree, False, ["abc"])
    transformation_result_4 = TransformationResult(tree, False, ["abc", "def"])

    # Check that values of type TransformationResult are valid
    assert transformation_result_1.tree == tree
    assert transformation_result_1.tree_changed == False
    assert transformation_result_1.dependencies == []
    assert transformation_result_2.tree == tree
    assert transformation_result_2.tree_changed == True
    assert transformation_result_2.dependencies == []
    assert transformation_result_3

# Generated at 2022-06-23 23:41:39.303563
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('output.txt')
    o = Path('input.txt')
    InputOutput(i, o)


# Generated at 2022-06-23 23:41:44.698032
# Unit test for constructor of class InputOutput
def test_InputOutput():
    tmpdir = tempfile.mkdtemp()
    input_p = Path(tmpdir) / 'input'
    output_p = Path(tmpdir) / 'output'
    io = InputOutput(input_p, output_p)
    assert io.input == input_p
    assert io.output == output_p

# Generated at 2022-06-23 23:41:47.776516
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input, output = Path('a'), Path('b')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-23 23:41:50.418368
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(None, False, [])
    assert result.tree is None
    assert not result.tree_changed
    assert not result.dependencies

# Generated at 2022-06-23 23:41:53.964700
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(0, 0, (2, 7), [])
    assert cr.files == 0
    assert cr.time == 0
    assert cr.target == (2, 7)
    assert cr.dependencies == []


# Generated at 2022-06-23 23:41:55.188254
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(0, 0, (0, 0), [])


# Generated at 2022-06-23 23:41:57.324620
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_io = InputOutput(Path("input"), Path("output"))
    assert input_io.input == Path("input")
    assert input_io.output == Path("output")

# Generated at 2022-06-23 23:41:59.058306
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files = 1,
                      time = 3.2,
                      target = (3, 6),
                      dependencies = [])


# Generated at 2022-06-23 23:42:01.893453
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    d = TransformationResult(ast.Module(), True, ['foo.py', 'bar.py'])
    assert isinstance(d.tree, ast.AST)
    assert isinstance(d.tree_changed, bool)
    assert all(isinstance(i, str) for i in d.dependencies)