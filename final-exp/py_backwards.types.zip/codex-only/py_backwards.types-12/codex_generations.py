

# Generated at 2022-06-23 23:32:06.531743
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.Module()
    obj = TransformationResult(tree, True, [])
    assert obj.tree == tree
    assert obj.tree_changed == True
    assert obj.dependencies == []

# Generated at 2022-06-23 23:32:10.373654
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('/tmp/foo/bar')
    out = Path('/tmp/baz/qux')
    inout = InputOutput(inp, out)
    assert inout.input == inp
    assert inout.output == out


# Generated at 2022-06-23 23:32:13.806705
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('def f(): a = 5', mode='exec')
    result = TransformationResult(tree, False, [])
    assert result.tree == tree
    assert result.tree_changed == False
    assert result.dependencies == []

# Generated at 2022-06-23 23:32:15.430296
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=0, time=0.0, target=(3,0), dependencies=[])



# Generated at 2022-06-23 23:32:19.420258
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(11, 0.111, (3, 8), ['a', 'b'])
    assert cr.files == 11
    assert cr.time == 0.111
    assert cr.target == (3, 8)
    assert cr.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:32:22.616826
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    a = CompilationResult(0, 0., (3, 0), [])
    b = CompilationResult(0, 0., (3, 0), [])
    c = CompilationResult(1, 0., (3, 0), [])
    d = CompilationResult(0, 0., (3, 1), [])
    assert a == b
    assert a != c
    assert a != d
    assert a != object()


# Generated at 2022-06-23 23:32:24.431404
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Given
    CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=['5'])

# Generated at 2022-06-23 23:32:29.743317
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path = Path('/tmp')
    input_output_pair = InputOutput(input=path / 'input.py',
                                    output=path / 'output.py')
    assert(input_output_pair.input == path / 'input.py')
    assert(input_output_pair.output == path / 'output.py')


# Generated at 2022-06-23 23:32:34.131251
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('for i in range(10): pass')
    result = TransformationResult(tree,
                                  True,
                                  ['foo.py', 'bar.py'])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == ['foo.py', 'bar.py']

# Generated at 2022-06-23 23:32:35.566464
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    _ = TransformationResult(tree=None, tree_changed=False, dependencies=[])

# Generated at 2022-06-23 23:32:39.171565
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput('input.py', 'output.py')
    assert input_output.input == Path('input.py')
    assert input_output.output == Path('output.py')

# Test compilation_target_to_compiler_arguments

# Generated at 2022-06-23 23:32:40.791511
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(0, 1, (2, 3), [])



# Generated at 2022-06-23 23:32:43.419965
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p = Path('a/b/c.txt')
    i = InputOutput(input=p,
                    output=p)
    assert(i.input == i.output)

# Generated at 2022-06-23 23:32:48.154594
# Unit test for constructor of class InputOutput
def test_InputOutput():
    IO = InputOutput('input', 'output')
    assert isinstance(IO.input, Path)
    assert isinstance(IO.output, Path)
    assert IO == InputOutput(Path('input'), Path('output'))
    assert IO == InputOutput(Path('input'), 'output')
    assert IO == InputOutput('input', Path('output'))


# Generated at 2022-06-23 23:32:51.260522
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=2, time=3.21, target=(3, 4))
    assert result.files == 2
    assert result.time == 3.21
    assert result.target == (3, 4)
    assert result.dependencies == []



# Generated at 2022-06-23 23:32:53.799174
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    try:
        TransformationResult(ast.Module(), False, [])
        TransformationResult(ast.Module(), True, [])
        TransformationResult(ast.Module(), False, ['a'])
        TransformationResult(ast.Module(), True, ['a', 'b'])
    except TypeError:
        assert False, "Error in TransformationResult class"


# Main class for creation of transformation class

# Generated at 2022-06-23 23:32:55.434360
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a'), Path('b')) == InputOutput(input=Path('a'), output=Path('b'))


# Generated at 2022-06-23 23:32:59.336140
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=4, time=17.0,
                                           target=(3, 7),
                                           dependencies=['a', 'b', 'c'])
    assert compilation_result.files == 4
    assert compilation_result.time == 17.0
    assert compilation_result.target == (3, 7)
    assert compilation_result.dependencies == ['a', 'b', 'c']


# Generated at 2022-06-23 23:33:00.551377
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path("i.py"), Path("o.py"))


# Generated at 2022-06-23 23:33:03.208335
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('foo.py')
    output = Path('foo.pyi')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output

# Generated at 2022-06-23 23:33:07.138095
# Unit test for constructor of class InputOutput
def test_InputOutput():
    Path = NamedTuple('Path', [('input', str),
                               ('output', str)])
    path = Path('in', 'out')
    result = InputOutput(Path('in', 'out'))
    assert result.input == path.input
    assert result.output == path.output
    assert result == InputOutput(Path(path.input, path.output))


# Generated at 2022-06-23 23:33:11.438070
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 2, (3, 4), ["hello"])
    assert result.files == 1
    assert result.time == 2
    assert result.target == (3, 4)
    assert result.dependencies == ["hello"]



# Generated at 2022-06-23 23:33:15.262948
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path = Path('input')
    input_output = InputOutput(path, path.with_suffix('.py'))
    assert input_output.input == input_output.output.with_suffix('.in')
    assert input_output.output == input_output.input.with_suffix('.py')

# Generated at 2022-06-23 23:33:18.775790
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(input=Path('input'), output=Path('output'))
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')

# Generated at 2022-06-23 23:33:28.614668
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    t = TransformationResult(tree, False, [])
    t.tree
    t.tree_changed
    t.dependencies
    t._replace(tree_changed=True, dependencies=['a'])
    t._fields
    t._asdict()
    t._replace(tree_changed=True).tree_changed
    t._replace(dependencies=['a']).dependencies

# Version of typed_ast that is used for tranformation
TransformationVersion = NamedTuple('TransformationVersion', [('major', int),
                                                             ('minor', int)])

# AST with version information
VersionedAST = NamedTuple('VersionedAST', [('version', TransformationVersion),
                                           ('tree', ast.AST)])


# Generated at 2022-06-23 23:33:30.419353
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = InputOutput(Path("in"), Path("out"))
    assert i.input == Path("in")
    assert i.output == Path("out")

# Generated at 2022-06-23 23:33:33.834054
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # type: () -> None
    i, o = Path('i.txt'), Path('o.txt')
    input_output = InputOutput(input=i, output=o)
    assert input_output.input == i
    assert input_output.output == o


# Generated at 2022-06-23 23:33:35.236704
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(0, 0, (0, 0), [])


# Generated at 2022-06-23 23:33:37.622005
# Unit test for constructor of class InputOutput
def test_InputOutput():
    data = InputOutput(Path('a'), Path('b'))
    assert data.input == Path('a')
    assert data.output == Path('b')

# Generated at 2022-06-23 23:33:42.756802
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(tree=None, tree_changed=True, dependencies=["a"])
    assert res.tree is None
    assert res.tree_changed is True
    assert res.dependencies == ["a"]


# Result of transformers transformation that can include an error
ErrorableTransformationResult = NamedTuple('ErrorableTransformationResult',
                                           [('result', TransformationResult),
                                            ('error', str)])


# Generated at 2022-06-23 23:33:44.701346
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2.5, (3, 4), []) ==\
        CompilationResult(1, 2.5, (3, 4), [])


# Generated at 2022-06-23 23:33:48.033478
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ins = InputOutput(Path('foo.py'), Path('bar.py'))
    tr = TransformationResult(ast.parse('pass'), True, ['a.py'])
    assert tr.tree is not None
    assert not isinstance(tr.tree, str)
    assert tr.tree_changed is True
    assert tr.dependencies is not None

# End of test for class TransformationResult

# Transformation result factory

# Generated at 2022-06-23 23:33:50.148252
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=1, time=1.0,
                             target=(3, 7), dependencies=[])


# Generated at 2022-06-23 23:33:54.759936
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    a = CompilationResult(files=123,
                          time=1.23,
                          target=(3, 7),
                          dependencies=['abc', 'def'])
    assert a.files == 123
    assert a.time == 1.23
    assert a.target == (3, 7)
    assert a.dependencies == ['abc', 'def']


# Generated at 2022-06-23 23:33:58.138160
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 10
    time = 1.0
    major = 2
    minor = 7
    target = (major, minor)
    dependencies = []
    result = CompilationResult(files, time, target, dependencies)
    assert result is not None


# Generated at 2022-06-23 23:34:01.682903
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = "input.txt"
    output = "output.txt"
    in_out = InputOutput(Path(input), Path(output))
    assert in_out.input == Path(input)
    assert in_out.output == Path(output)



# Generated at 2022-06-23 23:34:04.533467
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(1, 1.2, (3, 4), ['a', 'b'])
    assert r.files == 1
    assert r.time == 1.2
    assert r.target == (3, 4)
    assert r.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:34:05.722919
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(tree=ast.parse('pass'),
                         tree_changed=False,
                         dependencies=[])


# Generated at 2022-06-23 23:34:07.562524
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path("foo")
    output = Path("bar")

    input_output = InputOutput(input, output)

    assert input_output.input == input
    assert input_output.output == output

# Generated at 2022-06-23 23:34:09.633461
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('i')
    o = Path('o')
    io = InputOutput(i, o)
    assert io.input == i and io.output == o


# Generated at 2022-06-23 23:34:13.598170
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('1 + 1')
    result = TransformationResult(tree, True, ['dependency.py'])

    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == ['dependency.py']

# Result of box generation for currying
BoxResult = NamedTuple('BoxResult', [('box', str),
                                     ('dependencies', List[str])])


# Generated at 2022-06-23 23:34:15.411086
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.Module([]), True, ['a'])
    assert tr.tree_changed is True
    assert tr.dependencies == ['a']

# Generated at 2022-06-23 23:34:22.997480
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # setup
    tree = ast.Module([]).body
    tree_changed = True
    dependencies = []
    # run
    result = TransformationResult(tree, tree_changed, dependencies)
    # check
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# result of transformer chain operation
TransformerChainResult = NamedTuple('TransformerChainResult',
                                    [('trees', List[ast.AST]),
                                     ('trees_changed', bool),
                                     ('dependencies', List[str])])

# unit test for constructor of class TransformerChainResult

# Generated at 2022-06-23 23:34:26.292477
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_text = r'test/input/'
    output_text = r'test/output/'
    res = InputOutput(input_text, output_text)
    assert res.input == input_text
    assert res.output == output_text


# Generated at 2022-06-23 23:34:28.547807
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('a.py'), Path('a.pyc'))
    assert input_output.input == Path('a.py')
    assert input_output.output == Path('a.pyc')


# Generated at 2022-06-23 23:34:30.452530
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    _ = CompilationResult(1, 0.1, (3, 5), [])
    assert True



# Generated at 2022-06-23 23:34:35.325886
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a=1;b=2;c=a+b')
    res = TransformationResult(tree, False, ['a', 'b'])
    assert res.tree == tree
    assert res.tree_changed == False
    assert res.dependencies == ['a', 'b']

# Generated at 2022-06-23 23:34:38.244446
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('in'), Path('out')).input == Path('in')
    assert InputOutput(Path('in'), Path('out')).output == Path('out')

# Generated at 2022-06-23 23:34:42.214451
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=0.0, target=(3, 5), dependencies=[])
    assert cr.files == 1
    assert cr.time == 0.0
    assert isinstance(cr.time, float)
    assert cr.target == (3, 5)
    assert cr.dependencies == []

# Generated at 2022-06-23 23:34:44.830583
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('input')
    output = Path('output')
    arg = InputOutput(input_, output)
    assert arg.input == input_
    assert arg.output == output

# Generated at 2022-06-23 23:34:48.042434
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("")
    inout = TransformationResult(tree, False, [])
    assert inout.tree == tree
    assert inout.tree_changed == False
    assert inout.dependencies == []

# Generated at 2022-06-23 23:34:49.640711
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('input'), Path('output'))
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')

# Generated at 2022-06-23 23:34:51.678591
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 0')
    tree_changed = True
    dependencies = ['path0', 'path1']
    TransformationResult(tree=tree, tree_changed=tree_changed,
                         dependencies=dependencies)

# Generated at 2022-06-23 23:34:54.724409
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_file = Path('input.py')
    output_file = Path('output.py')
    input_output = InputOutput(input_file, output_file)
    assert input_output.input == input_file
    assert input_output.output == output_file


# Generated at 2022-06-23 23:34:55.956842
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(tree=None, tree_changed=None, dependencies=None)

# Generated at 2022-06-23 23:35:00.283409
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(0, 0.0, (0, 0), [])
    assert result.files == 0
    assert result.time == 0.0
    assert result.target == (0, 0)
    assert result.dependencies == []


# Generated at 2022-06-23 23:35:02.368883
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("print('Hello World')")
    assert TransformationResult(tree, False, []) \
           == TransformationResult(tree, False, [])

# Generated at 2022-06-23 23:35:07.957341
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_ = ast.parse('')
    result = TransformationResult(
        ast_, tree_changed=True, dependencies=[''])
    assert result.tree == ast_
    assert result.tree_changed is True
    assert result.dependencies == ['']


# Result for AST transformer
TransformerResult = NamedTuple('TransformerResult',
                               [('tree', ast.AST),
                                ('tree_changed', bool)])


# Generated at 2022-06-23 23:35:10.424651
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=None, tree_changed=False, dependencies=[])
    assert(tr.tree == None)
    assert(tr.tree_changed == False)
    assert(tr.dependencies == [])

# Generated at 2022-06-23 23:35:13.941862
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=5, time=3.5, target=(2, 7), dependencies=['a'])
    assert res.files == 5
    assert res.time == 3.5
    assert res.target == (2, 7)
    assert res.dependencies == ['a']


# Generated at 2022-06-23 23:35:23.434665
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=1,
                             time=1.0,
                             target=(2, 7),
                             dependencies=[]).files == 1
    assert CompilationResult(files=1,
                             time=1.0,
                             target=(2, 7),
                             dependencies=[]).time == 1.0
    assert CompilationResult(files=1,
                             time=1.0,
                             target=(2, 7),
                             dependencies=[]).target == (2, 7)
    assert CompilationResult(files=1,
                             time=1.0,
                             target=(2, 7),
                             dependencies=[]).dependencies == []


# Generated at 2022-06-23 23:35:27.967472
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    results = CompilationResult(files=10, time=20.0, target=(2, 7), dependencies=["a", "b"])
    assert results.files == 10
    assert results.time == 20.0
    assert results.target == (2, 7)
    assert results.dependencies == ["a", "b"]


# Generated at 2022-06-23 23:35:30.420975
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=1.0,
                               target=(3, 6),
                               dependencies=['test.py'])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 6)
    assert result.dependencies == ['test.py']



# Generated at 2022-06-23 23:35:32.222162
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.parse('a = 1'), True, ['a'])

# Assert that there are no loops in input/output pairs

# Generated at 2022-06-23 23:35:34.561057
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = 'test.py'
    output = 'test_c.py'
    pair = InputOutput(input, output)

    assert pair.input == input
    assert pair.output == output


# Generated at 2022-06-23 23:35:35.807096
# Unit test for constructor of class InputOutput
def test_InputOutput():  # type: () -> None
    InputOutput(input=Path('example'), output=Path('example.s'))


# Generated at 2022-06-23 23:35:38.002771
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.Module()
    r = TransformationResult(t, False, [])
    assert r.tree == t
    assert not r.tree_changed
    assert r.dependencies == []
    assert len(r.dependencies) == 0



# Generated at 2022-06-23 23:35:41.054734
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    r = TransformationResult(None, False, [])
    assert r.tree == None
    assert r.tree_changed == False
    assert r.dependencies == []

# Generated at 2022-06-23 23:35:43.151292
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a'), Path('b')) == InputOutput(Path('a'), Path('b'))



# Generated at 2022-06-23 23:35:47.089135
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(0, 0, (0, 0), [])
    assert result.files == 0
    assert result.time == 0
    assert result.target == (0, 0)
    assert result.dependencies == []



# Generated at 2022-06-23 23:35:51.746489
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1,
                                           time=1.0,
                                           target=(3, 5),
                                           dependencies=['foo'])
    assert str(compilation_result) == 'files: 1, time: 1.0, target: (3, 5), dependencies: [foo]'


# Generated at 2022-06-23 23:35:53.583481
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('/home/user/x.py'), Path('/home/user/y.py'))

# Generated at 2022-06-23 23:35:55.732651
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # pylint: disable=no-member
    instance = CompilationResult(0, 0, (3, 6), [])
    assert isinstance(instance.files, int)
    assert isinstance(instance.time, float)
    assert isinstance(instance.target, CompilationTarget)
    assert isinstance(instance.dependencies, List[str])


# Generated at 2022-06-23 23:35:56.991134
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path("input"), Path("output"))

# Generated at 2022-06-23 23:35:58.310803
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('file.txt'), Path('file.html'))


# Generated at 2022-06-23 23:35:59.340998
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('./i'), Path('./o'))


# Generated at 2022-06-23 23:36:03.145960
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=0, time=0, target=(3, 7), dependencies=[])
    assert cr.files == 0
    assert cr.time == 0
    assert cr.target == (3, 7)
    assert cr.dependencies == []


# Generated at 2022-06-23 23:36:06.935704
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('A'), Path('B')) == InputOutput(Path('A'), Path('B'))
    assert InputOutput(Path('A'), Path('B')) != InputOutput(Path('B'), Path('A'))


# Generated at 2022-06-23 23:36:10.545468
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(1, 1.0, (3, 7), [])
    assert compilation_result.files == 1
    assert compilation_result.time == 1.0
    assert compilation_result.target == (3, 7)


# Generated at 2022-06-23 23:36:12.923215
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('input'), Path('output')) == \
           InputOutput(input=Path('input'), output=Path('output'))

# Generated at 2022-06-23 23:36:18.706627
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(files=1, time=0.0,
                          target=(3, 6),
                          dependencies=['foo', 'bar'])
    assert r.files == 1
    assert r.time == 0.0
    assert r.target[0] == 3 and r.target[1] == 6
    assert r.dependencies[0] == 'foo' and r.dependencies[1] == 'bar'


# Generated at 2022-06-23 23:36:20.869121
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=None,
                              tree_changed=False,
                              dependencies=["somefile1", "somefile2"])


# Generated at 2022-06-23 23:36:27.287421
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    '''Test of constructor of class CompilationResult'''
    compilation_result = CompilationResult(5, 3.5,
                                           (3, 7),
                                           ['module1'])
    assert compilation_result.files == 5
    assert compilation_result.time == 3.5
    assert compilation_result.target == (3, 7)
    assert compilation_result.dependencies == ['module1']


# Generated at 2022-06-23 23:36:30.766376
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path("input_path")
    output_path = Path("output_path")
    input_output = InputOutput(input_path, output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path
    del input_output.input
    del input_output.output

# Generated at 2022-06-23 23:36:32.310463
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, True, []).tree is None



# Generated at 2022-06-23 23:36:36.319952
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('1+2')
    dependencies = ['__builtins__']
    res = TransformationResult(tree, True, dependencies)
    assert res.tree == tree
    assert res.tree_changed == True
    assert res.dependencies == ['__builtins__']



# Generated at 2022-06-23 23:36:40.176312
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(1, 0.1, (3, 6), [])
    assert res.files == 1
    assert res.time == 0.1
    assert res.target == (3, 6)
    assert res.dependencies == []



# Generated at 2022-06-23 23:36:42.714397
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path(__file__), Path(__file__)).input.name == __file__
    assert InputOutput(Path(__file__), Path(__file__)).output.name == __file__


# Generated at 2022-06-23 23:36:46.900601
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.1, target=(3, 2), dependencies=[])
    assert result.files == 1
    assert result.time == 1.1
    assert result.target == (3, 2)
    assert result.dependencies == []


# Generated at 2022-06-23 23:36:47.892073
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, None, None)

# Generated at 2022-06-23 23:36:51.408391
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    source = 'a.py'
    dependencies = ['b.py']
    result = TransformationResult(tree, True, dependencies)
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == dependencies

# Generated at 2022-06-23 23:36:54.795685
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    tres = TransformationResult(tree=tree,
                                tree_changed=True,
                                dependencies=['foo'])

    assert tres.tree == tree
    assert tres.tree_changed is True
    assert tres.dependencies == ['foo']

# Generated at 2022-06-23 23:36:57.401320
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/home/michal/input')
    output = Path('/home/michal/output')
    assert InputOutput(input, output) == InputOutput(input, output)

# Generated at 2022-06-23 23:36:59.382729
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('input'), Path('output')) == InputOutput('input', 'output')



# Generated at 2022-06-23 23:37:04.999419
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """Unit test for constructor of class InputOutput."""
    assert InputOutput(Path('a'), Path('b'))
    assert InputOutput(input=Path('a'), output=Path('b'))
    assert InputOutput(Path('a'), Path('b')).input == Path('a')
    assert InputOutput(Path('a'), Path('b')).output == Path('b')

# Generated at 2022-06-23 23:37:08.554790
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_case = InputOutput(input=Path('input'), output=Path('output'))
    assert isinstance(test_case, InputOutput)
    assert isinstance(test_case.input, Path)
    assert isinstance(test_case.output, Path)


# Generated at 2022-06-23 23:37:11.272467
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(tree=None,
                                  tree_changed=False,
                                  dependencies=[])
    assert result.tree is None
    assert result.tree_changed is False
    assert result.dependencies == []

# Generated at 2022-06-23 23:37:14.872026
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = None')
    tree_changed = True
    dependencies = ['a', 'b']
    result = TransformationResult(tree=tree, tree_changed=tree_changed,
                                  dependencies=dependencies)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-23 23:37:17.234635
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("")
    tree_changed = True
    dependencies = ["dep", "file"]
    r = TransformationResult(tree, tree_changed, dependencies)

    assert r.tree == tree
    assert r.tree_changed == tree_changed
    assert r.dependencies == dependencies

# Generated at 2022-06-23 23:37:21.524426
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(10, 0.0, (3, 7), [])
    assert cr.files == 10
    assert cr.time == 0.0
    assert cr.target == (3, 7)
    assert cr.dependencies == []


# Generated at 2022-06-23 23:37:24.769892
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # pylint: disable=W0612
    tree = ast.parse('foo')
    tree_changed = True
    dependencies = ['foo', 'bar']
    TransformationResult(tree, tree_changed, dependencies)

# Generated at 2022-06-23 23:37:27.565677
# Unit test for constructor of class InputOutput
def test_InputOutput():
    result = InputOutput(Path("/foo/bar"), Path("/baz/zab"))
    assert result.input == Path("/foo/bar")
    assert result.output == Path("/baz/zab")

# Generated at 2022-06-23 23:37:31.407049
# Unit test for constructor of class InputOutput
def test_InputOutput():

    # When
    input_output = InputOutput(input=Path('/tmp/my_input.py'),
                               output=Path('/tmp/my_output.py'))

    # Then
    assert input_output.input == Path('/tmp/my_input.py')
    assert input_output.output == Path('/tmp/my_output.py')


# Generated at 2022-06-23 23:37:35.795616
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=1,
                          time=1.0,
                          target=(3,6),
                          dependencies=["pandas"])
    assert c.files == 1
    assert c.time == 1.0
    assert c.target == (3,6)
    assert c.dependencies == ["pandas"]

# Generated at 2022-06-23 23:37:40.120826
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path_in = 'path_in'
    path_out = 'path_out'
    in_out = InputOutput(path_in, path_out)
    assert in_out.input == Path(path_in)
    assert in_out.output == Path(path_out)

# Generated at 2022-06-23 23:37:42.957117
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test = TransformationResult(ast.Module(), False, ['a', 'b', 'c'])
    assert test.tree
    assert not test.tree_changed
    assert test.dependencies == ['a', 'b', 'c']

# Generated at 2022-06-23 23:37:48.823965
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    import datetime

    compilation_result = CompilationResult(files=1, time=0.1, target=(3, 5),
                                           dependencies=['a', 'b', 'c'])
    assert compilation_result.files == 1
    assert compilation_result.time == 0.1
    assert compilation_result.target == (3, 5)
    assert compilation_result.dependencies == ['a', 'b', 'c']
    assert isinstance(compilation_result.time, float)
    assert isinstance(compilation_result.time, datetime.timedelta)


# Generated at 2022-06-23 23:37:51.145203
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from typed_ast import ast3 as ast
    a = ast.parse('pass')
    b = []
    s = TransformationResult(a, True, b)
    assert s.tree
    assert s.tree_changed
    assert s.dependencies

# Generated at 2022-06-23 23:37:52.015860
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('input.py'), Path('output.py'))

# Generated at 2022-06-23 23:37:55.467050
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = InputOutput(Path("dir/file.py"), Path("dir/file.py.out"))
    assert i.input == Path("dir/file.py")
    assert i.output == Path("dir/file.py.out")

# Generated at 2022-06-23 23:38:06.077217
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=None,
                              tree_changed=True,
                              dependencies=['a', 'b'])
    assert tr.tree is None
    assert tr.tree_changed == True
    assert tr.dependencies == ['a', 'b']

# List of all the transformations that are applied to the code to
# transpile it for Python 2

# Generated at 2022-06-23 23:38:12.144746
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input=Path('input'), output=Path('output')) == InputOutput(input=Path('input'), output=Path('output'))
    assert InputOutput(input=Path('input2'), output=Path('output')) != InputOutput(input=Path('input'), output=Path('output'))
    assert InputOutput(input=Path('input'), output=Path('output2')) != InputOutput(input=Path('input'), output=Path('output'))


# Generated at 2022-06-23 23:38:15.213415
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path_object = Path('/a/b/c')
    input_output = InputOutput(path_object, path_object)
    assert input_output.input == path_object
    assert input_output.output == path_object


# Generated at 2022-06-23 23:38:25.593782
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    """
    Unit test for the constructor of TransformationResult

    :return: None
    """
    tr = TransformationResult(tree=object(), tree_changed=True, dependencies=['a', 'b'])
    assert tr.tree is not None
    assert tr.tree_changed is True
    assert tr.dependencies is not None
    assert len(tr.dependencies) == 2
    assert 'a' in tr.dependencies
    assert 'b' in tr.dependencies


# Result of the compilation of a single file
SingleFileResult = NamedTuple('SingleFileResult',
                              [('input_output', InputOutput),
                               ('result', CompilationResult),
                               ('errors', List[str])])

# Result of the compilation of a directory

# Generated at 2022-06-23 23:38:29.375948
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(1, 0.2, (3,6), ['foo.py'])
    assert res.files == 1
    assert res.time == 0.2
    assert res.target == (3,6)
    assert res.dependencies == ['foo.py']


# Generated at 2022-06-23 23:38:32.026208
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    pr = TransformationResult(ast.AST(ast.mod('', []), []), False, [])
    assert(all(hasattr(pr, a) for a in ['tree', 'tree_changed', 'dependencies']))

# Generated at 2022-06-23 23:38:35.707600
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=5,
                                           time=3.5,
                                           target=(2, 7),
                                           dependencies=[])
    assert compilation_result.files == 5
    assert compilation_result.time == 3.5
    assert compilation_result.target == (2, 7)
    assert compilation_result.dependencies == []



# Generated at 2022-06-23 23:38:37.384604
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(input = 'foo', output = 'bar')
    InputOutput(input = Path('foo'), output = Path('bar'))

# Generated at 2022-06-23 23:38:41.568907
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path_0 = Path('/tmp/foo')
    path_1 = Path('/tmp/bar')
    inout_0 = InputOutput(path_0, path_1)
    assert inout_0.input == path_0
    assert inout_0.output == path_1

# Generated at 2022-06-23 23:38:44.831459
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """
    Test InputOutput constructor by passing it a few arguments
    """
    assert InputOutput('foo', 'bar') == ('foo', 'bar')

# Unit tests for constructor of class CompilationResult

# Generated at 2022-06-23 23:38:47.539626
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('a')
    out = Path('b')
    assert InputOutput(inp, out) == InputOutput(input=inp, output=out)



# Generated at 2022-06-23 23:38:51.516452
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(1, 0.1, (3, 5), ['foo', 'bar'])
    assert r.files == 1
    assert r.time == 0.1
    assert r.target == (3, 5)
    assert r.dependencies == ['foo', 'bar']


# Generated at 2022-06-23 23:38:54.691630
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Parameters of constructor
    input = 'input'
    output = 'output'

    # Call to tested constructor
    obj = InputOutput(input, output)

    # Check parameters of object
    assert obj.input == input
    assert obj.output == output

# Unit test of constructor of class TransformationResult

# Generated at 2022-06-23 23:38:55.805549
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(
        files=1,
        time=1.0,
        target=(3, 6),
        dependencies=['requests']
    )


# Generated at 2022-06-23 23:39:00.216061
# Unit test for constructor of class InputOutput
def test_InputOutput():
    import sys
    import io
    inp = io.StringIO('test')
    outp = io.StringIO()
    test_io = InputOutput(inp, outp)
    print(test_io.input, file=test_io.output)
    assert test_io.output.getvalue() == '<_io.StringIO object at 0x{:x}>'.\
        format(id(inp))


# Generated at 2022-06-23 23:39:02.730231
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('1')
    assert TransformationResult(t, False, []) == TransformationResult(t, False, [])

# Generated at 2022-06-23 23:39:05.457541
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    comp = CompilationResult(files=10, time=2., target=(2, 7),
                             dependencies=['a', 'b'])
    assert comp.files == 10
    assert comp.time == 2.
    assert comp.target == (2, 7)
    assert comp.dependencies == ['a', 'b']
    assert CompilationResult._fields == ('files', 'time', 'target',
                                         'dependencies')



# Generated at 2022-06-23 23:39:15.249094
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.parse("a"), True, [])
    assert isinstance(tr.tree, ast.AST)
    assert tr.tree_changed
    assert tr.dependencies == []

# List of invalid names for files
BadNames = NamedTuple('BadNames', [('method_names', Set[str]),
                                   ('docstring_names', Set[str])])

# Configuration of test suite
TestSuiteConfig = NamedTuple('TestSuiteConfig', [('name', str),
                                                 ('executable', str),
                                                 ('targets', List[CompilationTarget]),
                                                 ('additional_args', List[str])])

# Generated at 2022-06-23 23:39:20.150797
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=2, time=1.0, target=(3, 7),
                           dependencies=[str(Path('test.py').absolute())])
    assert cr.files == 2
    assert cr.time == 1.0
    assert cr.target == (3, 7)
    assert cr.dependencies == [str(Path('test.py').absolute())]


# Generated at 2022-06-23 23:39:22.095256
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, False, []).tree_changed
    assert not TransformationResult(None, False, []).tree_changed

# Generated at 2022-06-23 23:39:28.327339
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=5,
                                           time=1.1,
                                           target=(3, 4),
                                           dependencies=["a", "b"])
    assert (compilation_result.files == 5 and
            compilation_result.time == 1.1 and
            compilation_result.target == (3, 4) and
            compilation_result.dependencies == ["a", "b"])


# Generated at 2022-06-23 23:39:37.596894
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(tree=None, tree_changed=False, dependencies=[])
    assert(res.tree_changed == False)
    assert(len(res.dependencies) == 0)

# Output dependencies
OutputDependencies = NamedTuple('OutputDependencies',
                                [('output', Path),
                                 ('dependencies', List[str])])

# Result of compilation
CompilationResult = NamedTuple('CompilationResult',
                               [('files_compiled', int),
                                ('failed_files', List[Path]),
                                ('total_time', float),
                                ('target', CompilationTarget),
                                ('dependencies', List[str])])


# Generated at 2022-06-23 23:39:42.714507
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # pylint: disable=W0613, R0914
    tree = ast.parse('a = 1')
    dependencies = ['a.py']
    _ = TransformationResult(tree, True, dependencies)
    _ = TransformationResult(tree, False, dependencies)
    tree_changed = False
    _ = TransformationResult(tree, tree_changed, dependencies)
    _ = TransformationResult(tree, False, dependencies)

# Generated at 2022-06-23 23:39:43.598307
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    _ = TransformationResult(tree=None, tree_changed=True, dependencies=None)

# Generated at 2022-06-23 23:39:46.944674
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """Unit test for constructor of class InputOutput."""
    input_ = "input.py"
    output = "output.py"
    in_out = InputOutput(input=input_, output=output)



# Generated at 2022-06-23 23:39:51.320215
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inputOutput = InputOutput(
        input=Path('input.py'),
        output=Path('output.py'),
    )

    assert inputOutput.input.name == 'input.py'
    assert inputOutput.output.name == 'output.py'


# Generated at 2022-06-23 23:39:54.722647
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('path/to/input')
    output = Path('path/to/output')

    t = InputOutput(input, output)

    assert t.input == input
    assert t.output == output


# Generated at 2022-06-23 23:40:02.606393
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Type check
    assert len(InputOutput.__annotations__) == 2
    for attr in ['input', 'output']:
        assert InputOutput.__annotations__[attr] == Path
    # Should accept Path instances
    assert InputOutput(input=Path('a'),
                       output=Path('b')).input == Path('a')
    # Should accept strings
    assert InputOutput(input='a',
                       output='b').output == Path('b')
    # Should be immutable
    with pytest.raises(AttributeError):
        InputOutput(input='a',
                    output='b').input = 'b'

# Generated at 2022-06-23 23:40:04.808434
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.AST(), True, ['a', 'b', 'c'])

__all__ = ['TransformationResult',
           'CompilationResult',
           'InputOutput',
           'CompilationTarget']

# Generated at 2022-06-23 23:40:12.072242
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1,
                           time=0.1,
                           target=(3, 5),
                           dependencies=["sys", "os"])
    assert isinstance(cr, tuple)
    assert isinstance(cr, CompilationResult)
    assert cr.files == 1
    assert cr.time == 0.1
    assert cr.target == (3, 5)
    assert cr.dependencies == ["sys", "os"]


# Generated at 2022-06-23 23:40:16.988770
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path.cwd() / 'dir1' / 'dir2' / 'dir3'
    input_.mkdir(mode=0o755, parents=True)
    output_ = Path.cwd() / 'dir2'
    IO = InputOutput(input_, output_)
    assert IO.input == input_
    assert IO.output == output_


# Generated at 2022-06-23 23:40:18.286527
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(tree=None,
                         tree_changed=False,
                         dependencies=None)

# Generated at 2022-06-23 23:40:22.117663
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path0 = '/tmp/path0'
    path1 = '/tmp/path1'
    input_output = InputOutput(Path(path0), Path(path1))
    assert input_output.input == Path(path0)
    assert input_output.output == Path(path1)
    assert input_output == InputOutput(Path(path0), Path(path1))


# Generated at 2022-06-23 23:40:25.809354
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(2, 3.5, (3, 5), "")
    assert result.files == 2
    assert result.time == 3.5
    assert result.target == (3, 5)
    assert result.dependencies == ""


# Generated at 2022-06-23 23:40:28.220885
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=3, time=0.0, target=(3, 5),
                      dependencies=['A', 'B'])


# Generated at 2022-06-23 23:40:32.101562
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = InputOutput(input=Path("ab/cd/ef.py"),
                    output=Path("ab/cd/ef.py"))
    assert a.input == Path("ab/cd/ef.py")
    assert a.output == Path("ab/cd/ef.py")


# Generated at 2022-06-23 23:40:35.940736
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(1, 1.0, (3, 5), ['a', 'b'])
    assert res.files == 1
    assert res.time == 1.0
    assert res.target == (3, 5)
    assert res.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:40:37.733286
# Unit test for constructor of class CompilationResult
def test_CompilationResult():  # type: () -> None
    CompilationResult(files=1,
                      time=1.1,
                      target=(2, 3),
                      dependencies=[])

# Generated at 2022-06-23 23:40:38.989213
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('print(a)')
    tr = TransformationResult(tree, True, ['a'])

# Generated at 2022-06-23 23:40:46.551590
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result_of_compilation = CompilationResult(files=2,
                                              time=5.6,
                                              target=(3, 5),
                                              dependencies=['file0',
                                                            'file1'])
    assert result_of_compilation.files == 2
    assert result_of_compilation.time == 5.6
    assert result_of_compilation.target == (3, 5)
    assert result_of_compilation.dependencies == ['file0', 'file1']


# Generated at 2022-06-23 23:40:53.181464
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Given
    root = Path('root')
    input_ = Path('input.py')
    output = Path('output.py')

    # When
    input_output = InputOutput(input_, output)

    # Then
    assert input_output.input == input_
    assert input_output.output == output
    assert len(input_output) == 2
    assert isinstance(input_output, tuple)
    assert isinstance(input_output, NamedTuple)

# Generated at 2022-06-23 23:40:56.751503
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.Expr(value=ast.Num(n=1))
    result = TransformationResult(tree, True, ["some_dependency"])
    assert result.tree_changed
    assert result.dependencies == ["some_dependency"]

# Generated at 2022-06-23 23:40:59.916285
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(tree=None, tree_changed=None, dependencies=None)
    assert t.tree is None
    assert t.tree_changed is None
    assert t.dependencies is None


# Convert a path to a string

# Generated at 2022-06-23 23:41:02.808341
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('')
    tr = TransformationResult(tree, True, [])
    assert tr.tree == tree
    assert tr.tree_changed
    assert tr.dependencies == []

# Generated at 2022-06-23 23:41:08.790121
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    import astor
    new_tree = ast.parse('print("test")')
    res = TransformationResult(
        tree=new_tree,
        tree_changed=True,
        dependencies=['foo', 'bar']
    )
    assert astor.to_source(new_tree) == res.tree
    assert res.tree_changed
    assert res.dependencies == ['foo', 'bar']

# Generated at 2022-06-23 23:41:13.772299
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    import datetime

    result = CompilationResult(1, datetime.timedelta(0), (3, 6),
                               ["my_file.py"])
    assert isinstance(result, CompilationResult)
    assert result.files == 1
    assert result.time == datetime.timedelta(0)
    assert result.target == (3, 6)
    assert result.dependencies == ["my_file.py"]



# Generated at 2022-06-23 23:41:18.365713
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree_changed = True
    dependencies = ['./dep1', './dep2']
    tree = ast.parse(dedent("""\
        x = 1
        y = x
        """), '<unknown>', 'exec')
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies


# Generated at 2022-06-23 23:41:20.951098
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p = Path('input')
    q = Path('output')
    pair = InputOutput(p, q)
    assert pair.input == p
    assert pair.output == q


# Generated at 2022-06-23 23:41:24.406403
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=1, time=123.4, target=(3, 4),
                          dependencies=['foo', 'bar'])
    assert c.files == 1
    assert c.time == 123.4
    assert c.target == (3, 4)
    assert c.dependencies == ['foo', 'bar']


# Generated at 2022-06-23 23:41:26.419751
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.Expr(value=ast.NameConstant(value=None))
    TransformationResult(tree=t,
                         tree_changed=False,
                         dependencies=[])

# Generated at 2022-06-23 23:41:31.200891
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=0.123456,
                           target=(3, 6), dependencies=['foo.pyi'])
    assert cr.files == 1
    assert cr.time == 0.123456
    assert cr.target == (3, 6)
    assert cr.dependencies == ['foo.pyi']


# Generated at 2022-06-23 23:41:36.970199
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=42, time=3.14, target=(3, 6), dependencies=['foo', 'bar'])
    assert cr.files == 42
    assert cr.time == 3.14
    assert cr.target[0] == 3
    assert cr.target[1] == 6
    assert cr.dependencies[0] == 'foo'
    assert cr.dependencies[1] == 'bar'

# Generated at 2022-06-23 23:41:43.308051
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """Test the constructor of class InputOutput.
    """
    input_path = Path('input')
    output_path = Path('output')
    input_output_pair = InputOutput(input=input_path,
                                    output=output_path)
    assert input_output_pair.input == input_path
    assert input_output_pair.output == output_path


# Generated at 2022-06-23 23:41:48.343785
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('/home/foo/source.py')
    output_path = Path('/home/foo/target.py')
    io = InputOutput(input_path, output_path)
    assert io.input == input_path
    assert io.output == output_path


# Generated at 2022-06-23 23:41:49.623068
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # The arguments have the correct types
    TransformationResult(ast.parse(""), True, [])

# Generated at 2022-06-23 23:41:50.632338
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result = TransformationResult(
        tree=ast.parse('a = 2'),
        tree_changed=False,
        dependencies=['a.py'])


# Generated at 2022-06-23 23:41:53.776239
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_1 = InputOutput(Path("n"), Path("m"))
    assert input_output_1.input == Path("n")
    assert input_output_1.output == Path("m")

# Generated at 2022-06-23 23:42:01.590881
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.AST(),
                              False,
                              [])
    assert(isinstance(tr.tree, ast.AST))
    assert(tr.tree_changed is False)
    assert(isinstance(tr.dependencies, list))

# Result of analyzer analysis
AnalysisResult = NamedTuple('AnalysisResult',
                            [('preamble', str),
                             ('classes', List[ast.AST]),
                             ('dependencies', List[str])])

# Result of translation
TranslationResult = NamedTuple('TranslationResult',
                               [('input', Path),
                                ('output', Path),
                                ('dependencies', List[str])])

# Result of generator_interface.generate_code

# Generated at 2022-06-23 23:42:04.511428
# Unit test for constructor of class InputOutput
def test_InputOutput():
    d = Path('.')
    input = d / 'input'
    output = d / 'output'
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output