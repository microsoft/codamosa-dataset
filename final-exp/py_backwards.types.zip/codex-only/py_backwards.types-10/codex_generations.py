

# Generated at 2022-06-23 23:32:00.925357
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/test.py')
    output = Path('/tmp/test.c')
    iopair = InputOutput(input, output)
    assert iopair.input == input
    assert iopair.output == output

# Generated at 2022-06-23 23:32:06.009230
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path("A"), Path("B")) == \
           InputOutput(Path("A"), Path("B"))
    assert InputOutput(Path("A"), Path("B")) != \
           InputOutput(Path("A"), Path("C"))
    assert InputOutput(Path("A"), Path("B")) != \
           InputOutput(Path("C"), Path("B"))
    assert InputOutput(Path("A"), Path("B")) != \
           InputOutput(Path("C"), Path("D"))


# Generated at 2022-06-23 23:32:08.211819
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('a.py')
    output = Path('b.py')
    t = InputOutput(input=input, output=output)
    assert t.input == input
    assert t.output == output

# Generated at 2022-06-23 23:32:09.510951
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = InputOutput('a', 'b')
    assert i.input == 'a'
    assert i.output == 'b'


# Generated at 2022-06-23 23:32:12.853262
# Unit test for constructor of class InputOutput
def test_InputOutput():
    for path in ['foo', '/bar', 'baz/qux']:
        i = InputOutput(input = path, output = path)
        assert i.input == path
        assert i.output == path

# Generated at 2022-06-23 23:32:17.729028
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # pylint: disable=missing-docstring
    TransformationResult(ast.AST(), False, [])
    TransformationResult(ast.AST(), True, [])
    TransformationResult(ast.AST(), True, ['a'])
    TransformationResult(ast.AST(), True, ['a', 'b'])
    TransformationResult(ast.AST(), True, ['a', 'b', 'c'])

# Generated at 2022-06-23 23:32:20.122366
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(
        files=1,
        time=0.0,
        target=(2, 7),
        dependencies=[]
    )


# Generated at 2022-06-23 23:32:21.931562
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(15, 0.6, (3, 6), ["a.py", "b.py"])


# Generated at 2022-06-23 23:32:24.912182
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(1, 2, (3, 5), ['a'])
    assert c.files == 1
    assert c.time == 2
    assert c.target == (3, 5)
    assert c.dependencies == ['a']


# Generated at 2022-06-23 23:32:29.543526
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_node = ast.parse('pass')
    trans_result = TransformationResult(ast_node, True, [])
    assert trans_result.tree == ast_node
    assert trans_result.tree_changed == True
    assert trans_result.dependencies == []


# Generated at 2022-06-23 23:32:33.632819
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('input.py')
    output = Path('output.pyc')
    pair = InputOutput(input_, output)
    assert pair.input == input_
    assert pair.output == output
    assert pair == InputOutput('input.py', 'output.pyc')


# Generated at 2022-06-23 23:32:36.515836
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input.py')
    output = Path('/tmp/output.py')
    test = InputOutput(input, output)
    assert input == test.input
    assert output == test.output

# Generated at 2022-06-23 23:32:40.137373
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(
        files=0,
        time=0.0,
        target=(3, 7),
        dependencies=[]
    )
    assert compilation_result.files == 0
    assert compilation_result.time == 0.0
    assert compilation_result.target == (3, 7)
    assert compilation_result.dependencies == []


# Generated at 2022-06-23 23:32:42.031152
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=1, time=1.0, target=(3, 7), dependencies=[])


# Generated at 2022-06-23 23:32:43.875296
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert isinstance(InputOutput(Path('a.py'), Path('b.py')), InputOutput)

# Generated at 2022-06-23 23:32:49.492293
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, False, None)
    assert TransformationResult(None, False, [])
    assert TransformationResult(None, False, ['foo'])
    assert TransformationResult(None, True, [])
    assert TransformationResult(None, True, ['foo'])
    assert TransformationResult(None, True, None)
    assert TransformationResult(ast.parse('x = 2'), False, ['foo'])
    assert TransformationResult(ast.parse('x = 2'), True, ['foo'])

# Generated at 2022-06-23 23:32:53.420933
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 10
    time = 0.1
    target = (3, 5)
    dependencies = ['one', 'two']
    res = CompilationResult(files, time, target, dependencies)
    assert res.files == files
    assert res.time == time
    assert res.target == target
    assert res.dependencies == dependencies


# Generated at 2022-06-23 23:32:55.506607
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    def call():  # type: () -> None
        TransformationResult(ast.Module(), True, ['path/to/file'])
    call()

# Generated at 2022-06-23 23:32:56.436674
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(0, 0, (3, 6), [])

# Generated at 2022-06-23 23:32:57.176284
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput('input', 'output')

# Generated at 2022-06-23 23:32:59.215769
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # pylint: disable=invalid-name
    CompilationResult(1, 1.0, (3, 0), ["path/to/module.py"])



# Generated at 2022-06-23 23:33:02.919438
# Unit test for constructor of class InputOutput
def test_InputOutput():
    file_1 = Path("/home/user/file.txt")
    file_2 = Path("/home/user/file2.txt")
    test = InputOutput(file_1, file_2)
    assert test.input == file_1
    assert test.output == file_2



# Generated at 2022-06-23 23:33:03.749138
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.parse("pass"), False, [])

# Generated at 2022-06-23 23:33:07.988066
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    info = CompilationResult(1, 1.2, (2, 3), ['a', 'b'])
    assert info.files == 1
    assert info.time == 1.2
    assert info.target == (2, 3)
    assert info.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:33:12.741419
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c_result = CompilationResult(files=1,
                                 time=0.1,
                                 target=(3, 6),
                                 dependencies=[])
    assert c_result.files == 1
    assert c_result.time == 0.1
    assert c_result.target == (3, 6)
    assert c_result.dependencies == []

# Generated at 2022-06-23 23:33:14.373337
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('foo'), Path('bar')) == InputOutput('foo', 'bar')

# Generated at 2022-06-23 23:33:15.913544
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=0, time=0.0, target=(6, 2), dependencies=[])


# Generated at 2022-06-23 23:33:20.755293
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    class Foo(ast.AST):
        pass
    res = TransformationResult(
        tree=Foo(),
        tree_changed=True,
        dependencies=['foo', 'bar'])
    assert res.tree_changed
    assert isinstance(res.tree, Foo) == True
    assert len(res.dependencies) == 2
    assert res.dependencies == ['foo', 'bar']

# Generated at 2022-06-23 23:33:25.584472
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(None, False, ['foo'])
    assert t.tree is None
    assert t.tree_changed is False
    assert t.dependencies == ['foo']
    assert t.dependencies[0] == 'foo'
    assert t.dependencies[0] == t.dependencies[-1]

# Generated at 2022-06-23 23:33:29.470843
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(files=1,
                          time=0.1,
                          target=(3, 6),
                          dependencies=["x"])
    assert r.files == 1
    assert r.time == 0.1
    assert r.target == (3, 6)
    assert r.dependencies == ["x"]


# Generated at 2022-06-23 23:33:32.808651
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('1')
    res = TransformationResult(tree, False, [])

    assert isinstance(res.tree, ast.AST)
    assert isinstance(res.tree_changed, bool)
    assert isinstance(res.dependencies, list)


# Generated at 2022-06-23 23:33:35.244013
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    trans = TransformationResult(tree, False, [])
    assert trans.tree == tree
    assert trans.tree_changed == False
    assert trans.dependencies == []

# Generated at 2022-06-23 23:33:37.114963
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input=Path('input'), output=Path('output'))


# Generated at 2022-06-23 23:33:43.613121
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """
    Unit test for constructor of class InputOuput.
    """
    assert InputOutput(input=Path('input'), output=Path('output')) == \
           InputOutput(input=Path('input'), output=Path('output'))
    assert InputOutput(input=Path('input'), output=Path('output')) != \
           InputOutput(input=Path('inp'), output=Path('output'))
    assert InputOutput(input=Path('input'), output=Path('output')) != \
           InputOutput(input=Path('input'), output=Path('out'))

# Generated at 2022-06-23 23:33:46.155046
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/input')
    output = Path('/output')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-23 23:33:49.407082
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Basic constructors
    i_o = InputOutput(input=Path('input'), output=Path('output'))
    assert i_o.input == Path('input') and i_o.output == Path('output')


# Generated at 2022-06-23 23:33:52.545028
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input0 = 'input0'
    output0 = 'output0'
    inputoutput = InputOutput(input0, output0)
    assert inputoutput.input == Path(input0)
    assert inputoutput.output == Path(output0)



# Generated at 2022-06-23 23:33:57.752386
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(
        files=1,
        time=2.0,
        target=(3, 4),
        dependencies=['file_1', 'file_2']
    )

    assert compilation_result.files == 1
    assert compilation_result.time == 2.0
    assert compilation_result.target == (3, 4)
    assert compilation_result.dependencies == ['file_1', 'file_2']


# Generated at 2022-06-23 23:34:01.323393
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("pass")
    result = TransformationResult(tree, True, ["path/to/dependency.py"])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == ["path/to/dependency.py"]

# Generated at 2022-06-23 23:34:02.197207
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(Path('/tmp'), Path('/home/'))


# Generated at 2022-06-23 23:34:05.159945
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert len(CompilationResult._fields) == 4
    assert CompilationResult._fields[0] == 'files'
    assert CompilationResult._fields[1] == 'time'
    assert CompilationResult._fields[2] == 'target'
    assert CompilationResult._fields[3] == 'dependencies'


# Generated at 2022-06-23 23:34:11.835955
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Type checks
    CompilationResult(files=1, time=0.1, target=(3, 8), dependencies=["abc"])
    
    # And some sanity checks
    with pytest.raises(TypeError):
        CompilationResult(files="a", time=0.1, target=(3, 8), dependencies=["abc"])
    with pytest.raises(TypeError):
        CompilationResult(files=1, time="b", target=(3, 8), dependencies=["abc"])
    with pytest.raises(TypeError):
        CompilationResult(files=1, time=0.1, target=3, dependencies=["abc"])
    with pytest.raises(TypeError):
        CompilationResult(files=1, time=0.1, target=(3, 8), dependencies=["abc", 4])


# Generated at 2022-06-23 23:34:14.683319
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.0, target=(3, 5), dependencies=['a'])
    assert result.files == 1
    assert result.time == 0.0
    assert result.target == (3, 5)
    assert result.dependencies == ['a']


# Generated at 2022-06-23 23:34:16.910098
# Unit test for constructor of class InputOutput
def test_InputOutput():
    f = Path('a')
    g = Path('b')
    assert InputOutput(f, g).input == f
    assert InputOutput(f, g).output == g

# Generated at 2022-06-23 23:34:19.649028
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(0, 0, (0, 0), [])
    assert result.files == 0
    assert result.time == 0



# Generated at 2022-06-23 23:34:24.161680
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_node = ast.parse('42')
    transformation = TransformationResult(tree=ast_node,
                                          tree_changed=True,
                                          dependencies=[])
    assert transformation.tree == ast_node
    assert transformation.tree_changed == True
    assert transformation.dependencies == []

# Generated at 2022-06-23 23:34:26.626936
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # pylint: disable=unused-variable
    tree = ast.parse('pass')
    tree_changed = True
    dependencies = []
    result = TransformationResult(tree, tree_changed, dependencies)

# Generated at 2022-06-23 23:34:37.182127
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    string = "TransformationResult(tree=[], tree_changed=True, dependencies=['hello'])"
    assert str(TransformationResult(ast.AST(), True, ['hello'])) == string


# Annotation for transformer function
Transformer = Callable[[ast.AST, List[str]], TransformationResult]

# Annotation for context of transformer
TransformerContext = NamedTuple('TransformerContext',
                                [('file', Path),
                                 ('inputs_outputs', List[InputOutput]),
                                 ('transformer_functions', List[Transformer]),
                                 ('target', CompilationTarget),
                                 ('input_dependencies', List[str]),
                                 ('output_dependencies', List[str])])



# Generated at 2022-06-23 23:34:42.500909
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(
        ast.parse('1 + 1'),
        True,
        ['import datetime',
         'from typing import NamedTuple']).tree_changed == True
    assert TransformationResult(
        ast.parse('1 + 1'),
        True,
        ['import datetime',
         'from typing import NamedTuple']).dependencies == \
        ['import datetime',
         'from typing import NamedTuple']

# Generated at 2022-06-23 23:34:45.130018
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(ast.Module(), False, ['d1', 'd2'])
    assert not result.tree_changed
    assert len(result.dependencies) == 2

# Generated at 2022-06-23 23:34:54.580337
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # no changes
    tree = ast.parse('a=2')
    tr = TransformationResult(tree, False, [])
    assert tr[0] == tree
    assert tr[1] == False
    assert tr[2] == []
    assert tr == (tree, False, [])

    # one change
    tr = TransformationResult(tree, True, [])
    assert tr[0] == tree
    assert tr[1] == True
    assert tr[2] == []
    assert tr == (tree, True, [])

    # dependency
    tr = TransformationResult(tree, False, ['foo'])
    assert tr[0] == tree
    assert tr[1] == False
    assert tr[2] == ['foo']
    assert tr == (tree, False, ['foo'])

    # all

# Generated at 2022-06-23 23:34:58.696263
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path_a = Path(__file__)
    path_b = Path(__file__)

    pair = InputOutput(path_a, path_b)

    assert pair.input == path_a
    assert pair.output == path_b


# Generated at 2022-06-23 23:35:01.945604
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('input.py'), Path('output.py')).\
        input == Path('input.py')
    assert InputOutput(Path('input.py'), Path('output.py')).\
        output == Path('output.py')

# Generated at 2022-06-23 23:35:04.874678
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_tree = ast.parse("assert 1+2 == 3")
    tr = TransformationResult(ast_tree, True, [])
    assert tr.tree_changed is True
    assert len(tr.dependencies) == 0

# Generated at 2022-06-23 23:35:09.413718
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    t = CompilationResult(files=1,
                          time=1.1,
                          target=(2, 3),
                          dependencies=['d1', 'd2'])
    assert t.files == 1
    assert t.time == 1.1
    assert t.target == (2, 3)
    assert t.dependencies == ['d1', 'd2']

# Generated at 2022-06-23 23:35:12.562074
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('a = 5')
    r = TransformationResult(tree=t, tree_changed=True, dependencies=['foo'])
    assert t == r.tree
    assert r.tree_changed
    assert ['foo'] == r.dependencies



# Generated at 2022-06-23 23:35:15.758242
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=0, time=0, target=(3, 5), dependencies=[])
    assert cr.files == 0
    assert cr.time == 0
    assert cr.target == (3, 5)
    assert not cr.dependencies


# Generated at 2022-06-23 23:35:20.195508
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(input=Path('input.py'),
                               output=Path('output.py'))
    assert input_output.input.name == 'input.py'
    assert input_output.output.name == 'output.py'


# Generated at 2022-06-23 23:35:22.464710
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1,
                      time=2.0,
                      target=(3, 4),
                      dependencies=['a', 'b'])

# Generated at 2022-06-23 23:35:27.792087
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=20, time=0.5,
                               target=(3, 6),
                               dependencies=['foo.py', 'bar.py'])
    assert result.files == 20
    assert result.time == 0.5
    assert result.target == (3, 6)
    assert result.dependencies == ['foo.py', 'bar.py']


# Generated at 2022-06-23 23:35:29.365102
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('a')
    o = Path('b')
    io = InputOutput(i, o)
    assert io.input == i
    assert io.output == o


# Generated at 2022-06-23 23:35:33.119617
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=123, time=0.5, target=(2, 7),
                            dependencies=['foo', 'bar'])
    assert res.files == 123
    assert res.time == 0.5
    assert res.target == (2, 7)
    assert res.dependencies == ['foo', 'bar']


# Generated at 2022-06-23 23:35:35.723741
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    io = InputOutput(input=input, output=output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-23 23:35:38.271620
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    transformation_result = TransformationResult(ast.parse('a = 1'), True, ['b'])
    assert transformation_result.tree_changed is True
    assert type(transformation_result.tree) == ast.Module
    assert transformation_result.tree.body[0].value.n == 1
    assert transformation_result.dependencies == ['b']

# Generated at 2022-06-23 23:35:46.691141
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Given
    input = Path.home() / "foo" / "bar"
    output = Path.home() / "foo" / "baz"

    # When
    io = InputOutput(input, output)

    # Then
    assert io.input == input
    assert io.output == output
    assert io.input != io.output
    assert io.input != io.output.with_name('bar')
    assert io.input == io.output.with_name('bar').with_name('bar')
    assert io.input != io.output.with_name('bar').with_name('baz')

# Generated at 2022-06-23 23:35:53.758859
# Unit test for constructor of class InputOutput
def test_InputOutput():
    import sys
    from pathlib2 import Path
    from tempfile import NamedTemporaryFile

    io = InputOutput(input=Path('a'), output=Path('b'))
    with NamedTemporaryFile() as f:
        f.write(b"")
        f.flush()
        io2 = InputOutput(input=f.name, output=f.name)
        assert io2.input == io2.output
        if sys.version_info < (3,):
            assert io2.input != io2.output.name


# Generated at 2022-06-23 23:35:55.363921
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_file = Path('__main__.py')
    output_file = Path('__main__.py.c')
    pair = InputOutput(input_file, output_file)

    assert pair.input == input_file
    assert pair.output == output_file

# Generated at 2022-06-23 23:35:56.472955
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 1.3, (3, 0), [])


# Generated at 2022-06-23 23:35:57.880253
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert isinstance(InputOutput(Path('a'), Path('b')), InputOutput)


# Generated at 2022-06-23 23:36:02.478880
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('print(1)')
    tr = TransformationResult(tree, True, [])
    assert isinstance(tr.tree, ast.AST)
    assert tr.tree_changed is True
    assert isinstance(tr.dependencies, list)

# Executables transformations
ExeTransformResult = NamedTuple('ExeTransformResult',
                                [('result', List[InputOutput]),
                                 ('dependencies', List[str])])

# Target directory
TargetDirectory = NamedTuple('TargetDirectory', [('path', Path),
                                                 ('recursive', bool)])

# Generated at 2022-06-23 23:36:08.264241
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass', filename='<foo>')
    res = TransformationResult(tree, True, ['foo'])
    assert res.tree == tree
    assert res.tree_changed
    assert res.dependencies == ['foo']


# Result of source code transformation
CodeResult = NamedTuple('CodeResult',
                        [('source', str),
                         ('dependencies', List[str])])

# Generated at 2022-06-23 23:36:13.611919
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files_count = 100
    time = 1.23
    target = (2, 7)
    deps = ['a.py', 'b.py']
    res = CompilationResult(files_count, time, target, deps)
    assert res.files == files_count
    assert res.time == time
    assert res.target == target
    assert res.dependencies == deps


# Generated at 2022-06-23 23:36:18.152598
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1, time=1.0,
                                           target=(3, 6), dependencies=[])
    assert compilation_result.files == 1
    assert compilation_result.time == 1.0
    assert compilation_result.target == (3, 6)
    assert compilation_result.dependencies == []


# Generated at 2022-06-23 23:36:24.608890
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path(__file__)
    output_path = Path(__file__ + '.out')
    input_output = InputOutput(input_path, output_path)

    assert input_output.input == input_path
    assert input_output.output == output_path
    assert str(input_output) == "InputOutput(input=PosixPath('%s'), output=PosixPath('%s.out'))" % (__file__, __file__)


# Generated at 2022-06-23 23:36:29.115859
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('/home/tmp/input.py')
    output_path = Path('/home/tmp/output.py')
    input_output_pair = InputOutput(input_path, output_path)
    assert input_output_pair.input == input_path
    assert input_output_pair.output == output_path

# Generated at 2022-06-23 23:36:36.948003
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=10, time=10.0, target=(3, 5), dependencies=["a.py"])
    assert res.files == 10
    assert res.time == 10.0
    assert res.target == (3, 5)
    assert res.dependencies == ["a.py"]
    assert res[0] == 10
    assert res[1] == 10.0
    assert res[2] == (3, 5)
    assert res[3] == ["a.py"]


# Generated at 2022-06-23 23:36:39.660014
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.parse('x = 3'), True, ['a', 'b'])
    TransformationResult(ast.parse('x = 3'), False, [])
    return

# Generated at 2022-06-23 23:36:42.798122
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """Input/Output is correctly initialized and accessed."""
    input_ = Path("input.py")
    output = Path("output.py")
    io = InputOutput(input_, output)
    assert io.input is input_
    assert io.output is output


# Generated at 2022-06-23 23:36:45.684704
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = InputOutput(input=Path('a'), output=Path('b'))
    assert i.input == Path('a')
    assert i.output == Path('b')

# Generated at 2022-06-23 23:36:48.767011
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult._make((1, 2, (3, 4), ['a', 'b'])) == \
        CompilationResult(1, 2, (3, 4), ['a', 'b'])


# Generated at 2022-06-23 23:36:49.726415
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 1.0, (3, 5), ['a', 'b'])


# Generated at 2022-06-23 23:36:52.962018
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_input = Path('/tmp/in')
    test_output = Path('/tmp/out')
    test_case = InputOutput(input=test_input, output=test_output)
    check_input = test_case.input
    check_output = test_case.output
    assert check_input == test_input
    assert check_output == test_output


# Generated at 2022-06-23 23:36:57.934317
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # pylint: disable=too-few-public-methods
    class CompilationResult(NamedTuple('CompilationResult', [('files', int),
                                                              ('time', float),
                                                              ('target', CompilationTarget),
                                                              ('dependencies', List[str])])):
        pass

    # pylint: enable=too-few-public-methods
    CompilationResult(2, 3.0, (3, 4), ['dependency'])


# Generated at 2022-06-23 23:37:01.265166
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('a = 5')
    tr = TransformationResult(t, True, [])
    assert tr.tree == t
    assert tr.tree_changed == True
    assert tr.dependencies == []

# Generated at 2022-06-23 23:37:05.765087
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_file = Path('/tmp/my_input_file.txt')
    output_file = Path('/tmp/my_output_file.txt')
    input_output = InputOutput(input_file, output_file)
    assert input_file == input_output.input
    assert output_file == input_output.output

# Generated at 2022-06-23 23:37:14.489907
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from typed_ast import ast3 as ast
    tr = TransformationResult(ast.parse('1+2'), True, ['f1.py'])
    assert tr.tree.body[0].value.left.n == 1
    assert tr.tree_changed == True
    assert len(tr.dependencies) == 1
    assert tr.dependencies[0] == 'f1.py'

# Types of entity in a python source file
PythonEntityType = str

# The next constant can be used as an element of PythonEntityType.
METHOD_TYPE = 'METHOD'
CLASS_TYPE = 'CLASS'
FUNCTION_TYPE = 'FUNCTION'

# A single entity in a python source file

# Generated at 2022-06-23 23:37:16.922407
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('x')
    output = Path('y')
    inout = InputOutput(input_, output)
    assert inout.input == input_
    assert inout.output == output


# Generated at 2022-06-23 23:37:22.782320
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=5, time=0.5,
                               target=(3, 7),
                               dependencies=['a', 'b'])
    assert result.files == 5
    assert result.time == 0.5
    assert result.target == (3, 7)
    assert result.dependencies == ['a', 'b']



# Generated at 2022-06-23 23:37:24.584214
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 5.3, (3, 5), ['foo', 'bar'])



# Generated at 2022-06-23 23:37:28.449957
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.Module([])
    tree_changed = True
    dependencies = []
    TransformationResult(tree, tree_changed, dependencies)

__all__ = []
__all__.append('CompilationResult')
__all__.append('InputOutput')
__all__.append('TransformationResult')

# Generated at 2022-06-23 23:37:32.335005
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('input.py')
    output_path = Path('output.py')
    input_output = InputOutput(input=input_path, output=output_path)
    # Test __repr__
    assert str(input_output) == 'InputOutput(input=PosixPath(\'input.py\'), ' \
        'output=PosixPath(\'output.py\'))'


# Generated at 2022-06-23 23:37:36.037468
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('1 + 1', mode='eval')
    result = TransformationResult(tree, False, ['a.py'])
    assert result.tree == tree
    assert result.tree_changed == False
    assert result.dependencies == ['a.py']

# Generated at 2022-06-23 23:37:41.501525
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # given
    tree_changed = True

    # and
    tree = ast.parse('abc = 1')

    # and
    dependencies = ['foo', 'bar']

    # when
    transformation = TransformationResult(tree, tree_changed, dependencies)

    # then
    assert transformation.tree is tree
    assert transformation.tree_changed is tree_changed
    assert transformation.dependencies == dependencies

# Generated at 2022-06-23 23:37:45.147329
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(1, 0.1, (3, 7), [])
    assert(c.files == 1)
    assert(c.time == 0.1)
    assert(c.target == (3, 7))
    assert(c.dependencies == [])


# Generated at 2022-06-23 23:37:46.353991
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("x = 1")
    assert TransformationResult(tree=tree,
                                tree_changed=True,
                                dependencies=['foo'])

# Generated at 2022-06-23 23:37:48.656793
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(0, 0, (0, 0))
    assert cr.files == 0
    assert cr.time == 0
    assert cr.target == (0, 0)



# Generated at 2022-06-23 23:37:50.516096
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    r = TransformationResult(ast.AST(), True, [])
    assert r.tree_changed
    assert r.dependencies == []
    assert r.tree is not None

# Generated at 2022-06-23 23:37:55.108892
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=0, time=0.0, target=(3, 8),
                               dependencies=['test1', 'test2'])
    result.files = 42
    result.time = 23
    result.target = (3, 6)
    result.dependencies = ['test3', 'test4']


# Generated at 2022-06-23 23:37:59.106425
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.decompose_statement('pass'),
                                False,
                                []).tree_changed == False
    assert TransformationResult(ast.decompose_statement('pass'),
                                False,
                                []).dependencies == []

# Generated at 2022-06-23 23:38:02.649504
# Unit test for constructor of class InputOutput
def test_InputOutput():
    in_out = InputOutput(input=Path(__file__), output=Path(__file__))
    assert in_out.input == Path(__file__) and in_out.output == Path(__file__)

# Generated at 2022-06-23 23:38:06.763565
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    tree_changed = True
    dependencies = ['a', 'b']
    res = TransformationResult(tree, tree_changed, dependencies)
    assert(res.tree == tree and
           res.tree_changed == tree_changed and
           res.dependencies == dependencies)

# Generated at 2022-06-23 23:38:10.189922
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp')
    output = Path('/tmp2')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-23 23:38:12.661027
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    x = TransformationResult(ast.parse('pass').body[0], False, ['a.py'])
    assert not x.tree_changed
    assert x.dependencies == ['a.py']

# Generated at 2022-06-23 23:38:16.722075
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    astree = ast.parse('')
    dependencies = list(range(0, 10))
    tree_changed = True

    result = TransformationResult(astree, tree_changed, dependencies)

    assert result.tree == astree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-23 23:38:23.250161
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Arrange
    files = 1
    time = 0.123
    target = CompilationTarget(3,6)
    dependencies = ['asd', 'qwe']
    # Act
    result = CompilationResult(
        files,
        time,
        target,
        dependencies
    )
    # Assert
    assert result.files == files
    assert result.time == time
    assert result.target == target
    assert result.dependencies == dependencies



# Generated at 2022-06-23 23:38:27.322558
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/home/user/src/python/module.py')
    output = Path('/home/user/bin/module.py')
    input_output = InputOutput(input, output)

    assert input_output.input == input
    assert input_output.output == output

# Generated at 2022-06-23 23:38:31.021447
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(0, 0, (3, 6), [])
    assert compilation_result.files == 0
    assert compilation_result.time == 0
    assert compilation_result.target == (3, 6)
    assert compilation_result.dependencies == []



# Generated at 2022-06-23 23:38:33.444618
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(0, 0, (3, 7), ['hello.py'])
    assert CompilationResult(files=3, time=0.0, target=(3, 5), dependencies=[])


# Generated at 2022-06-23 23:38:35.718295
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('test_input')
    output = Path('test_output')
    pair = InputOutput(input, output)
    assert pair.input == input
    assert pair.output == output



# Generated at 2022-06-23 23:38:38.342415
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('in')
    out = Path('out')

    assert InputOutput(input=inp, output=out).input == inp
    assert InputOutput(input=inp, output=out).output == out


# Generated at 2022-06-23 23:38:43.678487
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=1,
                          time=1.0,
                          target=(3, 7),
                          dependencies=['stdlib'])
    assert c.files == 1
    assert c.time == 1.0
    assert c.target == (3, 7)
    assert c.dependencies == ['stdlib']


# Generated at 2022-06-23 23:38:47.740992
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=None, tree_changed=False,
                              dependencies=['a', 'b'])
    assert tr.tree is None
    assert tr.tree_changed is False
    assert tr.dependencies == ['a', 'b']

# Generated at 2022-06-23 23:38:50.272365
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = 'input'
    output = 'output'

    result = InputOutput(input_, output)
    assert result.input == input_
    assert result.output == output

# Generated at 2022-06-23 23:38:54.168701
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cmp = CompilationResult(files=1,
                            time=0.1,
                            target=(3, 8),
                            dependencies=[])
    assert cmp.files == 1
    assert cmp.time == 0.1
    assert cmp.target == (3, 8)
    assert cmp.dependencies == []


# Generated at 2022-06-23 23:38:56.347238
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilationResult = CompilationResult(files=1,
                                          time=1.0,
                                          target=(36, 0),
                                          dependencies=['a', 'b'])

    assert compilationResult.files == 1
    assert compilationResult.time == 1.0
    assert compilationResult.target == (36, 0)
    assert compilationResult.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:39:00.031478
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x=1')
    a = TransformationResult(tree, True, [])
    assert a.tree == tree
    assert a.tree_changed
    assert a.dependencies == []


# Result of transformations
TransformationChain = NamedTuple('TransformationChain',
                                 [('tree', ast.AST),
                                  ('tree_changed', bool),
                                  ('dependencies', List[str])])


# Generated at 2022-06-23 23:39:04.598120
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    comp_res = CompilationResult(10, 99.9, (2, 7), [])
    assert comp_res.files == 10
    assert comp_res.time == 99.9
    assert comp_res.target == (2, 7)
    assert comp_res.dependencies == []



# Generated at 2022-06-23 23:39:09.371293
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(1, 2.0, (3, 4), ["a", "b"])
    assert res.files == 1
    assert res.time == 2.0
    assert res.target == (3, 4)
    assert res.dependencies == ["a", "b"]



# Generated at 2022-06-23 23:39:13.560258
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.Module()
    TransformationResult(t, False, [])

# Result of transformer of code in one file
FileTransformationResult = NamedTuple('FileTransformationResult',
                                      [('changed', bool),
                                       ('dependencies', List[str])])


# Generated at 2022-06-23 23:39:17.908086
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Constructor
    tree = ast.parse('')
    tree_changed = True
    dependencies = []
    # transformers = transformer.TransformationResult(tree, tree_changed, dependencies)
    # Test attributes
    assert tree is tree
    assert tree_changed is True
    assert dependencies is dependencies

# Generated at 2022-06-23 23:39:24.630830
# Unit test for constructor of class InputOutput
def test_InputOutput():
    directory = Path('/tmp/leodir')
    infile = Path('infile.py')
    outfile = Path('outfile.py')

    # Input must be a path
    with pytest.raises(ValueError):
        InputOutput('infile.py', outfile)

    # Output must be a path
    with pytest.raises(ValueError):
        InputOutput(infile, 'outfile.py')

    # Constructor must accept arguments as strings
    InputOutput('infile.py', 'outfile.py')

    # Constructor must accept arguments as paths
    InputOutput(infile, outfile)

    # Raises error if only input path is passed
    with pytest.raises(TypeError):
        InputOutput(infile)

    # Raises error if only output path is passed

# Generated at 2022-06-23 23:39:35.746842
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('def f():\n  return 1+2*3')
    result = TransformationResult(tree, True, ['math'])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == ['math']

# Path to source code directory
Code = Path

# Path to executable
Executable = Path

# Path to test suite
TestSuite = Path

# Path to temporary directory
Temporary = Path

# Path to directory with executables
Executables = Path

# Path to directory with test suites
TestSuites = Path

# Path to directory with temporary directories
TempDir = Path

# Compilation target version
CompilationTarget = Tuple[int, int]

# Test executable
TestExe = Path

# Test suite
TestSuite = Path



# Generated at 2022-06-23 23:39:37.800947
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=0, time=0.0, target=(3, 6), dependencies=[])

# Generated at 2022-06-23 23:39:40.502052
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # test
    tr = TransformationResult(ast.parse(''), True, [])
    assert tr.tree
    assert tr.tree_changed
    assert tr.dependencies

# Generated at 2022-06-23 23:39:44.059458
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('project', '__init__.py')
    output = Path('project', '__init__.pypy')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output

# Test for constructor of class CompilationResult

# Generated at 2022-06-23 23:39:47.071910
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    null_tree = None
    tr = TransformationResult(null_tree, False, [])
    assert tr.tree is null_tree
    assert tr.tree_changed == False
    assert tr.dependencies == []

# Generated at 2022-06-23 23:39:55.941713
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('test.py')
    out = Path('test.pyc')

    # Test IO constructor
    assert InputOutput(inp, out) == InputOutput('test.py', 'test.pyc')

    # Test IO constructor with invalid type for input argument
    with pytest.raises(TypeError):
        InputOutput(1, out)

    # Test IO constructor with invalid type for output argument
    with pytest.raises(TypeError):
        InputOutput(inp, 1)

    # Test IO constructor with invalid type for both arguments
    with pytest.raises(TypeError):
        InputOutput(inp, 1)



# Generated at 2022-06-23 23:39:59.237637
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path.cwd()
    output = Path('/path/to/pathlib2')

    iopair = InputOutput(input, output)

    assert iopair.input == input
    assert iopair.output == output

# Generated at 2022-06-23 23:40:03.011719
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=0.01, target=(2, 7), dependencies=[])
    assert cr.files == 1
    assert cr.time > 0
    assert cr.target == (2, 7)
    assert cr.dependencies == []


# Generated at 2022-06-23 23:40:05.487787
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.Module()
    r = TransformationResult(t, True, [])
    assert r.tree is t
    assert r.tree_changed is True
    assert r.dependencies == []

# Generated at 2022-06-23 23:40:14.196589
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Arrange
    assert TransformationResult
    tree = ast.parse('print("foo")')
    dependencies = ['bar']

    # Act
    result = TransformationResult(tree, False, dependencies)

    # Assert
    assert result.tree == tree
    assert not result.tree_changed
    assert result.dependencies == dependencies
    assert repr(result) == 'TransformationResult(tree=Module(body=[Expr(value=Call(func=Name(id=\'print\', ctx=Load()), args=[Str(s="foo")], keywords=[]))]), tree_changed=False, dependencies={\'bar\'})'

# Generated at 2022-06-23 23:40:15.142238
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(1, False, [])

# Generated at 2022-06-23 23:40:18.962548
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 1.2, (3, 5), ['file.py'])
    assert result.files == 1
    assert result.time == 1.2
    assert result.target == (3, 5)
    assert result.dependencies == ['file.py']


# Generated at 2022-06-23 23:40:21.066723
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Check if exception raise
    with pytest.raises(ValueError):
        InputOutput(input=Path("input.py"), output=Path("input.py"))


# Generated at 2022-06-23 23:40:25.993868
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('')
    tr = TransformationResult(tree, True, [])
    assert tr.tree is tree
    assert tr.tree_changed is True
    assert tr.dependencies == []

# Result of running unit tests
UnitTestResult = NamedTuple('UnitTestResult',
                            [('passed', bool),
                             ('output', str)])


# Generated at 2022-06-23 23:40:27.145673
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input')
    output = Path('/tmp/output')
    a = InputOutput(input, output)

    assert a.input == input
    assert a.output == output


# Generated at 2022-06-23 23:40:32.936924
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    input_files = 3
    input_time = 4.56
    input_target = (3, 8)
    input_dependencies = ['a', 'b']
    result = CompilationResult(input_files,
                               input_time,
                               input_target,
                               input_dependencies)
    assert result.files == input_files
    assert result.time == input_time
    assert result.target == input_target
    assert result.dependencies == input_dependencies

# Generated at 2022-06-23 23:40:36.107169
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/home/piotr/test.py')
    output = Path('/opt/build/test.py')
    p = InputOutput(input, output)
    assert p.input == input
    assert p.output == output

# Generated at 2022-06-23 23:40:39.079736
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(ast.parse('[1, 2, 3]'), True, ['dep1', 'dep2'])
    assert result.tree is not None
    assert result.tree_changed is True
    assert result.dependencies == ['dep1', 'dep2']

# Generated at 2022-06-23 23:40:44.528773
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # type: () -> None
    target = CompilationResult(files=42, time=2.5, target=(3, 6),
                               dependencies=['a', 'b', 'c'])
    assert target.files == 42
    assert target.time == 2.5
    assert target.target == (3, 6)
    assert target.dependencies == ['a', 'b', 'c']


# Generated at 2022-06-23 23:40:48.151517
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput('input_path', 'output_path')
    assert input_output.input == Path('input_path')
    assert input_output.output == Path('output_path')

# Generated at 2022-06-23 23:40:51.497470
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(tree=ast.parse('pass'),
                               tree_changed=False,
                               dependencies=['a'])
    assert res.tree is not None
    assert not res.tree_changed
    assert res.dependencies == ['a']

# Generated at 2022-06-23 23:40:53.544820
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path(), Path())
    assert InputOutput(Path('.'), Path('.'))


# Generated at 2022-06-23 23:40:57.855759
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files = 7, time = 3.45, target = (3, 6), dependencies = ['foo', 'bar'])
    assert cr.files == 7
    assert cr.time == 3.45
    assert cr.target == (3, 6)
    assert cr.dependencies == ['foo', 'bar']

# Generated at 2022-06-23 23:41:00.166506
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('input'), Path('output'))
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')

# Generated at 2022-06-23 23:41:01.930472
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput('a', 'b') == InputOutput(Path('a'), Path('b'))

# Generated at 2022-06-23 23:41:05.244207
# Unit test for constructor of class InputOutput
def test_InputOutput():
  input = Path("input")
  output = Path("output")
  io = InputOutput(input, output)

  assert io.input == input
  assert io.output == output

# Generated at 2022-06-23 23:41:08.231214
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = u'input'
    o = u'output'
    p = InputOutput(i, o)
    assert p.input == i
    assert p.output == o


# Generated at 2022-06-23 23:41:15.317321
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('x=1')
    r = TransformationResult(t, True, ['a'])
    assert r.tree is not None and r.tree_changed and len(r.dependencies) == 1
    assert r.dependencies[0] == 'a'


# Result of inspecting a module
ModuleAnalysis = NamedTuple('ModuleAnalysis',
                            [('external_dependencies', List[str]),
                             ('external_symbols', List[str]),
                             ('internal_dependencies', List[str]),
                             ('internal_symbols', List[str]),
                             ('missing_dependencies', List[str])])


# Generated at 2022-06-23 23:41:19.201981
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult.__annotations__['files'] == int
    assert CompilationResult.__annotations__['time'] == float
    assert CompilationResult.__annotations__['target'] == CompilationTarget
    assert CompilationResult.__annotations__['dependencies'] == List[str]


# Generated at 2022-06-23 23:41:23.804815
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 10
    time = 10.0
    target = (3, 4)
    dependencies = ['some_module', 'some_other_module']
    compilation_result = CompilationResult(files, time, target, dependencies)
    assert (compilation_result.files == files and
            compilation_result.time == time and
            compilation_result.target == target and
            compilation_result.dependencies == dependencies)


# Generated at 2022-06-23 23:41:25.197086
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=0.0,
                      target=(3, 5), dependencies=['c1'])


# Generated at 2022-06-23 23:41:31.178702
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from typed_ast import ast3
    assert TransformationResult(tree = ast3.Module(),
                                tree_changed = False,
                                dependencies = [])


# Return type of functions which create compiler
CreateCompiler = Callable[[], 'Compiler']

# Return type of function which returns next compilation result
CompileNext = Callable[[], CompilationResult]

# Return type of function which process compilation result
ProcessCompilationResult = Callable[[CompilationResult], None]

# Return type of function which inputs output pair
TransformIO = Callable[[InputOutput], TransformationResult]

# Return type of function which transforms file
TransformFile = Callable[[Path], TransformationResult]

# Return type of function which transforms file
TransformLines = Callable[[List[str]], TransformationResult]

# Generated at 2022-06-23 23:41:34.848147
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path("input.py"), Path("output.py")).input == Path("input.py")
    assert InputOutput(Path("input.py"), Path("output.py")).output == Path("output.py")



# Generated at 2022-06-23 23:41:37.085529
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p = Path('i')
    q = Path('o')
    n = InputOutput(p, q)
    assert n.input == p
    assert n.output == q


# Generated at 2022-06-23 23:41:40.333677
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(
        ast.parse("x = 1\n"),
        True,
        ['foo.py'])


# Number of tests
TestNumber = int


# Generated at 2022-06-23 23:41:46.140443
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.5,
                               target=(3, 5), dependencies=['a.py'])
    assert result.files == 1
    assert result.time == 0.5
    assert result.target == (3, 5)
    assert result.dependencies == ['a.py']


# Generated at 2022-06-23 23:41:49.549116
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=1, time=2, target=(3, 4), dependencies=['a', 'b'])
    assert res.files == 1
    assert res.time == 2
    assert res.target == (3, 4)
    assert res.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:41:54.368208
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('1 + 1')
    tree.lineno = 1
    tree.col_offset = 2

    tr = TransformationResult(tree,
                              tree_changed=False,
                              dependencies=[])

    t = tr.tree
    assert isinstance(t.lineno, int)
    assert t.lineno == 1
    assert isinstance(t.col_offset, int)
    assert t.col_offset == 2

# Generated at 2022-06-23 23:41:57.818702
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('1 + 1')
    dependencies = ['spam', 'eggs']
    result = TransformationResult(tree, tree_changed=True,
                                  dependencies=dependencies)
    assert result.tree is tree
    assert result.tree_changed is True
    assert result.dependencies is dependencies