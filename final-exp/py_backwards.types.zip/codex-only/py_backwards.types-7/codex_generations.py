

# Generated at 2022-06-23 23:31:59.697729
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('hello.py')
    out = Path('hello.pyc')
    io = InputOutput(input=inp, output=out)
    assert (io.input, io.output) == (inp, out)

# Generated at 2022-06-23 23:32:02.196371
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(None, False, None)
    assert tr.tree == None
    assert tr.tree_changed == False
    assert tr.dependencies == None

# Generated at 2022-06-23 23:32:03.642640
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 1.0, (3, 7), ['/home/'])


# Generated at 2022-06-23 23:32:06.771575
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=2, target=(3, 4), dependencies=['a'])
    assert result.files == 1
    assert result.time == 2
    assert result.target == (3, 4)
    assert result.dependencies == ['a']

# Generated at 2022-06-23 23:32:13.949525
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 2.0, (3, 4), ['a', 'b']).files == 1
    assert CompilationResult(1, 2.0, (3, 4), ['a', 'b']).time == 2.0
    assert CompilationResult(1, 2.0, (3, 4), ['a', 'b']).target == (3, 4)
    assert CompilationResult(1, 2.0, (3, 4), ['a', 'b']).dependencies == ['a', 'b']


# Generated at 2022-06-23 23:32:17.961602
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.AST(), True, [])
    assert isinstance(tr.tree, ast.AST)
    assert isinstance(tr.tree_changed, bool)
    assert isinstance(tr.dependencies, list)
    assert len(tr.dependencies) == 0



# Generated at 2022-06-23 23:32:25.842202
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    class DummyTransformer(ast.NodeTransformer):
        def _generic_visit(self, node: ast.AST) -> ast.AST:
            return ast.copy_location(ast.Expression(node), node)

    tree: ast.AST = ast.parse("[1, 2, 3]", mode="eval")
    result: TransformationResult = TransformationResult(tree, False, [])
    assert result
    assert not result.tree_changed

    transformer = DummyTransformer()
    result_tree: ast.AST = transformer.visit(tree)
    new_result: TransformationResult = TransformationResult(result_tree, False, [])
    assert new_result

    assert ast.dump(result.tree) == ast.dump(tree)
    assert ast.dump(new_result.tree) != ast.dump(tree)

# Generated at 2022-06-23 23:32:36.318961
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CR = CompilationResult
    cr1 = CR(files=3, time=0.5, target=(3, 5),
             dependencies=['a.py', 'b.py'])
    cr2 = CR(files=3, time=0.5, target=(3, 5),
             dependencies=['a.py', 'b.py'])
    assert cr1 == cr2
    cr3 = CR(files=4, time=0.5, target=(3, 5),
             dependencies=['a.py', 'b.py'])
    assert cr1 != cr3
    cr4 = CR(files=3, time=0.4, target=(3, 5),
             dependencies=['a.py', 'b.py'])
    assert cr1 != cr4

# Generated at 2022-06-23 23:32:42.713120
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t1 = ast.parse("")
    t2 = ast.parse("x = y")
    t3 = ast.parse("x = y")
    TransformationResult(t1, False, ["dep1", "dep2"])
    TransformationResult(t2, True, ["dep1", "dep2"])
    TransformationResult(t3, True, [])


# Result of directory providers
DirectoryTrees = NamedTuple('DirectoryTrees',
                            [('input', Path),
                             ('output', Path)])

# Result of directory providers
DirectoryTrees = NamedTuple('DirectoryTrees',
                            [('input', Path),
                             ('output', Path)])

# Result of directory providers
DirectoryTrees = NamedTuple('DirectoryTrees',
                            [('input', Path),
                             ('output', Path)])

# Generated at 2022-06-23 23:32:45.685324
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('foo.py'), Path('bar.py'))
    assert input_output.input.name == 'foo.py'
    assert input_output.output.name == 'bar.py'

# Generated at 2022-06-23 23:32:48.113996
# Unit test for constructor of class InputOutput
def test_InputOutput():
    filename = Path('test-path').absolute()
    assert InputOutput(input=filename, output=filename).input == filename
    assert InputOutput(input=filename, output=filename).output == filename

# Generated at 2022-06-23 23:32:51.809501
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=1, time=1.0, target=(3,1), dependencies=['python', 'python2'])
    assert res.files == 1
    assert res.time == 1.0
    assert res.target == (3,1)
    assert res.dependencies == ['python', 'python2']


# Generated at 2022-06-23 23:32:56.159618
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # pylint: disable=unused-variable,expression-not-assigned,pointless-statement
    TransformationResult(tree=None, tree_changed=False, dependencies=[])

# Wrap all warnings
ALL_WARNINGS = 'always'

# File extensions
PY_EXTENSION = ".py"
PYC_EXTENSION = ".pyc"

# File names
COMMON_PY = "_common" + PY_EXTENSION
COMMON_PYC = COMMON_PY + PYC_EXTENSION

# Import name for common
COMMON_PYC_IMPORT_NAME = "_common"

# Indentation
INDENTATION = "    "

# Module names
MODULE_NAME_TEMPLATE = "{name}" + PY_EXTENSION

# Module paths
MODULE_PATH_

# Generated at 2022-06-23 23:32:57.521705
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(3, 7),
                      dependencies=['a', 'b'])


# Generated at 2022-06-23 23:32:59.497484
# Unit test for constructor of class InputOutput
def test_InputOutput():
    x = InputOutput(Path('foo.py'), Path('bar.py'))
    assert x.input == Path('foo.py')
    assert x.output == Path('bar.py')

# Generated at 2022-06-23 23:33:04.554244
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(
        files=5,
        time=2.5,
        target=(3, 6),
        dependencies=['/tmp/pypy/foo.py']
    )
    assert result.files == 5
    assert result.time == 2.5
    assert result.target == (3, 6)
    assert result.dependencies == ['/tmp/pypy/foo.py']



# Generated at 2022-06-23 23:33:05.922880
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, None, None)


# Generated at 2022-06-23 23:33:09.491898
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('print(1)')
    # noinspection PyTypeChecker
    trans = TransformationResult(t, False, [])
    assert trans.tree_changed is False
    assert trans.dependencies == []

# Generated at 2022-06-23 23:33:12.817726
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path("/foo/bar")
    output = Path("/baz/bar")
    input_output = InputOutput(input, output)

    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-23 23:33:21.303307
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path = './tests/data/test.py'
    input = Path(path)
    output = Path(path).with_suffix('.out')
    result = InputOutput(input, output)
    assert result.input == Path(path)
    assert result.output == Path(path).with_suffix('.out')
    assert result == InputOutput(input, output)

    io_path = './tests/data/test.io'
    io_input = Path(io_path)
    io_output = Path(io_path).with_suffix('.io')
    io_result = InputOutput(io_input, io_output)
    assert io_result.input == Path(io_path)
    assert io_result.output == Path(io_path).with_suffix('.io')
    assert io_result

# Generated at 2022-06-23 23:33:24.072218
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(None, None, None)
    assert tr.tree is None
    assert tr.tree_changed == None
    assert tr.dependencies is None

# Generated at 2022-06-23 23:33:26.833980
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p = Path('/a/b/c')
    i = InputOutput(p, p)
    assert i.input == p
    assert i.output == p

# Generated at 2022-06-23 23:33:29.950982
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(1, 2, (3, 4), ["a", "b"])
    assert c.files == 1
    assert c.time == 2
    assert c.target == (3, 4)
    assert c.dependencies == ["a", "b"]


# Generated at 2022-06-23 23:33:31.956546
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1,
                      time=1,
                      target=(2, 3),
                      dependencies=['a'])

# Generated at 2022-06-23 23:33:34.793865
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(tree='tree', tree_changed=True, dependencies=['dep'])
    assert res.tree == 'tree'
    assert res.tree_changed == True
    assert res.dependencies == ['dep']


# Generated at 2022-06-23 23:33:39.777203
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = 'foo/bar'
    output = 'foo/baz'
    assert InputOutput(input, output) == InputOutput(Path(input),
                                                     Path(output))
    assert InputOutput(input, output) == InputOutput(Path(input),
                                                     output)
    assert InputOutput(input, output) == InputOutput(input,
                                                     Path(output))

# Generated at 2022-06-23 23:33:43.311883
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = 'input.py'
    output_path = 'output.py'

    input_output = InputOutput(input_path, output_path)

    assert input_output.input.name == input_path
    assert input_output.output.name == output_path


# Generated at 2022-06-23 23:33:46.118571
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('print("Hello world")')
    r = TransformationResult(t, True, ['dep1', 'dep2'])
    assert r.tree == t
    assert r.tree_changed == True
    assert r.dependencies == ['dep1', 'dep2']

# Generated at 2022-06-23 23:33:49.717773
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # pylint: disable=missing-docstring,invalid-name
    # pylint: disable=protected-access
    assert TransformationResult(ast.AST(), True, None)
    assert TransformationResult(None, False, [])
    assert TransformationResult(None, None, None)

# Generated at 2022-06-23 23:33:53.242561
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(5, 6.5, (3, 6), [])
    assert compilation_result.files == 5
    assert compilation_result.time == 6.5
    assert compilation_result.target == (3, 6)
    assert compilation_result.dependencies == []

# Generated at 2022-06-23 23:33:58.391959
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=2.0,
                               target=(3, 4),
                               dependencies=["foo", "bar"])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target[0] == 3
    assert result.target[1] == 4
    assert result.dependencies[0] == "foo"
    assert result.dependencies[1] == "bar"

# Generated at 2022-06-23 23:34:01.837498
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(input=Path("test.py"),
                               output=Path("test.dist.py"))

    assert input_output.input == Path("test.py")
    assert input_output.output == Path("test.dist.py")



# Generated at 2022-06-23 23:34:04.655943
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/a/b/c/d')
    output = Path('/e/f/g/h')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-23 23:34:08.778999
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    data = CompilationResult(files=1, time=5,
                             target=CompilationTarget(3, 6),
                             dependencies=['hello.py'])

    assert data.files == 1
    assert data.time == 5
    assert data.target == CompilationTarget(3, 6)
    assert data.dependencies == ['hello.py']

# Generated at 2022-06-23 23:34:12.883248
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(0, 0, (3, 5), [])
    assert len(result) == 4
    assert isinstance(result.files, int)
    assert isinstance(result.time, float)
    assert isinstance(result.target, tuple)
    assert isinstance(result.target[0], int)
    assert isinstance(result.dependencies, list)
    assert len(result.dependencies) == 0



# Generated at 2022-06-23 23:34:15.093763
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0,
                               target=(3, 6), dependencies=[])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 6)
    assert result.dependencies == []

# Generated at 2022-06-23 23:34:18.860598
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """Unit test for constructor of class InputOutput"""
    input = Path('/tmp/input')
    output = Path('/tmp/output')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output

# Generated at 2022-06-23 23:34:22.699148
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input')
    output = Path('/tmp/output')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-23 23:34:28.001718
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=['A'])
    assert cr.files == 1
    assert cr.time == 2.0
    assert cr.target == (3, 4)
    assert cr.dependencies == ['A']



# Generated at 2022-06-23 23:34:30.614194
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Arrange
    # Act
    input_output = InputOutput(Path('a'), Path('b'))
    # Assert
    assert input_output.input == Path('a')
    assert input_output.output == Path('b')


# Generated at 2022-06-23 23:34:33.963937
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=1, time=1.0, target=(3, 6),
                            dependencies=['a', 'b', 'c'])
    assert res.files == 1
    assert res.time == 1.0
    assert res.target == (3, 6)
    assert sorted(res.dependencies) == ['a', 'b', 'c']

# Generated at 2022-06-23 23:34:39.165858
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Use constructor
    obj = CompilationResult(3, 1.5, (3, 7), ["a", "b"])

    # Check fields
    assert obj.files == 3
    assert obj.time == 1.5
    assert obj.target == (3, 7)
    assert obj.dependencies == ["a", "b"]


# Generated at 2022-06-23 23:34:41.873984
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=1,
                             time=0.001,
                             target=(2, 7),
                             dependencies=['ast.py'])


# Generated at 2022-06-23 23:34:52.046663
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    result = TransformationResult(None, False, ['a'])
    assert result.tree is None
    assert result.tree_changed is False
    assert len(result.dependencies) == 1

# Command line option
Option = NamedTuple('Option', [('long', str),
                               ('value', str),
                               ('default', str),
                               ('help', str)])

# Compilation limits
CompilationLimits = NamedTuple('CompilationLimits',
                               [('max_compilation_time', float),
                                ('max_file_size', int),
                                ('max_dependencies', int)])

# Input/dependencies pair

# Generated at 2022-06-23 23:34:55.482805
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(5, 10.5, (3, 5), ['a', 'b'])
    assert cr.files == 5
    assert cr.time == 10.5
    assert cr.target == (3, 5)
    assert cr.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:34:59.749665
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("return x+y")
    tr = TransformationResult(tree, True, ["some_dependency"])
    assert tr.tree == tree
    assert tr.tree_changed
    assert tr.dependencies == ["some_dependency"]


# Generated at 2022-06-23 23:35:02.610772
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('a')
    o = Path('b')
    r = InputOutput(input=i, output=o)
    assert r.input == i
    assert r.output == o


# Generated at 2022-06-23 23:35:07.542129
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r: CompilationResult = CompilationResult(files=1, time=100,
                                             target=(3, 4),
                                             dependencies=['a', 'b'])

    assert r.files == 1
    assert r.time == 100
    assert r.target == (3, 4)
    assert r.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:35:11.777299
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1, time=2,
                                           target=(1, 2),
                                           dependencies=['a', 'b'])
    assert compilation_result.files == 1
    assert compilation_result.time == 2
    assert compilation_result.target == (1, 2)
    assert compilation_result.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:35:14.057371
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_tree = ast.parse('x=1')
    result = TransformationResult(tree=ast_tree, tree_changed=True, dependencies=['y'])
    assert result.tree
    assert result.tree_changed
    assert result.dependencies == ['y']

# Generated at 2022-06-23 23:35:19.122021
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    target = (3, 7)
    result = CompilationResult(5, 100.5, target, ['file1', 'file2'])
    assert result.files == 5
    assert result.time == 100.5
    assert result.target == target
    assert result.dependencies == ['file1', 'file2']


# Generated at 2022-06-23 23:35:23.005867
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert (TransformationResult(
        tree=None,
        tree_changed=False,
        dependencies=[]).__repr__() ==
            "TransformationResult(tree=None, tree_changed=False, "
            "dependencies=[])")


# Generated at 2022-06-23 23:35:25.571723
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path("test.txt")
    o = Path("test.py")
    t = InputOutput(i, o)
    assert t.input == i
    assert t.output == o

# Generated at 2022-06-23 23:35:29.151390
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(1, 1.0, (3, 5), [])
    assert cr.files == 1
    assert cr.time == 1.0
    assert cr.target == (3, 5)
    assert cr.dependencies == []


# Generated at 2022-06-23 23:35:31.191606
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('1.py'), Path('1.pyc'))

    assert input_output.input == Path('1.py')
    assert input_output.output == Path('1.pyc')


# Generated at 2022-06-23 23:35:33.144398
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a.py'), Path('a.pyc')).input == Path('a.py')
    assert InputOutput(Path('a.py'), Path('a.pyc')).output == Path('a.pyc')

# Generated at 2022-06-23 23:35:34.765269
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 1.0, (3, 7), [])


# Generated at 2022-06-23 23:35:36.896605
# Unit test for constructor of class InputOutput
def test_InputOutput():
    result = InputOutput('test_input', 'test_output')
    assert isinstance(result.input, Path)
    assert isinstance(result.output, Path)


# Generated at 2022-06-23 23:35:43.327613
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # InputOutput should be constructed from valid input/output pairs
    InputOutput(Path('.'), Path('..'))

    # Constructor of InputOutput should disallow invalid input/output pairs
    bad_input = ('.', '..')
    with pytest.raises(TypeError):
        InputOutput(*bad_input)

    bad_output = (Path('.'), '..')
    with pytest.raises(TypeError):
        InputOutput(*bad_output)


# Generated at 2022-06-23 23:35:46.791272
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.Module(body=[ast.Str(s="")])
    r = TransformationResult(tree, False, [])
    assert r.tree_changed == False
    assert r.dependencies == []

# Generated at 2022-06-23 23:35:54.216964
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Default constructor
    result = CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=['5'])

    # The value of variable 'files' should be 1
    assert 1 == result.files

    # The value of variable 'time' should be 2.0
    assert 2.0 == result.time

    # The value of variable 'target' should be (3, 4)
    assert (3, 4) == result.target

    # The value of variable 'dependencies' should be ['5']
    assert ['5'] == result.dependencies


# Generated at 2022-06-23 23:35:58.928410
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p1 = Path('/abcd/efg')
    p2 = Path('/hijkl')

    io = InputOutput(p1, p2)

    assert io.input == p1
    assert io.output == p2

    # Test equality
    assert io == InputOutput(p1, p2)

    # Test inequality
    assert io != InputOutput(p2, p2)
    assert io != InputOutput(p1, p1)

# Generated at 2022-06-23 23:36:03.414924
# Unit test for constructor of class InputOutput
def test_InputOutput():
    ext = '.in'
    input_path = Path('test') / Path('test' + ext)
    output_path = Path('test') / Path('test' + ext + '.out')
    assert InputOutput(input_path, output_path) == InputOutput('test/test.in',
                                                               'test/test.in.out')

# Generated at 2022-06-23 23:36:04.871250
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(tree=None, tree_changed=False,
                                  dependencies=[])

# Generated at 2022-06-23 23:36:08.116225
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(None, False, None)
    
# Result of execution of run
RunResult = NamedTuple('RunResult', [('output', str),
                                     ('status', int)])


# Generated at 2022-06-23 23:36:10.544301
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1,
                      time=2.0,
                      target=(3, 4),
                      dependencies=['foo', 'bar'])



# Generated at 2022-06-23 23:36:16.933207
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(
        files=2,
        time=123.456,
        target=(3, 8),
        dependencies=[
            'file_1.py',
            'file_2.py'
        ]
    )
    assert res.files == 2
    assert res.time == 123.456
    assert res.target == (3, 8)
    assert res.dependencies == ['file_1.py', 'file_2.py']


# Generated at 2022-06-23 23:36:20.364738
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    x = CompilationResult(1, 1.0, (2, 7), [])
    assert x.files == 1
    assert x.time == 1.0
    assert x.target == (2, 7)
    assert x.dependencies == []


# Generated at 2022-06-23 23:36:23.413808
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """
    Checks if InputOutput is created properly.
    """
    input_path = Path('/tmp/input.txt')
    output_path = Path('/tmp/output.txt')
    input_output = InputOutput(input_path, output_path)

    assert input_output.input == input_path
    assert input_output.output == output_path

# Generated at 2022-06-23 23:36:26.130382
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('foo.py'), Path('bar.py')) == InputOutput('foo.py', 'bar.py')


# Generated at 2022-06-23 23:36:30.082704
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=3, time=0.1, target=(3, 6), dependencies=['a', 'b'])
    assert res.files == 3
    assert res.time == 0.1
    assert res.target == (3, 6)
    assert res.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:36:40.888831
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    assert TransformationResult(tree, True, ['dependency1', 'dependency2']) \
           == TransformationResult(tree, True, ['dependency1', 'dependency2'])
    assert TransformationResult(tree, False, ['dependency1', 'dependency2']) \
           != TransformationResult(tree, True, ['dependency1', 'dependency2'])


# Result of dependency analysis
DependencyResult = NamedTuple('DependencyResult', [('dependencies', List[str]),
                                                   ('target', CompilationTarget)])

# Result of dependency analysis for a pair of input/output

# Generated at 2022-06-23 23:36:48.332764
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert type(TransformationResult(ast.AST(), False, [])) == TransformationResult
    assert type(TransformationResult(ast.AST(), True, [])) == TransformationResult
    assert type(TransformationResult(ast.AST(), False, ['foo'])) == TransformationResult
    assert type(TransformationResult(ast.AST(), True, ['foo'])) == TransformationResult
    assert type(TransformationResult(ast.AST(), True, ['foo', 'bar'])) == TransformationResult
    assert type(TransformationResult(ast.AST(), True, ['/foo.py', '/bar.py'])) == TransformationResult

# Generated at 2022-06-23 23:36:49.951527
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=2,
                             time=0.5,
                             target=(3, 5),
                             dependencies=['foo.py'])

# Generated at 2022-06-23 23:36:55.286900
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(100, 10.5, (3, 7), ['foo', 'bar'])
    assert type(result.files) == int
    assert type(result.time) == float
    assert type(result.target) == tuple
    assert type(result.dependencies) == list
    assert result.files == 100
    assert result.time == 10.5
    assert result.target == (3, 7)
    assert result.dependencies == ['foo', 'bar']


# Generated at 2022-06-23 23:36:59.285711
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 5')
    tree_changed = True
    dependencies = ['a', 'b', 'c']
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-23 23:37:03.467299
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('my/path.py')
    output = Path('my/path.js')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-23 23:37:05.178193
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input = 'a', output = 'b').input == 'a'
    assert InputOutput(input = 'a', output = 'b').output == 'b'

# Generated at 2022-06-23 23:37:06.134910
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(Path('a'), Path('b'))

# Generated at 2022-06-23 23:37:08.896477
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('a.txt')
    output = Path('b.txt')
    a = InputOutput(input, output)
    assert (a.input == input)
    assert (a.output == output)

# Generated at 2022-06-23 23:37:12.913806
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=0,
                               time=0.0, 
                               target=(2, 7), 
                               dependencies=[])
    assert result.files == 0
    assert result.time == 0.0
    assert result.target == (2, 7)
    assert result.dependencies == []


# Generated at 2022-06-23 23:37:14.824873
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('test.py')
    o = Path('test.pyc')
    assert i == InputOutput(i, o).input
    assert o == InputOutput(i, o).output

# Generated at 2022-06-23 23:37:16.679271
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.parse("", "<test>"), True, [])
    TransformationResult(ast.parse("", "<test>"), False, None)

# Generated at 2022-06-23 23:37:19.545151
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=1,
                             time=2.1,
                             target=(3, 4),
                             dependencies=["a", "b"])

# Generated at 2022-06-23 23:37:23.070101
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(None, True, ['abc'])
    assert len(t) == 3
    assert t.tree == None
    assert t.tree_changed == True
    assert t.dependencies == ['abc']

# Generated at 2022-06-23 23:37:26.693200
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(5, 4.5, (2, 7), ['a'])
    assert res.files == 5
    assert res.time == 4.5
    assert res.target == (2, 7)
    assert res.dependencies == ['a']


# Generated at 2022-06-23 23:37:27.654448
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    _ = CompilationResult


# Generated at 2022-06-23 23:37:31.203987
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1, time=1.1, target=(3, 6), dependencies=['foo'])
    assert compilation_result.files == 1
    assert compilation_result.time == 1.1
    assert compilation_result.target == (3, 6)
    assert compilation_result.dependencies == ['foo']


# Generated at 2022-06-23 23:37:32.802880
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 0.0, (3, 5), [])


# Generated at 2022-06-23 23:37:38.182820
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=1, time=1.0, target=(3, 0),
                          dependencies=['foo.py', 'bar.py'])
    assert c.files == 1
    assert c.time == 1.0
    assert c.target == (3, 0)
    assert c.dependencies == ['foo.py', 'bar.py']



# Generated at 2022-06-23 23:37:43.853319
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=5,
                                           time=99.9,
                                           target=(3, 5),
                                           dependencies=['abc', 'def'])
    assert compilation_result.files == 5
    assert compilation_result.time == 99.9
    assert compilation_result.target == (3, 5)
    assert compilation_result.dependencies == ['abc', 'def']


# Generated at 2022-06-23 23:37:46.838587
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(10, 0.01, (3, 4), [])
    assert result.files == 10
    assert result.time == 0.01
    assert result.target == (3, 4)
    assert result.dependencies == []


# Generated at 2022-06-23 23:37:48.861969
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('/')
    o = Path('/')
    pair = InputOutput(i, o)
    assert pair.input == i
    assert pair.output == o

# Generated at 2022-06-23 23:37:53.698859
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.Name(id='abc', ctx=ast.Load())
    tree_changed = True
    dependencies = ['a.py', 'b.py', 'c.py']
    res = TransformationResult(tree, tree_changed, dependencies)
    assert res.tree == tree
    assert res.tree_changed == tree_changed
    assert res.dependencies == dependencies

# Generated at 2022-06-23 23:37:57.814086
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=100,
                           time=10.1,
                           target=(2, 7),
                           dependencies=['a', 'b'])
    assert cr.files == 100
    assert cr.time == 10.1
    assert cr.target == (2, 7)
    assert cr.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:38:00.197298
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path('input'), Path('output'))
    assert io.input == Path('input')
    assert io.output == Path('output')

# Generated at 2022-06-23 23:38:01.102788
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=[])


# Generated at 2022-06-23 23:38:08.093131
# Unit test for constructor of class InputOutput
def test_InputOutput():
    try:
        _ = InputOutput('a', 'b')
        assert False
    except TypeError:
        assert True
    try:
        _ = InputOutput(Path('a'), 'b')
        assert False
    except TypeError:
        assert True
    try:
        _ = InputOutput('a', Path('b'))
        assert False
    except TypeError:
        assert True
    try:
        _ = InputOutput(Path('a'), Path('b'))
        assert True
    except TypeError:
        assert False


# Generated at 2022-06-23 23:38:12.566566
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('1+1')
    tr = TransformationResult(tree, True, ['foo.py'])
    assert type(tr.tree) == ast.AST
    assert ast.dump(tr.tree) == ast.dump(tree)
    assert tr.tree_changed
    assert tr.dependencies == ['foo.py']

# Generated at 2022-06-23 23:38:15.394584
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('in.py')
    output = Path('out.py')

    assert(input == InputOutput(input, output).input)
    assert(output == InputOutput(input, output).output)


# Generated at 2022-06-23 23:38:18.001538
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    value = TransformationResult(ast.parse('1'), True, ['foo'])
    assert value.tree
    assert value.tree_changed
    assert value.dependencies == ['foo']

# Generated at 2022-06-23 23:38:28.187873
# Unit test for constructor of class CompilationResult
def test_CompilationResult():

    # Check exception if number of files is negative
    with pytest.raises(ValueError):
        CompilationResult(files=-1, time=0.1, target=(3, 6), dependencies=[])

    # Check exception if time is negative
    with pytest.raises(ValueError):
        CompilationResult(files=1, time=-0.1, target=(3, 6), dependencies=[])

    # Check exception if target version is less than 3
    with pytest.raises(ValueError):
        CompilationResult(files=1, time=0.1, target=(2, 6), dependencies=[])

    # Check exception if target version is 3 and less than 6
    with pytest.raises(ValueError):
        CompilationResult(files=1, time=0.1, target=(3, 5), dependencies=[])

    # Check exception if

# Generated at 2022-06-23 23:38:33.656994
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1,
                                           time=0.01,
                                           target=(3, 5),
                                           dependencies=('path1', 'path2'))

    assert isinstance(compilation_result.files, int)
    assert isinstance(compilation_result.time, float)
    assert isinstance(compilation_result.target, CompilationTarget)
    assert isinstance(compilation_result.dependencies, list)


# Generated at 2022-06-23 23:38:36.231517
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(input=Path('input.py'),
                               output=Path('output.py'))
    assert isinstance(input_output.input, Path)
    assert isinstance(input_output.output, Path)

# Generated at 2022-06-23 23:38:37.256275
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(2, 3.14, (3, 6), ["foo"])

# Generated at 2022-06-23 23:38:40.671254
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    source = """def f():
                   pass
               """
    tree = ast.parse(source)
    changed = False
    f = ast.parse('f = g', filename=source).body[0]
    changed = True
    dependencies = ['f', 'g']
    tr = TransformationResult(tree, changed, dependencies)
    assert tr.tree == tree
    assert tr.tree_changed == changed
    assert tr.dependencies == dependencies


# Generated at 2022-06-23 23:38:47.134963
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input=Path('input.py'), output=Path('output.py')).input == Path('input.py')
    assert InputOutput(input=Path('input.py'), output=Path('output.py')).output == Path('output.py')
    assert InputOutput(input=Path('input.py'), output=Path('output.py')) == InputOutput(input=Path('input.py'), output=Path('output.py'))


# Generated at 2022-06-23 23:38:50.819266
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(10, 1.0, (3, 5), [])
    assert r.files == 10
    assert r.time == 1.0
    assert r.target == (3, 5)
    assert r.dependencies == []



# Generated at 2022-06-23 23:38:54.368083
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # GIVEN
    input_ = Path('./foo/input.py')
    output = Path('./foo/output.py')

    # WHEN
    pair = InputOutput(input_, output)

    # THEN
    assert pair.input == input_
    assert pair.output == output


# Generated at 2022-06-23 23:38:55.105795
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, None, None)



# Generated at 2022-06-23 23:38:56.169659
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(tree=None, tree_changed=True, dependencies=[])

# Generated at 2022-06-23 23:38:58.905389
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('1 + 2')
    tr = TransformationResult(tree, True, ['file1', 'file2'])
    assert tr.tree == tree
    assert tr.tree_changed == True
    assert tr.dependencies == ['file1', 'file2']

# Generated at 2022-06-23 23:39:04.795037
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Prepare data
    files = 1
    time = 0.5
    target = (3, 8)
    dependencies = ['a.py', 'b.py']

    # Construct an object
    obj = CompilationResult(files, time, target, dependencies)

    # Test
    assert obj.files == files
    assert obj.time == time
    assert obj.target == target
    assert obj.dependencies == dependencies


# Generated at 2022-06-23 23:39:07.640880
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = InputOutput(input='input', output='output')
    assert(a.input == 'input')
    assert(a.output == 'output')


# Generated at 2022-06-23 23:39:12.917552
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=['a.py'])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == ['a.py']


# Generated at 2022-06-23 23:39:16.960010
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(1,1,(1,1),['a'])
    assert cr.files == 1
    assert cr.time == 1
    assert cr.target == (1,1)
    assert cr.dependencies == ['a']


# Generated at 2022-06-23 23:39:19.485372
# Unit test for constructor of class CompilationResult
def test_CompilationResult(): # type: () -> None
    CompilationResult(files=1, time=2.0, target=(2, 7), dependencies=['a', 'b'])


# Generated at 2022-06-23 23:39:25.606634
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr1 = TransformationResult(ast.parse('a = 1'), True, [])
    tr2 = TransformationResult(ast.parse('a = 1'), False, [])
    assert tr1.tree == ast.parse('a = 1')
    assert tr1.tree_changed == True
    assert tr1.dependencies == []
    assert tr2.tree == ast.parse('a = 1')
    assert tr2.tree_changed == False
    assert tr2.dependencies == []

# Generated at 2022-06-23 23:39:28.327121
# Unit test for constructor of class InputOutput
def test_InputOutput():
    files = InputOutput(input=Path('input'), output=Path('output'))
    assert files.input == Path('input')
    assert files.output == Path('output')


# Generated at 2022-06-23 23:39:34.336050
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=42,
                                           time=15.1,
                                           target=(3, 6),
                                           dependencies=['foo.py'])
    assert compilation_result.files == 42
    assert compilation_result.time == 15.1
    assert compilation_result.target == (3, 6)
    assert compilation_result.dependencies == ['foo.py']


# Generated at 2022-06-23 23:39:38.553940
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path('/usr/src/greet'),
                     Path('/usr/src/greet-minimized'))
    assert io.input == Path('/usr/src/greet')

# Generated at 2022-06-23 23:39:40.242435
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(0, 0.0, (2, 7), [])


# Generated at 2022-06-23 23:39:43.442310
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=['foo'])
    assert c.files == 1
    assert c.time == 2.0
    assert c.target == (3, 4)
    assert c.dependencies == ['foo']

# Generated at 2022-06-23 23:39:50.553387
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input=Path('/'), output=Path('/usr')) == \
           InputOutput(input=Path('/'), output=Path('/usr'))
    assert InputOutput(input=Path('/'), output=Path('/usr')) != \
           InputOutput(input=Path('/'), output=Path('/home'))
    assert InputOutput(input=Path('/'), output=Path('/usr')) != \
           InputOutput(input=Path('/home'), output=Path('/home'))


# Generated at 2022-06-23 23:39:57.786653
# Unit test for constructor of class InputOutput
def test_InputOutput():
    try:
        InputOutput('foo', 'bar')
        assert True is False
    except:
        pass
    assert InputOutput(Path('foo'), Path('bar')) == \
        InputOutput(Path('foo'), Path('bar'))
    assert InputOutput(Path('foo'), Path('bar')) != \
        InputOutput(Path('baz'), Path('bar'))
    assert InputOutput(Path('foo'), Path('bar')) != \
        InputOutput(Path('foo'), Path('baz'))

# Generated at 2022-06-23 23:40:01.774174
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(tree=ast.Module(), tree_changed=True,
                                  dependencies=['a', 'b'])
    assert isinstance(result.tree, ast.AST)
    assert result.tree_changed == True
    assert result.dependencies == ['a', 'b']

# Generated at 2022-06-23 23:40:04.713444
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # pylint: disable=no-value-for-parameter
    TransformationResult(None, None, None)
    TransformationResult(ast.parse('pass'), False, ['a.py'])
    # pylint: enable=no-value-for-parameter

# Generated at 2022-06-23 23:40:07.703944
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('foo')
    output = Path('bar')
    pair = InputOutput(input, output)
    assert pair.input == input
    assert pair.output == output

# Generated at 2022-06-23 23:40:12.943026
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    """Unit test for constructor of class TransformationResult"""
    tree = ast.parse('x=x+1', mode='eval')
    result = TransformationResult(tree, True, ['base.py'])
    assert result.tree is tree
    assert result.tree_changed is True
    assert result.dependencies == ['base.py']

# Generated at 2022-06-23 23:40:15.142442
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=2, time=3.14, target=(3, 7),
                      dependencies=['foo', 'bar'])


# Generated at 2022-06-23 23:40:16.104417
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.AST(), False, [])

# Generated at 2022-06-23 23:40:17.777265
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=1, time=0.0, target=(2, 7), dependencies=[])



# Generated at 2022-06-23 23:40:19.282518
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=1, time=1.0, target=(3, 2), dependencies=[])


# Generated at 2022-06-23 23:40:22.872356
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_tree = ast.AST()
    tree_changed = True
    dependencies = ['module1', 'module2']
    tr = TransformationResult(tree=ast_tree, tree_changed=tree_changed,
                              dependencies=dependencies)
    assert tr.tree == ast_tree
    assert tr.tree_changed == tree_changed
    assert tr.dependencies == dependencies

# Generated at 2022-06-23 23:40:26.668117
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(1, 2, (3, 4), ["a"])
    assert cr.files == 1
    assert cr.time == 2
    assert cr.target == (3, 4)
    assert cr.dependencies == ["a"]


# Generated at 2022-06-23 23:40:29.568218
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('a')
    o = Path('b')
    input_output = InputOutput(i, o)

    assert input_output.input == i
    assert input_output.output == o



# Generated at 2022-06-23 23:40:31.722754
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(0, 1.0, (3, 5), [])
    assert isinstance(res, CompilationResult)


# Generated at 2022-06-23 23:40:33.306297
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(tree=ast.parse('2+2'),
                         tree_changed=True,
                         dependencies=[])

# Generated at 2022-06-23 23:40:35.427321
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Checks that constructor validates the input parameters
    assert InputOutput(Path('/a'), Path('/b')) is not None


# Generated at 2022-06-23 23:40:36.962455
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    path = Path('./Dummy')
    TransformationResult(ast.parse(''), True, [str(path)])

# Generated at 2022-06-23 23:40:38.733250
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 2, (3, 4), ['a']) == \
        CompilationResult(1, 2, (3, 4), ['a'])


# Generated at 2022-06-23 23:40:41.972143
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('/tmp/input.py')
    output_path = Path('/tmp/output.py')
    assert InputOutput(input=input_path, output=output_path)



# Generated at 2022-06-23 23:40:47.697801
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('tests/data/valid/sample.py')
    output = Path('tests/data/valid/sample.py')
    input_output = InputOutput(input, output)
    assert(input_output.input == input)
    assert(input_output.output == output)
    assert(input_output == InputOutput(input, output))


# Generated at 2022-06-23 23:40:52.708939
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    target = CompilationResult(files=0, time=4.0, target=(3, 2),
                               dependencies=['foo', 'bar'])
    assert target.files == 0
    assert target.time == 4.0
    assert target.target == (3, 2)
    assert target.dependencies == ['foo', 'bar']


# Generated at 2022-06-23 23:40:56.614830
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=1, time=1.0, target=(3, 4), dependencies=[])
    assert c.files == 1
    assert c.time == 1.0
    assert c.target == (3, 4)
    assert c.dependencies == []



# Generated at 2022-06-23 23:41:00.098445
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(ast.parse('x = 1'), False, ['a.py'])
    assert t.tree.body[0].targets[0].id == 'x'
    assert t.tree_changed == False
    assert t.dependencies == ['a.py']

# Generated at 2022-06-23 23:41:01.822143
# Unit test for constructor of class InputOutput
def test_InputOutput():
    try:
        InputOutput()
    except:
        pytest.fail("Unit test failed")


# Generated at 2022-06-23 23:41:06.235232
# Unit test for constructor of class InputOutput
def test_InputOutput():
    arg1 = Path("./input.py")
    arg2 = Path("./input.py.out")

    obj = InputOutput(arg1, arg2)

    assert obj.input == arg1
    assert obj.output == arg2


# Generated at 2022-06-23 23:41:10.490824
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(None, False, None)

# Path of directory with sources
SourceDir = NamedTuple('SourceDir',
                       [('path', Path)])

# Information about transforming source directory to target directory
TransformResult = NamedTuple('TransformResult',
                             [('target_dir', Path),
                              ('result', CompilationResult)])

# Generated at 2022-06-23 23:41:12.437195
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files = 1, time = 5.0, target = (3, 6),
                      dependencies = ['f1'])


# Generated at 2022-06-23 23:41:15.443305
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.parse(''), False, [])
    TransformationResult(ast.parse(''), True, [])
    TransformationResult(ast.parse(''), False, [''])
    TransformationResult(ast.parse(''), True, [''])

# Generated at 2022-06-23 23:41:19.142532
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(tree=None, tree_changed=False, dependencies=[])
    assert result.tree is None
    assert not result.tree_changed
    assert result.dependencies == []


# Result of analyzing one input file
AnalysisResult = NamedTuple('AnalysisResult',
                            [('result', TransformationResult),
                             ('input_file', Path)])


# Generated at 2022-06-23 23:41:22.563122
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_file = Path('test.in')
    output_file = Path('test.out')
    input_output = InputOutput(input_file, output_file)
    assert(input_output.input == input_file)
    assert(input_output.output == output_file)


# Generated at 2022-06-23 23:41:24.195461
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=4.0,
                      target=(2, 7), dependencies=['a', 'b'])



# Generated at 2022-06-23 23:41:25.901679
# Unit test for constructor of class InputOutput
def test_InputOutput():
    result = InputOutput('a', 'b')
    assert result.input == 'a'
    assert result.output == 'b'


# Generated at 2022-06-23 23:41:27.339663
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.AST, bool, List[str])

# Generated at 2022-06-23 23:41:28.777013
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2, (3, 4), [])


# Generated at 2022-06-23 23:41:30.943948
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=0, time=0.0, target=(0, 0), dependencies=[])
    assert result.files == 0
    assert result.time == 0.0
    assert result.target == (0, 0)
    assert result.dependencies == []


# Generated at 2022-06-23 23:41:32.325455
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input=Path('foo.py'), output=Path('bar.py'))

# Generated at 2022-06-23 23:41:33.498929
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.parse(''), False, [])

# Generated at 2022-06-23 23:41:35.459568
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    assert TransformationResult(tree, True, ['test'])

# Generated at 2022-06-23 23:41:37.322544
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("a + b")
    TransformationResult(tree, False, [])


# Generated at 2022-06-23 23:41:40.084126
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = InputOutput(Path("foo"), Path("bar"))
    assert i.input == Path("foo")
    assert i.output == Path("bar")

# Generated at 2022-06-23 23:41:46.372678
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(0, 0.0, (0, 0), [])
    assert isinstance(compilation_result.files, int)
    assert isinstance(compilation_result.time, float)
    assert isinstance(compilation_result.target, CompilationTarget)
    assert isinstance(compilation_result.dependencies, List[str])


# Generated at 2022-06-23 23:41:52.110460
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('foo')
    output = Path('bar')
    io = InputOutput(input_, output)
    assert io.input == 'foo'
    assert io.output == 'bar'
    io = InputOutput(input_, None)
    assert io.input == 'foo'
    assert io.output == None
    io = InputOutput(None, output)
    assert io.input == None
    assert io.output == 'bar'
    io = InputOutput(None, None)
    assert io.input == None
    assert io.output == None


# Generated at 2022-06-23 23:41:55.653903
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=3, time=1.0, target=(3, 8), dependencies=[])
    assert cr.files == 3
    assert cr.time == 1.0
    assert cr.target == (3, 8)
    assert cr.dependencies == []


# Generated at 2022-06-23 23:41:59.269709
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('') # empty module
    tree.body = []
    result = TransformationResult(tree=tree,
                                  tree_changed=False,
                                  dependencies=['foo.py'])
    assert result.tree == tree
    assert result.tree_changed == False
    assert result.dependencies == ['foo.py']