

# Generated at 2022-06-23 23:32:13.664075
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_file = Path("in")
    output_file = Path("out")
    io = InputOutput(input_file, output_file)
    assert io.input == input_file
    assert io.output == output_file
    assert io[0] == input_file
    assert io[1] == output_file
    assert io == ("in", "out")
    with pytest.raises(TypeError):
        io = InputOutput("in", "out")
    with pytest.raises(TypeError):
        io = InputOutput("in", 135)
    with pytest.raises(TypeError):
        io = InputOutput(135, "out")
    with pytest.raises(TypeError):
        io = InputOutput(135, 135)
    with pytest.raises(TypeError):
        io = InputOutput

# Generated at 2022-06-23 23:32:20.745602
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Define test pairs
    input_output_pairs = [
        ('input', 'output'),
        (Path('input'), Path('output')),
        (Path('in/put'), 'output'),
        ('input', Path('output')),
    ]
    # Test pairs
    for input_, output in input_output_pairs:
        # Create InputOutput from inputs
        input_output = InputOutput(input=input_, output=output)
        # Check that input and output are of proper types
        assert isinstance(input_output.input, Path)
        assert isinstance(input_output.output, Path)

# Generated at 2022-06-23 23:32:23.504304
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(input=Path('/a/b/c/a.py'),
                               output=Path('/a/b/c/a_transformed.py'))
    assert(input_output.input == Path('/a/b/c/a.py'))
    assert(input_output.output == Path('/a/b/c/a_transformed.py'))

# Generated at 2022-06-23 23:32:25.969731
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """Unit test for constructor of class InputOutput"""
    io = InputOutput(input='foo', output='bar')
    assert io.input == 'foo'
    assert io.output == 'bar'

# Generated at 2022-06-23 23:32:33.362599
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # pylint: disable=invalid-name
    a = InputOutput(Path('a'), Path('b'))
    assert a.input == Path('a')
    assert a.output == Path('b')

    # pylint: disable=invalid-name
    a = InputOutput(input=Path('a'), output=Path('b'))
    assert a.input == Path('a')
    assert a.output == Path('b')

    # pylint: disable=invalid-name
    a = InputOutput('a', 'b')
    asse

# Generated at 2022-06-23 23:32:36.942247
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('print(1 + 1)')
    dependency = 'dependency1'
    trans = TransformationResult(tree, True, [dependency])
    assert trans.tree == tree
    assert trans.tree_changed == True
    assert trans.dependencies == [dependency]

# Generated at 2022-06-23 23:32:40.815452
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i1 = Path('/x')
    o1 = Path('/y')
    # create InputOutput instance
    input_output = InputOutput(input=i1, output=o1)
    # check content
    assert input_output.input == i1
    assert input_output.output == o1
    # test string representation
    assert str(input_output) == '<input: /x, output: /y>'


# Generated at 2022-06-23 23:32:43.466925
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.parse('1'), True, [])
    assert tr.tree_changed == True
    assert tr.dependencies == []

# Returns filled CompilationResult

# Generated at 2022-06-23 23:32:46.763561
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """
    >>> InputOutput(Path('input.py'), Path('output.py'))
    InputOutput(input=PosixPath('input.py'), output=PosixPath('output.py'))
    """
    pass


# Generated at 2022-06-23 23:32:49.408438
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('./input.py')
    output = Path('./output.py')
    inout = InputOutput(input, output)
    assert inout.input == input
    assert inout.output == output

# Generated at 2022-06-23 23:32:54.610817
# Unit test for constructor of class CompilationResult
def test_CompilationResult():

    # Type hints
    files: int
    time: float
    target: CompilationTarget
    dependencies: List[str]

    # Assign values
    files = 1
    time = 1.1
    dependencies = ['d1', 'd2']
    target = (3, 6)

    # Create instance
    result = CompilationResult(files, time, target, dependencies)

    # Check values
    assert result.files == files
    assert result.time == time
    assert result.target == target
    assert result.dependencies == dependencies


# Generated at 2022-06-23 23:32:57.589934
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=0.1, target=(3, 7), dependencies=['a'])
    assert cr.files == 1
    assert cr.time == 0.1
    assert cr.target == (3, 7)
    assert cr.dependencies == ['a']


# Generated at 2022-06-23 23:32:59.941096
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_input = Path('test.py')
    test_output = Path('test.js')
    test_object = InputOutput(input=test_input, output=test_output)
    assert test_object[0] == test_input
    assert test_object[1] == test_output

# Generated at 2022-06-23 23:33:02.334373
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = InputOutput(input="a", output="b")
    assert i.input == Path("a")
    assert i.output == Path("b")



# Generated at 2022-06-23 23:33:06.680178
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=3,
                               time=3.4,
                               target=(1, 0),
                               dependencies=['A', 'B', 'C'])
    assert result.files == 3
    assert result.time == 3.4
    assert result.target == (1, 0)
    assert result.dependencies == ['A', 'B', 'C']


# Generated at 2022-06-23 23:33:11.686328
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=5, time=1, target=(3, 5), dependencies=['a', 'b'])
    assert c.files == 5
    assert c.time == 1
    assert c.target == (3, 5)
    assert c.dependencies == ['a', 'b']

# Generated at 2022-06-23 23:33:16.110777
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=10,
                            time=0.35,
                            target=(3, 6),
                            dependencies=['file1', 'file2'])
    assert res.files == 10
    assert res.time == 0.35
    assert res.target == (3, 6)
    assert res.dependencies == ['file1', 'file2']


# Generated at 2022-06-23 23:33:19.479957
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('.')
    output_path = Path('/home/test')
    io = InputOutput(input_path, output_path)
    assert io.input == input_path
    assert io.output == output_path

# Generated at 2022-06-23 23:33:23.521631
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(0, 0.0, (3, 6), [])
    assert c.files == 0
    assert c.time == 0.0
    assert c.target == (3, 6)
    assert c.dependencies == []


# Generated at 2022-06-23 23:33:25.631839
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2.0, (3, 4), ['bla'])


# Generated at 2022-06-23 23:33:27.213152
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert isinstance(CompilationResult(0, 0, (0, 0), []), CompilationResult)


# Generated at 2022-06-23 23:33:29.092277
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput("foo", "bar")
    assert io.input == "foo"
    assert io.output == "bar"



# Generated at 2022-06-23 23:33:32.430718
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path_in = Path('./path/to/input')
    path_out = Path('./path/to/output')
    io = InputOutput(path_in, path_out)
    assert io.input == path_in
    assert io.output == path_out

# Generated at 2022-06-23 23:33:35.753138
# Unit test for constructor of class InputOutput
def test_InputOutput():
    in_ = Path('input')
    out = Path('output')
    io = InputOutput(in_, out)
    assert io.input == in_
    assert io.input.name == 'input'
    assert io.output == out
    assert io.output.name == 'output'


# Generated at 2022-06-23 23:33:37.929715
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p1 = Path('in1')
    p2 = Path('out1')
    res = InputOutput(p1, p2)
    assert res.input == p1
    assert res.output == p2


# Generated at 2022-06-23 23:33:40.008469
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('abc')
    o = Path('bcd')
    tr = InputOutput(i,o)
    asse

# Generated at 2022-06-23 23:33:42.316973
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    a = TransformationResult(None, None, [])
    assert a.dependencies == []
    assert a.tree == None
    assert a.tree_changed == None



# Generated at 2022-06-23 23:33:44.849215
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(0, 0.0, (0, 0), [])

    assert result.files == 0
    assert result.time == 0.0
    assert result.target == (0, 0)
    assert result.dependencies == []


# Generated at 2022-06-23 23:33:47.280720
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(None, False, None)
    assert tr.tree == None
    assert tr.tree_changed == False
    assert tr.dependencies == None

# Generated at 2022-06-23 23:33:55.563836
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=1,
                             time=1.1,
                             target=(3, 6),
                             dependencies=[]).files == 1
    assert CompilationResult(files=1,
                             time=1.1,
                             target=(3, 6),
                             dependencies=[]).time == 1.1
    assert CompilationResult(files=1,
                             time=1.1,
                             target=(3, 6),
                             dependencies=[]).target == (3, 6)
    assert CompilationResult(files=1,
                             time=1.1,
                             target=(3, 6),
                             dependencies=[]).dependencies == []



# Generated at 2022-06-23 23:34:02.775708
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('input.py')
    output_path = Path('output.ipynb')

    # Creator
    assert InputOutput(input_path, output_path) == InputOutput(input_path, output_path)
    assert InputOutput(input_path, output_path) != InputOutput(output_path, input_path)
    assert InputOutput(input_path, input_path) == InputOutput(input_path, input_path)

    # Accessors
    assert InputOutput(input_path, output_path).input == input_path
    assert InputOutput(input_path, output_path).output == output_path



# Generated at 2022-06-23 23:34:03.933993
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    TransformationResult(ast.Module(), True, [])

# Generated at 2022-06-23 23:34:08.896599
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from typed_ast import ast3 as ast
    from ast_typer.transformers import TransformationResult
    from ast_typer.tools import decorated_ast_to_source
    t = TransformationResult(tree=ast.parse("0"), tree_changed=True, dependencies=[])
    assert decorated_ast_to_source(t.tree) == "0\n"
    assert t.tree_changed
    assert t.dependencies == []


# Generated at 2022-06-23 23:34:11.624077
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_node = ast.parse('None', 'NOWHERE')
    tr = TransformationResult(ast_node, False, [])
    assert tr.tree == ast_node
    assert tr.tree_changed is False
    assert tr.dependencies == []



# Generated at 2022-06-23 23:34:14.291187
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=1.0, target=(1, 2), dependencies=[])
    assert cr.files == 1
    assert cr.time == 1.0
    assert cr.target == (1, 2)
    assert cr.dependencies == []

# Generated at 2022-06-23 23:34:16.495470
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p = Path('./foo')
    input_output = InputOutput(input=p, output=p)

    assert input_output.input == p
    assert input_output.output == p

# Generated at 2022-06-23 23:34:19.203125
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(input=Path('foo'), output=Path('bar'))
    assert io.input == Path('foo')
    assert io.output == Path('bar')


# Generated at 2022-06-23 23:34:24.680096
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    dependency = ['/folder/subfolder/module.py']
    content = CompilationResult(1, 2.1, (3, 4), dependency)
    assert content.files == 1
    assert content.time == 2.1
    assert content.target == (3, 4)
    assert content.dependencies == dependency


# Generated at 2022-06-23 23:34:27.724123
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path("input.py")
    output = Path("output.py")
    iot = InputOutput(input, output)
    result = iot
    assert result is not None

# Generated at 2022-06-23 23:34:37.419500
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    with pytest.raises(TypeError):
        CompilationResult()
    with pytest.raises(TypeError):
        CompilationResult(1)
    with pytest.raises(TypeError):
        CompilationResult(1, 2)
    with pytest.raises(TypeError):
        CompilationResult(1, 2, 3)
    with pytest.raises(TypeError):
        CompilationResult(1, 2, 3, 4)
    result = CompilationResult(1, 2, 3, [])
    assert result.files == 1
    assert result.time == 2
    assert result.target == 3
    assert result.dependencies == []


# Generated at 2022-06-23 23:34:45.269480
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Type check
    c = CompilationResult(1, 2.0, (3, 4), ['x', 'y'])
    assert c.files == 1
    assert c.time == 2.0
    assert c.target == (3, 4)
    assert c.dependencies == ['x', 'y']
    # Immutable
    with pytest.raises(AttributeError):
        c.files = 2
    with pytest.raises(AttributeError):
        c.time = 3.0
    with pytest.raises(AttributeError):
        c.target = (5, 6)
    with pytest.raises(AttributeError):
        c.dependencies = []


# Generated at 2022-06-23 23:34:51.141413
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from test_utils import ast_example
    TransformationResult(ast_example(), True, [''])
    TransformationResult(ast_example(), False, [''])
    TransformationResult(ast_example(), True, [])
    TransformationResult(ast_example(), False, [])


# Result of transformer function
TransformerResult = NamedTuple('TransformerResult',
                               [('tree', ast.AST),
                                ('tree_changed', bool)])

# Generated at 2022-06-23 23:34:55.168985
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    comp_res = CompilationResult(files=10, time=2.5, target=(3, 7), dependencies=['a', 'b'])
    assert comp_res.files == 10
    assert comp_res.time == 2.5
    assert comp_res.target == (3, 7)
    assert comp_res.dependencies == ['a', 'b']



# Generated at 2022-06-23 23:34:58.149795
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # pylint: disable=unused-variable
    res = CompilationResult(files=5, time=0.5, target=(3, 7), dependencies=['a', 'b'])

# Generated at 2022-06-23 23:35:01.858832
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0,
                               target=(3, 5), dependencies=[])
    assert result.files == 1
    assert result.time == 0
    assert result.target == (3, 5)
    assert not result.dependencies


# Generated at 2022-06-23 23:35:07.798945
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    import time
    result = CompilationResult(files=5,
                               time=0.4,
                               target=(3, 5),
                               dependencies=['a', 'b', 'c'])
    assert result.files == 5
    assert result.time < 0.5
    assert result.time > 0.3
    assert result.target == (3, 5)
    assert result.dependencies == ['a', 'b', 'c']

# Generated at 2022-06-23 23:35:12.519362
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(
        tree=ast.parse("1"),
        tree_changed=False,
        dependencies=[]
    )
    assert result.tree_changed == False
    assert result.dependencies == []
    print(result.tree)


# Result of transformers transformation
TypeCheckResult = NamedTuple('TypeCheckResult',
                             [('script', str),
                              ('script_changed', bool),
                              ('dependencies', List[str])])



# Generated at 2022-06-23 23:35:17.798980
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    # Using any arbitrary object as an AST
    obj = object()
    tree = ast.Module(body=[obj])
    res = TransformationResult(tree, True, [])
    assert res.tree_changed
    assert res.dependencies == []
    module = res.tree
    assert type(module) is ast.Module
    assert module.body == [obj]

# Generated at 2022-06-23 23:35:19.800141
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=None,
                                tree_changed=False,
                                dependencies=None)


# Generated at 2022-06-23 23:35:23.244892
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.Module()
    r = TransformationResult(t, True, ['x', 'y'])
    assert r.tree == t
    assert r.tree_changed == True
    assert r.dependencies == ['x', 'y']

# Generated at 2022-06-23 23:35:25.812391
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=3, time=3.14, target=(3, 5), dependencies=[])
    assert len(result) == 4


# Generated at 2022-06-23 23:35:28.666416
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = 0
    t = 1.0
    target = (3, 0)
    d = ['a.py', 'b.py']
    assert CompilationResult(c, t, target, d)


# Generated at 2022-06-23 23:35:30.947938
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('text.txt'),
                               Path('text_copy.txt'))
    assert input_output.input.name == 'text.txt'
    assert input_output.output.name == 'text_copy.txt'


# Generated at 2022-06-23 23:35:34.276787
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('/tmp/input')
    output_path = Path('/tmp/output')
    input_output = InputOutput(input=input_path, output=output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path


# Generated at 2022-06-23 23:35:37.132499
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=10, time=12, target=(1, 10), dependencies=["a", "b"])
    assert cr.files == 10
    assert cr.time == 12
    assert cr.target == (1, 10)
    assert cr.dependencies == ["a", "b"]


# Generated at 2022-06-23 23:35:39.591977
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = InputOutput(Path('foo'), Path('bar'))
    assert i.input == Path('foo')
    assert i.output == Path('bar')

# Generated at 2022-06-23 23:35:41.573310
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 1.1, (3, 6), ['a'])



# Generated at 2022-06-23 23:35:43.736103
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    with pytest.raises(TypeError):
        CompilationResult(files=42, time=42.0)


# Generated at 2022-06-23 23:35:47.212550
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse("a=1")
    r = TransformationResult(t, False, [])
    assert r.tree == t
    assert not r.tree_changed
    assert r.dependencies == []

# Generated at 2022-06-23 23:35:51.839985
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # given
    tree = ast.Module()
    tree_changed = False
    dependencies = ["dep1", "dep2"]
    # when
    result = TransformationResult(tree, tree_changed, dependencies)
    # then
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-23 23:35:53.673964
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 1.0, (3, 8), [])


# Generated at 2022-06-23 23:35:55.299526
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = InputOutput(Path("/a"), Path("/b"))
    assert a.input == Path("/a")
    assert a.output == Path("/b")

# Generated at 2022-06-23 23:35:58.420683
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('1')
    trans_res = TransformationResult(tree, True, ['a.py'])
    assert trans_res.tree_changed
    assert len(trans_res.dependencies) == 1
    assert trans_res.dependencies[0] == 'a.py'

# Generated at 2022-06-23 23:35:59.446253
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(0, 0, (0, 0), [''])

# Generated at 2022-06-23 23:36:02.815490
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.Module(body=[]), True, [])

    assert(isinstance(tr.tree, ast.AST))
    assert(isinstance(tr.tree_changed, bool))
    assert(isinstance(tr.dependencies, list))

# Generated at 2022-06-23 23:36:07.775375
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=3.14, target=(3, 7), dependencies=['foo', 'bar'])
    assert result.files == 1
    assert result.time == 3.14
    assert result.target == (3, 7)
    assert result.dependencies == ['foo', 'bar']


# Generated at 2022-06-23 23:36:11.737711
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    node = ast.Module()
    assert TransformationResult(tree=node,
                                tree_changed=True,
                                dependencies=[]) == TransformationResult(node, True, [])
    assert TransformationResult(node, True, []).tree is node
    assert TransformationResult(node, True, []).tree_changed


# Generated at 2022-06-23 23:36:18.921633
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(10, 10.0, (3, 4), ["foo.pyx"]).files == 10
    assert CompilationResult(10, 10.0, (3, 4), ["foo.pyx"]).time == 10.0
    assert CompilationResult(10, 10.0, (3, 4), ["foo.pyx"]).target == (3, 4)
    assert CompilationResult(10, 10.0, (3, 4), ["foo.pyx"]).dependencies == ["foo.pyx"]


# Generated at 2022-06-23 23:36:24.664487
# Unit test for constructor of class TransformationResult
def test_TransformationResult():

    tree = ast.parse('1 + 1')
    result = TransformationResult(tree, True, ['foo.py'])
    assert result.tree_changed == True
    assert result.dependencies == ['foo.py']

# Result of transformers validation
ValidationResult = NamedTuple('ValidationResult',
                              [('valid', bool),
                               ('message', str)])


# Generated at 2022-06-23 23:36:27.387030
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p = Path('a')
    i = InputOutput(p, p)
    assert i.input == p
    assert i.output == p


# Generated at 2022-06-23 23:36:31.246583
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CResult = CompilationResult(files=1, time=1.0,
                                target=(3, 5),
                                dependencies=['/tmp/abc/def.py'])
    assert CResult.files == 1
    assert CResult.time == 1.0
    assert CResult.target == (3, 5)
    assert CResult.dependencies == ['/tmp/abc/def.py']



# Generated at 2022-06-23 23:36:32.859186
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(0, 0.0, (0, 0), [])

# Generated at 2022-06-23 23:36:34.819706
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=None,
                                tree_changed=False,
                                dependencies=None)

# Generated at 2022-06-23 23:36:41.306946
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Test correct initilisation
    input_output = InputOutput(Path('README.rst'), Path('dist/README.rst'))
    assert input_output.input == Path('README.rst')
    assert input_output.output == Path('dist/README.rst')
    
    # Test not-possible initalization
    with pytest.raises(AttributeError):
        InputOutput(Path('README.rst'), None)  # type: ignore


# Generated at 2022-06-23 23:36:42.789701
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a'), Path('b')).input == Path('a')


# Generated at 2022-06-23 23:36:46.154427
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path('input.py'), Path('output.py'))

    assert io.input.name == 'input.py'
    assert io.output.name == 'output.py'


# Generated at 2022-06-23 23:36:50.988785
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.FunctionDef(name='foo', args=ast.arguments(args=[]), body=[], decorator_list=[])
    result = TransformationResult(tree=tree,
                                  tree_changed=True,
                                  dependencies=['foo.py'])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == ['foo.py']

# Generated at 2022-06-23 23:36:53.029184
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """ Test if the constructor properly extracts paths """
    tuple_ = InputOutput(Path('in'), Path('out'))
    assert tuple_.input == Path('in')
    assert tuple_.output == Path('out')

# Generated at 2022-06-23 23:36:55.327187
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    v = TransformationResult(None, None, None)

# Result of transformers compilation
Compilation = NamedTuple('Compilation', [('tree', ast.AST),
                                         ('result', CompilationResult),
                                         ('target', CompilationTarget),
                                         ('inputoutput', InputOutput),
                                         ('dependencies', List[str])])


# Generated at 2022-06-23 23:36:59.333848
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert(isinstance(TransformationResult(ast.AST(), True, ['a.py']),
                       TransformationResult))
    assert(TransformationResult(ast.AST(), True, ['a.py']).tree_changed)
    assert(TransformationResult(ast.AST(), False, ['a.py']).tree_changed)

# Generated at 2022-06-23 23:37:03.881950
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 1.0, (3, 5), ['foo'])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 5)
    assert result.dependencies == ['foo']


# Generated at 2022-06-23 23:37:05.796111
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(ast.parse('a = 1'), True, [])
    assert result.tree is not None
    assert result.tree_changed is True
    assert result.dependencies is not None


# Generated at 2022-06-23 23:37:11.443611
# Unit test for constructor of class CompilationResult
def test_CompilationResult():  # type: () -> None
    comp = CompilationResult(files=1, time=1.0, target=(3,7), dependencies=[])
    assert isinstance(comp, CompilationResult)
    assert isinstance(comp.files, int)
    assert isinstance(comp.time, float)
    assert comp.files == 1
    assert comp.time == 1.0
    assert comp.target == (3,7)
    assert comp.dependencies == []


# Generated at 2022-06-23 23:37:14.383224
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Input/output pair
    inp = Path('/some/random/path')
    outp = Path('/some/random/path/to/output')
    inp_out = InputOutput(inp, outp)

    assert inp_out.input == inp
    assert inp_out.output == outp

# Generated at 2022-06-23 23:37:17.872393
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    param1 = 42
    param2 = 3.14
    param3 = (3, 7)
    param4 = ["from math import pi"]
    res = CompilationResult(files=param1,
                            time=param2,
                            target=param3,
                            dependencies=param4)
    assert res.files == param1 and res.time == param2 and res.target == param3 and res.dependencies == param4


# Generated at 2022-06-23 23:37:22.924457
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path(__file__)
    output = Path(__file__ + '.out')
    input_output = InputOutput(input, output)
    assert input in input_output
    assert output in input_output
    assert input_output[0] == input
    assert input_output[1] == output


# Generated at 2022-06-23 23:37:25.105020
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.AST(), False, [])
    assert TransformationResult(ast.AST(), True, ["Hello", "World"])

# Generated at 2022-06-23 23:37:33.043904
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_tree = ast.parse("")

    res1 = TransformationResult(ast_tree, False, [])
    res2 = TransformationResult(ast_tree, True, [])
    res3 = TransformationResult(ast_tree, False, ["foo"])
    res4 = TransformationResult(ast_tree, True, ["foo"])

    assert isinstance(res1, TransformationResult)
    assert isinstance(res2, TransformationResult)
    assert isinstance(res3, TransformationResult)
    assert isinstance(res4, TransformationResult)

    assert res1.tree_changed == False
    assert res2.tree_changed == True
    assert res3.tree_changed == False
    assert res4.tree_changed == True

    assert res1.dependencies == []
    assert res2.dependencies == []

# Generated at 2022-06-23 23:37:36.084429
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('foo.in'),
                       Path('foo.out')) ==\
           InputOutput(input=Path('foo.in'),
                       output=Path('foo.out'))


# Generated at 2022-06-23 23:37:38.297304
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=0, time=0.0, target=(0, 0), dependencies=[])


# Generated at 2022-06-23 23:37:40.634267
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = InputOutput('foo', 'bar')
    assert a.input == Path('foo')
    assert a.output == Path('bar')


# Generated at 2022-06-23 23:37:46.019567
# Unit test for constructor of class InputOutput
def test_InputOutput():
    with pytest.raises(AssertionError):
        InputOutput(1, Path('foo'))
    with pytest.raises(AssertionError):
        InputOutput(Path('foo'), 1)
    with pytest.raises(AssertionError):
        InputOutput(None, Path('foo'))
    with pytest.raises(AssertionError):
        InputOutput(Path('foo'), None)
    assert InputOutput(Path('foo'), Path('bar'))

# Generated at 2022-06-23 23:37:48.899050
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('')
    tree_changed = True
    dependencies = ['foo']

    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree is tree
    assert result.tree_changed is tree_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-23 23:37:51.688686
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-23 23:37:55.859815
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = None
    tree_changed = False
    dependencies = []
    trans_result = TransformationResult(tree, tree_changed, dependencies)
    assert(trans_result.tree is None)
    assert(not trans_result.tree_changed)
    assert(trans_result.dependencies == [])

# Generated at 2022-06-23 23:37:57.934488
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(Path("data.txt"), Path("data_compiled.txt"))



# Generated at 2022-06-23 23:38:01.972388
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.parse('a'), True, [])
    assert isinstance(tr.tree, ast.AST)
    assert tr.tree_changed is True
    assert isinstance(tr.dependencies, list)
    assert len(tr.dependencies) == 0

# Generated at 2022-06-23 23:38:04.748404
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(
        files=3,
        time=0.01,
        target=(3, 5),
        dependencies=['foo']
    )
    assert c.files == 3.0
    assert c.time == 0.01
    assert c.target == (3, 5)
    assert c.dependencies == ['foo']


# Generated at 2022-06-23 23:38:07.384362
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(0, 0, (3, 6), [])
    assert cr.files == 0
    assert cr.time == 0
    assert cr.target == (3, 6)
    assert cr.dependencies == []


# Generated at 2022-06-23 23:38:10.775935
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # a = InputOutput("x.py", "y.py")
    a = InputOutput(Path("x.py"), Path("y.py"))
    assert a.input == "x.py"
    assert a.output == "y.py"

# Generated at 2022-06-23 23:38:18.287365
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('input'), Path('output')) == \
           InputOutput(Path('input'), Path('output'))
    assert InputOutput(Path('input'), Path('output')) == \
           InputOutput('input', 'output')
    assert InputOutput(Path('input'), Path('output')) != \
           InputOutput('input', 'output2')
    assert InputOutput(Path('input'), Path('output')) != \
           InputOutput('input2', 'output')
    assert InputOutput(Path('input'), Path('output')) != \
           InputOutput('input2', 'output2')
    assert InputOutput(Path('input'), Path('output')).input == \
           InputOutput('input', 'output').input


# Generated at 2022-06-23 23:38:21.062908
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    """Test of class TransformationResult"""
    tr = TransformationResult(ast.AST(), False, [])
    assert tr.tree_changed == False
    assert tr.dependencies == []

# Generated at 2022-06-23 23:38:24.746933
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(0, 0.0, (0, 0), [])
    assert cr.files == 0
    assert cr.time == 0.0
    assert cr.target == (0, 0)
    assert cr.dependencies == []


# Generated at 2022-06-23 23:38:29.380006
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=12, time=2.0,
                                           target=(3, 7), dependencies=[])
    assert compilation_result.files == 12
    assert compilation_result.time == 2.0
    assert compilation_result.target == (3, 7)
    assert compilation_result.dependencies == []



# Generated at 2022-06-23 23:38:30.106437
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2.0, (3, 4), [])

# Generated at 2022-06-23 23:38:37.277937
# Unit test for constructor of class TransformationResult
def test_TransformationResult(): # type: () -> None
    t = TransformationResult(ast.parse("pass"), False, ["foo.py"])
    assert t.tree is not None
    assert not t.tree_changed
    assert t.dependencies == ["foo.py"]

# The Pytype entity (class, function, etc.) the error was found on
PytypeEntity = str

# An error detected by Pytype
PytypeError = NamedTuple('PytypeError',
                         [('message', str),
                          ('lineno', int),
                          ('col_offset', int),
                          ('text', str),
                          ('node', PytypeEntity)])

# Question/answer pair for a PytypeError
QAPair = NamedTuple('QAPair',
                    [('question', str),
                     ('answer', str)])


# Generated at 2022-06-23 23:38:41.413972
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('test.txt')
    out = Path('test.html')
    i_o = InputOutput(inp, out)
    assert(i_o.input == inp)
    assert(i_o.output == out)



# Generated at 2022-06-23 23:38:45.485870
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.Assign(targets=[], value=None), True, [])
    assert tr.tree == ast.Assign(targets=[], value=None)
    assert tr.tree_changed == True
    assert tr.dependencies == []

# Generated at 2022-06-23 23:38:50.135232
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(1, 2.0, (3, 4), ['dependency'])
    assert compilation_result.files == 1
    assert compilation_result.time == 2.0
    assert compilation_result.target == (3, 4)
    assert compilation_result.dependencies == ['dependency']


# Generated at 2022-06-23 23:38:53.120770
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=ast.AST(),
                              tree_changed=True,
                              dependencies=[])
    assert tr.tree is not None
    assert tr.tree_changed is True
    assert len(tr.dependencies) == 0

# Generated at 2022-06-23 23:38:57.277376
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(
        tree = ast.parse('x = 1'),
        tree_changed = False,
        dependencies = ['file1.py', 'file2.py']
    )
    assert isinstance(tr, TransformationResult)
    assert tr.tree is not None
    assert not tr.tree_changed
    assert tr.dependencies == ['file1.py', 'file2.py']


# Generated at 2022-06-23 23:39:00.407342
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_obj = ast.parse('pass')
    res = TransformationResult(ast_obj, True, ['d1'])
    assert res.tree == ast_obj
    assert res.tree_changed
    assert res.dependencies == ['d1']
    res = TransformationResult(ast_obj, False, ['d1'])
    assert not res.tree_changed

# Generated at 2022-06-23 23:39:01.120119
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.Module(), True, ['a'])

# Generated at 2022-06-23 23:39:03.273089
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('src/file'), Path('bin/file'))


# Generated at 2022-06-23 23:39:09.370421
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=42,
                               time=1.0,
                               target=(3, 7),
                               dependencies=['a', 'b', 'c'])
    assert result.files == 42
    assert result.time == 1.0
    assert result.target == (3, 7)
    assert result.dependencies == ['a', 'b', 'c']


# Generated at 2022-06-23 23:39:13.207367
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path(__file__)
    output = Path(__file__)
    io = InputOutput(input=input_, output=output)
    assert io.input == input_
    assert io.output == output


# Generated at 2022-06-23 23:39:14.793087
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Just to make it PEP8 compliant
    assert InputOutput


# Generated at 2022-06-23 23:39:20.068763
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1,
                           time=0.1,
                           target=(3, 8),
                           dependencies=["foo", "bar", "baz"])
    assert cr.files == 1
    assert cr.time == 0.1
    assert cr.target == (3, 8)
    assert cr.dependencies == ["foo", "bar", "baz"]


# Generated at 2022-06-23 23:39:23.261827
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('pass')
    r = TransformationResult(t, False, [])
    assert r.tree == t
    assert not r.tree_changed
    assert not r.dependencies

# Generated at 2022-06-23 23:39:29.014243
# Unit test for constructor of class InputOutput
def test_InputOutput():
    import pytest
    p = InputOutput(Path("a"), Path("b"))
    assert p.input == Path("a")
    assert p.output == Path("b")
    with pytest.raises(TypeError):
        p = InputOutput("a", Path("b"))
    with pytest.raises(TypeError):
        p = InputOutput(Path("a"), "b")


# Generated at 2022-06-23 23:39:32.076250
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(
        ast.Module(), False, []).tree_changed is False
    assert TransformationResult(
        ast.Module(), True, []).tree_changed is True

# Generated at 2022-06-23 23:39:35.178677
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    cls = TransformationResult(ast.AST, False, [])
    assert isinstance(cls.tree_changed, bool), \
        "tree_changed must be a boolean"


# Generated at 2022-06-23 23:39:38.003522
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_tree = ast.parse('# Dummy code')
    tree_changed = True
    dependencies = []
    TransformationResult(ast_tree, tree_changed, dependencies)

# Generated at 2022-06-23 23:39:41.343198
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input_name.py')
    output = Path('output_name.py')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-23 23:39:42.549844
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('foo.py'), Path('out.c'))

# Generated at 2022-06-23 23:39:44.094512
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = "foo"
    output = "bar"
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-23 23:39:47.077319
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    """Unit test for CompilationResult class"""
    CompilationResult(files=8, time=0.1, target=(3, 6),
                      dependencies=['a.py', 'b.py'])

# Generated at 2022-06-23 23:39:52.538630
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    now = 42.0
    target = (3, 6)
    dependencies = ['a', 'b', 'c']

    result = CompilationResult(files=1, time=now, target=target,
                               dependencies=dependencies)

    assert result.files == 1
    assert result.time == now
    assert result.target == target
    assert result.dependencies == dependencies


# Generated at 2022-06-23 23:39:57.331136
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=1,
                            time=20,
                            target=(3, 5),
                            dependencies=['a'])
    assert res.files == 1
    assert res.time == 20
    assert res.target == (3, 5)
    assert res.dependencies == ['a']


# Generated at 2022-06-23 23:40:05.730800
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Valid
    assert InputOutput(Path('in/'), Path('out/'))
    assert InputOutput(Path('in/f.py'), Path('out/f.py'))
    assert InputOutput(Path('in/f.py'), Path('out/f.pyc'))
    assert InputOutput(Path('in/f.py'), Path('out/f.pyo'))

    # Not valid
    with pytest.raises(AssertionError):
        InputOutput(Path('in/f.py'), Path('out/'))
    with pytest.raises(AssertionError):
        InputOutput(Path('in/'), Path('out/f.py'))
    with pytest.raises(AssertionError):
        InputOutput(Path('in/f.py'), Path('out/f.pyx'))

# Generated at 2022-06-23 23:40:07.191919
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(0, 0.0, (0, 0), [])

# Generated at 2022-06-23 23:40:10.575586
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path("input.txt"), Path("output.txt"))
    with pytest.raises(TypeError):
        InputOutput("input.txt", "output.txt")

# Generated at 2022-06-23 23:40:16.344929
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    t = TransformationResult(tree, True, ["dependency"])
    assert t.tree_changed
    assert t.tree == tree
    assert t.dependencies == ["dependency"]

# Result of a single transformer
TransformerResult = NamedTuple('TransformerResult',
                               [('results', List[TransformationResult]),
                                ('tree_changed', bool)])


# Generated at 2022-06-23 23:40:18.360334
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=0.1, target=(3, 5), dependencies=['a', 'b'])


# Generated at 2022-06-23 23:40:21.630974
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree  = 'Mock'
    flag  = False
    deps  = []
    result = TransformationResult(tree, flag, deps)
    assert result.tree == tree
    assert result.tree_changed == flag
    assert result.dependencies == deps

# Generated at 2022-06-23 23:40:27.652868
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 10
    time = 20.0
    target = (3, 7)
    dependencies = ["os", "sys", "collections"]

    result = CompilationResult(files, time, target, dependencies)
    assert isinstance(result.files, int)
    assert isinstance(result.time, float)
    assert isinstance(result.target, CompilationTarget)
    assert isinstance(result.dependencies, list)



# Generated at 2022-06-23 23:40:30.441648
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-23 23:40:38.968853
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 0.0, (2, 5), ['/path/to/dep_1', '/path/to/dep_2']).files == 1
    assert CompilationResult(1, 0.0, (2, 5), ['/path/to/dep_1', '/path/to/dep_2']).time == 0.0
    assert CompilationResult(1, 0.0, (2, 5), ['/path/to/dep_1', '/path/to/dep_2']).target == (2, 5)
    assert CompilationResult(1, 0.0, (2, 5), ['/path/to/dep_1', '/path/to/dep_2']).dependencies == ['/path/to/dep_1', '/path/to/dep_2']

# Generated at 2022-06-23 23:40:39.740823
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, False, [])

# Generated at 2022-06-23 23:40:50.629590
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 1.0, (3, 0), ['a']) == CompilationResult(1, 1.0, (3, 0), ['a'])
    assert CompilationResult(1, 1.0, (3, 0), ['a']) != CompilationResult(2, 1.0, (3, 0), ['a'])
    assert CompilationResult(1, 1.0, (3, 0), ['a']) != CompilationResult(1, 2.0, (3, 0), ['a'])
    assert CompilationResult(1, 1.0, (3, 0), ['a']) != CompilationResult(1, 1.0, (3, 1), ['a'])

# Generated at 2022-06-23 23:40:56.002826
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=32,
                               time=0.5,
                               target=(2, 4),
                               dependencies=['abc', 'def'])
    assert result.files == 32
    assert result.time == 0.5
    assert result.target == (2, 4)
    assert result.dependencies == ['abc', 'def']


# Generated at 2022-06-23 23:40:58.547168
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=0.0, target=[2, 7],
                           dependencies=[])
    assert isinstance(cr, CompilationResult)


# Generated at 2022-06-23 23:41:03.880595
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.0, target=(3, 5),
                               dependencies=['foo.py', 'bar.py'])
    assert result.files == 1
    assert result.time == 0.0
    assert result.target == (3, 5)
    assert result.dependencies == ['foo.py', 'bar.py']



# Generated at 2022-06-23 23:41:08.661515
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.2, target=(3, 5),
                               dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 1.2
    assert result.target == (3, 5)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:41:13.298954
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=10, time=0.23, target=(3, 7),
                            dependencies=['a.py', 'b.py'])
    assert(res.files == 10)
    assert(res.time == 0.23)
    assert(res.target == (3, 7))
    assert(res.dependencies == ['a.py', 'b.py'])


# Generated at 2022-06-23 23:41:14.938385
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    import sys
    assert TransformationResult(
        ast.parse(sys.version),
        False,
        [])

# Generated at 2022-06-23 23:41:18.107951
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(0, 0, (0, 0), [])
    assert c.files == 0
    assert c.time == 0
    assert c.target == (0, 0)
    assert c.dependencies == []


# Generated at 2022-06-23 23:41:19.655845
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 1.0, (2, 3), ['a', 'b'])


# Generated at 2022-06-23 23:41:22.152040
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('input')
    o = Path('output')
    io = InputOutput(i, o)
    assert io.input == i
    assert io.output == o



# Generated at 2022-06-23 23:41:27.688260
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=1, time=2, target=(3, 4), dependencies=[])
    assert isinstance(res.files, int)
    assert isinstance(res.time, float)
    assert isinstance(res.target, tuple)
    assert isinstance(res.target[0], int)
    assert isinstance(res.target[1], int)
    assert isinstance(res.dependencies, list)
    assert res.files == 1
    assert res.time == 2
    assert res.target == (3, 4)
    assert res.dependencies == []

# Generated at 2022-06-23 23:41:30.848119
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    r = TransformationResult(tree=None, tree_changed=False, dependencies=None)
    assert r.tree is None
    assert r.tree_changed is False
    assert r.dependencies is None

# Generated at 2022-06-23 23:41:36.201572
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compiler = CompilationResult(files = 1, time = 1.0,
                                 target = (3, 7),
                                 dependencies = ['./a/b.py'])
    assert compiler.files == 1
    assert compiler.time == 1.0
    assert compiler.target == (3, 7)
    assert compiler.dependencies == ['./a/b.py']


# Generated at 2022-06-23 23:41:41.210462
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # noinspection PyArgumentList
    input_output = InputOutput(input='input_file.py',
                               output='output_file.py')
    assert input_output.input == Path('input_file.py')
    assert input_output.output == Path('output_file.py')

# Generated at 2022-06-23 23:41:46.983525
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    a = ast.Module()
    b = TransformationResult(a, True, [])
    assert b.tree is a
    assert b.tree_changed


# Performance result from running a test
PerformanceResult = NamedTuple('PerformanceResult',
                               [('name', str),
                                ('time', float)])



# Generated at 2022-06-23 23:41:49.138260
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i, o = Path('file.py'), Path('file.pyc')
    assert InputOutput(i, o) == (InputOutput(i, o))



# Generated at 2022-06-23 23:41:50.836557
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.Module([])
    assert TransformationResult(tree=t, tree_changed=True, dependencies=[])



# Generated at 2022-06-23 23:41:54.458752
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type:() -> None
    a = TransformationResult(tree=ast.AST(),
                             tree_changed=True,
                             dependencies=[])
    assert isinstance(a.tree, ast.AST)
    assert isinstance(a.tree_changed, bool)
    assert isinstance(a.dependencies, list)

# Generated at 2022-06-23 23:41:55.703240
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(Path('test'), Path('test2'))



# Generated at 2022-06-23 23:41:57.781643
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(
        files=1,
        time=0.01,
        target=(3, 5),
        dependencies=['foo.py']) is not None



# Generated at 2022-06-23 23:42:01.682631
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=0.1,
                               target=(3, 7),
                               dependencies=['abs.py', 'foo.py'])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 7)
    assert result.dependencies == ['abs.py', 'foo.py']


# Generated at 2022-06-23 23:42:04.205516
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    pass


__all__ = [
    'CompilationTarget',
    'CompilationResult',
    'InputOutput',
    'TransformationResult',
    'test_TransformationResult',
]