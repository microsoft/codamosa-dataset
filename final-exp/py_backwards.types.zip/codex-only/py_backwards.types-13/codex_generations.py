

# Generated at 2022-06-23 23:32:03.756852
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = InputOutput(Path('a'), Path('b'))
    assert inp.input == Path('a')
    assert inp.output == Path('b')


# Generated at 2022-06-23 23:32:05.720999
# Unit test for constructor of class InputOutput
def test_InputOutput(): # type: ignore
    assert InputOutput('/a.py', '/x.py') == InputOutput(Path('/a.py'), Path('/x.py'))

# Generated at 2022-06-23 23:32:14.718716
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # CompilationTarget has a pair of positive ints
    assert InputOutput(Path('a'), Path('b')).input.name == 'a'
    assert InputOutput(Path('a'), Path('b')).output.name == 'b'
    assert InputOutput('a', 'b').input.name == 'a'
    assert InputOutput('a', 'b').output.name == 'b'
    assert InputOutput(Path('a'), 'b').input.name == 'a'
    assert InputOutput(Path('a'), 'b').output.name == 'b'
    assert InputOutput('a', Path('b')).input.name == 'a'
    assert InputOutput('a', Path('b')).output.name == 'b'


# Generated at 2022-06-23 23:32:18.727692
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse('a = 1'), False, [])
    assert TransformationResult(ast.parse('a = 1'), True, [])
    assert TransformationResult(ast.parse('a = 1'), False, ['b'])
    assert TransformationResult(ast.parse('a = 1'), True, ['b'])

# Generated at 2022-06-23 23:32:20.949958
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p = Path('/user/path/file.txt')
    in_out = InputOutput(p, p)
    assert in_out.input == in_out.output

# Generated at 2022-06-23 23:32:22.399724
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i, o = Path('input.txt'), Path('output.txt')
    InputOutput(i, o)


# Generated at 2022-06-23 23:32:24.504632
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(input=Path('a'), output=Path('b'))
    assert io.input == Path('a')
    assert io.output == Path('b')

# Generated at 2022-06-23 23:32:28.009407
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=0.0,
                               target=(3, 6),
                               dependencies=['a', 'b', 'c'])


# Generated at 2022-06-23 23:32:30.972791
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('test.py'), Path()).input == Path('test.py')
    assert InputOutput(Path('test.py'), Path()).output == Path()

# Generated at 2022-06-23 23:32:34.613500
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=2, target=(3, 4), dependencies=[])
    assert cr.files == 1
    assert cr.time == 2
    assert cr.target == (3, 4)
    assert cr.dependencies == []


# Generated at 2022-06-23 23:32:37.313418
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('test.py')
    output = Path('test.pyc')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output

# Generated at 2022-06-23 23:32:42.730060
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=2, time=1.2, target=(3, 4), dependencies=['hello', 'world'])
    assert cr.files == 2
    assert cr.time == 1.2
    assert cr.target == (3, 4)
    assert isinstance(cr.dependencies, list)
    assert cr.dependencies == ['hello', 'world']


# Generated at 2022-06-23 23:32:46.438092
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path('file1.txt')
    path2 = Path('file2.txt')
    input_output = InputOutput(path1, path2)
    assert input_output.input is path1
    assert input_output.output is path2


# Generated at 2022-06-23 23:32:47.764452
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2.0, (3, 4), [])

# Generated at 2022-06-23 23:32:50.155087
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_path = Path('test')
    input_output = InputOutput(test_path, test_path)
    assert input_output.input == test_path
    assert input_output.output == test_path

# Generated at 2022-06-23 23:32:51.597687
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=0, time=0., target=(2, 7), dependencies=[])


# Generated at 2022-06-23 23:32:55.645463
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=10,
                                           time=1.0,
                                           target=(3, 6),
                                           dependencies=['abc', 'def'])
    assert compilation_result.files == 10
    assert compilation_result.time == 1.0
    assert compilation_result.target == (3, 6)
    assert compilation_result.dependencies == ['abc', 'def']



# Generated at 2022-06-23 23:32:56.335913
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput('input', 'output')


# Generated at 2022-06-23 23:32:59.396379
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_input = Path('a/b/c/d.txt')
    test_output = Path('e/f/g.txt')
    test_io = InputOutput(test_input, test_output)
    assert test_io.input == test_input
    assert test_io.output == test_output


# Generated at 2022-06-23 23:33:01.761413
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    dependencies = ['a', 'b']
    result = TransformationResult(ast.Module(), True, dependencies)
    assert result.tree_changed == True
    assert result.dependencies == dependencies

# Generated at 2022-06-23 23:33:05.275826
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=[])
    assert compilation_result.files == 1
    assert compilation_result.time == 2.0
    assert compilation_result.target == (3, 4)
    assert compilation_result.dependencies == []

# Generated at 2022-06-23 23:33:08.274627
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('a')
    output = input / 'b'
    x = InputOutput(input, output)
    assert x.input == input
    assert x.output == output

# Generated at 2022-06-23 23:33:11.493389
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path('./a.py'), Path('b.py'))
    assert io.input == Path('./a.py')
    assert io.output == Path('b.py')

# Generated at 2022-06-23 23:33:18.067006
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(ast.parse('x = 1\n'), False, ['a', 'b', 'c'])
    assert isinstance(t, TransformationResult)
    assert isinstance(t.tree, ast.AST)
    assert isinstance(t.tree_changed, bool)
    assert isinstance(t.dependencies, list)
    assert isinstance(t[0], ast.AST)
    assert isinstance(t[1], bool)
    assert isinstance(t[2], list)
    assert t.tree_changed == t[1]
    assert t.dependencies == t[2]

# Generated at 2022-06-23 23:33:22.060379
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ll = []
    result = TransformationResult(ast.Module(), False, ll)
    assert result.tree == ast.Module()
    assert result.tree_changed == False
    assert result.dependencies == ll


# Transformation function
TransformerFn = Callable[[ast.AST], TransformationResult]

# Generated at 2022-06-23 23:33:26.958901
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=1,
                            time=2.0,
                            target=(3, 4),
                            dependencies=['5'])
    assert res.files == 1
    assert res.time == 2.0
    assert res.target == (3, 4)
    assert res.dependencies == ['5']



# Generated at 2022-06-23 23:33:28.836820
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = InputOutput(Path("a"), Path("b"))
    assert a.input == Path("a")
    assert a.output == Path("b")

# Generated at 2022-06-23 23:33:32.256895
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(
        files=1,
        time=1.2,
        target=(3, 7),
        dependencies=['foo.py']
    )

    assert cr.files == 1
    assert cr.time == 1.2
    assert cr.target == (3, 7)
    assert cr.dependencies == ['foo.py']


# Generated at 2022-06-23 23:33:36.187609
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    """Unit test for constructor of class TransformationResult."""
    t = ast.parse('import sys')
    result = TransformationResult(tree=t, tree_changed=True, dependencies=['sys'])
    assert result.tree is t
    assert result.tree_changed is True
    assert result.dependencies == ['sys']

# Generated at 2022-06-23 23:33:45.064602
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree_0 = ast.parse("1 + 2", "<input>", "eval")
    tree_1 = ast.parse("1 + 2", "<input>", "eval")
    assert (tree_0 == tree_1)

    # Tree changed
    result = TransformationResult(tree_0, True, [])
    assert result.tree_changed
    assert not result.tree_changed

    # Tree not changed
    result = TransformationResult(tree_0, False, [])
    assert not result.tree_changed
    assert not result.tree_changed

    # Equality
    result_eq = TransformationResult(tree_0, False, [])
    result_ne = TransformationResult(tree_1, False, ["foo"])
    assert result == result_eq
    assert result != result_ne

    # Tree changed after reassignment

# Generated at 2022-06-23 23:33:48.695473
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Arrange
    inp = 'input.txt'
    out = 'output.txt'

    # Act
    result = InputOutput(inp, out)

    # Assert
    assert result.input == Path('input.txt')
    assert result.output == Path('output.txt')

# Generated at 2022-06-23 23:33:51.177504
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.Module()
    res = TransformationResult(tree, False, [])
    assert res.tree == tree
    assert not res.tree_changed
    assert res.dependencies == []

# Generated at 2022-06-23 23:33:54.379682
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path("input/file")
    outp = Path("output/file")
    input_output = InputOutput(inp, outp)
    assert input_output.input == inp
    assert input_output.output == outp

# Generated at 2022-06-23 23:33:57.371757
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = InputOutput(Path('foo'), Path('bar'))
    assert repr(a) == "InputOutput(input='foo', output='bar')"
    assert str(a) == "InputOutput(input='foo', output='bar')"


# Generated at 2022-06-23 23:33:59.158127
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(5, 0.5, (3, 6), ['foo', 'bar'])


# Generated at 2022-06-23 23:34:00.219027
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert isinstance(TransformationResult(None, None, None),
                      TransformationResult)

# Generated at 2022-06-23 23:34:01.943691
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = 'test.py'
    output = 'test-compiled.py'
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output

# Generated at 2022-06-23 23:34:04.600509
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=1, time=10, target=(3, 6), dependencies=[])
    assert res.files == 1
    assert res.time == 10
    assert res.target == (3, 6)
    assert res.dependencies == []


# Generated at 2022-06-23 23:34:07.112760
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    r = TransformationResult(None, None, None)
    assert r.tree is None
    assert r.tree_changed is None
    assert r.dependencies is None

# Generated at 2022-06-23 23:34:09.233188
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = InputOutput(Path('foo'), Path('bar'))
    assert i.input == Path('foo')
    assert i.output == Path('bar')


# Generated at 2022-06-23 23:34:12.484448
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=2.0, target=(36, 0), dependencies=['foo', 'bar'])
    assert(result.files == 1)
    assert(result.time == 2.0)
    assert(result.target == (36, 0))
    assert(result.dependencies == ['foo', 'bar'])

# Generated at 2022-06-23 23:34:16.188754
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=42, time=12.345,
                            target=(3, 7),
                            dependencies=["a.py", "b.py"])

    assert res.files == 42
    assert res.time == 12.345
    assert res.target == (3, 7)
    assert res.dependencies == ["a.py", "b.py"]


# Generated at 2022-06-23 23:34:24.464912
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=10,
                               time=0.2,
                               target=(3, 8),
                               dependencies=['a.py', 'b.py'])
    assert isinstance(result, CompilationResult)
    assert isinstance(result.files, int)
    assert isinstance(result.time, float)
    assert isinstance(result.target, CompilationTarget)
    assert isinstance(result.dependencies, list)
    assert result.files == 10
    assert result.time == 0.2
    assert result.target == (3, 8)
    assert result.dependencies == ['a.py', 'b.py']
    assert isinstance(repr(result), str)


# Generated at 2022-06-23 23:34:29.349370
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output
    assert not input_output.tree_changed
    assert not input_output.dependencies


# Generated at 2022-06-23 23:34:31.496094
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_tree = Empty()
    assert type(TransformationResult(ast_tree, True, [])) is TransformationResult
    assert TransformationResult(ast_tree, True, []).tree is ast_tree

# Generated at 2022-06-23 23:34:34.263101
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('my_input.py')
    output_path = Path('my_output.py')
    input_output = InputOutput(input=input_path, output=output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path



# Generated at 2022-06-23 23:34:37.249939
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('a')
    o = Path('b')
    x = InputOutput(i, o)
    assert x.input is i and x.output is o


# Generated at 2022-06-23 23:34:42.538618
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=10,
                                           time=0.1,
                                           target=(2, 7),
                                           dependencies=[])
    assert compilation_result.__class__ == CompilationResult
    assert compilation_result.files == 10
    assert compilation_result.time == 0.1
    assert compilation_result.target == (2, 7)
    assert compilation_result.dependencies == []


# Generated at 2022-06-23 23:34:46.877098
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 2.1, (3, 4), ["a.py"])
    assert result.files == 1
    assert result.time == 2.1
    assert result.target == (3, 4)
    assert result.dependencies == ["a.py"]


# Generated at 2022-06-23 23:34:52.375138
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t1 = ast.parse("")
    t2 = ast.parse("")
    tr1 = TransformationResult(t1, True, [])
    tr2 = TransformationResult(t2, False, [])
    assert tr1.tree == t1
    assert tr1.tree_changed
    assert tr1.dependencies == []
    assert tr2.tree == t2
    assert not tr2.tree_changed
    assert tr2.dependencies == []

# Generated at 2022-06-23 23:34:53.576420
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.parse('1'), True, ['foo.py'])

# Generated at 2022-06-23 23:34:58.379953
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=['foo', 'bar'])
    assert result[0] == 1
    assert result[1] == 2.0
    assert result[2] == (3, 4)
    assert result[3] == ['foo', 'bar']


# Generated at 2022-06-23 23:35:00.140245
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=None, tree_changed=False, dependencies=[])
    assert tr.dependencies == []

# Generated at 2022-06-23 23:35:03.826816
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    res = TransformationResult(None, True, [])
    assert isinstance(res.tree, ast.AST)
    assert isinstance(res.tree_changed, bool)
    assert isinstance(res.dependencies, list)



# Generated at 2022-06-23 23:35:06.048872
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('../file.py')
    output = Path('../file.pyc')
    InputOutput(input, output)

# Generated at 2022-06-23 23:35:13.689944
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    r = TransformationResult(None, None, None)
    assert r.tree is None
    assert r.tree_changed is None
    assert r.dependencies is None

# Information about a single file compilation
FileCompilation = NamedTuple('FileCompilation',
                             [('input', Path),
                              ('input_size', int),
                              ('output', Path),
                              ('output_size', int),
                              ('time', float),
                              ('target', CompilationTarget),
                              ('dependencies', List[str])])

# Information about transformations
TransformationReport = NamedTuple('TransformationReport',
                                  [('difference', Path),
                                   ('time', float)])

# Information about a single file transformation

# Generated at 2022-06-23 23:35:18.612472
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cres = CompilationResult(files=1, time=2, target=(2, 6),
                             dependencies=['a', 'b'])
    assert cres.files == 1
    assert cres.time == 2
    assert cres.target == (2, 6)
    assert cres.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:35:22.573061
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_file = Path('input.py')
    output_file = Path('out.py')
    inp_out = InputOutput(input_file, output_file)

    assert inp_out.input == input_file
    assert inp_out.output == output_file

# Generated at 2022-06-23 23:35:30.300512
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.Str(s='test'), False, [])

# All supported types
SupportedTypes = NamedTuple('SupportedTypes',
                            [('int', str),
                             ('bytes', str),
                             ('bytearray', str),
                             ('complex', str),
                             ('float', str),
                             ('bool', str),
                             ('str', str),
                             ('unicode', str),
                             ('list', str),
                             ('dict', str),
                             ('tuple', str),
                             ('set', str),
                             ('frozenset', str)])



# Generated at 2022-06-23 23:35:32.737915
# Unit test for constructor of class InputOutput
def test_InputOutput():
    x = InputOutput('input/path.py', 'output/path.py')
    assert x.input == Path('input/path.py')
    assert x.output == Path('output/path.py')

# Generated at 2022-06-23 23:35:35.853908
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=2.0, target=(3, 4),
                               dependencies=['d'])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == ['d']


# Generated at 2022-06-23 23:35:41.420297
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 2, (3, 4), [])
    assert CompilationResult(1, 2, (3, 4), ['a.py'])
    assert CompilationResult(1, 2, (3, 4), ['a.py', 'b.py'])
    assert CompilationResult(1, 2, (3, 4), ['a.py', 'b.py', 'c.py'])

# Generated at 2022-06-23 23:35:43.595471
# Unit test for constructor of class InputOutput
def test_InputOutput():
    try:
        InputOutput(Path("a"),
                    Path("b"))
    except Exception:
        assert(False)


# Generated at 2022-06-23 23:35:45.837728
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=0.0, target=(3, 8), dependencies=[])

# Generated at 2022-06-23 23:35:51.697687
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('inp')
    out = Path('out')
    in_out = InputOutput(inp, out)
    assert in_out.input == inp
    assert in_out.output == out
    assert in_out.input != out
    assert in_out.output != inp

if __name__ == '__main__':
    import pytest
    pytest.main(['-v', __file__])

# Generated at 2022-06-23 23:36:00.123208
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.Module(), True, ['']).tree_changed == True

# Entry points in AST nodes
EntryPoint = NamedTuple('EntryPoint', [('node', ast.AST),
                                       ('is_callable', bool)])

# Entry point in AST node with additional position information
EntryPointWithPosition = NamedTuple('EntryPointWithPosition',
                                    [('entry_point', EntryPoint),
                                     ('file', Path),
                                     ('line', int),
                                     ('column', int),
                                     ('source_code', str)])

# Entry points in AST nodes with additional position information
EntryPointsWithPosition = List[EntryPointWithPosition]

# AST node with additional position information

# Generated at 2022-06-23 23:36:04.271448
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('some/input.py')
    output = Path('some/output.py')
    input_output = InputOutput(input_, output)
    assert input_output.input == input_
    assert input_output.output == output


# Generated at 2022-06-23 23:36:14.724334
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Type checking
    CompilationResult(files=1, time=2.0, target=(1, 2), dependencies=[])
    # Value checking
    with pytest.raises(ValueError):
        CompilationResult(files=-1, time=2.0, target=(1, 2), dependencies=[])
    with pytest.raises(ValueError):
        CompilationResult(files=1, time=-2.0, target=(1, 2), dependencies=[])
    with pytest.raises(ValueError):
        CompilationResult(files=1, time=2.0, target=(1, -2), dependencies=[])
    with pytest.raises(ValueError):
        CompilationResult(files=1, time=2.0, target=(1, 2),
                          dependencies=None)


# Generated at 2022-06-23 23:36:17.616742
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Execution
    input_output = InputOutput(input='input', output='output')

    # Verification
    assert input_output.input == 'input'
    assert input_output.output == 'output'


# Generated at 2022-06-23 23:36:20.002964
# Unit test for constructor of class InputOutput
def test_InputOutput():
    x = InputOutput(input='aaa', output='bbb')
    assert x.input == Path('aaa')
    assert x.output == Path('bbb')


# Generated at 2022-06-23 23:36:21.732283
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(10, 0.5, (2, 6), ["/a/file.py", "/another/file.py"])


# Generated at 2022-06-23 23:36:26.083301
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('a/b/c.py'), Path('a/b/c.js'))
    assert input_output.input.name == 'c.py'
    assert input_output.output.name == 'c.js'


# Generated at 2022-06-23 23:36:29.791062
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=2, time=2.1, target=(3, 5), dependencies=['foo.py'])
    assert result.files == 2
    assert result.time == 2.1
    assert result.target == CompilationTarget(3, 5)
    assert  result.dependencies == ['foo.py']

# Generated at 2022-06-23 23:36:31.628190
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.Str(), True, ['test.py'])



# Generated at 2022-06-23 23:36:41.896553
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(10, 0.1, (3, 6), ['simplejson']) ==\
           CompilationResult(10, 0.1, (3, 6), ['simplejson'])
    assert CompilationResult(10, 0.1, (3, 6), ['simplejson']) !=\
           CompilationResult(10, 0.1, (3, 7), ['simplejson'])
    assert CompilationResult(10, 0.1, (3, 6), ['simplejson']) !=\
           CompilationResult(10, 0.1, (3, 6), ['requests'])
    assert CompilationResult(10, 0.1, (3, 6), ['simplejson']) !=\
           CompilationResult(10, 0.1, (3, 6), [])

# Generated at 2022-06-23 23:36:45.986394
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(10, 1.2, (3, 5), [])
    assert r.files == 10
    assert r.time == 1.2
    assert r.target == (3, 5)
    assert r.dependencies == []  # type: ignore


# Generated at 2022-06-23 23:36:49.422645
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 2.0, (3, 4), ["a", "b"]) == \
            CompilationResult(1, 2.0, (3, 4), ["a", "b"])


# Generated at 2022-06-23 23:36:53.013315
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=42, time=10.0, target=(3, 5), dependencies=['a'])
    assert result.files == 42
    assert result.time == 10.0
    assert result.target == (3, 5)
    assert result.dependencies == ['a']


# Generated at 2022-06-23 23:36:56.662076
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('test'), Path('test2'))
    assert InputOutput(Path(u'test'), Path(u'test2')) == InputOutput(u'test', u'test2')
    assert InputOutput(Path('test'), Path('test2')) == InputOutput(b'test', b'test2')

# Generated at 2022-06-23 23:36:59.812659
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = 'input'
    output = 'output'
    in_out = InputOutput(input, output)
    assert input == in_out.input
    assert output == in_out.output


# Generated at 2022-06-23 23:37:09.438530
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Correct arguments
    res = CompilationResult(files=1, time=1.0, target=(3, 10), dependencies=[])
    assert res == CompilationResult(files=1, time=1.0, target=(3, 10), dependencies=[])
    assert res != CompilationResult(files=1, time=1.0, target=(3, 10), dependencies=['a'])
    assert res != CompilationResult(files=1, time=1.0, target=(3, 11), dependencies=[])
    assert res != CompilationResult(files=1, time=1.1, target=(3, 10), dependencies=[])
    assert res != CompilationResult(files=2, time=1.0, target=(3, 10), dependencies=[])



# Generated at 2022-06-23 23:37:14.008013
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('print(2)')
    t = TransformationResult(tree, False, [])
    assert t.tree == tree
    assert not t.tree_changed
    assert t.dependencies == []

# Tuple of file name and InputOutput information
FileInputOutput = NamedTuple('FileInputOutput', [('file', Path),
                                                 ('io', InputOutput)])


# Generated at 2022-06-23 23:37:17.691558
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(tree = ast.parse(''),
                                  tree_changed = False,
                                  dependencies = [])
    assert result.tree is not None
    assert result.tree_changed is False
    assert result.dependencies == []

    # Check for incorrect number of arguments
    with pytest.raises(TypeError):
        TransformationResult()

# Generated at 2022-06-23 23:37:24.442843
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.Module([ast.Expr(ast.Num(42))],
                   type_ignores=[ast.Store(), ast.Load(), ast.Del(), ast.AugLoad()])
    r = TransformationResult(tree = t,
                             tree_changed = True,
                             dependencies = ['__builtins__'])
    assert r.tree == t
    assert r.tree_changed == True
    assert r.dependencies == ['__builtins__']

# Generated at 2022-06-23 23:37:27.654048
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = ast.parse('x = 10')
    output = ast.parse('x = 10')
    input_output = InputOutput(input_, output)
    assert input_output.input == input_
    assert input_output.output == output

# Generated at 2022-06-23 23:37:29.033585
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    dependencies = []  # type: List[str]
    assert TransformationResult(tree=ast.parse(''),
                                tree_changed=True,
                                dependencies=dependencies)

# Generated at 2022-06-23 23:37:32.287537
# Unit test for constructor of class InputOutput
def test_InputOutput():
    name = 'test.txt'
    io = InputOutput(Path(name), Path(name + '.out'))
    assert io.input == Path(name)
    assert io.output == Path(name + '.out')
    # Test property getter
    assert io.input.name == name

# Generated at 2022-06-23 23:37:34.711733
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=1,
                             time=0,
                             target=(3, 4),
                             dependencies=['abc'])



# Generated at 2022-06-23 23:37:38.126024
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('/dummy/input')
    o = Path('/dummy/output')
    pair = InputOutput(i, o)
    assert pair.input == i
    assert pair.output == o

# Generated at 2022-06-23 23:37:42.399950
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    target = CompilationResult(2, 3.56, (3, 7), ['foo', 'bar'])
    assert target.files == 2
    assert target.time == 3.56
    assert target.target == (3, 7)
    assert target.dependencies == ['foo', 'bar']


# Generated at 2022-06-23 23:37:44.673056
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('.')
    output = Path('.')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output

# Generated at 2022-06-23 23:37:47.036524
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input.py')
    output = Path('output.py')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-23 23:37:50.066044
# Unit test for constructor of class InputOutput
def test_InputOutput():
    expected_input = Path('./foo.py')
    expected_output = Path('./foo.pyc')
    i_o = InputOutput(expected_input,
                      expected_output)
    assert i_o.input == expected_input
    assert i_o.output == expected_output


# Generated at 2022-06-23 23:37:52.856989
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=4, time=10.4, target=(3, 5), dependencies=['pandas'])

    assert res.files == 4
    assert res.time == 10.4
    assert res.target == (3, 5)
    assert res.dependencies == ['pandas']



# Generated at 2022-06-23 23:37:56.614406
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(1, 2, (3, 4), [])
    assert compilation_result.files == 1
    assert compilation_result.time == 2
    assert compilation_result.target == (3, 4)
    assert compilation_result.dependencies == []



# Generated at 2022-06-23 23:37:58.509886
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(2, 3.0, (3, 7), [])



# Generated at 2022-06-23 23:38:02.130672
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a'), Path('b'))
    assert InputOutput(Path('a'), Path('b')).input == Path('a')
    assert InputOutput(Path('a'), Path('b')).output == Path('b')


# Generated at 2022-06-23 23:38:03.951616
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(10, 10.5, (3, 6), [])


# Generated at 2022-06-23 23:38:07.641436
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(1, 1, (3, 6), [])
    assert compilation_result.files == 1
    assert compilation_result.time == 1
    assert compilation_result.target == (3, 6)
    assert compilation_result.dependencies == []


# Generated at 2022-06-23 23:38:11.779234
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files = 10, time = 3.45, target = (3, 8), dependencies = [])
    assert result.files == 10
    assert result.time == 3.45
    assert result.target == (3, 8)
    assert result.dependencies == []


# Generated at 2022-06-23 23:38:14.378345
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('/input.txt')
    o = Path('/output.txt')
    inout = InputOutput(i, o)
    assert inout.input == i
    assert inout.output == o

# Generated at 2022-06-23 23:38:21.611638
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('def f(): pass')
    res = TransformationResult(tree, True, [])
    assert res.tree == tree
    assert res.tree_changed == True
    assert res.dependencies == []

# Command line arguments to run PyNanny on a program
PyNannyArgs = NamedTuple('PyNannyArgs', [('input', Path),
                                         ('output', Path),
                                         ('target', CompilationTarget),
                                         ('merge', bool),
                                         ('verbose', int)])

# Generated at 2022-06-23 23:38:24.879869
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path('/1.txt')
    path2 = Path('/2.txt')
    io = InputOutput(path1, path2)
    assert io.input == path1
    assert io.output == path2


# Generated at 2022-06-23 23:38:28.901208
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    p = Path('__init__.py')
    t = ast.Module()
    tr = TransformationResult(tree=t, tree_changed=False,
                              dependencies=[str(p)])

    assert tr.tree is t
    assert tr.tree_changed is False
    assert tr.dependencies == [str(p)]

# Generated at 2022-06-23 23:38:32.969841
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1,
                           time=1.0,
                           target=(2, 7),
                           dependencies=['abc'])
    assert cr.files == 1
    assert cr.time == 1.0
    assert cr.target == (2, 7)
    assert cr.dependencies == ['abc']


# Generated at 2022-06-23 23:38:34.375087
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a'), Path('b')) == ('a', 'b')


# Generated at 2022-06-23 23:38:36.338436
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test = InputOutput(Path("test"), Path("test_out"))
    assert test.input == Path("test")
    assert test.output == Path("test_out")


# Generated at 2022-06-23 23:38:37.563250
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('input'), Path('output'))


# Generated at 2022-06-23 23:38:38.782269
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2, (3, 4), [])

# Generated at 2022-06-23 23:38:42.137657
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    TransformationResult(tree, True, [])
    TransformationResult(tree, False, [])
    TransformationResult(tree, True, [])

# Generated at 2022-06-23 23:38:42.940459
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.parse('pass'), True, [])
    TransformationResult(ast.parse('pass'), False, [])

# Generated at 2022-06-23 23:38:44.495420
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    test = CompilationResult(files=1, time=2.0, target=(3, 4),
                             dependencies=['one', 'two'])
    assert test.files == 1
    assert test.time == 2.0
    assert test.target == (3, 4)
    assert test.dependencies == ['one', 'two']


# Generated at 2022-06-23 23:38:46.985242
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path = Path('/absolute/path/to/dir')
    InputOutput(input=path, output=path)


# Generated at 2022-06-23 23:38:48.745470
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: ignore
    # pylint: disable=unused-variable
    a = TransformationResult(tree=None,
                             tree_changed=True,
                             dependencies=[])
    assert a


# Generated at 2022-06-23 23:38:53.585779
# Unit test for constructor of class InputOutput
def test_InputOutput():
    fn = lambda: InputOutput("i", "o")
    assert fn.__name__ == "i"
    assert isinstance(fn.input, Path)
    assert isinstance(fn.output, Path)
    assert fn.input.name == "i"
    assert fn.output.name == "o"
    assert fn().input.name == "i"
    assert fn().output.name == "o"
    assert fn().input.name == "i"
    assert fn().output.name == "o"

# Generated at 2022-06-23 23:38:56.274137
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_input = Path('test')
    test_output = Path('test2')
    result = InputOutput(test_input, test_output)

    assert(result.input == test_input)
    assert(result.output == test_output)


# Generated at 2022-06-23 23:38:58.459045
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_input = '/test/input'
    test_output = '/test/output'

    assert InputOutput(test_input, test_output) ==\
        InputOutput(Path(test_input), Path(test_output))

# Generated at 2022-06-23 23:39:04.889986
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.Module()
    r = TransformationResult(t, False, [])
    assert isinstance(r.tree, ast.AST)
    assert not r.tree_changed
    assert len(r.dependencies) == 0
    assert isinstance(r, TransformationResult)
    

# Result of the visit
VisitorResult = NamedTuple('VisitorResult',
                           [('ast', ast.AST),
                            ('changed', bool)])



# Generated at 2022-06-23 23:39:09.741990
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test_input = ast.parse('a = 1')
    test_output = ast.parse('a = 1')
    res = TransformationResult(test_output, True, [])
    assert res.tree == test_input
    assert res.tree_changed == True
    assert res.dependencies == []

# Generated at 2022-06-23 23:39:13.509637
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(ast.AST(),
                                  True,
                                  [])
    assert result.tree is not None
    assert result.tree_changed is True
    assert result.dependencies == list()

test_TransformationResult()


# Generated at 2022-06-23 23:39:15.932058
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput('a', 'b')
    assert io.input == 'a'
    assert io.output == 'b'

# Generated at 2022-06-23 23:39:20.308307
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_node = ast.parse('a = 1')
    ast_node_changed = ast_node
    dependencies = ['a', 'b']
    result = TransformationResult(ast_node, ast_node_changed, dependencies)
    assert result.tree == ast_node
    assert result.tree_changed == ast_node_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-23 23:39:25.799469
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Given
    tree = ast.parse('')
    tree_changed = False
    dependencies = []

    # When
    transformation_result = TransformationResult(tree, tree_changed, dependencies)

    # Then
    assert (transformation_result.tree,
            transformation_result.tree_changed,
            transformation_result.dependencies) == (tree, tree_changed, dependencies)

# Generated at 2022-06-23 23:39:29.760728
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=2, target=(3, 4), dependencies=[])
    assert result.files == 1
    assert result.time == 2
    assert result.target == (3, 4)
    assert result.dependencies == []


# Generated at 2022-06-23 23:39:33.926341
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('/tmp/input')
    o = Path('/tmp/output')
    i_o = InputOutput(input=i, output=o)
    assert i_o.input == i
    assert i_o.output == o



# Generated at 2022-06-23 23:39:36.124980
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('input'), Path('output')) == \
        (Path('input'), Path('output'))


# Generated at 2022-06-23 23:39:44.550835
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from typing import List
    from typed_ast import ast3 as ast
    from pygears.typing import Int
    from pygears.lib import add
    from pygears.lib.verif import drv

    def check_result(result: TransformationResult):
        assert isinstance(result.tree, ast.Module)
        assert isinstance(result.tree_changed, bool)
        assert isinstance(result.dependencies, List)

    def compare(x: Int, y: Int):
        return x + y

    check_result(add(compare))

    r = drv(t=Int[16], seq=[1, 2, 3, 4]) \
        >> add(compare)

    check_result(r)

# Generated at 2022-06-23 23:39:46.383433
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 2.0, (1, 0), ['foo/bar.py'])



# Generated at 2022-06-23 23:39:48.203223
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input=Path('file.txt'),
                       output=Path('file.result'))

# Generated at 2022-06-23 23:39:53.534390
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=3, time=2.0, target=(3, 5),
                           dependencies=['a.py', 'b.py'])
    assert cr.files == 3
    assert cr.time == 2.0
    assert cr.target == (3, 5)
    assert cr.dependencies == ['a.py', 'b.py']



# Generated at 2022-06-23 23:39:56.479279
# Unit test for constructor of class InputOutput
def test_InputOutput():
    sample = InputOutput(Path('foo'), Path('bar'))
    assert sample.input == Path('foo')
    assert sample.output == Path('bar')


# Generated at 2022-06-23 23:40:01.914248
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('test_input')
    output_path = Path('test_output')
    input_output = InputOutput(input=input_path, output=output_path)
    assert input_output.input == input_path, 'InputOutput.input is not equal to the argument'
    assert input_output.output == output_path, 'InputOutput.output is not equal to the argument'


# Generated at 2022-06-23 23:40:04.550324
# Unit test for constructor of class InputOutput
def test_InputOutput():
    nt = InputOutput(Path('/home/spam'), Path('/home/eggs'))
    assert nt.input == Path('/home/spam')
    assert nt.output == Path('/home/eggs')



# Generated at 2022-06-23 23:40:10.835505
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Type check
    _ = CompilationResult(1, 0.1, (3, 7), list())

    # Value check
    result = CompilationResult(100, 0.001, (3, 7), list())
    assert result.files == 100
    assert result.time == 0.001
    assert result.target == (3, 7)
    assert result.dependencies == list()


# Generated at 2022-06-23 23:40:14.293656
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    TransformationResult(tree, False, [])
    TransformationResult(tree, True, [])
    TransformationResult(tree, False, ['a.py'])
    TransformationResult(tree, True, ['a.py'])

# Generated at 2022-06-23 23:40:16.439813
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = InputOutput(input=Path('in'), output=Path('out'))
    assert a.input
    assert a.output


# Generated at 2022-06-23 23:40:18.071805
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(0, 0.0, (3, 6), [])


# Generated at 2022-06-23 23:40:22.210335
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    args = ast.parse('def f(): pass'), False, ['a', 'b']
    klass = TransformationResult(*args)
    assert isinstance(klass, TransformationResult)
    assert klass.tree == args[0]
    assert klass.tree_changed == args[1]
    assert klass.dependencies == args[2]
    assert repr(klass) == 'TransformationResult(*{})'.format(args)

# Generated at 2022-06-23 23:40:27.653208
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert (TransformationResult(ast.parse(''), False, ['dep1', 'dep2']) ==
            TransformationResult(ast.parse(''), False, ['dep1', 'dep2']))
    assert (TransformationResult(ast.parse(''), False, ['dep1', 'dep2']) !=
            TransformationResult(ast.parse(''), True, ['dep1', 'dep2']))


# Generated at 2022-06-23 23:40:35.985116
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input')
    output = Path('/tmp/output')
    pair = InputOutput(input, output)
    assert input == pair.input
    assert output == pair.output
    assert len(pair) == 2
    assert input == pair[0]
    assert output == pair[1]
    assert input == pair[-2]
    assert output == pair[-1]
    pair = InputOutput(output, input)
    assert input == pair.input
    assert output == pair.output
    assert len(pair) == 2
    assert input == pair[0]
    assert output == pair[1]
    assert input == pair[-2]
    assert output == pair[-1]

# Generated at 2022-06-23 23:40:37.906026
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-23 23:40:39.841550
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('foo')
    output = Path('bar')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-23 23:40:45.222261
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # pylint: disable=invalid-name
    # pylint: disable=no-value-for-parameter
    ast_tree = ast.parse('import os')
    assert TransformationResult(ast_tree, True, []).tree_changed == True
    assert TransformationResult(ast_tree, False, []).tree_changed == False
# End of unit tests for class TransformationResult

# Generated at 2022-06-23 23:40:53.499426
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/home/data/input.txt')
    output = Path('/home/data/output.txt')

    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output

    input_output_1 = InputOutput(input=input, output=output)
    assert input_output_1.input == input
    assert input_output_1.output == output

    input_output_2 = InputOutput(output, input)
    assert input_output_2.input == input
    assert input_output_2.output == output

# Generated at 2022-06-23 23:40:56.717063
# Unit test for constructor of class InputOutput
def test_InputOutput():
    f1 = Path('a')
    f2 = Path('b')
    a = InputOutput(f1, f2)
    assert a.input == f1
    assert a.output == f2


# Generated at 2022-06-23 23:40:59.215713
# Unit test for constructor of class InputOutput
def test_InputOutput():
    x = InputOutput(Path('input'), Path('output'))
    assert x.input == Path('input')
    assert x.output == Path('output')


# Generated at 2022-06-23 23:41:02.563373
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('print("test")')
    dependencies = ['test']
    result = TransformationResult(tree, True, dependencies)
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == dependencies

# Generated at 2022-06-23 23:41:04.651251
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast.parse('')
    TransformationResult(ast.parse(''), False, [])

# Generated at 2022-06-23 23:41:07.699110
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('in')
    output = Path('out')

    assert InputOutput(input, output).input == input and \
           InputOutput(input, output).output == output



# Generated at 2022-06-23 23:41:12.900854
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1,
                                           time=0.1,
                                           target=(3, 6),
                                           dependencies=['a', 'b', 'c'])
    assert compilation_result.files == 1
    assert compilation_result.time == 0.1
    assert compilation_result.target == (3, 6)
    assert compilation_result.dependencies == ['a', 'b', 'c']


# Generated at 2022-06-23 23:41:14.518913
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 1.0, (2, 3), ['a', 'b'])



# Generated at 2022-06-23 23:41:20.499409
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    """
    Check if constructor of TransformationResult works correctly
    """
    test_result = TransformationResult(tree=None,
                                       tree_changed=True,
                                       dependencies=['a', 'b'])
    assert test_result.tree is None
    assert test_result.tree_changed
    assert test_result.dependencies == ['a', 'b']

    test_result = TransformationResult(tree=None,
                                       tree_changed=False,
                                       dependencies=None)
    assert test_result.tree is None
    assert not test_result.tree_changed
    assert not test_result.dependencies

# Generated at 2022-06-23 23:41:24.318786
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=1.0,
                               target=(2, 3),
                               dependencies=['/home/test'])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (2, 3)
    assert result.dependencies == ['/home/test']

# Generated at 2022-06-23 23:41:27.377969
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    source = 'abc'
    tree = ast.parse(source, mode='exec')
    dependencies = ['foo']
    result = TransformationResult(tree,
                                  True,
                                  dependencies=dependencies)
    assert (result.tree == tree)
    assert (result.tree_changed == True)
    assert (result.dependencies == dependencies)

# Generated at 2022-06-23 23:41:30.046070
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = InputOutput(Path('a'), Path('b'))
    b = InputOutput(a.input, a.output)
    assert a == b


# Generated at 2022-06-23 23:41:34.953535
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1,
                               target=(3, 7), dependencies=['foo', 'bar'])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 7)
    assert result.dependencies == ['foo', 'bar']


# Generated at 2022-06-23 23:41:38.785555
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    class A(ast.AST): pass
    result = TransformationResult(tree=A(), tree_changed=True, dependencies=[])
    assert result.tree is not None
    assert result.tree_changed is True
    assert result.dependencies == []

# Generated at 2022-06-23 23:41:43.672066
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(0, 0.0, (0, 0), [])
    assert cr.files == 0
    assert cr.time == 0.0
    assert cr.target == (0, 0)
    assert cr.dependencies == []


# Generated at 2022-06-23 23:41:48.230439
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=[])
    assert c.files == 1
    assert c.time == 1.0
    assert c.target == (3, 6)
    assert c.dependencies == []


# Generated at 2022-06-23 23:41:50.120225
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1,
                      time=1.0,
                      target=(1, 1),
                      dependencies=list())

# Generated at 2022-06-23 23:41:54.327770
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test_dependencies = ['foo', 'bar']
    test_tree = ast.Str(s='foo')
    test_tree_changed = True
    res = TransformationResult(test_tree, test_tree_changed, test_dependencies)
    assert res.tree == test_tree
    assert res.tree_changed == test_tree_changed
    assert res.dependencies == test_dependencies

# Generated at 2022-06-23 23:42:01.179013
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    """ Unit test for constructor of class CompilationResult """
    # Check that CompilationResult behaving like a namedtuple
    compile_result = CompilationResult(files=1, time=0.123,
                                       target=(3, 6), dependencies=['a', 'b'])
    assert compile_result[0] == 1
    assert compile_result[1] == 0.123
    assert compile_result[2] == (3, 6)
    assert compile_result[3] == ['a', 'b']

    # Check properties
    assert compile_result.files == 1
    assert compile_result.time == 0.123
    assert compile_result.target == (3, 6)
    assert compile_result.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:42:04.134759
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("")
    tr = TransformationResult(tree, True, [])
    assert tr.tree is tree
    assert tr.tree_changed is True
    assert tr.dependencies == []