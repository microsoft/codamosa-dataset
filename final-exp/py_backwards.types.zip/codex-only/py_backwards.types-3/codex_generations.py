

# Generated at 2022-06-23 23:31:56.244523
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # pylint: disable=invalid-name
    name = 'foo'
    assert TransformationResult(name, True, []) == (name, True, [])

# Generated at 2022-06-23 23:31:59.562418
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Arrange
    input = Path('./a/b/c')
    output = Path('d/e/f')

    # Act
    input_output = InputOutput(input, output)

    # Assert
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-23 23:32:02.714207
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    result = TransformationResult(tree, True, ['dep'])
    assert result.tree == ast.parse('a = 1')
    assert result.tree_changed
    assert result.dependencies == ['dep']

# Generated at 2022-06-23 23:32:03.526615
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # ...
    return True


# Generated at 2022-06-23 23:32:07.716831
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    tree = ast.parse('1+1')
    assert isinstance(tree, ast.AST)

    result = TransformationResult(tree=tree, tree_changed=True,
                                  dependencies=['/foo/bar'])
    assert isinstance(result, TransformationResult)

    assert result.tree is tree
    assert result.tree_changed is True
    assert result.dependencies == ['/foo/bar']


# Generated at 2022-06-23 23:32:13.710016
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io1 = InputOutput(Path(__file__), Path('/tmp/out.py'))
    assert io1.input.name == Path(__file__).name
    assert io1.output.name == 'out.py'

    io2 = InputOutput(Path(__file__), Path('/tmp/out.py'))
    assert io1.input == io2.input and io1.output == io2.output

# Generated at 2022-06-23 23:32:16.677113
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    result = TransformationResult(tree, True, ['a.py'])
    assert result.tree == tree
    assert result.tree_changed
    assert result.dependencies == ['a.py']

# Generated at 2022-06-23 23:32:19.340223
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('some_input')
    output = Path('some_output')
    p = InputOutput(input, output)
    assert p.input == input
    assert p.output == output

# Generated at 2022-06-23 23:32:21.824649
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    result = TransformationResult(tree, False, [])
    assert result.tree_changed == False
    assert result.tree == tree
    assert result.dependencies == []

# Generated at 2022-06-23 23:32:23.951298
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(3, 5),
                      dependencies=['a.py', 'b.py'])



# Generated at 2022-06-23 23:32:29.065379
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(tree=None, tree_changed=False,
                             dependencies=["a", "b"])
    assert isinstance(t, TransformationResult)


# Return value of function that implements transformers that do not change
# the ast
Result = NamedTuple('Result', [('dependencies', List[str])])


# Generated at 2022-06-23 23:32:33.233867
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=1, time=1.0, target=(3, 4),
                            dependencies=[])
    assert res.files == 1
    assert res.time == 1.0
    assert res.target == (3, 4)
    assert res.dependencies == []



# Generated at 2022-06-23 23:32:36.817288
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    class Node(ast.AST):
        _fields = ()

    n = Node()
    tr = TransformationResult(n, True, ['a', 'b'])
    assert tr.tree is n
    assert tr.tree_changed is True
    assert tr.dependencies == ['a', 'b']

# Generated at 2022-06-23 23:32:39.892898
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('1', '', 'eval')
    TransfResult = TransformationResult(tree=tree, tree_changed=False,
                                        dependencies=list())
    assert TransfResult.tree == tree
    assert TransfResult.tree_changed == False
    assert TransfResult.dependencies == list()



# Generated at 2022-06-23 23:32:43.044738
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse("x = 2")
    r = TransformationResult(t, False, [])
    assert t == r.tree
    assert not r.tree_changed
    assert r.dependencies == []

# Generated at 2022-06-23 23:32:48.197476
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_file = Path("/path/to/input")
    output_file = Path("/path/to/output")
    input_output = InputOutput(input_file, output_file)
    assert input_output.input == input_file
    assert input_output.output == output_file

    assert input_output.input == input_output[0]
    assert input_output.output == input_output[1]

# Generated at 2022-06-23 23:32:55.487893
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert (InputOutput(input=Path('a.py'), output=Path('b.py')) ==
            InputOutput(input=Path('a.py'), output=Path('b.py')))
    assert (InputOutput(input=Path('a.py'), output=Path('b.py')) !=
            InputOutput(input=Path('a.py'), output=Path('bc.py')))
    assert (InputOutput(input=Path('a.py'), output=Path('b.py')) !=
            InputOutput(input=Path('a.pyc'), output=Path('b.py')))
    assert (InputOutput(input=Path('a.py'), output=Path('b.py')) !=
            InputOutput(input=Path('a.py'), output=Path('b.pyc')))

# Generated at 2022-06-23 23:32:58.683545
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files = 1,
                           time = 1.5,
                           target = (3, 7),
                           dependencies = ["abc"])
    assert cr.files == 1
    assert cr.time == 1.5
    assert cr.target == (3, 7)
    assert cr.dependencies == ["abc"]


# Generated at 2022-06-23 23:33:01.200705
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    comp_res = CompilationResult(100, 2.0, (3, 4), ['a', 'b'])
    assert comp_res.files == 100
    assert comp_res.time == 2.0
    assert comp_res.target == (3, 4)
    assert comp_res.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:33:03.499013
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files = 1, time = 0.0, target = (3, 7), dependencies = [])
    assert result.files == 1
    assert result.time == 0.0
    assert result.target == (3, 7)
    assert result.dependencies == []


# Generated at 2022-06-23 23:33:04.314912
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('/dev/null'), Path('/dev/urandom'))

# Generated at 2022-06-23 23:33:06.402440
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('test'), Path('test2')) == \
           InputOutput(Path('test'), Path('test2'))

# Generated at 2022-06-23 23:33:09.783488
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    io = InputOutput(input, output)

    assert io.input == input
    assert io.output == output

# Generated at 2022-06-23 23:33:13.825809
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=0,
                               time=0.,
                               target=(3, 7),
                               dependencies=[])
    assert result.files == 0
    assert result.time == 0.
    assert result.target == (3, 7)
    assert result.dependencies == []


# Generated at 2022-06-23 23:33:16.089666
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('a')
    outp = Path('b')
    pair = InputOutput(inp, outp)
    assert pair.input == inp
    assert pair.output == outp


# Generated at 2022-06-23 23:33:20.515771
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=0, time=0,
                                           target=(3, 4),
                                           dependencies=[])
    assert compilation_result.files == 0
    assert compilation_result.time == 0
    assert compilation_result.target == (3, 4)
    assert compilation_result.dependencies == []



# Generated at 2022-06-23 23:33:22.948603
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # InputOutput should be constructed from Path objects
    input_output = InputOutput(Path('input.py'), Path('output.py'))
    # test that the input file exists
    assert input_output.input.exists()
    # the output file can't exist
    assert not input_output.output.exists()

# Generated at 2022-06-23 23:33:26.541829
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path("/my/input.py")
    output = Path("/my/output.py")
    pair = InputOutput(input_, output)
    assert pair.input == input_
    assert pair.output == output


# Generated at 2022-06-23 23:33:31.097281
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('a.txt')
    output = Path('a.b.txt')
    assert InputOutput(input=input, output=output) == InputOutput(input=input, output=output)
    assert InputOutput(input=input, output=output) != InputOutput(input=input, output=Path('b.txt'))
    assert InputOutput(input=input, output=output) != InputOutput(input=Path('b.tx'), output=output)

# Generated at 2022-06-23 23:33:35.096015
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_node = ast.parse('')

    res = TransformationResult(tree=ast_node,
                               tree_changed=True,
                               dependencies=['d', 'e', 'p'])

    assert ast_node is res.tree
    assert res.tree_changed == True
    assert res.dependencies == ['d', 'e', 'p']

# Generated at 2022-06-23 23:33:38.178335
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a'), Path('b'))
    assert InputOutput('a', 'b').input == Path('a')
    assert InputOutput('a', 'b').output == Path('b')


# Generated at 2022-06-23 23:33:41.412949
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Constructor without arguments
    io = InputOutput(input='1.py', output='1_py.py')
    assert io.input == '1.py'
    assert io.output == '1_py.py'



# Generated at 2022-06-23 23:33:43.147455
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=[])

# Generated at 2022-06-23 23:33:46.523924
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a'), Path('b')) == InputOutput('a', 'b')

# Default value for CompilationResult
CompilationResult.__new__.__defaults__ = (0, 0, None, [])

# Default value for TransformationResult
TransformationResult.__new__.__defaults__ = (None, False, [])

# Generated at 2022-06-23 23:33:47.488683
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(Path('A'), Path('B'))

# Generated at 2022-06-23 23:33:50.678733
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.AST()
    dependencies = ['foo.py']
    tr = TransformationResult(tree, True, dependencies)
    assert tr.tree is tree
    assert tr.tree_changed is True
    assert tr.dependencies == dependencies

# Generated at 2022-06-23 23:34:00.145293
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # pylint: disable=redefined-builtin, no-member, invalid-name
    # pylint: disable=unused-variable, import-outside-toplevel
    # pylint: disable=too-few-public-methods
    class TestTransformationResult(TransformationResult):
        def __new__(cls, tree = None, tree_changed = None, dependencies = []):
            return super().__new__(cls, tree, tree_changed, dependencies)

    transformation = TestTransformationResult(tree_changed = True)
    assert transformation.tree is None
    assert transformation.tree_changed is True

# Result of transformers compilation

# Generated at 2022-06-23 23:34:01.070384
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=0, time=0.1, target=(3, 4), dependencies=[])



# Generated at 2022-06-23 23:34:04.302716
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/i')
    output = Path('/tmp/o')
    assert InputOutput(input=input, output=output).input == input
    assert InputOutput(input=input, output=output).output == output
    assert InputOutput(input=input, output=output) != InputOutput(input=input,
                                                                   output=Path('tmp'))


# Generated at 2022-06-23 23:34:09.304621
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(
            input=Path('/path/to/input.py'),
            output=Path('/path/to/output.py')).input \
            == Path('/path/to/input.py')
    assert InputOutput(
            input=Path('/path/to/input.py'),
            output=Path('/path/to/output.py')).output \
            == Path('/path/to/output.py')


# Generated at 2022-06-23 23:34:10.079360
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(None, False, [])

# Generated at 2022-06-23 23:34:16.594258
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(0, 0, (2, 3), [])
    assert isinstance(c, CompilationResult)
    assert c.files == 0
    assert c.time == 0
    assert c.target == (2, 3)
    c = CompilationResult(0, 0, (2, 7), [])
    assert c.target == (2, 7)
    c = CompilationResult(1, 1, (3, 2), [])
    assert c.target == (3, 2)
    c = CompilationResult(2, 3, (3, 3), [])
    assert c.target == (3, 3)
    with pytest.raises(ValueError):
        CompilationResult(2, 3, (2, 8), [])

# Generated at 2022-06-23 23:34:18.559192
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(3, 5), dependencies=[])


# Generated at 2022-06-23 23:34:23.782087
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input.py')
    output = Path('output.py')
    pair = InputOutput(input=input, output=output)
    assert pair.input == input
    assert pair.output == output
    pair2 = InputOutput(input, output)
    assert pair == pair2


# Generated at 2022-06-23 23:34:28.333829
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=0, time=0,
                               target=(3, 3), dependencies=[])
    assert result.files == 0
    assert result.time == 0
    assert result.target == (3, 3)
    assert result.dependencies == []


# Generated at 2022-06-23 23:34:33.836861
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=2,
                          time=2.2,
                          target=(3, 5),
                          dependencies=['a', 'b'])
    assert c.files == 2
    assert c.time == 2.2
    assert c.target == (3, 5)
    assert c.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:34:39.841326
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a'), Path('b')) == InputOutput(input=Path('a'), output=Path('b'))
    assert str(InputOutput(Path('a'), Path('b'))) == '<a -> b>'
    assert repr(InputOutput(Path('a'), Path('b'))) == 'InputOutput(input=PosixPath(\'a\'), output=PosixPath(\'b\'))'

# Generated at 2022-06-23 23:34:48.135552
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # pylint: disable=unused-variable
    tree = ast.parse('', mode='exec')
    tr = TransformationResult(tree, True, ['f1.py', 'f2.py'])
    assert tr.tree == tree
    assert tr.tree_changed is True
    assert tr.dependencies == ['f1.py', 'f2.py']

# Result of optimizers transformation
OptimizationResult = NamedTuple('OptimizationResult',
                                [('object', bytes),
                                 ('object_changed', bool),
                                 ('dependencies', List[str])])


# Generated at 2022-06-23 23:34:49.726785
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('in'), Path('out'))
    assert input_output.input == Path('in')
    assert input_output.output == Path('out')

# Generated at 2022-06-23 23:34:50.862880
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2.0, (3, 4), [])



# Generated at 2022-06-23 23:34:54.316561
# Unit test for constructor of class CompilationResult
def test_CompilationResult():  # noqa: D103
    res = CompilationResult(files=3, time=3.14, target=(3, 6), dependencies=[])
    assert res.files == 3
    assert res.time == 3.14
    assert res.target == (3, 6)
    assert res.dependencies == []


# Generated at 2022-06-23 23:34:57.038922
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('a')
    o = Path('b')
    result = InputOutput(i, o)
    assert i == result.input
    assert o == result.output

# Generated at 2022-06-23 23:35:01.665693
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=0,
                           time=0.0,
                           target=(3, 8),
                           dependencies=[])
    assert cr.files == 0
    assert cr.time == 0.0
    assert cr.target == (3, 8)
    assert cr.dependencies == []


# Generated at 2022-06-23 23:35:04.970450
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path_in = Path('test')
    path_out = Path('test2')
    data = InputOutput(path_in, path_out)
    assert data.input == path_in
    assert data.output == path_out

# Generated at 2022-06-23 23:35:07.196056
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("")
    tree_changed = False
    dependencies = []
    TransformationResult(tree, tree_changed, dependencies)

# Generated at 2022-06-23 23:35:09.331314
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.Module(body=[]), False, [])
    assert tr.tree_changed == False
    assert len(tr.dependencies) == 0
    assert isinstance(tr.tree, ast.Module)

# Generated at 2022-06-23 23:35:13.172874
# Unit test for constructor of class CompilationResult
def test_CompilationResult():  # noqa: D103
    t1 = CompilationResult(files=10, time=1.23, target=(2, 7),
                           dependencies=['a', 'b'])
    assert t1.files == 10
    assert t1.time == 1.23
    assert t1.target == (2, 7)
    assert t1.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:35:18.367082
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("x=1")
    tree_changed = True
    dependencies = ['a.py', 'b.py']
    trans = TransformationResult(tree=tree,
                                 tree_changed=tree_changed,
                                 dependencies=dependencies)
    assert trans.tree == tree
    assert trans.tree_changed == tree_changed
    assert trans.dependencies == dependencies

# Generated at 2022-06-23 23:35:21.084441
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(tree=None, tree_changed=False, dependencies=[])
    assert result.tree is None
    assert result.tree_changed is False
    assert result.dependencies == []

# Generated at 2022-06-23 23:35:23.672213
# Unit test for constructor of class InputOutput
def test_InputOutput():
    pair = InputOutput(Path('input'), Path('output'))
    assert pair.input.name == 'input'
    assert pair.output.name == 'output'


# Generated at 2022-06-23 23:35:25.093244
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.AST(), True, ['file1', 'file2'])

# Generated at 2022-06-23 23:35:30.094613
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.12, target=(3, 6),
                               dependencies=['a.py', 'b.py', 'c.py'])
    assert result.files == 1
    assert result.time == 0.12
    assert result.target == (3, 6)
    assert result.dependencies == ['a.py', 'b.py', 'c.py']


# Generated at 2022-06-23 23:35:32.500429
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=0.0,
                               target=(3, 6),
                               dependencies=['__future__', 'foo'])
    assert result.files == 1
    assert result.time == 0.0
    assert result.target == (3, 6)
    assert result.dependencies == ['__future__', 'foo']


# Generated at 2022-06-23 23:35:34.922646
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    one = TransformationResult(ast.AST(), True, [])
    two = TransformationResult(ast.AST(), False, [])
    assert one is not two

# Generated at 2022-06-23 23:35:36.072367
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.Module()
    TransformationResult(tree, True, ['dependency'])

# Generated at 2022-06-23 23:35:41.286287
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1,
                           time=0.1,
                           target=(3, 5),
                           dependencies=["a", "b"])

    assert cr.files == 1
    assert cr.time == 0.1
    assert cr.target == (3, 5)
    assert cr.dependencies == ["a", "b"]


# Generated at 2022-06-23 23:35:43.014496
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_node = ast.Name()
    TransformationResult(ast_node, True, ['module1'])

# Generated at 2022-06-23 23:35:44.992430
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=1, time=1, target=(1, 1), dependencies=[])



# Generated at 2022-06-23 23:35:47.558930
# Unit test for constructor of class InputOutput
def test_InputOutput():
    pair = InputOutput('/foo', '/bar')
    assert pair.input is '/foo'
    assert pair.output is '/bar'


# Generated at 2022-06-23 23:35:49.267680
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path = Path(".") / 'input.py'
    io = InputOutput(path, path.with_name("output.py"))
    assert io.input == path
    assert io.output == path.with_name("output.py")

# Generated at 2022-06-23 23:35:51.453294
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(ast.parse(''), True, [])
    assert t.tree_changed == True
    assert t.dependencies == []

# Generated at 2022-06-23 23:35:52.912340
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput("input.py", "output.py")


# Generated at 2022-06-23 23:35:57.729645
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 2.0, (3, 4), ['test']).files == 1
    assert CompilationResult(1, 2.0, (3, 4), ['test']).time == 2.0
    assert CompilationResult(1, 2.0, (3, 4), ['test']).target == (3, 4)
    assert CompilationResult(1, 2.0, (3, 4), ['test']).dependencies == ['test']

# Generated at 2022-06-23 23:36:00.151040
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    result = TransformationResult(tree, True, ['A', 'B'])
    assert result.tree is tree
    assert result.tree_changed is True
    assert result.dependencies == ['A', 'B']

# Generated at 2022-06-23 23:36:03.829990
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('test/path/to/input')
    output = Path('test/path/to/output')

    result = InputOutput(input, output)

    assert result.input == input
    assert result.output == output



# Generated at 2022-06-23 23:36:05.258944
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(42, 42.0, (3, 5), [])

# Generated at 2022-06-23 23:36:10.315808
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=100,
                               time=0.1,
                               target=(2, 7),
                               dependencies=['a', 'b'])
    assert result.files == 100
    assert result.time == 0.1
    assert result.target == (2, 7)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:36:13.806613
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(0, 0, (2, 7), [])
    assert cr.files == 0
    assert cr.time == 0
    assert cr.target == (2, 7)
    assert cr.dependencies == []


# Generated at 2022-06-23 23:36:15.733592
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(10, 0.5, (3, 5), ['stdio.h'])


# Generated at 2022-06-23 23:36:18.663452
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert isinstance(InputOutput(Path('a'), Path('b'))
                      .input, Path)
    assert isinstance(InputOutput(Path('a'), Path('b'))
                    .output, Path)

# Generated at 2022-06-23 23:36:20.829380
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path = Path.cwd()
    input_output = InputOutput(path, path)
    assert input_output.input == path
    assert input_output.output == path


# Generated at 2022-06-23 23:36:23.316123
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(files=1, time=1, target=(3, 7), dependencies=[])
    assert r.files == 1
    assert r.time == 1
    assert r.target == (3, 7)
    assert r.dependencies == []



# Generated at 2022-06-23 23:36:26.033186
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1,
                      time=0.5,
                      target=(3, 4),
                      dependencies=[''])

# Generated at 2022-06-23 23:36:29.483471
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    ci = CompilationResult(0, 0, (3, 5), [])
    assert ci.files == 0
    assert ci.time == 0
    assert ci.target == (3, 5)
    assert ci.dependencies == []


# Generated at 2022-06-23 23:36:35.057590
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    result = TransformationResult(tree, False, ['fake_file.py'])
    assert isinstance(result.tree, ast.AST)
    assert result.tree_changed == False
    assert isinstance(result.dependencies, list)
    assert result.dependencies == ['fake_file.py']

# Generated at 2022-06-23 23:36:39.331975
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res: CompilationResult = CompilationResult(1, 2, (3, 4), ["a", "b"]) # type: ignore
    assert res.files == 1
    assert res.time == 2
    assert res.target == (3, 4)
    assert res.dependencies == ["a", "b"]


# Generated at 2022-06-23 23:36:41.390692
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    a = ast.AST()
    TransformationResult(a, True, ['a'])
    TransformationResult(a, False, ['a'])

# Generated at 2022-06-23 23:36:43.917327
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('test_input.py')
    out = Path('test_output.py')
    pair = InputOutput(input=inp, output=out)
    assert pair.input == inp
    assert pair.output == out

# Generated at 2022-06-23 23:36:51.573491
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_file = Path('/a/path')
    output_file = Path('/another/path')
    input_output = InputOutput(input_file, output_file)
    assert input_output.input == input_file
    assert input_output.output == output_file

    # check that inputs can be ==
    input_file = Path('/a/path')
    output_file = Path('/another/path')
    input_output = InputOutput(input_file, output_file)
    assert input_output.input == input_file
    assert input_output.output == output_file


# Generated at 2022-06-23 23:36:54.273766
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=2, target=(3, 4), dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 2
    assert result.target == (3, 4)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:37:01.214889
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(Path('file1.py'), Path('file2.py2'))
    with pytest.raises(TypeError) as e:
        InputOutput(1, Path('file2.py2'))
    assert '\'input\' must be of type \'Path\'' in str(e.value)
    with pytest.raises(TypeError) as e:
        InputOutput(Path('file1.py'), 1)
    assert '\'output\' must be of type \'Path\'' in str(e.value)


# Generated at 2022-06-23 23:37:05.335026
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(3, 0.165, (3, 7), [])
    assert cr.files == 3
    assert cr.time == 0.165
    assert cr.target == (3, 7)
    assert cr.dependencies == []



# Generated at 2022-06-23 23:37:09.239590
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = InputOutput(Path('foo.py'), Path('bar.py'))
    assert i.input == Path('foo.py')
    assert i.output == Path('bar.py')
    assert i.input.name == 'foo.py'
    assert i.output.name == 'bar.py'

# Generated at 2022-06-23 23:37:15.184538
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(5, 500.0, (3, 7), ['setuptools>=38', 'some_package'])
    assert r.files == 5
    assert r.time == 500.0
    assert r.target == (3, 7)
    assert r.dependencies == ['setuptools>=38', 'some_package']
    assert repr(r) == 'CompilationResult(files=5, time=500.0, '\
                      'target=(3, 7), dependencies=\'[setuptools>=38, some_package]\')'


# Generated at 2022-06-23 23:37:20.734915
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    a = CompilationResult(1, 1.0, (3, 4), [])
    b = CompilationResult(1, 1.0, (3, 4), [])
    assert a == b
    assert a != 1
    assert a.files == 1
    assert a.time == 1.0
    assert a.target == (3, 4)
    assert a.dependencies == []



# Generated at 2022-06-23 23:37:26.000371
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('a=1')
    r = TransformationResult(t, True, ['a', 'b'])
    assert r.tree == t
    assert r.tree_changed
    assert r.dependencies == ['a', 'b']
    r = TransformationResult(t, False, [])
    assert not r.tree_changed
    assert r.dependencies == []

# Generated at 2022-06-23 23:37:28.607742
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    output = CompilationResult(files=42, time=3.14, target=(3, 5),
                               dependencies=['a', 'b'])
    assert output.files == 42
    assert output.time == 3.14
    assert output.target == (3, 5)
    assert output.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:37:30.577116
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    try:
        CompilationResult(1, 2.5, (3, 4), ['file1', 'file2'])
    except:
        assert False


# Generated at 2022-06-23 23:37:32.524436
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.Module(), True, [])
    assert tr.tree_changed is True
    assert tr.dependencies == []

# Generated at 2022-06-23 23:37:35.047593
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = InputOutput('1', '2')
    assert str(a.input) == '1'
    assert str(a.output) == '2'


# Generated at 2022-06-23 23:37:41.023960
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('in'), Path('out')) == InputOutput(Path('in'),
                                                               Path('out'))
    assert InputOutput(Path('in'), Path('other')) != \
        InputOutput(Path('other'), Path('out'))
    assert InputOutput(Path('in'), Path('other')) != \
        InputOutput(Path('other'), Path('other'))



# Generated at 2022-06-23 23:37:45.413175
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(files = 3, time = 1,
                          target = (3, 7),
                          dependencies = ['a', 'b', 'c'])
    assert r.files == 3
    assert r.time == 1
    assert r.target == (3, 7)
    assert r.dependencies == ['a', 'b', 'c']


# Generated at 2022-06-23 23:37:46.284114
# Unit test for constructor of class TransformationResult

# Generated at 2022-06-23 23:37:48.586011
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # type: () -> None
    i = InputOutput(Path('a'), Path('b'))
    assert i.input == Path('a')
    assert i.output == Path('b')


# Generated at 2022-06-23 23:37:54.809798
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    f = lambda : None
    t = TransformationResult(ast.parse(f.__code__),
                             True,
                             [])
    assert t == TransformationResult(ast.parse(f.__code__),
                                     True,
                                     [])
    assert t != TransformationResult(ast.parse(f.__code__),
                                     False,
                                     [])
    assert t != TransformationResult(ast.parse(f.__code__),
                                     True,
                                     ['a'])

# Generated at 2022-06-23 23:37:58.993812
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    def make(t, tc, d):
        return TransformationResult(t, tc, d)

    a = ast.parse('pass')
    assert make(a, False, ['a', 'b']) == TransformationResult(a, False, ['a', 'b'])

# Generated at 2022-06-23 23:38:04.152875
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=100,
                               time=12,
                               target=(3, 6),
                               dependencies=['a.py', 'b.py'])
    assert result.files == 100
    assert result.time == 12
    assert result.target == (3, 6)
    assert result.dependencies == ['a.py', 'b.py']


# Generated at 2022-06-23 23:38:05.515677
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert isinstance(CompilationResult(*(0,) * 4), CompilationResult)

# Generated at 2022-06-23 23:38:09.692906
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=1, time=2.0,
                          target=(3, 4),
                          dependencies=['a', 'b', 'c'])
    assert c.files == 1
    assert c.time == 2.0
    assert c.target[0] == 3
    assert c.target[1] == 4
    assert c.dependencies == ['a', 'b', 'c']



# Generated at 2022-06-23 23:38:13.372604
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    TransformationResult(tree, True, [])
    TransformationResult(tree, False, ['foo.py'])
    TransformationResult(tree, False, [])


# Result of transformers transformation
# In contrast to TransformationResult, this is used when
# there is no AST tree
TransformationResultNoTree = NamedTuple('TransformationResultNoTree',
                                        [('tree_changed', bool),
                                         ('dependencies', List[str])])


# Generated at 2022-06-23 23:38:17.521939
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('raise Exception()')
    t = TransformationResult(tree, True, [])
    assert t.tree == tree
    assert t.tree_changed is True
    assert t.dependencies == []


# Global variable for disabling output
__QUIET__ = False

# Disables output

# Generated at 2022-06-23 23:38:19.844065
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('foo')
    output = Path('bar')
    assert InputOutput(input, output) == InputOutput(input, output)


# Generated at 2022-06-23 23:38:23.293539
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('a/b/c')
    output = Path('x/y/z')

    p = InputOutput(input_, output)

    assert p.input == input_
    assert p.output == output



# Generated at 2022-06-23 23:38:27.733679
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse("a = 1")
    tr = TransformationResult(tree=t, tree_changed=True, dependencies=['a', 'b'])
    assert tr.tree == t
    assert tr.tree_changed
    assert tr.dependencies == ['a', 'b']

# Assertion used to cause the build to fail if error is detected

# Generated at 2022-06-23 23:38:29.279894
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('sample'), Path('sample.pyc'))


# Generated at 2022-06-23 23:38:33.758137
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    test_result = CompilationResult(files=4,
                                    time=12.0,
                                    target=(2, 7),
                                    dependencies=['foo', 'bar'])
    assert test_result.files == 4
    assert test_result.time == 12.0
    assert test_result.target == (2, 7)
    assert test_result.dependencies == ['foo', 'bar']

# Generated at 2022-06-23 23:38:37.737547
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=2,
                               time=5.6,
                               target=(3, 7),
                               dependencies=['foo.py', 'bar.py'])
    assert result.files == 2
    assert result.time == 5.6
    assert result.target == (3, 7)
    assert result.dependencies == ['foo.py', 'bar.py']



# Generated at 2022-06-23 23:38:38.957745
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test_tree = ast.parse("pass")
    assert TransformationResult(test_tree, True, [])

# Generated at 2022-06-23 23:38:42.766267
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = InputOutput(Path('./a.py'), Path('./b.py'))
    assert a.input == Path('./a.py')
    assert a.output == Path('./b.py')

# Generated at 2022-06-23 23:38:48.089834
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(
        files=2,
        time=1.0,
        target=(3, 5),
        dependencies=['a', 'b']
    )
    assert res.files == 2
    assert res.time == 1.0
    assert res.target == (3, 5)
    assert res.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:38:53.171182
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert isinstance(TransformationResult(ast.AST(), True, []),
                      TransformationResult)

# Result of transformers check
CheckResult = NamedTuple('CheckResult',
                         [('check', bool),
                          ('reason', str)])

# Result of verifier
VerificationResult = NamedTuple('VerificationResult',
                                [('verification', bool),
                                 ('reason', str)])

# Result of execution
ExecutionResult = NamedTuple('ExecutionResult',
                             [('execution', bool),
                              ('reason', str)])

# Generated at 2022-06-23 23:38:55.249499
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('in'), Path('out')).input == Path('in')
    assert InputOutput(Path('in'), Path('out')).output == Path('out')

# Generated at 2022-06-23 23:38:56.806299
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0,
                      target=(3, 6), dependencies=[])


# Generated at 2022-06-23 23:38:59.690535
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('~/data/input.dat')
    output = Path('~/data/output.dat')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-23 23:39:03.756860
# Unit test for constructor of class InputOutput
def test_InputOutput():
    file_input = Path('input.txt')
    file_output = Path('output.txt')

    io_pair = InputOutput(file_input, file_output)

    assert io_pair.input == file_input
    assert io_pair.output == file_output


# Generated at 2022-06-23 23:39:11.452813
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(2, 5.0, (3, 7), [])
    assert isinstance(result.files, int)
    assert isinstance(result.time, float)
    assert isinstance(result.target, tuple)
    assert isinstance(result.dependencies, list)
    assert len(result.target) == 2
    assert result.target[0] == 3
    assert result.target[1] == 7
    assert result.files == 2
    assert result.time == 5.0
    assert result.dependencies == []


# Generated at 2022-06-23 23:39:13.560214
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=12, time=1.6, target=(3, 5), dependencies=[])


# Generated at 2022-06-23 23:39:15.585766
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2.0, (3, 4), ["foo"])


# Generated at 2022-06-23 23:39:20.711223
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # TODO: test for non default constructor
    result = CompilationResult(files=10, time=0.1, target=(3, 5), dependencies=["mod1", "mod2"])
    assert result.files == 10
    assert result.time == 0.1
    assert result.target == (3, 5)
    assert result.dependencies == ["mod1", "mod2"]



# Generated at 2022-06-23 23:39:24.069827
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('/in/')
    output = Path('/out/')
    input_output = InputOutput(input_, output)
    assert input_output.input == input_
    assert input_output.output == output



# Generated at 2022-06-23 23:39:29.154796
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(1, 2.0, (3, 4), ['a', 'b', 'c'])
    assert c.files == 1
    assert c.time == 2.0
    assert c.target == (3, 4)
    assert c.dependencies == ['a', 'b', 'c']


# Generated at 2022-06-23 23:39:34.707019
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=['1', '2'])
    assert compilation_result.files == 1
    assert compilation_result.time == 1.0
    assert compilation_result.target == (3, 6)
    assert compilation_result.dependencies == ['1', '2']



# Generated at 2022-06-23 23:39:38.895166
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(1, 1.0, (3, 1), [])
    assert res.files == 1
    assert res.time == 1.0
    assert res.target == (3, 1)
    assert res.dependencies == []


# Generated at 2022-06-23 23:39:42.276212
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=1, time=0, target=(3, 8), dependencies=[])
    assert res.files == 1
    assert res.time == 0
    assert res.target == (3, 8)
    assert res.dependencies == []


# Generated at 2022-06-23 23:39:44.654005
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = InputOutput(Path('example.py'), Path('example.pyi'))
    assert i.input == Path('example.py')
    assert i.output == Path('example.pyi')

# Generated at 2022-06-23 23:39:49.528147
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    a = TransformationResult(
        ast.Module([]),
        True,
        ['dep1', 'dep2'])
    b = TransformationResult(
        ast.Module([]),
        True,
        ['dep1'])
    assert (a.tree, a.tree_changed, a.dependencies) == \
           (b.tree, b.tree_changed, b.dependencies)

# Generated at 2022-06-23 23:39:52.678570
# Unit test for constructor of class InputOutput
def test_InputOutput():
    pair = InputOutput(Path('input.py'), Path('output.py'))
    assert pair.input == Path('input.py')
    assert pair.output == Path('output.py')

# Generated at 2022-06-23 23:39:58.249840
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    new_cr = CompilationResult(files=42, time=10.1, target=(3, 5), dependencies=['test.py', 'test2.py'])

    assert new_cr.files == 42
    assert new_cr.time == 10.1
    assert new_cr.target == (3, 5)
    assert new_cr.dependencies == ['test.py', 'test2.py']



# Generated at 2022-06-23 23:40:06.153197
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    name = (1, 2, 3)
    tree = ast.AST()
    tree_changed = False
    dependencies = [1, 2, 3]
    TransformationResult(name, tree, tree_changed, dependencies)


# Result of a single file compilation
CompilationInfo = NamedTuple('CompilationInfo',
                             [('input', Path),
                              ('output', Path),
                              ('files', int),
                              ('time', float),
                              ('target', CompilationTarget)])

# Compilation report
TransformationReport = NamedTuple('TransformationReport',
                                  [('compilation_results', List[CompilationResult]),
                                   ('target', CompilationTarget),
                                   ('time_spent', float)])

# Input/output of compilation of multiple files

# Generated at 2022-06-23 23:40:12.318712
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cmp_res = CompilationResult(1, 2.0, (3, 4), ['a', 'b'])
    assert len(cmp_res) == 4
    assert cmp_res.files == 1
    assert cmp_res.time == 2.0
    assert cmp_res.target == (3, 4)
    assert cmp_res.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:40:14.535114
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=1, time=3.0, target=(3, 7), dependencies=['d1'])


# Generated at 2022-06-23 23:40:19.675012
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    source_path = Path('source.py')
    source_module = ast.parse(source_path.read_text())
    dep_list = ['first.py', 'second.py']
    res = TransformationResult(tree=source_module, tree_changed=True,
                               dependencies=dep_list)
    assert res.tree == source_module
    assert res.tree_changed == True
    assert res.dependencies == dep_list

# Generated at 2022-06-23 23:40:21.386532
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=5.5, target=(3, 5), dependencies=['foo'])


# Generated at 2022-06-23 23:40:22.598535
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.AST(), False, [])

# Generated at 2022-06-23 23:40:26.160759
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """Unit test for constructor of class InputOutput"""
    input_file = Path('input.txt')
    output_file = Path('output.txt')
    result = InputOutput(input_file, output_file)
    assert result.input == input_file
    assert result.output == output_file

# Generated at 2022-06-23 23:40:29.961033
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path("input.py")
    output_path = Path("output.py")
    input_output = InputOutput(input_path, output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path


# Generated at 2022-06-23 23:40:33.808231
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = InputOutput(Path('a'), Path('b'))
    assert a.input.name == 'a'
    assert a.output.name == 'b'
    with pytest.raises(TypeError):
        InputOutput(None, None)
    # type: ignore


# Generated at 2022-06-23 23:40:37.851632
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=100, time=3.4, target=(3, 6), dependencies=["foo", "bar"])
    assert result.files == 100
    assert result.time == 3.4
    assert result.target == (3, 6)
    assert result.dependencies == ["foo", "bar"]


# Generated at 2022-06-23 23:40:40.769703
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('foo.py'), Path('bar.py'))
    assert InputOutput(Path('foo.py'), Path('bar.py')).input == Path('foo.py')
    assert InputOutput(Path('foo.py'), Path('bar.py')).output == Path('bar.py')

# Generated at 2022-06-23 23:40:42.723230
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    tree = ast.parse('1 + 1')
    assert isinstance(TransformationResult(tree, True, []), TransformationResult)

# Generated at 2022-06-23 23:40:45.222028
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    path = Path('p.py')
    CompilationResult(1, 2, (3, 4), [str(path)])

# Generated at 2022-06-23 23:40:47.606526
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    code = 'x = 1'
    tree = ast.parse(code)
    assert TransformationResult(tree, True, ['a', 'b'])

# Generated at 2022-06-23 23:40:51.540597
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse("print('Hello world')"),
                                False,
                                ['dependency1']).tree_changed is False

    assert TransformationResult(ast.parse("print('Hello world')"),
                                True,
                                ['dependency2']).tree_changed is True

# Generated at 2022-06-23 23:40:59.839755
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from typing import List

    from typed_ast import ast3 as ast

    tree = ast.Module(body=[ast.Import(names=[ast.alias(name='a', asname=None)])])
    dependencies = ['a.py']

    tr = TransformationResult(tree = tree,
                              tree_changed = True,
                              dependencies = dependencies)

    assert isinstance(tr.tree, ast.Module)
    assert isinstance(tr.tree_changed, bool)

    assert isinstance(tr.dependencies, List)
    assert len(tr.dependencies) == 1
    assert tr.dependencies[0] == 'a.py'

# Generated at 2022-06-23 23:41:05.441019
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert isinstance(TransformationResult(ast.Module(body=[]), True, []),
                      TransformationResult)


# Information about compilation
CompilationResult = NamedTuple('CompilationResult',
                               [('files', int),
                                ('time', float),
                                ('target', CompilationTarget),
                                ('dependencies', List[str])])



# Generated at 2022-06-23 23:41:07.274243
# Unit test for constructor of class InputOutput
def test_InputOutput():
    _ = InputOutput(Path('test_input'), Path('test_output'))


# Generated at 2022-06-23 23:41:11.587907
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(
        files=0,
        time=0,
        target=(0,0),
        dependencies=[]
    )
    assert compilation_result.files == 0
    assert compilation_result.time == 0
    assert compilation_result.target == (0,0)
    assert compilation_result.dependencies == []


# Generated at 2022-06-23 23:41:12.480231
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(Path('a'), Path('b'))

# Generated at 2022-06-23 23:41:17.363618
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # type: (...) -> None

    cr = CompilationResult(files=0,
                           time=1.0,
                           target=(3, 7),
                           dependencies=[
                               "a",
                               "b"])
    assert cr.files == 0
    assert cr.time == 1.0
    assert cr.target == (3, 7)
    assert cr.dependencies == ["a", "b"]


# Generated at 2022-06-23 23:41:18.948359
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    assert TransformationResult(ast.Module([]),
                                False,
                                [])

# Generated at 2022-06-23 23:41:21.807026
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("print 'hello'")
    tr = TransformationResult(tree, True, ['foo'])
    assert tr.tree == tree
    assert tr.tree_changed == True
    assert tr.dependencies == ['foo']


# Generated at 2022-06-23 23:41:23.182482
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 1.0, (2, 3), [])


# Generated at 2022-06-23 23:41:24.356217
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse('a = 1'), True, [])

# Generated at 2022-06-23 23:41:25.862268
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    original_tree = ast.AST()
    tree = ast.AST()
    dependencies = []
    TransformationResult(tree, True, dependencies)

# Generated at 2022-06-23 23:41:27.947978
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path("foo")
    path2 = Path("bar")
    input_output = InputOutput(path1, path2)
    assert input_output.input == path1
    assert input_output.output == path2

# Generated at 2022-06-23 23:41:29.452275
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a'), Path('b'))


# Generated at 2022-06-23 23:41:31.113948
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(input='sometest.in', output='sometest.out')
    assert io.input == 'sometest.in'
    assert io.output == 'sometest.out'

# Generated at 2022-06-23 23:41:36.100651
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    """
    Unit test for constructor of class TransformationResult
    """
    tree = ast.parse('1234')
    tree_changed = False
    dependencies = ['foo.py']
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-23 23:41:38.093114
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1,2,[3,4],['dep1', 'dep2'])


# Generated at 2022-06-23 23:41:40.802252
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert (TransformationResult(tree=None,
                                 tree_changed=False,
                                 dependencies=['foo']).dependencies
            == ['foo'])

# Generated at 2022-06-23 23:41:52.986292
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    try:
        TransformationResult(None, None, None)
    except TypeError:
        assert True
    except:
        assert False
    try:
        TransformationResult(None, None, [])
    except TypeError:
        assert True
    except:
        assert False
    try:
        TransformationResult(None, False, None)
    except TypeError:
        assert True
    except:
        assert False
    try:
        TransformationResult(None, False, [])
    except TypeError:
        assert True
    except:
        assert False
    try:
        TransformationResult(ast.AST(), None, None)
    except TypeError:
        assert True
    except:
        assert False
    try:
        TransformationResult(ast.AST(), None, [])
    except TypeError:
        assert True

# Generated at 2022-06-23 23:41:55.314506
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('input')
    o = Path('output')
    p = InputOutput(i, o)
    assert p.input == i
    assert p.output == o