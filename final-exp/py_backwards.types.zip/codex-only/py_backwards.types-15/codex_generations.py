

# Generated at 2022-06-23 23:31:58.119344
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    result = TransformationResult(None, False, [])
    assert isinstance(result.tree, ast.AST)
    assert isinstance(result.tree_changed, bool)
    assert isinstance(result.dependencies, list)

# Generated at 2022-06-23 23:32:01.324672
# Unit test for constructor of class InputOutput
def test_InputOutput():
    my_input = Path('foo')
    my_output = Path('bar')
    input_output = InputOutput(my_input, my_output)
    assert input_output.input == my_input
    assert input_output.output == my_output

# Generated at 2022-06-23 23:32:05.154537
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('foo.py'), Path('bar.pyc'))
    assert InputOutput(input=Path('foo.py'), output=Path('bar.pyc'))
    assert InputOutput(output=Path('bar.pyc'), input=Path('foo.py'))


# Generated at 2022-06-23 23:32:08.277898
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('x = 2')
    res = TransformationResult(tree=t, tree_changed=True, dependencies=['a'])
    assert isinstance(res.tree, ast.AST)
    assert res.tree_changed == True
    assert len(res.dependencies) == 1
    assert res.dependencies[0] == 'a'

# Generated at 2022-06-23 23:32:11.548152
# Unit test for constructor of class InputOutput
def test_InputOutput():
    t = InputOutput(Path('foo'), Path('bar'))
    assert t.input == Path('foo')
    assert t.output == Path('bar')


# Generated at 2022-06-23 23:32:14.583590
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('input.txt')
    out = Path('output.txt')
    res = InputOutput(inp, out)
    assert res.input == inp
    assert res.output == out

# Generated at 2022-06-23 23:32:15.858951
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('foo'), Path('bar'))



# Generated at 2022-06-23 23:32:22.086786
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Prepare unit test
    from astor.code_gen import to_source
    import os

    tree = ast.parse('x=1')
    tree_changed = True
    dependencies = [os.path.realpath(__file__)]
    transformation_result = TransformationResult(tree, tree_changed, dependencies)

    # Check expected result
    assert transformation_result.tree_changed == tree_changed
    assert to_source(transformation_result.tree) == to_source(tree)
    assert transformation_result.dependencies == dependencies


# Generated at 2022-06-23 23:32:26.120997
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('/tmp'), Path('/var')) == InputOutput(
        Path('/tmp'), Path('/var'))
    assert InputOutput(Path('/tmp'), Path('/var')) != InputOutput(
        Path('/tmp'), Path('/var2'))
    assert InputOutput(Path('/tmp'), Path('/var')) != InputOutput(
        Path('/tmp2'), Path('/var'))


# Generated at 2022-06-23 23:32:31.213862
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path("foo.in")
    output_path = Path("bar.out")
    input_output = InputOutput(input_path, output_path)

    assert isinstance(input_output, InputOutput)
    assert input_output.input == input_path
    assert input_output.output == output_path


# Generated at 2022-06-23 23:32:38.589267
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(
        ast.AST(),
        True,
        ['a', 'b']
    ) == TransformationResult(
        ast.AST(),
        True,
        ['a', 'b']
    )
    assert TransformationResult(
        ast.AST(),
        True,
        ['a', 'b']
    ) != TransformationResult(
        ast.AST(),
        True,
        []
    )
    assert TransformationResult(
        ast.AST(),
        True,
        ['a', 'b']
    ) != TransformationResult(
        ast.AST(),
        False,
        ['a', 'b']
    )



# Generated at 2022-06-23 23:32:43.872637
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    t = CompilationResult(files=1, time=1.2, target=(2, 7),
                          dependencies=['a', 'b', 'c'])
    assert t.files == 1
    assert t.time == 1.2
    assert t.target == (2, 7)
    assert t.dependencies == ['a', 'b', 'c']



# Generated at 2022-06-23 23:32:48.155200
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files = 1,
                               time = 0.1,
                               target = (3, 5),
                               dependencies = [])
    
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 5)
    assert result.dependencies == []
    

# Generated at 2022-06-23 23:32:50.937078
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('abc')
    o = Path('abc.pyc')
    io = InputOutput(i, o)
    assert io == InputOutput(i, o)
    assert io.input == i
    assert io.output == o


# Generated at 2022-06-23 23:32:53.127006
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # pylint: disable=too-many-function-args
    pair = TransformationResult(None, None, None)
    assert pair.tree is None
    assert pair.tree_changed is None
    assert pair.dependencies is None

# Transformation function
Transformation = Callable[[ast.AST], TransformationResult]

# Generated at 2022-06-23 23:32:55.545173
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.AST([]), False, [])
    assert tr.tree == ast.AST([])
    assert tr.tree_changed == False
    assert tr.dependencies == []

# Generated at 2022-06-23 23:32:59.686940
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=42,
                                           time=3.14,
                                           target=(3, 5),
                                           dependencies=['foo', 'bar'])
    assert compilation_result.files == 42
    assert compilation_result.time == 3.14
    assert compilation_result.target == (3, 5)
    assert compilation_result.dependencies == ['foo', 'bar']


# Generated at 2022-06-23 23:33:05.032358
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # pylint: disable=too-few-public-methods
    class DummyTree:
        pass

    dummy_deps = ['abc', 'def']
    tr = TransformationResult(DummyTree(), True, dummy_deps)
    assert isinstance(tr, TransformationResult)
    assert isinstance(tr.tree, DummyTree)
    assert tr.tree_changed
    assert isinstance(tr.dependencies, list)
    assert tr.dependencies == dummy_deps

# Generated at 2022-06-23 23:33:07.214290
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_tree = ast.parse("pass")
    assert isinstance(ast_tree, ast.AST)
    trans_result = TransformationResult(ast_tree, True, ["example.py"])
    assert trans_result.tree == ast_tree
    assert trans_result.tree_changed == True
    assert trans_result.dependencies == ["example.py"]

# Generated at 2022-06-23 23:33:11.493748
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    comp = CompilationResult(1, 0.1, (3, 8), [])
    assert comp.files == 1
    assert comp.time == 0.1
    assert comp.target == (3, 8)
    assert comp.dependencies == []


# Generated at 2022-06-23 23:33:12.109674
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.AST(), True, ['a'])

# Generated at 2022-06-23 23:33:14.159408
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    assert TransformationResult(ast.parse("x = 1"),
                                True,
                                ["a", "b"])

# Generated at 2022-06-23 23:33:17.866212
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Test required fields
    input_output = InputOutput(input=Path("./"), output=Path("./"))
    input_output = InputOutput(input=Path("./"), output=Path("./"))
    assert input_output.input == Path("./")
    assert input_output.output == Path("./")



# Generated at 2022-06-23 23:33:21.442698
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('initial.py'), Path('final.py'))
    assert input_output.input == Path('initial.py')
    assert input_output.output == Path('final.py')


# Generated at 2022-06-23 23:33:30.840559
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 1
    time = 5.0
    target = (3, 7)
    deps = ["numpy", "matplotlib"]
    result = CompilationResult(files, time, target, deps)
    assert result.files == files
    assert result.time == time
    assert result.target == target
    assert result.dependencies == deps
    assert result == CompilationResult(files, time, target, deps)
    assert result != CompilationResult(files + 1, time, target, deps)
    assert result != CompilationResult(files, time + 1, target, deps)
    assert result != CompilationResult(files, time, target[::-1], deps)
    assert result != CompilationResult(files, time, target, deps[::-1])


# Generated at 2022-06-23 23:33:33.943580
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = InputOutput(Path('.'), Path('.'))
    assert '<' not in str(i)
    assert isinstance(i.input, Path)
    assert isinstance(i.output, Path)


# Generated at 2022-06-23 23:33:39.344852
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1, time=10.0, target=(3, 7),
                                           dependencies=['a', 'b'])
    assert compilation_result.files == 1
    assert compilation_result.time == 10.0
    assert compilation_result.target == (3, 7)
    assert compilation_result.dependencies == ['a', 'b']



# Generated at 2022-06-23 23:33:47.144061
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Check that no arguments
    with pytest.raises(TypeError):
        result = CompilationResult()

    # Check that we require all arguments
    with pytest.raises(TypeError):
        result = CompilationResult(files=2)

    with pytest.raises(TypeError):
        result = CompilationResult(time=3)

    with pytest.raises(TypeError):
        result = CompilationResult(target=(1, 2))

    with pytest.raises(TypeError):
        result = CompilationResult(dependencies=['name'])

    # Check that we get the right result
    result = CompilationResult(files=2,
                               time=3,
                               target=(1, 2),
                               dependencies=['name'])
    assert result.files == 2
    assert result.time == 3

# Generated at 2022-06-23 23:33:48.488226
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    node = ast.Module()
    assert TransformationResult(node, True, [])

# Generated at 2022-06-23 23:33:50.588649
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=0, time=0.0,
                      target=(3, 7), dependencies=[])


# Generated at 2022-06-23 23:33:56.950001
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from types import ModuleType
    from typed_ast import ast3

    tree = ast.parse('x = 3')
    tree_changed = True
    dependencies = [str(Path(ModuleType.__file__))]

    result = TransformationResult(tree, tree_changed, dependencies)

    assert isinstance(result.tree, ast3.AST)
    assert isinstance(result.tree_changed, bool)
    assert isinstance(result.dependencies, list)
    assert all(isinstance(path, str) for path in result.dependencies)

# Generated at 2022-06-23 23:34:01.245160
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Given
    tree = ast.parse('pass')
    tree_changed = True
    dependencies = ['a', 'b', 'c']

    # When
    result = TransformationResult(tree, tree_changed, dependencies)

    # Then
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-23 23:34:04.089177
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(tree=ast.parse('1 + 2'),
                                  tree_changed=True,
                                  dependencies=['/path/to/file'])
    assert result.tree_changed
    assert result.dependencies == ['/path/to/file']

# Generated at 2022-06-23 23:34:08.104308
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(
        files=0, time=0.0, target=(2, 7), dependencies=[])

    assert compilation_result.files == 0
    assert compilation_result.time == 0.0
    assert compilation_result.target == (2, 7)
    assert compilation_result.dependencies == []



# Generated at 2022-06-23 23:34:10.374374
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = 'input.py'
    o = 'output.py'
    p = InputOutput(input=i, output=o)
    assert p.input == i
    assert p.output == o

# Generated at 2022-06-23 23:34:14.200734
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.AST(), False, [])
    assert tr.tree_changed is False
    assert len(tr.dependencies) == 0


# Result of transformers transformers_sequence
SequenceResult = NamedTuple('SequenceResult',
                            [('tree', ast.AST),
                             ('transformed', bool),
                             ('dependencies', List[str])])


# Generated at 2022-06-23 23:34:16.644187
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('a'), Path('b'))
    assert input_output.input == Path('a')
    assert input_output.output == Path('b')


# Generated at 2022-06-23 23:34:23.143015
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=1, time=0.1, target=(3, 4), dependencies=[]).files == 1
    assert CompilationResult(files=2, time=0.2, target=(3, 4), dependencies=[]).time == 0.2
    assert CompilationResult(files=3, time=0.3, target=(3, 4), dependencies=[]).target == (3, 4)
    assert CompilationResult(files=4, time=0.4, target=(3, 4), dependencies=[]).dependencies == []


# Generated at 2022-06-23 23:34:28.653254
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=0, time=0.0, target=(3, 7),
                            dependencies=['foo', 'bar'])
    assert res.files == 0
    assert res.time == 0.0
    assert res.target == (3, 7)
    assert res.dependencies == ['foo', 'bar']


# Generated at 2022-06-23 23:34:29.348638
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(1, 1, 1)

# Generated at 2022-06-23 23:34:31.222229
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(2, 3), dependencies=[])


# Generated at 2022-06-23 23:34:34.303748
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # type: () -> None
    result = CompilationResult(1, 0.1, (3, 6), [r'C:\foo\bar.py'])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 6)
    assert result.dependencies == [r'C:\foo\bar.py']


# Generated at 2022-06-23 23:34:40.888874
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    from tests.compiler.test_utils import get_ast_tree
    from tests.compiler.transformer.test_utils import get_dependency, get_changed
    tree = get_ast_tree()
    depends = [get_dependency()]
    changed = get_changed()
    result = TransformationResult(tree, changed, depends)
    assert result.tree == tree
    assert result.tree_changed == changed
    assert result.dependencies == depends

# Generated at 2022-06-23 23:34:44.879890
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path_from = Path('from_path')
    path_to = Path('to_path')
    input_output = InputOutput(path_from, path_to)
    assert input_output.input == path_from
    assert input_output.output == path_to

# Generated at 2022-06-23 23:34:54.394713
# Unit test for constructor of class InputOutput
def test_InputOutput():
    with pytest.raises(AssertionError):
        InputOutput('/usr/bin/python', '/usr/log/python')
    with pytest.raises(AssertionError):
        InputOutput(Path('/usr/bin/python'), '/usr/log/python')
    with pytest.raises(AssertionError):
        InputOutput('/usr/bin/python', Path('/usr/log/python'))

    assert InputOutput(Path('/usr/bin/python'), Path('/usr/log/python')) \
            == InputOutput(Path('/usr/bin/python'), Path('/usr/log/python'))

# Generated at 2022-06-23 23:35:00.043398
# Unit test for constructor of class InputOutput
def test_InputOutput():
    import os

    input_path = os.path.join('.', 'input.py')
    output_path = os.path.join('.', 'output.py')

    input_output = InputOutput(input=input_path, output=output_path)

    assert input_output.input == Path(input_path)
    assert input_output.output == Path(output_path)



# Generated at 2022-06-23 23:35:01.762274
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.Call()
    TransformationResult(tree=t, tree_changed=False, dependencies=[])

# Generated at 2022-06-23 23:35:06.771997
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=1.0,
                               target=(3, 5),
                               dependencies=['foo.py'])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 5)
    assert result.dependencies == ['foo.py']


# Generated at 2022-06-23 23:35:10.341130
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cres = CompilationResult(
        files=10,
        time=0.1,
        target=(3, 6),
        dependencies=['a', 'b'])
    assert cres.files == 10
    assert cres.time == 0.1
    assert cres.target == (3, 6)
    assert cres.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:35:14.767979
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(10,
                                           10.3,
                                           (3, 6),
                                           ['file', 'path'])
    assert compilation_result.files == 10
    assert compilation_result.time == 10.3
    assert compilation_result.target == (3, 6)
    assert compilation_result.dependencies == ['file', 'path']


# Generated at 2022-06-23 23:35:16.678298
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(None, False, [])
    assert tr.dependencies is not None

# Generated at 2022-06-23 23:35:18.966415
# Unit test for constructor of class InputOutput
def test_InputOutput():
    with pytest.raises(TypeError):
        InputOutput('foo', 'bar')

    assert InputOutput(Path('foo'), Path('bar'))

# Generated at 2022-06-23 23:35:22.464759
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x')
    dependencies = []
    TransformationResult(tree, True, dependencies)
    TransformationResult(tree, False, dependencies)
    TransformationResult(tree, True, dependencies)
    TransformationResult(tree, False, dependencies)

# Generated at 2022-06-23 23:35:26.212565
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=10, time=0.2, target=(3, 5), dependencies=[])
    assert result.files == 10
    assert result.time == 0.2
    assert result.target == (3, 5)
    assert result.dependencies == []


# Generated at 2022-06-23 23:35:33.265093
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 42
    time = 12.34
    target = (3, 6)
    dependencies = ['a', 'b']

    # Test construction and all fields
    result = CompilationResult(files, time, target, dependencies)
    assert result.files == files
    assert result.time == time
    assert result.target == target
    assert result.dependencies == dependencies

    # Test that result can be read from json
    json = '{"files": 42, "time": 12.34, "target": [3, 6], "dependencies": ["a", "b"]}'
    assert CompilationResult.from_json(json) == result


# Generated at 2022-06-23 23:35:34.524278
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(input = Path('aaa'),
                output = Path('bbb'))

# Generated at 2022-06-23 23:35:39.242212
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test_tree = ast.parse("a = 1")
    test_dependencies = ['a.py']

    test_result = TransformationResult(test_tree, True, test_dependencies)

    assert test_result.tree == test_tree
    assert test_result.tree_changed == True
    assert test_result.dependencies == test_dependencies

# Name of standard library directory
LibDirName = 'stdlib'

# Path to standard library directory
LibDirPath = Path(os.path.dirname(os.path.abspath(__file__))) / LibDirName

# Generated at 2022-06-23 23:35:42.371614
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path("foo/bar"), Path("bar/bar"))
    assert io.input == Path("foo/bar")
    assert io.output == Path("bar/bar")


# Generated at 2022-06-23 23:35:49.536052
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('abc')
    tree_changed = True
    dependencies = ['first', 'second']

    TransformationResult(tree, tree_changed, dependencies)

# Result of transpiler run
TranspilationResult = NamedTuple('TranspilationResult',
                                  [('tree', ast.AST),
                                   ('file_changed', bool),
                                   ('file_unchanged', bool),
                                   ('input_output', InputOutput),
                                   ('dependencies', List[str])])


# Generated at 2022-06-23 23:35:51.315155
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # pylint: disable=unused-variable
    TransformationResult(1, 2, 3)

# Generated at 2022-06-23 23:35:52.815324
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a'), Path('b'))


# Generated at 2022-06-23 23:35:56.424526
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_input = Path('test.py')
    test_output = Path('test.out')
    input_output = InputOutput(input=test_input, output=test_output)
    assert input_output.input == test_input
    assert input_output.output == test_output



# Generated at 2022-06-23 23:35:58.566114
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('./src')
    output = Path('./out')
    t = InputOutput(input, output)
    assert t.input == input
    assert t.output == output

# Generated at 2022-06-23 23:36:00.378566
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('test/input')
    output = Path('test/output')
    pair = InputOutput(input, output)
    assert pair.input == input
    assert pair.output == output

# Generated at 2022-06-23 23:36:02.596083
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_io = Path('foo', 'bar', 'baz.py')
    output_io = Path('foo', 'bar', 'baz.pyc')
    io = InputOutput(input_io, output_io)

    assert io.input == input_io
    assert io.output == output_io

# Generated at 2022-06-23 23:36:07.187373
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(input=Path("/path/to/input"), output=Path("/path/to/output"))
    assert input_output.input == Path("/path/to/input")
    assert input_output.output == Path("/path/to/output")



# Generated at 2022-06-23 23:36:08.555142
# Unit test for constructor of class InputOutput
def test_InputOutput():
    _ = InputOutput('input', 'output')


# Generated at 2022-06-23 23:36:12.376421
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_tree = ast.Module([])
    deps = ["a", "b"]
    result = TransformationResult(ast_tree, True, deps)
    assert result.tree_changed == True
    assert result.dependencies == deps
    assert result.tree == ast_tree

# Generated at 2022-06-23 23:36:14.512884
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=42, time=0.1,
                      target=(3, 7), dependencies=['a', 'b'])

# Generated at 2022-06-23 23:36:20.040726
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(1, 2.0, (3, 4),
                                           ['a', 'b', 'c'])
    assert (compilation_result.files == 1)
    assert (compilation_result.time == 2.0)
    assert (compilation_result.target == (3, 4))
    assert (compilation_result.dependencies == ['a', 'b', 'c'])


# Generated at 2022-06-23 23:36:23.413965
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # GIVEN
    input_path = Path('/path/to/input')
    output_path = Path('/path/to/output')

    # WHEN
    input_output = InputOutput(input_path, output_path)

    # THEN
    assert input_output.input == input_path
    assert input_output.output == output_path



# Generated at 2022-06-23 23:36:30.680966
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    """
    Test for constructor of class TransformationResult.
    """
    assert TransformationResult(ast.AST(), False, [])

# Result of function optional_list_to_list
OptionalList = NamedTuple('OptionalList', [('list', List),
                                           ('empty', bool)])

# Result of the compilation of a file or directory
Compilation = NamedTuple('Compilation', [('input', Path),
                                         ('has_error', bool),
                                         ('time', float),
                                         ('target', CompilationTarget),
                                         ('dependencies', List[str])])


# Generated at 2022-06-23 23:36:34.050140
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input=Path('/input.py'),
                       output=Path('/output.py')) \
    == \
    InputOutput('/input.py', '/output.py')



# Generated at 2022-06-23 23:36:36.666615
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = InputOutput(input=Path('input'), output=Path('output'))

    assert i.input.name == 'input'
    assert i.output.name == 'output'

# Generated at 2022-06-23 23:36:37.798198
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput('input', 'output')

# Generated at 2022-06-23 23:36:41.349452
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('in.txt')
    output_path = Path('out.txt')
    input_output = InputOutput(input_path, output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path


# Generated at 2022-06-23 23:36:45.270914
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=0, time=0.0, target=(3, 6), dependencies=[])
    assert cr.files == 0
    assert cr.time == 0
    assert cr.target == (3, 6)
    assert cr.dependencies == []


# Generated at 2022-06-23 23:36:49.176140
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path(__file__), Path(__file__) + '.pyc')
    assert input_output.input != input_output.output
    assert input_output.input.exists()
    assert not input_output.output.exists()

# Generated at 2022-06-23 23:36:52.394532
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    transformer = TransformationResult(ast.parse("1 + 2"), False, [])
    assert transformer.tree_changed == False
    assert transformer.dependencies == []


# Pair of input and output directories
InputOutputDir = NamedTuple('InputOutputDir', [('input', Path),
                                               ('output', Path)])



# Generated at 2022-06-23 23:36:54.310932
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    tr = TransformationResult(ast.AST(), False, [])
    assert tr.tree is not None
    assert tr.tree_changed == False
    assert tr.dependencies == []

# Generated at 2022-06-23 23:36:57.637134
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(1, 2.3, (3, 4), [])
    assert c.files == 1
    assert c.time == 2.3
    assert c.target == (3, 4)
    assert c.dependencies == []


# Generated at 2022-06-23 23:36:59.999856
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(None, True, [])
    assert res.tree_changed == True
    assert res.dependencies == []

# Generated at 2022-06-23 23:37:04.140857
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('foo/bar/baz.py')
    output = Path('foo/bar/baz.pyc')
    io = InputOutput(input=input, output=output)
    assert io.input == input
    assert io.output == output

# Generated at 2022-06-23 23:37:05.811572
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    o = CompilationResult(5, 42.56, (3, 5), ['z', 'a'])



# Generated at 2022-06-23 23:37:06.875876
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.AST(), True, [])

# Generated at 2022-06-23 23:37:13.108678
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_dir = Path('/home/gusseppe/input')
    output_dir = Path('/home/gusseppe/output')
    input_name = 'input.py'
    output_name = 'output.py'

    # NamedTuple constructor
    io = InputOutput(input=input_dir/input_name,
                     output=output_dir/output_name)
    assert io.input == input_dir/input_name
    assert io.output == output_dir/output_name

    # Static constructor
    io = InputOutput.make(input_dir, output_dir, input_name, output_name)
    assert io.input == input_dir/input_name
    assert io.output == output_dir/output_name

# Generated at 2022-06-23 23:37:15.027690
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(files=0, time=0, target=(2, 3), dependencies=[])
    assert(isinstance(r, CompilationResult))


# Generated at 2022-06-23 23:37:19.740084
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Empty input
    result = CompilationResult(files=0, time=0, target=(3, 3),
                               dependencies=[])
    assert result.files == 0
    assert result.time == 0
    assert result.target == (3, 3)
    assert result.dependencies == []
    # Test with input
    result = CompilationResult(files=3, time=2.5, target=(3, 5),
                               dependencies=['foo.py', 'bar.py'])
    assert result.files == 3
    assert result.time == 2.5
    assert result.target == (3, 5)
    assert result.dependencies == ['foo.py', 'bar.py']



# Generated at 2022-06-23 23:37:25.199778
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 10
    time = 10.0
    target = (3, 6)
    dependencies = ["asd/asdf/asdf"]

    cre = CompilationResult(files, time, target, dependencies)
    assert cre.files == files
    assert cre.time == time
    assert cre.target == target
    assert cre.dependencies == dependencies


# Generated at 2022-06-23 23:37:28.985529
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(1, 2, 3)


# A transformation is a function which takes an AST and return
# a pair (new_ast, changed) with the new ast and a boolean
# indicating if the AST changed. This function should also return
# the dependencies (function name or filename) of the transformation.

# Generated at 2022-06-23 23:37:32.501659
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1,
                           time=2.0,
                           target=(3, 4),
                           dependencies=['a', 'b'])
    assert cr.files == 1
    assert cr.time == 2.0
    assert cr.target == (3, 4)
    assert cr.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:37:40.726016
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(ast.parse('x = 2'), False, ['foo', 'bar'])
    assert isinstance(t.tree, ast.AST)
    assert isinstance(t.tree_changed, bool)
    assert isinstance(t.dependencies, list)
    assert t.dependencies == ['foo', 'bar']
    assert repr(t) == 'TransformationResult(tree=Module(body=[Assign(targets=[Name(id=\'x\', ctx=Store())], value=Num(n=2))]), tree_changed=False, dependencies=[\'foo\', \'bar\'])'

# Generated at 2022-06-23 23:37:44.232381
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=1, time=0.0, target=(3, 5), dependencies=[])
    assert c.files == 1
    assert c.time == 0.0
    assert c.target == (3, 5)
    assert c.dependencies == []


# Generated at 2022-06-23 23:37:46.302385
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input=Path('input'), output=Path('output')) == \
        InputOutput(input=Path('input'), output=Path('output'))


# Generated at 2022-06-23 23:37:47.467986
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Parameterless constructor
    TransformationResult()

    # Constructor with parameters
    TransformationResult(tree=None,
                         tree_changed=False,
                         dependencies=[])


# Generated at 2022-06-23 23:37:49.438922
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(
        files=1,
        time=1.0,
        target=(3, 7),
        dependencies=['foo', 'bar']
    )

# Generated at 2022-06-23 23:37:50.444650
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(ast.Module(), False, [])

# Generated at 2022-06-23 23:37:52.278963
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/root/input')
    output = Path('/root/output')
    input_output = InputOutput(input, output)

    assert input_output.input == input
    assert input_output.output == output

# Generated at 2022-06-23 23:37:56.058320
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    comp_res = CompilationResult(files=1, time=1,
                                 target=(3, 7), dependencies=[])
    assert comp_res.time == 1
    assert comp_res.target == (3, 7)
    assert comp_res.dependencies == []


# Generated at 2022-06-23 23:38:01.971876
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files_count = 2
    time_taken = 0.5
    major, minor = 3, 7

    result = CompilationResult(files_count, time_taken, (major, minor), [])

    assert result.files == files_count
    assert result.time == time_taken
    assert result.target == (major, minor)
    assert result.dependencies == []



# Generated at 2022-06-23 23:38:03.602327
# Unit test for constructor of class InputOutput
def test_InputOutput():
    file = Path('input')
    out = Path('output')
    input_output = InputOutput(file, out)
    assert input_output.input == file
    assert input_output.output == out


# Generated at 2022-06-23 23:38:10.484508
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    import datetime

    tree = ast.parse('pass')
    result = TransformationResult(tree, False, [])
    assert isinstance(result, TransformationResult)
    assert isinstance(result.tree, ast.AST)
    assert not result.tree_changed
    assert isinstance(result.dependencies, list)
    assert all(x.__class__.__name__ == 'str' for x in result.dependencies)

    result = TransformationResult(tree, True, [])
    assert isinstance(result, TransformationResult)
    a

# Generated at 2022-06-23 23:38:14.774526
# Unit test for constructor of class InputOutput
def test_InputOutput():
    data = [
        (['a', 'b'], Path('a'), Path('b')),
        ((Path('a'), Path('b')), Path('a'), Path('b')),
    ]
    for args, input, output in data:
        assert InputOutput(*args).input == input
        assert InputOutput(*args).output == output

# Generated at 2022-06-23 23:38:17.425772
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1,
                      time=1.0,
                      target=(2, 7),
                      dependencies=['a', 'b', 'c'])


# Generated at 2022-06-23 23:38:19.273415
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # type: () -> None
    InputOutput(input=Path('input'), output=Path('output'))



# Generated at 2022-06-23 23:38:22.813844
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('1+1')
    dependencies = ['a', 'b']
    transformation_result = TransformationResult(tree, False, dependencies)
    assert transformation_result.tree_changed == False
    assert transformation_result.dependencies == dependencies

# Generated at 2022-06-23 23:38:25.703738
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # pylint: disable=missing-docstring,too-few-public-methods,no-self-use
    class A(object):
        pass
    assert TransformationResult(A(), True, []).tree is A()

# Generated at 2022-06-23 23:38:29.514592
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    x = CompilationResult(1, 3.0, (3, 5), [])
    assert x.files == 1
    assert x.time == 3.0
    assert x.target == (3, 5)
    assert x.dependencies == []



# Generated at 2022-06-23 23:38:33.192910
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = 'example/abs_sum.py'
    path2 = 'example/sum.py'
    a = InputOutput(Path(path1), Path(path2))

    assert str(a.input) == path1
    assert str(a.output) == path2


# Generated at 2022-06-23 23:38:34.645445
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # One of the members is a bool, so this is not a simple FIXME
    TransformationResult(None, None, None)

# Generated at 2022-06-23 23:38:36.014160
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(0, 0.0, (3, 5), {})


# Generated at 2022-06-23 23:38:38.141289
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(ast.AST(), True, [])
    assert result.tree_changed == True
    result = TransformationResult(ast.AST(), False, [])
    assert result.tree_changed == False

# Generated at 2022-06-23 23:38:41.723225
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path('path1')
    path2 = Path('path2')
    inout = InputOutput(path1, path2)
    assert inout.input == path1
    assert inout.output == path2

# Generated at 2022-06-23 23:38:47.086376
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=1.0, target=(3, 8),
                           dependencies=['dep1', 'dep2'])
    assert cr.files == 1
    assert cr.time == 1.0
    assert cr.target == (3, 8)
    assert cr.dependencies == ['dep1', 'dep2']


# Generated at 2022-06-23 23:38:50.043166
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, False, None)
    assert TransformationResult(None, True, None)
    assert TransformationResult(None, True, [])
    assert TransformationResult(None, True, ["d1"])

# Generated at 2022-06-23 23:38:51.347797
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2, 3, 4)  # should not raise

# Generated at 2022-06-23 23:38:52.743009
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # type: () -> None
    InputOutput(Path('foo'), Path('bar'))



# Generated at 2022-06-23 23:38:54.863520
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # pylint: disable=line-too-long
    assert TransformationResult(tree=ast.AST(), tree_changed=False, dependencies=['foo', 'bar'])


# Generated at 2022-06-23 23:38:58.435612
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input=Path('input'), output=Path('output')) == \
           InputOutput(input=Path('input'), output=Path('output'))

    assert InputOutput(input=Path('input'), output=Path('output')) != \
           InputOutput(input=Path('input'), output=Path('output2'))

    assert InputOutput(input=Path('input'), output=Path('output')) != \
           InputOutput(input=Path('input2'), output=Path('output'))

# Generated at 2022-06-23 23:39:00.211049
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = InputOutput(Path('a'), Path('b'))
    assert a[0].name == 'a'
    assert a[1].name == 'b'


# Generated at 2022-06-23 23:39:07.058890
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # pylint: disable=unnecessary-comprehension
    TransformationResult()  # pylint: disable=no-value-for-parameter
    TransformationResult([], [])  # pylint: disable=no-value-for-parameter
    TransformationResult([i for i in range(10)], [i for i in range(20)])
    TransformationResult(tree=ast.parse('a=1'), tree_changed=True, dependencies=['a', 'b'])

# Generated at 2022-06-23 23:39:08.134043
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.AST(), False, [])

# Generated at 2022-06-23 23:39:10.349131
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(tree=ast.parse('1 + 1'),
                         tree_changed=True,
                         dependencies=[])

# Generated at 2022-06-23 23:39:14.156863
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('inp.py')
    out = Path('out.py')
    i_o = InputOutput(inp, out)

    assert i_o.input is inp
    assert i_o.output is out


# Generated at 2022-06-23 23:39:17.951311
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    obj = TransformationResult(tree=ast.parse(''), tree_changed=True, dependencies=['a', 'b'])
    assert(obj.tree is not None)
    assert(obj.tree_changed is True)
    assert(obj.dependencies == ['a', 'b'])

# Generated at 2022-06-23 23:39:19.471850
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    _ = CompilationResult(files=2, time=45.0, target=(2, 7),
                          dependencies=['foo', 'bar'])


# Generated at 2022-06-23 23:39:23.143825
# Unit test for constructor of class CompilationResult
def test_CompilationResult():  # noqa
    compilation_result = CompilationResult(files=1,
                                           time=0.0,
                                           target=(3, 6),
                                           dependencies=[])
    assert compilation_result.files == 1
    assert compilation_result.time == 0.0
    assert compilation_result.target == (3, 6)
    assert compilation_result.dependencies == []


# Generated at 2022-06-23 23:39:32.536562
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.AST(), True, ['a', 'b'])
    assert tr.tree_changed
    assert tr.dependencies == ['a', 'b']


# Info about dependencies
DependencyInfo = NamedTuple('DependencyInfo', [('dependencies', List[str]),
                                               ('curdir', Path),
                                               ('pycache', Path)])


# List of files to compile
CompilationFileInfo = NamedTuple('CompilationFileInfo',
                                 [('in_path', Path),
                                  ('out_path', Path),
                                  ('dependency_info', DependencyInfo)])

# Create empty DependencyInfo

# Generated at 2022-06-23 23:39:35.221770
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    pair = InputOutput(input, output)
    assert pair.input == input
    assert pair.output == output

# Generated at 2022-06-23 23:39:37.021283
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(10, 13, (3, 5), ['a', 'b'])



# Generated at 2022-06-23 23:39:37.764674
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.AST(), False, [])

# Generated at 2022-06-23 23:39:41.556573
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(tree = ast.parse("x = a"),
                                  tree_changed = True,
                                  dependencies = ['a'])
    assert isinstance(result.tree, ast.AST)
    assert result.tree_changed
    assert result.dependencies == ['a']

# Generated at 2022-06-23 23:39:46.290550
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=1, time=5.0, target=(2,7), dependencies=[])
    assert CompilationResult(files=2, time=10.0, target=(3,5), dependencies=["foo", "bar"])
    assert CompilationResult(files=0, time=0.0, target=(3,6), dependencies=["foo", "bar", "baz", "quux"])


# Generated at 2022-06-23 23:39:48.835092
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput("input.py", "output.py")
    assert io.input == Path("input.py")
    assert io.output == Path("output.py")

# Generated at 2022-06-23 23:39:50.551837
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(0, 0.0, (0, 0), [])



# Generated at 2022-06-23 23:40:01.573357
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    a = CompilationResult(1, 2.0, (3, 4), ['a', 'b', 'c'])
    assert a.files == 1
    assert a.time == 2.0
    assert a.target == (3, 4)
    assert set(a.dependencies) == {'a', 'b', 'c'}
    assert a == CompilationResult(1, 2.0, (3, 4), ['a', 'b', 'c'])
    assert a != CompilationResult(2, 2.0, (3, 4), ['a', 'b', 'c'])
    assert a != CompilationResult(1, 1.0, (3, 4), ['a', 'b', 'c'])

# Generated at 2022-06-23 23:40:03.518635
# Unit test for constructor of class InputOutput
def test_InputOutput():
    sample = InputOutput(Path('input.txt'), Path('output.txt'))
    assert sample.input == Path('input.txt')
    assert sample.output == Path('output.txt')

# Generated at 2022-06-23 23:40:07.651801
# Unit test for constructor of class InputOutput
def test_InputOutput():
    cwd = Path.cwd()
    input = cwd / 'input.py'
    output = cwd / 'output.py'
    input_output = InputOutput(input=input, output=output)
    assert isinstance(input_output, InputOutput)
    assert input_output.input == input


# Generated at 2022-06-23 23:40:11.251850
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input')
    output = Path('/tmp/output')
    result = InputOutput(input, output)
    assert result.input == input
    assert result.output == output


# Generated at 2022-06-23 23:40:18.359495
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> bool
    def get_tree():  # type: () -> ast.AST
        tree = ast.parse('a = 1')
        return tree

    dependencies = []
    tr = TransformationResult(get_tree(), True, dependencies)
    assert True

    return True


# Result of checkers check
CheckingResult = NamedTuple('CheckingResult',
                            [('warning', bool),
                             ('warning_message', str),
                             ('error', bool),
                             ('error_message', str),
                             ('dependencies', List[str])])


# Generated at 2022-06-23 23:40:20.070262
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 1.0, (3, 6), [])


# Generated at 2022-06-23 23:40:21.504651
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2.0, (3, 4), ['a', 'b'])


# Generated at 2022-06-23 23:40:23.942742
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('x = "xx"')
    assert TransformationResult(t, False, ["d1.py", "d2.py"])

# Generated at 2022-06-23 23:40:25.994195
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p = Path('foo')
    io = InputOutput(p, p)
    assert io.input == p and io.output == p



# Generated at 2022-06-23 23:40:27.113349
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('a/b')
    output = Path('c/d')
    pair = InputOutput(input, output)
    assert pair.input == input
    assert pair.output == output


# Generated at 2022-06-23 23:40:30.312616
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """Tests constructor of class InputOutput"""
    input_output_pair = InputOutput("input", "output")
    assert input_output_pair.input == Path("input")
    assert input_output_pair.output == Path("output")


# Generated at 2022-06-23 23:40:39.151173
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Create simple example
    p = Path('/tmp/foo.py')
    inp = InputOutput(input=p, output=p.with_suffix('.pyc'))

    # Check attributes
    assert inp.input == p
    assert inp.output == p.with_suffix('.pyc')
    assert inp.input.parent == p.parent
    assert inp.output.parent == p.with_suffix('.pyc').parent
    assert inp.input.stem == p.stem
    assert inp.output.stem == p.with_suffix('.pyc').stem
    assert inp.input.suffix == p.suffix
    assert inp.output.suffix == p.with_suffix('.pyc').suffix

    # Check string representation

# Generated at 2022-06-23 23:40:42.357368
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('test/dir/test.in')
    out = Path('test/dir/test.out')
    pair = InputOutput(inp, out)
    assert pair.input == inp
    assert pair.output == out
    assert repr(pair) == "InputOutput(input='test/dir/test.in', output='test/dir/test.out')"


# Generated at 2022-06-23 23:40:49.075605
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    v = TransformationResult(None, False, [])
    assert v.tree == None
    assert v.tree_changed == False
    assert v.dependencies == []
    assert repr(v) == "TransformationResult(tree=None, tree_changed=False, dependencies=[])"

# Information about a command line option
Option = NamedTuple('Option', [('shortname', str),
                               ('longname', str),
                               ('description', str)])

# Generated at 2022-06-23 23:40:59.484599
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    import ast
    import pytest
    from io import StringIO
    from typing import List
    from typed_ast import ast3 as ast

    tree = ast.parse('x = 1', mode='eval')
    changed_tree = ast.parse('x = 1', mode='eval')
    changed_tree.body.value.n += 1
    with pytest.raises(TypeError):
        # noinspection PyArgumentList
        TransformationResult(tree, True, ['a'])
    with pytest.raises(TypeError):
        # noinspection PyArgumentList
        TransformationResult(tree, True, ['a'])
    with pytest.raises(TypeError):
        TransformationResult(tree, False, [1])
    with pytest.raises(TypeError):
        TransformationResult(tree, False, ['a', 1])

# Generated at 2022-06-23 23:41:03.200240
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=0, time=0.,
                           target=(3, 4), dependencies=[])
    assert cr.files == 0
    assert cr.time == 0.
    assert cr.target == (3, 4)
    assert cr.dependencies == []


# Generated at 2022-06-23 23:41:11.169088
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # pylint: disable=too-few-public-methods
    class CompilationResult_(CompilationResult):
        def __new__(cls):
            files = 10
            time = 8.0
            target = (3, 6)
            dependencies = []
            return CompilationResult.__new__(cls, files, time, target, dependencies)
    compilation_result = CompilationResult_()
    assert compilation_result.files == 10
    assert compilation_result.time == 8.0
    assert compilation_result.target == (3, 6)
    assert compilation_result.dependencies == []


# Generated at 2022-06-23 23:41:15.527092
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path("test")
    output = Path("test")

    result = InputOutput(input, output)

    # test that strings were properly converted to Paths
    assert type(result.input) == Path
    assert type(result.output) == Path

    # test that correct values were set
    assert result.input == Path("test")
    assert result.output == Path("test")

# Generated at 2022-06-23 23:41:17.578790
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(input=Path('a'), output=Path('b'))
    assert io.input == Path('a')
    assert io.output == Path('b')


# Generated at 2022-06-23 23:41:18.468111
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.AST(), False, [])

# Generated at 2022-06-23 23:41:21.993683
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.Module(), False, [])
    assert TransformationResult(ast.Module(), False, ['file1', 'file2']).dependencies == ['file1', 'file2']


__all__ = ['CompilationResult', 'InputOutput', 'TransformationResult']

del NamedTuple

# Generated at 2022-06-23 23:41:25.074597
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    x = CompilationResult(1, 12.3, (3, 5), ['foo.py'])
    assert x.files == 1
    assert x.time == 12.3
    assert x.target == (3, 5)
    assert x.dependencies == ['foo.py']


# Generated at 2022-06-23 23:41:28.042271
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=3, time=0.1, target=(3, 5), dependencies=["a", "b"])
    assert cr.files == 3
    assert cr.time == 0.1
    assert cr.target == (3, 5)
    assert cr.dependencies == ["a", "b"]


# Generated at 2022-06-23 23:41:32.325512
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(1, 2, (3, 4), ['d1', 'd2'])
    assert cr.files == 1
    assert cr.time == 2
    assert cr.target == (3, 4)
    assert cr.dependencies == ['d1', 'd2']


# Generated at 2022-06-23 23:41:35.678438
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path("some_string")
    o = Path("some_other_string")
    io = InputOutput(input=i, output=o)
    assert io.input is i
    assert io.output is o

# Generated at 2022-06-23 23:41:39.078546
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(ast.parse("1+1"), False, [])
    assert result.tree is not None
    assert result.tree_changed == False
    assert result.dependencies is not None


# Generated at 2022-06-23 23:41:46.867108
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('build/_all_tests/test1.py'), Path('build/test1.py')) == \
           InputOutput(Path('build/_all_tests/test1.py'), Path('build/test1.py'))

    assert InputOutput(Path('build/_all_tests/test1.py'), Path('build/test1.py')) != \
           InputOutput(Path('build/test0.py'), Path('build/test1.py'))

# Generated at 2022-06-23 23:41:52.631028
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=10,
                               time=0.051,
                               target=(3, 7),
                               dependencies=['foo/bar.py'])
    assert result.files == 10
    assert result.time == 0.051
    assert result.target == (3, 7)
    assert result.dependencies == ['foo/bar.py']


# Generated at 2022-06-23 23:41:57.557194
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(
        files=10,
        time=42.0,
        target=(3, 5),
        dependencies=['p0', 'p1']
    )

    assert compilation_result.files == 10
    assert compilation_result.time == 42.0
    assert compilation_result.target == (3, 5)
    assert compilation_result.dependencies == ['p0', 'p1']
