

# Generated at 2022-06-23 23:32:04.589216
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=0, time=0, target=(3, 6), dependencies=[])

# Unit tests for constructor of class InputOutput

# Generated at 2022-06-23 23:32:07.113853
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    node = ast.Module()
    result = TransformationResult(node, True, [])
    assert type(result) == TransformationResult
    assert result.tree == node
    assert result.tree_changed == True
    assert result.dependencies == []

# Generated at 2022-06-23 23:32:08.541673
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput('input', 'output')
    assert io.input == 'input'
    assert io.output == 'output'


# Generated at 2022-06-23 23:32:13.084484
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path("/tmp/foo")
    output_path = Path("/tmp/bar")
    pair = InputOutput(input_path, output_path)
    assert pair.input == input_path
    assert pair.output == output_path



# Generated at 2022-06-23 23:32:16.193569
# Unit test for constructor of class InputOutput
def test_InputOutput():
    with pytest.raises(TypeError):
        InputOutput(input=Path(__file__), output=__file__)
    with pytest.raises(TypeError):
        InputOutput(input=__file__, output=Path(__file__))

# Generated at 2022-06-23 23:32:20.024726
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree = ast.parse("1+1"),
                              tree_changed = False,
                              dependencies = [])
    assert(tr.tree_changed == False)
    assert(tr.tree != None)
    assert(tr.dependencies == [])

# Generated at 2022-06-23 23:32:21.346451
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=2, time=3.0,
                             target=(2, 6), dependencies=['foo'])

# Generated at 2022-06-23 23:32:23.276864
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path('foo.txt'), Path('bar.txt'))
    assert io.input == Path('foo.txt')
    assert io.output == Path('bar.txt')
    # TODO python 3.5, __str__ and __repr__

# Generated at 2022-06-23 23:32:25.225924
# Unit test for constructor of class InputOutput
def test_InputOutput():
    with pytest.raises(TypeError):
        InputOutput(Path, Path)
    with pytest.raises(TypeError):
        InputOutput(1, 2)


# Generated at 2022-06-23 23:32:27.530207
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(tree=ast.parse('a=1'),
                         tree_changed=True,
                         dependencies=['a'])

# Generated at 2022-06-23 23:32:28.917169
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    pass

# Generated at 2022-06-23 23:32:31.969617
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    r = TransformationResult(tree, False, [])
    assert r.tree is tree
    assert r.tree_changed == False
    assert r.dependencies == []

# Generated at 2022-06-23 23:32:35.959621
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path_in = Path('test/test.py')
    path_out = Path('test/test.pyc')
    input_output = InputOutput(input=path_in, output=path_out)
    assert input_output.input == path_in
    assert input_output.output == path_out


# Generated at 2022-06-23 23:32:39.767331
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=123,
                           time=0.1,
                           target=(3, 4),
                           dependencies=['hello', 'world'])
    assert cr.files == 123
    assert cr.time == 0.1
    assert cr.target == (3, 4)
    assert cr.dependencies == ['hello', 'world']


# Generated at 2022-06-23 23:32:43.371604
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a.py'), Path('b.py')).input == Path('a.py')
    assert InputOutput(Path('a.py'), Path('b.py')).output == Path('b.py')


# Generated at 2022-06-23 23:32:45.182967
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('print(1)')
    result = TransformationResult(tree, True, [])

# Generated at 2022-06-23 23:32:47.620614
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('')
    tree_changed = False
    dependencies = []
    TransformationResult(tree=tree, tree_changed=tree_changed,
                         dependencies=dependencies)

# Generated at 2022-06-23 23:32:50.166683
# Unit test for constructor of class InputOutput
def test_InputOutput():
    f = InputOutput(Path("test1"), Path("test2"))
    assert f.input == Path("test1")
    assert f.output == Path("test2")
    assert f.input == Path("test1")

# Generated at 2022-06-23 23:32:51.951262
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Given
    input_ = Path('input')
    output = Path('output')

    # When
    pair = InputOutput(input_, output)

    # Then
    assert pair.input == input_
    assert pair.output == output

# Generated at 2022-06-23 23:32:56.335817
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=ast.parse('x = 1'),
                              tree_changed=True,
                              dependencies=['a', 'b'])
    assert tr.tree is not None, "Should not be None"
    assert tr.tree_changed is True, "Should be True"
    assert tr.dependencies == ['a', 'b'], "Should be ['a', 'b']"


# Result of transformers transformation
TransformationResultWrapper = NamedTuple('TransformationResultWrapper',
                                         [('path', Path),
                                          ('result', TransformationResult)])


# Generated at 2022-06-23 23:32:58.687038
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input, output = ('/tmp/input.py', '/tmp/output.py')
    assert InputOutput(Path(input), Path(output)).input == input
    assert InputOutput(Path(input), Path(output)).output == output

# Generated at 2022-06-23 23:33:00.883952
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    code = "print('hello')"
    tree = ast.parse(code)
    assert(TransformationResult(tree=tree, tree_changed=True, dependencies=[]))

# Generated at 2022-06-23 23:33:08.700951
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Input/output pair (with file names)
    io = InputOutput('foo.py', 'bar.py')
    assert io == InputOutput(Path('foo.py'), Path('bar.py'))

    # Input/output pair (with paths)
    io = InputOutput(Path('foo.py'), Path('bar.py'))
    assert io == InputOutput(Path('foo.py'), Path('bar.py'))

    # Input/output pair (with different types)
    io = InputOutput('foo.py', Path('bar.py'))
    assert io == InputOutput(Path('foo.py'), Path('bar.py'))

    # Input/output pair (with non-str/Path types)

# Generated at 2022-06-23 23:33:12.259512
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path('/tmp/input.py'), Path('/tmp/output.py'))
    assert io.input == Path('/tmp/input.py')
    assert io.output == Path('/tmp/output.py')



# Generated at 2022-06-23 23:33:14.627230
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1,
                      time=0.5,
                      target=(3, 7),
                      dependencies=['foo.py'])


# Generated at 2022-06-23 23:33:16.639637
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse(''), False, ['foo', 'bar']).dependencies == ['foo', 'bar']

# Generated at 2022-06-23 23:33:18.847760
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput('input', 'output').input == 'input'
    assert InputOutput('input', 'output').output == 'output'

# Generated at 2022-06-23 23:33:23.276951
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("x + y")
    tree_changed = True
    dependencies = ['f1.py', 'f2.py']
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-23 23:33:28.797930
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path("a")
    outp = Path("b")
    # Test initialization
    inout = InputOutput(input=inp, output=outp)
    assert inout.input == inp
    assert inout.output == outp
    # Test __repr__
    assert repr(inout) == f"InputOutput(input={repr(inp)}, " \
                          f"output={repr(outp)})"


# Generated at 2022-06-23 23:33:30.068546
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """Check InputOutput constructor"""
    input = Path('/foo/bar')
    output = Path('/baz/quux')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-23 23:33:32.082694
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('pass')
    res = TransformationResult(t, True, ['dep1', 'dep2'])
    assert res.tree_changed

# Generated at 2022-06-23 23:33:32.535070
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    Transfor

# Generated at 2022-06-23 23:33:34.984330
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.Module(),
                                True,
                                []) == TransformationResult(tree=ast.Module(),
                                                            tree_changed=True,
                                                            dependencies=[])

# Generated at 2022-06-23 23:33:38.085251
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p = Path('input.py')
    q = Path('output.py')
    input_output = InputOutput(p, q)
    assert input_output.input == p
    assert input_output.output == q

# Generated at 2022-06-23 23:33:43.164376
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = InputOutput(Path('/path/to/foo.py'), Path('/path/to/bar.py'))

    assert a[0] == Path('/path/to/foo.py')
    assert a[1] == Path('/path/to/bar.py')

    assert a.input == Path('/path/to/foo.py')
    assert a.output == Path('/path/to/bar.py')



# Generated at 2022-06-23 23:33:46.766365
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(tree=ast.parse("x=y"), tree_changed=False,
                                  dependencies=["a", "b"])
    assert result.tree != None
    assert result.tree_changed == False
    assert len(result.dependencies) == 2
    assert result.dependencies[0] == "a"
    assert result.dependencies[1] == "b"

# Generated at 2022-06-23 23:33:56.156651
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('__init__.py')
    output = Path('bar.py')
    input_output = InputOutput(input_, output)
    assert input_output[0] == input_
    assert input_output[1] == output
    with pytest.raises(TypeError) as excinfo:
        InputOutput('__init__.py', Path('bar.py'))
    assert str(excinfo.value) == 'The paths need to be pathlib.Path objects.'
    with pytest.raises(TypeError) as excinfo:
        InputOutput(Path('__init__.py'), 'bar.py')
    assert str(excinfo.value) == 'The paths need to be pathlib.Path objects.'
    with pytest.raises(TypeError) as excinfo:
        InputOutput(None, None)


# Generated at 2022-06-23 23:33:57.371816
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(input=Path('input'), output=Path('output'))


# Generated at 2022-06-23 23:34:00.010301
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = InputOutput(input = Path('a'), output = Path('b'))
    assert i.input == Path('a')
    assert i.output == Path('b')


# Generated at 2022-06-23 23:34:02.738337
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path("__init__.py")
    output = Path("__init__.pyc")
    input_output = InputOutput(input, output)
    assert(input_output.input == input)
    assert(input_output.output == output)

# Generated at 2022-06-23 23:34:05.601834
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(1, 1.2, (3, 7), ['hello.py'])
    assert c.files == 1
    assert c.time == 1.2
    assert c.target == (3, 7)
    assert c.dependencies == ['hello.py']


# Generated at 2022-06-23 23:34:11.761662
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    from test import test_tree, test_tree_changed, test_dependencies
    input = 'some sample input'
    output = 'some sample output'
    result = TransformationResult(tree=test_tree,
                                  tree_changed=test_tree_changed,
                                  dependencies=test_dependencies)
    assert isinstance(result, TransformationResult)
    assert result.tree == test_tree
    assert result.tree_changed == test_tree_changed
    assert result.dependencies == test_dependencies

# Result of transpilation
TranspilationResult = NamedTuple('TranspilationResult',
                                 [('source', str),
                                  ('dependencies', List[str])])


# Generated at 2022-06-23 23:34:14.134488
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('pass')
    tr = TransformationResult(tree=t, tree_changed=True, dependencies=[])
    assert tr.tree == t
    assert tr.tree_changed == True
    assert tr.dependencies == []


# Generated at 2022-06-23 23:34:18.252912
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(3, 8), dependencies=['pysqlite'])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 8)
    assert result.dependencies == ['pysqlite']



# Generated at 2022-06-23 23:34:20.631583
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=None,
                                tree_changed=False,
                                dependencies=None)

# Generated at 2022-06-23 23:34:26.775082
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # pylint: disable=missing-class-docstring
    # pylint: disable=too-few-public-methods
    class Test(NamedTuple):
        input: Path
        output: Path

    test_obj = Test('1', '2')
    assert test_obj.input == Path('1')
    assert test_obj.output == Path('2')

# Generated at 2022-06-23 23:34:30.874144
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    x = CompilationResult(files=2, time=2.0, target=(2, 7), dependencies=[])
    assert x.files == 2
    assert x.time == 2.0
    assert x.target == (2, 7)
    assert x.dependencies == []



# Generated at 2022-06-23 23:34:38.455848
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    """
    Test to ensure the constructor of CompilationResult works as expected.
    """
    result = CompilationResult(files=1,
                               time=1.0,
                               target=(3,7),
                               dependencies=['x.py', 'y.py'])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3,7)
    assert result.dependencies == ['x.py', 'y.py']


# Generated at 2022-06-23 23:34:40.591436
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p = Path('foo.py')
    x = InputOutput(p, p)
    assert x.input == p
    assert x.output == p



# Generated at 2022-06-23 23:34:44.333753
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=1.0,
                               target=(3, 7),
                               dependencies=['a', 'b', 'c'])
    assert isinstance(result, CompilationResult)


# Generated at 2022-06-23 23:34:52.047361
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path('foo')
    path2 = Path('bar')
    t = InputOutput(path1, path2)
    assert t.input == path1
    assert t.output == path2
    try:
        # type: ignore
        t.input = path2
    except AttributeError:
        pass
    else:
        raise TypeError('InputOutput.input is read only')
    try:
        # type: ignore
        t.output = path1
    except AttributeError:
        pass
    else:
        raise TypeError('InputOutput.output is read only')



# Generated at 2022-06-23 23:34:55.482964
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 2.0, (3, 4), ['foo', 'bar'])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == ['foo', 'bar']



# Generated at 2022-06-23 23:35:01.284487
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=1.0, target=(3, 5),
                           dependencies=['a', 'b'])
    assert (cr.files == 1)
    assert (cr.time == 1.0)
    assert (cr.target == (3, 5))
    assert (cr.dependencies == ['a', 'b'])
    print('CompilationResult done')


# Generated at 2022-06-23 23:35:05.875141
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=2, time=1.2,
                            target=(1, 2), dependencies=['a', 'b'])
    assert res.files == 2
    assert res.time == 1.2
    assert res.target == (1, 2)
    assert res.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:35:07.541764
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=1, time=0, target=(2, 7), dependencies=[])


# Generated at 2022-06-23 23:35:08.572441
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('1'), Path('2'))


# Generated at 2022-06-23 23:35:11.220679
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    res = TransformationResult(tree, True, ['a', 'b'])
    assert res.tree == tree
    assert res.tree_changed
    assert res.dependencies == ['a', 'b']

# Generated at 2022-06-23 23:35:16.125816
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    i = TransformationResult(None, False, [])
    assert i.tree == None
    assert i.tree_changed == False
    assert len(i.dependencies) == 0

    i = TransformationResult(ast.parse('1'), True, ['123'])
    assert ast.dump(i.tree) == 'Expression(body=Num(n=1))'
    assert i.tree_changed == True
    assert len(i.dependencies) == 1
    assert i.dependencies == ['123']

# Generated at 2022-06-23 23:35:23.534584
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    class_transformation_result = TransformationResult(ast.parse('a = 1'),
                                                       True,
                                                       ['a.py'])
    assert isinstance(class_transformation_result.tree, ast.AST)
    assert isinstance(class_transformation_result.tree_changed, bool)
    assert isinstance(class_transformation_result.dependencies, list)
    assert len(class_transformation_result.dependencies) == 1
    assert class_transformation_result.dependencies[0].endswith(".py")

# Generated at 2022-06-23 23:35:32.737860
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    comp_result = CompilationResult(files=1,
                                    time=1.0,
                                    target=(3, 5),
                                    dependencies=[])
    assert isinstance(comp_result.files, int)
    assert isinstance(comp_result.time, float)
    assert isinstance(comp_result.target, CompilationTarget)
    assert isinstance(comp_result.dependencies, List)
    comp_result = CompilationResult(files='1',
                                    time='1.0',
                                    target='(3, 5)',
                                    dependencies='')
    assert isinstance(comp_result.files, int)
    assert isinstance(comp_result.time, float)
    assert isinstance(comp_result.target, CompilationTarget)
    assert isinstance(comp_result.dependencies, List)

#

# Generated at 2022-06-23 23:35:35.123764
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('1')
    tr = TransformationResult(tree, True, [])
    assert tr.tree
    assert tr.tree_changed
    assert tr.dependencies == []

# Generated at 2022-06-23 23:35:35.959074
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    pass


# Generated at 2022-06-23 23:35:45.463183
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=ast.Expression(ast.Name(id='foo',
                                                            ctx=ast.Load(),
                                                            lineno=2,
                                                            col_offset=3,
                                                            end_lineno=4,
                                                            end_col_offset=5)),
                              tree_changed=True,
                              dependencies=['foo.py', 'bar.py'])
    assert tr.tree.lineno == 2
    assert tr.tree.col_offset == 3
    assert tr.tree.end_lineno == 4
    assert tr.tree.end_col_offset == 5
    assert tr.tree_changed
    assert len(tr.dependencies) == 2

# Generated at 2022-06-23 23:35:51.362557
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 1
    time = 0.1
    target = (3, 7)
    dependencies = ['dependency1.py']
    compilation_result = CompilationResult(
        files=files, time=time, target=target, dependencies=dependencies)
    assert compilation_result.files == files
    assert compilation_result.time == time
    assert compilation_result.target == target
    assert compilation_result.dependencies == dependencies


# Generated at 2022-06-23 23:35:56.267558
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('in'), Path('out')) == InputOutput('in', 'out')
    assert InputOutput(Path('in'), Path('out')) != InputOutput('in', 'err')
    assert InputOutput(Path('in'), Path('out')) != InputOutput('err', 'out')
    assert InputOutput(Path('in'), Path('out')) != InputOutput('err', 'err')

# Generated at 2022-06-23 23:35:58.592310
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('a')
    outp = Path('b')
    inout = InputOutput(inp, outp)
    assert inout.input == inp
    assert inout.output == outp



# Generated at 2022-06-23 23:36:01.979322
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 2.0, (2,7), ['a', 'b'])
    assert result.files == 1 and result.time == 2.0 and result.target == (2, 7) and result.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:36:07.036804
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=1.234, target=(3, 8), dependencies=['foo.py'])
    assert cr.files == 1
    assert cr.time == 1.234
    assert cr.target == (3, 8)
    assert cr.dependencies == ['foo.py']


# Generated at 2022-06-23 23:36:13.566123
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # pylint: disable=line-too-long
    assert InputOutput(Path('aaa'), Path('bbb')) == InputOutput(input=Path('aaa'), output=Path('bbb'))
    assert InputOutput(input=Path('aaa'), output=Path('bbb')) == InputOutput(input='aaa', output='bbb')
    assert InputOutput(Path('aaa'), Path('bbb')) != InputOutput(input=Path('aaa'), output=Path('bbb2'))


# Generated at 2022-06-23 23:36:17.774886
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = "/test/test.in"
    output_path = "/test/test.out"

    pair = InputOutput(Path(input_path), Path(output_path))

    assert(pair.input == Path(input_path))
    assert(pair.output == Path(output_path))


# Generated at 2022-06-23 23:36:19.510153
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=0, time=0, target=(0, 0), dependencies=[])


# Generated at 2022-06-23 23:36:21.588322
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path = Path('./test')
    paths = InputOutput(path, path)
    assert paths.input == path
    assert paths.output == path


# Generated at 2022-06-23 23:36:24.280597
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(None, True, [])
    assert result.tree is None
    assert result.tree_changed
    assert result.dependencies == []

# Generated at 2022-06-23 23:36:27.088767
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path = Path('path')
    input_output = InputOutput(path, path)
    assert input_output.input == path
    assert input_output.output == path

# Generated at 2022-06-23 23:36:30.424532
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # type: () -> None
    input = Path('/home/me/data/a.txt')
    output = Path('/home/me/data/b.txt')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output



# Generated at 2022-06-23 23:36:32.417876
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # noinspection PyUnresolvedReferences
    TransformationResult(tree=None, tree_changed=False, dependencies=None)

# Generated at 2022-06-23 23:36:35.228145
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(input='foo', output='bar')
    assert input_output.input == Path('foo')
    assert input_output.output == Path('bar')

# Generated at 2022-06-23 23:36:37.510010
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=15,
                      time=2.0,
                      target=(3, 7),
                      dependencies=['time'])



# Generated at 2022-06-23 23:36:39.276581
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("")
    TransformationResult(tree, False, ['a', 'b'])

# Generated at 2022-06-23 23:36:42.902584
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(5, 10.0, (3, 5), ["dep1", "dep2"])

    assert result.files == 5
    assert result.time == 10.0
    assert result.target == (3, 5)
    assert result.dependencies == ["dep1", "dep2"]



# Generated at 2022-06-23 23:36:47.551390
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.Module()
    tree_changed = True
    dependencies = ['f1.py', 'f2.py']
    tr = TransformationResult(tree, tree_changed, dependencies)
    assert tr.tree == tree
    assert tr.tree_changed == tree_changed
    assert tr.dependencies == dependencies

# Generated at 2022-06-23 23:36:49.324139
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2, (3, 4), ['a'])


# Generated at 2022-06-23 23:36:51.941790
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert(CompilationResult(1, 1, (2, 7), []) ==
           CompilationResult(files=1, time=1, target=(2, 7), dependencies=[]))



# Generated at 2022-06-23 23:36:54.300597
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(input=Path("/tmp/a"),
                               output=Path("b"))
    assert input_output.input == Path("/tmp/a")
    assert input_output.output == Path("b")


# Generated at 2022-06-23 23:36:59.381824
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Arrange
    files = 3
    time = 2.3
    target = (3, 5)
    dependencies = ['a', 'b', 'c']
    # Act
    result = CompilationResult(files, time, target, dependencies)
    # Assert
    assert result.files == files
    assert result.time == time
    assert result.target == target
    assert result.dependencies == dependencies


# Generated at 2022-06-23 23:37:06.134799
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cres = CompilationResult(files=2, time=0.12,
                             target=(3, 4),
                             dependencies=['file1.py', 'file2.py'])
    assert cres.files == 2
    assert cres.time == pytest.approx(0.12)
    assert cres.target == (3, 4)
    assert cres.dependencies == ['file1.py', 'file2.py']


# Generated at 2022-06-23 23:37:11.059724
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=3,
                               time=0.2,
                               target=(3, 5),
                               dependencies=['a', 'b', 'c'])
    assert result.files == 3
    assert result.time == 0.2
    assert result.target == (3, 5)
    assert result.dependencies == ['a', 'b', 'c']


# Generated at 2022-06-23 23:37:16.017768
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=2.0,
                               target=(3, 4),
                               dependencies=['d1', 'd2'])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == ['d1', 'd2']
    assert str(result) == 'CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=[\'d1\', \'d2\'])'


# Generated at 2022-06-23 23:37:19.894875
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('/tmp')
    output_path = Path('/tmp2')

    input_output = InputOutput(input_path, output_path)

    assert input_output.input == input_path
    assert input_output.output == output_path


# Generated at 2022-06-23 23:37:24.962313
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=3, time=2, target=(3, 5), dependencies=['a.py', 'b.py'])
    assert result.files == 3
    assert result.time == 2
    assert result.target == (3, 5)
    assert result.dependencies == ['a.py', 'b.py']


# Generated at 2022-06-23 23:37:28.184625
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = "input file"
    output = "output file"
    string_exception = "InputOutput() takes 2 positional arguments but 3 were given"
    assert InputOutput(input_, output).input == input_
    assert InputOutput(input_, output).output == output
    try:
        InputOutput(input_, output, string_exception)
    except Exception as e:
        assert str(e) == string_exception


# Generated at 2022-06-23 23:37:30.412159
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    def try_make():  # type: () -> None
        TransformationResult(ast.parse(""), False, [])
    try_make()

# Sort of compile-time type to represent a transformer

# Generated at 2022-06-23 23:37:32.492403
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path('/some/path')
    path2 = Path('/some/other/path')
    iop = InputOutput(path1, path2)
    assert iop.input == path1
    assert iop.output == path2
    assert iop == InputOutput(path1, path2)


# Generated at 2022-06-23 23:37:34.953030
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(ast.parse('a = "b"'), True, [])
    assert res.tree.body[0].value.s == "b"



# Generated at 2022-06-23 23:37:40.586211
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # pylint: disable=invalid-name
    tree = ast.parse('a = 1')  # type: ast.AST
    Result = TransformationResult(tree, True, ['module'])
    assert Result.tree == tree
    assert Result.tree_changed == True
    assert Result.dependencies == ['module']
    # pylint: enable=invalid-name

# Generated at 2022-06-23 23:37:44.433851
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(5, 2.5, (3, 7), [])
    assert compilation_result.files == 5
    assert compilation_result.time == 2.5
    assert compilation_result.target == (3, 7)
    assert compilation_result.dependencies == []


# Generated at 2022-06-23 23:37:47.737980
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    """
    Unit test for constructor of class TransformationResult
    """
    assert TransformationResult(None, None, None)

# Result of unit test
TestResult = NamedTuple('TestResult', [('success', bool),
                                       ('execution_time', float),
                                       ('message', str)])


# Generated at 2022-06-23 23:37:50.966961
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(10, 20.0,
                                           (3, 6), ['dependency_1'])
    assert compilation_result.files == 10
    assert compilation_result.time == 20.0
    assert compilation_result.target == (3, 6)
    assert compilation_result.dependencies == ['dependency_1']

# Generated at 2022-06-23 23:37:55.515072
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.0, target=(3, 6), dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 0.0
    assert result.target == (3, 6)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:37:59.673008
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('input_file')
    output_path = Path('output_file')
    io = InputOutput(input_path, output_path)
    assert io.input == input_path
    assert io.output == output_path


# Generated at 2022-06-23 23:38:02.807383
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('test')
    output = Path('output')
    in_out = InputOutput(input, output)
    assert in_out.input == input
    assert in_out.output == output

# Generated at 2022-06-23 23:38:05.753210
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = ast.Name('input')
    outp = ast.Name('output')
    io = InputOutput(inp, outp)
    assert io.input == inp
    assert io.output == outp


# Generated at 2022-06-23 23:38:08.317726
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=None,
                                tree_changed=False,
                                dependencies=[]) == TransformationResult(tree=None,
                                                                          tree_changed=False,
                                                                          dependencies=[])

# Generated at 2022-06-23 23:38:11.307438
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('/input')
    output = Path('/output')
    input_output = InputOutput(input_, output)
    assert input_ == input_output.input
    assert output == input_output.output

# Generated at 2022-06-23 23:38:13.513269
# Unit test for constructor of class InputOutput
def test_InputOutput():
    e = InputOutput(Path('input'), Path('output'))
    assert e.input == Path('input')
    assert e.output == Path('output')


# Generated at 2022-06-23 23:38:17.333516
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=0, time=0, target=(3, 5), dependencies=[])
    assert result.files == 0
    assert result.time == 0
    assert result.target == (3, 5)
    assert not result.dependencies


# Generated at 2022-06-23 23:38:22.141873
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(tree=None, tree_changed=False, dependencies=[])

CompilationResult.__module__ = 'typed_astunparse.transforms.utils'
InputOutput.__module__ = 'typed_astunparse.transforms.utils'
TransformationResult.__module__ = 'typed_astunparse.transforms.utils'

# Generated at 2022-06-23 23:38:31.907962
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None

    # Test the default constructor
    test_instance = TransformationResult(tree_changed=True, tree=None, dependencies=[])
    assert test_instance.tree_changed == True
    assert test_instance.tree == None
    assert test_instance.dependencies == []
    assert test_instance == TransformationResult(tree=None, tree_changed=True, dependencies=[])

    # Test the non-default constructor
    test_tree = ast.parse("")
    test_dependencies = ["A.py"]
    test_instance = TransformationResult(tree=test_tree, tree_changed=False, dependencies=test_dependencies)
    assert test_instance.tree_changed == False
    assert test_instance.tree == test_tree
    assert test_instance.dependencies == test_dependencies
    assert test_instance == TransformationResult

# Generated at 2022-06-23 23:38:36.910110
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """
    Tests proper initialization of Input/Output pairs
    """
    # Get fixture
    fixture = get_fixture('input_output.yml')
    for item in fixture:
        try:
            input_file = Path(item['input'])
            output_file = Path(item['output'])
        except TypeError:
            assert False

        io = InputOutput(input_file, output_file)
        assert io.input == input_file
        assert io.output == output_file



# Generated at 2022-06-23 23:38:42.137566
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_input = Path('input_file')
    test_output = Path('output_file')
    test_io = InputOutput(test_input, test_output)
    result_input = test_io.input
    result_output = test_io.output
    assert result_input == test_input
    assert result_output == test_output


# Generated at 2022-06-23 23:38:46.218493
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_tree = ast.parse("pass")
    test = TransformationResult(ast_tree, True, ["dep1", "dep2"])
    assert test.tree is ast_tree
    assert test.tree_changed is True
    assert test.dependencies == ["dep1", "dep2"]

# Generated at 2022-06-23 23:38:50.820769
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t1 = ast.parse('a = 1')
    t2 = ast.parse('b = 1')

    r1 = TransformationResult(tree=t1, tree_changed=False, dependencies=[])
    r2 = TransformationResult(tree=t2, tree_changed=True, dependencies=['b.py'])

    assert r1.tree == t1
    assert r1.tree_changed == False
    assert r1.dependencies == []

    assert r2.tree == t2
    assert r2.tree_changed == True
    assert r2.dependencies == ['b.py']

# Generated at 2022-06-23 23:38:52.418832
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 2, (3, 4), ['a', 'b'])



# Generated at 2022-06-23 23:38:55.800206
# Unit test for constructor of class InputOutput
def test_InputOutput():
    in_file = Path('/dir/input.txt')
    out_file = Path('/dir/output.txt')
    in_out = InputOutput(input=in_file, output=out_file)
    assert in_out.input == in_file
    assert in_out.output == out_file


# Generated at 2022-06-23 23:38:57.880461
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path("/input"), Path("/output")).input == Path("/input")
    assert InputOutput(Path("/input"), Path("/output")).output == Path("/output")

# Generated at 2022-06-23 23:39:00.995007
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(0, 0.0, (3, 7), [])
    assert isinstance(compilation_result.files, int)
    assert isinstance(compilation_result.time, float)
    assert isinstance(compilation_result.target, CompilationTarget)
    assert isinstance(compilation_result.dependencies, list)


# Generated at 2022-06-23 23:39:05.981533
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=2.0,
                               target=(3, 5),
                               dependencies=['a'])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 5)
    assert result.dependencies == ['a']


# Generated at 2022-06-23 23:39:08.128962
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1, target=(3, 7),
                               dependencies=['a.py', 'b.py'])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 7)
    assert result.dependencies == ['a.py', 'b.py']


# Generated at 2022-06-23 23:39:12.966344
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=0.001, target=(3, 5), dependencies=['a'])
    assert cr.files == 1
    assert cr.time == 0.001
    assert cr.target == (3, 5)
    assert cr.dependencies == ['a']


# Generated at 2022-06-23 23:39:17.016385
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    ret = CompilationResult(files=1, time=0.0, target=(3, 5), dependencies=[])
    assert ret.files == 1
    assert ret.time == 0.0
    assert ret.target == (3, 5)
    assert ret.dependencies == []


# Generated at 2022-06-23 23:39:21.469830
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    comp = CompilationResult(files=1, time=1.1, target=(3, 5),
                             dependencies=['a', 'b'])
    assert comp[0] == 1
    assert comp[1] == 1.1
    assert comp[2] == (3, 5)
    assert comp[3] == ['a', 'b']


# Generated at 2022-06-23 23:39:27.027336
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=None,
                              tree_changed=False,
                              dependencies=[])
    assert tr.tree is None
    assert tr.tree_changed is False
    assert tr.dependencies == []


# Version of transformer
TransformerVersion = NamedTuple('TransformerVersion', [('major', int),
                                                       ('minor', int),
                                                       ('patch', int)])


# Generated at 2022-06-23 23:39:33.364988
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compile_res = CompilationResult(files=0,
                                    time=1.0,
                                    target=(3, 5),
                                    dependencies=['file1', 'file2'])
    assert compile_res.files == 0
    assert compile_res.time == 1.0
    assert compile_res.target == (3, 5)
    assert compile_res.dependencies == ['file1', 'file2']


# Generated at 2022-06-23 23:39:36.809977
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x + 1')
    result = TransformationResult(tree, True, ["foo", "bar"])
    assert result.tree is tree
    assert result.tree_changed is True
    assert result.dependencies == ["foo", "bar"]

# Generated at 2022-06-23 23:39:43.880202
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(tree=ast.parse('a=1', '', 'eval'),
                                  tree_changed=False,
                                  dependencies=[])
    assert result.tree_changed == False
    assert result.dependencies == []
    assert result.tree.body[0].targets[0].id == 'a'
    assert result.tree.body[0].value.n == 1

# Result of transformer call
TransformationCallResult = NamedTuple('TransformationCallResult',
                                      [('name', str),
                                       ('result', TransformationResult)])


# Generated at 2022-06-23 23:39:47.070966
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output1 = InputOutput(Path('a'), Path('b'))
    assert input_output1.input == Path('a')
    assert input_output1.output == Path('b')



# Generated at 2022-06-23 23:39:49.621833
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=1, time=3, target=(3, 4),
                             dependencies=["a", "b.py"])


# Generated at 2022-06-23 23:39:54.775846
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    target = (3, 4)
    cr = CompilationResult(files=234, time=0.345, target=target, dependencies=['a', 'b'])

    assert cr.files == 234
    assert cr.time == 0.345
    assert cr.target == target
    assert cr.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:39:58.648921
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # pylint: disable=unused-variable
    files = 42
    time = 0.123
    target = (3, 7)
    dependencies = []
    CompilationResult(files, time, target, dependencies)
    # pylint: enable=unused-variable


# Generated at 2022-06-23 23:40:01.022442
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path(os.getcwd()), Path(os.getcwd()))


# Generated at 2022-06-23 23:40:04.179681
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert str(InputOutput(input=Path('test'), output=Path('test'))) == \
           "InputOutput(input=PosixPath('test'), output=PosixPath('test'))"


if __name__ == '__main__':
    test_InputOutput()

# Generated at 2022-06-23 23:40:12.797365
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c1 = CompilationResult(files=1, time=0.0, target=(3, 5),
                           dependencies=[])
    c2 = CompilationResult(files=1, time=0.0, target=(3, 5),
                           dependencies=[])
    assert c1 == c2

    c1 = CompilationResult(files=1, time=0.0, target=(3, 5),
                           dependencies=[])
    c2 = CompilationResult(files=1, time=0.0, target=(3, 5),
                           dependencies=['foo.py'])
    assert c1 != c2

# Generated at 2022-06-23 23:40:15.771968
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.parse('1 + 1'), False, [])

# Result of code execution
ExecutionResult = NamedTuple('ExecutionResult', [('result', Path),
                                                 ('time', float)])

# Generated at 2022-06-23 23:40:18.483006
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path("input"), Path("output"))
    assert input_output.input == Path("input")
    assert input_output.output == Path("output")



# Generated at 2022-06-23 23:40:24.362266
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=1, time=0.3, target=(3, 5),
                          dependencies=['astor'])
    assert isinstance(c, CompilationResult)
    assert isinstance(c.files, int)
    assert isinstance(c.time, float)
    assert isinstance(c.dependencies, list)
    assert c.files == 1
    assert c.time == 0.3
    assert c.target == (3, 5)


# Generated at 2022-06-23 23:40:27.405468
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_node = ast.parse("x = 1")
    t = TransformationResult(ast_node, False, [])
    assert_equal(TransformationResult(ast_node, False, []), t)

# Generated at 2022-06-23 23:40:31.112537
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('def foo(a):\n    return a')
    r = TransformationResult(t, False, ['foo.py'])
    assert r.tree == t
    assert r.tree_changed == False
    assert r.dependencies == ['foo.py']

# Generated at 2022-06-23 23:40:35.983793
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    dummy_tree = ast.parse('')
    dummy_dependencies = ['dummy/path/to/dependency/1',
                          'dummy/path/to/dependency/2']
    TransformationResult(tree=dummy_tree,
                         # If the tree has changed, the transformer tells the
                         # compiler to recompile its dependencies
                         tree_changed=True,
                         dependencies=dummy_dependencies)

# Generated at 2022-06-23 23:40:39.810890
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=0.5, target=(3, 6), dependencies=['a', 'b', 'c'])

    assert cr.files == 1
    assert cr.time == 0.5
    assert cr.target == (3, 6)
    assert cr.dependencies == ['a', 'b', 'c']


# Generated at 2022-06-23 23:40:41.889715
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=3, time=4.3,
                      target=(3, 4), dependencies=['test.py'])

# Generated at 2022-06-23 23:40:48.536058
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 12
    time = 5.2
    target = (3, 7)
    dependencies = ['/foo/bar', '/bar/baz']
    res = CompilationResult(files, time, target, dependencies)
    assert res.files == 12
    assert res.time == 5.2
    assert res.target == (3, 7)
    assert res.dependencies == ['/foo/bar', '/bar/baz']


# Generated at 2022-06-23 23:40:52.997309
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    record = CompilationResult(2, 3.14, (27, 2), ['a', 'b'])
    assert record.files == 2
    assert record.time == 3.14
    assert record.target == (27, 2)
    assert record.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:41:01.270804
# Unit test for constructor of class InputOutput
def test_InputOutput():
    locals_ = locals()
    X = locals_["X"] = type(lambda: 0)(lambda: 0)
    X.__qualname__ = "test_InputOutput.<locals>.X"
    X.__name__ = "X"
    X.__doc__ = ""
    exec('''if 1:
    def _f():
        yield
        yield

''', globals(), locals_)
    _f = locals_["_f"]
    for x, y in _f():
        def _f():
            yield
            yield
    X.__init__ = _f
    X.__module__ = __name__
    X.__annotations__ = {'input': Path,
                         'output': Path}
    return X


# Generated at 2022-06-23 23:41:04.557432
# Unit test for constructor of class CompilationResult

# Generated at 2022-06-23 23:41:07.217149
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1,
                      time=20,
                      target=(3, 7),
                      dependencies=['foo', 'bar'])


# Generated at 2022-06-23 23:41:16.039842
# Unit test for constructor of class InputOutput
def test_InputOutput():
    base_path = Path('/')
    input_path = Path('input.py')
    output_path = Path('output.py')
    # Constructor should accept pathlib.Path and str
    assert InputOutput(input_path, output_path) == InputOutput(str(input_path), output_path)
    assert InputOutput(input_path, output_path) == InputOutput(str(input_path), str(output_path))
    # Relative paths are changed to absolute
    assert InputOutput(input_path, output_path).input == base_path / input_path
    assert InputOutput(input_path, output_path).output == base_path / output_path
    # Output directory is created if it doesn't exist
    output_dir = Path('output-dir')

# Generated at 2022-06-23 23:41:20.752189
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # GIVEN
    tree = None
    tree_changed = True
    dependencies = []
    # WHEN
    result = TransformationResult(tree, tree_changed, dependencies)
    # THEN
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Type for transformer
Transformer = Callable[[ast.AST, str], TransformationResult]

# Generated at 2022-06-23 23:41:23.370583
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('foo.py')
    output = Path('bar.py')

    pair = InputOutput(input, output)

    assert pair.input == Path('foo.py')
    assert pair.output == Path('bar.py')

# Generated at 2022-06-23 23:41:26.405316
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = "/foo/bar/input.py"
    outp = "/foo/bar/output.py"
    p = InputOutput(input=Path(inp), output=Path(outp))
    assert p.input == inp
    assert p.output == outp

# Generated at 2022-06-23 23:41:29.542570
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('foo')
    output = Path('bar')
    obj = InputOutput(input, output)
    assert obj.input == input
    assert obj.output == output


# Generated at 2022-06-23 23:41:33.126860
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr1 = TransformationResult(tree=None, tree_changed=False, dependencies=['foo', 'bar'])
    assert tr1.tree is None
    assert tr1.tree_changed is False
    assert tr1.dependencies == ['foo', 'bar']

# Generated at 2022-06-23 23:41:35.946590
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = 'foo'
    output = 'bar'
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output

# Generated at 2022-06-23 23:41:38.901934
# Unit test for constructor of class InputOutput
def test_InputOutput():
    try:
        InputOutput(input='foo', output='bar')
        assert False
    except:
        pass

    InputOutput(input=Path('foo'), output=Path('bar'))

# Generated at 2022-06-23 23:41:42.826810
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert isinstance(InputOutput('1', '2'), InputOutput)
    assert InputOutput('1', '2').input == '1'
    assert InputOutput('1', '2').output == '2'


# Generated at 2022-06-23 23:41:51.186257
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=0, time=0.0, target=(2, 7), dependencies=[]).files == 0
    assert CompilationResult(files=0, time=0.0, target=(2, 7), dependencies=[]).time == 0.0
    assert CompilationResult(files=0, time=0.0, target=(2, 7), dependencies=[]).target == (2, 7)
    assert CompilationResult(files=0, time=0.0, target=(2, 7), dependencies=[]).dependencies == []


# Generated at 2022-06-23 23:41:55.567559
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation = CompilationResult(files=12,
                                    time=0.5,
                                    target=(3, 8),
                                    dependencies=['./a', './b'])
    assert compilation.files == 12
    assert compilation.time == 0.5
    assert compilation.target == (3, 8)
    assert compilation.dependencies == ['./a', './b']

# Generated at 2022-06-23 23:41:57.361513
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('foo.py'), Path('bar.py')) == InputOutput(Path('foo.py'), Path('bar.py'))

# Generated at 2022-06-23 23:42:00.975206
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(
        ast.parse('pass'),
        False,
        []
    ).tree == ast.parse('pass')
    assert TransformationResult(
        ast.parse('pass'),
        False,
        []
    ).tree_changed == False
    assert TransformationResult(
        ast.parse('pass'),
        False,
        []
    ).dependencies == []

# Generated at 2022-06-23 23:42:03.181750
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('foo.py'), Path('bar.py'))
