

# Generated at 2022-06-23 23:32:03.450393
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=0, time=0.0, target=(1, 7), dependencies=[]) is not None



# Generated at 2022-06-23 23:32:06.861259
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=10, time=1.2, target=(2, 7),
                          dependencies=['foo', 'bar'])
    assert c.files == 10
    assert c.time == 1.2
    assert c.target == (2, 7)
    assert c.dependencies == ['foo', 'bar']


# Generated at 2022-06-23 23:32:14.761249
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    import random
    import string

    def randomword(length):
        return ''.join(random.choice(string.ascii_lowercase) for _ in range(length))

    N_STRINGS = 10
    N_ITERATIONS = 100
    for i in range(N_ITERATIONS):
        files = random.randint(1, 99999)
        time = random.random()
        target = random.randint(1, 10), random.randint(1, 10)
        dependencies = [randomword(10) for _ in range(N_STRINGS)]

        CompilationResult(files, time, target, dependencies)

# Generated at 2022-06-23 23:32:17.029267
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path("foo.py")
    output = Path("foo.out")
    x = InputOutput(input, output)
    assert x.input == input
    assert x.output == output

# Generated at 2022-06-23 23:32:19.754093
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # type: () -> None
    InputOutput(Path('/tmp/a.py'), Path('/tmp/b.py'))

# Generated at 2022-06-23 23:32:20.201934
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.Module(), True, ['test'])

# Generated at 2022-06-23 23:32:21.135273
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(tree=None, tree_changed=False, dependencies=[])

# Generated at 2022-06-23 23:32:24.004166
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from typed_ast import ast3 as ast
    tree = ast.Module()

    result = TransformationResult(tree, True, ['file1', 'file2'])
    assert result.tree is tree
    assert result.tree_changed is True
    assert result.dependencies == ['file1', 'file2']
    assert isinstance(result, TransformationResult)

# Generated at 2022-06-23 23:32:27.145641
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('in.py'), Path('out.py'))
    assert input_output.input == Path('in.py')
    assert input_output.output == Path('out.py')

# Generated at 2022-06-23 23:32:31.823740
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 2.0, (3, 4), ['a', 'b'])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:32:34.714653
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('foo')
    out = Path('bar')
    t = InputOutput(inp, out)
    assert t.input == inp
    assert t.output == out


# Generated at 2022-06-23 23:32:36.775209
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    tree_changed = True
    dependencies = []
    TransformationResult(tree, tree_changed, dependencies)

# Generated at 2022-06-23 23:32:40.301135
# Unit test for constructor of class InputOutput
def test_InputOutput():
    in_file = "__init__.py"
    out_file = "python2.zip/__init__.py"
    i_o = InputOutput(in_file, out_file)
    assert i_o.input == Path(in_file)
    assert i_o.output == Path(out_file)


# Unit tests for class CompilationResult

# Generated at 2022-06-23 23:32:42.582254
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.parse(""), False, [])
    TransformationResult(tr.tree, tr.tree_changed, tr.dependencies)

# Generated at 2022-06-23 23:32:46.671752
# Unit test for constructor of class TransformationResult
def test_TransformationResult():

    tree = ast.parse('pass')
    dependencies = ['a', 'b']
    tr = TransformationResult(tree=tree,
                              tree_changed=True,
                              dependencies=dependencies)
    assert tr.tree == tree
    assert tr.tree_changed == True
    assert tr.dependencies == dependencies

# Generated at 2022-06-23 23:32:52.400567
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=None, tree_changed=False, dependencies=[])
    assert tr.tree is None
    assert not tr.tree_changed
    assert tr.dependencies == []

# Information about code that was inserted
InsertedCode = NamedTuple('InsertedCode', [('file_name', Path),
                                           ('module_name', str)])

# Input for module transformers
ModuleInfo = NamedTuple('ModuleInfo', [('path', Path),
                                       ('module_name', str)])


# Generated at 2022-06-23 23:32:54.023737
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(tree=None, tree_changed=False, dependencies=[])
    assert isinstance(res, TransformationResult)

# Generated at 2022-06-23 23:32:56.436437
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Arrange
    input = Path('in')
    output = Path('out')

    # Act
    io = InputOutput(input=input, output=output)

    # Assert
    assert input == io.input
    assert output == io.output



# Generated at 2022-06-23 23:32:58.512260
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # pylint: disable=unused-variable
    input_output = InputOutput(None, None)
    assert input_output.input is None
    assert input_output.output is None


# Generated at 2022-06-23 23:33:01.410514
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Test the type checker on the constructor
    tr = TransformationResult(tree=ast.Module(), tree_changed=True,
                              dependencies=[])
    # Test attributes
    tr.tree
    tr.tree_changed
    tr.dependencies

# Generated at 2022-06-23 23:33:03.667175
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('input'), Path('output'))
    assert str(input_output) == "InputOutput(input='input', output='output')"

# Generated at 2022-06-23 23:33:07.517613
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=None,
                                tree_changed=True,
                                dependencies=[])
    assert TransformationResult(tree=None,
                                tree_changed=False,
                                dependencies=['../mod'])
    assert TransformationResult(tree=None,
                                tree_changed=True,
                                dependencies=['../mod', '../dir'])


# Generated at 2022-06-23 23:33:11.493414
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('foo')
    output_path = Path('bar')
    input_output = InputOutput(input=input_path, output=output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path


# Generated at 2022-06-23 23:33:12.318166
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(2, 3, (3, 4), ['foo', 'bar'])

# Generated at 2022-06-23 23:33:13.153090
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input=Path('input'), output=Path('output'))

# Generated at 2022-06-23 23:33:14.521258
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree_changed = True
    tree = ast.parse("")
    dependencies = []
    TransformationResult(tree, tree_changed,
                         dependencies)

# Generated at 2022-06-23 23:33:17.887291
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = TransformationResult(ast.AST(), True, [])
    assert tree.tree_changed == True, \
        'transformation caused changes in tree'

    assert tree.dependencies, \
        'dependencies should not be empty'



# Generated at 2022-06-23 23:33:22.821089
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=1.0,
                               target=(2, 7),
                               dependencies=['test'])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (2, 7)
    assert result.dependencies == ['test']


# Generated at 2022-06-23 23:33:26.062142
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('1')
    tr = TransformationResult(tree, True, ['dep'])
    assert tr.tree == tree
    assert tr.tree_changed == True
    assert tr.dependencies == ['dep']

# Generated at 2022-06-23 23:33:28.165062
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    res = TransformationResult(tree, False, [])
    assert res.tree == tree
    assert res.tree_changed is False
    assert res.dependencies == []

# Generated at 2022-06-23 23:33:30.029559
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    class TestVisitor(ast.NodeVisitor):
        pass
    # Create AST tree

# Generated at 2022-06-23 23:33:32.397976
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')

    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output

# Generated at 2022-06-23 23:33:39.738911
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=42, target=(3, 5), dependencies=['a', 'b'])
    assert cr.files == 1
    assert cr.time == 42
    assert cr.target == (3, 5)
    assert cr.dependencies == ['a', 'b']
    cr_dict = cr._asdict()
    assert cr_dict['files'] == 1
    assert cr_dict['time'] == 42
    assert cr_dict['target'] == (3, 5)
    assert cr_dict['dependencies'] == ['a', 'b']


# Generated at 2022-06-23 23:33:41.773067
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    _ = TransformationResult(tree=None,
                             tree_changed=True,
                             dependencies=['a', 'b', 'c'])

# Generated at 2022-06-23 23:33:46.805353
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test_tree_1 = ast.parse('foo = 42')
    test_tree_2 = ast.parse('foo = 42')
    TransformationResult(tree=test_tree_1,
                         tree_changed=True,
                         dependencies=[])
    TransformationResult(tree=test_tree_1,
                         tree_changed=False,
                         dependencies=[])
    TransformationResult.__eq__(TransformationResult(tree=test_tree_1,
                                                     tree_changed=True,
                                                     dependencies=[]),
                                TransformationResult(tree=test_tree_2,
                                                     tree_changed=True,
                                                     dependencies=[]))


# Result of transformers compilation

# Generated at 2022-06-23 23:33:48.491513
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(2, 3), dependencies=[])


# Generated at 2022-06-23 23:33:52.446710
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x + y')
    tree_changed = True
    dependencies = ['x.py']
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-23 23:33:54.461145
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a.txt'), Path('b.txt')) == InputOutput('a.txt', 'b.txt')



# Generated at 2022-06-23 23:33:57.112991
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('a')
    output = Path('b')
    pair = InputOutput(input, output)
    assert pair.input == input
    assert pair.output == output


# Generated at 2022-06-23 23:34:00.772947
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(tree=None, tree_changed=False,
                                  dependencies=[])

# Result of transformer test
TestResult = NamedTuple('TestResult', [('result', bool),
                                       ('msg', str),
                                       ('exception', str)])


# Generated at 2022-06-23 23:34:04.976771
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1,
                                           time=0.0,
                                           target=(2, 7),
                                           dependencies=list())
    assert (compilation_result.files == 1)
    assert (compilation_result.time == 0.0)
    assert (compilation_result.target[0] == 2)
    assert (compilation_result.target[1] == 7)
    assert (compilation_result.dependencies == list())


# Generated at 2022-06-23 23:34:08.221804
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 10, (3, 7), [])
    assert result.files == 1
    assert result.time == 10
    assert result.target == (3, 7)
    assert result.dependencies == []


# Generated at 2022-06-23 23:34:10.917323
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(0, 0.0, (3, 5), [])
    assert res.files == 0
    assert res.time == 0.0
    assert res.target == (3, 5)
    assert res.dependencies == []


# Generated at 2022-06-23 23:34:13.482905
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(1, 2, (3, 4), ['a', 'b'])
    assert c.files == 1
    assert c.time == 2
    assert c.target == (3, 4)
    assert c.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:34:14.560191
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(None, False, [])
    assert res.__class__ is TransformationResult

# Generated at 2022-06-23 23:34:18.909555
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(
        files=1,
        target=(2, 3),
        time=5.6,
        dependencies=['a.py']
    )
    assert c.files == 1
    assert c.target == (2, 3)
    assert c.time == 5.6
    assert c.dependencies == ['a.py']

# Generated at 2022-06-23 23:34:24.946249
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    t = CompilationResult(1, 2, (3, 4), ['dep1', 'dep2'])
    assert t.files == 1
    assert t.time == 2
    assert t.target == (3, 4)
    assert t.dependencies == ['dep1', 'dep2'], \
        'Compilation result failed to store dependency list'


# Generated at 2022-06-23 23:34:31.363790
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.AST(),  True, ['a']) == (ast.AST(), True, ['a'])
    assert TransformationResult(ast.AST(),  False, ['a']) == (ast.AST(), False, ['a'])
    assert TransformationResult(ast.AST(),  True, []) == (ast.AST(), True, [])
    assert TransformationResult(ast.AST(),  False, []) == (ast.AST(), False, [])

# Generated at 2022-06-23 23:34:34.648422
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr1 = TransformationResult(None, None, None)
    assert tr1.tree is None
    assert tr1.tree_changed is None
    assert tr1.dependencies is None

    tr2 = TransformationResult(1, 'a', (1, 2))
    assert tr2.tree == 1
    assert tr2.tree_changed == 'a'
    assert tr2.dependencies == (1, 2)

# Generated at 2022-06-23 23:34:37.215507
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = 'path/to/input/file'
    output = 'path/to/output/file'
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-23 23:34:39.115857
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=1, time=1.1, target=(0, 0), dependencies=[])



# Generated at 2022-06-23 23:34:48.041314
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    import scc.lib.ast as ast
    import scc.lib.transformers as transformers
    Transformer = transformers.base.Transformer
    tree = ast.parse_file('tests/unittest/testdata/ok.py')
    transformer = Transformer('test', '1.0', err_level=1,
                              target=[(3, 6), (3, 7)])
    result = TransformationResult(tree=tree,
                                  tree_changed=False,
                                  dependencies=[])
    assert len(result) == 3
    assert result.tree is tree
    assert result.tree_changed is False
    assert result.dependencies == []



# Generated at 2022-06-23 23:34:50.128794
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_ = ast.Module(body=[])
    tr = TransformationResult(tree=ast_, tree_changed=True, dependencies=[])
    assert tr.tree == ast_
    assert tr.tree_changed
    assert tr.dependencies == []

# Generated at 2022-06-23 23:34:52.739368
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    input_output = InputOutput(input=input, output=output)
    assert input_output.input == input
    assert input_output.output == output
    assert input_output == InputOutput(input=input, output=output)

# Generated at 2022-06-23 23:34:54.032872
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput('a', 'b')


# Generated at 2022-06-23 23:34:56.682417
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(None, False, [])
    assert result.tree is None
    assert not result.tree_changed
    assert result.dependencies == []



# Generated at 2022-06-23 23:35:00.071451
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    try:
        # Type check
        TransformationResult(None, False, ['a', 'b'])
    except TypeError:
        assert(False)
    try:
        # Type check
        TransformationResult(None, 'False', ['a', 'b'])
    except TypeError:
        assert(False)
    try:
        # Type check
        TransformationResult(None, False, None)
    except TypeError:
        assert(False)

# Generated at 2022-06-23 23:35:03.783757
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(tree=None, tree_changed=False, dependencies=[])

# Result of transformer
TransformerResult = NamedTuple('TransformerResult',
                               [('input_output', InputOutput),
                                ('result', CompilationResult)])


# Generated at 2022-06-23 23:35:12.140043
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # pylint: disable=too-few-public-methods,invalid-name
    # pylint: disable=too-many-function-args,unused-variable

    CompilationResult(1, 0.0, (3, 6), [])
    CompilationResult(files=1, time=0.0, target=(3, 6), dependencies=[])
    CompilationResult(dependencies=[], files=1, time=0.0, target=(3, 6))
    CompilationResult(files=1, dependencies=[], time=0.0, target=(3, 6))
    CompilationResult(files=1, target=(3, 6), dependencies=[], time=0.0)
    CompilationResult(files=1, target=(3, 6), time=0.0, dependencies=[])

# Generated at 2022-06-23 23:35:14.872871
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(ast.parse('a = 1'), False, [])
    assert isinstance(res.tree, ast.AST)
    assert res.tree_changed == False
    assert isinstance(res.dependencies, list)

# Generated at 2022-06-23 23:35:20.144918
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=10, time=3.25, target=(3, 7), dependencies=['a', 'b'])
    assert cr.files == 10
    assert cr.time == 3.25
    assert cr.target == (3, 7)
    assert cr.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:35:23.968286
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('foo/bar')
    output = Path('foo/baz')
    pair = InputOutput(input_, output)
    assert isinstance(pair, InputOutput)
    assert pair.input == input_
    assert pair.output == output


# Generated at 2022-06-23 23:35:29.544388
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=4,
                           time=2.1,
                           target=(3, 5),
                           dependencies=['a/b.py', 'c/d.py'])
    assert cr.files == 4
    assert cr.time == 2.1
    assert cr.target == (3, 5)
    assert cr.dependencies == ['a/b.py', 'c/d.py']


# Generated at 2022-06-23 23:35:32.709560
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    input = ast.parse('pass')
    result = TransformationResult(input,
                                  False,
                                  ["<path>"])
    assert result.tree == input
    assert not result.tree_changed
    assert result.dependencies == ["<path>"]


# Generated at 2022-06-23 23:35:37.089817
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=5,
                           time=0.1,
                           target=(3, 7),
                           dependencies=['x.py'])
    assert cr.files == 5
    assert cr.time == 0.1
    assert cr.target == (3, 7)
    assert cr.dependencies == ['x.py']



# Generated at 2022-06-23 23:35:39.541225
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.1, target=(3, 3), dependencies=['a', 'b'])


# Generated at 2022-06-23 23:35:45.131823
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    comp_res = CompilationResult(
        files=0,
        time=1.0,
        target=(2, 3),
        dependencies=['a', 'b']
    )
    assert comp_res.files == 0
    assert comp_res.time == 1.0
    assert comp_res.target == (2, 3)
    assert comp_res.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:35:47.213458
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('foo = 1')
    TransformationResult(tree, True, ['foo'])

# Generated at 2022-06-23 23:35:48.244102
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    _ = TransformationResult(ast.Module, True, [])

# Generated at 2022-06-23 23:35:51.650987
# Unit test for constructor of class TransformationResult
def test_TransformationResult(): # type: () -> None
    tree = ast.Module([], type_ignores=[str])
    dependencies = ['a']
    res = TransformationResult(tree, False, dependencies)
    assert isinstance(res, TransformationResult)

# Generated at 2022-06-23 23:35:53.864965
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=123, time=3.14,
                      target=(3, 7), dependencies=[])


# Generated at 2022-06-23 23:35:56.390553
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(input='/in/path', output='/out/path')
    assert input_output.input == Path('/in/path')
    assert input_output.output == Path('/out/path')

# Generated at 2022-06-23 23:35:58.821762
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/etc/config')
    output = Path('/etc/hosts')
    pair = InputOutput(input, output)

    assert pair.input == input
    assert pair.output == output


# Generated at 2022-06-23 23:36:02.357918
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # pylint: disable=unused-variable
    input_obj: Path = Path('__init__.py')
    output_obj: Path = Path('__init__.pyc')
    _: InputOutput = InputOutput(input=input_obj, output=output_obj)

# Generated at 2022-06-23 23:36:04.718637
# Unit test for constructor of class InputOutput
def test_InputOutput():
    l = InputOutput(Path('a'), Path('b'))
    assert l.input == Path('a')
    assert l.output == Path('b')

# Generated at 2022-06-23 23:36:09.915414
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.Module([ast.Expr(ast.BinOp(ast.Num(1), ast.Add(), ast.Num(2)))])
    result = TransformationResult(tree, True, ['a', 'b'])
    assert (result.tree == tree)
    assert (result.tree_changed)
    assert (result.dependencies == ['a', 'b'])

# Generated at 2022-06-23 23:36:14.191243
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=3, time=5, target=(3, 6), dependencies=['foo', 'bar'])
    assert cr.files == 3
    assert cr.time == 5
    assert cr.target == (3, 6)
    assert cr.dependencies == ['foo', 'bar']


# Generated at 2022-06-23 23:36:21.402005
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = InputOutput(input='input', output='output')
    assert isinstance(a.input, Path)
    assert isinstance(a.output, Path)
    assert a.input == Path('input')
    assert a.output == Path('output')

    # Test get
    input, output = a
    assert isinstance(input, Path)
    assert isinstance(output, Path)
    assert input == Path('input')
    assert output == Path('output')

    # Test string representation
    assert repr(a) == "InputOutput(input='input', output='output')"

# Test constructor of class CompilationResult

# Generated at 2022-06-23 23:36:26.031877
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(1, 2.0, (3, 4), ['a', 'b'])
    assert cr.files == 1
    assert cr.time == 2.0
    assert cr.target == (3, 4)
    assert cr.dependencies == ['a', 'b']

# Generated at 2022-06-23 23:36:32.258033
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    dummy_files = 1
    dummy_time = 100.0
    dummy_compilation_target = (3, 7)
    dummy_dependencies = ['stdlib', 'a_library']
    dummy_compilation_result = CompilationResult(dummy_files,
                                                 dummy_time,
                                                 dummy_compilation_target,
                                                 dummy_dependencies)

    assert dummy_compilation_result.files == dummy_files
    assert dummy_compilation_result.time == dummy_time
    assert dummy_compilation_result.target == dummy_compilation_target
    assert dummy_compilation_result.dependencies == dummy_dependencies

# unit test for constructor of class TransformationResult

# Generated at 2022-06-23 23:36:35.874118
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p = Path('test.txt')
    inp_out = InputOutput(p, p)
    assert inp_out.input == inp_out.output

if __name__ == '__main__':
    test_InputOutput()

# Generated at 2022-06-23 23:36:40.497577
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(2,
                               42.42,
                               (3, 5),
                               ['something', 'something else'])
    assert result.files == 2
    assert result.time == 42.42
    assert result.target == (3, 5)
    assert result.dependencies == ['something', 'something else']



# Generated at 2022-06-23 23:36:42.976080
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('')
    result = TransformationResult(tree, True, [])
    assert result.tree == tree
    assert result.tree_changed
    assert result.dependencies == []

# Generated at 2022-06-23 23:36:51.658563
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("1+1")
    assert isinstance(tree, ast.AST)
    assert isinstance(TransformationResult(tree, True, []), TransformationResult)
    assert TransformationResult(tree, True, []).tree_changed
    assert not TransformationResult(tree, False, []).tree_changed

# Settings for the transformations to be performed
# on the code
TransformationsSettings = NamedTuple('TransformationsSettings',
                                     [('from_version', CompilationTarget),
                                      ('to_version', CompilationTarget),
                                      ('imports_lib', List[str])])

# Type of input file (Script, Package, Fixture)
InputFileType = NamedTuple

# Generated at 2022-06-23 23:36:53.462753
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(None, None, None)
    assert tr.tree == None
    assert tr.tree_changed == None
    assert tr.dependencies == None

# Generated at 2022-06-23 23:36:55.944173
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=5, time=0.5, target=(3, 8),
                      dependencies=['/usr/bin/python'])


# Generated at 2022-06-23 23:37:01.166521
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(
        files=1,
        time=1.0,
        target=(2, 7),
        dependencies=["a", "b", "c"]
    )

    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (2, 7)
    assert result.dependencies == ["a", "b", "c"]

# Generated at 2022-06-23 23:37:11.144223
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Default constructor success
    cr1 = CompilationResult(files=1, time=2.0, target=(3, 0), dependencies=[])
    assert cr1.files == 1
    assert cr1.time == 2.0
    assert cr1.target == (3, 0)
    assert cr1.dependencies == []

    # Constructor with keywords
    cr2 = CompilationResult(files=2, time=4.0,
                            target=(6, 0),
                            dependencies=['/path/to/dep1', '/path/to/dep2'])
    assert cr2.files == 2
    assert cr2.time == 4.0
    assert cr2.target == (6, 0)
    assert cr2.dependencies == ['/path/to/dep1', '/path/to/dep2']


# Generated at 2022-06-23 23:37:13.546383
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(
        files=2,
        time=3.2,
        target=(3, 5),
        dependencies=['a.py'],
    )

    assert isinstance(result, CompilationResult)


# Generated at 2022-06-23 23:37:15.894304
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(input=Path('.'), output=Path('foo/bar.py'))
    assert input_output.input == Path('.')
    assert input_output.output == Path('foo/bar.py')


# Generated at 2022-06-23 23:37:17.234215
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i, o = 'input', 'output'
    assert InputOutput(Path(i), Path(o)) == InputOutput(i, o)


# Generated at 2022-06-23 23:37:22.366569
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 1.0, (3, 7), [str(Path.home())])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 7)
    assert result.dependencies == [str(Path.home())]


# Generated at 2022-06-23 23:37:29.515242
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # string -> InputOutput
    def to_InpOut(string): return InputOutput('a', 'b')
    # InputOutput -> string
    def from_InpOut(inp_out): return '(a, b)'

    for (inp_out, expected) in [(InputOutput('a', 'b'), '(a, b)'),
                                (InputOutput(1, 2), '(1, 2)'),
                                (InputOutput('ab', 'cd'), '(ab, cd)')]:
        assert from_InpOut(inp_out) == expected
        assert to_InpOut(inp_out) == expected

# Generated at 2022-06-23 23:37:32.361426
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p1 = Path("a/b/c")
    p2 = Path("d/e/f")
    i1 = InputOutput(p1, p2)
    assert i1.input == p1
    assert i1.output == p2

# Generated at 2022-06-23 23:37:37.545428
# Unit test for constructor of class InputOutput
def test_InputOutput():
    import tempfile
    i, iname = tempfile.mkstemp()
    os.close(i)
    o, oname = tempfile.mkstemp()
    os.close(o)
    pair = InputOutput(Path(iname), Path(oname))
    assert pair.input.name == iname
    assert pair.output.name == oname


# Generated at 2022-06-23 23:37:42.305559
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(
        files = 1,
        time = 0,
        target = (3, 6),
        dependencies = []
    )
    assert res.files == 1
    assert res.time == 0
    assert res.target == (3, 6)
    assert res.dependencies == []

test_CompilationResult()


# Generated at 2022-06-23 23:37:46.779208
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("")
    dependencies = ["a.py", "b.py"]

    tf1 = TransformationResult(tree, True, dependencies)
    tf2 = TransformationResult(tree, False, dependencies)

    assert(tf1.tree_changed == True)
    assert(tf2.tree_changed == False)
    assert(tf1.dependencies == dependencies)
    assert(tf2.dependencies == dependencies)

# Generated at 2022-06-23 23:37:52.800240
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, False, [])
    assert TransformationResult(None, False, None)
    assert TransformationResult(None, True, [])
    assert TransformationResult(None, True, None)
    assert TransformationResult(None, None, [])
    assert TransformationResult(None, None, None)
    assert TransformationResult(ast.parse('1'), False, [])
    assert TransformationResult(ast.parse('1'), False, None)
    assert TransformationResult(ast.parse('1'), True, [])
    assert TransformationResult(ast.parse('1'), True, None)
    assert TransformationResult(ast.parse('1'), None, [])
    assert TransformationResult(ast.parse('1'), None, None)

# Generated at 2022-06-23 23:37:55.280380
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(
        1, 2, (3, 4), ['dep1', 'dep2']
    ) is not None



# Generated at 2022-06-23 23:37:58.039116
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = InputOutput(Path('input'), Path('output'))
    assert i.input == Path('input')
    assert i.output == Path('output')

# Generated at 2022-06-23 23:38:00.044608
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(tree=ast.parse("x = 42"),
                         tree_changed=False,
                         dependencies=[])

# Generated at 2022-06-23 23:38:06.668652
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(None, True, [])
    assert result.tree is None
    assert result.tree_changed is True
    assert result.dependencies == []

# Result of transformers transformation
Compilation = NamedTuple('Compilation',
                         [('input', Path),
                          ('output', Path),
                          ('tree', ast.AST),
                          ('changed', bool),
                          ('target', CompilationTarget),
                          ('dependencies', List[str])])


# Generated at 2022-06-23 23:38:11.212376
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=4, time=1.23, target=(3, 6), dependencies=['x', 'y'])
    assert result.files == 4
    assert result.time == 1.23
    assert result.target == (3, 6)
    assert result.dependencies == ['x', 'y']


# Generated at 2022-06-23 23:38:14.516716
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("1 + 1")
    result = TransformationResult(tree, False, [])

# Result of compiling single file
FileCompilationResult = NamedTuple('FileCompilationResult',
                                   [('input_output', InputOutput),
                                    ('result', CompilationResult)])

# Generated at 2022-06-23 23:38:18.797340
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('/tmp/a.py')
    output_path = Path('/tmp/a.pyc')
    input_output = InputOutput(input_path, output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path


# Generated at 2022-06-23 23:38:22.762618
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=42, time=123.1, target=(3, 5), dependencies=[])
    assert cr.files == 42
    assert cr.time == 123.1
    assert cr.target == (3, 5)
    assert cr.dependencies == []


# Generated at 2022-06-23 23:38:30.009082
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    """
    Kind of arbitrary unit test to check, that class TransformationResult is
    correctly initialized.
    """
    t = TransformationResult(1, True, "ab")
    assert t.tree == 1
    assert t.tree_changed == True
    assert t.dependencies == "ab"
    assert isinstance(t, TransformationResult)

# Result of typing module type checking
TypeCheckResult = NamedTuple('TypeCheckResult',
                             [('check_ok', bool),
                              ('type_errors', List[str]),
                              ('time', float)])


# Generated at 2022-06-23 23:38:34.284154
# Unit test for constructor of class InputOutput
def test_InputOutput():  # pylint: disable=invalid-name
    """Unit test for InputOutput"""

    # Constructor with both input and output.
    io = InputOutput(input=Path('foo'), output=Path('bar'))

    # Test if we can get the values from the constructed object and they are as expected
    assert io.input == Path('foo')
    assert io.output == Path('bar')


# Generated at 2022-06-23 23:38:36.333897
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path(__file__)
    output = input_ / ".."

    pair = InputOutput(input=input_, output=output)
    assert pair.input == input_
    assert pair.output == output

# Generated at 2022-06-23 23:38:37.356549
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(tree=None,
                         tree_changed=True,
                         dependencies=[])

# Generated at 2022-06-23 23:38:39.073549
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(input="input", output="output")
    assert io.input == "input"
    assert io.output == "output"



# Generated at 2022-06-23 23:38:49.191484
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('input'), Path('output')) == InputOutput(input='input', output='output')
    assert InputOutput(Path('input'), Path('output')).input == Path('input')
    assert InputOutput(Path('input'), Path('output')).output == Path('output')
    assert InputOutput(input='input', output='output').input == Path('input')
    assert InputOutput(input='input', output='output').output == Path('output')

    assert InputOutput(Path('input'), Path('output')).__str__() == 'InputOutput(input=input, output=output)'
    assert InputOutput(Path('input'), Path('output')).__repr__() == 'InputOutput(input=input, output=output)'

# Generated at 2022-06-23 23:38:52.202457
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.Name(id='x', ctx=ast.Load()),
                                False,
                                []) ==\
        TransformationResult(tree=ast.Name(id='x', ctx=ast.Load()),
                             tree_changed=False,
                             dependencies=[])

# Generated at 2022-06-23 23:38:54.161271
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = InputOutput(input='/a', output='/b')
    assert str(a.input) == '/a'
    assert str(a.output) == '/b'

# Generated at 2022-06-23 23:38:57.348057
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(1, 2, (3, 4), ['dep1', 'dep2'])
    assert cr.files == 1
    assert cr.time == 2
    assert cr.target == (3, 4)
    assert cr.dependencies == ['dep1', 'dep2']


# Generated at 2022-06-23 23:39:06.175353
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res1 = CompilationResult(files=1, time=1.0, target=(3,6),
                             dependencies=['/tmp/test1', '/tmp/test2'])
    assert isinstance(res1, CompilationResult)
    assert isinstance(res1.files, int)
    assert isinstance(res1.time, float)
    assert isinstance(res1.target, CompilationTarget)
    assert isinstance(res1.dependencies, list)
    assert res1.files == 1
    assert res1.time == 1.0
    assert res1.target == (3,6)
    assert res1.dependencies == ['/tmp/test1', '/tmp/test2']



# Generated at 2022-06-23 23:39:08.838610
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = None
    tree_changed = False
    dependencies = []
    assert TransformationResult(tree, tree_changed, dependencies)


# Generated at 2022-06-23 23:39:10.396289
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(Path('foo.py'), Path('bar.py'))


# Generated at 2022-06-23 23:39:13.656203
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('/path/to/input')
    o = Path('/path/to/output')
    io = InputOutput(i, o)
    assert io.input == i
    assert io.output == o

# Generated at 2022-06-23 23:39:14.425894
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, True, [])

# Generated at 2022-06-23 23:39:17.817810
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.AST()
    dependencies = []
    cls = TransformationResult(tree, False, dependencies)
    assert cls.tree == tree
    assert cls.tree_changed == False
    assert cls.dependencies == dependencies


# Generated at 2022-06-23 23:39:20.030881
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(10, 0.1, (3, 7), [])
    assert result.files == 10
    assert result.time == 0.1
    assert result.target == (3, 7)
    assert result.dependencies == []



# Generated at 2022-06-23 23:39:24.556346
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = InputOutput(Path(os.path.realpath(__file__)),
                    Path('file2'))
    b = InputOutput('file1', 'file2')
    c = InputOutput(Path(os.path.realpath(__file__)), Path('file2'))
    assert a == c
    assert a != b


# Generated at 2022-06-23 23:39:28.871083
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=0, time=0, target=(3, 5),
                               dependencies=[])
    assert result.files == 0
    assert result.time == 0
    assert result.target == (3, 5)
    assert result.dependencies == []

# Generated at 2022-06-23 23:39:33.503439
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inputs = [Path('.'), Path('/')]
    outputs = [Path('.'), Path('/')]

    for inp, out in product(inputs, outputs):
        pair = InputOutput(inp, out)
        assert pair.input == inp
        assert pair.output == out

# Generated at 2022-06-23 23:39:43.177920
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(1, 0.1, (2, 7), [])
    assert cr.files == 1
    assert cr.time == 0.1
    assert cr.target == (2, 7)
    assert cr.dependencies == []

    with pytest.raises(TypeError):
        CompilationResult('1', 0.1, (2, 7), [])

    with pytest.raises(TypeError):
        CompilationResult(1, '0.1', (2, 7), [])

    with pytest.raises(TypeError):
        CompilationResult(1, 0.1, '2, 7', [])

    with pytest.raises(TypeError):
        CompilationResult(1, 0.1, (2, 7), 1)


# Generated at 2022-06-23 23:39:47.030504
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('test.py'), Path('test.depep8.py'))
    assert (input_output.input == Path('test.py'))
    assert (input_output.output == Path('test.depep8.py'))


# Generated at 2022-06-23 23:39:51.370161
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=1, time=1.0, target=(3, 7), dependencies=[])
    assert c.files == 1
    assert c.time == 1.0
    assert c.target == (3, 7)
    assert c.dependencies == []


# Generated at 2022-06-23 23:39:53.852464
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('input')
    output = Path('output')
    pair = InputOutput(input_, output)
    assert pair.input == input_
    assert pair.output == output

# Generated at 2022-06-23 23:39:58.347594
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('/tmp/a.txt')
    out = Path('/tmp/b.txt')

    i_o = InputOutput(inp, out)

    assert i_o.input == inp
    assert i_o.output == out


# Unit tests for constructor of class CompilationResult

# Generated at 2022-06-23 23:40:03.778704
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    input_output_pair = InputOutput(Path('.'), Path('.'))
    transformed_tree = ast.parse('')
    transformation_result = TransformationResult(
        tree=transformed_tree,
        tree_changed=False,
        dependencies=['a', 'b']
    )
    assert transformation_result.tree is transformed_tree
    assert transformation_result.tree_changed is False
    assert transformation_result.dependencies == ['a', 'b']

# Generated at 2022-06-23 23:40:05.750536
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(tree = None,
                         tree_changed = False,
                         dependencies = [])
# pylint: enable=invalid-name

# Generated at 2022-06-23 23:40:09.290468
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=None, tree_changed=False,
                              dependencies=[])
    assert tr.tree is None
    assert not tr.tree_changed
    assert tr.dependencies == []

# Generated at 2022-06-23 23:40:16.987038
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1,
                           time=0.1,
                           target=(3, 4),
                           dependencies=['a', 'b'])
    print(cr)
    assert cr.files == 1
    assert cr.time == 0.1
    assert cr.target == (3, 4)
    assert cr.dependencies == ['a', 'b']
    assert str(cr) == "CompilationResult(files=1, time=0.1, target=(3, 4), dependencies=['a', 'b'])"


# Generated at 2022-06-23 23:40:18.883525
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=0,
                      time=0,
                      target=(3, 7),
                      dependencies=[])


# Generated at 2022-06-23 23:40:20.992329
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(None, True, [])
    assert tr.tree is None
    assert tr.tree_changed is True
    assert tr.dependencies == []

# Generated at 2022-06-23 23:40:25.902128
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    x = TransformationResult(tree=ast.parse('x = 1'),
                             tree_changed=True,
                             dependencies=['hello'])
    assert x.tree_changed

TransformationInput = NamedTuple('TransformationInput',
                                 [('tree', ast.AST),
                                  ('input', Path),
                                  ('output', Path)])


# Generated at 2022-06-23 23:40:28.361909
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path("a"), Path("b"))
    assert io.input == Path("a")
    assert io.output == Path("b")

# Generated at 2022-06-23 23:40:35.163708
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Default
    result = TransformationResult(tree=None,
                                  tree_changed=False,
                                  dependencies=[])
    assert result.tree is None
    assert result.tree_changed == False
    assert result.dependencies == []

    # Some values
    module = ast.Module()
    dependencies = ['foo', 'bar', 'baz']
    result = TransformationResult(tree=module,
                                  tree_changed=True,
                                  dependencies=dependencies)
    assert result.tree is module
    assert result.tree_changed == True
    assert result.dependencies is dependencies

# Generated at 2022-06-23 23:40:40.474638
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=5,
                                           time=5.2,
                                           target=(3, 6),
                                           dependencies=[])
    assert compilation_result.files == 5
    assert compilation_result.time == 5.2
    assert compilation_result.target == (3, 6)
    assert compilation_result.dependencies == []
    assert str(compilation_result) == 'CompilationResult(files=5, time=5.2, '\
                                      'target=(3, 6), dependencies=[])'


# Generated at 2022-06-23 23:40:45.541328
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    new = CompilationResult(files=2, time=12.1, target=(3, 5), dependencies=['a', 'b'])
    assert new.files == 2
    assert new.time == 12.1
    assert new.target == (3, 5)
    assert new.dependencies == ['a', 'b']



# Generated at 2022-06-23 23:40:49.972316
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_file = Path('input/file/name')
    output_file = Path('output/file/name')

    input_output_pair = InputOutput(input_file, output_file)

    assert input_output_pair.input == input_file
    assert input_output_pair.output == output_file

# Generated at 2022-06-23 23:40:52.470252
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree: ast.AST = ast.parse("")
    assert TransformationResult(tree, True, []).tree_changed == True



# Generated at 2022-06-23 23:40:55.482768
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # use real path name
    input = Path('test')
    output = Path('test')
    pair = InputOutput(input, output)
    assert pair.input == input
    assert pair.output == output

# Generated at 2022-06-23 23:41:00.167396
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    num_files = 2
    processing_time = 10
    target = (3, 6)
    result = CompilationResult(num_files,
                               processing_time,
                               target,
                               [])
    assert result.files == num_files
    assert result.time == processing_time
    assert result.target == target
    assert result.dependencies == []


# Generated at 2022-06-23 23:41:03.101667
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = Path('foo')
    b = Path('bar')
    c = InputOutput(input=a,
                    output=b)
    assert c.input == a
    assert c.output == b

# Generated at 2022-06-23 23:41:06.322012
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    x = TransformationResult(None, None, [])
    assert x.tree is None
    assert x.tree_changed is None
    assert x.dependencies == []


# Generated at 2022-06-23 23:41:09.713806
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(ast.parse('x = 5'), True, [])
    assert isinstance(result.tree, ast.Module)
    assert isinstance(result.tree_changed, bool)
    assert isinstance(result.dependencies, list)

# Generated at 2022-06-23 23:41:12.649915
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 0.0, (2, 7), [])
    CompilationResult(0, 10.0, (3, 5), [])
    CompilationResult(2, 20.0, (3, 7), [])


# Generated at 2022-06-23 23:41:15.973535
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=0, time=1.0, target=(3, 5), dependencies=[])
    assert cr.files == 0
    assert cr.time == 1.0
    assert cr.target == (3, 5)
    assert cr.dependencies == []


# Generated at 2022-06-23 23:41:16.812296
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(None, None, None)

# Generated at 2022-06-23 23:41:18.471500
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(ast.AST(), True, [])
    assert isinstance(result.dependencies, list)

# Generated at 2022-06-23 23:41:21.871408
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(1, 0.5, (3, 7), [])
    assert compilation_result.files == 1
    assert compilation_result.time == 0.5
    assert compilation_result.target == (3, 7)
    assert compilation_result.dependencies == []



# Generated at 2022-06-23 23:41:25.274426
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from typed_ast.ast3 import Module
    tree = Module()
    TransformationResult(tree, False, [])

    tree_changed = True
    TransformationResult(tree, tree_changed, [])

    dependencies = ['a.py', 'b.py', 'c.py']
    TransformationResult(tree, tree_changed, dependencies)

# Generated at 2022-06-23 23:41:27.500238
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('in')
    output = Path('out')
    input_output = InputOutput(input_, output)
    assert input_output.input == input_
    assert input_output.output == output


# Generated at 2022-06-23 23:41:30.999782
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('/foo/bar')
    out = Path('/baz/quux')
    i = InputOutput(input=inp, output=out)
    assert i.input == inp
    assert i.output == out



# Generated at 2022-06-23 23:41:38.194005
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    variables = {
        'files': 1,
        'time': 2,
        'target': (3, 4),
        'dependencies': ['test_dependencies']
    }
    result = CompilationResult(**variables)
    for var, val in variables.items():
        assert getattr(result, var) == val
    assert str(result) == \
        "CompilationResult(files=1, time=2, target=(3, 4), dependencies=['test_dependencies'])"


# Generated at 2022-06-23 23:41:44.519960
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=2.0,
                               target=(3, 4),
                               dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:41:52.248362
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('print("Hello")')
    result = TransformationResult(tree=t, tree_changed=True, dependencies=[])
    assert result.tree_changed is True
    assert result.dependencies == []
    result = TransformationResult(t, False, ['test.py'])
    assert result.tree_changed is False
    assert result.dependencies == ['test.py']
    result = TransformationResult(t, None, None)
    assert result.tree_changed is None
    assert result.dependencies is None

# Generated at 2022-06-23 23:41:56.033687
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cres = CompilationResult(1, 10., (3, 5), ["a", "b"])
    assert cres.files == 1
    assert cres.time == 10.
    assert cres.target == (3, 5)
    assert cres.dependencies == ["a", "b"]


# Generated at 2022-06-23 23:41:58.799495
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 1
    time = 1.0
    target = (3, 5)
    dependencies = ["a.py"]
    CompilationResult(files, time, target, dependencies)


# Generated at 2022-06-23 23:42:00.913249
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    result = InputOutput(input, output)

    assert result.input == input
    assert result.output == output


# Generated at 2022-06-23 23:42:03.098721
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('')
    assert isinstance(TransformationResult(tree, False, []), TransformationResult)