

# Generated at 2022-06-23 23:32:04.709392
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=1, time=0.1, target=(3, 5), dependencies=[])
    assert res.files == 1
    assert res.time == 0.1
    assert res.target == (3, 5)
    assert res.dependencies == []


# Generated at 2022-06-23 23:32:09.298583
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    """
    Test type of fields of type TransformationResult
    """
    tree = ast.parse('a = 1; b = 2; c = 3;')
    tree_changed = True
    dependencies = ['module.py', 'other.py']

    tr = TransformationResult(tree, tree_changed, dependencies)

    assert isinstance(tr.tree, ast.AST)
    assert isinstance(tr.tree_changed, bool)
    assert isinstance(tr.dependencies, list)
    assert isinstance(tr.dependencies[0], str)

# Generated at 2022-06-23 23:32:12.323267
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(None, True, [])
    assert result.tree is None
    assert result.tree_changed is True
    assert result.dependencies == []


# Generated at 2022-06-23 23:32:16.191713
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    tree = ast.parse('x + y')
    tree_changed = True
    dependencies = ['foo.py']

    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree is tree
    assert result.tree_changed is True
    assert result.dependencies == dependencies

# Generated at 2022-06-23 23:32:19.989912
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('input')
    o = Path('output')
    input_output = InputOutput(i, o)
    assert input_output.input == i
    assert input_output.output == o

# Generated at 2022-06-23 23:32:23.076123
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files = 1, time = 1, target = (3, 4), dependencies = [])
    assert result.files == 1
    assert result.time == 1
    assert result.target == (3, 4)
    assert result.dependencies == []


# Generated at 2022-06-23 23:32:25.521860
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    try:
        TransformationResult()  # type: ignore
        TransformationResult(tree=ast.AST(), tree_changed=True, dependencies=[])
    except TypeError as e:
        assert False, "Failed to instantiate TransformationResult()"

# Generated at 2022-06-23 23:32:32.015787
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.AST()
    tr = TransformationResult(tree=t, tree_changed=False, dependencies=[])
    assert tr.tree == t
    assert tr.tree_changed is False
    assert len(tr.dependencies) == 0


# Result of combiners' combiner
CombineResult = NamedTuple('CombineResult', [('tree', ast.AST),
                                             ('dependencies', List[str])])


# Generated at 2022-06-23 23:32:35.269560
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # default values
    assert TransformationResult(ast.parse('pass'), False, [])

    # different values
    d = {'foo': 1, 'bar': 2}
    assert TransformationResult(ast.parse('pass'), True, d) == d

# Generated at 2022-06-23 23:32:36.466276
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput('input', 'output')


# Generated at 2022-06-23 23:32:38.832976
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-23 23:32:44.119301
# Unit test for constructor of class InputOutput
def test_InputOutput():
    file1 = Path('/foo/bar')
    file2 = Path('a/b/c')
    pair1 = InputOutput(file1, file2)
    pair2 = InputOutput(file1, file2)
    pair3 = InputOutput(file2, file1)
    assert(pair1 == pair2)
    assert(pair1 != pair3)


# Generated at 2022-06-23 23:32:48.371656
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    file = Path('/dev/null')
    empty_ast = ast.Module(body=[])
    tree = TransformationResult(tree=empty_ast,
                                tree_changed=True,
                                dependencies=[file])
    assert tree.tree is empty_ast
    assert tree.tree_changed is True
    assert tree.dependencies == [file]

# Generated at 2022-06-23 23:32:52.476959
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    source = [
        "import os, sys",
        "def f(x): pass"
    ]
    tree = ast.parse("\n".join(source))
    out = TransformationResult(tree, True, ["os", "sys"])
    assert out.tree == tree
    assert out.tree_changed == True
    assert out.dependencies == ["os", "sys"]

# Generated at 2022-06-23 23:32:56.950633
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # pylint: disable=invalid-name
    result = CompilationResult(files=1,
                               time=1.0,
                               target=(3, 6),
                               dependencies=['foo', 'bar'])

    assert isinstance(result.files, int)
    assert isinstance(result.time, float)
    assert isinstance(result.target, CompilationTarget)
    assert isinstance(result.dependencies, List)


# Generated at 2022-06-23 23:32:57.691834
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.AST(), False, [])

# Generated at 2022-06-23 23:32:59.394198
# Unit test for constructor of class InputOutput
def test_InputOutput():
    f = InputOutput(Path('input.py'), Path('output.py'))
    assert f.input == Path('input.py')
    assert f.output == Path('output.py')

# Generated at 2022-06-23 23:33:02.099554
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(tree=None,
                                  tree_changed=None,
                                  dependencies=None)
    assert result.tree is None
    assert result.tree_changed is None
    assert result.dependencies is None

# Generated at 2022-06-23 23:33:05.057291
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("print('Hello world!')")
    t = TransformationResult(tree, True, [])
    assert t.tree == tree
    assert t.tree_changed == True
    assert t.dependencies == []


# Generated at 2022-06-23 23:33:09.493175
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(1, 2.0, (3, 4), [])
    assert c.files == 1
    assert c.time == 2.0
    assert c.target == (3, 4)
    assert c.dependencies == []


# Generated at 2022-06-23 23:33:11.254376
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=5, time=42.666, target=(3, 4), dependencies=[])

# Generated at 2022-06-23 23:33:15.752148
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, False, []).tree is None
    assert TransformationResult(None, False, []).tree_changed == False
    assert TransformationResult(None, False, []).dependencies == []
    assert TransformationResult(None, True, []).tree_changed == True
    assert TransformationResult(None, False, ['a', 'b']).dependencies == \
        ['a', 'b']

# Generated at 2022-06-23 23:33:21.304256
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=0,
                                           time=0,
                                           target=(0, 0),
                                           dependencies=[])
    assert(compilation_result.files == 0)
    assert(compilation_result.time == 0)
    assert(compilation_result.target == (0, 0))
    assert(compilation_result.dependencies == [])


# Generated at 2022-06-23 23:33:30.736090
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 1.0, (3, 4), ['a']).files == 1
    assert CompilationResult(1, 1.0, (3, 4), ['a']).time == 1.0
    assert CompilationResult(1, 1.0, (3, 4), ['a']).target == (3, 4)
    assert CompilationResult(1, 1.0, (3, 4), ['a']).dependencies == ['a']

    assert CompilationResult(1, 1.0, (3, 4), ['a']).files != 2
    assert CompilationResult(1, 1.0, (3, 4), ['a']).time != 2.0
    assert CompilationResult(1, 1.0, (3, 4), ['a']).target != (3, 5)

# Generated at 2022-06-23 23:33:38.316648
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('./a'), Path('./b')) == InputOutput(Path('./a'), Path('./b'))
    assert InputOutput(Path('./a'), Path('./b')) == (Path('./a'), Path('./b'))
    assert InputOutput(Path('./a'), Path('./b')) != (Path('./a'), Path('./c'))
    assert InputOutput(Path('./a'), Path('./b')).input == Path('./a')
    assert InputOutput(Path('./a'), Path('./b')).output == Path('./b')


# Generated at 2022-06-23 23:33:40.809361
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=1,
                             time=0.2,
                             target=(3, 5),
                             dependencies=['foo', 'bar'])


# Generated at 2022-06-23 23:33:44.381379
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=3, time=0.123,
                               target=(3, 7),
                               dependencies=['x', 'y'])
    assert result.files == 3
    assert result.time == 0.123
    assert result.target == (3, 7)
    assert result.dependencies == ['x', 'y']


# Generated at 2022-06-23 23:33:48.353222
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    input = CompilationResult(files=1, time=0.0, target=(3, 6),
                              dependencies=['x', 'y'])
    assert input.files == 1
    assert input.time == 0.0
    assert input.target == (3, 6)
    assert input.dependencies == ['x', 'y']


# Generated at 2022-06-23 23:33:49.776980
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult([], True, [])
    assert isinstance(tr, TransformationResult)

# Generated at 2022-06-23 23:33:55.443582
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(tree='', tree_changed=False, dependencies=[])
    assert res == TransformationResult(tree='', tree_changed=False, dependencies=[])
    assert res != TransformationResult(tree='', tree_changed=True, dependencies=[])
    assert res != TransformationResult(tree='', tree_changed=False, dependencies=['a'])
    assert res != TransformationResult(tree='', tree_changed=False, dependencies=[])
    assert res != "hello"

# Generated at 2022-06-23 23:34:00.146155
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=['a', 'b', 'c'])
    assert cr.files == 1
    assert cr.time == 2.0
    assert cr.target == (3, 4)
    assert cr.dependencies == ['a', 'b', 'c']


# Generated at 2022-06-23 23:34:03.424439
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('foo')
    output = Path('bar')
    io = InputOutput(input_, output)
    assert io.input == input_
    assert io.output == output
    assert io == InputOutput(input_, output)
    assert io != InputOutput(output, input_)


# Generated at 2022-06-23 23:34:05.836355
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path("a.py")
    output = Path("b.py")
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-23 23:34:12.636829
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    with pytest.raises(TypeError) as e:
        CompilationResult(10, 10.0, (3, 7), [])
        assert "unexpected type" in str(e.value)

    with pytest.raises(TypeError) as e:
        CompilationResult(10, 10.0, (3, 7), [])
        assert "unexpected type" in str(e.value)

    with pytest.raises(TypeError) as e:
        CompilationResult(10, 10.0, (3, '7'), [])
        assert "unexpected type" in str(e.value)

    with pytest.raises(TypeError) as e:
        CompilationResult(10, 10.0, (3,), ['asdf'])
        assert "unexpected type" in str(e.value)



# Generated at 2022-06-23 23:34:15.297195
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path = Path('test.txt')
    shape = InputOutput(path, path)
    assert shape.input == path
    assert shape.output == path
    # Str test
    assert str(shape) == "InputOutput(input='test.txt', output='test.txt')"


# Generated at 2022-06-23 23:34:24.021273
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=None,
                                tree_changed=False,
                                dependencies=[]).tree \
                                                 == None
    assert TransformationResult(tree=None,
                                tree_changed=False,
                                dependencies=[]).tree_changed \
                                                    == False
    assert TransformationResult(tree=None,
                                tree_changed=False,
                                dependencies=[]).dependencies \
                                                  == []

# Result of AST transformers
TransformationResults = NamedTuple('TransformationResults',
                                   [('tree', ast.AST),
                                    ('tree_changed', bool),
                                    ('dependencies', List[str]),
                                    ('results', List[TransformationResult])])


# Generated at 2022-06-23 23:34:29.874307
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1, time=0.0, target=(3, 6), dependencies=['a', 'b'])
    assert compilation_result.files == 1
    assert compilation_result.time == 0.0
    assert compilation_result.target == (3, 6)
    assert compilation_result.dependencies == ['a', 'b']



# Generated at 2022-06-23 23:34:40.977650
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path(__file__), Path(__file__)).input == Path(__file__)
    assert InputOutput(Path(__file__), Path(__file__)).output == Path(__file__)
    assert InputOutput(Path(__file__), __file__).input == Path(__file__)
    assert InputOutput(Path(__file__), __file__).output == Path(__file__)
    assert InputOutput(__file__, Path(__file__)).input == Path(__file__)
    assert InputOutput(__file__, Path(__file__)).output == Path(__file__)
    assert InputOutput(__file__, __file__).input == Path(__file__)
    assert InputOutput(__file__, __file__).output == Path(__file__)

# Generated at 2022-06-23 23:34:44.933474
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=0.1, target=(3, 6), dependencies=[])

    assert cr.files == 1
    assert cr.time == 0.1
    assert cr.target == (3, 6)
    assert cr.dependencies == []



# Generated at 2022-06-23 23:34:45.932376
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, False, [])

# Generated at 2022-06-23 23:34:48.736234
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(0, 0.0, (3, 2), []) == \
           CompilationResult(0, 0.0, (3, 2), [])


# Generated at 2022-06-23 23:34:51.538864
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('xi.py')
    o = Path('xi.c')
    pair = InputOutput(i, o)
    assert pair.input == i
    assert pair.output == o


# Generated at 2022-06-23 23:34:53.066642
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, None, None)


# Unit tests for constructor of class InputOutput

# Generated at 2022-06-23 23:34:56.515163
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(10, 10.0, (3, 7), ['a.py', 'b.py'])
    assert cr.files == 10
    assert cr.time == 10.0
    assert cr.target == (3, 7)
    assert cr.dependencies == ['a.py', 'b.py']


# Generated at 2022-06-23 23:35:00.951793
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=12, time=0.25, target=(3, 0), dependencies=['foo'])
    assert cr.files == 12
    assert cr.time == 0.25
    assert cr.target == (3, 0)
    assert cr.dependencies == ['foo']


# Generated at 2022-06-23 23:35:09.649798
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse("pass")
    p2 = ast.parse("pass")

    assert len(TransformationResult.__annotations__) == 3
    tr = TransformationResult(t, True, [])
    assert isinstance(tr.tree, ast.AST)
    assert tr.tree is t

    assert isinstance(tr.tree_changed, bool)
    assert tr.tree_changed is True

    assert isinstance(tr.dependencies, list)
    assert len(tr.dependencies) == 0

    assert tr != TransformationResult(p2, True, [])
    assert tr == TransformationResult(t, True, [])
    assert tr != TransformationResult(t, False, [])
    assert tr != TransformationResult(t, True, ["p"])

# Generated at 2022-06-23 23:35:14.399816
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1,
                                           time=2.0,
                                           target=(3, 4),
                                           dependencies=['a', 'b'])
    assert compilation_result.files == 1
    assert compilation_result.time == 2.0
    assert compilation_result.target == (3, 4)
    assert compilation_result.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:35:17.837310
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('in'), Path('out'))
    assert InputOutput(input=Path('in'), output=Path('out'))
    assert InputOutput('in', 'out')


# Generated at 2022-06-23 23:35:21.913767
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=11, time=0.5, target=(3, 5), dependencies=[])
    assert res.files == 11
    assert res.time == 0.5
    assert res.target == (3, 5)
    assert res.dependencies == []



# Generated at 2022-06-23 23:35:25.665147
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Given
    input = Path('test.py')
    output = Path('test.c')

    # When
    io = InputOutput(input, output)

    # Then
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-23 23:35:30.903777
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 1.0, (3, 5), ['f.py']) == \
           CompilationResult(1, 1.0, (3, 5), ['f.py'])
    assert not CompilationResult(1, 1.0, (3, 5), ['f.py']) == \
           CompilationResult(1, 1.0, (3, 6), ['f.py'])

# Test constructor of class InputOutput

# Generated at 2022-06-23 23:35:33.950459
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(files=0, time=0, target=(2, 6), dependencies=[])
    assert r.files == 0
    assert r.time == 0
    assert r.target == (2, 6)
    assert r.dependencies == []


# Generated at 2022-06-23 23:35:37.090053
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    a = CompilationResult(42, 5.0, (3, 6), [])
    assert a.files == 42
    assert a.time == 5.0
    assert a.target == (3, 6)
    assert a.dependencies == []


# Generated at 2022-06-23 23:35:41.672710
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # pylint: disable=anomalous-backslash-in-string
    test_ast = ast.parse('print "hello\n"',
                         mode="exec",
                         filename="./hello.py")
    test_tree = TransformationResult(tree=test_ast,
                                     tree_changed=False,
                                     dependencies=["./hello.py"])
    # pylint: enable=anomalous-backslash-in-string
    assert test_tree.tree.body[0].value.s == "hello\n"
    assert test_tree.tree_changed is False
    assert test_tree.dependencies == ["./hello.py"]

# Generated at 2022-06-23 23:35:47.512213
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    tr = TransformationResult(1, 2, 3)
    assert tr.tree == 1
    assert tr.tree_changed == 2
    assert tr.dependencies == 3

# Result of compilation
CompilationResults = NamedTuple('CompilationResults',
                                [('results', List[CompilationResult]),
                                 ('failed_compilations', List[InputOutput])])

# Generated at 2022-06-23 23:35:54.129537
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, False, [])

# Source file statistics
TaskStats = NamedTuple('TaskStats', [('source_name', str),
                                     ('source_size', int),
                                     ('source_lines', int),
                                     ('target_name', str),
                                     ('target_size', int),
                                     ('target_lines', int),
                                     ('time', float),
                                     ('target', CompilationTarget),
                                     ('dependencies', List[str])])


# Generated at 2022-06-23 23:35:56.619102
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('input')
    output_path = Path('output')
    io = InputOutput(input_path, output_path)
    assert io.input == input_path
    assert io.output == output_path

# Generated at 2022-06-23 23:35:59.041191
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    a = ast.parse('42')
    r = TransformationResult(a, True, ['42'])
    assert r.tree == a
    assert r.tree_changed == True
    assert r.dependencies == ['42']

# Generated at 2022-06-23 23:36:03.570310
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files = 1, time = 2.0, target = (3, 4),
                               dependencies = ['a', 'b'])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:36:09.220099
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_dir = Path('testdata/input')
    output_dir = Path('testdata/output')
    input_file = input_dir / 'simple.py'
    output_file = output_dir / input_file.relative_to(input_dir)
    io = InputOutput(input_file, output_file)
    assert io.input == input_file
    assert io.output == output_file

# Generated at 2022-06-23 23:36:19.347266
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    as_tree = ast.Module(
        [ast.FunctionDef(name='f',
                         args=ast.arguments(
                             posonlyargs=[],
                             vararg=None,
                             kwonlyargs=[],
                             kw_defaults=[],
                             kwarg=None,
                             defaults=[]),
                         body=[ast.Expr(value=ast.Str(s='something'))],
                         decorator_list=[],
                         returns=None)]
    )
    as_tree_changed = True
    as_dependencies = []

    tr = TransformationResult(as_tree, as_tree_changed, as_dependencies)

    assert tr.tree.body[0].name == 'f'
    assert tr.tree_changed
    assert tr.dependencies == []



# Generated at 2022-06-23 23:36:21.439476
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ret = TransformationResult(tree=None, tree_changed=False, dependencies=[])
    assert ret.tree is None
    assert ret.tree_changed is False
    assert ret.dependencies == []

# Generated at 2022-06-23 23:36:26.437266
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('path/to/input/file')
    output_path = Path('path/to/output/file')
    io = InputOutput(input_path, output_path)
    assert io.input == input_path
    assert io.output == output_path


# Generated at 2022-06-23 23:36:27.436024
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(Path(), Path())



# Generated at 2022-06-23 23:36:31.272704
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=0.1, target=(3, 6), dependencies=['/a/b', '/a/c/d'])
    assert cr.files == 1
    assert cr.time == 0.1
    assert cr.target == (3, 6)
    assert cr.dependencies == ['/a/b', '/a/c/d']


# Generated at 2022-06-23 23:36:34.613306
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t0 = ast.Module()
    tr = TransformationResult(t0, True, [])
    assert tr.tree is t0
    assert tr.tree_changed
    assert tr.dependencies == []

# Generated at 2022-06-23 23:36:39.278255
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    class C(ast.AST):
        pass

    result = TransformationResult(tree=C(), tree_changed=True,
                                  dependencies=['a', 'b', 'c'])

    assert isinstance(result.tree, C)
    assert result.tree_changed is True
    assert result.dependencies == ['a', 'b', 'c']

# Generated at 2022-06-23 23:36:43.183599
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    test = CompilationResult(files=1, time=2.0, target=(3, 4),
                             dependencies=['foo', 'bar'])
    assert test.files == 1
    assert test.time == 2.0
    assert test.target == (3, 4)
    assert test.dependencies == ['foo', 'bar']


# Generated at 2022-06-23 23:36:50.160730
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(None, False, [])
    assert isinstance(tr.tree, ast.AST)
    assert isinstance(tr.tree_changed, bool)
    assert isinstance(tr.dependencies, List[str])

# Result of transformers transformation
CompilationResult = NamedTuple('CompilationResult',
                               [('files', int),
                                ('time', float),
                                ('target', CompilationTarget),
                                ('dependencies', List[str])])


# Generated at 2022-06-23 23:36:54.325424
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # pylint: disable=too-few-public-methods
    class Test:
        def __init__(self, input, output):
            self.input = input
            self.output = output

    inp_out = InputOutput(Path('foo'), Path('bar'))
    assert inp_out.input == Path('foo')
    assert inp_out.output == Path('bar')

    test = Test('foo', 'bar')
    assert test.input == 'foo'
    assert test.output == 'bar'

# Generated at 2022-06-23 23:37:00.775581
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('input')
    output = Path('output')

    input_output = InputOutput(input_, output)

    assert input_output.input == Path('input')
    assert input_output.output == Path('output')

    same_input_output = InputOutput(Path('input'), Path('output'))

    assert input_output == same_input_output

    different_output_input_output = InputOutput(Path('input'), Path('other_output'))

    assert input_output != different_output_input_output

# Generated at 2022-06-23 23:37:05.719882
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=2.0, target=(3, 4),
                               dependencies=['a', 'b'])
    assert 1 == result.files
    assert 2.0 == result.time
    assert (3, 4) == result.target
    assert ['a', 'b'] == result.dependencies


# Generated at 2022-06-23 23:37:13.937850
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from typing import NamedTuple, Tuple, List
    import ast
    import unittest

    # Test value:
    test_result = TransformationResult(ast.AST(), True, [])
    assert test_result.tree is not None
    assert test_result.tree_changed is True
    assert type(test_result.dependencies) is list

    # Check that it's an instance of TransformationResult
    assert isinstance(test_result, TransformationResult)


# Project configuration
Project = NamedTuple('Project', [('src', Path),
                                 ('dest', Path),
                                 ('target', CompilationTarget),
                                 ('extra_deps', List[str]),
                                 ('extra_stdlib_deps', List[str])])


# Generated at 2022-06-23 23:37:16.594891
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(2, 3), dependencies=[])
    CompilationResult(files=1, time=1.0, target=(2, 3), dependencies=['x.py'])


# Generated at 2022-06-23 23:37:17.859404
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(0, 0.0, (3, 5), [])

# Generated at 2022-06-23 23:37:19.996813
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2.0, (3, 4), ["a", "b"])


# Generated at 2022-06-23 23:37:21.523707
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(tree='a', tree_changed=False,
                         dependencies=[])

# Generated at 2022-06-23 23:37:24.902966
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 2, (3,4), ['a'])
    assert CompilationResult(files=1, time=2, target=(3,4), dependencies=['a'])
    b = CompilationResult(1, 2, (3,4), ['a'])
    assert b.files == 1 and b.time == 2 and b.target == (3,4) and b.dependencies == ['a']


# Generated at 2022-06-23 23:37:27.391940
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(input=Path('input'), output=Path('output'))
    assert io.input == Path('input')
    assert io.output == Path('output')

# Generated at 2022-06-23 23:37:31.272283
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(
        files=1,
        time=2.0,
        target=(3, 4),
        dependencies=['a', 'b'],
    )
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:37:38.817355
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('test.py')
    o = Path('test.cpython-36.py')
    inp_out = InputOutput(input=i, output=o)
    assert inp_out.input == i
    assert i.name == inp_out.input.name
    assert inp_out.output == o
    assert o.name == inp_out.output.name
    assert str(inp_out) == "InputOutput(input=PosixPath('test.py'), output=PosixPath('test.cpython-36.py'))"

# Generated at 2022-06-23 23:37:45.300295
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """
    Unit test for constructor of class InputOutput
    """
    input_path = Path('in.py')
    output_path = Path('out.py')

    # Basic constructor
    input_output = InputOutput(input_path, output_path)
    assert isinstance(input_output, InputOutput)

    # Validate constructor arguments
    with pytest.raises(TypeError):
        InputOutput('in.py', output_path)
    with pytest.raises(TypeError):
        InputOutput(input_path, 'out.py')

# Generated at 2022-06-23 23:37:49.155601
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=1, time=2.0, target=(3, 4),
                            dependencies=['a', 'b'])
    assert res.files == 1
    assert res.time == 2.0
    assert res.target == (3, 4)
    assert res.dependencies == ['a', 'b']
    assert repr(res)


# Generated at 2022-06-23 23:37:51.961561
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(input=Path("input.s"), output=Path("output.s"))
    assert io.input == Path("input.s")
    assert io.output == Path("output.s")

# Generated at 2022-06-23 23:37:54.203748
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(1, 2.7, (3, 4), ['a'])

    assert res.files == 1
    assert res.time == 2.7
    assert res.target == (3, 4)
    assert res.dependencies == ['a']


# Generated at 2022-06-23 23:37:56.026509
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(files=1, time=2, target=(2, 3), dependencies=[])
    assert r.files == 1
    assert r.time == 2
    assert r.target == (2, 3)



# Generated at 2022-06-23 23:37:58.993394
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('test.txt')
    output = Path('test.out')
    assert InputOutput(input=input, output=output) == InputOutput(input, output)

# Generated at 2022-06-23 23:38:02.955132
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.Module([])
    tree_changed = True
    dependencies = []
    x = TransformationResult(tree, tree_changed, dependencies)
    assert x.tree is tree
    assert x.tree_changed is tree_changed
    assert x.dependencies is dependencies

# Generated at 2022-06-23 23:38:09.854336
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    import astor
    tree = ast.parse('import pkg')
    assert astor.to_source(tree) == 'import pkg\n'
    res = TransformationResult(tree=tree, tree_changed=False, dependencies=['pkg'])
    assert astor.to_source(res.tree) == 'import pkg\n'
    assert res.tree_changed == False
    assert res.dependencies == ['pkg']

__all__ = ['CompilationResult', 'InputOutput', 'TransformationResult',
           'CompilationTarget']

# Generated at 2022-06-23 23:38:12.828932
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    x = CompilationResult(0, 0.0, (0, 0), [])
    assert isinstance(x, CompilationResult) and isinstance(x.files, int) and isinstance(x.time, float)\
        and isinstance(x.target, CompilationTarget) and isinstance(x.dependencies, list)



# Generated at 2022-06-23 23:38:13.742705
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('input'), Path('output'))

# Generated at 2022-06-23 23:38:16.371831
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('a.py')
    output = Path('a.pyc')
    assert InputOutput(input_, output) == InputOutput(input_, output)



# Generated at 2022-06-23 23:38:19.130200
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse("")
    x = TransformationResult(t, True, [])
    assert x.tree == t
    assert x.tree_changed
    assert x.dependencies == []

# Generated at 2022-06-23 23:38:23.060666
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input.py')
    output = Path('/tmp/output.py')
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-23 23:38:27.519170
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    time = 12.345
    files = 3
    target = (3, 5)
    dependencies = ['dep1', 'dep2']
    result = CompilationResult(files, time, target, dependencies)
    assert result.files == files
    assert result.time == time
    assert result.target == target
    assert result.dependencies == dependencies



# Generated at 2022-06-23 23:38:32.187365
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert isinstance(TransformationResult(None, False, []),
                      TransformationResult)
    assert isinstance(TransformationResult(ast.Module(), False, []),
                      TransformationResult)
    assert isinstance(TransformationResult(ast.Module(), True, []),
                      TransformationResult)
    assert isinstance(TransformationResult(ast.Module(), False, ['abc']),
                      TransformationResult)



# Generated at 2022-06-23 23:38:34.851700
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    value1 = ast.parse('pass')
    value2 = [ast.parse('pass')]
    value3 = True
    value4 = ['pass']
    TransformationResult(value1, value2, value3, value4)


# Generated at 2022-06-23 23:38:38.262642
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=2.2,
                               target=(3, 4),
                               dependencies=['foo', 'bar'])
    assert result.files == 1
    assert result.time == 2.2
    assert result.target == (3, 4)
    assert result.dependencies == ['foo', 'bar']


# Generated at 2022-06-23 23:38:44.396271
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """
    Test the constructor of the class InputOutput.
    """
    input_path = Path('input')
    output_path = Path('output')
    io = InputOutput(input_path, output_path)
    assert io.input == input_path
    assert io.output == output_path
    assert io.input == 'input'
    assert io.output == 'output'


# Generated at 2022-06-23 23:38:46.401438
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(tree=ast.parse('1'), tree_changed=False,
                         dependencies=['dep'])

# Generated at 2022-06-23 23:38:47.836885
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse(""), True, [])[0]


# Generated at 2022-06-23 23:38:49.996903
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 1.0, (3, 5), ['a', 'b', 'c'])


# Generated at 2022-06-23 23:38:53.647858
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path("input")
    output = Path("output")
    input_output = InputOutput(input_, output)
    expected = ("InputOutput(input=PosixPath('input'), "
                "output=PosixPath('output'))")
    assert repr(input_output) == expected


# Generated at 2022-06-23 23:38:57.684472
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 42
    time = 0.001
    target = (3, 7)
    dependencies = ['foo', 'bar',
                    'baz']
    r = CompilationResult(files=files,
                          time=time,
                          target=target,
                          dependencies=dependencies)
    assert r.files == files
    assert r.time == time
    assert r.target == target
    assert r.dependencies == dependencies


# Generated at 2022-06-23 23:39:01.241385
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('a')
    output = Path('b')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output
    assert io != Path('a')
    assert io != InputOutput(output, input)
    assert str(io) == "InputOutput(input=PosixPath('a'), " \
                      "output=PosixPath('b'))"


# Generated at 2022-06-23 23:39:03.577122
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 1.0, (3, 5), [])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 5)
    assert result.dependencies == []


# Generated at 2022-06-23 23:39:08.079682
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput('input', 'output') == InputOutput(Path('input'), Path('output'))
    assert InputOutput('input', 'output') == InputOutput(Path('input'), Path('output'))
    assert InputOutput('input', 'output') == InputOutput(Path('input'), Path('output'))



# Generated at 2022-06-23 23:39:12.511331
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=3, time=0.23, target=(3, 7), dependencies=[])
    assert cr.files == 3
    assert cr.time == 0.23
    assert cr.target == (3, 7)
    assert cr.dependencies == []


# Generated at 2022-06-23 23:39:22.058982
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(1, 2.1, (3, 4), ["dep1", "dep2"])
    assert res.files == 1
    assert res.time == 2.1
    assert res.target == (3, 4)
    assert res.dependencies == ["dep1", "dep2"]


# Generated at 2022-06-23 23:39:26.513833
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    x = CompilationResult(42, 123.0, (3, 5), ['a'])
    assert (x.files == 42)
    assert (x.time == 123.0)
    assert (x.target == (3, 5))
    assert (x.dependencies[0] == 'a')


# Generated at 2022-06-23 23:39:29.304355
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # type: () -> None
    CompilationResult(files=1,
                      time=1.2,
                      target=(3, 5),
                      dependencies=["foo", "bar"])

# Generated at 2022-06-23 23:39:34.851829
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test_tree = ast.parse('x = 1')
    test_tree_changed = True
    test_dependencies = []

    result = TransformationResult(test_tree, test_tree_changed, test_dependencies)

    assert result.tree == test_tree
    assert result.tree_changed == test_tree_changed
    assert result.dependencies == test_dependencies

# Generated at 2022-06-23 23:39:38.703058
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(input=Path('input.py'),
                               output=Path('output.py'))

    assert input_output.input == Path('input.py')
    assert input_output.output == Path('output.py')

# Generated at 2022-06-23 23:39:41.767268
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Test for forbidden parameter name ;-)
    pytest.raises(TypeError, InputOutput, input="foo.py", output="bar.py")

    # Minimal test
    InputOutput("foo.py", "bar.py")

# Generated at 2022-06-23 23:39:46.649636
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    result = TransformationResult(tree,
                                  False,
                                  [])
    assert result.tree == tree
    assert result.tree_changed == False
    assert result.dependencies == []

# Abstraction of possible compilation parameters
CompilationParameters = NamedTuple('CompilationParameters',
                                   [('files', List[InputOutput]),
                                    ('target', CompilationTarget),
                                    ('jitter', str),
                                    ('jitter_flags', List[str])])


# Generated at 2022-06-23 23:39:55.513130
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p1 = Path('test.py')
    p2 = Path('test.c')

    # Path should be converted to string
    i = InputOutput(Path('test.py'), Path('test.c'))
    assert i.input == p1
    assert i.output == p2

    # Just string
    i = InputOutput('test.py', 'test.c')
    assert i.input == p1
    assert i.output == p2

    # Constructor should work with string only but not with something else
    with pytest.raises(TypeError):
        i = InputOutput(123, 456)


# Generated at 2022-06-23 23:39:57.611507
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # type: () -> None
    CompilationResult(1, 0.5, (3, 6), [])


# Generated at 2022-06-23 23:40:01.956044
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('test/test.py')
    output_path = Path('test/test2.py')
    input_output = InputOutput(input_path, output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path


# Generated at 2022-06-23 23:40:05.311327
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(1, 2.0, (3, 4), ['foo', 'bar'])
    assert c.files == 1
    assert c.time == 2.0
    assert c.target == (3, 4)
    assert c.dependencies == ['foo', 'bar']


# Generated at 2022-06-23 23:40:06.429907
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, False, [])

# Generated at 2022-06-23 23:40:09.485031
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(
        tree=ast.Module(), tree_changed=True, dependencies=[]) ==\
        TransformationResult(
            tree=ast.Module(), tree_changed=True, dependencies=[])

# Generated at 2022-06-23 23:40:15.237248
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # given
    files = 1
    time = 2.0
    target = (3, 4)
    dependencies = ['dep1', 'dep2', 'dep3']

    # when
    result = CompilationResult(files, time, target, dependencies)

    # then
    assert result.files == files
    assert result.time == time
    assert result.target == target
    assert result.dependencies == dependencies


# Generated at 2022-06-23 23:40:23.217125
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, False, None).tree is None
    assert not TransformationResult(None, False, None).tree_changed
    assert TransformationResult(None, False, None).dependencies is None

    assert TransformationResult(None, True, None).tree is None
    assert TransformationResult(None, True, None).tree_changed
    assert TransformationResult(None, True, None).dependencies is None

    assert TransformationResult(None, False, []).tree is None
    assert not TransformationResult(None, False, []).tree_changed
    assert TransformationResult(None, False, []).dependencies == []

    assert TransformationResult(None, True, []).tree is None
    assert TransformationResult(None, True, []).tree_changed
    assert TransformationResult(None, True, []).dependencies == []

    node = ast.parse('print("foo")')


# Generated at 2022-06-23 23:40:31.978563
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree: ast.AST = ast.parse('pass')
    tree_changed: bool = False
    dependencies: List[str] = ['file1.py', 'file2.py']
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Information about package for transformer
PackageInfo = NamedTuple('PackageInfo',
                         [('name', str),
                          ('version', str)])

# Information about transformer
TransformerInfo = NamedTuple('TransformerInfo',
                             [('package', PackageInfo),
                              ('module', str),
                              ('name', str)])


# Generated at 2022-06-23 23:40:35.813156
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(10, 1.2, (3, 5), ['animal.py', 'plant.py'])
    assert result.files == 10 and result.time == 1.2 and result.target == (3, 5)
    assert result.dependencies == ['animal.py', 'plant.py']


# Generated at 2022-06-23 23:40:36.893963
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2.0, (3, 4), ['a', 'b'])


# Generated at 2022-06-23 23:40:39.841529
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=0.0, target=((2, 7)), dependencies=[])
    assert isinstance(cr.files, int)
    assert isinstance(cr.time, float)
    assert isinstance(cr.target, CompilationTarget)
    assert isinstance(cr.dependencies, list)


# Generated at 2022-06-23 23:40:44.484139
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    res = TransformationResult(tree, True, ['file1', 'file2'])
    assert isinstance(res, TransformationResult)
    assert res.tree.body[0].value.n == 1
    assert res.tree_changed == True
    assert res.dependencies == ['file1', 'file2']

# Generated at 2022-06-23 23:40:47.051007
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 5')
    res = TransformationResult(tree, False, [])
    assert not res is None

# Generated at 2022-06-23 23:40:51.447073
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p_i = Path("./input1.txt")
    p_o = Path("./output1.txt")
    i_o = InputOutput(p_i, p_o)
    assert i_o.input == p_i
    assert i_o.output == p_o


# Generated at 2022-06-23 23:40:53.818100
# Unit test for constructor of class InputOutput
def test_InputOutput():
    file = Path('foo')
    assert InputOutput(file, file).input == file
    assert InputOutput(file, file).output == file

# Generated at 2022-06-23 23:40:57.025008
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input.py')
    output = Path('output.py')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-23 23:41:00.134250
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('inp')
    outp = Path('outp')
    io = InputOutput(inp, outp)
    assert(io.input == inp)
    assert(io.output == outp)


# Generated at 2022-06-23 23:41:06.100638
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # type: () -> None
    res = CompilationResult(files=1,
                            time=1.0,
                            target=(3, 5),
                            dependencies=['a', 'b'])
    assert res.files == 1
    assert res.time == 1.0
    assert res.target == (3, 5)
    assert res.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:41:10.037581
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    time = 1.
    files = 1
    target = (2, 7)
    dependencies = ['a', 'b']
    cr = CompilationResult(files, time, target, dependencies)
    assert cr.files == files
    assert cr.time == time
    assert cr.target == target
    assert cr.dependencies == dependencies

# Generated at 2022-06-23 23:41:11.964628
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = InputOutput("foo", "bar")
    assert i.input == "foo"
    assert i.output == "bar"

# Generated at 2022-06-23 23:41:15.652954
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # type: () -> None
    input_dir = Path('input')
    output_dir = Path('output')
    input_output = InputOutput(input=input_dir, output=output_dir)
    assert input_output.input is input_dir
    assert input_output.output is output_dir

# Generated at 2022-06-23 23:41:19.047376
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_name = "test.py"
    output_name = "test.pyc"
    the_input = Path(input_name)
    the_output = Path(output_name)
    obj = InputOutput(the_input, the_output)

    assert obj.input == the_input
    assert obj.output == the_output


# Generated at 2022-06-23 23:41:21.298552
# Unit test for constructor of class InputOutput
def test_InputOutput():
    result = InputOutput(input='text1', output='text2')
    assert result.input == 'text1'
    assert result.output == 'text2'


# Generated at 2022-06-23 23:41:23.621338
# Unit test for constructor of class InputOutput
def test_InputOutput():
    filename = Path('test.txt')
    input_output = InputOutput(filename, filename)
    assert input_output.input == filename
    assert input_output.output == filename


# Generated at 2022-06-23 23:41:29.591273
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Normal usage
    result = CompilationResult(30, 1.25, (3, 4), ['d1', 'd2'])

    # Check fields
    assert result.files == 30
    assert result.time == 1.25
    assert result.target == (3, 4)
    assert result.dependencies == ['d1', 'd2']

    # Check immutability
    with pytest.raises(AttributeError) as exc:
        result.files = 40
    assert str(exc.value) == "can't set attribute"


# Generated at 2022-06-23 23:41:34.040616
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(1, 2.2, (3, 4), ['a', 'b'])
    assert res.files == 1
    assert res.time == 2.2
    assert res.target == (3, 4)
    assert res.dependencies == ['a', 'b']



# Generated at 2022-06-23 23:41:38.260034
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('/tmp/input_file')
    output_path = Path('/tmp/output_file')
    input_output = InputOutput(input_path, output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path

# Generated at 2022-06-23 23:41:45.546508
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('assert True')
    transformation_result = TransformationResult(tree, True, ['a/b/c.py'])
    assert transformation_result.tree == tree
    assert transformation_result.tree_changed is True
    assert transformation_result.dependencies == ['a/b/c.py']

__all__ = ['CompilationTarget',
           'CompilationResult',
           'InputOutput',
           'TransformationResult']

# Generated at 2022-06-23 23:41:55.453914
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.Module()
    d = ['a.py']
    t1 = TransformationResult(tree=t, tree_changed=True, dependencies=d)
    assert t1.tree is t
    assert t1.tree_changed is True
    assert t1.dependencies is d

# Result of code generator
CodeGenerationResult = NamedTuple('CodeGenerationResult',
                                  [('generated_code', str)])

# Result of file compilation
FileCompilationResult = NamedTuple('FileCompilationResult',
                                   [('target', CompilationTarget),
                                    ('result_file', Path),
                                    ('result_code', str),
                                    ('result_deps', List[str])])

# Result of multi-file compilation

# Generated at 2022-06-23 23:41:56.945861
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2.0, (3, 4), [])


# Generated at 2022-06-23 23:41:59.931332
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('abc.py')
    output = Path('abc.pyc')
    inout = InputOutput(input, output)
    assert(inout.input == input)
    assert(inout.output == output)


# Generated at 2022-06-23 23:42:01.954719
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('foo.py')
    output = Path('bar.py')
    iop = InputOutput(input, output)
    assert iop.input == input
    assert iop.output == output
