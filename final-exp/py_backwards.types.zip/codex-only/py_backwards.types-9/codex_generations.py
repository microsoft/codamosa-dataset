

# Generated at 2022-06-23 23:32:00.925138
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(input=Path('/home/efi/input.txt'),
                     output=Path('/home/efi/output.txt'))
    assert(io.input == Path('/home/efi/input.txt'))
    assert(io.output == Path('/home/efi/output.txt'))

# Generated at 2022-06-23 23:32:02.031101
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert isinstance(TransformationResult(None, False, []), TransformationResult)

# Generated at 2022-06-23 23:32:05.043775
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('some_file.py')
    output = Path('some_file.pyi')

    assert input != output

    result = InputOutput(input=input, output=output)
    assert result.input == input
    assert result.output == output



# Generated at 2022-06-23 23:32:07.684256
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=0, time=0, target=(3, 7), dependencies=[])
    assert result.files == 0
    assert result.time == 0
    assert result.target == (3, 7)
    assert result.dependencies == []


# Generated at 2022-06-23 23:32:09.043020
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(tree=None,
                             tree_changed=None,
                             dependencies=[])
    assert t.dependencies == []

# Generated at 2022-06-23 23:32:14.852179
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 12
    time = 1.0
    target = (2, 7)
    dependencies = ['A', 'B']
    result = CompilationResult(files, time, target, dependencies)
    assert result.files == 12
    assert result.time == 1.0
    assert result.target == (2, 7)
    assert result.dependencies == ['A', 'B']


# Generated at 2022-06-23 23:32:18.125493
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input, output = Path('input.txt'), Path('output.txt')
    actual_pair = InputOutput(input, output)
    assert actual_pair.input == input
    assert actual_pair.output == output


# Generated at 2022-06-23 23:32:22.629756
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result_ = CompilationResult(files=1, time=0.3,
                                            target=CompilationTarget(2, 7),
                                            dependencies=[])
    assert(compilation_result_.files == 1)
    assert(compilation_result_.time == 0.3)
    assert(compilation_result_.target == CompilationTarget(2, 7))
    assert(compilation_result_.dependencies == [])

# Generated at 2022-06-23 23:32:26.070660
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=0.2,
                           target=(3, 6), dependencies=['a', 'b', 'c'])
    assert cr.files == 1
    assert cr.time == 0.2
    assert cr.target == (3, 6)
    assert cr.dependencies == ['a', 'b', 'c']


# Generated at 2022-06-23 23:32:31.968644
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # pylint: disable=unused-variable
    files = 0
    time = 0.0
    target = (2, 7)
    dependencies = []
    result = CompilationResult(files, time, target, dependencies)

    # pylint: disable=undefined-variable
    assert result.files is files
    assert result.time is time
    assert result.target is target
    assert result.dependencies is dependencies

# Generated at 2022-06-23 23:32:35.599946
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
  TransformResult = TransformationResult(tree=ast.AST(),
                                         tree_changed=True,
                                         dependencies=['foo', 'bar'])
  assert TransformResult.tree
  assert TransformResult.tree_changed
  assert TransformResult.dependencies == ['foo', 'bar']

# Generated at 2022-06-23 23:32:39.216454
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.3, target=(3,6), dependencies=[])
    assert result.files == 1
    assert result.time == 0.3
    assert result.target == (3,6)
    assert result.dependencies == []


# Generated at 2022-06-23 23:32:44.119281
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation = CompilationResult(files=1, time=10.0, target=(3, 6), dependencies=['a', 'b'])

    assert compilation.files == 1
    assert compilation.time == 10.0
    assert compilation.target == (3, 6)
    assert compilation.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:32:47.664462
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.0, target=(3, 6), dependencies=[])
    assert result.files == 1
    assert result.time == 0.0
    assert result.target == (3, 6)
    assert result.dependencies == []


# Generated at 2022-06-23 23:32:54.138073
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('1', 'file.py', mode='eval')
    tree_changed = True
    dependencies = ['file2.py', 'file3.py']
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Result of analysis and possible transformation
AnalysisResult = NamedTuple('AnalysisResult',
                            [('valid_for_target', bool),
                             ('tree_changed', bool),
                             ('dependencies', List[str])])


# Generated at 2022-06-23 23:33:01.113474
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput('/input/path.py', '/output/path.c').input == Path('/input/path.py')
    assert InputOutput('/input/path.py', '/output/path.c').output == Path('/output/path.c')
    assert InputOutput(Path('/input/path.py'), '/output/path.c').output == Path('/output/path.c')
    assert InputOutput('/input/path.py', Path('/output/path.c')).input == Path('/input/path.py')
    assert InputOutput('/input/path.py', Path('/output/path.c')).output == Path('/output/path.c')
    assert InputOutput(Path('/input/path.py'), '/output/path.c').output == Path('/output/path.c')
    assert Input

# Generated at 2022-06-23 23:33:02.769030
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-23 23:33:05.071637
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(1, 2.3, (3, 4), ['a', 'b'])
    assert res.files == 1
    assert res.time == 2.3
    assert res.target == (3, 4)
    assert res.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:33:11.829658
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    tr = TransformationResult(None, None, None)  # type: ignore
    assert tr.tree is None
    assert tr.tree_changed is None
    assert tr.dependencies is None


# Information about file
FileInfo = NamedTuple('FileInfo', [('path', Path),
                                   ('size', int),
                                   ('mtime', float),
                                   ('deps', List[Tuple[str, int, float]])])


# Generated at 2022-06-23 23:33:13.594891
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput('foo', 'bar') == InputOutput(Path('foo'), Path('bar'))

# Generated at 2022-06-23 23:33:17.375396
# Unit test for constructor of class InputOutput
def test_InputOutput():

    # Arrange
    path_str = 'file.py'
    input_path = Path(path_str)
    output_path = Path(path_str + 'c')

    # Act
    pair = InputOutput(input_path, output_path)

    # Assert
    assert pair.input == input_path
    assert pair.output == output_path

# Generated at 2022-06-23 23:33:18.933589
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert is_InputOutput(InputOutput(Path('~/a.py'), Path('~/a.js')))


# Generated at 2022-06-23 23:33:25.584090
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inputs = [
        {
            'input': 'foo.py',
            'output': 'foo.pyc',
        },
        {
            'input': Path('bar.py'),
            'output': Path('bar.pyc'),
        },
    ]

    for test in inputs:
        assert InputOutput(**test).input.as_posix() == test['input']
        assert InputOutput(**test).output.as_posix() == test['output']

# Generated at 2022-06-23 23:33:27.168896
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=None,
                                tree_changed=True,
                                dependencies=['foo'])

# Generated at 2022-06-23 23:33:29.358986
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = InputOutput(Path('input'), Path('output'))
    assert isinstance(i.input, Path)
    assert isinstance(i.output, Path)



# Generated at 2022-06-23 23:33:32.008534
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    r = TransformationResult(tree, True, [])
    assert r.tree == tree
    assert r.tree_changed == True
    assert r.dependencies == []

# Generated at 2022-06-23 23:33:37.931862
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    def dummy_constructor() -> TransformationResult:
        return TransformationResult(ast.parse('a = 1'), True, [])

    dummy_constructor()

# Result of compilers compilation
CompilationResult = NamedTuple('CompilationResult',
                               [('file', Path),
                                ('time', float),
                                ('target', CompilationTarget),
                                ('dependencies', List[str])])

# Result of compilers compilation
CompilationSoResult = NamedTuple('CompilationResult',
                                 [('target', CompilationTarget),
                                  ('so', bytes),
                                  ('dependencies', List[str])])


# Generated at 2022-06-23 23:33:42.125572
# Unit test for constructor of class InputOutput
def test_InputOutput():
    try:
        InputOutput('a', 'b')
    except TypeError:
        pass
    else:
        assert False, "TypeError not raised"
    InputOutput(Path('a'), 'b')
    InputOutput('a', Path('b'))
    InputOutput(Path('a'), Path('b'))


# Generated at 2022-06-23 23:33:45.089890
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, None, None)

# Transformation result for the first transformer
TransformationResultFirst = NamedTuple('TransformationResultFirst',
                                       [('tree', ast.AST),
                                        ('tree_changed', bool),
                                        ('dependencies', List[str]),
                                        ('target', CompilationTarget)])


# Generated at 2022-06-23 23:33:49.938588
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    class CustomAST(ast.AST):
        pass
    tr = TransformationResult(tree=CustomAST(),
                              tree_changed=False,
                              dependencies=['dep1', 'dep2'])
    assert(tr.tree_changed == False)
    assert(tr.dependencies == ['dep1', 'dep2'])
    assert(isinstance(tr.tree, CustomAST))

# Generated at 2022-06-23 23:33:55.264571
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i1 = InputOutput("a", "b")
    assert isinstance(i1.input, Path)
    assert isinstance(i1.output, Path)

    assert i1.input == Path("a")
    assert i1.output == Path("b")

    i2 = InputOutput(Path("c"), Path("d"))
    assert i1 != i2
    assert i2.input == Path("c")
    assert i2.output == Path("d")

# Generated at 2022-06-23 23:34:00.310404
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    dummy_ast = ast.Expr(value=ast.Num(n=1))
    dummy_dependencies = ['dummy']
    test = TransformationResult(tree=dummy_ast,
                                tree_changed=True,
                                dependencies=dummy_dependencies)
    assert test.tree == dummy_ast
    assert test.tree_changed == True
    assert test.dependencies == dummy_dependencies

# Generated at 2022-06-23 23:34:03.569380
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    r = TransformationResult(
        tree_changed=True,
        tree=ast.parse('y = x'),
        dependencies=['x.py'],
    )
    assert r.tree_changed is True
    assert isinstance(r.tree, ast.Module)
    assert r.dependencies == ['x.py']

# Generated at 2022-06-23 23:34:06.725158
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 2.0, (1, 1), [])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (1, 1)
    assert result.dependencies == []


# Generated at 2022-06-23 23:34:14.060788
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    import random
    import unittest
    import ast
    random_source = "".join(chr(random.randrange(256)) for _ in range(2048))
    random_ast = ast.parse(random_source)
    TransformationResult(tree=random_ast,
                         tree_changed=False,
                         dependencies=[])

# The maximum number of bytes that can be read at one time by read()
# on posix and windows systems. (4096 on posix, 8192 on windows)
# This is the default value used by TokenizeFile.
MaxReadBytes = io.DEFAULT_BUFFER_SIZE

# Default initial bytes to read by TokenizeFile
InitialReadBytes = 128

# Represent state of tokenization

# Generated at 2022-06-23 23:34:16.791728
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=1.1,
                               target=(3, 4),
                               dependencies=["a", "b"])
    assert result.files == 1
    assert result.time == 1.1
    assert result.target == (3, 4)
    assert result.dependencies == ["a", "b"]


# Generated at 2022-06-23 23:34:20.784351
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = InputOutput(Path('a'), Path('b'))
    b = InputOutput(Path('a'), Path('b'))
    assert a == b
    a = InputOutput(Path('a'), Path('b'))
    b = InputOutput(Path('b'), Path('a'))
    assert a != b

# Generated at 2022-06-23 23:34:24.569071
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput('input', 'output')
    assert input_output.input == 'input'
    assert input_output.output == 'output'
    print(input_output)


# Generated at 2022-06-23 23:34:28.925807
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """Unit test for constructor of class InputOutput

    """
    input = Path('foo.py')
    output = Path('foo.c')

    input_output = InputOutput(input, output)

    assert input_output.input == input
    assert input_output.output == output

# Generated at 2022-06-23 23:34:31.999532
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('a')
    o = Path('b')
    inputoutput = InputOutput(input=i, output=o)
    assert inputoutput.input == i
    assert inputoutput.output == o


# Generated at 2022-06-23 23:34:34.430150
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(1, 2, (3, 4), ['a', 'b'])
    assert res.files == 1
    assert res.time == 2
    assert res.target == (3, 4)
    assert res.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:34:36.088585
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(tree=ast.AST(), tree_changed=False,
                         dependencies=[])

# Generated at 2022-06-23 23:34:39.697850
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, False, []) != None


# Result of a single compilation test
CompilationTest = NamedTuple('CompilationTest',
                             [('input', InputOutput),
                              ('result', CompilationResult)])


# Generated at 2022-06-23 23:34:42.536038
# Unit test for constructor of class InputOutput
def test_InputOutput():
    x = InputOutput(input=Path('input'), output=Path('output'))
    assert x.input == Path('input')
    assert x.output == Path('output')

# Generated at 2022-06-23 23:34:48.935669
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = 'In'
    output = 'Out'
    assert InputOutput(input_, output).input == input_
    assert InputOutput(input_, output).output == output
    inputOutput = InputOutput(input_, output)
    assert inputOutput.input == input_
    assert inputOutput.output == output
    inputOutput = InputOutput(input_, output)
    assert inputOutput.input == input_
    assert inputOutput.output == output


# Generated at 2022-06-23 23:34:50.044172
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2, (3, 4), ['d1', 'd2'])


# Generated at 2022-06-23 23:34:52.046328
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(tree=ast.parse('pass'),
                               tree_changed=True,
                               dependencies=[])
    assert res

# Generated at 2022-06-23 23:34:53.485789
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(0, 0.0, (3, 7), []) is not None


# Generated at 2022-06-23 23:34:54.910163
# Unit test for constructor of class TransformationResult

# Generated at 2022-06-23 23:34:56.123980
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse(""), True, ["a", "b"])

# Generated at 2022-06-23 23:35:01.237335
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(0,
                                           123.456,
                                           (3, 0),
                                           [])
    assert compilation_result.files == 0
    assert compilation_result.time == 123.456
    assert compilation_result.target == (3, 0)
    assert compilation_result.dependencies == []


# Generated at 2022-06-23 23:35:09.258395
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from collections import Counter
    from anytree import Node
    from anytree.search import findall

    # Check
    tr = TransformationResult(Node('root'), True, ['dependency'])
    assert tr.tree_changed == True
    assert tr.dependencies == ['dependency']
    assert tr.tree.name == 'root'
    assert Counter(map(lambda x: x.name, findall(tr.tree, lambda x: True))) == Counter(['root'])

# Result of AST peephole
PeepholeResult = NamedTuple('PeepholeResult',
                            [('tree', ast.AST),
                             ('tree_changed', bool)])


# Generated at 2022-06-23 23:35:12.723762
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.AST(), False, []).tree_changed

# Information about transformers
TransformerInfo = NamedTuple('TransformerInfo',
                             [('name', str),
                              ('transf', Callable[[ast.AST],
                                                  TransformationResult])])

# Custom errors

# Generated at 2022-06-23 23:35:16.245792
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('')
    dependencies = ['a']
    tr = TransformationResult(tree=tree, tree_changed=False, dependencies=dependencies)
    assert tr.tree == tree
    assert tr.tree_changed == False
    assert tr.dependencies == ['a']

# Generated at 2022-06-23 23:35:19.891126
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    dependencies = ['foo.py']
    result = TransformationResult(tree, True, dependencies)
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == dependencies

# Generated at 2022-06-23 23:35:22.562864
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=1,
                             time=1.2,
                             target=(3, 5),
                             dependencies=['a', 'b'])

# Generated at 2022-06-23 23:35:24.697081
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput('input_path',
                       'output_path') == InputOutput(Path('input_path'), Path('output_path'))

# Generated at 2022-06-23 23:35:29.154634
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Given
    input_path = Path('input.py')
    output_path = Path('output.py')
    # When
    result = InputOutput(input_path, output_path)
    # Then
    assert isinstance(result, InputOutput)
    assert result.input == input_path
    assert result.output == output_path


# Generated at 2022-06-23 23:35:36.254436
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    """
    >>> TransformationResult(ast.parse('x=5'), True, ['foo'])
    TransformationResult(tree=Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=5))], type_ignores=[]), tree_changed=True, dependencies=['foo'])
    """
    pass

# Type alias for input/output pair with additional data (needed for generation of document)
InputOutputWithData = NamedTuple('InputOutputWithData',
                                 [('input', Path),
                                  ('output', Path),
                                  ('content', str),
                                  ('result', CompilationResult)])


# Generated at 2022-06-23 23:35:40.161340
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(tree=None,
                                  tree_changed=True,
                                  dependencies=["a", "b"])
    assert result.tree is None
    assert result.tree_changed is True
    assert result.dependencies == ["a", "b"]

# Generated at 2022-06-23 23:35:48.201880
# Unit test for constructor of class InputOutput
def test_InputOutput():
    try:
        InputOutput(input='foo', output='bar')
        raise Exception("should have raised a TypeError")
    except TypeError:
        pass

    try:
        InputOutput(input=Path('foo'), output='bar')
        raise Exception("should have raised a TypeError")
    except TypeError:
        pass

    try:
        InputOutput(input='foo', output=Path('bar'))
        raise Exception("should have raised a TypeError")
    except TypeError:
        pass

    InputOutput(input=Path('foo'), output=Path('bar'))

# Generated at 2022-06-23 23:35:53.298384
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    '''
    Unit test for constructor of class TransformationResult
    '''
    tree = ast.parse('x = 1')
    tree_changed = True
    dependencies = ['a', 'b']
    result = TransformationResult(tree, tree_changed, dependencies)
    assert (result.tree, result.tree_changed, result.dependencies) == (tree, tree_changed, dependencies)

# Generated at 2022-06-23 23:35:56.502137
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(0, 0.0, (3, 6), [])
    assert res.files == 0
    assert res.time == 0.0
    assert res.target == (3, 6)
    assert res.dependencies == []


# Generated at 2022-06-23 23:35:58.661127
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('input.txt')
    out = Path('output.txt')
    io = InputOutput(inp, out)
    assert io.input == inp
    assert io.output == out

# Generated at 2022-06-23 23:36:01.198191
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    value = CompilationResult(files=1, time=2.2, target=(3, 4), dependencies=[])
    assert value.files == 1
    assert value.time == 2.2
    assert value.target == (3, 4)
    assert value.dependencies == []


# Generated at 2022-06-23 23:36:05.104779
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.parse(''), True, [])


# Result of transformers transformation
CompilationError = NamedTuple('CompilationError',
                              [('input_filename', Path),
                               ('error_message', str)])

# Generated at 2022-06-23 23:36:09.498942
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """
    Test construction of the InputOutput class
    """
    input_output = InputOutput(input=Path('input.py'),
                               output=Path('output.py'))
    assert input_output.input == Path('input.py')
    assert input_output.output == Path('output.py')


# Generated at 2022-06-23 23:36:12.970558
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('input_path')
    output_path = Path('output_path')
    io = InputOutput(input_path, output_path)
    assert io.input == input_path
    assert io.output == output_path

# Generated at 2022-06-23 23:36:14.865123
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(0, 1.1, (2, 3), ['a'])



# Generated at 2022-06-23 23:36:18.570830
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    dict = {}
    dict['tree'] = ast.Module()
    dict['tree_changed'] = True
    dict['dependencies'] = []
    res = TransformationResult(**dict)
    assert isinstance(res.tree, ast.Module)
    assert res.tree_changed is True

# Generated at 2022-06-23 23:36:22.194684
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('/home/foo/bar/xyz.py')
    output_path = Path('/home/foo/bar/xyz-generated.py')

    io = InputOutput(input_path, output_path)

    assert io.input == input_path
    assert io.output == output_path


# Generated at 2022-06-23 23:36:23.216914
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    pass


# Generated at 2022-06-23 23:36:27.976284
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_file = Path("data/input.txt")
    output_file = Path("data/output.txt")

    input_output = InputOutput(input_file, output_file)

    assert input_output.input == input_file
    assert input_output.output == output_file


# Generated at 2022-06-23 23:36:28.948305
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 1.0, (3, 7), [])



# Generated at 2022-06-23 23:36:35.378422
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=2.0,
                               target=(3, 4),
                               dependencies=['d1', 'd2'])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == ['d1', 'd2']


# Generated at 2022-06-23 23:36:38.093045
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('a'), Path('b'))
    assert input_output.input == Path('a')
    assert input_output.output == Path('b')

# Generated at 2022-06-23 23:36:42.254016
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=ast.AST(), tree_changed=False, dependencies=[])
    assert tr.tree is not None
    assert tr.dependencies == []
    assert not tr.tree_changed


# AST to source transformer
Transformer = NamedTuple('Transformer', [('name', str),
                                         ('func', ast.AST)])

# Generated at 2022-06-23 23:36:45.986699
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = 'path1'
    path2 = 'path2'
    input_output = InputOutput(path1, path2)
    assert input_output.input == path1
    assert input_output.output == path2


# Generated at 2022-06-23 23:36:49.793435
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(10, 2.4, (3, 5), [])
    assert result.files == 10
    assert result.time == 2.4
    assert result.target == (3, 5)
    assert result.dependencies == []


# Generated at 2022-06-23 23:36:54.765415
# Unit test for constructor of class InputOutput
def test_InputOutput():
    with pytest.raises(TypeError):
        InputOutput("test", "test")
    with pytest.raises(TypeError):
        InputOutput(Path("test"), "test")
    with pytest.raises(TypeError):
        InputOutput("test", Path("test"))

    path1 = Path("test")
    path2 = Path("test2")
    input_output = InputOutput(path1, path2)
    assert isinstance(input_output.input, Path)
    assert isinstance(input_output.output, Path)
    assert input_output.input == path1
    assert input_output.output == path2

# Generated at 2022-06-23 23:36:56.341943
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(tree=None,
                             tree_changed=False,
                             dependencies=[])

# Generated at 2022-06-23 23:36:59.762031
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('path/to/input')
    output = Path('path/to/output')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-23 23:37:06.578835
# Unit test for constructor of class InputOutput
def test_InputOutput():
    d1 = '/ab/cd'
    d2 = 'ef'
    d3 = 'gh'
    f1 = 'abc'
    f2 = 'def.py'

    a = Path(d1) / Path(d2) / Path(d3)
    b = Path(f2)
    iop = InputOutput(a / Path(f1), a / b)
    assert iop.input == a / f1
    assert iop.output == a / b

# Generated at 2022-06-23 23:37:11.491511
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(
        files=5,
        time=0.5,
        target=(3, 7),
        dependencies=['a', 'b', 'c'])
    assert(result.files == 5)
    assert(result.time == 0.5)
    assert(result.target == (3, 7))
    assert(result.dependencies == ['a', 'b', 'c'])


# Generated at 2022-06-23 23:37:13.615679
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = 'input.py'
    output = 'output.py'
    io = InputOutput(input_, output)
    assert io.input == input_ and io.output == output



# Generated at 2022-06-23 23:37:16.413299
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=['a'])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == ['a']


# Generated at 2022-06-23 23:37:19.143708
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree1 = ast.parse('x = 7')

    assert TransformationResult(tree1, False, []) == \
           TransformationResult(tree1, False, [])

# Generated at 2022-06-23 23:37:20.190707
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(None, False, [])

# Generated at 2022-06-23 23:37:24.823841
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = 'input.py'
    output = 'input.pyc'
    _input = Path(input)
    _output = Path(output)
    io = InputOutput(_input, _output)
    assert(io.input == _input)
    assert(io.output == _output)



# Generated at 2022-06-23 23:37:27.654456
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    x = TransformationResult(None, None, None)
    assert isinstance(x, TransformationResult)
    assert x.tree is None
    assert x.tree_changed is None
    assert x.dependencies is None

# Generated at 2022-06-23 23:37:32.229313
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # pylint: disable=W0612
    src = Path('src')
    dst = Path('dst')
    input_output = InputOutput(src, dst)
    compilation_result = CompilationResult(files=1,
                                           time=0.5,
                                           target=(2, 7),
                                           dependencies=['a', 'b'])
    assert isinstance(compilation_result.files, int)
    assert isinstance(compilation_result.time, float)
    assert isinstance(compilation_result.target, tuple)
    assert isinstance(compilation_result.target[0], int)
    assert isinstance(compilation_result.target[1], int)
    assert isinstance(compilation_result.dependencies, list)

# Generated at 2022-06-23 23:37:33.891579
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(tree=ast.parse('1+2'), tree_changed=False, dependencies=[])
    assert 'TransformationResult(tree=' in repr(res)  # for coverage

# Generated at 2022-06-23 23:37:39.603541
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('1+2')
    tr = TransformationResult(tree, False, [])

    assert isinstance(tr.tree, ast.AST)
    assert isinstance(tr.tree_changed, bool)
    assert isinstance(tr.dependencies, list)
    assert all([isinstance(i, str) for i in tr.dependencies])



# Generated at 2022-06-23 23:37:42.911348
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path('input-path')
    path2 = Path('output-path')
    io = InputOutput(path1, path2)
    assert io.input == path1
    assert io.output == path2


# Generated at 2022-06-23 23:37:44.474176
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2.0, (3, 4), ['a'])


# Generated at 2022-06-23 23:37:46.856196
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('input')
    o = Path('output')
    input_output = InputOutput(i, o)
    assert input_output.input == i
    assert input_output.output == o

# Generated at 2022-06-23 23:37:50.730422
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=0.0, target=(3, 6),
                           dependencies=['/home/user/py2/lib/file.py'])
    assert cr.files == 1
    assert cr.time == 0.0
    assert cr.target == (3, 6)
    assert cr.dependencies == ['/home/user/py2/lib/file.py']

# Generated at 2022-06-23 23:37:54.101952
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=ast.Module([], []), tree_changed=False,
                              dependencies=[])
    assert tr.tree_changed == False
    assert tr.dependencies == []
    assert tr.tree != None


# Generated at 2022-06-23 23:37:56.430482
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    with pytest.raises(TypeError):
        TransformationResult(1, False, [])
        TransformationResult(tree=1, tree_changed=False, dependencies=[])

# Generated at 2022-06-23 23:38:00.563615
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=10, target=(3, 7),
                               dependencies=[])
    assert result.files == 1
    assert result.time == 10
    assert result.target == (3, 7)
    assert result.dependencies == []



# Generated at 2022-06-23 23:38:09.554724
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(None, False, ["dep1", "dep2"])
    assert isinstance(tr, TransformationResult)
    assert isinstance(tr.tree, ast.AST)
    assert tr.tree_changed == False
    assert tr.dependencies == ["dep1", "dep2"]

# Result of transformerss actions
TransformationActionResult = NamedTuple('TransformationActionResult',
                                        [('success', bool),
                                         ('errors', List[str])])

# Result of transformator's transformation
TransformationWrapper = NamedTuple('TransformationWrapper',
                                   [('transformation_result', TransformationResult),
                                    ('transformation_action_result', TransformationActionResult)])


# Generated at 2022-06-23 23:38:12.380468
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # pylint: disable=unused-variable
    # pylint: disable=unsubscriptable-object

    test_result = TransformationResult(None, None, None)
    assert test_result.tree == None
    assert test_result.tree_changed == None
    assert test_result.dependencies == None

    # pylint: enable=unsubscriptable-object
    # pylint: enable=unused-variable

# Generated at 2022-06-23 23:38:17.238442
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=['./some/path'])
    assert isinstance(cr.files, int)
    assert isinstance(cr.time, float)
    assert isinstance(cr.target, CompilationTarget)
    assert isinstance(cr.dependencies, list)


# Generated at 2022-06-23 23:38:21.267243
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(tree=ast.parse('a'),
                               tree_changed=False,
                               dependencies=['a', 'b'])
    assert(res.tree)
    assert(not res.tree_changed)
    assert(len(res.dependencies) == 2)

# Generated at 2022-06-23 23:38:27.280638
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(42, 3.14, (3, 7), ['foo.py', 'bar.py'])
    assert c.files == 42
    assert c.time == 3.14
    assert c.target == (3, 7)
    assert c.dependencies == ['foo.py', 'bar.py']

    with pytest.raises(TypeError):
        c = CompilationResult(42, 3.14, (3, 7), 42)


# Generated at 2022-06-23 23:38:32.617608
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_target = (3, 6)
    compilation_result = CompilationResult(files=2,
                                           time=2.0,
                                           target=compilation_target,
                                           dependencies=["a", "b"])
    assert compilation_result.files == 2
    assert compilation_result.time == 2.0
    assert compilation_result.target == compilation_target
    assert compilation_result.dependencies == ["a", "b"]

# Generated at 2022-06-23 23:38:34.219549
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput('a', 'b').input == 'a'
    assert InputOutput('a', 'b').output == 'b'

# Generated at 2022-06-23 23:38:36.769852
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('foo')
    to_test = TransformationResult(tree, True, ['a'])
    assert to_test.tree == tree
    assert to_test.tree_changed == True
    assert to_test.dependencies == ['a']

# Generated at 2022-06-23 23:38:39.733188
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=['a', 'b'])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3, 4)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:38:42.819747
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('./input')
    output = Path('./output')

    pair = InputOutput(input, output)

    assert pair.input == input
    assert pair.output == output

# Generated at 2022-06-23 23:38:52.872077
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 2.0, (3, 4), ['foo.py', 'bar.py']) == \
        CompilationResult(1, 2.0, (3, 4), ['foo.py', 'bar.py'])
    assert CompilationResult(1, 2.0, (3, 4), ['foo.py', 'bar.py']) != \
        CompilationResult(1, 10.0, (3, 4), ['foo.py', 'bar.py'])
    assert CompilationResult(1, 2.0, (3, 4), ['foo.py', 'bar.py']) != \
        CompilationResult(1, 2.0, (3, 0), ['foo.py', 'bar.py'])

# Generated at 2022-06-23 23:38:56.003521
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(1, 0.5, (3, 7), ['std'])
    assert compilation_result.files == 1
    assert compilation_result.time == 0.5
    assert compilation_result.target == (3, 7)
    assert compilation_result.dependencies == ['std']



# Generated at 2022-06-23 23:38:59.954634
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=1,
                            time=10.0,
                            target=(3, 4),
                            dependencies=['a.py'])
    assert res.files == 1
    assert res.time == 10.0
    assert res.target == (3, 4)
    assert res.dependencies == ['a.py']


# Generated at 2022-06-23 23:39:04.980130
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 1
    time = 2.3
    target = (3, 4)
    dependencies = ['dep', 'end']

    c = CompilationResult(files=files, time=time,
                          target=target, dependencies=dependencies)

    assert c.files == files
    assert c.time == time
    assert c.target == target
    assert c.dependencies == dependencies

    # Check hash
    assert hash(c)

    # Check equality
    assert c == CompilationResult(files=files, time=time,
                                  target=target, dependencies=dependencies)
    assert c != CompilationResult(files=files+1, time=time,
                                  target=target, dependencies=dependencies)
    assert c != CompilationResult(files=files, time=time+1,
                                  target=target, dependencies=dependencies)

# Generated at 2022-06-23 23:39:09.002627
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    module = ast.Module([])
    result = TransformationResult(tree=module, tree_changed=True, dependencies=[])
    assert result.tree == module
    assert result.tree_changed is True
    assert result.dependencies == []

# Generated at 2022-06-23 23:39:12.764964
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(0, 0, (0, 0), [])
    assert result.files == 0
    assert result.time == 0
    assert result.target == (0, 0)
    assert result.dependencies == []


# Generated at 2022-06-23 23:39:16.805186
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # pylint: disable=missing-docstring
    a = ast.parse('42')
    b = []
    c = TransformationResult(a, False, b)
    assert c.tree == a
    assert c.tree_changed == False
    assert c.dependencies == b

# Generated at 2022-06-23 23:39:18.920468
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=10, time=10.0,
                      target=(3, 6), dependencies=[])


# Generated at 2022-06-23 23:39:22.280692
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(1, 1.0, (3, 5), ['foo', 'bar'])
    assert cr.files == 1
    assert cr.time == 1.0
    assert cr.target == (3, 5)
    assert cr.dependencies == ['foo', 'bar']


# Generated at 2022-06-23 23:39:27.585401
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('/path/input')
    output_path = Path('/path/output')
    input_output = InputOutput(input=input_path, output=output_path)
    assert isinstance(input_output, InputOutput)
    assert input_output.input == input_path
    assert input_output.output == output_path


# Generated at 2022-06-23 23:39:38.803674
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Test: new object
    obj_1 = TransformationResult(ast.parse('str'), True, [])
    assert isinstance(obj_1, TransformationResult)
    obj_2 = TransformationResult(ast.parse('str'), False, [])
    assert isinstance(obj_2, TransformationResult)

    # Test: new object
    obj_3 = TransformationResult(ast.parse('str'), True, [])
    assert isinstance(obj_3, TransformationResult)
    obj_4 = TransformationResult(ast.parse('str'), False, [])
    assert isinstance(obj_4, TransformationResult)

    # Test: repr, str

# Generated at 2022-06-23 23:39:40.431499
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_io = InputOutput('in', 'out')
    assert test_io.input == Path('in')
    assert test_io.output == Path('out')



# Generated at 2022-06-23 23:39:41.573725
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 1.2, (3, 7), ['a.py'])


# Generated at 2022-06-23 23:39:45.139808
# Unit test for constructor of class InputOutput
def test_InputOutput():
    try:
        input = InputOutput("input", "output")
        assert(False)
    except TypeError: pass
    input = InputOutput(Path("input"), Path("output"))
    assert(input.input == Path("input"))
    assert(input.output == Path("output"))


# Generated at 2022-06-23 23:39:48.468292
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    _ = TransformationResult(None, None, None)  # type: ignore

# Result of transformer transformation
TransformerResult = NamedTuple('TransformerResult',
                               [('result', TransformationResult),
                                ('transformer', str)])


# Generated at 2022-06-23 23:39:52.353507
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Arrange
    testdata = [('a', 'b')]

    # Act
    x = InputOutput(*testdata)

    # Assert
    assert x.input == 'a'
    assert x.output == 'b'

# Generated at 2022-06-23 23:39:57.520936
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=10, time=0.1, target=(2, 7),
                           dependencies=['a', 'b', 'c'])
    assert cr.files == 10
    assert cr.time == 0.1
    assert cr.target == (2, 7)
    assert cr.dependencies == ['a', 'b', 'c']


# Generated at 2022-06-23 23:40:01.551381
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(input=Path('input.py'),
                               output=Path('output.py'))
    assert input_output.input == Path('input.py')
    assert input_output.output == Path('output.py')


# Generated at 2022-06-23 23:40:03.518597
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/input')
    output = Path('/output')
    pair = InputOutput(input, output)
    assert pair.input == input
    assert pair.output == output

# Generated at 2022-06-23 23:40:07.651983
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(input=Path("/test/input.py"),
                               output=Path("/test/output.py"))
    assert(input_output.input == Path("/test/input.py"))
    assert(input_output.output == Path("/test/output.py"))

# Generated at 2022-06-23 23:40:08.723999
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult()


# Generated at 2022-06-23 23:40:14.294357
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # given
    tree = ast.parse('a = 1')
    tree_changed = True
    dependencies = ['foo', 'bar']

    # when
    tr = TransformationResult(tree, tree_changed, dependencies)

    # then
    assert tr.tree == tree
    assert tr.tree_changed == tree_changed
    assert tr.dependencies == dependencies

# Generated at 2022-06-23 23:40:18.523196
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    dut = CompilationResult(42, 13.37, (3, 7), ['foo', 'bar'])
    assert dut.files == 42
    assert dut.time == 13.37
    assert dut.target == (3, 7)
    assert dut.dependencies == ['foo', 'bar']



# Generated at 2022-06-23 23:40:23.652050
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from test.ast_builders import build_int_ast

    tree = build_int_ast(10)
    result = TransformationResult(tree, True, ["test/dep1.py", "test/dep2.py"])

    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == ["test/dep1.py", "test/dep2.py"]

# Generated at 2022-06-23 23:40:26.667802
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    in_out = InputOutput(input, output)
    assert in_out.input == input
    assert in_out.output == output


# Generated at 2022-06-23 23:40:30.266482
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('path/to/input')
    output = Path('path/to/output')

    pair = InputOutput(input, output)
    assert pair.input == input
    assert pair.output == output

# Unit tests for constructor of class CompilationResult

# Generated at 2022-06-23 23:40:35.337546
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(files=5,
                          time=2.0,
                          target=(3, 7),
                          dependencies=['foo.py'])
    assert(r.files == 5)
    assert(r.time == 2.0)
    assert(r.target == (3, 7))
    assert(r.dependencies == ['foo.py'])


# Generated at 2022-06-23 23:40:38.413035
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=0, target=(2, 7), dependencies=[])
    assert cr.files == 1
    assert cr.time == 0
    assert cr.target == (2, 7)
    assert cr.dependencies == []


# Generated at 2022-06-23 23:40:41.818088
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Complete constructor call
    _tree = ast.parse("a = 1")
    _tree_changed = True
    _dependencies = ["some.py"]
    TransformationResult(_tree, _tree_changed, _dependencies)

    # Missing dependencies
    _tree_changed = True
    TransformationResult(_tree, _tree_changed)

    # Missing tree_changed
    TransformationResult(_tree)

# Generated at 2022-06-23 23:40:51.207055
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=None, tree_changed=True, dependencies=[])
    assert tr.tree is None
    assert tr.tree_changed == True
    assert tr.dependencies == []

    tr = TransformationResult(tree=ast.Name(id='a', ctx=ast.Load()),
                              tree_changed=False,
                              dependencies=['filename1', 'filename2'])
    assert isinstance(tr.tree, ast.Name)
    assert tr.tree.id == 'a'
    assert isinstance(tr.tree.ctx, ast.Load)
    assert tr.tree_changed == False
    assert tr.dependencies == ['filename1', 'filename2']

# Generated at 2022-06-23 23:41:00.899865
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse('3'),
                                False,
                                ['a', 'b'])._fields == \
        ('tree', 'tree_changed', 'dependencies')
    assert TransformationResult(ast.parse('3'),
                                False,
                                ['a', 'b']) == \
        TransformationResult(ast.parse('3'),
                             False,
                             ['a', 'b'])
    assert TransformationResult(ast.parse('3'),
                                False,
                                ['a', 'b']) == \
        TransformationResult(ast.parse('3'),
                             False,
                             ['a', 'b'])

# Generated at 2022-06-23 23:41:05.730643
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_input = Path(__file__)
    test_output = Path(__file__)
    test_tuple = InputOutput(test_input, test_output)

    assert test_tuple.input is test_input
    assert test_tuple.output is test_output



# Generated at 2022-06-23 23:41:14.890505
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    import random
    import os
    import sys
    import shutil
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdirname:
        tree = ast.parse('x = 3 + 4')
        tree_changed = bool(random.randint(0, 1))
        dependencies = [os.path.abspath(os.path.join(tmpdirname, 'dep{}'.format(i))) for i in range(10)]
        for i in range(10):
            os.makedirs(dependencies[i])
        transformation_result = TransformationResult(tree, tree_changed, dependencies)
        assert transformation_result.tree == tree
        assert transformation_result.tree_changed == tree_changed
        assert transformation_result.dependencies == dependencies
        for dep in dependencies:
            shutil.rmtree(dep)


# Generated at 2022-06-23 23:41:18.140653
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    a = CompilationResult(1, 2.0, (3, 4), ['a', 'b'])
    assert a.files == 1
    assert a.time == 2.0
    assert a.target == (3, 4)
    assert a.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:41:22.600625
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    class TestTransformer:
        def visit_Module(self, node):
            return TransformationResult(node, True, [])
    tree = ast.parse('x = 1')
    transformer = TestTransformer()
    result = transformer.visit(tree)
    assert result == TransformationResult(tree, True, [])
    assert result.tree is tree
    assert result.tree_changed is True
    assert result.dependencies == []

# Generated at 2022-06-23 23:41:26.159810
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(files=1, time=0.5, target=(2, 7), dependencies=[])
    assert isinstance(r.files, int)
    assert isinstance(r.time, float)
    assert isinstance(r.target, CompilationTarget)
    assert isinstance(r.dependencies, list)



# Generated at 2022-06-23 23:41:27.639379
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(None, False, None)
    assert tr.tree is None and not tr.tree_changed and tr.dependencies is None

# Generated at 2022-06-23 23:41:30.302816
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('.'), Path('.')).input  == Path('.')
    assert InputOutput(Path('.'), Path('.')).output == Path('.')

# Generated at 2022-06-23 23:41:35.677652
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=1,
                          time=0.1,
                          target=(3,7),
                          dependencies=['foo', 'bar'])
    assert c.files == 1
    assert c.time == 0.1
    assert c.target == (3,7)
    assert c.dependencies == ['foo', 'bar']


# Generated at 2022-06-23 23:41:38.611752
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_inout = InputOutput('a', 'b')
    assert test_inout.input == 'a'
    assert test_inout.output == 'b'


# Generated at 2022-06-23 23:41:44.947789
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.AST(), False, [])
    assert TransformationResult(ast.AST(), True, [])
    assert TransformationResult(ast.AST(), False, ['dep'])
    assert TransformationResult(ast.AST(), True, ['dep'])

# Compilation error
CompilationError = NamedTuple('CompilationError', [('message', str)])


# Generated at 2022-06-23 23:41:54.767421
# Unit test for constructor of class InputOutput
def test_InputOutput():
    def test(x, y):
        assert x == y.input
        assert y.output.name == y.input.name + ".pyc"
    test("/some/path/to/file", InputOutput("/some/path/to/file",
                                          "/some/path/to/file.pyc"))
    test("file", InputOutput("file", "file.pyc"))
    test("file.py", InputOutput("file.py", "file.pyc"))
    test("file.pyc", InputOutput("file.pyc", "file.pyc.pyc"))
    test("file.pyc", InputOutput("file.pyc.pyc", "file.pyc.pyc.pyc"))

# Generated at 2022-06-23 23:41:55.925700
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Test the constructor
    CompilationResult(1, 2.0, (3, 4), [])


# Generated at 2022-06-23 23:41:57.011828
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(0, 1, (2, 3), 4)

