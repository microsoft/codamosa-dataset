

# Generated at 2022-06-23 23:31:57.304264
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a/b.py'), Path('a/b.pyc')) == InputOutput(*('a/b.py', 'a/b.pyc'))


# Generated at 2022-06-23 23:32:02.634232
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast1 = ast.parse('x = 1')
    ast2 = ast.parse('y = 1')
    t1 = TransformationResult(ast1, True, ['a', 'b'])
    t2 = TransformationResult(ast2, False, ['a', 'b'])
    assert t1.tree_changed == True
    assert t2.tree_changed == False
    assert isinstance(t1.tree, ast.AST)
    assert t1.dependencies == ['a', 'b']

# Generated at 2022-06-23 23:32:06.148196
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_node = ast.parse("a = 1")
    transformation_result = TransformationResult(ast_node, True,
                                                 ["path/to/file.py"])

    assert transformation_result.tree is ast_node
    assert transformation_result.tree_changed
    assert transformation_result.dependencies == ["path/to/file.py"]

# Generated at 2022-06-23 23:32:10.695227
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=5, time=5.0, target=(3, 7), dependencies=["a", "b", "c"])
    assert cr.files == 5
    assert cr.time == 5.0
    assert cr.target == (3, 7)
    assert cr.dependencies == ["a", "b", "c"]

    try:
        cr = CompilationResult(files=5, time=5.0, target=(3, 7), dependencies="a")
    except Exception as e:
        assert isinstance(e, TypeError)
    else:
        assert False



# Generated at 2022-06-23 23:32:14.851924
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('/home/test/test.py')
    output_path = Path('/home/test/test')
    input_output = InputOutput(input=input_path, output=output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path

# Generated at 2022-06-23 23:32:21.506657
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse('a+b'), True, []) == TransformationResult(ast.parse('a+b'), True, [])
    assert TransformationResult(ast.parse('a+b'), True, []) != TransformationResult(ast.parse('a+b+c'), True, [])
    assert TransformationResult(ast.parse('a+b'), True, []) != TransformationResult(ast.parse('a+b'), False, [])
    assert TransformationResult(ast.parse('a+b'), True, []) != TransformationResult(ast.parse('a+b'), True, ['foo'])

# Generated at 2022-06-23 23:32:23.588261
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Create an object
    result = CompilationResult(1, 1.0, (3, 5), [])
    # Test for equality
    assert result == CompilationResult(1, 1.0, (3, 5), [])


# Generated at 2022-06-23 23:32:28.969637
# Unit test for constructor of class TransformationResult
def test_TransformationResult(): # type: () -> None
    tree = ast.parse('x = 1')
    tree_changed = False
    dependencies = ['abc']

    transformation_result = TransformationResult(tree, tree_changed,
                                                 dependencies)

    assert transformation_result.tree == tree
    assert transformation_result.tree_changed == tree_changed
    assert transformation_result.dependencies == dependencies

# Generated at 2022-06-23 23:32:31.639078
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path("input")
    output = Path("output")
    i = InputOutput(input, output)
    assert i.input == input
    assert i.output == output

# Generated at 2022-06-23 23:32:40.137579
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    dummy = ast.Assign()
    dummy.names = [ast.Name()]
    dummy.value = ast.Num()
    dummy.value.n = 7
    dummy.lineno = 18
    dummy.col_offset = 5
    result = TransformationResult(dummy, True, [])
    # Note: this test works given the current implementation, but would fail if
    # we changed the internal design. This can be fixed by changing the semantics
    # of the NamedTuple so that the constructor copies the fields deep instead of
    # shallow.
    assert(result.tree == dummy)
    assert(result.tree_changed == True)
    assert(result.dependencies == [])
    # Mutating result.tree should only change the value in result, but not in dummy
    # We don't know the actual members of dummy, but we know that it has

# Generated at 2022-06-23 23:32:45.228686
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input=Path('major/minor.py'),
                       output=Path('major/minor.py')).input == Path('major/minor.py')
    assert InputOutput(input=Path('major/minor.py'),
                       output=Path('major/minor.py')).output == Path('major/minor.py')


# Generated at 2022-06-23 23:32:48.025965
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('foo.txt')
    output = Path('bar.txt')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-23 23:32:49.572809
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput('foo', 'bar') == \
        InputOutput(Path('foo'), Path('bar'))

# Generated at 2022-06-23 23:32:56.258129
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # type: () -> None
    x = InputOutput('a.py', 'a_out.py')
    assert x.input == 'a.py'
    assert x.output == 'a_out.py'
    assert x.input == Path('a.py')
    assert x.output == Path('a_out.py')

    y = InputOutput(Path('b.py'), Path('b_out.py'))
    assert y.input == 'b.py'
    assert y.output == 'b_out.py'
    assert y.input == Path('b.py')
    assert y.output == Path('b_out.py')

# Generated at 2022-06-23 23:32:57.245594
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path("a.py"), Path("b.py"))


# Generated at 2022-06-23 23:32:59.806992
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(tree=ast.parse('a = 5'),
                                  tree_changed=True,
                                  dependencies=['b.py'])
    assert result.tree_changed == True
    assert result.dependencies == ['b.py']

# Generated at 2022-06-23 23:33:01.500696
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(0, 0.0, (0, 0), [])



# Generated at 2022-06-23 23:33:06.772719
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = 'base/path/to/input/'
    output = 'base/path/to/output/'
    InputOutput(input, output)

# Check that this does not raise an exception
InputOutput('base/path/to/input', 'base/path/to/output')

# Check that this raises an exception because of incompatible types
InputOutput(1, 'base/path/to/output')
IE01 = TypeError

# Check that this raises an exception because of incompatible types
InputOutput('base/path/to/input', 2)
IE02 = TypeError

# Check that this raises an exception because of incompatible types
InputOutput(1, 2)
IE03 = TypeError

# Check that this raises an exception because of incompatible types
InputOutput([1, 'base/path/to/input'], 2)
IE04 = TypeError

# Generated at 2022-06-23 23:33:08.725968
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.Module([], []), True, [])  # type: ignore

# Generated at 2022-06-23 23:33:10.552107
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp')
    output = Path('/tmp')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-23 23:33:19.030365
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from tempfile import TemporaryDirectory
    from typed_ast import ast3 as ast
    import os

    with TemporaryDirectory() as tmpdir:
        tree = ast.parse('')
        tr = TransformationResult(tree, False, [os.path.join(tmpdir, 'a.py'),
                                                 os.path.join(tmpdir, 'b.py')])
        assert tr.tree == tree
        assert tr.tree_changed == False
        assert tr.dependencies == [os.path.join(tmpdir, 'a.py'),
                                   os.path.join(tmpdir, 'b.py')]

# A tuple of argv[0] and argc[1]
Argv = NamedTuple('Argv', [('argv0', str),
                           ('argc1', str)])

# Generated at 2022-06-23 23:33:23.031938
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(10,
                               20,
                               (3, 5),
                               ['a', 'b'])

    assert result.files == 10
    assert result.time == 20
    assert result.target == (3, 5)


# Generated at 2022-06-23 23:33:28.302411
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(
        files=1,
        time=1.0,
        target=(2, 3),
        dependencies=['foo.py']
    )
    assert(cr.files == 1)
    assert(cr.time == 1.0)
    assert(cr.target == (2, 3))
    assert(cr.dependencies == ['foo.py'])



# Generated at 2022-06-23 23:33:31.389945
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(1, 1.1, (1, 2), ["a.py"])
    assert cr.files == 1
    assert cr.time == 1.1
    assert cr.target == (1, 2)
    assert cr.dependencies == ["a.py"]


# Generated at 2022-06-23 23:33:32.042930
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput('a', 'b')



# Generated at 2022-06-23 23:33:37.490773
# Unit test for constructor of class InputOutput
def test_InputOutput():

    # should be OK
    try:
        InputOutput(Path('foo'), Path('bar'))
    except TypeError:
        assert False
    else:
        assert True

    # should fail
    try:
        InputOutput(Path('foo'), 'bar')
    except TypeError:
        assert True

    # should fail
    try:
        InputOutput('foo', Path('bar'))
    except TypeError:
        assert True

    # should fail
    try:
        InputOutput('foo', 'bar')
    except TypeError:
        assert True


# Generated at 2022-06-23 23:33:40.717648
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path("hello.py")
    output = Path("hello.pyc")
    input_output = InputOutput(input, output)
    assert input == input_output.input
    assert output == input_output.output


# Generated at 2022-06-23 23:33:42.132452
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    try:
        TransformationResult(None, None, None)
    except TypeError:  # pragma: no cover
        assert False

# Generated at 2022-06-23 23:33:44.721596
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1, target=(3, 5), dependencies=[])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 5)
    assert result.dependencies == []


# Generated at 2022-06-23 23:33:47.851479
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('./input'), Path('./output'))
    assert input_output.input == Path('./input')
    assert input_output.output == Path('./output')


# Generated at 2022-06-23 23:33:52.105134
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 1
    time = 0.0
    target = (3, 5)
    dependencies = []
    result = CompilationResult(files, time, target, dependencies)
    assert result is not None
    assert result.files == files
    assert result.time == time
    assert result.target == target
    assert result.dependencies == dependencies


# Generated at 2022-06-23 23:34:01.442575
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('pass')
    dep = ['a']
    tt: TransformationResult = TransformationResult(t, True, dep)
    assert isinstance(tt.tree_changed, bool)
    assert isinstance(tt.tree, ast.AST)
    assert isinstance(tt.dependencies, list)

    tt = TransformationResult(t, False, dep)
    assert isinstance(tt.tree_changed, bool)
    assert isinstance(tt.tree, ast.AST)
    assert isinstance(tt.dependencies, list)

# Result of function transformer.transform()
TransformResult = NamedTuple('TransformResult',
                             [('tree', ast.AST),
                              ('changed', bool),
                              ('dependencies', List[str])])

# Result of function transformer.transform()

# Generated at 2022-06-23 23:34:04.532333
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=17, time=4.2, target=(3, 6), dependencies=['A', 'B'])
    assert result.files == 17
    assert result.time == 4.2
    assert result.target == (3, 6)
    assert result.dependencies == ['A', 'B']


# Generated at 2022-06-23 23:34:06.287195
# Unit test for constructor of class CompilationResult
def test_CompilationResult():  # type: () -> None
    CompilationResult(files=0, time=0, target=(3, 5), dependencies=[])



# Generated at 2022-06-23 23:34:08.816927
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('a')
    output = Path('b')
    t = InputOutput(input, output)
    assert t.input == input and t.output == output


# Generated at 2022-06-23 23:34:11.028440
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')

    r = TransformationResult(tree=tree, tree_changed=False, dependencies=[])
    assert isinstance(r, TransformationResult)


# Wrapper around types module

# Generated at 2022-06-23 23:34:13.216563
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('input')
    o = Path('output')
    assert InputOutput(input=i, output=o).input == i
    assert InputOutput(input=i, output=o).output == o

# Generated at 2022-06-23 23:34:16.599346
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 1.0, (3, 6), ['a', 'b', 'c'])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 6)
    assert result.dependencies == ['a', 'b', 'c']


# Generated at 2022-06-23 23:34:20.324163
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    value = CompilationResult(100, 1.0, (3, 6), [])
    assert 100 == value.files
    assert 1.0 == value.time
    assert (3, 6) == value.target
    assert [] == value.dependencies



# Generated at 2022-06-23 23:34:22.751451
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2, (3, 4), ['a', 'b'])


# Unit tests for constructor of class InputOutput

# Generated at 2022-06-23 23:34:27.172383
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    a = ast.Name()
    tr = TransformationResult(tree=a, tree_changed=True, dependencies=[])
    assert tr.tree == a
    assert tr.tree_changed
    assert tr.dependencies == []

# Generated at 2022-06-23 23:34:34.263292
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert issubclass(CompilationResult, NamedTuple)
    assert issubclass(CompilationResult, tuple)

    assert CompilationResult.__name__ == 'CompilationResult'
    assert CompilationResult.__doc__ == 'CompilationResult(files, time, target, dependencies)'

    assert CompilationResult._fields == ('files', 'time', 'target', 'dependencies')

    assert CompilationResult.files.__doc__ == 'Alias for field number 0'
    assert CompilationResult.files.__name__ == 'files'
    assert CompilationResult.files.__module__ == 'typed_ast.ast3'

    assert CompilationResult.time.__doc__ == 'Alias for field number 1'
    assert CompilationResult.time.__name__ == 'time'

# Generated at 2022-06-23 23:34:38.962543
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # pragma: no cover
    tree = ast.parse('42')
    tr = TransformationResult(tree, True, ['x', 'y', 'z'])
    assert tr.tree is tree
    assert tr.tree_changed is True
    assert tr.dependencies == ['x', 'y', 'z']

# Generated at 2022-06-23 23:34:41.985069
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input=Path('foo'), output=Path('bar')).input.name == 'foo'
    assert InputOutput(input=Path('foo'), output=Path('bar')).output.name == 'bar'

# Generated at 2022-06-23 23:34:48.040969
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1,
                                           time=1.0,
                                           target=(2, 0),
                                           dependencies=['foo', 'bar'])
    assert compilation_result.files == 1
    assert compilation_result.time == 1.0
    assert compilation_result.target == (2, 0)
    assert compilation_result.dependencies == ['foo', 'bar']


# Generated at 2022-06-23 23:34:52.945075
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('''
a = 1
b = 2
    ''')

    tres = TransformationResult(tree, False, ['a', 'b'])

    assert tres.tree.body[0].value.n == 1
    assert tres.tree_changed == False
    assert tres.dependencies == ['a', 'b']

# Check if string is valid identifier

# Generated at 2022-06-23 23:34:55.017750
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=0,
                      time=0,
                      target=(3, 5),
                      dependencies=[])


# Generated at 2022-06-23 23:34:58.433903
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.AST(), True, ['a'])
    assert isinstance(tr.tree, ast.AST)
    assert tr.tree_changed is True
    assert isinstance(tr.dependencies, list)

# Generated at 2022-06-23 23:35:01.332283
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    i_o = InputOutput(input, output)
    assert i_o.input == input
    assert i_o.output == output

# Generated at 2022-06-23 23:35:02.285004
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, None, None) is not None

# Generated at 2022-06-23 23:35:06.138898
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=3, time=3.14, target=(3, 5), dependencies=[])
    assert result.files == 3
    assert result.time == 3.14
    assert result.target == (3, 5)
    assert result.dependencies == []


# Generated at 2022-06-23 23:35:07.794564
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(tree=ast.AST(),
                         tree_changed=False,
                         dependencies=[])

import types

# Generated at 2022-06-23 23:35:10.822759
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    tr = TransformationResult(tree=tree, tree_changed=True, dependencies=[])
    assert tr.tree_changed == tr.tree_changed
    assert tr.tree == tr.tree
    assert tr.dependencies == tr.dependencies

# Generated at 2022-06-23 23:35:15.665623
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(1, 2, (3, 4), ['a.py', 'b.py'])
    test_assert(cr.files == 1)
    test_assert(cr.time == 2)
    test_assert(cr.target == (3, 4))
    test_assert(cr.dependencies == ['a.py', 'b.py'])


# Generated at 2022-06-23 23:35:20.935864
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(1, 0.0, (3, 7), ['a', 'b'])
    assert compilation_result.files == 1
    assert compilation_result.time == 0.0
    assert compilation_result.target == (3, 7)
    assert compilation_result.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:35:23.464414
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    comp_result = CompilationResult(1, 1, (3, 6), [])
    assert (comp_result.files == 1)
    assert (comp_result.time == 1)
    assert (comp_result.target == (3, 6))
    assert (comp_result.dependencies == [])



# Generated at 2022-06-23 23:35:27.276130
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 0.1, (3, 7), ['a', 'b']) == \
           CompilationResult(files=1, time=0.1,
                             target=(3, 7), dependencies=['a', 'b'])


# Generated at 2022-06-23 23:35:30.904502
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    def test(dependencies: List[str],
             tree: ast.AST,
             tree_changed: bool) -> None:
        TransformationResult(dependencies=dependencies,
                             tree=tree,
                             tree_changed=tree_changed)

    test([], ast.Str('a'), True)

# Generated at 2022-06-23 23:35:33.949835
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    x = TransformationResult(ast.parse('a=1'), False, ['a', 'b'])
    assert x.tree is not None
    assert x.tree_changed is False
    assert x.dependencies is not None
    assert len(x.dependencies) == 2

# Generated at 2022-06-23 23:35:35.820373
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.AST()
    assert isinstance(TransformationResult(tree, False, []), TransformationResult)
    assert isinstance(TransformationResult(tree, True, []), TransformationResult)

# Generated at 2022-06-23 23:35:39.184333
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 41
    time = 3.468
    target = (3, 8)
    dependencies = ['a', 'b', 'c']
    t = CompilationResult(files, time, target, dependencies)
    assert t.files == 41
    assert t.time == 3.468
    assert t.target == (3, 8)
    assert t.dependencies == ['a', 'b', 'c']


# Generated at 2022-06-23 23:35:43.061672
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=0, time=0.1, target=(2, 7), dependencies=[])
    assert cr.files == 0
    assert cr.time == 0.1
    assert cr.target == (2, 7)
    assert cr.dependencies == []


# Generated at 2022-06-23 23:35:46.591996
# Unit test for constructor of class InputOutput
def test_InputOutput():
    try:
        input = Path('in.txt')
        output = Path('out.txt')
        InputOutput(input, output)
        assert True
    except:
        assert False


# Generated at 2022-06-23 23:35:50.163219
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('in.py'), Path('out.py'))
    assert input_output.input == Path('in.py')
    assert input_output.output == Path('out.py')


# Generated at 2022-06-23 23:35:54.896385
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    ctx = CompilationResult(files=1, time=1.1, target=(2, 7),
                            dependencies=['a', 'b'])

    assert ctx.files == 1
    assert ctx.time == 1.1
    assert ctx.target == (2, 7)
    assert ctx.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:36:02.068848
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    t1 = CompilationResult(1, 1.0, (3, 5), ['a', 'b'])
    assert t1.files == 1
    assert t1.time == 1.0
    assert t1.target == (3, 5)
    assert t1.dependencies == ['a', 'b']

    t2 = CompilationResult(files=1, time=1.0, target=(2, 7),
                           dependencies=['c'])
    assert t2.files == 1
    assert t2.time == 1.0
    assert t2.target == (2, 7)
    assert t2.dependencies == ['c']


# Generated at 2022-06-23 23:36:06.733996
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # type: () -> None
    test_input = Path("foo")
    test_output = Path("bar")
    test_result = InputOutput(test_input, test_output)
    assert test_result.input == test_input
    assert test_result.output == test_output


# Generated at 2022-06-23 23:36:10.424474
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(5, 42.0, (3, 5), [])
    assert result.files == 5
    assert result.time == 42.0
    assert result.target == (3, 5)
    assert result.dependencies == []


# Generated at 2022-06-23 23:36:12.776366
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path('input'), Path('output'))
    assert io.input == Path('input')
    assert io.output == Path('output')

# Generated at 2022-06-23 23:36:15.879755
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 1')
    res = TransformationResult(tree, True, [])
    assert res.tree == tree
    assert res.tree_changed == True
    assert res.dependencies == []

# Generated at 2022-06-23 23:36:20.159315
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/home/user/project/src/a.py')
    output = Path('/tmp/a.py')
    io = InputOutput(input, output)

    assert str(io.input) == '/home/user/project/src/a.py'
    assert str(io.output) == '/tmp/a.py'

# Generated at 2022-06-23 23:36:24.549957
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 1, (3, 6), ['A', 'B'])
    assert result.files == 1
    assert result.time == 1
    assert result.target == (3, 6)
    assert result.dependencies == ['A', 'B']

# Generated at 2022-06-23 23:36:29.081735
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    a = CompilationResult(files=1, time=0.5, target=(3, 9), dependencies=["test.py"])
    assert a.files == 1
    assert a.time == 0.5
    assert a.target == (3, 9)
    assert a.dependencies == ["test.py"]


# Generated at 2022-06-23 23:36:38.668350
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(ast.parse('a = 1'), True, [])
    assert result.tree
    assert result.tree_changed
    assert result.dependencies == []
    assert 'asdl_seq(' in repr(result.tree)
    assert 'AST(' in repr(result.tree)
    assert 'AST(' in repr(result)


# Single Python file processing result
FileResult = NamedTuple('FileResult',
                        [('input', Path),
                         ('output', Path),
                         ('target', CompilationTarget),
                         ('status', bool),
                         ('compile_time', float),
                         ('transform_time', float)])


# Generated at 2022-06-23 23:36:41.481705
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    pair = InputOutput(input, output)
    assert pair.input == input
    assert pair.output == output


# Generated at 2022-06-23 23:36:43.743493
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.Module(), False, [])
    assert isinstance(tr.tree, ast.AST)
    assert not tr.tree_changed
    assert isinstance(tr.dependencies, List)

# Generated at 2022-06-23 23:36:44.801538
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    pass


# Generated at 2022-06-23 23:36:50.246420
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # no transformation -- no dependencies
    result = CompilationResult(files=10, time=0.0, target=(3, 6), dependencies=[])
    assert result.files == 10
    assert result.time == 0.0
    assert result.target == (3, 6)
    assert result.dependencies == []
    with pytest.raises(AttributeError):
        result.undefined


# Generated at 2022-06-23 23:36:50.910324
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.Module(), False, [])

# Generated at 2022-06-23 23:36:53.461680
# Unit test for constructor of class CompilationResult
def test_CompilationResult(): #type: () -> None
    result = CompilationResult(3, 1.5, (3, 7), ['src/mymodule.py'])
    assert result.files == 3
    assert result.time == 1.5
    assert result.target == (3, 7)


# Generated at 2022-06-23 23:37:04.140395
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    dependencies = ['mylib', 'numpy']
    tree = ast.parse('import collections, os')
    result = TransformationResult(tree, True, dependencies)
    assert isinstance(result.tree, ast.AST)
    assert result.tree_changed
    assert result.dependencies == dependencies

# Information about transformation
TransformationInfo = NamedTuple('TransformationInfo',
                                [('name', str),
                                 ('version', str),
                                 ('time', float)])

# Information about compiler
CompilerInfo = NamedTuple('CompilerInfo',
                          [('name', str),
                           ('version', str)])

# Result of compilation

# Generated at 2022-06-23 23:37:05.418663
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse('pass'), True, ['hello'])

# Generated at 2022-06-23 23:37:09.246038
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    expected_files = 1
    expected_time = 5.0
    expected_target = (3, 6)
    expected_deps = ['a', 'b']
    res = CompilationResult(expected_files, expected_time, expected_target,
                            expected_deps)
    assert res.files == expected_files
    assert res.time == expected_time
    assert res.target == expected_target
    assert res.dependencies == expected_deps


# Generated at 2022-06-23 23:37:11.025619
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    test = InputOutput(input, Path('output'))
    assert test.input == input
    assert test.output == Path('output')

# Generated at 2022-06-23 23:37:13.685320
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a=1')
    assert TransformationResult(tree, True, [])
    assert TransformationResult(tree, False, []).dependencies == []
    assert TransformationResult(tree, True, ['a', 'b']).dependencies == ['a', 'b']

# Generated at 2022-06-23 23:37:17.056468
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    tree_changed = True
    dependencies = ['foo.py']
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == ['foo.py']

# Generated at 2022-06-23 23:37:21.886219
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    """Unit test for constructor of class TransformationResult"""
    result = TransformationResult(tree=None,
                                  tree_changed=False,
                                  dependencies=[])

    assert (result.tree is None)
    assert not result.tree_changed
    assert (result.dependencies == [])

# Generated at 2022-06-23 23:37:23.877207
# Unit test for constructor of class InputOutput
def test_InputOutput():
    try:
        InputOutput()
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-23 23:37:28.133119
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr1 = CompilationResult(1, 2.0, (3, 4), ['a', 'b', 'c'])
    assert cr1.files == 1
    assert cr1.time == 2.0
    assert cr1.target == (3, 4)
    assert cr1.dependencies == ['a', 'b', 'c']

# Generated at 2022-06-23 23:37:29.160614
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # type: () -> None
    InputOutput(Path('foo.py'), Path('bar.py'))

# Generated at 2022-06-23 23:37:33.069873
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=10,time=1.5,target=(2,7),dependencies=['a'])

    assert(res.files == 10)
    assert(res.time == 1.5)
    assert(res.target == (2,7))
    assert(res.dependencies == ['/a'])


# Generated at 2022-06-23 23:37:36.864967
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    inout = InputOutput(input, output)
    assert(inout.input == input)
    assert(inout.output == output)

# Unit tests for static methods of class InputOutput

# Generated at 2022-06-23 23:37:40.024793
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    t = TransformationResult(ast.AST(), True, [])
    assert t.tree_changed
    assert not t.dependencies

# Generated at 2022-06-23 23:37:43.227324
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('/home/user/input.txt')
    o = Path('/home/user/output.txt')
    io = InputOutput(i, o)
    assert io.input == i
    assert io.output == o

# Generated at 2022-06-23 23:37:46.931061
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=1,
                          time=0.01,
                          target=(3, 10),
                          dependencies=['foo', 'bar'])
    assert c.files == 1
    assert c.time == 0.01
    assert c.target == (3, 10)
    assert c.dependencies == ['foo', 'bar']

# Generated at 2022-06-23 23:37:50.900571
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1, time=1.0,
                            target=(3, 7), dependencies=['a', 'b', 'c'])
    assert compilation_result.files == 1
    assert compilation_result.time == 1.0
    assert compilation_result.target == (3, 7)
    assert compilation_result.dependencies == ['a', 'b', 'c']

# Generated at 2022-06-23 23:37:55.467036
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('one')
    output = Path('two')
    assert InputOutput(input, output) == InputOutput(input, output)
    assert InputOutput(input, output) != InputOutput(output, input)
    assert str(InputOutput(input, output)) == "InputOutput(input=one, output=two)"


# Generated at 2022-06-23 23:38:01.291401
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r0 = CompilationResult(files=1,
                           time=2.0,
                           target=(3, 4),
                           dependencies=['x', 'y'])

    assert r0.files == 1
    assert r0.time == 2.0
    assert r0.target == (3, 4)
    assert r0.dependencies == ['x', 'y']


# Generated at 2022-06-23 23:38:02.865861
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(0, False, []).tree == 0
    assert TransformationResult(0, False, []).tree_changed == False
    assert TransformationResult(0, False, []).dependencies == []

# Generated at 2022-06-23 23:38:05.469180
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('input'), Path('output')).input == Path('input')
    assert InputOutput(Path('input'), Path('output')).output == Path('output')


# Generated at 2022-06-23 23:38:14.151440
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path_in = Path("input")
    path_out = Path("output")
    IO = InputOutput(path_in, path_out)
    assert IO.input == path_in
    assert IO.output == path_out
    IO = IO._replace(input="aa")
    assert IO.input == Path("aa")
    assert IO.output == path_out
    assert IO._fields == ('input', 'output')
    assert IO._asdict() == {'input': Path("aa"), 'output': Path("output")}
    IO._replace(input="aa", output="out")
    assert IO._asdict() == {'input': Path("aa"), 'output': Path("out")}


# Generated at 2022-06-23 23:38:18.326619
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path_input = Path("input.txt")
    path_output = Path("output.txt")
    input_output = InputOutput(input=path_input,
                               output=path_output)
    assert input_output.input == path_input
    assert input_output.output == path_output



# Generated at 2022-06-23 23:38:23.801429
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    try:
        from typed_ast import ast3 as ast
    except ImportError:
        from ast import AST as ast
    result = TransformationResult(tree=ast.parse('a = 1'),
                                  tree_changed=False,
                                  dependencies=['file1'])
    assert result.tree is not None
    assert result.tree_changed is False
    assert result.dependencies == ['file1']

# Generated at 2022-06-23 23:38:25.153520
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert len(TransformationResult(None, False, None)) == 3

# Generated at 2022-06-23 23:38:28.811661
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(1, 1.0, (2, 3), [])
    assert r.files == 1
    r = CompilationResult(files=1, time=1.0, target=(2, 3), dependencies=[])
    assert r.files == 1


# Generated at 2022-06-23 23:38:30.304302
# Unit test for constructor of class CompilationResult

# Generated at 2022-06-23 23:38:32.229719
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Act
    io = InputOutput('input', 'output')
    # Assert
    assert io.input == Path('input')
    assert io.output == Path('output')

# Generated at 2022-06-23 23:38:32.652966
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    pass

# Generated at 2022-06-23 23:38:35.718472
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(1, 2.0, (3, 4), ['A'])
    assert c.files == 1
    assert c.time == 2.0
    assert c.target == (3, 4)
    assert c.dependencies == ['A']


# Generated at 2022-06-23 23:38:38.660517
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_tree = ast.parse('')
    t_result = TransformationResult(ast_tree, False, [])
    assert t_result.tree == ast_tree
    assert t_result.tree_changed == False
    assert t_result.dependencies == []

# Generated at 2022-06-23 23:38:42.817869
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p1: Path = Path('foo')
    p2: Path = Path('bar')
    pair = InputOutput(p1, p2)
    assert pair.input == p1
    assert pair.output == p2


# Generated at 2022-06-23 23:38:43.795710
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('1 + 1')
    tree_changed = True
    dependencies = ['1.py']
    TransformationResult(tree, tree_changed, dependencies)


# Generated at 2022-06-23 23:38:47.843320
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=0.1, target=(3, 6), dependencies=[])
    assert cr.files == 1
    assert cr.time == 0.1
    assert cr.target == (3, 6)
    assert cr.dependencies == []


# Generated at 2022-06-23 23:38:50.142798
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = "input.txt"
    out = "output.txt"
    inout = InputOutput(Path(inp), Path(out))
    assert inout.input == Path(inp)
    assert inout.output == Path(out)

# Generated at 2022-06-23 23:38:52.283003
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(input="tmp", output="tmp2")
    assert input_output.input == "tmp"
    assert input_output.output == "tmp2"


# Generated at 2022-06-23 23:38:54.224105
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = 'input'
    output = 'output'
    iop = InputOutput(input, output)
    assert iop.input == input
    assert iop.output == output

# Generated at 2022-06-23 23:38:56.946874
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("x = 21")
    tree_changed = True
    dep = ['dep1']
    res = TransformationResult(tree, tree_changed, dep)
    assert res.tree == tree
    assert res.tree_changed == True
    assert res.dependencies == dep

# Generated at 2022-06-23 23:39:00.139930
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('input')
    output_path = Path('output')
    input_output = InputOutput(input_path, output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path


# Generated at 2022-06-23 23:39:00.894060
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(None, None, None)

# Generated at 2022-06-23 23:39:02.057974
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2.3, (3, 4), ['a', 'b'])


# Generated at 2022-06-23 23:39:07.991411
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inputp = Path('foo')
    output = Path('bar')
    try:
        input_output = InputOutput(inputp, output)
        assert input_output.input == inputp
        assert input_output.output == output
    except Exception as exc:
        assert False, 'Creation of InputOutput should be succesful'
    try:
        input_output = InputOutput(output, inputp)
        assert False, 'InputOutput constructor should fail when output is dir'
    except ValueError:
        pass
    try:
        input_output = InputOutput(inputp, None)
        assert False, 'InputOutput constructor should fail when output is None'
    except ValueError:
        pass

# Generated at 2022-06-23 23:39:12.058450
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    input_output = InputOutput(input, output)
    assert input_output == InputOutput(input, output)
    assert input_output != InputOutput(output, input)


# Generated at 2022-06-23 23:39:16.181363
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput('1', '2')
    assert input_output.input == '1'
    assert input_output.output == '2'
    assert input_output == ('1', '2')
    assert input_output != ('1', '3')

# Generated at 2022-06-23 23:39:18.364117
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert isinstance(InputOutput(Path(""), Path("")), InputOutput)
    assert isinstance(InputOutput("", ""), InputOutput)

# Generated at 2022-06-23 23:39:21.909278
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path('abc/') / 'def'
    path2 = Path('ghi')
    assert InputOutput(path1, path2) == InputOutput(path1, path2)
    assert InputOutput(path1, path2) != InputOutput(path2, path1)
    assert InputOutput(path1, path2) != InputOutput(path2, path2)


# Generated at 2022-06-23 23:39:23.740859
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=0, time=0.0, target=(2, 7), dependencies=[])


# Generated at 2022-06-23 23:39:28.034359
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    with pytest.raises(TypeError):
        TransformationResult(1, 2, 3)
    with pytest.raises(TypeError):
        TransformationResult(None, '', 1.0)
    with pytest.raises(TypeError):
        TransformationResult(None, False, [])

# Generated at 2022-06-23 23:39:33.068175
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    comp_result = CompilationResult(2, 5.3, (3, 7), ['/usr/bin'])
    assert comp_result.files == 2
    assert comp_result.time == 5.3
    assert comp_result.target == (3, 7)
    assert comp_result.dependencies == ['/usr/bin']


# Generated at 2022-06-23 23:39:41.513589
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a.py'), Path('b.py')) == InputOutput('a.py', 'b.py')
    assert InputOutput(Path('a.py'), Path('b.py')) != InputOutput('c.py', 'b.py')
    assert InputOutput(Path('a.py'), Path('b.py')) != InputOutput('a.py', 'c.py')
    assert InputOutput(Path('a.py'), Path('b.py')) != (Path('a.py'), Path('b.py'))
    assert InputOutput(Path('a.py'), Path('b.py')) != 'TestString'


# Generated at 2022-06-23 23:39:44.020871
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io1 = InputOutput(Path('input/'), Path('output/'))
    io2 = InputOutput(input=Path('input/'), output=Path('output/'))
    assert io1==io2



# Generated at 2022-06-23 23:39:47.077383
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input.py')
    output = Path('output.py')
    io = InputOutput(input=input, output=output)
    assert io.input == input
    assert io.output == output

# Generated at 2022-06-23 23:39:48.930349
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=[])


# Generated at 2022-06-23 23:39:56.234921
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_cases = [
        InputOutput(Path(__file__), Path('/tmp')),
        InputOutput(Path('/tmp'), Path(__file__)),
        InputOutput(Path(__file__[:-1]), Path(__file__)),
        InputOutput(Path(__file__), Path(__file__[:-1])),
    ]
    for test_case in test_cases:
        assert test_case.input.exists()
        assert not test_case.output.exists()

# Generated at 2022-06-23 23:40:02.427974
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr1 = TransformationResult(tree=ast.parse('x=1234\ny=5678',
                                              mode='exec'),
                               tree_changed=True,
                               dependencies=['dep1.py', 'dep2.py'])

    assert isinstance(tr1.tree, ast.AST)
    assert isinstance(tr1.tree_changed, bool)
    assert isinstance(tr1.dependencies, list)
    assert len(tr1.dependencies) > 0

# Generated at 2022-06-23 23:40:04.923865
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_input_output = InputOutput(Path('./in'), Path('./out'))
    assert test_input_output.input == Path('./in')
    assert test_input_output.output == Path('./out')


# Generated at 2022-06-23 23:40:08.315948
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path("tmp"), Path("tmp"))
    assert input_output.input == Path("tmp")
    assert input_output.output == Path("tmp")


# Generated at 2022-06-23 23:40:10.626351
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    _ = TransformationResult(tree, True, ['a.py'])

# Generated at 2022-06-23 23:40:14.095524
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = InputOutput(Path('/tmp/foo'),
                    Path('/tmp/bar'))
    assert (i.input, i.output) == (Path('/tmp/foo'),
                                   Path('/tmp/bar'))

# Generated at 2022-06-23 23:40:15.055732
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path("foo"), Path("bar"))

# Generated at 2022-06-23 23:40:17.219601
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.Module([]), True, [])
    print(tr)

# Class for transforming ASTs.

# Generated at 2022-06-23 23:40:20.390265
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=5.0, target=(3, 7), dependencies=[])
    assert cr.files == 1
    assert cr.time == 5.0
    assert cr.target == (3, 7)
    assert cr.dependencies == []



# Generated at 2022-06-23 23:40:27.256784
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # type: () -> None
    """
    * Tests the constructor of class InputOutput.
    """
    good_input = InputOutput(input='', output='')
    good_input = InputOutput(input=Path(''), output=Path(''))
    bad_input_1 = InputOutput(input='', output=[])
    bad_input_2 = InputOutput()

    assert good_input.input is not None
    assert good_input.output is not None
    assert not bad_input_1
    assert not bad_input_2

# Generated at 2022-06-23 23:40:29.086019
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    TransformationResult(tree=None, tree_changed=False,
                         dependencies=[])

# Generated at 2022-06-23 23:40:32.604212
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(2, 3.4, (2, 7), ['sys'])
    assert result.files == 2
    assert result.time == 3.4
    assert result.target == (2, 7)
    assert result.dependencies == ['sys']


# Generated at 2022-06-23 23:40:38.001485
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    result = TransformationResult(tree, False, [])
    assert result.tree is tree
    assert result.tree_changed is False
    assert result.dependencies == []

# Result of transformer transformation
# variables can be None if no variables were found
VariableAnalysisResult = NamedTuple('VariableAnalysisResult',
                                    [('variables', List[str]),
                                     ('dependencies', List[str])])


# Generated at 2022-06-23 23:40:40.170158
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input=Path('/tmp/test1'), output=Path('/tmp/test2'))
    assert InputOutput(input=Path('/tmp/test3'), output=Path('/tmp/test4'))

# Generated at 2022-06-23 23:40:44.429841
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path('foo.py')
    path2 = Path('bar.py')
    input_output = InputOutput(path1, path2)
    assert(input_output.input == path1)
    assert(input_output.output == path2)

# Test constructor of class CompilationResult

# Generated at 2022-06-23 23:40:49.658471
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('/some/where/input.bin')
    output_path = Path('/some/where/output.bin')
    input_output = InputOutput(input_path, output_path)

    assert input_output.input == input_path

    assert input_output.output == output_path



# Generated at 2022-06-23 23:40:52.517963
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=1, time=0.2, target=(2, 7),
                             dependencies=['some_mod.py'])


# Generated at 2022-06-23 23:40:55.152247
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path('.')
    path2 = Path('..')
    assert_equal(InputOutput(path1, path2), InputOutput(path1, path2))

# Generated at 2022-06-23 23:40:56.289354
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult is TransformationResult


# Generated at 2022-06-23 23:40:57.959076
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    assert isinstance(TransformationResult(ast.AST(),False,[]),
                      TransformationResult)

# Generated at 2022-06-23 23:40:59.643274
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=42, time=1.0, target=(2, 7), dependencies=[])


# Generated at 2022-06-23 23:41:04.857109
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=1,
                            time=2,
                            target=(3, 4),
                            dependencies=['test'])
    assert res.files == 1
    assert res.time == 2.
    assert res.target == (3, 4)
    assert res.dependencies == ['test']


# Generated at 2022-06-23 23:41:07.474753
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # type: () -> None
    """Validate the constructor of class InputOutput."""
    i = InputOutput('/', '/')
    assert i.input == Path('/')
    assert i.output == Path('/')


# Generated at 2022-06-23 23:41:13.668076
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    r1 = TransformationResult(tree, False, [])

    assert r1.tree is tree
    assert r1.tree_changed is False
    assert r1.dependencies == []


# Result of program transformation separate from apply_transformers
SourceFileTransformationResult = NamedTuple('SourceFileTransformationResult',
                                            [('tree', ast.AST),
                                             ('file_changed', bool),
                                             ('dependencies', List[str]),
                                             ])


# Generated at 2022-06-23 23:41:19.375560
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    expected_result = CompilationResult(files=42,
                                        time=1.23,
                                        target=(3, 6),
                                        dependencies=[])
    tmp = CompilationResult(files=42,
                            time=1.23,
                            target=(3, 6),
                            dependencies=[])
    assert(expected_result.files == 42)
    assert(expected_result.time == 1.23)
    assert(expected_result.target == (3, 6))
    assert(expected_result.dependencies == [])
    assert(tmp == expected_result)


# Generated at 2022-06-23 23:41:27.364035
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    """Unit tests for constructor of class TransformationResult"""
    with pytest.raises(TypeError):
        # some argument is not type TransformationResult
        TransformationResult(tree="t", tree_changed="tr", dependencies=[])

    with pytest.raises(TypeError):
        # some argument is not type TransformationResult
        TransformationResult(tree=ast.parse("x = 10"),
                             tree_changed="tr",
                             dependencies=[])

    with pytest.raises(TypeError):
        # some argument is not type TransformationResult
        TransformationResult(tree=ast.parse("x = 10"),
                             tree_changed=True,
                             dependencies="d")


# Generated at 2022-06-23 23:41:30.899596
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path('abc.txt')
    path2 = Path('file.txt')
    input_output = InputOutput(path1, path2)

    assert input_output.input == path1
    assert input_output.output == path2

# Generated at 2022-06-23 23:41:35.407246
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p = Path('/tmp/test')
    inp = InputOutput(p, p)
    assert inp.input == p
    assert inp.output == p
    inp = InputOutput(str(p), str(p))
    assert inp.input == p
    assert inp.output == p

# Generated at 2022-06-23 23:41:47.724567
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert(CompilationResult(files=0,
                             time=0,
                             target=(0, 0),
                             dependencies=[]) ==
           CompilationResult(files=0,
                             time=0,
                             target=(0, 0),
                             dependencies=[0, 1]))
    assert(CompilationResult(files=0,
                             time=0,
                             target=(0, 0),
                             dependencies=[]) !=
           CompilationResult(files=1,
                             time=0,
                             target=(0, 0),
                             dependencies=[]))

# Generated at 2022-06-23 23:41:54.157630
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("pass")
    t = TransformationResult(tree, True, [])
    assert t.tree is tree
    assert t.tree_changed

# Typed configuration for transformer
# See https://github.com/astroidmail/astroid/issues/636
TransformerConfig = NamedTuple('TransformerConfig',
                               [('transformer', str),
                                ('source', int),
                                ('target', CompilationTarget)])

# Generated at 2022-06-23 23:41:58.572611
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    import sys
    import time

    a = CompilationResult(
        files=1,
        time=time.time(),
        target=sys.version_info[:2],
        dependencies=[]
    )
    b = CompilationResult(
        files=1,
        time=time.time(),
        target=sys.version_info[:2],
        dependencies=[]
    )
    assert a == b