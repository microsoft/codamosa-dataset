

# Generated at 2022-06-23 23:31:59.607770
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/dev/null')
    output = Path('/dev/zero')
    in_out = InputOutput(input, output)
    assert in_out.input == input
    assert in_out.output == output


# Generated at 2022-06-23 23:32:06.861871
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 2.0, (3, 4), ['a', 'b', 'c']) == \
           CompilationResult(1, 2.0, (3, 4), ['a', 'b', 'c'])
    assert CompilationResult(1, 2.0, (3, 4), ['a', 'b', 'c']) != \
           CompilationResult(1, 2.0, (3, 4), ['a', 'b'])
    assert CompilationResult(1, 2.0, (3, 4), ['a', 'b', 'c']) != \
           CompilationResult(1, 2.0, (3, 5), ['a', 'b', 'c'])


# Generated at 2022-06-23 23:32:08.509589
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('print("a")')
    assert isinstance(TransformationResult(tree, True, []), TransformationResult)

# Generated at 2022-06-23 23:32:11.464119
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path("a.py"), Path("b.py"))
    assert InputOutput("a.py", "b.py")


# Generated at 2022-06-23 23:32:14.494735
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(ast.Module([]), False, [])
    assert res.tree == ast.Module([])
    assert res.tree_changed == False
    assert res.dependencies == []

# Generated at 2022-06-23 23:32:16.798741
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=5, time=3.5,
                      target=(3, 5), dependencies=['a.py', 'b.py'])


# Generated at 2022-06-23 23:32:22.408302
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=3.0, target=(3, 5),
                           dependencies=['a', 'b.c'])
    assert cr.files == 1
    assert cr.time == 3.0
    assert cr.target == (3,  5)
    assert cr.dependencies == ['a', 'b.c']
    with pytest.raises(AttributeError):
        cr.invalid_attribute1
    with pytest.raises(AttributeError):
        cr.invalid_attribute2 = 123



# Generated at 2022-06-23 23:32:23.646491
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=None, tree_changed=None, dependencies=None)

# Generated at 2022-06-23 23:32:24.713564
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert isinstance(TransformationResult(None, True, []), TransformationResult)

# Generated at 2022-06-23 23:32:30.927222
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=0, tree_changed=False, dependencies=[])
    assert tr.tree == 0
    assert tr.tree_changed == False
    assert tr.dependencies == []

# Result of code transformation
CodeTransformationResult = NamedTuple('CodeTransformationResult',
                                      [('code', str),
                                       ('changed', bool),
                                       ('dependencies', List[str])])


# Generated at 2022-06-23 23:32:34.198079
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('_input')
    output = Path('_output')
    input_output = InputOutput(input=input, output=output)
    assert input_output.input == input
    assert input_output.output == output


# Generated at 2022-06-23 23:32:37.629037
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # type: () -> None
    a = ast.AST()
    assert (TransformationResult(a, False, []) ==
            TransformationResult(a, False, []))
    assert (TransformationResult(a, True, []) !=
            TransformationResult(a, False, []))

# Generated at 2022-06-23 23:32:40.840304
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(ast.parse(''), True, [])
    assert result.tree is not None
    assert result.tree_changed is True
    assert len(result.dependencies) == 0

# Generated at 2022-06-23 23:32:44.311732
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(ast.Module(body=[]), True, ['a'])
    assert(result.tree.body == [])
    assert(result.tree_changed)
    assert(result.dependencies == ['a'])

# Generated at 2022-06-23 23:32:49.530703
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1, time=2.0, target=(3, 4),
                                           dependencies=['abc.py'])
    assert compilation_result.files == 1
    assert compilation_result.time == 2.0
    assert compilation_result.target[0] == 3
    assert compilation_result.target[1] == 4
    assert compilation_result.dependencies[0] == 'abc.py'


# Generated at 2022-06-23 23:32:50.807867
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.AST(), False, [])

# Generated at 2022-06-23 23:32:55.001440
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    my_tree = ast.parse('pass')
    my_result = TransformationResult(my_tree, True, [])
    if not my_result[0] == my_tree:
        raise Exception('Failed test_TransformationResult')
    if not my_result[1] == True:
        raise Exception('Failed test_TransformationResult')
    if not my_result[2] == []:
        raise Exception('Failed test_TransformationResult')

# Generated at 2022-06-23 23:32:56.181734
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('foo.py'), Path('bar.py'))


# Generated at 2022-06-23 23:33:00.393597
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=12, time=13.2, target=(3, 4),
                           dependencies=['one', 'two'])
    assert cr.files == 12
    assert cr.time == 13.2
    assert cr.target[0] == 3
    assert cr.target[1] == 4
    assert cr.dependencies[0] is 'one'
    assert cr.dependencies[1] is 'two'
    assert len(cr) == 4


# Generated at 2022-06-23 23:33:04.715009
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=1, time=1.5,
                            target=(3, 6),
                            dependencies=['foo', 'bar'])

    assert res.files == 1
    assert res.time == 1.5
    assert res.target == (3, 6)
    assert res.dependencies == ['foo', 'bar']


# Generated at 2022-06-23 23:33:06.753542
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path = Path('test-files/test-file.py')
    iop = InputOutput(path, path)
    assert iop.input == path
    assert iop.output == path

# Generated at 2022-06-23 23:33:10.605338
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path("A")
    o = Path("B")
    input_output = InputOutput(i, o)
    assert input_output.input == i
    assert input_output.output == o


# Generated at 2022-06-23 23:33:15.221830
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=0.1, target=(3, 6),
                           dependencies=['a', 'b'])
    assert(cr.files == 1)
    assert(cr.time == 0.1)
    assert(cr.target == (3, 6))
    assert(cr.dependencies == ['a', 'b'])



# Generated at 2022-06-23 23:33:18.766733
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=3,
                             time=1.0,
                             target=(3, 6),
                             dependencies=['./dep1', './dep2'])


# Generated at 2022-06-23 23:33:23.570515
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree: ast.AST = ast.parse('pass')
    tree_changed: bool = True
    dependencies: List[str] = ['a', 'b']

    result = TransformationResult(tree, tree_changed, dependencies)

    assert result.tree is tree
    assert result.tree_changed is tree_changed
    assert result.dependencies is dependencies

# Generated at 2022-06-23 23:33:25.631833
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    x = TransformationResult(tree=None,
                             tree_changed=False,
                             dependencies=[])

# Generated at 2022-06-23 23:33:26.875817
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput('a', 'b') == (Path('a'), Path('b'))

# Generated at 2022-06-23 23:33:30.839733
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(None, True, None)
    assert t
    assert t.tree is None and t.tree_changed is True and t.dependencies is None
    t = TransformationResult(ast.AST(), False, [])
    assert t and t.tree and t.tree_changed is False and t.dependencies
    assert len(t.dependencies) == 0

# Generated at 2022-06-23 23:33:38.395785
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    with pytest.raises(TypeError):
        CompilationResult(5, 3, (2, 7), [])
    with pytest.raises(TypeError):
        CompilationResult(5, 3.5, (2, 7), [])
    with pytest.raises(TypeError):
        CompilationResult(5, 3.5, (2, '3'), [])
    with pytest.raises(TypeError):
        CompilationResult(5, 3.5, (2,), [])
    with pytest.raises(TypeError):
        CompilationResult(5, 3.5, (2, 5, 6), [])
    with pytest.raises(TypeError):
        CompilationResult(5, 3.5, None, [])


# Generated at 2022-06-23 23:33:41.282411
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.Module(), False, set([])).tree_changed is False
    assert TransformationResult(ast.Module(), True, set([])).tree_changed is True


# Save results of compilation

# Generated at 2022-06-23 23:33:44.385953
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path('a'), Path('b'))
    assert type(io.input) is Path
    assert type(io.output) is Path
    assert io.input == Path('a')
    assert io.output == Path('b')


# Generated at 2022-06-23 23:33:48.398972
# Unit test for constructor of class CompilationResult
def test_CompilationResult():  # type: () -> None
    cr = CompilationResult(1, 1.0, (3, 6), ['dep1', 'dep2'])
    assert cr.files == 1
    assert cr.time == 1.0
    assert cr.target == (3, 6)
    assert cr.dependencies == ['dep1', 'dep2']


# Generated at 2022-06-23 23:33:50.149194
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('in'), Path('out')) == (Path('in'), Path('out'))

# Generated at 2022-06-23 23:33:52.150204
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files = 12, time = 0.42, target = (3, 4),
                      dependencies = ['a.py', 'b.py'])

# Generated at 2022-06-23 23:33:56.403683
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a'), Path('b')) == InputOutput(Path('a'), Path('b'))
    assert InputOutput(Path('a'), Path('b')) != InputOutput(Path('c'), Path('b'))
    assert InputOutput(Path('a'), Path('b')) != InputOutput(Path('a'), Path('d'))

# Generated at 2022-06-23 23:34:00.055202
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(3, 0.11, (2, 7), [])
    assert result.files == 3
    assert result.time == 0.11
    assert result.target == (2, 7)
    assert result.dependencies == []



# Generated at 2022-06-23 23:34:05.226426
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(0, 0.0, (0, 1), [])
    assert result.files == 0
    assert result.time == 0.0
    assert result.target == (0, 1)
    assert result.dependencies == []

    result = CompilationResult(1, 0.1, (3, 4), ['modules'])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 4)
    assert result.dependencies == ['modules']


# Generated at 2022-06-23 23:34:07.824950
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('1+1')
    tree_changed = True
    dependencies = ["a.py"]
    TransformationResult(tree, tree_changed, dependencies)  # type: ignore

# Generated at 2022-06-23 23:34:09.246757
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult()
    CompilationResult(1, 1.0, (2, 3), ['a', 'b'])


# Generated at 2022-06-23 23:34:11.502401
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse(''), False, ['']) == TransformationResult(tree=ast.parse(''),
                                                                                    tree_changed=False,
                                                                                    dependencies=[''])

# Generated at 2022-06-23 23:34:14.166577
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path(__file__)
    o = Path(__file__).parent / 'test_input_output.txt'
    a = InputOutput(input=i, output=o)
    assert a.input == i
    assert a.output == o


# Generated at 2022-06-23 23:34:16.316909
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    result = TransformationResult(tree=None, tree_changed=False, dependencies=[])
    assert result.tree == None
    assert result.tree_changed == False
    assert result.dependencies == []
    assert result.tree is result.tree
    assert result is not result

# Generated at 2022-06-23 23:34:21.871775
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    """
    Create a CompilationResult object with default arguments, and check if
    they are correct
    """

    compilation_result = CompilationResult(0, 0.0, (0, 0), [])
    assert isinstance(compilation_result, CompilationResult)

    assert compilation_result.files == 0
    assert compilation_result.time == 0
    assert compilation_result.target == (0, 0)
    assert compilation_result.dependencies == []


# Generated at 2022-06-23 23:34:24.107935
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput('input', 'output') == InputOutput(Path('input'),
                                                         Path('output'))

# Generated at 2022-06-23 23:34:29.085532
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = InputOutput(input=Path('test'), output=Path('test'))
    b = InputOutput(input=Path('test'), output=Path('test'))
    c = InputOutput(input='test', output='test')

    assert a == b
    assert a == c


# Generated at 2022-06-23 23:34:31.755059
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x=1')
    dependencies = ['foo', 'bar']
    TransformationResult(tree=tree, tree_changed=True, dependencies=dependencies)

# Generated at 2022-06-23 23:34:38.962688
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("")
    assert isinstance(tree, ast.AST)
    assert isinstance(tree, ast.Module)
    tr = TransformationResult(tree, True, [])
    assert isinstance(tr, TransformationResult)
    assert isinstance(tr.tree, ast.AST)
    assert isinstance(tr.tree, ast.Module)
    assert isinstance(tr.tree_changed, bool)
    assert isinstance(tr.dependencies, list)

# Generated at 2022-06-23 23:34:41.540805
# Unit test for constructor of class InputOutput
def test_InputOutput():
    sut = InputOutput(Path('in'), Path('out'))
    assert sut.input == Path('in')
    assert sut.output == Path('out')


# Generated at 2022-06-23 23:34:44.233612
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output

# Generated at 2022-06-23 23:34:48.636276
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(1, 2.0, (2, 7), [])

    assert(c.files == 1)
    assert(c.time == 2.0)
    assert(c.target == (2, 7))
    assert(c.dependencies == [])


# Generated at 2022-06-23 23:34:49.754810
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i, o = 'x', 'y'
    InputOutput(i, o)
    assert True

# Generated at 2022-06-23 23:34:52.794006
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=0, time=0.1, target=(2, 7),
                               dependencies=['a', 'b'])
    assert result.files == 0
    assert result.time == 0.1
    assert result.target == (2, 7)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:34:56.548134
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None

    a = ast.Module(body=[ast.Import(names=[ast.alias(name="sys", asname=None)])])
    tr = TransformationResult(tree=a, tree_changed=True, dependencies=['sys'])

    assert tr.tree == a
    assert tr.tree_changed
    assert tr.dependencies == ['sys']

# Generated at 2022-06-23 23:35:00.236677
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('/tmp'), Path('/tmp/a.py'))
    assert input_output.input == Path('/tmp')
    assert input_output.output == Path('/tmp/a.py')



# Generated at 2022-06-23 23:35:04.687319
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=3.14, target=(3, 7), dependencies=['foo', 'bar'])
    assert result.files == 1
    assert result.time == 3.14
    assert result.target == (3, 7)
    assert result.dependencies == ['foo', 'bar']



# Generated at 2022-06-23 23:35:06.527020
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # noinspection PyTypeChecker
    TransformationResult(tree=None, tree_changed=False, dependencies=[])

# Generated at 2022-06-23 23:35:08.905281
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("x = 5")
    result = TransformationResult(tree, False, ["antlr4"])
    assert result.tree == tree
    assert not result.tree_changed
    assert result.dependencies == ["antlr4"]

# Generated at 2022-06-23 23:35:10.881835
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(input=Path('/home/tom/file.py'),
                output=Path('/home/tom/file.pyc'))


# Generated at 2022-06-23 23:35:13.925439
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=0,
                      target=(0, 0), dependencies=[])
    CompilationResult(files=1, time=0, target=(0, 0))


# Generated at 2022-06-23 23:35:15.077995
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.Module([]), True, [])

# Generated at 2022-06-23 23:35:19.997631
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=0, time=0.0, target=(3, 6),
                            dependencies=['test'])
    assert res.files == 0
    assert res.time == 0.0
    assert res.target == (3, 6)
    assert res.dependencies == ['test']


# Generated at 2022-06-23 23:35:29.885628
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from unittest import TestCase
    from .visitor import Noop
    from .ast import Source

    class TestTransformationResult(TestCase):
        def test(self):
            source = Source('f.py', b'')

            result = TransformationResult(source.tree, False, [])
            self.assertTrue(source.tree is result.tree)
            self.assertFalse(result.tree_changed)
            self.assertEqual(result.dependencies, [])

            result = TransformationResult(source.tree, True, ['foo.py'])
            self.assertTrue(source.tree is result.tree)
            self.assertTrue(result.tree_changed)
            self.assertEqual(result.dependencies, ['foo.py'])


# Generated at 2022-06-23 23:35:37.374856
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    import random
    import string

    def get_random_string():
        return ''.join(random.choice(string.ascii_uppercase)
                       for _ in range(10))

    test_tree = ast.parse(get_random_string())
    test_tree_changed = random.randint(0, 1)
    test_dependencies = [get_random_string() for _ in range(3)]
    t = TransformationResult(test_tree, test_tree_changed, test_dependencies)
    assert t.tree == test_tree
    assert t.tree_changed == test_tree_changed
    assert t.dependencies == test_dependencies


# Test of typed_ast.ast3.AST

# Generated at 2022-06-23 23:35:40.909640
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    assert TransformationResult(ast.AST(),
                                True,
                                []) == TransformationResult(ast.AST(),
                                                            True,
                                                            [])

# Generated at 2022-06-23 23:35:47.465008
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # type: () -> None
    cr = CompilationResult(3, 0.3, (3, 3), ['1.py'])
    assert cr.files == 3
    assert cr.time == 0.3
    assert cr.target == (3, 3)
    assert cr.dependencies == ['1.py']
    assert str(cr) == '<CompilationResult: 3 files, 0.3 s, Python 3.3, [1.py]>'



# Generated at 2022-06-23 23:35:51.360939
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = "Hello"')
    result = TransformationResult(tree, True, ['dep1', 'dep2'])
    assert result.tree == tree
    assert result.tree_changed == True
    assert result.dependencies == ['dep1', 'dep2']

# Generated at 2022-06-23 23:35:53.582205
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path()
    output = Path()
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output

# Generated at 2022-06-23 23:35:57.691381
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Arrange
    tree = ast.AST()
    tree_changed = True
    dependencies = []
    # Act
    test = TransformationResult(tree=tree, tree_changed=tree_changed,
                                dependencies=dependencies)
    # Assert
    assert test.tree is tree
    assert test.tree_changed is True
    assert test.dependencies is dependencies

# Generated at 2022-06-23 23:36:00.218067
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=None, tree_changed=None, dependencies=None)
    assert isinstance(tr, TransformationResult)
    assert tr.tree is None
    assert tr.tree_changed is None
    assert tr.dependencies is None

# Generated at 2022-06-23 23:36:02.191639
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(input=Path("input.py"), output=Path("output.py"))


# Generated at 2022-06-23 23:36:07.239867
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cres = CompilationResult(2, 3.14, (3, 5), ['./abc.py'])
    assert cres.files == 2
    assert cres.time == 3.14
    assert cres.target == (3, 5)
    assert cres.dependencies == ['./abc.py']


# Generated at 2022-06-23 23:36:12.971267
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(None, None) == InputOutput(None, None)
    assert InputOutput(None, None) != InputOutput(None, Path(''))
    assert InputOutput(None, None) != InputOutput(Path(''), None)
    assert InputOutput(None, None) != InputOutput(Path(''), Path(''))
    assert InputOutput(Path(''), Path('')) == InputOutput(Path(''), Path(''))



# Generated at 2022-06-23 23:36:16.837766
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/', 'tmp', 'a.py')
    output = Path('/', 'tmp', 'b.py')
    pair = InputOutput(input, output)
    assert pair.input == input
    assert pair.output == output


# Generated at 2022-06-23 23:36:19.637751
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-23 23:36:27.289617
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('/a'), Path('/b')) == InputOutput(Path('/a'),
                                                             Path('/b'))
    assert InputOutput(Path('/a'), Path('/b')) != InputOutput(Path('/c'),
                                                             Path('/b'))
    assert InputOutput(Path('/a'), Path('/b')) != InputOutput(Path('/a'),
                                                             Path('/c'))
    assert InputOutput(Path('/a'), Path('/b')) != None


# Generated at 2022-06-23 23:36:30.334903
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input, output = Path("input"), Path("output")
    inout = InputOutput(input, output)
    assert inout.input == input
    assert inout.output == output
    assert inout[0] == input
    assert inout[1] == output

# Generated at 2022-06-23 23:36:33.661383
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = 'foo'
    output = 'bar'
    object = InputOutput(input=input, output=output)
    assert object.input == input
    assert object.output == output


# Generated at 2022-06-23 23:36:37.700801
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(None, None, None)
    assert res

# Meta information about analysis
MetaInformation = NamedTuple('MetaInformation', [('name', str),
                                                 ('time', float),
                                                 ('dependencies', List[str])])


# Generated at 2022-06-23 23:36:39.864161
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput('a', 'b').input == 'a'
    assert InputOutput('a', 'b').output == 'b'

# Generated at 2022-06-23 23:36:46.387694
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2.0, (3, 4), ['hello.py'])
    with pytest.raises(TypeError) as err:
        CompilationResult('1', 2.0, (3, 4), ['hello.py'])
    assert "unexpected type for 'files'" in str(err.value)
    with pytest.raises(TypeError) as err:
        CompilationResult(1, '2', (3, 4), ['hello.py'])
    assert "unexpected type for 'time'" in str(err.value)
    with pytest.raises(TypeError) as err:
        CompilationResult(1, 2.0, '3', ['hello.py'])
    assert "unexpected type for 'target'" in str(err.value)

# Generated at 2022-06-23 23:36:50.115038
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    target = CompilationResult(42, 'foo', (1, 2), [])
    assert target.files == 42
    assert target.time == 'foo'
    assert target.target == (1, 2)
    assert target.dependencies == []



# Generated at 2022-06-23 23:36:52.327499
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('/tmp/input')
    output = Path('/tmp/output')
    pair = InputOutput(input_, output)
    assert pair.input == input_
    assert pair.output == output


# Generated at 2022-06-23 23:36:55.017523
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(0, 0, (0, 0), [])
    assert result.files == 0
    assert result.time == 0
    assert result.target == (0, 0)
    assert result.dependencies == []

# Generated at 2022-06-23 23:36:56.536753
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Type checking
    TransformationResult(ast.parse('pass'), True, ['a', 'b'])

# Generated at 2022-06-23 23:37:00.947707
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_tree = ast.parse('')
    tree_changed = True
    dependencies = []
    transformation_result = TransformationResult(ast_tree, tree_changed, dependencies)
    assert isinstance(transformation_result, TransformationResult)
    assert transformation_result.tree == ast_tree
    assert transformation_result.tree_changed == tree_changed
    assert transformation_result.dependencies == dependencies


# Result of transformer execution
TransformerResult = NamedTuple('TransformerResult',
                               [('changed', bool),
                                ('dependencies', List[str])])

# Generated at 2022-06-23 23:37:04.388686
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path1 = Path('foo.py')
    path2 = Path('bar.py')
    assert InputOutput(path1, path2) == InputOutput(path1, path2)


# Generated at 2022-06-23 23:37:09.026044
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=10, time=0.01, target=(3, 6), dependencies=[])
    assert res.files == 10, "files"
    assert res.time == 0.01, "time"
    assert res.target == (3, 6), "target"
    assert isinstance(res.dependencies, list), "dependencies"


# Generated at 2022-06-23 23:37:10.715073
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=0.1, target=(3, 5), dependencies=[])


# Generated at 2022-06-23 23:37:13.539368
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    from pprint import pprint
    res = CompilationResult(files=0,
                            time=3.14,
                            target=(3, 5),
                            dependencies=[])
    pprint(res)


# Generated at 2022-06-23 23:37:16.018126
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_file = Path('input_file')
    output_file = Path('output_file')
    input_output = InputOutput(input_file, output_file)
    assert input_output.input == input_file
    assert input_output.output == output_file

# Generated at 2022-06-23 23:37:20.827994
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=2, time=1.1, target=(3, 6),
                           dependencies=['a', 'b'])
    assert cr.files == 2
    assert cr.time == 1.1
    assert cr.target == (3, 6)
    assert cr.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:37:23.021971
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=ast.parse(""), tree_changed=True, dependencies=[]).tree_changed

# Generated at 2022-06-23 23:37:25.009706
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.parse('1+2'),
                              False,
                              ['int'])
    assert tr.tree is not None
    assert not tr.tree_changed
    assert tr.dependencies == ['int']

# Generated at 2022-06-23 23:37:26.324922
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input=Path("foo"), output=Path("bar"))


# Generated at 2022-06-23 23:37:29.028542
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    in_out = InputOutput(input, output)

    assert in_out.input == input
    assert in_out.output == output


# Generated at 2022-06-23 23:37:31.741769
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    expected = CompilationResult(files=1, time=2.2, target=(3, 4), dependencies=['dep'])
    actual = CompilationResult(files=1, time=2.2, target=(3, 4), dependencies=['dep'])
    assert expected == actual

# Generated at 2022-06-23 23:37:40.311617
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert all(CompilationResult(0, 0, (3, 6), []) ==
               CompilationResult(0, 0, (3, 6), []))
    assert any(CompilationResult(0, 0, (3, 6), []) !=
               CompilationResult(0, 1, (3, 6), []))
    assert all(CompilationResult(0, 0, (3, 6), []) ==
               CompilationResult(0, 0, (3, 6), []))
    assert any(CompilationResult(0, 0, (3, 6), []) !=
               CompilationResult(0, 0, (3, 7), []))


# Generated at 2022-06-23 23:37:43.535793
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('/tmp/1.py'), Path('/tmp/2.py')) == InputOutput(input=Path('/tmp/1.py'), output=Path('/tmp/2.py'))


# Generated at 2022-06-23 23:37:45.029917
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('input.py'), Path('output.py'))


# Generated at 2022-06-23 23:37:46.816887
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # pylint: disable=no-value-for-parameter
    InputOutput('in', 'out')



# Generated at 2022-06-23 23:37:49.118649
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult._fields == ('files', 'time', 'target', 'dependencies')
    assert CompilationResult.__new__.__defaults__ == (0, 0.0, (3, 6), [])

# Generated at 2022-06-23 23:37:50.132097
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('test'), Path('output'))



# Generated at 2022-06-23 23:37:55.092139
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # GIVEN
    tree = ast.parse('x = 1 + 1')

    # WHEN
    tr = TransformationResult(tree=tree,
                              tree_changed=True,
                              dependencies=['a'])

    # THEN
    assert tr.tree == tree
    assert tr.tree_changed
    assert tr.dependencies == ['a']



# Generated at 2022-06-23 23:37:59.931749
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # type: () -> None
    cr = CompilationResult(files=1, time=0.1, target=(3, 5),
                           dependencies=[])
    assert cr.files == 1
    assert cr.time == 0.1
    assert cr.target == (3, 5)
    assert cr.dependencies == []



# Generated at 2022-06-23 23:38:04.252480
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    x = CompilationResult(10, 1., (3, 6), ['a', 'b'])
    assert x.files == 10
    assert x.time == 1.
    assert x.target == (3, 6)
    assert x.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:38:05.098151
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a'), Path('b')) == InputOutput('a', 'b')



# Generated at 2022-06-23 23:38:09.219210
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    import random
    import time
    random.seed(0)
    for i in range(1, 100):
        files = random.randint(1, 100)
        time_ = random.randint(1, 100)
        target = (3, 6)
        dependencies = [x for x in range(1, random.randint(1, 100))]
        _ = CompilationResult(files, time_, target, dependencies)



# Generated at 2022-06-23 23:38:09.828535
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(Path('a'), Path('b'))

# Generated at 2022-06-23 23:38:10.497124
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.Module(), True, ['foo'])

# Generated at 2022-06-23 23:38:13.016729
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('1\n')
    tree_changed = True
    dependencies = ['a', 'b']

    result = TransformationResult(tree, tree_changed, dependencies)

    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-23 23:38:18.048989
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    actual = CompilationResult(
        files=1,
        time=1.5,
        target=(3, 4),
        dependencies=["foo.py"]
    )
    expected = CompilationResult(
        files=1,
        time=1.5,
        target=(3, 4),
        dependencies=["foo.py"]
    )
    assert actual == expected



# Generated at 2022-06-23 23:38:23.294326
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    args = (50, 20.0, (3, 8), ['foo', 'bar'])
    compilation_result = CompilationResult(*args)
    assert (compilation_result.files == args[0]
            and compilation_result.time == args[1]
            and compilation_result.target == args[2]
            and compilation_result.dependencies == args[3])



# Generated at 2022-06-23 23:38:30.803601
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(1, 2, (3, 4), ['file'])
    assert res.files == 1
    assert res.time == 2
    assert res.target == (3, 4)
    assert res.dependencies == ['file']
    assert res[0] == 1
    assert res[1] == 2
    assert res[2] == (3, 4)
    assert res[3] == ['file']
    assert repr(res) == ("CompilationResult(files=1, time=2, target=(3, 4), "
                         "dependencies=['file'])")


# Generated at 2022-06-23 23:38:31.362544
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    pass

# Generated at 2022-06-23 23:38:33.988004
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # type: () -> None
    i = InputOutput(Path('input'), Path('output'))
    assert i[0] == Path('input')
    assert i[1] == Path('output')
    assert type(i) == InputOutput

# Generated at 2022-06-23 23:38:36.875022
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # type: () -> None
    input_output = InputOutput(Path('/tmp/input'), Path('/tmp/output'))
    assert input_output.input == Path('/tmp/input')
    assert input_output.output == Path('/tmp/output')

# Generated at 2022-06-23 23:38:42.391404
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from mypy.nodes import NameExpr
    from mypy.types import TypeVarType
    from mypy.nodes import IntExpr
    from mypy.types import AnyType, TypeOfAny
    from mypy.nodes import FuncDef
    from mypy.nodes import Var
    from mypy.nodes import ARG_POS, ARG_NAMED
    from mypy.types import FunctionLike
    from mypy.types import NoneTyp
    from mypy.nodes import CallExpr
    from mypy.nodes import MemberExpr
    from mypy.nodes import ReturnStmt


# Generated at 2022-06-23 23:38:46.934409
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('x = 1')
    tree_changed = True
    dependencies = ['a', 'b']

    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree == tree
    assert result.tree_changed == tree_changed
    assert result.dependencies == dependencies

# Generated at 2022-06-23 23:38:48.340705
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(1, 2, 3) == (1, 2, 3)

# Generated at 2022-06-23 23:38:52.872569
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=5,
                               time=1.2,
                               target=(3, 7),
                               dependencies=[])
    assert result.files == 5
    assert result.time == 1.2
    assert result.target[0] == 3
    assert result.target[1] == 7
    assert result.dependencies == []


# Generated at 2022-06-23 23:38:54.289685
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(0, 0.0, (3, 5), [])



# Generated at 2022-06-23 23:38:55.028670
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2.0, (3, 4), ['a', 'b'])

# Generated at 2022-06-23 23:38:57.837809
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(1, 2.0, (3, 4), [])
    assert cr.files == 1
    assert cr.time == 2.0
    assert cr.target == (3, 4)
    assert isinstance(cr.dependencies, list)


# Generated at 2022-06-23 23:38:59.135176
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 1.1, (3, 5), ["foo"])


# Generated at 2022-06-23 23:39:05.369442
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    example_tree = ast.parse('')
    example_tree_changed = True
    example_dependencies = []

    res = TransformationResult(example_tree,
                               example_tree_changed,
                               example_dependencies)
    assert res.tree == example_tree
    assert res.tree_changed == example_tree_changed
    assert res.dependencies == example_dependencies


# Result of a single step of compilation
StepResult = NamedTuple('StepResult',
                        [('step_name', str),
                         ('input_output', InputOutput),
                         ('success', bool),
                         ('result_bytes', bytes)])

# Result of compilation for input file

# Generated at 2022-06-23 23:39:07.430722
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=0, time=0.0, target=(0, 0), dependencies=[])


# Generated at 2022-06-23 23:39:14.525844
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    dummy_tree = ast.AST()
    tree_changed = True
    dependencies = ['foo', 'bar']
    transformation = TransformationResult(tree=dummy_tree,
                                          tree_changed=tree_changed,
                                          dependencies=dependencies)
    assert transformation.tree is dummy_tree
    assert transformation.tree_changed is tree_changed
    assert transformation.dependencies == dependencies
    assert isinstance(transformation, TransformationResult)
    assert isinstance(transformation, ast.AST)

# Generated at 2022-06-23 23:39:18.363757
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(10, 10.0, (3, 7), [])
    assert result.files == 10
    assert result.time == 10.0
    assert result.target == (3, 7)
    assert result.dependencies == []


# Generated at 2022-06-23 23:39:21.058306
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('foo')
    o = Path('bar')
    io = InputOutput(i, o)
    assert io.input == i
    assert io.output == o


# Generated at 2022-06-23 23:39:23.687128
# Unit test for constructor of class InputOutput
def test_InputOutput():
    try:
        InputOutput('','')
    except:
        try:
            InputOutput(Path(''), Path(''))
        except:
            assert False



# Generated at 2022-06-23 23:39:26.559891
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(input='input', output='output')
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')

# Generated at 2022-06-23 23:39:30.977352
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(1, 1.23, (3, 5), [])
    assert res.files == 1
    assert res.time == 1.23
    assert res.target == (3, 5)
    assert res.dependencies == []


# Generated at 2022-06-23 23:39:35.651941
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation = CompilationResult(files=1,
                                    time=0.5,
                                    target=(3, 7),
                                    dependencies=['foo.py'])
    assert compilation.files == 1
    assert compilation.time == 0.5
    assert compilation.target == (3, 7)
    assert compilation.dependencies == ['foo.py']

# Generated at 2022-06-23 23:39:38.314752
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # type: () -> None
    value = InputOutput('input', 'output')
    assert value == InputOutput(Path('input'), Path('output'))

# Generated at 2022-06-23 23:39:42.147603
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # noqa
    simple_tree = ast.parse('')
    inp = 'input'
    res = TransformationResult(simple_tree, False, [inp])
    assert res.tree == simple_tree
    assert res.tree_changed is False
    assert res.dependencies == [inp]

# Generated at 2022-06-23 23:39:46.290342
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    input_tuple = (ast.parse('a = 5'), True, [])
    transform_result = TransformationResult(*input_tuple)
    assert transform_result.tree == input_tuple[0]
    assert transform_result.tree_changed == input_tuple[1]
    assert transform_result.dependencies == input_tuple[2]

# Generated at 2022-06-23 23:39:52.102727
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # GIVEN constructor values
    tree = ast.parse("")
    tree_changed = True
    dependencies = list(["dep1", "dep2"])

    # WHEN construct TransformationResult
    res = TransformationResult(tree, tree_changed, dependencies)

    # THEN compare values
    assert res.tree == tree
    assert res.tree_changed == tree_changed
    assert res.dependencies == dependencies



# Generated at 2022-06-23 23:40:00.599938
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr1 = TransformationResult(ast.AST(), False, ['a', 'b'])
    assert len(tr1.dependencies) == 2
    assert tr1.tree_changed == False
    assert isinstance(tr1.tree, ast.AST)
    tr2 = TransformationResult(ast.AST(), True, ['c', 'd'])
    assert len(tr2.dependencies) == 2
    assert tr2.tree_changed == True
    assert isinstance(tr2.tree, ast.AST)

# Resolved module path
ModulePath = NamedTuple('ModulePath', [('relpath', Path),
                                       ('absdir', Path)])

# Generated at 2022-06-23 23:40:03.269752
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.parse(""), False, [])
    assert isinstance(tr.tree, ast.AST)
    assert tr.tree_changed == False
    assert isinstance(tr.dependencies, list)

# Generated at 2022-06-23 23:40:07.703769
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = 'C:\\Users\\path\\to\\input.py'
    output_path = 'C:\\Users\\path\\to\\output.py'
    io = InputOutput(input_path, output_path)
    assert io.input == input_path
    assert io.output == output_path


# Generated at 2022-06-23 23:40:14.146600
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=123,
                                           time=42.0,
                                           target=(3, 8),
                                           dependencies=["a", "b", "c"])
    assert compilation_result.files == 123
    assert compilation_result.time == 42.0
    assert compilation_result.target == (3, 8)
    assert compilation_result.dependencies == ["a", "b", "c"]


# Generated at 2022-06-23 23:40:18.072284
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(1, 0.2, (3, 4), ["a", "b.c"])
    assert cr.files == 1
    assert cr.time == 0.2
    assert cr.target == (3, 4)
    assert cr.dependencies == ["a", "b.c"]


# Generated at 2022-06-23 23:40:24.224545
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert(CompilationResult(1, 1.0, (3, 6), ['a']).files == 1)
    assert(CompilationResult(1, 1.0, (3, 6), ['a']).time == 1.0)
    assert(CompilationResult(1, 1.0, (3, 6), ['a']).target == (3, 6))
    assert(CompilationResult(1, 1.0, (3, 6), ['a']).dependencies == ['a'])


# Generated at 2022-06-23 23:40:33.891584
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Empty CompilationResult
    assert CompilationResult(0, 0.0, (3, 7), []) == CompilationResult(files=0,
                                                                      time=0.0,
                                                                      target=(3, 7),
                                                                      dependencies=[])

    # One file
    assert CompilationResult(1, 0.0, (3, 7), []) == CompilationResult(files=1,
                                                                      time=0.0,
                                                                      target=(3, 7),
                                                                      dependencies=[])

    # Many files
    assert CompilationResult(2, 0.0, (3, 7), []) == CompilationResult(files=2,
                                                                      time=0.0,
                                                                      target=(3, 7),
                                                                      dependencies=[])

    # Time != 0

# Generated at 2022-06-23 23:40:37.000146
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # type: () -> None
    input = Path('a')
    output = Path('b')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output



# Generated at 2022-06-23 23:40:40.792165
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('/tmp/file.txt')
    out = Path('/tmp/file.pyc')
    io = InputOutput(inp, out)
    assert io.input == inp
    assert io.output == out
    inp = Path('/tmp/file.txt')
    out = Path('/tmp/file.pyc')
    io = InputOutput(inp, out)
    assert io.input == inp
    assert io.output == out


# Generated at 2022-06-23 23:40:43.056242
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = 'src'
    output = 'dest'
    io = InputOutput(input, output)
    assert io.input == Path(input)
    assert io.output == Path(output)

# Generated at 2022-06-23 23:40:46.485459
# Unit test for constructor of class InputOutput
def test_InputOutput():
    cwd = Path.cwd()
    io = InputOutput(cwd, cwd)
    assert io.input == cwd
    assert io.output == cwd


# Generated at 2022-06-23 23:40:50.923685
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(1, 1.1, (1, 1), ['a', 'b'])
    assert res.files == 1
    assert res.time == 1.1
    assert res.target == (1, 1)
    assert res.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:40:53.316399
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(None, None, [])
    assert tr.tree is None and tr.dependencies == [] and tr.tree_changed is None

# Generated at 2022-06-23 23:40:58.012854
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('')
    tree_changed = True
    dependencies = ['The', 'Line', 'Before']
    result = TransformationResult(tree, tree_changed, dependencies)
    assert result.tree is tree
    assert result.tree_changed is True
    assert result.dependencies == ['The', 'Line', 'Before']



# Generated at 2022-06-23 23:41:02.216940
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Test default values
    res = CompilationResult()
    assert res.files == 0
    assert res.time == 0.
    assert res.target == (0, 0)
    assert res.dependencies == []

    res = CompilationResult(1, 1.0, (3, 4), ['a', 'b'])
    assert res.files == 1
    assert res.time == 1.0
    assert res.target == (3, 4)
    assert res.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:41:04.701411
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2.0, (3, 4), ['abc', 'def'])


# Generated at 2022-06-23 23:41:07.743040
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(
        files=10,
        time=1.234,
        target=(3, 7),
        dependencies=['foo.py', 'bar.py']
    )


# Generated at 2022-06-23 23:41:09.668368
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput((Path('a'), Path('b'))) == InputOutput((Path('a'), Path('b')))



# Generated at 2022-06-23 23:41:12.597613
# Unit test for constructor of class InputOutput
def test_InputOutput():  # type: () -> None
    input_ = Path('aaa/bbb')
    output = Path('ccc')
    io = InputOutput(input_, output)
    assert io.input == input_
    assert io.output == output


# Generated at 2022-06-23 23:41:20.639453
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    x = CompilationResult(42, 3.14, (3, 5), ["a", "b"])
    x = CompilationResult(42, 3.14, (3, 5), [])
    x = CompilationResult(42, 3.14, (3, 5), ["a"])
    y = CompilationResult(42, 3.14, (3, 5), ["a", "b"])
    z = CompilationResult(42, 3.14, (3, 5), ["b", "a"])

    # Test equality
    assert x == y
    assert x is not y
    assert x != z
    assert x == x

    # Test printing
    import pprint
    pp = pprint.PrettyPrinter(indent=1)
    pp.pprint(x)
    pp.pprint(y)

# Generated at 2022-06-23 23:41:21.949343
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(input=Path('a'), output=Path('b'))

# Generated at 2022-06-23 23:41:23.329306
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(0, 0.0, (0, 0), [])


# Generated at 2022-06-23 23:41:28.518298
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("x = 1")
    res = TransformationResult(tree, True, ['a', 'b', 'c'])
    assert(res.tree == tree)
    assert(res.tree_changed)
    assert(res.dependencies == ['a', 'b', 'c'])

    res = TransformationResult(tree, False, ['a', 'b', 'c'])
    assert(res.tree == tree)
    assert(not res.tree_changed)
    assert(res.dependencies == ['a', 'b', 'c'])

# Generated at 2022-06-23 23:41:31.588112
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input=Path('foo'), output=Path('bar')).input == Path('foo')
    assert InputOutput(input=Path('foo'), output=Path('bar')).output == Path('bar')

# Generated at 2022-06-23 23:41:37.893520
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path("foo/bar")
    output_path = Path("bar/foo")
    input_output = InputOutput(input_path, output_path)
    assert input_output.input == input_path
    assert input_output.output == output_path
    # Test equality
    assert InputOutput(input_path, output_path) == input_output
    assert InputOutput(output_path, input_path) != input_output


# Generated at 2022-06-23 23:41:43.308381
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    test_result = CompilationResult(5, 2.5, (3, 5), [])
    assert test_result.files == 5
    assert test_result.time == 2.5
    assert test_result.target == (3, 5)
    assert test_result.dependencies == []


# Generated at 2022-06-23 23:41:46.924901
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    tree = ast.parse("")
    tree_changed = True
    dependencies = ["/path/to/file"]
    _ = TransformationResult(tree, tree_changed, dependencies)


# Generated at 2022-06-23 23:41:51.403841
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=ast.parse('print("test")'),
                                tree_changed=True,
                                dependencies=['test'])

# Dict with tree and dependencies
TreeDict = Dict[str, Union[ast.AST, List[str]]]

# Generated at 2022-06-23 23:41:53.035745
# Unit test for constructor of class CompilationResult
def test_CompilationResult(): CompilationResult(files=0, time=0.0, target=(1, 0), dependencies=[])


# Generated at 2022-06-23 23:41:56.985086
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('')
    r = TransformationResult(t, True, [])
    assert r == (t, True, [])


# Result of running a transformer
TransformerOutput = NamedTuple('TransformerOutput',
                               [('tree', ast.AST),
                                ('tree_changed', bool)])
