

# Generated at 2022-06-23 23:32:05.376096
# Unit test for constructor of class InputOutput
def test_InputOutput():
    source = 'source'
    destination = 'destination'
    input_output = InputOutput(source, destination)
    assert input_output.input == source
    assert input_output.output == destination


# Generated at 2022-06-23 23:32:08.483763
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    test_result = CompilationResult(1, 2.3, (3, 4), ['x', 'y'])
    assert test_result.files == 1
    assert test_result.time == 2.3
    assert test_result.target == (3, 4)
    assert test_result.dependencies == ['x', 'y']

# Generated at 2022-06-23 23:32:10.515912
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=None,
                              tree_changed=False,
                              dependencies=['a', 'b'])
    assert tr.tree is None
    assert tr.tree_changed == False
    assert tr.dependencies == ['a', 'b']

# Generated at 2022-06-23 23:32:13.949142
# Unit test for constructor of class InputOutput
def test_InputOutput():
    from pathlib import Path

    t = InputOutput(input=Path('input.py'), output=Path('output.c'))
    assert t.input == Path('input.py')
    assert t.output == Path('output.c')

# Generated at 2022-06-23 23:32:15.607327
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(3, 5), dependencies=[])


# Generated at 2022-06-23 23:32:19.263068
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(0, 0.0, (3, 5), [])
    assert result.files == 0
    assert result.time == 0.0
    assert result.target == (3, 5)
    assert result.dependencies == []



# Generated at 2022-06-23 23:32:20.854171
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path = Path('/home')
    input = InputOutput(input=path, output=path)
    assert input.input == path
    assert input.output == path


# Generated at 2022-06-23 23:32:23.332955
# Unit test for constructor of class InputOutput
def test_InputOutput():
    foo = Path(__file__)
    bar = Path('bar')
    inputoutput = InputOutput(foo, bar)
    assert inputoutput.input == foo
    assert inputoutput.output == bar



# Generated at 2022-06-23 23:32:33.678306
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput('input', 'output')
    InputOutput(Path('input'), Path('output'))
    InputOutput(input='input', output='output')
    InputOutput(input=Path('input'), output=Path('output'))
    InputOutput(output='output', input='input')
    InputOutput(output=Path('output'), input=Path('input'))
    with pytest.raises(AttributeError):
        InputOutput('input')
    with pytest.raises(AttributeError):
        InputOutput(input='input')
    with pytest.raises(AttributeError):
        InputOutput('output')
    with pytest.raises(AttributeError):
        InputOutput(output='output')
    with pytest.raises(AttributeError):
        InputOutput(1, 2, 3)

# Generated at 2022-06-23 23:32:37.233834
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(100, 0.1, (3, 5), [])
    assert result.files == 100
    assert result.time == 0.1
    assert result.target == (3, 5)
    assert result.dependencies == []


# Generated at 2022-06-23 23:32:40.585450
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 2.0, (3, 4), ['a', 'b']) == CompilationResult(1, 2.0, (3, 4), ['a', 'b'])


# Generated at 2022-06-23 23:32:49.491691
# Unit test for constructor of class InputOutput
def test_InputOutput():
    try:
        _ = InputOutput(1, 2)
    except TypeError:
        pass
    else:
        assert False
    try:
        _ = InputOutput('1', 2)
    except TypeError:
        pass
    else:
        assert False
    try:
        _ = InputOutput(1, '2')
    except TypeError:
        pass
    else:
        assert False
    try:
        _ = InputOutput('1', '2')
    except TypeError:
        pass
    else:
        assert False
    result = InputOutput(Path('foo.py'), Path('bar.py'))
    assert result.input == Path('foo.py')
    assert result.output == Path('bar.py')

# Generated at 2022-06-23 23:32:54.130767
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=2,
                                           time=1.1,
                                           target=(3, 6),
                                           dependencies=['a.py', 'b.py'])
    # Check fields
    assert compilation_result.files == 2
    assert compilation_result.time == 1.1
    assert compilation_result.target == (3, 6)
    assert compilation_result.dependencies == ['a.py', 'b.py']



# Generated at 2022-06-23 23:32:57.426382
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.Module(body=[])
    a = TransformationResult(tree=t,
                             tree_changed=True,
                             dependencies=['first', 'second'])
    assert a.tree == t
    assert a.tree_changed is True
    assert a.dependencies == ['first', 'second']


# Generated at 2022-06-23 23:32:58.106388
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.parse(""), True, [])

# Generated at 2022-06-23 23:33:00.080467
# Unit test for constructor of class InputOutput
def test_InputOutput():
    '''
    Test that InputOutput can be constructed
    '''
    _ = InputOutput(Path('in.py'), Path('out.py'))



# Generated at 2022-06-23 23:33:07.951629
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a'), Path('b')) == InputOutput(Path('a'), Path('b'))
    assert InputOutput(Path('a'), Path('b')) != InputOutput(Path('a'), Path('c'))
    assert InputOutput(Path('a'), Path('b')) != InputOutput(Path('c'), Path('b'))

    assert InputOutput(Path('a'), Path('b')) != object()
    assert InputOutput(Path('a'), Path('b')) != None

    assert str(InputOutput(Path('a'), Path('b'))) == 'a -> b'
    assert repr(InputOutput(Path('a'), Path('b'))) == 'InputOutput(input=PosixPath(\'a\'), output=PosixPath(\'b\'))'

# Generated at 2022-06-23 23:33:14.883918
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    name = 'test'
    files = 10
    time = 1.0
    version = (3, 7)
    dependencies = []
    compilation_result = CompilationResult(name=name, files=files,
                                           time=time, target=version,
                                           dependencies=dependencies)
    assert isinstance(compilation_result, CompilationResult)
    assert compilation_result.files == files
    assert compilation_result.time == time
    assert compilation_result.target == version
    assert compilation_result.dependencies == dependencies



# Generated at 2022-06-23 23:33:18.966626
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_node = ast.Module()
    result = TransformationResult(ast_node, True, [])
    assert result.tree is ast_node
    assert result.tree_changed
    assert result.dependencies == []
    assert str(result) == "TransformationResult(tree=<_ast.Module object at 0x%x>, tree_changed=True, dependencies=[])" % id(ast_node)

# Generated at 2022-06-23 23:33:20.652896
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=10, time=20.0, target=(3, 6), dependencies=['a', 'b'])

# Generated at 2022-06-23 23:33:25.886017
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=2.0, target=(3, 4), dependencies=['a', 'b'])
    assert cr.files == 1
    assert cr.time == 2.0
    assert cr.target == (3, 4)
    assert cr.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:33:29.304833
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    target = (3, 8)
    dependencies = ['a', 'b', 'c']
    res = CompilationResult(2, 19.3, target, dependencies)
    assert res.files == 2
    assert res.time == 19.3
    assert res.target == target
    assert res.dependencies == dependencies


# Generated at 2022-06-23 23:33:33.642043
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_tree = ast.Module(body=[])
    result = TransformationResult(tree=ast_tree,
                                  tree_changed=True,
                                  dependencies=['a', 'b'])
    assert isinstance(result, TransformationResult)
    assert result.tree is ast_tree
    assert result.tree_changed is True
    assert result.dependencies == ['a', 'b']

# Generated at 2022-06-23 23:33:37.716251
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    dependencies = ['foo', 'bar', 'baz']
    t = TransformationResult(tree, False, dependencies)
    assert t.tree == tree
    assert not t.tree_changed
    assert t.dependencies == dependencies


# Generated at 2022-06-23 23:33:39.822931
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    _ = CompilationResult(files=0, time=0.0, target=(3, 7),
                          dependencies=[])


# Generated at 2022-06-23 23:33:41.346756
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(None, False, [])
    assert result.tree is None
    assert not result.tree_changed
    assert result.dependencies == []

# Generated at 2022-06-23 23:33:44.177775
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test = TransformationResult(tree=ast.parse('pass'),
                                tree_changed=False,
                                dependencies=['foo.py'])
    assert test.tree
    assert not test.tree_changed
    assert test.dependencies == ['foo.py']

# Generated at 2022-06-23 23:33:46.388715
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Here we just test an __init__ method
    # pylint: disable=W0212
    assert TransformationResult(None, False, []).__init__ ==\
        TransformationResult.__init__

# Generated at 2022-06-23 23:33:52.105283
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=12,
                                           time=124.2,
                                           target=(3, 5),
                                           dependencies=['/path/to/abc.py'])

    assert compilation_result.files == 12
    assert compilation_result.time == 124.2
    assert compilation_result.target == (3, 5)
    assert compilation_result.dependencies == ['/path/to/abc.py']



# Generated at 2022-06-23 23:33:57.092311
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree_result_ok = TransformationResult(ast.parse('1'),
                                          False,
                                          ['a', 'b', 'c'])

    assert tree_result_ok.tree
    assert not tree_result_ok.tree_changed
    assert tree_result_ok.dependencies == ['a', 'b', 'c']

    tree_result_fail = TransformationResult(ast.parse('1'),
                                            True,
                                            ['a', 'b', 'c'])

    assert tree_result_fail.tree
    assert tree_result_fail.tree_changed
    assert tree_result_fail.dependencies == ['a', 'b', 'c']


# Command line arguments

# Generated at 2022-06-23 23:33:58.780745
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(12, 15.45, (3, 5), [])



# Generated at 2022-06-23 23:34:00.186952
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(None, None, None)


# Generated at 2022-06-23 23:34:04.807627
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("1")
    tree_changed = True
    dependencies = ["a", "b"]
    t_result = TransformationResult(tree, tree_changed, dependencies)
    assert isinstance(t_result, TransformationResult)


# Result of analysis transformer
AnalysisResult = NamedTuple('AnalysisResult',
                            [('analyze_ast', ast.AST),
                             ('analyze_files', int),
                             ('analyze_time', float)])


# Generated at 2022-06-23 23:34:09.842067
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(
        files=1,
        time=0.5,
        target=(3, 7),
        dependencies=['a', 'b', 'c'])

    assert result.files == 1
    assert result.time == 0.5
    assert result.target == (3, 7)
    assert result.dependencies == ['a', 'b', 'c']
    assert isinstance(result, CompilationResult)



# Generated at 2022-06-23 23:34:13.540998
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=20,
                               time=10,
                               target=(3, 7),
                               dependencies=[
                                   "__future__",
                                   "typing"
                               ])
    assert result.files == 20
    assert result.time == 10
    assert result.target == (3, 7)
    assert result.dependencies == ["__future__", "typing"]


# Generated at 2022-06-23 23:34:16.034773
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    """
    Test method for constructor of class TransformationResult.
    """
    tree = ast.parse("a = 1")
    tr = TransformationResult(tree = tree,
                              tree_changed = False,
                              dependencies = [])

    assert tr.tree == tree
    assert not tr.tree_changed
    assert tr.dependencies == []



# Generated at 2022-06-23 23:34:16.408191
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    pass

# Generated at 2022-06-23 23:34:21.041802
# Unit test for constructor of class InputOutput
def test_InputOutput():
    files = (Path('x.py'), Path('x.pj'))
    a = InputOutput(*files)
    assert a.input == files[0]
    assert a.output == files[1]
    assert a.input != a.output
    assert a == InputOutput(*files)
    assert hash(a) == hash(InputOutput(*files))



# Generated at 2022-06-23 23:34:24.783684
# Unit test for constructor of class InputOutput
def test_InputOutput():
    I = Path('input')
    O = Path('output')
    io = InputOutput(I, O)
    assert io.input == I
    assert io.output == O


# Generated at 2022-06-23 23:34:27.834152
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=10, time=20.0, target=(3, 6), dependencies=['a.txt'])
    assert c.files == 10


# Generated at 2022-06-23 23:34:31.804080
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=1, time=1, target=(2, 3), dependencies=['hello'])

    assert res.files == 1
    assert res.time == 1
    assert res.target == (2, 3)
    assert res.dependencies == ['hello']

# Generated at 2022-06-23 23:34:36.854672
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(
        files=0, time=0.0, target=(3, 6), dependencies=[])
    assert result.files == 0
    assert result.time == 0.0
    assert result.target == (3, 6)
    assert result.dependencies == []


# Generated at 2022-06-23 23:34:38.813776
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    x = TransformationResult(None, None, None)
    assert x.__class__ == TransformationResult

# Generated at 2022-06-23 23:34:42.216721
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    code = 'a = 1\n'
    tree = ast.parse(code)
    res = TransformationResult(tree, True, [])
    assert res.tree == tree
    assert res.tree_changed
    assert res.dependencies == []

# Generated at 2022-06-23 23:34:47.373552
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=4,
                               time=0.001,
                               target=(0, 1),
                               dependencies=['a', 'b'])
    assert result.files == 4
    assert result.time == 0.001
    assert result.target == (0, 1)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:34:51.097680
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(1, 2, (3, 4), ['a', 'b'])
    assert result.files == 1
    assert result.time == 2
    assert result.target == (3, 4)
    assert result.dependencies == ['a', 'b']



# Generated at 2022-06-23 23:34:53.727636
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=[])
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 6)
    assert result.dependencies == []

# Generated at 2022-06-23 23:34:56.676298
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path('/a.py'), Path('/b.py'))
    assert io.input == Path('/a.py')
    assert io.output == Path('/b.py')

# Generated at 2022-06-23 23:34:59.231636
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/home/dandruk/test.py')
    output = Path('/home/dandruk/test.pyc')
    io = InputOutput(input=input, output=output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-23 23:35:04.501368
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    dep = [str(Path(__file__)), str(Path('__init__.py'))]
    cr = CompilationResult(files=1, time=0.3, target=(3, 6), dependencies=dep)
    assert cr.files == 1
    assert cr.time == 0.3
    assert cr.target == (3, 6)
    assert cr.dependencies == dep


# Generated at 2022-06-23 23:35:09.100469
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from ast import parse
    from typing import List
    assert TransformationResult(parse('x+1'), True, ['stdlib']).dependencies == ['stdlib']
    assert TransformationResult(parse('x+1'), False, ['stdlib']).dependencies == ['stdlib']
    assert TransformationResult(parse('x+1'), True, List(['stdlib'])).dependencies == ['stdlib']

# Generated at 2022-06-23 23:35:11.995155
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('some', 'filename')
    o = Path('other', 'filename')
    input_output = InputOutput(input=i, output=o)
    assert input_output.input == i
    assert input_output.output == o


# Generated at 2022-06-23 23:35:19.328956
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(None, None, None)
    assert(isinstance(tr.tree, ast.AST))
    assert(isinstance(tr.tree_changed, bool))


# Information about handling with the current package
PackageStatus = NamedTuple('PackageStatus', [('name', str),
                                             ('fullname', str)])

# Information about handling with the current module
ModuleStatus = NamedTuple('ModuleStatus', [('package', PackageStatus),
                                           ('name', str),
                                           ('fullname', str),
                                           ('path', Path)])

# Generated at 2022-06-23 23:35:24.353423
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1,
                           time=1.0,
                           target=(2, 7),
                           dependencies=['a', 'b'])
    assert cr.files == 1
    assert cr.time == 1.0
    assert cr.target == (2, 7)
    assert cr.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:35:27.373890
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('input'), Path('output'))
    assert input_output.input == Path('input')
    assert input_output.output == Path('output')


# Generated at 2022-06-23 23:35:29.716059
# Unit test for constructor of class InputOutput
def test_InputOutput():
    obj = InputOutput(Path('foo'), Path('bar'))
    eq_(obj.input, Path('foo'))
    eq_(obj.output, Path('bar'))

# Generated at 2022-06-23 23:35:32.195023
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    v = TransformationResult(tree=None,
                             tree_changed=False,
                             dependencies=[])
    assert v.tree is None
    assert v.tree_changed == False
    assert v.dependencies == []

# Generated at 2022-06-23 23:35:33.341944
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(Path('/tmp/1'), Path('/tmp/2'))

# Generated at 2022-06-23 23:35:39.431235
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(
        ast.parse('1 + 1'), True, ['a', 'b', 'c'])
    assert result.tree is not None
    assert isinstance(result.tree, ast.AST)
    assert str(result.tree) == 'Module(body=[Expr(value=BinOp(left=Num(n=1), op=Add(), right=Num(n=1)))])'
    assert result.tree_changed
    assert result.dependencies == ['a', 'b', 'c']

# Generated at 2022-06-23 23:35:44.533641
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path("input"), Path("output"))
    assert input_output.input == Path("input")
    assert input_output.output == Path("output")

    input_output = InputOutput("input", "output")
    assert input_output.input == Path("input")
    assert input_output.output == Path("output")


# Generated at 2022-06-23 23:35:48.836457
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    x = CompilationResult(1, 1.0, (3, 7), ['a'])
    assert x.files == 1
    assert x.time == 1.0
    assert x.target == (3, 7)
    assert x.dependencies == ['a']


# Generated at 2022-06-23 23:35:52.770812
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(0, 0.0, (3, 7), [])
    assert cr.files == 0
    assert cr.time == 0.0
    assert cr.target == (3, 7)
    assert cr.dependencies == []


# Generated at 2022-06-23 23:35:54.475576
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.AST()
    TransformationResult(tree, False, ['a.py'])


# Generated at 2022-06-23 23:35:57.380960
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    import astor
    t_result = TransformationResult(tree=ast.parse("a = 'a'"), tree_changed=True, dependencies=['a'])
    assert astor.to_source(t_result.tree) == "a = 'a'\n"
    assert t_result.tree_changed == True
    assert t_result.dependencies == ['a']


# Generated at 2022-06-23 23:36:00.076394
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = 'input'
    output = 'output'
    input_output = InputOutput(input, output)

    assert input_output.input == input
    assert input_output.output == output
    assert tuple(input_output) == (input, output)


# Generated at 2022-06-23 23:36:03.305934
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('test.txt')
    output = Path('test2.txt')
    value = InputOutput(input, output)
    assert value.input == input
    assert value.output == output

# Generated at 2022-06-23 23:36:09.737743
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    dummy_tree = ast.parse('1')
    dummy_tree_changed = False
    dummy_dependencies = ['test1', 'test2']
    result = TransformationResult(
        dummy_tree,
        dummy_tree_changed,
        dummy_dependencies
    )
    assert result.tree == dummy_tree
    assert result.tree_changed == dummy_tree_changed
    assert result.dependencies == dummy_dependencies
    assert result.dependencies is not dummy_dependencies

# Generated at 2022-06-23 23:36:12.425750
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput('input', 'output')
    assert isinstance(io.input, Path)
    assert isinstance(io.output, Path)


# Generated at 2022-06-23 23:36:15.494710
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # pylint: disable=invalid-name
    input_, output = "/input", "/output"
    pair = InputOutput(input_, output)
    assert pair.input == input_
    assert pair.output == output

# Generated at 2022-06-23 23:36:17.488421
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.AST(), False, ['foo', 'bar'])
    assert isinstance(tr.tree, ast.AST)
    assert not tr.tree_changed
    assert len(tr.dependencies) == 2
    assert tr.dependencies[0] == 'foo'
    assert tr.dependencies[1] == 'bar'


# Generated at 2022-06-23 23:36:19.930600
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(time=10.0,
                             files=100,
                             target=(3, 6),
                             dependencies=['foo', 'bar'])


# Generated at 2022-06-23 23:36:22.195004
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('a')
    output = Path('b')

    x = InputOutput(input_, output)

    assert x.input == input_
    assert x.output == output


# Generated at 2022-06-23 23:36:26.588925
# Unit test for constructor of class InputOutput
def test_InputOutput():
    file1 = Path("/blah/file1.py")
    file2 = Path("/blah/file2.py")
    input_output = InputOutput(file1, file2)
    assert input_output.input == file1
    assert input_output.output == file2

# Generated at 2022-06-23 23:36:29.590247
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(input=Path('/tmp'), output=Path('/tmp/out'))
    io = io._replace(input=Path('/usr/local'))
    assert io.input == Path('/usr/local')



# Generated at 2022-06-23 23:36:35.478216
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # pylint: disable=invalid-name
    a, b, c, d = (1, 2, (3, 4), ['a', 'b'])
    result = CompilationResult(a, b, c, d)
    assert result.files == a
    assert result.time == b
    assert result.target == c
    assert result.dependencies == d


# Generated at 2022-06-23 23:36:38.572550
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_tree = ast.Module()
    transformation = TransformationResult(ast_tree, False, [])
    assert transformation.tree == ast_tree
    assert transformation.tree_changed == False
    assert transformation.dependencies == []

# Generated at 2022-06-23 23:36:42.055970
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from tests.typed_ast_unparse import unparse
    tt = TransformationResult(ast.parse('pass'), True, [])
    assert unparse(tt.tree) == 'pass'
    assert tt.tree_changed
    assert len(tt.dependencies) == 0



# Generated at 2022-06-23 23:36:47.102679
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    r = TransformationResult(tree=ast.parse("pass"), tree_changed=False,
                             dependencies=[])
    assert r.tree is not None
    assert r.tree_changed is False
    assert r.dependencies == []


__all__ = [
    'CompilationTarget', 'CompilationResult', 'InputOutput',
    'TransformationResult']

# Generated at 2022-06-23 23:36:51.742681
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # pylint: disable=invalid-name
    # pylint: disable=unused-variable
    tree = ast.parse('x = 1')
    res = TransformationResult(tree, True, ['path/file.jedi'])
    assert res.tree == tree
    assert res.tree_changed == True
    assert res.dependencies == ['path/file.jedi']

# Generated at 2022-06-23 23:36:53.535725
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input.txt')
    output = Path('output.txt')
    pair = InputOutput(input, output)
    assert pair.input == input
    assert pair.output == output

# Generated at 2022-06-23 23:36:58.268567
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Result for empty file
    result = TransformationResult(ast.parse('pass', mode='exec'),
                                  False,
                                  [])

    # Test
    assert len(result.tree.body) == 1
    assert isinstance(result.tree.body[0], ast.Pass)
    assert result.tree_changed is False
    assert len(result.dependencies) == 0

# Generated at 2022-06-23 23:37:02.848154
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CR = CompilationResult(1, 1.1, (3, 4), [])
    assert CR.files == 1
    assert CR.time == 1.1
    assert CR.target == (3, 4)
    assert CR.dependencies == []


# Generated at 2022-06-23 23:37:06.039200
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_tree = ast.parse("pass")
    tr = TransformationResult(ast_tree, True, [])
    assert tr.tree == ast_tree
    assert tr.tree_changed == True
    assert tr.dependencies == []

# Generated at 2022-06-23 23:37:08.462370
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('A')
    output = Path('B')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output

# Generated at 2022-06-23 23:37:13.761417
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    TestInput = [('files', 1),
                 ('time', 1.5),
                 ('target', (2, 7)),
                 ('dependencies', ['a', 'b'])]
    result = CompilationResult(*TestInput)
    assert result.files == TestInput[0][1]
    assert result.time == TestInput[1][1]
    assert result.target == TestInput[2][1]
    assert result.dependencies == TestInput[3][1]


# Generated at 2022-06-23 23:37:16.419179
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('../path/to/input/file.py')
    output = Path('../path/to/output/file.py')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output

# Generated at 2022-06-23 23:37:18.318293
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('input.py'), Path('output.py'))


# Generated at 2022-06-23 23:37:23.582488
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files = 10
    t = 1.0
    target = (3, 2)
    dependencies = ['a', 'b']
    cr = CompilationResult(files, t, target, dependencies)
    assert cr.files == files
    assert cr.time == t
    assert cr.target == target
    assert cr.dependencies == dependencies


# Generated at 2022-06-23 23:37:27.156392
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(ast.parse('a=1'),
                                  True,
                                  [])
    assert(result.tree == ast.parse('a=1'))
    assert(result.tree_changed)
    assert(len(result.dependencies) == 0)

# Generated at 2022-06-23 23:37:28.408354
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=None, tree_changed=False, dependencies=[])



# Generated at 2022-06-23 23:37:30.957699
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(4, 5.6, (3, 5), [])
    assert cr.files == 4
    assert cr.time == 5.6
    assert cr.target == (3, 5)
    assert cr.dependencies == []

# Generated at 2022-06-23 23:37:32.977548
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path("/some/input")
    o = Path("/some/output")
    io = InputOutput(i, o)
    assert io.input == i
    assert io.output == o

# Generated at 2022-06-23 23:37:35.146534
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    try:
        TransformationResult([1, 2], True, [])
    except:
        assert False, 'NamedTuple described in wrong way'

# Generated at 2022-06-23 23:37:39.507815
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    out = CompilationResult(1, 0.25, (3,7), [])
    assert out.files == 1
    assert out.time == 0.25
    assert out.target == (3,7)
    assert out.dependencies == []



# Generated at 2022-06-23 23:37:41.739453
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('print("Hello world!")')
    TransformationResult(tree, True, [])
    TransformationResult(tree, False, [])

# Generated at 2022-06-23 23:37:43.744846
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = 'input'
    output = 'output'
    input_output = InputOutput(Path(input),
                               Path(output))
    assert input_output.input == Path(input)
    assert input_output.output == Path(output)


# Generated at 2022-06-23 23:37:46.131035
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(tree=None,
                                  tree_changed=True,
                                  dependencies=None)
    assert result.tree is None
    assert result.tree_changed is True
    a

# Generated at 2022-06-23 23:37:47.874964
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    tree = ast.parse("pass")
    # tree_changed is not optional!
    TransformationResult(tree, True, [])

# Generated at 2022-06-23 23:37:50.397040
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(0, 0, (0, 0), [])
    assert cr.files == 0
    assert cr.time == 0
    assert cr.target == (0, 0)
    assert cr.dependencies == []



# Generated at 2022-06-23 23:37:52.747822
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('a = 1', mode='eval')
    tr = TransformationResult(tree=t, tree_changed=True, dependencies=[])
    assert tr

# Generated at 2022-06-23 23:37:57.361840
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_module = ast.parse('a + b')

    # noinspection PyUnusedLocal
    def node_visitor(node, *args, **kwargs):
        pass

    result = TransformationResult(tree=ast_module,
                                  tree_changed=True,
                                  dependencies=['a.py', 'b.py'])
    assert isinstance(result, TransformationResult)

# Generated at 2022-06-23 23:38:01.869134
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i1 = InputOutput('input', 'output')
    i2 = InputOutput(Path('input'), Path('output'))
    i3 = InputOutput(i2)

    assert i1.input == i2.input == i3.input
    assert i1.output == i2.output == i3.output

# Generated at 2022-06-23 23:38:06.032255
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = "foo"
    output = "bar"
    pair = InputOutput(input, output)
    assert pair.input == input
    assert pair.output == output
    assert pair.input != pair.output

    pair2 = InputOutput(input, output)
    assert pair == pair2
    assert pair is not pair2

# Generated at 2022-06-23 23:38:09.003249
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path('a.py'), Path('b.py'))
    assert io.input == Path('a.py')
    assert io.output == Path('b.py')



# Generated at 2022-06-23 23:38:11.484130
# Unit test for constructor of class InputOutput
def test_InputOutput():
    """Test __init__ method of class InputOutput"""

    test_input = Path('/path/to/input.py')
    test_output = Path('/path/to/output.py')

    instance = InputOutput(input=test_input, output=test_output)

    assert instance.input == test_input
    assert instance.output == test_output


# Generated at 2022-06-23 23:38:12.844413
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    TransformationResult(None, None, None)

# Generated at 2022-06-23 23:38:15.838308
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(1, True, ['a', 'b'])
    assert result.tree == 1
    assert result.tree_changed is True
    assert result.dependencies == ['a', 'b']

# Generated at 2022-06-23 23:38:19.322051
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('/usr')
    out = Path('/bin')
    nt = InputOutput(inp, out)
    assert nt.input == inp
    assert nt.output == out


# Generated at 2022-06-23 23:38:28.187039
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.parse('1+1'), True, ['test1', 'test2'])
    assert(tr.tree is not None)
    assert(isinstance(tr.tree, ast.AST))
    assert(tr.tree_changed is True)
    assert(tr.dependencies == ['test1', 'test2'])

# Place where to store the file
OutputLocation = NamedTuple('OutputLocation', [('path', Path)])

# Type of dependency
DependencyType = NamedTuple('DependencyType', [('type', str)])

# Dependency information
Dependency = NamedTuple('Dependency', [('path', Path),
                                       ('type', DependencyType)])

# Generated at 2022-06-23 23:38:32.775570
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=2,
                               time=2.0,
                               target=(3, 6),
                               dependencies=['a', 'b'])
    assert result.files == 2
    assert result.time == 2.0
    assert result.target == (3, 6)
    assert result.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:38:33.627732
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # TODO: test
    pass



# Generated at 2022-06-23 23:38:36.480641
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path("foo.py")
    output = Path("bar.py")
    test_inputOutput = InputOutput.__new__(InputOutput, input, output)
    assert test_inputOutput.input == input
    assert test_inputOutput.output == output


# Generated at 2022-06-23 23:38:38.566714
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result1 = TransformationResult(tree=None, tree_changed=True, dependencies=[])
    result2 = TransformationResult(tree=None, tree_changed=True, dependencies=[])
    assert result1 == result2

# Generated at 2022-06-23 23:38:42.294360
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('input/path')
    output = Path('output/path')
    io = InputOutput(input_, output)
    assert io.input == input_
    assert io.output == output


# Generated at 2022-06-23 23:38:48.441136
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=42, time=3.14, target=(3, 6),
                                           dependencies=['foo.py', 'bar.py'])

    assert compilation_result.files == 42
    assert compilation_result.time == 3.14
    assert compilation_result.target == (3, 6)
    assert compilation_result.dependencies == ['foo.py', 'bar.py']


# Generated at 2022-06-23 23:38:50.534185
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output_pair = InputOutput('input', 'output')
    assert input_output_pair.input == 'input'
    assert input_output_pair.output == 'output'


# Generated at 2022-06-23 23:38:52.461423
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path('foo/bar.py'), Path('/tmp/baz.py'))
    assert isinstance(io, InputOutput)

# Generated at 2022-06-23 23:38:53.171105
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.Name(), False, [])

# Generated at 2022-06-23 23:38:55.207173
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse('pass'),
                                True,
                                []).tree_changed
    assert not TransformationResult(None,
                                    False,
                                    []).tree_changed

# Generated at 2022-06-23 23:38:57.453813
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p1 = Path('a/b/c')
    p2 = Path('a/b/d')

    assert(InputOutput(p1, p2) == InputOutput(p1, p2))



# Generated at 2022-06-23 23:39:01.118603
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=2,
                               time=0.34372,
                               target=(3, 7),
                               dependencies=['mydep1', 'mydep2'])
    assert isinstance(result.files, int)
    assert isinstance(result.time, float)
    assert isinstance(result.target, CompilationTarget)
    assert isinstance(result.dependencies, List[str])

# Generated at 2022-06-23 23:39:04.156163
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=1,
                             time=1.0,
                             target=(2, 7),
                             dependencies=['foo', 'bar'])


# Generated at 2022-06-23 23:39:10.698012
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('/input'),
                       Path('/output')) == InputOutput(Path('/input'),
                       Path('/output'))
    assert InputOutput(Path('/input'),
                       Path('/output')) != InputOutput(Path('/input'),
                       Path('/output2'))
    assert InputOutput(Path('/input2'),
                       Path('/output')) != InputOutput(Path('/input'),
                       Path('/output'))

# Generated at 2022-06-23 23:39:15.835019
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=1, time=2.0, target=(3, 4),
                            dependencies=['a', 'b'])
    assert res.files == 1
    assert res.time == 2.0
    assert res.target == (3, 4)
    assert res.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:39:19.905387
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.1,
                               target=(3, 5), dependencies=['foo'])
    assert result.files == 1
    assert result.time == 0.1
    assert result.target == (3, 5)
    assert result.dependencies == ['foo']


# Generated at 2022-06-23 23:39:23.092514
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(ast.AST(), True, ['a', 'b'])

    assert result.tree
    assert result.tree_changed is True
    assert result.dependencies == ['a', 'b']

# Generated at 2022-06-23 23:39:34.178178
# Unit test for constructor of class TransformationResult
def test_TransformationResult():  # type: () -> None
    trans_result = TransformationResult(ast.parse('a = 3'),
                                        True,
                                        ['a.py'])
    assert trans_result.tree == ast.parse('a = 3')
    assert trans_result.tree_changed
    assert trans_result.dependencies == ['a.py']
    trans_result = TransformationResult(ast.parse('a = 3'),
                                        False,
                                        ['a.py'])
    assert trans_result.tree == ast.parse('a = 3')
    assert not trans_result.tree_changed

# Result of transformer transformation
TransformerResult = NamedTuple('TransformerResult',
                               [('transformation', TransformationResult),
                                ('source', str),
                                ('dependencies', List[str])])


# Generated at 2022-06-23 23:39:36.287330
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # pylint: disable=unused-variable
    result = CompilationResult(1, 0.1, (3, 3), [])


# Generated at 2022-06-23 23:39:42.471151
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.Module(body=[])
    assert TransformationResult(tree=tree, tree_changed=True,
                                dependencies=[]) == \
        TransformationResult(tree, True, [])

# Information about compiler errors
CompilerError = NamedTuple('CompilerError',
                           [('input_file', Path),
                            ('output_file', Path),
                            ('error_message', str),
                            ('source_code', str)])


# Generated at 2022-06-23 23:39:48.391470
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c1 = CompilationResult(
        files=10, time=10.0,
        target=(3, 6), dependencies=[])
    assert c1.files == 10
    assert c1.time == 10.0
    assert c1.target == (3, 6)
    assert c1.dependencies == []
    c2 = CompilationResult(
        files=10, time=10.0,
        target=(3, 6), dependencies=['/src/a'])
    assert c2.dependencies == ['/src/a']
    # Test that changing dependencies of c1 doesn't affect c2
    c1.dependencies = ['/src/b']
    assert c2.dependencies == ['/src/a']
    assert c1.dependencies == ['/src/b']

# Generated at 2022-06-23 23:39:53.705775
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Act
    compilation_result = CompilationResult(2, 3.5, (2, 7), ["foo", "bar"])

    # Assert
    assert compilation_result.files == 2
    assert compilation_result.time == 3.5
    assert compilation_result.target == (2, 7)
    assert compilation_result.dependencies == ["foo", "bar"]


# Generated at 2022-06-23 23:39:59.332531
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=3,
                           time=2.3,
                           target=(3, 6),
                           dependencies=['pandas', 'numpy'])
    assert cr.files == 3
    assert cr.time == 2.3
    assert cr.target == (3, 6)
    assert cr.dependencies == ['pandas', 'numpy']



# Generated at 2022-06-23 23:40:01.978960
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # When
    result = CompilationResult(files=1,
                               time=1.0,
                               target=(3, 7),
                               dependencies=['foo'])

    # Then
    assert result.files == 1
    assert result.time == 1.0
    assert result.target == (3, 7)
    assert result.dependencies == ['foo']


# Generated at 2022-06-23 23:40:12.220934
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.parse('1'),
                                True, ['a', 'b']) == \
           TransformationResult(ast.parse('1'),
                                True, ['a', 'b'])

    assert TransformationResult(ast.parse('1'),
                                True, ['a', 'b']) != \
           TransformationResult(ast.parse('1'),
                                True, ['b', 'a'])

    assert TransformationResult(ast.parse('1'),
                                True, ['a', 'b']) != \
           TransformationResult(ast.parse('1'),
                                False, ['a', 'b'])

    assert TransformationResult(ast.parse('1'),
                                True, ['a', 'b']) != \
           TransformationResult(ast.parse('2'),
                                True, ['a', 'b'])

# Generated at 2022-06-23 23:40:17.125434
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path("/tmp/input")
    o = Path("/tmp/output")
    inout = InputOutput(i, o)
    assert inout.input == i
    assert inout.output == o

    inout = InputOutput(Path("."), Path("."))
    assert inout.input == Path(".")
    assert inout.output == Path(".")

# Generated at 2022-06-23 23:40:19.321286
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # pylint: disable=no-value-for-parameter
    CompilationResult(files=52, time=7.3, target=(3, 6), dependencies=[])


# Generated at 2022-06-23 23:40:22.664624
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=2.5, target=(3, 4), dependencies=['mod1', 'mod2'])
    assert cr.files == 1
    assert cr.time == 2.5
    assert cr.target == (3, 4)
    assert cr.dependencies == ['mod1',  'mod2']


# Generated at 2022-06-23 23:40:27.255070
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    my_result = TransformationResult(
        ast.parse('pass'),
        True,
        ['__init__.py', 'any.py'])

    assert isinstance(my_result.tree, ast.AST)
    assert my_result.tree_changed == True
    assert my_result.dependencies == ['__init__.py', 'any.py']

# Generated at 2022-06-23 23:40:35.644161
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    # Test 1
    tr = TransformationResult(tree=None, tree_changed=False, dependencies=None)
    assert tr.tree is None
    assert tr.tree_changed is False
    assert tr.dependencies is None
    # Test 2
    tr = TransformationResult(tree=ast.AST(), tree_changed=True, dependencies=['a'])
    assert tr.tree is not None
    assert tr.tree_changed is True
    assert tr.dependencies == ['a']
    # Test 3
    tr = TransformationResult(tree=ast.AST(), tree_changed=False, dependencies=['b'])
    assert tr.tree is not None
    assert tr.tree_changed is False
    assert tr.dependencies == ['b']

# Generated at 2022-06-23 23:40:41.234982
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=0,
                            time=0.0,
                            target=(3, 7),
                            dependencies=[])

    assert isinstance(res.files, int)
    assert res.files == 0
    assert isinstance(res.time, float)
    assert res.time == 0.0
    assert isinstance(res.target, tuple)
    assert isinstance(res.target[0], int)
    assert isinstance(res.target[1], int)
    assert isinstance(res.dependencies, list)
    assert res.dependencies == []


# Generated at 2022-06-23 23:40:45.053976
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("print('hello world!')")
    d = TransformationResult(tree, True, ['d1'])
    assert d.dependencies == ['d1']
    assert d.tree is not None

# Generator of semantic version

# Generated at 2022-06-23 23:40:48.395822
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i_o = InputOutput(input=Path('input'),
                      output=Path('output'))
    assert i_o.input.name == 'input'
    assert i_o.output.name == 'output'

# Generated at 2022-06-23 23:40:50.199201
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    class C(ast.AST):
        pass
    assert isinstance(TransformationResult(C(), True, []), TransformationResult)

# Generated at 2022-06-23 23:40:54.129162
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('')
    tree_changed = True
    dependencies = []
    tr = TransformationResult(tree, tree_changed, dependencies)
    assert tr.tree == tree
    assert tr.tree_changed == tree_changed
    assert tr.dependencies == dependencies

# Generated at 2022-06-23 23:40:58.502687
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=1.0,
                           target=(3, 4), dependencies=[])
    assert cr.files == 1
    assert cr.time == 1.0
    assert cr.target == (3, 4)
    assert cr.dependencies == []


# Generated at 2022-06-23 23:41:03.708158
# Unit test for constructor of class InputOutput
def test_InputOutput():
    file_in = Path('app/file.in')
    file_out = Path('app/file.out')

    pair = InputOutput(input=file_in, output=file_out)

    assert pair.input == file_in
    assert pair.output == file_out
    assert pair.input == pair[0]
    assert pair.output == pair[1]

# Generated at 2022-06-23 23:41:07.057456
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('foo')
    output = Path('bar')
    test = InputOutput(input=input, output=output)
    assert test.input is input
    assert test.output is output


# Generated at 2022-06-23 23:41:10.370809
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=None,
                              tree_changed=True,
                              dependencies=['A', 'B', 'C'])
    assert tr.tree is None
    assert tr.tree_changed
    assert tr.dependencies == ['A', 'B', 'C']

# Generated at 2022-06-23 23:41:14.038861
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_tree = ast.AST()

    res = TransformationResult(tree=ast_tree,
                               tree_changed=True,
                               dependencies=['foo'])

    assert res.tree == ast_tree
    assert res.tree_changed is True
    assert res.dependencies == ['foo']

# Generated at 2022-06-23 23:41:18.588954
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(None, True, [])
    assert t.tree is None
    assert t.tree_changed is True
    assert t.dependencies == []

# Result of the analysis
AnalysisResult = NamedTuple('AnalysisResult',
                            [('input', Path),
                             ('output', Path),
                             ('success', bool),
                             ('compilation_results', List[CompilationResult])])


# Generated at 2022-06-23 23:41:21.457562
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a'), Path('b')) == InputOutput(Path('a'), Path('b'))
    assert InputOutput(Path('a'), Path('b')) != InputOutput(Path('a'), Path('c'))



# Generated at 2022-06-23 23:41:25.143958
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # pylint: disable=no-value-for-parameter
    result = CompilationResult(files=1, time=1.1, target=(1, 1), dependencies=['a'])
    assert result.files == 1
    assert result.time == 1.1
    assert result.target == (1, 1)
    assert result.dependencies == ['a']


# Generated at 2022-06-23 23:41:29.687510
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_mock = mock.MagicMock(spec=Path)
    output_mock = mock.MagicMock(spec=Path)
    input_output = InputOutput(input_mock, output_mock)
    assert input_output.input == input_mock
    assert input_output.output == output_mock


# Generated at 2022-06-23 23:41:39.076984
# Unit test for constructor of class TransformationResult
def test_TransformationResult(): # type: () -> None
    test_a = TransformationResult(ast.Num, True, [])
    assert test_a.tree == ast.Num
    assert test_a.tree_changed
    assert test_a.dependencies == []

    test_b = TransformationResult(ast.Num, False, [])
    assert test_b.tree == ast.Num
    assert not test_b.tree_changed
    assert test_b.dependencies == []

    test_c = TransformationResult(ast.Num, False, ['test.py'])
    assert test_c.tree == ast.Num
    assert not test_c.tree_changed
    assert test_c.dependencies == ['test.py']

# Generated at 2022-06-23 23:41:43.975535
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input=Path('example_in'), output=Path('example_out')).input == Path('example_in')
    assert InputOutput(input=Path('example_in'), output=Path('example_out')).output == Path('example_out')


# Generated at 2022-06-23 23:41:47.555697
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = 'test.py'
    output = 'output.py'
    pair = InputOutput(Path(input), Path(output))
    assert pair.input == Path(input)
    assert pair.output == Path(output)

# Generated at 2022-06-23 23:41:54.376947
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    a = CompilationResult(files=1, time=1, target=(3, 4), dependencies=[])
    b = CompilationResult(files=1, time=1, target=(3, 4), dependencies=[])
    assert a == b
    a = CompilationResult(files=1, time=1, target=(3, 4), dependencies=['a'])
    b = CompilationResult(files=1, time=1, target=(3, 4), dependencies=['b'])
    assert not a == b

# Generated at 2022-06-23 23:41:58.236543
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=1, time=2.0, target=(3, 4),
                            dependencies=['a.py', 'b.py'])
    assert res.files == 1
    assert res.time == 2.0
    assert res.target == (3, 4)
    assert res.dependencies == ['a.py', 'b.py']


# Generated at 2022-06-23 23:41:59.557213
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(0, 1.0, (2, 3), [])


# Generated at 2022-06-23 23:42:00.277415
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('foo'), Path('bar'))

# Generated at 2022-06-23 23:42:01.842048
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input='a', output='b') == \
           InputOutput(input=Path('a'), output=Path('b'))

# Generated at 2022-06-23 23:42:04.996795
# Unit test for constructor of class InputOutput
def test_InputOutput():
    '''
    >>> test_InputOutput()
    '''
    input = Path('input')
    output = Path('output')
    pair = InputOutput(input, output)
    assert pair.input == input
    assert pair.output == output

# Function to pretty print compilation target