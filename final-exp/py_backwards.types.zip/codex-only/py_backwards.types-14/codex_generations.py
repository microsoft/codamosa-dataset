

# Generated at 2022-06-23 23:31:56.932818
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('/dev/null'), Path('/dev/null'))


# Generated at 2022-06-23 23:32:01.957114
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(
        3, 0.25, (3, 8), ['a.py', 'b.py', 'c.py'])
    assert compilation_result.files == 3
    assert compilation_result.time == 0.25
    assert compilation_result.target == (3, 8)
    assert compilation_result.dependencies == ['a.py', 'b.py', 'c.py']


# Generated at 2022-06-23 23:32:05.265717
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(2, 10.1, (3, 6), ['foo', 'bar'])
    assert result.files == 2
    assert result.time == 10.1
    assert result.target == (3, 6)
    assert result.dependencies == ['foo', 'bar']


# Generated at 2022-06-23 23:32:10.880216
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    files_num = 123
    time = 12.3
    target = (3, 5)
    libs = 1111
    res = CompilationResult(files=files_num,
                            time=time,
                            target=target,
                            dependencies=libs)
    assert isinstance(res, CompilationResult)
    assert res.files == files_num
    assert res.time == time
    assert res.target == target
    assert res.dependencies == libs

# Generated at 2022-06-23 23:32:16.369916
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(
        tree=ast.Module(body=[]),
        tree_changed=False,
        dependencies=[])
    assert isinstance(t, TransformationResult)
    assert isinstance(t.tree, ast.Module)
    assert isinstance(t.tree_changed, bool)
    assert isinstance(t.dependencies, list)
    assert all(map(lambda d: isinstance(d, str), t.dependencies))

# Generated at 2022-06-23 23:32:19.742316
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input.py')
    output = Path('output.py')
    assert InputOutput(input, output).input == input
    assert InputOutput(input, output).output == output


# Generated at 2022-06-23 23:32:23.837981
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    r = TransformationResult(ast.AST(), True, [])
    assert r.tree is not None
    assert r.tree_changed is not False
    assert r.dependencies is not None

# Result of parser
ParserResult = NamedTuple('ParserResult',
                          [('tree', ast.AST),
                           ('dependencies', List[str])])


# Generated at 2022-06-23 23:32:27.919100
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('pass')
    transformation_result = TransformationResult(tree, True, ['a.b'])
    assert transformation_result.tree == tree
    assert transformation_result.tree_changed == True
    assert transformation_result.dependencies == ['a.b']

# Generated at 2022-06-23 23:32:30.050932
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=0, time=1.0, target=(3, 0), dependencies=[])

# Generated at 2022-06-23 23:32:32.589807
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path('input.py'), Path('output.py'))
    assert io.input == Path('input.py')
    assert io.output == Path('output.py')

# Generated at 2022-06-23 23:32:34.355591
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compil_result = CompilationResult(files=0, time=0.0,
                                      target=(0,0), dependencies=[])
    assert isinstance(compil_result, CompilationResult)

# Generated at 2022-06-23 23:32:38.355158
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_data = Path('/path/to/input.py')
    output_data = Path('/path/to/output.py')
    test_1 = InputOutput(input_data, output_data)
    assert test_1.input == input_data
    assert test_1.output == output_data


# Generated at 2022-06-23 23:32:41.616936
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('in.py'), Path('out.py')) == \
           InputOutput(input = Path('in.py'), output = Path('out.py'))


# Generated at 2022-06-23 23:32:47.257359
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # Constructor
    c = CompilationResult(files=10,
                          time=3.5,
                          target=(2, 7),
                          dependencies=['a',
                                        'b'])

    # Assertions
    assert c.files == 10
    assert c.time == 3.5
    assert c.target == (2, 7)
    assert c.dependencies == ['a', 'b']



# Generated at 2022-06-23 23:32:48.939450
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(
        input=Path('test.py'),
        output=Path('test.pyc'))


# Generated at 2022-06-23 23:32:50.496449
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a.py'), Path('b.py'))


# Generated at 2022-06-23 23:32:53.056167
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('/dir/in.py'), Path('/dir/out.py')) \
        == InputOutput('/dir/in.py', '/dir/out.py')



# Generated at 2022-06-23 23:32:57.155296
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=4, time=2.0,
                            target=(3, 7),
                            dependencies=['foo.py', 'bar.py'])
    
    assert res.files == 4
    assert res.time == 2.0
    assert res.target == (3, 7)
    assert res.dependencies == ['foo.py', 'bar.py']


# Generated at 2022-06-23 23:32:58.118450
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult  # pylint: disable=unused-variable
    assert True

# Generated at 2022-06-23 23:33:01.157227
# Unit test for constructor of class InputOutput
def test_InputOutput():  # type: () -> None
    inp = Path('/home/root')
    outp = Path('/home/out')
    io = InputOutput(input=inp, output=outp)
    assert io.input == inp
    assert io.output == outp

# Generated at 2022-06-23 23:33:02.419667
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 1.0, (3, 5), ['a', 'b'])


# Generated at 2022-06-23 23:33:06.327719
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(None, True, [])
    assert result.tree is None
    assert result.tree_changed
    assert result.dependencies == []


# Name of the input variable for __main__ module
MainName = '__main__'

# Name of the module with python version information
VersionName = 'versioneer'


# Generated at 2022-06-23 23:33:10.412722
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(ast.parse('0'), False, ['foo.py'])

    assert isinstance(res.tree, ast.AST)
    assert isinstance(res.tree_changed, bool)
    assert isinstance(res.dependencies, list)

# Generated at 2022-06-23 23:33:11.485001
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=0, time=0.0, target=(3, 6), dependencies=[])



# Generated at 2022-06-23 23:33:18.868312
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=0, time=-1.0, target=(3, 6), dependencies=["a", "b", "c"])
    assert CompilationResult(files=1, time=0.0, target=(3, 6), dependencies=["a", "b", "c"])
    assert CompilationResult(files=0, time=1000, target=(3, 6), dependencies=["a", "b", "c"])
    assert CompilationResult(files=1, time=0.0, target=(3, 7), dependencies=["a", "b", "c"])
    assert CompilationResult(files=1, time=0.0, target=(3, 6), dependencies=[])


# Generated at 2022-06-23 23:33:20.567133
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(3, 5.3, (3, 5), ["a"])


# Generated at 2022-06-23 23:33:22.517135
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1,
                      time=1.0,
                      target=(3, 5),
                      dependencies=[])

# Generated at 2022-06-23 23:33:26.963698
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    source = CompilationResult(1, 1.0, (3, 7), ['a.py'])
    assert source.files == 1
    assert source.time == 1.0
    assert source.target == (3, 7)
    assert source.dependencies == ['a.py']


# Generated at 2022-06-23 23:33:30.631922
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('foo')
    output = Path('bar')
    input_output = InputOutput(input_, output)

    assert input_.name == 'foo'
    assert output.name == 'bar'
    assert input_output.input.name == 'foo'
    assert input_output.output.name == 'bar'


# Generated at 2022-06-23 23:33:33.724294
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('/usr/bin')
    outp = Path('/tmp/foobar')
    io = InputOutput(inp, outp)
    assert io.input == inp
    assert io.output == outp


# Generated at 2022-06-23 23:33:38.832774
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1,
                               time=23.0,
                               target=(2, 7),
                               dependencies=["a", "b"])
    assert result.files == 1
    assert result.time == 23.0
    assert result.target == (2, 7)
    assert result.dependencies == ["a", "b"]


# Generated at 2022-06-23 23:33:42.574971
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_path = Path('some/path')
    output_path = Path('some/other/path')

    assert InputOutput(input=input_path, output=output_path).input == input_path
    assert InputOutput(input=input_path, output=output_path).output == output_path

# Generated at 2022-06-23 23:33:44.235438
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(files=1, time=1.0, target=(3, 7),
                             dependencies=['foo'])


# Generated at 2022-06-23 23:33:46.420893
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('./in'), Path('./out')).input == Path('./in')
    assert InputOutput(Path('./in'), Path('./out')).output == Path('./out')

# Generated at 2022-06-23 23:33:48.833408
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    """Tests if CompilationResult class is created correctly."""
    assert CompilationResult(1, 100, (3, 7), []) is not None


# Generated at 2022-06-23 23:33:53.554290
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(input=Path('some/path/to/file.py'),
                     output=Path('path/to/CheckStyle/file.py'))
    assert io.input == Path('some/path/to/file.py')
    assert io.output == Path('path/to/CheckStyle/file.py')

# Unit tests for methods of class InputOutput

# Generated at 2022-06-23 23:33:55.168788
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(input=Path('input.py'), output=Path('output.py'))


# Generated at 2022-06-23 23:33:56.069712
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    _ = CompilationResult


# Generated at 2022-06-23 23:34:00.732840
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=0,
                               time=0,
                               target=(0, 0),
                               dependencies=[])
    assert result.files == 0
    assert result.time == 0
    assert result.target[0] == 0
    assert result.target[1] == 0
    assert len(result.dependencies) == 0


# Generated at 2022-06-23 23:34:04.227142
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(files=1, time=0.1, target=(3,6), dependencies=['foo', 'bar'])
    assert r.files == 1
    assert r.time == 0.1
    assert r.target == (3, 6)
    assert r.dependencies == ['foo', 'bar']


# Generated at 2022-06-23 23:34:06.250116
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('foo')
    out = Path('bar')
    io = InputOutput(inp, out)
    assert io.input == inp
    assert io.output == out

# Generated at 2022-06-23 23:34:10.819515
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=42,
                           time=33.2,
                           target=(3, 6),
                           dependencies=['foo', 'bar'])
    assert isinstance(cr, CompilationResult)
    assert cr.files == 42
    assert cr.time == 33.2
    assert cr.target == (3, 6)
    assert cr.dependencies == ['foo', 'bar']


# Generated at 2022-06-23 23:34:14.102889
# Unit test for constructor of class InputOutput
def test_InputOutput():
    a = InputOutput(input='/tmp/a.txt', output='/tmp/b.txt')
    assert str(a.input) == '/tmp/a.txt'
    assert a.input.name == 'a.txt'
    assert str(a.output) == '/tmp/b.txt'
    assert a.output.name == 'b.txt'

# Generated at 2022-06-23 23:34:15.860830
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path("/tmp/x")
    output = Path("/tmp/y")
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output

# Generated at 2022-06-23 23:34:16.397275
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert True

# Generated at 2022-06-23 23:34:20.442605
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    pass

# Input/output file pair with information about compilation
CompilationIO = NamedTuple('CompilationIO', [('input', Path),
                                             ('output', Path),
                                             ('result', CompilationResult),
                                             ('keep_file_by_default', bool)])


# Generated at 2022-06-23 23:34:25.109778
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=1, time=1.0, target=(3, 8), dependencies=[])
    assert res.files == 1
    assert res.time == 1.0
    assert res.target == (3, 8)
    assert res.dependencies == []


# Generated at 2022-06-23 23:34:28.599900
# Unit test for constructor of class InputOutput
def test_InputOutput():
    p = Path('input.py')
    o = Path('/output.py')
    i = InputOutput(p, o)
    assert i.input == p
    assert i.output == o

# Generated at 2022-06-23 23:34:33.670833
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=1.0, target=(3, 7), dependencies=[])
    assert isinstance(result.files, int)
    assert isinstance(result.time, float)
    assert isinstance(result.target, CompilationTarget)
    assert isinstance(result.dependencies, List[str])


# Generated at 2022-06-23 23:34:37.182321
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = Path('/input')
    outp = Path('/output')
    io = InputOutput(inp, outp)
    assert io.input == inp
    assert io.output == outp


# Generated at 2022-06-23 23:34:38.298012
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, False, None)

# Generated at 2022-06-23 23:34:41.877167
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=None,
                              tree_changed=False,
                              dependencies=['module1', 'module2'])
    assert tr.tree is None
    assert tr.tree_changed is False
    assert tr.dependencies == ['module1', 'module2']

# Generated at 2022-06-23 23:34:44.933143
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(ast.parse('1 + 2'), True, ['test1', 'test2'])
    assert tr.tree_changed
    assert tr.dependencies == ['test1', 'test2']

# Generated at 2022-06-23 23:34:50.452089
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_name = '1234'
    output_name = '123456'
    input  = Path(input_name)
    output = Path(output_name)
    inp_out = InputOutput(input, output)
    assert inp_out.input.as_posix() == input_name
    assert inp_out.output.as_posix() == output_name


# Generated at 2022-06-23 23:34:54.012140
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=1, time=1.0, target=(3, 5),
                           dependencies=[])
    assert cr.files == 1
    assert cr.time == 1.0
    assert cr.target == (3, 5)
    assert cr.dependencies == []


# Generated at 2022-06-23 23:34:55.653685
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(files=5, target=(3, 5) , time=3.5, dependencies=[])


# Generated at 2022-06-23 23:34:58.380420
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(tree=ast.Module(), tree_changed=True, dependencies=[])
    assert len(res.dependencies) == 0


# Generated at 2022-06-23 23:35:03.644902
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    dummy_tree = ast.parse('1+1')
    dummy_dependencies = ['a', 'b', 'c']
    dummy_result = TransformationResult(dummy_tree, True, dummy_dependencies)
    assert isinstance(dummy_result.tree, ast.AST)
    assert dummy_result.tree_changed is True
    assert dummy_result.dependencies == dummy_dependencies

# Generated at 2022-06-23 23:35:05.014618
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
     TransformationResult(tree=None, tree_changed=False, dependencies=[])

# Generated at 2022-06-23 23:35:08.899812
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # type: () -> None
    d = CompilationResult(files=0, time=0,
                          target=(3, 4), dependencies=[])
    assert d.files == 0
    assert d.time == 0
    assert d.target == (3, 4)
    assert d.dependencies == []


# Generated at 2022-06-23 23:35:10.570572
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(tree=ast.parse('pass'), tree_changed=True,
                             dependencies=[])
    print(t)

# Generated at 2022-06-23 23:35:14.969496
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # Type: () -> None
    p = Path("a")
    q = Path("b")
    assert InputOutput(input=p, output=q) == InputOutput(input=p, output=q)
    assert InputOutput(input=p, output=p) != InputOutput(input=p, output=q)
    assert InputOutput(input=q, output=q) != InputOutput(input=p, output=q)

# Generated at 2022-06-23 23:35:17.308390
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    assert CompilationResult(1, 1.1, (3, 2), ['first.py', 'second.py'])

# Generated at 2022-06-23 23:35:21.296770
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    r = CompilationResult(files=1, time=1.0, target=(3, 6), dependencies=[])
    assert r.files == 1
    assert r.time == 1.0
    assert r.target == (3, 6)
    assert r.dependencies == []


# Generated at 2022-06-23 23:35:23.638490
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=1, time=0.1, target=(3, 6), dependencies=[])
    assert res.files == 1
    assert res.time == 0.1
    assert res.target == (3, 6)
    assert res.dependencies == []



# Generated at 2022-06-23 23:35:26.266953
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = InputOutput('foo/bar', 'foo/bar')
    assert i.input == 'foo/bar'
    assert i.output == 'foo/bar'



# Generated at 2022-06-23 23:35:29.064854
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('.')
    output = Path('.')
    in_out = InputOutput(input, output)
    assert in_out.input == input
    assert in_out.output == output

# Generated at 2022-06-23 23:35:31.579763
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(
        tree=None,
        tree_changed=False,
        dependencies=[]
    )
    assert t.tree_changed is False
    assert len(t.dependencies) == 0

# Generated at 2022-06-23 23:35:33.689812
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=None, tree_changed=False, dependencies=[])
    assert tr.tree is None
    assert tr.tree_changed is False
    assert tr.dependencies == []

# Generated at 2022-06-23 23:35:35.857237
# Unit test for constructor of class InputOutput
def test_InputOutput():
    inp = "foo.py"
    out = "bar.pyc"
    InputOutput(input=inp, output=out)
    # If the test past, we are good
    assert True

# Generated at 2022-06-23 23:35:42.185159
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_target = (3, 6)
    compilation_result = CompilationResult(
        files=1,
        time=0.5,
        target=compilation_target,
        dependencies=["0.5 seconds",
                      "A file"])
    assert compilation_result.files == 1
    assert compilation_result.time == 0.5
    assert compilation_result.target == compilation_target
    assert compilation_result.dependencies == ["0.5 seconds",
                                               "A file"]

# Generated at 2022-06-23 23:35:47.652621
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = InputOutput(input=Path("input"),
                        output=Path("output"))
    another_input = InputOutput(input=Path("new input"),
                        output=Path("new output"))
    assert input.input == "input"
    assert input.output == "output"
    assert repr(input) == "input -> output"
    assert input != another_input
    assert input == input

# Generated at 2022-06-23 23:35:49.025079
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.parse('a = 1'), True, [])

# Generated at 2022-06-23 23:35:52.081004
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i, o = 'a', 'b'
    r = InputOutput(i, o)
    assert r.input == Path(i)
    assert r.output == Path(o)


# Generated at 2022-06-23 23:35:58.405535
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i1 = InputOutput('input.py', 'output.py')
    assert isinstance(i1.input, Path)
    assert i1.input.name == 'input.py'
    assert isinstance(i1.output, Path)
    assert i1.output.name == 'output.py'

    i2 = InputOutput(Path('input.py'), 'output.py')
    assert isinstance(i2.input, Path)
    assert i2.input.name == 'input.py'
    assert isinstance(i2.output, Path)
    assert i2.output.name == 'output.py'

    i3 = InputOutput('input.py', Path('output.py'))
    assert isinstance(i3.input, Path)
    assert i3.input.name == 'input.py'
    assert isinstance

# Generated at 2022-06-23 23:35:59.433213
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.AST(), True, ['abc', 'def'])

# Generated at 2022-06-23 23:36:03.675903
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=2.0, target=(3,4), dependencies=['path'])
    assert result.files == 1
    assert result.time == 2.0
    assert result.target == (3,4)
    assert result.dependencies == ['path']


# Generated at 2022-06-23 23:36:06.165596
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=0.1, target=(3, 4), dependencies=["a.txt"])


# Generated at 2022-06-23 23:36:10.586125
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('test_input.txt')
    o = Path('test_output.txt')

    pair = InputOutput(i, o)
    assert pair.input == i
    assert pair.output == o
    assert pair == InputOutput(i, o)
    assert pair != InputOutput(o, i)


# Generated at 2022-06-23 23:36:15.061227
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    data = CompilationResult(123, 1.0, (3, 5), ['foo', 'bar'])
    assert data.files == 123
    assert data.time == 1.0
    assert data.target == (3, 5)
    assert data.dependencies == ['foo', 'bar']



# Generated at 2022-06-23 23:36:17.962125
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('input')
    output = Path('output')
    i = InputOutput(input, output)
    assert i.input == input
    assert i.output == output



# Generated at 2022-06-23 23:36:21.551122
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=0.001, target=(3, 6),
                               dependencies=[])
    assert result.files == 1
    assert result.time == 0.001
    assert result.target == (3, 6)
    assert result.dependencies == []


# Generated at 2022-06-23 23:36:31.091848
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=1, time=2.2, target=(3, 4),
                               dependencies=['foo', 'bar'])
    assert result.files == 1
    assert result.time == 2.2
    assert result.target == (3, 4)
    assert result.dependencies == ['foo', 'bar']
    # Check that we get exceptions if we try to set the attributes
    with pytest.raises(AttributeError):
        result.files = 2
    with pytest.raises(AttributeError):
        result.time = 4.4
    with pytest.raises(AttributeError):
        result.target = (6, 8)
    with pytest.raises(AttributeError):
        result.dependencies = ['foo', 'bar', 'baz']

# Generated at 2022-06-23 23:36:34.459726
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("1+1")
    a = TransformationResult(tree, False, [])
    assert a.tree is tree
    assert a.tree_changed == False
    assert a.dependencies == []

# Generated at 2022-06-23 23:36:37.996243
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(Path('input.py'), Path('output.py'))
    assert isinstance(io, InputOutput)
    assert io.input == Path('input.py')
    assert io.output == Path('output.py')

# Generated at 2022-06-23 23:36:39.818113
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(ast.Module(), True, [])
    assert result.tree_changed



# Generated at 2022-06-23 23:36:42.674489
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path("/tmp/a.py")
    output = Path("/tmp/b.py")
    a = InputOutput(input, output)
    assert a.input == input
    assert a.output == output

# Generated at 2022-06-23 23:36:46.448442
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('fixtures/input.py')
    output = Path('fixtures/output.py')
    input_output = InputOutput(input, output)
    assert(input_output.input == input)
    assert(input_output.output == output)

# Generated at 2022-06-23 23:36:50.160896
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('./path/to/input.py')
    output = Path('./path/to/output.py')
    pair = InputOutput(input, output)
    assert(pair.input == input)
    assert(pair.output == output)



# Generated at 2022-06-23 23:36:53.939202
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from typed_ast.ast3 import parse
    from os.path import join
    from ast_transformer import TransformationResult
    from typing import NamedTuple

    # pylint: disable=E0001,W0621
    Result = TransformationResult
    assert Result(parse('pass'), True, ['foo', 'bar']) == Result(tree=parse('pass'),
                                                                tree_changed=True,
                                                                dependencies=['foo', 'bar'])

# Generated at 2022-06-23 23:36:57.351928
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=1, time=0.0,
                            target=(3, 7),
                            dependencies=['a', 'b', 'c'])
    assert len(res) == 4 and res == CompilationResult(*res)


# Generated at 2022-06-23 23:36:59.767601
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files=0,
                               time=0,
                               target=(2, 5),
                               dependencies=[])


# Generated at 2022-06-23 23:37:05.811581
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=1,
                                           time=2.0,
                                           target=(3, 4),
                                           dependencies=['a', 'b'])
    assert_equal(compilation_result,
                 CompilationResult(files=1,
                                   time=2.0,
                                   target=(3, 4),
                                   dependencies=['a', 'b']))


# Generated at 2022-06-23 23:37:08.982205
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('a = 1')  # noqa: F841
    tr = TransformationResult(t, True, ['a'])
    assert tr.tree_changed is True
    assert tr.dependencies == ['a']

# Generated at 2022-06-23 23:37:10.672072
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = InputOutput('a', 'b')
    assert i.input == 'a' and i.output == 'b'

# Generated at 2022-06-23 23:37:14.624546
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_tmp = ast.Module()
    tr = TransformationResult(ast_tmp, True, ['a.py', 'b.py'])
    assert tr.tree == ast_tmp
    assert tr.tree_changed
    assert tr.dependencies == ['a.py', 'b.py']

__all__ = ['CompilationResult', 'InputOutput', 'TransformationResult']

# Generated at 2022-06-23 23:37:16.112640
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=0, time=0.0, target=(3, 6),
                      dependencies=['a', 'b'])


# Generated at 2022-06-23 23:37:24.535621
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a/b/c'), Path('x/y/z')) == \
        InputOutput(Path('a/b/c'), Path('x/y/z'))
    assert InputOutput(Path('a/b/c'), Path('x/y/z')) != \
        InputOutput(Path('a/b/c'), Path('a/b/c'))
    assert InputOutput(Path('a/b/c'), Path('x/y/z')) != \
        InputOutput(Path('x/y/z'), Path('x/y/z'))

# Generated at 2022-06-23 23:37:31.907783
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('a = 3')
    tr = TransformationResult(tree, False, [])
    assert tr.tree is tree
    assert not tr.tree_changed
    assert isinstance(tr.tree_changed, bool)
    assert tr.dependencies == []
    assert isinstance(tr.dependencies, list)
    tr = TransformationResult(tree, True, [])
    assert tr.tree is tree
    assert tr.tree_changed
    tr = TransformationResult(tree, True, ['a', 'b'])
    assert tr.tree is tree
    assert tr.tree_changed
    assert tr.dependencies == ['a', 'b']
    assert isinstance(tr.dependencies, list)

# Generated at 2022-06-23 23:37:34.094448
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse("pass")
    deps = []
    x = TransformationResult(tree, False, deps)
    assert x.tree is tree
    assert x.tree_changed is False
    assert x.dependencies is deps

# Generated at 2022-06-23 23:37:38.410520
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('/tmp/a.py'), Path('/tmp/a.pyc'))
    assert input_output.input == Path('/tmp/a.py')
    assert input_output.output == Path('/tmp/a.pyc')


# Generated at 2022-06-23 23:37:41.499785
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('path_to_file.py')
    o = Path('path_to_file.pyc')
    assert InputOutput(i, o) == InputOutput(i, o)


# Generated at 2022-06-23 23:37:44.836536
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(tree=ast.parse(''),
                              tree_changed=False,
                              dependencies=[])

    assert tr.tree == ast.parse('')
    assert tr.tree_changed == False
    assert tr.dependencies == []

# Generated at 2022-06-23 23:37:48.713093
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    cr = CompilationResult(
        files=5,
        time=0.1,
        target=(3, 6),
        dependencies=['a.py', 'b.py'])

    assert cr.files == 5
    assert cr.time == 0.1
    assert cr.target == (3, 6)
    assert cr.dependencies == ['a.py', 'b.py']

# Generated at 2022-06-23 23:37:52.665446
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(ast.AST(), True, [])
    assert isinstance(result, TransformationResult)

    result = TransformationResult(ast.AST(), False, [])
    assert isinstance(result, TransformationResult)

    result = TransformationResult(ast.AST(), True, [])
    assert isinstance(result.tree, ast.AST)
    assert isinstance(result.tree_changed, bool)
    assert isinstance(result.dependencies, list)


# Generated at 2022-06-23 23:37:57.011905
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=1,
                          time=0.0,
                          target=(3, 6),
                          dependencies=[])

    assert(c.files == 1)
    assert(c.time == 0.0)
    assert(c.target == (3, 6))
    assert(c.dependencies == [])



# Generated at 2022-06-23 23:37:58.993535
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 2.0, (2, 3), ['x', 'y'])


# Generated at 2022-06-23 23:38:05.704411
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    """Example of shapeless.contrib.universe.test.

    See: https://github.com/milessabin/shapeless/blob/master/examples/src/main/scala/shapeless/contrib/universe/test.scala
    """
    from shapeless import tuplify
    from shapeless.contrib.universe import test
    r = TransformationResult(ast.AST, bool, [str])
    assert tuplify(test[TransformationResult]) == tuplify(r)

# Generated at 2022-06-23 23:38:08.959897
# Unit test for constructor of class InputOutput
def test_InputOutput():
    test_input_output = InputOutput(input=Path('/home/input'),
                                    output=Path('/home/output'))
    assert test_input_output.input == Path('/home/input')
    assert test_input_output.output == Path('/home/output')


# Generated at 2022-06-23 23:38:13.394312
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    # pylint: disable=too-many-function-args
    cr = CompilationResult(0, 0.0, (3, 7), [])
    assert cr.files == 0
    assert cr.time == 0.0
    assert cr.target == (3, 7)
    assert cr.dependencies == []


# Generated at 2022-06-23 23:38:19.227242
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path("foo")
    output = Path("bar")
    input_output = InputOutput(input, output)
    assert input_output.input == input
    assert input_output.output == output
    input_output.input = Path("baz")
    input_output.output = Path("bin")
    assert input_output.input == Path("baz")
    assert input_output.output == Path("bin")


# Generated at 2022-06-23 23:38:23.527054
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    b = True
    l = ['foo']
    t = ast.parse('')
    result = TransformationResult(t, b, l)
    assert(result.tree_changed == b)
    assert(result.tree == t)
    assert(result.dependencies == l)
    return True

# Generated at 2022-06-23 23:38:24.879585
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput('input', 'output')


# Generated at 2022-06-23 23:38:33.193450
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tr = TransformationResult(None, None, None)
    assert tr.tree is None
    assert tr.tree_changed is None
    assert tr.dependencies == []


# Information about a single test case processed
TestCaseResult = NamedTuple('TestCaseResult',
                            [('input_file', Path),
                             ('output_file', Path),
                             ('compiled', bool),
                             ('result', CompilationResult),
                             ('transformed', bool),
                             ('transformations', List[TransformationResult]),
                             ('files_written', int),
                             ('files_deleted', int),
                             ('files_moved', int),
                             ('files_copied', int)])


# Generated at 2022-06-23 23:38:40.180053
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    import types # maybe use "import types as types" for the same effect?
    cr = CompilationResult(1, 1.5, (3, 7), ['a', 'b'])

    # Make sure type is CompilationResult
    assert isinstance(cr, types.FunctionType)

    # Check each member independently
    assert cr.files == 1
    assert cr.time == 1.5
    assert cr.target == (3, 7)
    assert cr.dependencies == ['a', 'b']

    # Check tuple
    assert cr[0] == 1
    assert cr[1] == 1.5
    assert cr[2] == (3, 7)
    assert cr[3] == ['a', 'b']

    # Make sure members cannot be changed

# Generated at 2022-06-23 23:38:44.396693
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    dependencies = []
    tree = ast.parse('1')
    result = TransformationResult(tree, True, dependencies)
    assert isinstance(result.tree, ast.AST)
    assert isinstance(result.tree_changed, bool)
    assert isinstance(result.dependencies, list)

# Generated at 2022-06-23 23:38:48.441492
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    res = TransformationResult(tree=None,
                               tree_changed=True,
                               dependencies=['path1', 'path2'])
    assert res.tree is None
    assert res.tree_changed is True
    assert res.dependencies == ['path1', 'path2']

# Generated at 2022-06-23 23:38:52.950935
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(
        files=10,
        time=3.14,
        target=(3, 7),
        dependencies=['a', 'b'])
    assert c.files == 10
    assert c.time == 3.14
    assert c.target == (3, 7)
    assert c.dependencies == ['a', 'b']


# Generated at 2022-06-23 23:38:55.947785
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(1, 2, (3, 4), ['5', '6'])
    assert res.files == 1
    assert res.time == 2
    assert res.target == (3, 4)
    assert res.dependencies == ['5', '6']


# Generated at 2022-06-23 23:38:59.912963
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('def f(): pass')
    dependencies = []
    result = TransformationResult(tree = t, tree_changed = False,
                                  dependencies = dependencies)
    assert result.tree == t
    assert result.tree_changed == False
    assert result.dependencies == dependencies

# Result of compiler compilation
CompilationRequest = NamedTuple('CompilationRequest',
                                [('input', Path),
                                 ('output', Path),
                                 ('target', CompilationTarget)])

# Generated at 2022-06-23 23:39:03.662398
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.parse('x=0')
    tr = TransformationResult(t, False, ['foo'])
    assert(tr.tree == t)
    assert(tr.tree_changed == False)
    assert(tr.dependencies == ['foo'])

# Generated at 2022-06-23 23:39:05.035953
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(tree=None, tree_changed=False, dependencies=[])

# Generated at 2022-06-23 23:39:09.904731
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(files = 1,
                               time = 1.0,
                               target = (3, 4),
                               dependencies = [])
    assert [result.files, result.time, result.target, result.dependencies] == [1, 1.0, (3, 4), []]


# Generated at 2022-06-23 23:39:15.932625
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(files=3, time=10.0, target=(3, 5),
                                           dependencies=['a', 'b', 'c'])
    assert compilation_result.files == 3
    assert compilation_result.time == 10.0
    assert compilation_result.target == (3, 5)
    assert compilation_result.dependencies == ['a', 'b', 'c']


# Generated at 2022-06-23 23:39:17.680260
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(1, 1.1, (3, 4), ['./foo'])



# Generated at 2022-06-23 23:39:18.630938
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(None, True, [])

# Generated at 2022-06-23 23:39:24.073595
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from copy import deepcopy
    from inspect import isclass
    from ast import parse
    from tempfile import TemporaryDirectory
    from pydevd import settrace as _settrace
    source = TemporaryDirectory()
    target = TemporaryDirectory()
    #_settrace()
    result = TransformationResult(parse("print('Hello World')"),
                                  True,
                                  [str(source.name), str(target.name)])
    assert result.tree_changed
    assert isclass(result.tree)
    assert result.tree == parse("print('Hello World')")
    assert deepcopy(result) == result
    assert deepcopy(result.dependencies) == result.dependencies

# Generated at 2022-06-23 23:39:28.034453
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_ = Path('1.py')
    output = Path('2.py')
    input_output = InputOutput(input_, output)
    assert input_output.input == input_
    assert input_output.output == output


# Generated at 2022-06-23 23:39:33.831874
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.Module([ast.Expr(ast.Call(ast.Name('print', ast.Load()),
                                         [ast.Str('Hello')],
                                         [], None, None))])
    res = TransformationResult(tree, True, ['hello.py'])
    assert res.tree == tree
    assert res.tree_changed == True
    assert res.dependencies == ['hello.py']

# Generated at 2022-06-23 23:39:38.605339
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    tree = ast.parse('3')
    p = Path('.')
    trans_result = TransformationResult(tree, False, [str(p)])
    assert trans_result.tree_changed == False
    assert trans_result.dependencies == [str(p)]
    assert trans_result.tree == tree

# Generated at 2022-06-23 23:39:39.577016
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    TransformationResult(ast.AST(), False, [])

# Generated at 2022-06-23 23:39:42.832597
# Unit test for constructor of class InputOutput
def test_InputOutput():  # type: () -> None
    input, output = Path('/a/b/c.py'), Path('/a/b/c.py')
    p = InputOutput(input, output)
    assert p.input == input
    assert p.output == output



# Generated at 2022-06-23 23:39:45.760295
# Unit test for constructor of class InputOutput
def test_InputOutput():
    i = Path('input')
    o = Path('output')
    io = InputOutput(i, o)
    assert io.input == i
    assert io.output == o



# Generated at 2022-06-23 23:39:48.651108
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    result = TransformationResult(ast.AST(), False, [])
    assert isinstance(result, TransformationResult)
    assert result.tree_changed == False
    assert result.dependencies == []


# Generated at 2022-06-23 23:39:54.548871
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    ast_tree = ast.parse('a = 1')
    tree_changed = True
    dependencies = []
    assert TransformationResult(ast_tree, tree_changed, dependencies)

# Result of transformer apply function
TransformerResult = NamedTuple('TransformerResult',
                               [('tree', ast.AST),
                                ('tree_changed', bool),
                                ('dependencies', List[str])])


# Generated at 2022-06-23 23:39:57.653965
# Unit test for constructor of class InputOutput
def test_InputOutput():
    path = Path("/some/path")
    input_output = InputOutput(input=path, output=path)
    assert input_output.input == path
    assert input_output.output == path

# Generated at 2022-06-23 23:39:59.088814
# Unit test for constructor of class InputOutput
def test_InputOutput():
    InputOutput(input=Path('foo'), output=Path('bar'))



# Generated at 2022-06-23 23:40:02.856262
# Unit test for constructor of class InputOutput
def test_InputOutput():
    io = InputOutput(input='/tmp/foo.py',
                     output='/tmp/foo.so')

    assert io.input == Path('/tmp/foo.py')
    assert io.output == Path('/tmp/foo.so')


# Generated at 2022-06-23 23:40:05.313313
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    obj = TransformationResult(
        tree = ast.parse('1 + 1'),
        tree_changed = True,
        dependencies = []
    )
    assert isinstance(obj, TransformationResult)


# Generated at 2022-06-23 23:40:07.159890
# Unit test for constructor of class InputOutput
def test_InputOutput():
    # type: () -> None

    InputOutput(Path('a.txt'), Path('b.txt'))



# Generated at 2022-06-23 23:40:17.992312
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    try:
        assert CompilationResult(0, 0.0, (0, 0), [])
    except:
        raise AssertionError("Error with test 1 for constructor of CompilationResult")
    try:
        assert CompilationResult(0, 0.0, (0, 0), ["a", "b"])
    except:
        raise AssertionError("Error with test 2 for constructor of CompilationResult")
    try:
        assert CompilationResult(1, 0.0, (0, 0), ["a", "b"])
    except:
        raise AssertionError("Error with test 3 for constructor of CompilationResult")

# Generated at 2022-06-23 23:40:19.791915
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=2, target=(3, 4), dependencies=['a', 'b'])


# Generated at 2022-06-23 23:40:22.449436
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('in')
    output = Path('out')
    io = InputOutput(input, output)
    assert io.input == input
    assert io.output == output


# Generated at 2022-06-23 23:40:27.839899
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    compilation_result = CompilationResult(1, 2, (3, 4), [])
    assert compilation_result.files == 1
    assert compilation_result.time == 2
    assert compilation_result.target == (3, 4)
    assert compilation_result.dependencies == []
    assert str(compilation_result) == \
        'Compiled 1 files in 2 second(s) for target (3, 4)'



# Generated at 2022-06-23 23:40:31.470586
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    a = CompilationResult(0, 0.0, (0, 0), [])
    b = CompilationResult(files=0,
                          time=0.0,
                          target=(0, 0),
                          dependencies=[])

    assert a == b


# Generated at 2022-06-23 23:40:33.390717
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.0, target=(1, 2), dependencies=['a'])


# Generated at 2022-06-23 23:40:36.190277
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path('/tmp/input')
    output = Path('/tmp/output')
    pair = InputOutput(input, output)

    assert pair.input == input
    assert pair.output == output


# Generated at 2022-06-23 23:40:39.874014
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    test_tree = ast.parse('1 + 1')
    test_tree_changed = True
    test_dependencies = ['test_dependency']
    tr = TransformationResult(test_tree,
                              test_tree_changed,
                              test_dependencies)
    assert tr.tree.body == test_tree.body
    assert tr.tree_changed == test_tree_changed
    assert tr.dependencies == test_dependencies

# Generated at 2022-06-23 23:40:41.629932
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    CompilationResult(files=1, time=1.1, target=(1, 2), dependencies=[])


# Generated at 2022-06-23 23:40:49.030069
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    from ast import parse
    from transformers import SourceTransformers
    import types
    import inspect

    tree_changed = True
    dependencies = ['foo.py', 'bar.py']

    tr = TransformationResult(parse('1'), tree_changed, dependencies)
    assert inspect.isclass(TransformationResult)
    assert isinstance(tr, TransformationResult)
    assert tr.tree_changed is tree_changed
    assert tr.tree.body[0].value.n == 1
    assert tr.dependencies == dependencies

# Generated at 2022-06-23 23:40:52.332589
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input = Path("input.py")
    output = Path("output.py")
    inout = InputOutput(input, output)
    assert inout.input == input
    assert inout.output == output


# Generated at 2022-06-23 23:41:00.704978
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = ast.Name()
    res = TransformationResult(tree=t, tree_changed=True, dependencies=['foo'])
    assert res.tree is t
    assert res.tree_changed
    assert res.dependencies == ['foo']

# Result of compilation of several files
CompilationSummary = NamedTuple('CompilationSummary',
                                [('compiled', int),
                                 ('skipped', int)])

# Result of compilation of single file
FileCompilationResult = NamedTuple('FileCompilationResult',
                                   [('source', Path),
                                    ('target', Path),
                                    ('success', bool),
                                    ('errors', List[str]),
                                    ('target_version', CompilationTarget)])


# Generated at 2022-06-23 23:41:07.217185
# Unit test for constructor of class InputOutput
def test_InputOutput():
    assert InputOutput(Path('a'), Path('b')) == InputOutput(input='a', output='b')
    assert InputOutput(Path('a'), Path('b')) == InputOutput(input=Path('a'), output=Path('b'))
    assert InputOutput(Path('a'), Path('b')).input == Path('a')
    assert InputOutput(Path('a'), Path('b')).output == Path('b')


# Generated at 2022-06-23 23:41:11.323809
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    time = 5.
    files = 1
    target = (3, 7)
    dependencies = []
    result = CompilationResult(files, time, target, dependencies)
    assert result.files == files
    assert result.time == time
    assert result.target == target
    assert result.dependencies == dependencies



# Generated at 2022-06-23 23:41:19.528895
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    loc = ast.parse('a = 1').body[0].lineno
    TransformationResult(ast.parse('a = 1'), False, [])
    TransformationResult(ast.parse('a = 1'), True, [])
    TransformationResult(ast.parse('a = 1').body[0], False, [])
    TransformationResult(ast.parse('a = 1').body[0], True, [])
    TransformationResult(ast.parse('a = 1').body[0].lineno, False, [])
    TransformationResult(ast.parse('a = 1').body[0].lineno, True, [])
    TransformationResult(loc, False, [])
    TransformationResult(loc, True, [])

    # noinspection PyUnresolvedReferences
    TransformationResult((1, 2, 3), True, [])
    # noinspection PyUnresolved

# Generated at 2022-06-23 23:41:23.241699
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    assert TransformationResult(ast.AST(), False, []) == \
           TransformationResult(ast.AST(), False, [])


# Version of code that is on repository
SvnInfo = NamedTuple('SvnInfo',
                     [('revision', str),
                      ('last_changed_date', str),
                      ('url', str)])


# Generated at 2022-06-23 23:41:25.678962
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    t = TransformationResult(tree=ast.parse('a'),
                             tree_changed=False,
                             dependencies=['a'])
    assert t.tree
    assert not t.tree_changed
    assert t.dependencies == ['a']

# Generated at 2022-06-23 23:41:28.575934
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c = CompilationResult(files=1, time=0.1, target=(3, 5), dependencies=[])

    assert c.files == 1
    assert c.time == 0.1
    assert c.target[0] == 3
    assert c.target[1] == 5
    assert len(c.dependencies) == 0



# Generated at 2022-06-23 23:41:31.564969
# Unit test for constructor of class TransformationResult
def test_TransformationResult():
    obj = TransformationResult(tree=None, tree_changed=False, dependencies=[])
    assert obj.tree is None
    assert obj.tree_changed is False
    assert obj.dependencies == []


# Result of transformers transformation
TransformationKey = NamedTuple('TransformationKey',
                               [('name', str),
                                ('kwargs', dict)])


# Generated at 2022-06-23 23:41:35.301432
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput(Path('test_input'), Path('test_output'))
    assert input_output.input == Path('test_input')
    assert input_output.output == Path('test_output')


# Generated at 2022-06-23 23:41:42.827000
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    c1 = CompilationResult(files=42, time=2.5, target=(2, 7), dependencies=['MyModule', 'YourModule'])

    assert c1.files == 42
    assert c1.time == 2.5
    assert c1.target == (2, 7)
    assert c1.dependencies == ['MyModule', 'YourModule']

    c2 = CompilationResult(**c1._asdict())

    assert c1 == c2


# Generated at 2022-06-23 23:41:48.771712
# Unit test for constructor of class InputOutput
def test_InputOutput():
    input_output = InputOutput('/hello/world/input.py',
                               '/hello/world/output.py')
    assert input_output.input == Path('/hello/world/input.py')
    assert input_output.output == Path('/hello/world/output.py')
    assert input_output.input == Path('/hello/world/input.py')


# Generated at 2022-06-23 23:41:53.087841
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    result = CompilationResult(123, 123.456, (2, 7), [])
    assert result.files == 123
    assert result.time == 123.456
    assert result.target == (2, 7)
    assert result.dependencies == []


# Generated at 2022-06-23 23:41:57.023093
# Unit test for constructor of class CompilationResult
def test_CompilationResult():
    res = CompilationResult(files=0,
                            time=0.0,
                            target=(0, 0),
                            dependencies=[])
    assert res.files == 0
    assert res.time == 0.0
    assert res.target == (0, 0)
    assert res.dependencies == []
