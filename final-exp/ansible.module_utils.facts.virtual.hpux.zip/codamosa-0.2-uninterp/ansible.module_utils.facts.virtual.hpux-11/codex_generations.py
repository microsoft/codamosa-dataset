

# Generated at 2022-06-17 03:08:14.379769
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-17 03:08:16.565476
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:08:18.669686
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:08:27.266188
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualFacts
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualMetaclass
    from ansible.module_utils.facts.virtual.hpux import VirtualSubclass
    from ansible.module_utils.facts.virtual.hpux import VirtualSubclassMetaclass

# Generated at 2022-06-17 03:08:28.691255
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:08:38.157230
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvm
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvpar
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux

# Generated at 2022-06-17 03:08:40.272318
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-17 03:08:41.969031
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:08:50.800412
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector

# Generated at 2022-06-17 03:08:52.437310
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:09:08.490477
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(dict(module=dict()))
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-17 03:09:19.332381
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvm
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvpar
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux

# Generated at 2022-06-17 03:09:30.576198
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvm
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_npar
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_

# Generated at 2022-06-17 03:09:32.462744
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-17 03:09:34.023517
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:09:35.438525
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:09:37.104342
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:09:39.151711
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:09:40.583537
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:09:43.153821
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:09:57.357596
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-17 03:09:58.878774
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-17 03:10:00.280415
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-17 03:10:06.472645
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_subclass
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_collector_platforms
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_collector_subclass
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_collector_classes

# Generated at 2022-06-17 03:10:09.724887
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(dict())
    assert hpux_virtual.platform == 'HP-UX'



# Generated at 2022-06-17 03:10:13.170193
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-17 03:10:15.375884
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-17 03:10:21.134407
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector

# Generated at 2022-06-17 03:10:23.421968
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:10:27.752417
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'
    assert hv.get_virtual_facts() == {'virtualization_type': 'host', 'virtualization_role': 'HPVM', 'virtualization_tech_guest': set(['HPVM']), 'virtualization_tech_host': set()}

# Generated at 2022-06-17 03:10:42.934639
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:10:44.464029
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:10:46.981218
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(dict())
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-17 03:10:48.769736
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-17 03:10:57.673083
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoCollector
    from ansible.module_utils.facts.virtual.hpux import Virtualization
    from ansible.module_utils.facts.virtual.hpux import VirtualizationCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualizationFactCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualizationFacts

# Generated at 2022-06-17 03:10:59.009400
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:11:00.366178
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:11:02.621139
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:11:05.546206
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-17 03:11:17.746318
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual

    class MockModule(object):
        def __init__(self):
            self.run_command = MockModule.run_command

        def run_command(cmd):
            if cmd == '/usr/sbin/vecheck':
                return 0, '', ''
            elif cmd == '/opt/hpvm/bin/hpvminfo':
                return 0, 'Running HPVM vPar', ''
            elif cmd == '/usr/sbin/parstatus':
                return 0, '', ''


# Generated at 2022-06-17 03:11:40.431979
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
   

# Generated at 2022-06-17 03:11:42.211620
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-17 03:11:44.088851
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:11:50.085049
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = AnsibleModule(argument_spec={})
    virtual_facts = HPUXVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    assert virtual_facts['virtualization_tech_guest'] == set(['HP vPar'])
    assert virtual_facts['virtualization_tech_host'] == set()


# Generated at 2022-06-17 03:11:59.874943
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector

# Generated at 2022-06-17 03:12:07.613809
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    import os
    import re
    import sys
    import unittest

    class MockModule(object):
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    class MockOs(object):
        def __init__(self):
            self.path_exists_results = []
            self.path_

# Generated at 2022-06-17 03:12:16.641737
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpar import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpvm import HPUXVirtual
    from ansible.module_utils.facts.virtual.npar import HPUXVirtual
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import VirtualOptions
    from ansible.module_utils.facts.virtual.base import VirtualFacts
    from ansible.module_utils.facts.virtual.base import VirtualMachine
    from ansible.module_utils.facts.virtual.base import VirtualMachineOptions
    from ansible.module_utils.facts.virtual.base import VirtualMachineFacts

# Generated at 2022-06-17 03:12:18.984183
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'
    assert virtual_facts.get_virtual_facts() == {}

# Generated at 2022-06-17 03:12:26.273712
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.exit_json = MagicMock()
    module.fail_json = MagicMock()
    virtual_facts = HPUXVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    assert virtual_facts['virtualization_tech_guest'] == set(['HP vPar'])
    assert virtual_facts['virtualization_tech_host'] == set()


# Generated at 2022-06-17 03:12:31.127340
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector

# Generated at 2022-06-17 03:12:47.277898
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:12:48.654348
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:12:51.409208
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:12:58.561425
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
   

# Generated at 2022-06-17 03:13:06.450928
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector

# Generated at 2022-06-17 03:13:09.607268
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:13:10.891449
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-17 03:13:18.308651
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_platform
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_platform_virtual
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_platform_virtual_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_platform_virtual_hp

# Generated at 2022-06-17 03:13:28.861709
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector

# Generated at 2022-06-17 03:13:31.647722
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:13:43.112409
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:13:44.612563
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual({})
    assert virtual.platform == 'HP-UX'

# Generated at 2022-06-17 03:13:54.790337
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoCollector
    from ansible.module_utils.facts.virtual.hpux import Virtualization
    from ansible.module_utils.facts.virtual.hpux import VirtualizationCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualizationFactCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualizationFacts

# Generated at 2022-06-17 03:14:05.859052
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    import os
    import re
    import sys
    import unittest
    import tempfile
    import shutil
    import subprocess
    import ansible.module_utils.facts.virtual.hpux

    class TestHPUXVirtual(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.tmpdir)

# Generated at 2022-06-17 03:14:16.997573
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoCollector
    from ansible.module_utils.facts.virtual.hpux import Virtualization
    from ansible.module_utils.facts.virtual.hpux import VirtualizationCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualizationFactCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualizationFacts

# Generated at 2022-06-17 03:14:19.498136
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(dict())
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-17 03:14:21.722412
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:14:32.083551
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoCollector
    from ansible.module_utils.facts.virtual.hpux import Virtualization
    from ansible.module_utils.facts.virtual.hpux import VirtualizationCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualizationFactCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualizationFacts

# Generated at 2022-06-17 03:14:34.453066
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.platform == 'HP-UX'
    assert hv.get_virtual_facts() == {}


# Generated at 2022-06-17 03:14:37.576661
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'
    assert hv.get_virtual_facts() == {}


# Generated at 2022-06-17 03:14:49.401227
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'
    assert virtual_facts.get_virtual_facts() == {}

# Generated at 2022-06-17 03:14:53.315570
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualFacts
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualMetaclass
    from ansible.module_utils.facts.virtual.hpux import VirtualSubclass
    from ansible.module_utils.facts.virtual.hpux import VirtualSubclassMetaclass

# Generated at 2022-06-17 03:14:55.053280
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:14:56.773744
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:15:04.233392
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector

# Generated at 2022-06-17 03:15:16.415302
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvm
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hppar
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux

# Generated at 2022-06-17 03:15:24.762017
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo

    class TestModule(object):
        def __init__(self):
            self.run_command_environ_update = {}

        def run_command(self, cmd, check_rc=True):
            if cmd == '/usr/sbin/vecheck':
                return 0, '', ''
            elif cmd == '/opt/hpvm/bin/hpvminfo':
                return 0, 'Running as HPVM vPar', ''

# Generated at 2022-06-17 03:15:33.782795
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvm
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvpar
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux

# Generated at 2022-06-17 03:15:42.982542
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector

# Generated at 2022-06-17 03:15:43.928835
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-17 03:15:59.707270
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:16:06.153768
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_linux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_openbsd
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_sunos

# Generated at 2022-06-17 03:16:09.503245
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-17 03:16:19.495681
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvm
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpar
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_

# Generated at 2022-06-17 03:16:26.506751
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvm
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_vpar
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_

# Generated at 2022-06-17 03:16:28.442663
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-17 03:16:37.848284
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
   

# Generated at 2022-06-17 03:16:39.934696
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-17 03:16:41.424314
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-17 03:16:52.184592
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoModule
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoModuleCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoModuleParser
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoModuleParserCollector

# Generated at 2022-06-17 03:17:23.251607
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:17:30.727976
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
   

# Generated at 2022-06-17 03:17:40.767677
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoModule
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoModuleCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoModuleParser

# Generated at 2022-06-17 03:17:43.468967
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-17 03:17:51.912926
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvm
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvpar
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux

# Generated at 2022-06-17 03:17:53.294178
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-17 03:17:54.655113
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:17:59.600024
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(dict())
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-17 03:18:07.439306
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual