

# Generated at 2022-06-17 03:08:14.545313
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:08:16.566735
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual()
    assert virtual.platform == 'HP-UX'


# Generated at 2022-06-17 03:08:25.125977
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector

# Generated at 2022-06-17 03:08:26.999216
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:08:36.536080
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector

# Generated at 2022-06-17 03:08:45.582562
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvm
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_npar
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_

# Generated at 2022-06-17 03:08:50.505338
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector

# Generated at 2022-06-17 03:09:01.449858
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvm
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvpar
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux

# Generated at 2022-06-17 03:09:02.130697
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:09:08.240061
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_platform_specific
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_platform_specific_collector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_platform_specific_collector_class
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_

# Generated at 2022-06-17 03:09:22.127138
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualFacts
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualMetaclass
    from ansible.module_utils.facts.virtual.hpux import VirtualNetworkInterface
    from ansible.module_utils.facts.virtual.hpux import VirtualNetworkInterfaceInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualNetworkInterfaceMetaclass

# Generated at 2022-06-17 03:09:30.892922
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Create a HPUXVirtual object
    hpux_virtual = HPUXVirtual()
    # Create a dictionary with the expected results
    expected_result = {'virtualization_type': 'guest',
                       'virtualization_role': 'HP vPar',
                       'virtualization_tech_guest': set(['HP vPar']),
                       'virtualization_tech_host': set()}
    # Call the method get_virtual_facts of the object
    result = hpux_virtual.get_virtual_facts()
    # Compare the result with the expected result
    assert result == expected_result

# Generated at 2022-06-17 03:09:39.102429
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts

    # Test get_virtual_facts()
    #
    # Test case 1:
    #   - /usr/sbin/vecheck exists
    #   - /usr/sbin/vecheck returns 0
    #   - /opt/hpvm/bin/hpvminfo exists
    #   - /opt/hpvm/bin/hpvminfo returns 0
    #   - /opt/hpvm/bin/hpvminfo returns 'Running HPVM vPar'

# Generated at 2022-06-17 03:09:40.547368
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:09:43.149772
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:09:44.780928
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-17 03:09:55.495166
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoCollector
    from ansible.module_utils.facts.virtual.hpux import Virtualization
    from ansible.module_utils.facts.virtual.hpux import VirtualizationCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualizationFactCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualizationFacts

# Generated at 2022-06-17 03:10:03.556064
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    import os
    import re
    import sys
    import unittest

    class MockModule(object):
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    class MockOs(object):
        def __init__(self):
            self.path_exists_results = []
            self.path_

# Generated at 2022-06-17 03:10:06.784406
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-17 03:10:18.454473
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvm
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvpar
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux

# Generated at 2022-06-17 03:10:52.820556
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvm
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvpar
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux

# Generated at 2022-06-17 03:10:54.562533
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:11:03.406507
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_linux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_bsd
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_solaris

# Generated at 2022-06-17 03:11:16.537402
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualMachine
    from ansible.module_utils.facts.virtual.hpux import VirtualMachineCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualNetwork
    from ansible.module_utils.facts.virtual.hpux import VirtualNetwork

# Generated at 2022-06-17 03:11:28.527589
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
   

# Generated at 2022-06-17 03:11:30.236828
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:11:40.394229
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvm
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvpar
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux

# Generated at 2022-06-17 03:11:41.883038
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-17 03:11:44.179989
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:11:46.786583
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-17 03:12:41.982645
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-17 03:12:43.383793
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict())
    assert virtual.platform == 'HP-UX'


# Generated at 2022-06-17 03:12:44.988638
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-17 03:12:55.151858
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo
    import os
    import re

    class FakeModule(object):
        def __init__(self):
            self.run_command_args = []
            self.run_command_rcs = []
            self.run_command_exceptions = []
            self.run_command_calls = 0
            self.run_command_rc = 0
            self.run_command_out = ''
            self.run_command_err = ''


# Generated at 2022-06-17 03:13:03.616479
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_collector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_virtual
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_virtual

# Generated at 2022-06-17 03:13:16.330462
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
   

# Generated at 2022-06-17 03:13:26.691129
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_subclass

    # Test for method get_virtual_facts of class HPUXVirtual
    # Test case 1:
    # Test for the case when /usr/sbin/vecheck exists and
    # /opt/hpvm/bin/hpvminfo exists and
    # /usr/sbin/parstatus exists
    # Expected result:
    # virtualization_type = '

# Generated at 2022-06-17 03:13:28.164830
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:13:39.258983
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvm
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_npar
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_

# Generated at 2022-06-17 03:13:50.321705
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _platform
    from ansible.module_utils.facts.virtual.hpux import _fact_class
    from ansible.module_utils.facts.virtual.hpux import platform
    from ansible.module_utils.facts.virtual.hpux import _platform
    from ansible.module_utils.facts.virtual.hpux import _fact_class
    from ansible.module_utils.facts.virtual.hpux import platform
    from ansible.module_utils.facts.virtual.hpux import _

# Generated at 2022-06-17 03:14:35.709624
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualFacts
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualMetaclass
    from ansible.module_utils.facts.virtual.hpux import VirtualNetwork
    from ansible.module_utils.facts.virtual.hpux import VirtualSubclass
    from ansible.module_utils.facts.virtual.hpux import VirtualSub

# Generated at 2022-06-17 03:14:38.167815
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:14:40.980501
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:14:43.288026
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-17 03:14:52.512244
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvm
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvpar
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux

# Generated at 2022-06-17 03:14:55.430749
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-17 03:14:57.932138
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'
    assert hv.get_virtual_facts() == {}


# Generated at 2022-06-17 03:14:59.473287
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-17 03:15:05.677492
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualFacts
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo

    # Create a HPUXVirtual object
    hpux_virtual = HPUXVirtual()

    # Create a HPUXVirtualCollector object
    hpux_virtual_collector = HPUXVirtualCollector()

    # Create a Virtual object
    virtual = Virtual()

    # Create a VirtualCollector object
    virtual_collector = VirtualCollector()

    # Create a VirtualFacts object
   

# Generated at 2022-06-17 03:15:07.358258
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-17 03:16:05.558559
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:16:09.502844
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'
    assert hv.get_virtual_facts() == {}

# Generated at 2022-06-17 03:16:12.150850
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:16:20.783896
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Create a mock module
    mock_module = type('AnsibleModule', (), {})()
    mock_module.run_command = lambda *args, **kwargs: (0, '', '')
    mock_module.params = {}

    # Create a mock file system
    mock_filesystem = {
        '/usr/sbin/vecheck': True,
        '/opt/hpvm/bin/hpvminfo': True,
        '/usr/sbin/parstatus': True,
    }

    # Create a HPUXVirtual object
    hpux_virtual = HPUXVirtual(mock_module)
    hpux_virtual.filesystem = mock_filesystem

    # Test get_virtual_facts
    virtual_facts = hpux_virtual.get_virtual_facts()

# Generated at 2022-06-17 03:16:27.484518
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_vecheck
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvminfo
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hp

# Generated at 2022-06-17 03:16:37.581591
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualFacts

    class TestModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def run_command(self, cmd):
            return self.rc, self.out, self.err

    # test for HP vPar
    module = TestModule(0, '', '')
    hpux_virtual = HPUXVirtual(module)
    hpux_virtual.get_virtual

# Generated at 2022-06-17 03:16:40.497108
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'
    assert virtual_facts.get_virtual_facts() == {}


# Generated at 2022-06-17 03:16:51.062367
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector

# Generated at 2022-06-17 03:16:53.697068
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'
    assert virtual_facts.get_virtual_facts() == {}


# Generated at 2022-06-17 03:16:56.061534
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'
    assert hv.get_virtual_facts() == {}


# Generated at 2022-06-17 03:18:00.212864
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpar import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpvm import HPUXVirtual
    from ansible.module_utils.facts.virtual.npar import HPUXVirtual
    from ansible.module_utils.facts.virtual.ve import HPUXVirtual
    from ansible.module_utils.facts.virtual.ivm import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpvm import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpvm import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpvm import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpvm import HPUXVirtual

# Generated at 2022-06-17 03:18:09.374463
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoCollector

    class FakeModule(object):
        def __init__(self):
            self.run_command = lambda x: (0, '', '')

    class FakeVirtualInfo(VirtualInfo):
        def __init__(self):
            self.module = FakeModule()

    class FakeVirtualInfoCollector(VirtualInfoCollector):
        def __init__(self):
            self.module = FakeModule