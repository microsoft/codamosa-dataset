

# Generated at 2022-06-17 03:08:22.358861
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector

# Generated at 2022-06-17 03:08:26.500562
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'
    assert virtual_facts.get_virtual_facts() == {'virtualization_type': 'guest', 'virtualization_role': 'HP vPar', 'virtualization_tech_guest': {'HP vPar'}, 'virtualization_tech_host': set()}

# Generated at 2022-06-17 03:08:36.069378
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoCollector
    from ansible.module_utils.facts.virtual.hpux import Virtualization, VirtualizationCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualizationFactCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualizationFacts
    from ansible.module_utils.facts.virtual.hpux import VirtualizationInfo

# Generated at 2022-06-17 03:08:37.517563
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:08:38.951697
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-17 03:08:41.876524
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.platform == 'HP-UX'
    assert hv.get_virtual_facts() == {}


# Generated at 2022-06-17 03:08:43.408389
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-17 03:08:45.197626
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-17 03:08:54.886422
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts

    # Create a HPUXVirtual object
    hpux_virtual = HPUXVirtual()

    # Create a HPUXVirtualCollector object
    hpux_virtual_collector = HPUXVirtualCollector()

    # Create a Virtual object
    virtual = Virtual()

    # Create a VirtualCollector object
    virtual_collector = VirtualCollector()

    # Create a _get_virtual_facts object
    get_virtual_facts = _get_virtual_facts()

# Generated at 2022-06-17 03:09:04.742563
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvm
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvpar
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux

# Generated at 2022-06-17 03:09:22.355010
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvm
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvpar
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux

# Generated at 2022-06-17 03:09:25.089290
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict())
    assert virtual.platform == 'HP-UX'


# Generated at 2022-06-17 03:09:27.118472
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:09:29.686205
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:09:31.985665
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(dict())
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-17 03:09:33.649144
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'
    assert virtual_facts.get_virtual_facts() == {}


# Generated at 2022-06-17 03:09:35.106682
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict())
    assert virtual.platform == 'HP-UX'


# Generated at 2022-06-17 03:09:36.498249
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-17 03:09:37.930005
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:09:48.078218
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual

# Generated at 2022-06-17 03:10:06.429274
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoCollector
    from ansible.module_utils.facts.virtual.hpux import Virtualization
    from ansible.module_utils.facts.virtual.hpux import VirtualizationCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualizationFactCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualizationFacts

# Generated at 2022-06-17 03:10:18.343244
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualFacts
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualMetaclass
    from ansible.module_utils.facts.virtual.hpux import VirtualNetworkInterface
    from ansible.module_utils.facts.virtual.hpux import VirtualNetworkInterfaceInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualNetworkInterfaceMetaclass

# Generated at 2022-06-17 03:10:19.767919
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(dict())
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-17 03:10:29.557004
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Create a HPUXVirtual object
    hpux_virtual = HPUXVirtual()

    # Create a module object
    module = type('', (), {})()
    module.run_command = lambda x: (0, '', '')
    hpux_virtual.module = module

    # Test the get_virtual_facts method
    hpux_virtual_facts = hpux_virtual.get_virtual_facts()
    assert hpux_virtual_facts['virtualization_type'] == 'guest'
    assert hpux_virtual_facts['virtualization_role'] == 'HP vPar'
    assert hpux_virtual_facts['virtualization_tech_guest'] == set(['HP vPar'])
    assert hpux_virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:10:39.051088
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
   

# Generated at 2022-06-17 03:10:40.705870
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:10:43.200124
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-17 03:10:52.496838
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoModule
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoModuleCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoModuleParser
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoParser

# Generated at 2022-06-17 03:10:53.681567
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-17 03:11:02.586379
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector

# Generated at 2022-06-17 03:11:28.788225
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvm
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvpar
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux

# Generated at 2022-06-17 03:11:30.791591
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-17 03:11:32.260342
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:11:42.285183
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvm
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvpar
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux

# Generated at 2022-06-17 03:11:44.602109
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(dict(module=dict()))
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-17 03:11:54.542626
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoModule
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoModuleCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoModuleParser

    class MockModule(object):
        def __init__(self):
            self.run_command = MockModule.run_command

# Generated at 2022-06-17 03:11:56.895153
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:12:05.326144
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts

    # Test for HP-UX guest
    class TestModule:
        def __init__(self):
            self.run_command_environ_update = {}

# Generated at 2022-06-17 03:12:09.461500
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'
    assert virtual_facts.get_virtual_facts() == {}

# Generated at 2022-06-17 03:12:12.001021
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:12:29.829885
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvm
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvpar
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux

# Generated at 2022-06-17 03:12:32.091466
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:12:42.076096
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts

    # Create a mock module
    module = MockModule()

    # Create a mock class
    class MockHPUXVirtual(HPUXVirtual):
        def __init__(self, module):
            self.module = module

    # Create a mock class
    class MockHPUXVirtualCollector(HPUXVirtualCollector):
        def __init__(self, module):
            self.module = module
            self.fact_class = MockHPUXVirtual

   

# Generated at 2022-06-17 03:12:43.705488
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-17 03:12:54.101008
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoCollector
    from ansible.module_utils.facts.virtual.hpux import Virtualization
    from ansible.module_utils.facts.virtual.hpux import VirtualizationCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualizationFacts
    from ansible.module_utils.facts.virtual.hpux import VirtualizationFactsCollector

# Generated at 2022-06-17 03:13:00.075038
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_subclass
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_collector_platforms
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_collector_subclass
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_collector_instance

# Generated at 2022-06-17 03:13:02.552657
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'
    assert virtual_facts.get_virtual_facts() == {}


# Generated at 2022-06-17 03:13:15.854538
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector

# Generated at 2022-06-17 03:13:17.130779
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-17 03:13:22.870975
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.platform == 'HP-UX'
    assert hv.get_virtual_facts() == {
        'virtualization_type': 'guest',
        'virtualization_role': 'HP nPar',
        'virtualization_tech_guest': set(['HP nPar']),
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-17 03:13:48.238897
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_subclass
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_collector_platforms
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_collector_subclass
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_collector_instance

# Generated at 2022-06-17 03:13:56.713096
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpu import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpu import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpu import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpu import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpu import _get_virtual_facts_platform
    from ansible.module_utils.facts.virtual.hpu import _get_virtual_facts_platform_by_platform
    from ansible.module_utils.facts.virtual.hpu import _get_virtual_facts_platform_by_distribution
    from ansible.module_utils.facts.virtual.hpu import _get_virtual_facts_platform_by

# Generated at 2022-06-17 03:13:59.308894
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:14:01.248399
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual({})
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-17 03:14:03.317299
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(dict())
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-17 03:14:05.940934
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:14:09.400379
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(dict())
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-17 03:14:17.937560
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Create a HPUXVirtual object
    hpux_virtual = HPUXVirtual()

    # Create a mock module
    mock_module = type('AnsibleModule', (object,), {
        'run_command': hpux_virtual.run_command
    })

    # Set module.run_command side effect
    def run_command(command):
        if command == '/usr/sbin/vecheck':
            return 0, '', ''
        elif command == '/opt/hpvm/bin/hpvminfo':
            return 0, 'Running HPVM vPar', ''
        elif command == '/usr/sbin/parstatus':
            return 0, '', ''
        else:
            return 1, '', ''

    mock_module.run_command = run_command

    # Set the module

# Generated at 2022-06-17 03:14:29.366021
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoCollector
    from ansible.module_utils.facts.virtual.hpux import Virtualization
    from ansible.module_utils.facts.virtual.hpux import VirtualizationCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualizationFactCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualizationFacts

# Generated at 2022-06-17 03:14:36.477079
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoModule
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoModuleCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoModuleParser
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoParser

# Generated at 2022-06-17 03:14:47.708964
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-17 03:14:49.872794
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'
    assert hv.get_virtual_facts() == {}


# Generated at 2022-06-17 03:14:59.948921
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvm
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvpar
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux

# Generated at 2022-06-17 03:15:01.616225
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-17 03:15:03.442819
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-17 03:15:12.151016
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoModule
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoModuleCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoModuleParser
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoModuleParserCollector

# Generated at 2022-06-17 03:15:13.929875
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(dict())
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-17 03:15:22.811937
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvm
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_npar
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_

# Generated at 2022-06-17 03:15:28.762081
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    import os
    import re
    import sys

    class MockModule(object):
        def __init__(self):
            self.run_command = Mock(return_value=(0, '', ''))

    class Mock(object):
        def __init__(self, *args, **kwargs):
            pass

        def __call__(self, *args, **kwargs):
            return Mock()


# Generated at 2022-06-17 03:15:36.428387
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual

    module = AnsibleModule(
        argument_spec = dict()
    )

    hpux_virtual = HPUXVirtual(module)
    virtual_facts = hpux_virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    assert virtual_facts['virtualization_tech_guest'] == set(['HP vPar'])
    assert virtual_facts['virtualization_tech_host'] == set()


# Generated at 2022-06-17 03:15:53.395014
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-17 03:15:55.130422
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:15:57.276502
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'
    assert virtual_facts.get_virtual_facts() == {}


# Generated at 2022-06-17 03:15:58.627608
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-17 03:15:59.973526
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:16:01.916815
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:16:03.564231
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-17 03:16:16.945099
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvm
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_npar
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_

# Generated at 2022-06-17 03:16:24.452367
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts

    # Create a mock module
    mock_module = type('AnsibleModule', (object,), {
        'run_command': lambda *_: (0, '', ''),
        'get_bin_path': lambda *_: '/bin/true',
    })()

    # Create a HPUXVirtual object
    hpux_virtual = HPUXVirtual(mock_module)

    # Create a Virtual object
    virtual = Virtual(mock_module)



# Generated at 2022-06-17 03:16:25.908061
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'
    assert virtual_facts.get_virtual_facts() == {}


# Generated at 2022-06-17 03:16:51.225611
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-17 03:16:55.657927
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(dict())
    assert hv.platform == 'HP-UX'
    assert hv.get_virtual_facts() == {'virtualization_type': 'guest', 'virtualization_role': 'HP nPar', 'virtualization_tech_guest': {'HP nPar'}, 'virtualization_tech_host': set()}

# Generated at 2022-06-17 03:17:04.111833
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux.hpux import test_HPUXVirtual_get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux.hpux import test_HPUXVirtualCollector_get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux.hpux import test_Virtual_get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux.hpux import test_VirtualCollector_get_virtual_

# Generated at 2022-06-17 03:17:05.395868
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(dict())
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-17 03:17:06.614299
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-17 03:17:16.734159
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_platform
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_platform_subclass
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_subclass
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_subclass

# Generated at 2022-06-17 03:17:18.024883
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:17:19.391979
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:17:22.015594
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'
    assert virtual_facts.get_virtual_facts() == {}

# Generated at 2022-06-17 03:17:29.847160
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector

# Generated at 2022-06-17 03:18:05.553381
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvm
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_npar
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_