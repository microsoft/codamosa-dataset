

# Generated at 2022-06-17 03:08:16.233259
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-17 03:08:24.728512
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual

# Generated at 2022-06-17 03:08:26.851259
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-17 03:08:28.618826
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'
    assert hv.get_virtual_facts() == {}

# Generated at 2022-06-17 03:08:31.197217
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:08:32.971235
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:08:34.992752
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-17 03:08:36.879470
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-17 03:08:45.886217
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector

# Generated at 2022-06-17 03:08:50.699841
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virtual_facts = HPUXVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    assert 'HP vPar' in virtual_facts['virtualization_tech_guest']
    assert 'HPVM vPar' in virtual_facts['virtualization_tech_guest']
    assert 'HPVM IVM' in virtual_facts['virtualization_tech_guest']
    assert 'HPVM' in virtual_facts['virtualization_tech_guest']
    assert 'HP nPar' in virtual_facts['virtualization_tech_guest']
    assert not virtual_facts['virtualization_tech_host']

# Generated at 2022-06-17 03:09:06.652230
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualFacts
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualMetaclass
    from ansible.module_utils.facts.virtual.hpux import VirtualNetworkInterface
    from ansible.module_utils.facts.virtual.hpux import VirtualNetworkInterfaceInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualNetworkInterfaceMetaclass

# Generated at 2022-06-17 03:09:10.264977
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-17 03:09:12.167783
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'
    assert virtual_facts.get_virtual_facts() == {}


# Generated at 2022-06-17 03:09:20.416662
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Create a dummy module
    module = AnsibleModule(argument_spec={})
    # Create a dummy class
    hpux_virtual = HPUXVirtual(module)
    # Create a dummy file
    with open('/usr/sbin/vecheck', 'w') as f:
        f.write('#!/usr/bin/sh\necho "HP vPar"')
    # Create a dummy file
    with open('/opt/hpvm/bin/hpvminfo', 'w') as f:
        f.write('#!/usr/bin/sh\necho "Running HPVM vPar"')
    # Create a dummy file
    with open('/usr/sbin/parstatus', 'w') as f:
        f.write('#!/usr/bin/sh\necho "HP nPar"')
    # Set execute permission

# Generated at 2022-06-17 03:09:22.590440
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-17 03:09:25.417690
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-17 03:09:32.159203
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    v = HPUXVirtual(module)
    facts = v.get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP vPar'
    assert facts['virtualization_tech_guest'] == set(['HP vPar'])
    assert facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:09:39.771185
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvm
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_npar
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_

# Generated at 2022-06-17 03:09:42.568307
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'
    assert hv.get_virtual_facts() == {}

# Generated at 2022-06-17 03:09:53.249917
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.posix import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.posix import PosixVirtual, PosixVirtualCollector
    from ansible.module_utils.facts.virtual.posix import LinuxVirtual, LinuxVirtualCollector
    from ansible.module_utils.facts.virtual.posix import OpenBSDVirtual, OpenBSDVirtualCollector

# Generated at 2022-06-17 03:10:07.522284
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'
    assert virtual_facts.get_virtual_facts() == {}


# Generated at 2022-06-17 03:10:10.289616
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:10:19.599116
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_subclass
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_collector_platforms
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_collector_subclass
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_collector_instance

# Generated at 2022-06-17 03:10:30.169523
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    import os
    import re
    import sys
    import unittest
    import tempfile
    import shutil

    class TestAnsibleModule(object):
        def __init__(self, params):
            self.params = params

        def run_command(self, cmd):
            return 0, '', ''

    class TestHPUXVirtual(HPUXVirtual):
        def __init__(self, module):
            self.module = module


# Generated at 2022-06-17 03:10:31.856432
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(dict())
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-17 03:10:40.644900
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_collector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_subclass
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_subclass_collector

    # Test for method get_virtual_facts of class HPUXVirtual
    # Test for virtualization_type = guest
    # Test for virtual

# Generated at 2022-06-17 03:10:50.773102
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual

# Generated at 2022-06-17 03:10:52.203324
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:11:00.644582
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual

# Generated at 2022-06-17 03:11:03.154604
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.platform == 'HP-UX'
    assert hv.get_virtual_facts() == {}


# Generated at 2022-06-17 03:11:18.494092
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector

    # Create a HPUXVirtual object
    hpux_virtual = HPUXVirtual()

    # Create a HPUXVirtualCollector object
    hpux_virtual_collector = HPUXVirtualCollector()

    # Create a Virtual object
    virtual = Virtual()

    # Create a VirtualCollector object
    virtual_collector = VirtualCollector()

    # Create a module object

# Generated at 2022-06-17 03:11:21.091240
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:11:23.778839
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:11:33.310798
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvm
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_npar
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_

# Generated at 2022-06-17 03:11:35.839406
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:11:38.645170
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'
    assert hv.get_virtual_facts() == {}


# Generated at 2022-06-17 03:11:45.884780
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvm
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_npar
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_

# Generated at 2022-06-17 03:11:48.673722
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'
    assert virtual_facts.get_virtual_facts() == {}


# Generated at 2022-06-17 03:11:58.521941
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import ansible.module_utils.facts.virtual.hpux as hpux
    import ansible.module_utils.facts.virtual.base as base
    import ansible.module_utils.facts.virtual.hpux as hpux
    import ansible.module_utils.facts.virtual.hpux as hpux
    import ansible.module_utils.facts.virtual.hpux as hpux
    import ansible.module_utils.facts.virtual.hpux as hpux
    import ansible.module_utils.facts.virtual.hpux as hpux
    import ansible.module_utils.facts.virtual.hpux as hpux
    import ansible.module_utils.facts.virtual.hpux as hpux
    import ansible.module_utils.facts.virtual.hpux as hpux

# Generated at 2022-06-17 03:11:59.874262
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:12:26.892076
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:12:37.229861
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtualization
    from ansible.module_utils.facts.virtual.hpux import VirtualizationCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualizationFactory
    from ansible.module_utils.facts.virtual.hpux import VirtualizationFactoryCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualizationFactoryCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualizationFactoryCollector

# Generated at 2022-06-17 03:12:38.688752
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:12:41.116500
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:12:50.987919
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualFacts
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualMetaclass
    from ansible.module_utils.facts.virtual.hpux import VirtualNetwork
    from ansible.module_utils.facts.virtual.hpux import VirtualSubclass
    from ansible.module_utils.facts.virtual.hpux import VirtualSub

# Generated at 2022-06-17 03:12:52.950171
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(dict())
    assert hv.platform == 'HP-UX'
    assert hv.get_virtual_facts() == {}

# Generated at 2022-06-17 03:12:59.374281
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvm
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_npar
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_

# Generated at 2022-06-17 03:13:02.006211
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-17 03:13:03.420117
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:13:16.252100
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_subclass
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_collector_platforms
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_collector_subclass
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_collector_init

# Generated at 2022-06-17 03:13:42.968680
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:13:44.818397
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:13:47.255324
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:13:56.066957
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_subclass
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_collector_platforms
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_collector_subclass
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_collector_init

# Generated at 2022-06-17 03:13:58.020710
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:14:00.146876
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict())
    assert virtual.platform == 'HP-UX'


# Generated at 2022-06-17 03:14:10.720246
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import test_HPUXVirtual_get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import test_HPUXVirtualCollector_get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import test_Virtual_get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import test_VirtualCollector_get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import test_Virtual

# Generated at 2022-06-17 03:14:21.830814
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoCollector
    from ansible.module_utils.facts.virtual.hpux import Virtualization
    from ansible.module_utils.facts.virtual.hpux import VirtualizationCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualizationFactCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualizationFacts

# Generated at 2022-06-17 03:14:23.755574
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-17 03:14:33.492703
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoModule
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoModuleCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoModuleParser
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoModuleParserCollector

# Generated at 2022-06-17 03:14:58.094507
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.platform == 'HP-UX'
    assert hv.get_virtual_facts() == {'virtualization_type': 'guest', 'virtualization_role': 'HP vPar', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set(['HP vPar'])}


# Generated at 2022-06-17 03:14:59.630058
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:15:01.047736
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:15:02.987423
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:15:16.290724
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_platform_specific
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_platform_specific_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_platform_specific_hpux_HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import _get

# Generated at 2022-06-17 03:15:18.245612
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:15:20.028959
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.platform == 'HP-UX'
    assert hv.get_virtual_facts() == {}

# Generated at 2022-06-17 03:15:26.584686
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvm
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvpar
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux

# Generated at 2022-06-17 03:15:28.004258
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-17 03:15:37.106805
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector

# Generated at 2022-06-17 03:16:18.177801
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual

# Generated at 2022-06-17 03:16:19.599597
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-17 03:16:21.266026
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-17 03:16:27.763048
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import ansible.module_utils.facts.virtual.hpux as hpux
    import ansible.module_utils.facts.virtual.base as base
    import ansible.module_utils.facts.virtual.hpux as hpux
    import ansible.module_utils.facts.virtual.hpux as hpux
    import ansible.module_utils.facts.virtual.hpux as hpux
    import ansible.module_utils.facts.virtual.hpux as hpux
    import ansible.module_utils.facts.virtual.hpux as hpux
    import ansible.module_utils.facts.virtual.hpux as hpux
    import ansible.module_utils.facts.virtual.hpux as hpux
    import ansible.module_utils.facts.virtual.hpux as hpux

# Generated at 2022-06-17 03:16:37.608829
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import VirtualFacts
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoFacts
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoParams

# Generated at 2022-06-17 03:16:39.893478
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(dict())
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-17 03:16:41.719021
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(dict())
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-17 03:16:44.479746
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:16:54.687183
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvm
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_vpar
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_

# Generated at 2022-06-17 03:17:03.312548
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector

# Generated at 2022-06-17 03:17:43.687231
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_subclass
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_collector_platforms
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_collector_subclass
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_collector_init_subclass

# Generated at 2022-06-17 03:17:45.790507
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:17:53.749641
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvm
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvpar
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux

# Generated at 2022-06-17 03:17:58.852840
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvm
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvpar
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux

# Generated at 2022-06-17 03:18:00.693541
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:18:07.960984
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
   