

# Generated at 2022-06-17 03:08:16.772454
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:08:25.312523
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvm
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvpar
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux

# Generated at 2022-06-17 03:08:27.182746
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:08:36.682518
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualFacts
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualMetaclass
    from ansible.module_utils.facts.virtual.hpux import VirtualNetwork
    from ansible.module_utils.facts.virtual.hpux import VirtualSubclass
    from ansible.module_utils.facts.virtual.hpux import VirtualSub

# Generated at 2022-06-17 03:08:38.079977
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-17 03:08:47.140050
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoModule
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoModuleCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoModuleParser
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoParser

# Generated at 2022-06-17 03:08:52.073063
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_subclass
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_collector_platforms
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_collector_subclass
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_collector_classes

# Generated at 2022-06-17 03:08:54.368523
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual({})
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-17 03:09:04.471492
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector

# Generated at 2022-06-17 03:09:07.866400
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:09:22.721771
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvm
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_npar
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_

# Generated at 2022-06-17 03:09:34.062807
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualFacts
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualMetaclass
    from ansible.module_utils.facts.virtual.hpux import VirtualNetworkInterface
    from ansible.module_utils.facts.virtual.hpux import VirtualNetworkInterfaceFacts
    from ansible.module_utils.facts.virtual.hpux import VirtualNetworkInterfaceInfo

# Generated at 2022-06-17 03:09:35.225591
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:09:41.768570
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtualization
    from ansible.module_utils.facts.virtual.hpux import VirtualizationCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualizationFactory

    # Create a HPUXVirtual object
    hpux_virtual = HPUXVirtual()

    # Create a Virtualization object
    virtualization = Virtualization()

    # Create a VirtualizationFactory object
    virtualization_factory = VirtualizationFactory()

    # Create a VirtualizationCollector object
    virtualization_

# Generated at 2022-06-17 03:09:52.574986
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_collector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_collector_class
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hp

# Generated at 2022-06-17 03:10:01.448873
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoCollector
    from ansible.module_utils.facts.virtual.hpux import Virtualization
    from ansible.module_utils.facts.virtual.hpux import VirtualizationCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualizationFactCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualizationFacts

# Generated at 2022-06-17 03:10:02.366396
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:10:04.635545
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-17 03:10:17.926272
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector

# Generated at 2022-06-17 03:10:27.144949
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
   

# Generated at 2022-06-17 03:10:43.699443
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector

# Generated at 2022-06-17 03:10:46.147059
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:10:54.769215
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux

    # Test with HP-UX virtualization facts
    virtual_facts = _get_virtual_facts_hpux()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'

# Generated at 2022-06-17 03:10:56.333985
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-17 03:10:58.300069
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual({})
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-17 03:11:02.049216
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector

# Generated at 2022-06-17 03:11:03.616213
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:11:16.697642
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoModule
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoModuleCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoModuleParser
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoModuleParserCollector

# Generated at 2022-06-17 03:11:20.523489
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'
    assert hv.get_virtual_facts() == {}


# Generated at 2022-06-17 03:11:30.915801
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvm
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_npar
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_

# Generated at 2022-06-17 03:11:44.987045
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:11:47.364313
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict())
    assert virtual.platform == 'HP-UX'


# Generated at 2022-06-17 03:11:57.336526
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux

    # Test case 1:
    #   - HP-UX 11.31
    #   - HPVM IVM
    #   - HPVM vPar
    #   - HPVM guest
    #   - HPVM host
    #   - HP nPar
    #   - HP vPar
    #   - virtualization_type = guest
    #   - virtual

# Generated at 2022-06-17 03:11:58.797275
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:12:06.734175
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    import os
    import re


# Generated at 2022-06-17 03:12:13.408933
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvm
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvpar
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux

# Generated at 2022-06-17 03:12:23.463899
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvm
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_npar
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_

# Generated at 2022-06-17 03:12:29.849091
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux

    # Test for virtualization_type and virtualization_role
    # when vecheck exists and returns 0
    module = MockModule()
    module.run_command = Mock(return_value=(0, '', ''))
    virtual = HPUXVirtual(module)
    virtual_facts = virtual.get_virtual_facts()

# Generated at 2022-06-17 03:12:32.672978
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'
    assert virtual_facts.get_virtual_facts() == {}


# Generated at 2022-06-17 03:12:42.554594
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual

# Generated at 2022-06-17 03:13:01.774630
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'
    assert hpux_virtual.get_virtual_facts() == {}


# Generated at 2022-06-17 03:13:03.177962
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-17 03:13:16.168191
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual

# Generated at 2022-06-17 03:13:17.468450
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-17 03:13:28.011757
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualFacts
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualMetaclass
    from ansible.module_utils.facts.virtual.hpux import VirtualNetworkInterface
    from ansible.module_utils.facts.virtual.hpux import VirtualNetworkInterfaces
    from ansible.module_utils.facts.virtual.hpux import VirtualSubclass

# Generated at 2022-06-17 03:13:34.142625
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualFacts
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualMetaclass
    from ansible.module_utils.facts.virtual.hpux import VirtualNetworkInterface
    from ansible.module_utils.facts.virtual.hpux import VirtualNetworkInterfaceInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualNetworkInterfaceMetaclass

# Generated at 2022-06-17 03:13:44.658855
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualInfoCollector
    from ansible.module_utils.facts.virtual.hpux import Virtualization
    from ansible.module_utils.facts.virtual.hpux import VirtualizationCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualizationFactCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualizationFacts

# Generated at 2022-06-17 03:13:54.824913
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_collector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_platform
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_subclass
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_subclass_collector

# Generated at 2022-06-17 03:14:05.853351
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector

# Generated at 2022-06-17 03:14:08.707289
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:14:19.908496
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-17 03:14:22.143228
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-17 03:14:24.066873
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:14:26.480335
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-17 03:14:32.683902
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector

# Generated at 2022-06-17 03:14:44.797997
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo

    class ModuleMock(object):
        def __init__(self):
            self.params = {}
            self.run_command_environ_update = {}

        def run_command(self, cmd, check_rc=True, environ_update=None):
            if cmd == "/usr/sbin/vecheck":
                return 0, "", ""

# Generated at 2022-06-17 03:14:47.078877
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:14:56.853256
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual

# Generated at 2022-06-17 03:15:04.286266
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_from_collectors
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_collectors
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_collectors_from_platforms
    from ansible.module_utils.facts.virtual.hpux import _get_platforms

# Generated at 2022-06-17 03:15:05.750548
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:15:26.545781
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvm
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvpar
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux

# Generated at 2022-06-17 03:15:35.682172
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_vpar
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvm
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_

# Generated at 2022-06-17 03:15:37.070511
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:15:45.931950
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualFacts
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualMetaclass
    from ansible.module_utils.facts.virtual.hpux import VirtualNetworkInterface
    from ansible.module_utils.facts.virtual.hpux import VirtualNetworkInterfaceInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualNetworkInterfaceMetaclass

# Generated at 2022-06-17 03:15:47.792212
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-17 03:15:50.001716
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.platform == 'HP-UX'
    assert hv.get_virtual_facts() == {}


# Generated at 2022-06-17 03:15:52.772827
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'
    assert virtual_facts.get_virtual_facts() == {}

# Generated at 2022-06-17 03:15:54.432724
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-17 03:15:56.371277
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-17 03:15:57.756609
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-17 03:16:20.615229
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import ModuleStub
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import test_HPUXVirtual_get_virtual_facts

    # Create a stub module
    module = ModuleStub()

    # Create a stub class
    class StubClass:
        def __init__(self, module):
            self.module = module

    # Create a stub object
    obj = StubClass(module)

    # Create a stub Virtual class

# Generated at 2022-06-17 03:16:27.356723
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_platform_specific
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_platform_specific_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_platform_specific_hpux_HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import _get

# Generated at 2022-06-17 03:16:29.654607
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:16:38.330258
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_collector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_subclass
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_subclass_collector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_platform

# Generated at 2022-06-17 03:16:40.375996
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:16:50.974764
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector

# Generated at 2022-06-17 03:16:52.839229
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:17:01.774248
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import get_virtual_subclass
    from ansible.module_utils.facts.virtual.hpux import get_virtual_subclass_by_platform
    from ansible.module_utils.facts.virtual.hpux import get_virtual_subclass_by_virttype
    from ansible.module_utils.facts.virtual.hpux import get_virtual_subclass_by_platform_and_virttype
   

# Generated at 2022-06-17 03:17:03.498680
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-17 03:17:05.892927
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-17 03:17:46.688605
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import VirtualFacts
    from ansible.module_utils.facts.virtual.hpux import VirtualInfo
    from ansible.module_utils.facts.virtual.hpux import VirtualMetaclass
    from ansible.module_utils.facts.virtual.hpux import VirtualNetworkInterface
    from ansible.module_utils.facts.virtual.hpux import VirtualNetworkInterfaceFacts
    from ansible.module_utils.facts.virtual.hpux import VirtualNetworkInterfaceInfo

# Generated at 2022-06-17 03:17:48.192644
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-17 03:17:55.739609
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvm
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux_hpvpar
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux

# Generated at 2022-06-17 03:17:59.706172
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict())
    assert virtual.platform == 'HP-UX'


# Generated at 2022-06-17 03:18:07.485068
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux

    # Test with vecheck
    module = MockModule()
    module.run_command = Mock(return_value=(0, '', ''))
    os.path.exists = Mock(return_value=True)
    virtual_facts = _get_virtual_facts(module)
    assert virtual_facts['virtualization_type'] == 'guest'
   