

# Generated at 2022-06-25 01:07:50.214852
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()


# Generated at 2022-06-25 01:07:51.906588
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    test_case_0()

# Generating test cases
if __name__ == '__main__':
    test_HPUXVirtual()

# Generated at 2022-06-25 01:07:58.200745
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    facts = {'ansible_distribution_release': '11.31', 'ansible_architecture': 'ia64', 'virtualization_role': 'HPVM IVM', 'ansible_distribution': 'HP-UX', 'ansible_os_family': 'HP-UX', 'virtualization_type': 'guest', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}
    h_p_u_x_virtual_0 = HPUXVirtual(facts, None)
    assert h_p_u_x_virtual_0._platform == 'HP-UX'
    assert h_p_u_x_virtual_0.virtual == facts['virtualization_type']
    assert h_p_u_x_virtual_0.role == facts['virtualization_role']


# Generated at 2022-06-25 01:08:03.563127
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual({})
    h_p_u_x_virtual_dict_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert('virtualization_tech_guest' in h_p_u_x_virtual_dict_0)
    assert('virtualization_tech_host' in h_p_u_x_virtual_dict_0)


# Generated at 2022-06-25 01:08:04.861601
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_collector_0 = HPUXVirtualCollector()

# Generated at 2022-06-25 01:08:05.600998
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()

# Generated at 2022-06-25 01:08:06.515916
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:08:08.774937
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    virtual_facts = h_p_u_x_virtual_0.get_virtual_facts()
    assert virtual_facts == {}

# Generated at 2022-06-25 01:08:12.730738
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(dict())
    assert h_p_u_x_virtual_0._platform == 'HP-UX'
    assert h_p_u_x_virtual_0.virtual == dict()


# Generated at 2022-06-25 01:08:14.303507
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    obj1 = HPUXVirtual()
    obj1.module = ""
    obj2 = HPUXVirtual(data="",module="")



# Generated at 2022-06-25 01:08:25.602800
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual = HPUXVirtual()
    assert h_p_u_x_virtual.get_virtual_facts()

# Generated at 2022-06-25 01:08:32.266732
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_object = HPUXVirtual(None)

    # Test for method get_virtual_facts of class HPUXVirtual
    virtual_facts = h_p_u_x_virtual_object.get_virtual_facts()
    virtual_facts = h_p_u_x_virtual_object.get_virtual_facts()
    h_p_u_x_virtual_object = HPUXVirtual(None)
    virtual_facts = h_p_u_x_virtual_object.get_virtual_facts()
    assert isinstance(virtual_facts, dict) is True
    assert virtual_facts == {}



# Generated at 2022-06-25 01:08:33.892494
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()

    assert h_p_u_x_virtual_0.get_virtual_facts() is None

# Generated at 2022-06-25 01:08:37.672272
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Test get_virtual_facts of class HPUXVirtual
    """
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:08:43.668824
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0._module.get_bin_path = lambda x: '/bin/'
    h_p_u_x_virtual_0._module.run_command = lambda x: ('','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','')
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:08:48.725349
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.get_virtual_facts() == dict(virtualization_type=None, virtualization_role=None, virtualization_technologies=set())

if __name__ == "__main__":
    test_case_0()
    test_HPUXVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:08:55.372520
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module.run_command = lambda x: (0, "", "")
    h_p_u_x_virtual_0.module.params = {'gather_subset': ['all']}
    h_p_u_x_virtual_0.module.tmpdir = './ansible/tmp'
    h_p_u_x_virtual_0.module.exit_json = lambda x: x
    h_p_u_x_virtual_0.module.fail_json = lambda msg: msg
    os.path.exists = lambda x: True
    facts = h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:08:58.092786
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.get_virtual_facts() == {}


# Generated at 2022-06-25 01:09:02.044251
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    # Check if method get_virtual_facts() returns a value
    assert h_p_u_x_virtual_0.get_virtual_facts() != None


# Generated at 2022-06-25 01:09:03.208893
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:09:19.223187
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()

# Generated at 2022-06-25 01:09:22.684302
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = None
    fact_class = HPUXVirtual(module)
    virtual_facts = fact_class.get_virtual_facts()
    assert virtual_facts['virtualization_tech_guest'] == set(['HPVM'])
    assert virtual_facts['virtualization_tech_host'] == set([])
    assert virtual_facts['virtualization_type'] == 'host'
    assert virtual_facts['virtualization_role'] == 'HPVM'


# Generated at 2022-06-25 01:09:31.797704
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module.run_command = FakeRunCommand()

# Generated at 2022-06-25 01:09:37.214609
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0._module = MockModule()
    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_type': 'guest', 'virtualization_role': 'HPVM guest'}


# Generated at 2022-06-25 01:09:39.296435
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:09:41.953529
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    #  TODO: These test case should be executed in a VM. Then the dict can be asserted
    assert h_p_u_x_virtual_0.get_virtual_facts() == {}


# Generated at 2022-06-25 01:09:43.085537
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual = HPUXVirtual(dict(module=dict()))


# Generated at 2022-06-25 01:09:47.849235
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    print(':::::')
    h_p_u_x_virtual_collector_0 = HPUXVirtualCollector()
    a = h_p_u_x_virtual_collector_0.collect()
    print(a)
    print(':::::')


# Generated at 2022-06-25 01:09:55.285435
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module.run_command = mock_run_command_0
    h_p_u_x_virtual_0.module.run_command.return_value = (0, 'hpvminfo: Running HPVM host', '')
    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_role': 'HPVM',
                                                     'virtualization_type': 'host',
                                                     'virtualization_tech_host': {'HPVM'},
                                                     'virtualization_tech_guest': {}}


# Generated at 2022-06-25 01:09:56.885797
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:10:11.914216
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # Constructor test case #0 with args
    h_p_u_x_virtual_0 = HPUXVirtual(dict(module=None))


# Generated at 2022-06-25 01:10:16.089018
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.get_virtual_facts() is None, "HPUXVirtual.get_virtual_facts() is not returning None"


# Generated at 2022-06-25 01:10:22.142828
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual('/path/to/ansible_module')
    h_p_u_x_virtual_0.module.run_command = Mock(return_value=(0, 'out', 'err'))
    h_p_u_x_virtual_0.facts['virtualization_technologies_guest'] = set()
    h_p_u_x_virtual_0.facts['virtualization_technologies_host'] = set()
    h_p_u_x_virtual_0.get_virtual_facts()
    if h_p_u_x_virtual_0.facts['virtualization_technologies_host'] == set():
        pass
    else:
        assert False

# Generated at 2022-06-25 01:10:26.204938
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module_args = dict()

    g = HPUXVirtual(module_args)

    # get_virtual_facts method of class HPUXVirtual
    out = g.get_virtual_facts()
    assert isinstance(out, dict)


# Generated at 2022-06-25 01:10:32.267316
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all'], type='list')
        )
    )
    # Ignore platform check, we test only the behavior of HPUXVirtual
    h_p_u_x_virtual_0 = HPUXVirtual(module, ['!all'])
    h_p_u_x_virtual_1 = HPUXVirtual(module)
    # The results are not exact, perhaps a bug in fact_collector?
    h_p_u_x_virtual_2 = HPUXVirtual(module, ['all'])


# Generated at 2022-06-25 01:10:32.706083
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual()

# Generated at 2022-06-25 01:10:39.860023
# Unit test for constructor of class HPUXVirtual

# Generated at 2022-06-25 01:10:46.073443
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_get_virtual_facts_0 = HPUXVirtual()
    h_p_u_x_virtual_get_virtual_facts_0._module = {}
    h_p_u_x_virtual_get_virtual_facts_0._module['run_command'] = True
    h_p_u_x_virtual_get_virtual_facts_0.module = {}
    h_p_u_x_virtual_get_virtual_facts_0.module['run_command'] = True

    assert {} == h_p_u_x_virtual_get_virtual_facts_0.get_virtual_facts()


# Generated at 2022-06-25 01:10:49.511249
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.get_virtual_facts()

if __name__ == '__main__':
    test_case_0()
    # test_HPUXVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:10:50.708229
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual().get_virtual_facts()['virtualization_type'] == 'none'


# Generated at 2022-06-25 01:11:04.300327
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.platform == 'HP-UX'


# Generated at 2022-06-25 01:11:08.094252
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    
    # Setup test data
    h_p_u_x_virtual_0 = HPUXVirtual()
    
    # Invoke method
    result = h_p_u_x_virtual_0.get_virtual_facts()
    
    # Test assertions
    pass


if __name__ == '__main__':
    test_case_0()
    test_HPUXVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:11:14.549665
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module = None
    h_p_u_x_virtual_0.get_virtual_facts()

if __name__ == '__main__':
    test_case_0()
    test_HPUXVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:11:23.590160
# Unit test for constructor of class HPUXVirtual

# Generated at 2022-06-25 01:11:25.224554
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual() is not None


# Generated at 2022-06-25 01:11:27.861376
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual = HPUXVirtual(module=None)
    h_p_u_x_virtual.module.run_command = run_command_mock
    h_p_u_x_virtual.module.params = {}
    h_p_u_x_virtual.get_virtual_facts()


# Generated at 2022-06-25 01:11:31.055854
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0_virtual_facts = h_p_u_x_virtual_0.get_virtual_facts()

if __name__ == '__main__':
    test_case_0()
    test_HPUXVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:11:32.161591
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    test_case_0()
    h_p_u_x_virtual_0 = HPUXVirtual()

# Generated at 2022-06-25 01:11:37.008158
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module.run_command = lambda x: (0, 'system type:', '')
    h_p_u_x_virtual_0.module.run_command = lambda x: (0, 'uname -r:', '')
    h_p_u_x_virtual_0.module.run_command = lambda x: (0, '#', '')
    h_p_u_x_virtual_0.module.run_command = lambda x: (0, "cat /proc/cpuinfo | grep 'model name'", '')
    h_p_u_x_virtual_0.module.run_command = lambda x: (0, 'hardware platform:', '')
    h_p_

# Generated at 2022-06-25 01:11:39.155997
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:11:53.692164
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual_0 = HPUXVirtual()

# Generated at 2022-06-25 01:12:03.029565
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0._module.get_bin_path = mock_get_bin_path
    h_p_u_x_virtual_0._module.run_command = mock_run_command
    h_p_u_x_virtual_0._module.params = {'gather_subset': set(['!all', 'virtual'])}
    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_type': 'guest', 'virtualization_role': 'HP vPar', 'virtualization_type_role': 'guest:HP vPar', 'virtualization_tech_guest': {'HP vPar'}}


# Generated at 2022-06-25 01:12:05.916952
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


if __name__ == '__main__':
    for test_func in [test_case_0, test_HPUXVirtual]:
        test_func()

# Generated at 2022-06-25 01:12:08.111695
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    Unit test for constructor of class HPUXVirtual
    """
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.platform == "HP-UX"


# Generated at 2022-06-25 01:12:12.428090
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    class HPUXVirtual_class():
        def __init__(self, dict={}):
            attrs = dict
            self.os = attrs.get('os', {})
            self.module = attrs.get('module', {})
            self.module.run_command = HPUXVirtual_class.my_run_command
            self.virtual = attrs.get('virtual', {})
        @staticmethod
        def my_run_command(cmd):
            from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
            return HPUXVirtual_class.run_command_map.get(cmd, (0, "", ""))
        run_command_map = {}
    facts = {}
    inst = H

# Generated at 2022-06-25 01:12:17.056020
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()

# Generated at 2022-06-25 01:12:19.890229
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0_get_virtual_facts = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:12:20.792740
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual(dict())


# Generated at 2022-06-25 01:12:25.024357
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(dict(http_header=dict()))
    assert h_p_u_x_virtual_0 is not None


# Generated at 2022-06-25 01:12:26.676362
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:12:44.111614
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()

# Generated at 2022-06-25 01:12:45.889543
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.platform == 'HP-UX'


# Generated at 2022-06-25 01:12:49.571515
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:12:51.358903
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = AnsibleModule(
        argument_spec = dict()
    )
    h_p_u_x_virtual_0 = HPUXVirtual(module)


# Generated at 2022-06-25 01:12:57.087401
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(mock_module_0)
    assert h_p_u_x_virtual_0 is not None


# Generated at 2022-06-25 01:12:58.943389
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    os.environ['ANSIBLE_FACT_CACHE'] = None
    virtual_facts = HPUXVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()


# Generated at 2022-06-25 01:13:08.967601
# Unit test for method get_virtual_facts of class HPUXVirtual

# Generated at 2022-06-25 01:13:12.086308
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()


# Generated at 2022-06-25 01:13:15.592226
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}


# Generated at 2022-06-25 01:13:17.349722
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    out = HPUXVirtual()
    assert out


# Generated at 2022-06-25 01:13:28.412905
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.get_virtual_facts() == {}


# Generated at 2022-06-25 01:13:31.127851
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0 is not None


# Generated at 2022-06-25 01:13:32.582923
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual.platform == 'HP-UX'


# Generated at 2022-06-25 01:13:42.340635
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module = MockModule()
    h_p_u_x_virtual_0.module.run_command = run_command_mock
    h_p_u_x_virtual_0.module.run_command.side_effect = [(0, 'out', 'err')]
    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_tech_guest': set(['HP nPar']), 'virtualization_role': 'HP nPar', 'virtualization_type': 'guest', 'virtualization_tech_host': set()}

    h_p_u_x_virtual_1 = HPUXVirtual()
    h_p_u_x_virtual

# Generated at 2022-06-25 01:13:44.843227
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual(dict())
    h_p_u_x_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:13:48.544143
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()
    assert h_p_u_x_virtual._platform == 'HP-UX'


# Generated at 2022-06-25 01:13:49.172806
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-25 01:13:53.429982
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(ansible_module=None)
    assert h_p_u_x_virtual_0.platform == 'HP-UX'


# Generated at 2022-06-25 01:14:03.906863
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()

    h_p_u_x_virtual_0.module.run_command = MagicMock(return_value=(0, 'out', 'err'))
    h_p_u_x_virtual_0.module.run_command.return_value = (0, 'out', 'err')
    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_role': 'HP vPar', 'virtualization_type': 'guest', 'virtualization_tech_guest': {'HP vPar'}, 'virtualization_tech_host': set()}

    h_p_u_x_virtual_0.module.run_command.return_value = (0, 'out', 'err')
    assert h_p_

# Generated at 2022-06-25 01:14:06.199834
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.get_virtual_facts() is not None

# Generated at 2022-06-25 01:14:19.340389
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    assert not test_case_0()


# Generated at 2022-06-25 01:14:21.399620
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    test_case_0()


# Generated at 2022-06-25 01:14:23.226907
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():

    str_0 = '%s.%d'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    #This will be true if the constructor did not fail
    bool_0 = bool(h_p_u_x_virtual_0)



# Generated at 2022-06-25 01:14:27.697800
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = '%s.%d'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:14:38.282987
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = '%s.%d'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    assert h_p_u_x_virtual_0._platform == 'HP-UX'
    assert h_p_u_x_virtual_0._module.params[str_0] is not None
    assert h_p_u_x_virtual_0._module.params['run_command'].__name__ == 'run_command'
    assert h_p_u_x_virtual_0._module.params['get_file_content'].__name__ == 'get_file_content'
    assert h_p_u_x_virtual_0._module.check_mode is False
    assert h_p_u_x_virtual_0._module.debug is False
    assert h

# Generated at 2022-06-25 01:14:41.046629
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual('/tmp/ansible_facts.i0jwAJ/ansible_facts.json').get_virtual_facts() == {'virtualization_role': 'HP nPar', 'virtualization_tech_guest': {'HP nPar'}, 'virtualization_tech_host': set(), 'virtualization_type': 'guest'}


# Generated at 2022-06-25 01:14:44.149214
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    var_1 = HPUXVirtual('hostname')
    if var_1 is not None:
        var_2 = var_1.get_virtual_facts()


# Generated at 2022-06-25 01:14:51.214806
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    print('Test "HPUXVirtual" constructor')
    h_p_u_x_virtual_0 = HPUXVirtual('arg_0')
    assert isinstance(h_p_u_x_virtual_0, HPUXVirtual)
    assert hasattr(h_p_u_x_virtual_0, 'platform')
    assert hasattr(h_p_u_x_virtual_0, 'module')


# Generated at 2022-06-25 01:14:57.986609
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = '%s.%d'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    assert h_p_u_x_virtual_0._platform == 'HP-UX'
    assert h_p_u_x_virtual_0.platform == 'HP-UX'
    assert h_p_u_x_virtual_0._fact_class == HPUXVirtual

# Unit test method in class HPUXVirtual

# Generated at 2022-06-25 01:15:00.605284
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = '%s.%d'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_type': 'guest', 'virtualization_role': 'HP nPar', 'virtualization_tech_host': set(), 'virtualization_tech_guest': {'HP nPar'}}

# Generated at 2022-06-25 01:15:15.115313
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    test_case_0()

# Generated at 2022-06-25 01:15:16.912172
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = '%s.%d'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:15:21.851358
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = '%s.%d'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    # gosh
    # h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:15:27.461685
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = '%s.%d'
    var_0 = HPUXVirtual(str_0)
    assert isinstance(var_0, HPUXVirtual)==True, "TestCase 0 failed."


# Generated at 2022-06-25 01:15:30.233841
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = '%s.%d'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    params_0 = 'w'
    h_p_u_x_virtual_0.module(params_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:15:34.554443
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    var_0 = HPUXVirtual('this.is.my.fqdn')
    var_1 = var_0.get_virtual_facts()
    assert var_1['virtualization_type'] == 'guest'
    assert var_1['virtualization_role'] == 'HP nPar'

# Generated at 2022-06-25 01:15:40.371109
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = '%s.%d'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:15:46.572363
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # Test with freebsd's module
    # Create a new function that accepts a system's module
    module_0 = AnsibleModule(argument_spec={})
    h_p_u_x_virtual_0 = HPUXVirtual(module_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    # get_virtual_facts() returns a dict
    assert 'virtualization_type' in var_0
    assert 'virtualization_role' in var_0
    assert 'virtualization_tech_guest' in var_0
    assert 'virtualization_tech_host' in var_0
    assert 'virtualization_tech' in var_0
    # h_p_u_x_virtual_0.virtualization_type is string

# Generated at 2022-06-25 01:15:49.485261
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = '%s.%d'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 == None


# Generated at 2022-06-25 01:15:50.784507
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = '%s.%d'
    var_1 = HPUXVirtual(str_0)
    return var_1


# Generated at 2022-06-25 01:16:23.141587
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = '%s.%d'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:16:26.608808
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = '%s.%d'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)


# Generated at 2022-06-25 01:16:29.487362
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    assert False # TODO: Write unit test.


# Generated at 2022-06-25 01:16:34.901046
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = ': %d'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    assert h_p_u_x_virtual_0._platform == 'HP-UX'


# Generated at 2022-06-25 01:16:41.063851
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = '!C]_%(6U{'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:16:43.409550
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = '%s.%d'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:16:48.915064
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module = MagicMock()
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    # Nothing to validate here


# Generated at 2022-06-25 01:16:51.758677
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = '%s.%d'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 == {}


# Generated at 2022-06-25 01:16:57.445439
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_1 = '%s.%d'
    h_p_u_x_virtual_1 = HPUXVirtual(str_1)
    result = h_p_u_x_virtual_1.get_virtual_facts()
    assert 'virtualization_type' in result
    assert result['virtualization_type'] == 'guest'
    assert 'virtualization_tech_host' in result
    assert result['virtualization_tech_host'] == set()
    assert 'virtualization_role' in result
    assert result['virtualization_role'] == 'HP nPar'
    assert 'virtualization_tech_guest' in result
    assert result['virtualization_tech_guest'] == set(['HP nPar'])


if __name__ == '__main__':
    test_case_0()
    test_H

# Generated at 2022-06-25 01:17:06.109417
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    var_1 = HPUXVirtual(os.path.sep)
    var_2 = var_1.get_virtual_facts()


if __name__ == '__main__':
    ans_0 = os.path.sep
    h_p_u_x_virtual_0 = HPUXVirtual(ans_0)
    var_3 = h_p_u_x_virtual_0.get_virtual_facts()
    ans_0 = os.path.sep
    h_p_u_x_virtual_collector_0 = HPUXVirtualCollector(ans_0)
    var_4 = h_p_u_x_virtual_collector_0.collect()

# Generated at 2022-06-25 01:17:36.508810
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = '%s.%d'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)


# Generated at 2022-06-25 01:17:41.092424
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = 'J3_%*b0a'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()