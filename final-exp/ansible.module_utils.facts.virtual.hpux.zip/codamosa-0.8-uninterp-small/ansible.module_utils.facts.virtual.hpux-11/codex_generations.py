

# Generated at 2022-06-25 01:07:46.467162
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module.run_command = lambda x: (0, '', '')
    res = h_p_u_x_virtual_0.get_virtual_facts()
    assert res['virtualization_type'] == 'guest'
    assert res['virtualization_role'] == 'HP vPar'


# Generated at 2022-06-25 01:07:48.393893
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


if __name__ == '__main__':
    test_HPUXVirtual()

# Generated at 2022-06-25 01:07:51.540535
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    virtual_facts = h_p_u_x_virtual_0.get_virtual_facts()
    assert 'virtualization_role' in virtual_facts.keys()
    assert 'virtualization_type' in virtual_facts.keys()

# Generated at 2022-06-25 01:07:53.811073
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    test_case_0()
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert True, "Constructor of class HPUXVirtual did not return True"


# Generated at 2022-06-25 01:07:56.190346
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(None)
    # ValueError if parameter 'module' is None.
    try:
        h_p_u_x_virtual_0 = HPUXVirtual(None)
    except ValueError:
        pass

# Generated at 2022-06-25 01:07:57.457893
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()

# Unit tests for methods of class HPUXVirtual

# Generated at 2022-06-25 01:08:05.639960
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    virtual_facts = {}
    host_tech = set()
    guest_tech = set()
    if os.path.exists('/usr/sbin/vecheck'):
        rc, out, err = HPUXVirtual().module.run_command("/usr/sbin/vecheck")
        if rc == 0:
            guest_tech.add('HP vPar')
            virtual_facts['virtualization_type'] = 'guest'
            virtual_facts['virtualization_role'] = 'HP vPar'
    if os.path.exists('/opt/hpvm/bin/hpvminfo'):
        rc, out, err = HPUXVirtual().module.run_command("/opt/hpvm/bin/hpvminfo")

# Generated at 2022-06-25 01:08:07.086426
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    test_case_0()

# Generated at 2022-06-25 01:08:13.582734
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    data_dict = {'virtualization_tech_host': set([]), 'virtualization_tech_guest': set(['HPVM IVM']), 'virtualization_role': 'HPVM IVM', 'virtualization_type': 'guest'}
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module = {"run_command": {"rc": 0, "out": "Running HPVM guest", "err": ""}}
    assert h_p_u_x_virtual_0.get_virtual_facts() == data_dict


# Generated at 2022-06-25 01:08:18.830605
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    obj = h_p_u_x_virtual_0.get_virtual_facts()
    assert 'virtualization_type' in obj
    assert 'virtualization_role' in obj
    assert 'virtualization_tech_host' in obj
    assert 'virtualization_tech_guest' in obj
    assert 'virtualization_host_type' not in obj
    assert 'virtualization_host_role' not in obj
    assert 'virtualization_host_uuid' not in obj
    assert 'virtualization_host_name' not in obj
    assert 'virtualization_guest_type' not in obj
    assert 'virtualization_guest_uuid' not in obj
    assert 'virtualization_guest_name' not in obj

# Generated at 2022-06-25 01:08:28.705931
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module = FakeAnsibleModule()
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:08:31.542389
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module = {'run_command': run_command_mock}
    h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:08:32.864256
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_obj_0 = HPUXVirtual(HPUXVirtualCollector())


# Generated at 2022-06-25 01:08:37.962411
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module = None
    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_role': 'HP nPar', 'virtualization_type': 'guest', 'virtualization_tech_guest': {'HP nPar'}, 'virtualization_tech_host': set()}


# Generated at 2022-06-25 01:08:40.095754
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual(module=HPUXModule)
    assert h_p_u_x_virtual_0.get_virtual_facts() is None


# Generated at 2022-06-25 01:08:44.682681
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(dict(ANSIBLE_MODULE_ARGS=dict(gather_subset='!all', filter='*')))
    h_p_u_x_virtual_0.populate()
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:08:52.070747
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_collector_1 = HPUXVirtualCollector()
    h_p_u_x_virtual_1 = HPUXVirtual(h_p_u_x_virtual_collector_1._collector_facts)

    os.path.exists('/usr/sbin/vecheck')
    os.path.exists('/opt/hpvm/bin/hpvminfo')
    os.path.exists('/usr/sbin/parstatus')
    out = '''Running: HPVM vPar'''
    rc = 0
    h_p_u_x_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:08:54.445346
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    f = HPUXVirtual({})
    res = dict()
    res['virtualization_tech_host'] = set()
    res['virtualization_tech_guest'] = set()
    res['virtualization_type'] = 'guest'
    res['virtualization_role'] = 'HP vPar'
    assert f.get_virtual_facts() == res


# Generated at 2022-06-25 01:09:03.564925
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    virtual = type('Virtual', (object,), {})
    virtual.module = type('Module', (object,), {})
    virtual.module.run_command = type('RunCommand', (object,), {'return_value': [0, 'std out', 'std err']})
    virtual.module.run_command.__dict__.__setitem__('_ansible_no_log', False)
    virtual_1 = HPUXVirtual(virtual)

    virtual_1.module.run_command = type('RunCommand', (object,), {'return_value': [0, 'std out', 'std err']})
    virtual_1.module.run_command.__dict__.__setitem__('_ansible_no_log', False)

# Generated at 2022-06-25 01:09:04.435937
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()

# Generated at 2022-06-25 01:09:26.607885
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.platform == 'HP-UX'


# Generated at 2022-06-25 01:09:29.961027
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()

    assert h_p_u_x_virtual_0.platform == 'HP-UX'

# Generated at 2022-06-25 01:09:32.269946
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual({'config_file': '/etc/facter/facts.d/repository_virtual_facts.txt'})


# Generated at 2022-06-25 01:09:41.090162
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_collector_0 = HPUXVirtualCollector()
    h_p_u_x_virtual_0 = HPUXVirtual(h_p_u_x_virtual_collector_0)
    out = h_p_u_x_virtual_0.get_virtual_facts()
    assert 'virtualization_type' in out
    assert 'virtualization_role' in out
    assert 'virtualization_tech_host' in out
    assert 'virtualization_tech_guest' in out
    assert len(out['virtualization_tech_host']) == 0
    assert len(out['virtualization_tech_guest']) >= 0

# Generated at 2022-06-25 01:09:46.485899
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module = MagicMock()
    h_p_u_x_virtual_0.module.run_command.return_value = (0, '', '')
    ret_val = h_p_u_x_virtual_0.get_virtual_facts()
    assert ret_val['virtualization_type'] == 'host'

# Generated at 2022-06-25 01:09:51.968391
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual(dict(ANSIBLE_MODULE_ARGS={}), dict(), dict())
    h_p_u_x_virtual_0.module.run_command = lambda args, check_rc=True: (0, '', '')
    h_p_u_x_virtual_0.module.exit_json = lambda **kwargs: None
    h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:09:54.433431
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual(module=None)
    result = h_p_u_x_virtual_0.get_virtual_facts()
    assert result

# Generated at 2022-06-25 01:09:55.821738
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    hpux_virtual_0 = HPUXVirtual()
    virtual_facts = hpux_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:09:56.947211
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_HPUXVirtual_get_virtual_facts_0()



# Generated at 2022-06-25 01:09:58.378662
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    if h_p_u_x_virtual_0.get_virtual_facts():
        return True
    else:
        return False


# Generated at 2022-06-25 01:10:28.859832
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()
    assert h_p_u_x_virtual.get_virtual_facts() == {'virtualization_type': 'guest', 'virtualization_role':
                                                   'HP vPar', 'virtualization_tech_host': set(),
                                                   'virtualization_tech_guest': {'HP vPar'}}


# Generated at 2022-06-25 01:10:33.544404
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    output = h_p_u_x_virtual_0.get_virtual_facts()
    assert output['virtualization_role'] == 'HP vPar'
    assert output['virtualization_type'] == 'guest'
    assert output['virtualization_tech_guest'] == {'HP vPar'}
    assert output['virtualization_tech_host'] == set()
    assert output['virtualization_product'] == set()

# Generated at 2022-06-25 01:10:34.002172
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-25 01:10:36.492195
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    this_obj = HPUXVirtual(module=None)
    assert this_obj.platform == 'HP-UX', 'Failed to set platform to HP-UX.'

# Generated at 2022-06-25 01:10:37.935637
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(dict())
    assert h_p_u_x_virtual_0

# Generated at 2022-06-25 01:10:41.437329
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    HPUXVirtual_instance = HPUXVirtual()
    #print("HPUXVirtual_instance.get_virtual_facts() = " + str(HPUXVirtual_instance.get_virtual_facts()))

if __name__ == '__main__':
    test_case_0()
    test_HPUXVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:10:46.036672
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0


# Generated at 2022-06-25 01:10:47.377969
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    return h_p_u_x_virtual_0


# Generated at 2022-06-25 01:10:50.949044
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual({}, {})
    h_p_u_x_virtual_0.module = {'run_command': {'ex_rc': 0, 'stdout': ''}}

    h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:10:52.805140
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert type(h_p_u_x_virtual_0.get_virtual_facts()) is dict


# Generated at 2022-06-25 01:11:26.111231
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.platform == 'HP-UX'
    assert isinstance(h_p_u_x_virtual_0, HPUXVirtual)
    var_3 = h_p_u_x_virtual_0.get_virtual_facts()
    assert h_p_u_x_virtual_0.platform == 'HP-UX'
    assert isinstance(h_p_u_x_virtual_0, HPUXVirtual)


# Generated at 2022-06-25 01:11:26.843892
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_case_0()


# Generated at 2022-06-25 01:11:28.532256
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = 1.0
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    assert h_p_u_x_virtual_0._platform == 'HP-UX'

# Generated at 2022-06-25 01:11:30.849149
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    float_0 = 7182.0
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:11:31.478726
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    test_case_0()


# Generated at 2022-06-25 01:11:32.133578
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_case_0()

# Generated at 2022-06-25 01:11:34.246502
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    float_0 = 959.0
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert not var_0 == None


# Generated at 2022-06-25 01:11:39.969965
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    float_0 = 504.0
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:11:41.076225
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = 575.0
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)


# Generated at 2022-06-25 01:11:46.712005
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Setup
    float_0 = 615.0
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    # Assertions

# Generated at 2022-06-25 01:12:19.186587
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = 615.0
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:12:24.527290
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = 472.5
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)


# Generated at 2022-06-25 01:12:28.329826
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    float_0 = 14.0
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    set_0 = var_0.get('virtualization_tech_host')
    var_1 = set_0.isdisjoint(set())
    assert var_1
    set_1 = var_0.get('virtualization_tech_guest')
    var_2 = set_1.isdisjoint(set())
    assert var_2

# Generated at 2022-06-25 01:12:34.573465
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = 553.0
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    # Test method get_virtual_facts of class HPUXVirtual
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:12:42.482494
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    float_0 = 615.5
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    var_1 = {'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_type': None, 'virtualization_role': None}
    assert var_0 == var_1


# Generated at 2022-06-25 01:12:44.297314
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:12:45.849502
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = HPUXVirtual(float(611) / 1000.0)
    var_0 = float_0.get_virtual_facts()

# Generated at 2022-06-25 01:12:50.985766
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = 615.0
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    assert h_p_u_x_virtual_0.platform == 'HP-UX'



# Generated at 2022-06-25 01:12:53.678974
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = 958.0
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:13:02.058939
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = 615.0
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    h_p_u_x_virtual_0.get_virtual_facts()
    var_0 = h_p_u_x_virtual_1 = HPUXVirtual(float_0)
    var_0.get_virtual_facts()
    var_0 = h_p_u_x_virtual_2 = HPUXVirtual(float_0)
    var_0.get_virtual_facts()
    var_0 = h_p_u_x_virtual_3 = HPUXVirtual(float_0)
    var_0.get_virtual_facts()
    var_0 = h_p_u_x_virtual_4 = HPUXVirtual(float_0)
    var

# Generated at 2022-06-25 01:13:27.483569
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    float_0 = 615.0
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    # Input of get_virtual_facts seems to always be the float 0.615
    float_1 = 615.0
    var_0 = h_p_u_x_virtual_0.get_virtual_facts(float_1)
    # Output of get_virtual_facts seems to always be a dict with two items
    assert len(var_0) == 2

# Generated at 2022-06-25 01:13:30.766561
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    float_0 = 615.0
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:13:33.210902
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_1 = 2.0
    #Unit test for constructor of class HPUXVirtual
    h_p_u_x_virtual_1 = HPUXVirtual(float_1)


# Generated at 2022-06-25 01:13:35.756785
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = 615.0
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    assert h_p_u_x_virtual_0._platform() == 'HP-UX'


# Generated at 2022-06-25 01:13:38.403370
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    float_0 = 615.0
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:13:43.291879
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    float_0 = 615.0
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:13:48.232528
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_1 = 615.0
    h_p_u_x_virtual_1 = HPUXVirtual(float_1)
    var_1 = h_p_u_x_virtual_1.get_virtual_facts()
    assert var_1 == {}

# Generated at 2022-06-25 01:13:57.459254
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
  float_0 = 615.0
  h_p_u_x_virtual_0 = HPUXVirtual(float_0)
  assert h_p_u_x_virtual_0.module is float_0
  virtual_facts_0 = h_p_u_x_virtual_0.get_virtual_facts()
  # AssertionError: [{'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}] != [{'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_type': 'guest', 'virtualization_role': 'HPVM vPar'}]


# Generated at 2022-06-25 01:14:02.092570
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    float_0 = 615.0
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:14:07.359724
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    float_0 = 615.0
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_role': 'HPVM IVM', 'virtualization_type': 'guest', 'virtualization_tech': None, 'virtualization_tech_host': set(), 'virtualization_tech_guest': {'HPVM IVM'}}

# Generated at 2022-06-25 01:14:34.590860
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = 538.0
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    assert float_0 is float_0

# Generated at 2022-06-25 01:14:38.213709
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = 615.0
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)


# Generated at 2022-06-25 01:14:40.356029
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    float_0 = 615.0
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:14:44.766118
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    float_0 = 615.0
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)

    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

test_case_0()

# Generated at 2022-06-25 01:14:46.198043
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert True


# Generated at 2022-06-25 01:14:51.835868
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    ansible_module_0 = AnsibleModule(argument_spec=dict())
    float_0 = 615.0
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    var_1 = h_p_u_x_virtual_0.get_virtual_facts()
    ansible_module_0.exit_json(changed=False, ansible_facts=dict(var_1=var_1))

# Generated at 2022-06-25 01:14:56.803422
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():

    float_0 = 14475.43439
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)

    assert h_p_u_x_virtual_0._platform == 'HP-UX'


# Generated at 2022-06-25 01:15:01.819639
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # constructor test
    float_0 = 615.0
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    assert h_p_u_x_virtual_0._platform == 'HP-UX'
    assert h_p_u_x_virtual_0.platform == 'HP-UX'
    assert h_p_u_x_virtual_0._module == 615.0
    assert h_p_u_x_virtual_0.module == 615.0


# Generated at 2022-06-25 01:15:05.221340
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = 615.0
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    print(var_0)


if __name__ == '__main__':
    test_HPUXVirtual()

# Generated at 2022-06-25 01:15:12.230302
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    float_1 = 966.0
    h_p_u_x_virtual_1 = HPUXVirtual(float_1)
    var_1 = h_p_u_x_virtual_1.get_virtual_facts()
    assert var_1 == {
        'virtualization_role': 'HPVM IVM', 'virtualization_type': 'guest',
        'virtualization_tech_guest': {'HPVM IVM'}, 'virtualization_tech_host': set()
    }



# Generated at 2022-06-25 01:15:43.123490
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = 784.0
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    assert (h_p_u_x_virtual_0.module.params['gather_subset'] == ["!all"])

# Generated at 2022-06-25 01:15:46.765587
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_1 = 615.0
    h_p_u_x_virtual_1 = HPUXVirtual(float_1)


# Generated at 2022-06-25 01:15:49.271931
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = 615.0
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    assert h_p_u_x_virtual_0 is not None


# Generated at 2022-06-25 01:15:54.097984
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = 615.0
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    assert h_p_u_x_virtual_0.module is not None
    assert h_p_u_x_virtual_0.platform == 'HP-UX'


# Generated at 2022-06-25 01:15:59.585931
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    float_0 = 615.0
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:16:05.691351
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    float_0 = 615.0
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 == dict(virtualization_tech_host=set(),
                         virtualization_tech_guest=set())

# Generated at 2022-06-25 01:16:07.671755
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_1 = 395.0
    h_p_u_x_virtual_1 = HPUXVirtual(float_1)
    h_p_u_x_virtual_1.get_virtual_facts()

# Generated at 2022-06-25 01:16:10.107339
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = 615.0
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 == {}


# Generated at 2022-06-25 01:16:12.303457
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = 615.0
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    assert h_p_u_x_virtual_0._module_args == 615.0



# Generated at 2022-06-25 01:16:21.963290
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = 615.0
    h_p_u_x_virtual_1 = HPUXVirtual(float_0)
    assert h_p_u_x_virtual_1.platform == 'HP-UX'
    assert h_p_u_x_virtual_1.module is not None
    assert h_p_u_x_virtual_1.virtualization_type == 'unknown'
    assert h_p_u_x_virtual_1.virtualization_role == 'unknown'
    assert h_p_u_x_virtual_1.virtualization_system == 'unknown'
    assert h_p_u_x_virtual_1.virtualization_product == 'unknown'
    assert h_p_u_x_virtual_1.virtualization_uuid == 'unknown'


# Generated at 2022-06-25 01:16:57.469573
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Test with positive values
    float_1 = 554.2
    h_p_u_x_virtual_1 = HPUXVirtual(float_1)
    var_0 = h_p_u_x_virtual_1.get_virtual_facts()
    # Test with negative values
    float_2 = -664.7
    h_p_u_x_virtual_2 = HPUXVirtual(float_2)
    var_0 = h_p_u_x_virtual_2.get_virtual_facts()
    # Test with zero values
    float_3 = 0.0
    h_p_u_x_virtual_3 = HPUXVirtual(float_3)
    var_0 = h_p_u_x_virtual_3.get_virtual_facts()

# Generated at 2022-06-25 01:16:58.691722
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = 615.0
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)


# Generated at 2022-06-25 01:16:59.689921
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)


# Generated at 2022-06-25 01:17:00.874167
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = 615.0
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)


# Generated at 2022-06-25 01:17:03.092387
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    float_0 = 615.0
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:17:06.471459
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = 994.0
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:17:14.155520
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    float_0 = 615.0
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
        'virtualization_role': 'None',
        'virtualization_type': 'physical'}

if __name__ == '__main__':
    test_HPUXVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:17:19.882974
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    float_0 = 615.0
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:17:21.836252
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual(None)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert not var_0


# Generated at 2022-06-25 01:17:27.111064
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    float_0 = 615.0
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    h_p_u_x_virtual_0.get_virtual_facts()
