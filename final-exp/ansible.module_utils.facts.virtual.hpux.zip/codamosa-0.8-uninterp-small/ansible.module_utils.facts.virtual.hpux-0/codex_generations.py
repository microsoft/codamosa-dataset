

# Generated at 2022-06-25 01:07:45.651153
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual(dict(), True)
    assert h_p_u_x_virtual.platform == 'HP-UX'

# Generated at 2022-06-25 01:07:50.802428
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_file = os.path.join(os.getcwd(), 'unit/modules/test_hpux_virtual.py')
    test_case = HPUXVirtual(test_file, '')
    result = test_case.get_virtual_facts()
    assert result['virtualization_type'] == 'host'
    assert result['virtualization_role'] == 'HPVM'
    assert result['virtualization_tech_guest'] == set(['HPVM'])
    assert result['virtualization_tech_host'] == set([])

# Generated at 2022-06-25 01:07:53.379497
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual(module=None)
    # assert that the collect_data method returned a dict
    assert type(h_p_u_x_virtual_0.get_virtual_facts()) == dict

# Generated at 2022-06-25 01:07:55.612028
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # Test with parameter `platform`
    h_p_u_x_virtual_0 = HPUXVirtual(platform='host')


if __name__ == '__main__':
    test_case_0()
    test_HPUXVirtual()

# Generated at 2022-06-25 01:08:04.114193
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    virtual_facts = h_p_u_x_virtual_0.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_tech_guest'] == set()

    if os.path.exists('/usr/sbin/vecheck'):
        rc, out, err = h_p_u_x_virtual_0.module.run_command("/usr/sbin/vecheck")
        if rc == 0:
            assert virtual_facts['virtualization_type'] == 'guest'

# Generated at 2022-06-25 01:08:10.170922
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    hpuxvirtual_0 = HPUXVirtual()
    hpuxvirtual_0_get_virtual_facts = hpuxvirtual_0.get_virtual_facts()
    assert hpuxvirtual_0_get_virtual_facts == \
        {
            'virtualization_type': 'guest',
            'virtualization_role': 'HP vPar',
            'virtualization_tech_host': {},
            'virtualization_tech_guest': {
                'HP vPar',
                'HPVM vPar',
                'HPVM IVM',
                'HPVM',
                'HP nPar',
            },
        }


# Generated at 2022-06-25 01:08:13.176916
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:08:15.689142
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.get_virtual_facts()
    if h_p_u_x_virtual_0.platform is None:
        print("Error")


# Generated at 2022-06-25 01:08:22.551382
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module = MagicMock()
    h_p_u_x_virtual_0.module.run_command = MagicMock(return_value=(0, '', ''))
    h_p_u_x_virtual_0.module.get_bin_path = MagicMock(return_value='/usr/sbin/vecheck')

    h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:08:23.611813
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()

# Generated at 2022-06-25 01:08:33.360424
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()


# Generated at 2022-06-25 01:08:42.252948
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module = AnsibleModule(
        argument_spec=dict()
    )

    # Assert set of keys in result
    expected_keys = ['virtualization_tech_host', 'virtualization_role', 'virtualization_type', 'virtualization_tech_guest']
    result_keys = list(h_p_u_x_virtual_0.get_virtual_facts().keys())
    result_keys.sort()
    expected_keys.sort()
    assert result_keys == expected_keys

    # Assert value of keys in result
    assert h_p_u_x_virtual_0.get_virtual_facts() == dict()

    # Call run_command and create mocks
    h_p_

# Generated at 2022-06-25 01:08:47.102091
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    v = dict(virtual=dict(type='host'))
    x = h_p_u_x_virtual_0.get_virtual_facts()
    assert v == x
    x = h_p_u_x_virtual_0.get_virtual_facts(v)
    assert v == x


# Generated at 2022-06-25 01:08:48.300327
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()

# Generated at 2022-06-25 01:08:49.897613
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()
    h_p_u_x_virtual.get_virtual_facts()

# Generated at 2022-06-25 01:08:53.084556
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()

    virtual_facts_0 = h_p_u_x_virtual_0.get_virtual_facts()

    assert 'virtualization_type' in virtual_facts_0
    assert 'virtualization_role' in virtual_facts_0


# Generated at 2022-06-25 01:08:53.951864
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()


# Generated at 2022-06-25 01:08:54.846456
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    if __name__ == "__main__":
       test_case_0()

# Generated at 2022-06-25 01:08:57.013688
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert isinstance(h_p_u_x_virtual_collector_0._fact_class(0), HPUXVirtual)


# Generated at 2022-06-25 01:09:02.456527
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # Parameters that are passed to constructor
    module = 'module'

    # Example 1: Test constructor by passing a valid object

    # Creation of object
    h_p_u_x_virtual_0 = HPUXVirtual(module)

    # Checking whether created object is of HPUXVirtual class
    assert isinstance(h_p_u_x_virtual_0, HPUXVirtual) == True


# Generated at 2022-06-25 01:09:18.361731
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.get_virtual_facts() == { 'virtualization_role': 'HP nPar', 'virtualization_tech_guest': { 'HP nPar' }, 'virtualization_tech_host': set([]), 'virtualization_type': 'guest' }


if __name__ == '__main__':
    test_HPUXVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:09:21.061940
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual = HPUXVirtual({})
    # TODO: remove
    assert h_p_u_x_virtual.get_virtual_facts() == {}
    assert type(h_p_u_x_virtual.get_virtual_facts()) == dict

test_case_0()
test_HPUXVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:09:27.520378
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual = HPUXVirtual(module=FauxAnsibleModule(), subtype='HPUX')
    h_p_u_x_virtual_facts = h_p_u_x_virtual.get_virtual_facts()
    assert h_p_u_x_virtual_facts['virtualization_type'] == 'guest'
    assert h_p_u_x_virtual_facts['virtualization_role'] == 'HP vPar'


# Generated at 2022-06-25 01:09:31.762732
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()

if __name__ == "__main__":
    h_p_u_x_virtual_collector_0 = HPUXVirtualCollector()
    test_case_0()
    test_HPUXVirtual()

# Generated at 2022-06-25 01:09:36.087311
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_1 = HPUXVirtual({})
    assert h_p_u_x_virtual_1 is not None

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 01:09:43.271914
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():

    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0._platform == 'HP-UX'
    assert h_p_u_x_virtual_0.virtual_facts == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}
    assert h_p_u_x_virtual_0.all_facts == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}
    assert h_p_u_x_virtual_0.has_virt() is False
    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}
    assert h_p_u_

# Generated at 2022-06-25 01:09:47.075845
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual({})
    # Access properties
    h_p_u_x_virtual_0.platform

# Generated at 2022-06-25 01:09:50.528125
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.virtualization_type == 'NA'
    assert h_p_u_x_virtual_0.virtualization_role == 'NA'


# Generated at 2022-06-25 01:09:51.485041
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    HPUXVirtual().get_virtual_facts()

# Generated at 2022-06-25 01:09:53.448833
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()

if __name__ == '__main__':
    test_case_0()

    print('Success')

# Generated at 2022-06-25 01:10:10.823533
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:10:11.508980
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    hpux_virtual = HPUXVirtual()
    # TODO: implement unit test

# Generated at 2022-06-25 01:10:16.181495
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_role': 'guest', 'virtualization_type': 'guest', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

# Generated at 2022-06-25 01:10:16.964295
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:10:23.469343
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    HPUXVirtual_get_virtual_facts_0 = HPUXVirtual()
    HPUXVirtual_get_virtual_facts_0.module = MockModule(params={})
    HPUXVirtual_get_virtual_facts_0.module.run_command = Mock(return_value=(0, '', ''))
    HPUXVirtual_get_virtual_facts_0.platform = 'Linux'
    HPUXVirtual_get_virtual_facts_0.virtualization_type = 'HPVM'
    HPUXVirtual_get_virtual_facts_0.virtualization_role = 'HPVM'
    HPUXVirtual_get_virtual_facts_0.virtualization_tech_guest = set(['HPVM'])

# Generated at 2022-06-25 01:10:27.351511
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_1 = HPUXVirtual({}, {})
    h_p_u_x_virtual_1.module = None
    assert h_p_u_x_virtual_1.get_virtual_facts() == {}

# Generated at 2022-06-25 01:10:29.649136
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual({})
    assert h_p_u_x_virtual_0.name == 'HP-UX virtual fact collector'

# Generated at 2022-06-25 01:10:32.672450
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual(module=None)
    h_p_u_x_virtual_0.platform = 'HP-UX'
    assert h_p_u_x_virtual_0.get_virtual_facts() == {}


# Generated at 2022-06-25 01:10:33.574666
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()

# Generated at 2022-06-25 01:10:38.790838
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module = MagicMock()
    h_p_u_x_virtual_0.module.run_command = MagicMock(return_value=(0, '', ''))
    h_p_u_x_virtual_0._get_platform = MagicMock(return_value='HP-UX')
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:10:55.346754
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    Constructor of class HPUXVirtual
    """
    h_p_u_x_virtual = HPUXVirtual(None)


# Generated at 2022-06-25 01:11:02.807369
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    data = {'virtualization_tech': ['HP nPar', 'HPVM', 'HP vPar'], 'virtualization_role': 'guest', 'virtualization_type': 'guest', 'virtualization_tech_host': set(), 'virtualization_tech_guest': {'HP nPar', 'HPVM', 'HP vPar'}}
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert data == h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:11:04.276185
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:11:09.672651
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.get_virtual_facts() == {
        'virtualization_role': None,
        'virtualization_type': None,
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(),
    }

# Generated at 2022-06-25 01:11:13.570006
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:11:15.200423
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.get_virtual_facts() is None


# Generated at 2022-06-25 01:11:16.853040
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    :return:
    """
    h_p_u_x_virtual_0 = HPUXVirtual()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 01:11:19.944699
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:11:25.336029
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()

if __name__ == '__main__':
    test_case_0()
    test_HPUXVirtual()

# Generated at 2022-06-25 01:11:27.994034
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_0 = HPUXVirtual()
    virtual_1 = HPUXVirtual()
    virtual_2 = HPUXVirtual()
    virtual_3 = HPUXVirtual()
    virtual_4 = HPUXVirtual()
    virtual_5 = HPUXVirtual()
    virtual_6 = HPUXVirtual()


# Generated at 2022-06-25 01:11:41.193632
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module = MockModule()

    results = h_p_u_x_virtual_0.get_virtual_facts()

    assert isinstance(results, dict)
    assert results == {}


# Generated at 2022-06-25 01:11:42.899409
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual('h_p_u_x_virtual_0')
    assert h_p_u_x_virtual_0.platform == 'HP-UX'

# Generated at 2022-06-25 01:11:46.601710
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:11:47.454043
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    obj = HPUXVirtual()
    assert obj


# Generated at 2022-06-25 01:11:48.086301
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual


# Generated at 2022-06-25 01:11:50.135888
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()
    assert h_p_u_x_virtual.platform == 'HP-UX'

# Generated at 2022-06-25 01:11:54.971859
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module_dummy = object()
    h_p_u_x_virtual = HPUXVirtual(module_dummy)
    if not isinstance(h_p_u_x_virtual, HPUXVirtual):
        raise AssertionError(
            "Instance creation failed. Not instance of HPUXVirtual"
        )

# Generated at 2022-06-25 01:11:59.245854
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:12:06.096430
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual(dict(ANSIBLE_MODULE_ARGS={}))
    h_p_u_x_virtual_0.get_virtual_facts()
    h_p_u_x_virtual_0 = HPUXVirtual(dict(ANSIBLE_MODULE_ARGS={}))
    h_p_u_x_virtual_0.get_virtual_facts()
    h_p_u_x_virtual_0 = HPUXVirtual(dict(ANSIBLE_MODULE_ARGS={}))
    h_p_u_x_virtual_0.get_virtual_facts()
    h_p_u_x_virtual_0 = HPUXVirtual(dict(ANSIBLE_MODULE_ARGS={}))
    h_p_u_x_virtual_

# Generated at 2022-06-25 01:12:07.987301
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()
    assert h_p_u_x_virtual is not None


# Generated at 2022-06-25 01:12:23.514611
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'XI8%+VcJj%'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    assert h_p_u_x_virtual_0._module is str_0


# Generated at 2022-06-25 01:12:24.537033
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    print('test_HPUXVirtual')
    test_case_0()


# Generated at 2022-06-25 01:12:27.212567
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = ''
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:12:31.931668
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    assert callable(HPUXVirtual.get_virtual_facts)


# Generated at 2022-06-25 01:12:35.611619
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'XI8%+VcJj%'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0['virtualization_tech_host'] == set([])
    assert var_0['virtualization_role'] == "HPVM IVM"
    assert var_0['virtualization_type'] == "guest"
    assert var_0['virtualization_tech_guest'] == set(['HPVM IVM'])


# Generated at 2022-06-25 01:12:40.887296
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    json_0 = 'M1).'
    str_0 = '<!DF'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    # The following call might raise an exception
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:12:44.232445
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'XI8%+VcJj%'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    assert(h_p_u_x_virtual_0.module == str_0)


# Generated at 2022-06-25 01:12:46.323821
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'XI8%+VcJj%'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)

test_HPUXVirtual()

# Generated at 2022-06-25 01:12:53.580644
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'XI8%+VcJj%'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    h_p_u_x_virtual_0.get_virtual_facts()
    var_1 = h_p_u_x_virtual_0.virtualization_tech_guest
    var_2 = h_p_u_x_virtual_0.virtualization_tech_host
    var_3 = h_p_u_x_virtual_0.virtualization_role
    var_4 = h_p_u_x_virtual_0.virtualization_type


# Generated at 2022-06-25 01:12:59.946480
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    try:
        str_0 = 'XI8%+VcJj%'
        h_p_u_x_virtual_0 = HPUXVirtual(str_0)
        var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    except Exception as exception:
        var_0 = exception.__class__

    assert type(var_0) == type(KeyError)




# Generated at 2022-06-25 01:13:25.389969
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = 'XI8%+VcJj%'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)

    # Test case with arguments that would return True.
    var_1 = h_p_u_x_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:13:27.406668
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'XI8%+VcJj%'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)


# Generated at 2022-06-25 01:13:28.218257
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert True


# Generated at 2022-06-25 01:13:32.808847
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = 'XI8%+VcJj%'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 == None, 'result of method get_virtual_facts is different of expected'


# Generated at 2022-06-25 01:13:35.379789
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    var_1 = 'TmZwvQ0GmW'
    var_2 = HPUXVirtual(var_1)
    var_3 = var_2.get_virtual_facts()
    assert var_3 == None


# Generated at 2022-06-25 01:13:38.034569
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = 'fD$YMs[{H'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:13:43.465816
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'XI8%+VcJj%'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    assert h_p_u_x_virtual_0._module == str_0


# Generated at 2022-06-25 01:13:48.683369
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'XI8%+VcJj%'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 == {} # unknown virtualization


# Generated at 2022-06-25 01:13:53.776521
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = 'oRz^T!\x7fQ?y'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:14:04.920067
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    var_1 = HPUXVirtual('XI8%+VcJj%')
    var_2 = var_1.get_virtual_facts()
    assert var_2 == dict(virtualization_tech_host=set([]), virtualization_tech_guest=set([]), virtualization_type=None, virtualization_role=None)
    var_3 = HPUXVirtual('H.E,]<.')
    var_4 = var_3.get_virtual_facts()
    assert var_4 == dict(virtualization_tech_host=set([]), virtualization_tech_guest=set([]), virtualization_type=None, virtualization_role=None)
    var_5 = HPUXVirtual('G;iFN}')
    var_6 = var_5.get_virtual_facts()
   

# Generated at 2022-06-25 01:14:31.629014
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'XI8%+VcJj%'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    assert h_p_u_x_virtual_0._module == str_0
    assert h_p_u_x_virtual_0.platform == 'HP-UX'


# Generated at 2022-06-25 01:14:33.628640
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'XI8%+VcJj%'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)


# Generated at 2022-06-25 01:14:39.783128
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'BbCM#iL- %'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    assert h_p_u_x_virtual_0.module == str_0
    assert h_p_u_x_virtual_0.platform == 'HP-UX'
    assert h_p_u_x_virtual_0.virtualization_type == 'Full'
    assert h_p_u_x_virtual_0.virtualization_role == 'guest'
    assert h_p_u_x_virtual_0.virtualization_fact == 'host'


# Generated at 2022-06-25 01:14:44.389737
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'YwQ$R!@5z~'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    src_0 = "get_virtual_facts"
    method_0 = getattr(h_p_u_x_virtual_0, src_0)
    method_0()
    h_p_u_x_virtual_collector_0 = HPUXVirtualCollector()
    h_p_u_x_virtual_collector_0.collect()
    h_p_u_x_virtual_collector_0.fetch_all()

test_case_0()
test_HPUXVirtual()

# Generated at 2022-06-25 01:14:50.150572
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'Yzp'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    assert h_p_u_x_virtual_0._platform == 'HP-UX'

# Generated at 2022-06-25 01:14:51.627358
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'XI8%+VcJj%'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)


# Generated at 2022-06-25 01:14:58.321410
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'xi8%+VcJj%'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.platform
    var_1 = h_p_u_x_virtual_0.module
    # AssertionError: Use assertEqual instead of assertTrue
    assert var_1 == str_0
    # AssertionError: Use assertEqual instead of assertTrue
    assert var_0 == 'HP-UX'

# Generated at 2022-06-25 01:15:01.704291
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'XI8%+VcJj%'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    assert h_p_u_x_virtual_0._module == str_0
    assert h_p_u_x_virtual_0._platform == 'HP-UX'


# Generated at 2022-06-25 01:15:02.878875
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'XI8%+VcJj%'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)


# Generated at 2022-06-25 01:15:06.382930
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'XI8%+VcJj%'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert type(var_0) == dict


# Generated at 2022-06-25 01:16:07.074850
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = '/etc/motd'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:16:08.176677
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    assert no_side_effects(HPUXVirtual().get_virtual_facts)

test_case_0()

# Generated at 2022-06-25 01:16:14.349072
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = 'D*w\x19sHl0'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    # AssertionError: 'virtualization_tech_guest' not in dict
    # assert 'virtualization_tech_guest' in var_0
    # AssertionError: 'virtualization_tech_host' not in dict
    # assert 'virtualization_tech_host' in var_0
    # AssertionError: 'virtualization_type' not in dict
    # assert 'virtualization_type' in var_0
    # AssertionError: 'virtualization_role' not in dict
    # assert 'virtualization_role' in var_0


# Generated at 2022-06-25 01:16:15.602360
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # No test case found for usage of get_virtual_facts
    pass  # Additional test cases to be added

# Testing

# Generated at 2022-06-25 01:16:18.332804
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = 'y'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0.get('virtualization_tech_host') == set()
    assert var_0.get('virtualization_tech_guest') == set()


# Generated at 2022-06-25 01:16:24.723709
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = '1,-&O[$;.H'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    assert h_p_u_x_virtual_0._platform == 'HP-UX'
    assert h_p_u_x_virtual_0.module == str_0
    assert h_p_u_x_virtual_0._fact_class == HPUXVirtual
    # Test with a test string
    str_1 = 'XI8%+VcJj%'
    h_p_u_x_virtual_1 = HPUXVirtual(str_1)
    var_1 = h_p_u_x_virtual_1.get_virtual_facts()
    assert var_1['virtualization_type'] == 'guest'
    assert var_

# Generated at 2022-06-25 01:16:28.372867
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'XI8%+VcJj%'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    assert (h_p_u_x_virtual_0._module == str_0)
    assert (h_p_u_x_virtual_0.platform == 'HP-UX')


# Generated at 2022-06-25 01:16:35.799715
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector

    str_0 = 'XI8%+VcJj%'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    # print(var_0)
    # assert(var_0.virtualization_type == '')

# Generated at 2022-06-25 01:16:38.155917
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_1 = 'Q2Z&Mf:nI'
    h_p_u_x_virtual_1 = HPUXVirtual(str_1)
    assert h_p_u_x_virtual_1.module == str_1


# Generated at 2022-06-25 01:16:44.213093
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'XI8%+VcJj%'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    assert h_p_u_x_virtual_0._module == 'XI8%+VcJj%'
    assert h_p_u_x_virtual_0._facts['virtualization_type'] == 'guest'
    assert h_p_u_x_virtual_0._facts['virtualization_tech_guest'] == {'HPVM IVM'}
    assert h_p_u_x_virtual_0._facts['virtualization_tech_host'] == {'HPVM vPar'}
    assert h_p_u_x_virtual_0._facts['virtualization_role'] == 'HP nPar'
    h_p_u_