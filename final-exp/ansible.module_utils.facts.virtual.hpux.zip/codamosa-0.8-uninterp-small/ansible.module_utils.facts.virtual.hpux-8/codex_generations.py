

# Generated at 2022-06-25 01:07:45.166595
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:07:47.383288
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(module=None)
    assert h_p_u_x_virtual_0.platform == 'HP-UX'


# Generated at 2022-06-25 01:07:53.160790
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual({})

# Generated at 2022-06-25 01:08:00.185525
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()

    h_p_u_x_virtual_0.module = h_p_u_x_virtual_0.fake_module
    h_p_u_x_virtual_0.module.run_command.return_value = (0, 'out', 'err')
    h_p_u_x_virtual_0.module.os.path.exists.return_value = True

    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_tech_guest': set(['HP nPar', 'HP vPar']),
                                                     'virtualization_type': 'guest',
                                                     'virtualization_role': 'HP vPar',
                                                     'virtualization_tech_host': set()}

# Generated at 2022-06-25 01:08:02.296868
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:08:03.401693
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()


# Generated at 2022-06-25 01:08:05.967938
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}


# Generated at 2022-06-25 01:08:08.034826
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(dict())


# Generated at 2022-06-25 01:08:12.971250
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.platform == 'HP-UX'
    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_tech_host': set(), 'virtualization_tech_guest': set(), 'virtualization_type': None, 'virtualization_role': None}

# Generated at 2022-06-25 01:08:16.208229
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0._module = DummyAnsibleModule()
    h_p_u_x_virtual_0._module.run_command = fake_run_command_0

    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:08:28.782482
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual({}, {})

    assert not (h_p_u_x_virtual_0 is None)


# Generated at 2022-06-25 01:08:29.847853
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:08:31.541674
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    with pytest.raises(
            TypeError) as error:
        h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:08:32.864294
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()
    assert h_p_u_x_virtual is not None


# Generated at 2022-06-25 01:08:34.312540
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual({})
    assert h_p_u_x_virtual_0.platform == 'HP-UX'


# Generated at 2022-06-25 01:08:36.615574
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:08:37.422064
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    pass  # noqa: NF701


# Generated at 2022-06-25 01:08:41.775775
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module_args = dict()
    # Case 0
    module_args['collect_default_facts'] = 'False'
    module_args['gather_subset'] = ['all']
    module_args['filter'] = '*'

    h_p_u_x_virtual_0 = HPUXVirtual(module_args=module_args)



# Generated at 2022-06-25 01:08:43.907052
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.platform == 'HP-UX'


# Generated at 2022-06-25 01:08:46.428024
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0


# Generated at 2022-06-25 01:09:02.008738
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    var_1 = h_p_u_x_virtual_0.get_virtual_facts()
    var_2 = h_p_u_x_virtual_0.get_virtual_facts()
    var_3 = h_p_u_x_virtual_0.get_virtual_facts()
    var_4 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:09:09.403705
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    assert h_p_u_x_virtual_0._platform == 'HP-UX'
    if callable(getattr(h_p_u_x_virtual_0, 'get_virtual_facts', None)):
        # h_p_u_x_virtual_0._platform == 'HP-UX'
        # h_p_u_x_virtual_0.get_virtual_facts()
        pass
        # var_0 = h_p_u_x_virtual_0.get_virtual_facts()
        # assert var_0 is not None
    else:
        raise Exception("Cannot find method get_virtual_facts in class HPUXVirtual")


# Generated at 2022-06-25 01:09:11.232778
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:09:13.528135
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)


# Generated at 2022-06-25 01:09:20.464783
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    var_1 = h_p_u_x_virtual_0.get_virtual_facts()
    var_2 = h_p_u_x_virtual_0.get_virtual_facts()
    var_3 = h_p_u_x_virtual_0.get_virtual_facts()
    var_4 = h_p_u_x_virtual_0.get_virtual_facts()
    var_5 = h_p_u_x_virtual_0.get_virtual_facts()
    var_6 = h_p_u_x_virtual_0.get_virtual_facts()
   

# Generated at 2022-06-25 01:09:24.981772
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(254)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 01:09:30.661301
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_role': 'HPVM', 'virtualization_type': 'host', 'virtualization_tech_guest': {'HPVM'}, 'virtualization_tech_host': set()}


# Generated at 2022-06-25 01:09:40.797090
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert h_p_u_x_virtual_0 == h_p_u_x_virtual_0
    assert isinstance(h_p_u_x_virtual_0, h_p_u_x_virtual_0.__class__)
    assert len(var_0) == 5
    assert var_0['virtualization_tech_host'] == set()
    assert var_0['virtualization_type'] == 'host'
    assert var_0['virtualization_role'] == 'HPVM'
    assert var_0['virtualization_tech_guest'] == {'HPVM'}

# Generated at 2022-06-25 01:09:42.033576
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)


# Generated at 2022-06-25 01:09:48.847139
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # Test with int as argument
    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    
    # Test with a string as argument
    str_0 = 'hello world'
    h_p_u_x_virtual_1 = HPUXVirtual(str_0)
    
    # Test with float as argument
    float_0 = 45.0
    h_p_u_x_virtual_2 = HPUXVirtual(float_0)



# Generated at 2022-06-25 01:10:14.740086
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():

    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)


# Generated at 2022-06-25 01:10:21.076061
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert (var_0.get('virtualization_role') == 'HP vPar') | (var_0.get('virtualization_role') == 'HPVM vPar') | (var_0.get('virtualization_role') == 'HPVM IVM') | (var_0.get('virtualization_role') == 'HPVM') | (var_0.get('virtualization_role') == 'HP nPar')
    assert var_0.get('virtualization_type')
    assert var_0.get('virtualization_tech_guest')
    assert var_0.get('virtualization_tech_host')

# Generated at 2022-06-25 01:10:23.995073
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_role': 'HPVM', 'virtualization_type': 'host'} or var_0 == {'virtualization_type': 'host', 'virtualization_role': 'HPVM'}


# Generated at 2022-06-25 01:10:27.423393
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:10:31.290111
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_10 = 254
    h_p_u_x_virtual_10 = HPUXVirtual(int_10)
    var_10 = h_p_u_x_virtual_10.__dict__
    var_11 = {'module': int_10, 'platform': 'HP-UX'}
    assert var_10 == var_11


# Generated at 2022-06-25 01:10:33.453790
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:10:36.463718
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 255
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:10:38.617558
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 123
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    assert isinstance(h_p_u_x_virtual_0, HPUXVirtual)

# Generated at 2022-06-25 01:10:39.537998
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test = HPUXVirtual
    test.get_virtual_facts()

# Generated at 2022-06-25 01:10:42.070967
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    assert h_p_u_x_virtual_0.module == int_0


# Generated at 2022-06-25 01:11:18.031065
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    int_1 = h_p_u_x_virtual_0._module.run_command.call_count
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    int_2 = h_p_u_x_virtual_0._module.run_command.call_count
    var_1 = h_p_u_x_virtual_0._module.run_command.assert_called()
    var_2 = h_p_u_x_virtual_0.get_virtual_facts()
    int_3 = h_p_u_x_virtual_0._module.run_command.call_count


# Generated at 2022-06-25 01:11:26.313731
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert isinstance(var_0, dict)
    assert var_0['virtualization_type'] == 'guest'
    assert var_0['virtualization_role'] == 'HP nPar'
    assert isinstance(var_0['virtualization_tech_guest'], set)
    assert 'HP nPar' in var_0['virtualization_tech_guest']
    assert isinstance(var_0['virtualization_tech_host'], set)
    assert var_0['virtualization_tech_host'] == set()

# Generated at 2022-06-25 01:11:27.617723
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_case_0()
    print('Test of method get_virtual_facts of class HPUXVirtual is finished')



# Generated at 2022-06-25 01:11:28.878624
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_1 = 254
    h_p_u_x_virtual_1 = HPUXVirtual(int_1)



# Generated at 2022-06-25 01:11:31.648228
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    assert h_p_u_x_virtual_0._module == int_0
    assert h_p_u_x_virtual_0.platform == 'HP-UX'



# Generated at 2022-06-25 01:11:33.179598
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:11:41.942078
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # Object defined respecting the class HPUXVirtual and tested with the previous function
    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    assert h_p_u_x_virtual_0._platform == "HP-UX"
    assert h_p_u_x_virtual_0.module._socket_path == '254'
    assert h_p_u_x_virtual_0._fact_class == HPUXVirtual
    assert h_p_u_x_virtual_0.platform == 'HP-UX'


# Generated at 2022-06-25 01:11:45.693063
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    assert h_p_u_x_virtual_0._module.params['gather_subset'] == ['!all', 'min', 'virtual'], 'incorrect value for h_p_u_x_virtual_0._module.params[\'gather_subset\']'
    assert h_p_u_x_virtual_0.platform == 'HP-UX', 'incorrect value for h_p_u_x_virtual_0.platform'

# Generated at 2022-06-25 01:11:47.700000
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:11:51.575085
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    ret_2 = h_p_u_x_virtual_0.get_virtual_facts()
    assert ret_2 == {'virtualization_tech_host': set(), 'virtualization_tech_guest': set(), 'virtualization_role': 'cgroups', 'virtualization_type': 'guest'}

# Generated at 2022-06-25 01:12:52.801766
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    var_0 = os.path.exists('/usr/sbin/vecheck')
    var_1 = os.path.exists('/opt/hpvm/bin/hpvminfo')
    var_2 = os.path.exists('/usr/sbin/parstatus')

    int_0 = 254

    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    var_3 = 256
    h_p_u_x_virtual_0.module = h_p_u_x_virtual_0.module
    if (var_0):
        h_p_u_x_virtual_0.module.run_command = h_p_u_x_virtual_0.module.run_command
    if (var_1):
        h_p_u_x_virtual

# Generated at 2022-06-25 01:13:00.313411
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    var_1 = h_p_u_x_virtual_0.module
    int_1 = 255
    var_2 = h_p_u_x_virtual_0.get_virtual_facts()
    h_p_u_x_virtual_1 = HPUXVirtual(int_1)
    var_3 = h_p_u_x_virtual_1.module


# Generated at 2022-06-25 01:13:04.406894
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    var_1 = h_p_u_x_virtual_0.virtualization_type
    var_2 = h_p_u_x_virtual_0.virtualization_role
    var_3 = h_p_u_x_virtual_0.virtualization_tech_guest
    var_4 = h_p_u_x_virtual_0.virtualization_tech_host
    var_5 = h_p_u_x_virtual_0.virtualization_subsystem

# Generated at 2022-06-25 01:13:09.422807
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    var_1 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_1 == {}


# Generated at 2022-06-25 01:13:14.778604
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 90
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    # Calling get_virtual_facts() method of HPUXVirtual class

# Generated at 2022-06-25 01:13:19.487530
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    try:
        var_0 = 254
        obj_0 = HPUXVirtual(var_0)
        if(str(type(obj_0)) == "<class '__main__.HPUXVirtual'>"):
            print("Unit test for constructor of class HPUXVirtual passed.")
        else:
            print("Unit test for constructor of class HPUXVirtual failed.")
    except:
        print("Unit test for constructor of class HPUXVirtual failed.")


# Generated at 2022-06-25 01:13:25.280337
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    return var_0



# Generated at 2022-06-25 01:13:27.650538
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_1 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_1)
    assert h_p_u_x_virtual_0 is not None


test_case_0()

# Generated at 2022-06-25 01:13:30.956375
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    int_0 = 5
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:13:37.013331
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    assert h_p_u_x_virtual_0._connection._socket_path == '/var/run/ansible.socket'
    assert h_p_u_x_virtual_0.get_virtual_facts() == {}
    assert h_p_u_x_virtual_0.platform == 'HP-UX'
    # FIXME assert h_p_u_x_virtual_0.module == object
    assert h_p_u_x_virtual_0.command_exists('/usr/sbin/vecheck') == False
    assert h_p_u_x_virtual_0.command_exists('/opt/hpvm/bin/hpvminfo') == False
    assert h_p_

# Generated at 2022-06-25 01:14:20.576792
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)

    assert h_p_u_x_virtual_0 is not None


# Generated at 2022-06-25 01:14:24.438798
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    int_0 = 150
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    print("Type of var_0 is: " + var_0.__class__.__name__)
    print("Value of var_0 is: " + repr(var_0))
    print("Length of var_0 is: " + str(len(var_0)))

# Generated at 2022-06-25 01:14:26.039007
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:14:28.068635
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    assert h_p_u_x_virtual_0.get_virtual_facts()['virtualization_role'] == 'HPVM guest'



# Generated at 2022-06-25 01:14:30.917715
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)


# Generated at 2022-06-25 01:14:33.705409
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    assert h_p_u_x_virtual_0._module.params['gather_subset'] == ['all']
    assert h_p_u_x_virtual_0.platform == 'HP-UX'



# Generated at 2022-06-25 01:14:34.517670
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_case_0()



# Generated at 2022-06-25 01:14:40.426147
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    var_1 = h_p_u_x_virtual_0.platform
    assert var_1 == 'HP-UX', 'Incorrect value of variable var_1'


# Generated at 2022-06-25 01:14:44.323015
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    assert(h_p_u_x_virtual_0.get_virtual_facts() == None)

# Generated at 2022-06-25 01:14:49.462613
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)


# Generated at 2022-06-25 01:15:53.549875
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 254
    assert isinstance(HPUXVirtual(int_0), HPUXVirtual)

# Generated at 2022-06-25 01:15:58.741600
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert 'virtualization_type' in var_0
    assert 'virtualization_role' in var_0
    assert 'virtualization_tech_host' in var_0
    assert 'virtualization_tech_guest' in var_0

# Generated at 2022-06-25 01:16:03.630934
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    # class HPUXVirtual does not have a method get_virtual_facts


# Generated at 2022-06-25 01:16:09.911681
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    int_0 = 0
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0['virtualization_tech_guest'] == set()
    assert var_0['virtualization_tech_host'] == set()
    assert var_0['virtualization_type'] == 'full'


# Generated at 2022-06-25 01:16:11.186233
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)


# Generated at 2022-06-25 01:16:13.200532
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:16:15.759901
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 233
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    int_1 = -1
    assert h_p_u_x_virtual_0.module.run_command.__defaults__ == (None, False, int_1, None, None)

# Generated at 2022-06-25 01:16:16.785236
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)


# Generated at 2022-06-25 01:16:19.953067
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    with pytest.raises(TypeError):
        h_p_u_x_virtual_0 = HPUXVirtual(None)

# Generated at 2022-06-25 01:16:30.154634
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    int_0 = 254
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    var_1 = h_p_u_x_virtual_0.get_virtual_facts()
    int_1 = 253
    h_p_u_x_virtual_1 = HPUXVirtual(int_1)
    var_2 = h_p_u_x_virtual_1.get_virtual_facts()
    int_2 = 266
    h_p_u_x_virtual_2 = HPUXVirtual(int_2)
    var_3 = h_p_u_x_virtual_2.get_virtual_facts()
    int_3 = 254
    h_p_u_x_virtual_3 = HPUXVirtual(int_3)
    var_4 = h_