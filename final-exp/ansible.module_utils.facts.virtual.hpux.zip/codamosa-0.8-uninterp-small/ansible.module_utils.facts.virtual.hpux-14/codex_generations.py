

# Generated at 2022-06-25 01:07:45.454377
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0 is not None


# Generated at 2022-06-25 01:07:48.826437
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0=HPUXVirtual(module=None)

# Generated at 2022-06-25 01:07:54.771213
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    virtual_facts_0 = {}
    virtual_facts_0['virtualization_type'] = 'guest'
    virtual_facts_0['virtualization_role'] = 'HP nPar'
    virtual_facts_0['virtualization_tech_host'] = set(['HPVM'])
    virtual_facts_0['virtualization_tech_guest'] = set(['HP nPar', 'HP vPar'])
    h_p_u_x_virtual_0 = HPUXVirtual(module=HPUXVirtualCollector)
    assert h_p_u_x_virtual_0.get_virtual_facts() == virtual_facts_0

# Generated at 2022-06-25 01:07:55.568531
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual()


# Generated at 2022-06-25 01:07:56.218664
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual()


# Generated at 2022-06-25 01:07:57.061507
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()

# Generated at 2022-06-25 01:07:58.706552
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual('')


# Generated at 2022-06-25 01:08:07.418384
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    data_for_test_get_virtual_facts_0 = {
        'virtual_facts':
            {'virtualization_role': 'HPVM IVM',
             'virtualization_type': 'guest',
             'virtualization_tech_guest': {'HPVM IVM'},
             'virtualization_tech_host': set()}
    }
    h_p_u_x_virtual_0 = HPUXVirtual(module=AnsibleModule(argument_spec=dict()),
                                    collector=None)
    h_p_u_x_virtual_0.get_virtual_facts()
    assert data_for_test_get_virtual_facts_0['virtual_facts'] == \
        h_p_u_x_virtual_0.facts


# Generated at 2022-06-25 01:08:09.308437
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert len(h_p_u_x_virtual_0.get_virtual_facts()) > 0



# Generated at 2022-06-25 01:08:12.765486
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    m_1 = HPUXVirtual()
    m_1_d = m_1.__dict__
    assert m_1_d['platform'] == 'HP-UX'


# Generated at 2022-06-25 01:08:29.492663
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_collector_0 = HPUXVirtualCollector()
    h_p_u_x_virtual_0 = h_p_u_x_virtual_collector_0.collect()[0]
    facts = h_p_u_x_virtual_0.get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts

# Generated at 2022-06-25 01:08:30.741783
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual(module=module_0)
    h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:08:32.109201
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual.platform == 'HP-UX'


# Generated at 2022-06-25 01:08:34.628222
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    res = h_p_u_x_virtual_0.get_virtual_facts()
    assert res == {'virtualization_tech_host': set(),
                   'virtualization_tech_guest': set(),
                   }


# Generated at 2022-06-25 01:08:37.243314
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert isinstance(h_p_u_x_virtual_0, HPUXVirtual)


# Generated at 2022-06-25 01:08:38.607051
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual({}, {})


# Generated at 2022-06-25 01:08:42.085860
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.platform == 'HP-UX'
    assert h_p_u_x_virtual_0.get_virtual_facts() == {}

# Generated at 2022-06-25 01:08:47.513239
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()

    assert h_p_u_x_virtual.platform == 'HP-UX'
    assert h_p_u_x_virtual.virtual_facts == {'virtualization_role': 'HP vPar', 'virtualization_tech_guest': {'HP vPar'}, 'virtualization_type': 'guest', 'virtualization_tech_host': set()}


# Generated at 2022-06-25 01:08:48.724089
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()

# Generated at 2022-06-25 01:08:51.398276
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    try:
        HPUXVirtual()
    except Exception as e:
        print("Failed to init HPUXVirtual class. Error is: " + str(e))
        return 1
    else:
        return 0


# Generated at 2022-06-25 01:09:05.806145
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # Test methods of virtual_facts
    # test_case_0()
    h_p_u_x_virtual_0 = HPUXVirtual()
    var_0 = h_p_u_x_virtual_0.platform
    return



# Generated at 2022-06-25 01:09:10.220585
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    bytes_0 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    var_0 = h_p_u_x_virtual_0._platform
    var_1 = h_p_u_x_virtual_0.get_virtual_facts()
    var_2 = h_p_u_x_virtual_0._platform

# Generated at 2022-06-25 01:09:15.856483
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    bytes_0 = b'\xbd\x14\x0e\x1d\x8b\xeb\x9e'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    bytes_1 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    h_p_u_x_virtual_1 = HPUXVirtual(bytes_1)
    var_1 = h_p_u_x_virtual_1.get_virtual_facts()
    bytes_2 = b'\xbd\x14\x0e\x1d\x8b\xeb\x9e'
    h_p_u

# Generated at 2022-06-25 01:09:18.722437
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    bytes_0 = b'\x62\x8f\xbe\x2f\xeb\x46\xcc\xd0'
    v_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    var_0 = v_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:09:24.174748
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    bytes_0 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    assert h_p_u_x_virtual_0._platform == 'HP-UX'
    assert h_p_u_x_virtual_0._collectors == ['HPUXVirtualCollector']


# Generated at 2022-06-25 01:09:26.643061
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(b'\xe9\xef\x0f\x10\xbd\xe4\x96')
    assert h_p_u_x_virtual_0._platform == 'HP-UX'


# Generated at 2022-06-25 01:09:29.449400
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    var_1 = HPUXVirtual(None)

#Unit test for constructor of class HPUXVirtualCollector

# Generated at 2022-06-25 01:09:34.723520
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    bytes_0 = b'\xde\x07\xdb\xcf\xed\x16\x9d'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:09:39.297467
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    bytes_0 = b'\xb2G\xe3\xa3'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    bytes_1 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    h_p_u_x_virtual_1 = HPUXVirtual(bytes_1)


# Generated at 2022-06-25 01:09:42.735085
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    bytes_0 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    assert h_p_u_x_virtual_0.module == None
    assert h_p_u_x_virtual_0.platform == 'HP-UX'



# Generated at 2022-06-25 01:10:01.041432
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0 = HPUXVirtual()
    # num_2 = h_p_u_x_virtual_0.get_virtual_facts()
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


if __name__ == "__main__":
    test_case_0()
    test_HPUXVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:10:06.133260
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    bytes_0 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    return HPUXVirtualCollector

# Generated at 2022-06-25 01:10:11.367053
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    bytes_0 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert (var_0['virtualization_type'] == 'guest')

# Generated at 2022-06-25 01:10:12.662284
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual({})
    assert h_p_u_x_virtual_0.get_virtual_facts() == {}

# Generated at 2022-06-25 01:10:17.144639
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # Simple test case: the first two bytes of Linux magic are \x7fELF.
    bytes_0 = b'\x7fELF'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_tech_host': set([]), 'virtualization_tech_guest': set([])}

    # Simple test case: the first two bytes of the HP-UX magic are \xe9\xef.
    bytes_1 = b'\xe9\xef'
    h_p_u_x_virtual_1 = HPUXVirtual(bytes_1)
    var_1 = h_p_u_x_virtual_1.get_virtual_

# Generated at 2022-06-25 01:10:19.974596
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    bytes_0 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:10:21.988406
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # Testing the constructor
    bytes_0 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    var_0 = HPUXVirtual(bytes_0)
    assert var_0


# Generated at 2022-06-25 01:10:26.559632
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    bytes_0 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:10:31.835290
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    bytes_0 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert h_p_u_x_virtual_0._platform == 'HP-UX'
    assert h_p_u_x_virtual_0._fact_class == HPUXVirtual


# Generated at 2022-06-25 01:10:38.965249
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    bytes_0 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    assert h_p_u_x_virtual_0._bytes == bytearray(b'\xe9\xef\x0f\x10\xbd\xe4\x96')
    assert h_p_u_x_virtual_0._platform == 'HP-UX'
    assert h_p_u_x_virtual_0._facts == {'virtualization_type': 'guest', 'virtualization_role': 'HP nPar', 'virtualization_tech_guest': {'HP nPar'}, 'virtualization_tech_host': set()}


# Generated at 2022-06-25 01:11:01.689011
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    bytes_0 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 is not var_0



# Generated at 2022-06-25 01:11:09.527546
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    bytes_0 = b'\xa0\x8a\x15\x1d\x9f\x82\x8f'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_role': 'HPVM', 'virtualization_type': 'host', 'virtualization_tech_guest': {'HPVM'}, 'virtualization_tech_host': set()}

# Generated at 2022-06-25 01:11:15.024718
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    bytes_0 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:11:20.732610
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():

    bytes_0 = b'\x00\x0a\x00\x00\x00\x10'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    assert isinstance(h_p_u_x_virtual_0, HPUXVirtual)



# Generated at 2022-06-25 01:11:28.049812
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    bytes_1 = b'\x18\x8a\x6d\x07\xb7\xda\x8d'
    h_p_u_x_virtual_1 = HPUXVirtual(bytes_1)
    var_0 = h_p_u_x_virtual_1.get_virtual_facts()
    # print(var_0)
    # assert var_0.get('virtualization_type') == 'guest'

# Generated at 2022-06-25 01:11:32.637914
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    fiber_channel_adapters_0 = set()
    fiber_channel_host_adapters_0 = set()
    fiber_channel_host_adapters_0.add(u'HP QLogic 16Gb Dual Port Fibre Channel Host Bus Adapter')
    fiber_channel_adapters_0.add(u'HP QLogic 16Gb Dual Port Fibre Channel Host Bus Adapter')
    b_0 = b'\x81\xba\x1a\x8f\x98\x13\xd3\x19'
    b_0 += b'\x1a\x02\x8f\xab\xc6\x00\xe0'

# Generated at 2022-06-25 01:11:33.139737
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    ## Test case 0
    test_case_0()

# Generated at 2022-06-25 01:11:39.127048
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0._platform == 'Linux'
    assert h_p_u_x_virtual_0._virtual_subclass == 'OpenVZ'



# Generated at 2022-06-25 01:11:44.923963
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_1 = HPUXVirtual(b'\x6d\x6e\x6f\x70\x71\x72\x73')
    h_p_u_x_virtual_2 = HPUXVirtual(b'\x74\x75\x76\x77\x78\x79\x7a')
    h_p_u_x_virtual_3 = HPUXVirtual(b'\x61\x62\x63\x64\x65\x66\x67')
    h_p_u_x_virtual_4 = HPUXVirtual(b'\x68\x69\x6a\x6b\x6c\x6d\x6e')

# Generated at 2022-06-25 01:11:46.059375
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    assert callable(HPUXVirtual.get_virtual_facts)


# Generated at 2022-06-25 01:12:03.381018
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    bytes_0 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)


# Generated at 2022-06-25 01:12:04.792172
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert callable(HPUXVirtual)


# Generated at 2022-06-25 01:12:10.558480
# Unit test for constructor of class HPUXVirtual

# Generated at 2022-06-25 01:12:15.648212
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    bytes_0 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_role': 'HP vPar', 'virtualization_type': 'guest'}


# Generated at 2022-06-25 01:12:17.422938
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    bytes_0 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:12:21.347726
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    h_p_u_x_virtual_0 = HPUXVirtual()

    var_0 = {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}


    assert h_p_u_x_virtual_0.get_virtual_facts() == var_0

# Generated at 2022-06-25 01:12:24.268570
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert callable(HPUXVirtual)



# Generated at 2022-06-25 01:12:29.282462
# Unit test for constructor of class HPUXVirtual

# Generated at 2022-06-25 01:12:35.440764
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    bytes_0 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:12:40.887043
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    bytes_0 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:13:04.359940
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    test_case_0()


# Generated at 2022-06-25 01:13:11.999580
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    bytes_1 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_1)
    bytes_2 = b'\x38\x34\x08\x19\xa2\x8f\xbe'
    h_p_u_x_virtual_1 = HPUXVirtual(bytes_2)


# Generated at 2022-06-25 01:13:18.594318
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    bytes_0 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    assert isinstance(h_p_u_x_virtual_0, HPUXVirtual)
    assert not hasattr(h_p_u_x_virtual_0, 'virtual_facts')
    assert not hasattr(h_p_u_x_virtual_0, 'module')
    var_0 = h_p_u_x_virtual_0.current_task
    var_1 = h_p_u_x_virtual_0.fail_json
    var_2 = h_p_u_x_virtual_0.is_virtual
    var_3 = h_p_u_x_

# Generated at 2022-06-25 01:13:23.452547
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """test_HPUXVirtual_get_virtual_facts"""
    var_0 = HPUXVirtual()

    var_1 = var_0.get_virtual_facts()
    assert var_1 is None

# Generated at 2022-06-25 01:13:31.409738
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    bytes_0 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_role': '', 'virtualization_type': ''}

if __name__ == "__main__":
    import sys
    import inspect
    sys.exit(0 if inspect.getmoduleinfo(__name__, 'main') else 1)

# Generated at 2022-06-25 01:13:34.667938
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    bytes_0 = b'\x00\xf2\xc1\x80\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)


# Test for function get_virtual_facts

# Generated at 2022-06-25 01:13:42.801298
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    bytes_0 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    assert isinstance(h_p_u_x_virtual_0, HPUXVirtual)
    assert isinstance(h_p_u_x_virtual_0._platform, str)
    assert h_p_u_x_virtual_0._platform == 'HP-UX'


# Generated at 2022-06-25 01:13:43.780840
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert True


# Generated at 2022-06-25 01:13:48.991467
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    bytes_0 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Unit tests for class HPUXVirtualCollector

# Generated at 2022-06-25 01:13:57.507616
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    bytes_0 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_type()
    var_1 = h_p_u_x_virtual_0.get_virtual_subtype()
    var_2 = h_p_u_x_virtual_0.get_virtual_role()
    var_3 = h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:14:26.292924
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    bytes_0 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    #
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

# Test of the function get_virtual_facts

# Generated at 2022-06-25 01:14:32.007546
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    bytes_0 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    if (h_p_u_x_virtual_0.get_virtual_facts() != None):
        raise Exception("Failed")

if __name__ == "__main__":
    test_case_0()
    test_HPUXVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:14:37.834269
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    bytes_0 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:14:40.098406
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    bytes_0 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)


# Generated at 2022-06-25 01:14:50.216968
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    bytes_0 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    assert isinstance(h_p_u_x_virtual_0, HPUXVirtual)
    assert h_p_u_x_virtual_0._platform is 'HP-UX'
    assert h_p_u_x_virtual_0._bitness is 64
    assert h_p_u_x_virtual_0._platform_token is not None
    assert h_p_u_x_virtual_0._platform_token_name is 'PA-RISC'


# Generated at 2022-06-25 01:14:52.460693
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    bytes_0 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:14:56.832966
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    bytes_0 = b'\xc7\xe1\xb4\x01\xab\xae\x90'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)


# Generated at 2022-06-25 01:15:02.351453
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    bytes_0 = b'\x07\x8d\xe4\x0f\x86\xc4\x0d'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0['virtualization_role'] == 'HP nPar'
    assert var_0['virtualization_type'] == 'guest'
    assert var_0['virtualization_tech_host'] == set()
    assert var_0['virtualization_tech_guest'] == {'HP nPar'}



# Generated at 2022-06-25 01:15:05.944403
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    bytes_0 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

    assert var_0 is not None


# Generated at 2022-06-25 01:15:13.438866
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    bytes_0 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_tech_guest': set(['HP vPar', 'HP nPar']),
                     'virtualization_tech_host': set(['HPVM']),
                     'virtualization_role': 'HP vPar',
                     'virtualization_type': 'guest'}

# Generated at 2022-06-25 01:15:49.401822
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0
    var_1 = var_0['virtualization_tech_guest']
    assert var_1
    var_2 = var_0['virtualization_tech_host']
    assert var_2
    assert var_0['virtualization_role']
    assert var_0['virtualization_type']


# Generated at 2022-06-25 01:15:53.816526
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    bytes_0 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_role': 'HP nPar', 'virtualization_type': 'guest', 'virtualization_tech_guest': {'HP nPar'}, 'virtualization_tech_host': set()}


if __name__ == '__main__':
    test_case_0()
    test_HPUXVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:15:55.585107
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    assert test_case_0() == {}

# Generated at 2022-06-25 01:16:02.604426
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    bytes_0 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    assert h_p_u_x_virtual_0._fact_class == HPUXVirtual
    assert h_p_u_x_virtual_0._platform == 'HP-UX'
    assert h_p_u_x_virtual_0._bytes == b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    assert h_p_u_x_virtual_0._module == None


# Generated at 2022-06-25 01:16:07.556916
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    bytes_0 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    test_var_0 = h_p_u_x_virtual_0._platform
    assert test_var_0 == "HP-UX", "Expected "+"HP-UX"+", but got "+test_var_0
	

# Generated at 2022-06-25 01:16:08.703617
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
  new_HPUXVirtual = HPUXVirtual()


# Generated at 2022-06-25 01:16:09.772761
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    try:
        test_case_0()
        assert True
    except AssertionError:
        assert False

# Generated at 2022-06-25 01:16:11.024743
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    obj = HPUXVirtual({})
    try:
        obj.get_virtual_facts()
    except:
        pass


# Generated at 2022-06-25 01:16:13.255114
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    bytes_0 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)


# Generated at 2022-06-25 01:16:17.650628
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    n_bytes_0 = randint(0, 5)
    var_0 = get_random_bytes(n_bytes_0)
    h_p_u_x_virtual_0 = HPUXVirtual(var_0)
    var_1 = {}
    write_message_to_file(var_1)
    method_return_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert method_return_0 is not None, \
        "HPUXVirtual.get_virtual_facts: did not return expected value"

# Test case for method get_virtual_facts of class HPUXVirtual

# Generated at 2022-06-25 01:16:51.606202
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    bytes_0 = b'6\xf4\xda\xce\xa8\x14\x15\xb7\xe1\x04\xe5\xad\xb5\x87\x96'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 != None


# Generated at 2022-06-25 01:16:52.252811
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    assert True == True


# Generated at 2022-06-25 01:16:54.992400
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    bytes_0 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:17:00.863557
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    bytes_0 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    assert h_p_u_x_virtual_0._platform == 'HP-UX'


# Generated at 2022-06-25 01:17:03.716144
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    bytes_0 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:17:05.779581
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert callable(HPUXVirtual)


# Generated at 2022-06-25 01:17:07.286100
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    try:
        cwd = os.getcwd()
        if cwd == '/tmp':
            pass
        else:
            assert False
    except:
        assert False


# Generated at 2022-06-25 01:17:07.854402
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    test_case_0()

# Generated at 2022-06-25 01:17:14.759680
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    bytes_0 = b'\xc9\xaf\xca\xea\xaf\x17\xc0k\x0c\x04\xdb\x0b\xa3\x1e\x7f\x16'
    h_p_u_x_virtual_1 = HPUXVirtual(bytes_0)
    var_1 = h_p_u_x_virtual_1.get_virtual_facts()
    assert var_1 is None


# Generated at 2022-06-25 01:17:21.860000
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    bytes_0 = b'\xe9\xef\x0f\x10\xbd\xe4\x96'
    h_p_u_x_virtual_0 = HPUXVirtual(bytes_0)
    # Test if object of class HPUXVirtual was created
    assert repr(h_p_u_x_virtual_0) == "<HPUXVirtual('HP-UX', 'guest', 'HP nPar')>"
