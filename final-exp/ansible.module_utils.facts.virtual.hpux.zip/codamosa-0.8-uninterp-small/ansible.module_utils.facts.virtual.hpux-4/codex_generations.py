

# Generated at 2022-06-25 01:07:43.038377
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:07:46.536116
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_type': 'guest', 'virtualization_role': 'HP nPar', 'virtualization_tech_guest': set(['HP nPar']), 'virtualization_tech_host': set([])}

# Generated at 2022-06-25 01:07:54.017160
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0._module = MagicMock()

# Generated at 2022-06-25 01:07:55.197354
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual(module=None)


# Generated at 2022-06-25 01:08:00.330668
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module.run_command = MagicMock(return_value=(0, 'HPVM host', ''))
    h_p_u_x_virtual_0.module.run_command = MagicMock(return_value=(0, 'HPVM guest', ''))
    h_p_u_x_virtual_0.module.run_command = MagicMock(return_value=(0, 'HPVM vPar', ''))
    h_p_u_x_virtual_0.module.run_command = MagicMock(return_value=(0, 'HP vPar', ''))

# Generated at 2022-06-25 01:08:03.324464
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    HP_UX_virtual_0 = HPUXVirtual()
    HP_UX_virtual_0.module.run_command = run_command
    HP_UX_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:08:05.908355
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    if h_p_u_x_virtual_collector_0._platform == h_p_u_x_virtual_collector_0._fact_class.platform:
        h_p_u_x_virtual_collector_0._fact_class.get_virtual_facts()

# Generated at 2022-06-25 01:08:08.447525
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert isinstance(h_p_u_x_virtual_0, HPUXVirtual)


# Generated at 2022-06-25 01:08:16.428455
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual({'_ansible_module_name': 'Test', '_ansible_socket_path': '/var/folders/q7/f5l539cj5rv2r2r7_y1w5y080000gn/T'})
    assert h_p_u_x_virtual_0.module.params['_ansible_module_name'] == 'Test'
    assert h_p_u_x_virtual_0.module.params['_ansible_socket_path'] == '/var/folders/q7/f5l539cj5rv2r2r7_y1w5y080000gn/T'
    assert h_p_u_x_virtual_0.platform == 'HP-UX'


# Generated at 2022-06-25 01:08:18.384728
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()

if __name__ == '__main__':
    test_case_0()
    test_HPUXVirtual()

# Generated at 2022-06-25 01:08:28.152002
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:08:30.327412
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_collector_0 = HPUXVirtualCollector()


# Generated at 2022-06-25 01:08:33.932919
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(False)
    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_type': 'physical', 'virtualization_role': 'physical'}


# Generated at 2022-06-25 01:08:43.218406
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.virtualization_type = 'guest'
    h_p_u_x_virtual_0.virtualization_role = 'HPVM vPar'
    h_p_u_x_virtual_0.virtualization_tech_host = set(['HPVM'])
    h_p_u_x_virtual_0.virtualization_tech_guest = set(['HPVM'])
    virtual_facts = h_p_u_x_virtual_0.get_virtual_facts()
    assert 'virtualization_tech_guest' in virtual_facts, 'Attribute \'virtualization_tech_guest\' not found in virtual_facts returned from HPUXVirtual.get_virtual_facts().'

# Generated at 2022-06-25 01:08:44.299005
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual({})


# Generated at 2022-06-25 01:08:46.557239
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:08:52.614806
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.populate()
    assert h_p_u_x_virtual_0.facts['virtualization_role'] == 'HP nPar'
    assert h_p_u_x_virtual_0.facts['virtualization_type'] == 'guest'
    assert h_p_u_x_virtual_0.facts['virtualization_tech_guest'] == set(['HP nPar'])
    assert h_p_u_x_virtual_0.facts['virtualization_tech_host'] == set()

# Generated at 2022-06-25 01:08:53.728855
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:08:54.846150
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:08:57.013797
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual({})
    assert h_p_u_x_virtual_0


# Generated at 2022-06-25 01:09:14.760727
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.get_virtual_facts() == {}

# Generated at 2022-06-25 01:09:16.370633
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.platform == 'HP-UX'


# Generated at 2022-06-25 01:09:17.793275
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:09:23.444001
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    with open('/proc/cpuinfo', 'r') as proc_cpu_info:
        cpu_info = proc_cpu_info.read()
        result = re.match('.*HP.*K\.*-\.*SKIPPER.*', cpu_info).group(0)
    h_p_u_x_virtual_0 = HPUXVirtual(None, cpu_info=result)
    assert h_p_u_x_virtual_0.get_virtual_facts()['virtualization_tech_guest'] == {'HP nPar'}
    assert h_p_u_x_virtual_0.get_virtual_facts()['virtualization_tech_host'] == set()
    assert h_p_u_x_virtual_0.get_virtual_facts()['virtualization_type'] == 'guest'
    assert h_

# Generated at 2022-06-25 01:09:24.536633
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()

# Generated at 2022-06-25 01:09:25.430668
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()

# Generated at 2022-06-25 01:09:26.644242
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()



# Generated at 2022-06-25 01:09:29.448853
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:09:30.758565
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:09:34.957080
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.get_virtual_facts() is not False


# Generated at 2022-06-25 01:10:04.136745
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()

# Generated at 2022-06-25 01:10:06.233353
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(HPUXVirtualCollector.module)

if __name__ == '__main__':
    test_case_0()
    test_HPUXVirtual()

# Generated at 2022-06-25 01:10:07.011477
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:10:10.028869
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:10:11.743426
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_1 = HPUXVirtual()


# Generated at 2022-06-25 01:10:14.518262
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:10:16.337891
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0._platform == 'HP-UX'


# Generated at 2022-06-25 01:10:21.752049
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_1 = HPUXVirtual(dict())
    h_p_u_x_virtual_2 = HPUXVirtual(dict())
    h_p_u_x_virtual_3 = HPUXVirtual(dict())
    h_p_u_x_virtual_4 = HPUXVirtual(dict())
    h_p_u_x_virtual_5 = HPUXVirtual(dict())
    h_p_u_x_virtual_6 = HPUXVirtual(dict())
    h_p_u_x_virtual_7 = HPUXVirtual(dict())

# Generated at 2022-06-25 01:10:23.746808
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    print('Test Case 1: Constructor and get_virtual_facts()')
    h_p_u_x_virtual_0 = HPUXVirtual(module=HPUXVirtual)
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:10:26.524289
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert hasattr(HPUXVirtual, 'virtualization_type')
    assert hasattr(HPUXVirtual, 'virtualization_role')



# Generated at 2022-06-25 01:11:01.688878
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.get_virtual_facts() is None

# Generated at 2022-06-25 01:11:08.833888
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_collector_0 = HPUXVirtualCollector()
    dict = h_p_u_x_virtual_collector_0.get_virtual_facts()
    assert dict['virtualization_type'] == 'guest'
    assert dict['virtualization_role'] == 'HP vPar'
    assert dict['virtualization_tech_host'] == set()


# Generated at 2022-06-25 01:11:13.263757
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()


# Generated at 2022-06-25 01:11:14.428864
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:11:16.161644
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0._collector_platform == 'HP-UX'


# Generated at 2022-06-25 01:11:19.434172
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    obj = HPUXVirtual()

    assert obj.platform == u'HP-UX'



# Generated at 2022-06-25 01:11:20.321894
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()

# Generated at 2022-06-25 01:11:27.794780
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    answer = h_p_u_x_virtual_0.get_virtual_facts()
    assert answer == {'virtualization_role': 'HP nPar',
                      'virtualization_type': 'guest',
                      'virtualization_tech_host': set(),
                      'virtualization_tech_guest': set(['HP nPar'])}

# Generated at 2022-06-25 01:11:32.795699
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual = HPUXVirtual()
    # Test case 0
    virtual_facts = h_p_u_x_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_tech_guest'] == {'HP nPar', 'HPVM IVM', 'HPVM vPar', 'HP vPar'}
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_role'] in ('HP nPar', 'HPVM IVM', 'HPVM vPar', 'HP vPar')
    assert virtual_facts['virtualization_type'] == 'guest'

# Generated at 2022-06-25 01:11:39.155486
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(dict())
    # Let's validate facts returned with constructor of class HPUXVirtual
    h_p_u_x_virtual_0.populate()
    assert 'virtualization_type' in h_p_u_x_virtual_0.facts



# Generated at 2022-06-25 01:12:04.326809
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:12:05.438230
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(module=None)


# Generated at 2022-06-25 01:12:07.963843
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual = HPUXVirtual()
    assert h_p_u_x_virtual.get_virtual_facts() == 'return value of HPUXVirtual.get_virtual_facts()'


# Generated at 2022-06-25 01:12:09.638761
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(
        module=AnsibleModule(
            argument_spec={})
    )
    h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:12:11.509117
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:12:17.652968
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0_obj = HPUXVirtual(ansible_module_get_opts_mock, 
                                        ansible_module_run_command_mock,
                                        ansible_module_fail_json_mock,
                                        ansible_module_exit_json_mock)
    expected_virtual_facts = dict([])
    expected_virtual_facts['virtualization_type'] = 'guest'
    expected_virtual_facts['virtualization_role'] = 'HPVM IVM'
    expected_virtual_facts['virtualization_tech_host'] = set(['HPVM'])
    expected_virtual_facts['virtualization_tech_guest'] = set(['HPVM'])
    actual_virtual_facts = h_p_u_x_virtual_0_obj.get_

# Generated at 2022-06-25 01:12:19.067922
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.get_virtual_facts()['virtualization_type']=='physical'


# Generated at 2022-06-25 01:12:24.079729
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()

# Generated at 2022-06-25 01:12:28.131555
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_collector_0 = HPUXVirtualCollector()
    assert h_p_u_x_virtual_0.guest_facts is None
    assert h_p_u_x_virtual_0.platform == 'HP-UX'
    assert h_p_u_x_virtual_0.module is None


# Generated at 2022-06-25 01:12:32.157721
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(dict())


# Generated at 2022-06-25 01:13:04.795496
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual_instance = HPUXVirtual()
    assert HPUXVirtual_instance.platform is 'HP-UX'
    assert HPUXVirtual_instance.virtualization_type is None
    assert HPUXVirtual_instance.virtualization_role is None


# Generated at 2022-06-25 01:13:07.764142
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:13:12.208351
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual = HPUXVirtual({})
    
    if h_p_u_x_virtual is not None:
        virtual_facts = h_p_u_x_virtual.get_virtual_facts()
        if virtual_facts is not None:
            print(virtual_facts)

# Generated at 2022-06-25 01:13:16.927470
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()

    get_virtual_facts_ = h_p_u_x_virtual_0.get_virtual_facts()

    assert get_virtual_facts_ == {'virtualization_role': 'HP nPar', 'virtualization_tech_guest': {'HP nPar'}, 'virtualization_type': 'guest', 'virtualization_tech_host': set()}

# Generated at 2022-06-25 01:13:22.689006
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module_args={}
    # Case 0
    test_case_0()

    # Unit test for method get_virtual_facts of class HPUXVirtual
    # Case 0
    if (HPUXVirtual().get_virtual_facts() is not None):
        print("Success: test_get_virtual_facts_case_0")
    else:
        print("Failure: test_get_virtual_facts_case_0")

    # Case 1
    if (HPUXVirtual().get_virtual_facts() is not None):
        print("Success: test_get_virtual_facts_case_1")
    else:
        print("Failure: test_get_virtual_facts_case_1")

# Generated at 2022-06-25 01:13:29.351593
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.platform == 'HP-UX'
    assert h_p_u_x_virtual_0.get_virtual_facts() == {}
    assert h_p_u_x_virtual_0.get_virtual_facts(collect_default=False) == {}


# Generated at 2022-06-25 01:13:32.330544
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(dict(module=dict(run_command=dict(side_effect=lambda *args: (0, '', '')))))

# Generated at 2022-06-25 01:13:42.313492
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module = MagicMock()
    h_p_u_x_virtual_0.module.run_command.return_value = (0, 'echo', '')
    h_p_u_x_virtual_0.module.get_bin_path.return_value = 'echo'
    h_p_u_x_virtual_0.sysctl = MagicMock()
    h_p_u_x_virtual_0.sysctl.return_value = 'echo'
    h_p_u_x_virtual_0.read_file = MagicMock()
    h_p_u_x_virtual_0.read_file.return_value = {'echo': 'echo'}
    h

# Generated at 2022-06-25 01:13:44.328685
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:13:47.749308
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual({})


# Generated at 2022-06-25 01:14:15.906939
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_obj_0 = HPUXVirtual()
    h_p_u_x_virtual_obj_0.module = MagicMock()
    h_p_u_x_virtual_obj_0.module.run_command.side_effect = [
        (0, "", ""),
        (0, "\n", ""),
        (0, "Running HPVM vPar VM.", ""),
        (0, "", ""),
        (0, "\n", ""),
        (0, "Running HPVM guest VM.", ""),
        (0, "", ""),
        (0, "\n", ""),
        (0, "Running HPVM host.", ""),
        (0, "", ""),
        (0, "\n\n", ""),
    ]

# Generated at 2022-06-25 01:14:24.677112
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False)

    h_p_u_x_virtual_0.module.run_command = MagicMock(return_value=(0, 'Hosting Environment:\n  HPVM host\n', ''))

    # Test using /usr/sbin/vecheck file
    os.path.exists = MagicMock(return_value=True)

    rc, out, err = h_p_u_x_virtual_0.module.run_command("/usr/sbin/vecheck")

    assert rc == 0
    assert out == 'Hosting Environment:\n  HPVM host\n'
    assert err == ''

# Generated at 2022-06-25 01:14:31.251151
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    '''
    AnsibleModuleFake(run_command=lambda x: (0, 'fake_out', 'fake_err'), load_file=lambda x: None, fail_json=lambda: None)
    '''
    virtual_facts = {}
    virtual_facts = HPUXVirtual().get_virtual_facts()
    assert virtual_facts == {'virtualization_type': 'guest', 'virtualization_role': 'HP vPar', 'virtualization_tech_host': set(), 'virtualization_tech_guest': {'HP vPar'}}

# Generated at 2022-06-25 01:14:38.213337
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    tutil_HPUXVirtual_get_virtual_facts = HPUXVirtual()
    tutil_HPUXVirtual_get_virtual_facts.module = MagicMock()
    stub_value_data = {'stdout': '', 'rc': 1, 'stderr': ''}
    tutil_HPUXVirtual_get_virtual_facts.module.run_command.return_value = stub_value_data
    tutil_HPUXVirtual_get_virtual_facts.get_virtual_facts()

# Generated at 2022-06-25 01:14:41.969675
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(module=None)
    assert h_p_u_x_virtual_0.platform == "HP-UX"


# Generated at 2022-06-25 01:14:42.921216
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-25 01:14:44.392480
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:14:51.242146
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # construct a new HPUXVirtual
    h_p_u_x_virtual_1 = HPUXVirtual()
    # check instance
    if not isinstance(h_p_u_x_virtual_1, Virtual):
        raise AssertionError("Expected {}, got {}".format("HPUXVirtual", type(h_p_u_x_virtual_1)))


# Generated at 2022-06-25 01:14:55.029204
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-25 01:15:04.330192
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module.run_command = MagicMock(return_value=(0, 'out', 'err'))
    h_p_u_x_virtual_0.module.run_command = MagicMock(return_value=(0, 'out', 'err'))
    h_p_u_x_virtual_0.module.run_command = MagicMock(return_value=(0, 'out', 'err'))
    h_p_u_x_virtual_0.module.run_command = MagicMock(return_value=(0, 'out', 'err'))

# Generated at 2022-06-25 01:15:44.528663
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    bool_0 =  None
    h_p_u_x_virtual_0 = HPUXVirtual(bool_0)
    h_p_u_x_virtual_1 = HPUXVirtual(bool_0)
    h_p_u_x_virtual_2 = HPUXVirtual(bool_0)
    h_p_u_x_virtual_3 = HPUXVirtual(bool_0)
    h_p_u_x_virtual_0.module = mock.Mock()
    h_p_u_x_virtual_1.module = mock.Mock()
    h_p_u_x_virtual_2.module = mock.Mock()
    h_p_u_x_virtual_3.module = mock.Mock()

# Generated at 2022-06-25 01:15:46.876752
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    bool_0 = False
    h_p_u_x_virtual_0 = HPUXVirtual(bool_0)
    try:
        var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    except Exception:
        assert False


# Generated at 2022-06-25 01:15:49.380790
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    bool_0 = True
    h_p_u_x_virtual_0 = HPUXVirtual(bool_0)
    assert h_p_u_x_virtual_0 != None


# Generated at 2022-06-25 01:15:50.259216
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    assert 1 == 1
    assert 1 == 1



# Generated at 2022-06-25 01:15:52.136358
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    bool_0 = True
    h_p_u_x_virtual_0 = HPUXVirtual(bool_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:15:59.511540
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    bool_0 = True
    h_p_u_x_virtual_0 = HPUXVirtual(bool_0)
    assert h_p_u_x_virtual_0._platform == 'HP-UX'
    assert h_p_u_x_virtual_0._module == bool_0
    assert h_p_u_x_virtual_0._fact_class == h_p_u_x_virtual_0
    assert h_p_u_x_virtual_0._virtualization_type_facts == {
        'virtualization_type': 'guest',
        'virtualization_role': 'HP nPar'
    }
    assert h_p_u_x_virtual_0._virtualization_type_facts_os_release == {}
    assert h_p_u_x_virtual_0._virtualization_type_

# Generated at 2022-06-25 01:16:06.581536
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(True)
    var_1 = h_p_u_x_virtual_0.platform
    var_2 = h_p_u_x_virtual_0.get_virtual_facts()
    var_4 = h_p_u_x_virtual_0.get_virtual_facts()
    var_6 = h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:16:08.995537
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    bool_0 = True
    h_p_u_x_virtual_0 = HPUXVirtual(bool_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:16:12.473685
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    bool_0 = True
    h_p_u_x_virtual_0 = HPUXVirtual(bool_0)
    # Testing different type of input
    virtual_facts = h_p_u_x_virtual_0.get_virtual_facts()
    # Boolean
    assert virtual_facts['virtualization_type'] == 'guest'
    # Boolean
    assert virtual_facts['virtualization_role'] == 'HP vPar'


# Generated at 2022-06-25 01:16:17.530822
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    if os.path.exists('/usr/sbin/vecheck') and os.path.exists('/opt/hpvm/bin/hpvminfo') and os.path.exists('/usr/sbin/parstatus'):
        bool_0 = True
        h_p_u_x_virtual_0 = HPUXVirtual(bool_0)
        var_0 = h_p_u_x_virtual_0.get_virtual_facts()
        assert type(var_0) is dict
        assert 'virtualization_role' in var_0
        assert 'virtualization_type' in var_0
        assert 'virtualization_tech_host' in var_0
        assert 'virtualization_tech_guest' in var_0

# Generated at 2022-06-25 01:17:20.998426
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    bool_1 = True
    h_p_u_x_virtual_1 = HPUXVirtual(bool_1)


# Generated at 2022-06-25 01:17:27.415438
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    bool_0 = True
    h_p_u_x_virtual_0 = HPUXVirtual(bool_0)
    # dict expected: virtual_facts
    virtual_facts = dict()
    virtual_facts['virtualization_tech_host'] = 'guest'
    virtual_facts['virtualization_tech_guest'] = 'host'
    virtual_facts['virtualization_type'] = 'role'
    # dict expected: dict
    dict = dict()
    dict['virtualization_type'] = 'guest'
    dict['virtualization_role'] = 'HP nPar'
    dict['virtualization_tech_guest'] = set(['HP nPar'])
    dict['virtualization_tech_host'] = set(['guest', 'host'])
    # dict dict: dict
    dict = dict()

# Generated at 2022-06-25 01:17:31.288766
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    bool_0 = True
    h_p_u_x_virtual_0 = HPUXVirtual(bool_0)
    h_p_u_x_virtual_0.module.run_command = MagicMock(return_value=(0, 'asd', ''))
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:17:33.091463
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    bool_0 = True
    h_p_u_x_virtual_0 = HPUXVirtual(bool_0)
