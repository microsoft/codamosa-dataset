

# Generated at 2022-06-25 01:07:46.852298
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    print(h_p_u_x_virtual_0.virtualization_type)
    print(h_p_u_x_virtual_0.virtualization_role)
    print(h_p_u_x_virtual_0.virtualization_tech_host)
    print(h_p_u_x_virtual_0.virtualization_tech_guest)

# Generated at 2022-06-25 01:07:48.213460
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(module=None)


# Generated at 2022-06-25 01:07:49.301444
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:07:50.987731
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    print('\nIn function test_HPUXVirtual')
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:07:52.393614
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:07:54.552459
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(dict())
    assert h_p_u_x_virtual_0.platform == 'HP-UX'



# Generated at 2022-06-25 01:07:56.161106
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_collector_0 = HPUXVirtualCollector()
    h_p_u_x_virtual_0 = HPUXVirtual()

# Generated at 2022-06-25 01:07:58.640603
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert isinstance(h_p_u_x_virtual_0.get_virtual_facts(), dict)

if __name__ == '__main__':
    # test_HPUXVirtual_get_virtual_facts()
    print('Unit Tests Done')

# Generated at 2022-06-25 01:07:59.780239
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()

# Generated at 2022-06-25 01:08:02.790418
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual({})

    # assert that no exception is raised
    h_p_u_x_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:08:15.809710
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module.run_command = MagicMock(return_value=(0, "Mocked output", ""))
    h_p_u_x_virtual_0.module.params = {}

    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:08:17.620137
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:08:19.584498
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0._platform == 'HP-UX'


# Generated at 2022-06-25 01:08:23.027122
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    result = h_p_u_x_virtual_0.get_virtual_facts()
    assert result is not None


# Generated at 2022-06-25 01:08:24.065073
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()

# Generated at 2022-06-25 01:08:25.025503
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()

# Generated at 2022-06-25 01:08:30.093363
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_role': 'HPVM IVM', 'virtualization_type': 'guest', 'virtualization_tech_guest': {'HPVM IVM'}, 'virtualization_tech_host': set()}



# Generated at 2022-06-25 01:08:38.536113
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_virtual_facts = HPUXVirtual.get_virtual_facts(None)
    assert(test_virtual_facts['virtualization_type'] == 'physical' or
           test_virtual_facts['virtualization_type'] == 'guest')
    assert('virtualization_role' in test_virtual_facts or
           test_virtual_facts['virtualization_role'] == 'HP vPar' or
           test_virtual_facts['virtualization_role'] == 'HPVM IVM' or
           test_virtual_facts['virtualization_role'] == 'HPVM vPar' or
           test_virtual_facts['virtualization_role'] == 'HP nPar')

# Generated at 2022-06-25 01:08:47.795194
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    virtualization_facts = {
        'virtualization_type': 'guest'
    }

    h_p_u_x_virtual_0 = HPUXVirtual()

    # not a guest
    h_p_u_x_virtual_0.module = mock.MagicMock(**{'run_command.return_value': (1, '', '')})
    virtualization_facts = h_p_u_x_virtual_0.get_virtual_facts()
    assert virtualization_facts['virtualization_type'] == ''

    expected_virtualization_facts = {
        'virtualization_type': 'guest',
        'virtualization_role': 'HP vPar'
    }

# Generated at 2022-06-25 01:08:51.953986
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():

    h_p_u_x_virtual_0 = HPUXVirtual({})
    h_p_u_x_virtual_1 = HPUXVirtual({})

    # Make sure that HP-UXVirtual instances do not share
    # mutable objects like dictionaries.
    assert h_p_u_x_virtual_0.platform is not h_p_u_x_virtual_1.platform


# Generated at 2022-06-25 01:09:07.904788
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()
    h_p_u_x_virtual.get_virtual_facts()


# Generated at 2022-06-25 01:09:10.249437
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


if __name__ == "__main__":
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:09:14.867068
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.get_virtual_facts() == {
        'virtualization_type': None,
        'virtualization_role': None,
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(),
    }

# Generated at 2022-06-25 01:09:17.944627
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module.exit_json = lambda x: x
    h_p_u_x_virtual_0.module.run_command = lambda x: (0, '', '')
    h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:09:26.044110
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_collector_0 = HPUXVirtualCollector()

    # Test with vPar and VMIVM
    h_p_u_x_virtual_1 = HPUXVirtual(
        module=dict(
            run_command=lambda x: (0, '', '') if x == "/usr/sbin/vecheck" else (0, 'Running HPVM guest', '') if x == "/opt/hpvm/bin/hpvminfo" else (0, '', ''),
            ANSIBLE_MODULE_ARGS=dict(
                gather_subset=['all']
            )
        )
    )

# Generated at 2022-06-25 01:09:29.620280
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
# (for value in h_p_u_x_virtual_0.get_virtual_facts().values(): return value) is True

# Generated at 2022-06-25 01:09:30.889820
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual(dict())


# Generated at 2022-06-25 01:09:32.134329
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual({})


# Generated at 2022-06-25 01:09:36.466079
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0._module = MockModule()
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:09:40.103613
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Create an instance of class HPUXVirtual
    h_p_u_x_virtual_0 = HPUXVirtual()

    # Call method get_virtual_facts of HPUXVirtual
    h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:09:56.915296
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.platform == 'HP-UX'

# Generated at 2022-06-25 01:09:58.608461
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()

    assert(h_p_u_x_virtual_0.platform == 'HP-UX')


# Generated at 2022-06-25 01:10:03.182316
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    '''
    Test case for get_virtual_facts of class HPUXVirtual
    '''
    h_p_u_x_module_0 = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    h_p_u_x_virtual_0 = HPUXVirtual(h_p_u_x_module_0)
    h_p_u_x_virtual_facts_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert h_p_u_x_virtual_facts_0['virtualization_role'] == 'HP vPar'

# Generated at 2022-06-25 01:10:09.537391
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0._module = MagicMock()
    h_p_u_x_virtual_0._module.run_command.return_value = (0, '', '')
    with patch('ansible.module_utils.facts.virtual.hpu.os.path.exists') as path_exists:
        path_exists.return_value = False
        h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:10:14.419830
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()

    # Unit test for method get_virtual_facts of class HPUXVirtual when called with no arguments
    def test_HPUXVirtual_get_virtual_facts__0():
        assert h_p_u_x_virtual_0.get_virtual_facts() == {}



# Generated at 2022-06-25 01:10:15.769957
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:10:17.474223
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():

    h_p_u_x_virtual_0 = HPUXVirtual(module)
    assert h_p_u_x_virtual_0.platform == 'HP-UX'

# Generated at 2022-06-25 01:10:20.351009
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert isinstance(h_p_u_x_virtual_0, HPUXVirtual)


# Generated at 2022-06-25 01:10:22.476407
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.platform == 'HP-UX'
    # test method: get_virtual_facts
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:10:26.060349
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    uname = os.uname()
    h_p_u_x_virtual_0 = HPUXVirtual(uname=uname)


# Generated at 2022-06-25 01:10:47.349920
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module = MagicMock()
    h_p_u_x_virtual_0.module.run_command.return_value = 0, 'stdout', 'stderr'
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:10:54.338774
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()

    with open('tests/unit/ansible_collections/ansible/community/plugins/modules/facts/virtual/hpux_virtual.out') as data_file:
        data = data_file.read()

    h_p_u_x_virtual_0.module.run_command = Mock()
    h_p_u_x_virtual_0.module.run_command.side_effect = [(0, b'', ''),(0, b'', ''), (0, data.encode(), '')]

    virtual_facts = h_p_u_x_virtual_0.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HPVM'


# Generated at 2022-06-25 01:10:55.716408
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:10:56.681481
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:10:57.450125
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()


# Generated at 2022-06-25 01:11:01.411461
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(actual=True)


# Generated at 2022-06-25 01:11:03.805953
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module = MockModule()
    h_p_u_x_virtual_0.get_virtual_facts()

testcases_HPUXVirtual = [
    (test_HPUXVirtual_get_virtual_facts, "test_HPUXVirtual_get_virtual_facts")
]

# Generated at 2022-06-25 01:11:08.787564
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual('h_p_u_x_virtual_module')
    assert h_p_u_x_virtual_0.module


# Generated at 2022-06-25 01:11:12.867362
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_case_0()

# Generated at 2022-06-25 01:11:17.138545
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0._module = {}
    h_p_u_x_virtual_0._module['run_command'] = 'run_command'
    assert h_p_u_x_virtual_0.get_virtual_facts() == {
        'virtualization_role': 'HPVM',
        'virtualization_type': 'host',
        'virtualization_tech_guest': set(['HPVM']),
        'virtualization_tech_host': set([])
    }

# Generated at 2022-06-25 01:11:34.347660
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    expected_dict = {'virtualization_tech_host': set(), 'virtualization_role': 'HP vPar', 'virtualization_tech_guest': {'HP vPar'}, 'virtualization_type': 'guest'}
    h_p_u_x_virtual_0 = HPUXVirtual()
    result = h_p_u_x_virtual_0.get_virtual_facts()
    assert result == expected_dict


# Generated at 2022-06-25 01:11:38.386461
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual(module=None)

# Generated at 2022-06-25 01:11:40.153981
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():

    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.platform == 'HP-UX'


# Generated at 2022-06-25 01:11:45.939979
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(dict(module=dict()))

# Generated at 2022-06-25 01:11:47.043079
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()



# Generated at 2022-06-25 01:11:50.378161
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(module=AnsibleModule(argument_spec={})  # noqa: F405
    )
    if type(h_p_u_x_virtual_0) is not HPUXVirtual:
        print("Failed to instantiate HPUXVirtual")


# Generated at 2022-06-25 01:11:55.326715
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module = MagicMock()
    h_p_u_x_virtual_0.module.run_command = MagicMock(return_value=(0, '', ''))
    h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:11:59.425413
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    if h_p_u_x_virtual_collector_0.get_virtual_facts() == {}:
        return 0
    else:
        return 1


# Generated at 2022-06-25 01:12:06.273253
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Unit test for method get_virtual_facts of class HPUXVirtual
    h_p_u_x_virtual_0 = HPUXVirtual(module=None)
    # Case 1: If a guest
    h_p_u_x_virtual_0.facts = {'architecture': 'ia64', 'num_ipv4_addresses': 0, 'virtualization_type': 'guest'}
    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_type': 'guest', 'virtualization_role': 'HPVM IVM',
                                                     'virtualization_tech_host': set(), 'virtualization_tech_guest': {
        'HPVM IVM'}}
    # Case 2: If a host

# Generated at 2022-06-25 01:12:11.848384
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual(module=MagicMock())
    assert h_p_u_x_virtual_0.get_virtual_facts() is None

# Generated at 2022-06-25 01:12:31.946638
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()

# Generated at 2022-06-25 01:12:35.861193
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()
    assert 'virtualization_type' in h_p_u_x_virtual.collect()
    assert 'virtualization_role' in h_p_u_x_virtual.collect()


# Generated at 2022-06-25 01:12:40.169883
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    virtual_facts = h_p_u_x_virtual_0.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'host'

# Generated at 2022-06-25 01:12:49.624966
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_collector_0 = HPUXVirtualCollector()
    h_p_u_x_virtual_0 = h_p_u_x_virtual_collector_0._fact_class(h_p_u_x_virtual_collector_0._module)
    h_p_u_x_virtual_0._module.run_command = run_command_mock
    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_tech_host': set(), 'virtualization_tech_guest': {'HP nPar'}, 'virtualization_type': 'guest', 'virtualization_role': 'HP nPar'}


# Generated at 2022-06-25 01:12:56.571784
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual({})
# Entering the context manager
# Exiting the context manager
# Entering the context manager
# Exiting the context manager
# Entering the context manager
# Exiting the context manager
# Entering the context manager
# Exiting the context manager
# Entering the context manager
# Exiting the context manager
# Entering the context manager
# Exiting the context manager
# Entering the context manager
# Exiting the context manager
# Entering the context manager
# Exiting the context manager
# Entering the context manager
# Exiting the context manager
# Entering the context manager
# Exiting the context manager
# Entering the context manager
# Exiting the context manager
# Entering the context manager
# Exiting the context manager
# Entering the context manager
# Exiting the

# Generated at 2022-06-25 01:12:57.230816
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()

# Generated at 2022-06-25 01:13:00.271264
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    if HPUXVirtual().platform != 'HP-UX':
        assert False
    return 'Unit test for constructor of class HPUXVirtual ran successfully'


# Generated at 2022-06-25 01:13:01.149637
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:13:05.705316
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual().platform == 'HP-UX'
    assert HPUXVirtual().get_virtual_facts()['virtualization_type'] == 'guest' or \
        HPUXVirtual().get_virtual_facts()['virtualization_type'] == 'host' 

# Generated at 2022-06-25 01:13:08.967259
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()

    assert h_p_u_x_virtual_0.platform == 'HP-UX'
    assert h_p_u_x_virtual_0.virtualization_type is None
    assert h_p_u_x_virtual_0.virtualization_role is None
    assert h_p_u_x_virtual_0.virtualization_system is None


# Generated at 2022-06-25 01:13:19.035024
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()

# Generated at 2022-06-25 01:13:23.020555
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:13:26.618796
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    class_obj = HPUXVirtual({})
    assert class_obj.platform == 'HP-UX'
    assert class_obj.virtualization_type == 'guest'
    assert class_obj.virtualization_role == 'HP vPar'


# Generated at 2022-06-25 01:13:28.668674
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual(module=None)
    h_p_u_x_virtual_0.get_virtual_facts()
    assert True

# Generated at 2022-06-25 01:13:30.072205
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()

# Generated at 2022-06-25 01:13:34.649403
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual({}, {})
    h_p_u_x_virtual_0.module.run_command = lambda x, check_rc=False: [0, '', '']
    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}

# Generated at 2022-06-25 01:13:36.500951
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert isinstance(h_p_u_x_virtual_0, HPUXVirtual)


# Generated at 2022-06-25 01:13:37.967896
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.platform == 'HP-UX'



# Generated at 2022-06-25 01:13:42.484270
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:13:44.111269
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    try:
        HPUXVirtual()
    except:
        pass


# Generated at 2022-06-25 01:13:58.973090
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.get_virtual_facts()
    # Test whether exception was raised and whether it is of the right type


# Generated at 2022-06-25 01:14:02.367803
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:14:05.270719
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual(module=None)
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:14:08.376400
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(module=object)
    assert h_p_u_x_virtual_0.platform == 'HP-UX'

# Generated at 2022-06-25 01:14:14.133764
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module.run_command = lambda x: (0, "", "")
    h_p_u_x_virtual_0.module.get_bin_path = lambda x: '/usr/sbin/vecheck'
    assert h_p_u_x_virtual_0.get_virtual_facts()['virtualization_role'] == 'HP vPar'


# Generated at 2022-06-25 01:14:15.178521
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:14:19.855576
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual({'ansible_facts': {'system_name': ''}})

# Generated at 2022-06-25 01:14:29.244658
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    HPUX_virtual = HPUXVirtual()
    h_p_u_x_virtual_facts = HPUX_virtual.get_virtual_facts()
    assert not h_p_u_x_virtual_facts['virtualization_tech_host']
    assert not h_p_u_x_virtual_facts['virtualization_tech_guest']
    assert not h_p_u_x_virtual_facts['virtualization_type']
    assert not h_p_u_x_virtual_facts['virtualization_role']


# Generated at 2022-06-25 01:14:39.953899
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module.run_command = lambda: (0, '', '')
    h_p_u_x_virtual_0.module.run_command = lambda: (0, '', '')
    h_p_u_x_virtual_0.module.run_command = lambda: (0, '', '')
    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_type': 'guest', 'virtualization_role': 'HP nPar', 'virtualization_tech_guest': {'HP vPar', 'HPVM IVM', 'HPVM vPar', 'HP nPar'}, 'virtualization_tech_host': set()}


# Generated at 2022-06-25 01:14:45.971687
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    try:
        h_p_u_x_virtual_0 = HPUXVirtual()
        # Assertion error raised to indicate test failure
        assert False
    except Exception as e:
        if 'not implemented' not in str(e):
            print(e)
            # Assertion error raised to indicate test failure
            assert False


# Generated at 2022-06-25 01:15:21.038304
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:15:22.455141
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.get_virtual_facts() == {}



# Generated at 2022-06-25 01:15:30.406966
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert isinstance(h_p_u_x_virtual_0, Virtual) is True
    assert hasattr(h_p_u_x_virtual_0, 'platform') is True
    assert h_p_u_x_virtual_0.platform == 'HP-UX'
    assert hasattr(h_p_u_x_virtual_0, 'get_virtual_facts') is True
    assert callable(h_p_u_x_virtual_0.get_virtual_facts) is True


# Generated at 2022-06-25 01:15:33.391466
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual({})


# Generated at 2022-06-25 01:15:39.606203
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Create instance of HPUXVirtual
    h_p_u_x_virtual_0 = HPUXVirtual()
    # Call method get_virtual_facts of HPUXVirtual
    h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:15:40.672369
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert(HPUXVirtualCollector().__class__.__name__ == 'HPUXVirtualCollector')


# Generated at 2022-06-25 01:15:46.788125
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()
    assert(h_p_u_x_virtual.platform == 'HP-UX')

# Generated at 2022-06-25 01:15:47.632809
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual({})


# Generated at 2022-06-25 01:15:49.271823
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()


# Generated at 2022-06-25 01:15:57.238620
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_collector_0 = HPUXVirtualCollector()
    h_p_u_x_virtual_0 = HPUXVirtual(h_p_u_x_virtual_collector_0)
    rc, out, err = h_p_u_x_virtual_0.module.run_command("/opt/hpvm/bin/hpvminfo")
    assert (rc == 0 and re.match('.*Running.*HPVM guest.*', out)) == False



# Generated at 2022-06-25 01:16:27.013546
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:16:27.983703
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()


# Generated at 2022-06-25 01:16:28.927195
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual() is not None


# Generated at 2022-06-25 01:16:35.011535
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0._get_virtual_facts()
    h_p_u_x_virtual_0.module.fail_json.assert_called_with(
        msg='Could not collect HP-UX virtualization facts.'
    )

# Generated at 2022-06-25 01:16:40.049299
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:16:40.827731
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()


# Generated at 2022-06-25 01:16:46.453633
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module = MagicMock()
    h_p_u_x_virtual_0.module.run_command = MagicMock()
    h_p_u_x_virtual_0.module.run_command.return_value = (0, 'stdout value', 'stderr value')
    h_p_u_x_virtual_0.get_virtual_facts()
    out_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert out_0['virtualization_type'] == 'guest'
    assert out_0['virtualization_role'] == 'HP nPar'

# Generated at 2022-06-25 01:16:51.942762
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Create an instance of HPUXVirtual
    h_p_u_x_virtual_0 = HPUXVirtual()
    # Call the method get_virtual_facts of HPUXVirtual instance
    vf = h_p_u_x_virtual_0.get_virtual_facts()
    assert vf['virtualization_tech_host'] == set()
    assert vf['virtualization_tech_guest'] == set()
    assert vf['virtualization_role'] == 'HP vPar'
    assert vf['virtualization_type'] == 'guest'

# Generated at 2022-06-25 01:16:54.048827
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert(False if 'virtualization_role' not in h_p_u_x_virtual_0.get_virtual_facts() else True)
    return


# Generated at 2022-06-25 01:16:59.886530
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_h_p_u_x_virtual = HPUXVirtual()
    test_h_p_u_x_virtual.get_virtual_facts()

# Generated at 2022-06-25 01:17:32.662829
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
