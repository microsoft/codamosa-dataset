

# Generated at 2022-06-25 01:07:48.826541
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual = HPUXVirtual()
    # Test for raised exception
    if h_p_u_x_virtual.get_virtual_facts() != {}:
        raise Exception("Unexpected facts gathered")

# Generated at 2022-06-25 01:07:50.250993
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(module=None)


# Generated at 2022-06-25 01:07:52.238389
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()
    assert h_p_u_x_virtual.platform == 'HP-UX'


# Generated at 2022-06-25 01:07:53.025079
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    result = HPUXVirtual()
    assert result is not None


# Generated at 2022-06-25 01:07:53.733401
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()

# Generated at 2022-06-25 01:07:55.801833
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Create class object for class HPUXVirtual
    HPUXVirtual_obj = HPUXVirtual()

    # Call method get_virtual_facts of class HPUXVirtual
    HPUXVirtual_obj.get_virtual_facts()


# Generated at 2022-06-25 01:08:00.184681
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module = Mock(return_value=None)

    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_role': None, 'virtualization_type': None}

# Generated at 2022-06-25 01:08:02.903520
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.get_virtual_facts()

test_case_0()

# Generated at 2022-06-25 01:08:05.033035
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.get_virtual_facts() is not None


# Generated at 2022-06-25 01:08:07.273880
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    try:
        h_p_u_x_virtual_0 = HPUXVirtual()
    except Exception as e:
        assert False


# Generated at 2022-06-25 01:08:18.385637
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert h_p_u_x_virtual_collector_0 is not None

# Generated at 2022-06-25 01:08:22.588238
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()
    assert(h_p_u_x_virtual.platform)
    h_p_u_x_virtual.get_virtual_facts()  # TODO: Need to mock.


# Generated at 2022-06-25 01:08:24.933313
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """Class to test constructor of HPUXVirtual class"""
    h_p_u_x_virtual_0 = HPUXVirtual('module')
    assert h_p_u_x_virtual_0.module is 'module'


# Generated at 2022-06-25 01:08:27.146795
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:08:28.396956
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()

# Generated at 2022-06-25 01:08:34.762205
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0._module = MagicMock()
    var_1 = {}
    h_p_u_x_virtual_0._module.run_command.return_value = (MagicMock(return_value=0), var_1, MagicMock(return_value=0))
    out_1 = h_p_u_x_virtual_0.get_virtual_facts()
    assert out_1['virtualization_type'] == 'host'
    assert out_1['virtualization_role'] == 'HPVM'
    assert out_1['virtualization_tech_guest'] == {'HPVM', 'HPVM IVM', 'HPVM vPar', 'HP nPar', 'HP vPar'}
    assert out

# Generated at 2022-06-25 01:08:36.129001
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual({})
    assert (isinstance(h_p_u_x_virtual, Virtual))


# Generated at 2022-06-25 01:08:38.502227
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual({})


if __name__ == '__main__':
    test_case_0()
    test_HPUXVirtual()

# Generated at 2022-06-25 01:08:42.772277
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module.run_command = MagicMock(return_value=(0, 'out', 'err'))
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:08:51.432990
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_collector_0 = HPUXVirtualCollector()
    h_p_u_x_virtual_0 = h_p_u_x_virtual_collector_0._fact_class()
    h_p_u_x_virtual_1 = h_p_u_x_virtual_0.get_virtual_facts()
    assert 'virtualization_type' == h_p_u_x_virtual_1['virtualization_type']
    assert 'virtualization_role' == h_p_u_x_virtual_1['virtualization_role']
    assert 'virtualization_tech_guest' == h_p_u_x_virtual_1['virtualization_tech_guest']

# Generated at 2022-06-25 01:09:08.608798
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_1 = '#W>#=LrxEOQu'
    h_p_u_x_virtual_1 = HPUXVirtual(str_1)
    str_2 = '#$%^&*>F[f^'
    h_p_u_x_virtual_1.module = str_2
    var_1 = h_p_u_x_virtual_1.module
    var_2 = h_p_u_x_virtual_1.platform
    var_3 = h_p_u_x_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:09:12.882980
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = '#W>#=LrxEOQu'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = isinstance(h_p_u_x_virtual_0, HPUXVirtual)
    # assert var_0 == 'self.module'
    var_1 = h_p_u_x_virtual_0.get_virtual_facts()
    var_2 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_2 != None


# Generated at 2022-06-25 01:09:15.413709
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # Test for get_virtual_facts
    str_0 = '=^c%+B`x#z'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    test_case_0()



# Generated at 2022-06-25 01:09:19.661842
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = '#W>#=LrxEOQu'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    assert h_p_u_x_virtual_0._platform == 'HP-UX'
    assert h_p_u_x_virtual_0.platform == 'HP-UX'
    assert h_p_u_x_virtual_0._module == str_0
    assert h_p_u_x_virtual_0.module == str_0


# Generated at 2022-06-25 01:09:29.344855
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = '^FnBk-#t'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    str_1 = 'E^<&_ZQr'
    h_p_u_x_virtual_1 = HPUXVirtual(str_1)
    var_1 = h_p_u_x_virtual_1.get_virtual_facts()
    str_2 = '+dWJ]8mv'
    h_p_u_x_virtual_2 = HPUXVirtual(str_2)
    var_2 = h_p_u_x_virtual_2.get_virtual_facts()

# Generated at 2022-06-25 01:09:32.252037
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = '#W>#=LrxEOQu'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    assert h_p_u_x_virtual_0.platform == 'HP-UX'



# Generated at 2022-06-25 01:09:41.953872
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = '//+;1W'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    str_1 = '//+;1W'
    h_p_u_x_virtual_0 = HPUXVirtual(str_1)
    str_2 = '//+;1W'
    h_p_u_x_virtual_0 = HPUXVirtual(str_2)
    str_3 = '/3T'
    h_p_u_x_virtual_0 = HPUXVirtual(str_3)
    var_1 = h_p_u_x_virtual_0.module
    str_4 = '//+;1W'
    h_p_u_x_virtual_1 = HPUXVirtual(str_4)
    var_

# Generated at 2022-06-25 01:09:43.114716
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = ''
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)

# Generated at 2022-06-25 01:09:47.884382
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = '!n(V1,?@v'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    assert h_p_u_x_virtual_0.module == str_0


# Generated at 2022-06-25 01:09:52.342546
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = '#W>#=LrxEOQu'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    if h_p_u_x_virtual_0.module is not str_0:
        var_0 = False
        return var_0
    var_0 = True
    return var_0


# Generated at 2022-06-25 01:10:11.487300
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = '#W>#=LrxEOQu'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:10:16.181818
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # test with dummy input
    str_0 = '#W>#=LrxEOQu'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 is not None


# Generated at 2022-06-25 01:10:22.218054
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = '#W>#=LrxEOQu'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    # Check if "h_p_u_x_virtual_0" is of class HPUXVirtual
    assert isinstance(h_p_u_x_virtual_0, HPUXVirtual)
    # test function get_virtual_facts of class HPUXVirtual
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    # Check if "var_0" is of class dict
    assert isinstance(var_0, dict)
    # test attribute virtualization_type of class HPUXVirtual
    # Check if "h_p_u_x_virtual_0" is of class HPUXVirtual

# Generated at 2022-06-25 01:10:26.678566
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = '#W>#=LrxEOQu'
    h_p_u_x_virtual_1 = HPUXVirtual(str_0)
    var_1 = h_p_u_x_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:10:33.871305
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = '#W>#=LrxEOQu'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    str_1 = 'dKj"X=VxI4bJ'
    h_p_u_x_virtual_1 = HPUXVirtual(str_1)
    str_2 = 'U5y"U5y"U5y"'
    h_p_u_x_virtual_2 = HPUXVirtual(str_2)
    str_3 = 'AzY|d,:Q@&-$'
    h_p_u_x_virtual_3 = HPUXVirtual(str_3)
    str_4 = '$eO,1Nt/p<s}'

# Generated at 2022-06-25 01:10:38.589376
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = 'Bz'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

    assert 'virtualization_type' in var_0
    assert 'virtualization_role' in var_0
    assert 'virtualization_tech_guest' in var_0
    assert 'virtualization_tech_host' in var_0



# Generated at 2022-06-25 01:10:41.618354
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = '#W>#=LrxEOQu'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:10:46.757077
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = '#W>#=LrxEOQu'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    assert h_p_u_x_virtual_0._platform == 'HP-UX'


# Generated at 2022-06-25 01:10:49.779950
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert h_p_u_x_virtual_0.get_virtual_facts() == "bxJaNwPWI"

if __name__ == '__main__':
    test_case_0()
    test_HPUXVirtual()

# Generated at 2022-06-25 01:10:55.631697
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = '#W>#=LrxEOQu'
    str_1 = 'xv5Kl'
    str_2 = '@!4q3'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    h_p_u_x_virtual_0.l_h_p_u_x_virtual_0 = str_1
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 == {}
    h_p_u_x_virtual_0.l_h_p_u_x_virtual_0 = str_2
    var_1 = h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:11:15.657759
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = '#W>#=LrxEOQu'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert 'virtualization_role' in var_0
    assert 'virtualization_type' in var_0


# Generated at 2022-06-25 01:11:20.547980
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = '#W>#=LrxEOQu'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:11:29.516713
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = 'B'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    h_p_u_x_virtual_0.module = MagicMock()
    h_p_u_x_virtual_0.module.run_command.return_value = (0, '#pF7fB$n', '#zP![[-')

    # Call method
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_type': 'host', 'virtualization_role': 'HPVM', 'virtualization_tech_host': {'HPVM'}, 'virtualization_tech_guest': set()}

if __name__ == '__main__':
    test_case_0()


# Generated at 2022-06-25 01:11:32.246391
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'E?a]h?'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    str_1 = h_p_u_x_virtual_0.platform
    assert str_1 == 'HP-UX'


# Generated at 2022-06-25 01:11:34.915680
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = "Ux>#.gDzU=_4N"
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    assert h_p_u_x_virtual_0.module == str_0
    assert h_p_u_x_virtual_0.platform == 'HP-UX'


# Generated at 2022-06-25 01:11:40.429675
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = '#W>#=LrxEOQu'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:11:51.291405
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = '1'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.has_hv()
    h_p_u_x_virtual_1 = HPUXVirtual(str_0)
    var_1 = h_p_u_x_virtual_1.is_guest()
    h_p_u_x_virtual_2 = HPUXVirtual(str_0)
    var_2 = h_p_u_x_virtual_2.is_host()
    h_p_u_x_virtual_3 = HPUXVirtual(str_0)
    var_3 = h_p_u_x_virtual_3.get_all_guest_names()

# Unit

# Generated at 2022-06-25 01:11:59.466771
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = 'A1GlXR~xP'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert len(var_0) == 2
    assert 'virtualization_type' in var_0
    assert len(var_0['virtualization_type']) == 1
    assert 'virtualization_role' in var_0
    assert len(var_0['virtualization_role']) == 1
    assert 'virtualization_tech_guest' not in var_0
    assert 'virtualization_tech_host' not in var_0
    str_1 = 'xlJkWPs|>'
    h_p_u_x_virtual_1 = HPUX

# Generated at 2022-06-25 01:12:02.769377
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # Simple example of the class constructor
    str_0 = '#W>#=LrxEOQu'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    assert h_p_u_x_virtual_0._module == str_0
    # More complex example of the class constructor


# Generated at 2022-06-25 01:12:03.383582
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    test_case_0()


# Generated at 2022-06-25 01:12:18.141194
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    param_0 = '#W>#=LrxEOQu'
    try:
        HPUXVirtual(param_0)
    except Exception:
        assert False


# Generated at 2022-06-25 01:12:19.888646
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = '#W>#=LrxEOQu'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:12:29.120268
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = '#W>#=LrxEOQu'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_role': None, 'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_type': None}
    str_3 = 'U6:fEWh,Rw;@O'
    h_p_u_x_virtual_1 = HPUXVirtual(str_3)
    var_1 = h_p_u_x_virtual_1.get_virtual_facts()

# Generated at 2022-06-25 01:12:31.731262
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Test cases
    test_case_0()

# Generated at 2022-06-25 01:12:35.873113
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'VTvxo|>W8X?4q3)p'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    # Call get_virtual_facts method of class HPUXVirtual
    test_case_0()


# Generated at 2022-06-25 01:12:39.261131
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():

    input = '#W>#=LrxEOQu'

    # test case 0
    test_case_0()


# Generated at 2022-06-25 01:12:41.062024
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    foo = HPUXVirtual('/path/to/ansible_module')
    foo.module.fail_json.assert_called_with(msg='Unsupported platform!')


# Generated at 2022-06-25 01:12:45.273897
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'q3gezHg'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    assert h_p_u_x_virtual_0._module == 'q3gezHg'


# Generated at 2022-06-25 01:12:51.161763
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = '#W>#=LrxEOQu'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    assert h_p_u_x_virtual_0.module == str_0
    assert h_p_u_x_virtual_0.platform == 'HP-UX'


# Generated at 2022-06-25 01:12:57.893985
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = '!V)Lx1~z7'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0._collector
    assert var_0 == str_0


# Generated at 2022-06-25 01:13:19.035041
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'GX?-z'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    assert h_p_u_x_virtual_0._data == 'GX?-z'


# Generated at 2022-06-25 01:13:29.302582
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():

    # 1. Create an object
    # 2. Compare attributes with input values

    global str_0, h_p_u_x_virtual_0, var_0
    str_0 = '#W>#=LrxEOQu'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_role': None, 'virtualization_type': None, 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}


# Generated at 2022-06-25 01:13:32.834254
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = '#W>#=LrxEOQu'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    assert h_p_u_x_virtual_0.facts == dict()


# Generated at 2022-06-25 01:13:38.417230
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = '#W>#=LrxEOQu'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    BOOL_0 = isinstance(var_0, dict)
    if BOOL_0:
        if var_0:
            BOOL_1 = ('virtualization_type' in var_0) and ('virtualization_role' in var_0)
            if BOOL_1:
                var_1 = var_0.get('virtualization_type')
                BOOL_2 = (var_1 is not None) and (var_1 != '')
                var_2 = var_0.get('virtualization_role')

# Generated at 2022-06-25 01:13:44.966485
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = '#W>#=LrxEOQu'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_tech_host': set(), 'virtualization_tech_guest': set(), 'virtualization_type': 'physical', 'virtualization_role': 'physical'}


# Generated at 2022-06-25 01:13:52.456600
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = "vxfrz"
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 == dict(virtualization_tech_host=set([]), virtualization_role="HP nPar", virtualization_type="guest", virtualization_tech_guest=set(['HP nPar']))

    str_1 = "4XJr"
    h_p_u_x_virtual_1 = HPUXVirtual(str_1)
    var_1 = h_p_u_x_virtual_1.get_virtual_facts()

# Generated at 2022-06-25 01:13:55.068089
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_1 = 'gxIOAo>qzp'
    h_p_u_x_virtual_1 = HPUXVirtual(str_1)
    assert h_p_u_x_virtual_1.platform == 'HP-UX'


# Generated at 2022-06-25 01:13:58.992153
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'Eo@H;O#<QOgEA'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.module

# Generated at 2022-06-25 01:14:03.907564
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = '#W>#=LrxEOQu'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:14:06.635751
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = 'U>/9iP#xA8#4'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    assert h_p_u_x_virtual_0.get_virtual_facts() == dict()
#
# main()
#

# Generated at 2022-06-25 01:14:31.652367
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = '#W>#=LrxEOQu'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:14:39.033754
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    #
    # creates an instance of class HPUXVirtual
    #
    str_0 = '#W>#=LrxEOQu'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    #
    # defines virtual_facts
    #
    virtual_facts = {}

    # executes method get_virtual_facts
    # returns var_0
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert virtual_facts == var_0


# Generated at 2022-06-25 01:14:42.816542
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'hpuX virtual'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert (var_0['virtualization_role'] == 'HP nPar')


# Generated at 2022-06-25 01:14:46.197558
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_1 = '#W>#=LrxEOQu'
    h_p_u_x_virtual_1 = HPUXVirtual(str_1)
    var_1 = h_p_u_x_virtual_1.get_virtual_facts()

test_HPUXVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:14:50.939356
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    '''
    Unit test for method get_virtual_facts of class HPUXVirtual
    '''
    str_0 = '1B5j`{9XJ-{a_j'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:14:57.124746
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = 'Nl:bK5a'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 == {}


# Generated at 2022-06-25 01:15:00.527028
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = '#W>#=LrxEOQu'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:15:02.189035
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = 's/-J30Y$g'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:15:05.625736
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # str :
    str_1 = '#W>#=LrxEOQu'
    h_p_u_x_virtual_1 = HPUXVirtual(str_1)
    var_1 = h_p_u_x_virtual_1.get_virtual_facts()
    assert var_1 == {}


# Generated at 2022-06-25 01:15:07.626250
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = '#W>#=LrxEOQu'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    assert (h_p_u_x_virtual_0._module == str_0)


# Generated at 2022-06-25 01:15:41.246731
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = 'Q@'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert type(var_0) == dict


# Generated at 2022-06-25 01:15:48.603171
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = '#W>#=LrxEOQu'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

    assert isinstance(var_0, dict) == True
    assert var_0 == {'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}


# Generated at 2022-06-25 01:15:55.283252
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = '#W>#=LrxEOQu'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    assert h_p_u_x_virtual_0.module == str_0
    assert h_p_u_x_virtual_0.platform == 'HP-UX'


# Generated at 2022-06-25 01:16:03.172281
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Parameters:
    #   str_0: ('#W>#=LrxEOQu',)
    # Return:
    #   var_0:
    #     var_0: {u'virtualization_tech_host': set([]), u'virtualization_type': u'guest', u'virtualization_tech_guest': set([u'HP nPar', u'HP vPar', u'HPVM'])}
    str_0 = '#W>#=LrxEOQu'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:16:10.802736
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = 'G^ztK$Pt.9vO8&fkw>c'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert (var_0['virtualization_role'] == 'HPVM IVM')
    assert (var_0['virtualization_tech_host'] == set())
    assert (var_0['virtualization_type'] == 'guest')
    assert (var_0['virtualization_tech_guest'] == {'HPVM'}), ('Failed assert#1')

# Generated at 2022-06-25 01:16:16.703115
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    collector = HPUXVirtualCollector()
    facts = collector.collect(None, None)
    assert facts['virtualization_type'] == 'host' or facts['virtualization_type'] == 'guest'

# Generated at 2022-06-25 01:16:20.931052
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_1 = '#W>#=LrxEOQu'
    h_p_u_x_virtual_1 = HPUXVirtual(str_1)
    var_1 = h_p_u_x_virtual_1.get_virtual_facts()
    return var_1


# Generated at 2022-06-25 01:16:25.826248
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = ''
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:16:29.438331
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    assert(HPUXVirtual.get_virtual_facts() is None)


# Generated at 2022-06-25 01:16:37.109858
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = 'j|O\x7fA\x7f#`y]`'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_type': 'guest', 'virtualization_role': 'HP nPar', 'virtualization_tech_guest': set(['HP nPar']), 'virtualization_tech_host': set()}


# Generated at 2022-06-25 01:17:12.611133
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert True


# Generated at 2022-06-25 01:17:20.665103
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = 'A'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0._platform
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

if __name__ == '__main__':
    test_case_0()
    test_HPUXVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:17:22.398654
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = 'jK'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:17:26.464710
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(str)


# Generated at 2022-06-25 01:17:30.086730
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual('EbQ#6UJ3Bw>')
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0['virtualization_type'] == 'guest'
    assert var_0['virtualization_role'] == 'HPVM guest'


# Generated at 2022-06-25 01:17:33.452755
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = '#W>#=LrxEOQu'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 == {}


# Generated at 2022-06-25 01:17:39.529203
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = '#W>#=LrxEOQu'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    # check returned value