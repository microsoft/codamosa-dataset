

# Generated at 2022-06-25 01:07:42.818528
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual({})



# Generated at 2022-06-25 01:07:45.452752
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual = HPUXVirtual()
    result = h_p_u_x_virtual.get_virtual_facts()
    assert result['virtualization_tech_guest'] == set()
    assert result['virtualization_tech_host'] == set()

# Generated at 2022-06-25 01:07:49.371565
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual(dict()).platform == 'HP-UX'
    assert HPUXVirtual(dict()).virtualization_type == 'host'
    assert HPUXVirtual(dict()).virtualization_role == None
    assert HPUXVirtual(dict()).virtualization_tech_guest == set()
    assert HPUXVirtual(dict()).virtualization_tech_host == set()


# Generated at 2022-06-25 01:07:51.356820
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()
    assert h_p_u_x_virtual.platform == 'HP-UX'


# Generated at 2022-06-25 01:07:52.757489
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:07:55.787363
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual({'platform': 'HP-UX', 'virtualization_type': 'guest'})
    if h_p_u_x_virtual_0.virtualization_type != 'guest':
        print("ERROR: virtualization_type is not set properly")


# Generated at 2022-06-25 01:07:56.441682
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert not HPUXVirtual()

# Generated at 2022-06-25 01:07:57.996708
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()

# Generated at 2022-06-25 01:07:59.444682
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    hpuxvirtual = HPUXVirtual(dict())
    hpuxvirtual.get_virtual_facts()

# Generated at 2022-06-25 01:08:07.526000
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
# Result of hpux_virtual_0.get_virtual_facts() with inputs
#    set(['parstatus'])
#    'guest'
#    set(['parstatus'])
#    'HP nPar'
#    set()
    expected_result_0 = {
        'virtualization_type': 'guest',
        'virtualization_role': 'HP nPar',
        'virtualization_tech_guest': set(['parstatus']),
        'virtualization_tech_host': set(),
    }
    h_p_u_x_virtual_0 = HPUXVirtual()
    result = h_p_u_x_virtual_0.get_virtual_facts()
    assert result == expected_result_0



# Generated at 2022-06-25 01:08:16.347370
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual(dict())



# Generated at 2022-06-25 01:08:20.730485
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    virtual_facts = h_p_u_x_virtual_0.get_virtual_facts()
    assert virtual_facts['virtualization_type'] or virtual_facts['virtualization_role'] in ('guest', 'host')


if __name__ == '__main__':
    test_case_0()
    test_HPUXVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:08:29.454055
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module.run_command = MagicMock(return_value=(0, 'arbitrary', 'arbitrary'))
    h_p_u_x_virtual_0.module.fail_json = MagicMock(return_value=dict())
    h_p_u_x_virtual_0.module.exit_json = MagicMock(return_value=dict())
    h_p_u_x_virtual_0.get_virtual_facts()
    h_p_u_x_virtual_0.module.fail_json.assert_called_with(msg='Could not determine if host is HPVM guest')


# Generated at 2022-06-25 01:08:30.541400
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.get_virtual_facts() == {}


# Generated at 2022-06-25 01:08:38.103544
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Note: Additional test case will be added to test
    # the functionality of the method get_virtual_facts
    # of class HPUXVirtual
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module = AnsibleModule('Test')
    h_p_u_x_virtual_0.module.run_command = mock.Mock(return_value=(0, 'No Linux OS instance is running', ''))
    h_p_u_x_virtual_0.module.get_bin_path = mock.Mock(return_value=('/usr/sbin/dmesg'))
    h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:08:39.965001
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual({})
    assert h_p_u_x_virtual.get_virtual_facts() == {}


# Generated at 2022-06-25 01:08:42.351941
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:08:44.407154
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0._platform == 'HP-UX'


# Generated at 2022-06-25 01:08:49.462752
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual(module=MockedModule)

    if h_p_u_x_virtual_0.get_virtual_facts() != {'virtualization_type': 'guest', 'virtualization_role': 'HP vPar', 'virtualization_tech_host': set(), 'virtualization_tech_guest': {'HP vPar'}}:
        raise AssertionError

# Generated at 2022-06-25 01:08:50.732471
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    result = HPUXVirtual().get_virtual_facts()
    assert result is not None

# Generated at 2022-06-25 01:09:02.132594
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual({}, None, None)


# Generated at 2022-06-25 01:09:03.292278
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:09:10.688088
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_type': '', 'virtualization_role': ''}, "If no virtualization technologies are detected, the virtualization_type, virtualization_role, virtualization_tech_host, and virtualization_tech_guest should be empty"
    h_p_u_x_virtual_0._module.run_command = lambda x: (0, '', '')
    h_p_u_x_virtual_0._module.tmpdir = lambda: '/'

# Generated at 2022-06-25 01:09:13.207803
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(module=None)


# Generated at 2022-06-25 01:09:14.472407
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_instance_0 = HPUXVirtual('ansible.module_utils.facts.virtual.hpux')

# Generated at 2022-06-25 01:09:17.029558
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    assert HPUXVirtual().get_virtual_facts() == {
        'virtualization_type': 'guest',
        'virtualization_role': 'HP vPar',
        'virtualization_tech_guest': {'HP vPar'},
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-25 01:09:20.086995
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual = HPUXVirtual(None)
    assert h_p_u_x_virtual.get_virtual_facts() == {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
        'virtualization_type': 'host',
        'virtualization_role': 'HPVM'
    }

# Generated at 2022-06-25 01:09:21.061596
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()
    print(h_p_u_x_virtual)

# Generated at 2022-06-25 01:09:24.922344
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual({})
    h_p_u_x_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:09:26.642182
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:09:40.396220
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:09:45.727851
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    ansible_module_1 = AnsibleModule(
        argument_spec={})
    if not h_p_u_x_virtual_0.get_virtual_facts():
        assert False
    h_p_u_x_virtual_0.module = ansible_module_1
    if not h_p_u_x_virtual_0.get_virtual_facts():
        assert False


# Generated at 2022-06-25 01:09:53.355679
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Set up mock facts object
    fake_ansible_module = FakeAnsibleModule()
    h_p_u_x_virtual_0 = HPUXVirtual({}, fake_ansible_module)

    # Set up expected results
    expected_results_0 = {'virtualization_type': 'guest', 'virtualization_role': 'HP nPar', 'virtualization_tech_guest': set(['HP nPar']), 'virtualization_tech_host': set([])}

    # Make the call.
    actual_results_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert (actual_results_0 == expected_results_0)


# Generated at 2022-06-25 01:10:00.050103
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_1 = HPUXVirtual()
    h_p_u_x_virtual_2 = HPUXVirtual()
    h_p_u_x_virtual_3 = HPUXVirtual()
    h_p_u_x_virtual_4 = HPUXVirtual()
    h_p_u_x_virtual_5 = HPUXVirtual()
    h_p_u_x_virtual_6 = HPUXVirtual()
    h_p_u_x_virtual_7 = HPUXVirtual()
    h_p_u_x_virtual_8 = HPUXVirtual()
    h_p_u_x_virtual_9 = HPUXVirtual()
    h_p_u_x_

# Generated at 2022-06-25 01:10:05.040021
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module_args = dict()
    set_module_args(module_args)

    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module = FakeModule(module_args)

    # Test if we are running on HP vPar
    h_p_u_x_virtual_0.module.exists.side_effect = lambda x: True if x == '/usr/sbin/vecheck' else False
    h_p_u_x_virtual_0.module.rc.side_effect = lambda x, **kwargs: 0 if x == '/usr/sbin/vecheck' else 1
    result = h_p_u_x_virtual_0.get_virtual_facts()
    assert result['virtualization_type'] == 'guest'
    assert result

# Generated at 2022-06-25 01:10:06.324852
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual({})
    assert(h_p_u_x_virtual_0._platform == 'HP-UX')

# Generated at 2022-06-25 01:10:16.337990
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    # Test with True as argument.
    h_p_u_x_virtual_0.module.exit_json = lambda x: x
    h_p_u_x_virtual_0.module.fail_json = lambda x: x
    h_p_u_x_virtual_0.module.run_command = lambda *x: (0, '', '')
    h_p_u_x_virtual_0.module.params = {}
    h_p_u_x_virtual_0.get_virtual_facts()
    h_p_u_x_virtual_0.module.run_command = lambda *x: (1, '', '')
    h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:10:17.467623
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual
    assert h_p_u_x_virtual_0.platform == 'HP-UX'

# Generated at 2022-06-25 01:10:19.822814
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux_virtual import HPUXVirtual
    h_p_u_x_virtual_0 = HPUXVirtual({'module': 'dummy'})
    h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:10:28.107858
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual(module=None)
    h_p_u_x_virtual_0.module.run_command = lambda x: (0, 'Running HPVM guest', '')
    assert h_p_u_x_virtual_0.get_virtual_facts() == {
        'virtualization_role': 'HPVM IVM',
        'virtualization_type': 'guest',
        'virtualization_tech_guest': set(['HPVM IVM']),
        'virtualization_tech_host': set(),
    }
    h_p_u_x_virtual_0 = HPUXVirtual(module=None)
    h_p_u_x_virtual_0.module.run_command = lambda x: (0, 'Running HPVM vPar', '')


# Generated at 2022-06-25 01:10:45.965262
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual({})


# Generated at 2022-06-25 01:10:46.613641
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    obj = HPUXVirtual()
#

# Generated at 2022-06-25 01:10:48.212043
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.get_virtual_facts() is None


# Generated at 2022-06-25 01:10:50.317905
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(dict())


# Generated at 2022-06-25 01:10:52.082630
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_type': 'guest', 'virtualization_role': 'HP nPar', 'virtualization_tech_guest': {'HP nPar'}, 'virtualization_tech_host': set()}

# Generated at 2022-06-25 01:11:00.805615
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    module = AnsibleModuleMock()
    module.run_command = run_command_mock()
    h_p_u_x_virtual_0.module = module
    h_p_u_x_virtual_0._get_virtual_facts()
    dict_0 = h_p_u_x_virtual_0.facts
    assert dict_0['virtualization_type'] == 'host'
    assert dict_0['virtualization_role'] == 'HPVM'
    assert list_eq(dict_0['virtualization_tech_host'], ['HPVM'])
    assert list_eq(dict_0['virtualization_tech_guest'], ['HPVM'])



# Generated at 2022-06-25 01:11:06.166339
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module = AnsibleModule(argument_spec=dict())
    h_p_u_x_virtual_0.module.run_command = MagicMock(return_value=(0, '', ''))
    h_p_u_x_virtual_0.os_path = MagicMock()
    h_p_u_x_virtual_0.os_path.exists = MagicMock(return_value=False)
    expected_result = {}
    expected_result['virtualization_tech_host'] = set()
    expected_result['virtualization_tech_guest'] = set()
    result = h_p_u

# Generated at 2022-06-25 01:11:06.571704
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    pass

# Generated at 2022-06-25 01:11:07.390280
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()


# Generated at 2022-06-25 01:11:15.171441
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class MockModule:
        def run_command(self):
            return 0, 'foo out', ''
    mock_module = MockModule()
    module_return_value = HPUXVirtual(mock_module).get_virtual_facts()
    assert module_return_value['virtualization_tech_guest'] == set()
    assert module_return_value['virtualization_tech_host'] == set()
    assert module_return_value['virtualization_type'] == 'guest'
    assert module_return_value['virtualization_role'] == 'HPVM vPar'


# Generated at 2022-06-25 01:11:31.025587
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    var_2 = dict()
    h_p_u_x_virtual_1 = HPUXVirtual(var_2)
    assert h_p_u_x_virtual_1.get_virtual_facts() == {}


# Generated at 2022-06-25 01:11:33.011319
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    var_1 = dict()
    h_p_u_x_virtual_1 = HPUXVirtual(var_1)
    assert h_p_u_x_virtual_1.get_virtual_facts() is not False


# Generated at 2022-06-25 01:11:40.045321
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    var_2 = dict()
    h_p_u_x_virtual_1 = HPUXVirtual(var_2)
    var_3 = h_p_u_x_virtual_1.get_virtual_facts()
    print(var_3)

if __name__ == "__main__":

    test_case_0()
    test_HPUXVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:11:42.156036
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    var_0 = dict()
    h_p_u_x_virtual_0 = HPUXVirtual(var_0)
    var_1 = h_p_u_x_virtual_0.get_virtual_facts()
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:11:45.265434
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
  assert True

# Generated at 2022-06-25 01:11:51.291430
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    var_2 = dict()
    h_p_u_x_virtual_1 = HPUXVirtual(var_2)
    assert hasattr(h_p_u_x_virtual_1, '_HPUXVirtual__get_virtual_facts')
    assert hasattr(h_p_u_x_virtual_1, '_HPUXVirtual__build_virtual_facts')
    assert hasattr(h_p_u_x_virtual_1, '_HPUXVirtual__virtual_facts')
    assert hasattr(h_p_u_x_virtual_1, '_HPUXVirtual__module')
    var_3 = h_p_u_x_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:11:52.259169
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    assert type(h_p_u_x_virtual_0.get_virtual_facts()) == dict


# Generated at 2022-06-25 01:11:53.610821
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    var_3 = dict()
    h_p_u_x_virtual_1 = HPUXVirtual(var_3)


# Generated at 2022-06-25 01:12:02.497231
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    var_2 = dict()
    h_p_u_x_virtual_1 = HPUXVirtual(var_2)
    var_3 = h_p_u_x_virtual_1.get_virtual_facts()
    if 'virtualization_type' in var_3.keys():
        assert True
    else:
        assert False
    if 'virtualization_role' in var_3.keys():
        assert True
    else:
        assert False
    if 'virtualization_tech_host' in var_3.keys():
        assert True
    else:
        assert False
    if 'virtualization_tech_guest' in var_3.keys():
        assert True
    else:
        assert False

# Generated at 2022-06-25 01:12:09.321117
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    var_0 = dict()
    h_p_u_x_virtual_0 = HPUXVirtual(var_0)
    var_1 = h_p_u_x_virtual_0.get_virtual_facts()
    assert (var_1['virtualization_role'] == 'HPVM' or var_1['virtualization_role'] == 'HP nPar' or var_1['virtualization_role'] == 'HP vPar' or var_1['virtualization_role'] == 'HPVM vPar' or var_1['virtualization_role'] == 'HPVM IVM' or var_1['virtualization_role'] == 'host' or var_1['virtualization_role'] == 'guest')

# Generated at 2022-06-25 01:12:37.620033
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
  pass

# Generated at 2022-06-25 01:12:44.296747
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    var_0 = dict()
    h_p_u_x_virtual_0 = HPUXVirtual(var_0)
    assert h_p_u_x_virtual_0._is_hp_vm_par == False
    assert h_p_u_x_virtual_0._parstatus_out == True
    assert h_p_u_x_virtual_0.virtual_facts == dict()
    assert h_p_u_x_virtual_0.module == var_0
    assert h_p_u_x_virtual_0.module_name == 'HPUXVirtual'
    assert h_p_u_x_virtual_0.platform == 'HP-UX'


# Generated at 2022-06-25 01:12:49.601577
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    var_0 = dict()
    h_p_u_x_virtual_0 = HPUXVirtual(var_0)
    var_1 = h_p_u_x_virtual_0.get_virtual_facts()
    var_2 = var_1
    assert any(var_2)


# Generated at 2022-06-25 01:12:52.228743
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert False

# Unit tests for method get_virtual_facts() of class HPUXVirtual

# Generated at 2022-06-25 01:13:01.967291
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    var_0 = dict()
    h_p_u_x_virtual_0 = HPUXVirtual(var_0)
    print("type of returned object: ", type(h_p_u_x_virtual_0))
    print("value of virtualization_type: ", h_p_u_x_virtual_0.virtualization_type)
    print("value of virtualization_role: ", h_p_u_x_virtual_0.virtualization_role)
    print("value of virtualization_relative_number: ", h_p_u_x_virtual_0.virtualization_relative_number)
    print("value of virtualization_product_name: ", h_p_u_x_virtual_0.virtualization_product_name)

# Generated at 2022-06-25 01:13:06.662090
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    var_0 = dict()
    h_p_u_x_virtual_0 = HPUXVirtual(var_0)
    var_1 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:13:16.264980
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_1 = HPUXVirtual(dict(virtualization_type=True,virtualization_role=True,virtualization_technology_guest=True,virtualization_technology_host=True,virtualization_technology=True), dict())
    assert h_p_u_x_virtual_1 != None
    assert h_p_u_x_virtual_1.module == dict(virtualization_type=True,virtualization_role=True,virtualization_technology_guest=True,virtualization_technology_host=True,virtualization_technology=True)
    assert h_p_u_x_virtual_1.platform == 'HP-UX'
    assert h_p_u_x_virtual_1.virtual_facts == dict()
    assert h_p_u_x_virtual_1.virtualization == dict

# Generated at 2022-06-25 01:13:22.930843
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    var_0 = dict()
    h_p_u_x_virtual_0 = HPUXVirtual(var_0)
    var_1 = h_p_u_x_virtual_0.get_virtual_facts()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 01:13:32.173003
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    var_2 = dict()
    h_p_u_x_virtual_1 = HPUXVirtual(var_2)
    var_3 = h_p_u_x_virtual_1.get_virtual_facts()
    assert (HPUXVirtualCollector._fact_class == HPUXVirtual)
    assert (HPUXVirtualCollector._platform == 'HP-UX')
    assert (h_p_u_x_virtual_1.platform == 'HP-UX')
    assert (isinstance(var_3, dict))
    assert (var_3['virtualization_type'] == 'guest')
    assert (isinstance(var_3['virtualization_role'], str))
    assert (isinstance(var_3['virtualization_tech_host'], set))

# Generated at 2022-06-25 01:13:39.009608
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    var_2 = dict()
    h_p_u_x_virtual_1 = HPUXVirtual(var_2)
    var_3 = h_p_u_x_virtual_1.get_virtual_facts()
    var_4 = 'virtualization_role'
    var_5 = var_3['virtualization_role']
    assert var_5 == 'HP vPar'


# Generated at 2022-06-25 01:14:20.152673
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    var_0 = dict()
    h_p_u_x_virtual_0 = HPUXVirtual(var_0)


# Generated at 2022-06-25 01:14:26.100952
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    var_5 = dict()
    h_p_u_x_virtual_1 = HPUXVirtual(var_5)
    var_6 = h_p_u_x_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:14:27.732715
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    var_0 = dict()
    h_p_u_x_virtual_0 = HPUXVirtual(var_0)


# Generated at 2022-06-25 01:14:29.097032
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    assert (HPUXVirtual.get_virtual_facts)

# Generated at 2022-06-25 01:14:39.953475
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    var_0 = dict()
    h_p_u_x_virtual_0 = HPUXVirtual(var_0)
    var_2 = None
    if (isinstance(var_2, HPUXVirtual)):
        var_3 = var_2.get_virtual_facts()
        print(var_3)
    print(var_2)
    print(h_p_u_x_virtual_0)
    var_2 = h_p_u_x_virtual_0
    if (isinstance(var_2, HPUXVirtual)):
        var_3 = var_2.get_virtual_facts()
        print(var_3)
    print(var_2)
    print(h_p_u_x_virtual_0)
    var_1 = h_p_u_x_virtual

# Generated at 2022-06-25 01:14:43.567390
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    var_0 = dict()
    h_p_u_x_virtual_0 = HPUXVirtual(var_0)

# Generated at 2022-06-25 01:14:49.870916
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    var_0 = dict()
    h_p_u_x_virtual_0 = HPUXVirtual(var_0)
    var_1 = h_p_u_x_virtual_0.get_virtual_facts()
    assert isinstance(var_1, dict)
    test_case_0()


# Generated at 2022-06-25 01:14:52.718269
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    var_0 = dict()
    h_p_u_x_virtual_0 = HPUXVirtual(var_0)
    assert h_p_u_x_virtual_0._platform == 'HP-UX'
    assert h_p_u_x_virtual_0._module == var_0
    assert h_p_u_x_virtual_0._virtual_facts == {}


# Generated at 2022-06-25 01:14:56.862463
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    var_0 = dict()
    h_p_u_x_virtual_0 = HPUXVirtual(var_0)
    var_1 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:15:00.354581
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    var_0 = dict()
    h_p_u_x_virtual_0 = HPUXVirtual(var_0)
    assert h_p_u_x_virtual_0
    assert h_p_u_x_virtual_0.module


# Generated at 2022-06-25 01:15:59.536357
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    var_0 = dict()
    h_p_u_x_virtual_0 = HPUXVirtual(var_0)
    assert h_p_u_x_virtual_0.platform == 'HP-UX'

# Generated at 2022-06-25 01:16:04.976376
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    var_0 = dict()
    h_p_u_x_virtual_0 = HPUXVirtual(var_0)
    assert h_p_u_x_virtual_0._distro == 'HP-UX'


# Generated at 2022-06-25 01:16:08.197840
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    var_2 = dict()
    h_p_u_x_virtual_1 = HPUXVirtual(var_2)
    var_3 = h_p_u_x_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:16:10.348640
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    var_0 = dict()
    h_p_u_x_virtual_0 = HPUXVirtual(var_0)
    var_1 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:16:12.556759
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    var_0 = dict()
    h_p_u_x_virtual_0 = HPUXVirtual(var_0)
    var_1 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:16:15.991361
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    var_2 = dict()
    var_3 = HPUXVirtual(var_2)
    assert (var_3 is not False)


# Generated at 2022-06-25 01:16:16.965761
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    var_2 = dict()
    h_p_u_x_virtual_1 = HPUXVirtual(var_2)


# Generated at 2022-06-25 01:16:24.228905
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    var_2 = dict()
    h_p_u_x_virtual_1 = HPUXVirtual(var_2)
    var_3 = {'virtualization_type': 'guest', 'virtualization_role': 'HP vPar'}
    var_4 = {'virtualization_type': 'guest', 'virtualization_role': 'HPVM vPar'}
    var_5 = {'virtualization_type': 'guest', 'virtualization_role': 'HPVM IVM'}
    var_6 = {'virtualization_type': 'host', 'virtualization_role': 'HPVM'}
    var_7 = {'virtualization_type': 'guest', 'virtualization_role': 'HP nPar'}
    # No virtualization

# Generated at 2022-06-25 01:16:26.664364
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    var_0 = dict()
    h_p_u_x_virtual_0 = HPUXVirtual(var_0)


# Generated at 2022-06-25 01:16:34.485879
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    var_2 = dict()
    var_3 = HPUXVirtual(var_2)
    assert ('virtualization_type' in var_3.available_facts)
    assert ('virtualization_role' in var_3.available_facts)
    assert ('virtualization_tech_guest' in var_3.available_facts)
    assert ('virtualization_tech_host' in var_3.available_facts)
    assert (var_3.__class__.__name__ == 'HPUXVirtual')
    assert (var_3.platform == 'HP-UX')