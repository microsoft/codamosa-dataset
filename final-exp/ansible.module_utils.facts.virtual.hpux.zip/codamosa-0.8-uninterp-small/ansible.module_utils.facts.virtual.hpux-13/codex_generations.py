

# Generated at 2022-06-25 01:07:45.452298
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    # Check if the object was initialized properly

    if isinstance(h_p_u_x_virtual_0, Virtual):
        is_init = True
    else:
        is_init = False

    assert is_init


# Generated at 2022-06-25 01:07:47.348258
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()

    h_p_u_x_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:07:54.740730
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module = AnsibleModuleMock()
    assert h_p_u_x_virtual_0.module == AnsibleModuleMock()
    assert h_p_u_x_virtual_0.platform == 'HP-UX'
    assert h_p_u_x_virtual_0.virt_subtype_fact_name == 'virtualization_subtype'
    assert h_p_u_x_virtual_0.virt_who_command == 'hp-virt'
    assert h_p_u_x_virtual_0.virt_what_command == '/usr/sbin/parstatus'

# Generated at 2022-06-25 01:07:55.992732
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:08:00.436631
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert 'HPUXVirtual' == h_p_u_x_virtual_0.__class__.__name__
    assert h_p_u_x_virtual_0.platform == 'HP-UX'
    assert h_p_u_x_virtual_0.system == 'HP-UX'


# Generated at 2022-06-25 01:08:01.952545
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    obj = HPUXVirtual()


# Generated at 2022-06-25 01:08:05.733350
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class MockModule(object):
        module = {}
        params = {}
        check_mode = False
        no_log = False
        run_command = lambda self, _: (0, '', '')

    h_p_u_x_virtual_0 = HPUXVirtual(MockModule())
    assert h_p_u_x_virtual_0.get_virtual_facts() is not None


# Generated at 2022-06-25 01:08:08.034083
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual({"module_name": "test"}, "test_value")


# Generated at 2022-06-25 01:08:14.644836
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual({'module': {'run_command': lambda x: [0, '', ''], 'path': {'exists': lambda x: 1}, 'params': {'gather_subset': []}, 'check_mode': 0, 'get_bin_path': lambda x, opt_dirs=None: '/usr/bin/' + x, 'fail_json': lambda **args: True, 'fail_json_on_missing_params': lambda **args: True}})
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:08:15.809456
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:08:30.360964
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module = ansible_module_0
    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_type': 'guest', 'virtualization_role': 'HP vPar'}


# Generated at 2022-06-25 01:08:35.037499
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.supported_facts['virtual_facts'] = True
    facts_dict_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert type(facts_dict_0) is dict
    assert 'virtualization_type' in facts_dict_0
    assert 'virtualization_role' in facts_dict_0


# Generated at 2022-06-25 01:08:39.172662
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual({})
    assert isinstance(h_p_u_x_virtual_0, HPUXVirtual)
    assert h_p_u_x_virtual_0.data == {}
    assert h_p_u_x_virtual_0.platform == 'HP-UX'

# Generated at 2022-06-25 01:08:45.594701
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_collector_0 = HPUXVirtualCollector()
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module = ""
    h_p_u_x_virtual_0.path_exists = ""
    h_p_u_x_virtual_0.gather_subset = ""
    h_p_u_x_virtual_0.run_command = ""


# Generated at 2022-06-25 01:08:51.746478
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import HPUXVirtual
    from ansible.module_utils.facts import BaseFactCollector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.facts.virtual.hpux.hpux_virtual import HPUXVirtualCollector
    h_p_u_x_virtual_0 = HPUXVirtual(BaseFactCollector(Connection('', '', '', '', '')))
    assert h_p_u_x_virtual_0.get_virtual_facts() == {}


# Generated at 2022-06-25 01:08:54.462313
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_obj = HPUXVirtual()
    for key,value in h_p_u_x_virtual_obj.get_virtual_facts().items():
        print("Facts for class HPUXVirtual : ", key, " - ", value)
    assert h_p_u_x_virtual_obj.get_virtual_facts()['virtualization_type'] == 'host'
    

# Generated at 2022-06-25 01:08:55.372572
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()

# Generated at 2022-06-25 01:08:57.570070
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert 'hpuxvirtual' == HPUXVirtual().get_module_name()


# Generated at 2022-06-25 01:08:58.532861
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()

# Generated at 2022-06-25 01:09:00.633351
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert len(HPUXVirtualCollector().collect()) > 0

# Generated at 2022-06-25 01:09:11.316109
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()


# Generated at 2022-06-25 01:09:12.989379
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(ansible_module=None)
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:09:14.017014
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:09:20.894396
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    hpux_virtual_0 = HPUXVirtual()
    hpux_virtual_1 = HPUXVirtual()
    hpux_virtual_2 = HPUXVirtual()
    hpux_virtual_3 = HPUXVirtual()
    hpux_virtual_4 = HPUXVirtual()
    assert hpux_virtual_0.get_virtual_facts() == {'virtualization_type': 'host', 'virtualization_tech_host': set(), 'virtualization_tech_guest': {'HPVM', 'HP nPar', 'HP vPar'}, 'virtualization_role': 'HPVM'}

# Generated at 2022-06-25 01:09:23.985448
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()


# Generated at 2022-06-25 01:09:25.183159
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual({})


# Generated at 2022-06-25 01:09:32.427192
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=['!all'], type='list')
        },
        supports_check_mode=True
    )
    # Test case with expected values
    h_p_u_x_virtual = HPUXVirtual(module)
    # Define the return values from above
    h_p_u_x_virtual_platform = 'HP-UX'
    # Test if the expected values are defined correctly
    assert h_p_u_x_virtual.platform == h_p_u_x_virtual_platform

# Unit tests for class HPUXVirtualCollector

# Generated at 2022-06-25 01:09:35.306060
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()


# Generated at 2022-06-25 01:09:37.145831
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:09:39.184772
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:09:52.373009
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual(module=None)
    assert h_p_u_x_virtual is not None


# Generated at 2022-06-25 01:09:59.326718
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual = HPUXVirtual()
    # get_virtual_facts execute command
    h_p_u_x_virtual.module.run_command = lambda args, check_rc=True: (0, "hpvminfo", "")
    virtualization_type = h_p_u_x_virtual.get_virtual_facts()['virtualization_type']
    assert virtualization_type == 'guest'
    virtualization_role = h_p_u_x_virtual.get_virtual_facts()['virtualization_role']
    assert virtualization_role == 'HPVM IVM'
    virtualization_tech_guest = h_p_u_x_virtual.get_virtual_facts()['virtualization_tech_guest']
    assert "HPVM IVM" in virtualization_tech_gu

# Generated at 2022-06-25 01:10:01.370134
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert (h_p_u_x_virtual_0.get_virtual_facts()['virtualization_tech_guest'] == {'HP nPar', 'HP vPar'})

# Generated at 2022-06-25 01:10:05.380468
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()
    # Test for class HPUXVirtual constructor
    assert isinstance(h_p_u_x_virtual, HPUXVirtual)


# Generated at 2022-06-25 01:10:09.074258
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module.run_command = lambda cmd: (0, "Running HPVM guest.", "")
    h_p_u_x_virtual_facts_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert h_p_u_x_virtual_facts_0['virtualization_type'] == 'guest'
    assert h_p_u_x_virtual_facts_0['virtualization_role'] == 'HPVM IVM'


# Generated at 2022-06-25 01:10:12.196365
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_collector_0 = HPUXVirtualCollector()
    h_p_u_x_virtual_0 = h_p_u_x_virtual_collector_0.collect()
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:10:16.338711
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec={}
    )

    h_p_u_x_virtual_0 = HPUXVirtual(module)
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:10:21.456625
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    arguments = dict(
        module=dict(type='AnsibleModule'),
    )
    h_p_u_x_virtual_0 = HPUXVirtual(**arguments)

    arguments = dict(
        cmd=dict(type='str'),
        rc=dict(type='int'),
        out=dict(type='str'),
        err=dict(type='str'),
    )
    h_p_u_x_virtual_0.module.run_command = MagicMock(**arguments)
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:10:25.807462
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(
            foo=dict(required=False, type='str')
        ),
        supports_check_mode=True
    )
    h_p_u_x_virtual_0 = HPUXVirtual(module)

    # Use AnsibleModule.run_command instead of module.run_command
    rc, out, err = module.run_command("/usr/sbin/parstatus")
    if rc == 0:
        guest_tech = set()

        h_p_u_x_virtual_0.virtualization_type = 'guest'
        h_p_u_x_virtual_0.virtualization_role = 'HP nPar'
        guest_tech.add('HP nPar')
        h_p_u_x_virtual_0.virtualization_tech_

# Generated at 2022-06-25 01:10:30.951257
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():

    # Create a new instance of HPUXVirtual
    h_p_u_x_virtual_0 = HPUXVirtual()

    # Check attributes of HPUXVirtual
    assert h_p_u_x_virtual_0.platform == 'HP-UX'
    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_type': '', 'virtualization_role': ''}


# Generated at 2022-06-25 01:10:46.814192
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.platform == 'HP-UX'


# Generated at 2022-06-25 01:10:47.701299
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()

# Generated at 2022-06-25 01:10:51.037127
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(module=None, subprocess=None)
    assert not h_p_u_x_virtual_0.module
    assert not h_p_u_x_virtual_0.subprocess


# Generated at 2022-06-25 01:10:55.069189
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Set object
    h_p_u_x_virtual_0 = HPUXVirtual()
    # Store return value of method get_virtual_facts in local variable
    h_p_u_x_virtual_get_virtual_facts_local_var = h_p_u_x_virtual_0.get_virtual_facts()
    # Assertion of method get_virtual_facts of class HPUXVirtual
    assert h_p_u_x_virtual_get_virtual_facts_local_var is not None


# Generated at 2022-06-25 01:11:01.824407
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module_args = dict(
        gathering='minimal'
    )
    h_p_u_x_virtual_0 = HPUXVirtual(module_args)

    assert(h_p_u_x_virtual_0 is not None)
    assert(h_p_u_x_virtual_0.module.params['gathering'] == 'minimal')

# Generated at 2022-06-25 01:11:06.292036
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()

    assert(h_p_u_x_virtual_0.platform == 'HP-UX')



# Generated at 2022-06-25 01:11:07.697159
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.get_virtual_facts() != {}

# Generated at 2022-06-25 01:11:14.579751
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module.run_command = run_command_mock
    h_p_u_x_virtual_0.get_virtual_facts()
    h_p_u_x_virtual_0.module.fail_json.assert_called_with(msg='Unknown HP-UX virtualization type.')


# Generated at 2022-06-25 01:11:19.314503
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:11:20.375218
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:11:41.623388
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual(module=None)

    res = h_p_u_x_virtual_0.get_virtual_facts()
    assert not res['virtualization_tech_host']
    assert res['virtualization_type'] == 'guest'
    assert res['virtualization_role'] == 'HP nPar'
    assert res['virtualization_tech_guest'] == {'HP nPar'}

# Generated at 2022-06-25 01:11:51.339070
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0._module = MockModule()
    h_p_u_x_virtual_0.get_virtual_facts()
    h_p_u_x_virtual_0._module = MockModule()
    h_p_u_x_virtual_0.get_virtual_facts()
    h_p_u_x_virtual_0._module = MockModule()
    h_p_u_x_virtual_0.get_virtual_facts()
    h_p_u_x_virtual_0._module = MockModule()


# Generated at 2022-06-25 01:11:51.906235
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    assert HPUXVirtual()

# Generated at 2022-06-25 01:11:54.171183
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    hpux_virtual_0 = HPUXVirtual()
    hpux_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:12:01.924173
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual({})
    # Test whether instance created properly
    assert isinstance(h_p_u_x_virtual_0, HPUXVirtual)
    class0 = h_p_u_x_virtual_0.__class__.__name__
    method0 = h_p_u_x_virtual_0.get_virtual_facts.__func__.__name__
    # Test whether methods named correctly
    assert class0 == "HPUXVirtual"
    assert method0 == "get_virtual_facts"


# Generated at 2022-06-25 01:12:07.963837
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Arrange
    h_p_u_x_virtual_0 = HPUXVirtual(module)

    # Act
    actual = h_p_u_x_virtual_0.get_virtual_facts()

    # Assert
    assert actual == {'virtualization_role': 'HP nPar', 'virtualization_type': 'guest', 'virtualization_tech_host': {}, 'virtualization_tech_guest': {'HP nPar'}}


# Generated at 2022-06-25 01:12:11.530819
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Test case for 'HPUXVirtual.get_virtual_facts'
    """
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_role': 'HP nPar',
                                                     'virtualization_tech_guest': {'HP nPar'},
                                                     'virtualization_tech_host': set(),
                                                     'virtualization_type': 'guest'}

# Generated at 2022-06-25 01:12:12.410208
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:12:20.034967
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual_0 = HPUXVirtual()
    # After the above method, value of 'virtualization_type' = None
    # After the above method, value of 'virtualization_role' = None
    # After the above method, value of 'virtualization_tech_host' = set()
    # After the above method, value of 'virtualization_tech_guest' = set()


# Generated at 2022-06-25 01:12:20.770365
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()

# Generated at 2022-06-25 01:12:45.314730
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()

    rc, out, err = h_p_u_x_virtual_0.module.run_command("/usr/sbin/vecheck")
    if rc == 0:
        guest_tech = set()
        guest_tech.add('HP vPar')
        virtual_facts = {}
        virtual_facts['virtualization_type'] = 'guest'
        virtual_facts['virtualization_role'] = 'HP vPar'
        virtual_facts['virtualization_tech_host'] = set()
        virtual_facts['virtualization_tech_guest'] = guest_tech
        assert virtual_facts == h_p_u_x_virtual_0.get_virtual_facts()
    else:
        rc, out, err = h_p_u_x_

# Generated at 2022-06-25 01:12:48.951874
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:12:53.006458
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()
    h_p_u_x_virtual.get_virtual_facts()

    assert h_p_u_x_virtual.platform == 'HP-UX'
    assert h_p_u_x_virtual.virtual_facts['virtualization_tech_guest'] == set()
    assert h_p_u_x_virtual.virtual_facts['virtualization_tech_host'] == set()


# Generated at 2022-06-25 01:12:57.800019
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module = MockAnsibleModule()
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:13:00.265431
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual({})
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:13:04.152591
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.platform == 'HP-UX'


# Generated at 2022-06-25 01:13:11.178275
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual('ansible.module_utils.facts.virtual.h_p_u_x.module')
    h_p_u_x_virtual_0.module.run_command = run_command
    h_p_u_x_virtual_0.module.exit_json = exit_json
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:13:16.011059
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()
    assert h_p_u_x_virtual.__class__.__name__ == 'HPUXVirtual'
    assert h_p_u_x_virtual.__doc__ == '\n    This is a HP-UX specific subclass of Virtual. It defines\n    - virtualization_type\n    - virtualization_role\n    '


# Generated at 2022-06-25 01:13:16.903882
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:13:19.369193
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0._module = h_p_u_x_virtual_0
    h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:13:29.351671
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:13:31.329593
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()



# Generated at 2022-06-25 01:13:38.436485
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # Test for proper initialization of class
    assert isinstance(HPUXVirtual().__class__, Virtual)
    # Test for proper wording of virtualization_type and virtualization_role
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert "virtualization_type" in h_p_u_x_virtual_0.get_virtual_facts().keys()
    assert "virtualization_role" in h_p_u_x_virtual_0.get_virtual_facts().keys()
    assert "virtualization_tech_host" in h_p_u_x_virtual_0.get_virtual_facts().keys()
    assert "virtualization_tech_guest" in h_p_u_x_virtual_0.get_virtual_facts().keys()

# Generated at 2022-06-25 01:13:41.928523
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()


# Generated at 2022-06-25 01:13:47.981739
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
# Constructing an instance of the HPUXVirtual class with the module object
    h_p_u_x_virtual_1 = HPUXVirtual(module)
    assert h_p_u_x_virtual_1



# Generated at 2022-06-25 01:13:58.586956
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_collector_1 = HPUXVirtualCollector()
    h_p_u_x_virtual_0 = HPUXVirtual(h_p_u_x_virtual_collector_1, {'HPUXVirtual': {'DATA': 'dict'}})
    h_p_u_x_virtual_1 = HPUXVirtual(h_p_u_x_virtual_collector_1, {'HPUXVirtual': {'DATA': 'dict'}})
    h_p_u_x_virtual_2 = HPUXVirtual(h_p_u_x_virtual_collector_1, {'HPUXVirtual': {'DATA': 'dict'}})
    result = h_p_u_x_virtual_0.get_virtual_facts()
    assert result

# Generated at 2022-06-25 01:14:06.014143
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module = MockModule()
    h_p_u_x_virtual_0.module.run_command = Mock(return_value=(0, '', ''))
    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}


# Generated at 2022-06-25 01:14:07.822099
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()

# Generated at 2022-06-25 01:14:12.990309
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    out1 = h_p_u_x_virtual_0.get_virtual_facts()
    assert out1['virtualization_role'] == 'HP vPar'
    assert out1['virtualization_type'] == 'guest'
    assert out1['virtualization_tech_host'] == set()



# Generated at 2022-06-25 01:14:13.977246
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()

# Generated at 2022-06-25 01:14:27.314494
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual(module=None)
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:14:34.856238
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_type': 'guest', 'virtualization_role': 'HP nPar', 'virtualization_tech_guest': {'HP nPar'}, 'virtualization_tech_host': set([])}


# Generated at 2022-06-25 01:14:36.469378
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()

# Generated at 2022-06-25 01:14:37.710084
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:14:39.591581
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module_args = {}
    module = AnsibleModule(argument_spec=module_args)
    h_p_u_x_virtual = HPUXVirtual(module)


# Generated at 2022-06-25 01:14:40.872304
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0 is not None


# Generated at 2022-06-25 01:14:43.662479
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()



# Generated at 2022-06-25 01:14:48.941370
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
        h_p_u_x_virtual_0 = HPUXVirtual({})
        assert isinstance(h_p_u_x_virtual_0._module, object)


# Generated at 2022-06-25 01:14:54.741941
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0._module = MockModule()
    h_p_u_x_virtual_0._module.run_command = Mock()
    h_p_u_x_virtual_0._module.run_command.return_value = (0, 'Running in a HPVM vPar', '')
    virtual_facts = h_p_u_x_virtual_0.get_virtual_facts()
    correct_virtual_facts = {'virtualization_type': 'guest',
                             'virtualization_role': 'HPVM vPar',
                             'virtualization_tech_guest': {'HPVM vPar'},
                             'virtualization_tech_host': set()}
    assert virtual_facts == correct_virtual

# Generated at 2022-06-25 01:15:03.091577
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_collector_0 = HPUXVirtualCollector()
    h_p_u_x_virtual_0 = HPUXVirtualCollector._fact_class(h_p_u_x_virtual_collector_0.module)
    # Weird case because no vecheck/parstatus/hpvminfo
    rc, out, err = h_p_u_x_virtual_0.module.run_command("echo 'stout'")
    # assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_role': 'host', 'virtualization_type': 'host', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}
    # If we execute vecheck and it returns 0
    # assert h_p_u

# Generated at 2022-06-25 01:15:22.076044
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_type': 'host', 'virtualization_role': 'HPVM'}


# Generated at 2022-06-25 01:15:27.648584
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_get_virtual_facts_0 = h_p_u_x_virtual_0.get_virtual_facts()
    pass

# Generated at 2022-06-25 01:15:29.394064
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # should be True
    assert True == HPUXVirtual().is_platform_supported()
    # platform is HPUX
    assert 'HP-UX' == HPUXVirtual().platform


# Generated at 2022-06-25 01:15:36.208315
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    output = {
        'virtualization_type': 'guest',
        'virtualization_role': 'HPVM IVM',
        'virtualization_tech_guest': {
            'HPVM IVM',
        },
        'virtualization_tech_host': set(),
    }
    assert h_p_u_x_virtual_0.get_virtual_facts() == output

if __name__ == '__main__':
    test_case_0()
    test_HPUXVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:15:39.094996
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()

# Generated at 2022-06-25 01:15:45.363681
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    dict_0 = {}
    dict_1 = {}
    module_0 = AnsibleModule(
        argument_spec=dict_0,
        supports_check_mode=False
    )
    module_1 = AnsibleModule(
        argument_spec=dict_1,
        supports_check_mode=False
    )
    h_p_u_x_virtual_0 = HPUXVirtual(
        module=module_0
    )
    h_p_u_x_virtual_1 = HPUXVirtual(
        module=module_1
    )
    assert h_p_u_x_virtual_1.get_virtual_facts() == {'virtualization_role': None, 'virtualization_type': None, 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}

#

# Generated at 2022-06-25 01:15:46.236307
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual = HPUXVirtual()


# Generated at 2022-06-25 01:15:47.284627
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:15:51.334319
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    hpuxv = HPUXVirtual()
    hpuxv.module.run_command = run_command
    hpuxv.module.get_bin_path = lambda x: 'fake'
    res = hpuxv.get_virtual_facts()
    assert res['virtualization_type'] == 'guest'
    assert 'HPVM IVM' in res['virtualization_tech_host']
    assert res['virtualization_role'] == 'HPVM IVM'

# Generated at 2022-06-25 01:15:52.964841
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:16:11.156266
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual(module=None)
    print('Testing get_virtual_facts')
    assert h_p_u_x_virtual_0.get_virtual_facts() is None

# Generated at 2022-06-25 01:16:14.483631
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()
    assert h_p_u_x_virtual.get_virtual_facts() == {'virtualization_tech_host': set(),
                                                   'virtualization_type': 'guest',
                                                   'virtualization_tech_guest': {'HP vPar'},
                                                   'virtualization_role': 'HP vPar'}


# Generated at 2022-06-25 01:16:15.257586
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()

# Generated at 2022-06-25 01:16:16.167456
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:16:17.664720
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    out = h_p_u_x_virtual_0.get_virtual_facts()
    assert out is not None


# Generated at 2022-06-25 01:16:19.649620
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0_obj = HPUXVirtual()
    try:
        h_p_u_x_virtual_0_obj.get_virtual_facts()
    except Exception as exception:
        if exception.__class__.__name__ == 'NotImplementedError':
            assert True
        else:
            assert False


# Generated at 2022-06-25 01:16:23.271309
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:16:26.798643
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    HPUXVirtual_0 = HPUXVirtual()
    HPUXVirtual_0.module = None
    assert HPUXVirtual_0.get_virtual_facts() == {}

# Generated at 2022-06-25 01:16:29.509564
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:16:33.048185
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual(module=None)
    facts = {}
    h_p_u_x_virtual_0.network_module.run_command.return_value = (0, '', '')
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:16:53.755524
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    module = type('', (), {})()
    module.run_command = lambda *args, **kwargs: (0, '', '')
    h_p_u_x_virtual_0.module = module
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:16:59.681047
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:17:01.572827
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    virtual_facts = h_p_u_x_virtual_0.get_virtual_facts()
    assert type(virtual_facts) is dict


# Generated at 2022-06-25 01:17:05.946155
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():

    # Execute constructor of class HPUXVirtual
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:17:06.858685
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual({})


# Generated at 2022-06-25 01:17:10.108813
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.get_virtual_facts() # method call


# Generated at 2022-06-25 01:17:13.513824
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:17:14.952513
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual = HPUXVirtual()
    h_p_u_x_virtual.get_virtual_facts()

# Generated at 2022-06-25 01:17:24.541695
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module = MagicMock()
    h_p_u_x_virtual_0.module.run_command = MagicMock(return_value=(0, '{"cmd": ["/usr/sbin/vecheck", ""], "rc": 0, "delta": "0:00:00.053984", "stdout": "", "stdout_lines": [], "stderr": "", "stderr_lines": []}', ''))

# Generated at 2022-06-25 01:17:27.715041
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    virtual_0 = HPUXVirtual({})
    virtual_0.get_virtual_facts()

if __name__ == "__main__":
    test_case_0()
    test_HPUXVirtual_get_virtual_facts()