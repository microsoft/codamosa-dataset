

# Generated at 2022-06-25 01:07:43.004133
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()

# Generated at 2022-06-25 01:07:45.085075
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual(module=None)
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:07:46.431601
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:07:47.787367
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:07:53.271842
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_collector_1 = HPUXVirtualCollector()
    h_p_u_x_virtual_0 = HPUXVirtual(h_p_u_x_virtual_collector_1._module)
    res = h_p_u_x_virtual_0.get_virtual_facts()
    assert 'virtualization_type' in res
    assert 'virtualization_role' in res
    assert 'virtualization_tech_guest' in res
    assert 'virtualization_tech_host' in res


# Generated at 2022-06-25 01:07:54.050220
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual()


# Generated at 2022-06-25 01:07:55.478561
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(module='h_p_u_x_virtual_module_0')

# Generated at 2022-06-25 01:07:57.561316
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.platform == 'HP-UX'


# Generated at 2022-06-25 01:08:00.507617
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Create a new instance of class HPUXVirtual
    h_p_u_x_virtual = HPUXVirtual()

    # Unit test for method get_virtual_facts of class HPUXVirtual
    h_p_u_x_virtual.get_virtual_facts()

# Generated at 2022-06-25 01:08:03.218039
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_1 = HPUXVirtual()


# Generated at 2022-06-25 01:08:16.720777
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    virtual_facts_1 = HPUXVirtual().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts_1  # True
    assert 'virtualization_role' in virtual_facts_1  # True
    assert virtual_facts_1['virtualization_type'] == 'guest'  # True
    assert virtual_facts_1['virtualization_role'] == 'HP nPar'  # True
    assert 'virtualization_tech_guest' in virtual_facts_1  # True
    assert 'virtualization_tech_host' in virtual_facts_1  # True


# Generated at 2022-06-25 01:08:17.464290
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert True



# Generated at 2022-06-25 01:08:26.460570
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Setup
    h_p_u_x_virtual = HPUXVirtual({"module": {}})

    # Exercise
    expected_virtual_facts = {'virtualization_type': 'guest',
                              'virtualization_role': 'HP vPar'}
    with os.popen(h_p_u_x_virtual.module.file_module._shell, 'w') as fd:
        fd.write('echo "Running HP vPar"')
    virtual_facts = h_p_u_x_virtual.get_virtual_facts()
    # Verify
    assert virtual_facts == expected_virtual_facts

    # Exercise
    expected_virtual_facts = {}
    with os.popen(h_p_u_x_virtual.module.file_module._shell, 'w') as fd:
        f

# Generated at 2022-06-25 01:08:32.236446
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module.run_command = lambda x: (0, '', '')
    result = h_p_u_x_virtual_0.get_virtual_facts()
    assert result.get('virtualization_type') == 'guest'
    assert result.get('virtualization_role') == 'HP vPar'
    assert result.get('virtualization_tech_host') == set()
    assert result.get('virtualization_tech_guest') == {'HP vPar'}


# Generated at 2022-06-25 01:08:37.481838
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual = HPUXVirtual()
    h_p_u_x_virtual.module = AnsibleModuleMock()
    h_p_u_x_virtual.module.run_command = run_command

    # Add your pre-existing test cases here
    # Test case for /usr/sbin/vecheck file
    if os.path.exists('/usr/sbin/vecheck'):
        rc, out, err = h_p_u_x_virtual.module.run_command("/usr/sbin/vecheck")

# Generated at 2022-06-25 01:08:39.369903
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:08:41.740257
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:08:50.372706
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual = HPUXVirtual()
    # Case 0: Tests if returnded virtualization_role is correct
    result0 = h_p_u_x_virtual.get_virtual_facts()['virtualization_role']
    if result0 == 'HPVM IVM':
        print("Correct! get_virtual_facts returned virtualization_role = 'HPVM IVM'")
    else:
        print("Wrong! get_virtual_facts did not returned virtualization_role = 'HPVM IVM'")
    # Case 1: Tests if returnded virtualization_type is correct
    result1 = h_p_u_x_virtual.get_virtual_facts()['virtualization_type']

# Generated at 2022-06-25 01:08:57.772973
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Test case for `HPUXVirtual.get_virtual_facts` method
    """
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0._module = unittest.mock.Mock()
    h_p_u_x_virtual_0._module.run_command = unittest.mock.Mock()
    h_p_u_x_virtual_0._module.run_command.return_value = [0, 'Running HPVM vPar', '']
    h_p_u_x_virtual_0.facts = unittest.mock.Mock()
    h_p_u_x_virtual_0.facts.items = unittest.mock.Mock()
    h_p_u_x_virtual

# Generated at 2022-06-25 01:08:58.713796
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual({}, {})

# Generated at 2022-06-25 01:09:14.942726
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0['virtualization_type'] == 'guest'
    assert var_0['virtualization_role'] == 'HP vPar'
    assert var_0['virtualization_tech_host'] == set()
    assert var_0['virtualization_tech_guest'] == {'HP vPar'}

# Generated at 2022-06-25 01:09:20.010129
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
  set_0 = set()
  h_p_u_x_virtual_0 = HPUXVirtual(set_0)
  var_0 = h_p_u_x_virtual_0.get_virtual_facts()
  var_1 = h_p_u_x_virtual_0.platform
  var_2 = h_p_u_x_virtual_0.data
  var_3 = h_p_u_x_virtual_0.get_all_facts()


# Generated at 2022-06-25 01:09:21.950521
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:09:26.007598
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    assert h_p_u_x_virtual_0.platform == 'HP-UX'
    assert h_p_u_x_virtual_0.module == set_0


# Generated at 2022-06-25 01:09:32.235401
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0['virtualization_tech_host'] == set()
    assert var_0['virtualization_tech_guest'] == set()
    assert var_0['virtualization_type'] == ''
    assert var_0['virtualization_role'] == ''



# Generated at 2022-06-25 01:09:39.222173
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    assert isinstance(h_p_u_x_virtual_0, HPUXVirtual)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

    assert var_0['virtualization_role'] == 'HP nPar'
    assert var_0['virtualization_type'] == 'guest'

# Generated at 2022-06-25 01:09:42.289384
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

if __name__ == '__main__':
    test_HPUXVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:09:46.091787
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    assert h_p_u_x_virtual_0


# Generated at 2022-06-25 01:09:50.632289
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    set_15 = set()
    h_p_u_x_virtual_1 = HPUXVirtual(set_15)
    var_1 = h_p_u_x_virtual_1.get_virtual_facts()
    assert (var_1 == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()})


# Generated at 2022-06-25 01:09:53.355419
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:10:06.352153
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:10:12.164933
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_type': 'guest', 'virtualization_role': 'HP nPar', 'virtualization_tech_host': set(), 'virtualization_tech_guest': {'HP nPar'}}


# Generated at 2022-06-25 01:10:18.548720
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # instantiate object with wrong params
    with pytest.raises(AttributeError):
        set_1 = set()
        h_p_u_x_virtual_1 = HPUXVirtual()
        var_1 = h_p_u_x_virtual_1.get_virtual_facts()
    # instantiate object with correct params
    set_2 = set()
    h_p_u_x_virtual_2 = HPUXVirtual(set_2)
    var_2 = h_p_u_x_virtual_2.get_virtual_facts()


# Generated at 2022-06-25 01:10:20.048302
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    pass


# Generated at 2022-06-25 01:10:24.813186
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    with patch.object(ansible_module_utils.facts.virtual.h_p_u_x.HPUXVirtual,
        "get_virtual_facts", autospec=True) as mock_HPUXVirtual_get_virtual_facts:
        set_0 = set()
        h_p_u_x_virtual_0 = HPUXVirtual(set_0)
        assert mock_HPUXVirtual_get_virtual_facts.called_once
        var_0 = mock_HPUXVirtual_get_virtual_facts.call_args_list[0][0][0]
        assert var_0 is h_p_u_x_virtual_0
        var_1 = mock_HPUXVirtual_get_virtual_facts.call_args_list[0][0][1]
        assert var_1 == set_0


# Generated at 2022-06-25 01:10:28.378533
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    set_p = set()
    h_p_u_x_virtual = HPUXVirtual(set_p)

    assert isinstance(h_p_u_x_virtual, HPUXVirtual)


if __name__ == "__main__":
    test_case_0()
    test_HPUXVirtual()

    print("Done!")

# Generated at 2022-06-25 01:10:29.133724
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    test_case_0()


# Generated at 2022-06-25 01:10:32.555239
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
  set_0 = set()
  assert set_0 == {}, "At this point set_0 should be {}"
#   assert h_p_u_x_virtual_0.get_virtual_facts() == '', "At this point h_p_u_x_virtual_0.get_virtual_facts() should be ''"


# Generated at 2022-06-25 01:10:33.694037
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    set_0 = set()
    HPUXVirtual(set_0)


# Generated at 2022-06-25 01:10:37.475179
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    assert h_p_u_x_virtual_0._supported_dists == set_0
    assert h_p_u_x_virtual_0.platform == 'HP-UX'


# Generated at 2022-06-25 01:10:52.007117
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    assert isinstance(h_p_u_x_virtual_0, HPUXVirtual)


# Generated at 2022-06-25 01:10:53.343770
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)


# Generated at 2022-06-25 01:10:58.400510
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    var_1 = h_p_u_x_virtual_0.get_virtual_facts()
    h_p_u_x_virtual_0.module = None
    var_2 = h_p_u_x_virtual_0.get_virtual_facts()
    var_3 = h_p_u_x_virtual_0.get_virtual_facts()
    h_p_u_x_virtual_0.module = None
    var_4 = h_p_u_x_virtual_0.get_virtual_facts()
    var_5 = h_p_u_x_virtual

# Generated at 2022-06-25 01:11:05.884718
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)

# Generated at 2022-06-25 01:11:07.542944
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:11:10.762794
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    set_1 = set()
    h_p_u_x_virtual_1 = HPUXVirtual(set_1)
    assert h_p_u_x_virtual_1._platform == 'HP-UX'

# Generated at 2022-06-25 01:11:15.200526
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    assert h_p_u_x_virtual_0
    assert h_p_u_x_virtual_0.platform is "HP-UX"


# Generated at 2022-06-25 01:11:17.211384
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    set_1 = set()
    h_p_u_x_virtual_1 = HPUXVirtual(set_1)
    assert h_p_u_x_virtual_1.get_virtual_facts() == {'virtualization_type': 'guest', 'virtualization_role': 'HPVM vPar', 'virtualization_tech_guest': {'HPVM vPar'}, 'virtualization_tech_host': set()}


# Generated at 2022-06-25 01:11:18.761327
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    pass

# Generated at 2022-06-25 01:11:19.914589
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    set_0 = set()
    HPUXVirtual(set_0)


# Generated at 2022-06-25 01:11:38.454595
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual(set())

# Generated at 2022-06-25 01:11:41.735322
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}


# Generated at 2022-06-25 01:11:43.494174
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert type(var_0) is dict

# Generated at 2022-06-25 01:11:51.427978
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    var_0 = h_p_u_x_virtual_0.virtualization_type
    assert var_0 is None
    var_1 = h_p_u_x_virtual_0.virtualization_role
    assert var_1 is None
    var_2 = h_p_u_x_virtual_0.virtualization_type_role
    assert var_2 is None
    var_3 = h_p_u_x_virtual_0.virtualization_full_info
    assert var_3 is None
    var_4 = h_p_u_x_virtual_0.virtualization_tech_guest
    assert var_4 is None
    var_5 = h_p_u_

# Generated at 2022-06-25 01:11:52.559848
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)


# Generated at 2022-06-25 01:11:53.961073
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)

if __name__ == "__main__":
    test_HPUXVirtual()

# Generated at 2022-06-25 01:11:59.436682
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    assert h_p_u_x_virtual_0._platform == 'HP-UX'
    assert h_p_u_x_virtual_0._facts is set_0


# Generated at 2022-06-25 01:12:01.375237
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)


# Generated at 2022-06-25 01:12:06.232500
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v_c_h_p_u_x_factory_0 = HPUXVirtualCollector()
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
# Creation of class HPUXVirtualCollector for 'HP-UX' finished

# Generated at 2022-06-25 01:12:11.484701
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)


# Generated at 2022-06-25 01:12:43.280424
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 == {
        'virtualization_type': 'host',
        'virtualization_role': 'HPVM',
        'virtualization_tech_host': set(['HPVM']),
        'virtualization_tech_guest': set(['HPVM'])
    }

# Generated at 2022-06-25 01:12:46.153021
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 == {}


# Generated at 2022-06-25 01:12:51.211668
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:12:55.914342
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_case_0()


# Generated at 2022-06-25 01:12:58.601139
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    var_1 = h_p_u_x_virtual_0.get_virtual_facts()
    assert 'virtualization_type' in var_1
    assert 'virtualization_role' in var_1


# Generated at 2022-06-25 01:13:06.324302
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    assert h_p_u_x_virtual_0.virtualization_type == None
    assert h_p_u_x_virtual_0.platform == 'HP-UX'
    assert h_p_u_x_virtual_0.virtualization_role == None


# Generated at 2022-06-25 01:13:16.011034
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    var_0 = set()
    var_1 = HPUXVirtual(var_0)
    assert type(var_1) == HPUXVirtual
    assert var_1._supported_dists == set(['HP-UX'])
    assert var_1.virtualization_type == None
    assert var_1.virtualization_role == None
    assert var_1.virtualization_system == None
    assert var_1.virtualization_uuid == None
    assert var_1.virtual == None
    assert var_1.virtualization_hypervisor == None
    assert var_1.virtualization_hypervisor_vendor == None
    assert var_1.virtualization_hypervisor_version == None
    assert var_1.virtualization_product_name == None
    assert var_1.virtualization_product_vendor == None
   

# Generated at 2022-06-25 01:13:18.767118
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    set_1 = set()
    h_p_u_x_virtual_1 = HPUXVirtual(set_1)
    assert h_p_u_x_virtual_1._platform == 'HP-UX'


# Generated at 2022-06-25 01:13:19.899666
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_1 = HPUXVirtual(set())


# Generated at 2022-06-25 01:13:25.009020
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:14:05.679991
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:14:08.606513
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:14:12.710647
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    set_1 = set()
    h_p_u_x_virtual_1 = HPUXVirtual(set_1)
    var_1 = h_p_u_x_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:14:15.494456
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

    assert var_0 == {'virtualization_type': None, 'virtualization_role': None, 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}

# Generated at 2022-06-25 01:14:17.628802
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:14:20.242096
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_role': 'para-virtualized', 'virtualization_type': 'guest', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}

# Generated at 2022-06-25 01:14:27.241447
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    try:
        test_case_0()
    except:
        var_0 = set()
        h_p_u_x_virtual_0 = HPUXVirtual(var_0)
        # We're using fake data.
        var_1 = h_p_u_x_virtual_0.get_virtual_facts()
        assert False

#

# Generated at 2022-06-25 01:14:30.629942
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:14:31.771568
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_1 = HPUXVirtual()


# Generated at 2022-06-25 01:14:35.048060
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 == {}


# Generated at 2022-06-25 01:15:34.227553
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:15:41.722754
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    assert h_p_u_x_virtual_0._platform == 'HP-UX'
    assert h_p_u_x_virtual_0._fail_gracefully is set()
    assert h_p_u_x_virtual_0._virtual_facts == {}



# Generated at 2022-06-25 01:15:46.324472
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)

    rc, out, err = h_p_u_x_virtual_0.module.run_command("/bin/true")
    assert rc == 0
    rc, out, err = h_p_u_x_virtual_0.module.run_command("/bin/false")
    assert rc == 1
    v_type = h_p_u_x_virtual_0.get_virtual_facts()
    assert v_type == {'virtualization_type': 'host', 'virtualization_tech_guest': set([]),
                      'virtualization_tech_host': set([]), 'virtualization_role': ''}
    rc, out, err = h_p_u_x_virtual_0

# Generated at 2022-06-25 01:15:52.647983
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)

    def side_effect_run_command_0(*args, **kwargs):
        return 0, '', ''

    h_p_u_x_virtual_0.module.run_command = side_effect_run_command_0
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 == {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }
    assert h_p_u_x_virtual_0.facts == {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }



# Generated at 2022-06-25 01:15:57.208225
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 == {}, "Expected '{}', but got '{}'".format({}, var_0)


# Generated at 2022-06-25 01:15:57.818665
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    pass


# Generated at 2022-06-25 01:15:58.902778
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    test_case_0()

if __name__ == '__main__':
    test_HPUXVirtual()

# Generated at 2022-06-25 01:16:05.120805
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    var_1 = HPUXVirtual(set_0).get_virtual_facts()
    assert var_0 != var_1

# Generated at 2022-06-25 01:16:05.555740
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-25 01:16:07.758103
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    assert type(h_p_u_x_virtual_0.get_virtual_facts()) == dict

# Generated at 2022-06-25 01:17:14.284170
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    h_p_u_x_virtual_0._module.run_command = mock_run_command
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0['virtualization_type'] == 'guest'
    assert var_0['virtualization_role'] == 'HP vPar'
    assert var_0['virtualization_tech_guest'] == {'HP vPar'}
    assert var_0['virtualization_tech_host'] == set()

# Mock for method run_command of object HPUXVirtual

# Generated at 2022-06-25 01:17:20.085097
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    assert type(h_p_u_x_virtual_0.get_virtual_facts()) is dict


# Generated at 2022-06-25 01:17:22.667022
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    assert 0 == h_p_u_x_virtual_0.get_virtual_facts()

if __name__ == '__main__':
    test_case_0()
    test_HPUXVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:17:30.562681
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    set_1 = set()
    h_p_u_x_virtual_1 = HPUXVirtual(set_1)
    try:
        h_p_u_x_virtual_1.get_virtual_facts()
    except Exception as exception:
        print(exception)

if __name__ == '__main__':
    import sys
    if sys.argv[1] == '0':
        test_case_0()
    elif sys.argv[1] == 'HPUXVirtual_get_virtual_facts':
        test_HPUXVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:17:37.064726
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    set_0 = set()
    h_p_u_x_virtual_0 = HPUXVirtual(set_0)
    var_0 = h_p_u_x_virtual_0.virtual_type()
    assert var_0 == 'HP-UX'

    var_1 = h_p_u_x_virtual_0.get_virtual_facts()
    assert 'virtualization_type' not in var_1
    assert 'virtualization_role' not in var_1

    assert var_1['virtualization_tech_guest'] == set()
    assert var_1['virtualization_tech_host'] == set()

if __name__ == "__main__":
    test_case_0()