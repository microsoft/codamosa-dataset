

# Generated at 2022-06-25 01:07:48.065430
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual(module=None)
    assert h_p_u_x_virtual

# Generated at 2022-06-25 01:07:53.847371
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    h_p_u_x_virtual_0 = HPUXVirtual()

    # Test using parameters: module
    h_p_u_x_virtual_1 = HPUXVirtual(module=h_p_u_x_virtual_0.module)

    assert h_p_u_x_virtual_1.get_virtual_facts() == {'virtualization_role': 'HP vPar',
                                                    'virtualization_tech_guest': {'HP vPar'},
                                                    'virtualization_type': 'guest',
                                                    'virtualization_tech_host': set()}

# Generated at 2022-06-25 01:07:54.668225
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    s_0 = HPUXVirtual({"module_setup": False})


# Generated at 2022-06-25 01:07:56.578868
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    print("Unit test for constructor of HPUXVirtual")
    h_p_u_x_virtual_0 = HPUXVirtual(
        module=True)
    print(" Instance created successfully.")


# Generated at 2022-06-25 01:08:05.192927
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_instance_0 = HPUXVirtual()
    h_p_u_x_virtual_collector_0 = HPUXVirtualCollector()
    h_p_u_x_virtual_instance_0.module = h_p_u_x_virtual_collector_0.module
    h_p_u_x_virtual_instance_0.module.run_command = MagicMock(return_value=(0, "hpvm is running", ""))
    h_p_u_x_virtual_instance_0.module.get_bin_path = MagicMock(return_value="/opt/hpvm/bin/hpvminfo")

    h_p_u_x_virtual_instance_0.get_virtual_facts()
    h_p_u_x_virtual_instance_0

# Generated at 2022-06-25 01:08:07.199592
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual(dict(), dict())


# Generated at 2022-06-25 01:08:08.891453
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual(dict(), dict())
    assert h_p_u_x_virtual._module is not None


# Generated at 2022-06-25 01:08:13.412700
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    from ansible.module_utils.facts.virtual.h_p_u_x import HPUXVirtual
    h_p_u_x_virtual = HPUXVirtual()

# Testcase to get the virtual fact with output of virtualization_type, virtualization_role, virtualization_tech_host, virtualization_tech_guest

# Generated at 2022-06-25 01:08:16.347573
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_type': None, 'virtualization_role': None, 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

# Generated at 2022-06-25 01:08:17.700125
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual()
    virtual.get_virtual_facts()



# Generated at 2022-06-25 01:08:27.869499
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    obj = HPUXVirtual()
    assert obj is not None


# Generated at 2022-06-25 01:08:30.057304
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual = HPUXVirtual()
    h_p_u_x_virtual.module = None
    h_p_u_x_virtual.get_virtual_facts()

# Generated at 2022-06-25 01:08:34.516102
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual = HPUXVirtualCollector().get_virtual_facts()
    assert h_p_u_x_virtual.virtualization_tech_host == set()
    assert h_p_u_x_virtual.virtualization_role in ['HP vPar', 'HPVM vPar', 'HPVM IVM', 'HPVM', 'HP nPar']
    assert h_p_u_x_virtual.virtualization_type == 'guest'
    assert h_p_u_x_virtual.virtualization_tech_guest != set()

# Generated at 2022-06-25 01:08:35.516242
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:08:37.611389
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:08:40.029231
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module_args = dict()
    test_HPUXVirtual = HPUXVirtual(module_args)
    print(test_HPUXVirtual)
    assert "HPUXVirtual" in str(test_HPUXVirtual)


# Generated at 2022-06-25 01:08:42.942440
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual({u'module': {u'run_command': run_command_0}}, {}, [])



# Generated at 2022-06-25 01:08:46.246175
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual({})
    assert h_p_u_x_virtual_0._platform == 'HP-UX'

if __name__ == '__main__':
    test_HPUXVirtual()

# Generated at 2022-06-25 01:08:47.724355
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:08:50.301614
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # Check if the constructor of class HPUXVirtual raises any Exceptions
    try:
        HPUXVirtual()
    except Exception:
        raise AssertionError('Constructor of class `HPUXVirtual` cannot raise Exception')


# Generated at 2022-06-25 01:09:08.022851
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    data = h_p_u_x_virtual_0.facts
    assert data['virtualization_tech_host'] == set()
    assert data['virtualization_tech_guest'] == set()
    assert data['virtualization_role'] == ''
    assert data['virtualization_type'] == ''

# Generated at 2022-06-25 01:09:08.959268
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()

# Generated at 2022-06-25 01:09:09.871079
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()

# Generated at 2022-06-25 01:09:10.540905
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    HPUXVirtual().get_virtual_facts()

# Generated at 2022-06-25 01:09:19.091732
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_collector_0 = HPUXVirtualCollector()
    h_p_u_x_virtual_0 = h_p_u_x_virtual_collector_0._fact_class({})
    h_p_u_x_virtual_0.module = MagicMock()
    h_p_u_x_virtual_0.module.run_command.return_value = (0, 'HPVM guest', '')
    h_p_u_x_virtual_0.module.run_command.return_value = (0, 'Role : Virtual Partition', '')
    h_p_u_x_virtual_0.module.run_command.return_value = (0, 'HPVM host', '')
    h_p_u_x_virtual_0.module.run_

# Generated at 2022-06-25 01:09:20.535654
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0._platform == 'HP-UX'


# Generated at 2022-06-25 01:09:23.394411
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual(dict())
    h_p_u_x_virtual_0.module = MockModule()
    h_p_u_x_virtual_0.module.run_command = mock_function('h_p_u_x_virtual_0')
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:09:25.224276
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.platform == 'HP-UX'


# Generated at 2022-06-25 01:09:27.517501
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    # Test for instantiation of class HPUXVirtual
    assert h_p_u_x_virtual_0


# Generated at 2022-06-25 01:09:29.900800
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()



# Generated at 2022-06-25 01:09:52.068449
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual = HPUXVirtual(dict())

# Generated at 2022-06-25 01:09:59.040937
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_collector_0 = HPUXVirtualCollector()
    h_p_u_x_virtual_0 = HPUXVirtual({})
    h_p_u_x_virtual_0._module={}
    h_p_u_x_virtual_0._module.run_command=lambda a : (0, "", "")
    assert not h_p_u_x_virtual_0.get_virtual_facts()
    h_p_u_x_virtual_0._module.run_command=lambda a : (1, "", "")
    assert not h_p_u_x_virtual_0.get_virtual_facts()
    h_p_u_x_virtual_0._module.run_command=lambda a : (0, "Running HPVM vPar", "")

# Generated at 2022-06-25 01:10:02.372766
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_type': 'guest',
                                                     'virtualization_role': 'HP vPar',
                                                     'virtualization_tech_host': set(),
                                                     'virtualization_tech_guest': {'HP vPar'}}

# Generated at 2022-06-25 01:10:05.213911
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual(None)
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:10:08.905406
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    FACT_RETURN = {
        'virtualization_tech_guest': set(['HP vPar']),
        'virtualization_tech_host': set(),
        'virtualization_type': 'guest',
        'virtualization_role': 'HP vPar'
    }

    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module.run_command = lambda *args: (0, '', '')
    assert h_p_u_x_virtual_0.get_virtual_facts() == FACT_RETURN


# Generated at 2022-06-25 01:10:16.025817
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all', '!min'], type='list')
        ),
        supports_check_mode=True
    )
    h_p_u_x_virtual_0 = HPUXVirtual(module)
    assert h_p_u_x_virtual_0.get_virtual_facts()[
        'virtualization_tech_host'] == set()
    assert h_p_u_x_virtual_0.get_virtual_facts()[
        'virtualization_tech_guest'] == set()


# Generated at 2022-06-25 01:10:18.427794
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_role': 'HP vPar', 'virtualization_type': 'guest'}


# Generated at 2022-06-25 01:10:20.048373
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    x = HPUXVirtual()


# Generated at 2022-06-25 01:10:23.400852
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module.run_command = lambda x: (0, '', '')
    h_p_u_x_virtual_0.os_version = '10.11'
    h_p_u_x_virtual_0.module.params['gather_subset'] = ['!all']
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:10:27.640479
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    facts = h_p_u_x_virtual_0.get_virtual_facts()
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_type'] == 'host'

# Generated at 2022-06-25 01:10:45.709420
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()


# Generated at 2022-06-25 01:10:47.492597
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual(module=None)
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:10:52.486959
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module.run_command = mock_command
    assert h_p_u_x_virtual_0.get_virtual_facts() == ({'virtualization_type': 'host', 'virtualization_role': 'HPVM', 'virtualization_tech_guest': set(['HPVM']), 'virtualization_tech_host': set()}, ['Command did not return rc 0'])

# Generated at 2022-06-25 01:10:54.679833
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(module=None)
    assert h_p_u_x_virtual_0.platform == 'HP-UX'
    assert h_p_u_x_virtual_0.module == None


# Generated at 2022-06-25 01:11:00.971789
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.platform == 'HP-UX'
    assert h_p_u_x_virtual_0._get_host_facts() == {}


# Generated at 2022-06-25 01:11:01.824140
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()


# Generated at 2022-06-25 01:11:02.965099
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    instance = HPUXVirtual()
    assert instance.platform == "HP-UX"


# Generated at 2022-06-25 01:11:11.510889
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual({'module': 'module_0'})
    h_p_u_x_virtual_1 = HPUXVirtual({'module': 'module_1'})
    h_p_u_x_virtual_0 = HPUXVirtual({'module': 'module_2'})

    if h_p_u_x_virtual_0.platform == 'HP-UX':
        assert h_p_u_x_virtual_0.module == 'module_0'
    if h_p_u_x_virtual_1.platform == 'HP-UX':
        assert h_p_u_x_virtual_1.module == 'module_1'
    if h_p_u_x_virtual_0.platform == 'HP-UX':
        assert h_p

# Generated at 2022-06-25 01:11:19.104372
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0._module = mock_module_for_HPUXVirtual()
    output_dict = h_p_u_x_virtual_0.get_virtual_facts()
    assert output_dict['virtualization_type'] == 'guest'
    assert output_dict['virtualization_role'] == 'HP nPar'
    assert output_dict['virtualization_tech_guest'] == {'HP nPar'}
    assert output_dict['virtualization_tech_host'] == set()


# Generated at 2022-06-25 01:11:20.091878
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual({}, {}, {}, {})


# Generated at 2022-06-25 01:11:38.654518
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(module=None)

# Generated at 2022-06-25 01:11:39.903586
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:11:40.264708
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert True

# Generated at 2022-06-25 01:11:46.462378
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    true = True
    false = False
    null = None
    dict_0 = HPUXVirtualCollector().get_virtual_facts()
    print(dict_0)

# Generated at 2022-06-25 01:11:51.450291
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(dict(module=dict()))
    h_p_u_x_virtual_1 = HPUXVirtual(dict(module=dict(), platform='AIX'))
    h_p_u_x_virtual_2 = HPUXVirtual(dict(module=dict(), platform='HP-UX'))
    try:
        h_p_u_x_virtual_3 = HPUXVirtual(dict(module=dict(), platform='Linux'))
    except SystemExit as exception:
        assert(exception.code == 1)


# Generated at 2022-06-25 01:11:52.537745
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:11:53.365300
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:11:54.527142
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    e_0 = HPUXVirtual(module=None)


# Generated at 2022-06-25 01:11:58.787568
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:11:59.989080
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(module=None)


# Generated at 2022-06-25 01:12:16.513044
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert True

# Generated at 2022-06-25 01:12:21.596699
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    float_0 = 226.86611
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_tech_guest': set(['HP nPar']), 'virtualization_tech_host': set(), 'virtualization_type': 'guest', 'virtualization_role': 'HP nPar'}

# Generated at 2022-06-25 01:12:26.519846
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # Test with no argument
    h_p_u_x_virtual_0 = HPUXVirtual()
    # Test with float argument
    float_0 = 226.86611
    h_p_u_x_virtual_1 = HPUXVirtual(float_0)
    # Test with float and float  argument
    float_0 = 226.86611
    h_p_u_x_virtual_2 = HPUXVirtual(float_0, float_0)
    # Test with string and string  argument
    string_0 = "gtvBl"
    string_1 = "\"$l}x"
    h_p_u_x_virtual_3 = HPUXVirtual(string_0, string_1)
    # Test with string and float  argument
    string_0 = "gtvBl"
    h_p

# Generated at 2022-06-25 01:12:28.058322
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = 226.86611
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)


# Generated at 2022-06-25 01:12:31.916752
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert callable(HPUXVirtual)


# Generated at 2022-06-25 01:12:34.534135
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    float_1 = 226.86611
    h_p_u_x_virtual_1 = HPUXVirtual(float_1)
    var_1 = h_p_u_x_virtual_1.get_virtual_facts()
    assert var_1 == {
        'virtualization_tech_guest': {},
        'virtualization_tech_host': {}
    }


# Generated at 2022-06-25 01:12:40.083066
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = 226.86611
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    assert h_p_u_x_virtual_0.module._debug == False

# Generated at 2022-06-25 01:12:44.018436
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = 226.86611
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    result = h_p_u_x_virtual_0.platform
    assert result == "HP-UX", "Expected 'HP-UX' but got: %s" % result


# Generated at 2022-06-25 01:12:45.540303
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = 226.86611
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)


# Generated at 2022-06-25 01:12:50.746052
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_1 = 400.0
    h_p_u_x_virtual_1 = HPUXVirtual(float_1)
    h_p_u_x_virtual_2 = HPUXVirtual(float_1)

# Generated at 2022-06-25 01:13:05.601086
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    float_0 = 226.86611
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 == None

# Generated at 2022-06-25 01:13:07.496406
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert(HPUXVirtual.platform is not None)


# Generated at 2022-06-25 01:13:16.832613
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = 226.86611
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    assert h_p_u_x_virtual_0._module.params['gather_subset'] == ['!all', '!any', '!min', '!hardware', '!network', '!virtual', '!facter']
    assert h_p_u_x_virtual_0.platform == 'HP-UX'
    assert h_p_u_x_virtual_0._platform == 'HP-UX'
    assert h_p_u_x_virtual_0._module.params['filter'] == '*'
    assert h_p_u_x_virtual_0._module.params['fact_path'] == '/etc/ansible/facts.d'
    assert h_p_u

# Generated at 2022-06-25 01:13:22.083235
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = 226.86611
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)


# Generated at 2022-06-25 01:13:23.824448
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    float_0 = 226.86611
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:13:26.984434
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = 226.86611
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    assert not h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:13:33.097251
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    float_0 = 226.86611
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    var_1 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_1['virtualization_type'] == 'host'
    assert var_1['virtualization_tech_host'] == set()
    assert var_1['virtualization_tech_guest'] == set()
    assert var_1['virtualization_role'] == 'HPVM'


# Generated at 2022-06-25 01:13:34.807396
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = 91.074444
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)


# Generated at 2022-06-25 01:13:37.827400
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = -448.22909
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    assert h_p_u_x_virtual_0._name == 'HP-UX'



# Generated at 2022-06-25 01:13:43.135998
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = 191.43894
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    assert float_0 == float_0
    assert 'HP-UX' == h_p_u_x_virtual_0.platform


# Generated at 2022-06-25 01:14:11.117088
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    print('Test HPUXVirtual')
    h = HPUXVirtual(0)

    # Check default fact
    facts = h.get_virtual_facts()
    assert facts == {'virtualization_type': 'guest', 'virtualization_role': None, 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}

    # Check vPar guest
    facts['virtual_vpar_guest'] = True
    facts = h.get_virtual_facts()
    assert facts == {'virtualization_type': 'guest', 'virtualization_role': 'HP vPar', 'virtualization_tech_host': set(), 'virtualization_tech_guest': {'HP vPar'}}

    # Check nPar guest
    facts['virtual_vpar_guest'] = None

# Generated at 2022-06-25 01:14:11.583774
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    pass

# Generated at 2022-06-25 01:14:15.143318
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    file_path = os.path.dirname(os.path.abspath(__file__))
    file_name = file_path + "/../../module_utils/facts/virtual/hpux.py"
    with open(file_name, 'r') as f:
        module_body = f.read()
    test_code = '''
if __name__ == "__main__":
    test_case_0()
'''
    module_body += test_code
    exec(module_body)

# Generated at 2022-06-25 01:14:23.387332
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_3 = 226.86611
    h_p_u_x_virtual_3 = HPUXVirtual(float_3)
    var_3 = h_p_u_x_virtual_3.get_virtual_facts()
    # assert type(var_3) ==  <class 'dict'>
    # assert 'virtualization_type' in var_3
    # assert 'virtualization_role' in var_3
    # assert 'virtualization_tech_host' in var_3
    # assert 'virtualization_tech_guest' in var_3


test_case_0()
test_HPUXVirtual()

# Generated at 2022-06-25 01:14:25.747701
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    assert True


# Generated at 2022-06-25 01:14:29.097861
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    float_0 = 226.86611
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 == {}

# Generated at 2022-06-25 01:14:33.207985
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    assert False

# vim: set et notminux:

# Generated at 2022-06-25 01:14:36.228577
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = 553.78094
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    assert h_p_u_x_virtual_0._platform == 'HP-UX'




# Generated at 2022-06-25 01:14:37.223289
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    with pytest.raises(TypeError):
        HPUXVirtual()



# Generated at 2022-06-25 01:14:40.217858
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    obj = HPUXVirtual(float)
    try:
        assert obj.platform == 'HP-UX'
    except AssertionError as e:
        print("Expected: <HP-UX> but got: <{}>".format(obj.platform))


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 01:15:06.383018
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert var_0 == {}

# Generated at 2022-06-25 01:15:11.703039
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    float_0 = 226.86611
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:15:16.057833
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = 226.86611
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    print("Virtual type is: ", h_p_u_x_virtual_0.virtualization_type)
    print("Virtual role is: ", h_p_u_x_virtual_0.virtualization_role)
    print("Virtual guest tech is: ", h_p_u_x_virtual_0.virtualization_tech_guest)
    print("Virtual host tech is: ", h_p_u_x_virtual_0.virtualization_tech_host)

if __name__ == '__main__':
    test_case_0()
    test_HPUXVirtual()

# Generated at 2022-06-25 01:15:22.717907
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = 226.86611
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    assert h_p_u_x_virtual_0._platform == ('HP-UX')
    assert h_p_u_x_virtual_0.module == (float_0)
    assert h_p_u_x_virtual_0.data == (None)


# Generated at 2022-06-25 01:15:28.351830
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = 226.86611
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:15:31.302251
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = 226.86611
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    float_1 = 806.7867
    h_p_u_x_virtual_1 = HPUXVirtual(float_1)

    print(h_p_u_x_virtual_0)
    print(h_p_u_x_virtual_1)


# Generated at 2022-06-25 01:15:34.625111
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = 138.663665
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    # Test method get_virtual_facts() of class HPUXVirtual
    test_case_0(h_p_u_x_virtual_0)


# Generated at 2022-06-25 01:15:40.669698
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    float_0 = 271.89599
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0
    # add test here


# Generated at 2022-06-25 01:15:47.293817
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    print('Testing method get_virtual_facts of class HPUXVirtual')
    # Testing case #0
    print('Testing case #0')
    test_case_0()

if __name__ == '__main__' :
    test_HPUXVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:15:53.482640
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    float_0 = 461.40308
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    # assert virtual_facts == expected
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    # assert virtualization_type == expected
    expected = 'guest'
    var_1 = var_0['virtualization_type']
    assert var_1 == expected
    # assert virtualization_role == expected
    expected = 'HPVM vPar'
    var_2 = var_0['virtualization_role']
    assert var_2 == expected
    # assert virtualization_tech_guest == expected
    expected = set(['HPVM vPar'])
    var_3 = var_0['virtualization_tech_guest']
    assert var_

# Generated at 2022-06-25 01:16:25.944633
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(None)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:16:30.687829
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = 565.883322
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    print(h_p_u_x_virtual_0.platform)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:16:39.274594
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual(17.0)
    h_p_u_x_virtual_0.module = mock.Mock()
    h_p_u_x_virtual_0.module.run_command.return_value = (0, 'stdout', 'stderr')
    bool_0, bool_1, bool_2 = h_p_u_x_virtual_0.os.path.exists('/usr/sbin/vecheck')
    if bool_0:
        h_p_u_x_virtual_0.module.run_command.return_value = (0, 'stdout', 'stderr')
        var_0 = h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:16:40.121825
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    run_test(0, test_case_0)

# Generated at 2022-06-25 01:16:43.201576
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = 674.22728
    float_1 = 819.1183
    h_p_u_x_virtual_0 = HPUXVirtual(float_0, float_1)
    h_p_u_x_virtual_1 = HPUXVirtual(float_0)
    h_p_u_x_virtual_2 = HPUXVirtual()


# Generated at 2022-06-25 01:16:47.727467
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    float_0 = 226.86611
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    var_1 = h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:16:51.330280
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    test_case_0()

# Generated at 2022-06-25 01:16:53.609268
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    float_0 = 226.86611
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    # AssertionError
    return


# Generated at 2022-06-25 01:16:55.780513
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    float_0 = 183.7373646
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    var_46 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_46 is None

# Generated at 2022-06-25 01:17:00.901408
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    float_0 = 278.882577
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    assert h_p_u_x_virtual_0.get_virtual_facts() == 'HP vPar', 'Failure: get_virtual_facts did not return expected value'


# Generated at 2022-06-25 01:17:30.533711
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = 226.86611
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_role': None, 'virtualization_type': None}


# Generated at 2022-06-25 01:17:33.992649
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    float_0 = 0.391942
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    if not var_0:
        print("Test #1 failed.")


# Generated at 2022-06-25 01:17:36.858369
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    float_0 = 226.86611
    h_p_u_x_virtual_0 = HPUXVirtual(float_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    #assert var_0 == 
