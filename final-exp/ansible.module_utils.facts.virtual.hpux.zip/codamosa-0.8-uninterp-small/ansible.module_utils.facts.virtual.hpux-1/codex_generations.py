

# Generated at 2022-06-25 01:07:52.130455
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 0
    h_p_u_x_virtual_0 = HPUXVirtual(int_0, int_0)
    assert hasattr(h_p_u_x_virtual_0, '_get_virtual_facts')
    assert hasattr(h_p_u_x_virtual_0, '_handle_duplicates')
    assert hasattr(h_p_u_x_virtual_0, 'remove_duplicates')
    assert hasattr(h_p_u_x_virtual_0, 'get_all')
    assert h_p_u_x_virtual_0._platform == 'HP-UX'


# Generated at 2022-06-25 01:07:54.083309
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.get_virtual_facts()
##########


# Generated at 2022-06-25 01:07:54.720168
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    test_case_0()


# Generated at 2022-06-25 01:07:55.964110
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    obj = HPUXVirtual(10000, 10000)
    assert isinstance(obj, HPUXVirtual)

# Generated at 2022-06-25 01:08:03.182955
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = -2875
    h_p_u_x_virtual_collector_0 = HPUXVirtualCollector(int_0, int_0)
    str_0 = "8\x00\n\x00\"\x00\x00\x00\x00\x00\x00\x00\x00\x00"
    int_1 = -2770
    int_2 = -2830

    h_p_u_x_virtual_collector_0.cleanup(int_2, str_0)
    assert h_p_u_x_virtual_collector_0.facts == {}

# Generated at 2022-06-25 01:08:04.756944
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
  hP_uX_virtual_0 = HPUXVirtual()
  # print hP_uX_virtual_0


# Generated at 2022-06-25 01:08:07.638815
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    int_0 = -2922
    h_p_u_x_virtual_collector_0 = HPUXVirtualCollector(int_0, int_0)
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module = None
    # 'NoneType' object is not iterable
    assert h_p_u_x_virtual_0.get_virtual_facts() == {}


# Generated at 2022-06-25 01:08:09.800427
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = -5984
    h_p_u_x_virtual_0 = HPUXVirtual(int_0, int_0)
    assert h_p_u_x_virtual_0._module is not None

# Generated at 2022-06-25 01:08:17.432141
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = -2922
    h_p_u_x_virtual_collector_0 = HPUXVirtualCollector(int_0, int_0)
    int_0 = -2639
    h_p_u_x_virtual_collector_1 = HPUXVirtualCollector(int_0, int_0)
    h_p_u_x_virtual_0 = HPUXVirtual(int_0, int_0, h_p_u_x_virtual_collector_0)
    int_0 = -2922
    h_p_u_x_virtual_collector_2 = HPUXVirtualCollector(int_0, int_0)

# Generated at 2022-06-25 01:08:18.100570
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    test_case_0()


# Generated at 2022-06-25 01:08:31.915913
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    result = h_p_u_x_virtual_0.get_virtual_facts()
    assert isinstance(result, dict) is True
    result = h_p_u_x_virtual_0.get_virtual_facts()
    assert 'virtualization_tech_guest' in result
    result = h_p_u_x_virtual_0.get_virtual_facts()
    assert 'virtualization_tech_host' in result

# Generated at 2022-06-25 01:08:35.066370
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_role': 'HP nPar', 'virtualization_type': 'guest', 'virtualization_tech_guest': {'HP nPar'}, 'virtualization_tech_host': set()}



# Generated at 2022-06-25 01:08:41.882137
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_1 = HPUXVirtual()
    h_p_u_x_virtual_1.populate()
    assert h_p_u_x_virtual_1.virtualization_type == 'host'
    assert h_p_u_x_virtual_1.virtualization_role == 'HPVM'
    assert h_p_u_x_virtual_1.virtualization_tech_host == set(['HPVM'])
    assert h_p_u_x_virtual_1.virtualization_tech_guest == set()


# Generated at 2022-06-25 01:08:43.422440
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:08:44.785279
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual()
    assert virtual.platform == 'HP-UX'


# Generated at 2022-06-25 01:08:52.976021
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module = AnsibleModule(
        argument_spec=dict()
    )
    h_p_u_x_virtual_0.module.run_command = Mock(
        return_value=(0, 'Running HPVM vPar', '')
    )
    h_p_u_x_virtual_0.module.run_command = Mock(
        return_value=(0, 'Running HPVM guest', '')
    )
    h_p_u_x_virtual_0.module.run_command = Mock(
        return_value=(0, 'Running HPVM host', '')
    )

# Generated at 2022-06-25 01:08:54.562353
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0._platform == 'HP-UX'



# Generated at 2022-06-25 01:09:03.674612
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.virtualization_type == None
    assert h_p_u_x_virtual_0.virtualization_role == None
    assert h_p_u_x_virtual_0.virtualization_role_exists == False
    assert h_p_u_x_virtual_0.virtualization_guest == None
    assert h_p_u_x_virtual_0.virtualization_guest_type == None
    assert h_p_u_x_virtual_0.virtualization_guest_exists == False
    assert h_p_u_x_virtual_0.virtualization_host_type == None
    assert h_p_u_x_virtual_0.virtualization_host_type

# Generated at 2022-06-25 01:09:11.067104
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Test with parstatus present
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module.run_command = MagicMock(return_value=(0, '', ''))
    h_p_u_x_virtual_0.module.run_command = MagicMock(return_value=(0, 'blahblah', ''))
    h_p_u_x_virtual_0.module.run_command = MagicMock(return_value=(0, 'blahblahparstatus: HPVM guestblahblah', ''))
    h_p_u_x_virtual_0.module.run_command = MagicMock(return_value=(0, 'blahblahRunning HPVM vParblahblah', ''))
    h_p_

# Generated at 2022-06-25 01:09:19.117482
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    rc, out, err = h_p_u_x_virtual_0.module.run_command("/opt/hpvm/bin/hpvminfo")
    if rc == 0:
        if re.match('.*Running.*HPVM vPar.*', out):
            result = h_p_u_x_virtual_0.get_virtual_facts()
            assert result['virtualization_type'] == 'guest'
            assert result['virtualization_role'] == 'HPVM vPar'
        elif re.match('.*Running.*HPVM guest.*', out):
            result = h_p_u_x_virtual_0.get_virtual_facts()
            assert result['virtualization_type'] == 'guest'

# Generated at 2022-06-25 01:09:30.067773
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual(module=dict())



# Generated at 2022-06-25 01:09:35.951022
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    if type(h_p_u_x_virtual_0) == type(HPUXVirtual()):
        print("Test case 0: Constructed object is of class HPUXVirtual (Test passed)")
    else:
        print("Test case 0: Constructed object is not of class HPUXVirtual (Test failed)")


# Generated at 2022-06-25 01:09:43.187635
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_get_virtual_facts_0 = HPUXVirtual()
    h_p_u_x_virtual_get_virtual_facts_0.module = AnsibleModule(
        argument_spec=dict()
    )
    h_p_u_x_virtual_get_virtual_facts_0.module.run_command = MagicMock(return_value=(0, '', ''))
    h_p_u_x_virtual_get_virtual_facts_0.module.run_command = MagicMock(return_value=(0, '', ''))
    h_p_u_x_virtual_get_virtual_facts_0.module.run_command = MagicMock(return_value=(0, 'Running HPVM guest.', ''))
    h_p_u_x_virtual_get

# Generated at 2022-06-25 01:09:47.628183
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()
    assert isinstance(h_p_u_x_virtual, HPUXVirtual)
    assert isinstance(h_p_u_x_virtual, Virtual)



# Generated at 2022-06-25 01:09:48.349644
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    pass


# Generated at 2022-06-25 01:09:50.458115
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert(h_p_u_x_virtual_0.get_virtual_facts() == {})


# Generated at 2022-06-25 01:09:57.822732
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.platform == 'HP-UX'
    assert h_p_u_x_virtual_0._get_platform_of_type.im_class == HPUXVirtual
    assert h_p_u_x_virtual_0._get_platform_of_type.__self__.__class__.__name__ == 'HPUXVirtual'
    assert h_p_u_x_virtual_0._get_platform_of_type.__doc__ == 'Returns a dict containing virtualization facts or an empty dict'
    assert h_p_u_x_virtual_0.get_virtual_facts.im_class == HPUXVirtual
    assert h_p_u_x_virtual_0.get_virtual

# Generated at 2022-06-25 01:10:01.041219
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_type': 'guest', 'virtualization_role': 'HP vPar', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set(['HP vPar', 'HP nPar'])}


# Generated at 2022-06-25 01:10:05.733761
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()

    h_p_u_x_virtual_0.set_module(0)
    h_p_u_x_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:10:06.722953
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:10:25.349320
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # Checking instance attribute 'platform' of class 'HP-UXVirtual'
    test_case_0()



# Generated at 2022-06-25 01:10:28.143488
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = 'hL5#5xj'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:10:31.140286
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_1 = '@YH~]Fp\x07_'
    h_p_u_x_virtual_1 = HPUXVirtual(str_1)
    var_1 = h_p_u_x_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:10:32.776768
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = 'ZSt.[zsF'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:10:36.271872
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'Rx#Z[0t/E1}'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    assert h_p_u_x_virtual_0._module == 'Rx#Z[0t/E1}'


# Generated at 2022-06-25 01:10:38.906233
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'FlG>ud:E[#xi'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    assert h_p_u_x_virtual_0.module == "FlG>ud:E[#xi"


# Generated at 2022-06-25 01:10:41.707704
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual('/etc/passwd')

    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

    assert var_0 == {}


# Generated at 2022-06-25 01:10:47.235883
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'FlG>ud:E[#xi'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

# vim:se filetype=python shiftwidth=4 tabstop=4 expandtab autoindent smartindent

# Generated at 2022-06-25 01:10:54.257303
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = 'ID3qw1j'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    # virtual_facts: {'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_role': None, 'virtualization_type': None}
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    # virtual_facts: {'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_role': None, 'virtualization_type': None}
    var_1 = h_p_u_x_virtual_0.get_virtual_facts()
    # virtual_facts: {'virtualization_tech_guest': set(), 'virtualization_tech_

# Generated at 2022-06-25 01:10:58.117310
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'b@fBy;M3>&_N<H'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    assert h_p_u_x_virtual_0.virtual == str_0


# Generated at 2022-06-25 01:11:19.073334
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'FlG>ud:E[#xi'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    h_p_u_x_virtual_1 = HPUXVirtual(str_0)
    h_p_u_x_virtual_1.platform
    assert h_p_u_x_virtual_0.platform == 'HP-UX'
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:11:24.285587
# Unit test for constructor of class HPUXVirtual

# Generated at 2022-06-25 01:11:26.421516
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = 'FlG>ud:E[#xi'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:11:28.295326
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'FlG>ud:E[#xi'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)


# Generated at 2022-06-25 01:11:31.084949
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_1 = 'FlG>ud:E[#xi'
    h_p_u_x_virtual_1 = HPUXVirtual(str_1)
    var_1 = h_p_u_x_virtual_1.get_virtual_facts()
    assert var_1 == None


# Generated at 2022-06-25 01:11:31.963071
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Case 0
    test_case_0()



# Generated at 2022-06-25 01:11:34.091046
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = 'i]0Kj#G'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:11:43.902106
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = '[*oT=_'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    assert h_p_u_x_virtual_0._module == '[*oT=_'
    assert h_p_u_x_virtual_0._platform == 'HP-UX'
    str_1 = 'p<i/c9&$'
    h_p_u_x_virtual_1 = HPUXVirtual(str_1)
    assert h_p_u_x_virtual_1._module == 'p<i/c9&$'
    assert h_p_u_x_virtual_1._platform == 'HP-UX'
    str_2 = 'P>Y_Jm!3D'
    h_p_u_x_virtual_2

# Generated at 2022-06-25 01:11:47.975279
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = ':&X>UT:'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    var_1 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:11:50.838566
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'flG>ud:E[#xi'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:12:05.342652
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert test_case_0() is None, 'Failed to create or run testcase of class HPUXVirtual.'


# Generated at 2022-06-25 01:12:07.573046
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'FlG>ud:E[#xi'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:12:08.414888
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    # Test 1 - Testing successful execution of method
    test_case_0()

# end

# Generated at 2022-06-25 01:12:10.557666
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'FlG>ud:E[#xi'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:12:15.189982
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'LPm'
    str_1 = '1JMWs'
    str_2 = 'IhJ'
    str_3 = 'C'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0, str_1, str_2, str_3)
# Constructor test for class HPUXVirtualCollector

# Generated at 2022-06-25 01:12:16.958155
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = Virtual._get_cpuid_info()
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:12:20.175084
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = 'FlG>ud:E[#xi'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert not var_0


# Generated at 2022-06-25 01:12:25.010900
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    x = HPUXVirtual('pwel')
    assert x.data == 'pwel'
    assert x.platform == 'HP-UX'
    assert x.module == None


# Generated at 2022-06-25 01:12:28.402907
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'FlG>ud:E[#xi'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

    assert 'virtualization_tech_host' in var_0
    assert 'virtualization_tech_guest' in var_0
    assert 'virtualization_role' in var_0
    assert 'virtualization_type' in var_0


# Generated at 2022-06-25 01:12:35.375492
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_1 = 'FlG>ud:E[#xi'
    h_p_u_x_virtual_1 = HPUXVirtual(str_1)
    assert h_p_u_x_virtual_1.module == str_1
    assert h_p_u_x_virtual_1.platform == 'HP-UX'


# Generated at 2022-06-25 01:13:04.432348
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'lGwNx]&6*8U}'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)



# Generated at 2022-06-25 01:13:12.349085
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = 'FlG>ud:E[#xi'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    var_1 = HPUXVirtual(str_0).get_virtual_facts()
    del str_0
    del var_0
    del var_1
    del h_p_u_x_virtual_0
    assert True


# Generated at 2022-06-25 01:13:15.591682
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    _module = '/usr/sbin/parstatus'
    __version__ = '0.0.2'
    assert(_module == '/usr/sbin/parstatus')
    assert(__version__ == '0.0.2')

# Generated at 2022-06-25 01:13:17.672479
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = 'sLf$^d:P'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:13:25.852749
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'str_0'  # Define object
    int_0 = 0  # Define object
    str_1 = 'str_1'  # Define object
    str_2 = 'str_2'  # Define object
    h_p_u_x_virtual_0 = HPUXVirtual(str_0, int_0, str_1, str_2)  # Create object
    h_p_u_x_virtual_1 = HPUXVirtual(str_0)  # Create object



# Generated at 2022-06-25 01:13:34.435107
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = 'yW/`^nM{@gd('
    str_1 = '{Xtj|@ut>P^}'
    str_2 = 'cj)rBYDF!z{^'
    str_3 = '7FWuEKB_Fu5%'
    str_4 = '<uSbJ-a*'
    str_5 = '+Qa;Gw&hD^j'
    str_6 = '+ZW8Xv+_%'
    str_7 = 'yW/`^nM{@gd('
    list_0 = []
    list_1 = []
    list_2 = []
    list_3 = []
    list_4 = []
    set_0 = set()
    set_1 = set()
    h_p_u

# Generated at 2022-06-25 01:13:35.224359
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    pass


# Generated at 2022-06-25 01:13:37.470636
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'FlG>ud:E[#xi'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)


# Generated at 2022-06-25 01:13:42.270024
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual(str())
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:13:47.580000
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = 'Uq'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:14:12.482078
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # str_0 = 'FlG>ud:E[#xi'
    # h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    # var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert False


# Generated at 2022-06-25 01:14:14.366925
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = '+e$J4,P%*ud:'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    # Test whether instance created properly.
    assert isinstance(h_p_u_x_virtual_0, HPUXVirtual)



# Generated at 2022-06-25 01:14:18.141614
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'jCdNXe'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    assert h_p_u_x_virtual_0._platform == 'HP-UX'

    str_0 = '~:/HZ-_2'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)

    str_0 = '-]aX$W&7D'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:14:20.055964
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = 'gikw/'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_3 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_3 == {}



# Generated at 2022-06-25 01:14:29.243779
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = ')m'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

    assert var_0 == {
        'virtualization_role': None,
        'virtualization_tech_host': set(),
        'virtualization_type': None,
        'virtualization_tech_guest': set()
    }


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 01:14:39.955225
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = 'f1X7]<'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0['virtualization_tech_guest'] == set()
    assert var_0['virtualization_tech_host'] == set()
    assert var_0['virtualization_type'] == 'container'
    assert var_0['virtualization_role'] == 'guest'
    assert var_0 == {'virtualization_tech_host': set(), 'virtualization_tech_guest': set(), 'virtualization_role': 'guest', 'virtualization_type': 'container'}

# Test class for method get_virtual_facts of class HPUXVirtual

# Generated at 2022-06-25 01:14:48.119238
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = 'm^v?P'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_type': 'guest', 'virtualization_role': 'HP nPar', 'virtualization_tech_guest': {'HP nPar'}, 'virtualization_tech_host': set()}


# Generated at 2022-06-25 01:14:52.984459
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'YU[mXHs_;+'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    assert h_p_u_x_virtual_0.module.params['gather_subset'] == ['all']
    assert h_p_u_x_virtual_0.module.params['gather_timeout'] == 10
    assert h_p_u_x_virtual_0.module.params['filter'] == '*'


# Generated at 2022-06-25 01:14:56.414652
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = 'FlG>ud:E[#xi'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)


# Generated at 2022-06-25 01:14:58.585601
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_collector_0 = HPUXVirtualCollector()
    var_0 = h_p_u_x_virtual_collector_0.collect()

# Generated at 2022-06-25 01:15:29.043345
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # h_p_u_x_virtual_1 = HPUXVirtual()
    pass

# Generated at 2022-06-25 01:15:33.912010
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual(None)

    assert isinstance(h_p_u_x_virtual_0.get_virtual_facts(), dict) is True

# Generated at 2022-06-25 01:15:39.420285
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0 is not None


# Generated at 2022-06-25 01:15:41.698363
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:15:46.474033
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = init__HPUXVirtual(0)


# Generated at 2022-06-25 01:15:50.943038
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0['virtualization_tech_host'] == set()
    assert var_0['virtualization_role'] == 'HP vPar'
    assert var_0['virtualization_tech_guest'] == {'HP vPar'}
    assert var_0['virtualization_type'] == 'guest'



# Generated at 2022-06-25 01:15:52.359938
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    virtual_facts_0 = h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:15:53.525438
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.collect()

# Generated at 2022-06-25 01:15:56.826939
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual = HPUXVirtual()
    assert h_p_u_x_virtual.get_virtual_facts() is None


# Generated at 2022-06-25 01:15:59.366208
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.platform == 'HP-UX'


# Generated at 2022-06-25 01:16:59.813671
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    var_0 = h_p_u_x_virtual_0.get_virtual_facts(h_p_u_x_virtual_0)


# Generated at 2022-06-25 01:17:01.297515
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    var_1 = h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:17:03.118808
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual('ansible.')
    var_1 = h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:17:07.512803
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert os.path.exists('/usr/sbin/vecheck') == False
    assert os.path.exists('/opt/hpvm/bin/hpvminfo') == False
    assert os.path.exists('/usr/sbin/parstatus') == False
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.get_virtual_facts(h_p_u_x_virtual_0)


# Generated at 2022-06-25 01:17:09.757532
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0['virtualization_type'] == 'host'


# Generated at 2022-06-25 01:17:13.672407
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:17:20.157345
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert(var_0 == {'virtualization_tech_guest': set([]),
                     'virtualization_tech_host': set([])})


# Generated at 2022-06-25 01:17:21.051114
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert callable( getattr(HPUXVirtual, 'collect') )


# Generated at 2022-06-25 01:17:26.509844
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    test_dict = {'virtualization_tech_guest': set(), 'virtualization_role': 'HP nPar', 'virtualization_tech_host': set(), 'virtualization_type': 'guest'}
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 == test_dict

if __name__ == "__main__":
    test_case_0()
    test_HPUXVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:17:29.273716
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    hp_ux_virtual_0 = HPUXVirtual()
    hp_ux_virtual_0.module = module_0
    var_2 = hp_ux_virtual_0.get_virtual_facts()
    assert type(var_2) is dict