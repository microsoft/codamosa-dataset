

# Generated at 2022-06-25 01:07:51.173644
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_type': None, 'virtualization_role': None, 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

# Generated at 2022-06-25 01:07:53.452491
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual = HPUXVirtual()
    virtual_facts_dict = h_p_u_x_virtual.get_virtual_facts()
    return virtual_facts_dict

# Generated at 2022-06-25 01:07:54.437376
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:07:57.877485
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    print("\n")
    # `HPUXVirtual.get_virtual_facts` is not implemented
    # Call `HPUXVirtual.get_virtual_facts`
    # h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:08:00.795602
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.platform == 'HP-UX'
    assert h_p_u_x_virtual_0.get_virtual_facts() == {}



# Generated at 2022-06-25 01:08:02.638323
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()

# Generated at 2022-06-25 01:08:07.877197
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module = MagicMock()
    h_p_u_x_virtual_0.module.run_command.side_effect = lambda x: (0, "fake_result", "")
    h_p_u_x_virtual_0.module.run_command.return_value = 0
    h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:08:09.769560
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual({'module': {'run_command': (lambda x, **y: ("", "", 0))}})



# Generated at 2022-06-25 01:08:14.064858
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    import os
    import re
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.platform == 'HP-UX'
    assert h_p_u_x_virtual_0.get_virtual_facts() == {}

# Generated at 2022-06-25 01:08:15.266375
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()



# Generated at 2022-06-25 01:08:25.175883
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_instance_0 = HPUXVirtual()


# Generated at 2022-06-25 01:08:26.643223
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    test_case_0()


# Generated at 2022-06-25 01:08:33.812064
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():

    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.virtualization_type == 'unknown'
    assert h_p_u_x_virtual_0.virtualization_role == 'unknown'
    assert h_p_u_x_virtual_0.virtualization_system == 'unknown'
    assert h_p_u_x_virtual_0.virtualization_hypervisor == 'unknown'
    assert h_p_u_x_virtual_0.virtualization_host_name == 'unknown'
    assert h_p_u_x_virtual_0.virtualization_guest_name == 'unknown'
    assert h_p_u_x_virtual_0.virtualization_product == 'unknown'
    assert h_p_u_x_virtual_0

# Generated at 2022-06-25 01:08:35.365337
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual(dict(), dict())


# Generated at 2022-06-25 01:08:39.799738
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    my_hpuxvirtual_0 = HPUXVirtual()
    my_hpuxvirtual_0.module.run_command = lambda cmd: (0, 'Running HPVM vPar', '')
    my_hpuxvirtual_0.module.get_bin_path = lambda cmd, opt: 'cmd'
    my_hpuxvirtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:08:49.256192
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Test function for method get_virtual_facts of class HPUXVirtual
    """
    h_p_u_x_virtual_1 = HPUXVirtual()
    h_p_u_x_virtual_1.module.run_command = get_run_command_0()
    assert 'HPVM' in h_p_u_x_virtual_1.get_virtual_facts()[
        'virtualization_tech_guest']
    h_p_u_x_virtual_2 = HPUXVirtual()
    h_p_u_x_virtual_2.module.run_command = get_run_command_0()
    assert 'HP vPar' in h_p_u_x_virtual_2.get_virtual_facts()[
        'virtualization_tech_guest']
    h_p_

# Generated at 2022-06-25 01:08:54.619027
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    virtual_h_p_u_x_virtual_0 = HPUXVirtual()
    virtual_h_p_u_x_virtual_0.module = MagicMock(return_value='')
    virtual_h_p_u_x_virtual_0.module.run_command = MagicMock(return_value=(0, 0, 0))
    virtual_h_p_u_x_virtual_0.module.params = {}
    assert virtual_h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}


# Generated at 2022-06-25 01:08:55.544745
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    pass

# Generated at 2022-06-25 01:08:58.283325
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.get_virtual_facts() == None


# Generated at 2022-06-25 01:09:00.669561
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(module_0)


# Generated at 2022-06-25 01:09:17.616517
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    if os.path.exists('/usr/sbin/vecheck') and os.path.exists('/opt/hpvm/bin/hpvminfo') and os.path.exists('/usr/sbin/parstatus'):
        h_p_u_x_virtual_0 = HPUXVirtual()
        assert h_p_u_x_virtual_0.facts['virtualization_type'] == 'guest'
        assert h_p_u_x_virtual_0.facts['virtualization_role'] == 'HP vPar'
        h_p_u_x_virtual_0 = None

# Generated at 2022-06-25 01:09:20.637347
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module = ansible_module_0
    h_p_u_x_virtual_0.module.run_command = run_command_0
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:09:24.469117
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.platform == 'HP-UX'


# Generated at 2022-06-25 01:09:25.374087
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:09:26.576774
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:09:28.505548
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual(module=None)
    h_p_u_x_virtual_0.module.run_command = run_command_mock
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:09:36.233089
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    set_module_args(module_args)
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.get_virtual_facts()


if __name__ == '__main__':
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.basic import AnsibleModule
    module_args = {}
    module = AnsibleModule(argument_spec=module_args)
    facts_obj = Facts(module)
    facts_obj.populate_facts()
    module.exit_json(changed=False)

# Generated at 2022-06-25 01:09:42.236760
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
        __virtual = HPUXVirtual()
        __virtual_facts = __virtual.get_virtual_facts()
        __virtual_expected_facts = {
            'virtualization_tech_guest': set(['HPVM', 'HP nPar']),
            'virtualization_role': 'HP nPar',
            'virtualization_type': 'guest',
            'virtualization_tech_host': set()
        }
        assert __virtual_facts == __virtual_expected_facts

if __name__ == '__main__':
    test_case_0()
    test_HPUXVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:09:52.223046
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import json
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    h_p_u_x_virtual_obj = HPUXVirtual()
    h_p_u_x_virtual_obj.module = mock_module_0
    h_p_u_x_virtual_obj.module.run_command = mock_run_command_0
    h_p_u_x_virtual_obj.module.run_command.return_value = (0, "", "")
    h_p_u_x_virtual_obj_get_virtual_facts = h_p_u_x_virtual_obj.get_virtual_facts()

# Generated at 2022-06-25 01:09:54.195282
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(module=dict(params=dict()), platform='HP-UX')


# Generated at 2022-06-25 01:10:11.488698
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    result = h_p_u_x_virtual_0.get_virtual_facts()
    assert isinstance(result, dict)

# Generated at 2022-06-25 01:10:13.857796
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    #do something
    h_p_u_x_virtual_collector_0 = HPUXVirtualCollector()
    h_p_u_x_virtual_collector_0_0 = HPUXVirtual(h_p_u_x_virtual_collector_0)
    ret = h_p_u_x_virtual_collector_0_0.get_virtual_facts()

# Generated at 2022-06-25 01:10:15.994280
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:10:17.163686
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:10:23.702340
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    rc, out, err = h_p_u_x_virtual_0.module.run_command("/usr/sbin/vecheck")
    if rc == 0:
        rc, out, err = h_p_u_x_virtual_0.module.run_command("/usr/sbin/parstatus")
        if rc == 0:
            virtual_facts_0 = h_p_u_x_virtual_0.get_virtual_facts()
            assert 'virtualization_role' in virtual_facts_0, 'virtual_facts_0.get(virtualization_role) is incorrect'
            assert virtual_facts_0['virtualization_role'] == 'HP nPar'

# Generated at 2022-06-25 01:10:30.025442
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    if h_p_u_x_virtual_collector_0 is not None:
        module = h_p_u_x_virtual_collector_0._module_class
    h_p_u_x_virtual_0 = HPUXVirtual(module)
    if h_p_u_x_virtual_0._module != module:
        raise Exception("Module not set")
    if h_p_u_x_virtual_0._platform != 'HP-UX':
        raise Exception("Platform not set")


# Generated at 2022-06-25 01:10:31.804729
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0


# Generated at 2022-06-25 01:10:33.665154
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(module = None)
    h_p_u_x_virtual_1 = HPUXVirtual(module = None)


# Generated at 2022-06-25 01:10:34.630764
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()

# Generated at 2022-06-25 01:10:37.128436
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:10:52.636075
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    from ansible.module_utils.facts.virtual.h_p_u_x import HPUXVirtual
    out = HPUXVirtual()


# Generated at 2022-06-25 01:10:53.433437
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:10:55.885864
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.get_virtual_facts()


if __name__ == '__main__':
    test_case_0()
    test_HPUXVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:11:05.447957
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()

    # test_virtualization_type of class HPUXVirtual
    assert h_p_u_x_virtual_0.virtualization_type() == {}

    # test_virtualization_role of class HPUXVirtual
    assert h_p_u_x_virtual_0.virtualization_role() == {}

    # test_virtualization_guest_tech of class HPUXVirtual
    assert h_p_u_x_virtual_0.virtualization_guest_tech() == {}

    # test_virtualization_host_tech of class HPUXVirtual
    assert h_p_u_x_virtual_0.virtualization_host_tech() == {}

    # test_get_virtual_facts of class HPUXVirtual
    assert h_p_

# Generated at 2022-06-25 01:11:06.899377
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    h_p_u_x_virtual_instance = HPUXVirtual()


# Generated at 2022-06-25 01:11:08.533746
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual(module=MagicMock())

    assert isinstance(h_p_u_x_virtual_0.get_virtual_facts(), dict)

# Generated at 2022-06-25 01:11:12.736256
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()


# Generated at 2022-06-25 01:11:17.962933
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import os
    h_p_u_x_virtual_0 = HPUXVirtual()
    setattr(h_p_u_x_virtual_0, 'module', os)
    h_p_u_x_virtual_get_virtual_facts_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert h_p_u_x_virtual_get_virtual_facts_0['virtualization_type'] == 'guest'
    assert h_p_u_x_virtual_get_virtual_facts_0['virtualization_role'] == 'HP vPar'
    assert h_p_u_x_virtual_get_virtual_facts_0['virtualization_tech_guest'] == {'HP vPar'}

# Generated at 2022-06-25 01:11:19.261491
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual(module=None)

    if h_p_u_x_virtual.platform == "HP-UX":
        assert True


# Generated at 2022-06-25 01:11:20.408101
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()  # noqa: F841

# Generated at 2022-06-25 01:11:47.153689
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(dict())
    h_p_u_x_virtual_1 = HPUXVirtual(
        module=dict(),
        collect_subset=list('no'))


# Generated at 2022-06-25 01:11:50.482966
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    try:
        import sys
        import ansible.module_utils.facts.virtual.hpux as hpux
        module = ansible.module_utils.facts.virtual.hpux.HPUXVirtual()
        module.get_virtual_facts()
    except Exception as ex:
        assert type(ex).__name__ == 'AttributeError'


# Generated at 2022-06-25 01:11:51.470635
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(dict())


# Generated at 2022-06-25 01:11:52.199464
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_ = HPUXVirtual()


# Generated at 2022-06-25 01:11:55.247757
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_type': None, 'virtualization_role': None, 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}


# Generated at 2022-06-25 01:11:58.979841
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:12:00.949065
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():

    h_p_u_x_virtual = HPUXVirtual()
    assert h_p_u_x_virtual is not None


# Generated at 2022-06-25 01:12:07.103191
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_collector_0 = HPUXVirtualCollector()
    h_p_u_x_virtual_0 = HPUXVirtual(h_p_u_x_virtual_collector_0)
    assert h_p_u_x_virtual_0.get_virtual_facts() == {}


# Generated at 2022-06-25 01:12:15.414215
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module_args = {}
    m = AnsibleModule(argument_spec=module_args, supports_check_mode=True)

    h_p_u_x_virtual_0 = HPUXVirtual({}, m)
    setattr(m, 'run_command', lambda x: (0, 'fake', ''))

    h_p_u_x_virtual_0.module = m
    h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:12:19.837505
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    data = h_p_u_x_virtual_0.get_virtual_facts()
    assert data['virtualization_tech_guest'] == set()
    assert data['virtualization_tech_host'] == set()
    pass


# Generated at 2022-06-25 01:12:47.944189
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    HPUXVirtual_class_instance = HPUXVirtual()
    result = HPUXVirtual_class_instance.get_virtual_facts()


# Generated at 2022-06-25 01:12:50.484579
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:12:52.337320
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:12:57.444459
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(module=None)
    print(h_p_u_x_virtual_0)


if __name__ == '__main__':
    test_HPUXVirtual()

# Generated at 2022-06-25 01:13:06.578231
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    def test_module_run_command_side_effect(arg1):
        if re.match('.*vecheck.*', arg1):
            return (0, '', '')
        elif re.match('.*hpvminfo.*', arg1):
            return (0, 'Running HPVM guest\n', '')
        elif re.match('.*parstatus.*', arg1):
            return (0, '', '')
        else:
            return (256, '', '')

    module_mock = type('module_mock', (object,), {
        'run_command': lambda arg1: test_module_run_command_side_effect(arg1)
    })

    test_module = module_mock()

    test_class = HPUXVirtual(test_module)

    assert test_class

# Generated at 2022-06-25 01:13:16.167944
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0._module = {
        'run_command': (
            0,
            '',
            ''
        )
    }

    def good_file(filename):
        return True

    def isfile(filename):
        return True

    h_p_u_x_virtual_0.os.path.exists = good_file
    h_p_u_x_virtual_0.os.path.isfile = isfile
    h_p_u_x_virtual_0.virtual_facts = {}
    h_p_u_x_virtual_0_virtual_facts = h_p_u_x_virtual_0.get_virtual_facts()
    assert h_p_u_x_virtual

# Generated at 2022-06-25 01:13:17.545048
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual(dict()).platform == 'HP-UX'


# Generated at 2022-06-25 01:13:21.940990
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:13:26.028473
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    host_tech = set()
    guest_tech = set()
    expected_virtual_facts = {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_guest': guest_tech,
        'virtualization_tech_host': host_tech
    }

    h_p_u_x_virtual_get_virtual_facts_0 = HPUXVirtual()
    if h_p_u_x_virtual_get_virtual_facts_0.get_virtual_facts() != expected_virtual_facts:
        raise AssertionError("Expected: %s, but got: %s" % (expected_virtual_facts, h_p_u_x_virtual_get_virtual_facts_0.get_virtual_facts()))

# Generated at 2022-06-25 01:13:28.105277
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual({'module_name': 'test'})
    assert h_p_u_x_virtual_0 is not None

# Generated at 2022-06-25 01:13:52.503762
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_1 = HPUXVirtual()
    h_p_u_x_virtual_2 = HPUXVirtual()
    h_p_u_x_virtual_3 = HPUXVirtual()
    h_p_u_x_virtual_4 = HPUXVirtual()
    h_p_u_x_virtual_5 = HPUXVirtual()
    h_p_u_x_virtual_6 = HPUXVirtual()
    h_p_u_x_virtual_7 = HPUXVirtual()
    h_p_u_x_virtual_8 = HPUXVirtual()
    h_p_u_x_virtual_9 = HPUXVirtual()
    h_p_u_x_

# Generated at 2022-06-25 01:13:53.193294
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual


# Generated at 2022-06-25 01:14:01.767589
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module.run_command = run_command
    h_p_u_x_virtual_0.module.params = {}
    virtual_facts = h_p_u_x_virtual_0.get_virtual_facts()
    assert virtual_facts == {'virtualization_type': 'host', 'virtualization_role': 'HPVM', 'virtualization_tech_host': {'HPVM'}, 'virtualization_tech_guest': {'HPVM'}}


# Generated at 2022-06-25 01:14:02.912336
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()


# Generated at 2022-06-25 01:14:05.981895
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual({}).platform == 'HP-UX'
    assert re.search(HPUXVirtual({})._re_exists['hpvm'], '/opt/hpvm/bin/hpvminfo')


# Generated at 2022-06-25 01:14:14.588997
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    virtual_facts_dict = h_p_u_x_virtual_0.get_virtual_facts()
    if 'virtualization_type' in virtual_facts_dict.keys():
        assert (virtual_facts_dict.get('virtualization_type') == 'guest' or virtual_facts_dict.get('virtualization_type') == 'host')

# Generated at 2022-06-25 01:14:24.709543
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual = HPUXVirtual()
    h_p_u_x_virtual.module._debug = False
    h_p_u_x_virtual.module.run_command = fake_run_command
    expected_virtual_facts_1 = {'virtualization_tech_guest': set(), 'virtualization_role': 'HP vPar', 'virtualization_type': 'guest', 'virtualization_tech_host': set()}
    expected_virtual_facts_0 = {'virtualization_tech_guest': set(), 'virtualization_role': 'HP vPar', 'virtualization_type': 'host', 'virtualization_tech_host': set()}

# Generated at 2022-06-25 01:14:27.026025
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    output = h_p_u_x_virtual_0.get_virtual_facts()
    assert output == {}


# Generated at 2022-06-25 01:14:28.358230
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:14:39.896758
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_collector_0 = HPUXVirtualCollector()
    h_p_u_x_virtual_0 = h_p_u_x_virtual_collector_0._get_virtual_facts()
    # Virtualization guest_tech should be empty set
    assert h_p_u_x_virtual_0['virtualization_tech_guest'] == set()
    # Virtualization host_tech should be empty set
    assert h_p_u_x_virtual_0['virtualization_tech_host'] == set()
    # Virtualization role should be empty string
    assert h_p_u_x_virtual_0['virtualization_role'] == ''
    # Virtualization type should be empty string
    assert h_p_u_x_virtual_0['virtualization_type'] == ''

# Generated at 2022-06-25 01:15:14.151170
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = ' fetch host object using name deal with  implicit localhost '
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    int_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert (str_0 == ' fetch host object using name deal with  implicit localhost ')
    assert (h_p_u_x_virtual_0 != None)


# Generated at 2022-06-25 01:15:16.082560
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = ' fetch host object using name deal with implicit localhost '
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:15:19.587319
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-25 01:15:27.314182
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    print("running test get_virtual_facts")
    str_0 = ' fetch host object using name deal with implicit localhost '
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    print("Test 0:")
    print("var_0 = ")
    for ele in var_0:
        print(ele, end="")
    print("\n")


# Generated at 2022-06-25 01:15:29.528166
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = ' fetch host object using name deal with implicit localhost '
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    assert str_0 == h_p_u_x_virtual_0.module._name


# Generated at 2022-06-25 01:15:33.309392
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    assert h_p_u_x_virtual_0.get_virtual_facts() == test_case_0()

# Generated at 2022-06-25 01:15:39.550798
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_hpu_0 = ' fetch host object using name deal with implicit localhost '
    h_p_u_x_virtual_0 = HPUXVirtual(str_hpu_0)
    assert h_p_u_x_virtual_0 is not None


# Generated at 2022-06-25 01:15:40.082488
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    assert set() == set()

# Generated at 2022-06-25 01:15:43.963129
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = ' fetch host object using name deal with implicit localhost '
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    assert h_p_u_x_virtual_0.module == str_0
    assert h_p_u_x_virtual_0.platform == 'HP-UX'
    assert h_p_u_x_virtual_0._dist_version_cache == {}


# Generated at 2022-06-25 01:15:46.952541
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = ' fetch host object using name deal with implicit localhost '
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    var_1 = HPUXVirtual.get_virtual_facts(h_p_u_x_virtual_0)


# Generated at 2022-06-25 01:16:20.135617
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = ' fetch host object using name deal with implicit localhost '
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    # AssertionError: The value for virtualization_tech_guest is not correct.
    assert (h_p_u_x_virtual_0.virtualization_tech_guest == {'HP vPar', 'HP nPar', 'HPVM IVM', 'HPVM vPar', 'HPVM'})
    # AssertionError: The value for virtualization_tech_host is not correct.
    assert (h_p_u_x_virtual_0.virtualization_tech_host == set())
    # AssertionError: The value for virtualization_role is not correct.

# Generated at 2022-06-25 01:16:21.306998
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = ' fetch host object using name deal with implicit localhost '
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)


# Generated at 2022-06-25 01:16:27.299529
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = ' fetch host object using name deal with implicit localhost '
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert 'virtualization_tech_host' not in var_0
    assert 'virtualization_tech_guest' in var_0


# Generated at 2022-06-25 01:16:29.708276
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = ' fetch host object using name deal with implicit localhost '
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:16:32.755727
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = ' fetch host object using name deal with implicit localhost '
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    assert h_p_u_x_virtual_0.module == str_0 


# Generated at 2022-06-25 01:16:36.247131
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = ' fetch host object using name deal with implicit localhost '
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:16:41.151918
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = 'fetch host object using name deal with implicit localhost'
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    assert h_p_u_x_virtual_0.get_virtual_facts() is None


# Generated at 2022-06-25 01:16:45.213762
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # Constructor and attr of HPUXVirtual
    str_0 = ' fetch host object using name deal with implicit localhost '
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)

    # attr of HPUXVirtual
    assert h_p_u_x_virtual_0.module == str_0
    assert h_p_u_x_virtual_0._platform == 'HP-UX'
    assert h_p_u_x_virtual_0.platform == 'HP-UX'


# Generated at 2022-06-25 01:16:48.052693
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = ' fetch host object using name deal with implicit localhost '
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:16:51.719531
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    tmp_0 = HPUXVirtual('ModuleUtilsVirtual.collector')
    str_0 = ' fetch host object using name deal with implicit localhost '
    var_0 = tmp_0.get_virtual_facts(str_0)
    assert(var_0 == {})


# Generated at 2022-06-25 01:17:30.364742
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    str_0 = ' fetch host object using name deal with implicit localhost '
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    if var_0 == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_type': 'host', 'virtualization_role': 'physical'}:
        var_0 = True
    else:
        var_0 = False


# Generated at 2022-06-25 01:17:32.791007
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = ' fetch host object using name deal with implicit localhost '
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)


# Generated at 2022-06-25 01:17:33.398223
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    test_case_0()

# Generated at 2022-06-25 01:17:39.482137
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    str_0 = ' fetch host object using name deal with implicit localhost '
    h_p_u_x_virtual_0 = HPUXVirtual(str_0)
    assert 'virtualization_tech_host' in h_p_u_x_virtual_0
    assert 'virtualization_tech_guest' in h_p_u_x_virtual_0
    assert 'virtualization_role' in h_p_u_x_virtual_0
    assert 'virtualization_type' in h_p_u_x_virtual_0
    assert isinstance(h_p_u_x_virtual_0['virtualization_tech_host'], set)
    assert isinstance(h_p_u_x_virtual_0['virtualization_tech_guest'], set)
    assert h_p_u_x_virtual_