

# Generated at 2022-06-25 01:07:47.066864
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    # Currently, no test for virtual_facts


# Generated at 2022-06-25 01:07:48.139092
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual({})

# Generated at 2022-06-25 01:07:55.406072
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()

    # Assert property “virtualization_type”
    assert h_p_u_x_virtual_0.virtualization_type == None

    # Assert property “virtualization_role”
    assert h_p_u_x_virtual_0.virtualization_role == None

    # Assert property “virtualization_tech_guest”
    assert h_p_u_x_virtual_0.virtualization_tech_guest == set()

    # Assert property “virtualization_tech_host”
    assert h_p_u_x_virtual_0.virtualization_tech_host == set()

    # Assert property “virtualization_tech_guest_list”
    assert h_p_u_x

# Generated at 2022-06-25 01:07:57.426277
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.platform == 'HP-UX'


# Generated at 2022-06-25 01:08:05.101798
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    # Test 'virtualization_type' of class HPUXVirtual
    assert h_p_u_x_virtual_0.virtualization_type is None
    # Test 'virtualization_role' of class HPUXVirtual
    assert h_p_u_x_virtual_0.virtualization_role is None
    # Test 'virtualization_tech_host' of class HPUXVirtual
    assert h_p_u_x_virtual_0.virtualization_tech_host is None
    # Test 'virtualization_tech_guest' of class HPUXVirtual
    assert h_p_u_x_virtual_0.virtualization_tech_guest is None

# Generated at 2022-06-25 01:08:07.876578
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()



if __name__ == "__main__":
    test_case_0()
    test_HPUXVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:08:10.014126
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module_args = dict(
        gather_subset=['all']
    )
    h_p_u_x_virtual = HPUXVirtual(module_args)
    print(h_p_u_x_virtual.platform)


# Generated at 2022-06-25 01:08:12.421675
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(module=None)

# Generated at 2022-06-25 01:08:18.175876
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module.run_command = run_command
    h_p_u_x_virtual_0.module.run_command.side_effect = [
        (0, '', ''),
        (0, '', ''),
        (0, '', ''),
        (0, '', '')
    ]
    assert h_p_u_x_virtual_0.get_virtual_facts() == {
        'virtualization_role': 'HPVM',
        'virtualization_type': 'host',
        'virtualization_tech_host': {'HPVM'},
        'virtualization_tech_guest': set()
    }


# Generated at 2022-06-25 01:08:27.870979
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual({})
    h_p_u_x_virtual_1 = HPUXVirtual({'ansible_facts': {'virtual': {'guest_tech': 'HPVM IVM'}, 'virtual_role': 'HPVM IVM'}})
    h_p_u_x_virtual_2 = HPUXVirtual({'ansible_facts': {'virtual_role': 'HP vPar'}})
    h_p_u_x_virtual_3 = HPUXVirtual({'ansible_facts': {'virtual_role': 'HPVM vPar'}})
    h_p_u_x_virtual_4 = HPUXVirtual({'ansible_facts': {'virtual_role': 'HP nPar'}})
    h_p_u_x

# Generated at 2022-06-25 01:08:38.888118
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.platform == 'HP-UX'


# Generated at 2022-06-25 01:08:42.352273
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.get_virtual_facts() == {
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(),
    }

# Generated at 2022-06-25 01:08:47.402788
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    virtual_facts = {}

    # Run get_virtual_facts method
    h_p_u_x_virtual_0 = HPUXVirtual({'module': module}, virtual_facts, 'HP-UX')
    h_p_u_x_virtual_1 = h_p_u_x_virtual_0.get_virtual_facts()
    assert h_p_u_x_virtual_1 == virtual_facts

# Generated at 2022-06-25 01:08:54.346334
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    out = {'virtualization_role': 'HP vPar','virtualization_tech_host':set(),'virtualization_type': 'guest','virtualization_tech_guest': set(['HP vPar'])}
    h_p_u_x_virtual_0 = HPUXVirtual()

# Generated at 2022-06-25 01:08:58.928924
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    Constructor test for class HPUXVirtual
    """
    h_p_u_x_virtual_0 = HPUXVirtual(None)
    if h_p_u_x_virtual_0.platform != 'HP-UX':
        raise Exception('Expected value HP-UX for attribute platform, but got ' + repr(h_p_u_x_virtual_0.platform))


# Generated at 2022-06-25 01:09:03.292269
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    print(h_p_u_x_virtual_0.get_virtual_facts())

# h_p_u_x_virtual_0 = HPUXVirtual()
# print(h_p_u_x_virtual_0.get_virtual_facts())

# Generated at 2022-06-25 01:09:07.613385
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.get_virtual_facts()['virtualization_type'] == 'guest'
    assert h_p_u_x_virtual_0.get_virtual_facts()['virtualization_role'] == 'HPVM'



# Generated at 2022-06-25 01:09:11.952751
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_collector_0 = HPUXVirtualCollector()
    h_p_u_x_virtual_0 = HPUXVirtual(h_p_u_x_virtual_collector_0.module)
    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_type': 'guest', 'virtualization_role': 'HP vPar', 'virtualization_tech_guest': {'HP nPar', 'HP vPar'}, 'virtualization_tech_host': set()}


# Generated at 2022-06-25 01:09:13.404619
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(dict())
    assert h_p_u_x_virtual_0 is not None


# Generated at 2022-06-25 01:09:19.693955
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual(dict(ANSIBLE_MODULE_ARGS={'gather_subset': ['all']}, ANSIBLE_FACTS={}))
    h_p_u_x_virtual_0.module.run_command = MagicMock(return_value=(0, '', ''))
    h_p_u_x_virtual_0.get_virtual_facts()
    h_p_u_x_virtual_0.module.run_command.assert_has_calls([call("/usr/sbin/vecheck"), call("/opt/hpvm/bin/hpvminfo"), call("/usr/sbin/parstatus")])

# Generated at 2022-06-25 01:09:38.063394
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_role': None, 'virtualization_type': None,
                                                     'virtualization_type_role': None, 'virtualization_tech_guest': set(),
                                                     'virtualization_tech_host': set()}


# Generated at 2022-06-25 01:09:42.589780
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    os.path.exists.return_value = True
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.get_virtual_facts() == {'virtualization_type': 'guest', 'virtualization_role': 'HP nPar', 'virtualization_tech_guest': {'HP nPar'}, 'virtualization_tech_host': set()}

# Generated at 2022-06-25 01:09:47.558421
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_collector_0 = HPUXVirtualCollector()
    h_p_u_x_virtual_0 = h_p_u_x_virtual_collector_0.collect()[0]
    h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:09:49.292115
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(None, {})


# Generated at 2022-06-25 01:09:50.848634
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:09:58.088357
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module_args = {'ANSIBLE_MODULE_ARGS': {}}
    h_p_u_x_virtual_0 = HPUXVirtual(module_args=module_args)
    h_p_u_x_virtual_0.module.run_command = run_command_mock
    h_p_u_x_virtual_get_virtual_facts_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert h_p_u_x_virtual_get_virtual_facts_0['virtualization_tech_guest'] == {'HP nPar', 'HP vPar'}
    assert h_p_u_x_virtual_get_virtual_facts_0['virtualization_tech_host'] == set()
    assert h_p_u_x_virtual_get_virtual_

# Generated at 2022-06-25 01:10:00.633046
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    h_p_u_x_virtual_0 = HPUXVirtual(module)
    h_p_u_x_virtual_0.get_virtual_facts()
    module.run_command.assert_called_with("/usr/sbin/vecheck")


# Generated at 2022-06-25 01:10:01.931310
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.facts == {}

# Generated at 2022-06-25 01:10:04.331966
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()


# Generated at 2022-06-25 01:10:12.459063
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Given
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0._module = mock.Mock()
    h_p_u_x_virtual_0.module.run_command = mock.MagicMock(return_value=("", "", "", "", 0))
    h_p_u_x_virtual_0._module._socket_path = "/foo/bar"

    # When
    result = h_p_u_x_virtual_0.get_virtual_facts()

    # Then
    assert "run_command" in h_p_u_x_virtual_0.module.run_command.call_args_list[0][0]
    assert "virtualization_type" in result
    assert "virtualization_type" in result
   

# Generated at 2022-06-25 01:10:32.355359
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual() # Instantiate class
    # Assert if Virtualization Type equals
    assert h_p_u_x_virtual_0.get_virtual_facts()['virtualization_type'] == 'guest'
    # Assert if Virtualization Role equals
    assert h_p_u_x_virtual_0.get_virtual_facts()['virtualization_role'] == 'HP vPar'
    # Assert if Virtualization Tech Guest equals
    assert h_p_u_x_virtual_0.get_virtual_facts()['virtualization_tech_guest'] == {'HP vPar'}
    # Assert if Virtualization Tech Host equals
    assert h_p_u_x_virtual_0.get_virtual_facts()['virtualization_tech_host'] == set()

# Generated at 2022-06-25 01:10:36.587087
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    _h_p_u_x_virtual = HPUXVirtual()
    _dict = {}
    _dict = _h_p_u_x_virtual.get_virtual_facts()
    assert type(_dict) is dict, "Return type of method get_virtual_facts of class HPUXVirtual is %s, expected: <class 'dict'>" % (
        type(_dict)
    )


# Generated at 2022-06-25 01:10:37.818066
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:10:45.096987
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = AnsibleModule(
        argument_spec=dict()
    )
    h_p_u_x_virtual_0 = HPUXVirtual(module)
    # When no config file, 'virtualization_tech_guest' should be empty
    actual = 'virtualization_tech_guest' in h_p_u_x_virtual_0.get_virtual_facts()
    assert actual is False
    # When no config file, 'virtualization_tech_host' should be empty
    actual = 'virtualization_tech_host' in h_p_u_x_virtual_0.get_virtual_facts()
    assert actual is False
    # When no config file, 'virtualization_role' should be empty
    actual = 'virtualization_role' in h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:10:47.077946
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # Given
    h_p_u_x_virtual_0 = HPUXVirtual(module=None, collect_echo=False)

    #When
    #Then
    assert h_p_u_x_virtual_0 is not None


# Generated at 2022-06-25 01:10:51.098043
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Tests the method get_virtual_facts of class HPUXVirtual.

    It is a static method. Thus it can be tested without instantiating an
    object.
    """
    h_p_u_x_virtual = HPUXVirtual(module=None)
    assert h_p_u_x_virtual.get_virtual_facts() is not None



# Generated at 2022-06-25 01:10:52.247359
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:10:54.177223
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_collector_0 = HPUXVirtualCollector()
    h_p_u_x_virtual_0 = h_p_u_x_virtual_collector_0.fetch_virtual_facts()
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:11:01.094035
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual(module=True)
    assert h_p_u_x_virtual_0.platform == 'HP-UX'
    assert h_p_u_x_virtual_0.get_virtual_facts()


if __name__ == '__main__':
    test_case_0()
    test_HPUXVirtual()

# Generated at 2022-06-25 01:11:02.683794
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    my_h_p_u_x_virtual_object = HPUXVirtual()
    my_h_p_u_x_virtual_object.get_virtual_facts()


# Generated at 2022-06-25 01:11:34.801284
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()

    set(['vPar'])
    assert h_p_u_x_virtual_0.get_virtual_facts()['virtualization_type'] == 'guest'

# Generated at 2022-06-25 01:11:43.949937
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()

    # From /etc/issue
    facts = dict()
    h_p_u_x_virtual_0.facts = facts

    h_p_u_x_virtual_0._get_virtual_facts()

    assert h_p_u_x_virtual_0.facts['virtualization_type'] == 'guest'
    assert h_p_u_x_virtual_0.facts['virtualization_role'] == 'HP vPar' # HP-UX vPars
    assert 'HPVM' not in h_p_u_x_virtual_0.facts['virtualization_tech_host']
    assert 'HPVM' in h_p_u_x_virtual_0.facts['virtualization_tech_guest']
    assert 'HP vPar'

# Generated at 2022-06-25 01:11:48.530037
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_collector_1 = HPUXVirtualCollector()
    cmd = "/usr/sbin/vecheck"
    rc = 0
    out = "Technologies\n"\
        "------------\n"\
        "\n"\
        "Running HP vPar"
    err = ""
    h_p_u_x_virtual_collector_1.module.run_command = \
        lambda *arg: (rc, out, err)

# Generated at 2022-06-25 01:11:53.509577
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert True == True

# How to improve coverage:
# Write more unit tests for this class

# Generated at 2022-06-25 01:11:59.038137
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpuxvirtual_0 = HPUXVirtual({})
    assert hpuxvirtual_0.get_virtual_facts() == {'virtualization_role': None, 'virtualization_type': None, 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}


# Generated at 2022-06-25 01:12:02.847777
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    virtual_facts_0 = HPUXVirtual().get_virtual_facts()
    assert virtual_facts_0['virtualization_tech_host'] == set()
    assert virtual_facts_0['virtualization_tech_guest'] == set()
    assert virtual_facts_0['virtualization_type'] == 'guest'
    assert virtual_facts_0['virtualization_role'] == 'HP nPar'


# Generated at 2022-06-25 01:12:04.353172
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual({})
    assert h_p_u_x_virtual is not None

# Generated at 2022-06-25 01:12:07.427593
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    virtual_facts_from_method_get_virtual_facts = h_p_u_x_virtual_0.get_virtual_facts()
    assert virtual_facts_from_method_get_virtual_facts



# Generated at 2022-06-25 01:12:14.915808
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    try:
        h_p_u_x_virtual_0.get_virtual_facts()
    except (TypeError, NameError) as error:
        print(
            'Error in get_virtual_facts: {0}'.format(
                repr(error)))


# Generated at 2022-06-25 01:12:21.375200
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    facts = {}
    h_p_u_x_virtual_0.module.run_command = run_command_mock
    h_p_u_x_virtual_0.module.params = {}
    virtual_facts = h_p_u_x_virtual_0.get_virtual_facts()
    assert virtual_facts == facts

# Mock of run_command function

# Generated at 2022-06-25 01:12:56.856664
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():

    # Test with an empty list of facts
    list_0 = []
    h_p_u_x_virtual_0 = HPUXVirtual(list_0)

    # Test with an list of facts containing kvpairs with:
    #  - Virtualization technology
    list_1 = [
        {
            'key': 'virtualization_tech_guest',
            'value': 'HP vPar'
        },
        {
            'key': 'virtualization_tech_host',
            'value': 'HPVM'
        },
        {
            'key': 'virtualization_role',
            'value': 'HPVM vPar'
        }
    ]
    h_p_u_x_virtual_1 = HPUXVirtual(list_1)



# Generated at 2022-06-25 01:13:00.870237
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    list_0 = []
    h_p_u_x_virtual_0 = HPUXVirtual(list_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0['virtualization_type'] == 'host'
    assert var_0['virtualization_role'] == 'HPVM'
    assert var_0['virtualization_tech_host'] == set(['HPVM'])
    assert var_0['virtualization_tech_guest'] == set(['HPVM'])



# Generated at 2022-06-25 01:13:02.693718
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # create object of class HPUXVirtual without any parameter
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.platform == 'HP-UX'


# Generated at 2022-06-25 01:13:12.348936
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    list_0 = []
    h_p_u_x_virtual_0 = HPUXVirtual(list_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    var_1 = []
    var_2 = h_p_u_x_virtual_0.get_virtual_facts()
    var_3 = []
    var_4 = h_p_u_x_virtual_0.get_virtual_facts()
    var_5 = []
    var_6 = h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:13:13.916929
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    list_0 = []
    h_p_u_x_virtual_0 = HPUXVirtual(list_0)


# Generated at 2022-06-25 01:13:17.524299
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    list_1 = []
    h_p_u_x_virtual_1 = HPUXVirtual(list_1)
    h_p_u_x_virtual_1.module.run_command = run_command_mock
    var_1 = h_p_u_x_virtual_1.get_virtual_facts()



# Generated at 2022-06-25 01:13:25.464936
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    list_0 = []
    h_p_u_x_virtual_0 = HPUXVirtual(list_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert not(var_0['virtualization_type'] == 'guest')
    h_p_u_x_virtual_0 = HPUXVirtual(list_0)
    var_1 = h_p_u_x_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:13:27.487555
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    var_0 = HPUXVirtualCollector().get_all_facts()

if __name__ == "__main__":
    test_HPUXVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:13:30.766353
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    list_1 = []
    h_p_u_x_virtual_1 = HPUXVirtual(list_1)
    var_1 = h_p_u_x_virtual_1.get_virtual_facts()



# Generated at 2022-06-25 01:13:33.474215
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    list_0 = []
    h_p_u_x_virtual_0 = HPUXVirtual(list_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:13:54.197040
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    list_0 = []
    h_p_u_x_virtual_0 = HPUXVirtual(list_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:13:58.949329
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    list_0 = []
    h_p_u_x_virtual_0 = HPUXVirtual(list_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:14:08.675858
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    list_0 = ['list', 'elem']
    h_p_u_x_virtual_0 = HPUXVirtual(list_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_tech_host': set(), 'virtualization_technology': []}
    list_1 = []
    h_p_u_x_virtual_1 = HPUXVirtual(list_1)
    var_1 = h_p_u_x_virtual_1.get_virtual_facts()
    assert var_1 == {'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}
    list_2 = ['list']

# Generated at 2022-06-25 01:14:12.989121
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    list_0 = []
    h_p_u_x_virtual_0 = HPUXVirtual(list_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert isinstance(var_0, dict)



# Generated at 2022-06-25 01:14:16.629989
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    list_0 = []
    h_p_u_x_virtual_0 = HPUXVirtual(list_0)


# Generated at 2022-06-25 01:14:19.576151
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual(None)
    assert h_p_u_x_virtual_0._module is None
    # No assertions
    print('module = {}'.format(h_p_u_x_virtual_0._module))
    print('module = {}'.format(h_p_u_x_virtual_0.module))
    print('module = {}'.format(h_p_u_x_virtual_0.module))


# Generated at 2022-06-25 01:14:27.697852
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    list_0 = []
    h_p_u_x_virtual_0 = HPUXVirtual(list_0)
    assert h_p_u_x_virtual_0._platform == 'HP-UX'
    assert h_p_u_x_virtual_0._fact_class == HPUXVirtual
    assert isinstance(h_p_u_x_virtual_0.module, type(None))


# Generated at 2022-06-25 01:14:31.311875
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    list_0 = []
    h_p_u_x_virtual_0 = HPUXVirtual(list_0)
    assert isinstance(h_p_u_x_virtual_0.module, list) is True


# Generated at 2022-06-25 01:14:35.314842
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    list_0 = []
    h_p_u_x_virtual_0 = HPUXVirtual(list_0)
    h_p_u_x_virtual_0.get_virtual_facts()
    h_p_u_x_virtual = HPUXVirtual(module)
    h_p_u_x_virtual.get_virtual_facts()


# Generated at 2022-06-25 01:14:39.935724
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():   
    list_0 = []
    h_p_u_x_virtual_0 = HPUXVirtual(list_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_type': 'guest', 'virtualization_role': 'HPVM vPar', 'virtualization_tech_host': set(), 'virtualization_tech_guest': {'HPVM vPar'}}
   


# Generated at 2022-06-25 01:15:05.650222
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    list_1 = []
    h_p_u_x_virtual_1 = HPUXVirtual(list_1)
    assert h_p_u_x_virtual_1 is not None


# Generated at 2022-06-25 01:15:07.454919
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    list_0 = []
    h_p_u_x_virtual_0 = HPUXVirtual(list_0)
    assert h_p_u_x_virtual_0._platform == 'HP-UX'



# Generated at 2022-06-25 01:15:12.815894
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    list_0 = []
    h_p_u_x_virtual_0 = HPUXVirtual(list_0)
    assert h_p_u_x_virtual_0.platform == 'HP-UX'


# Generated at 2022-06-25 01:15:14.442148
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    list_0 = []
    h_p_u_x_virtual_0 = HPUXVirtual(list_0)
    assert isinstance(h_p_u_x_virtual_0, HPUXVirtual)

# Generated at 2022-06-25 01:15:18.897171
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    list_0 = []
    h_p_u_x_virtual_0 = HPUXVirtual(list_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    var_1 = h_p_u_x_virtual_0.get_virtual_facts()
    var_3 = h_p_u_x_virtual_0.get_virtual_facts()
    var_1 = h_p_u_x_virtual_0.get_virtual_facts()
    var_1 = h_p_u_x_virtual_0.get_virtual_facts()
    var_2 = h_p_u_x_virtual_0.get_virtual_facts()
    var_1 = h_p_u_x_virtual_0.get_virtual_facts()
   

# Generated at 2022-06-25 01:15:21.627412
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    try:
        list_0 = []
        h_p_u_x_virtual_0 = HPUXVirtual(list_0)
    except NameError:
        assert False


# Generated at 2022-06-25 01:15:30.861025
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = {}
    host_tech_0 = set()
    rc_0, out_0, err_0 = h_p_u_x_virtual_0.module.run_command("/usr/sbin/vecheck")
    if rc_0 == 0:
        guest_tech_0.add('HP vPar')
        virtual_facts['virtualization_type'] = 'guest'
        virtual_facts['virtualization_role'] = 'HP vPar'
    rc_1, out_1, err_1 = h_p_u_x_virtual_0.module.run_command("/opt/hpvm/bin/hpvminfo")

# Generated at 2022-06-25 01:15:37.512105
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    var_1 = [""]
    h_p_u_x_virtual_1 = HPUXVirtual(var_1)
    var_2 = dict()
    var_2['virtualization_tech_host'] = set()
    var_2['virtualization_tech_guest'] = set()
    var_2['virtualization_type'] = "guest"
    var_2['virtualization_role'] = "HPVM IVM"
    var_2['virtualization_tech_host'] = set()
    var_2['virtualization_tech_guest'] = {"HPVM IVM"}
    assert h_p_u_x_virtual_1.get_virtual_facts() == var_2
    var_1 = "/usr/sbin/parstatus"
    var_3 = dict()

# Generated at 2022-06-25 01:15:40.638511
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    list_0 = []
    h_p_u_x_virtual_0 = HPUXVirtual(list_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    print(var_0)


# Generated at 2022-06-25 01:15:49.954743
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    list_0 = []
    h_p_u_x_virtual_0 = HPUXVirtual(list_0)
    # Test the condition if virtualization is enabled

# Generated at 2022-06-25 01:16:51.841568
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    list_0 = []
    h_p_u_x_virtual_0 = HPUXVirtual(list_0)

# Generated at 2022-06-25 01:16:55.913630
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    list_0 = []
    h_p_u_x_virtual_0 = HPUXVirtual(list_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert not var_0['virtualization_tech_host']
    assert not var_0['virtualization_tech_guest']
    assert var_0['virtualization_type'] == 'physical'
    assert var_0['virtualization_role'] == ''


test_case_0()



# Generated at 2022-06-25 01:16:58.912958
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    list_1 = []
    h_p_u_x_virtual_1 = HPUXVirtual(list_1)
    assert h_p_u_x_virtual_1._facts
    assert h_p_u_x_virtual_1._platform
    assert h_p_u_x_virtual_1._module
    assert h_p_u_x_virtual_1._sys_virtualization_paths


# Generated at 2022-06-25 01:17:03.355793
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    list_0 = []
    h_p_u_x_virtual_0 = HPUXVirtual(list_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    # Call the getter method of class HPUXVirtual to get virtual_facts
    #dict_0 = var_0.get_virtual_facts()
    # Verify assertions made by test case
    assert var_0 == {'virtualization_tech_guest': set([]), 'virtualization_tech_host': set([]), 'virtualization_role': ''}


# Generated at 2022-06-25 01:17:06.714788
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    list_0 = []
    h_p_u_x_virtual_0 = HPUXVirtual(list_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    if (var_0 is None):
        raise ValueError("Cannot find virtualization_type.")

    if ((not var_0.has_key('virtualization_type')) or (not var_0.has_key('virtualization_role'))):
        raise ValueError("Extracted virtualization_type are not correct.")


# Generated at 2022-06-25 01:17:14.032147
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    list_0 = []
    h_p_u_x_virtual_0 = HPUXVirtual(list_0)
    assert h_p_u_x_virtual_0._Virtual__module == list_0
    assert h_p_u_x_virtual_0._Virtual__platform == 'HP-UX'
    assert h_p_u_x_virtual_0._Virtual__fact_class == HPUXVirtual
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:17:20.081625
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    list_0 = []
    h_p_u_x_virtual_0 = HPUXVirtual(list_0)
    if not (isinstance(h_p_u_x_virtual_0.get_virtual_facts(), dict)):
        raise (AssertionError)

# Generated at 2022-06-25 01:17:21.401391
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    list_0 = []
    h_p_u_x_virtual_0 = HPUXVirtual(list_0)



# Generated at 2022-06-25 01:17:26.490561
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    list_0 = []
    h_p_u_x_virtual_1 = HPUXVirtual(list_0)
    assert isinstance(h_p_u_x_virtual_1, HPUXVirtual) == True


# Generated at 2022-06-25 01:17:29.245758
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    list_0 = []
    h_p_u_x_virtual_0 = HPUXVirtual(list_0)
    assert h_p_u_x_virtual_0._platform == "HP-UX"
