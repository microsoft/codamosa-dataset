

# Generated at 2022-06-25 01:07:45.084549
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Instantiate an HPUXVirtual() object
    h_p_u_x_virtual_0 = HPUXVirtual()
    # Invoke get_virtual_facts() method of the object
    h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:07:45.821947
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual()


# Generated at 2022-06-25 01:07:53.308572
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    # Test only if hpvm_running. If True, then hpvm_facts() is called.
    h_p_u_x_virtual_0.hpvm_running = True
    # Test only if hppara_running. If True, then hppara_facts() is called.
    h_p_u_x_virtual_0.hppara_running = True
    # Test only if vecheck_running. If True, then vecheck_facts() is called.
    h_p_u_x_virtual_0.vecheck_running = True
    # Test only if hpvm_running. If True, then hpvm_facts() is not called.
    h_p_u_x_virtual_0.hpvm_running = False
    # Test only

# Generated at 2022-06-25 01:07:54.928090
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


if __name__ == '__main__':
    test_case_0()
    test_HPUXVirtual()

# Generated at 2022-06-25 01:08:00.727574
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module_name_0 = 'ansible_test_module'
    module_args_0 = {}
    ansible_module_0 = HPUXVirtual(module_name=module_name_0, module_args=module_args_0)
    virtual_facts = HPUXVirtual.get_virtual_facts(ansible_module_0)
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts

# Generated at 2022-06-25 01:08:03.146910
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual = HPUXVirtual()
    assert h_p_u_x_virtual != None


# Generated at 2022-06-25 01:08:05.252752
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual({'module': FakeModule()})
    assert h_p_u_x_virtual_0 is not None



# Generated at 2022-06-25 01:08:06.944179
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()

# Generated at 2022-06-25 01:08:08.684118
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual({})
    h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:08:09.634899
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()

# Generated at 2022-06-25 01:08:19.295403
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_1 = HPUXVirtual()

if __name__ == '__main__':
    test_case_0()
    test_HPUXVirtual()

# Generated at 2022-06-25 01:08:24.095486
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Create an instance of class HPUXVirtual
    h_p_u_x_virtual = HPUXVirtual(dict())
    # get the virtual facts
    h_p_u_x_virtual_facts = h_p_u_x_virtual.get_virtual_facts()
    assert type(h_p_u_x_virtual_facts) is dict


# Generated at 2022-06-25 01:08:25.295991
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()


# Generated at 2022-06-25 01:08:33.247229
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual()
    h_p_u_x_virtual_0.module = Mock()

    h_p_u_x_virtual_0.module.run_command.side_effect = [(0, "/usr/sbin/parstatus", ""), (0, "/opt/hpvm/bin/hpvminfo", ""), (0, "/usr/sbin/vecheck", "")]

    h_p_u_x_virtual_0.get_virtual_facts()

    h_p_u_x_virtual_0.module.run_command.assert_has_calls([mock.call("/usr/sbin/parstatus"), mock.call("/opt/hpvm/bin/hpvminfo"), mock.call("/usr/sbin/vecheck")])

# Generated at 2022-06-25 01:08:34.812783
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual({})
    h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:08:36.177067
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual(module=None)
    h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:08:44.545873
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h_p_u_x_virtual_0 = HPUXVirtual(dict(module=None, sudoable=False))
    h_p_u_x_virtual_0.module.run_command = (lambda x: (0, 'HP vPar', ''))
    h_p_u_x_virtual_0.module.run_command = (lambda x: (0, 'Running HPVM vPar', ''))
    h_p_u_x_virtual_0.module.run_command = (lambda x: (0, 'Running HPVM guest', ''))
    h_p_u_x_virtual_0.module.run_command = (lambda x: (0, 'Running HPVM host', ''))

# Generated at 2022-06-25 01:08:47.512733
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual()
    if virtual.platform != 'HP-UX':
        print("Error: platform is not set correctly in class HPUXVirtual")


# Generated at 2022-06-25 01:08:48.006914
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-25 01:08:49.896226
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_p_u_x_virtual_0 = HPUXVirtual()
    assert h_p_u_x_virtual_0.platform == 'HP-UX'


# Generated at 2022-06-25 01:09:07.023857
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 2453
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    #var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    #print(var_0)


if __name__ == "__main__":
    #test_HPUXVirtual()
    test_case_0()

# Generated at 2022-06-25 01:09:08.898969
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_a = 2457
    h_p_u_x_virtual_1 = HPUXVirtual(int_a)
    assert h_p_u_x_virtual_1 != None


# Generated at 2022-06-25 01:09:11.852017
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 2453
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


if __name__ == '__main__':
    
    test_case_0()
    test_HPUXVirtual()

# Generated at 2022-06-25 01:09:13.063703
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    input = HPUXVirtual(None)
    assert input != None


# Generated at 2022-06-25 01:09:14.944150
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 2453
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    assert isinstance(h_p_u_x_virtual_0, HPUXVirtual)


# Generated at 2022-06-25 01:09:15.621552
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # Just to silence pylint
    pass

# Generated at 2022-06-25 01:09:21.638436
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 2453
    virtual_1 = HPUXVirtual(int_0)
    assert virtual_1.os is None, 'The attribute "os" of class <HPUXVirtual> is not initialized properly'
    assert virtual_1.module.run_command('/usr/sbin/vecheck')[0] != 0, 'The attribute "os" of class <HPUXVirtual> is not initialized properly'
    assert virtual_1.platform == 'HP-UX', 'The attribute "platform" of class <HPUXVirtual> is not initialized properly'
    assert virtual_1.module.run_command('/opt/hpvm/bin/hpvminfo')[0] != 0, 'The attribute "os" of class <HPUXVirtual> is not initialized properly'

# Generated at 2022-06-25 01:09:25.461188
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 2453
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:09:29.551565
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    int_0 = 2453
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 is not None


# Generated at 2022-06-25 01:09:32.167976
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    int_0 = 2453
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    # var_0 = h_p_u_x_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:09:59.554951
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 2453
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)



# Generated at 2022-06-25 01:10:00.221757
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    test_case_0()


# Generated at 2022-06-25 01:10:02.605176
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    mod_0 = 2453
    h_p_u_x_virtual_0 = HPUXVirtual(mod_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

    assert var_0['virtualization_type'] == 'guest'


# Generated at 2022-06-25 01:10:05.733898
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 2453
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:10:12.648007
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 2453
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    assert h_p_u_x_virtual_0.module.exit_json.call_count == 0
    assert h_p_u_x_virtual_0.module.fail_json.call_count == 0
    h_p_u_x_virtual_0.get_virtual_facts()
    assert h_p_u_x_virtual_0.module.exit_json.call_count == 1
    assert h_p_u_x_virtual_0.module.fail_json.call_count == 0

# Generated at 2022-06-25 01:10:16.921086
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    int_0 = 2453
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    print("%s" % (var_0))


# Generated at 2022-06-25 01:10:18.336437
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 2453
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)

# Generated at 2022-06-25 01:10:19.687865
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 2453
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)

# Generated at 2022-06-25 01:10:21.695617
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    int_0 = 2453
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:10:23.876394
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 2453
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    assert h_p_u_x_virtual_0.module == 2453
    assert h_p_u_x_virtual_0.platform == 'HP-UX'


# Generated at 2022-06-25 01:11:25.924863
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 2453
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    assert h_p_u_x_virtual_0.module == 2453


# Generated at 2022-06-25 01:11:28.018072
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 2453
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    # assert h_p_u_x_virtual_0.get_virtual_facts() == var_0


# Generated at 2022-06-25 01:11:30.328783
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    int_0 = 2453
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:11:32.351282
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    int_0 = 2453
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:11:33.913994
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    int_0 = 2453
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

test_case_0()

# Generated at 2022-06-25 01:11:42.309196
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    int_1 = 2453
    h_p_u_x_virtual_1 = HPUXVirtual(int_1)
    var_1 = h_p_u_x_virtual_1.get_virtual_facts()
    assert var_1['virtualization_type'] == 'guest'
    assert var_1['virtualization_role'] == 'HP nPar'
    assert var_1['virtualization_tech_host'] == set()
    assert var_1['virtualization_tech_guest'] == {'HP nPar'}


# Generated at 2022-06-25 01:11:44.014156
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    int_0 = 2453
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert not var_0



# Generated at 2022-06-25 01:11:45.666471
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import StringIO
    import sys
    backup = sys.stdout
    sys.stdout = StringIO.StringIO()
    try:
        test_case_0()
    finally:
        sys.stdout = backup



# Generated at 2022-06-25 01:11:46.374681
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    test_case_0()

# Generated at 2022-06-25 01:11:52.480121
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 2453
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)

    assert h_p_u_x_virtual_0.module is not None
    assert h_p_u_x_virtual_0.platform == 'HP-UX'
    int_0 = 2453
    h_p_u_x_virtual_1 = HPUXVirtual(int_0)

    assert h_p_u_x_virtual_1.module is not None
    assert h_p_u_x_virtual_1.platform == 'HP-UX'
    int_0 = 2453
    h_p_u_x_virtual_2 = HPUXVirtual(int_0)

    assert h_p_u_x_virtual_2.module is not None
    assert h_p

# Generated at 2022-06-25 01:12:43.144678
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    int_0 = 2453
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    var_1 = h_p_u_x_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:12:48.736894
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    int_0 = 2453
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

# Generated at 2022-06-25 01:12:54.178879
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_1 = 2453
    h_p_u_x_virtual_1 = HPUXVirtual(int_1)
    var_1 = h_p_u_x_virtual_1._platform
    var_2 = h_p_u_x_virtual_1._fact_class
    h_p_u_x_virtual_2 = HPUXVirtual(int_1)
    var_3 = h_p_u_x_virtual_2._platform
    var_4 = h_p_u_x_virtual_2._fact_class


# Generated at 2022-06-25 01:12:57.858306
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 2453
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    assert int_0 == h_p_u_x_virtual_0._module.exit_json.call_count


# Generated at 2022-06-25 01:13:00.819481
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 2972
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    assert h_p_u_x_virtual_0._platform == 'HP-UX'



# Generated at 2022-06-25 01:13:09.119261
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_2 = 149
    h_p_u_x_virtual_2 = HPUXVirtual(int_2)
    # AssertionError: <class 'ansible.module_utils.facts.virtual.hpux.HPUXVirtual'> is not equal to <class 'ansible.module_utils.facts.virtual.base.Virtual'>
    # assert isinstance(h_p_u_x_virtual_2, Virtual), "AssertionError: <class 'ansible.module_utils.facts.virtual.hpux.HPUXVirtual'> is not equal to <class 'ansible.module_utils.facts.virtual.base.Virtual'>"
    int_1 = 6356
    h_p_u_x_virtual_1 = HPUXVirtual(int_1)
    # AssertionError: <class 'ansible.module

# Generated at 2022-06-25 01:13:14.703546
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    int_0 = 2453
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:13:17.674402
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    int_0 = 2453
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    if r'' == r'':
        assert True
    else:
        assert False


# Generated at 2022-06-25 01:13:22.451549
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 2453
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
#AssertionError: h_p_u_x_virtual_0.platform != 'HP-UX'


# Generated at 2022-06-25 01:13:23.992885
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 2453
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)

# Generated at 2022-06-25 01:14:44.000170
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 2453
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)


# Generated at 2022-06-25 01:14:44.600781
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    test_case_0()

# Generated at 2022-06-25 01:14:51.319173
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 2453
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()
    assert h_p_u_x_virtual_0._platform == 'HP-UX'
    assert h_p_u_x_virtual_0._module == int_0


# Generated at 2022-06-25 01:14:53.171449
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    int_0 = 2453
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    var_1 = h_p_u_x_virtual_0.get_virtual_facts()
    assert res_1 == var_1


# Generated at 2022-06-25 01:14:55.702355
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    if not h_p_u_x_virtual_0:
        h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    var_0 = h_p_u_x_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:14:58.504029
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 2453
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    # No assertions in the constructor


# Generated at 2022-06-25 01:15:00.478587
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    int_0 = 2453
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    test_case_0()

# Generated at 2022-06-25 01:15:05.307470
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_3 = 2453
    h_p_u_x_virtual_3 = HPUXVirtual(int_3)
    assert isinstance(h_p_u_x_virtual_3.module, object)


# Generated at 2022-06-25 01:15:05.894003
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_case_0()

# Generated at 2022-06-25 01:15:09.824335
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    int_0 = 1892
    h_p_u_x_virtual_0 = HPUXVirtual(int_0)
    assert h_p_u_x_virtual_0._module.params['gather_subset'] == '!all'
