

# Generated at 2022-06-23 02:13:48.557126
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = VirtualCollector(os.path.realpath(__file__))
    assert type(virtual_collector)==HPUXVirtualCollector

# Generated at 2022-06-23 02:13:51.390811
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    ptr = HPUXVirtual({})
    assert ptr.platform == 'HP-UX'
    assert ptr.get_virtual_facts() == {}


# Generated at 2022-06-23 02:13:57.954640
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = AnsibleModuleMock()
    virtual_facts = HPUXVirtualCollector(module).collect()
    assert virtual_facts['virtualization_type'] == 'host'
    assert virtual_facts['virtualization_role'] == 'HPVM'
    assert virtual_facts['virtualization_tech_host'] == set(['HPVM'])
    assert virtual_facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-23 02:13:58.945288
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual()


# Generated at 2022-06-23 02:14:00.667507
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert isinstance(HPUXVirtualCollector(), HPUXVirtualCollector)

# Generated at 2022-06-23 02:14:10.032175
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import ansible_collector

    module = ansible_collector.get_module()
    hpux_virtual = HPUXVirtual(module)
    result = hpux_virtual.get_virtual_facts()
    assert isinstance(result, dict)
    assert result['virtualization_tech_guest'] == set()
    assert result['virtualization_tech_host'] == set()
    assert result['virtualization_type'] == 'guest'
    assert result['virtualization_role'] == 'HP vPar'

# Generated at 2022-06-23 02:14:13.410579
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    collection = HPUXVirtualCollector(None)
    assert isinstance(collection._fact_class(collection), HPUXVirtual)

# Generated at 2022-06-23 02:14:15.155157
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = HPUXVirtualCollector(dict())
    assert module

# Generated at 2022-06-23 02:14:26.479663
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    hpux_virtual = HPUXVirtual()

    module = DummyModule()
    hpux_virtual.module = module

    # Test when we are not a virtual machine
    module.run_command.return_value = (1, '', '')
    module.os.path.exists.return_value = False
    assert hpux_virtual.get_virtual_facts() == {'virtualization_tech_host': set(),
        'virtualization_tech_guest': set()}

    # Test vecheck
    module.os.path.exists.return_value = True
    module.run_command.return_value = (0, '', '')

# Generated at 2022-06-23 02:14:28.923608
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    if HPUXVirtualCollector.detect():
        HPUXVirtualCollector().collect()

# Generated at 2022-06-23 02:14:31.183634
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector()
    assert collector.platform == 'HP-UX'
    assert collector._fact_class == 'HPUXVirtual'

# Generated at 2022-06-23 02:14:33.352490
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual({})
    assert hpux_virtual


# Generated at 2022-06-23 02:14:35.158763
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    vinfo = HPUXVirtual()
    assert vinfo
    assert vinfo.platform == 'HP-UX'

# Generated at 2022-06-23 02:14:35.721211
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert isinstance(HPUXVirtual(), Virtual)

# Generated at 2022-06-23 02:14:41.025752
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert virtual_collector.platform == 'HP-UX'
    assert virtual_collector.__class__.__name__ == 'HPUXVirtualCollector'


# Generated at 2022-06-23 02:14:49.979719
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Run a virtual facts collection on an HP-UX system
    # This can only be run on a HP-UX system.
    # It is not run automatically as part of the unit tests.
    _module = 'ansible.module_utils.facts.virtual.hpu_ux'
    _hpux_virtual = __import__(_module, '', '', ['ansible.module_utils.facts.virtual.hpu_ux'])

    hpux_virtual = _hpux_virtual.HPUXVirtual(None)
    hpux_virtual_facts = hpux_virtual.get_virtual_facts()
    print(hpux_virtual_facts)
    assert hpux_virtual_facts is not None
    assert hpux_virtual_facts['virtualization_tech_guest'] is not None

# Generated at 2022-06-23 02:14:54.560768
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual({})
    assert v
    assert isinstance(v, HPUXVirtual)
    assert HPUXVirtualCollector._platform == 'HP-UX'


# Generated at 2022-06-23 02:15:05.613596
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import ansible.module_utils.facts.virtual.hpux as hpux_virt
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual

    # Test with a file existing
    mock_module = MockAnsibleModule()
    hpux_virt.os.path.exists = Mock(return_value=True)
    hpux_virt.AnsibleModule = Mock(return_value=mock_module)

    h = HPUXVirtual()
    h.get_virtual_facts()

    assert mock_module.run_command.call_count == 3

# Generated at 2022-06-23 02:15:08.677565
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():

    vc = HPUXVirtualCollector()
    assert isinstance(vc, HPUXVirtualCollector)
    assert vc._fact_class == HPUXVirtual
    assert vc._platform == 'HP-UX'

# Generated at 2022-06-23 02:15:10.238952
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict())
    assert virtual._platform == 'HP-UX'


# Generated at 2022-06-23 02:15:18.504607
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    hpux = HPUXVirtual(module)

    hpux.module.run_command = run_command_mock
    hpux_facts = hpux.get_virtual_facts()

    assert hpux_facts['virtualization_tech_guest'] == set(['HPVM IVM'])
    assert hpux_facts['virtualization_tech_host'] == set()
    assert hpux_facts['virtualization_type'] == 'guest'
    assert hpux_facts['virtualization_role'] == 'HPVM IVM'

# Generated at 2022-06-23 02:15:29.993367
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    if not os.path.exists('/usr/sbin/parstatus'):
        return
    if not os.path.exists('/usr/sbin/vecheck'):
        return
    if not os.path.exists('/opt/hpvm/bin/hpvminfo'):
        return
    class ModuleStub(object):
        def __init__(self, rc=0, out='Running HPVM vPar', err=''):
            self.rc = rc
            self.out = out
            self.err = err
        def run_command(self, cmd):
            return self.rc, self.out, self.err

    hv = HPUXVirtual(ModuleStub())

# Generated at 2022-06-23 02:15:34.439758
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector(None)
    assert virtual_collector
    assert virtual_collector._platform == 'HP-UX'
    assert virtual_collector._fact_class == HPUXVirtual

# Unit tests for class HPUXVirtual

# Generated at 2022-06-23 02:15:41.261421
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    # Constructor of class HPUXVirtualCollector
    # object is created for
    # unit testing purpose
    v = HPUXVirtualCollector()

    # By using __dict__,
    # all the attributes and
    # values of the class
    # object are fetched
    # Here platforms is the
    # attribute of the class
    result = v.__dict__

    # This assert statement
    # checks if the fetched
    # attribute is equal to
    # the given value
    assert result['_platform'] == 'HP-UX'

# Generated at 2022-06-23 02:15:43.699392
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    myTest = HPUXVirtual(None)
    assert myTest.platform == 'HP-UX'


# Generated at 2022-06-23 02:15:48.830206
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual(dict(module=dict()))
    assert virtual_obj.platform == 'HP-UX'
    assert virtual_obj.get_virtual_facts() == {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }


# Generated at 2022-06-23 02:15:50.354770
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv._platform == 'HP-UX'

# Generated at 2022-06-23 02:15:55.637317
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts import cache
    import ansible.module_utils.facts.virtual.hpar as hpar
    hpux_test_obj = hpar.HPUXVirtual(Collector({}, cache=cache.Cache()))
    assert hpux_test_obj._platform == 'HP-UX'
    assert hpux_test_obj._fact_class == hpar.HPUXVirtual


# Generated at 2022-06-23 02:16:06.563062
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    virtual = HPUXVirtual({})
    if os.path.exists('/usr/sbin/vecheck'):
        with open('test/unittests/facts/hpux/vecheck', 'r') as f:
            virtual.module.run_command = lambda x: (0, f.read(), '')

        virtual_facts = virtual.get_virtual_facts()
        assert 'virtualization_type' in virtual_facts
        assert virtual_facts['virtualization_type'] == 'guest'
        assert 'virtualization_role' in virtual_facts
        assert virtual_facts['virtualization_role'] == 'HP vPar'
        assert 'virtualization_tech_guest' in virtual_facts
        assert len(virtual_facts['virtualization_tech_guest']) == 1

# Generated at 2022-06-23 02:16:09.132992
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(module=None)
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-23 02:16:18.809580
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import unittest
    import os

    class MockModule(object):
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    def os_path_exists_patch(path):
        if path == '/usr/sbin/vecheck':
            return True
        elif path == '/opt/hpvm/bin/hpvminfo':
            return True
        elif path == '/usr/sbin/parstatus':
            return True

    class MockOsPath(object):
        exists = os_path_exists_patch

    class MockOs(object):
        path = MockOs

# Generated at 2022-06-23 02:16:29.081147
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Test Virtual.get_virtual_facts method
    """

    class ModuleStub(object):
        def run_command(self, args):
            out = ''
            if 'hpvminfo' in args:
                out += '''Running HPVM guest\n
                vPars on this host: 35\n
                Running vPars: 35\n
                Total vCPUs in running vPars: 728\n
                CPUs available for virtualization: 140\n
                Logical CPU support: Yes\n
                Total logical CPUs: 140\n
                Total memory: 122880 MB\n
                Total memory available for virtualization: 122880 MB\n
                Total disk available for virtualization: 22640233 MB\n
                '''
                rc = 0

# Generated at 2022-06-23 02:16:39.862387
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Test get_virtual_facts method with values based on test_HPVM_Virtual_get_virtual_facts
    """
    from ansible.module_utils.facts.virtual import HPUXVirtual
    hx = HPUXVirtual(dict(module=None))

    hx.module.run_command = lambda x: (0, '', '')
    assert hx.get_virtual_facts() == \
        {'virtualization_type': 'host',
         'virtualization_role': 'HPVM',
         'virtualization_tech_guest': set(['HPVM']),
         'virtualization_tech_host': set()}

    hx.module.run_command = lambda x: (0, 'test output,Running virtual machine,foo', '')

# Generated at 2022-06-23 02:16:42.012551
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual({})
    assert h is not None


# Generated at 2022-06-23 02:16:46.113135
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict(module=dict()))
    assert virtual_facts._platform == 'HP-UX'
    assert virtual_facts._fact_class.platform == 'HP-UX'
    assert virtual_facts.get_virtual_facts() == {}

# Generated at 2022-06-23 02:16:47.182407
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual()

# Generated at 2022-06-23 02:16:56.988228
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpar import HPUXVirtual, Virtual, VirtualCollector
    class TestVirtual(Virtual):
        platform = 'Linux'
        def get_virtual_facts(self):
            return {
                'virtualization_type': 'guest',
                'virtualization_role': 'HP vPar'
            }
    class TestVirtualCollector(VirtualCollector):
        _fact_class = TestVirtual
        _platform = 'Linux'
    class TestModule(object):
        def run_command(self):
            return (0, '', '')
    module = TestModule()
    virtual = TestVirtual(module)
    virtual_collector = TestVirtualCollector(module)
    virtual_collector.populate()

# Generated at 2022-06-23 02:17:05.072871
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    '''
    This unit test tests whether the HPUXVirtualCollector class is constructed
    properly.
    '''
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    hv = HPUXVirtualCollector()
    assert isinstance(hv, VirtualCollector)
    assert hv._platform == "HP-UX"
    assert hv._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:17:15.602200
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    ''' Test get_virtual_facts function of class Virtual '''
    from ansible.module_utils.facts.virtual.hpuxto import HPUXVirtual
    from ansible.module_utils import basic
    import ansible.module_utils.facts.virtual.base
    m = basic.AnsibleModule(argument_spec={})
    m.run_command = ansible.module_utils.facts.virtual.base.run_command
    hv = HPUXVirtual(m)

    # create mocked function
    def mocked_os_path_exists(path):
        if path == '/usr/sbin/vecheck':
            return True
        return False

    def mocked_os_access(path, mode):
        if path == '/usr/sbin/vecheck':
            return True
        return False


# Generated at 2022-06-23 02:17:28.495778
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import HPUXVirtual
    from ansible.module_utils.facts import Module
    from ansible.module_utils.facts.virtual import BaseVirtual
    from ansible.module_utils.facts.virtual import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector

    # Set up a bare bones class to mimic a module object
    module = Module()
    module.run_command = HPUXVirtual.run_command

    # Test get_virtual_facts on a regular HP-UX platform.
    # We fake that we are a guest and defer to VirtualCollector to
    # test the regular platform case.
    BaseVirtual.on_hpux = True
    BaseVirtual.on_guest = True
    base_virtual = BaseVirtual(module)


# Generated at 2022-06-23 02:17:41.886382
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # First we set up the values that would be returned by the mock
    class MockShell:
        def __init__(self, mock_values):
            self._mock_values = mock_values
            self._mock_index = 0
        def run_command(self, command):
            rc, out, err = self._mock_values[self._mock_index]
            self._mock_index += 1
            return rc, out, err
    mock_shell = MockShell([(0,'Virtualization Software - HP vPars',''),
                            (0,'Virtualization Software - HPVM',''),
                            (0,'Virtualization Software - HP nPars','')])

    # Then we set up a virtual class to be tested
    from ansible.module_utils.facts.virtual import HPUXVirtual
    virtual = H

# Generated at 2022-06-23 02:17:49.643165
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # Create an instance of class HPUXVirtual
    h_virtual = HPUXVirtual()
    # Verify virtualization_type
    h_virtual_type = h_virtual.get_virtual_facts()['virtualization_type']
    assert h_virtual_type in ('host', 'guest', None)
    # Verify virtualization_role
    h_virtual_role = h_virtual.get_virtual_facts()['virtualization_role']
    assert h_virtual_role in ('HP vPar', 'HPVM vPar', 'HPVM IVM', 'HPVM', 'HP nPar', None)

# Generated at 2022-06-23 02:17:57.900412
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    facts = {}
    fake_module = type('obj', (object,), {})()
    collector = HPUXVirtualCollector(fake_module, facts, None)
    assert isinstance(collector, HPUXVirtualCollector)
    assert isinstance(collector.platform, str)
    assert isinstance(collector.facts, dict)
    assert isinstance(collector.data, dict)
    assert isinstance(collector._fact_class, type)
    assert collector._fact_class.platform == 'HP-UX'

# Generated at 2022-06-23 02:17:59.375155
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-23 02:18:06.712756
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    hpx = HPUXVirtual(None)
    hpx._module.run_command = lambda x: (0, 'Running HPVM guest', '')
    hpx._module.get_bin_path = lambda x: '/opt/hpvm/bin/' + x
    hpxfacts = hpx.get_virtual_facts()
    assert hpxfacts['virtualization_type'] == 'guest'
    assert hpxfacts['virtualization_role'] == 'HPVM IVM'
    assert hpxfacts['virtualization_tech_host'] == set()
    assert hpxfacts['virtualization_tech_guest'] == set(['HPVM'])


# Generated at 2022-06-23 02:18:13.206270
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    '''
    Test HPUXVirtualCollector constructor.
    '''
    test_dict = {'virtualization_type': 'guest', 'virtualization_role': 'HPVM IVM',
                 'virtualization_tech_guest': {'HPVM IVM'}, 'virtualization_tech_host': set()}

    assert HPUXVirtualCollector().collect() == test_dict

# Generated at 2022-06-23 02:18:16.159450
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual({})
    assert v.platform == 'HP-UX'
    assert v.virtual_subtype == 'guest'
    assert v._dist_version == ''


# Generated at 2022-06-23 02:18:28.740260
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    v = HPUXVirtual()

    v.module.run_command = MagicMock()
    v.module.run_command.return_value = (0, 'HPVM IVM', '')
    assert v.get_virtual_facts() == {'virtualization_type': 'guest', 'virtualization_role': 'HPVM IVM', 'virtualization_tech_host': set([]), 'virtualization_tech_guest': set(['HPVM IVM'])}
    v.module.run_command.return_value = (0, 'HPVM host', '')
    assert v.get_virtual_facts() == {'virtualization_type': 'host', 'virtualization_role': 'HPVM', 'virtualization_tech_host': set(['HPVM']), 'virtualization_tech_guest': set([])}
   

# Generated at 2022-06-23 02:18:43.395977
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    import mock
    import os

    module = mock.Mock()
    # Running HPVM
    module.run_command.return_value = (0, 'Running HPVM vPar', '')
    os.path.exists.return_value = True
    hv = HPUXVirtual(module)
    virtual_facts = hv.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HPVM vPar'
    assert 'HPVM IVM' in virtual_facts['virtualization_tech_guest']
    assert 'HPVM' in virtual_facts['virtualization_tech_guest']
    assert 'HPVM vPar' in virtual_facts

# Generated at 2022-06-23 02:18:45.501497
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-23 02:18:56.346046
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpu_x import HPUXVirtual
    from ansible.module_utils.facts.virtual import VirtualCollector

    test_module = VirtualCollector()
    test_module._platform_name = 'HP-UX'
    test_object = HPUXVirtual(test_module)

    test_object.module.run_command = lambda x: (0, "", "")
    test_object._hpu_x_get_virtual_facts = lambda: {}

    test_object.get_virtual_facts()

    expected_output = {'virtualization_tech_guest': set(), 'virtualization_tech_host': set(),
                       'virtualization_type': 'guest', 'virtualization_role': 'HP vPar'}


# Generated at 2022-06-23 02:19:05.342029
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    hv = HPUXVirtual(None)
    if hv.collector.running_in_container:
        # If we're running inside a container, the tests don't have to be run
        return
    facts = hv.get_virtual_facts()
    assert(facts['virtualization_type'] is not None)
    assert(facts['virtualization_role'] is not None)

# Generated at 2022-06-23 02:19:16.895052
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Test for method get_virtual_facts of class HPUXVirtual
    """
    test_module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['all'], type='list'),
        ),
        supports_check_mode=True)
    test_class = HPUXVirtual(test_module)
    result = test_class.get_virtual_facts()
    assert result['virtualization_type'] == 'guest'
    assert result['virtualization_role'] == 'HP nPar'

# Generated at 2022-06-23 02:19:27.389542
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.virtual import hpux

    # Create a test fixture
    module = basic.AnsibleModule(
        argument_spec = dict()
    )

    # Mock the module
    vm = hpux.HPUXVirtual(module)

    # Create a test class instance
    test_inst = HPUXVirtualCollector(module)

    # Check get_virtual_facts
    # test fixture is not a host
    assert test_inst.get_virtual_facts(vm) == {}
    # test fixture is a guest (vpar)
    test_inst.check_guest = lambda x: True
    assert test_inst.get_virtual_facts(vm)['virtualization_type'] == 'guest'

# Generated at 2022-06-23 02:19:37.827773
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class ModuleStub(object):
        def __init__(self):
            self.params = dict()
            self.exit_json = dict()
            self.run_command_calls = list()

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)

    class FactsStub():
        def __init__(self):
            pass

        def __getitem__(self, key):
            return 'HP-UX'

    module = ModuleStub()
    facts = {'system_vendor': FactsStub()}
    obj = HPUXVirtual(module=module, facts=facts)

    # Case 1: vecheck exists, hpvminfo exists, parstatus exists
    open('/usr/sbin/vecheck', 'a').close()

# Generated at 2022-06-23 02:19:43.546793
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    obj_HPUXVirtual = HPUXVirtual(module)
    virtual_facts = obj_HPUXVirtual.get_virtual_facts()
    assert virtual_facts.get('virtualization_role') == 'HPVM'
    assert 'HPVM' in virtual_facts.get('virtualization_tech_guest')
    assert 'HP' in virtual_facts.get('virtualization_type')


# Generated at 2022-06-23 02:19:45.848977
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert x
    assert x._platform == 'HP-UX'


# Generated at 2022-06-23 02:19:57.677045
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )
    result = dict(
        ansible_facts=dict(
            ansible_virtualization_type='',
            ansible_virtualization_role='',
            ansible_virtualization_tech_guest=set(),
            ansible_virtualization_tech_host=set())
    )
    hpux_virtual = HPUXVirtual(module)

    facts = hpux_virtual.get_virtual_facts()
    result['ansible_facts']['ansible_virtualization_type'] = facts['virtualization_type']
    result['ansible_facts']['ansible_virtualization_role'] = facts['virtualization_role']

# Generated at 2022-06-23 02:20:06.584294
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import virtual
    from ansible.module_utils.facts.cache import Cache
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual

    module = AnsibleModuleMock()
    cache = Cache(module, 'ansible_facts')
    BaseFactCollector._cache = cache
    fake_module = virtual.Virtual(module=module)
    hpux_virtual = HPUXVirtual(fake_module)

    module.run_command = MagicMock(return_value=(0, '', ''))
    facts = hpux_virtual.get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP vPar'

# Generated at 2022-06-23 02:20:07.135247
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual()

# Generated at 2022-06-23 02:20:12.108179
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock()
    module.run_command.return_value = (0,'','')
    virtual_collector = HPUXVirtual(module=module)

    results = virtual_collector.get_virtual_facts()
    assert results['virtualization_type'] == 'host'
    assert results['virtualization_role'] == 'HPVM'
    assert results['virtualization_tech_host'] == set(['HPVM'])
    assert results['virtualization_tech_guest'] == set()

# Generated at 2022-06-23 02:20:16.510285
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """
    This is a unit test for HPUXVirtualCollector class. It tests if the constructor
    is working as expected
    """
    hv = HPUXVirtualCollector()
    assert hv.platform == 'HP-UX'
    assert hv._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:20:21.736650
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpuxVirtualCollector = HPUXVirtualCollector()
    assert hpuxVirtualCollector._fact_class == HPUXVirtual
    assert hpuxVirtualCollector._platform == 'HP-UX'


if __name__ == '__main__':
    test_HPUXVirtualCollector()

# Generated at 2022-06-23 02:20:24.007461
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual()
    assert virtual_obj._platform == 'HP-UX'



# Generated at 2022-06-23 02:20:31.588283
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    virtual_facts_obj = HPUXVirtual()
    virtual_facts = virtual_facts_obj.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP nPar'
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_tech_guest'] == {'HP vPar', 'HP nPar'}

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-23 02:20:33.795783
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert isinstance(HPUXVirtualCollector(), VirtualCollector)

# Unit tests for methods of class HPUXVirtualCollector

# Generated at 2022-06-23 02:20:36.260762
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert x._fact_class._platform == 'HP-UX'

# Generated at 2022-06-23 02:20:40.670810
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(_module=None)
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-23 02:20:43.443844
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
     h = HPUXVirtualCollector()
     assert h.platform == "HP-UX"

# Generated at 2022-06-23 02:20:44.856155
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({}, {}, {})
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-23 02:20:56.187459
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible_collections.ansible.community.tests.unit.compat.mock import Mock, patch
    from ansible_collections.ansible.community.plugins.module_utils.facts.virtual.hpx import HPUXVirtual
    get_virtual_facts_patch = patch.object(HPUXVirtual, 'get_virtual_facts')
    module = Mock()
    virtual_facts = copy.deepcopy(HPUX_FACTS)
    get_virtual_facts_patch.start().return_value = virtual_facts
    fact_class_obj = HPUXVirtual()
    fact_class_obj.module = module
    returned_facts = fact_class_obj.get_virtual_facts()
    assert returned_facts == virtual_facts
    get_virtual_facts_patch.stop()

# Generated at 2022-06-23 02:20:58.807429
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-23 02:21:10.114482
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Test values
    my_class = HPUXVirtual()
    my_class.module = MockModule()
    my_class.module.run_command.return_value = [0, '', '']
    virtual_facts = my_class.get_virtual_facts()

    assert my_class.platform == 'HP-UX'
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    assert 'HP vPar' in virtual_facts['virtualization_tech_guest']
    assert 'HP nPar' in virtual_facts['virtualization_tech_guest']
    assert 'HPVM vPar' in virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-23 02:21:20.421268
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import ModuleStub
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual import BaseVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector

    # Create a mock module
    module = ModuleStub()

    # create an instance of HPUXVirtual and invoke its get_virtual_facts()
    hpux_virtual = HPUXVirtual(module)
    facts = hpux_virtual.get_virtual_facts()

    # Confirm expected keys are present
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts

    #

# Generated at 2022-06-23 02:21:21.710722
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual({}).platform == 'HP-UX'  # Construct an instance of HPUXVirtual


# Generated at 2022-06-23 02:21:25.038623
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(MockModule())
    virtual = HPVirtual(module)
    virtual_facts_expected = {
        'virtualization_type': 'guest',
        'virtualization_role': 'HP vPar',
        'virtualization_tech_guest': {'HP vPar'},
        'virtualization_tech_host': set()
        }
    virtual_facts = virtual.get_virtual_facts()
    assert(virtual_facts_expected == virtual_facts)



# Generated at 2022-06-23 02:21:28.788425
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    for item in ('virtualization_tech_host', 'virtualization_tech_guest', 'virtualization_type', 'virtualization_role'):
        assert item in virtual_facts.data.keys()

# Generated at 2022-06-23 02:21:33.226468
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """Unit test for constructor of HPUXVirtualCollector"""
    hpx_virtual_obj = HPUXVirtualCollector()
    assert hpx_virtual_obj.platform == 'HP-UX', 'Failed to set platform'
    assert hpx_virtual_obj.fact_class == HPUXVirtual, 'Failed to set fact_class'

# Generated at 2022-06-23 02:21:36.298262
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = AnsibleModuleMock()
    hv = HPUXVirtual(module)
    assert hv.platform is 'HP-UX'
    assert hv.module is module


# Generated at 2022-06-23 02:21:41.832390
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict())
    if virtual.__class__.__name__ != 'HPUXVirtual' or \
       virtual.platform != 'HP-UX':
        print("[ERR] Fail to instantiate class.")
        sys.exit(1)
    else:
        print("[OK] instantiated class.")


# Generated at 2022-06-23 02:21:43.944105
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual({}, {})
    assert h.platform == 'HP-UX'



# Generated at 2022-06-23 02:21:49.346848
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpuxVirtual = HPUXVirtual(dict(module=dict()))
    assert hpuxVirtual.virtualization_role == ''
    assert hpuxVirtual.virtualization_type == 'unknown'
    assert hpuxVirtual.virtualization_tech_guest == set()
    assert hpuxVirtual.virtualization_tech_host == set()


# Generated at 2022-06-23 02:21:51.615925
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = AnsibleModuleMock(params={})
    virtual_obj = HPUXVirtual(module)
    assert virtual_obj



# Generated at 2022-06-23 02:21:54.620659
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert issubclass(HPUXVirtualCollector, VirtualCollector)
    assert HPUXVirtualCollector._platform == 'HP-UX'
    assert HPUXVirtualCollector._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:22:05.135789
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class MockModule(object):
        def __init__(self):
            self.run_command = Mock()

    class MockFacts(object):
        def __init__(self):
            self.module = MockModule()

    host = HPUXVirtual(MockFacts())
    # If a file exists, rc == 0 and output matches.
    for file, rc, out in (('/usr/sbin/vecheck', 0, '.*Running.*'),
                          ('/opt/hpvm/bin/hpvminfo', 0, '.*Running.*')):
        with open(__file__) as ff:
            with open(file, 'w') as f:
                f.write(ff.read())
        host.module.run_command.return_value = rc, out, ''
        virtual_facts = host.get_virtual

# Generated at 2022-06-23 02:22:07.832476
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vc = HPUXVirtualCollector()
    assert vc._fact_class == HPUXVirtual
    assert vc._platform == 'HP-UX'


# Generated at 2022-06-23 02:22:10.498265
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual(dict(module=dict()))
    assert virtual_obj.platform == 'HP-UX'


# Generated at 2022-06-23 02:22:13.368592
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv.platform == 'HP-UX'
    assert hv.fact_class._platform == 'HP-UX'

# Generated at 2022-06-23 02:22:14.836442
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector._platform == 'HP-UX'

# Generated at 2022-06-23 02:22:22.389898
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    virt_module = HPUXVirtual({})
    virt_module.module = {'run_command': run_command_stub}
    expected_facts = {
        'virtualization_type': 'guest',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': {'HP vPar', 'HPVM vPar', 'HPVM IVM', 'HP nPar'},
        'virtualization_role': 'HPVM IVM'
    }
    actual_facts = virt_module.get_virtual_facts()
    assert expected_facts == actual_facts



# Generated at 2022-06-23 02:22:24.389479
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert virtual_collector.platform == 'HP-UX'



# Generated at 2022-06-23 02:22:27.225803
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    test_HPUXVirtual = HPUXVirtual()
    assert test_HPUXVirtual.platform =='HP-UX'

# Generated at 2022-06-23 02:22:31.769150
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    assert obj.platform == 'HP-UX', "platform property should be equal to 'HP-UX'"
    assert obj._fact_class == HPUXVirtual, "_fact_class property should be equal to HPUXVirtual"
    assert obj._platform == 'HP-UX', "_platform property should be equal to 'HP-UX'"

# Generated at 2022-06-23 02:22:34.321891
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    Constructor of class HPUXVirtual
    """
    hv = HPUXVirtual({})
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-23 02:22:35.627393
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual(dict())
    assert h.platform == 'HP-UX'

# Generated at 2022-06-23 02:22:36.841228
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    h = HPUXVirtualCollector()
    assert h.platform == 'HP-UX'

# Generated at 2022-06-23 02:22:40.373741
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    from ansible.module_utils.facts.virtual.hpu import HPUXVirtual
    hpux_virtual = HPUXVirtual(dict(), dict())
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-23 02:22:43.889635
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vc = HPUXVirtualCollector()
    assert vc.platform == 'HP-UX'
    assert vc._fact_class._platform == 'HP-UX'




# Generated at 2022-06-23 02:22:44.952120
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-23 02:22:46.357115
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt = HPUXVirtual()
    assert virt.platform == 'HP-UX'



# Generated at 2022-06-23 02:22:53.460332
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Arrange
    class_under_test = HPUXVirtual()
    class_under_test.module = MockModule()
    class_under_test.module.run_command.return_value = (0, '', '')

    # Act
    result = class_under_test.get_virtual_facts()

    # Assert
    assert result.get('virtualization_type') == 'guest'
    assert result.get('virtualization_role') == 'HP vPar'


# Generated at 2022-06-23 02:23:03.665586
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    # vecheck available, not in a vPar
    import ansible.module_utils.facts.virtual as virtual_mod
    import ansible.module_utils.facts.virtual.hpux as hpux_mod
    from ansible.module_utils.facts.virtual.base import VirtualCollector

    virtual_mod.Command = VirtualCommandMock
    hpux_mod.VirtualCollector = VirtualCollector

    host = hpux_mod.HPUXVirtual()
    host.module = VirtualModuleMock()

    host.module.run_command = run_command_mock
    host.module.run_command.return_value = (0,'whatever','')

    facts = host.get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP vPar'

# Generated at 2022-06-23 02:23:15.448708
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    global module
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    hpux_virtual = HPUXVirtual(module)
    module.params = {'kernel': 'hpux'}
    virtual_facts = hpux_virtual.get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

    assert 'HPVM' in virtual_facts['virtualization_tech_host']
    assert 'HPVM vPar' in virtual_facts['virtualization_tech_guest']
    assert 'HPVM IVM' in virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-23 02:23:27.072597
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    v = HPUXVirtual()
    v.module = mock_ansible_module(
        params=dict(),
        check_mode=False
    )
    v.module.run_command.side_effect = [
        (0, "Running on HPVM vPar", ""),
        (0, "Running on HPVM host", ""),
        (0, "Running on HPVM vPar", ""),
        (0, "Running on HPVM guest", ""),
        (0, "Running on HPVM vPar", "")]
    virtual_facts = v.get_virtual_facts()
    assert virtual_facts['virtualization_role'] == 'HPVM vPar'
    assert virtual_facts['virtualization_type'] == 'host'
    assert 'HPVM vPar' in virtual_facts['virtualization_tech_guest']
   

# Generated at 2022-06-23 02:23:34.107160
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    m_ansible_module = mock.MagicMock()
    m_ansible_module.params = {}
    m_ansible_module.get_bin_path.side_effect = lambda x, required=None: x
    result = HPUXVirtualCollector(m_ansible_module)
    assert result._platform == 'HP-UX'
    assert result._fact_class.platform == 'HP-UX'
    assert result._fact_class.virtualization_type is None


# Generated at 2022-06-23 02:23:40.709572
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible_collections.ansible.community.tests.unit.module_utils.facts.virtual.posix.test_posix import MockModule

    module = MockModule()
    hpvx_virtual_facts = HPUXVirtual(module)

    if os.path.exists('/opt/hpvm/bin/hpvminfo') and os.path.exists('/usr/sbin/parstatus'):
        hpvx_virtual_facts._executable_exists['/opt/hpvm/bin/hpvminfo'] = True
        hpvx_virtual_facts._executable_exists['/usr/sbin/parstatus'] = True
        hpvx_virtual_facts._executable_exists['/usr/sbin/vecheck'] = False

# Generated at 2022-06-23 02:23:45.020532
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = MockAnsibleModule(
        dict(
            virtualization_type=None,
            virtualization_role=None
        )
    )

    hv = HPUXVirtual(module)

    hv.get_virtual_facts()
    assert module.params == dict(
        virtualization_type='guest',
        virtualization_role='HP nPar'
    )