

# Generated at 2022-06-23 02:13:44.395229
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = AnsibleModule(argument_spec=dict())
    hpux_virtual_obj = HPUXVirtual(module)

    assert hpux_virtual_obj
    assert hpux_virtual_obj.platform == 'HP-UX'



# Generated at 2022-06-23 02:13:47.033519
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    '''
    Validate that HPUXVirtual can be created.
    '''
    virtual = HPUXVirtual()
    assert virtual is not None


# Generated at 2022-06-23 02:13:54.008783
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Initialize a dictionary to hold the results of
    # get_virtual_facts method
    get_virtual_facts_dict = {}

    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_result = {}

        def run_command(self, *args, **kwargs):
            if args[0] == '/usr/sbin/vecheck':
                return (0,
                        '  HP-UX virtual partitions\n' +
                        '     Status : Running\n' +
                        '  Virtual product version : B.11.23\n' +
                        '      Virtual OS version : B.11.23.09\n' +
                        '   HP-UX p-Class vPars : 0\n',
                        '')

# Generated at 2022-06-23 02:14:06.368451
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import mock
    class MockModule(object):
        def __init__(self):
            self.params = {}
        def run_command(self, command):
            if command == '/usr/sbin/vecheck':
                return (0, '', '')
            if command == '/opt/hpvm/bin/hpvminfo':
                return (0, 'Running HPVM host', '')
            if command == '/usr/sbin/parstatus':
                return (0, '', '')
            return (1, '', '')
    mock_module = MockModule()
    virtual_facts = HPUXVirtual(mock_module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'host'
    assert virtual_facts['virtualization_role'] == 'HPVM'

# Generated at 2022-06-23 02:14:18.107832
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector

    hpux_virtual_obj = HPUXVirtual()
    hpux_virtual_collector_obj = VirtualCollector()

    hpux_virtual_obj.module = HPUXVirtualCollector._mock_module_helper("HP-UX")

    hpux_virtual_obj.module.run_command = HPUXVirtualCollector._mock_module_helper(
        0, '''Running HPVM VPAR
Running HPVM guest
''', '', '')
    guest_facts = hpux_virtual_obj.get_virtual_facts()
    assert guest

# Generated at 2022-06-23 02:14:20.851841
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector._platform == 'HP-UX'
    assert HPUXVirtualCollector._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:14:22.065547
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual()
    assert v.platform == 'HP-UX'
    assert not v.virtualization_type
    assert not v.virtualization_role


# Generated at 2022-06-23 02:14:24.095190
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_hpux = HPUXVirtual()
    assert virtual_hpux.virtualization_type is None
    assert virtual_hpux.virtualization_role is None



# Generated at 2022-06-23 02:14:31.386883
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    fake_module = object()

    collector = HPUXVirtualCollector(fake_module, '/path/to/file')

    assert(isinstance(collector, HPUXVirtualCollector))

    assert(isinstance(collector.fact, HPUXVirtual))
    assert(collector.fact.module == fake_module)
    assert(collector.fact.virtual_facts_file == '/path/to/file')
    assert(collector.platform == 'HP-UX')

# Generated at 2022-06-23 02:14:39.806891
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class HPUXVirtual
    """
    class ModuleStub():
        def run_command(self, cmd):
            return 0, '', ''

    class HPUXVirtualStub(HPUXVirtual):
        def __init__(self):
            self.module = ModuleStub()

    virtual = HPUXVirtualStub()
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] is None
    assert virtual_facts['virtualization_role'] is None
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-23 02:14:44.013588
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """
    Unit test for constructor of class HPUXVirtualCollector
    """
    obj = HPUXVirtualCollector()
    assert obj._fact_class == HPUXVirtual
    assert obj._platform == 'HP-UX'

# Generated at 2022-06-23 02:14:50.645378
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual

    # Test Virtualization facts gathering
    virtual = HPUXVirtual({})
    virtual_facts = virtual.get_virtual_facts()
    # Virtual facts dictionary
    # {'virtualization_role': 'HP vPar', 'virtualization_tech_host': set(),
    #   'virtualization_tech_guest': set(['HP vPar']), 'virtualization_type': 'guest'}
    assert virtual_facts == {'virtualization_role': 'HP vPar', 'virtualization_tech_guest': ['HP vPar'],
                             'virtualization_tech_host': [], 'virtualization_type': 'guest'}

# Generated at 2022-06-23 02:14:54.011453
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    h = HPUXVirtualCollector()
    assert h._fact_class == HPUXVirtual
    assert h._platform == 'HP-UX'

# Generated at 2022-06-23 02:14:56.231879
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual({})
    assert virtual.platform == 'HP-UX'
    assert virtual.get_virtual_facts() == {}



# Generated at 2022-06-23 02:15:07.294343
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    mock_module = MockModule({})
    mock_module.run_command = Mock(return_value=(0, '', ''))

    mock_module.run_command.side_effect = [
        (0, '', ''),
        (0, 'Running HPVM vPar', ''),
        (0, 'Running HPVM guest', ''),
        (0, 'Running HPVM host', '')
    ]

    hpux = HPUXVirtual(mock_module)

    # No virtualization technology is running
    assert hpux.get_virtual_facts() == {'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}
    # hpvminfo shows that HPVM vPar is running

# Generated at 2022-06-23 02:15:09.532158
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(dict(module=dict()))
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-23 02:15:13.517628
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector(None)
    assert isinstance(x, HPUXVirtualCollector)
    assert x.platform == 'HP-UX'
    assert x._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:15:16.999076
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec={},
    )
    if module._name == '__main__':
        module.exit_json(changed=False, ansible_facts=dict(HPUXVirtual().get_virtual_facts()))


# Generated at 2022-06-23 02:15:18.701671
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    obj = HPUXVirtual()
    assert obj.platform == 'HP-UX'


# Generated at 2022-06-23 02:15:21.659814
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpx = HPUXVirtual({})
    assert hpx is not None

if __name__ == '__main__':
    test_HPUXVirtual()

# Generated at 2022-06-23 02:15:23.917130
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpux = HPUXVirtualCollector()
    assert hpux._fact_class == HPUXVirtual
    assert hpux._platform == 'HP-UX'

# Generated at 2022-06-23 02:15:25.810458
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtualCollector=HPUXVirtualCollector()
    assert virtualCollector._platform == 'HP-UX'

# Generated at 2022-06-23 02:15:30.080640
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual({'module': None})
    assert virtual_obj.platform == 'HP-UX'
    assert virtual_obj.virtual_collector_class == HPUXVirtualCollector
    assert not virtual_obj.get_virtual_facts()

# Generated at 2022-06-23 02:15:32.010404
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts._platform == 'HP-UX'

# Generated at 2022-06-23 02:15:34.389376
# Unit test for constructor of class HPUXVirtualCollector

# Generated at 2022-06-23 02:15:44.794737
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector

    # Case 1: virtualization_type and virtualization_role:
    #         When '/usr/sbin/vecheck' exists and returns 'HP vPar'
    module = type('module', (object,), {'run_command': lambda self, x: (0, 'HP vPar', None)})()
    fact_class = HPUXVirtual(module)
    facts = fact_class.get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP vPar'
    assert facts['virtualization_tech_guest'] == set(['HP vPar'])

    #

# Generated at 2022-06-23 02:15:47.774501
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux = HPUXVirtual(None)
    assert hpux.platform == 'HP-UX'
    assert hpux.has_cmd() is False
    assert hpux.has_file() is False


# Generated at 2022-06-23 02:15:49.581262
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(dict())
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-23 02:15:54.752519
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """
    This is a unit test for constructor of class HPUXVirtualCollector
    """
    # Constructor test
    facts = { 'virtualization_type': 'guest', 'virtualization_role': 'HPVM vPar' }
    virtual = HPUXVirtualCollector(facts)
    assert virtual.facts == facts
    assert virtual.platform == 'HP-UX'
    assert virtual.fact_class is HPUXVirtual

# Generated at 2022-06-23 02:15:58.247174
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector()
    assert isinstance(collector, VirtualCollector)
    assert collector._platform == 'HP-UX'
    assert collector._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:15:59.698686
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = HPUXVirtual()
    assert module.platform == 'HP-UX'

# Generated at 2022-06-23 02:16:03.271227
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert hasattr(HPUXVirtualCollector, '_platform')
    assert hasattr(HPUXVirtualCollector, '_fact_class')
    assert HPUXVirtualCollector._platform == 'HP-UX'
    assert HPUXVirtualCollector._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:16:10.060386
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    result = HPUXVirtual().get_virtual_facts()
    assert result['virtualization_type'] == 'guest'
    assert result['virtualization_role'] == 'HP vPar'
    assert result['virtualization_tech_guest'] == set(['HP vPar'])
    assert result['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:16:16.231315
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpar import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpvm import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual

    #  Test HPUX virtual facts system
    virtual_facts_system = {'virtualization_type': 'host',
                            'virtualization_role': 'HPVM',
                            'virtualization_tech_host': {'HPVM'},
                            'virtualization_tech_guest': set()
                            }

    #  Test HPUX virtual facts system

# Generated at 2022-06-23 02:16:26.954928
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Make a simple module for testing
    from ansible.module_utils import basic
    module = basic.AnsibleModule(argument_spec={}, supports_check_mode=True)
    # Make an instance of the HPUXVirtual class
    virtual_facts = HPUXVirtual(module=module)

    # Test the get_virtual_facts method on a HP-UX vPar guest
    facts = {}
    # Create a file that looks like a HP-UX vPar guest
    with open('/usr/sbin/vecheck', 'w') as f:
        f.write('')
    virtual_facts.get_virtual_facts()
    virtual_facts.populate_facts(facts, 'virtual_facts')
    assert facts['virtual_facts']['virtualization_type'] == 'guest'

# Generated at 2022-06-23 02:16:38.572183
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # create a instance of HPUXVirtual with module_mock
    fake_module = FakeAnsibleModule()

    # check for /usr/sbin/vecheck
    mock_vecheck = '/usr/sbin/vecheck'
    mock_vecheck_rc = 0
    mock_vecheck_out = 'Running in HP vPar'
    mock_vecheck_err = ''
    HPUXVirtual.module_mock.run_command.register_mock_command(mock_vecheck, mock_vecheck_rc, mock_vecheck_out, mock_vecheck_err)

    # check for /opt/hpvm/bin/hpvminfo
    mock_hpvminfo = '/opt/hpvm/bin/hpvminfo'
    mock_hpvminfo_rc = 0
    mock_hpv

# Generated at 2022-06-23 02:16:48.586123
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Test cases for testing method get_virtual_facts of class HPUXVirtual
    """
    from ansible.module_utils.facts.virtual.hpux_virtual import HPUXVirtual
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.six import PY2
    from ansible.module_utils._text import to_bytes

    class FakeModule(object):
        def __init__(self, name, home):
            self.name = name
            self.home = home

        def run_command(self, *cmd):
            if cmd[0] == ("/usr/sbin/vecheck") and self.name == "parmgr" and \
                    self.home == "yes":
                return (0, "", "")

# Generated at 2022-06-23 02:16:49.914757
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-23 02:16:58.068465
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import mock
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    h = HPUXVirtual()
    h.module = mock.Mock()
    h.module.run_command.return_value = (0, "", "")
    with patch.object(os.path, "exists", mock.Mock(return_value=True)):
        virtual_facts = h.get_virtual_facts()
        assert virtual_facts['virtualization_role'] == 'HP vPar'
        assert virtual_facts['virtualization_type'] == 'guest'

# Generated at 2022-06-23 02:17:01.282970
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert x.platform == 'HP-UX'
    assert x.fact_class == HPUXVirtual

# Generated at 2022-06-23 02:17:04.763258
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    '''
    Constructor of class HPUXVirtual
    '''
    hvx = HPUXVirtual()
    assert hvx._platform == 'HP-UX'



# Generated at 2022-06-23 02:17:11.317089
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = DummyModule()
    facts_collector = HPUXVirtual(module)
    facts = facts_collector.get_virtual_facts()
    assert facts['virtualization_type'] == 'host'
    assert facts['virtualization_role'] == 'HPVM'
    assert facts['virtualization_tech_host'] == set(['HPVM'])
    assert facts['virtualization_tech_guest'] == set(['HPVM'])


# Unit test base class

# Generated at 2022-06-23 02:17:13.562707
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    obj = HPUXVirtual()


# Generated at 2022-06-23 02:17:16.161071
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """Unit test for constructor of class HPUXVirtualCollector
    """
    virtual_instance = HPUXVirtualCollector()
    assert virtual_instance._platform == 'HP-UX'

# Generated at 2022-06-23 02:17:18.549318
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector._platform == 'HP-UX'
    assert HPUXVirtualCollector._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:17:21.239868
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    h = HPUXVirtualCollector()
    assert h._platform == 'HP-UX'
    assert h._fact_class.platform == 'HP-UX'

# Generated at 2022-06-23 02:17:23.386232
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    assert obj.platform == 'HP-UX'


# Generated at 2022-06-23 02:17:37.978405
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import _run_command
    from ansible.module_utils.facts.virtual.hpux import _run_command_posix
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_hpux
    from ansible.module_utils.facts.virtual.hpux import _get_virtual_facts_

# Generated at 2022-06-23 02:17:45.917322
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class MockModule(object):
        def run_command(self, command, check_rc=True):
            class MockPopen(object):
                def __init__(self, command, check_rc=True):
                    if command == "/usr/sbin/vecheck":
                        self.rc = 0
                        self.stdout = '   vecheck: vPar Installed\n'
                    elif command == "/opt/hpvm/bin/hpvminfo":
                        self.rc = 0
                        self.stdout = '   Running as HPVM vPar\n'
                    elif command == "/usr/sbin/parstatus":
                        self.rc = 0
                        self.stdout = '   System is a vPars system.\n'
                    else:
                        self.rc = 1

# Generated at 2022-06-23 02:17:59.720204
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = MockModule()
    # command 'vecheck' returns a matching line
    vecheck_command = MockCommand("/usr/sbin/vecheck", 0, "HP vPar status: Running", "")
    # command 'hpvminfo' returns no matching line
    hpvminfo_command = MockCommand("/opt/hpvm/bin/hpvminfo", 0, "", "")
    # command 'parstatus' returns no matching line
    parstatus_command = MockCommand("/usr/sbin/parstatus", 0, "", "")
    module.run_command = Mock(return_value=(0, "", ""))
    module.run_command.side_effect = [vecheck_command, hpvminfo_command, parstatus_command]
    hv = HPUXVirtual(module)
    facts = hv

# Generated at 2022-06-23 02:18:01.185642
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv._platform == 'HP-UX'


# Generated at 2022-06-23 02:18:02.926801
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert isinstance(HPUXVirtualCollector(), VirtualCollector)

# Generated at 2022-06-23 02:18:06.035455
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector._platform == 'HP-UX'
    assert HPUXVirtualCollector._fact_class == HPUXVirtual



# Generated at 2022-06-23 02:18:10.052502
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpuxvirtual = HPUXVirtual()
    assert isinstance(hpuxvirtual, Virtual)
    assert hpuxvirtual.platform == 'HP-UX'

# Generated at 2022-06-23 02:18:13.346437
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual(None)
    assert v.platform == 'HP-UX'
    assert v.get_virtual_facts() == {}


# Generated at 2022-06-23 02:18:23.719239
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual import Virtual, VirtualCollector
    from ansible.module_utils._text import to_bytes
    import re
    import pytest
    from ansible.module_utils.six import PY3

    if PY3:
        import io
    else:
        import cStringIO as io

    class MockModule:
        def __init__(self):
            self.run_command_args = []
            self.run_command_rcs = []
            self.run_command_outs = []
            self.run_command_errs = []


# Generated at 2022-06-23 02:18:33.858550
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    example_output = """
        hpvmstatus: HPVM is off
        hpvminfo: running HPVM guest
        parstatus: guest
    """
    expected_virtual_facts = {}
    expected_virtual_facts['virtualization_type'] = 'guest'
    expected_virtual_facts['virtualization_role'] = 'HPVM IVM'
    expected_virtual_facts['virtualization_tech_guest'] = {'HPVM IVM'}
    expected_virtual_facts['virtualization_tech_host'] = set()

    hv = HPUXVirtual(dict(module=None, collected_facts=dict()))
    hv.module.run_command = lambda *args, **kwargs: (0, example_output, '')
    virtual_facts = hv.get_virtual_facts()

# Generated at 2022-06-23 02:18:43.252488
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    hpux_virtual.get_virtual_facts()
    hpux_virtual.populate()
    assert 'virtualization_role' in hpux_virtual.data.keys()
    assert 'virtualization_type' in hpux_virtual.data.keys()
    assert hpux_virtual.data['virtualization_role'] == 'HP vPar'
    assert hpux_virtual.data['virtualization_type'] == 'guest'
    assert 'virtualization_type_role' in hpux_virtual.data.keys()
    assert hpux_virtual.data['virtualization_type_role'] == 'guest:HP vPar'

# Generated at 2022-06-23 02:18:52.273136
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Do not set any env var
    module = AnsibleModule(argument_spec=dict())

    # Create an instance of HP-UX specific class of Virtual
    obj_hpux_virt = HPUXVirtual(module)

    # Return virtualization facts
    dict_facts = {}
    dict_facts = obj_hpux_virt.get_virtual_facts()
    
    # Assert the expected results
    assert 'virtualization_type' in dict_facts
    assert 'virtualization_role' in dict_facts
    assert 'virtualization_role_id' in dict_facts
    assert 'virtualization_technologies' in dict_facts

# Generated at 2022-06-23 02:19:01.433692
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )

    class ModuleMock(object):
        def __init__(self, module_args):
            self.params = module_args
            self.run_command_results = []

        def run_command(self, cmd):
            output = self.run_command_results.pop(0)
            rc = 0 if output[1] is True else 1
            return rc, output[0], ''

    module.run_command = ModuleMock(module.params).run_command

    # test for virtualization_type and virtualization_role
    module.run_command_results = [(('', True), None, None)]
    assert HPUXVirtual(module).get_virtual_facts() == {}

# Generated at 2022-06-23 02:19:03.906864
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual({})
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-23 02:19:08.277627
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import mock

    module = mock.MagicMock()
    module.run_command = mock.Mock(return_value=(0, '', ''))
    module.get_bin_path = mock.Mock(return_value='')

    HP_UX = HPUXVirtual(module)
    HP_UX.get_virtual_facts()

# Generated at 2022-06-23 02:19:10.090235
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-23 02:19:20.212776
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import tempfile
    from ansible.module_utils.facts import netbsd

    # Create a fake temp module class
    class BSDFakeModule(object):
        def __init__(self):
            self.tmpdir = tempfile.mkdtemp()
            self.params = {}

        def get_bin_path(self, name):
            return name

        def run_command(self, name):
            import sys

            if name == '/usr/sbin/parstatus':
                return 1, "", ""
            elif name == '/usr/sbin/vecheck':
                return 0, "", ""
            elif name == '/opt/hpvm/bin/hpvminfo':
                return 0, "Running HPVM guest", None
            else:
                print("UNKNOWN:", name)
                sys.exit(1)



# Generated at 2022-06-23 02:19:21.860126
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict(module=dict()), dict())
    assert virtual

# Generated at 2022-06-23 02:19:24.830780
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    from ansible.module_utils.facts.virtual.hpar import HPUXVirtualCollector
    assert HPUXVirtualCollector._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:19:35.366105
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class HPUXVirtual_fake():
        def __init__(self, module):
            self.module = module
        def run_command(self, cmd):
            if cmd == "/usr/sbin/vecheck":
                return (0, "", "")
            elif cmd == "/opt/hpvm/bin/hpvminfo":
                return (0, "Running HPVM guest", "")
            elif cmd == "/usr/sbin/parstatus":
                return (0, "", "")
            else:
                return (1, "", "")

    class FakeModule():
        def __init__(self):
            self.run_command = HPUXVirtual_fake(self).run_command

    module = FakeModule()

    hpux_virtual = HPUXVirtual(module)
    virtual_facts = hpux_

# Generated at 2022-06-23 02:19:45.212858
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hv.hpux.HPUXVirtual import HPUXVirtual
    class1 = HPUXVirtual([''])
    opt_hv = os.path.exists('/opt/hpvm/bin/hpvminfo')
    usr_sbin_vecheck = os.path.exists('/usr/sbin/vecheck')
    usr_sbin_parstatus = os.path.exists('/usr/sbin/parstatus')
    exp_res = {}
    exp_res['virtualization_type'] = 'guest'
    exp_res['virtualization_role'] = 'HP nPar'
    exp_res['virtualization_tech_guest'] = set(['HP nPar'])
    exp_res['virtualization_tech_host'] = set

# Generated at 2022-06-23 02:19:48.316482
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert virtual_collector._platform == 'HP-UX'
    assert virtual_collector._fact_class.platform == 'HP-UX'

# Generated at 2022-06-23 02:19:50.159734
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual({})
    assert HPUXVirtual({}).platform == 'HP-UX'

# Generated at 2022-06-23 02:19:56.356101
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual()
    assert h.platform == 'HP-UX'
    assert h.get_virtual_facts() == dict(
        virtualization_type='guest',
        virtualization_role='HP vPar',
        virtualization_tech_guest={'HP vPar'},
        virtualization_tech_host=set())

# Generated at 2022-06-23 02:20:05.385735
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Initialize the class
    obj = HPUXVirtual()

    # Set the file exists to True
    obj.module.run_command = lambda x: (0, '', '')

    # Test when file exists
    obj.facts['virtualization_type'] = None
    obj.facts['virtualization_role'] = None
    obj.get_virtual_facts()
    assert obj.facts['virtualization_type'] == 'guest'
    assert obj.facts['virtualization_role'] == 'HP vPar'

    # Set the file exists to True
    obj.module.run_command = lambda x: (0, 'Running HPVM on HPVM vPar', '')

    # Test when file exists
    obj.facts['virtualization_type'] = None
    obj.facts['virtualization_role'] = None
    obj.get_virtual

# Generated at 2022-06-23 02:20:13.120855
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    Constructor of class HPUXVirtual is tested with:
    - 'parse_hint' is set to be 'verify'

    Output of constructor is tested to be
    - virtual_facts = {}
    - virtual_hint = ''

    """
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    hpux_virtual = HPUXVirtual(module)
    assert hpux_virtual.virtual_facts == {}
    assert hpux_virtual.virtual_hint == ''


# Generated at 2022-06-23 02:20:16.802175
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual({})
    assert isinstance(v, HPUXVirtual)
    assert isinstance(v, Virtual)
    assert isinstance(v, object)


# Constructor test of HPUXVirtualCollector

# Generated at 2022-06-23 02:20:21.641931
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpv_collector = HPUXVirtualCollector()
    assert hpv_collector.platform == 'HP-UX'
    assert hpv_collector._fact_class.platform == 'HP-UX'


# Generated at 2022-06-23 02:20:28.383251
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import VirtualInfo
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.virtual import Virtual, VirtualCollector

# Generated at 2022-06-23 02:20:31.646323
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict())
    assert virtual._platform == 'HP-UX'
    assert virtual._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:20:32.666493
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-23 02:20:35.809727
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpux_virtual = HPUXVirtualCollector(None)
    assert hpux_virtual._fact_class == HPUXVirtual
    assert hpux_virtual._platform == 'HP-UX'

# Generated at 2022-06-23 02:20:39.104348
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    facts = HPUXVirtualCollector()
    assert facts.__class__.__name__ == 'HPUXVirtualCollector'

# Generated at 2022-06-23 02:20:49.501574
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpri = HPUXVirtualCollector()
    hpri.collect()
    facts = hpri.get_facts()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP nPar'
    assert facts['virtualization_tech_host'] == set(['HPVM'])
    assert facts['virtualization_tech_guest'] == set(['HP vPar', 'HPVM vPar', 'HPVM IVM', 'HP nPar'])

# Generated at 2022-06-23 02:20:55.774866
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    va = HPUXVirtual()
    assert va.platform == 'HP-UX'
    assert va.virtualization_type is None
    assert va.virtualization_role is None
    assert va.virtualization_tech_host == set()
    assert va.virtualization_tech_guest == set()
    assert va.virtualization_system is None
    assert va.virtualization_system_version is None
    assert va.virtualization_system_release is None


# Generated at 2022-06-23 02:20:57.993746
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    if os.path.exists('/usr/sbin/parstatus'):
        obj = HPUXVirtualCollector()
        assert obj != None

# Generated at 2022-06-23 02:21:02.454605
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vc = HPUXVirtualCollector()
    assert isinstance(vc._fact_class, HPUXVirtual)
    assert vc._platform == 'HP-UX'



# Generated at 2022-06-23 02:21:12.283698
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Create a module object with preset facts
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
        facts=dict()
    )

    hpux_virtual = HPUXVirtual(module)

    # Gather facts from virtualization system
    virtual = hpux_virtual.get_virtual_facts()

    for key, value in virtual.items():
        print("%s: %s" % (key, value))

from ansible.module_utils.basic import *

if __name__ == '__main__':
    # Run test
    test_HPUXVirtual_get_virtual_facts()

# Generated at 2022-06-23 02:21:23.040724
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():

    class TestModule(object):
        def run_command(self, cmd):
            if cmd.startswith('/usr/sbin/parstatus'):
                return 0, 'a', 'b'
            elif cmd.startswith('/opt/hpvm/bin/hpvminfo'):
                return 0, 'Running as HPVM host', 'c'
            elif cmd.startswith('/usr/sbin/vecheck'):
                return 0, 'a', 'b'
        def get_bin_path(self, arg, *args, **kwargs):
            return arg

    connection = TestModule()
    result = HPUXVirtual(connection).populate()
    assert result['virtualization_type'] == 'host'
    assert result['virtualization_role'] == 'HPVM'

# Generated at 2022-06-23 02:21:27.558896
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpux_virtual_collector = HPUXVirtualCollector()
    assert hpux_virtual_collector._fact_class is not None, "No fact class instantiated"
    assert hpux_virtual_collector._platform is not None, "No platform defined"

# Generated at 2022-06-23 02:21:30.474044
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector()
    assert collector.platform == 'HP-UX'
    assert collector.fact_class == HPUXVirtual


# Generated at 2022-06-23 02:21:32.718749
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()

    assert obj._fact_class is HPUXVirtual
    assert obj._platform is 'HP-UX'

# Generated at 2022-06-23 02:21:35.395691
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = AnsibleModuleMock()
    hpux_virtual_collector = HPUXVirtual(module)
    assert hpux_virtual_collector.module == module

# Generated at 2022-06-23 02:21:37.984611
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    Create a instance of HPUXVirtual
    """

    obj = HPUXVirtual()

    assert obj.platform == 'HP-UX'



# Generated at 2022-06-23 02:21:45.619060
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt = HPUXVirtual(dict())

    assert type(virt.virtualization_type) is str
    assert type(virt.virtualization_role) is str
    assert type(virt.virtualization_type_role) is str
    assert type(virt.virtualization_system) is str
    assert type(virt.virtualization_technologies) is str
    assert type(virt.virtualization_type_role) is str
    assert type(virt.virt_who) is bool

# Generated at 2022-06-23 02:21:50.861961
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    '''
    Unit test for constructor of class HPUXVirtualCollector
    >>> from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    >>> hpx = HPUXVirtualCollector()
    >>> hpx._platform
    'HP-UX'
    >>> hpx._fact_class.platform
    'HP-UX'
    '''
    pass

# Generated at 2022-06-23 02:21:51.518325
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    pass

# Generated at 2022-06-23 02:21:54.518786
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpux_v = HPUXVirtualCollector()
    assert hpux_v._platform == 'HP-UX'
    assert hpux_v._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:22:05.065891
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import ansible.module_utils.facts.virtual.hpux_virtual
    import mock

    class FakeModule(object):
        def __init__(self):
            module_utils = ansible.module_utils.facts.virtual.hpux_virtual
            self.module = mock.MagicMock()
            self.module.run_command = module_utils.run_command
    class FakeResult(object):
        def __init__(self, returncode, stdout, stderr):
            self.returncode = returncode
            self.stdout = stdout
            self.stderr = stderr

    v = HPUXVirtual(FakeModule())
    v.module.run_command.return_value = FakeResult(0, "", "")
    assert v.get_virtual_facts() == {}
    v.module.run

# Generated at 2022-06-23 02:22:13.817480
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    fact_file = '/tmp/ansible_facts.txt'
    module = basic.AnsibleModule(argument_spec={})
    module.exit_json = lambda x: x
    setattr(module, 'run_command',
            lambda x: (0, 'HPVM guest virtual machine\n', ''))
    setattr(module, 'get_bin_path', lambda x: '/opt/hpvm/bin/hpvminfo')
    setattr(module, '_collect_subset', lambda x: {})


# Generated at 2022-06-23 02:22:20.522196
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import ModuleStub
    module = ModuleStub()
    virtual = HPUXVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    assert virtual_facts['virtualization_tech_guest'] == set(['HP vPar'])
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:22:25.760314
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual

    module = type('', (), {'run_command': lambda self, x: (0, x, '')})
    module.exit_json = lambda x: x
    module.fail_json = lambda x: x

    h_hpux_virtual = HPUXVirtual(module)

    assert h_hpux_virtual.get_virtual_facts() == {}

# Generated at 2022-06-23 02:22:36.279175
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Test HPUXVirtual in guest HP vPar
    module = FakeModule({
        '/usr/sbin/vecheck': '',
    })
    virtual = HPUXVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert len(virtual_facts['virtualization_tech_host']) == 0
    assert len(virtual_facts['virtualization_tech_guest']) == 1
    assert 'HP vPar'

# Generated at 2022-06-23 02:22:45.581717
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Set up a temporary directory
    ansible_module = AnsibleModule({})
    tmp_dir = mkdtemp(prefix='ansible-tmp-')
    vcollector = HPUXVirtualCollector(ansible_module=ansible_module)
    vfact = HPUXVirtual(ansible_module=ansible_module)

    # Create a fake file to mimic the vpar status
    fbo = open(os.path.join(tmp_dir, 'vecheck'), 'w')
    fbo.close()

    # Test method on a vPar guest
    virtual_facts = vfact.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    assert virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-23 02:22:49.298116
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpux_virtual_collector = HPUXVirtualCollector()
    assert hpux_virtual_collector._platform == 'HP-UX'
    assert hpux_virtual_collector._fact_class.platform == 'HP-UX'


# Generated at 2022-06-23 02:23:00.702313
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import ModuleBase
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.virtual import HPUXVirtual as HPUXVirtual
    import os

    class MockModule(ModuleBase):
        def __init__(self):
            super(MockModule, self).__init__()
            self.params = {}

        def get_bin_path(self, executable=None, req_false=False):
            if req_false:
                return False
            return super(MockModule, self).get_bin_path(executable, req_false)

        def run_command(self, command):
            return 0, '', ''

    module = MockModule()

    virtual_facts = HPUXVirtual(module = module).get_virtual_facts()

# Generated at 2022-06-23 02:23:13.158556
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Open the mock file
    from ansible.module_utils import facts
    with open(os.path.join(facts.FACT_CACHE_DIR, 'hpux_virtual.out')) as f:
        mock_output = f.read()

    # Create the mock AnsibleModule
    from ansible.module_utils.facts import virtual
    mock_module = virtual.AnsibleModule()
    mock_module.run_command = mock.Mock(return_value=(0, mock_output, ''))
    mock_module.exit_json = mock.Mock(return_value=None)

    # Instantiate the HPUXVirtual class
    from ansible.module_utils.facts.virtual import HPUXVirtual
    hpux_virtual = HPUXVirtual(mock_module)

    # Instantiate the VirtualCollector

# Generated at 2022-06-23 02:23:17.964869
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = type('MockOSIF', (), {'run_command': (0, '', '')})
    facts = HPUXVirtualCollector(module).collect(None, None)
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP vPar'

# Generated at 2022-06-23 02:23:19.603710
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-23 02:23:22.633376
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    assert obj.platform == 'HP-UX'
    assert obj._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:23:24.898150
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpx_info = HPUXVirtual()
    assert hpx_info.platform == 'HP-UX'


# Generated at 2022-06-23 02:23:26.614880
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector._platform == "HP-UX"
    assert HPUXVirtualCollector._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:23:31.394929
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    instance = HPUXVirtualCollector()
    # Unit test for variable _fact_class
    assert instance._fact_class == HPUXVirtual
    # Unit test for variable _platform
    assert instance._platform == 'HP-UX'



# Generated at 2022-06-23 02:23:34.754059
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual(dict())
    assert virtual_obj.platform == 'HP-UX'


# Generated at 2022-06-23 02:23:43.500043
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_facts = HPUXVirtual()
    # check the platform
    assert virtual_facts.platform == "HP-UX"
    # check that platform-specific method is used
    assert virtual_facts.get_virtual_facts()['virtualization_role'] == 'HP nPar'
    assert virtual_facts.get_virtual_facts()['virtualization_type'] == 'guest'
    assert 'HPVM' in virtual_facts.get_virtual_facts()['virtualization_tech_guest']
    assert 'HPVM' in virtual_facts.get_virtual_facts()['virtualization_tech_host']