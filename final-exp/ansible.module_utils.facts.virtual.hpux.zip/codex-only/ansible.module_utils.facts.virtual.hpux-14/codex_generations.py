

# Generated at 2022-06-23 02:13:44.529960
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual({})
    assert hpux_virtual
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-23 02:13:52.748426
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    if not os.path.exists('/usr/sbin/vecheck'):
        os.makedirs('/usr/sbin')
        with open('/usr/sbin/vecheck', 'w') as f:
            f.write('#!/usr/bin/env bash\nexit 0')
        os.chmod('/usr/sbin/vecheck', 0o755)

    if not os.path.exists('/opt/hpvm/bin/hpvminfo'):
        os.makedirs('/opt/hpvm/bin')
        with open('/opt/hpvm/bin/hpvminfo', 'w') as f:
            f.write('#!/usr/bin/env bash\n')

# Generated at 2022-06-23 02:14:03.354160
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual

    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all', '!min'], type='list')
        )
    )

    # Run module and get results
    results = HPUXVirtual.get_virtual_facts(module)
    assert 'virtualization_type' in results
    assert 'virtualization_role' in results
    assert 'virtualization_tech_host' in results
    assert 'virtualization_tech_guest' in results



# Generated at 2022-06-23 02:14:14.859741
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    M = HPUXVirtual(dict(module=dict(run_command=run_command_mock_factory([
        dict(cmd='/usr/sbin/vecheck', rc=0),
        dict(cmd='/opt/hpvm/bin/hpvminfo', rc=0, out="Running HPVM vPar"),
        dict(cmd='/usr/sbin/parstatus', rc=0)
    ]))), dict())

    assert M.get_virtual_facts() == dict(
        virtualization_type='guest',
        virtualization_role='HP nPar',
        virtualization_tech_host=set(),
        virtualization_tech_guest=set(['HP nPar', 'HPVM vPar', 'HP vPar'])
    )



# Generated at 2022-06-23 02:14:17.149650
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'



# Generated at 2022-06-23 02:14:19.019923
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert x
    assert x._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:14:24.331129
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'
    assert virtual_facts.virtualization_tech_guest == set()
    assert virtual_facts.virtualization_tech_host == set()
    assert virtual_facts.virtualization_role == ''
    assert virtual_facts.virtualization_type == 'guest'


# Generated at 2022-06-23 02:14:27.901340
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual_class_inst = HPUXVirtual()
    assert HPUXVirtual_class_inst.platform == 'HP-UX'


# Generated at 2022-06-23 02:14:29.735099
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    obj = HPUXVirtual(None)
    assert obj.platform == 'HP-UX'



# Generated at 2022-06-23 02:14:32.450268
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector._platform == 'HP-UX'
    assert HPUXVirtualCollector._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:14:39.952780
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = type('', (), {})()
    module.run_command = lambda cmd: (0, '', '')
    module.exit_json = lambda **kwargs: (0, '', '')
    module.fail_json = lambda **kwargs: (0, '', '')
    hpuxvirtual = HPUXVirtual(module)
    assert hpuxvirtual.get_virtual_facts() == {'virtualization_type': 'guest',
                                               'virtualization_role': 'HP nPar',
                                               'virtualization_tech_host': set([]),
                                               'virtualization_tech_guest': {'HP nPar'}}

# Generated at 2022-06-23 02:14:49.480647
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    # get_virtual_facts is tested by passing a mocked module to HPUXVirtual
    # In order to do this, we define
    # - a fake class
    # - a class mocking the module
    # - a method mocking run_command()
    # - test arguments
    # - expected results

    class FakeHPUX():
        """
        This is a fake class with a name and a version
        """
        platform = 'HP-UX'
        version = 'B.11.23'

    class FakeModule():
        """This is a fake module class"""
        def __init__(self):
            """Constructor"""
            self.run_command_counter = 0

        def run_command(self, cmd):
            """
            This method mocks the run_command method of the ansible Module()
            """

# Generated at 2022-06-23 02:14:53.844959
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict())
    assert virtual._platform == 'HP-UX'
    assert virtual._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:14:56.102085
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    # Instantiate class object
    hpxvirtualobj = HPUXVirtualCollector()
    assert hpxvirtualobj._platform == "HP-UX"

# Generated at 2022-06-23 02:14:57.956886
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict())
    assert virtual.platform == 'HP-UX'


# Generated at 2022-06-23 02:14:59.836864
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtualobj = HPUXVirtual()
    assert virtualobj.platform == 'HP-UX'


# Generated at 2022-06-23 02:15:06.747397
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    This function tests get_virtual_facts function of class HPUXVirtual.
    Invoke get_virtual_facts and check whether the key
    'virtualization_type' and 'virtualization_role' are present.
    """
    virt_obj = HPUXVirtual()
    virtual_facts = virt_obj.get_virtual_facts()
    keys = virtual_facts.keys()
    assert 'virtualization_type' in keys
    assert 'virtualization_role' in keys

# Generated at 2022-06-23 02:15:11.376745
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import HPUXVirtual

    hpuxvirtual_obj = HPUXVirtual({})
    facts = hpuxvirtual_obj.get_virtual_facts()
    assert sorted(facts.keys()) == ['virtualization_role', 'virtualization_tech_guest', 'virtualization_tech_host', 'virtualization_type']

# Generated at 2022-06-23 02:15:12.605348
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert Virtual().get_virtual_facts() == {}
    assert HPUXVirtual().platform == 'HP-UX'
    assert HPUXVirtual().get_virtual_facts() == {}

# Generated at 2022-06-23 02:15:23.324950
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module_mock = MockModule()
    facts_mock = MockHPUXVirtual()

    module_mock.run_command.return_value = (0, '', '')
    module_mock.params = {}

    # Test when there is no virtualization technology
    virtual_facts = facts_mock.get_virtual_facts()
    assert virtual_facts == {}

    # Test when virtualization_type is guest
    module_mock.path_exists.side_effect = [True, False, False]
    module_mock.run_command.return_value = (0, 'This is HP vPar', '')
    virtual_facts = facts_mock.get_virtual_facts()

# Generated at 2022-06-23 02:15:34.745813
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    test HPUXVirtual.get_virtual_facts
    """
    class MockModule:
        def __init__(self):
            pass
        @staticmethod
        def run_command(cmd):
            if cmd == '/usr/sbin/vecheck':
                return 0, 'Running on HP vPar virtual partition.\n', ''
            if cmd == '/usr/sbin/parstatus':
                return 0, 'Running on HP nPar virtual partition.\n', ''
            if cmd == '/opt/hpvm/bin/hpvminfo':
                return 1, '', ''
        def fail_json(self, msg):
            raise Exception('fail_json called')

    class HPUXVirtualSubclass(HPUXVirtual):
        def __init__(self, module):
            self.module = module

    module = Mock

# Generated at 2022-06-23 02:15:43.115311
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    HPUXVirtual_class_instance = HPUXVirtual()
    virtual_facts_list = HPUXVirtual_class_instance.get_virtual_facts()
    assert type(virtual_facts_list) is dict
    assert virtual_facts_list.get('virtualization_type')
    assert virtual_facts_list.get('virtualization_role')
    assert virtual_facts_list.get('virtualization_tech_guest')
    assert virtual_facts_list.get('virtualization_tech_host')

# Generated at 2022-06-23 02:15:53.873305
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """ This utility method tests get_virtual_facts method of class HPUXVirtual """

    # Define the expected output for a supported guest
    expected_facts = {
        'virtualization_type': 'guest',
        'virtualization_role': 'HP nPar',
        'virtualization_tech_guest': set(['HP nPar']),
        'virtualization_tech_host': set()
    }

    # Define the side effect for ansible.module_utils.facts.virtual.base Virtual.get_file_content()
    def get_file_content_side_effect(path):
        if path == '/usr/sbin/vecheck':
            return '', '', 0
        if path == '/usr/sbin/parstatus':
            return 'Virtualization: HP nPar', '', 0
        return '', '', 1

# Generated at 2022-06-23 02:15:55.089415
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert x.platform == 'HP-UX'

# Generated at 2022-06-23 02:15:58.196054
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector._platform == 'HP-UX'
    assert HPUXVirtualCollector._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:16:08.402183
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = {'virtualization_tech_guest': set(),
                     'virtualization_tech_host': set(),
                     'virtualization_type': '',
                     'virtualization_role': '',
                     'virtualization_system': ''}
    hpux_virtual = HPUXVirtual(dict(), virtual_facts)
    assert hpux_virtual.platform == 'HP-UX'
    assert hpux_virtual.virtual_facts['virtualization_type'] == ''
    assert hpux_virtual.virtual_facts['virtualization_role'] == ''
    assert hpux_virtual.virtual_facts['virtualization_system'] == ''
    assert hpux_virtual.virtual_facts['virtualization_tech_guest'] == set()
    assert hpux_virtual.virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:16:18.242800
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import ansible.module_utils.facts.virtual.hpux_virtual as hpux_virtual
    import ansible.module_utils.facts.virtual.hpux_virtual

    class FakeModule(object):
        def run_command(self, cmd):
            class FakeResult(object):
                def __init__(self, stdout, stderr):
                    self.stdout = stdout
                    self.stderr = stderr
                def __getitem__(self, name):
                    return getattr(self, name)
                def __repr__(self):
                    return 'FakeResult(stdout=%s, stderr=%s)' % (self.stdout, self.stderr)
            if 'vecheck' in cmd:
                return (0, '', '')

# Generated at 2022-06-23 02:16:20.150313
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    vf = HPUXVirtual({})
    assert vf.platform == 'HP-UX'

# Generated at 2022-06-23 02:16:30.130657
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    HPUXVirtual_facts = dict()

    HPUXVirtual_facts['virtualization_tech_guest'] = set()
    HPUXVirtual_facts['virtualization_tech_host'] = set()
    HPUXVirtual_facts['virtualization_type'] = 'guest'
    HPUXVirtual_facts['virtualization_role'] = 'HP vPar'

    HPUXVirtual_instance = HPUXVirtual(None)
    HPUXVirtual_instance.get_virtual_facts()
    assert(HPUXVirtual_facts == HPUXVirtual_instance.facts)

    HPUXVirtual_facts['virtualization_type'] = 'guest'
    HPUXVirtual_facts['virtualization_role'] = 'HPVM vPar'

    HPUXVirtual_instance = HPUXVirtual(None)
    HPU

# Generated at 2022-06-23 02:16:32.410971
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    result = VirtualCollector.collector_class(None, None).__class__.__name__
    assert result == 'HPUXVirtualCollector'

# Generated at 2022-06-23 02:16:36.314442
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = MagicMock(params={})
    res = HPUXVirtualCollector(module)
    assert res.__class__.__name__ == 'HPUXVirtualCollector'
    assert res.platform == 'HP-UX'
    assert res.fact_class is HPUXVirtual

# Generated at 2022-06-23 02:16:39.459743
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    Constructor test without argument
    """
    my_obj = HPUXVirtual()
    assert my_obj.platform == 'HP-UX'
    assert my_obj._virtual == {}


# Generated at 2022-06-23 02:16:47.559263
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(dict())
    assert hpux_virtual.platform == 'HP-UX'
    assert hpux_virtual.get_virtual_facts() == {
        'virtualization_type': 'guest',
        'virtualization_role': 'HP nPar',
        'virtualization_tech_guest': set(['HP nPar']),
        'virtualization_tech_host': set()
    }


# Test for constructor of class HPUXVirtualCollector

# Generated at 2022-06-23 02:16:57.265142
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.virtual.hpar import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpvm import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpvm import HPUXVirtual

    facts = Facts({})
    HPUXVirtual().populate()
    assert 'virtualization_type' in facts.ansible_facts
    assert 'virtualization_role' in facts.ansible_facts
    assert 'virtualization_tech_guest' in facts.ansible_facts
    assert 'virtualization_tech_host' in facts.ansible_facts
    assert 'HP vPar' in facts.ansible_facts['virtualization_tech_guest']
    assert 'HPVM vPar' in facts.ansible

# Generated at 2022-06-23 02:17:01.816065
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    from ansible.module_utils import basic
    hpux = HPUXVirtualCollector(basic.AnsibleModule(
    ))

    assert hpux.platform == 'HP-UX'
    assert issubclass(hpux._fact_class, HPUXVirtual)

# Generated at 2022-06-23 02:17:09.042496
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpu import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpu import HPUXVirtualCollector
    my_facts = {'virtualization_type': 'guest',
                'virtualization_role': 'HP nPar'}
    my_obj = HPUXVirtual({'module': 'module'})
    my_obj.get_virtual_facts()
    assert my_obj.facts == my_facts



# Generated at 2022-06-23 02:17:18.455802
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    hw = HPUXVirtual(dict(module=dict()), dict(), dict())


# Generated at 2022-06-23 02:17:30.513023
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virtual_facts = HPUXVirtual(module).get_virtual_facts()
    assert isinstance(virtual_facts, dict)
    assert 'virtualization_type' in virtual_facts
    assert isinstance(virtual_facts['virtualization_type'], str)
    if virtual_facts['virtualization_type']:
        assert isinstance(virtual_facts['virtualization_type'], str)
        assert 'virtualization_role' in virtual_facts
        assert isinstance(virtual_facts['virtualization_role'], str)
    else:
        assert 'virtualization_role' not in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert isinstance(virtual_facts['virtualization_tech_guest'], set)

# Generated at 2022-06-23 02:17:34.854263
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    if not os.path.exists('/usr/sbin/parstatus'):
        return
    hv = HPUXVirtual({}, None)
    hv.get_virtual_facts()


if __name__ == '__main__':
    test_HPUXVirtual()

# Generated at 2022-06-23 02:17:38.296417
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    facts = {}
    virtual_facts = HPUXVirtual(facts)
    assert virtual_facts._facts == facts
    assert virtual_facts._platform == "HP-UX"
    assert virtual_facts._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:17:40.381885
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    assert obj._platform == 'HP-UX'
    assert obj._fact_class.platform == 'HP-UX'

# Generated at 2022-06-23 02:17:51.290952
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    import sys

    stdout = """
    hostname:myhost
    HPVM_INFO_BEGIN
    Running HPVM guest
    HPVM_INFO_END
    """
    stdout = StringIO(stdout)
    if PY3:
        stdout = stdout.buffer
    sys.stdin = stdout
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    module.run_command = mock.Mock(return_value=(0, stdout,""))
    virtual_facts = HPUXVirtual(module).get_virtual

# Generated at 2022-06-23 02:17:55.844041
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    c = HPUXVirtualCollector()
    assert c._platform == "HP-UX"

# Generated at 2022-06-23 02:17:58.369088
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():

    # Test with no values
    virtual = HPUXVirtual()
    assert virtual.virtualization_type is None
    assert virtual.virtualization_role is None
    assert virtual.virtualization_system is None

# Generated at 2022-06-23 02:18:00.729405
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert isinstance(virtual_collector._fact_class, HPUXVirtual)
    assert virtual_collector._platform == 'HP-UX'

# Generated at 2022-06-23 02:18:05.622063
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_hpux = HPUXVirtual({})
    assert virtual_hpux.platform == 'HP-UX'
    assert virtual_hpux.get_virtual_facts() == {
        'virtualization_type': 'guest',
        'virtualization_role': 'HPVM',
        'virtualization_tech_guest': set(['HPVM']),
        'virtualization_tech_host': set([])}

# Generated at 2022-06-23 02:18:16.817356
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible_collections.ansible.community.tests.unit.module_utils.facts.virtual.hpux.mock_module import MockModule
    from ansible_collections.ansible.community.tests.unit.module_utils.facts.virtual.hpux.mock_subprocess import MockSubprocess

    facts_dict = {}
    module = MockModule(facts_dict)
    subprocess = MockSubprocess(
        (0, 'Running in HPVM vPar', ''),
        (0, 'Running in HPVM guest', '')
    )

    hpux_virtual = HPUXVirtual(module, subprocess)
    virtual_facts = hpux_virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'guest'

# Generated at 2022-06-23 02:18:21.531989
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt = HPUXVirtual()
    assert virt.platform == 'HP-UX'
    assert virt.virtualization_type is None
    assert virt.virtualization_role is None
    assert virt.virtualization_system is None


# Generated at 2022-06-23 02:18:30.624248
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # This test requires access to /usr/sbin/parstatus, /usr/sbin/vecheck, and
    # /opt/hpvm/bin/hpvminfo.
    try:
        from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.facts.virtual.hpux.HPUXVirtual import test_HPUXVirtual
    except ImportError:
        raise Exception("failed to import Ansible module for testing")
    obj = test_HPUXVirtual()
    obj._module = None
    result = obj.get_virtual_facts()
    assert type(result) == dict, "successfully got virtual facts"
    assert 'virtualization_type' in result.keys(), "answer contains virtualization_type"

# Generated at 2022-06-23 02:18:37.294773
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert not HPUXVirtual().is_linux()
    assert HPUXVirtual().platform == 'HP-UX'

# Generated at 2022-06-23 02:18:40.390583
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_hpx = HPUXVirtual(dict(module=dict()))
    assert virtual_hpx.platform == 'HP-UX'


# Generated at 2022-06-23 02:18:42.559541
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-23 02:18:46.132039
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    hv = HPUXVirtual()
    vf = hv.get_virtual_facts()
    assert 'virtualization_role' in vf
    assert 'virtualization_type' in vf

# Generated at 2022-06-23 02:18:49.471148
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_factory = HPUXVirtual()
    assert virtual_factory.__class__.__name__ == 'HPUXVirtual'
    assert virtual_factory.platform == 'HP-UX'

# Generated at 2022-06-23 02:18:50.501090
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    HPUXVirtual().get_virtual_facts()

# Generated at 2022-06-23 02:18:52.009896
# Unit test for method get_virtual_facts of class HPUXVirtual

# Generated at 2022-06-23 02:18:54.974236
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    h = HPUXVirtualCollector()
    assert h.platform == 'HP-UX'
    assert h.fact_class == HPUXVirtual


# Generated at 2022-06-23 02:18:57.529650
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    Create object instance HPUXVirtual

    :return:
    """
    facts = HPUXVirtual({})
    assert facts

# Generated at 2022-06-23 02:19:08.445710
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.virtual import VirtualCollector
    from ansible.module_utils.facts.virtual.hpuix import HPUXVirtual

    class FakeModule:
        def __init__(self):
            self.run_command_result = (0, '', '')

        def run_command(self, arg):
            return self.run_command_result

    class FakeOptions:
        pass

    module = FakeModule()
    options = FakeOptions()
    options.filename = '/somefile'
    options.failed = False
    options.ignore_errors = False

    HPUXVirtualCollector.set_module(module)
    HPUXVirtualCollector.set_options(options)


# Generated at 2022-06-23 02:19:09.470023
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual({})


# Generated at 2022-06-23 02:19:19.889400
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector

    class FakeModule(object):
        def __init__(self, rc, out, err, cmd):
            self.rc = rc
            self.out = out
            self.err = err
            self.cmd = cmd

        def run_command(self, cmd):
            if cmd == "/usr/sbin/vecheck":
                return self.rc, self.out, self.err

# Generated at 2022-06-23 02:19:22.404174
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert issubclass(HPUXVirtualCollector, VirtualCollector)
    assert isinstance(HPUXVirtualCollector._fact_class, type)

# Generated at 2022-06-23 02:19:24.634855
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpuxVirtual = HPUXVirtual({})
    assert hpuxVirtual.platform == 'HP-UX'

# Generated at 2022-06-23 02:19:35.147245
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hp_ux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hp_ux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hp_ux import VirtualCollector
    from ansible.module_utils.facts.virtual.hp_ux import Virtual

    # Setup of test

    # Mock subprocess.run
    import subprocess

    # Create mocks
    class RunMock(object):
        def __init__(self, args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    subprocess_mock = subprocess.run
    subprocess_run_mock = RunMock(args=None, **None)

    # Create test class

    # Constructor of class
   

# Generated at 2022-06-23 02:19:36.559342
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual({}).platform == 'HP-UX'

# Generated at 2022-06-23 02:19:46.644945
# Unit test for method get_virtual_facts of class HPUXVirtual

# Generated at 2022-06-23 02:19:48.942558
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virt_obj = HPUXVirtual({})
    assert hpux_virt_obj.module is not None


# Generated at 2022-06-23 02:19:49.954423
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-23 02:19:55.232536
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    hx = HPUXVirtual({})
    hx.module.run_command = run_command_mock
    facts = hx.get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP nPar'



# Generated at 2022-06-23 02:20:00.607810
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = Virtual()
    hpux_virtual_obj = HPUXVirtual(virtual_obj._module)
    assert hpux_virtual_obj.__class__.__name__ == 'HPUXVirtual'
    assert hpux_virtual_obj.platform == 'HP-UX'


# Generated at 2022-06-23 02:20:09.556227
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Create MockModule instance for UnitTest
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.dict_transformations import dict_merge

    def get_bin_path(name):
        return '/usr/bin/' + name

    mock_module = type('MockModule', (basic.AnsibleModule,), {
        'run_command': lambda self, cmd, check_rc=True: (0, '', ''),
        'get_bin_path': get_bin_path
    })

    # Create instance of HPUXVirtual fact class
    fact_class = HPUXVirtual(mock_module)

    # Run method get_virtual_facts and check returned virtualization facts
    virtual_facts = fact_class.get_virtual

# Generated at 2022-06-23 02:20:16.422733
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()

    assert hpux_virtual.platform == 'HP-UX'

    hpux_virtual_facts = hpux_virtual.get_virtual_facts()

    assert hpux_virtual_facts['virtualization_tech_guest'] == set()
    assert hpux_virtual_facts['virtualization_tech_host'] == set()
    assert hpux_virtual_facts['virtualization_type'] == 'guest'
    assert hpux_virtual_facts['virtualization_role'] == 'HP vPar'

# Generated at 2022-06-23 02:20:28.341097
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = FakeModule()
    module.run_command = FakeRunner()
    hpux_virtual = HPUXVirtual(module)

    # Test parstatus
    module.run_command.rc = 0
    module.run_command.output = """
System Memory Information
Memory size=2048MB
Memory free=1464MB
Memory status=Normal

Partition Information
Partition number=0
Partition name=CORE.0
Bootable Partition=Yes
Memory status=Normal
Partition size=2048MB
Processor status=Normal
Processor count=2
Processor configuration=1x2
Processor type=Integrity Superdome
Partition type=HPVM guest
Sharing mode=Dedicated

Partition State=Running

Network Information
Number of network interfaces=4
"""
    hpux_virtual.get_virtual_

# Generated at 2022-06-23 02:20:40.571357
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.HPUX_virtual import HPUXVirtual
    from ansible.module_utils.facts.virtual.HPUX_virtual import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.base import VirtualFacts
    from ansible.module_utils.facts.virtual.base import VirtualInfo
    from ansible.module_utils.facts.virtual.base import VirtualCollector

    class FakeModule:
        def __init__(self):
            self.run_command = FakeRunCommand()

    class FakeResult:
        def __init__(self):
            self.rc = 0
            self.stdout = 'stdout'
            self.stderr = 'stderr'

        @property
        def exited(self):
            return True


# Generated at 2022-06-23 02:20:42.835480
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vc = HPUXVirtualCollector()
    assert vc
    assert vc._fact_class == HPUXVirtual
    assert vc._platform == 'HP-UX'



# Generated at 2022-06-23 02:20:50.331103
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # create test class
    v = HPUXVirtual()
    # set up test data
    v.module.params['gather_subset'] = ['all']
    # run method
    v.get_virtual_facts()
    # check that virtualization_type is correct
    assert v.facts['virtualization_type'] == 'guest', \
        "virtualization_type wasn't set correctly"



# Generated at 2022-06-23 02:20:51.871176
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual({})
    assert virtual.platform == 'HP-UX'


# Generated at 2022-06-23 02:20:53.900256
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(dict(module=dict()))
    assert isinstance(hv, HPUXVirtual)


# Generated at 2022-06-23 02:20:55.268336
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-23 02:21:00.899130
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    print("Running test_HPUXVirtualCollector")

    module = AnsibleModuleMock()
    virtual_collector = HPUXVirtualCollector()
    virtual = virtual_collector.collect(module=module)

    assert isinstance(virtual, HPUXVirtual)

# Generated at 2022-06-23 02:21:02.826844
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector()
    assert collector.platform == 'HP-UX'
    assert collector._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:21:04.335850
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_inst = HPUXVirtual()
    assert virtual_inst.platform == 'HP-UX'

# Generated at 2022-06-23 02:21:07.288291
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual(dict())
    assert v.platform == 'HP-UX'
    assert not hasattr(v, 'data')

# Generated at 2022-06-23 02:21:12.090817
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = AnsibleModuleMock()
    virtual_obj = HPUXVirtualCollector(module)
    assert virtual_obj._platform == "HP-UX"
    assert virtual_obj._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:21:17.597964
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import tempfile
    import ansible.module_utils.facts.virtual.hpx
    import ansible.module_utils.facts.virtual.base
    virtualinstance = ansible.module_utils.facts.virtual.hpx.HPUXVirtual(None, tempfile, tempfile)
    assert isinstance(virtualinstance, ansible.module_utils.facts.virtual.base.Virtual)
    assert virtualinstance.get_virtual_facts() == {}

# Generated at 2022-06-23 02:21:21.593814
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpx_virtual = HPUXVirtualCollector()
    assert hpx_virtual._fact_class.platform == 'HP-UX', 'Specified platform is invalid'


# Generated at 2022-06-23 02:21:23.548514
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-23 02:21:25.420289
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual({})
    assert v.platform == 'HP-UX'


# Generated at 2022-06-23 02:21:27.570445
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector()
    assert isinstance(collector._fact_class(collector.module), HPUXVirtual)

# Generated at 2022-06-23 02:21:29.926719
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virt = HPUXVirtualCollector()
    assert virt._platform == 'HP-UX'
    assert virt._fact_class.platform == 'HP-UX'

# Generated at 2022-06-23 02:21:32.199018
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = None
    virt = HPUXVirtual(module)
    assert (virt.collector.platform == 'HP-UX')

# Generated at 2022-06-23 02:21:33.262659
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual({})
    assert virtual_obj.platform == 'HP-UX'


# Generated at 2022-06-23 02:21:46.183282
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec={
        }
    )

    def run_command(command):
        if command == '/usr/sbin/vecheck':
            return (0, '', '')
        else:
            return (1, '', '')

    module.run_command = run_command

    # Commands for different virtualization role
    hpu = HPUXVirtual(module)
    facts = hpu.get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP vPar'
    assert facts['virtualization_tech_guest'] == {'HP vPar'}
    assert facts['virtualization_tech_host'] == set()
    module.run_command = lambda x: (1, '', '')


# Generated at 2022-06-23 02:21:50.604114
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    here = os.path.dirname(__file__)
    hpu_virtual = HPUXVirtualCollector(None, here + '/fixtures', None)
    assert hpu_virtual
    assert hpu_virtual.collect()
    assert hpu_virtual.fact_class.platform == 'HP-UX'

# Generated at 2022-06-23 02:21:52.810826
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vc = HPUXVirtualCollector()
    assert vc._platform == 'HP-UX'
    assert vc._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:21:56.596300
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_collector = HPUXVirtualCollector()
    virtual_facts_object = virtual_collector._get_virtual_facts_platform_dependent()
    assert isinstance(virtual_facts_object, HPUXVirtual)
    assert virtual_facts_object._platform == 'HP-UX'

# Generated at 2022-06-23 02:22:05.582265
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import ansible.module_utils.facts.virtual.hpar as hpar
    import ansible.module_utils.facts.virtual.hpvm as hpvm
    import ansible.module_utils.facts.virtual.hpnpar as hpnpar
    guest_virt_map = {'hpar': hpar.HParGuest, 'hpvm': hpvm.HPVMGuest, 'hpnpar': hpnpar.HPNParGuest}
    for virt_type in guest_virt_map:
        virtual_facts = guest_virt_map[virt_type]().get_virtual_facts()
        assert virtual_facts['virtualization_type'] == 'guest'
        assert virtual_facts['virtualization_role'] == virt_type
        assert virt_type in virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-23 02:22:14.125212
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Test method get_virtual_facts of class HPUXVirtual.
    """
    from ansible.module_utils import basic
    h = basic.AnsibleModule({})
    h.exit_json = lambda x: x
    h.run_command = lambda x: (0, '', '')
    del os.environ['VIRTUAL_TYPE']
    del os.environ['VIRTUAL_ROLE']
    os.environ['PATH'] = '/usr/sbin:/usr/bin'
    v = HPUXVirtual(h)
    result = v.get_virtual_facts()
    assert not result['virtualization_tech_guest']
    assert not result['virtualization_tech_host']
    os.environ['VIRTUAL_TYPE'] = 'guest'

# Generated at 2022-06-23 02:22:23.817880
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    from ansible.module_utils.facts.virtual.hpux_virtual import HPUXVirtual
    from ansible.module_utils.facts.virtual import Virtual
    from ansible.module_utils.facts import ModuleData
    from ansible.module_utils.facts.virtual import VirtualCollector
    import tempfile
    import os
    import re

    v = HPUXVirtual()

    module = ModuleData('test_module')
    v.module = module

    virtual_role = 'test_virtual_role'
    virtual_type = 'test_virtual_type'
    virtual_facts_expected = {'virtualization_type':'test_virtual_type','virtualization_role':'test_virtual_role'}

    # Test when run_command succeeds

# Generated at 2022-06-23 02:22:31.175225
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import sys
    import unittest
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual

    class TestHPUXVirtualGetVirtualFacts(unittest.TestCase):
        def setUp(self):
            self.hpux = HPUXVirtual()
            sys.modules['hpux'] = self.hpux

        def test_get_virtual_facts_returns_empty_dict_when_no_virtual_techs(self):
            virtual_facts = self.hpux.get_virtual_facts()
            virtual_tech_guest = virtual_facts.get('virtualization_tech_guest')
            virtual_tech_host = virtual_facts.get('virtualization_tech_host')
            virtualization_type = virtual_facts.get('virtualization_type')

# Generated at 2022-06-23 02:22:33.434063
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv._platform == "HP-UX", "Failed to create HP-UX virtual instance"

# Generated at 2022-06-23 02:22:40.014132
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """Test hpux virtual collector."""
    module = AnsibleModule(argument_spec={})
    hpux_virtual = HPUXVirtualCollector(module)
    assert hpux_virtual.platform == 'HP-UX'
    assert hpux_virtual.module == module
    assert hpux_virtual._facts == {}
    assert hpux_virtual._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:22:51.332936
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Test method get_virtual_facts of class HPUXVirtual.
    """
    test_module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=['!all', 'virtual'], type='list'),
            'gather_timeout': dict(default=10, type='int')
        }
    )
    hpux_virtual = HPUXVirtual(module=test_module)
    virtual_facts = hpux_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'host'
    assert virtual_facts['virtualization_role'] == 'HPVM'
    assert virtual_facts['virtualization_tech_host'] == set(['HPVM'])
    assert virtual_facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-23 02:22:53.136337
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual(None)
    assert v.platform == 'HP-UX'


# Generated at 2022-06-23 02:22:57.378387
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual({})
    assert isinstance(h, Virtual)
    assert issubclass(h.__class__, Virtual)

# Generated at 2022-06-23 02:23:07.052559
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.utils import get_file_content
    import json
    import os

    module = "ansible.modules.system.setup"
    filename = os.path.join(os.path.dirname(__file__),
                             'fixtures', 'ansible_test_hpux_virtual.out')
    data = get_file_content(filename)
    facts = json.loads(data)
    print(facts)
    v = HPUXVirtual(module)

    virtual_facts = v.get_virtual_facts()
    assert virtual_facts == {'virtualization_type': 'host',
                             'virtualization_role': 'HPVM',
                             'virtualization_tech_host': set(),
                             'virtualization_tech_guest': set(['HPVM'])}



# Generated at 2022-06-23 02:23:11.111365
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual(None)
    assert h.platform == 'HP-UX'
    assert h.get_virtual_facts() == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}



# Generated at 2022-06-23 02:23:12.662113
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    h = HPUXVirtualCollector()
    assert (h.platform == 'HP-UX' and
            h.fact_class == HPUXVirtual)

# Generated at 2022-06-23 02:23:20.900350
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    v = HPUXVirtual(dict(ansible_facts=dict()))
    v_facts = v.get_virtual_facts()
    assert isinstance(v_facts, dict)
    assert 'virtualization_type' in v_facts
    assert 'virtualization_role' in v_facts
    assert 'virtualization_tech_host' in v_facts
    assert 'virtualization_tech_guest' in v_facts
    assert isinstance(v_facts['virtualization_tech_host'], set)
    assert isinstance(v_facts['virtualization_tech_guest'], set)

# Generated at 2022-06-23 02:23:31.166865
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector

    from mock import patch
    from mock import MockModule

    MockModule.run_command = Mock(return_value=(0, '', ''))
    HPUXVirtualCollector.is_hpux = Mock(return_value=True)
    VirtualCollector.is_s390x = Mock(return_value=False)
    VirtualCollector.is_ia64 = Mock(return_value=False)

# Generated at 2022-06-23 02:23:43.448634
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import os
    import re
    from ansible_collections.ansible.community.plugins.module_utils.facts.virtual.hpux import HPUXVirtual
    mock_ansible_run_command = os.path.dirname(__file__) + '/ansible_run_command'
    os.environ['mock_ansible_run_command'] = mock_ansible_run_command
    myth = HPUXVirtual()
    myth.module = os.path.dirname(__file__) + '/ansible_module_fake'
    facts = myth.get_virtual_facts()
    print(facts)
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP vPar'