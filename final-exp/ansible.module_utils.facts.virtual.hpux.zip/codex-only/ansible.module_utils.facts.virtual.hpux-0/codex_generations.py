

# Generated at 2022-06-23 02:13:47.291046
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    c = HPUXVirtualCollector()
    assert c.__doc__.startswith("This is a HP-UX specific subclass of VirtualCollector")
    assert c._fact_class == HPUXVirtual
    assert c._platform == 'HP-UX'


# Generated at 2022-06-23 02:13:54.184738
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import os
    import tempfile
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual

    result = {
        'virtualization_role': 'HPVM IVM',
        'virtualization_type': 'guest',
        'virtualization_tech_guest': set(['HPVM IVM']),
        'virtualization_tech_host': set()
    }

    # Create temporary directory and temporary file in it
    tmpdir = tempfile.mkdtemp()

    os.mkdir(os.path.join(tmpdir, 'opt/'))
    os.mkdir(os.path.join(tmpdir, 'opt/hpvm'))
    os.mkdir(os.path.join(tmpdir, 'opt/hpvm/bin'))


# Generated at 2022-06-23 02:13:56.619528
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector._fact_class is HPUXVirtual
    assert HPUXVirtualCollector._platform == 'HP-UX'

# Generated at 2022-06-23 02:14:00.974907
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual('module')
    assert h.get_virtual_facts() == {'virtualization_type': 'guest', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set(), 'virtualization_role': 'HP vPar'}

# Generated at 2022-06-23 02:14:13.272781
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    def ModuleMock(*args, **kwargs):
        module = Mock(params=dict())
        return module

    def RunCommandMock(*args, **kwargs):
        cmd = args[0]
        if cmd == "/usr/sbin/vecheck":
            rc = 0
            out = "Running HP vPar"
            err = ""
        elif cmd == "/opt/hpvm/bin/hpvminfo":
            rc = 0
            out = "Running HPVM vPar"
            err = ""
        elif cmd == "/usr/sbin/parstatus":
            rc = 0
            out = "Running HP nPar"
            err = ""
        else:
            rc = -1
            out = ""
            err = ""

        return (rc, out, err)

    module = ModuleMock()

# Generated at 2022-06-23 02:14:16.688906
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(dict())
    assert hpux_virtual._platform == "HP-UX"

# Testing of HPUXVirtualCollector class

# Generated at 2022-06-23 02:14:17.682873
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual(dict())

# Generated at 2022-06-23 02:14:29.219621
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    # Test case 1
    # Test data: no 'vecheck', parstatus and hpvminfo files
    # Expected result:
    #     - virtualization_type and virtualization_role is None
    #     - virtualization_tech_guest and virtualization_tech_host are empty set
    # Test
    virtual = HPUXVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] is None
    assert virtual_facts['virtualization_role'] is None
    assert virtual_facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-23 02:14:32.348613
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = AnsibleModule(argument_spec={})
    virtual_collector = HPUXVirtualCollector(module)
    assert virtual_collector._fact_class.platform == 'HP-UX'


# Generated at 2022-06-23 02:14:36.361609
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtualization = Virtual()
    assert virtualization.platform == 'HP-UX'
    assert virtualization.distribution is None
    assert virtualization.product_name is None
    assert virtualization.virtualization_role is None
    assert virtualization.virtualization_type is None



# Generated at 2022-06-23 02:14:38.872659
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpux_vt_collector = HPUXVirtualCollector(None)
    hpux_vt_collector.collect()
    assert hpux_vt_collector._facts['virtualization_type']

# Generated at 2022-06-23 02:14:42.959284
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual({})
    assert hpux_virtual.platform == 'HP-UX'
    assert hpux_virtual.is_platform_supported() is True


# Generated at 2022-06-23 02:14:50.646278
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    HPUXVirtual - get_virtual_facts() returns a dict
    """
    from ansible.module_utils.facts import ModuleArgsParser
    from ansible.module_utils.facts import Cache
    from ansible.module_utils.facts.collector import get_collector_instance

    args = { 'gather_subset':['!all', 'virtual'] }
    m = ModuleArgsParser.parse(args)
    cache = Cache(m)

    hpux_virtual_facts = {}
    if os.path.exists('/usr/sbin/vecheck'):
        rc, out, err = m.run_command("/usr/sbin/vecheck")
        if rc == 0:
            hpux_virtual_facts['virtualization_type'] = 'guest'

# Generated at 2022-06-23 02:14:51.686106
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()


# Generated at 2022-06-23 02:15:02.686671
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Test case for method get_virtual_facts of class HPUXVirtual
    """
    import ansible.module_utils.facts.virtual.hpux
    class FakeModule(object):
        def run_command(self, cmd):
            if cmd == '/usr/sbin/vecheck':
                return 0, '', ''
            elif cmd == '/opt/hpvm/bin/hpvminfo':
                return 0, 'Running HPVM guest', ''
            elif cmd == '/usr/sbin/parstatus':
                return 0, '', ''
            else:
                AssertionError("Test case for get_virtual_facts does not support run_command with %s", cmd)

    v_obj = HPUXVirtual(FakeModule())

# Generated at 2022-06-23 02:15:10.020321
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Test with fakestdout and fakemod
    from .test_virtual import MockModule
    from .test_virtual import MockStdout

    class MockLinuxModule(MockModule):
        def __new__(cls, *args, **kargs):
            return super(MockLinuxModule,
                         cls).__new__(cls, *args, **kargs)

    class MockLinuxStdout(MockStdout):
        def __new__(cls, *args, **kargs):
            return super(MockLinuxStdout,
                         cls).__new__(cls, *args, **kargs)

    module = MockLinuxModule()
    stdout = MockLinuxStdout()


# Generated at 2022-06-23 02:15:13.313949
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpux_virtual_collector = HPUXVirtualCollector()
    assert isinstance(hpux_virtual_collector, VirtualCollector)



# Generated at 2022-06-23 02:15:15.777805
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    print('Testing get_virtual_facts...')
    v = HPUXVirtual()
    vf = v.get_virtual_facts()
    print(vf)

# Generated at 2022-06-23 02:15:19.206541
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """
    Check FactClass and Platform are set correctly
    """
    obj = HPUXVirtualCollector()
    assert obj.fact_class is HPUXVirtual
    assert obj.platform == 'HP-UX'

# Generated at 2022-06-23 02:15:22.177615
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """
    Create an instance of HPUXVirtualCollector without any arguments
    and without triggering the subclass HPUXVirtual.
    """
    HPUXVirtualCollector()

# Generated at 2022-06-23 02:15:25.241481
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """
    Create an instance of HPUXVirtualCollector to
    check if class constructor is defined properly
    """
    hpux_virtual_col = HPUXVirtualCollector()
    assert hpux_virtual_col

# Generated at 2022-06-23 02:15:27.293503
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-23 02:15:29.180167
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(None)
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-23 02:15:33.984203
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual()
    assert virtual_obj.platform == 'HP-UX'
    assert virtual_obj.type == 'guest'
    assert virtual_obj.role == 'HP vPar'
    assert 'HP vPar' in virtual_obj.guest_tech
    assert 'HPVM vPar' not in virtual_obj.guest_tech

# Generated at 2022-06-23 02:15:35.821397
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(dict())
    assert hv.platform == "HP-UX"

# Generated at 2022-06-23 02:15:38.490225
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virt_collector = HPUXVirtualCollector()
    assert virt_collector._fact_class == HPUXVirtual
    assert virt_collector._platform == 'HP-UX'

# Generated at 2022-06-23 02:15:39.478620
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-23 02:15:41.738793
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpuxv = HPUXVirtual({})
    assert hpuxv.platform == 'HP-UX'

# Generated at 2022-06-23 02:15:49.889530
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    facts = dict()
    module = dict()

    h = HPUXVirtual(module, facts)

    cmd = h.module.run_command
    cmd_out = dict()
    cmd_out[('/usr/sbin/vecheck',)] = (0, '', '')
    cmd_out[('/opt/hpvm/bin/hpvminfo',)] = (0, 'Running under HPVM host', '')
    cmd_out[('/usr/sbin/parstatus',)] = (0, '', '')
    h.module.run_command = lambda *args, **kwargs: cmd_out[(args,)]

    h.get_virtual_facts()
    h.module.run_command = cmd

    assert h.facts['virtualization_type'] == 'host'

# Generated at 2022-06-23 02:15:55.080651
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # Test no parameters
    virtual_obj = HPUXVirtual()
    assert virtual_obj.virtualization_type == ''
    assert virtual_obj.virtualization_role == ''
    assert virtual_obj.virtualization_system == ''
    assert virtual_obj.virtualization_uuid == ''
    assert virtual_obj.virtualization_host_uuid == ''
    assert virtual_obj.virtualization_host_name == ''
    assert virtual_obj.virtualization_product_name == ''
    assert virtual_obj.virtualization_product_version == ''
    assert virtual_obj.virtualization_product_serial == ''

# Generated at 2022-06-23 02:16:06.029513
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible_collections.ansible.community.tests.unit.module_utils._text import to_bytes

    Virtual._module = None

    # Unit test to check virtual_facts for guest.
    fact_file = 'unittest_file_hpx_virtual_guest'
    mc = HPUXVirtual(fact_file=fact_file)
    mc._module = None
    mc.populate()

    virtuals = mc.get_virtual_facts()
    assert virtuals.get('virtualization_type') == 'guest'
    assert 'HP vPar' in virtuals.get('virtualization_tech_guest')

    # Unit test to check virtual_facts for host
    fact_file = 'unittest_file_hpx_virtual_host'

# Generated at 2022-06-23 02:16:10.008747
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = DummyAnsibleModule()
    virtual_collector = HPUXVirtualCollector(module)
    assert virtual_collector._fact_class is HPUXVirtual
    assert virtual_collector._platform is 'HP-UX'


# Generated at 2022-06-23 02:16:18.572890
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Returns UnitTest object to test get_virtual_facts method of
    class HPUXVirtual
    """
    module = AnsibleModuleMock()
    module.run_command = mock.Mock(return_value=(0, 'HPVM guest', ''))
    hpuxvirt = HPUXVirtual(module)

    virtual_facts = {'virtualization_role': 'HPVM IVM',
                     'virtualization_type': 'guest',
                     'virtualization_tech_guest': set(['HPVM IVM']),
                     'virtualization_tech_host': set(['HPVM'])
                     }

    assert virtual_facts == hpuxvirt.get_virtual_facts()



# Generated at 2022-06-23 02:16:20.051033
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector._platform == 'HP-UX'


# Generated at 2022-06-23 02:16:24.912628
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts_dict = HPUXVirtual(None).get_virtual_facts()
    assert 'virtualization_type' in virtual_facts_dict
    assert 'virtualization_role' in virtual_facts_dict
    assert 'virtualization_tech_guest' in virtual_facts_dict
    assert 'virtualization_tech_host' in virtual_facts_dict

# Generated at 2022-06-23 02:16:30.169534
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_facts = HPUXVirtualCollector(None, None, {})
    assert virtual_facts is not None
    assert virtual_facts.platform == 'HP-UX'
    assert virtual_facts.__doc__ == '''This is a HP-UX specific subclass of Virtual. It defines
    - virtualization_type
    - virtualization_role'''
    assert virtual_facts._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:16:37.745556
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    h = HPUXVirtualCollector()
    assert h._fact_class == HPUXVirtual
    assert h._platform == 'HP-UX'
    assert h._virtual_impl == ['NetBSDVirtual', 'LinuxVirtual', 'SunOSVirtual', 'FreeBSDVirtual', 'HPUXVirtual']

# Generated at 2022-06-23 02:16:39.805348
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtfact = HPUXVirtual({})
    assert virtfact.platform == 'HP-UX'

# Generated at 2022-06-23 02:16:44.180688
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpx = HPUXVirtualCollector(None)
    assert isinstance(hpx, VirtualCollector)
    assert hpx._platform == 'HP-UX'
    assert isinstance(hpx._fact_class, HPUXVirtual)



# Generated at 2022-06-23 02:16:48.675934
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import Virtual, HPUXVirtual
    facts_obj = Virtual()
    hpux_virtual_obj = HPUXVirtual()
    hpux_virtual_obj.module = None
    assert hpux_virtual_obj.get_virtual_facts() is None

# Generated at 2022-06-23 02:16:57.226279
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import sys
    import ansible.module_utils.facts.virtual.hpux as hpux
    module = hpux
    module.ANSIBLE_MODULE = "hpux"
    module.ANSIBLE_MODULE_ARGS = None
    module.ANSIBLE_MODULE_CONSTANTS = None

# Generated at 2022-06-23 02:17:08.511872
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    class ModuleMock(object):
        def __init__(self):
            self.run_command_result = [0, "", ""]

        def run_command(self, cmd, check_rc=True):
            return self.run_command_result

    module = ModuleMock()
    virtual = HPUXVirtual(module)

    # Case 1: vecheck does not exist, hpvminfo does not exist, parstatus does not exist
    module.run_command_result = [1, "", ""]
    result = virtual.get_virtual_facts()
    assert result['virtualization_tech_host'] == set()
    assert result['virtualization_tech_guest'] == set()
    assert not 'virtualization_type' in result
    assert not 'virtualization_role' in result

    # Case 2: vecheck exists and

# Generated at 2022-06-23 02:17:18.133991
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    import sys
    # sys.path.insert(0, '../../../../../lib/system')
    # sys.path.insert(0, '../../../../lib/system')
    sys.path.insert(0, '../../../../python/ansible/module_utils/facts/virtual')

    from ansible.module_utils.facts.virtual.hpuxtools.hpvmtools import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpuxtools.hpvmtools import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpuxtools.hpvmtools import VirtualCollector

    import platform
    import os

    class MockModule():
        def run_command(self, cmd):
            return (0, 'out', 'err')


# Generated at 2022-06-23 02:17:21.296207
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual({}, None)
    assert v.platform == 'HP-UX'
    assert v.get_virtual_facts() == {}


# Generated at 2022-06-23 02:17:25.705252
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = type('', (object,), {'run_command': lambda self, cmd: (0, '', '')})
    hpux_vt = HPUXVirtualCollector(module, {})
    assert hpux_vt.platform == HPUXVirtual._platform

# Generated at 2022-06-23 02:17:36.951924
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """Unit test for method get_virtual_facts of class HPUXVirtual"""

    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    hpux_virtual = HPUXVirtual(module)

    # Test with both /usr/sbin/vecheck and /opt/hpvm/bin/hpvminfo
    rc, out, err = module.run_command("/usr/sbin/vecheck")

# Generated at 2022-06-23 02:17:42.848018
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Unit test to get the virtualization facts of hp-ux based systems
    """
    from ansible.module_utils.facts.virtual import VirtualCollector

    collector = VirtualCollector()
    virtual_facts = collector.get_virtual_facts()
    for key in virtual_facts.keys():
        print(key, ': ', virtual_facts[key])


if __name__ == '__main__':
    test_HPUXVirtual_get_virtual_facts()

# Generated at 2022-06-23 02:17:45.098423
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    assert obj.platform == 'HP-UX'
    assert obj._fact_class is HPUXVirtual

# Generated at 2022-06-23 02:17:47.977555
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual()
    assert v.platform == 'HP-UX'


# Generated at 2022-06-23 02:18:00.768600
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import os
    import sys
    import unittest
    import ansible.module_utils.facts.virtual.hpux as hpux_virtual

    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
    from ansible.module_utils.facts import ModuleFactCollector
    from ansible_module_test import DummyModule

    class DummyHPUXVirtual(hpux_virtual.HPUXVirtual):
        '''
        Dummy class that can be used as a consequence of invoking
        hpux_virtual.HPUXVirtual() instead of the real class. This
        overrides some methods to test get_virtual_facts() of class
        HPUXVirtual() only.
        '''

        def get_virtual_facts(self):
            self.module

# Generated at 2022-06-23 02:18:03.298618
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv._fact_class is HPUXVirtual
    assert hv._platform == 'HP-UX'

# Generated at 2022-06-23 02:18:15.524594
# Unit test for method get_virtual_facts of class HPUXVirtual

# Generated at 2022-06-23 02:18:18.760138
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual({})
    assert virtual_obj.platform == 'HP-UX'


# Generated at 2022-06-23 02:18:27.002163
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = AnsibleModule(argument_spec=dict())
    virtual_collector = HPUXVirtual(module)
    facts = virtual_collector.collect()
    assert isinstance(facts, dict)
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP vPar'
    assert facts['virtualization_role'] == 'HP vPar'
    assert isinstance(facts['virtualization_tech_host'], set)
    assert isinstance(facts['virtualization_tech_guest'], set)

# Generated at 2022-06-23 02:18:32.560222
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    This method test the get_virtual_facts method of HPUXVirtual class for
    different scenarios
    """
    virtual_facts = {"virtualization_type": 'guest',
                     "virtualization_role": 'HP nPar'}
    hpux_virtual = HPUXVirtual({}, "", "", False)

    hpux_virtual.module.run_command = mock_run_command

    hpux_virtual.get_virtual_facts()

    assert hpux_virtual.facts == virtual_facts



# Generated at 2022-06-23 02:18:37.343863
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    # Assure that the class can be initialized
    HPUXVirtualCollector()

# Generated at 2022-06-23 02:18:44.365321
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """Check the constructor of the class HPUXVirtualCollector"""
    # pylint: disable=protected-access
    assert HPUXVirtualCollector._platform == 'HP-UX',\
        'The _platform should be HP-UX'
    assert HPUXVirtualCollector._fact_class == HPUXVirtual,\
        'The _fact_class should be HPUXVirtual'


# Generated at 2022-06-23 02:18:46.511949
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """
    Constructor test HPUXVirtualCollector
    """
    result = HPUXVirtualCollector()
    assert result._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:18:48.118232
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector()
    assert collector.platform == 'HP-UX'

# Generated at 2022-06-23 02:18:50.039011
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    x = HPUXVirtual({})
    print(x.get_virtual_facts())


# Generated at 2022-06-23 02:18:51.654743
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual()
    assert virtual.platform == 'HP-UX'


# Generated at 2022-06-23 02:19:02.503718
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    current_directory = os.path.dirname(os.path.realpath(__file__))

    # Mock module_utils.facts.virtual.base.AnsibleModule
    from ansible.module_utils.facts import virtual
    virtual.AnsibleModule = MockAnsibleModule

    # Mock module_utils.facts.virtual.base.os
    virtual.os = MockOs

    # Mock module_utils.facts.virtual.base.os.path
    virtual.os.path = MockOsPath

    import ansible.module_utils.facts.virtual.hpux
    facts_instance = ansible.module_utils.facts.virtual.hpux.HPUXVirtual(module=MockAnsibleModule)
    virtual_facts = facts_instance.get_virtual_facts()


# Generated at 2022-06-23 02:19:11.260555
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """Test get_virtual_facts method of HPUXVirtual class"""
    class ModuleStub(object):
        def run_command(self_, cmd, check_rc=True):
            return (0, 'a', 'b')

    module = ModuleStub()
    collector = HPUXVirtual(module)
    virtual_facts = collector.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'

    # Test when vecheck does not exist.
    class ModuleStub2(object):
        def run_command(self_, cmd, check_rc=True):
            return (1, 'a', 'b')

    module = ModuleStub2()
    collector = HPUXVirtual(module)
    virtual_facts

# Generated at 2022-06-23 02:19:20.539186
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = type('Module', (object,), {})()
    module.run_command = type('RunCommand', (object,), {})()
    module.run_command.return_value = (0, '', '')
    hv = HPUXVirtual(module)
    facts = hv.collect()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP vPar'
    assert facts['virtualization_tech_guest'] == {'HP vPar'}
    assert facts['virtualization_tech_host'] == set()


# Generated at 2022-06-23 02:19:22.668120
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual({}, {})
    assert h is not None


# Generated at 2022-06-23 02:19:28.194816
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    my_HPUXVirtualCollector = HPUXVirtualCollector('module_name', 'module_args')
    assert my_HPUXVirtualCollector.module_name == 'module_name'
    assert my_HPUXVirtualCollector.module_args == 'module_args'
    assert my_HPUXVirtualCollector._platform == 'HP-UX'

# Generated at 2022-06-23 02:19:38.164428
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import Virtual, HPUXVirtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux_virtual import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpvm_virtual import HPVMVirtualCollector
    from ansible.module_utils.facts.virtual.hpux_virtual import HPUXVirtual
    HPUXVirtual._module = _mock_module
    f = HPUXVirtual()
    f.get_virtual_facts()
    assert f.facts == {'virtualization_tech_host': set(['HPVM']), 'virtualization_tech_guest': set(['HPVM'])}


# Generated at 2022-06-23 02:19:41.934322
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    arg = {}
    module = HPUXVirtualCollector._get_module(arg)
    assert isinstance(module, HPUXVirtual)
    assert module.module.params == arg
    assert module.module._name == 'ansible_HP-UX_facts'

# Generated at 2022-06-23 02:19:50.976163
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import FactCollector

    facts = FactCollector()
    hpxv = HPUXVirtual(facts)

    class ModuleMock:
        def run_command(self, cmd):
            return (0, 'test_stdout', 'test_stderr')
    hpxv.module = ModuleMock()
    os.path.exists = lambda path: True

    # test hp vpar
    assert hpxv.get_virtual_facts() == {'virtualization_type': 'guest', 'virtualization_role': 'HP vPar',
                                        'virtualization_tech_host': set(), 'virtualization_tech_guest': set(['HP vPar'])}

    # test hpvm vpar

# Generated at 2022-06-23 02:19:53.263453
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert issubclass(HPUXVirtualCollector, VirtualCollector)

# Generated at 2022-06-23 02:19:56.043090
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert x.platform == 'HP-UX'
    assert x._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:20:00.556132
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = None
    virtual_facts_HPUX = HPUXVirtual(module).get_virtual_facts()
    assert virtual_facts_HPUX['virtualization_tech_guest'] == virtual_facts_HPUX['virtualization_tech_host']

# Generated at 2022-06-23 02:20:02.574767
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector()
    assert collector.platform == 'HP-UX'
    assert collector._fact_class is HPUXVirtual

# Generated at 2022-06-23 02:20:12.023992
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    '''
    This is a unit test for the method get_virtual_facts of the class HPUXVirtual.
    '''
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    import os
    import re


# Generated at 2022-06-23 02:20:14.388812
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv is not None


# Generated at 2022-06-23 02:20:25.776428
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import tempfile
    from ansible.module_utils.facts import _shared_loader_obj
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector

    # Create a temporary directory to test HPUXVirtualCollector
    fact_class_dir = tempfile.mkdtemp()

    # Get HPUXVirtualCollector into a sub class
    class CollectorSubClass(HPUXVirtualCollector):
        _fact_class_dir = fact_class_dir

    # Populate collected_regex with a fake virtualization_tech_guest name

# Generated at 2022-06-23 02:20:38.440197
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import HPUXVirtual as HPV
    from ansible.module_utils.facts.virtual.base import Virtual
    import os
    import mock

    class Module(object):
        def __init__(self):
            self.run_command = mock.Mock(return_value=(0, 'test', ''))

    def run_command(command):
        if command == '/usr/sbin/vecheck':
            return (0, 'test', '')
        elif command == '/opt/hpvm/bin/hpvminfo':
            return (0, 'test', '')
        elif command == '/usr/sbin/parstatus':
            return (0, 'test', '')


# Generated at 2022-06-23 02:20:52.678911
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class HPUXVirtual
    """
    import os
    import shutil
    import tempfile

    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector

    facts = {}
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-23 02:20:58.144122
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(None)
    assert isinstance(hv, Virtual)

    assert hv.platform == 'HP-UX'

    assert hv.get_virtual_facts() == {'virtualization_role': '', 'virtualization_type': 'guest',
                                      'virtualization_tech_guest': set(),
                                      'virtualization_tech_host': set()}

# Generated at 2022-06-23 02:21:02.175559
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    ''' Unit test for constructor of class HPUXVirtualCollector '''
    HPUXVirtualCollector()


# Generated at 2022-06-23 02:21:03.843011
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    assert obj.platform == 'HP-UX'
    assert obj.fact_class == HPUXVirtual

# Generated at 2022-06-23 02:21:07.485641
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpu = HPUXVirtualCollector()
    assert hpu.platform == 'HP-UX'
    assert hpu._platform == 'HP-UX'
    assert hpu._fact_class.platform == 'HP-UX'

# Generated at 2022-06-23 02:21:18.444676
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    virtual_facts = {'virtualization_type': '',
                     'virtualization_role': '',
                     'virtualization_tech_guest': set(),
                     'virtualization_tech_host': set()}
    hw = HPUXVirtual(dict(module=None), virtual_facts)
    virtual_facts = hw.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts, "virtualization_type should be in virtual_facts"
    assert 'virtualization_role' in virtual_facts, "virtualization_role should be in virtual_facts"
    assert 'virtualization_tech_guest' in virtual_facts, "virtualization_tech_guest should be in virtual_facts"
    assert 'virtualization_tech_host' in virtual_facts, "virtualization_tech_host should be in virtual_facts"

# Generated at 2022-06-23 02:21:20.777274
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-23 02:21:21.629390
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-23 02:21:32.352857
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import sys, imp, os
    sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../../'))
    from ansible.module_utils.facts.virtual.hpux.hpux import HPUXVirtual
    test_vect = HPUXVirtual()
    test_vect.module = DummyAnsibleModule()
    test_vect.module.run_command = DummyRunCommand()
    test_vect.module.run_command.result = {}
    test_vect.module.run_command.result[0] = ("/usr/sbin/vecheck", "", 0)

# Generated at 2022-06-23 02:21:35.776388
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpxvc = HPUXVirtualCollector()
    assert hpxvc.platform == 'HP-UX'
    assert hpxvc.fact_class == HPUXVirtual

# Generated at 2022-06-23 02:21:36.880739
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict())
    assert virtual.platform == 'HP-UX'

# Generated at 2022-06-23 02:21:46.304884
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    collector.collect_only = True
    hpux_virtual = HPUXVirtual(module)
    assert 'HP' in hpux_virtual.get_virtual_facts()['virtualization_role']
    assert 'host' in hpux_virtual.get_virtual_facts()['virtualization_type']
    assert 'HPVM vPar' in hpux_virtual.get_virtual_facts()['virtualization_tech_guest']

# Generated at 2022-06-23 02:21:49.044681
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    facts = {}
    virtual = HPUXVirtual(facts, None)
    assert virtual.platform == 'HP-UX'
    assert virtual._platform == 'HP-UX'


# Generated at 2022-06-23 02:21:53.055571
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    my_HPUXVirtualCollector = HPUXVirtualCollector()
    assert my_HPUXVirtualCollector._platform == "HP-UX"
    assert my_HPUXVirtualCollector._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:21:58.859486
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv1 = HPUXVirtual({})
    assert hv1.data['virtualization_type'] == 'host'
    assert hv1.data['virtualization_role'] == ''
    assert hv1.data['virtualization_tech_host'] == set()
    assert hv1.data['virtualization_tech_guest'] == set()

# Generated at 2022-06-23 02:22:02.597722
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """Unit test for constructor of class HPUXVirtualCollector"""
    hpux_virtual_collector = HPUXVirtualCollector()
    assert hpux_virtual_collector._platform == 'HP-UX'
    assert isinstance(hpux_virtual_collector._fact_class(), HPUXVirtual)


# Generated at 2022-06-23 02:22:04.278683
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict(), dict())
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-23 02:22:06.574541
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    test_object = HPUXVirtual(dict())
    assert test_object
    assert type(test_object) is HPUXVirtual

# Generated at 2022-06-23 02:22:09.111266
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert isinstance(HPUXVirtual(), Virtual)


# Generated at 2022-06-23 02:22:20.155638
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    v = HPUXVirtual(BaseFactCollector())
    vm_facts = v.get_virtual_facts()
    assert 'virtualization_type' in vm_facts
    assert vm_facts['virtualization_type'] == 'guest'
    assert 'virtualization_role' in vm_facts
    assert vm_facts['virtualization_role'] == 'HP vPar'
    assert 'virtualization_tech_guest' in vm_facts
    assert 'virtualization_tech_host' in vm_facts

# Generated at 2022-06-23 02:22:28.032165
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import ansible_hpux_virtual_facts.module_utils.facts.virtual.hpux

    # instantiate a module
    module = FakeAnsibleModule()

    # instantiate HPUXVirtual object
    hpux_virtual_obj = ansible_hpux_virtual_facts.module_utils.facts.virtual.hpux.HPUXVirtual(module)

    # create an empty dictionary to contain the facts
    hpux_virtual_facts = {}

    hpux_virtual_obj.get_virtual_facts()
    if hpux_virtual_obj.virtual_facts is not None:
        hpux_virtual_facts = hpux_virtual_obj.virtual_facts

    return hpux_virtual_facts


# Generated at 2022-06-23 02:22:30.725664
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert x._platform == 'HP-UX'
    assert x._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:22:31.774706
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-23 02:22:42.093756
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = type('FakeModule', (), {})()
    module.run_command = type('DummyRunCommand', (), {'return_value': (0, '', '')})
    module.get_bin_path = type('DummyGetBinPath', (), {'return_value': '/usr/sbin/vecheck'})
    facts = HPUXVirtual(module, [])
    virtual_facts = facts.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    assert 'HP vPar' in virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-23 02:22:44.899891
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert x._platform == 'HP-UX'
    assert x._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:22:48.529531
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    hpuxvirtual = HPUXVirtual()

    facts = hpuxvirtual.get_virtual_facts()

    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-23 02:22:49.630569
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual()

# Generated at 2022-06-23 02:22:59.592546
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual

    hpux_virtual = HPUXVirtual()

    facts = {'virtualization_tech_guest': set(),
             'virtualization_tech_host': set(),
             'virtualization_type': {},
             'virtualization_role': {},
             'virtualization_system': {},
             'virtualization_hypervisor': {}}

    #
    # Test for VPar
    #
    hpux_virtual.module.run_command = \
        lambda *args, **kwargs: (0, 'Running HP vPar vPars using 2.0.0', '')
    result = hpux_virtual.get_virtual_facts()
    assert result['virtualization_type'] == 'guest'

# Generated at 2022-06-23 02:23:00.571698
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    hpuvirtual = HPUXVirtual()

# Generated at 2022-06-23 02:23:05.648147
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(dict(module=None))
    assert hpux_virtual.platform == 'HP-UX'
    assert hpux_virtual.get_virtual_facts() == {'virtualization_type': 'host'}


# Generated at 2022-06-23 02:23:08.176041
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual()
    if (h.platform != 'HP-UX'):
        raise AssertionError('h.platform != HP-UX')

# Generated at 2022-06-23 02:23:10.337679
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual(dict())
    assert h.platform == 'HP-UX'



# Generated at 2022-06-23 02:23:12.922029
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-23 02:23:18.609872
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    vdata = {}
    hpu = HPUXVirtual(vdata)
    assert vdata['virtualization_type'] == "guest"
    assert vdata['virtualization_role'] == "HP nPar"
    assert vdata['virtualization_tech_guest'] == set(['HP nPar'])
    assert vdata['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:23:29.579376
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import sys

    class TestModule():
        def run_command(self, cmd):
            if cmd == '/usr/sbin/vecheck':
                return (0, '', '')
            if cmd == '/opt/hpvm/bin/hpvminfo':
                return (0, 'Running HPVM vPar', '')
            if cmd == '/usr/sbin/parstatus':
                return (0, '', '')
            return (0, '', '')
    testmodule = TestModule()

    testhpxv = HPUXVirtual(testmodule)
    testhpxvfacts = testhpxv.get_virtual_facts()
    guest_technologies = testhpxvfacts['virtualization_tech_guest']
    host_technologies = testhpxvfacts['virtualization_tech_host']

# Generated at 2022-06-23 02:23:41.421485
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    module.run_command.side_effect = [
        (0, '', ''),
        (1, 'Running on an HPVM vPar', ''),
        (0, 'Running on an HPVM guest', ''),
        (1, 'Running on an HPVM host', ''),
        (0, '', '')
    ]
    virtual_facts = HPUXVirtual(module).get_virtual_facts()
    assert virtual_facts['ansible_virtualization_type'] == 'guest'
    assert virtual_facts['ansible_virtualization_role'] == 'HPVM IVM'
    assert 'HPVM' in virtual_facts['ansible_virtualization_tech_guest']
    assert 'HPVM vPar' in virtual_facts['ansible_virtualization_tech_guest']


# Generated at 2022-06-23 02:23:43.602994
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux = HPUXVirtual(dict())
    assert hpux.platform == "HP-UX"