

# Generated at 2022-06-23 02:13:42.195183
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-23 02:13:45.210305
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-23 02:13:50.547963
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hvm_virtual_collector = HPUXVirtualCollector()
    assert hvm_virtual_collector._platform == 'HP-UX'

# Generated at 2022-06-23 02:13:56.424070
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual({})
    assert virtual_obj.platform == "HP-UX"
    assert virtual_obj.get_virtual_facts() == {'virtualization_tech_guest': set(),
                                               'virtualization_tech_host': set(),
                                               'virtualization_type': '',
                                               'virtualization_role': ''}


# Generated at 2022-06-23 02:14:00.395137
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    data = {}
    shared_module_params = {}
    hpux_virtual_obj = HPUXVirtual(data, shared_module_params)
    assert hpux_virtual_obj.platform == "HP-UX"


# Generated at 2022-06-23 02:14:03.719755
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vc = HPUXVirtualCollector(None)
    assert vc._platform == 'HP-UX'
    assert vc._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:14:07.048541
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    # Create a new class, so we can clear the caches
    collector = HPUXVirtualCollector()
    assert isinstance(collector, HPUXVirtualCollector)

# Generated at 2022-06-23 02:14:09.423539
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv._fact_class == HPUXVirtual
    assert hv._platform == 'HP-UX'

# Generated at 2022-06-23 02:14:10.925800
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(None)
    assert virtual.platform == 'HP-UX'

# Generated at 2022-06-23 02:14:13.735998
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux = HPUXVirtual()
    assert hpux.platform == 'HP-UX'


# Generated at 2022-06-23 02:14:17.201940
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    args = dict(
        gather_subset=['all'],
    )
    HPUXVirtualCollector(module=None, facts=None, args=args)

# Generated at 2022-06-23 02:14:19.702761
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hu = HPUXVirtual()
    assert hu.platform == 'HP-UX'

# Generated at 2022-06-23 02:14:23.668252
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = AnsibleModule(argument_spec={})
    vm = HPUXVirtual(module)
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    assert isinstance(vm, HPUXVirtual)
    assert vm.platform == 'HP-UX'

# Generated at 2022-06-23 02:14:29.314819
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual({})
    assert virtual.platform == 'HP-UX'
    assert virtual.command() is None
    assert virtual.exists() is False
    assert virtual.guest_tech() == []
    assert virtual.host_tech() == []
    assert virtual.role() is None
    assert virtual.type() is None

# Generated at 2022-06-23 02:14:32.089311
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vc = HPUXVirtualCollector()
    assert vc.platform == 'HP-UX'
    assert vc._fact_class.platform == 'HP-UX'

# Generated at 2022-06-23 02:14:41.301512
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Test the get_virtual_facts method of class HPUXVirtual
    """
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.base import MockModule
    from ansible.module_utils.facts.virtual.base import MockSubprocess
    from ansible.module_utils.facts.virtual.base import MockFile
    from ansible.module_utils.facts.virtual.base import MockPersistentDict
    from ansible.module_utils.facts.virtual.base import MockCPUInfo

    def mock_init(self, module):
        self._module = module
        self._cpuinfo = MockCPUInfo([])
        return

    hv = H

# Generated at 2022-06-23 02:14:50.120732
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # VirtualCollector object
    virtual = HPUXVirtual()
    # Virtual object
    virt = HPUXVirtual()
    # Test vPar
    virt.module.run_command = lambda x: (0, '', '')
    virtual_facts = virt.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    assert virtual_facts['virtualization_tech_guest'] == set(['HP vPar'])
    # Test nPar
    virt.module.run_command = lambda x: (0, '', '')
    virtual_facts = virt.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'

# Generated at 2022-06-23 02:14:51.870492
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.virtualization_type == ''
    assert hv.virtualization_role == ''

# Generated at 2022-06-23 02:15:02.904659
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    module_mock = Mock()
    virtual_mock = HPUXVirtual(module_mock)

    # Case 1: Both parstatus and vecheck exist
    module_mock.run_command.return_value = 0, 'HPUX', ''
    virtual_mock.module = module_mock
    with patch('os.path.exists', return_value = True):
        virtual_facts = virtual_mock.get_virtual_facts()
        assert_equals(virtual_facts['virtualization_type'], 'guest')
        assert_equals(virtual_facts['virtualization_role'], 'HP nPar')

# Generated at 2022-06-23 02:15:04.725862
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    # instantiate an object of HPUXVirtualCollector
    ins = HPUXVirtualCollector()
    assert ins._platform == 'HP-UX'

# Generated at 2022-06-23 02:15:07.396869
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert(hv._fact_class == HPUXVirtual)
    assert(hv._platform == 'HP-UX')

# Generated at 2022-06-23 02:15:09.306574
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    try:
        hv = HPUXVirtual(dict())
    except:
        pass



# Generated at 2022-06-23 02:15:18.579809
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    from ansible.module_utils._text import to_bytes

    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # Get HPUXVirtual virtual facts
    hpux_virtual_facts = HPUXVirtual(module).get_virtual_facts()
    assert hpux_virtual_facts['virtualization_type'] == 'guest'
    assert hpux_virtual_facts['virtualization_role'] == 'HP nPar'
    assert hpux_virtual_facts['virtualization_tech_guest'] == {'HP nPar'}
    assert hpux_virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:15:23.617066
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    class args():
        pass

    argobj = args()
    argobj.module = ''
    obj = HPUXVirtualCollector(argobj)
    assert obj.platform == 'HP-UX'
    assert obj.fact_class is HPUXVirtual
    assert obj.fact_class._platform == 'HP-UX'


# Generated at 2022-06-23 02:15:26.154104
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    v = HPUXVirtualCollector()
    assert v._platform == 'HP-UX'
    assert v._fact_class._platform == 'HP-UX'

# Generated at 2022-06-23 02:15:34.171280
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    import os
    import unittest

    class FakeModuleRunningCommandSuccess(object):
        def run_command(self, cmd):
            out = '/usr/sbin/vecheck\n/opt/hpvm/bin/hpvminfo\n/usr/sbin/parstatus'
            return 0, out, ''

    class FakeModuleRunningCommandFail(object):
        def run_command(self, cmd):
            return -1, '', ''

    class FakeModuleRunningCommandFailWarn(object):
        def run_command(self, cmd):
            return -1, '', 'Warning:  Failed to determine hardware.'


# Generated at 2022-06-23 02:15:44.592714
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import ModuleTestCase
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    import mock

    module = ModuleTestCase.make_module()
    hpux_virtual = HPUXVirtual(module)

    def run_command(cmd, check_rc=True):
        if cmd.startswith("/usr/sbin/parstatus"):
            return 0, "", ""
        elif cmd.startswith("/usr/sbin/vecheck"):
            return 0, "", ""
        elif cmd.startswith("/opt/hpvm/bin/hpvminfo"):
            return 0, "Virtual machine Running, HPVM guest\n", ""
        return 1, "", ""


# Generated at 2022-06-23 02:15:46.401550
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpuxvirtual = HPUXVirtual()
    assert hpuxvirtual.platform == 'HP-UX'

# Generated at 2022-06-23 02:15:56.060947
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    class ModuleStub:
        def __init__(self):
            self.run_command_calls = 0

        def run_command(self, cmd):
            self.run_command_calls += 1
            if cmd == '/usr/sbin/vecheck':
                return 0, '', ''
            elif cmd == '/opt/hpvm/bin/hpvminfo':
                if self.run_command_calls == 3:
                    return 0, 'running on HPVM guest', ''
                elif self.run_command_calls == 2:
                    return 0, 'running on HPVM host', ''
                elif self.run_command_calls == 1:
                    return 0, 'running on HPVM vPar', ''
            elif cmd == '/usr/sbin/parstatus':
                return 0, '', ''



# Generated at 2022-06-23 02:15:58.326005
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtual()
    assert isinstance(obj, Virtual)
    assert obj.platform == 'HP-UX'

# Generated at 2022-06-23 02:16:02.549563
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = FakeAnsibleModule()
    hv = HPUXVirtual(module)
    assert hv
    assert hv.module == module
    assert isinstance(hv.virtual_facts, dict)
    assert hv.platform == 'HP-UX'



# Generated at 2022-06-23 02:16:11.201556
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    test_class = HPUXVirtual(dict(module=dict(run_command=run_command)))

    # set up vecheck output
    test_class.module.run_command.run_command_envs = [{"PATH": "/usr/sbin"}, {"PATH": ""}]
    test_class.module.run_command.commands = ["/usr/sbin/vecheck"]
    test_class.module.run_command.rcs = [0]
    test_class.module.run_command.stdouts = ["""System virtualization status:
 Virtual Partition is currently running as a guest on this system.
"""]
    test_class.module.run_command.stderrs = [""]
    if 'virtualization_type' in test_class.get_virtual_facts():
        assert test_class.get_virtual_facts

# Generated at 2022-06-23 02:16:16.626025
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    facts = {'ANSIBLE_MODULE_ARGS': {}}
    hux_virtual_collector = HPUXVirtualCollector(facts, None)
    assert hux_virtual_collector._platform == 'HP-UX'
    assert hux_virtual_collector._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:16:27.324536
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
   # This test should return a dict with all values set to None
   # since the arguments of Virtual class are empty
    test_module = AnsibleModule(
        argument_spec = dict()
    )
    test_HPUXVirtual = HPUXVirtual(module=test_module)
    virtual_facts = test_HPUXVirtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    assert virtual_facts['virtualization_tech_guest'] == {'HP vPar'}
    assert 'HPVM vPar' not in virtual_facts['virtualization_tech_guest']
    assert 'HPVM IVM' not in virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-23 02:16:38.046061
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # Test case with virtualization_type and virtualization_role
    virtual_facts = {'virtualization_type': 'guest',
                     'virtualization_role': 'HP vPar'}
    v = HPUXVirtual(virtual_facts, {})
    assert v.virtualization_type == 'guest'
    assert v.virtualization_role == 'HP vPar'
    assert v.virtualization_tech == {'HP vPar'}

    # Test case without virtualization_type and virtualization_role
    virtual_facts = {}
    v = HPUXVirtual(virtual_facts, {})
    assert v.virtualization_type is None
    assert v.virtualization_role is None
    assert v.virtualization_tech == set()



# Generated at 2022-06-23 02:16:43.651127
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    vm = HPUXVirtual()
    vm.module = AnsibleModule(argument_spec={})
    vm._run_command = lambda x: x
    vm.module.run_command = lambda x: x
    vm.get_virtual_facts()['virtualization_tech_guest'] == 'guest'

# Generated at 2022-06-23 02:16:54.157106
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class HPUXVirtual
    """
    #  Testing with vecheck, hpvminfo and parstatus present
    class MockModule(object):
        def __init__(self):
            self.run_command_count = 0
            self.run_command_args = []
        def run_command(self, args):
            self.run_command_count += 1
            self.run_command_args.append(args)
            if self.run_command_count == 1:
                return (0, 'parsed output of vecheck', '')
            elif self.run_command_count == 2:
                return (0, 'parsed output of hpvminfo', '')

# Generated at 2022-06-23 02:16:57.785872
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert virtual_collector._fact_class == HPUXVirtual
    assert virtual_collector._platform == 'HP-UX'

# Generated at 2022-06-23 02:17:01.010618
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    fact_class = HPUXVirtualCollector()
    assert fact_class._platform == 'HP-UX'
    assert fact_class._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:17:02.606196
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual(dict())
    assert h.platform == 'HP-UX'

# Generated at 2022-06-23 02:17:05.996931
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert isinstance(hv, HPUXVirtualCollector)
    assert isinstance(hv._fact_class, HPUXVirtual)

# Generated at 2022-06-23 02:17:10.457348
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """Creating an instance of HPUXVirtual without arguments
       should populate virtualization_type and virtualization_role
       with right values."""
    test_virtual = HPUXVirtual()
    assert test_virtual.virtualization_type == 'host'
    assert test_virtual.virtualization_role == ''


# Generated at 2022-06-23 02:17:12.683316
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector()
    assert collector._fact_class == HPUXVirtual
    assert collector._platform == 'HP-UX'

# Generated at 2022-06-23 02:17:18.860472
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    _module = mock.MagicMock(
        changed=False,
        check_mode=False,
        run_command=mock.MagicMock(side_effect=[(0, "", ""),(0, "Running HPVM vPar", ""),(0, "Running HPVM guest", ""),
            (0, "Running HPVM host", ""),(0, "", "")]),
    )
    _module.params = {}
    _module.exit_json = mock.MagicMock()

    _virtual_collector = HPUXVirtual(_module)
    _virtual_collector.get_virtual_facts()

# Generated at 2022-06-23 02:17:22.884069
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual({}, None)
    assert virtual
    assert virtual.platform == 'HP-UX'
    assert virtual.get_virtual_facts()['virtualization_role'] == 'HP nPar'


# Generated at 2022-06-23 02:17:27.469434
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    '''
    Unit test for constructor of class HPUXVirtualCollector
    '''
    collector = HPUXVirtualCollector()
    assert collector._platform == "HP-UX"
    assert isinstance(collector._facts['virtual_facts'], HPUXVirtual)


# Generated at 2022-06-23 02:17:41.189479
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModuleMock({})
    virtual_facts = {}

    hv = HPUXVirtual(module)

    rc = 1
    out = ""
    err = "/usr/sbin/vecheck: not found."

    hv.module.run_command.return_value = rc, out, err
    virtual_facts = hv.get_virtual_facts()

    assert 'virtualization_role' not in virtual_facts
    assert 'virtualization_type' not in virtual_facts

    rc = 0
    out = "Running HPVM guest"
    err = ""

    hv.module.run_command.return_value = rc, out, err
    virtual_facts = hv.get_virtual_facts()

    assert virtual_facts['virtualization_role'] == 'HPVM IVM'

# Generated at 2022-06-23 02:17:52.021869
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    import inspect
    module = VirtualCollector
    current_dir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    print('current directory:' + current_dir)
    module_path = os.path.join(current_dir, '../../../lib/ansible/module_utils/facts/virtual/hpux.py')
    hpux = __import__('hpux', globals(), locals(), ['HPUXVirtualCollector'], 0) # type: hpux
    loader = inspect.getmodule(hpux)

    vc = hpux.HPUXVirtualCollector(loader, module_path, {}, {}, '')
    assert isinstance(vc, hpux.HPUXVirtualCollector)
    vc.collect()

# Generated at 2022-06-23 02:17:55.450338
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v_class_obj = HPUXVirtual()
    assert v_class_obj._platform == 'HP-UX'
    assert v_class_obj.platform == 'HP-UX'


# Generated at 2022-06-23 02:18:05.791002
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible_collections.ciscodevnet.ansible_dnac.tests.unit.compat.mock import patch, MagicMock
    from ansible_collections.ciscodevnet.ansible_dnac.plugins.module_utils import facts

    try:
        import hpuxfacts
    except ImportError:
        hpuxfacts = None
    if hpuxfacts is None:
        hpuxfacts = MagicMock()
    hpuxfacts.facts = MagicMock()

    # All tests for HP-UX should be in the context manager below
    with patch.dict(facts.HP_UX_FACTS, {}, clear=True):
        facts.HP_UX_FACTS['virtualization_type'] = 'physical'
        hpux_virtual = HPUXVirtual(module=MagicMock())
        hpux

# Generated at 2022-06-23 02:18:14.380741
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    from ansible.module_utils.facts.virtual.hpar import HPARVirtual
    from ansible.module_utils.facts.virtual.hpvm import HPVMVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector

    vc = HPUXVirtualCollector(None, None, None)
    assert vc is not None

    vc = HPUXVirtualCollector(HPARVirtual, HPVMVirtual, None)
    assert vc is not None


# Generated at 2022-06-23 02:18:15.947348
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    test_class = HPUXVirtual()
    assert test_class.platform == 'HP-UX'


# Generated at 2022-06-23 02:18:20.090563
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    facts = dict()
    test = HPUXVirtualCollector(facts, None)
    assert test._fact_class is HPUXVirtual
    assert test._platform == 'HP-UX'

# Generated at 2022-06-23 02:18:21.583005
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert isinstance(HPUXVirtualCollector(), VirtualCollector)

# Generated at 2022-06-23 02:18:23.346473
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    # the constructor should just work and not raise any exception
    HPUXVirtualCollector()

# Generated at 2022-06-23 02:18:32.018033
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec={}
    )

    # Mock the HPUXVirtual class
    HPUXVirtualMock = mock.MagicMock(spec=HPUXVirtual)
    HPUXVirtualMock.platform = 'HP-UX'

    # Mock the subprocess.Popen class
    module.run_command = mock.MagicMock()

    # Mock module.run_command return values
    module.run_command.return_value = (0, 'Running as HPVM guest.', '')

    # Create a instance of HPUXVirtualMock and call the get_virtual_facts
    hpuxvirtual_obj = HPUXVirtualMock(module)
    virtual_facts = hpuxvirtual_obj.get_virtual_facts()

    # Verify return data
    module.run_command.assert_any

# Generated at 2022-06-23 02:18:40.698532
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts._platform == 'HP-UX'
    assert virtual_facts.virtualization_type == 'guest'
    assert virtual_facts.virtualization_role == 'HPVM IVM'
    assert 'HPVM IVM' in virtual_facts.virtualization_tech_guest
    assert len(virtual_facts.virtualization_tech_host) == 0


# Generated at 2022-06-23 02:18:44.119345
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    facts = HPUXVirtualCollector()
    assert isinstance(facts, VirtualCollector)
    assert facts._platform == 'HP-UX'
    assert isinstance(facts._fact_class, HPUXVirtual)


# Generated at 2022-06-23 02:18:52.635189
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = None
    result = {'virtualization_type': 'guest', 'virtualization_role': 'HP nPar',
              'virtualization_tech_guest': set(['HP nPar']),
              'virtualization_tech_host': set([])}
    hpux_virtual = HPUXVirtual(module)
    hpux_virtual.module.run_command = lambda *args, **kwargs: (0, '', '')
    hpux_virtual.module.run_command = fake_run_command
    assert hpux_virtual.get_virtual_facts() == result



# Generated at 2022-06-23 02:18:59.533976
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    hpux_virtual = HPUXVirtual()
    facts = hpux_virtual.get_virtual_facts()
    assert dict == facts.__class__
    assert 5 == len(facts)
    assert 'virtualization_type' in facts.keys()
    assert 'virtualization_role' in facts.keys()
    assert 'virtualization_tech_guest' in facts.keys()
    assert 'virtualization_tech_host' in facts.keys()
    assert 'virtualization_type' in facts.keys()
    assert 'virtualization_type' in facts.keys()

# Generated at 2022-06-23 02:19:00.997303
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual(dict())
    assert v.platform == 'HP-UX'

# Generated at 2022-06-23 02:19:10.894268
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    data = dict(
        ansible_facts={
            'ansible_processor_cores': '2',
            'ansible_processor_count': '2',
            'ansible_processor_threads_per_core': '2',
            'ansible_processor_vcpus': '4'
        }
    )
    set_module_args(data)
    my_obj = HPUXVirtual()
    my_obj.setup()
    my_obj.populate()
    result = my_obj.get_virtual_facts()
    assert result['virtualization_type'] == 'guest'
    assert result['virtualization_role'] == 'HP vPar'
    assert result['virtualization_tech_host'] == set()
   

# Generated at 2022-06-23 02:19:13.185841
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert isinstance(hv, HPUXVirtual)

# Generated at 2022-06-23 02:19:15.099928
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual()
    assert virtual_obj.platform == 'HP-UX'


# Generated at 2022-06-23 02:19:17.343913
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict(module=dict()))
    assert virtual.platform == 'HP-UX'


# Generated at 2022-06-23 02:19:18.608126
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual({})
    assert virtual.platform == 'HP-UX'

# Generated at 2022-06-23 02:19:20.790814
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpxv = HPUXVirtual()
    assert hpxv.platform == "HP-UX"


# Generated at 2022-06-23 02:19:23.190493
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    a = HPUXVirtualCollector()
    assert a._fact_class == HPUXVirtual
    assert a._platform == 'HP-UX'

# Generated at 2022-06-23 02:19:24.780724
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_hpx_instance = HPUXVirtualCollector()

# Generated at 2022-06-23 02:19:26.694538
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert virtual_collector is not None

# Generated at 2022-06-23 02:19:27.750617
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-23 02:19:30.891872
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module_mock = MockModule()
    hv = HPUXVirtual(module_mock)
    assert hv.module == module_mock
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-23 02:19:32.741599
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-23 02:19:36.461542
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert x._fact_class == HPUXVirtual
    assert x._platform == 'HP-UX'



# Generated at 2022-06-23 02:19:39.854858
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    result = HPUXVirtualCollector()
    assert result
    assert result.platform == 'HP-UX'
    assert result._fact_class == HPUXVirtual
    assert result._platform == 'HP-UX'


# Generated at 2022-06-23 02:19:49.426639
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    import sys
    if sys.version_info[0] == 2:
        import __builtin__ as builtins
    else:
        import builtins
    builtins.__ansible_module_builtin__ = True
    setattr(builtins, '__ansible_module_builtin__', True)

    mock_module = type('AnsibleModule', (object,), {
        'run_command': lambda *args, **kwargs: (0, 'fake_stdout', ''),
        'fail_json': lambda *args, **kwargs: sys.exit(1),
    })()
    virtual_collector = HPUXVirtualCollector(mock_module)
    virtual_facts = virtual_collector.collect()['ansible_facts']['ansible_virtualization_facts']

    assert type(virtual_facts)

# Generated at 2022-06-23 02:19:59.665071
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual import VirtualCollector
    from ansible.module_utils.facts.virtual import Virtual

    hv = HPUXVirtualCollector()
    assert isinstance(hv, HPUXVirtualCollector)
    assert isinstance(hv, VirtualCollector)
    assert hv._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:20:01.285759
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    res = HPUXVirtualCollector()
    assert isinstance(res, HPUXVirtualCollector)


# Generated at 2022-06-23 02:20:03.305583
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    Constructor of class HPUXVirtual must be callable without
    any required or optional arguments
    """
    HPUXVirtual()

# Generated at 2022-06-23 02:20:07.158179
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    Create an instance of HPUXVirtual
    """
    hv = HPUXVirtual({})
    assert isinstance(hv, HPUXVirtual)
    assert isinstance(hv, Virtual)



# Generated at 2022-06-23 02:20:10.066503
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = dict()
    facts = dict()
    virtualcollector = HPUXVirtualCollector(module, facts)
    assert virtualcollector.platform == 'HP-UX'
    assert virtualcollector.fact_class == HPUXVirtual

# Generated at 2022-06-23 02:20:12.425536
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv.platform == 'HP-UX'
    assert hv._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:20:14.742815
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virt_coll = HPUXVirtualCollector()
    assert virt_coll.platform == 'HP-UX'
    assert virt_coll.fact_class == HPUXVirtual

# Generated at 2022-06-23 02:20:21.689281
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict())
    assert virtual.platform == 'HP-UX'
    assert virtual.get_virtual_facts() == dict(virtualization_tech_guest=set(['HP vPar', 'HPVM vPar', 'HPVM IVM', 'HP nPar']),
                virtualization_type='guest', virtualization_tech_host=set(['HPVM']),
                virtualization_role='HPVM vPar')


# Generated at 2022-06-23 02:20:26.384798
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.virtualization_type == 'guest'
    assert virtual_facts.virtualization_role == 'HP nPar'
    assert virtual_facts.virtualization_tech_guest == {'HP nPar'}
    assert virtual_facts.virtualization_tech_host == set()

# Generated at 2022-06-23 02:20:30.552741
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = AnsibleModuleMock()
    virtual = HPUXVirtualCollector(module, "")
    assert virtual.platform == 'HP-UX'
    assert virtual.get_virtual_facts()

# following code used for testing class HPUXVirtual

# Generated at 2022-06-23 02:20:33.365011
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert virtual_collector._fact_class == HPUXVirtual
    assert virtual_collector._platform == 'HP-UX'

# Generated at 2022-06-23 02:20:37.293727
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    assert obj.platform == 'HP-UX'
    assert obj.fact_class == HPUXVirtual


# Generated at 2022-06-23 02:20:42.181734
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual(dict())
    assert v.platform == "HP-UX"


# Generated at 2022-06-23 02:20:45.762899
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual_instance = HPUXVirtual(dict())
    assert isinstance(hpux_virtual_instance, HPUXVirtual)


# Generated at 2022-06-23 02:20:56.572803
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec=dict())
    # vecheck
    tmp_path = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_path, 'vecheck')
    with open(tmp_file, 'w') as my_file:
        my_file.write('#!/usr/bin/ksh\n')
        my_file.write('exit 0')
    os.chmod(tmp_file, 0o755)
    module.params['_ansible_tmpdir'] = tmp_path
    module.run_command = run_command
    virtual = HPUXVirtual(module)

# Generated at 2022-06-23 02:21:03.797503
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpxvirtual = HPUXVirtual(None)
    assert hpxvirtual.platform == 'HP-UX'
    assert hpxvirtual.virtualization_type is None
    assert hpxvirtual.virtualization_role is None
    assert hpxvirtual.virtualization_tech_guest is None
    assert hpxvirtual.virtualization_tech_host is None
    assert hpxvirtual.module is None



# Generated at 2022-06-23 02:21:06.233788
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpuxvirtual = HPUXVirtual({})
    assert hpuxvirtual.platform == 'HP-UX'

# Generated at 2022-06-23 02:21:09.232796
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpx = HPUXVirtualCollector()
    assert hpx._fact_class == HPUXVirtual
    assert hpx._platform == 'HP-UX'

# Generated at 2022-06-23 02:21:13.171535
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    import json
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    output = HPUXVirtual(dict(), dict()).get_virtual_facts()
    assert type(output) == dict
    assert output == {}

# Generated at 2022-06-23 02:21:15.009486
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-23 02:21:18.307474
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert virtual_collector._platform == 'HP-UX'
    assert virtual_collector._fact_class.platform == 'HP-UX'
    assert callable(virtual_collector._fact_class)


# Generated at 2022-06-23 02:21:21.704698
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    assert obj.platform == 'HP-UX'
    assert obj._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:21:23.290701
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-23 02:21:34.165752
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import virt

    # test_class
    module = type('', (), {})()
    def run_command(self, cmd):
        if self.cmd == "/usr/sbin/vecheck":
            if self.file_context == "vecheck0":
                return (0, "", "")
            if self.file_context == "vecheck1":
                return (0, "", "")
        if self.cmd == "/opt/hpvm/bin/hpvminfo":
            if self.file_context == "hpvminfo0":
                return (0, "", "")

# Generated at 2022-06-23 02:21:35.633859
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt = HPUXVirtual(module=None)
    assert virt.platform == 'HP-UX'


# Generated at 2022-06-23 02:21:43.656183
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import ModuleData
    from ansible.module_utils.facts.virtual.hpu import HPUXVirtual
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual import VirtualCollector

    # Initialize the module data class
    moduledata = ModuleData()
    moduledata.init_module_args()

    # Mock the module
    module = Virtual(moduledata)

    # Initialize the Virtual Collector class
    virtualcollector = VirtualCollector(module)

    # Initialize the HPUXVirtual class
    hpuvirtual = HPUXVirtual(module, virtualcollector.get_platform())

    # Mocking os.path.exists

# Generated at 2022-06-23 02:21:51.268887
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    the test_HPUXVirtual_get_virtual_facts method of the HPUXVirtual class returns a dictionary containing
    virtualization facts tested by running command on the localhost.
    """

    module = AnsibleModule(argument_spec={})

    HPUXVirtual.module = module
    virtual = HPUXVirtual()
    virtual_facts = virtual.get_virtual_facts()

    module.exit_json(ansible_facts={'ansible_virtualization_facts': virtual_facts})



# Generated at 2022-06-23 02:21:59.751780
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Assign
    h = HPUXVirtual({'module_setup': True})
    # Act
    vf = h.get_virtual_facts()
    # Assert
    # vf shall be a dict
    assert isinstance(vf, dict)
    # The vf dict shall contain virtualization_type
    assert 'virtualization_type' in vf
    # The vf dict shall contain virtualization_role
    assert 'virtualization_role' in vf
    # The vf dict shall contain virtualization_tech_guest
    assert 'virtualization_tech_guest' in vf
    # The vf dict shall contain virtualization_tech_host
    assert 'virtualization_tech_host' in vf

# Generated at 2022-06-23 02:22:04.505467
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpux_virtual_col = HPUXVirtualCollector()
    assert hpux_virtual_col.platform == 'HP-UX'
    assert hpux_virtual_col.fact_class.platform == 'HP-UX'


# Generated at 2022-06-23 02:22:07.181486
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert x.platform == 'HP-UX'
    assert x._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:22:09.613039
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual({})
    assert v.platform == 'HP-UX'


# Generated at 2022-06-23 02:22:13.794988
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    Test HPUXVirtual
    """
    hpux_virtual_facts = HPUXVirtual()
    assert hpux_virtual_facts.platform == 'HP-UX'
    assert hpux_virtual_facts.guest == {}


# Generated at 2022-06-23 02:22:15.582772
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.platform == 'HP-UX'



# Generated at 2022-06-23 02:22:19.868175
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    # Create an instance of HPUXVirtualCollector
    hv = HPUXVirtualCollector()

    # Test for class of _fact_class property
    assert hv._fact_class == HPUXVirtual

    # Test for string _platform class property
    assert isinstance(hv._platform, str)


# Generated at 2022-06-23 02:22:22.220016
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert x.platform == 'HP-UX'
    assert x._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:22:25.891695
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = FakeModule('HP-UX', '12.0')
    HPUXVirtualCollector(module).collect()


# Generated at 2022-06-23 02:22:30.462453
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
            argument_spec=dict(),
            supports_check_mode=True,
            )

    ret = HPUXVirtual().get_virtual_facts()
    assert ret == {}

# Generated at 2022-06-23 02:22:33.152070
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv._platform == 'HP-UX'
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-23 02:22:38.399370
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    # Create a dummy module for testing
    class DummyModule:
        def __init__(self):
            self._ansible_module = True

    de = DummyModule()
    try:
        HPUXVirtualCollector._load_platform_subclass(de)
    except KeyError:
        assert False, "Failed to find class HPUXVirtualCollector"

# Generated at 2022-06-23 02:22:42.094034
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    assert obj.platform == 'HP-UX'
    assert obj._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:22:50.903432
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    hp = HPUXVirtual(module)
    hp.get_virtual_facts()
    hp.get_virtual_facts()

    # Check that the VirtualizationRole is HP nPar
    if hp.virtual_facts['virtualization_role'] != 'HP nPar':
        module.fail_json(msg="Error in get_virtual_facts, virtualization role should be HP nPar but it is %s" % hp.virtual_facts['virtualization_role'])
        assert False



# Generated at 2022-06-23 02:22:53.826058
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """Check the class constructor of HPUXVirtualCollector"""
    hpx_virtual_collector = HPUXVirtualCollector()
    assert hpx_virtual_collector


# Generated at 2022-06-23 02:23:03.723464
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    mock_module = MockModule()
    mock_module.run_command = Mock(side_effect=[(0, '', ''), (1, '', ''), (0, '', ''), (1, '', ''), (0, '', ''),
                                                (1, '', ''), (0, '', ''), (0, '', ''),(1, '', ''), (0, '', ''),
                                                (1, '', ''), (0, '', ''), (0, '', ''), (1, '', ''), (0, '', ''),
                                                (1, '', ''), (0, '', ''), (1, '', ''), (0, '', ''), (1, '', '')])
    fact_class = HPUXVirtual(module=mock_module)
    virtual_

# Generated at 2022-06-23 02:23:14.308751
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = type('MockModule', (object,), {'run_command': lambda *args, **kwargs: (0, '', '')})
    fact_class = HPUXVirtual(module)
    virtual_facts = fact_class.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP nPar'
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_tech_guest'] == set(['HP nPar'])

# Generated at 2022-06-23 02:23:17.273524
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert virtual_collector._fact_class is HPUXVirtual
    assert virtual_collector._platform is 'HP-UX'

# Generated at 2022-06-23 02:23:26.562751
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible_collections.notstdlib.moveitallout.tests import mock
    mock_module = mock.mock_module_helper()
    mock_module.run_command = mock.Mock(return_value=(0, '', ''))
    mock_module.params = {'gather_subset': '!all,!min'}
    hx_virt = HPUXVirtual(mock_module)
    facts = hx_virt.get_virtual_facts()
    assert 'virtualization_type' in facts, "virtualization_type not present in facts"

# Generated at 2022-06-23 02:23:28.793120
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector.platform == 'HP-UX'
    assert HPUXVirtualCollector._fact_class.platform == 'HP-UX'

# Generated at 2022-06-23 02:23:31.858546
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpuxVirtualCollector = HPUXVirtualCollector()
    assert hpuxVirtualCollector._platform == 'HP-UX'
    assert hpuxVirtualCollector._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:23:44.154691
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils._text import to_bytes

    module = AnsibleModule(
        argument_spec={}
    )
    hpux = HPUXVirtual(module)
    virtual_facts = hpux.get_virtual_facts()

    host_tech = set()
    guest_tech = set()
    if os.path.exists('/usr/sbin/vecheck'):
        rc, out, err = module.run_command("/usr/sbin/vecheck")
        if rc == 0:
            guest_tech.add('HP vPar')
            assert virtual_facts['virtualization_type'] == 'guest'
