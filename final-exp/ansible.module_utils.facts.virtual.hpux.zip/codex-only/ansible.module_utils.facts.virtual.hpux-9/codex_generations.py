

# Generated at 2022-06-23 02:13:49.001049
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import types
    import json

    module = types.ModuleType('ansible.module_utils.facts.virtuatl.hpu')
    module.run_command = run_command_mock

    facts_dict = {'virtualization_type': 'guest',
                  'virtualization_role': 'HP vPar',
                  'virtualization_tech_guest': ['HP vPar'],
                  'virtualization_tech_host': []
                 }

    # load HPUXVirtual class
    hpu_virt = HPUXVirtual(module)
    response = hpu_virt.get_virtual_facts()

    # compare the result
    assert(json.dumps(facts_dict) == json.dumps(response))



# Generated at 2022-06-23 02:13:51.296596
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = FakeAnsibleModule()
    facts = HPUXVirtual(module)
    assert facts.platform == 'HP-UX'



# Generated at 2022-06-23 02:13:53.847637
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv._fact_class is HPUXVirtual

# Generated at 2022-06-23 02:14:06.213515
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.test_utils import FakeModule
    from ansible.module_utils.facts.virtual.test_utils import FakeCommand
    from ansible.module_utils.facts.virtual.test_utils import FakeCommandExecutor
    from ansible.module_utils.facts.virtual.test_utils import FakeFile

    # Check that guest_tech is marked as host and virtualization_role is
    # correctly set when parstatus command output is given
    module = FakeModule(dict(name='HPUXVirtual'))
    command_executor = FakeCommandExecutor(dict(
        parstatus='',
    ))
    file_executor = FakeFile(dict(
        vecheck_exists=False,
        hpvminfo_exists=False,
    ))


# Generated at 2022-06-23 02:14:17.965680
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Arrange
    from ansible.module_utils.basic import AnsibleModule

    import tempfile

    tmpdir = tempfile.mkdtemp(prefix="test_HPUXVirtual_get_virtual_facts_")

    os.makedirs(tmpdir + '/usr/sbin')
    os.makedirs(tmpdir + '/etc')
    os.makedirs(tmpdir + '/opt/hpvm/bin')

    # vecheck
    open(tmpdir + '/usr/sbin/vecheck', 'a').close()
    # parstatus
    open(tmpdir + '/usr/sbin/parstatus', 'a').close()
    # hpvminfo
    open(tmpdir + '/opt/hpvm/bin/hpvminfo', 'a').close()

    # hpvmstatus

# Generated at 2022-06-23 02:14:20.749482
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_facts = HPUXVirtualCollector()
    # Class name of first class in ancestor hierarchy
    assert virtual_facts.__class__.__name__ == 'HPUXVirtualCollector'

# Generated at 2022-06-23 02:14:23.159141
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    test_obj = HPUXVirtual({}, {}, {}, False)
    assert test_obj.platform == "HP-UX"


# Generated at 2022-06-23 02:14:24.125229
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual()



# Generated at 2022-06-23 02:14:32.245007
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    m = HPUXVirtual(dict(module_args=dict()), dict())
    m.module.run_command = lambda *args, **kwargs: (0, '', '')
    facts = m.get_virtual_facts()
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_tech_guest'] == set(['HPVM', 'HP nPar', 'HP vPar'])
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP vPar'

# Generated at 2022-06-23 02:14:36.636090
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpvx = HPUXVirtual()
    assert hpvx.platform == 'HP-UX'
    assert hpvx.has_svm_profiles() == True
    assert hpvx.has_vparstatus() == True
    assert hpvx.has_hpvmstatus() == True

# Generated at 2022-06-23 02:14:38.797018
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict(module=dict()), "")
    assert virtual.platform == virtual.platform
    assert virtual.get_virtual_facts() == dict()


# Generated at 2022-06-23 02:14:40.874605
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector(HPUXVirtual)
    assert collector.fact_class == HPUXVirtual
    assert collector.platform == 'HP-UX'

# Generated at 2022-06-23 02:14:49.890151
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Unit test for get_virtual_facts method
    # The use case for vecheck is covered here
    # vecheck is only supported in HP-UX 11iv3 releases
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    import os
    import os.path
    import platform
    if os.uname()[0] != 'HP-UX':
        return
    if os.uname()[3].startswith('B.11.31'):
        return
    class AnsibleModule:
        def run_command(self):
            return (0, 'ipar', '')
        def get_bin_path(self, cmd):
            return cmd
    class Facts:
        def __init__(self):
            self.system = 'HP-UX'

# Generated at 2022-06-23 02:14:53.548721
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual({})

if __name__ == '__main__':
    test_HPUXVirtual()

# Generated at 2022-06-23 02:15:02.103737
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    '''
    Unit test for method get_virtual_facts of class HPUXVirtual
    '''
    # Create HPUXVirtual class instance
    hpux_virtual = HPUXVirtual()

    # Create a AnsibleModule Mock
    mock_module = MagicMock(ansible.module_utils.basic.AnsibleModule)

    # Add the return values for the mocked methods
    mock_module.run_command.return_value = (0, "Running HPVM vPar", "")

    # Add the module mock to the instance
    hpux_virtual.module = mock_module

    # Add the methods mocked values to the instance
    hpux_virtual.module.run_command.return_value = (0, "Running HPVM vPar", "")

    # Call the method get_virtual_facts
    virtual_facts = hpux_virtual

# Generated at 2022-06-23 02:15:03.619879
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-23 02:15:05.762319
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = FakeAnsibleModule()
    virtual_collector = HPUXVirtualCollector(module=module)
    assert type(virtual_collector) == HPUXVirtualCollector


# Generated at 2022-06-23 02:15:14.833431
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    ''' unit test for HPUXVirtual.get_virtual_facts '''
    module = FakeModule()
    hpu = HPUXVirtual(module)
    hpu.get_virtual_facts()
    hpu.module.run_command.assert_any_call("/usr/sbin/vecheck")
    hpu.module.run_command.assert_any_call("/opt/hpvm/bin/hpvminfo")
    hpu.module.run_command.assert_any_call("/usr/sbin/parstatus")
    assert hpu.virtual_facts['virtualization_type'] == 'host'
    assert hpu.virtual_facts['virtualization_role'] == 'HPVM'


# Generated at 2022-06-23 02:15:26.414335
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    from ansible.test.unit.modules.utils.test_file import TestFile
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    module_mock = basic.AnsibleModule(
        argument_spec=dict()
    )
    TestFile.__makedirs__ = False
    del module_mock._syslog_facility

    TestFile.write_file(path='/usr/sbin/parstatus', content=b'parstatus')
    TestFile.write_file(path='/opt/hpvm/bin/hpvminfo', content=b'hpvminfo')
    TestFile.write_file(path='/usr/sbin/vecheck', content=b'vecheck')

# Generated at 2022-06-23 02:15:31.767431
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.virtualization_type == ''
    assert virtual_facts.virtualization_role == ''
    assert virtual_facts.virtualization_tech_guest == set()
    assert virtual_facts.virtualization_tech_host == set()
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-23 02:15:42.503432
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible_collections.ansible.community.tests.unit.compat import mock
    from ansible_collections.ansible.community.tests.unit.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase, set_module_args

    class TestAnsibleModule(object):
        pass

    hpux_virtual_fact_obj = HPUXVirtual()

    class TestHPUXVirtual(object):
        def get_virtual_facts(self):
            return {}

    with mock.patch.object(HPUXVirtual, '_load_platform_subclass', return_value=TestHPUXVirtual()):
        hpux_virtual_fact_obj.get_facts()


# Generated at 2022-06-23 02:15:53.274016
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.platform == 'HP-UX'
    assert hv.virtualization_type == ''
    assert hv.virtualization_role == ''
    assert hv.virtualization_tech_host == set()
    assert hv.virtualization_tech_guest == set()
    hv = HPUXVirtual({'virtualization_type': 'guest'})
    assert hv.virtualization_type == 'guest'
    assert hv.virtualization_role == ''
    assert hv.virtualization_tech_host == set()
    assert hv.virtualization_tech_guest == set()
    hv = HPUXVirtual({
        'virtualization_type': 'guest',
        'virtualization_role': 'HP vPar'
    })
    assert h

# Generated at 2022-06-23 02:16:04.642050
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux_virtual import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux_virtual import get_all_virtual_subclasses

    module = FakeAnsibleModule()
    module.run_command.return_value = (1, None, None)
    module.get_bin_path.return_value = None

    # Test 1: No virtualization
    hpux_virtual = HPUXVirtual(module)
    facts = hpux_virtual.get_virtual_facts()
    assert facts['virtualization_type'] == 'physical'
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_tech_guest'] == set()

    # Test 2: vecheck installed and returning

# Generated at 2022-06-23 02:16:11.098281
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    test_obj = HPUXVirtual({})
    assert test_obj
    assert test_obj.platform == 'HP-UX'
    assert test_obj.virtualization_type == 'guest'
    assert test_obj.virtualization_role == 'HP vPar'
    assert test_obj.virtualization_tech_guest == set(['HP vPar'])
    assert test_obj.virtualization_tech_host == set()


# Generated at 2022-06-23 02:16:13.025788
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector()._fact_class.platform == 'HP-UX'

# Generated at 2022-06-23 02:16:22.154461
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Test with /usr/sbin/vecheck present
    module_context = dict(path=['/usr/sbin'],
                          run_command=lambda x, module=None: (0, '', ''))
    vecheck_virtual = HPUXVirtual(module_context)
    assert vecheck_virtual.get_virtual_facts() == {'virtualization_tech_host': set(),
                                                   'virtualization_tech_guest': set(['HP vPar']),
                                                   'virtualization_type': 'guest',
                                                   'virtualization_role': 'HP vPar'}

    # Test with /opt/hpvm/bin/hpvminfo present

# Generated at 2022-06-23 02:16:31.621310
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # The assumption is that this test is run on a VM or vPar system.
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )
    hw_facts = HPUXVirtual(module).get_virtual_facts()
    assert 'virtualization_type' in hw_facts
    assert 'virtualization_role' in hw_facts
    assert 'virtualization_tech_host' in hw_facts
    assert 'virtualization_tech_guest' in hw_facts
    assert isinstance(hw_facts['virtualization_tech_host'], set)
    assert isinstance(hw_facts['virtualization_tech_guest'], set)
    assert not hw_facts['virtualization_tech_host']

# Generated at 2022-06-23 02:16:39.305166
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    virtual_sys = HPUXVirtual()
    virtual_facts = {
        'virtualization_type': 'guest',
        'virtualization_role': 'HPVM IVM',
        'virtualization_tech_host': set(['HPVM']),
        'virtualization_tech_guest': set(['HPVM'])
    }
    virtual_facts_method = virtual_sys.get_virtual_facts()
    assert virtual_facts_method == virtual_facts



# Generated at 2022-06-23 02:16:42.838018
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert x.platform == 'HP-UX'
    assert x._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:16:46.916574
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = AnsibleModuleMock()
    hpux_virtual_collector = HPUXVirtualCollector(module)
    assert hpux_virtual_collector._fact_class == HPUXVirtual
    assert hpux_virtual_collector._platform == 'HP-UX'


# Generated at 2022-06-23 02:16:51.713786
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual = HPUXVirtualCollector()
    assert virtual.virtual._platform == 'HP-UX'
    assert virtual.virtual.fact_class == HPUXVirtual
    assert virtual.virtual.platform == 'HP-UX'
    assert virtual.virtual.cache_location is None
    assert virtual.virtual.cache_attrname is None


# Generated at 2022-06-23 02:16:54.906937
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    Unit test for constructor of class HPUXVirtual
    """
    facts = {}
    hpsu_virtual = HPUXVirtual(facts, None)
    assert hpsu_virtual.platform == "HP-UX"

# Generated at 2022-06-23 02:17:06.841639
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    config = {'HPUX': {'condition': 'True',
                       'virtualization_role': 'HPVM IVM',
                       'virtualization_type': 'guest',
                       'virtualization_tech_guest': set(['HPVM IVM']),
                       'virtualization_tech_host': set([])}}
    virtual_facts = HPUXVirtual.collect(config)
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HPVM IVM'
    assert len(virtual_facts['virtualization_tech_guest']) == 1
    assert 'HPVM IVM' in virtual_facts['virtualization_tech_guest']
    assert len(virtual_facts['virtualization_tech_host']) == 0

# Generated at 2022-06-23 02:17:09.196981
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    x = HPUXVirtual({},{}, {})
    assert(x.platform == 'HP-UX')


# Generated at 2022-06-23 02:17:16.990490
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    hpux_virtual = HPUXVirtual()
    # protected properties
    assert hpux_virtual._platform == 'HP-UX'
    # public properties are not defined yet
    assert not hasattr(hpux_virtual, 'virtualization_type')
    assert not hasattr(hpux_virtual, 'virtualization_role')
    assert not hasattr(hpux_virtual, 'virtualization_tech_guest')
    assert not hasattr(hpux_virtual, 'virtualization_tech_host')


# Generated at 2022-06-23 02:17:29.274520
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_obj = HPUXVirtual()
    test_obj.module = MockModule()
    test_obj.module.get_bin_path.return_value = '/usr/sbin'

    # Test case no.1
    test_obj.module.run_command.return_value = (0, '', '')
    assert test_obj.get_virtual_facts() == {'virtualization_tech_guest': set(),
                                            'virtualization_tech_host': set()}

    # Test case no.2
    test_obj.module.run_command.return_value = (0, 'Running HPVM guest', '')

# Generated at 2022-06-23 02:17:31.286567
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == HPUXVirtual._platform

# Generated at 2022-06-23 02:17:41.687313
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import os
    import tempfile
    import shutil
    import subprocess
    import ansible.module_utils.facts.virtual.hpar as Virtual
    import ansible.module_utils.facts.virtual.hpvm as HPVM
    import ansible.module_utils.facts.virtual.npar as NPAR
    import ansible.module_utils.facts.virtual.vpar as VPAR
    import ansible.module_utils.facts.virtual.virtual as Virtual
    import ansible.module_utils.facts.virtual.ldom as LDOM
    import ansible.module_utils.facts.virtual.openvz as OPENVZ
    import ansible.module_utils.facts.virtual.esx as ESX
    import ansible.module_utils.facts.virtual.vserver as VSERVER

# Generated at 2022-06-23 02:17:42.991626
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-23 02:17:48.171788
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt = HPUXVirtualCollector.fetch_virtual_facts()
    assert virt['virtualization_type'] == 'guest'
    assert virt['virtualization_role'] == 'HP nPar'
    assert virt['virtualization_tech_guest'] == set(['HP nPar', 'HP vPar'])
    assert virt['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:17:49.938850
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # Test for correct instantiation
    assert HPUXVirtual(dict())


# Generated at 2022-06-23 02:18:01.962635
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Test HPUXVirtual.get_virtual_facts
    """
    from ansible.module_utils.facts import MockModule
    from ansible.module_utils.facts.collector import BaseFactCollector
    # Make a mock module and initialize it with fake arguments
    module = MockModule(check_invalid_arguments=False)
    base_collector = BaseFactCollector(module=module)

    # Set a default ansible_facts directory
    base_collector.collect()
    # Set some facts
    module.ansible_facts['ansible_facts_dir'] = os.path.join(os.path.dirname(__file__), '../../../lib/ansible/module_utils/facts')

    # Create a HPUXVirtual instance

# Generated at 2022-06-23 02:18:10.330552
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Tests for method get_virtual_facts of class HPUXVirtual.
    """
    class FakeModule:
        def __init__(self):
            self.run_command = HPUXVirtual._run_command

    class FakeHPUXVirtual(HPUXVirtual):
        def __init__(self, module=None):
            self.module = module

    hv = FakeHPUXVirtual(module=FakeModule())

    # HP vPar
    HPUXVirtual._run_command = lambda a: (0,
                                          ' vecheck: HPVM status: Running HPVM vPar',
                                          '')
    facts = hv._get_virtual_facts()
    assert facts['virtualization_role'] == 'HP vPar'

    # HPVM vPar

# Generated at 2022-06-23 02:18:16.492259
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    Test the constructor of HPUXVirtual.
    """
    virtual_facts_obj = HPUXVirtual(module=None)
    result_in_platform = HPUXVirtual._platform in virtual_facts_obj.platform
    result_get_virtual_facts = len(virtual_facts_obj.get_virtual_facts()) > 0
    assert result_in_platform and result_get_virtual_facts

# Generated at 2022-06-23 02:18:23.508424
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux_virtual import HPUXVirtual
    from ansible.module_utils.facts.processor.hpux import HPUXProcessor

    module = FakeModule()
    hpux_virtual = HPUXVirtual(module)
    hpux_virtual.get_virtual_facts()
    assert module.fail_json.called == 0

# Generated at 2022-06-23 02:18:33.700664
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():

    virtual_facts = {
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': {'HP vPar', 'HPVM vPar', 'HP nPar'},
    }
    hpux_virtual_inst = HPUXVirtual(dict(module=None))
    assert hpux_virtual_inst.platform == 'HP-UX'
    hpux_virtual_facts = hpux_virtual_inst.get_virtual_facts()
    assert hpux_virtual_facts['virtualization_type'] == 'guest'
    assert hpux_virtual_facts['virtualization_role'] == 'HPVM vPar'
    assert hpux_virtual_facts['virtualization_tech_host'] == virtual_facts['virtualization_tech_host']

# Generated at 2022-06-23 02:18:35.285085
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual()
    assert virtual_obj.platform == 'HP-UX'

# Generated at 2022-06-23 02:18:39.438471
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    test_HPUXVirtualCollector = HPUXVirtualCollector()

    assert test_HPUXVirtualCollector.platform == 'HP-UX'
    assert test_HPUXVirtualCollector._fact_class == HPUXVirtual



# Generated at 2022-06-23 02:18:51.440041
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    virtual_facts = HPUXVirtual(module=None)
    virtual_collector = VirtualCollector(module=None)
    # Case 1: parstatus is present and parstatus returns with exit code 0
    virtual_facts.module.run_command = lambda x: (0, '', '')
    virtual_facts.module.command_exists = lambda x: {
        '/opt/hpvm/bin/hpvminfo': False,
        '/usr/sbin/parstatus': True,
        '/usr/sbin/vecheck': False,
    }.get(x, True)
    result = virtual_facts.get_virtual_facts()

# Generated at 2022-06-23 02:18:55.751579
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # mock values for input parameters
    module = {'run_command': FakeRunCommand().run_command}
    # mock return values for methods
    hpx_virtual = HPUXVirtual(module)
    hpx_virtual.get_virtual_facts()


# Generated at 2022-06-23 02:18:59.736284
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_str = '<class \'ansible.module_utils.facts.virtual.hpux.HPUXVirtual\'>'
    assert str(HPUXVirtualCollector._fact_class) == virtual_str
    assert HPUXVirtualCollector._platform == 'HP-UX'


# Generated at 2022-06-23 02:19:09.817371
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six.moves import StringIO
    import ansible.module_utils.facts.virtual.hpux
    hpux_virtual = HPUXVirtual(ansible.module_utils._ANSIBLE_ARGS, StringIO(), StringIO())
    hpux_virtual_collector = HPUXVirtualCollector()
    hpux_virtual.module.run_command = lambda x: (0, to_bytes("hpux"), "")
    virtual_facts = hpux_virtual.get_virtual_facts()

# Generated at 2022-06-23 02:19:11.133127
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-23 02:19:20.472884
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 02:19:22.214632
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector()
    assert collector._platform == 'HP-UX'

# Generated at 2022-06-23 02:19:25.234507
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    from ansible.module_utils.facts.virtual.hpar import HPUXVirtualCollector
    assert HPUXVirtualCollector._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:19:27.168512
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert isinstance(HPUXVirtualCollector(), HPUXVirtualCollector)



# Generated at 2022-06-23 02:19:37.660022
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible_collections.community.general.tests.unit.compat import unittest

    class TestHPUXVirtual(unittest.TestCase):
        def setUp(self):
            class MockModule(object):
                def run_command(self, command):
                    return rc, to_bytes(out, errors='surrogate_or_strict'), to_bytes(err, errors='surrogate_or_strict')
            self.module = MockModule()
            self.hpux_virtual = HPUXVirtual(self.module)

        rc_map

# Generated at 2022-06-23 02:19:40.242775
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert(x.platform == 'HP-UX')
    assert(x.fact_class == HPUXVirtual)


# Generated at 2022-06-23 02:19:43.897061
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = AnsibleModuleMock()
    fact_class = HPUXVirtualCollector.get_fact_class()
    fact_class_obj = fact_class(module)
    assert fact_class_obj.platform == 'HP-UX', 'platform should be HP-UX'

# Generated at 2022-06-23 02:19:55.358707
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Set up test case data
    test_data = {
        'virtualization_type': 'host',
        'virtualization_role': 'HPVM',
        'virtualization_tech_host': {'HPVM'},
        'virtualization_tech_guest': set(),
    }

    # Instantiate the module class
    module_args = {
        'module_executable': '/opt/hpvm/bin/hpvminfo',
        'command_executable': '/bin/cat',
        'command_output': '\n'.join([
            'HPVM guest running',
            'HPVM guest running',
            'HPVM guest running',
            'HPVM guest running',
            'HPVM guest running',
        ]),
    }
    module = FakeAnsibleModule(**module_args)

    # Instantiate the

# Generated at 2022-06-23 02:19:57.025873
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(None)

    assert virtual._platform == 'HP-UX'



# Generated at 2022-06-23 02:19:57.956360
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-23 02:20:02.406819
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    facts = HPUXVirtual({}, {}).get_virtual_facts()
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP vPar'
    assert facts['virtualization_type'] == 'guest'

# Generated at 2022-06-23 02:20:11.836438
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # create an instance of class HPUXVirtual
    mock_module = type('AnsibleModule', (object,), {'run_command': run_command})
    hpux_virtual = HPUXVirtual(mock_module)

    # These strings will be returned by the mocked AnsibleModule.run_command()
    # when its get_virtual_facts() method will be called.
    vecheck_out = "Virtual Partition Environment Version 2.0"
    hpvminfo_out_nopar = "Running HPVM guest"
    hpvminfo_out_par = "Running HPVM vPar"
    hpvminfo_out_host = "Running HPVM host"
    parstatus_out = "Partition ID = 0 (primary partition)"

    # test get_virtual_facts() in case of virtualization_type = guest
   

# Generated at 2022-06-23 02:20:23.731355
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    mock_module = MockModule()
    mock_module.run_command = Mock(return_value=(0, "Running as an HPVM guest\nHPVM Version 7.05", ""))
    mock_module.get_bin_path = Mock(return_value='/opt/hpvm/bin/hpvminfo')
    facts = HPUXVirtual(mock_module).get_virtual_facts()
    assert 'virtualization_type' in facts
    assert facts['virtualization_type'] == 'guest'
    assert 'virtualization_role' in facts
    assert facts['virtualization_role'] == 'HPVM IVM'
    assert 'virtualization_tech_guest' in facts
    assert 'HPVM' in facts['virtualization_tech_guest']
    assert 'virtualization_tech_host' in facts

# Generated at 2022-06-23 02:20:30.906234
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # Create object of class HPUXVirtual
    hw = HPUXVirtual()
    virtual_facts = hw.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP nPar'
    assert virtual_facts['virtualization_tech_guest'] == set(['HP nPar'])
    assert virtual_facts['virtualization_tech_host'] == set([])

# Generated at 2022-06-23 02:20:42.105861
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """Test get_virtual_facts method of HPUXVirtual
    """
    import tempfile
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import Settings

    settings = Settings(
        module_name='test_get_virtual_facts',
        module_args={},
        timeout=30,
        stdout_callback='json',
        facts=None
    )

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create test files
    file_path = tmp_dir + '/vecheck'
    with open(file_path, 'w+b') as f:
        f.write(to_bytes(''))
    os.chmod(file_path, 0o755)


# Generated at 2022-06-23 02:20:47.782448
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector()
    assert collector.__class__.__name__ == 'HPUXVirtualCollector'
    assert collector.platform == 'HP-UX'
    assert collector._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:20:52.900203
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict(module=dict()))
    assert virtual._platform == 'HP-UX'
    assert virtual.platform == 'HP-UX'
    assert virtual.virtualization_type is None
    assert virtual.virtualization_role is None
    assert virtual.virtualization_tech_host == set()
    assert virtual.virtualization_tech_guest == set()


# Generated at 2022-06-23 02:20:57.005390
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    from ansible.module_utils.facts import collector
    collector.collector.GATHERER = 'fake'
    virtual_facts = HPUXVirtual(dict(), dict())
    assert virtual_facts._platform == 'HP-UX'
    assert virtual_facts._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:21:02.807786
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module_mock = MagicMock(name='module')
    module_mock.run_command.return_value = (0, 'output virt', '')
    v = HPUXVirtual(module_mock)
    assert 'virtualization_type' in v.get_virtual_facts()

# Generated at 2022-06-23 02:21:09.812925
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import mock

    module = mock.Mock()
    item = HPUXVirtual(module)
    result = item.get_virtual_facts()
    assert result['virtualization_type'] == 'guest'
    assert result['virtualization_role'] == 'HP nPar'
    assert result['virtualization_tech_guest'] == {'HP nPar'}
    assert result['virtualization_tech_host'] == set()



# Generated at 2022-06-23 02:21:15.337536
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """
    This will test the constructor of HPUXVirtualCollector
    """
    hpuxv = HPUXVirtualCollector()
    assert hpuxv.platform == 'HP-UX'
    assert type(hpuxv).__name__ == 'HPUXVirtualCollector'
    assert isinstance(hpuxv.get_all(), dict)


# Generated at 2022-06-23 02:21:23.134486
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.collector import TestModule
    from ansible.module_utils.facts import local_facts
    from ansible.module_utils._text import to_bytes
    import sys

    host_facts = local_facts.load_facts(loader=None, filename=os.path.join(os.path.dirname(__file__), 'fixtures', 'local_facts.json'))

    testmodule = TestModule({})
    setattr(testmodule, 'run_command', lambda *a, **kw: (0, to_bytes('x'), None))

    collector = HPUXVirtual(testmodule)

    if sys.version_info[0] < 3:
        assert collector.get_virtual_facts() == host_facts['ansible_virtualization_facts']
    else:
        assert collector.get

# Generated at 2022-06-23 02:21:26.762623
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux = HPUXVirtualCollector()
    assert hpux.platform == 'HP-UX'
    assert hpux._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:21:30.270903
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = type('FakeModule', (object,), dict(params=None, run_command=lambda x: x))
    virtual_collector = HPUXVirtualCollector(module)
    assert virtual_collector._fact_class.platform == 'HP-UX'

# Generated at 2022-06-23 02:21:32.725692
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector(None)
    assert hv.platform == 'HP-UX'
    assert hv._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:21:35.206367
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual({'module_setup': {'filter': ''}}, None, None)
    ret = virtual.get_virtual_facts()
    assert ret['virtualization_type'] in ['guest', 'host']

# Generated at 2022-06-23 02:21:38.079334
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv_facts  = HPUXVirtual(dict(ANSIBLE_MODULE_ARGS={})).populate()
    assert hv_facts['virtualization_type'] == 'guest'
    assert hv_facts['virtualization_role'] == 'HP vPar'

# Generated at 2022-06-23 02:21:41.412539
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """
    Test the constructor of class HPUXVirtualCollector
    """
    collector = HPUXVirtualCollector()
    assert collector.is_virtual() is not None

# Generated at 2022-06-23 02:21:46.383212
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    # Test when no module is passed to the constructor
    vc = HPUXVirtualCollector(None)
    assert isinstance(vc, HPUXVirtualCollector)
    assert vc.platform == 'HP-UX'
    assert vc.fact_class.platform == 'HP-UX'

# Generated at 2022-06-23 02:21:48.749190
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(dict())
    assert hpux_virtual.platform == 'HPUX'


# Generated at 2022-06-23 02:21:50.655516
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual({})
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-23 02:21:54.053908
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPfact = HPUXVirtualCollector()
    assert HPfact.platform == 'HP-UX'
    assert HPfact._fact_class == HPUXVirtual
    assert HPfact._platform == 'HP-UX'

# Generated at 2022-06-23 02:21:58.428537
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpx = HPUXVirtualCollector()
    assert isinstance(hpx, VirtualCollector)
    assert hpx.platform == 'HP-UX'
    assert hpx.fact_class == HPUXVirtual

# Generated at 2022-06-23 02:22:09.276813
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    virtual_facts = {}

    if os.path.exists('/usr/sbin/vecheck'):
        rc, out, err = module.run_command("/usr/sbin/vecheck")
        if rc == 0:
            guest_tech.add('HP vPar')
            virtual_facts['virtualization_type'] = 'guest'
            virtual_facts['virtualization_role'] = 'HP vPar'
    if os.path.exists('/opt/hpvm/bin/hpvminfo'):
        rc, out, err = module.run_command("/opt/hpvm/bin/hpvminfo")
        if rc == 0 and re.match('.*Running.*HPVM vPar.*', out):
            guest_tech.add('HPVM vPar')
            virtual_facts['virtualization_type']

# Generated at 2022-06-23 02:22:11.322047
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpu = HPUXVirtual()
    assert hpu.platform == 'HP-UX'

# Generated at 2022-06-23 02:22:18.237827
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )

    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    virtual = HPUXVirtual(module)
    facts = virtual.get_virtual_facts()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''
    assert len(facts['virtualization_tech_guest']) == 0
    assert len(facts['virtualization_tech_host']) == 0


# Generated at 2022-06-23 02:22:20.071755
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv_c = HPUXVirtualCollector()
    assert hv_c._platform == 'HP-UX'

# Generated at 2022-06-23 02:22:28.905653
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    hv = HPUXVirtual({})
    hv.module.run_command = MagicMock()
    hv.module.run_command.side_effect = [
        (0, 'HPVM vPar', ''),
        (0, 'HPVM vPar', ''),
        (0, 'Running HPVM host system', ''),
        (0, '', ''),
        (0, 'HP nPar', '')
    ]

    assert hv.get_virtual_facts() == {
        'virtualization_tech_guest': set(['HP vPar', 'HPVM vPar', 'HP nPar']),
        'virtualization_tech_host': set(['HPVM']),
        'virtualization_type': 'guest',
        'virtualization_role': 'HP nPar'
    }

# Generated at 2022-06-23 02:22:38.092343
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # pylint: disable=protected-access,import-error
    from ansible.module_utils.facts.virtual.hpux_virtual import HPUXVirtual
    from ansible.module_utils.facts.virtual import Virtual
    from ansible.module_utils.facts.virtual.hpux_virtual import HPUXVirtualCollector
    import os
    import re

    class MockModule(object):
        def __init__(self):
            pass

        class RunCommand(object):
            def __init__(self):
                self.rc = 0
                self.err = None
                self.out = None

            def __call__(self, cmd):
                if cmd == '/usr/sbin/vecheck':
                    self.out = "Running inside a HP-UX virtual partition (vPar)"
                    return self.rc, self.out,

# Generated at 2022-06-23 02:22:41.340240
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-23 02:22:42.379980
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    mod = HPUXVirtual()
    assert mod.platform == 'HP-UX'

# Generated at 2022-06-23 02:22:46.462569
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    facts = {}
    HPUXVC = HPUXVirtualCollector(dict(), facts)
    assert(HPUXVC.platform == 'HP-UX')
    assert(HPUXVC._fact_class.__name__ == 'HPUXVirtual')



# Generated at 2022-06-23 02:22:57.159311
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    class TestModule():
        def __init__(self, module_name):
            self.run_command_environ_update = {}
            self.run_command_executable = '/bin/sh'

        def run_command(self, command, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            if command == '/usr/sbin/vecheck':
                rc = 0
                out = "running virtualized"
                err = ''
                return rc, out, err
            if command == '/opt/hpvm/bin/hpvminfo':
                rc = 0
                out = "Running in HPVM vPar"
                err = ''
                return rc, out, err
            if command == '/usr/sbin/parstatus':
                rc = 0

# Generated at 2022-06-23 02:22:58.936230
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert isinstance(hv, HPUXVirtual)

# Generated at 2022-06-23 02:23:07.391769
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Create the object
    test_obj = HPUXVirtual()

    # Mock the module, since we can't use it during unit test
    test_obj.module = MockModule()

    # Create a dictionary containing the expected key/value pairs
    correct_dict = dict(
        virtualization_type='guest',
        virtualization_role='HP nPar',
        virtualization_tech_guest=set(['HP nPar']),
        virtualization_tech_host=set([])
    )

    # Get the virtual facts
    virtual_facts = test_obj.get_virtual_facts()

    # Compare the virtual facts we got with the correct dictionary
    assert correct_dict == virtual_facts



# Generated at 2022-06-23 02:23:10.038727
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual(dict())
    assert v.platform == 'HP-UX'
    assert v.get_virtual_facts() is None

# Generated at 2022-06-23 02:23:12.630658
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv._platform == 'HP-UX'
    assert hv._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:23:16.054811
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual(dict())
    assert v.get_virtual_facts() == {
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set()
    }

# Generated at 2022-06-23 02:23:18.911389
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual = HPUXVirtualCollector()
    assert virtual._platform == 'HP-UX'
    assert virtual._fact_class == HPUXVirtual



# Generated at 2022-06-23 02:23:22.115160
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert x._fact_class == HPUXVirtual
    assert x._platform == 'HP-UX'



# Generated at 2022-06-23 02:23:29.405473
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import ModuleTestCase
    from ansible.module_utils.facts.virtual import HPUXVirtual

    vTest = HPUXVirtual()
    vTest.module = ModuleTestCase()
    vTest.get_virtual_facts()

    assert vTest.virtual_facts['virtualization_type'] == 'guest'
    assert vTest.virtual_facts['virtualization_role'] == 'HP nPar'
    assert 'HP nPar' in vTest.virtual_facts['virtualization_tech_guest']
    assert len(vTest.virtual_facts['virtualization_tech_guest']) == 1

# Generated at 2022-06-23 02:23:31.358139
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual_obj = HPUXVirtual()
    assert hpux_virtual_obj.platform == "HP-UX"


# Generated at 2022-06-23 02:23:43.654549
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class HPUXVirtualTest(HPUXVirtual):
        def __init__(self):
            class Module():
                def run_command(self, cmd):
                    return(0, 'Running guest with HPVM vPar', '')
            self.module = Module()

    hv = HPUXVirtualTest()
    facts = hv.get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HPVM vPar'
    assert 'HPVM vPar' in facts['virtualization_tech_guest']
    assert 'HP vPar' not in facts['virtualization_tech_guest']
    assert 'HP nPar' not in facts['virtualization_tech_guest']
    assert set() in facts['virtualization_tech_host']

    # Unit test