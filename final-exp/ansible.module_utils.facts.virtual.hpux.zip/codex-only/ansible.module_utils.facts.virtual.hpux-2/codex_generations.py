

# Generated at 2022-06-23 02:13:46.219185
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-23 02:13:47.794797
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    v = HPUXVirtualCollector()
    assert v._fact_class == HPUXVirtual
    assert v._platform == "HP-UX"

# Generated at 2022-06-23 02:13:50.595434
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpux_virtual_collector = HPUXVirtualCollector()
    assert hpux_virtual_collector._platform == 'HP-UX'

# Generated at 2022-06-23 02:13:55.279320
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    test_HPUXVirtual = HPUXVirtual({})
    assert test_HPUXVirtual.virtualization_type == 'guest'
    assert test_HPUXVirtual.virtualization_role == 'HP nPar'
    assert test_HPUXVirtual.virtualization_subtype == ''

# Generated at 2022-06-23 02:13:58.138441
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.platform == 'HP-UX'
    assert hv.get_virtual_facts()['virtualization_type'] == 'host'

# Generated at 2022-06-23 02:14:00.666961
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    assert obj._platform == 'HP-UX'
    assert obj._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:14:04.380160
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt_obj = HPUXVirtual(dict())
    assert isinstance(virt_obj, Virtual)
    assert virt_obj.platform == "HP-UX"
    assert virt_obj.get_virtual_facts() == dict()

# Generated at 2022-06-23 02:14:06.891024
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-23 02:14:18.590303
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    def run_cmd(cmd):
        if cmd == '/usr/sbin/vecheck':
            return (0, '', '')
        elif cmd == '/opt/hpvm/bin/hpvminfo':
            return (0, 'Running HPVM guest on host: Host_1', '')
        elif cmd == '/usr/sbin/parstatus':
            return (0, '', '')
        elif cmd == '/usr/sbin/parstatus -V':
            return (0, '', '')
        else:
            return (-1, '', '')

# Generated at 2022-06-23 02:14:30.160986
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.virtual.hpar import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpar import HPUXVirtualCollector
    from ansible.module_utils._text import to_bytes

    module = HPUXVirtual.module
    module.run_command = run_command_mock

    # The following lines are required to get module_utils.facts initialized
    # with a module object.
    module.exit_json = exit_json_mock
    facts_obj = Facts(module)
    facts_obj.populate()

    hpar_collector = HPUXVirtualCollector(module=module, facts=facts_obj.facts)
    hpar_collector.collect()
    hpar_virtual = hpar_

# Generated at 2022-06-23 02:14:39.843822
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Test for HP nPar
    hpx_virtual_obj1 = HPUXVirtual({})
    hp_npar_output = '/usr/sbin/parstatus: not found\n'
    hpx_virtual_obj1.module.run_command = MagicMock(return_value=(0, hp_npar_output, ''))
    assert hpx_virtual_obj1.get_virtual_facts()['virtualization_role'] == 'HP nPar'

    # Test for HP vPar
    hpx_virtual_obj2 = HPUXVirtual({})
    hp_vpar_output = ''
    hpx_virtual_obj2.module.run_command = MagicMock(return_value=(0, hp_vpar_output, ''))

# Generated at 2022-06-23 02:14:42.234575
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual({})
    assert h.get_virtual_facts() == {}

# Generated at 2022-06-23 02:14:43.883461
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt = HPUXVirtual(dict())
    assert virt.platform == 'HP-UX'


# Generated at 2022-06-23 02:14:45.781394
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector('/dev/null')
    assert x._fact_class.platform == 'HP-UX'



# Generated at 2022-06-23 02:14:50.500548
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Run the test
    hpux_virtual = HPUXVirtual()
    virtual_facts = hpux_virtual.get_virtual_facts()

    # Assert virtualization tech
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

    # Assert virtualization type and role
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'

# Generated at 2022-06-23 02:14:52.775358
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpux_virtual_collector = HPUXVirtualCollector(None)
    assert hpux_virtual_collector.platform == 'HP-UX'

# Generated at 2022-06-23 02:14:54.726152
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual({})  # an empty dict will suffice
    assert virtual.platform == 'HP-UX'

# Generated at 2022-06-23 02:15:05.770902
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    mod = FakeModule('/path/to/ansible')
    hpux_virtual = HPUXVirtual(module=mod)
    guest_tech = set()
    host_tech = set()
    # 1. test HPVM guest
    mod.run_command_args['returncode'] = 0
    mod.run_command_args['stdout'] = "Running HPVM guest"
    result = hpux_virtual.get_virtual_facts()
    assert result['virtualization_type'] == 'guest'
    assert result['virtualization_tech_guest'] == set(['HPVM IVM'])
    assert result['virtualization_tech_host'] == set()
    assert result['virtualization_role'] == 'HPVM IVM'
    #

# Generated at 2022-06-23 02:15:09.431404
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    facts = dict()
    HPUXVirtualCollector(facts=facts, module=None)
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP vPar'

# Generated at 2022-06-23 02:15:13.808854
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_hpux = HPUXVirtual()
    assert virtual_hpux.platform == 'HP-UX'
    assert HPUXVirtual.get_virtual_facts.__doc__ == "Get virtualization facts."
    assert HPUXVirtual.platform == 'HP-UX'


# Generated at 2022-06-23 02:15:15.139198
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert issubclass(HPUXVirtualCollector, VirtualCollector)

# Generated at 2022-06-23 02:15:26.688782
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hw_facts = dict()
    hw_facts['system'] = dict()
    hw_facts['system']['manufacturer'] = 'Hewlett-Packard'
    hw_facts['system']['product'] = 'HP 9000/824/C3000'
    hw_facts['system']['version'] = 'A.0'
    hv_facts = dict()
    hv_facts['virtualization_role'] = 'HPVM'
    hv_facts['virtualization_type'] = 'host'
    hv_facts['virtualization_tech_host'] = set()
    hv_facts['virtualization_tech_host'].add('HPVM')
    hv_facts['virtualization_tech_guest'] = set()

# Generated at 2022-06-23 02:15:37.882520
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import os
    from ansible.module_utils.facts.virtual import HPUXVirtual
    if os.path.exists('/usr/sbin/parstatus'):
        virtual_facts = HPUXVirtual(dict(module=dict(run_command=run_command))).get_virtual_facts()
        assert 'virtualization_type' in virtual_facts
        assert 'virtualization_type' in virtual_facts
        assert virtual_facts['virtualization_type'] == 'guest'
        assert 'virtualization_role' in virtual_facts
        assert virtual_facts['virtualization_role'] == 'HP nPar'
        assert 'virtualization_tech_host' in virtual_facts
        assert isinstance(virtual_facts['virtualization_tech_host'], set)
        assert 'virtualization_tech_guest' in virtual_facts


# Generated at 2022-06-23 02:15:40.056449
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual()

# Generated at 2022-06-23 02:15:43.816347
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt = HPUXVirtual()
    # Check the default value of virtualization_type
    assert virt.data['virtualization_type'] == 'NA'
    # Check the default value of virtualization_role
    assert virt.data['virtualization_role'] == 'NA'

# Generated at 2022-06-23 02:15:52.406224
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual import VirtualCollector
    import os
    import re

    # Initialize environment
    virtual_collector_obj = HPUXVirtualCollector()
    virtual_obj = HPUXVirtual(virtual_collector_obj)
    
    # Initialize virtual guest environment
    setattr(virtual_obj.module, 'run_command', lambda cmd: (0, 'Running HPVM guest', ''))
    setattr(virtual_obj, 'is_file', lambda cmd: True)
    virtual_obj.is_file.side_effect = lambda cmd: cmd == '/opt/hpvm/bin/hpvminfo'

# Generated at 2022-06-23 02:15:54.347944
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    c = HPUXVirtualCollector()
    assert c.facts['virtualization_type'] == "unknown"

# Generated at 2022-06-23 02:16:04.066442
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = None
    expected = {
        'virtualization_type': 'guest',
        'virtualization_role': 'HP vPar',
        'virtualization_tech_guest': set(['HP vPar']),
        'virtualization_tech_host': set([])
    }
    try:
        import ansible.module_utils.basic
        from ansible.module_utils.facts.virtual import HPUXVirtual
    except Exception:
        pass
    else:
        module = ansible.module_utils.basic.AnsibleModule({}, {})
        hpx_virtual = HPUXVirtual(module)
        result = hpx_virtual.get_virtual_facts()
        assert(expected == result)

# Generated at 2022-06-23 02:16:10.158710
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = MockModule(platform='HP-UX')

    hpux = HPUXVirtual(module)
    hpux.get_virtual_facts()

    assert 'virtualization_role' in module.virtual_facts
    assert 'virtualization_type' in module.virtual_facts
    assert 'virtualization_tech_guest' in module.virtual_facts
    assert 'virtualization_tech_host' in module.virtual_facts

# Generated at 2022-06-23 02:16:13.393367
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = HPUXVirtualCollector
    assert module._platform == 'HP-UX'
    assert module._fact_class.__name__ == 'HPUXVirtual'

# Generated at 2022-06-23 02:16:17.950934
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_obj = HPUXVirtual({})
    virtual_facts = test_obj.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts

# Generated at 2022-06-23 02:16:19.280860
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-23 02:16:29.451310
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Import class HPUXVirtual and its test class
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual import AnsibleFakeModule

    hw_output = """
Machdep.processor.architecture: PA-RISC
Machdep.processor.implementation: PA-RISC 2.0
Machdep.cpu.features: FPU(v2)
Machdep.cpu.features: Integer(v1)
Machdep.cpu.features: MMU(v2)
Machdep.cpu.features: OSF_W2(v0)
Machdep.cpu.features: PA2.0(v1)
"""

# Generated at 2022-06-23 02:16:36.682422
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    HP-UX tests
    """
    module = FakeAnsibleModule({'python_version': 2})
    module.run_command.return_value = (0, '', '')

    virtual = HPUXVirtual(module)
    facts = virtual.get_facts()

    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP vPar'
    assert 'host' not in facts['virtualization_type']
    assert 'HP' not in facts['virtualization_role']


# Generated at 2022-06-23 02:16:47.024037
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # import module snippets
    from ansible.module_utils.facts import ansible_virtual_facts

    # setup test variables
    test_module = ansible_virtual_facts
    test_module.run_command = get_run_command_results
    test_module.os.path.exists.side_effect = get_exist_side_effect
    test_module.module = HPUXVirtual()

    # define expected results
    expected_results = {
        'virtualization_role': 'HP nPar',
        'virtualization_type': 'guest',
        'virtualization_tech_guest': set(['HP nPar']),
        'virtualization_tech_host': set([]),
    }

    # run method
    actual_results = test_module.module.get_virtual_facts()

    # assert results
   

# Generated at 2022-06-23 02:16:49.402075
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv.platform == 'HP-UX'
    assert isinstance(hv.collect(), dict)

# Generated at 2022-06-23 02:16:52.121174
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    o = HPUXVirtual(None)
    assert o.facts['virtualization_type'] is None
    assert o.facts['virtualization_role'] is None



# Generated at 2022-06-23 02:16:55.044549
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.virtualization_type == "host"
    assert hv.virtualization_role == "HPVM"
    assert 'HPVM' in set(hv.virtualization_tech_host)



# Generated at 2022-06-23 02:17:07.417889
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class MockModule(object):
        def run_command(self, command, check_rc=True):
            if command == "/usr/sbin/vecheck":
                rc = 0
                out = "out"
                err = "err"
            elif command == "/opt/hpvm/bin/hpvminfo":
                rc = 0
                out = "out"
                err = "err"
            elif command == "/usr/sbin/parstatus":
                rc = 0
                out = "out"
                err = "err"
            return rc, out, err

    class MockOSModule(object):
        def path(self, name):
            if name == "/usr/sbin/vecheck":
                return True
            elif name == "/opt/hpvm/bin/hpvminfo":
                return True
            el

# Generated at 2022-06-23 02:17:09.250351
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpuxvirtual = HPUXVirtual({})
    assert hpuxvirtual.platform == 'HP-UX'

# Generated at 2022-06-23 02:17:11.915317
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpx = HPUXVirtualCollector()
    assert hpx.platform == 'HP-UX'
    assert hpx.fact_class == HPUXVirtual


# Generated at 2022-06-23 02:17:14.927488
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual({})
    a = {'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}
    assert h.get_virtual_facts() == a



# Generated at 2022-06-23 02:17:21.444585
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    expected = {
        'virtualization_role': 'HPVM IVM',
        'virtualization_type': 'guest',
        'virtualization_tech_guest': set(['HPVM IVM']),
        'virtualization_tech_host': set(),
        'virtualization_system': 'HPVM'
    }
    hpux_virtual = HPUXVirtual(dict(module=dict()))
    hpux_virtual.module.run_command = run_command
    result = hpux_virtual.get_virtual_facts()
    assert result == expected



# Generated at 2022-06-23 02:17:33.464969
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class TestModule(object):
        def __init__(self):
            self.run_command = lambda x: (0, 'output', '')

    def mock_open(path):
        if path in ('/usr/sbin/vecheck', '/opt/hpvm/bin/hpvminfo'):
            return MagicMock(spec=file, return_value=None)
        raise OSError(2, 'File does not exist')

    hpuxtest = HPUXVirtual(TestModule())
    hpuxtest.module.run_command = lambda x: (0, '', '')
    hpuxtest.module.file_exists = lambda x: True
    hpuxtest.open = mock_open


# Generated at 2022-06-23 02:17:36.600502
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpuxVirtual = HPUXVirtual()
    assert hpuxVirtual.platform == 'HP-UX'
    assert hpuxVirtual.get_virtual_facts()['virtualization_role'] == 'HP nPar'

# Generated at 2022-06-23 02:17:38.419709
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """
    Unit test for constructor of class HPUXVirtualCollector
    """
    hpux_virtual_collector = HPUXVirtualCollector()
    assert hpux_virtual_collector._fact_class is HPUXVirtual
    assert hpux_virtual_collector._platform == 'HP-UX'

# Generated at 2022-06-23 02:17:41.417793
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    Unit test for constructor of class HPUXVirtual
    :return:
    """
    hpux_virtual = HPUXVirtual({})
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-23 02:17:45.677840
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.__class__.__name__ == 'HPUXVirtual'
    #assert virtual_facts.__doc__ == Virtual.__doc__
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-23 02:17:54.388203
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    mock_module = MockModule()
    mock_module.run_command.return_value = (0, '', '')
    hv = HPUXVirtual(mock_module)
    facts = hv.get_virtual_facts()
    assert facts == {}
    mock_module.run_command.assert_called_once_with('/usr/sbin/vecheck')

    mock_module = MockModule()
    mock_module.run_command.return_value = (0, 'test output from vecheck', '')
    hv = HPUXVirtual(mock_module)
    facts = hv.get_virtual_facts()
    assert facts == {}
    mock_module.run_command.assert_called_once_with('/usr/sbin/vecheck')

    mock_module = MockModule()
    mock_

# Generated at 2022-06-23 02:18:05.050463
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # For testing, we don't want to execute under the context of a module
    module = None
    HPUXVirtual.get_module = lambda self: module
    HPUXVirtual.run_commands = lambda self, cmds: (0, b'', b'')

    hv = HPUXVirtual(module=module)

    # normal case when commands return correct output
    HPUXVirtual.run_commands = lambda self, cmds: (0, b'Running HPVM guest', b'')
    assert hv.get_virtual_facts() == {'virtualization_role': 'HPVM IVM',
                                      'virtualization_tech_guest': set(['HPVM IVM']),
                                      'virtualization_tech_host': set([]),
                                      'virtualization_type': 'guest'}

    # case

# Generated at 2022-06-23 02:18:06.501161
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual(None)

# Generated at 2022-06-23 02:18:13.932140
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual({})
    assert v.data == {}
    assert v.platform == "HP-UX"
    assert v.get_virtual_facts() == {
        'virtualization_type': 'guest',
        'virtualization_role': 'HP vPar',
        'virtualization_tech_host': {},
        'virtualization_tech_guest': {
            'HP vPar'
        }
    }


# Generated at 2022-06-23 02:18:18.506853
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """
    Unit test for constructor of class HPUXVirtualCollector
    """
    class_instance = HPUXVirtualCollector()
    assert class_instance.platform == 'HP-UX'
    assert class_instance._fact_class == HPUXVirtual
    assert class_instance._fact_class.platform == 'HP-UX'

# Generated at 2022-06-23 02:18:29.689129
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    import os
    from ansible.module_utils.facts.virtual.hpux_virtual import HPUXVirtual
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.hpux_virtual import HPUXVirtualCollector

    # Create a instance of class HPUXVirtual and check the inheritance
    os.environ['VIRTUAL_TYPE'] = 'hpux'
    hpux_virtual = HPUXVirtual({})
    assert isinstance(hpux_virtual, HPUXVirtual)
    assert isinstance(hpux_virtual, Virtual)
    assert isinstance(hpux_virtual, BaseFactCollector)

    # Create a instance of class HPUXVirtualCollector and check the inheritance
   

# Generated at 2022-06-23 02:18:38.869974
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector_obj = HPUXVirtualCollector()
    assert virtual_collector_obj.platform == 'HP-UX'
    assert virtual_collector_obj._fact_class == HPUXVirtual
    assert virtual_collector_obj._fact_class.platform == 'HP-UX'


# Generated at 2022-06-23 02:18:48.118122
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    hpux = HPUXVirtual(module)
    if hpux.is_platform_supported():
        facts = hpux.get_virtual_facts()
        assert facts['virtualization_type'] == 'guest'
        assert facts['virtualization_role'] == 'HPVM IVM'
        assert facts['virtualization_tech_host'] == 'HPVM'
        assert facts['virtualization_tech_guest'] == 'HPVM IVM'
    else:
        assert "This platform is not supported"

# Generated at 2022-06-23 02:18:50.041062
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    assert obj
    assert obj._fact_class.platform == 'HP-UX'

# Generated at 2022-06-23 02:19:00.227430
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Validate the get_virtual_facts method of HPUXVirtual class
    """
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    hv = HPUXVirtual()

    # If no file exists, no role should be set
    hv.module.run_command = lambda x: (0, '', '')
    virtual_facts = hv.get_virtual_facts()
    assert virtual_facts == {'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}

    # File vecheck exists, role should be set
    hv.module.run_command = lambda x: (0, '\nVirtual Environment detection\n\nThe system is running as a Virtual Partition.\n\n', '')
    virtual_facts = hv.get_

# Generated at 2022-06-23 02:19:02.451820
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpuxvirtual = HPUXVirtual()
    assert hpuxvirtual.platform == 'HP-UX'

# Generated at 2022-06-23 02:19:05.371708
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert virtual_collector._platform == 'HP-UX'
    assert virtual_collector._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:19:11.569726
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpx = HPUXVirtualCollector()
    assert hpx.platform == 'HP-UX'
    assert hpx._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:19:14.412337
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    # test get_virtual_facts()
    virtual_facts.get_virtual_facts()

# Generated at 2022-06-23 02:19:22.023309
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux_hpvm import HPUXVirtual
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.virtual import Virtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux_hpvm import HPUXVirtualCollector
    import ansible.module_utils.facts.virtual.hpux_hpvm
    import ansible.module_utils.facts.virtual.hpux

    module_facts = ModuleFacts(True, '/usr/bin/python', '/usr/bin/python', '/usr/bin/python')

    #
    # Test in vPar
    #

# Generated at 2022-06-23 02:19:29.769011
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class Module(object):
        def __init__(self):
            self.run_command = lambda *_args: (0, 'Mock output', '')
    module = Module()
    hpuX_virtual = HPUXVirtual(module)
    expected_facts = dict(
        virtualization_tech_guest=set(['HP vPar']),
        virtualization_tech_host=set(),
        virtualization_type='guest',
        virtualization_role='HP vPar',
    )
    assert expected_facts == hpuX_virtual.get_virtual_facts()

# Generated at 2022-06-23 02:19:38.659221
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = type('', (object, ), {'run_command': lambda *args, **kwargs: (0, 'output', 'error')})
    virtual = HPUXVirtual(module)

    assert virtual.platform == 'HP-UX'
    assert virtual.virtual_facts == {}
    # run_command() is mocked out with a lambda function
    assert virtual.get_virtual_facts() == {
        'virtualization_role': 'HP vPar',
        'virtualization_type': 'guest',
        'virtualization_tech_guest': set(['HP vPar']),
        'virtualization_tech_host': set([]),
    }

# Generated at 2022-06-23 02:19:48.482031
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class FakeModule(object):
        def __init__(self, module_name, module_args, module_kwargs):
            self.module_name = module_name
            self.module_args = module_args
            self.module_kwargs = module_kwargs
            self.params = module_kwargs['params']
            self.exit_json = module_kwargs['exit_json']
            self.fail_json = module_kwargs['fail_json']

        def run_command(self, command, data=None, check_rc=True):
            return (0, 'HPVM vPar', '')

    fake_module = FakeModule('test_module', '', {'params': {}, 'exit_json': 0, 'fail_json': 0})
    # Initialize HPUXVirtual class instance

# Generated at 2022-06-23 02:19:54.539872
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    hv = HPUXVirtual()
    assert hv.get_virtual_facts() == {'virtualization_type': 'guest', 'virtualization_role': 'HP vPar', 'virtualization_tech_guest': set(['HP vPar']), 'virtualization_tech_host': set([])}

# Generated at 2022-06-23 02:20:05.562619
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import ansible.module_utils.facts.virtual.hpar as hpar

    module_args = {}
    fake_module = FakeAnsibleModule(module_args, platform='HP-UX')

    fake_module.run_command = run_command

    virtual = HPUXVirtual(fake_module)

    virtual_facts = virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'host'
    assert virtual_facts['virtualization_role'] == 'HPVM'
    assert virtual_facts['virtualization_tech_host'] == set(['HPVM'])
    assert virtual_facts['virtualization_tech_guest'] == set()
    paste_script_returns = (1, '', 'No such file or directory\n')


# Generated at 2022-06-23 02:20:13.742342
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    mod_name = 'ansible.module_utils.facts.virtual.hpux.HPUXVirtualCollector'
    module = 'ansible.module_utils.facts.virtual.hpux'
    HPUXVirtualCollector_instance = HPUXVirtualCollector()
    assert HPUXVirtualCollector_instance._fact_class.__name__ == 'HPUXVirtual'
    assert HPUXVirtualCollector_instance._fact_class.__module__ == mod_name
    assert HPUXVirtualCollector_instance._platform == 'HP-UX'
    assert HPUXVirtualCollector_instance._module == module

# Generated at 2022-06-23 02:20:25.111872
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from unittest import TestCase

    class TestHPUXModule():
        def __init__(self, out, rc=0):
            self.out = out
            self.rc = rc

        def run_command(self, cmd):
            return (self.rc, self.out, '')

    class TestHPUXVirtual(HPUXVirtual):
        def __init__(self, module):
            self.module = module

    class TestHPUXVirtualCollector(HPUXVirtualCollector):
        def __init__(self, module):
            self.module = module

    class Args():
        def __init__(self):
            self.gather_subset = 'all'

    class AnsibleModule():
        def __init__(self, out, rc=0):
            self.run_command = TestH

# Generated at 2022-06-23 02:20:37.612774
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """ Unit test for method get_virtual_facts of class HPUXVirtual """
    virtual = HPUXVirtual()

    # Patching methods
    def dummy_run_command(module, cmd):
        return 0, "Running HPVM guest", ""

    def dummy_module_run_command(cmd):
        return 0, "Running HPVM guest", ""

    virtual.module.run_command = dummy_module_run_command
    virtual.run_command = dummy_run_command

    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_tech_guest'] == set(['HPVM IVM'])
    assert virtual_facts['virtualization_tech_host'] == set([])
    assert virtual_facts['virtualization_role'] == 'HPVM IVM'

# Generated at 2022-06-23 02:20:42.647742
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert x._platform == 'HP-UX'
    assert x._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:20:44.953244
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    instance = HPUXVirtual()
    assert isinstance(instance, HPUXVirtual)
    assert instance.platform == 'HP-UX'
    assert isinstance(instance.get_virtual_facts(), dict)


# Generated at 2022-06-23 02:20:47.230505
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert issubclass(HPUXVirtualCollector, VirtualCollector)

# Generated at 2022-06-23 02:20:49.312452
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual({})
    assert hpux_virtual


# Generated at 2022-06-23 02:20:57.907797
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts import ModuleStub
    import os

    module = ModuleStub()
    orb = HPUXVirtual(module)

    results = {'virtualization_type': '',
               'virtualization_role': '',
               'virtualization_tech_host': set(),
               'virtualization_tech_guest': set()}

    if os.path.exists('/usr/sbin/vecheck'):
        module.run_command.return_value = (0, 'Running HP vPar', '')
        results['virtualization_tech_guest'].add('HP vPar')

# Generated at 2022-06-23 02:21:01.540358
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({}, False)
    assert hv.platform == "HP-UX"

# Generated at 2022-06-23 02:21:13.114271
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(
        return_value=(0, 'Running HPVM guest', '')
    )
    if os.path.exists('/opt/hpvm/bin/hpvminfo'):
        h = HPUXVirtual(module)
        facts = h.get_virtual_facts()
        assert facts == {
            'virtualization_type': 'guest',
            'virtualization_role': 'HPVM IVM',
            'virtualization_tech_guest': set(['HPVM IVM']),
            'virtualization_tech_host': set()
        }


if __name__ == '__main__':
    from ansible.module_utils.basic import *
    from ansible.module_utils._text import to_bytes
   

# Generated at 2022-06-23 02:21:13.839629
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual()

# Generated at 2022-06-23 02:21:15.900578
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector()
    assert 'HP-UX' == collector._platform
    assert HPUXVirtual == collector._fact_class

# Generated at 2022-06-23 02:21:18.445868
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpux_collector = HPUXVirtualCollector()
    assert hpux_collector._fact_class == HPUXVirtual
    assert hpux_collector._platform == 'HP-UX'


# Generated at 2022-06-23 02:21:24.217432
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = AnsibleModule(argument_spec={})
    v = HPUXVirtualCollector(module)
    assert v._platform == 'HP-UX'
    assert v.platform == 'HP-UX'
    assert v._fact_class is HPUXVirtual
    assert v._file_path == ''
    assert v.vendor == 'hpe'


# Generated at 2022-06-23 02:21:27.317387
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual()
    assert virtual_obj.platform == 'HP-UX'
    assert virtual_obj.get_virtual_facts() == {}

# Generated at 2022-06-23 02:21:29.313749
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-23 02:21:39.574762
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    # HPUXVirtualCollector requires ansible_facts['ansible_lsb'] to be a dict.
    # The following is not the ideal way to call HPUXVirtualCollector but I
    # could not find a better way.
    ansible_facts = {}
    ansible_facts['ansible_lsb'] = {}
    ansible_facts['ansible_lsb']['distcodename'] = None
    ansible_facts['ansible_lsb']['description'] = None
    ansible_facts['ansible_lsb']['id'] = None
    ansible_facts['ansible_lsb']['major_release'] = None
    ansible_facts['ansible_lsb']['release'] = None
    h = HPUXVirtualCollector(ansible_facts=ansible_facts)


# Generated at 2022-06-23 02:21:50.270059
# Unit test for method get_virtual_facts of class HPUXVirtual

# Generated at 2022-06-23 02:21:53.179342
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    assert obj.virtinfo is None
    assert obj.platform == 'HP-UX'


# Generated at 2022-06-23 02:21:54.099714
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-23 02:22:02.427937
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    facts = {}
    module = MockModule()
    hpx_virtual = HPUXVirtual(module=module, facts=facts)
    hpx_virtual.get_virtual_facts()
    assert module.run_command.call_count == 3
    expected_calls = [
        call("/usr/sbin/vecheck"),
        call("/opt/hpvm/bin/hpvminfo"),
        call("/usr/sbin/parstatus")
    ]
    module.run_command.assert_has_calls(expected_calls, any_order=True)

# Generated at 2022-06-23 02:22:04.617671
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    my_HPUXVirtualCollector = HPUXVirtualCollector(None)

    assert my_HPUXVirtualCollector._platform == 'HP-UX'


# Generated at 2022-06-23 02:22:06.931956
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_facts_collector = HPUXVirtualCollector()
    assert virtual_facts_collector._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:22:18.831462
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_module = FakeModule()
    test_module.run_command = lambda cmd: ['','','']
    test_module.command_available = lambda cmd: True
    test_HPUXVirtual = HPUXVirtual(test_module)
    facts = {}
    facts = test_HPUXVirtual.get_virtual_facts()
    assert 'virtualization_type' not in facts
    assert 'virtualization_role' not in facts
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host'] == set()

    test_module.run_command = lambda cmd: ['','This is a HPVM host','']
    facts = test_HPUXVirtual.get_virtual_facts()
    assert facts['virtualization_type'] == 'host'

# Generated at 2022-06-23 02:22:21.059009
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    one_fact_class = HPUXVirtualCollector()
    assert HPUXVirtualCollector == type(one_fact_class)


# Generated at 2022-06-23 02:22:25.840994
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    hpux_virtual = HPUXVirtual()
    virtual_facts = hpux_virtual.get_virtual_facts()
    assert isinstance(virtual_facts, dict)
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-23 02:22:28.349432
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    h = HPUXVirtualCollector()
    assert h._fact_class is HPUXVirtual

# Generated at 2022-06-23 02:22:38.154164
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Setup
    module = AnsibleModuleMock({
        'command': "/usr/sbin/vecheck"
    })
    module_return_values = {
        'exists.return_value': True,
        'run_command.return_value': (0, "vPar is running with the following configuration:\nConfigured vPars: 1\nTotal vCPUs: 8\nActive vCPUs: 4\nMax CPUs per vPar: 8\nActive vCPUs per vPar: 4\nNumber of vPars running: 1\n", ""),
    }
    module.configure_mock(**module_return_values)

    # Test
    hpu = HPUXVirtual(module)
    results = hpu.get_virtual_facts()

    # Verify

# Generated at 2022-06-23 02:22:41.880654
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpuxvirtual_instance = HPUXVirtual()
    assert hpuxvirtual_instance
    assert hpuxvirtual_instance.platform == 'HP-UX'

# Generated at 2022-06-23 02:22:52.841919
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import ansible.module_utils.facts.virtual.hpux_virtual as hpux_virtual
    from ansible.module_utils.facts.virtual._hpux_virtual import HPUXVirtual
    from ansible.module_utils.facts.virtual._hpux_virtual import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.base import VirtualCollector

    # Temporary class to simulate module.run_command
    class FakeModule:
        def __init__(self, params):
            self.params = params

        def run_command(self, cmd):
            extra_msg = ''
            if cmd == '/usr/sbin/vecheck':
                if self.params['vecheck_exist'] == 'yes':
                    rc = 0
                    out = ''
                    err = ''

# Generated at 2022-06-23 02:23:03.434035
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Mock module class
    class MockModule(object):
        RUN_CMD_RESULT = [[0, "", ""]]

        def __init__(self):
            self._run_command = [None]

        def run_command(self, cmd):
            self._run_command[0] = cmd
            return self.RUN_CMD_RESULT.pop(0)

    # Mock module
    module = MockModule()
    # Instance of HPUXVirtual
    virtual = HPUXVirtual(module)
    path = {
        '/usr/sbin/vecheck': True,
        '/opt/hpvm/bin/hpvminfo': True,
        '/usr/sbin/parstatus': False
    }
    virtual_facts = virtual.get_virtual_facts(path)

# Generated at 2022-06-23 02:23:08.862618
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    hpux_virtual_vm = HPUXVirtual()
    guest_facts = hpux_virtual_vm.get_virtual_facts()
    assert len(guest_facts) == len(['virtualization_type', 'virtualization_role', 'virtualization_tech_host', 'virtualization_tech_guest'])
    assert guest_facts['virtualization_type'] == 'guest'
    assert guest_facts['virtualization_role'] == 'HP vPar'


# Generated at 2022-06-23 02:23:19.151940
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector_obj = HPUXVirtualCollector()
    assert virtual_collector_obj._platform == 'HP-UX'
    assert virtual_collector_obj._fact_class == HPUXVirtual
    virtual_collector_obj.collect()
    facts = virtual_collector_obj.get_facts()
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_type' in facts
    assert 'virtual' in facts


# Generated at 2022-06-23 02:23:30.040779
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible_module_hpux_virtual import MockModule
    from ansible_module_hpux_virtual import MockCommand
    module = MockModule()

    if_vecheck_absent = MockCommand(rc=1, out='', err='')
    if_vecheck_present = MockCommand(rc=0, out='', err='')
    if_hpvminfo_absent = MockCommand(rc=1, out='', err='')
    if_hpvminfo_running_vpar = MockCommand(rc=0, out='Running HPVM vPar', err='')
    if_hpvminfo_running_guest = MockCommand(rc=0, out='Running HPVM guest', err='')

# Generated at 2022-06-23 02:23:31.103387
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual()


# Generated at 2022-06-23 02:23:33.174666
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual()
    assert v.platform == 'HP-UX'


# Generated at 2022-06-23 02:23:34.954437
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    my_test = HPUXVirtual()
    assert isinstance(my_test, HPUXVirtual)

# Generated at 2022-06-23 02:23:39.165664
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual({})
    assert hpux_virtual.platform == 'HP-UX'
    assert hpux_virtual._virtual_facts == {}
    assert hpux_virtual._get_virtual_facts() == {}


# Generated at 2022-06-23 02:23:49.932654
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import ansible.module_utils.basic
    from ansible.module_utils.facts.collector.virtual.hpar import HPUXVirtual

    mocked_module = ansible.module_utils.basic.AnsibleModule
    mocked_module_instance = mocked_module()

    hpar = HPUXVirtual(mocked_module_instance)

    # Testing when /usr/sbin/vecheck exists
    mocked_module_instance.run_command = MagicMock(return_value=(0, '', ''))
    mocked_module_instance.check_file_path = MagicMock(return_value=True)
