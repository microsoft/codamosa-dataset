

# Generated at 2022-06-23 02:13:48.703163
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(None)
    assert hpux_virtual.platform == 'HP-UX'
    assert hpux_virtual._platform == 'HP-UX'

# Generated at 2022-06-23 02:13:52.272105
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    This function is used to test the constructor of class HPUXVirtual.
    """
    virtual_obj = HPUXVirtual()
    assert virtual_obj.platform == 'HP-UX'
    assert virtual_obj.get_virtual_facts() == {}

# Generated at 2022-06-23 02:14:04.668118
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class OSModuleMock():
        def __init__(self):
            self.run_command_results = None
            self.run_command_args = {}

        def run_command(self, args):
            self.run_command_args = args
            return self.run_command_results

    os_module_mock = OSModuleMock()
    os_module_mock.run_command_results = [0, "Running Par (HP vPar) vParName1", ""]
    h = HPUXVirtual(module=os_module_mock)
    virtual_facts = h.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'

# Generated at 2022-06-23 02:14:07.550325
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpux_virtual_collector = HPUXVirtualCollector()
    assert hpux_virtual_collector._platform == 'HP-UX'

# Generated at 2022-06-23 02:14:17.252701
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    vs = HPUXVirtual({})
    out = vs.get_virtual_facts()
    assert type(out) == dict
    assert 'virtualization_type' in out
    assert 'virtualization_role' in out
    assert 'virtualization_tech_guest' in out
    assert 'virtualization_tech_host' in out
    assert type(out['virtualization_tech_guest']) == set
    assert type(out['virtualization_tech_host']) == set
    assert type(out['virtualization_type']) == str
    assert type(out['virtualization_role']) == str or out['virtualization_role'] is None

# Generated at 2022-06-23 02:14:19.701948
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector()._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:14:26.337284
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class mocked_module(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs

        def run_command(self, cmd):
            return 0, "", ""
    my_module = mocked_module()
    my_HPUXVirtual = HPUXVirtual(my_module)
    virtual_facts = my_HPUXVirtual.get_virtual_facts()
    assert 'HP-UX' in virtual_facts['virtualization_type']

# Generated at 2022-06-23 02:14:28.470732
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual({})
    assert virtual.get_virtual_facts() == {}

# Generated at 2022-06-23 02:14:33.538492
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """Unit test for constructor of class HPUXVirtualCollector"""
    hpux_virtual_collector_obj = HPUXVirtualCollector()
    assert hpux_virtual_collector_obj.platform == 'HP-UX'
    assert hpux_virtual_collector_obj.fact_class == HPUXVirtual


# Generated at 2022-06-23 02:14:40.195301
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual

    facts = dict(module=dict(run_command=run_command_mock))
    hpux_virtual = HPUXVirtual(facts=facts)
    print('hpux_virtual.get_virtual_facts:', hpux_virtual.get_virtual_facts())
    assert hpux_virtual.get_virtual_facts() == {'virtualization_role': 'HPVM IVM', 'virtualization_type': 'guest', 'virtualization_tech_host': set(), 'virtualization_tech_guest': {'HPVM IVM'}}

# Generated at 2022-06-23 02:14:42.466891
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    instance = HPUXVirtualCollector()
    assert instance is not None
    assert instance.platform == 'HP-UX'
    assert HPUXVirtualCollector._platform == 'HP-UX'


# Generated at 2022-06-23 02:14:43.939719
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    assert obj.fact_class is HPUXVirtual
    assert obj.platform is 'HP-UX'

# Generated at 2022-06-23 02:14:45.151338
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector()._platform == 'HP-UX'

# Generated at 2022-06-23 02:14:46.675492
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector()
    assert collector.get_fact_class() == HPUXVirtual

# Generated at 2022-06-23 02:14:49.570527
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector().platform == 'HP-UX'

# Generated at 2022-06-23 02:14:54.178400
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hypervisor = HPUXVirtualCollector()
    assert hypervisor._platform == 'HP-UX'
    assert hypervisor._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:14:55.638981
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual()
    assert v.platform == 'HP-UX'

# Generated at 2022-06-23 02:14:59.572300
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    from ansible.module_utils.facts.virtual.hpux_virtual import HPUXVirtualCollector
    hv = HPUXVirtualCollector()
    assert hv.platform == 'HP-UX'
    assert hv._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:15:00.776871
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-23 02:15:05.876952
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert virtual_collector.__class__.__name__ == 'HPUXVirtualCollector'
    assert virtual_collector._fact_class.__name__ == 'HPUXVirtual'
    assert virtual_collector._platform == 'HP-UX'



# Generated at 2022-06-23 02:15:07.396098
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()



# Generated at 2022-06-23 02:15:09.306463
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual1 = HPUXVirtualCollector()
    assert virtual1._fact_class._platform == 'HP-UX'

# Generated at 2022-06-23 02:15:14.051322
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_hpux = HPUXVirtual({})
    assert virtual_hpux.platform == 'HP-UX'


# Test that get_virtual_facts() method
# - will return a dict
# - will set virtualization_type and virtualization_role to expected values
#   in case vecheck is available

# Generated at 2022-06-23 02:15:25.442205
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import Virtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector

    class TestModule:
        def __init__(self, params):
            self.params = params

        def run_command(self, command):
            if command == '/usr/sbin/vecheck':
                return (0, 'HP-UX Running vPar', '')
            elif command == '/opt/hpvm/bin/hpvminfo':
                return (0, 'HPVM Running HPVM vPar', '')

# Generated at 2022-06-23 02:15:27.329525
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.platform == 'HP-UX'
    assert hv.command == ''

# Generated at 2022-06-23 02:15:37.017321
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    import shutil
    with open('/usr/sbin/vecheck', 'w') as f:
        f.write('#!/bin/sh\n')
        f.write('echo "hpux"\n')
        f.write('exit 0\n')
    module = FakeAnsibleModule(
        **{
            'ansible.module_utils.facts.virtual.hpux.HPUXVirtual': {
                '_virtual_facts': {},
            },
        }
    )
    result = HPUXVirtual(module).collect()
    shutil.os.remove('/usr/sbin/vecheck')
    assert result['virtualization_tech_guest'] == {'HP vPar'}
    assert result['virtualization_type'] == 'guest'

# Generated at 2022-06-23 02:15:46.746727
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    params = {
        'run_command': lambda *_args, **_kwargs: (
            1, 'Running HPVM guest', ''
        )
    }
    test_object = Virtual(params)
    test_object.get_virtual_facts()
    assert test_object.virtual_facts['virtualization_tech_guest'] == set()
    assert test_object.virtual_facts['virtualization_tech_host'] == {'HPVM'}
    assert test_object.virtual_facts['virtualization_role'] == 'HPVM IVM'
    assert test_object.virtual_facts['virtualization_type'] == 'guest'

# Generated at 2022-06-23 02:15:49.680696
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    Unit test for constructor of class HPUXVirtual
    """
    hv_obj = HPUXVirtual(None)
    assert hv_obj.platform == 'HP-UX'


# Generated at 2022-06-23 02:15:52.130352
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector().platform == 'HP-UX'
    assert HPUXVirtualCollector()._fact_class == HPUXVirtual

# unit test for get_virtual_facts() of class HPUXVirtual

# Generated at 2022-06-23 02:15:55.309206
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vc = HPUXVirtualCollector()
    assert isinstance(vc, VirtualCollector)
    assert vc.platform == vc._platform
    assert vc.fact_class == vc._fact_class

# Generated at 2022-06-23 02:15:57.526362
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual()

    assert virtual_obj.platform is 'HP-UX'


# Generated at 2022-06-23 02:16:00.631018
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()

    assert virtual_collector._fact_class == HPUXVirtual
    assert virtual_collector._platform == 'HP-UX'


# Generated at 2022-06-23 02:16:02.802488
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-23 02:16:09.137293
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual()
    assert virtual.platform == "HP-UX"
    assert virtual.get_virtual_facts() == {
        'virtualization_role': 'guest',
        'virtualization_type': 'guest',
        'virtualization_tech_guest': {},
        'virtualization_tech_host': {}
    }



# Generated at 2022-06-23 02:16:15.414604
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = MockModule()
    facts = HPUXVirtual(module=module).get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_tech_guest' in facts
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HPVM vPar'


# --------------------------

# Generated at 2022-06-23 02:16:17.744161
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    # create a HPUX virtual collector
    HPUXVirtualCollector('ansible.module_utils.facts.virtual.hpux')

# Generated at 2022-06-23 02:16:22.012680
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    facts = {}
    module = get_module_mock(params={'gather_subset': '!all,!min'})
    hpux_virtual_obj = HPUXVirtual(module)
    hpux_virtual_obj.get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts



# Generated at 2022-06-23 02:16:31.456234
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = MockModule()
    hpuxvirtual = HPUXVirtual(module)
    hpuxvirtual.module.run_command = Mock(return_value=(0, '', ''))

    module.run_command = Mock(return_value=(0, '', ''))

    # Test for HP VM guest (when /opt/hpvm/bin/hpvminfo output contains "HPVM guest")
    hpuxvirtual.module.run_command = Mock(return_value=(0, 'Running HPVM guest', ''))
    hpuxvirtual.get_virtual_facts()
    assert hpuxvirtual.facts['virtualization_type'] == 'guest'
    assert hpuxvirtual.facts['virtualization_role'] == 'HPVM IVM'
    assert 'HPVM IVM' in hpuxvirtual.facts['virtualization_tech_guest']

# Generated at 2022-06-23 02:16:38.779603
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    m = HPUXVirtual({})
    virtual_facts = m.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-23 02:16:50.778399
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = type('AnsibleModule', (object,), {'run_command': run_command})
    setattr(module, '_ansible_module', module)

    file_exists_map = {
        '/usr/sbin/vecheck': True,
        '/opt/hpvm/bin/hpvminfo': True,
        '/usr/sbin/parstatus': True,
    }
    def file_exists(path):
        return file_exists_map[path]

    hv = HPUXVirtual(module)
    hv.file_exists = file_exists
    facts = hv.get_virtual_facts()

    assert facts['virtualization_role'] == 'HP nPar'
    assert facts['virtualization_type'] == 'guest'

# Generated at 2022-06-23 02:16:54.000730
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual({},{},{},{})
    assert isinstance(virtual_obj, HPUXVirtual)
    assert virtual_obj.platform == 'HP-UX'
    virtual_info = {'virtualization_type': 'guest', 'virtualization_role': 'HP nPar', 'virtualization_tech_host': {}, 'virtualization_tech_guest': {'HP nPar'}}
    assert virtual_obj.get_virtual_facts() == virtual_info

# Generated at 2022-06-23 02:17:06.165456
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class HPUXVirtual
    """
    hpux_virtual = HPUXVirtual()
    hpux_virtual.module.run_command = MagicMock(return_value=(0, '', ''))
    hpux_virtual.module.get_bin_path = MagicMock(side_effect=['/opt/hpvm/bin/hpvminfo', '', '/usr/sbin/parstatus', '/usr/sbin/vecheck'])
    hpux_virtual.module.params = {'gather_subset': ['virtual']}
    hpux_virtual.module.get_module_path = MagicMock(return_value='/usr/lib/ansible/module_utils/facts/virtual/hpux.py')

    hpux_virtual.is_hpux = Magic

# Generated at 2022-06-23 02:17:08.412357
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv._fact_class == HPUXVirtual
    assert hv._platform == 'HP-UX'

# Generated at 2022-06-23 02:17:16.948183
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = HumanAnsibleModule(argument_spec={})
    virtobj = HPUXVirtual(module)
    virtobj._module.run_command = Mock(return_value=(0, '', ''))
    virtobj._module.get_bin_path = Mock(side_effect=[None, '/opt/hpvm/bin/hpvminfo'])
    assert virtobj._platform == 'HP-UX'
    assert virtobj.get_virtual_facts() == \
           {'virtualization_type': 'host', 'virtualization_role': 'HPVM',
            'virtualization_tech_guest': set(['HPVM']), 'virtualization_tech_host': set()}

# Generated at 2022-06-23 02:17:19.275493
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpu = HPUXVirtualCollector(None)
    assert hpu.platform == 'HP-UX'
    assert hpu._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:17:21.882393
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt_facts = HPUXVirtual(dict(module=dict()), dict())
    assert virt_facts.platform == 'HP-UX'



# Generated at 2022-06-23 02:17:24.050963
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(dict())
    assert hv.platform == "HP-UX"

# Generated at 2022-06-23 02:17:27.191405
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    vc = HPUXVirtual(dict())
    assert vc.platform == 'HP-UX'
    assert vc.get_virtual_facts() == {}


# Generated at 2022-06-23 02:17:34.096267
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=['!all'], type='list'),
            'filter': dict(default='*', type='str'),
            'gather_timeout': dict(default=10, type='int'),
        }
    )
    hpux_virtual = HPUXVirtual(module)
    hpux_virtual.module.exit_json = lambda x: x
    hpux_virtual.get_virtual_facts()



# Generated at 2022-06-23 02:17:37.584864
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    virtual_facts = HPUXVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'host'
    assert virtual_facts['virtualization_role'] == 'HPVM'
    assert virtual_facts['virtualization_tech_guest'] == {'HPVM'}
    assert virtual_facts['virtualization_tech_host'] == set()



# Generated at 2022-06-23 02:17:39.399024
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict(), dict())
    assert virtual_facts.platform == "HP-UX"

# Generated at 2022-06-23 02:17:43.407221
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual({})

    assert virtual.platform == 'HP-UX'
    assert not virtual.get_virtual_facts()


# Generated at 2022-06-23 02:17:46.590884
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """
    Class HPUXVirtualCollector should always be created of all the classes derived from VirtualCollector.
    Hence this test case.
    """
    obj = HPUXVirtualCollector()
    assert obj

# Generated at 2022-06-23 02:17:48.868854
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(None).get_virtual_facts()

    assert virtual_facts['virtualization_type']

# Generated at 2022-06-23 02:17:54.746058
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector()
    assert isinstance(collector, HPUXVirtualCollector)


# Generated at 2022-06-23 02:18:03.096124
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.virtual.base import host_data, guest_data
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    module = AnsibleModule(argument_spec={})
    hp_virtual_obj = HPUXVirtual(module)
    # Test 1
    # When guest is HP vPar
    # then virtualization_type should be guest
    # and virtualization_role should be HP vPar
    # and both keys of virtualization_tech should be empty set
    host_data['virtual'] = {'HP-UX': {'hw_vendor': 'HP',
                                      'hw_product': 'HP-RISK'}}

# Generated at 2022-06-23 02:18:15.413328
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux.test.test_hpux_virtual \
        import ExecutableAnsibleModule, Bunch
    my_executable_module = ExecutableAnsibleModule(
        'ansible.module_utils.facts.virtual.hpux.HPUXVirtual',
        dict(module_name='ansible.module_utils.facts.virtual.hpux.virtual'))
    my_executable_module.ansible_module = Bunch()
    my_executable_module.ansible_module.run_command = \
        lambda cmd: (0, "/usr/sbin/vecheck: Running on a vPar\n", "")
    hpux_virtual = HPUXVirtual(my_executable_module)
    virtual_facts = hpux_virtual.get_virtual_facts()

# Generated at 2022-06-23 02:18:27.895546
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    m = {'run_command': MagicMock(return_value=(0, 'Running HPVM vPar', ''))}
    m.update(HPUXVirtual_return_values)
    HPUXVirtual.module = MagicMock(**m)
    hvf = HPUXVirtual().get_virtual_facts()
    assert hvf['virtualization_type'] == 'guest'
    assert hvf['virtualization_role'] == 'HPVM vPar'
    assert 'HPVM vPar' in hvf['virtualization_tech_guest']
    assert len(hvf['virtualization_tech_guest']) == 1
    assert len(hvf['virtualization_tech_host']) == 0

# Generated at 2022-06-23 02:18:34.591500
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    virtual = HPUXVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert('virtualization_tech_guest' in virtual_facts)
    assert('virtualization_tech_host' in virtual_facts)
    assert('virtualization_type' in virtual_facts)
    assert('virtualization_role' in virtual_facts)

    # Test with vecheck installed
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    virtual = HPUXVirtual(module)
    virtual._executable_exists = lambda x: True if x == '/usr/sbin/vecheck' else False

# Generated at 2022-06-23 02:18:40.110277
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux_virtual  import HPUXVirtual
    m = HPUXVirtual()
    facts = m.get_virtual_facts()
    assert isinstance(facts['virtualization_tech_guest'], set)
    assert isinstance(facts['virtualization_tech_host'], set)

# Generated at 2022-06-23 02:18:44.698878
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    facts = dict()
    facts['ansible_virtualization_type'] = None
    facts['ansible_virtualization_role'] = None

    vc = HPUXVirtualCollector(None, facts, {}, [], [])
    assert vc
    assert vc._fact_class

# Generated at 2022-06-23 02:18:47.669013
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hp_virt = HPUXVirtual({})
    assert hp_virt.platform == 'HP-UX'
    assert hp_virt.get_virtual_facts() == {}

# Generated at 2022-06-23 02:18:58.839992
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # This is for mocking the run_command
    class MockModule():
        def run_command(self, cmd):
            if cmd == "/usr/sbin/vecheck":
                return (0, '', '')
            elif cmd == "/opt/hpvm/bin/hpvminfo":
                return (0,
                        '\nSystem Information\n' +
                        '\tRunning as HPVM Host\n' +
                        'Information on Virtual Machines\n' +
                        'Running HPVM guest as nPartition\n', '')
            elif cmd == "/usr/sbin/parstatus":
                return (0,'','')
            else:
                return (1,'','')

        def get_bin_path(self, arg, *args, **kwargs):
            return arg

    import platform
    virtual_collector

# Generated at 2022-06-23 02:18:59.849465
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-23 02:19:09.949502
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import Virtual, HPUXVirtual
    import os
    import re
    import tempfile
    import shutil
    import filecmp
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.hpu import HPUXVirtualCollector

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-23 02:19:13.321973
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert isinstance(hv, HPUXVirtualCollector)


# Generated at 2022-06-23 02:19:14.744861
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_test = HPUXVirtual({})
    assert virtual_test


# Generated at 2022-06-23 02:19:18.518769
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    from ansible.module_utils.facts.virtual.hpar import HPUXVirtual
    # unit test uses the same instance, so need to create new object each time
    assert HPUXVirtual() is not HPUXVirtual()
    assert HPUXVirtual() != 1


# Generated at 2022-06-23 02:19:25.001696
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({}, {})
    assert not virtual_facts.is_nested()
    assert not virtual_facts.is_container()
    assert virtual_facts.get_virtual_facts() == {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
        'virtualization_type': '',
        'virtualization_role': ''
    }

# Generated at 2022-06-23 02:19:28.639894
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpuxtest = HPUXVirtualCollector()
    assert isinstance(hpuxtest, VirtualCollector)
    assert hpuxtest._fact_class == HPUXVirtual
    assert hpuxtest._platform == 'HP-UX'

# Generated at 2022-06-23 02:19:32.189478
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = type('FakeModule', (object,), {})
    facts = {'system': 'HP-UX'}
    hv = HPUXVirtual(module, facts)
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-23 02:19:43.457735
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """UnitTest"""
    return_val = {'virtualization_type': 'host',
                  'virtualization_role': 'HPVM'}

    class dummy_module:
        def __init__(self):
            self.run_command = MockRunCmd()
            self.facts = {}
            self.params = {}

    class MockRunCmd:
        def __init__(self):
            self.mock_hpvminfo = 'Running as an HPVM host'

        def __call__(self, cmd):
            if cmd == '/opt/hpvm/bin/hpvminfo':
                return (0, self.mock_hpvminfo, '')
            elif cmd == '/usr/sbin/parstatus':
                return (1, '', '')

# Generated at 2022-06-23 02:19:47.848414
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import CollectFactsTestCase
    hpuxvirtual = HPUXVirtual(CollectFactsTestCase())
    hpuxvirtual.get_virtual_facts()

# Generated at 2022-06-23 02:19:52.538252
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    test_host = {
        'ansible_facts': {
            'ansible_system_vendor': 'Hewlett-Packard'
        }
    }
    hpux_virtual_collector = HPUXVirtualCollector(None, test_host)
    assert hpux_virtual_collector._platform == 'HP-UX'

# Generated at 2022-06-23 02:19:55.401900
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vc = HPUXVirtualCollector()
    assert(vc.platform == "HP-UX")

# Generated at 2022-06-23 02:19:57.422505
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpx = HPUXVirtual(dict())
    assert hpx.get_virtual_facts()['virtualization_type'] == 'guest'

# Generated at 2022-06-23 02:19:58.351585
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector(None)

# Generated at 2022-06-23 02:20:01.376793
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert x.platform == 'HP-UX'
    assert 'virtualization_type' in x.get_virtual_facts()
    assert 'virtualization_role' in x.get_virtual_facts()

# Generated at 2022-06-23 02:20:10.790451
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all', '!min'], type='list')
        ),
        supports_check_mode=True
    )

    # create an instance of HPUXVirtual and execute get_virtual_facts
    hpxvirtual = HPUXVirtual(test_module)
    virtual_facts = hpxvirtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'host' or virtual_facts['virtualization_type'] == 'guest'

# Generated at 2022-06-23 02:20:14.941076
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hvirt = HPUXVirtualCollector()
    assert hvirt.platform == 'HP-UX'
    assert hvirt.fact_class.platform == 'HP-UX'
    assert hvirt.get_virtual_facts() == {}

# Generated at 2022-06-23 02:20:22.675171
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtualCollector().collect()
    expected_virtual_facts = {
        'virtualization_type': 'guest',
        'virtualization_role': 'HP nPar',
        'virtualization_tech_guest': set(['HP nPar']),
        'virtualization_tech_host': set()
    }
    for key in expected_virtual_facts:
        assert key in virtual_facts
        assert virtual_facts[key] == expected_virtual_facts[key]

# Generated at 2022-06-23 02:20:29.875840
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock

    hpux_virtual = HPUXVirtual(module)
    facts = hpux_virtual.get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP vPar'
    assert facts['virtualization_tech_guest'] == {'HP vPar'}
    assert facts['virtualization_tech_host'] == set()


# Generated at 2022-06-23 02:20:39.723054
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    from ansible.module_utils.facts.collector.virtual.hpux import HPUXVirtual

    # Create a subclass object of class HPUXVirtual
    virtual_collector = HPUXVirtual()

    # Check the default values of instance variables
    assert virtual_collector.platform == 'HP-UX'
    assert virtual_collector.virtualization_type == 'NA'
    assert virtual_collector.virtualization_role == 'NA'
    assert type(virtual_collector.virtualization_tech_host) == set
    assert type(virtual_collector.virtualization_tech_guest) == set

# Generated at 2022-06-23 02:20:42.982604
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual({})
    assert virtual_obj is not None


# Generated at 2022-06-23 02:20:47.684555
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpux = HPUXVirtualCollector(None)
    assert hpux._fact_class._platform == 'HP-UX'
    assert hpux._platform == 'HP-UX'

# Generated at 2022-06-23 02:20:50.225893
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    v = HPUXVirtual()
    assert v.platform == "HP-UX"

# Generated at 2022-06-23 02:20:53.026478
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert virtual_collector._fact_class == HPUXVirtual
    assert virtual_collector._platform == 'HP-UX'


# Generated at 2022-06-23 02:21:01.164765
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'
    assert virtual_facts.get_virtual_facts() == {
        'virtualization_type': 'guest',
        'virtualization_role': 'HP vPar',
        'virtualization_tech_guest': set(['HP vPar']),
        'virtualization_tech_host': set()
    }
    assert virtual_facts.search_string_exists('HP-UX')

# Generated at 2022-06-23 02:21:09.024651
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    from ansible.module_utils.facts.virtual.hpux.vpar import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux.hpvm import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux.npar import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual import VirtualCollector
    assert issubclass(HPUXVirtualCollector, VirtualCollector)
    assert HPUXVirtualCollector._platform == 'HP-UX'


# Generated at 2022-06-23 02:21:11.896808
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vc = HPUXVirtualCollector()
    assert vc._fact_class == HPUXVirtual
    assert vc._platform == 'HP-UX'

# Generated at 2022-06-23 02:21:21.055913
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    
    class FakeAnsibleModule:
        def __init__(self, params=None, mode='none'):
            self._params = params
            self._mode = mode
        
        @property
        def params(self):
            return self._params
        
        def run_command(self, command, check_rc=False):
            """
            Fake run_command method to test HPUXVirtual.get_virtual_facts()
            - If we are on mode 'none' it simply return that we are not a HP-UX VM
            - If we are in mode 'hpvm', it return that we are a HPVM IVM
            - TODO : other mode to test ?
            """
            if self._mode == 'none':
                return (1, 'Host is not a VM', '')

# Generated at 2022-06-23 02:21:31.811396
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class HPUXVirtual'''
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual as HPUXVirtualMock

    HPUXVirtualMock.module = Mock()
    HPUXVirtualMock.module.run_command = run_command_mock
    hv = HPUXVirtualMock()
    hv_facts = hv.get_virtual_facts()
    assert hv_facts['virtualization_type'] == 'guest'
    assert hv_facts['virtualization_role'] == 'HP vPar'
    assert hv_facts['virtualization_tech_host'] == set()
    assert hv_facts['virtualization_tech_guest'] == set(['HP nPar', 'HP vPar'])


# Unit

# Generated at 2022-06-23 02:21:32.905510
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    obj = HPUXVirtual(dict())
    assert (obj.platform == 'HP-UX')


# Generated at 2022-06-23 02:21:34.096142
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual({})

    assert(isinstance(v, Virtual))

# Generated at 2022-06-23 02:21:37.149653
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # Test for HPUXVirtual module constructor
    my_test_virtual_facts = HPUXVirtual(dict())
    assert my_test_virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-23 02:21:48.183055
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # For testing purpose, we will create a dummy class to
    # be able to change the module.run_command
    module_args = {}
    module = AnsibleModule(argument_spec=module_args)
    set_module_args(module_args)

    # For testing purpose, we will create a dummy class to
    # be able to change the module.run_command
    class HPModule:
        class RunCommand:
            @staticmethod
            def run_command(command, check_rc=False):
                class Result:
                    rc = 1
                    stdout = "stdout"
                    stderr = "stderr"

                result = Result()

                if command == "/usr/sbin/vecheck":
                    result.rc = 0
                elif command == "/opt/hpvm/bin/hpvminfo":
                    result

# Generated at 2022-06-23 02:21:49.516639
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-23 02:21:52.445948
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(None)
    assert virtual_facts.platform == 'HP-UX'



# Generated at 2022-06-23 02:21:53.872837
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    instance = HPUXVirtualCollector()
    assert instance._platform == 'HP-UX'

# Generated at 2022-06-23 02:21:56.570586
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert isinstance(HPUXVirtualCollector(None, None), VirtualCollector)

# Generated at 2022-06-23 02:21:59.202941
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    ansible_module = AnsibleModule(argument_spec={})
    virtual_collector = HPUXVirtualCollector(ansible_module=ansible_module)
    assert isinstance(virtual_collector, VirtualCollector)

# Generated at 2022-06-23 02:22:04.578065
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    # new object of class HPUXVirtualCollector
    hpx_virtual_collector = HPUXVirtualCollector()
    # check the platform of class HPUXVirtualCollector
    assert hpx_virtual_collector._platform == 'HP-UX'
    assert isinstance(hpx_virtual_collector._fact_class(), HPUXVirtual) == True
    # check the list length
    assert len(hpx_virtual_collector.collect()) == 1


# Generated at 2022-06-23 02:22:09.622631
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    '''
    Unit test for method get_virtual_facts of class HPUXVirtual
    '''
    test_obj = HPUXVirtual()
    # Check virtualization_type
    assert test_obj.get_virtual_facts()['virtualization_type'] == 'guest'
    # Check virtualization_type
    assert test_obj.get_virtual_facts()['virtualization_role'] == 'HP nPar'

# Generated at 2022-06-23 02:22:12.936995
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # test default constructor
    HPUXVirtual()

    # test constructor with module_name 'kmod'
    HPUXVirtual(module_name='kmod')

# Generated at 2022-06-23 02:22:20.212364
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # I need to set the module name here
    module = AnsibleModule(argument_spec={})

    # I need to set the module_utils.basic.AnsibleModule.run_command
    # to run_command mock function, so I can assert its called properly
    module.run_command = run_command

    # Create an instance of the HPUXVirtual class
    hpx_virtual_obj = HPUXVirtual(module)

    # Call get_virtual_facts of HPUXVirtual
    # instance to set the facts
    hpx_virtual_obj.get_virtual_facts()

    # Assert that the facts are set
    assert hpx_virtual_obj.facts['virtualization_type'] == 'guest'
    assert hpx_virtual_obj.facts['virtualization_role'] == 'HP nPar'
    assert hpx

# Generated at 2022-06-23 02:22:25.151475
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )
    virt_collector = HPUXVirtualCollector(module)
    assert virt_collector._platform == 'HP-UX'
    assert virt_collector._fact_class == HPUXVirtual



# Generated at 2022-06-23 02:22:27.329470
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual({})
    assert v



# Generated at 2022-06-23 02:22:32.958371
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = DummyAnsibleModule()
    hpux_virtual = HPUXVirtual(module)

    assert hpux_virtual.platform == 'HP-UX'
    assert hpux_virtual.get_virtual_facts() == {'virtualization_type': None, 'virtualization_role': None,
                                                'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}



# Generated at 2022-06-23 02:22:45.106150
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual

    module = AnsibleModule(
        argument_spec = dict()
    )

    def set_module_run_command_args(rc, out, err):
        module.run_command = lambda *args, **kwargs: (rc, out, err)

    hpux_virtual = HPUXVirtual(module)
    # test hpux virtualization_role and virtualization_type in case of /usr/sbin/vecheck:
    set_module_run_command_args(0, '', '')
    hpux_virtual._facts['ansible_virtualization_type'] = None
    hpux_virtual._facts['ansible_virtualization_role'] = None
    hpux_virtual.get_virtual_facts()
    assert hpux_virtual._

# Generated at 2022-06-23 02:22:47.346825
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    collected_facts = {
        'virtualization_type': 'guest',
        'virtualization_role': 'HP vPar',
        'virtualization_tech_guest': set(['HP vPar']),
        'virtualization_tech_host': set([]),
    }
    virtual = HPUXVirtual({})
    assert collected_facts == virtual.get_virtual_facts()

# Generated at 2022-06-23 02:22:49.792103
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt = HPUXVirtual(dict(module=dict()))
    assert virt.platform == 'HP-UX'


# Generated at 2022-06-23 02:22:52.998549
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    # Unit test for constructor of class HPUXVirtualCollector
    _h = HPUXVirtualCollector(None)
    print("test_HPUXVirtualCollector ok")


# Generated at 2022-06-23 02:23:03.290160
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    import platform
    # using the HP-UX class name here to be able to check if the output fact class is the HP-UX
    # one and not the generic Unix one
    instance = HPUXVirtualCollector(platform.system(), platform.machine())
    assert instance.fact_class.platform == 'HP-UX'
    assert instance.fact_class.__name__ == 'HPUXVirtual'
    assert instance._platform == 'HP-UX'
    # test the guest/host virtualization names
    assert 'HP vPar' in instance._virtual_types
    assert 'HPVM vPar' in instance._virtual_types
    assert 'HPVM IVM' in instance._virtual_types
    assert 'HPVM' in instance._virtual_types
    assert 'HP nPar' in instance._virtual_types

# Generated at 2022-06-23 02:23:03.930344
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-23 02:23:05.484168
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual()
    assert v.platform == 'HP-UX'

# Generated at 2022-06-23 02:23:07.996686
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.__class__.__name__ == 'HPUXVirtual'

# Generated at 2022-06-23 02:23:17.578257
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class TestModule:
        def run_command(self):
            return 0, "", ""

    class TestAnsibleModule:
        def __init__(self):
            self.params = {}
            self.run_command = TestModule().run_command

    x = HPUXVirtual(TestAnsibleModule())
    facts = x.get_virtual_facts()
    assert facts['virtualization_type'] == 'host'
    assert facts['virtualization_role'] == 'HPVM'
    assert facts['virtualization_tech_host'] == {'HPVM'}
    assert facts['virtualization_tech_guest'] == {'HPVM'}

# Generated at 2022-06-23 02:23:24.105622
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    fake_module = FakeAnsibleModule()
    fake_module.params = {}
    facts = HPUXVirtual(fake_module).get_virtual_facts()

    assert len(facts['virtualization_tech_guest']) == 1
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP nPar'


# Generated at 2022-06-23 02:23:25.623307
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-23 02:23:27.067474
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv is not None


# Generated at 2022-06-23 02:23:30.269324
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpu = HPUXVirtualCollector()
    assert hpu._fact_class.platform == 'HP-UX'

# Generated at 2022-06-23 02:23:31.198673
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-23 02:23:32.334370
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual()

# Generated at 2022-06-23 02:23:36.539703
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector()
    assert collector
    assert collector.platform == 'HP-UX'
    assert collector.fact_class == HPUXVirtual
    assert collector.fact == HPUXVirtual()

# Generated at 2022-06-23 02:23:47.525185
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts import ModuleStub

    stub_module = ModuleStub(dict(HOME="/", PATH="/usr/bin:/usr/sbin:/bin:/sbin"))

    # HPUXVirtual object pointing to the HPUXVirtual class.
    # This object can be used to call methods from the class HPUXVirtual
    hpux_virtual = HPUXVirtual(stub_module)

    # Test for virtualization_tech_host
    # Mock os.path.exists("/opt/hpvm/bin/hpvminfo") returning True
    # To get virtualization_tech_host = {'HPVM'}