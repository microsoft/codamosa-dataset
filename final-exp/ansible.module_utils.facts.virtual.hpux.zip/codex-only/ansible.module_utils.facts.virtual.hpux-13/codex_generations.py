

# Generated at 2022-06-23 02:13:42.602412
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    host = HPUXVirtual({})
    assert host.virtual.platform == 'HP-UX'
    assert host.virtual.virtualization_role == ''

# Generated at 2022-06-23 02:13:44.861764
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert isinstance(HPUXVirtual(), Virtual)


# Generated at 2022-06-23 02:13:53.709187
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    args = dict(module_utils='ansible.module_utils.facts.virtual.hpux.HPUXModule')
    test_class = HPUXVirtual(args)
    test_virtual = test_class.get_virtual_facts()
    assert test_virtual['virtualization_tech_guest'] is not None
    assert test_virtual['virtualization_tech_host'] is not None

# Generated at 2022-06-23 02:13:57.277323
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """
     Unit test for constructor of class HPUXVirtualCollector
     """
    platform_facts = {}
    virtual_facts = {}
    module = None
    HPUXVirtualCollector(module, platform_facts, virtual_facts)



# Generated at 2022-06-23 02:13:59.882373
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual({})
    assert v.platform == 'HP-UX', "Failed to setup HPUXVirtual"


# Generated at 2022-06-23 02:14:05.267791
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    VirtualCollector.collector_class = HPUXVirtualCollector
    assert VirtualCollector.collector_class
    assert VirtualCollector.collector_class._platform == 'HP-UX'
    assert VirtualCollector.collector_class._fact_class == HPUXVirtual



# Generated at 2022-06-23 02:14:08.308808
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    This will test the constructor of HPUXVirtual class.
    """
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-23 02:14:10.482960
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpv = HPUXVirtualCollector()
    assert hpv._fact_class == HPUXVirtual
    assert hpv._platform == 'HP-UX'

# Generated at 2022-06-23 02:14:11.633639
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()



# Generated at 2022-06-23 02:14:16.206920
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual({}, {})
    assert virtual.platform == 'HP-UX'
    assert not hasattr(virtual, 'virtualization_type')
    assert not hasattr(virtual, 'virtualization_role')
    assert not hasattr(virtual, 'virtualization_tech_guest')
    assert not hasattr(virtual, 'virtualization_tech_host')


# Generated at 2022-06-23 02:14:20.312732
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = {'virtualization_tech_guest': set(['HPVM IVM']), 'virtualization_type': 'guest',
                   'virtualization_role': 'HPVM IVM', 'virtualization_tech_host': set([])}
    assert HPUXVirtual(None).get_virtual_facts() == virtual_obj



# Generated at 2022-06-23 02:14:23.111493
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual()
    assert virtual_obj.platform == 'HP-UX'
    assert virtual_obj.get_virtual_facts() == {}

# Generated at 2022-06-23 02:14:24.538373
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    test_obj = HPUXVirtual()


# Generated at 2022-06-23 02:14:36.090288
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import _VirtualFactCollector
    from ansible.module_utils.facts import _HPUXVirtualInfo
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector

    # instantiate HPUXVirtual class without calling __init__
    hv = Virtual()

    # set global options and parameters
    hv.module = _VirtualFactCollector
    hv.module.get_bin_path = lambda *args: '/usr/sbin/vecheck'
    hv.module.run_command = lambda *args, **kwargs: (0, '', '')
    hv.dmesg = ''

    # set options and parameters of hpuxvi object
    hv.hpuxvi = _HPUXVirtualInfo()
    hv.hpuxvi.hpvm

# Generated at 2022-06-23 02:14:46.228997
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    HPUXVirtual_get_virtual_facts() - test get_virtual_facts

    Input data to test against.
    """
    # pylint: disable=line-too-long
    TEST_DATA = (
        # distribution_name, distribution_version
        ('HP-UX', 'B.11.31'),
        ('HP-UX', 'B.11.31'),
        ('other', '1.0')
    )

    for distribution_name, distribution_version in TEST_DATA:
        yield check_HPUXVirtual_get_virtual_facts, distribution_name, distribution_version



# Generated at 2022-06-23 02:14:49.800993
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-23 02:15:00.557122
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class ModuleStub:
        def __init__(self):
            self.run_command_count = 0
            self.run_command_args = []

        def run_command(self, arg):
            self.run_command_count += 1
            self.run_command_args.append(arg)
            if arg == '/usr/sbin/vecheck':
                return (0, 'success', 'error')
            elif arg == '/opt/hpvm/bin/hpvminfo':
                return (0, 'Running HPVM vPar', 'error')
            elif arg == '/usr/sbin/parstatus':
                return (0, 'success', 'error')
            else:
                return (1, '', 'error')

        def fail_json(self, **args):
            pass

    module = ModuleStub()

# Generated at 2022-06-23 02:15:11.376781
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import ModuleStub

# Generated at 2022-06-23 02:15:13.706791
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector()
    assert collector.platform == "HP-UX"
    assert collector.fact_class == HPUXVirtual

# Generated at 2022-06-23 02:15:18.621050
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    obj = HPUXVirtual({})
    assert obj.vendor == 'Hewlett-Packard Company'
    assert obj.platform == 'HP-UX'
    obj = HPUXVirtual({'platform': 'Foo'})
    assert obj.platform == 'Foo'



# Generated at 2022-06-23 02:15:29.639832
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Create an instance of class HPUXVirtual
    hpux_virtual = HPUXVirtual()
    hpux_virtual.module = MockModule()

    # Set up the dummy contents of files that we expect
    # hpux_virtual.module.get_bin_path to return when
    # invoked with various parameter values
    hpux_virtual.module.get_bin_path.side_effect = [
        "",
        "/usr/sbin/vecheck",
        "/opt/hpvm/bin/hpvminfo",
        "/usr/sbin/parstatus",
    ]

    # Set up the dummy output of the commands that we expect
    # hpux_virtual.module.run_command to return when
    # invoked with various parameter values

# Generated at 2022-06-23 02:15:40.585696
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import FactModule
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils._text import to_text

    class TestModule(object):
        def __init__(self):
            self.params = dict()
            self.run_command_environ_update = dict()

    class TestClassHPUXVirtual(HPUXVirtual):
        def __init__(self, module):
            super(TestClassHPUXVirtual, self).__init__(module)
            self._facts = dict()

        @property
        def facts(self):
            return self._facts


# Generated at 2022-06-23 02:15:49.167195
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Test HPUXVirtual.get_virtual_facts.
    """

    import sys
    if sys.version_info[0] < 3:
        # Python 2.X
        import mock
        builtin_module = '__builtin__'
    else:
        # Python 3.X
        import unittest.mock as mock
        builtin_module = 'builtins'

    # This mocks the implementation of run_command as used in HPUXVirtual.
    # Upon calling, it updates the dictionary of run_command_results
    # with the command to execute as key and the expected out and err.
    run_command_results = {}
    def mocked_run_command(self, command, check_rc=True, close_fds=True):
        if command not in run_command_results:
            self.fail

# Generated at 2022-06-23 02:15:50.443524
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    d = HPUXVirtual()
    assert d.platform == 'HP-UX'


# Generated at 2022-06-23 02:15:52.063461
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt = HPUXVirtual({})
    assert virt._platform == 'HP-UX'
    assert virt.get_virtual_facts() == {}

# Generated at 2022-06-23 02:15:54.937668
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    facts = {}
    platform = 'HP-UX'
    virtual_collector = HPUXVirtualCollector(facts, platform)
    assert virtual_collector._facts == facts
    assert virtual_collector._platform == platform


# Generated at 2022-06-23 02:15:58.479770
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector('module', {})
    assert x.platform == 'HP-UX'
    assert x.fact_class._platform == 'HP-UX'


# Generated at 2022-06-23 02:15:59.548799
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():

    HPUXVirtualCollector()

# Generated at 2022-06-23 02:16:01.923236
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector
    assert collector._fact_class is HPUXVirtual
    assert collector._platform is 'HP-UX'



# Generated at 2022-06-23 02:16:13.744097
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # Create a mock module and namespaces
    fake_module = type('AnsibleModule', (object,), {'run_command': lambda *x: [0, '', '']})
    namespace = type('AnsibleNamespace', (object,), {'module': fake_module})
    setattr(namespace, 'virtual_subclass', HPUXVirtual)

    # Create an instance and call get_virtual_facts method
    hpux_virtual = HPUXVirtual(namespace)
    virtual_facts = hpux_virtual.get_virtual_facts()

    # Assert that the keys exist in the returned dictionary
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host'

# Generated at 2022-06-23 02:16:23.715025
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = FakeModule()
    hpux_virtual = HPUXVirtual(module)
    hpux_virtual.get_virtual_facts()
    assert len(hpux_virtual.facts['virtualization_tech_guest']) == 2
    assert 'HPVM' in hpux_virtual.facts['virtualization_tech_guest']
    assert 'HP nPar' in hpux_virtual.facts['virtualization_tech_guest']
    assert 'HPVM' in hpux_virtual.facts['virtualization_tech_host']
    assert hpux_virtual.facts['virtualization_type'] == 'guest'
    assert hpux_virtual.facts['virtualization_role'] == 'HP nPar'


# Generated at 2022-06-23 02:16:26.039498
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv._platform == 'HP-UX'


# Generated at 2022-06-23 02:16:38.411722
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector

    HPUXVirtualCollector.collect()
    assert Virtual.virtualization_type == 'guest'
    assert Virtual.virtualization_role == 'HPVM'
    assert Virtual.virtualization_tech_guest == set('HPVM')
    assert Virtual.virtualization_tech_host == set()

    HPUXVirtual.get_virtual_facts()
    assert HPUXVirtual.virtualization_type == 'guest'
    assert HPUXVirtual.virtualization_role == 'HPVM'

# Generated at 2022-06-23 02:16:40.256880
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts_instance = HPUXVirtual()
    assert virtual_facts_instance.platform == 'HP-UX'

# Generated at 2022-06-23 02:16:44.654787
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(None)
    print("HPUXVirtual: " + repr(virtual_facts))
    assert 'HPUXVirtual' == virtual_facts.__class__.__name__
    assert 'virtual' == virtual_facts.subclass

# Generated at 2022-06-23 02:16:47.456453
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    virtual_instance = HPUXVirtual()
    assert virtual_instance.platform == 'HP-UX'

# Generated at 2022-06-23 02:16:57.186501
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    ''' Unit test for method get_virtual_facts of class HPUXVirtual '''
    hpux_virtual = HPUXVirtual({}, {})
    hpux_virtual.module.run_command = lambda x: (0, '', '')
    # Case 1: if  rc == 0, set virtualization_type to guest
    hpux_virtual.module.run_command = lambda x: (0, '', '')
    assert hpux_virtual.get_virtual_facts()['virtualization_type'] == 'guest'
    # Case 2: if  rc != 0, virtualization_type remains empty set
    hpux_virtual.module.run_command = lambda x: (1, '', '')
    assert not hpux_virtual.get_virtual_facts()['virtualization_type']


# Generated at 2022-06-23 02:16:59.328948
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    info = HPUXVirtual()
    assert info.platform == 'HP-UX'


# Generated at 2022-06-23 02:17:06.642237
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    from ansible.module_utils.facts import FactCollector

    collector = FactCollector(HPUXVirtual)
    virtual_facts = HPUXVirtual({},{},{})
    result = collector._process_virtual(virtual_facts)
    assert 'virtualization_role' in result['virtualization']
    assert 'virtualization_type' in result['virtualization']
    assert 'HP nPar' in result['virtualization']['virtualization_role']

# Generated at 2022-06-23 02:17:12.276941
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    mod_args = dict()
    mod_args['run_command'] = M_run_command
    m = HPUXVirtual(module=MockedModule(params=mod_args))
    vf = m.get_virtual_facts()
    assert vf['virtualization_type'] == 'guest'
    assert vf['virtualization_role'] == 'HPVM vPar'



# Generated at 2022-06-23 02:17:14.470879
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_fact_collector = HPUXVirtualCollector()
    assert virtual_fact_collector._platform == 'HP-UX'


# Generated at 2022-06-23 02:17:16.624312
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = AnsibleModule(argument_spec={})
    assert(HPUXVirtualCollector(module) is not None)


# Generated at 2022-06-23 02:17:20.180250
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = AnsibleModuleMock()
    virtual = HPUXVirtual(module)
    assert virtual.platform == 'HP-UX'
    assert virtual.module == module


# Generated at 2022-06-23 02:17:30.160590
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class AnsibleModule:
        def __init__(self):
            pass
        def run_command(self,cmd):
            if re.match('.*vecheck.*', cmd):
                return 0, 'HP vPar', None
            elif re.match('.*hpvminfo.*', cmd):
                return 0, 'Running\nHPVM vPar', None
            elif re.match('.*parstatus.*', cmd):
                return 0, 'HP nPar', None
            elif re.match('.*uname.*', cmd):
                return 0, 'HP-UX', None
            else:
                return 0, '', None
        def fail_json(self, *args):
            pass
    module = AnsibleModule()

    v = HPUXVirtual(module)
    virtual_facts = v.get_virtual

# Generated at 2022-06-23 02:17:40.998872
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    '''
    unit test for method get_virtual_facts of class HPUXVirtual
    '''

    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual

    from ansible.module_utils.facts.collector import BaseFactCollector

    hpux_virtual_collector = BaseFactCollector()
    hpux_virtual_collector.collect()

    hpux_virtual_collector._data['virtualization_type'] = None
    hpux_virtual_collector._data['virtualization_role'] = None

    hpux_virtual_collector._data['virtualization_tech_guest'] = set()
    hpux_virtual_collector._data['virtualization_tech_host'] = set()

    hpux_virtual = HPUXVirtual(hpux_virtual_collector)
    hpux_

# Generated at 2022-06-23 02:17:49.056503
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Unit test should create a temporary module and run get_virtual_facts over that
    # This function is meant to be used in unit testing
    # Parameters:
    #   module : (instance) Used to run commands on the vm
    #   os_family : (str) Used to override facts in the event of failover
    #   os_name : (str) Used to override facts in the event of failover
    # Return value:
    #   virtual_facts : (dict)
    module = {}
    virtual_facts = HPUXVirtual(module).get_virtual_facts()
    return virtual_facts

# Generated at 2022-06-23 02:17:57.486197
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    results = HPUXVirtual().get_virtual_facts()
    assert results['virtualization_tech_host'] == set()
    assert results['virtualization_tech_guest'] == set()
    assert results['virtualization_type'] == 'host'  # Default value
    assert results['virtualization_role'] == 'HP-UX'  # Default value


# Generated at 2022-06-23 02:18:07.399499
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class LinuxModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def run_command(self, cmd):
            return self.rc, self.out, self.err

    def get_module(out):
        if out == 'vecheck':
            rc = 0
            err = ''
            out = 'The "vecheck" system is running.'
        elif out == 'hpvminfo':
            rc = 0
            err = ''
            out = 'Running as HPVM vPar'
        elif out == 'parstatus':
            rc = 0
            err = ''
            out = 'Running as NPAR'
        else:
            rc = 0
            out = ''
            err = ''

# Generated at 2022-06-23 02:18:08.966880
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    a = HPUXVirtualCollector()
    assert isinstance(a, VirtualCollector)

# Generated at 2022-06-23 02:18:11.705290
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector.platform == 'HP-UX'
    assert HPUXVirtualCollector.fact_class == HPUXVirtual


# Generated at 2022-06-23 02:18:14.039308
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector(None)
    assert collector.platform == 'HP-UX'


# Generated at 2022-06-23 02:18:18.628429
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # mock a ansible module
    module = MockAnsibleModule()
    virtual = HPUXVirtual(module)
    assert virtual._platform == 'HP-UX'
    assert virtual._fact_class.__name__ == 'HPUXVirtual'
    assert virtual._collector.__name__ == 'HPUXVirtualCollector'


# Generated at 2022-06-23 02:18:21.425266
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    assert obj
    assert obj._platform == 'HP-UX'
    assert obj._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:18:22.896847
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpu = HPUXVirtual()
    assert hpu._platform == 'HP-UX'

# Generated at 2022-06-23 02:18:28.741450
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual({})
    assert v._platform == 'HP-UX'
    assert v._fact_class is None
    assert v.virtualization_type is None
    assert v.virtualization_role is None
    assert v.virtualization_tech_guest == set()
    assert v.virtualization_tech_host == set()
    assert v.virtualization_status is None


# Generated at 2022-06-23 02:18:36.241137
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual()
    assert hasattr(virtual_obj, 'platform')
    assert hasattr(virtual_obj, 'get_virtual_facts')

# Generated at 2022-06-23 02:18:48.010008
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import ModuleStub
    from ansible.module_utils.facts.virtual import Collector
    from ansible.module_utils.facts.virtual.hpu import HPUXVirtual

    hpux_virtual = HPUXVirtual()
    hpux_collector = Collector()

    hpux_virtual.module = ModuleStub()
    hpux_virtual.module.run_command = lambda x: (0, "HPVM vPar is running", None)
    hpux_collector.module = ModuleStub()
    hpux_collector.module.run_command = lambda x: (0, "HPVM vPar is running", None)

    assert hpux_collector.get_virtual_facts() == hpux_virtual.get_virtual_facts()

# Generated at 2022-06-23 02:18:48.670592
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual()

# Generated at 2022-06-23 02:18:50.069367
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    o = HPUXVirtual({})
    assert o.platform == 'HP-UX'

# Generated at 2022-06-23 02:18:51.296137
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector._platform == 'HP-UX'

# Generated at 2022-06-23 02:18:58.756702
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = MockAnsibleModule()
    module.run_command.side_effect = run_command_mock
    virtual_facts = HPUXVirtual(module).get_virtual_facts()
    assert(virtual_facts['virtualization_type'] == 'guest')
    assert(virtual_facts['virtualization_role'] == 'HP nPar')
    assert(virtual_facts['virtualization_tech_guest'] == set(['HP nPar']))
    assert(virtual_facts['virtualization_tech_host'] == set())


# Generated at 2022-06-23 02:19:02.686645
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    facts = dict()
    facts['ansible_os_family'] = 'HP-UX'
    test_HPUXVirtualCollector = HPUXVirtualCollector(facts=facts)
    assert test_HPUXVirtualCollector._platform == 'HP-UX'

# Generated at 2022-06-23 02:19:08.417812
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    from ansible.module_utils._text import to_text
    hv = HPUXVirtualCollector.fetch_virtual_facts(module=None)
    assert hv.virtualization_type == 'guest'
    assert hv.virtualization_role == 'HP vPar'
    assert to_text(hv.virtualization_tech_host) == to_text(set())
    assert to_text(hv.virtualization_tech_guest) == to_text(set(['HP vPar']))

# Generated at 2022-06-23 02:19:19.535717
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    mymodule = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    if not os.path.exists('/usr/sbin/parstatus'):
        del os.environ["MOCK_HPUX_VIRTUAL"]
        mymodule.exit_json(changed=True, ansible_facts={})
    os.environ["MOCK_HPUX_VIRTUAL"] = "True"

    HPUX_virtual_facts = HPUXVirtual(mymodule)

    virtual_facts_result = HPUX_virtual_facts.get_virtual_facts()
    assert virtual_facts_result['virtualization_type'] == 'guest'
    assert virtual_facts_result['virtualization_role'] == 'HP nPar'

    # Run it again to make sure the values

# Generated at 2022-06-23 02:19:21.625101
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt = HPUXVirtual({})
    assert virt.platform == 'HP-UX'


# Generated at 2022-06-23 02:19:25.088325
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    test_obj = HPUXVirtualCollector()
    assert test_obj
    assert test_obj.platform == 'HP-UX'
    assert test_obj._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:19:25.706279
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    return

# Generated at 2022-06-23 02:19:28.065094
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_collector = HPUXVirtual()
    assert virtual_collector.platform == 'HP-UX'



# Generated at 2022-06-23 02:19:29.947106
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual()
    assert virtual_obj.platform == 'HP-UX'

# Generated at 2022-06-23 02:19:31.790451
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert x._platform == 'HP-UX'
    assert issubclass(x._fact_class, Virtual)

# Generated at 2022-06-23 02:19:35.544338
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    # HPUXVirtualCollector is singleton class,
    # so calling constructor twice will return
    # same class
    hv1 = HPUXVirtualCollector()
    hv2 = HPUXVirtualCollector()
    assert hv1 == hv2



# Generated at 2022-06-23 02:19:45.381552
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual

    class HPModule(object):
        def __init__(self):
            self.run_command_results = {
                '/usr/sbin/vecheck': (0, None, None),
                '/opt/hpvm/bin/hpvminfo': (0, '', None),
                '/usr/sbin/parstatus': (0, None, None),
            }
            self.params = {
                'run_command_environ_update': {
                    'LANG': 'C',
                    'LC_ALL': 'C'
                }
            }

        def run_command(self, args):
            if args in self.run_command_results:
                return self.run_command_results[args]
            else:
                raise Runtime

# Generated at 2022-06-23 02:19:46.642605
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual()


# Generated at 2022-06-23 02:19:48.015105
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpux_vc = HPUXVirtualCollector()
    assert hpux_vc.platform == 'HP-UX'

# Generated at 2022-06-23 02:19:51.075302
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Run method with parameters
    hpx = HPUXVirtual(dict(module=dict()))
    assert isinstance(hpx, HPUXVirtual)
    assert isinstance(hpx.get_virtual_facts(), dict)

# Generated at 2022-06-23 02:19:54.240090
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    result = virtual_facts.get_all_facts()
    assert 'virtualization_type' in result

# Generated at 2022-06-23 02:19:56.735295
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hp = HPUXVirtual()
    assert hp.platform == 'HP-UX'
    assert hp.module == None


# Generated at 2022-06-23 02:20:00.603668
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpux_virtual = HPUXVirtualCollector()

    assert hpux_virtual._platform == 'HP-UX'
    assert hpux_virtual._fact_class.__name__ == "HPUXVirtual"

# Generated at 2022-06-23 02:20:02.620984
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector._platform == 'HP-UX'
    assert HPUXVirtualCollector._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:20:11.587739
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class RunCommand(object):
        def __init__(self,out,rc=0):
            self.out = out
            self.rc = rc
        def __call__(self,command):
            return self.rc, self.out, ''
    class Module(object):
        def __init__(self,run_command):
            self.run_command = run_command
    from ansible.module_utils.facts import virtual
    hvm = HPUXVirtual(Module(RunCommand('')))
    virtual_facts = hvm.get_virtual_facts()
    assert 'virtualization_type' not in virtual_facts
    assert 'virtualization_role' not in virtual_facts

    hvm = HPUXVirtual(Module(RunCommand('Running HPVM vPar')))
    virtual_facts = hvm.get_virtual_facts

# Generated at 2022-06-23 02:20:17.208847
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = AnsibleModuleMock()
    filename = '/etc/system-release'
    if os.path.exists(filename):
        with open(filename) as fh:
            release = fh.read()
        if "Hewlett-Packard Company" in release:
            # Create an instance of HPUXVirtual
            hpux_virtual = HPUXVirtual(module)
            assert hpux_virtual is not None
        else:
            assert False
    else:
        assert False

# Generated at 2022-06-23 02:20:19.300571
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
  h=HPUXVirtualCollector()
  assert h.__class__.__name__ == 'HPUXVirtualCollector'

# Unit tests for class HPUXVirtual

# Generated at 2022-06-23 02:20:21.583049
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    # test1: Default constructor
    x = HPUXVirtualCollector()
    assert x.platform == "HP-UX"
    assert x._fact_class == HPUXVirtual
    assert x.collect() == dict(virtualization_type=None, virtualization_role=None, virtualization_tech_guest=set(), virtualization_tech_host=set())

# Generated at 2022-06-23 02:20:23.271729
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtualCollector = HPUXVirtualCollector()
    assert virtualCollector.platform == 'HP-UX'

# Generated at 2022-06-23 02:20:24.853971
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual()
    assert virtual.platform == 'HP-UX'

# Generated at 2022-06-23 02:20:27.716929
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vc = HPUXVirtualCollector()
    assert isinstance(vc._fact_class(None), HPUXVirtual)
    assert vc._platform == 'HP-UX'

# Generated at 2022-06-23 02:20:29.310676
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt = HPUXVirtual(dict())
    assert 'HP-UX' == virt.platform

# Generated at 2022-06-23 02:20:31.640740
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpux_virtual_collector = HPUXVirtualCollector()
    assert hpux_virtual_collector is not None

# Generated at 2022-06-23 02:20:39.814052
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = FakeModule()
    hpux_virtual = HPUXVirtual(module)
    hpux_virtual.get_virtual_facts()
    expected_virtual_facts = {'virtualization_type': 'guest',
                              'virtualization_role': 'HPVM IVM',
                              'virtualization_tech_guest': set(['HPVM']),
                              'virtualization_tech_host': set([])}
    assert hpux_virtual.facts == expected_virtual_facts



# Generated at 2022-06-23 02:20:42.590133
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual('/')
    assert virtual.platform == 'HP-UX'

# Generated at 2022-06-23 02:20:45.684547
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    c = HPUXVirtualCollector()
    assert c.get_virtual_facts()



# Generated at 2022-06-23 02:20:48.765192
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = HPUXVirtual(dict(), dict())
    assert HPUXVirtual.platform == 'HP-UX'


# Generated at 2022-06-23 02:20:50.506369
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    _HPUXVirtual = HPUXVirtual({})
    assert _HPUXVirtual.platform == 'HP-UX'

# Generated at 2022-06-23 02:20:52.885618
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv._platform == 'HP-UX'
    assert hv._fact_class == HPUXVirtual
    assert hv._fact_class.platform == 'HP-UX'

# Generated at 2022-06-23 02:20:55.960903
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    facts = {}
    hv = HPUXVirtualCollector(facts, None)
    assert hv._platform is "HP-UX"
    assert hv._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:21:06.656283
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    #===================================================================================================================
    # Global variables and constants
    #===================================================================================================================
    module_name = 'ansible_collections.ansible.community.tests.unit.module_utils.facts.virtual'
    test_module_path = '%s.%s.%s' % (module_name, 'HPUXVirtual', 'HPUXVirtual')
    test_module = __import__(test_module_path, fromlist=[''])
    from ansible_collections.ansible.community.tests.unit.compat.mock import Mock, MagicMock, patch, PropertyMock
    #===================================================================================================================
    # Test cases
    #===================================================================================================================

    class TestHPUXVirtual(test_module.HPUXVirtual):
        def __init__(self, module):
            self.module = module

   

# Generated at 2022-06-23 02:21:12.279957
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    obj = HPUXVirtual(None)
    obj.get_virtual_facts()
    assert obj.virtualization_tech_guest == set()
    assert obj.virtualization_tech_host == set()
    assert obj.virtualization_type is None
    assert obj.virtualization_role is None


# Generated at 2022-06-23 02:21:14.919264
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    f = HPUXVirtualCollector()
    assert f.platform == 'HP-UX'
    assert f._fact_class == HPUXVirtual



# Generated at 2022-06-23 02:21:20.111581
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    facts = dict()
    module = FakeAnsibleModule(facts)
    vc_obj = HPUXVirtualCollector(module)
    assert vc_obj.platform == 'HP-UX'
    assert vc_obj._fact_class == HPUXVirtual
    assert vc_obj._platform == 'HP-UX'
    assert vc_obj.module == module


# Generated at 2022-06-23 02:21:22.031189
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPTestobj = HPUXVirtual({})
    assert HPTestobj.platform == 'HP-UX'



# Generated at 2022-06-23 02:21:23.967262
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert virtual_collector._platform == 'HP-UX'

# Generated at 2022-06-23 02:21:34.210053
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    m = FakeModule()
    os.environ['PATH'] = '/opt/hpvm/bin:/usr/sbin'
    os.path.exists = FakePathExists(True)
    hpuxvirtual = HPUXVirtual(m)
    hpuxvirtual.get_virtual_facts()
    os.path.exists = FakePathExists(False)
    assert hpuxvirtual.virtual_facts['virtualization_tech_guest'] == set(['HPVM'])
    assert hpuxvirtual.virtual_facts['virtualization_tech_host'] == set([])
    assert hpuxvirtual.virtual_facts['virtualization_type'] == 'host'
    assert hpuxvirtual.virtual_facts['virtualization_role'] == 'HPVM'
    os.path.exists = FakePathExists(True)
    hpuxvirtual.get

# Generated at 2022-06-23 02:21:46.304871
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Initialize class
    ivm = HPUXVirtual({})

    # Unit test case 1 - when /usr/sbin/vecheck and /usr/sbin/parstatus exists
    ivm.get_file_exists_mock = True
    ivm.module.run_command_mock = [(0, '', ''), (0, '', '')]
    ivm.module.run_command_isroot_mock = True
    facts_dict = ivm.get_virtual_facts()
    expected = {'virtualization_type': 'guest',
                'virtualization_tech_host': set(['HPVM']),
                'virtualization_tech_guest': set(['HP nPar', 'HP vPar']),
                'virtualization_role': 'HP vPar'}

# Generated at 2022-06-23 02:21:49.045202
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    # Test HPUXVirtualCollector's constructor.
    assert virtual_collector._platform == 'HP-UX'

# Generated at 2022-06-23 02:21:52.518005
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    mmodule = type('module', (), {'run_command': lambda *args, **kwargs: (0, '', '')})()
    facts = HPUXVirtual(mmodule)
    assert facts.platform == 'HP-UX'



# Generated at 2022-06-23 02:21:54.784635
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hw = HPUXVirtual(None)
    assert hw.platform == 'HP-UX'

### Unit tests for get_virtual_facts()

# Generated at 2022-06-23 02:21:58.007363
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    mod = AnsibleModule(argument_spec={'gather_subset': dict(default=['!all'], type='list')})
    vm = HPUXVirtual(module=mod)
    virtual_facts = vm.get_virtual_facts()

# Generated at 2022-06-23 02:22:07.926695
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = DummyAnsibleModule()
    result = HPUXVirtualCollector.gather_virtual_facts(module)['ansible_facts']['virtualization']
    assert result == {
        'domain': None,
        'hypervisor': None,
        'is_guest': False,
        'is_host': None,
        'product_name': None,
        'role': None,
        'system': None,
        'type': None,
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
        'virtualization_type': None,
        'virtualization_role': None
    }
#
# Unit test class definition
#

# Generated at 2022-06-23 02:22:19.035461
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import os
    import tempfile

    tfile = tempfile.NamedTemporaryFile()
    # Test when vecheck file is present

# Generated at 2022-06-23 02:22:21.701766
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpv = HPUXVirtual()
    assert hpv.platform == 'HP-UX'
    assert hpv.get_virtual_facts() is not None

# Generated at 2022-06-23 02:22:24.541537
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    '''
    Get virtual facts on HP-UX systems
    :return: dictionary of keys with their respective values
    '''
    virtual_facts = {}
    virtual_facts = HPUXVirtual().get_virtual_facts()
    return virtual_facts

# Generated at 2022-06-23 02:22:30.263156
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual(dict()).platform == 'HP-UX'
    assert HPUXVirtual(dict())._platform == 'HP-UX'
    assert HPUXVirtual(dict())._fact_class.platform == 'HP-UX'
    assert HPUXVirtual(dict()).get_virtual_facts() == dict()


# Generated at 2022-06-23 02:22:39.040860
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Init
    test_module_path = os.path.dirname(__file__)
    test_module_path = test_module_path.replace(os.sep, "/")
    test_data_path = test_module_path + "/virtual_data/"
    test_module = type('HPUXVirtual')
    hpux_virtual = HPUXVirtual(test_module)
    virtual_facts = {}
    guest_tech = set()
    host_tech = set()


# Generated at 2022-06-23 02:22:43.663531
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({}, {})
    assert virtual_facts.platform == "HP-UX"
    assert virtual_facts.virtualization_type is None

# test_HPUXVirtual_fails_missing_command

# Generated at 2022-06-23 02:22:44.737741
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-23 02:22:55.516575
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpar import HPUXVirtual
    hpar_virtual_facts = HPUXVirtual()
    hpar_virtual_facts.module.run_command.return_value = (0, 'HP-UX V4.0', '')
    hpar_facts = hpar_virtual_facts.get_virtual_facts()
    assert hpar_facts['virtualization_type'] == 'guest'
    assert hpar_facts['virtualization_role'] == 'HP vPar'
    assert 'HP vPar' in hpar_facts['virtualization_tech_guest']
    assert 'HP nPar' not in hpar_facts['virtualization_tech_guest']
    assert hpar_facts['virtualization_type'] == 'guest'

# Generated at 2022-06-23 02:23:03.835665
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class ModuleStub():
        def __init__(self):
            pass

        def run_command(self, cmd):
            if cmd == "/usr/sbin/vecheck":
                return (0, "", "")
            elif cmd == "/opt/hpvm/bin/hpvminfo":
                return (0, "Running HPVM guest", "")
            elif cmd == "/usr/sbin/parstatus":
                return (0, "", "")

    moduleStub = ModuleStub()
    hpux = HPUXVirtual(moduleStub)
    facts = hpux.get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HPVM IVM'
    assert facts['virtualization_tech_host'] == set()
    assert facts

# Generated at 2022-06-23 02:23:05.339419
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual()

    assert(virtual)
    assert(virtual.platform == 'HP-UX')


# Generated at 2022-06-23 02:23:15.068702
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h = HPUXVirtual({'ansible_facts': {}})
    virtual_facts = h.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert virtual_facts['virtualization_type'] in ['guest', 'host']
    assert virtual_facts['virtualization_role'] in ['HP vPar', 'HPVM vPar', 'HPVM IVM', 'HP nPar']

# Generated at 2022-06-23 02:23:16.254279
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtual()
    assert obj.platform == 'HP-UX'

# Generated at 2022-06-23 02:23:18.812393
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual


# Generated at 2022-06-23 02:23:22.007186
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_instance = HPUXVirtualCollector()
    assert virtual_instance._platform == 'HP-UX'
    assert virtual_instance._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:23:25.820031
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import ansible.module_utils.facts.virtual.hpu as hpu
    dummy_class = hpu.HPUXVirtual(module='dummy_module')
    # must return a dictionary
    assert ( type(dummy_class.get_virtual_facts()) == dict )

# Generated at 2022-06-23 02:23:31.726383
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux_collector import HPUXVirtual
    facts = HPUXVirtual({})
    virtual_facts = facts.get_virtual_facts()
    assert (virtual_facts['virtualization_type'] == 'guest')
    assert (virtual_facts['virtualization_role'] == 'HP vPar')

# Generated at 2022-06-23 02:23:35.541418
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vc = HPUXVirtualCollector()
    assert vc._platform == 'HP-UX'
    assert vc._fact_class.__name__ == 'HPUXVirtual'

# Generated at 2022-06-23 02:23:45.258006
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class HPUXVirtual
    """
    import tempfile

    test_file_path = {}

    def run_command_side_effect(command):
        if command == "/usr/sbin/vecheck":
            return (0, "", "")
        elif command == "/opt/hpvm/bin/hpvminfo":
            return (0, "Running hpvm guest", "")
        elif command == "/usr/sbin/parstatus":
            return (0, "", "")
        else:
            raise Exception("Unknown command %s" % command)

    def exists_side_effect(path):
        """ Fake os.path.exists """