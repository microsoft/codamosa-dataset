

# Generated at 2022-06-23 02:13:42.270495
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-23 02:13:45.210534
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpuxvirtual_obj = HPUXVirtual(dict())
    assert hpuxvirtual_obj.platform == 'HP-UX'

# Generated at 2022-06-23 02:13:51.661474
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    assert isinstance(obj, HPUXVirtualCollector)
    assert obj.platform == 'HP-UX'
    assert obj._fact_class == HPUXVirtual



# Generated at 2022-06-23 02:13:54.850618
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    m = VirtualCollector().get_virtual_collector('HP-UX')
    assert isinstance(m, HPUXVirtualCollector)

# Generated at 2022-06-23 02:13:56.619046
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-23 02:13:57.649663
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(None)
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-23 02:13:59.038220
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv is not None

# Generated at 2022-06-23 02:14:04.224026
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    c = HPUXVirtualCollector()
    assert c.get_virtual_facts() == {'virtualization_tech_guest': set(),
                                     'virtualization_tech_host': set(),
                                     'virtualization_type': None,
                                     'virtualization_role': None}


# Generated at 2022-06-23 02:14:07.154883
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    assert obj.platform == 'HP-UX'
    assert obj.fact_class == HPUXVirtual

# Generated at 2022-06-23 02:14:18.821540
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
      Unit test for method get_virtual_facts of class HPUXVirtual
    """
    Facter = {
        'system': 'HP-UX',
    }
    module = type('', (object,), {'run_command': lambda *x: ('', '', '')})()
    virtual = HPUXVirtual(module)

    # handle run command error
    def run_command(cmd):
        return 1, '', ''
    module.run_command = run_command
    assert virtual.get_virtual_facts() == {}

    # no virtualization
    def run_command(cmd):
        return 0, '', ''
    module.run_command = run_command

# Generated at 2022-06-23 02:14:23.297995
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpar import HPUXVirtual as module
    virtual_facts = module().get_virtual_facts()
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    assert virtual_facts['virtualization_type'] == 'guest'

# Generated at 2022-06-23 02:14:34.969175
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Test get_virtual_facts of class HPUXVirtual (invalid virtualization_type)
    module = type('', (object,), {'run_command': lambda a, b: (0, "", "")})
    module.exit_json = lambda arg: True
    module.fail_json = lambda arg: False
    v = HPUXVirtual(module)
    assert v.virtualization_type == 'unknown'

    # Test get_virtual_facts of class HPUXVirtual (vecheck guest)
    module = type('', (object,), {'run_command': lambda a, b: (0, "", "")})
    module.exit_json = lambda arg: True
    module.fail_json = lambda arg: False
    os.path.exists = lambda a: True
    v = HPUXVirtual(module)


# Generated at 2022-06-23 02:14:39.547093
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = AnsibleModule(argument_spec={})
    is_hpux = HPUXVirtual(module)
    module.exit_json(changed=False, ansible_facts=dict(is_hpux.get_virtual_facts() or {}))


# Generated at 2022-06-23 02:14:42.633710
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    os.path.exists = lambda x: x == '/usr/sbin/vecheck'
    module = AnsibleModule(argument_spec={})
    module.params = {}
    os.path.exists = lambda x: x == '/opt/hpvm/bin/hpvminfo'
    modul

# Generated at 2022-06-23 02:14:47.966147
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import tempfile
    filename = tempfile.mktemp()
    fd = os.open(filename, os.O_RDWR | os.O_CREAT | os.O_TRUNC, 0o600)
    os.write(fd, "HPVM guest")
    os.close(fd)
    m = HPUXVirtual({'module_setup': True, 'command_wrapper': ''})
    assert m.get_virtual_facts() == {'virtualization_tech_host': set(), 'virtualization_tech_guest': {'HPVM'}, 'virtualization_type': 'guest', 'virtualization_role': 'HPVM'}
    os.unlink(filename)

# Generated at 2022-06-23 02:14:59.314310
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    module = {}
    module['run_command'] = lambda x,y: (0, (x,y), None)
    module['path'] = {'exists': lambda x: x in ['/usr/sbin/parstatus','/usr/sbin/vecheck','/opt/hpvm/bin/hpvminfo']}
    f = HPUXVirtual({})
    f.module = module
    facts = f.get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP nPar'
    assert facts['virtualization_tech_guest'] == set(['HP nPar'])
    assert facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:15:02.850110
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts_object = HPUXVirtual(None)
    assert virtual_facts_object.platform == 'HP-UX'
    assert virtual_facts_object.get_virtual_facts() == {}

# Generated at 2022-06-23 02:15:10.877214
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    HPUXVirtual.module = None
    HPUXVirtual.module.run_command = run_command
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.get_virtual_facts() == {
        'virtualization_tech_guest': {'HPVM', 'HP vPar', 'HP nPar'},
        'virtualization_tech_host': set(),
        'virtualization_type': 'guest',
        'virtualization_role': 'HP vPar'
    }


# Generated at 2022-06-23 02:15:13.988448
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    _hpuxvirtualcollector = HPUXVirtualCollector()
    assert _hpuxvirtualcollector.platform == 'HP-UX'
    assert _hpuxvirtualcollector._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:15:25.392318
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts import ModuleStub
    from ansible.module_utils.facts.virtual.hpux.test_HPUXVirtual import (MockHPUXModule)

    # Mock parameters of HPUXVirtual class
    module = MockHPUXModule()
    module.run_command = MockHPUXModule.run_command
    mod_stub = ModuleStub({'ansible_facts':{}})
    hpux_virtual = HPUXVirtual(module, mod_stub)
    hpux_virtual_facts = hpux_virtual.get_virtual_facts()
    assert hpux_virtual_facts['virtualization_tech_guest'] == set([])

# Generated at 2022-06-23 02:15:27.446843
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual(dict())
    assert h.platform == 'HP-UX'


# Generated at 2022-06-23 02:15:29.333336
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux = HPUXVirtual({})
    assert hpux.platform == 'HP-UX'

# Generated at 2022-06-23 02:15:32.183746
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert issubclass(HPUXVirtualCollector, VirtualCollector)
    assert HPUXVirtualCollector._platform == 'HP-UX'

# Generated at 2022-06-23 02:15:43.030106
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import ModuleFailedException
    from ansible.module_utils.facts.utils import ansible_environment
    from ansible.module_utils.facts.virtual.hpu_ux import HPUXVirtual
    from ansible.module_utils.six.moves import builtins

    HPUXVirtual.module = DummyModule('SomeData')
    HPUXVirtual.module.params = {}
    HPUXVirtual.module.run_command = mock_cmd
    HPUXVirtual.module.get_bin_path = lambda x: ['bin_path']
    HPUXVirtual.module.check_mode = False
    HPUXVirtual.facts = {}
    HPUXVirtual.get_virtual_facts()


if __name__ == '__main__':
    test_HPUXVirtual_get

# Generated at 2022-06-23 02:15:49.580891
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.params = {}

    iface = HPUXVirtual(module)
    facts = iface.get_virtual_facts()

    assert facts is not None
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts


# Generated at 2022-06-23 02:15:56.199842
# Unit test for constructor of class HPUXVirtual

# Generated at 2022-06-23 02:16:06.687412
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_module = type('test_module', (object,), {'run_command': run_command})
    # test unit in guest
    hpux_virtual_collector = HPUXVirtualCollector(test_module)
    hpux_virtual_collector.module.run_command = get_run_command_results(rc=0, out='vswap')
    assert hpux_virtual_collector.get_virtual_facts() == {'virtualization_type': 'guest',
                                                          'virtualization_role': 'HP vPar',
                                                          'virtualization_tech_host': set(),
                                                          'virtualization_tech_guest': {'HP vPar'}}
    # test unit in host
    hpux_virtual_collector = HPUXVirtualCollector(test_module)
    hp

# Generated at 2022-06-23 02:16:09.233461
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(dict(module=dict()))
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-23 02:16:12.951105
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj0 = HPUXVirtualCollector()
    assert VirtualCollector._platform == obj0._platform
    assert VirtualCollector._fact_class == obj0._fact_class

# Generated at 2022-06-23 02:16:16.674011
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    '''
    Test the constructor of class HPUXVirtualCollector
    '''
    hv_object = HPUXVirtualCollector()
    assert hv_object.platform == 'HP-UX'

# Generated at 2022-06-23 02:16:24.861759
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    virtual = HPUXVirtual(module)
    virtual_facts = {}
    virtual_facts['virtualization_type'] = 'guest'
    virtual_facts['virtualization_role'] = 'HP vPar'
    virtual_facts['virtualization_tech_guest'] = ['HP vPar']
    virtual_facts['virtualization_tech_host'] = []

    assert virtual.get_virtual_facts() == virtual_facts

# Generated at 2022-06-23 02:16:26.301308
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector().platform == 'HP-UX'

# Generated at 2022-06-23 02:16:38.778340
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual

    module = MockModule()

    class TestHPUXVirtual(HPUXVirtual):
        def exists(self, path):
            if path == '/usr/sbin/vecheck':
                return True
            if path == '/opt/hpvm/bin/hpvminfo':
                return True
            if path == '/usr/sbin/parstatus':
                return True
            return False

    virtual = TestHPUXVirtual(module)
    virtual.get_virtual_facts()
    assert module.params['gather_subset'] == ['!all', 'virtual']
    assert 'virtualization_type' in module.exit_args['ansible_facts']
    assert 'virtualization_role' in module.exit_args['ansible_facts']
   

# Generated at 2022-06-23 02:16:49.130325
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import Virtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    mocked_module = Virtual({})
    facts = HPUXVirtual(mocked_module)
    facts.module.run_command = run_command_mock
    assert isinstance(facts, HPUXVirtual)
    assert facts.get_virtual_facts() == {'virtualization_type': 'guest',
                                         'virtualization_role': 'HP vPar',
                                         'virtualization_tech_host': set(),
                                         'virtualization_tech_guest': {'HP vPar'}}


# Generated at 2022-06-23 02:16:52.595961
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """
    Test constructor of class HPUXVirtualCollector
    """
    collector = HPUXVirtualCollector()
    assert collector.platform == 'HP-UX'

# Generated at 2022-06-23 02:16:53.764968
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert x.platform == 'HP-UX'

# Generated at 2022-06-23 02:16:58.676291
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector
    assert HPUXVirtualCollector.__name__ == 'HPUXVirtualCollector'
    assert HPUXVirtualCollector._fact_class is HPUXVirtual
    assert HPUXVirtualCollector._platform == 'HP-UX'

# Generated at 2022-06-23 02:17:09.734636
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # vPar
    m = VirtualCollector()

# Generated at 2022-06-23 02:17:12.040263
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual({})
    assert virtual_obj.platform == 'HP-UX'



# Generated at 2022-06-23 02:17:21.373067
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class FakeModule():
        def __init__(self):
            self.params = {}
            self.run_command = FakeRunCommand()
    class FakeRunCommand():
        def __init__(self):
            self.rc = 0
            self.stdout_lines = []
            self.stderr_lines = []
        def __call__(self, args, check_rc=True):
            if args == "/usr/sbin/vecheck":
                self.stdout_lines.append("HP vPar")
            elif args == "/opt/hpvm/bin/hpvminfo":
                self.stdout_lines.append("Running HPVM host")
            elif args == "/usr/sbin/parstatus":
                self.stdout_lines.append("HP nPar")
            return self.rc, self.stdout

# Generated at 2022-06-23 02:17:24.903388
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    fc = HPUXVirtualCollector(dict(), '', '', '', '')
    assert fc.__dict__ == {'_fact_class': HPUXVirtual, '_platform': 'HP-UX'}

# Generated at 2022-06-23 02:17:32.136700
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    This unit test is executed to test the methods of HPUXVirtual class.
    """

    # Create a new instance of HPUXVirtual class
    hpx_virtual = HPUXVirtual(None)

    # Execute get_virtual_facts method and store the result in the variable virtual_facts
    virtual_facts = hpx_virtual.get_virtual_facts()

    # Verify the result of get_virtual_facts method and make sure it is not empty
    if not virtual_facts:
        assert False

# Generated at 2022-06-23 02:17:36.955222
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(module)
    assert virtual.platform == 'HP-UX'
    assert virtual.virtualization_type == 'guest'
    assert virtual.virtualization_role == 'HP vPar'
    assert len(virtual.virtualization_tech_guest) == 1
    assert len(virtual.virtualization_tech_host) == 0

# Generated at 2022-06-23 02:17:38.397043
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual()
    assert h.platform == 'HP-UX'

# Generated at 2022-06-23 02:17:40.139855
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual({})
    assert len(v.virtual_facts.keys()) == 0


# Generated at 2022-06-23 02:17:51.291028
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({'module': {'run_command': ['command', 'stdout', 'stderr']}})
    assert hv.platform == 'HP-UX'
    assert hv.get_virtual_facts()['virtualization_type'] == 'guest'
    assert hv.get_virtual_facts()['virtualization_role'] == 'HP vPar'
    hv = HPUXVirtual({'module': {'run_command': ['command', 'stdout', 'stderr']}})

# Generated at 2022-06-23 02:18:02.270737
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    import sys
    import os

    fc = FactCollector()
    fc.collect(["virtual"])
    virtual_facts = {}

    module = FakeModule(untouched=True)

    hv = HPUXVirtual(module)
    virtual_facts = hv.get_virtual_facts()

    # At least one of guest or host technology should be present
    if not virtual_facts['virtualization_tech_guest'] or not virtual_facts['virtualization_tech_host']:
        sys.exit(1)

    # If virtualization_tech_guest is not empty, then virtualization_type and virtualization_role
    # should be present.

# Generated at 2022-06-23 02:18:10.944566
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts(): # pylint: disable=redefined-outer-name
    from ansible_collections.ansible.community.tests.unit.module_utils.facts.virtual import MockModule

    # instance of class HPUXVirtual
    hpux_virtual = HPUXVirtual(MockModule(), dict())

    # set values of method_calls of mocked object to []
    mock_open = MockModule().open
    mock_open.reset_mock()

    # set attributes of mocked object
    hpux_virtual.module.run_command.return_value = 0, "HPVM host", ""

    # run get_virtual_facts method of class HPUXVirtual
    virtual_facts = hpux_virtual.get_virtual_facts()

    # assert methods calls

# Generated at 2022-06-23 02:18:12.511338
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-23 02:18:14.528040
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual()
    assert virtual_obj.platform == 'HP-UX'


# Generated at 2022-06-23 02:18:16.502373
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'



# Generated at 2022-06-23 02:18:21.532064
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """
    Unit test for constructor of class HPUXVirtualCollector
    """
    my_obj = HPUXVirtualCollector()
    assert my_obj
    assert my_obj.platform == 'HP-UX'


# Generated at 2022-06-23 02:18:23.294530
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    b = HPUXVirtualCollector()
    assert b._platform == 'HP-UX'

# Generated at 2022-06-23 02:18:33.575460
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # In testing the below code will run in a different context than
    # when run on a target, so we'll need to fake a module object
    class FakeModule:

        def __init__(self):
            self.run_command_calls = []
            self.run_command_rcs = []
            self.run_command_returns = []
            self.run_command_call_count = 0

        def run_command(self, command):
            self.run_command_calls.append(command)
            self.run_command_call_count = len(self.run_command_calls)
            return self.run_command_rcs[self.run_command_call_count - 1], \
                   self.run_command_returns[self.run_command_call_count - 1], ''


# Generated at 2022-06-23 02:18:41.788050
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h = HPUXVirtual({})
    # case 1 - Ve On
    h.module.run_command = lambda x: (0, '', '')
    r = h.get_virtual_facts()
    assert r['virtualization_type'] == 'guest'
    assert r['virtualization_role'] == 'HP vPar'
    # case 2 - Ve Off
    h.module.run_command = lambda x: (1, '', '')
    r = h.get_virtual_facts()
    assert r['virtualization_type'] == 'NA'
    assert r['virtualization_role'] == 'NA'

# Generated at 2022-06-23 02:18:45.376597
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector()
    assert collector.platform == 'HP-UX'
    assert collector._fact_class == 'HPUXVirtual'
    assert collector._platform == 'HP-UX'

# Generated at 2022-06-23 02:18:56.261142
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # test data
    test_data = {
        "ansible_facts": {
            "virtualization_type": "guest",
            "virtualization_role": "HP nPar",
            "virtualization_tech_guest": set([u'HP nPar']),
            "virtualization_tech_host": set([])
        }
    }

    # Test code
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual import VirtualCollector

    m = HPUXVirtualCollector()
    m.module = AnsibleModule(argument_spec={})
    m._collect_platform_subset = lambda *args, **kwargs: None
    m

# Generated at 2022-06-23 02:19:02.975406
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'
    assert virtual_facts.get_virtual_facts() == {
        'virtualization_type': None,
        'virtualization_role': None,
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-23 02:19:06.270989
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    myHPUXVirtual = HPUXVirtual(dict())
    assert myHPUXVirtual.virtual == dict()
    assert myHPUXVirtual.platform == 'HP-UX'
    assert myHPUXVirtual.module == None


# Generated at 2022-06-23 02:19:12.095040
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # basic test for constructor of class HPUXVirtual
    HPUXVirt = HPUXVirtual()
    assert HPUXVirt.platform == 'HP-UX'


# Generated at 2022-06-23 02:19:16.712038
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'
    assert virtual_facts.get_virtual_facts()['virtualization_type'] == 'host'
    assert virtual_facts.get_virtual_facts()['virtualization_role'] == 'physical'

# Generated at 2022-06-23 02:19:19.029486
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vc = HPUXVirtualCollector()
    assert vc._fact_class == HPUXVirtual
    assert vc._platform == 'HP-UX'

# Generated at 2022-06-23 02:19:29.930662
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import ModuleDummy
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector

    module = ModuleDummy()
    hpux = HPUXVirtualCollector()
    hpux.module = module

    # Case 1: Case when vecheck is available, but does not return any output
    module.run_command = lambda x: (1, '', '')
    module.exit_json = lambda x: None
    hpux.get_virtual_facts()
    assert hpux.facts['virtualization_type'] == 'unknown'

    # Case 2: Case when vecheck is available and returns output

# Generated at 2022-06-23 02:19:30.996853
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpuxvirtual = HPUXVirtual({})

# Generated at 2022-06-23 02:19:36.025120
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual()
    assert h._platform == 'HP-UX'
    assert h.platform == 'HP-UX'
    assert h.virtualization_type == 'unknown'
    assert h.virtualization_role == 'unknown'
    assert h.virtualization_tech_guest == set()
    assert h.virtualization_tech_host == set()



# Generated at 2022-06-23 02:19:37.527386
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux = HPUXVirtual()
    assert(hpux is not None)

# Generated at 2022-06-23 02:19:45.038397
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = type('FakeModule', (), {})
    module.run_command = run_command_mock
    hpx_virtual = HPUXVirtual(module)
    virtual_facts = hpx_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP nPar'
    assert set(virtual_facts['virtualization_tech_guest']) == {'HP nPar', 'HP vPar'}
    assert set(virtual_facts['virtualization_tech_host']) == set()


# Generated at 2022-06-23 02:19:50.624218
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    Test if all class attributes are defined correctly.
    """
    hpx_virtual = HPUXVirtual(dict())
    assert 'HP-UX' == hpx_virtual.platform
    assert hpx_virtual.platform == hpx_virtual._platform
    assert hpx_virtual._fact_class == HPUXVirtual
    assert hpx_virtual._platform == 'HP-UX'



# Generated at 2022-06-23 02:20:03.171433
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpar import HPUXVirtual
    from ansible.module_utils import basic
    import json

    module = basic.AnsibleModule(
        argument_spec=dict()
    )
    setattr(module, 'run_command', lambda *args, **kwargs: (0, '', ''))

    if os.path.exists('/opt/hpvm/bin/hpvminfo'):
        setattr(module, 'run_command', lambda *args, **kwargs: (0, "Running HPVM vPar", ''))
        hpux_virtual = HPUXVirtual(module)
        result = hpux_virtual.get_virtual_facts()

        assert result['virtualization_type'] == 'guest'

# Generated at 2022-06-23 02:20:06.506902
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    assert isinstance(obj, VirtualCollector)
    assert obj._fact_class is HPUXVirtual

# Generated at 2022-06-23 02:20:07.980626
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    a=HPUXVirtual(dict())
    assert a.platform == 'HP-UX'


# Generated at 2022-06-23 02:20:09.485458
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert virtual_collector.platform == "HP-UX"

# Generated at 2022-06-23 02:20:18.804316
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.virtual.hpux import get_virtual_facts

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True)

    hpux = HPUXVirtual(module=module)
    module.get_bin_path = hpux.get_bin_path
    hpux.run_command = lambda x: (0, '', '')

    hpux.module.run_command = lambda x: (0, '', '', '')
    facts = get_virtual_facts(hpux)

# Generated at 2022-06-23 02:20:20.946046
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(dict(module=dict()))
    assert HPUXVirtual.platform == 'HP-UX'

# Generated at 2022-06-23 02:20:22.812358
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    x = HPUXVirtual()
    assert x.platform == 'HP-UX'


# Generated at 2022-06-23 02:20:24.748795
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-23 02:20:26.565946
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert x.platform == 'HP-UX'


# Generated at 2022-06-23 02:20:39.312782
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    # Check whether virtualization_type and virtualization_role
    # is set correctly for
    # a) HP-UX guest in HP vPar
    # b) HPVM vPar
    # c) HPVM IVM
    # d) HP-UX host and HPVM
    # e) HP-UX guest in NPAR
    module = FakeModule()
    module.add_cmd_output('vecheck')
    module.add_cmd_output('hpvminfo')
    module.add_cmd_output('parstatus')

    facts = HPUXVirtualCollector(module).collect()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP vPar'
    assert 'HPVM vPar' in facts['virtualization_tech_guest']

# Generated at 2022-06-23 02:20:52.900131
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    import os
    import shutil
    import tempfile
    test_dir = tempfile.mkdtemp()
    # Create vecheck
    vecheck = os.path.join(test_dir, 'vecheck')
    open(vecheck, 'a').close()
    os.chmod(vecheck, 0o755)
    # Create hpvminfo
    hpvminfo = os.path.join(test_dir, 'hpvminfo')
    open(hpvminfo, 'a').close()

# Generated at 2022-06-23 02:21:03.677131
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    MockModule = type('MockModule', (), {'run_command': lambda x: (0, None, None)})
    MockOS = type('MockOS', (), {'path': type('MockPath', (), {'exists': lambda x: True})})
    MockModule.os = MockOS
    obj = HPUXVirtual(MockModule)
    assert obj.get_virtual_facts() == {'virtualization_tech_guest': {'HP vPar', 'HP nPar', 'HPVM vPar', 'HPVM IVM'}, 'virtualization_tech_host': set(), 'virtualization_type': 'guest', 'virtualization_role': 'HP vPar'}


# Generated at 2022-06-23 02:21:07.678944
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    hv = HPUXVirtual({})
    facts = hv.get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HPVM'

# Generated at 2022-06-23 02:21:10.304919
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-23 02:21:12.449645
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector(None, None, None, None)
    assert isinstance(x, HPUXVirtualCollector)
    assert isinstance(x._fact_class, HPUXVirtual)
    assert x._platform == 'HP-UX'

# Generated at 2022-06-23 02:21:16.010471
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    # just test name of the class
    assert HPUXVirtualCollector._platform == 'HP-UX'
    assert HPUXVirtualCollector._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:21:17.678115
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    obj = HPUXVirtual({}, {}, {}, [], {})
    assert obj.platform == 'HP-UX'

# Generated at 2022-06-23 02:21:22.969309
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class MockModule:
        def run_command(self, cmd):
            return (0, cmd, '')
    m = MockModule()
    v = HPUXVirtual(m)
    f = v.get_virtual_facts()
    assert isinstance(f, dict)

# Generated at 2022-06-23 02:21:33.621869
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    host_tech = set()
    guest_tech = set()

    hv = HPUXVirtual({})
    hv.module.run_command = run_command

    # expected result when vecheck exists
    virtual_facts = hv.get_virtual_facts()
    guest_tech.add('HP vPar')
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    assert virtual_facts['virtualization_tech_guest'] == guest_tech
    assert virtual_facts['virtualization_tech_host'] == host_tech

    # expected result when vecheck does not exists and
    # hpvminfo exists with output 'Running HPVM guest'
    virtual_facts = hv.get_virtual_facts()

# Generated at 2022-06-23 02:21:46.234745
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import subprocess
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts import ModuleStub
    from ansible.module_utils.facts import Cache

    def run_commands(commands, check_rc=True, data=None):
        """
        run_command that is mocked
        """
        cmd = commands['cmd']
        if cmd == '/usr/sbin/vecheck':
            out = 'Virtual machine node: vecheck'.encode('utf-8')
            rc = 0
        elif cmd == '/opt/hpvm/bin/hpvminfo':
            out = ' '.encode('utf-8')
            rc = 0
        elif cmd == '/usr/sbin/parstatus':
            out = ''.encode('utf-8')

# Generated at 2022-06-23 02:21:47.729833
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert issubclass(HPUXVirtualCollector, VirtualCollector)

# Generated at 2022-06-23 02:21:57.873601
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # Create instance of HPUXVirtual()
    virt = HPUXVirtual(dict())
    # Check if attributes are initialized
    assert virt.virtualization_type == ''
    assert virt.virtualization_role == ''
    assert virt.virtualization_use == ''
    assert virt.virtualization_system == ''
    assert virt.virtualization_uid == ''
    assert virt.virtualization_product_name == ''
    assert virt.virtualization_hypervisor_version == ''
    assert virt.virtualization_product_version == ''
    assert virt.virtualization_product_serial == ''
    assert virt.virtualization_machine_id == ''
    assert virt.virtualization_operating_system == ''
    assert virt.virtualization_operating_system_version == ''
    assert virt.virtualization_operating_system_maj_version == ''

# Generated at 2022-06-23 02:22:05.620650
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    res = HPUXVirtual('ansible.module_utils.facts.virtual.hpux.Virtual').get_virtual_facts()
    assert res['virtualization_type'] == 'guest'
    assert res['virtualization_role'] == 'HP nPar'
    assert 'HPVM IVM' in res['virtualization_tech_host']
    assert 'HPVM' in res['virtualization_tech_host']
    assert 'HPVM vPar' in res['virtualization_tech_host']
    assert 'HPVM vPar' in res['virtualization_tech_guest']
    assert 'HP vPar' in res['virtualization_tech_guest']
    assert 'HP nPar' in res['virtualization_tech_guest']

# Generated at 2022-06-23 02:22:14.156661
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Test get_virtual_facts function.
    """
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    class TestModule(object):
        """
        This is a test class
        """
        def __init__(self):
            """
            Constructor
            """
            self.params = {}
            self.run_command = basic.run_command

    hpux_virtual = HPUXVirtual(TestModule())
    hpux_virtual_collector = HPUXVirtualCollector(TestModule())
    hpux_virtual_dict = hpux_virtual.get_virtual_facts()
    hpux_virtual_collector_dict = hpux_virtual_collector.collect()['ansible_virtual']
    assert hpux_virtual_dict == hpux_virtual_collector

# Generated at 2022-06-23 02:22:16.233156
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector()
    assert collector.platform == 'HP-UX'
    assert collector.fact_class == HPUXVirtual

# Generated at 2022-06-23 02:22:17.516339
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
   assert isinstance(HPUXVirtualCollector(), VirtualCollector)

# Generated at 2022-06-23 02:22:20.344893
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    d = HPUXVirtualCollector()
    assert d._fact_class == HPUXVirtual
    assert d._platform == 'HP-UX'

# Generated at 2022-06-23 02:22:22.850857
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    assert obj._fact_class is not None

if __name__ == '__main__':
    test_HPUXVirtualCollector()

# Generated at 2022-06-23 02:22:26.998958
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert issubclass(HPUXVirtualCollector, VirtualCollector)
    assert HPUXVirtualCollector._platform == 'HP-UX'
    assert HPUXVirtualCollector._fact_class == HPUXVirtual
    hpx_virtual_collector = HPUXVirtualCollector()
    assert isinstance(hpx_virtual_collector, VirtualCollector)


# Generated at 2022-06-23 02:22:28.946617
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt = HPUXVirtual(dict())
    assert virt.platform == 'HP-UX'


# Generated at 2022-06-23 02:22:38.403263
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import sys
    import subprocess
    from ansible.module_utils.facts.virtual.hpux.hpux_virtual import HPUXVirtual as HPUXVirtualTest
    if sys.version_info[0] == 2:
        unittest_module = __import__('unittest2')
    else:
        unittest_module = __import__('unittest')
    unittest = unittest_module.defaultTestLoader.loadTestsFromModule(unittest_module)

    class TestModule(object):
        def __init__(self, *args, **kwargs):
            self.run_command = HPUXVirtualTest.run_command

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
           

# Generated at 2022-06-23 02:22:42.527601
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    facts = {}
    vc = HPUXVirtual(facts)
    assert vc
    assert vc.platform == 'HP-UX'



# Generated at 2022-06-23 02:22:45.314169
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vc = HPUXVirtualCollector()
    assert vc.platform == 'HP-UX'
    assert vc._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:22:49.852858
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv.get_all_facts()
    assert hv._fact_class is HPUXVirtualCollector._fact_class
    assert isinstance(hv.get_all_facts(), dict)
    assert hv._platform is HPUXVirtualCollector._platform

# Generated at 2022-06-23 02:22:56.274042
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import json
    module = AnsibleModuleMock()
    cls = HPUXVirtual(module)
    virtual_facts = cls.get_virtual_facts()
    assert virtual_facts == {'virtualization_type': 'guest',
                             'virtualization_role': 'HPVM IVM',
                             'virtualization_tech_host': set(),
                             'virtualization_tech_guest': {'HPVM IVM', 'HPVM'}}


# Generated at 2022-06-23 02:23:06.353048
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import HPUXVirtual
    from ansible.module_utils.facts.virtual import BaseVirtual
    from ansible.module_utils.facts.virtual.base import Virtual
    module = get_module_mock()

    # Return code and output of /usr/sbin/vecheck for a guest system
    rc = 0
    vecheck_out = [
        'PAR:     NO',
        'VE:      NO'
    ]
    module.run_command = Mock(return_value=(rc, vecheck_out, None))

    # Return code and output of /opt/hpvm/bin/hpvminfo for a guest system
    rc = 0

# Generated at 2022-06-23 02:23:10.397784
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpvx = HPUXVirtual({})
    assert hpvx.platform == 'HP-UX'
    assert hpvx.guest_tech == set()
    assert hpvx.host_tech == set()


# Generated at 2022-06-23 02:23:11.114690
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-23 02:23:22.403781
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class AnsibleModule(object):
        def __init__(self):
            self.module_args=dict()
        class ModuleArgs(object):
            def __init__(self):
                self.shell = shell
        def run_command(self, command):
            return (0, '', '')
    class ShellModule(object):
        def __init__(self):
            self.params=dict()
        def get_bin_path(self, arg, opt_dirs=None, required=False):
            return '/usr/sbin/parstatus'
    module = AnsibleModule()
    module.params['shell'] = ShellModule()
    hpux = HPUXVirtual(module)
    facts = hpux.get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'

# Generated at 2022-06-23 02:23:25.209341
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virtual = HPUXVirtual(module)
    result = virtual.get_virtual_facts()
    assert result

# Generated at 2022-06-23 02:23:35.552703
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    import sys

    orig_run_command = HPUXVirtual.run_command

    # Construct the object
    hpux_virtual_obj = HPUXVirtual(None, dict())

    # Test presence of HP nPar
    def run_command_fake_npar(cmd, **kwargs):
        return (0, 'hpux 11.31\nnpar_name        mynpar\nnpar_partition_id 1\n', '')

    HPUXVirtual.run_command = run_command_fake_npar
    hpux_virtual_facts = hpux_virtual_obj.get_virtual_facts()

# Generated at 2022-06-23 02:23:37.963893
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert x.platform == "HP-UX"
    assert x._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:23:40.802216
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vc = HPUXVirtualCollector()
    assert vc._fact_class == HPUXVirtual
    assert vc._platform == 'HP-UX'

