

# Generated at 2022-06-23 02:13:45.642440
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = {}
    virtual_facts["virtualization_type"] = 'host'
    virtual_facts["virtualization_role"] = 'HPVM'
    virtual_facts["virtualization_tech_host"] = 'HPVM'
    virtual_facts["virtualization_tech_guest"] = 'HPVM'

    virt = HPUXVirtual(dict(module=dict()))
    assert virt.get_virtual_facts() == virtual_facts

# Generated at 2022-06-23 02:13:46.998017
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-23 02:13:48.211990
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual({})
    assert virtual.platform == 'HP-UX'


# Generated at 2022-06-23 02:13:52.670272
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = type('FakeModule', (object,), dict(run_command=lambda x: (0, '', '')))()
    virt_collector = HPUXVirtual(module=module)
    result = virt_collector.fetch_virtual_facts()
    assert 'virtualization_type' in result

# Generated at 2022-06-23 02:13:54.324196
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual is not None


# Generated at 2022-06-23 02:13:57.677212
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    my_obj = HPUXVirtualCollector()
    assert(my_obj._platform == 'HP-UX')
    assert(issubclass(my_obj._fact_class, HPUXVirtual))


# Generated at 2022-06-23 02:13:59.088758
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual(dict()).platform == 'HP-UX'

# Generated at 2022-06-23 02:14:11.035974
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux.get_virtual_facts import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux.get_virtual_facts import HPUXVirtual
    import json

    import sys
    if sys.version_info.major < 3:
        from StringIO import StringIO
    else:
        from io import StringIO

    class MockModule(object):
        '''
        This class is used for setting module instance variables when testing get_virtual_facts method of class HPUXVirtual.
        '''
        def __init__(self, module_name='test_module', module_path='test_path'):
            self.module_name = module_name
            self.module_path = module_path
            self.params = {}
            self.check_mode

# Generated at 2022-06-23 02:14:15.494389
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
  hpx = HPUXVirtualCollector()
  # check if it is an instance of VirtualCollector
  assert isinstance(hpx, VirtualCollector)
  # check platform
  assert hpx.platform == 'HP-UX'
  # check fact_class
  assert hpx.fact_class == HPUXVirtual

# Generated at 2022-06-23 02:14:26.554792
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    hvirt = HPUXVirtual()

    # Mock capabilities of platform and set expectations
    hvirt.capabilities = {'is_hpux': True}
    hvirt.module.run_command.return_value = (0, '', '')
    hvirt.module.run_command.expect_call('/usr/sbin/vecheck')
    hvirt.module.run_command.expect_call('/opt/hpvm/bin/hpvminfo')
    hvirt.module.run_command.expect_call('/usr/sbin/parstatus')

# Generated at 2022-06-23 02:14:37.548079
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import Virtualization
    test_stream = """

Date: Wed Nov  1 16:33:39 2017

HPUX Version: 11.31

"""
    virtual_collector = VirtualCollector(None, test_stream)
    hpx_virtual = HPUXVirtual(virtual_collector)
    virtual_facts = hpx_virtual.get_virtual_facts()

# Generated at 2022-06-23 02:14:40.874680
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_obj = HPUXVirtual({})
    assert hpux_obj.platform == "HP-UX"
    assert hpux_obj.get_virtual_facts() == dict(virtualization_tech_guest=set(),
                                                virtualization_tech_host=set())


# Generated at 2022-06-23 02:14:45.035610
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # See file tests/units/module_utils/facts/virtual/base.py
    # for the details of VirtualCollector mock
    # and tests/units/module_utils/facts/virtual/HPUX.py
    # for the details of HPUXVirtual
    pass

# Generated at 2022-06-23 02:14:46.553213
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    facts = {}
    myfact = HPUXVirtual(ansible_facts=facts)
    assert myfact != None

# Generated at 2022-06-23 02:14:54.724284
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class HPModule:
        def run_command(self, cmd):
            return 0, '', ''
    class HPMockFactsModule:
        def __init__(self):
            self.module = HPModule()
    hp_facts = HPMockFactsModule()
    hp_virtual = HPUXVirtual(hp_facts)
    hp_virtual_facts = {
        'virtualization_type': 'guest',
        'virtualization_role': 'HPVM IVM',
        'virtualization_tech_guest': set(['HPVM IVM']),
        'virtualization_tech_host': set()
    }
    assert hp_virtual.get_virtual_facts() == hp_virtual_facts

# Generated at 2022-06-23 02:14:57.022530
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv._fact_class is not None
    assert hv._platform is not None


# Generated at 2022-06-23 02:14:58.891575
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_class = HPUXVirtual()
    assert virtual_class.platform == "HP-UX"


# Generated at 2022-06-23 02:15:01.975300
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert virtual_collector._fact_class == HPUXVirtual
    assert virtual_collector._platform == 'HP-UX'

# Generated at 2022-06-23 02:15:12.683254
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Parameterized tests to run get_virtual_facts of class HPUXVirtual
    # with various input parameters and check output.
    #
    # Path to test data directory:
    data_dir = os.path.dirname(__file__) + "/test_data/"
    #
    # Paramterized test data:
    #
    # List of tuples with test data and expected output:
    test_data = []
    # test case with no virtualization
    test_data.append(
        ('test_data_HPUX_no_virtualization',
         {'virtualization_tech_guest': set(),
          'virtualization_tech_host': set(),
          'virtualization_role': '',
          'virtualization_type': ''})
    )
    # test case with HP vPar
    test_data.append

# Generated at 2022-06-23 02:15:19.286079
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict()
    )

    module.run_command = MagicMock(return_value=(0, '', ''))

    actual_result = HPUXVirtual(module).get_virtual_facts()
    virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }
    assert virtual_facts == actual_result

# Generated at 2022-06-23 02:15:30.506229
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux.hpux import test_HPUXVirtual_get_virtual_facts

    class TestModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err
        def run_command(self, cmd):
            return(self.rc, self.out, self.err)

    # Test for HP vPar host
    hv = HPUXVirtual(TestModule(0, '', ''))
    facts = hv.get_virtual_facts()

# Generated at 2022-06-23 02:15:38.934498
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual import VirtualCollector
    module = AnsibleModuleMock()
    mod = HPUXVirtualCollector(module=module)
    facts = mod.get_virtual_facts()
    assert facts['virtualization_type'] == 'host'
    assert facts['virtualization_role'] == 'HPVM'
    assert facts['virtualization_tech_host'] == set(["HPVM"])
    assert facts['virtualization_tech_guest'] == set([])


# Generated at 2022-06-23 02:15:48.058975
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class HPUXVirtual
    """
    module = type('', (), {'run_command': lambda self, cmd: (0, cmd, '')})()
    # test VE
    vecheck_path = '/usr/sbin/vecheck'
    os.path.exists = lambda path: True if path == vecheck_path else False
    virtual_facts = HPUXVirtual(module).get_virtual_facts()
    assert 'virtualization_role' in virtual_facts
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    assert 'virtualization_type' in virtual_facts
    assert virtual_facts['virtualization_type'] == 'guest'
    assert 'virtualization_tech_guest' in virtual_facts

# Generated at 2022-06-23 02:15:51.238246
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class HPUXVirtual
    """
    from ansible.module_utils.facts.virtual import HPUXVirtual
    test_instance = HPUXVirtual()
    test_instance.get_virtual_facts()

# Generated at 2022-06-23 02:15:52.107775
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector(None)

# Generated at 2022-06-23 02:15:57.906317
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    virtual_obj = HPUXVirtual()
    virtual_obj.module.run_command = lambda x: (0, 'Running HPVM guest', '')
    assert virtual_obj.get_virtual_facts() == \
        {'virtualization_role': 'HPVM IVM', 'virtualization_type': 'guest', 'virtualization_tech_host': set([]), 'virtualization_tech_guest': set(['HPVM'])}

    virtual_obj.module.run_command = lambda x: (0, 'Running HPVM vPar', '')

# Generated at 2022-06-23 02:15:59.797911
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual()
    assert virtual._platform == 'HP-UX'


# Generated at 2022-06-23 02:16:02.802960
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    facts_collector = HPUXVirtualCollector()
    assert facts_collector._fact_class is HPUXVirtual
    assert facts_collector._platform == 'HP-UX'

# Generated at 2022-06-23 02:16:04.510292
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(None)
    assert hv.platform == 'HP-UX'



# Generated at 2022-06-23 02:16:06.205672
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vc = HPUXVirtualCollector()
    assert vc._platform == 'HP-UX'

# Generated at 2022-06-23 02:16:13.452676
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Testing HPUXVirtual class
    """
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual import VirtualCollector
    from ansible.module_utils.facts import FallbackModule
    import tempfile
    import shutil

    test_dir = tempfile.mkdtemp()

    # Test HPVM vPar
    open(os.path.join(test_dir, 'hpvminfo'), 'w').write('\n'.join((
        'Running with HPVM vPar',
        '',
        'Virtual Machines (VMs):',
        '  Name                 Status                    Type           Boot Disk      Memory (MB)',
        '  -----------------------------------------------------------------------------------------------')))

# Generated at 2022-06-23 02:16:18.649823
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = FakeAnsibleModule({})
    fact_class = HPUXVirtual(module)
    virtual_facts = fact_class.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP nPar'
    assert 'HP vPar' in virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-23 02:16:22.272681
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpux_virtual_collector = HPUXVirtualCollector()
    assert hpux_virtual_collector._platform == 'HP-UX'
    assert hpux_virtual_collector._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:16:31.646965
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    MOCK_PARAMS = {
        'ansible_facts': {
            'virtualization_type': 'guest',
            'virtualization_role': 'HPVM',
            'virtualization_tech_host': set('HPVM'),
            'virtualization_tech_guest': set('HPVM')
        }
    }

    mock_module = Mock(params=MOCK_PARAMS)
    mock_class = Mock(return_value=mock_module)

    with patch.multiple(HP-UXVirtual, module=mock_class) as mocks:
        virtual = HP-UXVirtual()
        virtual.get_virtual_facts()

        assert mocks['module'].run_command.call_count == 2

# Generated at 2022-06-23 02:16:37.590487
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    results = HPUXVirtualCollector(None, None).collect()
    assert results['virtualization_type'] == 'guest'


if __name__ == '__main__':
    test_HPUXVirtualCollector()

# Generated at 2022-06-23 02:16:40.256751
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    os_facts = dict()
    HPUXVirtualCollector(os_facts)
    assert os_facts['virtualization_type'] == 'guest'


# Generated at 2022-06-23 02:16:43.382633
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h = HPUXVirtual({})
    h.module = FakeModule()
    h.module.run_command = FakeRunCommand()
    h.get_virtual_facts()



# Generated at 2022-06-23 02:16:46.578560
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = FakeAnsibleModule()
    hpux_virtual_collector = HPUXVirtualCollector(module)
    assert hpux_virtual_collector.platform == 'HP-UX'


# Generated at 2022-06-23 02:16:49.390590
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpuxvirtual = HPUXVirtualCollector()
    assert hpuxvirtual.platform == 'HP-UX'
    assert hpuxvirtual.fact_class == HPUXVirtual

# Generated at 2022-06-23 02:16:52.827591
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector()
    collector.collect()
    fact = collector.get_facts()
    assert isinstance(fact, HPUXVirtual)

# Generated at 2022-06-23 02:17:03.004737
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.posix import VirtualCollector as PosixVirtualCollector
    from ansible.module_utils.facts.virtual.posix import Virtual as PosixVirtual

    virtual_facts = HPUXVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_tech_guest'] == set('foo')
    assert virtual_facts['virtualization_tech_host']  == set()
    assert virtual_facts['virtualization_type']       == 'guest'
    assert virtual_facts['virtualization_role']       == 'foo'


# Generated at 2022-06-23 02:17:06.351576
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(dict())
    assert hpux_virtual.platform == 'HP-UX'
    assert hpux_virtual._platform == 'HP-UX'


# Generated at 2022-06-23 02:17:11.495764
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual(dict(), 'ansible.module_utils.facts.virtual.hpux.HPUXVirtual').get_virtual_facts() == {'virtualization_tech_guest': set(), 'virtualization_type': 'guest', 'virtualization_role': 'HPVM', 'virtualization_tech_host': set()}

# Generated at 2022-06-23 02:17:14.115775
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert HPUXVirtualCollector._platform == 'HP-UX'
    assert HPUXVirtualCollector._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:17:18.115094
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # Create mock module object
    mock_module = type('AnsibleModule')
    mock_module.params = {}
    mock_module.run_command = HPUXVirtual._run_command
    virtual = HPUXVirtual(mock_module)

    assert virtual.platform == 'HP-UX'

# Generated at 2022-06-23 02:17:22.698082
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """
    Test the constructor of HPUXVirtualCollector
    """
    o = HPUXVirtualCollector()
    assert o.os_platform == 'HP-UX', "Test failed: Got %s instead of HP-UX" % o.os_platform


# Generated at 2022-06-23 02:17:29.781328
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    hpux_virtual = HPUXVirtual(module)
    facts = hpux_virtual.get_virtual_facts()

    assert facts['virtualization_type'] == 'host' or facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] in ['HP vPar', 'HPVM vPar', 'HPVM IVM', 'HP nPar', '']

# Generated at 2022-06-23 02:17:39.399787
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Sample date for test of method
    # get_virtual_facts of class HPUXVirtual
    test_data = {
                 'virtualization_type': 'guest',
                 'virtualization_role': 'HPVM IVM',
                 'virtualization_tech_guest': set(['HPVM IVM']),
                 'virtualization_tech_host': set([]),
                 }
    test_class = HPUXVirtual()
    result = test_class.get_virtual_facts()
    assert result == test_data, \
            "test_HPUXVirtual_get_virtual_facts: data mismatch"
    print("test_HPUXVirtual_get_virtual_facts: Ok")


# Generated at 2022-06-23 02:17:51.109117
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual(dict(ANSIBLE_MODULE_ARGS={}), False)
    assert h.platform == 'HP-UX'
    assert h.module is not None

    # Unit test for 'get_virtual_facts'
    # Return values for HP-UX
    #   virtual_facts['virtualization_type'] = 'guest' or 'host'
    #   virtual_facts['virtualization_role'] = 'HP vPar' or 'HPVM vPar' or 'HP nPar' or 'HPVM'
    #   virtual_facts['virtualization_tech_guest'] = set( 'HP vPar' or 'HPVM vPar' or 'HP nPar' or 'HPVM' )
    #   virtual_facts['virtualization_tech_host'] = set()

    # Executing 'vecheck' on HP-UX

# Generated at 2022-06-23 02:17:56.934489
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv.platform == "HP-UX"
    assert hv._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:18:03.483946
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(type='list', default=['!all', '!min']),
        }
    )
    collector = HPUXVirtualCollector(module=module)
    facts = collector.get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP nPar'
    assert 'HP nPar' in facts['virtualization_tech_guest']
    assert len(facts['virtualization_tech_host']) == 0
    # Add more unit tests as and when more functions are added.



# Generated at 2022-06-23 02:18:05.481431
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hp_virtual = HPUXVirtual()
    assert hp_virtual._platform == 'HP-UX'


# Generated at 2022-06-23 02:18:09.135751
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector()
    assert collector._fact_class == HPUXVirtual
    assert collector._platform == 'HP-UX'

# Generated at 2022-06-23 02:18:18.030326
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.virtual.hpux import VirtualHPUXModule
    module = VirtualHPUXModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    obj = module.virtual.HPUXVirtual(module)

    # test case for virtualization_type = guest and virtualization_role = HP vPar
    if os.path.exists('/usr/sbin/vecheck'):
        setattr(basic.AnsibleModule, 'run_command',
                lambda x: (0, '[{"enabled":"true","role":"HP vPar","type":"guest"}]', ''))

# Generated at 2022-06-23 02:18:19.557355
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vc = HPUXVirtualCollector()
    assert vc
    assert vc._fact_class == HPUXVirtual
    assert vc._platform == 'HP-UX'



# Generated at 2022-06-23 02:18:30.534850
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module_mocker = AnsibleModuleMockBuilder()
    module_mocker.mock_module('ansible.module_utils.facts.virtual.base')
    module_mocker.mock_module('ansible.module_utils.facts.virtual.hpuivm')
    module_mocker.mock_module('ansible.module_utils.facts.virtual.hpvpar')
    module_mocker.mock_module('ansible.module_utils.facts.virtual.hpvm')

    mock = module_mocker.get_mock()
    mock.run_command = MagicMock()

# Generated at 2022-06-23 02:18:44.020150
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Testing when no virtualization technology is present
    module = MockModule({})
    mock_facter = MockFactCollector()
    obj = HPUXVirtual(module, mock_facter)
    virtual_facts = obj.get_virtual_facts()
    assert sorted(virtual_facts.keys()) == ['virtualization_tech_guest',
                                            'virtualization_tech_host']
    assert not virtual_facts['virtualization_tech_guest']
    assert not virtual_facts['virtualization_tech_host']

    # Testing when guest on HP vPar
    module = MockModule({})
    mock_facter = MockFactCollector()
    obj = HPUXVirtual(module, mock_facter)
    obj.module.run_command = Mock(return_value=(0, '', ''))
    obj.module.file

# Generated at 2022-06-23 02:18:46.583270
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vc = HPUXVirtualCollector()
    assert vc._platform == 'HP-UX'
    assert vc._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:18:50.543703
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = type('module', (object,), {})()
    virtual = HPUXVirtual(module)
    assert (virtual.platform == 'HP-UX')


# Generated at 2022-06-23 02:18:59.899207
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Stub module class to be used in get_virtual_facts()
    class StubModule:
        def run_command(self, cmd):
            return 0, '', ''

    # Create a stub module object
    module = StubModule()

    # Create a stub Virtual object
    virtual_obj = HPUXVirtual(module)
    virtual_obj.ls = {'HP-UX': {'virtual_facts': {'virtualization_type': 'guest',
                                                  'virtualization_role': 'HPVM IVM',
                                                  'virtualization_tech_guest': set(['HPVM IVM']),
                                                  'virtualization_tech_host': set([])}}}

    # Mock the exists method of os.path to return true for the specified path
    def mocked_exists(path):
        return True

    # Set the mocked

# Generated at 2022-06-23 02:19:02.827956
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector._platform == 'HP-UX'
    assert HPUXVirtualCollector._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:19:06.449429
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
    )
    collector = HPUXVirtualCollector(module=module)
    virtual = collector.collect()[0]
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] in ['host', 'guest']

# Generated at 2022-06-23 02:19:17.198721
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import ansible.module_utils.facts.virtual.hpux
    import os

    m_execute = os.popen
    os.popen = None

    try:
        hpux = ansible.module_utils.facts.virtual.hpux.HPUXVirtual()
        assert hpux.get_virtual_facts() == dict(virtualization_type=None,
                                                virtualization_role=None,
                                                virtualization_tech_host=set(),
                                                virtualization_tech_guest=set())
    finally:
        os.popen = m_execute

# Generated at 2022-06-23 02:19:20.455939
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict(), None)
    assert type(virtual) is HPUXVirtual
    assert virtual.platform == 'HP-UX'
    assert type(virtual.get_virtual_facts()) is dict

# Generated at 2022-06-23 02:19:25.001553
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """
    This is a unit test for HPUXVirtualCollector class
    """
    h = HPUXVirtualCollector()
    assert isinstance(h, HPUXVirtualCollector)
    assert h.platform == 'HP-UX'


# Generated at 2022-06-23 02:19:35.501180
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.module_generic import ModuleGeneric
    from random import randint
    from tempfile import mkdtemp
    from shutil import rmtree

    hv = HPUXVirtual()
    hv.module = ModuleGeneric()
    hv.module.run_command = run_command

    def run_command(command):
        rc = randint(0, 2)
        if "/usr/sbin/vecheck" in command:
            if rc == 0:
                out = "test"
            else:
                out = False
        elif "/opt/hpvm/bin/hpvminfo" in command:
            if rc == 0:
                out = "Running as HPVM guest"

# Generated at 2022-06-23 02:19:45.340064
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hstdout = open('/tmp/HPUXVirtual.txt', 'w')
    hstdout.write("""
/usr/sbin/vecheck
/opt/hpvm/bin/hpvminfo
/usr/sbin/parstatus
""")
    hstdout.close()

    hstderr = open('/tmp/HPUXVirtual.err', 'w')
    hstderr.write("""
Running
Running HPVM guest
Running HPVM host
""")
    hstderr.close()

    x = HPUXVirtual(dict(ansible_facts=dict()), dict(module_stdout=hstdout.name, module_stderr=hstderr.name))
    y = x.get_virtual_facts()
    assert len(y) == 5

# Generated at 2022-06-23 02:19:46.815442
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector()
    assert collector._platform == 'HP-UX'

# Generated at 2022-06-23 02:19:49.429367
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpux_vc = HPUXVirtualCollector()
    assert hpux_vc._fact_class == HPUXVirtual
    assert hpux_vc._platform == 'HP-UX'

# Generated at 2022-06-23 02:19:54.544592
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = DummyAnsibleModule()
    virtual_facts = HPUXVirtual(module)
    assert virtual_facts.__class__.__name__ == 'HPUXVirtual'
    assert virtual_facts.platform == 'HP-UX'



# Generated at 2022-06-23 02:20:03.854628
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual

    # Create a dictionary containing input data for the test.
    input_data = {
        'hpvminfo': None,
        'parstatus': None,
        'vecheck': None,
    }

    # Create a HPUXVirtual object.
    hpux_virtual_facts_obj = HPUXVirtual(dict())

    # Unit test for method get_virtual_facts of class HPUXVirtual
    # with hpvminfo result text.
    hpvminfo_result_text = "Running HPVM vPar"
    hpux_virtual_facts_obj.hpvminfo = lambda: hpvminfo_result_text
    virtual_facts = hpux_virtual_facts_obj._get_virtual_facts()

# Generated at 2022-06-23 02:20:08.458792
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    assert obj.__class__.__name__ == 'HPUXVirtualCollector'
    assert obj.__class__.__bases__ == (VirtualCollector, )
    assert obj.platform == 'HP-UX'
    assert obj._fact_class == HPUXVirtual



# Generated at 2022-06-23 02:20:10.697251
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv._platform == 'HP-UX'

# Generated at 2022-06-23 02:20:12.022894
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual()
    assert v.platform == 'HP-UX'

# Generated at 2022-06-23 02:20:15.784310
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    my_HPUXVirtualCollector = HPUXVirtualCollector()
    assert my_HPUXVirtualCollector is not None
    assert my_HPUXVirtualCollector._fact_class == HPUXVirtual



# Generated at 2022-06-23 02:20:18.912055
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    my_test = HPUXVirtualCollector()
    assert my_test is not None


# Generated at 2022-06-23 02:20:25.628146
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    get_virtual_facts = HPUXVirtual().get_virtual_facts
    #
    # The following vars are defined for the sake of unit test.
    #
    module = FakeAnsibleModule()
    #
    # Test with vecheck is not exists.
    #
    os.path.exists = MagicMock(side_effect=[False, False])
    assert get_virtual_facts() == {'virtualization_type': None,
                                   'virtualization_role': None,
                                   'virtualization_tech_guest': set(),
                                   'virtualization_tech_host': set()}
    #
    # Test with '/usr/sbin/vecheck' command returns non-zero value.
    #
    os.path.exists = MagicMock(side_effect=[True, False])
    module.run_

# Generated at 2022-06-23 02:20:31.999300
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpuxvc = HPUXVirtualCollector()
    # Assert type of attribute _fact_class
    assert(isinstance(hpuxvc._fact_class, type))
    # Assert value of attribute _fact_class
    assert(hpuxvc._fact_class == HPUXVirtual)
    # Assert value of attribute _platform
    assert(hpuxvc._platform == 'HP-UX')

# Generated at 2022-06-23 02:20:42.729782
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import Virtual, VirtualCollector
    from ansible.module_utils.facts import FactModule
    try:
        from ansible.module_utils._text import to_text
    except ImportError:
        from ansible.module_utils.basic import to_text
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.virtual.hpar import HPUXVirtual

    test_data = (
        ({}, {}),
    )

# Generated at 2022-06-23 02:20:52.313820
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    hv = HPUXVirtual({})
    hv.module.run_command = lambda x: (0, 'Running HPVM guest', '')
    facts = hv.get_virtual_facts()

    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HPVM IVM'
    assert 'HPVM' in facts['virtualization_tech_guest']
    assert 'HPVM vPar' not in facts['virtualization_tech_guest']
    assert 'HP vPar' not in facts['virtualization_tech_guest']
    assert 'HP nPar' not in facts['virtualization_tech_guest']
    assert 'HPVM' not in facts['virtualization_tech_host']
    assert 'HPVM vPar' not in facts['virtualization_tech_host']
   

# Generated at 2022-06-23 02:20:54.703706
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    assert obj
    assert obj._platform == 'HP-UX'
    assert obj._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:21:05.693629
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    py_module_args = {}
    py_module_args['ansible_facts'] = {}
    py_module_args['ansible_facts']['ansible_system'] = 'HP-UX'
    py_module_args['module'] = 'setup'
    py_module_args['_ansible_version'] = '2.8'
    py_module_args['ansible_python_interpreter'] = 'python'
    py_module_args['ansible_system_capabilities_allowed'] = ['']
    py_module_args['_ansible_module_name'] = 'setup'
    py_module_args['_ansible_module_setup'] = True

    hpux_virtual = HPUXVirtual(py_module_args)
    facts = hpux_virtual.get_virtual_facts()

   

# Generated at 2022-06-23 02:21:13.206517
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    data = {'ansible_facts': {}}
    module = SystemFacts(dict(), data)

    virt = HPUXVirtual(module)
    virtual_facts = virt.get_virtual_facts()
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

    assert not virtual_facts.get('virtualization_type')
    assert not virtual_facts.get('virtualization_role')

# Generated at 2022-06-23 02:21:16.758327
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    This will test the constructor of HPUXVirtual class
    """
    check = HPUXVirtual()
    assert check.platform == 'HP-UX'

# Generated at 2022-06-23 02:21:21.118948
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert x.platform == 'HP-UX'
    assert isinstance(x.collector, HPUXVirtual)
    assert x.fact_class == HPUXVirtual

# Generated at 2022-06-23 02:21:22.696329
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual()
    assert virtual
    assert virtual._platform == 'HP-UX'


# Generated at 2022-06-23 02:21:26.978474
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.virtualization_type is None
    assert virtual_facts.virtualization_role is None
    assert virtual_facts.virtualization_tech_guest == set()
    assert virtual_facts.virtualization_tech_host == set()

# Generated at 2022-06-23 02:21:36.169466
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hp_ux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hp_ux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual import Virtual, VirtualCollector
    from ansible.module_utils.basic import AnsibleModule
    import os

    def dummy_run_command(command):
        """
        run_command implementation for unit test
        """
        if command == "/usr/sbin/vecheck":
            return (0, "", "")
        if command == "/opt/hpvm/bin/hpvminfo":
            return (0, "Running as HPVM vPar", "")
        if command == "/usr/sbin/parstatus":
            return (0, "parstatus test", "")

# Generated at 2022-06-23 02:21:37.985038
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-23 02:21:40.951867
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    my_hpu = HPUXVirtual(dict())
    assert my_hpu.platform == "HP-UX"


# Generated at 2022-06-23 02:21:43.161500
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual()
    assert h.platform == HPUXVirtual.platform


# Generated at 2022-06-23 02:21:45.739607
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual()
    assert virtual._platform == 'HP-UX'


# Generated at 2022-06-23 02:21:56.188504
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import FactModule
    from ansible.module_utils.facts.virtual import BaseVirtual

    module = FactModule()
    module.params = {"gather_subset": ['all'], "filter": '*'}
    module.run_command = BaseVirtual.run_command
    module.load_file = BaseVirtual.load_file
    hpux_virtual = HPUXVirtual(module)
    virtual_facts = hpux_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'host'
    assert virtual_facts['virtualization_role'] == 'HPVM'
    assert 'HPVM' in virtual_facts['virtualization_tech_host']
    assert not virtual_facts['virtualization_tech_guest']


# Generated at 2022-06-23 02:21:57.405696
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual()
    assert v._platform == 'HP-UX'



# Generated at 2022-06-23 02:22:04.992442
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class MockModule():
        def run_command(self, command):
            return (0, "", "")
    class MockAnsibleModule():
        def __init__(self):
            self.module = MockModule()
    hpuxvirtual = HPUXVirtual(MockAnsibleModule())
    expected_virtual_facts = {'virtualization_type': "guest",
                              'virtualization_role': "HP nPar",
                              'virtualization_tech_host': set([]),
                              'virtualization_tech_guest': set(['HP nPar'])}
    assert hpuxvirtual.get_virtual_facts() == expected_virtual_facts

# Generated at 2022-06-23 02:22:09.504537
# Unit test for method get_virtual_facts of class HPUXVirtual

# Generated at 2022-06-23 02:22:20.523976
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Stub module
    stub_module = type('stub_module', (object,), {
        'run_command': lambda self, command: (0, '', ''),
        'get_bin_path': lambda self, command: command,
    })

    # Stub facts
    stub_facts = type('stub_facts', (object,), {
        '__getitem__': lambda self, key: '',
    })

    # Stub is_hpux
    stub_is_hpux = type('stub_is_hpux', (object,), {
        '__getitem__': lambda self, key: True,
    })

    # Stub exists
    stub_exists = type('stub_exists', (object,), {
        '__call__': lambda self, key: False,
    })

    # Stub Virtual class

# Generated at 2022-06-23 02:22:21.488514
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-23 02:22:22.877218
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform is not None


# Generated at 2022-06-23 02:22:28.071311
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
  hv = HPUXVirtual()
  assert hv.platform == 'HP-UX'
  assert hv.get_virtual_facts()['virtualization_tech_guest'] == set()
  assert hv.get_virtual_facts()['virtualization_tech_host']  == set()
  assert hv.get_virtual_facts()['virtualization_type']       == None
  assert hv.get_virtual_facts()['virtualization_role']       == None


# Generated at 2022-06-23 02:22:29.951281
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert isinstance(hv, HPUXVirtualCollector)

# Generated at 2022-06-23 02:22:34.190192
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    try:
        print("Unit test for HPUXVirtualCollector")
        instance = HPUXVirtualCollector()
        assert not instance is None
        print("Unit test for HPUXVirtualCollector complete")
    except:
        print("Unit test for HPUXVirtualCollector failed")


# Generated at 2022-06-23 02:22:46.198132
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    from ansible_collections.ansible.community.tests.unit.compat.mock import MagicMock, patch


# Generated at 2022-06-23 02:22:56.921725
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.virtual import HPUXVirtual
    module = FakeAnsibleModule()
    hostvars = Facts(module, 'virtual', '', [], [], [], {})
    hostvars._facts['virtual'] = {}
    hostvars._facts['virtual']['virtualization_type'] = 'HP-UX'
    # hostvars._facts['virtual']['virtualization_role'] = 'VMware vCenter'
    test_HPUXVirtual = HPUXVirtual(module, hostvars)
    result = test_HPUXVirtual.get_virtual_facts()
    # assert result == {'virtualization_type': 'guest', 'virtualization_role': 'HPVM vPar',
    #                   'virtualization_tech_

# Generated at 2022-06-23 02:22:58.880894
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpx = HPUXVirtualCollector()
    assert hpx._platform == 'HP-UX'
    assert hpx._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:23:03.614122
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = {}
    module['run_command'] = run_command
    fact_collector = HPUXVirtualCollector(module)
    assert(isinstance(fact_collector, VirtualCollector))
    assert(isinstance(fact_collector.platform, str))
    assert(isinstance(fact_collector.fact_class, Virtual))


# Generated at 2022-06-23 02:23:13.096629
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    test_module = type('test', (object,), {'params': {}})
    test_module.run_command = _test_command
    test_module.exit_json = _test_exit_json
    test_module.fail_json = _test_fail_json
    collector = HPUXVirtualCollector(test_module)
    assert collector.__module__ == 'ansible.module_utils.facts.virtual.hpux'
    assert collector.__class__.__name__ == 'HPUXVirtualCollector'
    assert collector._platform == 'HP-UX'
    assert collector._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:23:18.346356
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vobj = HPUXVirtualCollector()
    assert vobj['virtualization_tech_guest'] == set()
    assert vobj['virtualization_tech_host'] == set()
    assert vobj['virtualization_type'] == 'guest'
    assert vobj['virtualization_role'] == 'HP vPar'


# Generated at 2022-06-23 02:23:29.448015
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    import ansible.module_utils.facts.virtual.hpux
    import platform

    m_platform = platform
    m_platform.system.return_value = 'HP-UX'
    m_platform.release.return_value = 'B.11.23'
    m_platform.mac_ver.return_value = ('', ('', '', ''), '')

    mock_module = basic.AnsibleModule(
        argument_spec={},
    )

    # Mocks the module.run_command() method to test get_virtual_facts method
    def run_command(self, cmd, check_rc=True):
        rc = 0
        out = ""
        err = ""

# Generated at 2022-06-23 02:23:31.988854
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector('module', 'runner')
    assert obj.platform == 'HP-UX'
    assert obj.fact_class == HPUXVirtual

# Generated at 2022-06-23 02:23:44.246742
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual import VirtualCollector
    from ansible.module_utils.facts.virtual import VirtualFactCache
    import ansible.module_utils.facts.virtual.hpux

    # Make sure the generic class is not used
    assert VirtualCollector is not HPUXVirtualCollector
    assert VirtualFactCache is not ansible.module_utils.facts.virtual.hpux.HPUXVirtualFactCache

    # Set up mocks
    mocked_module = type('AnsibleModule', (object, ),
                         dict(run_command=lambda *_: (0, '', ''),
                              _diff=True))()
