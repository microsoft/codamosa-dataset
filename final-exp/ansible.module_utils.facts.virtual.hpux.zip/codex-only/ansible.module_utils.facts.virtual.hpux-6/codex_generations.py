

# Generated at 2022-06-23 02:13:50.082183
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.platform == 'HP-UX'
    assert hv.get_virtual_facts() == {'virtualization_type': 'guest', 'virtualization_role': 'HP vPar'}

# Generated at 2022-06-23 02:13:52.222555
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert isinstance(virtual_collector, HPUXVirtualCollector)

# Generated at 2022-06-23 02:14:04.621519
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModuleMock({})
    run_command_result = ([0, "", ""])
    module.run_command = Mock(return_value=run_command_result)
    virtual = HPUXVirtual(module)

    # Patch method run_command of class Virtual
    module.run_command = Mock(return_value=run_command_result)

    # Patch os.path.exists
    module.os.path.exists = Mock(return_value=True)

    rc, out, err = module.run_command("/usr/sbin/vecheck")
    assert rc == 0
    assert out != ""
    assert err == ""

    rc, out, err = module.run_command("/opt/hpvm/bin/hpvminfo")
    assert rc == 0
    assert out != ""
   

# Generated at 2022-06-23 02:14:06.680393
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual(dict(module=None)).platform == 'HP-UX'

# Generated at 2022-06-23 02:14:09.470344
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    c = HPUXVirtualCollector()
    assert c
    assert c._fact_class == HPUXVirtual
    assert c._platform == 'HP-UX'


# Generated at 2022-06-23 02:14:16.949769
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    facts = {
        'virtualization_tech_host': set(),
        'virtualization_role': 'HP nPar',
        'virtualization_type': 'guest',
        'virtualization_tech_guest': set(),
    }
    hpux = HPUXVirtual(None)
    assert hpux
    assert isinstance(hpux,Virtual)
    assert hpux.platform == 'HP-UX'
    assert hpux.get_virtual_facts() == facts


# Generated at 2022-06-23 02:14:21.265158
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual(dict())
    assert virtual_obj.virtualization_type == 'host'
    assert virtual_obj.virtualization_role == ''
    assert virtual_obj.virtualization_role_guest == []
    assert virtual_obj.virtualization_role_host == []
    assert virtual_obj.virtualization_role_guest == []
    assert virtual_obj.virtualization_role_host == []

# Generated at 2022-06-23 02:14:24.316596
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = AnsibleModuleMock()
    collector = HPUXVirtualCollector(module)
    assert collector.facts['virtualization_type'] == 'guest'
    assert collector.facts['virtualization_role'] == 'HP vPar'
    assert collector.facts['virtualization_tech_guest'] == {'HP vPar'}



# Generated at 2022-06-23 02:14:34.761521
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    HPUX = HPUXVirtual()

    def side_effect(arg):
        if arg == '/usr/sbin/vecheck':
            return (0, '', '')
        if arg == '/opt/hpvm/bin/hpvminfo':
            return (0, '', '')
        if arg == '/usr/sbin/parstatus':
            return (0, '', '')
        else:
            return (1, '', '')

    setattr(HPUX.module, 'run_command', side_effect)
    facts = HPUX.get_virtual_facts()
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:14:37.163153
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    facts = HPUXVirtualCollector()
    assert isinstance(facts,HPUXVirtualCollector)
    assert facts.facts is not None


# Generated at 2022-06-23 02:14:38.647112
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-23 02:14:48.671872
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    print('Testing get_virtual_facts of class HPUXVirtual')
    module = MagicMock()
    module.run_command.return_value = (0, "Running HPVM vPar.\n", '')
    module.run_command.return_value = (0, "Running HPVM host.\n", '')

    virtual_facts_ = HPUXVirtual(module)
    virtual_facts = virtual_facts_.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HPVM vPar'
    virtual_facts = virtual_facts_.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'host'
    assert virtual_facts['virtualization_role'] == 'HPVM'

# Generated at 2022-06-23 02:14:56.584561
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    '''The function HPUXVirtual.get_virtual_facts is designed to
       return virtualization facts under HP-UX platform. This library
       is tested here using mocking concept of Python. The tests are
       written using the standard library "mock" which is a part of
       Python since Python 3.3.

       To run the unit tests for this library, execute the command:
       "python -m pytest -v" in the directory containing this file.
    '''

    # Import the standard library mock
    try:
        from unittest.mock import MagicMock
    except ImportError:
        from mock import Mock as MagicMock

    # Import the module to be tested
    from ansible.module_utils.facts.virtual.hpu import HPUXVirtual

    # Create a magic mock module
    mock_module = MagicMock()

   

# Generated at 2022-06-23 02:15:04.990001
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    '''
    Test get_virtual_facts with different output of commands.
    '''
    from ansible.module_utils.six import StringIO

    class TestModule(object):
        def __init__(self, params):
            self._params = params

        def run_command(self, command, check_rc=True):
            rc = 0
            if command.find('vecheck') != -1:
                output = """
                Virtual Partition (VPAR) support is enabled.
                """
            elif command.find('hpvminfo') != -1:
                output = """
                Running HPVM guest
                """
            elif command.find('parstatus') != -1:
                output = """
                N_Pars:     1
                """
            else:
                rc = -1

# Generated at 2022-06-23 02:15:09.285424
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.data['virtualization_tech_host'] is None
    assert hv.data['virtualization_tech_guest'] is None
    assert hv.data['virtualization_role'] is None
    assert hv.data['virtualization_type'] is None

# Generated at 2022-06-23 02:15:19.825489
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    try:
        import ansible.module_utils.facts.virtual.hpux
        from ansible.module_utils.facts import FactCollector
    except ImportError:
        print("Could not import ansible.module_utils.facts.virtual.hpux")
        return

    class AnsibleModuleMock(object):
        def __init__(self, params):
            self._result = {
                'ansible_facts': {
                    'virtualization': {
                        'type': None,
                        'tech_host': set(),
                        'tech_guest': set(),
                        'role': None,
                    }
                }
            }
            self.params = params

        def exit_json(self, **kwargs):
            raise SystemExit(1)


# Generated at 2022-06-23 02:15:21.221939
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector(None)

# Generated at 2022-06-23 02:15:26.154471
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert HPUXVirtualCollector._fact_class.platform == 'HP-UX'
    assert HPUXVirtualCollector._platform == 'HP-UX'
    assert virtual_collector.platform == 'HP-UX'
    assert virtual_collector.fact_class.platform == 'HP-UX'

# Generated at 2022-06-23 02:15:32.857658
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import ansible.module_utils.facts.virtual.hpux
    module = ansible.module_utils.facts.virtual.hpux
    virtual = module.HPUXVirtual(module)
    supported = virtual.is_supported()
    if supported:
        facts = virtual.get_virtual_facts()
        print("Virtual facts:", facts)
    else:
        print("HPUXVirtual is not supported on this platform")


# Generated at 2022-06-23 02:15:35.924276
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert virtual_collector._platform == 'HP-UX'
    assert virtual_collector._fact_class.__name__ == 'HPUXVirtual'

# Generated at 2022-06-23 02:15:43.848969
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict())
    assert virtual.__class__.__name__ == "HPUXVirtual"
    assert virtual.platform == 'HP-UX'
    assert virtual.virtualization_tech_guest == set()
    assert virtual.virtualization_tech_host == set()
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'host'
    assert virtual_facts['virtualization_role'] == 'HPVM'
    assert virtual_facts['virtualization_tech_guest'] == set(['HPVM'])
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:15:48.563000
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import HPUXVirtual
    module = get_empty_module()
    module.run_command = get_fake_run_command()
    virtual = HPUXVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert(virtual_facts['virtualization_type'] == 'guest')
    assert(virtual_facts['virtualization_role'] == 'HPVM IVM')



# Generated at 2022-06-23 02:15:51.114164
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    '''
    Unit test for constructor of class HPUXVirtual
    '''
    v = HPUXVirtual({}, False)
    assert v.platform == "HP-UX"


# Generated at 2022-06-23 02:16:00.840303
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class TestModule(object):
        def run_command(self, cmd):
            if cmd == '/usr/sbin/vecheck':
                return 0, '', ''
            elif cmd == '/opt/hpvm/bin/hpvminfo':
                return 0, 'Running HPVM guest virtual machine', ''
            elif cmd == '/usr/sbin/parstatus':
                return 0, '', ''
            elif cmd == '/usr/sbin/prtconf':
                return 0, '', ''

    module = TestModule()
    hpux = HPUXVirtual()
    hpux.module = module
    facts = hpux.get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HPVM IVM'

# Generated at 2022-06-23 02:16:07.600588
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = {
        'virtualization_type': 'guest',
        'virtualization_role': 'HP vPar',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(['HP vPar', 'HP nPar'])
    }
    h = HPUXVirtual({})
    assert h.get_virtual_facts() == virtual_facts

# Generated at 2022-06-23 02:16:17.390795
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = type('', (), {'run_command': lambda self, k: ('0', '', '')})()
    os.path.exists = lambda k: True
    hv = HPUXVirtual(module)
    assert hv.get_virtual_facts() == {'virtualization_type': 'guest',
                                      'virtualization_role': 'HP vPar',
                                      'virtualization_tech_guest': {'HP vPar'},
                                      'virtualization_tech_host': set()}

# Generated at 2022-06-23 02:16:22.050937
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    '''
    Unit test for constructor of class HPUXVirtualCollector
    '''

    hpxvirtual_obj = HPUXVirtualCollector()
    assert hpxvirtual_obj._platform == 'HP-UX'
    assert hpxvirtual_obj._fact_class.platform == 'HP-UX'
    assert hpxvirtual_obj._fact_class.__name__ == 'HPUXVirtual'


# Generated at 2022-06-23 02:16:24.391784
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual({'ANSIBLE_MODULE_ARGS': {}}).platform == 'HP-UX'


# Generated at 2022-06-23 02:16:26.250750
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(dict())
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-23 02:16:29.614469
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual({})
    assert v.collect()['virtualization_type'] == 'guest'
    assert v.collect()['virtualization_role'] == 'HP vPar'
    assert 'HP vPar' in v.collect()['virtualization_tech_guest']

# Generated at 2022-06-23 02:16:32.309641
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    assert obj is not None
    assert obj.__class__.__name__ == 'HPUXVirtualCollector'


# Generated at 2022-06-23 02:16:37.279926
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(dict(module=dict()))
    assert hv.platform == 'HP-UX'
    assert hv.module is not None

# Generated at 2022-06-23 02:16:39.202233
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-23 02:16:45.347552
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils import basic

    m = basic.AnsibleModule(argument_spec=dict())
    facts = HPUXVirtual(m).get_facts()
    assert facts['virtualization_tech_guest'] == {'HP vPar', 'HPVM vPar', 'HPVM IVM', 'HP nPar'}

# Generated at 2022-06-23 02:16:55.575350
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    facts = {}
    class DummyModule(object):
        def run_command(self, cmd):
            return 0, '', ''
    dummyModule = DummyModule()
    hv = HPUXVirtual(dummyModule, facts)
    hv._module.run_command = lambda cmd: (0, '', '')
    assert hv.get_virtual_facts() == {'virtualization_type': 'guest',
                                      'virtualization_role': 'HP vPar',
                                      'virtualization_tech_guest': set(['HP vPar']),
                                      'virtualization_tech_host': set()}
    facts['virtualization_type'] = 'host'

# Generated at 2022-06-23 02:16:59.555705
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpx = HPUXVirtualCollector()
    assert hpx._platform == 'HP-UX'
    assert hpx._fact_class.platform == 'HP-UX'

# Generated at 2022-06-23 02:17:07.261700
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Run method get_virtual_facts of class HPUXVirtual
    print("Testing method get_virtual_facts of class HPUXVirtual")
    collect = HPUXVirtualCollector()
    data = collect.get_virtual_facts()
    # Test virtualization_type
    if data['virtualization_type'] in ['host', 'guest']:
        print("virtualization_type: %s OK" % data['virtualization_type'])
    else:
        raise Exception("virtualization_type: %s KO" % data['virtualization_type'])

# Generated at 2022-06-23 02:17:09.501480
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    facts = HPUXVirtualCollector().collect()
    if not hasattr(facts, 'virtualization'):
        raise Exception("Failed to initialize fact class")

# Generated at 2022-06-23 02:17:12.583804
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """Test class HPUXVirtualCollector"""
    virt_facts = HPUXVirtualCollector()
    assert virt_facts.platform == 'HP-UX'
    assert virt_facts.fact_class is HPUXVirtual

# Generated at 2022-06-23 02:17:15.345400
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector(None)
    assert collector._platform == 'HP-UX'
    assert collector._fact_class == HPUXVirtual
# end of test_HPUXVirtualCollector()

# Generated at 2022-06-23 02:17:20.569569
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virt = HPUXVirtual()
    if hpux_virt.platform != 'HP-UX':
        raise AssertionError()
    if hpux_virt._platform != 'HP-UX':
        raise AssertionError()


# Generated at 2022-06-23 02:17:32.731816
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import HPUXVirtual
    import tempfile

    module = AnsibleModuleMock()
    file_name = tempfile.mktemp()
    test_file = open(file_name, "w")
    test_file.write('Running, HPVM vPar')
    test_file.close()

    module.run_command.return_value = (0, file_name, '')

    virtual_facts = HPUXVirtual(module=module).get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HPVM vPar'
    assert virtual_facts['virtualization_tech_guest'] == set(['HPVM vPar'])
    assert virtual_facts['virtualization_tech_host']

# Generated at 2022-06-23 02:17:44.331864
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import FactCollector

    class Argv:
        def __init__(self):
            self.run_command = ['/usr/sbin/vecheck']

    class RunCommand:
        def __init__(self, out, rc=0, err=''):
            self.out = out
            self.rc = rc
            self.err = err

    class Module:
        def __init__(self):
            self.RunCommand = RunCommand
            self.run_command = RunCommand
            self.argv = Argv

    def get_virtual_facts(self, module):
        return Virtual(module).get_virtual_facts()

    class Facts:
        def __init__(self):
            self.module = Module()


# Generated at 2022-06-23 02:17:47.271034
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hp_virtual = HPUXVirtual()
    assert hp_virtual.platform == 'HP-UX'


# Generated at 2022-06-23 02:17:54.684202
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    set_module_args(dict(
        gather_subset='min'
    ))
    virtual = HPUXVirtual()
    assert virtual.get_virtual_facts() == dict(
        virtualization_type='guest',
        virtualization_role='HP nPar'
    )

# Generated at 2022-06-23 02:18:03.063469
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = dict()
    virtual_facts['virtualization_type'] = 'host'
    virtual_facts['virtualization_role'] = 'HPVM'
    virtual_facts['virtualization_tech_host'] = set(['HPVM'])
    virtual_facts['virtualization_tech_guest'] = set()
    hpux_virtual = HPUXVirtual(virtual_facts)
    assert(hpux_virtual.is_virtual() is True)
    assert(hpux_virtual._is_virtual_guest() is False)
    assert(hpux_virtual._is_virtual_host() is True)
    assert(hpux_virtual.get_virtualization_type() == 'host')
    assert(hpux_virtual.get_virtualization_role() == 'HPVM')

# Generated at 2022-06-23 02:18:15.413436
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    test_HPUXVirtual_get_virtual_facts()
    """
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    # Setup module object
    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    virtual_facts = collector.get_virtual_facts(module)
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'

    virtualization_tech_guest = virtual_facts['virtualization_tech_guest']
    assert 'HP vPar' in virtualization_tech_guest
    assert 'HPVM vPar' in virtualization_tech_guest
    assert 'HP nPar' in virtualization_

# Generated at 2022-06-23 02:18:18.650360
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert virtual_collector is not None

# Generated at 2022-06-23 02:18:25.523943
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    # Make sure the constructor creates an empty object
    virtual_collector = HPUXVirtualCollector(load_file=False)
    assert virtual_collector.facts == {}
    # Make sure the constructor creates an object with the correct
    # attribute values
    virtual_collector = HPUXVirtualCollector(load_file=False)
    assert virtual_collector.facts_class == HPUXVirtual
    assert virtual_collector.platform == 'HP-UX'



# Generated at 2022-06-23 02:18:35.153955
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux_virtual import HPUXVirtual

    # This is a hack to avoid calling the module.run_command method
    # Will create a mock class and assign it to ansible.module_utils.facts.virtual.base.AnsibleModule
    # so it will be called instead of AnsibleModule.run_command
    class MockModule(object):
        def __init__(self):
            self.params = {}

        def run_command(self, cmd):
            return 0, "", ""

    class MockAnsibleModule:
        def __init__(self):
            self.params = {}

        def fail_json(self, *args, **kwargs):
            return 1

    mock_module = MockModule()
    mock_ansible_module = MockAnsibleModule()

   

# Generated at 2022-06-23 02:18:44.514652
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    # Test 1: No virtualization
    def test_1(self):
        self.module.run_command.return_value = (0, '', '')
        self.module.os.path.exists.side_effect = [False]

        virtual = HPUXVirtual(self.module)
        facts = virtual.get_virtual_facts()

        assert facts['virtualization_type'] == 'physical'
        assert facts['virtualization_role'] == 'physical'
        assert facts['virtualization_tech_guest'] == set()
        assert facts['virtualization_tech_host'] == set()

    # Test 2: HP nPar
    def test_2(self):
        self.module.run_command.return_value = (0, '', '')

# Generated at 2022-06-23 02:18:46.955142
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert isinstance(hv, HPUXVirtualCollector)
    assert hv.platform == 'HP-UX'
    assert hv._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:18:49.768130
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vc = HPUXVirtualCollector()
    assert vc._fact_class is HPUXVirtual

# Generated at 2022-06-23 02:18:51.817028
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(dict())
    assert isinstance(hpux_virtual, HPUXVirtual)

# Generated at 2022-06-23 02:19:02.689179
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = get_mock_ansible_module_for_class(HPUXVirtual)
    module.mock_command('/usr/sbin/vecheck', True, '\n')
    module.mock_command('/opt/hpvm/bin/hpvminfo', True, '\n')
    module.mock_command('/usr/sbin/parstatus', True, '\n')
    virtual_facts_obj = HPUXVirtual()
    virtual_facts_obj.module = module
    assert virtual_facts_obj.get_virtual_facts() == {}
    module.mock_command('/usr/sbin/vecheck', False, '\n')
    module.mock_command('/opt/hpvm/bin/hpvminfo', True, '\n')
    module.mock_command

# Generated at 2022-06-23 02:19:09.308709
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vc = HPUXVirtualCollector()
    assert isinstance(vc, HPUXVirtualCollector)
    assert vc._platform == 'HP-UX'
    assert vc._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:19:13.724386
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert virtual_collector._platform == 'HP-UX'
    assert isinstance(virtual_collector._fact_class, HPUXVirtual)

# Generated at 2022-06-23 02:19:15.979791
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    Create an object of HPUXVirtualClass
    """
    virtual = HPUXVirtual(dict())
    assert virtual

# Generated at 2022-06-23 02:19:18.518164
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    facts = dict()
    my_ob = HPUXVirtualCollector(facts, None)
    assert isinstance(my_ob, HPUXVirtualCollector)

# Generated at 2022-06-23 02:19:21.145271
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual({})
    hpux_virtual.get_virtual_facts()
    assert hpux_virtual


# Generated at 2022-06-23 02:19:30.460245
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class HPUXVirtual'''
    from ansible.module_utils.facts.virtual.hpar import Virtual, VirtualCollector
    import tempfile
    import os
    module = AnsibleModule(argument_spec={})

    tmp_file_name = tempfile.mktemp()
    open(tmp_file_name, 'w').close()

    v = Virtual(module)
    os.remove(tmp_file_name)
    v.get_virtual_facts()

    os.remove(tmp_file_name)
    v.get_virtual_facts()
    os.remove(tmp_file_name)
    v.get_virtual_facts()



# Generated at 2022-06-23 02:19:31.927915
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert x.platform == 'HP-UX'

# Generated at 2022-06-23 02:19:34.872082
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual({'module': None})
    assert h.platform == 'HP-UX'


# Generated at 2022-06-23 02:19:44.820913
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Test for HPUXVirtual.get_virtual_facts()
    """
    from ansible.module_utils.facts.virtual.hpar import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpvm import HPUXVirtual as HPVM
    from ansible.module_utils.facts.virtual.hpvm import HPVM_vpar
    from ansible.module_utils.facts.virtual.hpvm import HPVM_guest
    from ansible.module_utils.facts.virtual.hpvm import HPVM_host
    hpux_facts = HPUXVirtual(None)
    hpvm = HPVM(None)
    hpvm_vpar = HPVM_vpar(None)
    hpvm_guest = HPVM_guest(None)

# Generated at 2022-06-23 02:19:56.158105
# Unit test for method get_virtual_facts of class HPUXVirtual

# Generated at 2022-06-23 02:20:05.518610
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = MockModule()
    hpx_virtual = HPUXVirtual(module)
    guest_tech = {'HP nPar'}
    host_tech = set()
    virtual_facts = {'virtualization_type': 'guest',
                     'virtualization_role': 'HP nPar',
                     'virtualization_tech_guest': guest_tech,
                     'virtualization_tech_host': host_tech
                     }
    assert virtual_facts == hpx_virtual.get_virtual_facts()


from ansible.module_utils.facts.virtual.hpux import HPUXVirtual, HPUXVirtualCollector
from ansible.module_utils.basic import AnsibleModule



# Generated at 2022-06-23 02:20:08.488401
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual()
    assert virtual_obj.platform == 'HP-UX'
    assert virtual_obj.get_all_virtual_facts() == {}


# Generated at 2022-06-23 02:20:18.335973
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import ModuleExecutor, get_module_path
    import ansible.module_utils.facts.collector

    class MockModule:
        def __init__(self, params):
            self.params = params
            self._name = 'ansible_facts'

        def run_command(self, command):
            print('Running command: %s' % command)
            if command == "/opt/hpvm/bin/hpvminfo":
                return 0, 'Running HPVM guest', ''
            elif command == "/usr/sbin/vecheck":
                return 0, 'Running HP vPar', ''
            elif command == "/usr/sbin/parstatus":
                return 0, 'Running HP nPar', ''
            else:
                return -1, '', ''


    # Create a dummy params

# Generated at 2022-06-23 02:20:20.898708
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert issubclass(HPUXVirtualCollector, VirtualCollector)
    assert HPUXVirtualCollector._platform == 'HP-UX'


# Generated at 2022-06-23 02:20:32.206199
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    from ansible.module_utils.facts.virtual.hpuix import HPUXVirtual
    from ansible.module_utils.facts.virtual import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual

    class MockModule(object):
        def __init__(self):
            self.run_command = run_command

        def exit_json(self, **kwargs):
            pass

        def fail_json(self, **kwargs):
            pass

        def run_command(self, **kwargs):
            return run_command(**kwargs)

    class MockCollector(VirtualCollector):
        _fact_class = HPUXVirtual
        _platform = 'HP-UX'


# Generated at 2022-06-23 02:20:42.917061
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """ testing get_virtual_facts() of class HPUXVirtual """
    hv = HPUXVirtual({}, {}, {})

    # If vecheck does not exist, virtual_facts['virtualization_role'] shall be empty.
    with open('/usr/sbin/vecheck', 'w') as fp:
        fp.write('#! /bin/sh\nexit 1')
    virtual_facts = hv.get_virtual_facts()
    assert virtual_facts['virtualization_role'] == ''

    # If vecheck exists and vecheck is executed successfuly,
    # virtual_facts['virtualization_role'] shall be 'HP vPar'.
    with open('/usr/sbin/vecheck', 'w') as fp:
        fp.write('#! /bin/sh\nexit 0')
    virtual

# Generated at 2022-06-23 02:20:53.309212
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import subprocess
    from ansible.module_utils.facts.virtual.hpux.hpux_virtual import HPUXVirtual

    execute_command_mock = subprocess.Mock()
    execute_command_mock.return_value = (0, "", "")

    h = HPUXVirtual({})
    h.get_virtual_facts()
    assert execute_command_mock.mock_calls == [
        subprocess.call(['/usr/sbin/vecheck']),
        subprocess.call(['/opt/hpvm/bin/hpvminfo']),
        subprocess.call(['/usr/sbin/parstatus'])
    ]

# Generated at 2022-06-23 02:20:55.312655
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    my_obj = HPUXVirtual(module)
    assert my_obj.platform == 'HP-UX'

# Generated at 2022-06-23 02:21:06.225523
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    test_data = {
        "virtualization_type": "guest",
        "virtualization_role": "HP vPar",
        "virtualization_tech_host": set(),
        "virtualization_tech_guest": set(["HP vPar"])
    }

    module = FakeModule()
    my_virt = HPUXVirtual(module)
    facts = my_virt.get_virtual_facts()

    assert (facts['virtualization_type'] == test_data['virtualization_type'])
    assert (facts['virtualization_role'] == test_data['virtualization_role'])
    assert (facts['virtualization_tech_host'] == test_data['virtualization_tech_host'])
    assert (facts['virtualization_tech_guest'] == test_data['virtualization_tech_guest'])



# Generated at 2022-06-23 02:21:15.009923
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    mocked_module = Mock(return_value=None)
    mocked_module.run_command = Mock(return_value=(0, '', ''))

    hpux_virtual = HPUXVirtual(mocked_module)
    facts = hpux_virtual.get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP nPar'
    assert facts['virtualization_tech_guest'] == set(['HP nPar'])
    assert facts['virtualization_tech_host'] == set()


# Generated at 2022-06-23 02:21:16.296261
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-23 02:21:28.194932
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class HPUXVirtual
    """
    # Create HPUXVirtual instance
    hv_obj = HPUXVirtual()

    # Fake the run_command method
    def fake_run_command(self, cmd, check_rc=True):
        """
        Fake the run_command method in module_utils.basic.AnsibleModuleUtilsMixin
        class.
        """
        if cmd == "/usr/sbin/parstatus":
            class FakeHPVMParstatusCmd(object):
                """
                This is a fake class for invoking the run_command method.
                """
                def __init__(self):
                    self.error = None
                    self.fail = None
                    self.rc = 0
                    self.stdout = "Running in HP nPar"
                    self

# Generated at 2022-06-23 02:21:38.720078
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpu_x import HPUXVirtual
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import ModuleExecutor
    import types

    class MockModule:
        def __init__(self):
            self.run_command = MockRunCommand()
            self.params = dict()

        def get_bin_path(self, arg):
            return arg

    class MockRunCommand:
        def __init__(self):
            self.rc = 0
            self.output = None
            self.error = None

        def __call__(self, cmd):
            return self.rc, self.output, self.error

    class MockPythonModuleExecutor:

        _python_module_results = dict()

# Generated at 2022-06-23 02:21:44.970259
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # GIVEN a HPUXVirtual module
    hpux_virtual_test = HPUXVirtual(dict(module=dict()))
    # WHEN get_virtual_facts is called
    hpux_virtual_test.get_virtual_facts()
    # THEN the result should be a dict
    assert isinstance(hpux_virtual_test.virtual_facts, dict)

# Generated at 2022-06-23 02:21:50.448980
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec=dict())

    virtual_facts = HPUXVirtual(module).get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_fact

# Generated at 2022-06-23 02:21:59.680142
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """Unit test class HPUXVirtual
    """
    obj = HPUXVirtual()
    assert obj._platform == "HP-UX"
    assert obj.platform == "HP-UX"
    assert not obj.virtual
    assert not obj.container
    assert not obj.jail
    assert not obj.zone
    assert not obj.xen
    assert not obj.vserver
    assert not obj.vmm
    assert obj._fact_class == HPUXVirtual
    assert obj.virtualization_role == "HP-UX"
    assert not obj.virtualization_type

# Generated at 2022-06-23 02:22:10.522409
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import sys
    import subprocess

    class MockModule(object):
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []
        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            sys.exit(1)
        def run_command(self, args, check_rc=True):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

    module = MockModule()
    module.run_command_results.append((0, "Running HPVM guest",""))
    m = HPUXVirtual(module)
    vf = m.get_virtual_facts()

# Generated at 2022-06-23 02:22:14.981851
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpuxVirtualCollector = HPUXVirtualCollector()
    assert hpuxVirtualCollector._fact_class == HPUXVirtual
    assert hpuxVirtualCollector._platform == 'HP-UX'

# Generated at 2022-06-23 02:22:19.990804
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = 'ansible.module_utils.facts.virtual.hpux.HPUXVirtualCollector'
    collector = HPUXVirtualCollector(module)

    assert collector.platform == 'HP-UX'
    assert collector._fact_class == HPUXVirtual
    assert collector.facts is None
    assert collector.facts_collected == False

# Generated at 2022-06-23 02:22:21.751108
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_fact = HPUXVirtual()
    assert virtual_fact.platform == 'HP-UX'

# Generated at 2022-06-23 02:22:27.437775
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual({})
    assert v is not None
    assert v.platform == 'HP-UX'
    # Verify that the paths mentioned above does not exist
    assert not v.get_virtual_facts()['virtualization_type']
    assert not v.get_virtual_facts()['virtualization_role']
    assert not v.get_virtual_facts()['virtualization_tech_guest']
    assert not v.get_virtual_facts()['virtualization_tech_host']


# Generated at 2022-06-23 02:22:29.741059
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    x = HPUXVirtual()
    assert x.platform == 'HP-UX'
    assert len(x.virtual_facts) == 0

# Generated at 2022-06-23 02:22:38.673873
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    os.environ['ANSIBLE_VIRTUAL'] = 'HP-UX'
    hpux_virtual = HPUXVirtual(dict())
    if not os.path.exists('/usr/sbin/vecheck'):
        del os.environ['ANSIBLE_VIRTUAL']
        assert hpux_virtual.get_virtual_facts() == None
        return

# Generated at 2022-06-23 02:22:50.743820
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import mock
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({'gather_subset': ['!all', 'virtual']})
    module.run_command = mock.Mock()
    module.run_command.return_value = (0, '', '')
    hpux_virtual = HPUXVirtual(module)

    module.run_command.assert_called_with("/usr/sbin/vecheck")
    module.run_command.assert_called_with("/opt/hpvm/bin/hpvminfo")
    module.run_command.assert_called_with("/usr/sbin/parstatus")

    assert hpux_virtual.setup()

# Generated at 2022-06-23 02:22:56.865074
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.module_generic import DummyModule
    module = DummyModule()
    hpux_virtual = HPUXVirtual(module)
    assert hpux_virtual.get_virtual_facts() == {}

# Generated at 2022-06-23 02:23:01.176581
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # Setup the class.
    from ansible.module_utils.facts import namespace

    # The class to test
    v = HPUXVirtual(namespace.BaseModuleMock())

    # Ensure that there are no facts yet
    obs = v.get_virtual_facts()
    assert obs == {}



# Generated at 2022-06-23 02:23:05.219283
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    os_facts = dict(distribution=dict(distribution='HP-UX'))
    hw_facts = dict()
    a = HPUXVirtualCollector(os_facts, hw_facts)
    assert a.platform == 'HP-UX'
    assert a._fact_class.__name__ == 'HPUXVirtual'


# Generated at 2022-06-23 02:23:07.248417
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(dict())
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-23 02:23:09.861528
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpv = HPUXVirtual(dict())
    assert hpv.platform == 'HP-UX'
    assert hpv.get_virtual_facts() == {}

# Generated at 2022-06-23 02:23:17.512750
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    module.run_command = run_commandMock
    v = HPUXVirtual(module)
    expected_dict = {'virtualization_type': 'guest', 'virtualization_role': 'HP nPar',
                     'virtualization_tech_guest': {'HP nPar'}, 'virtualization_tech_host': set()}
    v_dict = v.get_virtual_facts()
    assert cmp(v_dict, expected_dict) == 0



# Generated at 2022-06-23 02:23:29.319744
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class Options(object):
        def __init__(self, args=None, connection=None):
            self.connection = connection
            self.become = False
            self.become_user = ''
            self.become_ask_pass = False
            self.remote_user = 'user'
            self.private_key_file = 'private_key_file'
            self.timeout = 10
            self.ssh_common_args = ''
            self.sftp_extra_args = ''
            self.scp_extra_args = ''
            self.ssh_extra_args = ''
            self.verbosity = 0
            self.check = False
            self.diff = False

    class Module(object):
        def __init__(self, **kwargs):
            self.params = Options()
            self.check_mode

# Generated at 2022-06-23 02:23:31.483906
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv._platform == 'HP-UX'
    assert hv._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:23:40.533685
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    hv = HPUXVirtual()
    facts = hv.get_virtual_facts()
    assert 'virtualization_type' in facts
    assert facts['virtualization_type'] == 'guest'
    assert 'virtualization_role' in facts
    assert facts['virtualization_role'] == 'HP vPar'
    assert 'virtualization_tech_host' in facts
    assert  facts['virtualization_tech_host'] == set([])
    assert 'virtualization_tech_guest' in facts
    assert facts['virtualization_tech_guest'] == set(['HP vPar'])

# Generated at 2022-06-23 02:23:45.638785
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual().populate()
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'