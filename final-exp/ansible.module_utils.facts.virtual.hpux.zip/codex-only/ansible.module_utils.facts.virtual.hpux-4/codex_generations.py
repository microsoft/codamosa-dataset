

# Generated at 2022-06-23 02:13:43.356940
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_obj = HPUXVirtualCollector()
    assert '_fact_class' in dir(virtual_obj)
    assert '_platform' in dir(virtual_obj)
    assert virtual_obj._platform == 'HP-UX'
    assert virtual_obj._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:13:51.665881
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    print("\n*** Unit Test ***\n")

    ansible_virtual_facts = HPUXVirtualCollector().collect()
    print("\nAnsible Module Output:\n", ansible_virtual_facts)
    print("\n*** End Unit Test ***\n")

if __name__ == '__main__':
    test_HPUXVirtualCollector()

# Generated at 2022-06-23 02:13:55.616278
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert issubclass(HPUXVirtualCollector, VirtualCollector)
    assert HPUXVirtualCollector._fact_class == HPUXVirtual
    assert HPUXVirtualCollector._platform == 'HP-UX'

# Generated at 2022-06-23 02:13:56.997855
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    obj.collect()

# Generated at 2022-06-23 02:14:09.424408
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    # Setup test data
    module_args = {}

    # Setup mocking
    class MockModule:
        pass
    
    class MockModule2:
        def run_command(command):
            if command == '/usr/sbin/vecheck':
                return 0, '', ''
            if command == '/opt/hpvm/bin/hpvminfo':
                return 0, 'Running as HPVM vPar.', ''
            if command == '/usr/sbin/parstatus':
                return 0, '', ''
            if command == '/usr/sbin/ioscan -kf':
                return 0, '', ''

    module = MockModule()

    module.run_command = MockModule2.run_command

    module.params = module_args

    hv = HPUXVirtual(module)

    virtual_facts = hv.get

# Generated at 2022-06-23 02:14:15.516219
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """
    test if the HPUXVirtualCollector class is correctly instantiated
    """
    assert HPUXVirtualCollector().__class__.__name__ == 'HPUXVirtualCollector'
    assert HPUXVirtualCollector()._fact_class.__name__ == 'HPUXVirtual'
    assert HPUXVirtualCollector()._platform == 'HP-UX'
    print("Unit test for HPUXVirtualCollector successful")


# Generated at 2022-06-23 02:14:17.200557
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    a = HPUXVirtualCollector()
    assert a.platform == 'HP-UX'

# Generated at 2022-06-23 02:14:24.571016
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    This is a unit test for method get_virtual_facts of class HPUXVirtual.
    It tests the ability of the method to correctly get the virtualization
    facts from the host system. It tests both the successful case, when the
    host system is indeed a virtual system and the unhappy case, when the
    host system is a bare metal system.
    """
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    if PY3:
        to_bytes = lambda x: bytes(x, 'latin-1')

    module_args = {}


# Generated at 2022-06-23 02:14:36.137020
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # test with a host
    v_obj = HPUXVirtual()
    v_obj.module = MagicMock(return_value=0)
    facts = v_obj.get_virtual_facts()
    assert facts['virtualization_type'] == 'host'
    assert facts['virtualization_role'] == 'HPVM'
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host'] == set(['HPVM'])
    assert VirtualCollector._platform == 'HP-UX'
    assert HPUXVirtualCollector._fact_class == HPUXVirtual

    # test with a guest
    v_obj = HPUXVirtual()
    v_obj.module = MagicMock(return_value=0)
    facts = v_obj.get_virtual_facts()

# Generated at 2022-06-23 02:14:48.193531
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector

    try:
        from unittest.mock import MagicMock
    except:
        from mock import MagicMock

    module = MagicMock()
    module.run_command = MagicMock(return_value=(0, 'Running as HPVM guest', None))

    HPUXVirtualCollector._module = module

    hpux_virtual_ins = HPUXVirtual(module)
    hpux_guest_data = hpux_virtual_ins.get_virtual_facts()

    assert hpux_guest_data['virtualization_type'] == 'guest'
    assert hpux_guest_data['virtualization_role'] == 'HPVM IVM'

# Generated at 2022-06-23 02:14:50.242766
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpuxvirtual = HPUXVirtual()
    assert hpuxvirtual


# Generated at 2022-06-23 02:14:53.927127
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    assert obj._fact_class is HPUXVirtual
    assert obj._platform == 'HP-UX'

# Generated at 2022-06-23 02:14:58.489361
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v_instance = HPUXVirtual()

    assert(v_instance.platform == 'HP-UX')
    assert(v_instance.get_virtual_facts() == {'virtualization_type': 'guest', 'virtualization_role': 'HPVM',
                                              'virtualization_tech_guest': set(['HPVM']), 'virtualization_tech_host': set()})


# Generated at 2022-06-23 02:15:02.027488
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpx = HPUXVirtualCollector()
    assert hpx
    assert hpx._fact_class == HPUXVirtual
    assert hpx.platform == 'HP-UX'



# Generated at 2022-06-23 02:15:03.858258
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    assert obj._platform == 'HP-UX'
    assert obj == obj.fetch_virtual_facts()

# Generated at 2022-06-23 02:15:05.839016
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector._platform == 'HP-UX'
    assert HPUXVirtualCollector._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:15:07.250033
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual()
    assert virtual.platform == 'HP-UX'

# Generated at 2022-06-23 02:15:16.309418
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    This test verifies the correct operation of get_virtual_facts()
    """

    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual

    # Create a fake ansible module
    module = AnsibleModule(argument_spec={})

    # Create a fake hpux module
    hpux_virtual = HPUXVirtual(module=module)

    # Run get_virtual_facts and compare results
    assert hpux_virtual.get_virtual_facts() == dict(
        virtualization_type='host',
        virtualization_role='HPVM',
        virtualization_tech_guest={'HPVM'},
        virtualization_tech_host=set()
    )

# Generated at 2022-06-23 02:15:17.461743
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-23 02:15:19.982327
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    test_HPUXVirtual = HPUXVirtual(dict())
    assert test_HPUXVirtual.platform == 'HP-UX'


# Generated at 2022-06-23 02:15:23.634334
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpxvc = HPUXVirtualCollector()
    assert hpxvc._fact_class == HPUXVirtual
    assert hpxvc._platform == 'HP-UX'

# Generated at 2022-06-23 02:15:25.540703
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector([])
    assert obj.platform == 'HP-UX'


# Generated at 2022-06-23 02:15:30.555065
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = AnsibleModule(argument_spec={})
    virt = HPUXVirtual(module)
    assert virt.platform == 'HP-UX'
    assert virt._platform == 'HP-UX'
    assert virt.get_virtual_facts() == {'virtualization_type': 'guest',
                                        'virtualization_role': 'HP nPar',
                                        'virtualization_tech_host': set(),
                                        'virtualization_tech_guest': {'HP nPar'}}

# Generated at 2022-06-23 02:15:36.129847
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    module.run_command = MagicMock(return_value=[0, "Running HPVM vPar", None])
    obj = HPUXVirtual(module)
    virtual_facts = obj.get_virtual_facts()
    assert 'HPVM vPar' in virtual_facts['virtualization_tech_guest']
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HPVM vPar'

# Generated at 2022-06-23 02:15:40.708635
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-23 02:15:49.230768
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class HPUXVirtual
    """
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import test_HPUXVirtual_get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual
    import os
    class MockHPUXVirtual(HPUXVirtual):
        def __init__(self, module):
            self.virtual = HPUXVirtual(module)
            self.module = module


# Generated at 2022-06-23 02:15:50.509537
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector(None)

    assert collector._platform == 'HP-UX'

# Generated at 2022-06-23 02:15:56.919074
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import os
    import tempfile
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    HPUX_FACTS = {
         'virtualization_tech_guest': set(),
         'virtualization_tech_host': set(),
    }

    args = dict(
        ANSIBLE_MODULE_ARGS={},
        ANSIBLE_FACTS={},
    )

    ansible_module = basic.AnsibleModule(**args)
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 02:15:59.235705
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vc = HPUXVirtualCollector()
    assert vc.platform == 'HP-UX'
    assert vc._fact_class is HPUXVirtual

# Generated at 2022-06-23 02:16:03.451580
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """ Test for constructor of class HPUXVirtualCollector """
    # Test for constructor
    try:
        hpu = HPUXVirtualCollector()
        assert hpu
    except Exception:
        print("Test failed, constructor of HPUXVirtualCollector class failed")


# Generated at 2022-06-23 02:16:06.999863
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert isinstance(hpux_virtual, HPUXVirtual)
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-23 02:16:09.906748
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector()
    assert collector.platform == 'HP-UX'
    assert isinstance(collector._fact_class, HPUXVirtual)


# Generated at 2022-06-23 02:16:13.329915
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = AnsibleModuleMock()
    virtual_facts = HPUXVirtualCollector(module).collect()
    assert isinstance(virtual_facts, dict)


# Generated at 2022-06-23 02:16:22.344753
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    virtual_facts = {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
        'virtualization_type': None,
        'virtualization_role': None,
        'virtualization_system': None
    }

    from ansible.module_utils.facts.virtual.hpx_pa_risc import HPUXVirtual

    hpux_virtual = HPUXVirtual()

    hpux_virtual.module.run_command = lambda x: (0, "", "")
    virtual_facts = hpux_virtual.get_virtual_facts()
    assert('HPVM' in virtual_facts['virtualization_tech_guest'])
    assert('HP nPar' in virtual_facts['virtualization_tech_guest'])

# Generated at 2022-06-23 02:16:24.702504
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()

    # Validating the platform
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-23 02:16:27.323602
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert x._platform == "HP-UX"
    assert x._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:16:31.455697
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    facts = HPUXVirtualCollector(None, None, None, None).collect()
    assert facts['virtualization_type'] == 'host'
    assert facts['virtualization_role'] == 'HPVM'

# Generated at 2022-06-23 02:16:41.689448
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_facts = HPUXVirtualCollector().collect()
    assert len(virtual_facts) == 1, "virtual_facts %s" % virtual_facts
    assert 'virtualization_type' in virtual_facts, "virtual_facts %s" % virtual_facts
    assert 'virtualization_role' in virtual_facts, "virtual_facts %s" % virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts, "virtual_facts %s" % virtual_facts
    assert 'virtualization_tech_host' in virtual_facts, "virtual_facts %s" % virtual_facts

    if virtual_facts['virtualization_type'] == 'guest':
        assert virtual_facts['virtualization_role'] in virtual_facts['virtualization_tech_guest'], "virtual_facts %s" % virtual_facts

# Generated at 2022-06-23 02:16:44.075498
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    test = HPUXVirtualCollector()
    assert test._fact_class is HPUXVirtual
    assert test._platform is 'HP-UX'

# Generated at 2022-06-23 02:16:54.156702
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    This function tests method get_virtual_facts of class HPUXVirtual.
    It mocks HPUXVirtual.get_virtualization_type and HPUXVirtual.get_virtualization_role
    """
    from mock import Mock, patch
    from ansible.module_utils.facts.virtual.hpu import HPUXVirtual

    hpuxvirtual = HPUXVirtual(Mock())
    hpuxvirtual.get_virtualization_type = Mock(return_value='guest')
    hpuxvirtual.get_virtualization_role = Mock(return_value='HPVM guest')

    virtual_facts = hpuxvirtual.get_virtual_facts()
    assert virtual_facts == {'virtualization_type': 'guest', 'virtualization_role': 'HPVM guest'}

# Generated at 2022-06-23 02:16:59.218542
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpUX_virtual = HPUXVirtual(None)
    assert hpUX_virtual.platform == 'HP-UX'
    assert hpUX_virtual.hypervisor is None
    assert hpUX_virtual.virtual is None
    assert hpUX_virtual.container is None


# Generated at 2022-06-23 02:17:01.445037
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    fact = HPUXVirtualCollector({}, None)
    assert fact.platform == 'HP-UX'


# Generated at 2022-06-23 02:17:12.498442
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible_collections.misc.not_a_real_collection.tests.unit.compat.mock import patch, Mock
    from ansible_collections.misc.not_a_real_collection.plugins.modules import hpux_facts

    with patch.object(hpux_facts.AnsibleModule, "run_command") as mock_run_command:
        mock_module = hpux_facts.AnsibleModule(
            argument_spec={
            }
        )
        mock_module.run_command = Mock(return_value=(0, "", ""))
        virtual = HPUXVirtual(module=mock_module)
        facts = virtual.get_virtual_facts()
        assert facts['virtualization_type'] == 'guest'
        assert facts['virtualization_role'] == 'HP vPar'

# Generated at 2022-06-23 02:17:14.317663
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpuxvirtual = HPUXVirtual('module')
    assert hpuxvirtual


# Generated at 2022-06-23 02:17:20.354941
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    virtual_facts_obj = HPUXVirtual()
    virtual_facts_obj.module.run_command = mock_run_command
    virtual_facts = virtual_facts_obj.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    assert 'HP vPar' in virtual_facts['virtualization_tech_guest']
    assert virtual_facts['virtualization_tech_host'] == set()



# Generated at 2022-06-23 02:17:32.546184
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    assert HPUXVirtual().get_virtual_facts() == {
        'virtualization_type': 'guest',
        'virtualization_role': 'HP vPar',
        'virtualization_tech_guest': {'HP vPar'},
        'virtualization_tech_host': set()
    }
    assert HPUXVirtual().get_virtual_facts() == {
        'virtualization_type': 'guest',
        'virtualization_role': 'HPVM vPar',
        'virtualization_tech_guest': {'HPVM vPar'},
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-23 02:17:38.046953
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vc = HPUXVirtualCollector()
    assert vc._fact_class == HPUXVirtual
    assert vc._platform == 'HP-UX'


# Generated at 2022-06-23 02:17:40.261841
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # It should always return a dictionary
    assert isinstance(HPUXVirtual(None).get_virtual_facts(), dict)



# Generated at 2022-06-23 02:17:44.072961
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert virtual_collector._platform == 'HP-UX'
    assert virtual_collector._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:17:53.544880
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    platform_facts = {}
    hpux = HPUXVirtual(platform_facts)

    # Test 1: vecheck installed - vPar guest
    platform_facts = {'system': 'HP-UX'}
    hpux = HPUXVirtual(platform_facts)

    class Mod(object):
        def run_command(self, cmd, check_rc=None):
            class Run(object):
                def __init__(self, rc, out, err):
                    self.rc = rc
                    self.stdout = out
                    self.stderr = err
                def splitlines(self):
                    return self.stdout.splitlines()

            class Param(object):
                def __init__(self, cmd):
                    if cmd == '/usr/sbin/vecheck':
                        self.rc = 0

# Generated at 2022-06-23 02:17:55.504812
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_class = HPUXVirtual('module')
    assert virtual_class._platform == 'HP-UX'

# Generated at 2022-06-23 02:18:01.665572
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual().get_virtual_facts()
    assert virtual_facts.get('virtualization_type') == 'guest'
    assert virtual_facts.get('virtualization_role') == 'HP nPar'
    assert virtual_facts.get('virtualization_tech_guest') == set(['HP nPar'])
    assert virtual_facts.get('virtualization_tech_host') == set()


# Generated at 2022-06-23 02:18:10.124961
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    mock_module = MockModule()
    test_HPUXVirtual = HPUXVirtual(mock_module)

    # Case: vecheck exists
    os.path.exists = Mock(return_value=True)
    mock_module.run_command = Mock(return_value=(0, 'Success', ''))
    virtual_facts = test_HPUXVirtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    assert virtual_facts['virtualization_tech_guest'] == set(['HP vPar'])

    # Case: hpvminfo exists and is vPar 
    os.path.exists = Mock(side_effect=[False, True])

# Generated at 2022-06-23 02:18:13.790414
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virt_obj = HPUXVirtualCollector()
    assert isinstance(virt_obj, HPUXVirtualCollector)
    assert isinstance(virt_obj._fact_class, HPUXVirtual)

# Generated at 2022-06-23 02:18:18.365767
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    fc = HPUXVirtualCollector()
    assert fc.facts['virtualization_type'] == 'host'
    assert fc.facts['virtualization_role'] == ''
    assert fc.facts['virtualization_tech_guest'] == set([])
    assert fc.facts['virtualization_tech_host'] == set(['HPVM'])

# Generated at 2022-06-23 02:18:29.159874
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import Virtual, HPUXVirtual
    facts_module_mock = Virtual()
    facts_module_mock.run_command.return_value = (0, '', '')
    HPUXVirtual.platform = 'HP-UX'

    hp_ux_virtual_mock = HPUXVirtual(facts_module_mock)
    virtual_facts = hp_ux_virtual_mock.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'host'
    assert virtual_facts['virtualization_role'] == 'HPVM'
    assert virtual_facts['virtualization_tech_guest'] == {'HPVM'}
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:18:37.396267
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    assert obj.platform == 'HP-UX'
    assert obj.fact_class == HPUXVirtual


# Generated at 2022-06-23 02:18:49.841157
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Import needed modules
    import ansible.module_utils.facts.virtual.hpux as hpux_virtual
    import ansible.module_utils.facts.virtual.base as virtual_base
    import ansible.module_utils.facts.virtual.collector as virtual_collector
    import ansible.module_utils.facts.fact_cache as fact_cache
    import ansible.module_utils.facts.system.distribution as distribution
    import ansible.module_utils.facts.system.platform as platform
    import ansible.module_utils.facts.system.kernel as kernel
    import ansible.module_utils.facts.system.service_mgr as service_mgr
    import ansible.module_utils.facts.system.system as system
    import ansible.module_utils.facts.system.hw_hwraid as hwraid

# Generated at 2022-06-23 02:19:00.093969
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class MockModule(object):
        def run_command(self, args, check_rc=True):
            if args == ('/usr/sbin/vecheck',):
                return (0, 'HP-UX vPars/vSMP', '')
            elif args == ('/opt/hpvm/bin/hpvminfo',):
                return (0, 'Running on HPVM guest: hpvm2', '')
            elif args == ('/usr/sbin/parstatus',):
                return (0, 'Running on HP nPar', '')
            else:
                return (1, '', '')

    o = HPUXVirtual(MockModule())
    facts = o.get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'

# Generated at 2022-06-23 02:19:09.499144
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import ansible.module_utils.facts.virtual.hpux

    class FakeArgs(object):
        def __init__(self, module=None):
            self.module = module

    class FakeModule(object):
        def __init__(self, name):
            self.name = name
            self.args = FakeArgs(self)
        def run_command(self, cmd):
            self.cmd = cmd
            self.rc = 0
            self.out = ''
            self.err = ''

# Generated at 2022-06-23 02:19:19.913342
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class MockedModule:
        def __init__(self, facts={}):
            self.params = {}
            self.facts = facts

        def run_command(self, cmd):
            return 1, None, None

    module = MockedModule()
    result = HPUXVirtual(module).get_virtual_facts()
    assert result == {'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}

    module = MockedModule({'virtualization_tech_host': set(), 'virtualization_tech_guest': set()})
    module.run_command = lambda cmd: (0, 'Running in HPVM guest', None)
    result = HPUXVirtual(module).get_virtual_facts()

# Generated at 2022-06-23 02:19:25.518094
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    huxv = HPUXVirtual(None)
    assert huxv.platform == 'HP-UX'
    assert huxv._virtual_facts == dict()
    assert huxv.virtual == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_type': '', 'virtualization_role': ''}



# Generated at 2022-06-23 02:19:27.483851
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert virtual_collector._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:19:30.155286
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    mod = HPUXVirtualCollector(module=None)
    assert mod.platform == 'HP-UX'
    assert mod._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:19:31.988507
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(None)
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-23 02:19:39.708830
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    mocked_module = MockAnsibleModule({})
    mocked_module.run_command.return_value = 0, \
                                             'Running HPVM host\n', \
                                             ''
    mocked_module.get_bin_path.return_value = 'path_to_hpvm'
    facts = HPUXVirtual(mocked_module).get_virtual_facts()
    assert facts['virtualization_type'] == 'host'
    assert facts['virtualization_role'] == 'HPVM'

# Generated at 2022-06-23 02:19:44.326153
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    '''
    make instance of HPUXVirtual and call get_virtual_facts
    '''
    hv = HPUXVirtual()
    assert hv.get_virtual_facts() == {'virtualization_type': 'guest',
                                      'virtualization_role': 'HP nPar',
                                      'virtualization_tech_guest': set(['HPVM IVM', 'HP vPar', 'HP nPar']),
                                      'virtualization_tech_host': set()}

# Generated at 2022-06-23 02:19:46.610827
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpux_virtual = HPUXVirtualCollector.factory()
    assert isinstance(hpux_virtual, HPUXVirtual)

# Generated at 2022-06-23 02:19:50.928569
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual({})
    assert h.platform == 'HP-UX'
    h = HPUXVirtual({'ANSIBLE_SYSTEM_VERSION': 'HP-UX B.11.31 U ia64 0707192950'})
    assert h.platform == 'HP-UX'

# Generated at 2022-06-23 02:19:55.423308
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpxvirtual = HPUXVirtual(None)
    assert hpxvirtual is not None
    assert hpxvirtual.get_virtual_facts() == {}
    assert hpxvirtual.platform == 'HP-UX'



# Generated at 2022-06-23 02:20:01.996370
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_h = HPUXVirtual(dict())
    assert virtual_h.virtualization_role == "HP-UX"
    assert virtual_h.virtualization_type == ""
    assert virtual_h.virtualization_subtype == ""
    assert virtual_h.virtualization_role == ""
    assert virtual_h.virtualization_system == ""
    assert virtual_h.virtualization_uuid == ""
    assert virtual_h.virtualization_product_name == ""
    assert virtual_h.virtualization_product_version == ""
    assert virtual_h.virtualization_product_vendor == ""

# Generated at 2022-06-23 02:20:10.647978
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual

    m = HPUXVirtual({})

    # Inject mocks
    import os
    def mock_exists(path):
        return path in ['/usr/sbin/vecheck', '/opt/hpvm/bin/hpvminfo', '/usr/sbin/parstatus']

    os.path.exists = mock_exists

    import errno
    class MockPopen(object):
        def __init__(self, cmd, *args, **kwargs):
            self.args = cmd
            self.returncode = 0
            self.stdout = ''
            self.stderr = ''


# Generated at 2022-06-23 02:20:12.558305
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    o = HPUXVirtual(dict())
    assert o.platform == 'HP-UX'


# Generated at 2022-06-23 02:20:23.776664
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Check if HPUXVirtual.get_virtual_facts() returns correct results.
    """
    hpux_virtual = HPUXVirtual({'module_setup': True})
    if os.path.exists('/usr/sbin/vecheck'):
        rc, out, err = hpux_virtual.module.run_command("/usr/sbin/vecheck")
        if rc == 0:
            hpux_virtual.get_virtual_facts()
            assert hpux_virtual.facts['virtualization_type'] == 'guest'
            assert hpux_virtual.facts['virtualization_role'] == 'HP vPar'
            assert hpux_virtual.facts['virtualization_tech_host'] == set()
            assert hpux_virtual.facts['virtualization_tech_guest'] == set(['HP vPar'])

# Generated at 2022-06-23 02:20:35.531465
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = Mock()
    module.run_command.side_effect = [(0, '', ''), (0, '', ''), (0, '', ''), (0, '', ''), (0, '', '')]
    hpux_virtual = HPUXVirtual(module)
    hpux_virtual.get_virtual_facts()
    assert hpux_virtual.virtual_facts['virtualization_tech_guest'] == set()
    assert hpux_virtual.virtual_facts['virtualization_tech_host'] == set()
    hpux_virtual.virtual_facts = {}

    module.run_command.side_effect = [(0, '', ''), (0, '', ''), (0, '', ''), (0, '', ''), (0, '', ''), (0, 'Running HP-UX virtual partition', '')]
    hp

# Generated at 2022-06-23 02:20:45.049169
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    test_module = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True)
    test_module.params = {}
    test_module.run_command = lambda args, check_rc=True: (0, '', '')
    test_module.exit_json = lambda **kwargs: test_module.fail_json(**kwargs)
    test_module.fail_json = lambda **kwargs: test_module.exit_json(**kwargs)

    virtual_col = HPUXVirtualCollector(test_module)
    virtual_facts = virtual_col.collect()
    facts = {}
    for k, v in virtual_facts.items():
        facts[k] = v

# Generated at 2022-06-23 02:20:49.556315
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    known_args = set(['module'])
    hv_test_object = HPUXVirtual({})
    assert len(known_args & set(hv_test_object.__dict__)) == len(list(known_args))


# Generated at 2022-06-23 02:20:52.002250
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_hpux = HPUXVirtual(dict(ANSIBLE_MODULE_ARGS={}))
    assert virtual_hpux.platform == 'HP-UX'


# Generated at 2022-06-23 02:20:57.009879
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    v = HPUXVirtual()
    res = v.get_virtual_facts()
    assert res == {
            'virtualization_type': 'guest',
            'virtualization_role': 'HPVM',
            'virtualization_technologies': ['HPVM'],
            'virtualization_tech_guest': ['HPVM vPar', 'HPVM IVM'],
            'virtualization_tech_host': []
            }

# Generated at 2022-06-23 02:21:04.987969
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hp_ux_virtual = HPUXVirtualCollector()

    assert hp_ux_virtual.get_facts()['virtualization_type'] == 'host'
    assert hp_ux_virtual.get_facts()['virtualization_role'] == 'HPVM'
    assert hp_ux_virtual.get_facts()['virtualization_tech_host'] == set(
        ['HPVM'])
    assert hp_ux_virtual.get_facts()['virtualization_tech_guest'] == set()

# Generated at 2022-06-23 02:21:09.759746
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    collector = HPUXVirtualCollector()
    assert collector.platform == 'HP-UX'
    assert collector._fact_class.platform == 'HP-UX'

# Generated at 2022-06-23 02:21:13.281534
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
  hpuxVirtualCollector = HPUXVirtualCollector()
  assert hpuxVirtualCollector._fact_class == HPUXVirtual
  assert hpuxVirtualCollector._platform == 'HP-UX'

# Generated at 2022-06-23 02:21:17.498237
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv_collector = HPUXVirtualCollector(None)
    assert isinstance(hv_collector._fact_class(hv_collector._module), HPUXVirtual)
    assert hv_collector._platform == 'HP-UX'

# Generated at 2022-06-23 02:21:29.380826
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    cwd = os.path.dirname(os.path.realpath(__file__))

    # testing for par status
    vpar = HPUXVirtual(dict(module=dict(run_command=lambda x: (0, '', ''))))
    assert vpar.get_virtual_facts() == dict(
        virtualization_type='guest',
        virtualization_role='HP nPar',
        virtualization_tech_guest={'HP nPar'},
        virtualization_tech_host=set(),
    )

    # testing for vecheck
    vpar = HPUXVirtual(dict(module=dict(run_command=lambda x: (0, '', '')), ANSIBLE_REMOTE_TEMP=cwd))

# Generated at 2022-06-23 02:21:39.575083
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class HPUXModule:
        def run_command(self, command):
            return 0, """
            HPVM guest:
                vm0, Running.
                vmusr0, Unconfigured.
                vmusr1, Unconfigured.
                vmusr2, Unconfigured.
            """, ''
    module = HPUXModule()
    result = HPUXVirtual(module).get_virtual_facts()
    assert 'virtualization_role' in result
    assert result['virtualization_role'] == 'HPVM IVM'
    assert 'virtualization_type' in result
    assert result['virtualization_type'] == 'guest'
    assert 'virtualization_tech_guest' in result
    assert 'HPVM' in result['virtualization_tech_guest']

# Generated at 2022-06-23 02:21:48.069245
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    hpux_virtual = HPUXVirtual(module=module)

    hpux_virtual.get_virtual_facts()
    assert 'virtualization_type' in hpux_virtual.virtual_facts
    assert 'virtualization_role' in hpux_virtual.virtual_facts
    assert 'virtualization_tech_guest' in hpux_virtual.virtual_facts
    assert 'virtualization_tech_host' in hpux_virtual.virtual_facts

# Generated at 2022-06-23 02:21:53.839104
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()

    expected_output = {'virtualization_type': 'guest',
                       'virtualization_role': 'HP nPar',
                       'virtualization_tech_guest': {'HP nPar'},
                       'virtualization_tech_host': set()}

    assert virtual_facts.get_virtual_facts() == expected_output

# Generated at 2022-06-23 02:21:59.920160
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    m = HPUXVirtual({})
    assert 'virtual_facts' in m.get_virtual_facts()
    assert 'virtualization_type' in m.get_virtual_facts()['virtual_facts']
    assert 'virtualization_role' in m.get_virtual_facts()['virtual_facts']
    assert 'virtualization_tech_host' in m.get_virtual_facts()['virtual_facts']
    assert 'virtualization_tech_guest' in m.get_virtual_facts()['virtual_facts']

# Generated at 2022-06-23 02:22:03.957275
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():

    obj =  HPUXVirtualCollector('module')
    assert obj.platform == 'HP-UX'
    assert obj._fact_class == HPUXVirtual
    obj.collect()

# Generated at 2022-06-23 02:22:08.760966
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtual(dict())
    assert collector.__class__.__name__ == 'HPUXVirtual'
    assert collector.virtualization_tech_guest == set()
    assert collector.virtualization_tech_host == set()
    assert not collector.get_virtual_facts()['virtualization_role']
    assert not collector.get_virtual_facts()['virtualization_type']

# Generated at 2022-06-23 02:22:12.831450
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector._platform == 'HP-UX'
    assert isinstance(HPUXVirtualCollector._fact_class, type)
    assert issubclass(HPUXVirtualCollector._fact_class, Virtual)

# Generated at 2022-06-23 02:22:22.796949
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """ Test get_virtual_facts for HPUXVirtual class """
    from ansible_collections.ansible.community.plugins.module_utils.facts import FactsModule

    test_obj = FactsModule()
    hpx = HPUXVirtual(test_obj)

    data_path = os.path.join(os.path.dirname(__file__), 'fixtures',
                             'virtual_hpx.unit')

    hpx.module.run_command = lambda args: (0, open(data_path).read(), '')
    hpx.module.params = {'gather_subset': 'all'}
    result = hpx.get_virtual_facts()
    assert result['virtualization_role'] == 'HP nPar'
    assert result['virtualization_type'] == 'guest'

# Generated at 2022-06-23 02:22:35.255558
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """Check if correct dict is returned."""
    module = AnsibleModule
    module.run_command = Mock(return_value=(0, '', ''))
    os.path.exists = Mock(side_effect=lambda x: x in ['/usr/sbin/vecheck', '/opt/hpvm/bin/hpvminfo', '/usr/sbin/parstatus'])
    hv = HPUXVirtual(module)
    # Test if method get_virtual_facts() returns a dict
    assert isinstance(hv.get_virtual_facts(), dict)
    # Test if method get_virtual_facts() returns dict with correct 'virtualization_type' and 'virtualization_role' keys

# Generated at 2022-06-23 02:22:44.643563
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    import os

    dummy_module = type('', (), {
        'run_command': lambda *a, **kw: (0, '', '')
    })()
    dummy_test = HPUXVirtual(dummy_module)

    # Both guest and host virtualization are detected
    dummy_test.module.run_command = lambda *a, **kw: (0, 'Running HPVM guest', '')
    dummy_test.module.get_bin_path = lambda *a, **kw: '/opt/hpvm/bin'
    facts = dummy_test.get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HPVM IVM'

# Generated at 2022-06-23 02:22:46.015004
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()


# Generated at 2022-06-23 02:22:49.740478
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    facts = HPUXVirtualCollector()
    assert facts.get_virtual_facts()['virtualization_tech_guest'] == set()
    assert facts.get_virtual_facts()['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:22:54.144674
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector._platform == 'HP-UX'
    assert HPUXVirtualCollector._fact_class == HPUXVirtual
    vc = HPUXVirtualCollector()
    assert vc._platform == 'HP-UX'
    assert vc._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:22:59.614792
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpc = HPUXVirtualCollector()
    assert hpc.__class__.__name__ == 'HPUXVirtualCollector'
    assert hpc.platform == 'HP-UX'
    assert hpc._fact_class.__name__ == 'HPUXVirtual'
    assert hpc._fact_class.platform == 'HP-UX'

# Generated at 2022-06-23 02:23:00.617235
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-23 02:23:13.155457
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import tempfile
    from ansible.module_utils.facts.collector import BaseFactCollector

    class MockModule(object):
        def __init__(self, params={}):
            self.params = params

        def run_command(self, cmd):
            if cmd == 'uname -n':
                return 0, 'mock.localhost', ''
            elif cmd == 'uname -r':
                return 0, 'B.11.31', ''
            elif cmd == '/usr/sbin/vecheck':
                return 0, 'Running inside vPar', ''
            elif cmd == '/opt/hpvm/bin/hpvminfo':
                return 0, 'Running inside HPVM vPar', ''

# Generated at 2022-06-23 02:23:15.780825
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector()
    assert isinstance(collector._fact_class, HPUXVirtual)
    assert collector._platform == 'HP-UX'

# Generated at 2022-06-23 02:23:26.310088
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = type('AnsibleModule', (object,), {})
    module.run_command = type('RunCommand', (object,), {})
    module.run_command.return_value = (0, '/home/test', '')
    module.params = {}
    module.check_mode = False
    HPUXVirtual.module = module

    facts = HPUXVirtual().get_virtual_facts()
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_tech_guest'] == set(['HP vPar'])
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP vPar'


# Generated at 2022-06-23 02:23:30.805510
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    v = HPUXVirtualCollector()
    assert v
    assert v._platform == 'HP-UX'
    assert issubclass(v._fact_class, HPUXVirtual)


# Generated at 2022-06-23 02:23:32.275834
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual().platform == 'HP-UX'


# Generated at 2022-06-23 02:23:34.702601
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector()
    assert collector.platform == 'HP-UX'

# Generated at 2022-06-23 02:23:36.707075
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    c = HPUXVirtualCollector
    assert c._platform == 'HP-UX'


# Generated at 2022-06-23 02:23:39.437831
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual = HPUXVirtualCollector()
    assert virtual._fact_class == HPUXVirtual
    assert virtual._platform == 'HP-UX'