

# Generated at 2022-06-23 02:13:58.710987
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import ModuleStub
    from ansible.module_utils.facts.virtual.hpu_x import HPUXVirtual
    from ansible.module_utils.facts.fact_cache import FactCache
    from ansible.module_utils.facts.system.distribution import Distribution

    module = ModuleStub()
    fact_cache = FactCache()
    fact_cache.collect(module)

    hpu_x = HPUXVirtual(module, fact_cache)
    facts = hpu_x.get_virtual_facts()

    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts
    assert isinstance(facts['virtualization_tech_guest'], set)
    assert isinstance(facts['virtualization_tech_host'], set)




# Generated at 2022-06-23 02:14:00.871775
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    if 'HPUX' in VirtualCollector.get_platforms():
        hpux = HPUXVirtual()

# Generated at 2022-06-23 02:14:01.773587
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-23 02:14:13.273361
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    module = basic.AnsibleModule(argument_spec={})
    module.run_command = lambda x: (0, '', '')

    from ansible.module_utils.facts import collector
    facts_collector = collector.get_collector(module)
    results = facts_collector.collect(module)
    virtual_facts = results['ansible_facts']['virtualization_facts']

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'

# Generated at 2022-06-23 02:14:17.494378
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    h = HPUXVirtualCollector()
    assert isinstance(h, VirtualCollector)
    assert h.platform == 'HP-UX'
    assert hasattr(h, '_fact_class')
    assert h._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:14:18.590011
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})

# Generated at 2022-06-23 02:14:19.764799
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-23 02:14:22.590515
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_hpux = HPUXVirtual(dict(module=dict()))
    assert virtual_hpux.platform == 'HP-UX'
    assert virtual_hpux.module is not None

# Generated at 2022-06-23 02:14:24.376665
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual({'module_setup': True})
    assert(virtual_obj.platform == 'HP-UX')

# Generated at 2022-06-23 02:14:35.953663
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    # Test case: No virtualization tech
    HPUXVirtualCollector.get_virtual_facts.return_value = {
        'virtualization_tech_guest': {},
        'virtualization_tech_host': {},
        'virtualization_type': '',
        'virtualization_role': ''
    }
    # Verify returned value of method get_virtual_facts
    result = HPUXVirtualCollector.get_virtual_facts()

# Generated at 2022-06-23 02:14:38.645996
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-23 02:14:40.200577
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    c = HPUXVirtual()
    assert c.platform == "HP-UX"

# Generated at 2022-06-23 02:14:46.984554
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual

    # Test if the class member _platform is 'HP-UX'
    x = HPUXVirtualCollector()
    assert x._platform == 'HP-UX'

    # Test if the class member _fact_class.platform is 'HP-UX'
    x = HPUXVirtualCollector()
    assert x._fact_class.platform == 'HP-UX'

    # Test if the class member _fact_class is HPUXVirtual
    x = HPUXVirtualCollector()
    assert x._fact_class == HPUXVirtual

    # Test if the class inherits from VirtualCollector

# Generated at 2022-06-23 02:14:49.876042
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({},{},{})
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-23 02:14:58.243868
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(dict(ANSIBLE_MODULE_ARGS={}))
    assert hv.platform == 'HP-UX'
    assert not hasattr(hv, 'data')
    hv.get_virtual_facts()
    assert 'virtualization_type' in hv.data
    assert 'virtualization_role' in hv.data
    assert 'virtualization_tech_host' in hv.data
    assert 'virtualization_tech_guest' in hv.data
    assert len(hv.data['virtualization_tech_guest']) == 1

# Generated at 2022-06-23 02:15:00.759939
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    Returns true if the constructor can create an object of HPUXVirtual
    """
    module = None
    v = HPUXVirtual(module)
    assert v is not None


# Generated at 2022-06-23 02:15:02.904003
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt = HPUXVirtual()
    assert virt.platform == 'HP-UX'

# Generated at 2022-06-23 02:15:05.154052
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    facts = {}    # A module_utils/facts.py structure
    HPUXVirtualCollector(facts, None) # Calling constructor of HPUXVirtualCollector
    assert VirtualCollector._platform == 'HP-UX'
    assert VirtualCollector._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:15:09.032985
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict(ANSIBLE_MODULE_ARGS={'gather_subset': 'all'},
                               ANSIBLE_SYSTEM_HOSTNAME='localhost'))
    assert virtual.platform == 'HP-UX'


# Generated at 2022-06-23 02:15:12.133166
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    mc = HPUXVirtualCollector()
    assert(isinstance(mc, VirtualCollector))
    assert(isinstance(mc, object))
    return


# Generated at 2022-06-23 02:15:21.472471
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = MockModule()
    virtual = HPUXVirtual(module)
    virtual.get_virtual_facts()
    assert module.params == {'warn': True, 'gather_subset': 'all', 'gather_timeout': 10}
    assert module.virtual_facts == {
        'virtualization_type': 'guest',
        'virtualization_role': 'HP nPar',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': {'HP nPar'}
    }
    module.run_command_calls = [('/usr/sbin/parstatus', '', '', 0)]
    virtual.get_virtual_facts()
    assert module.params == {'warn': True, 'gather_subset': 'all', 'gather_timeout': 10}
    assert module

# Generated at 2022-06-23 02:15:23.274674
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    assert obj.platform == 'HP-UX'
    assert obj._fact_class == HPUXVirtual
    assert obj.fact_class == HPUXVirtual


# Generated at 2022-06-23 02:15:26.638607
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import ansible_virtual_facts
    data_dict = {}
    v = HPUXVirtual(data_dict)
    result = v.get_virtual_facts()
    assert not result

# Generated at 2022-06-23 02:15:28.974569
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(dict(module=dict()))
    assert hpux_virtual.platform == 'HP-UX'



# Generated at 2022-06-23 02:15:31.443840
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-23 02:15:41.595788
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpu import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpu import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    import os
    import re

    HPUXVirtualCollector._platform = 'HP-UX'
    HPUXVirtual._platform = 'HP-UX'

    class MockModule(object):
        def __init__(self):
            self.params = None

        def run_command(self, cmd):
            return (0, '', '')

    class MockOs(object):
        def __init__(self):
            self.path = {}
            self.path['exists_true'] = True

# Generated at 2022-06-23 02:15:43.289250
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts._platform == 'HP-UX'


# Generated at 2022-06-23 02:15:45.641674
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert x
    assert x._platform == 'HP-UX'

# Generated at 2022-06-23 02:15:47.051018
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    v = HPUXVirtualCollector()
    assert v


# Generated at 2022-06-23 02:15:49.180010
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hp_virtual = HPUXVirtual(dict())
    assert hp_virtual
    assert hp_virtual.platform == 'HP-UX'


# Generated at 2022-06-23 02:15:50.730088
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual()
    assert virtual_obj.platform == 'HP-UX'


# Generated at 2022-06-23 02:15:51.575747
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual.platform == 'HP-UX'

# Generated at 2022-06-23 02:16:02.019379
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Verify the correct return of get_virtual_facts

    1. This method must return a dict object
    2. This method must have 3 key/value pairs
    3.  virtualization_type key must have guest value
    4. virtualization_role key must have HPVM vPar value
    5. 'virtualization_tech_guest' key must return two values
        'HPVM vPar' and 'HP vPar' 
    6. 'virtualization_tech_host' key must return empty set
    """
    hpux_virtual_class = HPUXVirtual()

# Generated at 2022-06-23 02:16:11.059066
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class ModuleMock():
        def __init__(self):
            self.params = {}

    class HPUXVirtualMock(HPUXVirtual):
        def __init__(self, module):
            self.module = module

    class FileMock():
        def __init__(self, path):
            self.filename = path
            self.exists = None

        def exists(self):
            if self.filename == '/usr/sbin/vecheck':
                self.exists = True

        def run_command(self, command):
            if command == '/usr/sbin/vecheck':
                return 0, 'test for vecheck', ''
            if command == '/opt/hpvm/bin/hpvminfo':
                return 0, 'test for hpvminfo', ''

# Generated at 2022-06-23 02:16:16.879360
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    my_virtual = HPUXVirtual()
    virtual_facts = my_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] is not None
    assert virtual_facts['virtualization_role'] is not None

# Generated at 2022-06-23 02:16:18.780307
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(None)
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-23 02:16:23.227529
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vc = HPUXVirtualCollector()
    assert hasattr(vc, '_platform')
    assert hasattr(vc, '_fact_class')
    assert vc._platform == 'HP-UX'
    assert vc._fact_class.platform == 'HP-UX'


# Generated at 2022-06-23 02:16:25.129072
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    instance = HPUXVirtualCollector()
    assert instance._platform == 'HP-UX'


# Generated at 2022-06-23 02:16:36.105389
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpu import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpu import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual import VirtualCollector
    from ansible.module_utils.facts.virtual import Virtual

    vc1 = VirtualCollector()
    vc2 = HPUXVirtualCollector()
    v = HPUXVirtual(vc1)
    vu = HPUXVirtual(vc2)
    assert isinstance(vc1, VirtualCollector)
    assert isinstance(vc2, VirtualCollector)
    assert isinstance(v, Virtual)
    assert isinstance(vu, Virtual)

    assert v.get_virtual_facts() == {}
    assert vu.get_virtual_facts() == {}


#

# Generated at 2022-06-23 02:16:46.617092
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    # mock module to run commands
    module = Mock()
    out_vecheck = "vecheck: vecheck: This system is not a virtual environment"
    out_hpvminfo = "Running HPVM guest"
    out_parstatus = "parstatus: parstatus: This system is not a virtual environment"
    module.run_command.side_effect = [
        (0, out_vecheck, ''),
        (0, out_hpvminfo, ''),
        (0, out_parstatus, ''),
    ]

    # test get_virtual_facts
    test_obj = HPUXVirtual(module)
    virtual_facts = test_obj.get_virtual_facts()

# Generated at 2022-06-23 02:16:48.546399
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vc = HPUXVirtualCollector()
    assert vc.platform == 'HP-UX'
    assert vc.fact_class == HPUXVirtual

# Generated at 2022-06-23 02:16:50.687818
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_facts = HPUXVirtualCollector()
    assert virtual_facts._platform == 'HP-UX'

# Generated at 2022-06-23 02:16:55.120800
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    This method unit test the get_virtual_facts method of the
    HPUXVirtual class
    """
    class ModuleMock(object):
        def __init__(self):
            self.run_command_result = list()
            self.run_command_result.append((0, '', ''))
            self.run_command_result.append((0, '', ''))
            self.run_command_result.append((0, 'Running a HPVM vPar', ''))
            self.run_command_result.append((0,
                                            'Running a HPVM guest',
                                            ''))
            self.run_command_result.append((0,
                                            'Running a HPVM host',
                                            ''))

        def run_command(self, cmd, check_rc=True):
            run

# Generated at 2022-06-23 02:16:57.671622
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual({}, {}).platform == 'HP-UX'

# Generated at 2022-06-23 02:17:01.337723
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vc = HPUXVirtualCollector()
    assert vc
    assert vc._platform == 'HP-UX'
    assert vc._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:17:12.405494
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.virtual import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector

    # Use VirtualCollector as base class with empty methods
    class FakeVirtualCollector(VirtualCollector):
        _platform = 'HP-UX'
        def collect(self, module=None, collected_facts=None):
            return collected_facts

    hpux_virtual = HPUXVirtual(module=None)
    hpux_virtual_collector = HPUXVirtualCollector(module=None)
    hpux_virtual_collector.collect_virtual_facts = FakeVirtualCollector(module=None).collect_virtual_facts


# Generated at 2022-06-23 02:17:15.560696
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector()
    assert collector.platform == 'HP-UX'
    assert collector.fact_class == HPUXVirtual
    assert collector.fact_class().platform == 'HP-UX'



# Generated at 2022-06-23 02:17:21.462237
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """
    Test the constructor of HPUXVirtualCollector class.
    """
    HPUX_virtual_collector = HPUXVirtualCollector()
    assert HPUX_virtual_collector._fact_class == HPUXVirtual
    assert HPUX_virtual_collector._platform == 'HP-UX'

# Generated at 2022-06-23 02:17:25.436805
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpux_virtual_collector = HPUXVirtualCollector()
    assert(hpux_virtual_collector._platform == 'HP-UX')
    assert(hpux_virtual_collector._fact_class == HPUXVirtual)

# Generated at 2022-06-23 02:17:36.600597
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import HPUXVirtual
    from ansible.module_utils.facts.virtual import Virtual
    from ansible.module_utils.facts.virtual import VirtualCollector

    # Mock base Virtual class
    Virtual.get_file_content = get_file_content_mock
    Virtual.get_mount_points = get_mount_points_mock
    Virtual.get_interfaces_ip = get_interfaces_ip_mock
    Virtual.get_commands_output = get_commands_output_mock

    # Mock VirtualCollector class
    VirtualCollector._get_platform_subclass = get_platform_subclass_mock

    # Test get_virtual_facts method
    hpux_virtual = HPUXVirtual({})


# Generated at 2022-06-23 02:17:38.130924
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.virtualization_type == 'guest'
    assert virtual_facts.virtualization_role == 'HP vPar'
    assert virtual_facts.virtualization_tech_host == set()

# Generated at 2022-06-23 02:17:39.975813
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-23 02:17:43.917814
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux = HPUXVirtual()
    assert hpux.virtualization_type == 'host'
    assert hpux.platform == 'HP-UX'


# Generated at 2022-06-23 02:17:51.033041
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test1 = HPUXVirtual({})
    test1_get_virtual_facts_output = test1.get_virtual_facts()
    test1_get_virtual_facts_output_expected = {
        'virtualization_type': 'guest',
        'virtualization_role': 'HP nPar',
        'virtualization_tech_guest': {'HP vPar', 'HP nPar'},
        'virtualization_tech_host': set()
    }
    assert test1_get_virtual_facts_output == test1_get_virtual_facts_output_expected

# Generated at 2022-06-23 02:18:00.958195
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    # Create a dummy module
    class TestModule(object):
        pass
    tested_module = TestModule()
    tested_module.run_command = lambda cmd, *args, **kwargs: (0, 'success', '')

    facts = HPUXVirtual(tested_module).get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP vPar'
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_tech_guest'] == set(['HP vPar'])



# Generated at 2022-06-23 02:18:09.546820
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import HPUXVirtual

    # Set-up mocked module
    module = MockHPModule()

    # Test method with vecheck
    module.run_command.return_value = (0, 'some output', '')
    os.path.exists.side_effect = lambda x: True

    virtual_facts = HPUXVirtual(module).get_virtual_facts()
    assert module.run_command.call_count == 1
    assert os.path.exists.call_count == 1
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    assert virtual_facts['virtualization_tech_guest'] == set(['HP vPar'])

# Generated at 2022-06-23 02:18:18.230747
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    # Mock class and objects
    class MockModule(object):
        def __init__(self):
            self.run_command = MockModule.run_command

        def run_command(self, cmd):
            out = '''Running HPVM vPar
                    System is NOT running a supported version of HP-UX.
                    '''
            return 0, out, ''

    class MockFile(object):
        def __init__(self):
            self.exists = MockFile.exists

        def exists(self, file_name):
            if file_name.endswith('/usr/sbin/vecheck'):
                return True
            if file_name.endswith('/opt/hpvm/bin/hpvminfo'):
                return True

# Generated at 2022-06-23 02:18:20.959417
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    c = HPUXVirtualCollector()
    assert c.platform == 'HP-UX'
    assert c._fact_class == HPUXVirtual


# Generated at 2022-06-23 02:18:29.992024
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Example data from out_vecheck_0
    # fmt: off
    out_vecheck_0 = """
    Model Name: hp Virtual Machine
    Serial Number: M4ZW3X00X9
    CPU: 1 @ 1624 MHz
    Memory Size: 2048 MB
    OS Version: B.11.31
    """
    # fmt: on
    # Example data from out_vecheck_1
    # fmt: off
    out_vecheck_1 = """
    Model Name: hp sx110 server
    Serial Number: M4ZW3X00X9
    CPU: 1 @ 1624 MHz
    Memory Size: 2048 MB
    OS Version: B.11.31
    """
    # fmt: on
    # Example data from out_hpvminfo_1
    # fmt: off
    out_hpvminfo

# Generated at 2022-06-23 02:18:32.082397
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert isinstance(HPUXVirtual(), Virtual)

# Generated at 2022-06-23 02:18:38.861687
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector._platform == 'HP-UX'
    assert HPUXVirtualCollector._fact_class == HPUXVirtual
    assert Virtual is not HPUXVirtual


# Generated at 2022-06-23 02:18:40.111509
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-23 02:18:42.246763
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux = HPUXVirtual()
    assert hpux.platform == 'HP-UX'



# Generated at 2022-06-23 02:18:53.936013
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
        from ansible.module_utils.facts import FactCollector
        from ansible.module_utils.facts.virtual import HPUXVirtual

        # the following directories are created in the memory
        # of pytest, so we need to find a way to mock them
        directories = ['/usr/sbin/vecheck',
                       '/opt/hpvm/bin/hpvminfo',
                       '/usr/sbin/parstatus']

        class FakeModule:
            class FakeRunCommand:
                def __init__(self, rc, out, err):
                    self.rc = rc
                    self.out = out
                    self.err = err

                def __call__(self, *args, **kwargs):
                    return (self.rc, self.out, self.err)


# Generated at 2022-06-23 02:18:55.891951
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpu = HPUXVirtualCollector()
    assert hpu._platform == 'HP-UX'

# Generated at 2022-06-23 02:18:58.247400
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(dict(module=None))
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-23 02:19:07.641258
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # use module_utils.basic.AnsibleModule object for passing mock commands
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    hpux_virtual_facts = HPUXVirtual(module)

    if os.path.exists('/usr/sbin/vecheck'):
        pass
    elif os.path.exists('/opt/hpvm/bin/hpvminfo'):
        pass
    elif os.path.exists('/usr/sbin/parstatus'):
        pass
    else:
        assert hpux_virtual_facts.get_virtual_facts() == {}

# Generated at 2022-06-23 02:19:11.268472
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual(dict(module=None))
    assert(v.platform == 'HP-UX')

# Generated at 2022-06-23 02:19:13.063162
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector().platform == 'HP-UX'


# Generated at 2022-06-23 02:19:13.857904
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual()

# Generated at 2022-06-23 02:19:15.655744
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-23 02:19:17.099580
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = FakeAnsibleModule()
    VirtualCollector(module)


# Generated at 2022-06-23 02:19:18.427154
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict(module=dict()))
    assert virtual

# Generated at 2022-06-23 02:19:22.844843
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # get_virtual_facts() returns a dictionary
    # and check that the dictionary is not empty
    virtual = HPUXVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert isinstance(virtual_facts, dict)
    assert virtual_facts

# Generated at 2022-06-23 02:19:26.588049
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_HPUXVirtual = HPUXVirtual()
    test_HPUXVirtual.module.run_command = test_HPUXVirtual_run_command
    test_HPUXVirtual.get_virtual_facts()


# Generated at 2022-06-23 02:19:30.161062
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict())
    assert virtual.platform == 'HP-UX'
    assert virtual.get_virtual_facts() == dict(
        virtualization_tech_guest=set(),
        virtualization_tech_host=set(),
    )

# Generated at 2022-06-23 02:19:31.672773
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt = HPUXVirtual({})
    assert virt.platform == 'HP-UX'

# Generated at 2022-06-23 02:19:41.262615
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    class ModuleStub():
        def run_command(self, command):
            if command == '/usr/sbin/vecheck':
                return 0, '', ''
            elif command == '/usr/sbin/parstatus':
                return 0, '', ''
            elif command == '/opt/hpvm/bin/hpvminfo':
                return 0, '  Running as an HPVM IVM', ''
            else:
                return 1, '', ''

    result = {}
    result['virtualization_type'] = 'guest'
    result['virtualization_role'] = 'HPVM IVM'
    result['virtualization_tech_guest'] = set(['HPVM IVM'])
    result['virtualization_tech_host'] = set()

    module = ModuleStub()

# Generated at 2022-06-23 02:19:49.609041
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    m = VirtualCollector._create_module_mock()

    m.run_command.return_value = (
        0,
        '/opt/hpvm/bin/hpvminfo:Running HPVM guest for HP-UX 11.31',
        ''
    )

    h = HPUXVirtual(m)
    h.get_virtual_facts()

    assert m.run_command.call_count == 1
    args, kwargs = m.run_command.call_args

    assert args == ("/opt/hpvm/bin/hpvminfo",)

# Generated at 2022-06-23 02:19:52.676957
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    virtual_obj = HPUXVirtual(module)
    assert {} == virtual_obj.get_virtual_facts()


# Fake AnsibleModule class

# Generated at 2022-06-23 02:19:55.164188
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector()
    assert collector._fact_class == HPUXVirtual
    assert collector._platform == 'HP-UX'

# Generated at 2022-06-23 02:20:06.080196
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """Unit test for method 'get_virtual_facts' of class HPUXVirtual"""
    module = FakeAnsibleModule()
    module.run_command = fake_run_command
    hpux_virtual = HPUXVirtual(module=module)
    guest_tech = set()

    # test case for parstatus
    hpux_virtual.module.run_command = fake_parstatus_cmd
    virtual_facts = hpux_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP nPar'
    guest_tech.add('HP nPar')
    assert virtual_facts['virtualization_tech_guest'] == guest_tech

    # test case for hpvminfo
    hpux_virtual.module.run_command

# Generated at 2022-06-23 02:20:08.984132
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(module=None)
    assert virtual._platform == 'HP-UX'
    assert virtual._fact_class._platform == 'HP-UX'

# Generated at 2022-06-23 02:20:15.849325
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    # Unit test for virtualization_type
    assert hpux_virtual.virtualization_type == 'unknown'
    # Unit test for virtualization_role
    assert hpux_virtual.virtualization_role == 'unknown'
    # Unit test for virtualization_tech_host
    assert hpux_virtual.virtualization_tech_host == set()
    # Unit test for virtualization_tech_guest
    assert hpux_virtual.virtualization_tech_guest == set()


# Generated at 2022-06-23 02:20:20.958447
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    virtual_facts = dict()
    virtual_facts['virtualization_type'] = 'guest'
    virtual_facts['virtualization_role'] = 'HP nPar'
    virtual_facts['virtualization_tech_guest'] = {'HP nPar'}
    virtual_facts['virtualization_tech_host'] = set()

    hpux_virtual_obj = HPUXVirtual(dict(module=dict()))
    hpux_virtual_obj.module.run_command = mock_run_command
    facts = hpux_virtual_obj.get_virtual_facts()
    assert facts == virtual_facts


# Generated at 2022-06-23 02:20:32.261732
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.utils import AnsibleFactCollector

    # Create instance of HPUXVirtual
    data = AnsibleFactCollector.get_platform_facts()
    obj = HPUXVirtual(data)

    # Testing with a vPar guest
    obj.module.run_command = mock_get_command_result
    obj.module.command_results = {
        '/usr/sbin/vecheck': (0, "HP Virtual Partition Manager", ''),
        '/opt/hpvm/bin/hpvminfo': (0, "HPVM vPar", ''),
        '/usr/sbin/parstatus': (0, "", '')
    }

# Generated at 2022-06-23 02:20:33.250848
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-23 02:20:37.102017
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpuxvirtcol = HPUXVirtualCollector()
    assert hpuxvirtcol._fact_class == HPUXVirtual
    assert hpuxvirtcol._platform == 'HP-UX'

# Generated at 2022-06-23 02:20:42.648107
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.platform == 'HP-UX'
    assert hv.get_virtual_facts() == {}

# Generated at 2022-06-23 02:20:43.842070
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-23 02:20:48.882869
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    facts = HPUXVirtualCollector()
    assert facts._platform == 'HP-UX'
    assert facts._fact_class
    assert facts._fact_class.platform == 'HP-UX'


# Generated at 2022-06-23 02:20:51.714655
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector('ansible.module_utils.facts')
    assert collector.platform == 'HP-UX'
    assert collector.fact_class == HPUXVirtual


# Generated at 2022-06-23 02:20:56.365760
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec=dict())
    module.params['gather_subset'] = ['!all', 'virtual']
    hpux_virtual = HPUXVirtual(module)
    facts = hpux_virtual.get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'



# Generated at 2022-06-23 02:20:58.501098
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(dict())

    assert hv.platform == 'HP-UX'

# Generated at 2022-06-23 02:21:01.955515
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux = HPUXVirtual()
    hpux.get_virtual_facts()
    assert hpux.facts == {}

# Generated at 2022-06-23 02:21:04.174185
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vc = HPUXVirtualCollector()
    assert vc.platform == 'HP-UX'
    assert isinstance(vc._fact_class, HPUXVirtual)

# Generated at 2022-06-23 02:21:07.486092
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.system == 'HP-UX'
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-23 02:21:09.708765
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual(dict())
    assert v.platform == 'HP-UX'

# Generated at 2022-06-23 02:21:11.700126
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv is not None

# Generated at 2022-06-23 02:21:15.055728
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule()
    fact = HPUXVirtual(m)
    # Below line will fail if it does not get the expected result
    assert fact.get_virtual_facts()

# Generated at 2022-06-23 02:21:17.082662
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vc = HPUXVirtualCollector()
    assert vc.platform == 'HP-UX'
    assert vc._fact_class == HPUXVirtual

# Generated at 2022-06-23 02:21:21.540919
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = opp
    virtual = HPUXVirtual(module)
    assert virtual._module == module
    assert virtual.platform == 'HP-UX'

# Test get_virtual_facts method

# Generated at 2022-06-23 02:21:31.069990
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class HPUXVirtual
    """
    # Test for non-virtualized case
    module = AnsibleModule(argument_spec={})
    # set these so we can do basic fail_json in get_virtual_facts
    module.params = {}
    set_module_args(module.params)

    hpux = HPUXVirtual(module)
    facts = hpux.get_virtual_facts()
    assert 'virtualization_type' not in facts
    assert 'virtualization_role' not in facts
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_tech_guest' in facts



# Generated at 2022-06-23 02:21:33.060424
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    facts = dict()
    vc = HPUXVirtualCollector(facts, None)
    assert vc._platform == 'HP-UX'

# Generated at 2022-06-23 02:21:34.296869
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-23 02:21:40.951942
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert HPUXVirtualCollector._fact_class == HPUXVirtual
    assert HPUXVirtualCollector._platform == 'HP-UX'
    assert hv.platform == 'HP-UX'
    assert hv.collect()['virtualization_type'] == 'guest'
    assert hv.collect()['virtualization_role'] == 'HP nPar'

# Generated at 2022-06-23 02:21:52.670198
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import Virtual, VirtualCollector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.utils import ansible_facts_to_dict
    from ansible.module_utils import basic
    import sys

    facts_d = dict(
        os=dict(
            family='HP-UX',
            name='HP-UX'
        ),
        virtualization=dict(
            role='guest'
        )
    )

    # Mock module class

# Generated at 2022-06-23 02:21:59.288631
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    '''
    This method tests whether the object created using HPUXVirtualCollector class
    is an instance of HPUXVirtualCollector class and object created using its parent
    VirtualCollector class is an instance of VirtualCollector class.
    '''

    hpx_virtual_collector_obj = HPUXVirtualCollector()
    assert isinstance(hpx_virtual_collector_obj, HPUXVirtualCollector)

    virtual_collector_obj = VirtualCollector()
    assert isinstance(virtual_collector_obj, VirtualCollector)

# Generated at 2022-06-23 02:22:01.993761
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = type('old_module', (object, ), { 'run_command': dict()})()
    instance = HPUXVirtualCollector(module)
    assert instance._platform == 'HP-UX'


# Generated at 2022-06-23 02:22:04.518221
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import module_utils.facts.virtual.hpux_virtual as hpux_virtual_files
    HPUXVirtual._module = None
    virtual_facts = HPUXVirtual(module=None).get_virtual_facts()
    assert virtual_facts == hpux_virtual_files.HPUX_VIRTUAL_FACTS


# Generated at 2022-06-23 02:22:07.600713
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert isinstance(hv, VirtualCollector)
    assert hv.__class__.__name__ == "HPUXVirtualCollector"



# Generated at 2022-06-23 02:22:10.498772
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    h = HPUXVirtualCollector()
    assert h.platform == 'HP-UX'
    assert h.fact_class == HPUXVirtual

# Generated at 2022-06-23 02:22:12.100407
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual(dict())
    assert v.platform == 'HP-UX'

# Generated at 2022-06-23 02:22:14.411393
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(dict())
    assert hv.system == 'HP-UX'
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-23 02:22:17.117363
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    facts = dict()
    virtual_collector = HPUXVirtualCollector(facts, None)
    assert virtual_collector
    assert virtual_collector._collect_once


# Generated at 2022-06-23 02:22:22.715211
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    from ansible.module_utils.facts import Collector
    # Test if the collector can recognize the platform
    assert Collector.detect_platform('HPUX') == 'HP-UX'
    assert Collector.detect_platform('') is None
    # Test if the collector can be instantiated for platform 'HPUX'
    assert HPUXVirtualCollector is not None

# Generated at 2022-06-23 02:22:26.206089
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual({}, {})
    assert virtual is not None


# Generated at 2022-06-23 02:22:34.619819
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class TestModule(object):
        def run_command(self, args):
            return 0, '', ''

    module = TestModule()
    collector = HPUXVirtualCollector(module=module)
    collector._platform = 'HP-UX'
    virtual_facts = collector.get_virtual_facts()

    if 'virtualization_tech_guest' not in virtual_facts:
        assert False
    virtualization_tech_guest = virtual_facts['virtualization_tech_guest']
    if 'HP nPar' not in virtualization_tech_guest:
        assert False


# Generated at 2022-06-23 02:22:36.524549
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict(module=dict()))
    assert virtual.platform == 'HP-UX'


# Generated at 2022-06-23 02:22:39.244858
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts_obj = HPUXVirtual(dict())
    assert virtual_facts_obj.platform == 'HP-UX'


# Generated at 2022-06-23 02:22:40.327072
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts is not None


# Generated at 2022-06-23 02:22:43.027073
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts_obj = HPUXVirtual.load_virtual_facts()
    assert 'virtualization_type' in virtual_facts_obj

# Generated at 2022-06-23 02:22:45.013361
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(None)
    assert virtual.platform == 'HP-UX'


# Generated at 2022-06-23 02:22:48.252857
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # required arguments for constructor
    module = None
    # call constructor without optional argument
    virt = HPUXVirtual(module)
    # check that instance is created
    assert virt


# Generated at 2022-06-23 02:22:50.216536
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert virtual_collector.virtual is not None

# Generated at 2022-06-23 02:22:52.278145
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector.virtual  # will raise AttributeError if class not initialized

# Generated at 2022-06-23 02:22:58.756158
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpux_virtual_collector = HPUXVirtualCollector()
    assert hpux_virtual_collector.platform == 'HP-UX'
    assert hpux_virtual_collector._fact_class.platform == 'HP-UX'
    assert isinstance(hpux_virtual_collector._fact_class(), HPUXVirtual)

# Generated at 2022-06-23 02:23:02.519532
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    # constructor tests
    x = HPUXVirtualCollector()
    assert x
    assert x.facts == {}
    assert x.platform == 'HP-UX'
    assert x._fact_class == HPUXVirtual
    assert x._platform == 'HP-UX'

# Generated at 2022-06-23 02:23:04.935637
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual().__class__.__name__ == "HPUXVirtual"
    assert HPUXVirtual().platform == "HP-UX"

# Generated at 2022-06-23 02:23:08.835812
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    h = HPUXVirtualCollector()
    assert h.platform == 'HP-UX'
    assert h.fact_class == HPUXVirtual
    assert h.collector == None

# Unit tests for class HPUXVirtual

# Generated at 2022-06-23 02:23:11.464600
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """
    Unit test for the initialization of class HPUXVirtualCollector
    """
    HPUXVirtualCollector()



# Generated at 2022-06-23 02:23:22.712462
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    # Setup mock objects
    # An object for testing.paramiko.SSHClient()
    class MockSSHClient():
        def __init__(self):
            pass

        def set_missing_host_key_policy(self, param):
            pass

        def connect(self, hostname, port, username, password, key_filename, timeout):
            pass

    # An object for testing.subprocess.Popen()
    class MockPopen():
        def __init__(self):
            pass

        def communicate(self):
            pass

    # An object for testing.subprocess.Popen().communicate()
    class MockPopenCommunicate():
        def __init__(self):
            pass


# Generated at 2022-06-23 02:23:27.571702
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_inst = HPUXVirtual(dict())
    result = virtual_inst.get_virtual_facts()
    assert result['virtualization_type'] is None
    assert result['virtualization_role'] is None
    assert result['virtualization_tech_guest'] == set()
    assert result['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:23:33.040632
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector(None)
    assert virtual_collector.platform == 'HP-UX'
    assert str(virtual_collector) == 'HP-UX'
    assert virtual_collector.virtual == HPUXVirtual
    assert virtual_collector.virtual.platform == 'HP-UX'
    assert virtual_collector.virtual.__name__ == 'HPUXVirtual'

# Generated at 2022-06-23 02:23:42.507938
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    class ModuleMock():
        def __init__(self):
            self.run_command = lambda x: (0, '', '')
            self.params = {}

    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual

    module = ModuleMock()
    virtual = HPUXVirtual(module, None)

    assert virtual.get_virtual_facts() == {
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(),
        'virtualization_type': 'guest',
        'virtualization_role': 'HP nPar'}



# Generated at 2022-06-23 02:23:44.437075
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    coll = HPUXVirtualCollector()
    assert coll.platform == 'HP-UX'
    assert coll._fact_class == HPUXVirtual