

# Generated at 2022-06-11 05:46:30.509298
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.get_virtual_facts() == {}

# Generated at 2022-06-11 05:46:35.471568
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(dict())
    assert hv.platform == 'HP-UX'
    assert hv.get_virtual_facts() == {
        'virtualization_type': 'guest',
        'virtualization_role': 'HPVM IVM',
        'virtualization_tech_guest': {'HP vPar', 'HPVM vPar', 'HPVM IVM', 'HP nPar'},
        'virtualization_tech_host': set([])
    }

# Generated at 2022-06-11 05:46:37.859313
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual._platform == 'HP-UX'
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-11 05:46:41.761575
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual()
    assert virtual.platform == 'HP-UX'
    assert virtual.get_virtual_facts() == {'virtualization_type': 'guest', 'virtualization_role': 'HP vPar',
                                           'virtualization_tech_guest': {'HP vPar'}, 'virtualization_tech_host':set()}

# Generated at 2022-06-11 05:46:49.851207
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virtual = HPUXVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    if os.path.exists('/usr/sbin/vecheck') and os.path.exists('/opt/hpvm/bin/hpvminfo') and os.path.exists('/usr/sbin/parstatus'):
        assert virtual_facts['virtualization_type'] == 'guest'
        assert virtual_facts['virtualization_role'] == 'HP nPar'
        assert virtual_facts['virtualization_tech_host'] == set()
        assert virtual_facts['virtualization_tech_guest'] == set(['HP vPar', 'HPVM IVM', 'HP nPar'])

# Generated at 2022-06-11 05:46:52.660944
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    hpux_virtual = HPUXVirtual(module=module)
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-11 05:47:00.856540
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import mock
    import tempfile

    tmp_file = tempfile.NamedTemporaryFile()
    tmp_name = tmp_file.name
    tmp_file.write('test'.encode('utf-8'))
    tmp_file.flush()
    with mock.patch('os.path.exists') as mock_exists:
        mock_exists.side_effect = lambda x: x == tmp_name

# Generated at 2022-06-11 05:47:09.894281
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    # Mock methods and attributes
    class MockModule(object):
        def run_command(self, cmd):
            return 0, 'output', 'error'

    class MockFacts(object):
        module = MockModule
        virtualization_tech_guest = set()
        virtualization_tech_host = set()
        virtualization_type = ''
        virtualization_role = ''

    obj = HPUXVirtual()
    obj.facts = MockFacts

    assert obj.get_virtual_facts() == {
        'virtualization_tech_guest': set(['HP vPar', 'HP nPar']),
        'virtualization_tech_host': set(),
        'virtualization_type': 'guest',
        'virtualization_role': 'HP vPar'
    }

# Generated at 2022-06-11 05:47:12.482556
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # All parameters / attributes of the class should exist after constructor is called
    virtual = HPUXVirtual(module=None)
    assert virtual.facts == dict()
    assert virtual.platform == 'HP-UX'

# Generated at 2022-06-11 05:47:20.975878
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    # Because the object is created with a mocked module, the method
    # run_command will not run any command itself, but just return a tuple
    # containing the exit code, the output and the error
    obj = HPUXVirtual(module=module)
    if os.path.exists('/usr/sbin/vecheck'):
        obj.module.run_command = lambda x: (0, '', '')
        facts = obj.get_virtual_facts()
        assert facts['virtualization_type'] == 'guest'
        assert facts['virtualization_role'] == 'HP vPar'
        assert facts['virtualization_tech_host'] == set()
        assert facts['virtualization_tech_guest'] == set

# Generated at 2022-06-11 05:47:35.178683
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    vecheck_vpar_out = [0, '::CAPABILITY:vpar:::', '', '']
    hpvminfo_vpar_out = [0, 'HPVM vPar                                   Running\n', '', '']
    hpvminfo_ivm_out = [0, 'HPVM guest vpars                            Running\n', '', '']
    hpvminfo_host_out = [0, 'HPVM host vpars                              Running\n', '', '']
    parstatus_out = [0, 'System name :  devhpx1\n', '', '']

    # Test get_virtual_facts for vPar

# Generated at 2022-06-11 05:47:36.607463
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpuxvirtual = HPUXVirtual()
    assert hpuxvirtual.platform == 'HP-UX'


# Generated at 2022-06-11 05:47:45.109389
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Test the method get_virtual_facts of class HPUXVirtual
    """
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    import ansible.module_utils.facts.virtual.base
    import sys

    # Setup the class virtualization_type and virtualization_role
    ansible.module_utils.facts.virtual.base.virtualization_type = ""
    ansible.module_utils.facts.virtual.base.virtualization_role = ""

    # Create a virtual instance.
    virtual_inst = VirtualCollector.factory()

    # Define a test class which extends the HPUXVirtual class

# Generated at 2022-06-11 05:47:50.373170
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    mock_module = MockModule()
    mock_module.run_command = Mock(return_value=(0, 'Running HPVM HP_UX based vPar', ''))
    hpux_virtual = HPUXVirtual(mock_module)
    virtual_facts = hpux_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HPVM vPar'


# Generated at 2022-06-11 05:47:52.944497
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual({})
    assert 'hp' in v.data['system']['manufacturer'].lower()
    assert 'hpux' in v.data['system']['product'].lower()

# Generated at 2022-06-11 05:48:00.916885
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    '''
    This test case verifies the behavior of get_virtual_facts of HPUXVirtual
    class.
    We are using the below toy module to mock the module.run_command.
    class MockModule(object):
      def run_command(self, *args, **kwargs):
        return 0, '<output>', '<error>'
    In the test case, we are mocking the behavior of os.path.exists.
    '''
    MockModule = type('MockModule', (object,), {'run_command': lambda *args, **kwargs: (0, '<output>', '<error>')})
    module = MockModule()

    ret = {}

    virtual_facts = {}

    guest_tech = set()
    host_tech = set()


# Generated at 2022-06-11 05:48:09.527363
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import pytest
    from ansible.module_utils.facts import ansible_module
    from ansible.module_utils.facts.virtual.hpu import HPUXVirtual
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.facts.collector import TestModuleCollector

    class TestHPUXVirtual(HPUXVirtual):
        """
        Override methods that would interact with the system for testing.
        """
        def __init__(self, module):
            super(TestHPUXVirtual, self).__init__(module)

        def get_run_command_responses(self):
            """
            Provide responses to run_command calls
            """

# Generated at 2022-06-11 05:48:10.294918
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual()

# Generated at 2022-06-11 05:48:16.208912
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux.hpux import HPUXVirtual
    module = MockModule()
    hpux_virtual = HPUXVirtual(module)
    facts = hpux_virtual.get_virtual_facts()
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_type'] == None
    assert facts['virtualization_role'] == None

# Used for unit tests

# Generated at 2022-06-11 05:48:17.805309
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual(dict())
    assert virtual_obj.__class__.__name__ == 'HPUXVirtual'


# Generated at 2022-06-11 05:48:30.140200
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual(dict())
    assert virtual_obj.platform == 'HP-UX'


# Generated at 2022-06-11 05:48:32.066762
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual()
    assert isinstance(v, HPUXVirtual)
    assert isinstance(v, Virtual)


# Generated at 2022-06-11 05:48:41.309922
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    HPUXVirtualCollector.collect()
    virtual_facts = HPUXVirtualCollector.get_virtual_facts()
    assert type(virtual_facts) is dict
    assert type(virtual_facts['virtualization_tech_host']) is set
    assert type(virtual_facts['virtualization_tech_guest']) is set
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-11 05:48:45.266273
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """Unit test for method get_virtual_facts of class HPUXVirtual
    """
    module = AnsibleModule(
        argument_spec=dict(
            gathering='hardware',
            filter='*'
        )
    )
    virtual = HPUXVirtual(module)
    result = virtual.get_virtual_facts()
    assert result == {}


# Generated at 2022-06-11 05:48:51.048149
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    mock_module = MockModule()
    mock_module.run_command = Mock(return_value=(0, '', ''))
    h = HPUXVirtual(module=mock_module)
    result = h.get_virtual_facts()
    assert result == {'virtualization_type': None,
                      'virtualization_role': None,
                      'virtualization_tech_host': set(),
                      'virtualization_tech_guest': set()}


# Generated at 2022-06-11 05:48:52.823974
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpx = HPUXVirtual()
    assert hpx.hpx.__class__.__name__ == 'HPUXVirtual'


# Generated at 2022-06-11 05:49:00.796010
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    hpuxvirtual = HPUXVirtual({})
    hpuxvirtual.module.run_command = mock_run_command
    hpuxvirtual.module.params = {}

    hpuxvirtual.get_virtual_facts()

    if not os.path.exists('/usr/sbin/vecheck'):
        assert hpuxvirtual.virtual_facts == {'virtualization_tech_guest': set(),
            'virtualization_tech_host': set()}
    else:
        assert hpuxvirtual.virtual_facts == {'virtualization_tech_guest': set(['HP vPar']),
            'virtualization_tech_host': set(),
            'virtualization_role': 'HP vPar',
            'virtualization_type': 'guest'}


# Generated at 2022-06-11 05:49:03.132501
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual()
    assert isinstance(virtual_obj, Virtual)
    assert virtual_obj.platform == 'HP-UX'


# Generated at 2022-06-11 05:49:10.574360
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = {}

    if os.path.exists('/usr/sbin/vecheck'):
        rc, out, err = module.run_command("/usr/sbin/vecheck")
        if rc == 0:
            virtual_facts['virtualization_type'] = 'guest'
            virtual_facts['virtualization_role'] = 'HP vPar'
    if os.path.exists('/opt/hpvm/bin/hpvminfo'):
        rc, out, err = module.run_command("/opt/hpvm/bin/hpvminfo")
        if rc == 0 and re.match('.*Running.*HPVM vPar.*', out):
            virtual_facts['virtualization_type'] = 'guest'
            virtual_facts['virtualization_role'] = 'HPVM vPar'
       

# Generated at 2022-06-11 05:49:16.922279
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    This is a test method for class HPUXVirtual.get_virtual_facts
    """
    os.path.exists = lambda x: True
    class ModuleMock(object):
        def run_command(self, *cmd, **args):
            if cmd == ('/usr/sbin/vecheck',):
                return (0, '', '')
            if cmd == ('/opt/hpvm/bin/hpvminfo',):
                return (0, 'Running HPVM vPar\n', '')
            if cmd == ('/usr/sbin/parstatus',):
                return (0, '', '')
            raise Exception('Unexpected command called: %s' % cmd)

    m = ModuleMock()
    v = HPUXVirtual(m)
    facts = v.get_virtual_facts()
   

# Generated at 2022-06-11 05:49:41.720174
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpu = HPUXVirtual(None)
    assert hpu.platform == "HP-UX"


# Generated at 2022-06-11 05:49:43.118253
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual()
    assert v.platform == 'HP-UX'


# Generated at 2022-06-11 05:49:43.987576
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual(dict())
    pass

# Generated at 2022-06-11 05:49:45.305848
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt = HPUXVirtual()
    assert virt.platform == 'HP-UX'


# Generated at 2022-06-11 05:49:47.251967
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    assert(HPUXVirtual.get_virtual_facts() != None)


# Generated at 2022-06-11 05:49:48.643028
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv is not None

# Generated at 2022-06-11 05:49:53.012068
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpuix import HPUXVirtual
    module = HPUXVirtual()
    assert module.get_virtual_facts() == {
        'virtualization_role': 'HP vPar',
        'virtualization_type': 'guest', 
        'virtualization_tech_guest': set(['HP vPar']), 
        'virtualization_tech_host': set()
        }

# Generated at 2022-06-11 05:49:56.835300
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual(dict())
    assert v.platform == 'HP-UX'
    assert v.virtualization_type == 'host'
    assert v.virtualization_role == ''
    assert v.virtualization_subrole == ''
    assert len(v.virtualization_tech_guest) == 0
    assert len(v.virtualization_tech_host) == 0

# Generated at 2022-06-11 05:50:00.875353
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.facts['virtualization_type'] == 'guest'
    assert hv.facts['virtualization_role'] == 'HP nPar'
    assert 'HP nPar' in hv.facts['virtualization_tech_guest']
    assert 'HP nPar' not in hv.facts['virtualization_tech_host']

# Generated at 2022-06-11 05:50:02.927423
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpxVirtual = HPUXVirtual()
    assert type(hpxVirtual) is HPUXVirtual
    assert hpxVirtual._platform == 'HP-UX'


# Generated at 2022-06-11 05:51:00.934898
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    virt = HPUXVirtual(test_module)
    virt_facts = virt.get_virtual_facts()
    print("Virtual Facts: %s" % virt_facts)
    assert virt_facts['virtualization_type'] == 'guest'
    assert virt_facts['virtualization_role'] == 'HP nPar'
    assert virt_facts['virtualization_tech_guest'] == set(['HP nPar'])
    assert virt_facts['virtualization_tech_host'] == set([])


# Generated at 2022-06-11 05:51:02.333470
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts_obj = HPUXVirtual()
    assert isinstance(virtual_facts_obj, HPUXVirtual)

# Generated at 2022-06-11 05:51:12.051481
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class TestModule():
        def __init__(self, out, err, rc, path):
            self.out = out
            self.err = err
            self.rc = rc
            self.path = path

        def run_command(self, command):
            return self.rc, self.out, self.err

    def test_os_path_exists(path):
        if path == '/usr/sbin/vecheck':
            return True
        else:
            return False

    # Testing running as guest in vecheck
    out = 'Ve check'
    module = TestModule(out, '', 0, '/usr/sbin/vecheck')
    os_path_exists = test_os_path_exists
    facts = HPUXVirtual(module, os_path_exists).get_virtual_facts()

# Generated at 2022-06-11 05:51:20.099773
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    def run_command(command, *args, **kwargs):
        if isinstance(command, basestring):
            command = [command]
        if command[0] == "/usr/sbin/vecheck":
            return 0, " veroot  \n\
 vdb  -rw-rw-rw-  1 root sys     74624 Dec 20  2002  /usr/sbin/vecheck", ""
        elif command[0] == "/opt/hpvm/bin/hpvminfo":
            return 0, "Running HPVM vPar", ""

# Generated at 2022-06-11 05:51:27.815015
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
  # Test data to be passed
  test_str1 = "HPVM vPar is running"
  test_str2 = "HP nPar is running"
  test_str3 = "HP vPar is running"
  test_str4 = "HPVM guest is running"
  test_str5 = "HPVM host is running"
  test_str6 = "HPVM IVM is running"
  test_str7 = "HP vPar and HPVM guest is running"
  test_str8 = "HP nPar and HPVM guest is running"
  test_str9 = "HP nPar and HPVM vPar is running"
  test_str10 = "HP vPar and HPVM host is running"
  test_str11 = "HPVM host and HPVM IVM is running"

# Generated at 2022-06-11 05:51:32.255933
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts_obj = HPUXVirtual()

    assert virtual_facts_obj.platform == 'HP-UX'
    assert virtual_facts_obj.get_virtual_facts() == {'virtualization_role': 'HPVM', 'virtualization_type': 'host', 'virtualization_tech_guest': {'HPVM'}, 'virtualization_tech_host': set()}

# Generated at 2022-06-11 05:51:33.776781
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    x = HPUXVirtual()
    assert x.platform == 'HP-UX'



# Generated at 2022-06-11 05:51:36.026051
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual({})
    assert v.platform == 'HP-UX'
    assert v.file_paths['service_mgr'] == '/sbin/init.d'

# Generated at 2022-06-11 05:51:37.421964
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    my_fact = HPUXVirtual()
    assert 'HP-UX' == my_fact.platform


# Generated at 2022-06-11 05:51:38.796444
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    host_virtual = HPUXVirtual(module=None)
    assert host_virtual
    host_virtual.collect()

# Generated at 2022-06-11 05:53:12.342402
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class fake_module(object):
        def run_command(self, cmd):
            rc = None
            out = None
            err = None
            if cmd == '/usr/sbin/vecheck':
                rc = 0
            elif cmd == '/opt/hpvm/bin/hpvminfo':
                rc = 0
                out = 'Running in HPVM vPar'
            elif cmd == '/usr/sbin/parstatus':
                rc = 0
            return rc, out, err

    class fake_module_notvecheck(object):
        def run_command(self, cmd):
            rc = None
            out = None
            err = None
            if cmd == '/usr/sbin/vecheck':
                rc = 2
            return rc, out, err


# Generated at 2022-06-11 05:53:14.251526
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpuxv = HPUXVirtual(None)
    assert hpuxv.platform == 'HP-UX'



# Generated at 2022-06-11 05:53:17.864991
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual()
    assert virtual_obj.virtualization_type == 'guest'
    assert virtual_obj.virtualization_role == 'HP vPar'
    assert virtual_obj.virtualization_tech_guest == ['HP vPar']
    assert virtual_obj.virtualization_tech_host == []

# Generated at 2022-06-11 05:53:22.314746
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    res = HPUXVirtual.get_virtual_facts(HPUXVirtual())
    assert isinstance(res, dict)
    assert set(list(res.keys())) == set(['virtualization_type', 'virtualization_role', 'virtualization_tech_guest', 'virtualization_tech_host'])

# Generated at 2022-06-11 05:53:24.694724
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual(dict())
    assert v
    assert v.platform == 'HP-UX'

# Unit tests for get_virtual_facts()

# Generated at 2022-06-11 05:53:25.886502
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual()

    assert virtual_obj._platform == 'HP-UX'

# Generated at 2022-06-11 05:53:27.913926
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    print(virtual_facts)


# unit test for get_virtual_facts of class HPUXVirtual

# Generated at 2022-06-11 05:53:34.091341
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible import module_utils
    import ansible.module_utils.facts.virtual.hpux
    m = module_utils.basic.AnsibleModule()
    v = HPUXVirtual(m)
    v.module.run_command = lambda x: (0, '', '')
    v_facts = v.get_virtual_facts()
    assert v.platform == 'HP-UX'
    assert 'virtualization_type' in v_facts
    assert 'virtualization_role' in v_facts

# Generated at 2022-06-11 05:53:35.893778
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual(dict(), dict(module=dict()))
    assert v.platform == 'HP-UX'



# Generated at 2022-06-11 05:53:37.715735
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual({})
    assert v.platform == 'HP-UX'
    assert v.collector.platform == 'HP-UX'