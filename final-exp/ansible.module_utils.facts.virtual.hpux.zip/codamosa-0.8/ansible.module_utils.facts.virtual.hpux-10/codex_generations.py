

# Generated at 2022-06-11 05:46:35.906326
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    class LinuxModule:
        def __init__(self):
            self.run_command = ''

    class LinuxModuleResult:
        def __init__(self):
            self.rc = 0
            self.out = ''
            self.err = ''
            return

    facts = {}

    def run_command(x):
        return LinuxModuleResult()

    temp_module = LinuxModule()
    temp_module.run_command = run_command

    hv = HPUXVirtual(temp_module)
    facts.update(hv.get_virtual_facts())

# Generated at 2022-06-11 05:46:38.496388
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():

    hpux_virtual_test = HPUXVirtual(dict(module='test'))

    assert hpux_virtual_test.module == 'test'
    assert hpux_virtual_test.platform == 'HP-UX'

# Generated at 2022-06-11 05:46:46.833471
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import platform

    hw_arch = platform.machine()
    if hw_arch == 'ia64':
        mocked_module = MockModule({
            '/usr/sbin/vecheck': '',
            '/opt/hpvm/bin/hpvminfo': 'Running HPVM vPar',
            '/usr/sbin/parstatus': ''
        })
        vFacts = HPUXVirtual().populate()
        assert vFacts['virtualization_type'] == 'guest'
        assert vFacts['virtualization_role'] == 'HPVM vPar'
        assert vFacts['virtualization_tech_host'] == set()
        assert vFacts['virtualization_tech_guest'] == set(['HPVM vPar'])

# Generated at 2022-06-11 05:46:49.595278
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual({})
    assert v.platform == Virtual.platform
    v = HPUXVirtual({'ANSIBLE_SYSTEM_MODULE_PATH': '../'})
    assert v.platform == 'HP-UX'

# Generated at 2022-06-11 05:46:53.707900
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = type(str, (object,), dict(run_command=lambda x: (0, '', '')))()
    obj = HPUXVirtual(module)
    assert type(obj).__name__ == 'HPUXVirtual'
    assert hasattr(obj, 'get_virtual_facts')
    assert obj.platform == 'HP-UX'


# Generated at 2022-06-11 05:46:57.080485
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    m = HPUXVirtual(dict())
    assert m.platform == 'HP-UX'
    assert m.virtualization_type is None
    assert m.virtualization_role is None
    assert m.virtualization_tech_host == set()
    assert m.virtualization_tech_guest == set()

# Generated at 2022-06-11 05:46:59.255424
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUX_Virtual = HPUXVirtual()
    assert HPUX_Virtual.platform == 'HP-UX'
    assert HPUX_Virtual.virtual == 'HP-UX'

# Generated at 2022-06-11 05:47:08.135365
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual

    tmp_file_path = "/tmp/hpux_virtual_facts"
    tmp_file_content = """Running HPVM vPar
"""
    fact_collector = FactCollector(None, HPUXVirtualCollector)
    fact_collector.find_collector("virtual")
    fact_collector.collectors['virtual'].module = \
                                                MockModule(tmp_file_path)
    virtual_facts = fact_collector.collectors['virtual'].get_virtual_facts()
    # Check method get_virtual_facts of class HPUXVirtual returns virtual_facts
    # dict with key virtualization_type and virtualization_role

# Generated at 2022-06-11 05:47:10.345944
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    # Assert that virtual_facts.platform is defined
    assert virtual_facts.platform



# Generated at 2022-06-11 05:47:15.964207
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Create instance of class HPUXVirtual
    virtual_facts = HPUXVirtual()

    # Create mock values
    os.path.exists.return_value = True

    # Invoke method
    virtual_facts_dict = virtual_facts.get_virtual_facts()

    # Check results
    assert virtual_facts_dict['virtualization_type'] == 'guest'
    assert virtual_facts_dict['virtualization_role'] == 'HP vPar'

    # Delete instance of class HPUXVirtual
    del virtual_facts

# Generated at 2022-06-11 05:47:26.612259
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual()
    assert v.platform == 'HP-UX'


# Generated at 2022-06-11 05:47:27.634772
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    VR = HPUXVirtual(dict())
    assert VR.platform == 'HP-UX'

# Generated at 2022-06-11 05:47:29.537335
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpxv = HPUXVirtual(dict(), dict())

    # Tests for the get_virtual_facts method
    assert hpxv.get_virtual_facts() == {}

# Generated at 2022-06-11 05:47:30.764490
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    mod = HPUXVirtual(None)
    assert mod.platform == 'HP-UX'

# Generated at 2022-06-11 05:47:35.498183
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hp_ux import HPUXVirtual
    facts = HPUXVirtual({})
    virt_facts = facts.get_virtual_facts()
    assert 'virtualization_type' in virt_facts
    assert 'virtualization_role' in virt_facts
    assert 'virtualization_tech_host' in virt_facts
    assert 'virtualization_tech_guest' in virt_facts

# Generated at 2022-06-11 05:47:44.006806
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class HPModuleFake:
        def __init__(self):
            self.run_command_rc = 0

        def run_command(self, command):
            if command == "/usr/sbin/vecheck":
                stdout = 'foo'
            elif command == "/opt/hpvm/bin/hpvminfo":
                stdout = 'Running HPVM vPar'
            elif command == "/usr/sbin/parstatus":
                stdout = 'foo'
            else:
                raise Exception("Don't know how to handle command: %s" % command)
            return self.run_command_rc, stdout, ''

    class ModuleFake:
        def __init__(self):
            self.run_command_rc = 0


# Generated at 2022-06-11 05:47:48.306166
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = type('FakeModule', (), {'run_command': lambda *args, **kwargs: (0, '', ''), })
    module.exit_json = lambda *args, **kwargs: None
    module.fail_json = lambda *args, **kwargs: None
    if HPUXVirtual(module).virtual:
        assert True
    else:
        assert False


# Generated at 2022-06-11 05:47:49.462845
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual({})
    assert h.platform == "HP-UX"

# Generated at 2022-06-11 05:47:50.986907
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts._platform == 'HP-UX'

# Generated at 2022-06-11 05:47:57.789588
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.virtual import BaseVirtual

    fake_module = FactCollector()
    virtual_obj = BaseVirtual(fake_module)
    virtual_obj.get_virtual_facts()
    if virtual_obj.virtual_facts:
        assert 'virtualization_tech_guest' in virtual_obj.virtual_facts
        assert 'virtualization_tech_host' in virtual_obj.virtual_facts
        assert 'virtualization_type' in virtual_obj.virtual_facts
        assert 'virtualization_role' in virtual_obj.virtual_facts
    else:
        assert False, "Virtual facts not found"

# Generated at 2022-06-11 05:48:10.187423
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(None)
    assert virtual.get_virtual_facts() == {
        'virtualization_type': 'host',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

# Generated at 2022-06-11 05:48:18.668730
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=False
    )
    facts = {}

# Generated at 2022-06-11 05:48:21.622667
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    virt = HPUXVirtual(dict(module=dict()))
    result = virt.get_virtual_facts()
    assert result == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

# Generated at 2022-06-11 05:48:23.229440
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual(dict(), dict())
    assert virtual_obj.platform == 'HP-UX'

# Generated at 2022-06-11 05:48:24.929282
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    huxvirtual = HPUXVirtual({})
    assert huxvirtual.platform == 'HP-UX'


# Generated at 2022-06-11 05:48:26.426899
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual({}, {})
    assert virtual.platform == 'HP-UX'


# Generated at 2022-06-11 05:48:30.261461
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_factory = HPUXVirtualCollector()
    virtual_factory.collect()
    virtual_factory.populate_facts()
    fact_module = HPUXVirtual()
    virtual_facts = fact_module.get_virtual_facts()
    assert virtual_facts['virtualization_type'] is not None

# Generated at 2022-06-11 05:48:39.740992
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    def _mock_run_command(cmd, *args, **kwargs):
        if cmd == '/usr/sbin/vecheck':
            return 0, '', ''
        elif cmd == '/opt/hpvm/bin/hpvminfo':
            return 0, 'Running - HPVM vPar', ''

    # making Virtual._module class attribut available
    virtual = HPUXVirtual()
    virtual._module.run_command = _mock_run_command

    # running the method to test
    virtual_facts = virtual.get_virtual_facts()

    # making assertions
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HPVM vPar'
    assert len(virtual_facts['virtualization_tech_guest']) == 2

# Generated at 2022-06-11 05:48:43.462775
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(dict(module=dict()))
    assert hpux_virtual is not None
    assert 'guest' == hpux_virtual.get_virtual_facts()['virtualization_type']
    assert 'HP nPar' == hpux_virtual.get_virtual_facts()['virtualization_role']

# Generated at 2022-06-11 05:48:48.501572
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule()
    hpux_virtual_fact = HPUXVirtual(module=module)
    virtual_facts = hpux_virtual_fact.get_virtual_facts()
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert 'virtualization_role' not in virtual_facts
    assert virtual_facts['virtualization_type'] == 'host'

# Generated at 2022-06-11 05:49:19.876914
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict()
    )
    module.run_command = lambda cmd: (0, '', '')
    module.does_file_exist = lambda cmd: True
    virtual = HPUXVirtual(module).get_virtual_facts()
    assert virtual['virtualization_type'] == 'guest'
    assert virtual['virtualization_role'] == 'HP vPar'



# Generated at 2022-06-11 05:49:23.776220
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    virtual = HPUXVirtual()
    virtual_facts = virtual.get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-11 05:49:24.533965
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual()


# Generated at 2022-06-11 05:49:26.145891
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    test_HPUXVirtual = HPUXVirtual(None)
    assert test_HPUXVirtual.platform == 'HP-UX'

# Generated at 2022-06-11 05:49:27.467403
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-11 05:49:30.741412
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = AnsibleModule(argument_spec={})
    virtual_class = HPUXVirtual(module)
    facts = virtual_class.get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HPVM vPar'

# Generated at 2022-06-11 05:49:38.340763
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Check when hpvm is host
    hpux_virtual = HPUXVirtual()
    hpux_virtual.module.run_command = MagicMock()
    hpux_virtual.module.run_command.return_value = (0, 'Random output', '')
    hpux_virtual.module.run_command.side_effect = [
        (0, 'Random output', ''),
        (0, 'Running HPVM Virtual Machine Manager 7.2.0.', ''),
        (0, 'Running HPVM guest under host vmhost-1.example.com.', ''),
        (0, 'Random output', ''),
    ]
    result = hpux_virtual.get_virtual_facts()
    assert result['virtualization_type'] == 'host'
    assert result['virtualization_role'] == 'HPVM'

# Generated at 2022-06-11 05:49:39.868996
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual({})
    assert 'virtualization_type' in v.get_virtual_facts()


# Generated at 2022-06-11 05:49:48.563935
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class MockModule(object):
        def __init__(self, *args, **kwargs):
            self.params = {}
            self.run_command_success = True
            self.run_command_call_count = 0
            self.run_command_rc = 0
            self.run_command_out = ""
            self.run_command_err = ""

        def fail_json(self, *args, **kwargs):
            raise Exception('NotImplemented')

        def run_command(self, args, check_rc=False):
            self.run_command_call_count += 1
            rc = self.run_command_rc 
            out = self.run_command_out
            err = self.run_command_err
            return rc, out, err


# Generated at 2022-06-11 05:49:49.979213
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual({}, {})
    assert v.platform == 'HP-UX'

# Generated at 2022-06-11 05:50:21.391764
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    hpux_virtual = HPUXVirtual(dict(module=dict(run_command=run_command)))
    hpux_virtual_facts = hpux_virtual.get_virtual_facts()

    assert hpux_virtual_facts['virtualization_type'] == 'guest'
    assert hpux_virtual_facts['virtualization_role'] == 'HP vPar'

# Generated at 2022-06-11 05:50:23.320167
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_instance = HPUXVirtual()
    assert virtual_instance.name == 'HP-UX'
    assert virtual_instance.platform == 'HP-UX'


# Generated at 2022-06-11 05:50:31.352424
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.test.test_hpux import command_output
    from ansible.module_utils.facts.virtual.test.test_hpux import HpuxModuleMock

    hp_ux_virtual = HPUXVirtual(HpuxModuleMock(command_output))

    set_vecheck_is_present = False
    set_hpvm_is_present = False
    set_parstatus_is_present = False

    if os.path.exists('/usr/sbin/vecheck'):
        set_vecheck_is_present = True
    if os.path.exists('/opt/hpvm/bin/hpvminfo'):
        set_hpvm_is_present = True

# Generated at 2022-06-11 05:50:32.694517
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-11 05:50:40.139701
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    from ansible.module_utils.facts.virtual import HPUXVirtual
    from ansible.module_utils.facts.virtual import Virtual
    from ansible.module_utils.facts.virtual import VirtualCollector
    
    hpv = HPUXVirtual()
    assert isinstance(hpv, Virtual), "HPUXVirtual is a subclass of Virtual"
    assert issubclass(HPUXVirtual, Virtual), "HPUXVirtual is a subclass of Virtual"
    assert isinstance(hpv, VirtualCollector), "HPUXVirtual is a subclass of VirtualCollector"
    assert issubclass(HPUXVirtual, VirtualCollector), "HPUXVirtual is a subclass of VirtualCollector"


# Generated at 2022-06-11 05:50:42.518004
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = AnsibleModule(argument_spec=dict())
    virtual = HPUXVirtual(module)
    assert virtual.platform == 'HP-UX'
    assert virtual.module == module


# Generated at 2022-06-11 05:50:50.673649
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Define a class of mock_module with class variable run_command
    class MockModule(object):
        run_command = ""

    # Instantiate mock_module
    mock_module = MockModule()

    # Define a class of mock_module with class variable run_command
    class MockModule(object):
        run_command = ""

    # Instantiate mock_module
    mock_module = MockModule()

    # Instantiate HPUXVirtual object
    hpux_virtual = HPUXVirtual(mock_module)

    # Set module.run_command = "vecheck_command"
    mock_module.run_command = "/usr/sbin/vecheck"
    hpux_virtual.module = mock_module

# Generated at 2022-06-11 05:50:51.490321
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual()


# Generated at 2022-06-11 05:50:59.571662
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.facts import VarsModule, get_file_lines
    module = VarsModule()
    module.run_command = run_command
    module.get_file_lines = get_file_lines
    v = HPUXVirtual(module)
    facts = v.get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP vPar'
    assert 'HP vPar' in facts['virtualization_tech_guest']
    assert 'HP nPar' in facts['virtualization_tech_guest']
    assert 'HPVM vPar' in facts['virtualization_tech_guest']
    assert 'HPVM IVM' in facts['virtualization_tech_guest']

# Generated at 2022-06-11 05:51:00.356325
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert True

# Generated at 2022-06-11 05:52:03.232598
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Setup module
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, "", ""))
    module.stat = MagicMock(return_value=None)
    module.read_file = MagicMock(return_value=b"")

    # Setup hpux virtual
    hpux_virtual = HPUXVirtual(module)

    # Execute get_virtual_facts
    facts = hpux_virtual.get_virtual_facts()

    # Testing
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP vPar'
    assert facts['virtualization_tech_host'] == set()

# Generated at 2022-06-11 05:52:13.798586
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    import ansible.module_utils.facts.virtual.hpux as hpux

    # Create a class for mock module object
    class MockModule():
        def __init__(self):
            self.params = {}
            self.run_command = self.run_command_mock
        def fail_json(self, msg):
            raise Exception(msg)
        def run_command_mock(self, command):
            print ('MOCKED run_command: %s' % command)
            if 'vecheck' in command:
                return 0, 'Mocked vecheck output', ''
            elif '/opt/hpvm/bin/hpvminfo' in command:
                return 0, 'Mocked hpvminfo output', ''

# Generated at 2022-06-11 05:52:15.741828
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv._platform == "HP-UX"


# Generated at 2022-06-11 05:52:17.047159
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict())
    assert virtual._platform == 'HP-UX'

# Generated at 2022-06-11 05:52:25.219094
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Returns:
        dict: facts about virtualization
    """
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux.collection import VirtualCollector
    import os
    import operator

    class MockModule:
        def __init__(self, module_name, result, errmsg):
            self.result = result
            self.errmsg = errmsg
            self.run_command_params = []

        def run_command(self, command):
            self.run_command_params.append(command)
            if self.errmsg:
                return 1, self.errmsg, None
            else:
                return 0, self.result, None


# Generated at 2022-06-11 05:52:29.717258
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-11 05:52:31.167237
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual({})
    assert h.platform == 'HP-UX'


# Generated at 2022-06-11 05:52:34.426922
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts_collection = HPUXVirtualCollector(None, None, None)
    virtual_facts_instance = virtual_facts_collection._fact_class(virtual_facts_collection.module)
    assert virtual_facts_instance.platform == 'HP-UX'

# Generated at 2022-06-11 05:52:38.349412
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    fakemodule = FakeModule()
    facts = HPUXVirtual(fakemodule).get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts


# Generated at 2022-06-11 05:52:40.400367
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hvfacts = HPUXVirtual(dict())
    assert hvfacts.platform == 'HP-UX'



# Generated at 2022-06-11 05:53:17.260657
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-11 05:53:24.345693
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Return the virtualization facts.
    """
    test_module = AnsibleModule(argument_spec={})
    virtual_facts = HPUXVirtual().get_virtual_facts(module=test_module)
    assert virtual_facts['virtualization_tech_guest'] == set(['HP nPar',
                                                              'HP vPar',
                                                              'HPVM vPar',
                                                              'HPVM IVM'])
    assert virtual_facts['virtualization_tech_host'] == set([])


# Generated at 2022-06-11 05:53:33.773113
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class HPUXVirtual
    """
    from ansible.module_utils.facts import Facts

    results = {}
    class ModuleMock:
        def run_command(cmd):
            if cmd == "/usr/sbin/vecheck":
                results['rc'] = 0
                results['out'] = '0000'
                results['err'] = ''
            elif cmd == "/opt/hpvm/bin/hpvminfo":
                results['rc'] = 0
                results['out'] = 'Running in HPVM vPar'
                results['err'] = ''
            elif cmd == "/usr/sbin/parstatus":
                results['rc'] = 0
                results['out'] = '0000'
                results['err'] = ''
        def fail_json(msg):
            pass

# Generated at 2022-06-11 05:53:37.832803
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Unit test function to test the method get_virtual_facts of class HPUXVirtual
    """
    hpx = HPUXVirtual()
    # vecheck does exist but does not contain the correct output
    hpx.module.run_command = lambda x: (0, 'invalid output', '')
    assert hpx.get_virtual_facts() == {}


# Generated at 2022-06-11 05:53:45.749551
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """Test case for get_virtual_facts of class HPUXVirtual
    """
    hpux_virtual = HPUXVirtual()
    # Populate get_virtual_facts method's return stuff
    hpux_virtual.module.run_command = fake_run_command_get_virtual_facts
    hpux_virtual.module.run_command.return_code = 0
    hpux_virtual.module.run_command.stderr = ''
    hpux_virtual.module.run_command.stdout = "Running HPVM vPar\n" \
                      "Virtual Machine Management Daemon is running\n"
    # Populate virtual_facts dictionary
    virtual_facts = hpux_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'

# Generated at 2022-06-11 05:53:47.371418
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-11 05:53:54.985394
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Initialization of test variables
    vecheck_out = {'rc': 1, 'out': '', 'err': None}
    hpvminfo_out = {'rc': 1, 'out': '', 'err': None}
    parstatus_out = {'rc': 1, 'out': '', 'err': None}

    # Check for HP vPar as guest
    vecheck_out = {'rc': 0, 'out': '', 'err': None}
    hpvminfo_out = {'rc': 1, 'out': '', 'err': None}
    parstatus_out = {'rc': 1, 'out': '', 'err': None}
    hpux_virtual_obj = HPUXVirtual(None)

# Generated at 2022-06-11 05:53:56.298078
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual('')

    assert virtual._platform == 'HP-UX'


# Generated at 2022-06-11 05:53:56.977987
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    HPUXVirtualCollector()

# Generated at 2022-06-11 05:54:03.179904
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    from ansible.module_utils.facts.virtual.hpuxtestdata import output_hpux_vecheck_vecheck_rc_0, output_hpux_vecheck_rc_1, \
        output_hpux_hpvminfo_vecheck_rc_0, output_hpux_hpvminfo_rc_1, output_hpux_hpvminfo_rc_1_with_hpvm_guest, \
        output_hpux_hpvminfo_rc_1_with_hpvm_host, output_hpux_parstatus_rc_0, output_hpux_parstatus_rc_1

    import sys
    import json
    import os
    import mock


# Generated at 2022-06-11 05:55:15.271072
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # missing files
    hv = HPUXVirtual({})
    assert not hv.get_virtual_facts()

    # simulate an hpux virtualization host
    for f in ('/usr/sbin/parstatus', '/opt/hpvm/bin/hpvminfo'):
        hv = HPUXVirtual({'module_setup': {'command_defaults': {}}})
        hv.module.run_command = lambda x: (0, 'Running HPVM host', '')
        hv.module.get_bin_path = lambda x: f
        assert hv.get_virtual_facts()['virtualization_type'] == 'host'
        assert 'HPVM' in hv.get_virtual_facts()['virtualization_tech_host']

    # simulate an hpux virtualization guest on par

# Generated at 2022-06-11 05:55:17.093067
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    test_obj = HPUXVirtual({}, dict(), dict())
    assert test_obj
    assert test_obj.platform == 'HP-UX'

# Generated at 2022-06-11 05:55:22.244782
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    un_virt = HPUXVirtual()
    assert un_virt
    assert un_virt.platform == 'HP-UX'
    assert un_virt._platform == 'HP-UX'
    assert un_virt.get_virtual_facts() == {'virtualization_type': '',
                                           'virtualization_role': '',
                                           'virtualization_tech_guest': set(),
                                           'virtualization_tech_host': set()}

# Generated at 2022-06-11 05:55:23.998849
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict(module=dict()), dict())
    assert(virtual.platform == 'HP-UX')


# Generated at 2022-06-11 05:55:32.110965
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    class MockModule(object):
        def __init__(self, rc=0, out='', err=''):
            self.rc = rc
            self.out = out
            self.err = err

        def run_command(self, cmd):
            return (self.rc, self.out, self.err)

    class MockOS(object):
        def __init__(self, path=True):
            self.path = path

        def exists(self, path):
            return self.path

    module = MockModule()
    os = MockOS()

    # Test 1
    hpux_virt = HPUXVirtual(module)
    hpux_virt.os = os

    # Test 1.1
    os.path = True
    module.rc = 0
    module.out = "Running as HPVM vPar"

    #

# Generated at 2022-06-11 05:55:40.469350
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    print("Testing method get_virtual_facts of class HPUXVirtual")

    # Set up required mocks

    # Create a mock OS module
    import builtins
    builtins.__import_.side_effect = lambda name, globals=None, locals=None, fromlist=(), level=0: name
    # Mock the os module
    os = builtins.__import__('os')
    os.path.exists = lambda path: True
    os.uname = lambda: [1,2,3,4]
    # Mock the os.path module
    os.path = builtins.__import__('os.path')
    os.path.exists = lambda path: Tru

    # Create a mock command module
    import sys

# Generated at 2022-06-11 05:55:43.200864
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'

    hpux_virtual = HPUXVirtual(module=None)
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-11 05:55:45.887099
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(dict(module=dict()))
    assert hpux_virtual.module == dict()
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-11 05:55:47.837028
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    '''Unit test for constructor of class HPUXVirtual'''

    # Test with no args
    virtual = HPUXVirtual(None)
    assert virtual



# Generated at 2022-06-11 05:55:49.532550
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual_obj = HPUXVirtual({})
    assert hpux_virtual_obj.platform == "HP-UX"
