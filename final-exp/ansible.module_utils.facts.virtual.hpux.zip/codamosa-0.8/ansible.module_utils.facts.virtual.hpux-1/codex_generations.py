

# Generated at 2022-06-11 05:46:35.863825
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # Example data taken from "vecheck" command output
    virtual_facts = {
        'virtualization_type': 'guest',
        'virtualization_role': 'HP vPar',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(['HP vPar']),
    }

    hpux_virtual_collector = HPUXVirtual(dict(module=dict()), 'setup')
    assert hpux_virtual_collector.get_virtual_facts() == virtual_facts


# Generated at 2022-06-11 05:46:39.115281
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """Unit test for constructor of class HPUXVirtual"""
    hpx_virtual = HPUXVirtual(dict())
    assert hpx_virtual.platform == 'HP-UX'

if __name__ == '__main__':
    test_HPUXVirtual()

# Generated at 2022-06-11 05:46:41.017310
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.__class__.__name__ == "HPUXVirtual"

# Generated at 2022-06-11 05:46:42.565935
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual({})
    assert h.platform == 'HP-UX'


# Generated at 2022-06-11 05:46:50.661077
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import Virtual
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.basic import AnsibleModule
    import tempfile
    import os
    import sys
    module = AnsibleModule({},{})
    class FakeModule():
        def __init__(self):
            pass
        def run_command(self,cmd):
            if cmd == "uname -s":
                return 0,b"HP-UX", ""
            return 0,b"",

# Generated at 2022-06-11 05:46:52.178398
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    p = HPUXVirtual()
    assert p.platform == 'HP-UX'

# Generated at 2022-06-11 05:46:59.420088
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
        # Create an instance of class HPUXVirtual
        hp_virtual = HPUXVirtual()
        # Set these values to be returned by mock_run_command
        hp_virtual.module.run_command.return_value = (1,"ignored", "UNIX HPVM Guest")
        # Call method get_virtual_facts to unit test
        virtual_facts = hp_virtual.get_virtual_facts()
        # Assert if correct values are returned
        assert virtual_facts == {'virtualization_type': 'guest', 'virtualization_role': 'HPVM IVM',
                                 'virtualization_tech_host': set(), 'virtualization_tech_guest': {'HPVM IVM'}}


# Generated at 2022-06-11 05:47:04.962824
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    vp = HPUXVirtual({})
    assert vp.platform == 'HP-UX'
    assert vp.guest_tech == set()
    assert vp.host_tech == set()
    assert 'virtualization_type' not in vp.virtual_facts
    assert 'virtualization_role' not in vp.virtual_facts
    assert 'virtualization_technologies_host' not in vp.virtual_facts
    assert 'virtualization_technologies_guest' not in vp.virtual_facts

# Generated at 2022-06-11 05:47:14.217497
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.test.test_hp_ux import VirtualRunnerHpux
    from ansible.module_utils.facts.virtual.test.test_hp_ux import VirtualDependencies
    import ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts.virtual.hp_ux as hp_ux
    import ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts.virtual.hp_ux as hp_ux_virtual
    import ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts.virtual.hp_ux as hp_ux_collector
    hp_ux_virtual.HPUXVirtual = VirtualRunnerHpux
    hp_ux.hpux_virtual = hp_ux_virtual

# Generated at 2022-06-11 05:47:16.372364
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpxvirtual = HPUXVirtual(None)
    assert hpxvirtual.platform == 'HP-UX'
    assert hpxvirtual.get_virtual_facts() == {}

# Generated at 2022-06-11 05:47:26.370348
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual(dict())
    assert h.platform == 'HP-UX'

# Generated at 2022-06-11 05:47:27.399663
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict())
    assert virtual.platform == 'HP-UX'

# Generated at 2022-06-11 05:47:35.731058
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import get_module_class
    from ansible.module_utils.facts.virtual.collector import VirtualCollector
    from ansible.module_utils.facts import ModuleDataCollector
    # pylint: disable=unused-variable
    class MockModule(object):
        def __init__(self):
            pass

        def run_command(self, command):
            if command == '/usr/sbin/vecheck':
                return 0, '', ''
            if command == '/opt/hpvm/bin/hpvminfo':
                return 0, '', ''
            if command == '/usr/sbin/parstatus':
                return 0, '', ''

    module = MockModule()
    module.get_bin_path = lambda p: p

# Generated at 2022-06-11 05:47:44.237085
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = MockAnsibleModule("ansible.module_utils.facts.virtual.hpux.hpux.HPUXVirtual")
    module.run_command = MockRunCommand()
    hpux_virtual = HPUXVirtual(module)
    assert hpux_virtual.platform == 'HP-UX'
    hpux_virtual.get_virtual_facts()
    assert hpux_virtual.virtual_facts['virtualization_type'] == 'guest'
    assert hpux_virtual.virtual_facts['virtualization_role'] == 'HP vPar'
    assert hpux_virtual.virtual_facts['virtualization_tech_host'] == set()
    assert hpux_virtual.virtual_facts['virtualization_tech_guest'] == {'HP vPar'}


# mock class for class MockAnsibleModule

# Generated at 2022-06-11 05:47:45.689723
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_fact = HPUXVirtual()
    assert virtual_fact is not None


# Generated at 2022-06-11 05:47:54.185923
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    def get_module_mock(name, args):
        class RunCommandMock():
            def __init__(self, name, args):
                self.name = name
                self.args = args

            def run_command(self, arg):
                if 'vecheck' in arg:
                    if 'host' in self.args:
                        rc = 1
                    else:
                        rc = 0
                    out = ''
                    err = ''
                elif 'hpvminfo' in arg:
                    if 'HPVM vPar' in self.args:
                        rc = 0
                        out = 'Running HPVM vPar guest'
                        err = ''
                    elif 'HPVM guest' in self.args:
                        rc = 0
                        out = 'Running HPVM guest'
                        err = ''

# Generated at 2022-06-11 05:48:00.052071
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec=dict())
    virt_inst = HPUXVirtual(module)
    virtual_facts = virt_inst.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'host'
    assert virtual_facts['virtualization_role'] == 'HPVM'
    assert 'HPVM' in virtual_facts['virtualization_tech_host']
    assert 'HPVM IVM' in virtual_facts['virtualization_tech_guest']
    assert 'HPVM vPar' in virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-11 05:48:02.264122
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    '''Unit test for constructor of HPUXVirtual class'''
    hpux_virtual_obj = HPUXVirtual(None)
    hpux_virtual_obj.get_virtual_facts()

# Generated at 2022-06-11 05:48:10.865643
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    def mock_run_command(self, args, check_rc=True):
        commands = {
            "/usr/sbin/vecheck": (0, "VirtualPartition(VP)", ""),
            "/opt/hpvm/bin/hpvminfo": (0, "Running in HPVM vPar", "")
        }
        return commands.get(args, (0, "", ""))

    hpx = HPUXVirtual()
    hpx.module = type('', (), {})()
    hpx.module.run_command = mock_run_command

    virtual_facts = hpx.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HPVM vPar'

# Generated at 2022-06-11 05:48:12.509885
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_hpux = HPUXVirtual({})
    assert virtual_hpux.platform == 'HP-UX'

# Generated at 2022-06-11 05:48:29.941458
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = DummyModule(
        stdout='guest\nhost\n',
        rc=0
    )
    mod_path = 'ansible.module_utils.facts.virtual.hpux.HPUXVirtual'
    with mock.patch(mod_path, module):
        virtual = HPUXVirtual()
        virtual_facts = virtual.get_virtual_facts()
        assert virtual_facts['virtualization_type'] == "guest"
        assert virtual_facts['virtualization_role'] == "HPVM IVM"
        assert virtual_facts['virtualization_tech_guest'] == {'HPVM IVM', 'HPVM'}
        assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-11 05:48:33.261836
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual({}, {})
    assert v.platform == 'HP-UX'
    assert v.name == 'HP-UX'
    assert v.virtualization_type is None
    assert v.virtualization_role is None

# Generated at 2022-06-11 05:48:36.982059
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({}, {})
    assert hv.__class__.__name__ == 'HPUXVirtual'
    assert hv.platform == 'HP-UX'
    assert hv.virtualization_type is None
    assert hv.virtualization_role is None

# Generated at 2022-06-11 05:48:39.513401
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpuxv = HPUXVirtual({})
    assert hpuxv.platform == 'HP-UX'
    assert hpuxv.get_virtual_facts() == {}
    assert hpuxv.collect() == {}

# Generated at 2022-06-11 05:48:42.882857
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(dict(module=dict()))
    assert hv.platform == 'HP-UX'
    assert 'module' in hv.module
    assert hv.module['module'] == dict()
    assert not hv.virtual_facts
    assert not hv.all_facts


# Generated at 2022-06-11 05:48:44.039072
# Unit test for method get_virtual_facts of class HPUXVirtual

# Generated at 2022-06-11 05:48:48.824412
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict(), dict())
    assert virtual_facts.__class__.__name__ == 'HPUXVirtual'
    assert virtual_facts.virtualization_type == 'guest'
    assert virtual_facts.virtualization_role == 'HP vPar'
    # Unit test for constructor of class HPUXVirtualCollector
    test_HPUXVirtualCollector()



# Generated at 2022-06-11 05:48:51.254820
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts._platform == 'HP-UX'
    assert virtual_facts._fact_class == HPUXVirtual

# Generated at 2022-06-11 05:48:51.766625
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual()

# Generated at 2022-06-11 05:48:53.523423
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virt = HPUXVirtual()
    assert hpux_virt.platform == 'HP-UX'


# Generated at 2022-06-11 05:49:17.650761
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    virt = HPUXVirtual(dict())
    virt.module = MockModule()
    virt.get_virtual_facts()
    assert virt.facts['virtualization_type'] == 'guest'
    assert virt.facts['virtualization_role'] == 'HP vPar'
    assert virt.facts['virtualization_tech_guest'] == set(['HP vPar'])
    assert virt.facts['virtualization_tech_host'] == set()


# Generated at 2022-06-11 05:49:19.372188
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual(dict(module=dict()))
    assert virtual_obj.platform == 'HP-UX'

# Generated at 2022-06-11 05:49:21.676750
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = AnsibleModule(argument_spec={})
    virtual_facts_obj = HPUXVirtual(module)
    assert virtual_facts_obj.platform == "HP-UX"

# Generated at 2022-06-11 05:49:23.498918
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpxvirtual = HPUXVirtual()
    assert hpxvirtual.get_virtual_facts()['virtualization_tech_host'] == set()


# Generated at 2022-06-11 05:49:25.168225
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    fact_class = HPUXVirtual(dict(), dict())
    assert fact_class.platform == 'HP-UX'



# Generated at 2022-06-11 05:49:32.599238
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import ansible.module_utils.facts.virtual.hpux
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.virtual.base
    import ansible.module_utils.facts.virtual.hpar

    def run_command(module, command):
        return (1, '', '')

    def fail_json(module, msg):
        return

    class ModuleStub():
        _ansible_module_instance = True
        params = {}
        fail_json = fail_json
        run_command = run_command

    mod = ModuleStub()
    mod.params = {}
    ansible.module_utils.facts.virtual.hpux.module = mod
    ansible.module_utils.facts.virtual.module = mod
    ansible.module_utils.facts.virtual.base

# Generated at 2022-06-11 05:49:35.160731
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():

    # set module
    module = None

    # create instance of class HP-UXVirtual
    hvx = HPUXVirtual(module)

    # check if platform is HP-UX
    assert hvx.platform == 'HP-UX'


# Generated at 2022-06-11 05:49:36.686860
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-11 05:49:44.099306
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    mock_module = type('MockModule', (object,), {'run_command': MockRunCommand})
    mock_module.run_command.out = [
        '', '', '',
        """HPVM: Running as a HPVM guest
        This HPVM guest does not support virtual switching
        """, 'HPVM: Running as a HPVM host'
        ]
    mock_module.run_command.rc = [0, 0, 2, 0, 0]
    virtual = HPUXVirtual(mock_module)

    expected_guest_tech = set(['HPVM IVM'])
    expected_host_tech = set(['HPVM'])

# Generated at 2022-06-11 05:49:45.404519
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict(), dict())
    assert virtual.platform == 'HP-UX'

# Generated at 2022-06-11 05:50:46.251342
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_hpux = HPUXVirtual()
    assert virtual_hpux.platform == 'HP-UX'
    assert not virtual_hpux.virtual

# Generated at 2022-06-11 05:50:51.769328
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux.hpux import HPUXVirtual
    h = HPUXVirtual({'module_setup': False})

    result = h.get_virtual_facts()

    assert result['virtualization_type'] == 'guest'
    assert result['virtualization_role'] == 'HPVM IVM'
    assert result['virtualization_tech_host'] == set(['HPVM'])
    assert result['virtualization_tech_guest'] == set(['HPVM IVM'])

# Generated at 2022-06-11 05:50:53.109238
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    obj = HPUXVirtual()
    assert obj.platform == 'HP-UX'



# Generated at 2022-06-11 05:50:54.807859
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt = HPUXVirtual()
    if virt is None:
        raise AssertionError("Failed to create HPUX virtualization fact class")

# Generated at 2022-06-11 05:51:02.903890
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    hv = HPUXVirtual()

    # Test when output of /usr/sbin/vecheck contains 'Running virtualized'
    rc, out, err = hv.module.run_command.mock_calls[0][1][0]
    assert rc == 0 and out == 'Running virtualized'
    virtual_facts = hv.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    assert virtual_facts['virtualization_tech_guest'] == set(['HP vPar'])
    assert virtual_facts['virtualization_tech_host'] == set()

    # Test when output of /usr/sbin/vecheck doesn't contain 'Running virtualized'
    rc, out, err = hv.module

# Generated at 2022-06-11 05:51:08.370426
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    hpux_virtual = HPUXVirtual(dict(module=None))
    virtual_facts = hpux_virtual.get_virtual_facts()
    if 'virtualization_type' in virtual_facts:
        assert virtual_facts['virtualization_type'] in ['guest', 'host']
        assert virtual_facts['virtualization_role'] in ['HP vPar', 'HPVM vPar', 'HPVM IVM', 'HPVM', 'HP nPar']

# Generated at 2022-06-11 05:51:10.293626
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual({})
    hpux_virtual.get_virtual_facts()

# Generated at 2022-06-11 05:51:15.266427
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    hpux_virtual_collector = HPUXVirtualCollector()
    virtual_facts = hpux_virtual_collector.collect(None, None)
    assert isinstance(virtual_facts, dict)
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-11 05:51:17.358921
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    my_obj = HPUXVirtual(dict(module=None))
    platform =  'HP-UX'
    assert my_obj.platform == platform


# Generated at 2022-06-11 05:51:18.842199
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hw = HPUXVirtual({})
    assert(isinstance(hw, HPUXVirtual))

# Generated at 2022-06-11 05:52:20.796083
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    virtual_facts.populate()
    assert type(virtual_facts.virtual) == dict

# Generated at 2022-06-11 05:52:28.172327
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class MockModule():
        def __init__(self):
            self.run_command = Mock(return_value=(0, 'Successfull', ''))

    class MockFactCollector():
        def __init__(self):
            self.module = MockModule()

        def get_all(self):
            return {}

    class MockHPUXVirtual(HPUXVirtual):
        def __init__(self):
            self.module = MockFactCollector().module
            super(HPUXVirtual, self).__init__()

    # Test for /usr/sbin/vecheck
    setattr(HPUXVirtual, 'os_path_exists', Mock(side_effect=[True, False]))

# Generated at 2022-06-11 05:52:37.370957
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    m = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )

    h = HPUXVirtual(m)

    # Unit test for method get_virtual_facts of class HPUXVirtual
    # Check if no virtualization_type or virtualization_role values are set
    # Check empty set for virtualization_tech_guest and virtualization_tech_host
    virtual_facts = h.get_virtual_facts()
    assert 'virtualization_role' not in virtual_facts
    assert 'virtualization_type' not in virtual_facts
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set

# Generated at 2022-06-11 05:52:46.333164
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Arrange:
        Mock module
    Act:
        Invoke get_virtual_facts() of class HPUXVirtual
    Assert:
        Correct virtual facts are returned
    """
    vm = HPUXVirtual(None, None)
    vm.module = MagicMock()
    vm.module.run_command.return_value = (0, '', '')

    assert vm.get_virtual_facts() == {}

    vm.module.run_command.return_value = (0, '', '')
    os.path.exists.side_effect = [True, True]
    vm.module.run_command.return_value = (0, '', '')

# Generated at 2022-06-11 05:52:48.403527
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpuxvirtual = HPUXVirtual({},{},{})
    assert hpuxvirtual.platform == 'HP-UX'

# Generated at 2022-06-11 05:52:51.341333
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual({})
    assert hpux_virtual.platform == 'HP-UX'
    assert 'virtualization_role' not in hpux_virtual.get_virtual_facts()


# Generated at 2022-06-11 05:52:53.777637
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = AnsibleModule(argument_spec={})
    v = HPUXVirtual(module=module)
    assert v.platform == 'HP-UX'



# Generated at 2022-06-11 05:53:03.861280
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import ModuleStub
    from ansible.module_utils.facts.virtual.hpxux import HPUXVirtual
    from ansible.module_utils.facts.is_hpux import IsHPUXModule

    def run_command(*args, **kwargs):
        if args[0] == '/usr/sbin/vecheck':
            return 0, '', ''
        elif args[0] == '/opt/hpvm/bin/hpvminfo':
            return 0, 'Running HPVM guest', ''
        elif args[0] == '/usr/sbin/parstatus':
            return 0, '', ''
        else:
            return 1, '', ''

    def exists(*args, **kwargs):
        if args[0] == '/usr/sbin/vecheck':
            return

# Generated at 2022-06-11 05:53:07.636048
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(None)
    assert hpux_virtual._platform == 'HP-UX'
    assert hpux_virtual._fact_class == HPUXVirtual
    assert hpux_virtual._collector_platforms == ['HP-UX']



# Generated at 2022-06-11 05:53:16.875471
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    facts = {}
    module = {}
    module['run_command'] = lambda *args, **kwargs: (0, '', '')
    assert HPUXVirtual(module).get_virtual_facts() == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}
    module['run_command'] = lambda *args, **kwargs: (1, '', '')
    assert HPUXVirtual(module).get_virtual_facts() == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}
    module['run_command'] = lambda *args, **kwargs: (0, 'Invalid', '')
    assert HPUXVirtual(module).get_virtual_facts()

# Generated at 2022-06-11 05:54:12.511620
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    virtual_facts = {}
    module = MockModule()

    hpuxvirtual = HPUXVirtual(module)
    virtual_facts = hpuxvirtual.get_virtual_facts()
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

# returns a Mock module

# Generated at 2022-06-11 05:54:17.938908
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual, HPUXVirtualCollector
    module = basic.AnsibleModule(argument_spec={})

    if module._socket_path:
        connection = Connection(module._socket_path)
        fc = HPUXVirtualCollector(module=module, connection=connection)
    else:
        fc = HPUXVirtualCollector(module=module)
    f = fc.fetch_facts()
    assert isinstance(f, dict)
    assert 'virtualization_type' in f
    assert 'virtualization_role' in f

# Generated at 2022-06-11 05:54:19.554817
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    hpux_virtual.get_virtual_facts()
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-11 05:54:26.108529
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    v = HPUXVirtual()
    v.module = MockModule()

    v.module.run_command.return_value = (0, 'Running in HPVM guest', '')
    assert v.get_virtual_facts() == {
        'virtualization_type' : 'guest',
        'virtualization_role' : 'HPVM IVM',
        'virtualization_tech_host' : set(),
        'virtualization_tech_guest' : set(['HPVM'])
    }
    v.module.run_command.return_value = (0, 'Running in HPVM vPar HPVM guest', '')

# Generated at 2022-06-11 05:54:32.933400
# Unit test for method get_virtual_facts of class HPUXVirtual

# Generated at 2022-06-11 05:54:34.734692
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpu = HPUXVirtual()
    if hpu == None:
        raise AssertionError('constructor of class HPUXVirtual failed to return an object instance')


# Generated at 2022-06-11 05:54:43.451096
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    from ansible.module_utils.facts import FactCollector
    facts_module = FactCollector(None, module_args={})
    virtual_facts.populate(facts_module)
    assert set(virtual_facts.virtual_facts) == set(['virtualization_type', 'virtualization_role',
                                                    'virtualization_tech_guest', 'virtualization_tech_host'])
    assert virtual_facts.virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts.virtual_facts['virtualization_role'] == 'HP vPar'
    assert virtual_facts.virtual_facts['virtualization_tech_guest'] == set(['HP vPar', 'HP nPar'])
    assert virtual_facts.virtual_facts['virtualization_tech_host']

# Generated at 2022-06-11 05:54:45.483459
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpx = HPUXVirtual()
    assert hpx.platform == 'HP-UX'


# Generated at 2022-06-11 05:54:48.793099
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual({'hwpack': 'hpux'})
    assert hpux_virtual.virtual_facts['virtualization_type'] == 'host'
    assert hpux_virtual.virtual_facts['virtualization_role'] == 'HPVM'
    assert len(hpux_virtual.virtual_facts['virtualization_tech_guest']) == 3
    assert len(hpux_virtual.virtual_facts['virtualization_tech_host']) == 0

# Generated at 2022-06-11 05:54:49.668175
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt = HPUXVirtual(None)
    assert virt.platform == 'HP-UX'