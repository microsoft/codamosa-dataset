

# Generated at 2022-06-11 05:46:37.192817
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})

    assert hv.virtualization_type == 'host', 'constructor should set virtualization_type to "host"'
    assert hv.virtualization_role == 'host', 'constructor should set virtualization_role to "host"'
    assert hv.virtualization_tech_host == set(['HPVM']), 'constructor should set virtualization_tech_host to "HPVM"'
    assert hv.virtualization_tech_guest == set(['HPVM']), 'constructor should set virtualization_tech_guest to "HPVM"'

# Generated at 2022-06-11 05:46:44.529361
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """ this test for HP-UX Virtual facts
    """
    module = AnsibleModule(argument_spec={})
    virtual_obj = HPUXVirtual()
    virtual_obj.module = module
    virtual_obj.populate()
    assert 'virtualization_type' in virtual_obj.facts
    assert 'virtualization_role' in virtual_obj.facts
    assert 'virtualization_tech_guest' in virtual_obj.facts
    assert 'virtualization_tech_host' in virtual_obj.facts


if __name__ == '__main__':
    from ansible.module_utils.basic import *  # pylint: disable=no-name-in-module,import-error,redefined-builtin
    main()

# Generated at 2022-06-11 05:46:48.195271
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'
    assert virtual_facts.virtualization_type == 'guest'
    assert virtual_facts.virtualization_role == 'HP vPar'
    assert virtual_facts.virtualization_tech == 'HP vPar'


# Generated at 2022-06-11 05:46:53.027094
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    v = HPUXVirtual()
    v.module = DummyAnsibleModule()
    v.module.run_command = run_command_mock
    v.platform = 'HP-UX'
    v.get_virtual_facts()
    assert v.facts['virtualization_type'] == 'guest'
    assert v.facts['virtualization_role'] == 'HPVM IVM'


# Unit test with mocks

# Generated at 2022-06-11 05:47:00.269683
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = FakeModule('/usr/sbin/vecheck', '/opt/hpvm/bin/hpvminfo', '/usr/sbin/parstatus')
    v = HPUXVirtual(module)
    assert v.module == module
    assert v.platform == 'HP-UX'
    assert v.virtualization_type == 'guest'
    assert v.virtualization_role == 'HP vPar'
    assert v.virtualization_tech_guest == set(['HP vPar'])
    assert v.virtualization_tech_host == set()
    assert v.virtualization == 'guest'
    assert v.virtualization_full == 'guest (HP vPar)'



# Generated at 2022-06-11 05:47:09.574872
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import FactCollector
    import os
    import shutil
    import tempfile

# Generated at 2022-06-11 05:47:10.705725
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hin = HPUXVirtual(dict())
    assert hin.platform == Virtual.platform

# Generated at 2022-06-11 05:47:12.962400
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = AnsibleModule(argument_spec={})
    virtual_facts = HPUXVirtual(module)
    virtual_facts.collect()
    assert module.exit_json.called

# Generated at 2022-06-11 05:47:14.961828
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts_collection = HPUXVirtual()
    assert virtual_facts_collection.platform == "HP-UX"



# Generated at 2022-06-11 05:47:16.706054
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual("module", "module.run_command")
    assert h.platform == 'HP-UX'


# Generated at 2022-06-11 05:47:28.518495
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict())
    assert virtual
    assert virtual.platform == 'HP-UX'



# Generated at 2022-06-11 05:47:30.241177
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'
    assert virtual_facts.module is not None

# Generated at 2022-06-11 05:47:31.696521
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux = HPUXVirtual({})
    assert hpux.platform == 'HP-UX'


# Generated at 2022-06-11 05:47:40.201160
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    module = basic.AnsibleModule(
        argument_spec=dict()
    )
    module.run_command = lambda *args: (0, b'', b'')
    module.exit_json = lambda **kargs: None

    virtual = HPUXVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    virtual_tech = virtual_facts['virtualization_tech_guest']
    assert 'HP vPar' in virtual_tech
    assert 'HPVM vPar' not in virtual_tech
    assert 'HPVM IVM' not in virtual_

# Generated at 2022-06-11 05:47:41.469965
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpx = HPUXVirtual()
    assert hpx is not None

# Generated at 2022-06-11 05:47:43.499574
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # run constructor
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == "HP-UX"


# Generated at 2022-06-11 05:47:50.723913
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """ Unit test for method get_virtual_facts of class HPUXVirtual """
    module = type('Module', (), {})()
    module.run_command = run_command
    if_facts_dict = HPUXVirtual(module).get_virtual_facts()
    assert if_facts_dict['virtualization_tech_host'] == set()
    assert if_facts_dict['virtualization_tech_guest'] == {'HP nPar', 'HP vPar'}
    assert if_facts_dict['virtualization_type'] == 'guest'
    assert if_facts_dict['virtualization_role'] == 'HP vPar'


# Stub of AnsibleModule.run_command

# Generated at 2022-06-11 05:47:52.984850
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'
    assert virtual_facts.get_virtual_facts() == {}

# Generated at 2022-06-11 05:48:00.957127
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_obj = HPUXVirtual({}, {}, {}, {})
    test_obj.module.run_command = MagicMock(return_value=(0, 'stdout', 'stderr'))
    os.path.exists = MagicMock(return_value=True)

    expected_dict = {'virtualization_type': 'guest',
                     'virtualization_role': 'HP vPar',
                     'virtualization_tech_guest': {'HP vPar'},
                     'virtualization_tech_host': set()}
    assert test_obj.get_virtual_facts() == expected_dict


# Generated at 2022-06-11 05:48:02.513671
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual({})
    assert virtual.platform == 'HP-UX'


# Generated at 2022-06-11 05:48:28.694859
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual_object = HPUXVirtual(dict())
    assert hpux_virtual_object.platform == 'HP-UX'


# Generated at 2022-06-11 05:48:32.971064
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():

    v = HPUXVirtual()

    assert v.platform is 'HP-UX'
    assert v.virtualization_type is None
    assert v.virtualization_role is None
    assert v.virtualization_tech_guest is None
    assert v.virtualization_tech_host is None


# Generated at 2022-06-11 05:48:41.842844
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class TestModule:
        def run_command(self, cmd):
            if cmd == "/usr/sbin/vecheck":
                out = "vecheck: INFO: A vPar is present on this system\n"
                return 0, out, None
            elif cmd == "/opt/hpvm/bin/hpvminfo":
                out = "Running in HPVM vPar 1.1.0"
                return 0, out, None
            elif cmd == "/usr/sbin/parstatus":
                out = "ISL Mode:  Dual Virtualized Partition\n"
                return 0, out, None
            else:
                return 1, None, None

    class TestAnsibleModule:
        def __init__(self):
            self.run_command = TestModule().run_command
            self.params = None

# Generated at 2022-06-11 05:48:45.537111
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class HPUXVirtual.
    """
    module = AnsibleModule(argument_spec={})
    obj = HPUXVirtualCollector(module=module)
    output = obj.get_virtual_facts()
    # Change assert with appropriate comparision
    assert(output)



# Generated at 2022-06-11 05:48:54.779901
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import HPUXVirtual

    TEST_HPUX_INSTALLED = {
        'virtualization_tech_host': ['HPVM host'],
        'virtualization_tech_guest': ['HP vPar', 'HPVM guest', 'HP nPar'],
        'virtualization_type': 'guest',
        'virtualization_role': 'HP nPar'}

    TEST_HPUX_NONE = {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()}

    virtual = HPUXVirtual({})
    is_installed = False

# Generated at 2022-06-11 05:49:03.025500
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class ModuleMock:
        def run_command(self, command):
            if command == '/usr/sbin/vecheck':
                return (0, '1\n', '')
            elif command == '/opt/hpvm/bin/hpvminfo':
                return (0, 'Running HPVM vPar\n', '')
            elif command == '/usr/sbin/parstatus':
                return (0, '', '')
            else:
                return (1, '', '')

    m = ModuleMock()
    virtual = HPUXVirtual(m)
    facts = virtual.get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HPVM vPar'

# Generated at 2022-06-11 05:49:10.465388
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

  # vecheck not exists, hpvminfo not exists, parstatus not exists
  file_dict = {'/usr/sbin/vecheck': False,
               '/opt/hpvm/bin/hpvminfo': False,
               '/usr/sbin/parstatus': False}
  def fake_path_exists(path):
    return file_dict[path]

  module = Mock(run_command=lambda x: (0, '', ''), check_mode=False)
  module.run_command = Mock(return_value=(0, '', ''))
  hpuxvirtual_obj = HPUXVirtual(module)

# Generated at 2022-06-11 05:49:14.785152
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts_dict = HPUXVirtual(dict())
    assert virtual_facts_dict
    assert virtual_facts_dict.platform == "HP-UX"
    assert virtual_facts_dict.get_virtual_facts() ==  {'virtualization_type': None,
                                                       'virtualization_role': None,
                                                       'virtualization_tech_guest': set(),
                                                       'virtualization_tech_host': set()
                                                      }


# Generated at 2022-06-11 05:49:16.029588
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv is not None
    assert hv._platform == 'HP-UX'

# Generated at 2022-06-11 05:49:24.603984
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpar import HPUXVirtualCollector, HPUXVirtual
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.facts.collector import BaseFactCollector

    class MockHPUXVirtual(HPUXVirtual):
        """
        This is a mockup subclass of HPUXVirtual. Its methods all
        return their input value.
        """
        def __init__(self, *args, **kwargs):
            super(MockHPUXVirtual, self).__init__(*args, **kwargs)

        @property
        def get_virtual_facts(self):
            return self._get_virtual_facts()


# Generated at 2022-06-11 05:50:00.523883
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    # Create instance of class HPUXVirtual
    hpux_virtual_inst = HPUXVirtual({})

    # Patch method run_command
    hpux_virtual_inst.run_command = patch_run_command

    # Test for method get_virtual_facts
    result = hpux_virtual_inst.get_virtual_facts()
    assert result['virtualization_type'] == 'host'
    assert result['virtualization_role'] == 'HPVM'
    assert result['virtualization_tech_host'] == {'HPVM'}



# Generated at 2022-06-11 05:50:05.958886
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    hvirtual = HPUXVirtual()
    hvirtual.module.run_command = fake_run_command
    hvirtual_facts = hvirtual.get_virtual_facts()
    assert hvirtual_facts
    assert hvirtual_facts['virtualization_type'] == 'guest'
    assert hvirtual_facts['virtualization_role'] == 'HPVM vPar'
    assert hvirtual_facts['virtualization_tech_guest'] == {'HPVM vPar'}
    assert hvirtual_facts['virtualization_tech_host'] == set()


# Generated at 2022-06-11 05:50:14.268617
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Test a hypervisor returns the expected facts
    facts = {'ansible_facts': {'virtualization_type': 'host',
                               'virtualization_role': 'HPVM',
                               'virtualization_tech_host': frozenset(['HPVM']),
                               'virtualization_tech_guest': frozenset(),
                               'virtualization_full': {'virtualization_type': 'host',
                                                       'virtualization_role': 'HPVM',
                                                       'virtualization_tech_host': frozenset(['HPVM']),
                                                       'virtualization_tech_guest': frozenset()}
                               }}
    fake_module = FakeHPVMHostModule()
    v = HPUXVirtual(fake_module)
    virtual_facts = v.get_virtual_facts()
    assert virtual

# Generated at 2022-06-11 05:50:15.648273
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual("test_module")
    assert 'HP-UX' == virtual_facts.platform

# Generated at 2022-06-11 05:50:23.611603
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux = HPUXVirtual()
    # initialize HPUXVirtual with empty paramters
    assert hpux.virtualization_type == ''
    assert hpux.virtualization_role == ''
    assert hpux.virtualization_tech_guest == set()
    assert hpux.virtualization_tech_host == set()
    # initialize HPUXVirtual with predefined parameters
    hpux.virtualization_type = 'guest'
    hpux.virtualization_role = 'HPVM vPar'
    hpux.virtualization_tech_guest = set(['HPVM'])
    hpux.virtualization_tech_host = set(['HPVM'])
    # test attributes of class HPUXVirtual
    assert hpux.virtualization_type == 'guest'

# Generated at 2022-06-11 05:50:31.653051
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class HPUXVirtual
    """

    import ansible.module_utils.facts.virtual.hpx
    import ansible.module_utils.facts.virtual.base
    import ansible.module_utils.facts.virtual.collector

    module_mock = ansible.module_utils.facts.virtual.base.AnsibleModule
    module_mock.run_command = lambda x: (0, "", "")

    module = ansible.module_utils.facts.virtual.base.AnsibleModule(
        argument_spec={})

    vm = ansible.module_utils.facts.virtual.hpx.HPUXVirtual(module)

    # vecheck file exists, expects HP vPar on HP-UX
    os.path.exists = lambda x: True
   

# Generated at 2022-06-11 05:50:33.628710
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux = HPUXVirtual(dict(module=dict()))
    assert hpux
    assert hpux.platform == 'HP-UX'



# Generated at 2022-06-11 05:50:36.107665
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv is not None
    assert hv.platform == 'HP-UX'
    assert hv.module is not None


# Generated at 2022-06-11 05:50:37.242361
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual(dict())
    assert h.platform == 'HP-UX'

# Generated at 2022-06-11 05:50:42.485198
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_module = type('TestModule', (object,), {'run_command': run_command})
    test_instance = HPUXVirtual(test_module)
    facts = test_instance.get_virtual_facts()
    assert facts['virtualization_tech_guest'] == set(['HP nPar'])
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP nPar'


# Generated at 2022-06-11 05:51:16.644034
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import ModuleStub

    test_module = ModuleStub(dict(
        command_defaults=dict(path=dict(
            bsd="/usr/bin:/bin:/usr/sbin:/sbin",
            hpux="/usr/bin:/opt/local/bin:/opt/local/sbin:/bin:/usr/bin:/sbin:/usr/sbin"
        )),
        ANSIBLE_MODULE_ARGS=dict(
            gather_subset='all'
        )
    ))

    hpux_virtual = HPUXVirtual(test_module)
    facts = hpux_virtual.get_virtual_facts()

    assert len(facts) == 3
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts

# Generated at 2022-06-11 05:51:24.161365
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts import ModuleStub
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual import VirtualCollector

    module = ModuleStub(dict(
        command='command',
        run_command=lambda x, **kwargs: (0, 'stdout', 'stderr'),
    ))
    HPUXVirtualCollector(module=module)

    assert isinstance(HPUXVirtualCollector._fact_class, HPUXVirtual)
    assert HPUXVirtualCollector._platform == 'HP-UX'
    assert isinstance(HPUXVirtualCollector, VirtualCollector)


# Generated at 2022-06-11 05:51:33.023082
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import os
    from ansible.module_utils.facts.virtual.hpux_virtual import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux_virtual import HPUXVirtualCollector

    def run_command_mock(command, module):
        p = re.compile('/usr/sbin/vecheck')
        s = re.compile('/opt/hpvm/bin/hpvminfo')
        t = re.compile('/usr/sbin/parstatus')
        if p.match(command):
            return (0, '', '')
        elif s.match(command):
            return (0, 'Running as a HPVM guest', '')
        elif t.match(command):
            return (0, '', '')

    guest_tech = set()
    host

# Generated at 2022-06-11 05:51:40.560414
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Initialise mocks for class HPUXVirtual
    HPUXVirtual_mock = HPUXVirtual()

    # Initialise return values for mocks
    if os.path.exists('/usr/sbin/vecheck'):
        rc, out, err = 0, 'Running HP nPar', ''
    else:
        rc, out, err = 1, '', ''
    HPUXVirtual_mock.module.run_command.return_value = (rc, out, err)

    if os.path.exists('/opt/hpvm/bin/hpvminfo'):
        rc, out, err = 0, 'Running HPVM guest', ''
    else:
        rc, out, err = 1, '', ''

# Generated at 2022-06-11 05:51:44.467596
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # Following should create object of class HPUXVirtual
    hpux_virtual = HPUXVirtual(dict(module=dict()))
    assert hpux_virtual.platform == 'HP-UX'
    assert hpux_virtual.module == dict()
    assert hpux_virtual.virtualization_type is None
    assert hpux_virtual.virtualization_role is None

# Generated at 2022-06-11 05:51:54.503794
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = {"run_command": {"side_effect": [
        (0, "Running HPVM vPar guest\n", ""),
        (0, "Running HPVM vPar\n", ""),
        (1, "", ""),
        (0, "nPar: yes", ""),
        (1, "", ""),
        (0, "running vpar", "")
    ]}}
    hv_obj = HPUXVirtual(module)
    assert hv_obj.get_virtual_facts() == {
        'virtualization_type': 'guest',
        'virtualization_role': 'HPVM vPar',
        'virtualization_tech_guest': set(['HPVM vPar']),
        'virtualization_tech_host': set(),
    }

# Generated at 2022-06-11 05:52:02.898638
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import tempfile
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch

    module = tempfile.NamedTemporaryFile()

    # side effects of mock_module
    mock_module = patch.multiple(HPUXVirtual,
                                 module=module,
                                 run_command=lambda *args, **kwargs: (0, '', ''),
                                 )

    mock_module.start()
    hpux_virtual = HPUXVirtual()
    hpux_virtual.get_virtual_facts()
    assert hpux_virtual.virtual_facts['virtualization_type'] == 'guest'
    assert hpux_virtual.virtual_facts['virtualization_role'] == 'HP vPar'
    assert hpux_virtual.virtual_facts['virtualization_tech_guest'] == set

# Generated at 2022-06-11 05:52:04.739359
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    x = HPUXVirtual(dict(ANSIBLE_MODULE_ARGS={}), None)
    assert x


# Generated at 2022-06-11 05:52:07.685229
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual_ = HPUXVirtual()
    assert hpux_virtual_.platform == 'HP-UX'
    assert hpux_virtual_._platform == 'HP-UX'

# Generated at 2022-06-11 05:52:10.068113
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v1 = HPUXVirtual({})
    assert v1.platform == 'HP-UX'



# Generated at 2022-06-11 05:52:52.496859
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-11 05:53:02.387595
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import hpux
    from ansible.module_utils.facts import ModuleStub
    from ansible.module_utils.facts import CommandStubber

    module = ModuleStub()
    command = CommandStubber(module)

    if hpux.HPUXVirtual.get_virtual_facts(HPUXVirtual(module)):
        assert hpux.HPUXVirtual.get_virtual_facts(HPUXVirtual(module)) == {'virtualization_type': 'guest', 'virtualization_role': 'HP vPar'}

    command.stub('/usr/sbin/vecheck', out = "Running on HP vPar with parid 1")

# Generated at 2022-06-11 05:53:04.253861
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()

    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-11 05:53:13.971747
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    hpux_virtual = HPUXVirtual()
    hpux_virtual.module = Mock()
    # Run on HPVM host
    setattr(hpux_virtual.module, 'run_command', Mock(return_value=(0, '/opt/hpvm/bin/hpvminfo: Running HPVM host version 6.0.0.13', None)))
    assert hpux_virtual.get_virtual_facts() == {'virtualization_type': 'host', 'virtualization_role': 'HPVM', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set(['HPVM'])}
    # Run on HPVM client

# Generated at 2022-06-11 05:53:23.655962
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import HPUXVirtual
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import StringIO

    fake_module = type('FakeModule', (object,), dict(
        run_command=lambda self, cmd: (0, str(cmd), ''),
        fail_json=lambda self, **args: sys.exit(1),
        params=dict(
            gather_subset=['!all', 'virtual']
        )
    ))()

    fake_module.VE_DICT = {
        '/usr/sbin/vecheck': 'Running HPVM guest',
        '/opt/hpvm/bin/hpvminfo': 'Running HPVM guest',
        '/usr/sbin/parstatus': 'Running HPVM guest'
    }



# Generated at 2022-06-11 05:53:28.207517
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    '''Test HPUXVirtual get_virtual_facts'''
    from ansible.module_utils.facts.virtual.hpar import HPUXVirtual
    from ansible.module_utils.facts.virtual.tests.unit.hpvm import FakeModule
    virtual_obj = HPUXVirtual(FakeModule())
    assert type(virtual_obj.get_virtual_facts()) == dict

# Generated at 2022-06-11 05:53:32.006577
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # Test for constructor, when passing an empty module
    module_mock = {}
    virtual_facts = HPUXVirtual(module_mock)
    assert virtual_facts.__class__.__name__ == 'HPUXVirtual'
    assert virtual_facts.module == module_mock


# Generated at 2022-06-11 05:53:33.814223
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(dict())
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-11 05:53:42.177450
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    fake_module = None
    test_obj = HPUXVirtual(fake_module)
    # test with hpvm guest (hpvm 7.x)
    rc_hpvm = 0

# Generated at 2022-06-11 05:53:43.575443
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(dict())
    assert hpux_virtual.get_virtual_facts()

# Generated at 2022-06-11 05:54:52.995308
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux.HPUXVirtual import HPUXVirtual
    h = HPUXVirtual()
    result = h.get_virtual_facts()
    assert 'virtualization_type' in result
    assert 'virtualization_role' in result
    assert 'virtualization_tech_host' in result
    assert 'virtualization_tech_guest' in result


# Generated at 2022-06-11 05:54:56.950406
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.collector
    assert virtual_facts.get_virtual_facts()['virtualization_type'] == 'guest'
    assert virtual_facts.get_virtual_facts()['virtualization_role'] == 'HP vPar'


# Generated at 2022-06-11 05:54:58.503425
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual()
    assert virtual.platform == 'HP-UX'


# Generated at 2022-06-11 05:55:06.588808
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """ Test of get_virtual_facts method
    Test the method get_virtual_facts which returns the virtual
    facts when the system is running in a host or guest
    """

    import os.path

    class TestModule():
        def __init__(self):
            pass

        def run_command(self, command):
            if 'vecheck' in command:
                if os.path.exists('/usr/sbin/vecheck'):
                    return (0, '', '')
                else:
                    return (1, '', '')
            elif 'hpvminfo' in command:
                if os.path.exists('/opt/hpvm/bin/hpvminfo'):
                    if 'Cannot run command' in command:
                        return (1, '', '')

# Generated at 2022-06-11 05:55:14.848716
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpu_ux import HPUXVirtual
    import ansible.module_utils.facts.virtual.hpu_ux as hpu_ux_mock

    # Mock class module
    class MockModule(object):
        def __init__(self):
            return

        def run_command(self, cmd=None, data=None):
            return (0, '', '')

    hpu_ux_mock.os = MockModule()
    hpu_ux_mock.os.path = MockModule()

    # Mock method os.path.exists
    def mock_os_path_exists(path=None):
        return True

    hpu_ux_mock.os.path.exists = mock_os_path_exists

    # Mock method os.path.isf

# Generated at 2022-06-11 05:55:15.849538
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # Just check if this is initializable
    HPUXVirtual()

# Generated at 2022-06-11 05:55:17.400785
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual({'module': None})
    assert virtual._platform == 'HP-UX'


# Generated at 2022-06-11 05:55:21.902262
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual().collect()['virtualization_type'] == 'guest'
    assert HPUXVirtual().collect()['virtualization_role'] == 'HP vPar'
    assert HPUXVirtual().collect()['virtualization_tech_guest'] == set(['HP vPar'])
    assert 'virtualization_tech_host' not in HPUXVirtual().collect()

# Generated at 2022-06-11 05:55:30.048351
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import ansible.module_utils.facts.virtual.hpux

    m_ansible_module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False)

    m_ansible_module.run_command = lambda cmd: (0, to_bytes('It is a virtual machine'), '')
    m_ansible_module.params = None
    m_hpux_virtual = ansible.module_utils.facts.virtual.hpux.HPUXVirtual(m_ansible_module)


# Generated at 2022-06-11 05:55:38.167364
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Test data
    hpx_virtual_testdata = [
        (None, ''),
        ('/usr/sbin/vecheck', ''),
        ('/usr/sbin/vecheck', 'Running in LPAR mode'),
        ('/opt/hpvm/bin/hpvminfo', ''),
        ('/opt/hpvm/bin/hpvminfo', 'Running in HPVM host mode'),
        ('/opt/hpvm/bin/hpvminfo', 'Running in HPVM vPar mode'),
        ('/opt/hpvm/bin/hpvminfo', 'Running in HPVM guest mode'),
        ('/usr/sbin/parstatus', ''),
        ('/usr/sbin/parstatus', 'Running in LPAR mode'),
    ]

    # Expected outcomes
    hpx_virtual_expected_outcomes