

# Generated at 2022-06-11 05:46:38.815534
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts import virtual

    module_mock = patch.dict(virtual.__dict__, {'HPUXVirtual': HPUXVirtual})

    module_mock.start()
    hv = HPUXVirtual()
    module_mock.stop()

    hv.module.run_command = lambda x: (0, '', '')
    assert hv.get_virtual_facts() == {}
    assert hv.get_virtual_facts()['virtualization_type'] == 'guest'
    assert hv.get_virtual_facts()['virtualization_role'] == 'HP vPar'


# Generated at 2022-06-11 05:46:40.103219
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    Constructor for class HPUXVirtual
    """
    HPUXVirtual()

# Generated at 2022-06-11 05:46:48.253254
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpuxtop import HPUXVirtual as test_class
    test_obj = test_class({})
    test_obj.module = DummyModule()
    test_obj.module.run_command = DummyModule.run_command
    test_obj.module.run_command.commands = {
        '/usr/sbin/vecheck': (0, '', ''),
        '/opt/hpvm/bin/hpvminfo': (0, 'Running as HPVM host', ''),
        '/usr/sbin/parstatus': (0, '', '')
    }
    result = test_obj.get_virtual_facts()
    assert result['virtualization_type'] == 'host'
    assert result['virtualization_role'] == 'HPVM'

# Generated at 2022-06-11 05:46:50.172650
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert issubclass(HPUXVirtual, Virtual)
    assert HPUXVirtual.platform == 'HP-UX'


# Generated at 2022-06-11 05:46:58.376584
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    virtual_facts = {}
    host_tech = set()
    guest_tech = set()

    class HP(object):
        @staticmethod
        def run_command(shell_cmd):
            class Out(object):
                return_code = 0
                stdout = ""
                stderr = ""
            if shell_cmd == "/usr/sbin/vecheck":
                out = Out()
                out.stdout = "Running HP-UX virtual partition"
                return out.return_code, out.stdout, out.stderr
            elif shell_cmd == "/opt/hpvm/bin/hpvminfo":
                out = Out()
                out.stdout = "Running HPVM guest"
                return out.return_code, out.stdout, out.stderr

# Generated at 2022-06-11 05:47:00.526644
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual({})
    assert virtual.data['virtualization_type'] == 'host'
    assert virtual.data['virtualization_role'] == ''

# Generated at 2022-06-11 05:47:01.898271
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-11 05:47:03.639546
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-11 05:47:06.101256
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'
    assert hpux_virtual._platform == 'HP-UX'

# Generated at 2022-06-11 05:47:09.813865
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    from ansible.module_utils.facts import virtual

    collector = virtual.VirtualCollector()
    assert isinstance(collector, virtual.VirtualCollector)
    fact_class = collector.get_fact_class()
    assert fact_class is HPUXVirtual


# Generated at 2022-06-11 05:47:21.281054
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-11 05:47:23.099411
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(None)
    assert virtual


# Generated at 2022-06-11 05:47:27.534869
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(None)
    assert hpux_virtual.platform == 'HP-UX', 'Test Failed: HP-UX class instantiation failed'
    assert hpux_virtual.get_virtual_facts() == {'virtualization_tech_host': set(), 'virtualization_tech_guest': set(), 'virtualization_type': '', 'virtualization_role': ''}, 'Test Failed: HP-UX virtual facts retrieval failed'

# Generated at 2022-06-11 05:47:35.878957
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Create a HPUXVirtual object
    hpux_virtual = HPUXVirtual("ansible_module")
    hpux_virtual.module.run_command = run_command
    hpux_virtual.module.get_bin_path = get_bin_path

    # Set the possible output of run_command
    out = (0, "Running HPVM vPar\n", "")

    # Set the possible output of get_bin_path
    bin_path = "/usr/sbin/parstatus"

    # Get the virtualization facts
    virtual_facts = hpux_virtual.get_virtual_facts()

    # Check if method get_virtual_facts returned dict
    assert isinstance(virtual_facts, dict)

    # Check if method get_virtual_facts returned expected dict

# Generated at 2022-06-11 05:47:44.396088
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.facts import ModuleStub
    builtins.__dict__['open'] = open

    # Empty parameters.
    my_args = {}
    my_obj = HPUXVirtual(ModuleStub(**my_args))
    my_facts = my_obj.get_virtual_facts()
    assert 'virtualization_type' not in my_facts
    assert 'virtualization_role' not in my_facts
    assert 'virtualization_tech' not in my_facts

# Generated at 2022-06-11 05:47:46.248402
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_ansible_module = HPUXVirtual(dict())
    assert virtual_ansible_module.platform == 'HP-UX'

# Generated at 2022-06-11 05:47:47.868782
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({}, {}, {})
    assert 'HP' in hv._platform

# Generated at 2022-06-11 05:47:54.742777
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    expected_virtual_facts = {
        'virtualization_type': 'guest',
        'virtualization_role': 'HP vPar',
        'virtualization_tech_guest': set(['HP vPar']),
        'virtualization_tech_host': set(),
    }

    hv = HPUXVirtual(module=None)
    virtual_facts = hv.get_virtual_facts()

    if expected_virtual_facts == virtual_facts:
        print("Constructor of class HPUXVirtual works")
    else:
        print("Constructor of class HPUXVirtual failed")

if __name__ == "__main__":
    test_HPUXVirtual()

# Generated at 2022-06-11 05:48:03.548828
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import ModuleFacts

    # Make sure sys.modules is empty
    for module_name in sys.modules.keys():
        sys.modules.pop(module_name)

    # Create an instance of HPUXVirtual
    obj = HPUXVirtual(ModuleFacts({}, None, None, None))

    # Create a virtual_facts dictionary
    virtual_facts = {}
    virtual_facts['virtualization_type'] = 'host'
    virtual_facts['virtualization_role'] = 'HPVM'
    technology_host = set()
    technology_host.add('HPVM')
    virtual_facts['virtualization_tech_host'] = technology_host
    technology_guest = set()
    technology_guest.add('HPVM IVM')

# Generated at 2022-06-11 05:48:11.665085
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class HPUXModule(object):
        def __init__(self):
            self.run_command_calls = []
            self.run_command_rcs = dict()
            self.run_command_rcs['/usr/sbin/vecheck'] = 0
            self.run_command_rcs['/opt/hpvm/bin/hpvminfo'] = 0
            self.run_command_rcs['/usr/sbin/parstatus'] = 0

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            return (self.run_command_rcs[cmd], '', '')

    m = HPUXModule()
    v = HPUXVirtual(m)
    facts = v.get_virtual_facts()

# Generated at 2022-06-11 05:48:28.933320
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.virtual import HPUXVirtual
    from ansible.module_utils.facts import FakeModule

    module = FakeModule()
    os.path.exists = lambda path: True
    module.run_command = lambda command: (0, to_bytes('Running HPVM vPar'), None)

    hw = HPUXVirtual()
    hw.module = module
    virtual_facts = hw.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HPVM vPar'
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-11 05:48:30.658416
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpuxvirt = HPUXVirtual(None)
    assert hpuxvirt.platform == 'HP-UX'

# Generated at 2022-06-11 05:48:34.787609
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.virtualization_type == 'host'
    assert virtual_facts.virtualization_role == ''
    assert virtual_facts.virtualization_technologies == {'host': set(), 'guest': set()}



# Generated at 2022-06-11 05:48:37.056251
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    m = HPUXVirtual({})
    assert m.virtualization_type == ''
    assert m.virtualization_role == ''
    assert m.virtualization_system == ''



# Generated at 2022-06-11 05:48:41.112359
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpuxvirtual = HPUXVirtual(None)
    env = os.environ.copy()
    env['PATH'] = hpuxvirtual.module.get_bin_path()
    data = hpuxvirtual.get_virtual_facts()
    assert data['virtualization_type'] == 'host'
    assert data['virtualization_role'] == 'HPVM'


# Generated at 2022-06-11 05:48:42.612851
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual()
    assert virtual_obj.platform == 'HP-UX'


# Generated at 2022-06-11 05:48:51.496370
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    facts_hpux = {
        'virtualization_type': 'host',
        'virtualization_role': 'HPVM',
        'virtualization_tech_host': set(['HPVM']),
        'virtualization_tech_guest': set(),
    }

    # Sample output from parstatus

# Generated at 2022-06-11 05:48:53.600456
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'
    assert HPUXVirtual._platform == 'HP-UX'


# Generated at 2022-06-11 05:48:55.879959
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert isinstance(virtual_facts, Virtual)
    assert virtual_facts.platform == 'HP-UX'



# Generated at 2022-06-11 05:49:04.129870
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Unit test for method - get_virtual_facts
    """
    # Create Ansible facts for test
    fake_ansible_facts = dict(platform='HP-UX',
                              os_family="HP-UX",
                              os_name='HP-UX')
    # Create mock module object and initialize with Ansible facts
    fake_module = type('AnsibleModule', (object,),
                       dict(exit_json=lambda self, **kwargs:
                            dict(ansible_facts=kwargs),
                            check_mode=False, params=dict()))
    mock_module_obj = fake_module()
    mock_module_obj.params['gather_subset'] = 'default'
    mock_module_obj.params['gather_timeout'] = 10

# Generated at 2022-06-11 05:49:20.451256
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # For now we are only testing if the constructor can be called
    # successfully. The details are tested in the underlying class
    # Virtual.
    from ansible.module_utils.facts import virtual
    virtual.HPUXVirtual(dict())



# Generated at 2022-06-11 05:49:22.256128
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-11 05:49:23.128946
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual(dict())
    assert v

# Generated at 2022-06-11 05:49:24.156232
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual({})
    assert h.platform == 'HP-UX'

# Generated at 2022-06-11 05:49:31.720438
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import Virtual, VirtualCollector
    from ansible.module_utils.facts import ModuleStub
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.virtual.hpu_ve import HPUXVirtual, HPUXVirtualCollector

    module = ModuleStub(dict(
        params=dict(
            gather_subset=[
                '!all',
                'virtual'
            ]
        )
    ))
    hpu_ve_virtual_facts = HPUXVirtual(module)
    virtual_facts = hpu_ve_virtual_facts.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-11 05:49:32.724649
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-11 05:49:35.013618
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    m_module = MagicMock(run_command=Mock(return_value=(0, '', '')))
    v = HPUXVirtual(m_module)
    v.get_virtual_facts()


# Generated at 2022-06-11 05:49:38.849182
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'
    assert hasattr(hv, 'virtualization_type')
    assert hasattr(hv, 'virtualization_role')
    assert hasattr(hv, 'virtualization_tech_guest')
    assert hasattr(hv, 'virtualization_tech_host')

# Generated at 2022-06-11 05:49:40.103770
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(None)
    assert hpux_virtual._platform == 'HP-UX'

# Generated at 2022-06-11 05:49:41.486372
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    hv = HPUXVirtual()
    assert hv.get_virtual_facts() == hv.virtual_facts

# Generated at 2022-06-11 05:50:02.645350
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import os
    import sys
    import unittest
    import mock

    class TestAnsibleModule:
        def __init__(self, *args, **kwargs):
            self.run_command_args = []
            self.run_command_rc = []
            self.run_command_out = []
            self.run_command_err = []
            self.run_command_calls = 0

        def run_command(self, args):
            self.run_command_args.append(args)
            rc = self.run_command_rc[self.run_command_calls]
            out = self.run_command_out[self.run_command_calls]
            err = self.run_command_err[self.run_command_calls]
            self.run_command_calls += 1


# Generated at 2022-06-11 05:50:04.160687
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt_facts = HPUXVirtual({})
    assert virt_facts.platform == 'HP-UX'

# Generated at 2022-06-11 05:50:05.258191
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_Virtual_get_virtual_facts(HPUXVirtual)

# Generated at 2022-06-11 05:50:07.074002
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual(None)
    assert v.platform == 'HP-UX'
    assert v.get_virtual_facts() is None

# Generated at 2022-06-11 05:50:07.599685
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-11 05:50:09.338720
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_hpux = HPUXVirtual(None)
    assert type(virtual_hpux).__name__ == "HPUXVirtual"


# Generated at 2022-06-11 05:50:10.792715
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual(None)
    assert v.platform == "HP-UX"


# Generated at 2022-06-11 05:50:19.210338
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virtual_obj = HPUXVirtual(module)
    if virtual_obj.module.get_bin_path('/usr/sbin/vecheck'):
        # Output from vecheck command
        vecheck_out = '''
This system appears to be a virtual server.
The following HP-UX virtualization technologies are installed:
        Virtual Partition Manager (VPAR)
        Virtual Machine Manager (VMM)
        '''
        # Expected output of get_virtual_facts()

# Generated at 2022-06-11 05:50:20.649618
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpuxv = HPUXVirtual()
    assert hpuxv.platform == "HP-UX"

# Generated at 2022-06-11 05:50:28.482740
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Test case 1
    # Create a temp module named Module and then create a temp class Test inside
    # which has a method, run_command to return the expected output.
    class Test():
        def run_command(self, cmd):
            if cmd == "/usr/sbin/vecheck":
                out = "Virtual Partition detected, this is a vPar"
                return 0, out, ''
            elif cmd == "/opt/hpvm/bin/hpvminfo":
                out = "Running: HPVM vPar"
                return 0, out, ''
            else:
                return ''

    module = Test()
    virtual = HPUXVirtual()

    # Execute the get_virtual_facts() method of class HPUXVirtual by setting
    # module as the value of the argument and then compare the output received with the
    # expected output

# Generated at 2022-06-11 05:50:49.457972
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpu_ux import HPUXVirtual
    from ansible.module_utils.six.moves import builtins
    hpu_ux_virtual = HPUXVirtual()
    hpu_ux_virtual.module = builtins.object()
    hpu_ux_virtual.module.run_command = lambda arg: (0, '', '')
    hpu_ux_virtual.module.params = builtins.dict()
    assert hpu_ux_virtual.get_virtual_facts()['virtualization_tech_host'] == set()
    assert hpu_ux_virtual.get_virtual_facts()['virtualization_tech_guest'] == {'HP vPar', 'HPVM vPar', 'HPVM IVM', 'HP nPar'}

# Generated at 2022-06-11 05:50:57.611043
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    class Unit:

        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

    class Module:

        def __init__(self):
            self.run_command_results = {
                "/usr/sbin/vecheck": Unit(0, "", ""),
                "/opt/hpvm/bin/hpvminfo": Unit(0, "Running HPVM guest.", ""),
                "/usr/sbin/parstatus": Unit(0, "", "")
            }

        def run_command(self, cmd):
            unit = self.run_command_results[cmd]
            return unit.rc, unit.out, unit.err

    module = Module()
    hv = HPUXVirtual(module)
    facts = hv.get_

# Generated at 2022-06-11 05:50:59.029932
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPVF = HPUXVirtual()
    assert HPVF.platform == 'HP-UX'

# Generated at 2022-06-11 05:51:07.692179
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import Facts
    from ansible.module_utils._text import to_bytes

    #########
    # mocks #
    #########
    module_mock = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    facts_mock = Facts(
        module_mock
    )


# Generated at 2022-06-11 05:51:16.003239
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import HPUXVirtual
    from ansible.module_utils.facts import ModuleDataCollector

    module = FakeAnsibleModule()
    module.run_command.side_effect = fake_exec_cmd

    hpux_virtual = HPUXVirtual(module)
    result = hpux_virtual.get_virtual_facts()
    assert result['virtualization_tech_guest'] == \
        {'HP vPar', 'HP nPar', 'HPVM vPar', 'HPVM IVM'}
    assert result['virtualization_type'] == 'guest'
    assert result['virtualization_role'] == 'HPVM IVM'
    assert result['virtualization_tech_host'] == set()



# Generated at 2022-06-11 05:51:23.676808
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class TestModule(object):
        def __init__(self):
            self.run_command_mock = None

        def run_command(self, command):
            if command == '/usr/sbin/vecheck':
                return (0, '', '')
            elif command == '/opt/hpvm/bin/hpvminfo':
                return (0, 'Running HPVM vPar', '')
            elif command == '/usr/sbin/parstatus':
                return (0, '', '')

    class TestAnsibleModule(object):
        def __init__(self):
            self.params = {
                'name': 'test',
                'state': 'present',
                'partition': '2',
                'size': '1G'
            }

            self.module = TestModule()


# Generated at 2022-06-11 05:51:27.814823
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils import facts
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.facts.virtual.hpu import HPUXVirtual
    h = HPUXVirtual(facts.ModuleStub(None))

    return h.get_virtual_facts()

# Generated at 2022-06-11 05:51:36.187449
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import ModuleStub
    from ansible.module_utils import basic

    module = ModuleStub(
        dict(
            ANSIBLE_MODULE_ARGS={}
        ),
        basic.AnsibleModule
    )
    virtual = HPUXVirtual(module)
    rc, out, err = module.run_command("/bin/hostname")
    hpvm_host = re.match('hpvm', out, re.M|re.I)
    hpvm_guest = re.match('hpvm', out, re.M|re.I)
    rc, out, err = module.run_command("/usr/sbin/parstatus")
    nPar = re.match('HP-UX.*nPar', out, re.M|re.I)
    rc, out,

# Generated at 2022-06-11 05:51:37.584659
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpx = HPUXVirtual({})
    assert hpx.platform == 'HP-UX'

# Generated at 2022-06-11 05:51:40.762974
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt = HPUXVirtual({})
    resval = virt.get_virtual_facts()
    assert 'virtualization_type' in resval
    assert 'virtualization_role' in resval
    assert 'virtualization_tech_guest' in resval
    assert 'virtualization_tech_host' in resval

# Generated at 2022-06-11 05:51:57.907872
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hw = HPUXVirtual({})
    assert hw.platform == 'HP-UX'
    assert hw.get_virtual_facts() == {}

# Generated at 2022-06-11 05:52:07.027358
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class TestModule(object):
        @staticmethod
        def run_command(cmd):
            hpvminfo_output = 'Running HPVM 4.3.01 guest.' #HPVM guest
            parstatus_output = """
            nPartition: 3
            DualCore: True
            """
            vecheck_output = 'vecheck: Running in a vPar guest environment.'
            if cmd == "/usr/sbin/vecheck":
                return 0, vecheck_output, ""
            if cmd == "/opt/hpvm/bin/hpvminfo":
                return 0, hpvminfo_output, ""
            if cmd == "/usr/sbin/parstatus":
                return 0, parstatus_output, ""
            return 3, '', ''


    t = HPUXVirtual(TestModule())
    result = t.get_virtual

# Generated at 2022-06-11 05:52:09.084869
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpv = HPUXVirtual(dict())
    assert hpv.platform == 'HP-UX'

# Generated at 2022-06-11 05:52:19.073826
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible_collections.ansible.community.tests.unit.module_utils.facts.virtual.hpuxtest import (
        FakeModule, FakeHPvPar, FakeHPVM_host, FakeHPVM_guest, FakeHPVM_vPar, FakeHPnPar
        )

    module = FakeModule()

    vecheck_noexists = HPUXVirtual(module)
    hpvm_noexists = HPUXVirtual(module)
    parstatus_noexists = HPUXVirtual(module)

    hpvm_host = HPUXVirtual(module)
    hpvm_host.module.run_command = FakeHPVM_host('/opt/hpvm/bin/hpvminfo').run_command
    hpvm_guest = HPUXVirtual(module)
    hpvm_guest.module.run_

# Generated at 2022-06-11 05:52:26.933086
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.virtual import BaseVirtual
    from ansible.module_utils.facts.virtual import VirtualCollector
    from ansible.module_utils.facts.virtual import PPC64LVirtual
    from ansible.module_utils.facts.virtual import HPUXVirtual
    import os
    import ansible.module_utils.facts.virtual.hpux
    facts_obj = Facts(module=None)
    facts_obj.populate_facts(None)
    virtual_obj = HPUXVirtual(module=None, facts=facts_obj)
    old_run_command = ansible.module_utils.facts.virtual.hpux.run_command

# Generated at 2022-06-11 05:52:29.479257
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # TODO: unit test
    pass


# Generated at 2022-06-11 05:52:38.351117
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils import facts
    from ansible.module_utils.facts.collector.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts import cache
    import os

    test_data_dir = os.path.join(os.path.dirname(__file__), 'unit/data/hpux')

    class MockModule(object):
        def __init__(self, module_utils):
            self.module_utils = module_utils

        def run_command(self, cmd):
            if cmd == '/usr/sbin/vecheck':
                return 0, '', ''
            elif cmd == '/opt/hpvm/bin/hpvminfo':
                return 0, 'HPVM installed \nRunning as HPVM guest\n', ''

# Generated at 2022-06-11 05:52:40.027912
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual_object = HPUXVirtual()
    assert hpux_virtual_object.platform == 'HP-UX'

# Generated at 2022-06-11 05:52:44.076157
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    Test HPUXVirtual class constructor with valid and invalid values
    """
    module_mock = MockModule()

    hpx_virtual = HPUXVirtual(module_mock)

    assert hpx_virtual.platform == 'HP-UX'
    assert hpx_virtual.module == module_mock



# Generated at 2022-06-11 05:52:52.741866
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # instantiate FakeModule class
    fake_module = FakeModule()
    # instantiate HPUXVirtual class
    h_virtual = HPUXVirtual(module=fake_module)

    # set expected output for the module run_command
    fake_module.run_command_output['rc'] = 0
    fake_module.run_command_output['stdout'] = ''
    fake_module.run_command_output['stderr'] = ''

    # set expected output for the method exists
    h_virtual.exists_output = False

    # run the get_virtual_facts method
    facts = h_virtual.get_virtual_facts()

    # assert that the facts are as expected
    assert facts == {}



# Generated at 2022-06-11 05:53:04.160568
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v1 = HPUXVirtual({})
    assert v1.platform == 'HP-UX'
    assert v1.module == {}


# Generated at 2022-06-11 05:53:13.853152
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Test nothing available, returns empty facts
    mock_module = MockModule({})
    hv = HPUXVirtual(mock_module)
    vf = hv.get_virtual_facts()
    assert not vf
    # Test nPar available, returns nPar facts
    mock_module = MockModule({})
    mock_module.run_commands("/usr/sbin/parstatus")
    hv = HPUXVirtual(mock_module)
    vf = hv.get_virtual_facts()
    assert vf
    assert vf['virtualization_tech_host'] == set()
    assert vf['virtualization_tech_guest'] == {'HP nPar'}
    assert vf['virtualization_type'] == 'guest'

# Generated at 2022-06-11 05:53:23.529408
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Test the get_virtual_facts method of the HPUXVirtual class.
    """
    import ansible.module_utils.facts.virtual.hpux_virtual as hpux_virtual
    import ansible.module_utils.facts.virtual.base as base
    import ansible.module_utils.facts.virtual.linux_virtual as linux_virtual
    import ansible.module_utils.facts.virtual.solaris_virtual as solaris_virtual
    module = base.AnsibleModuleMock()
    module.run_command = linux_virtual.AnsibleModuleMock.run_command
    hpux_virtual.os = linux_virtual.AnsibleModuleMock()
    hpux_virtual.os.path = solaris_virtual.AnsibleModuleMock()
    hpux_virtual.os.path.exists

# Generated at 2022-06-11 05:53:25.911689
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    mod = FakeModule({})
    hpux = HPUXVirtual(mod)
    assert hpux.platform == 'HP-UX'
    assert hpux.module == mod


# Generated at 2022-06-11 05:53:27.579006
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual_obj = HPUXVirtual()
    assert HPUXVirtual_obj.platform == 'HP-UX'

# Generated at 2022-06-11 05:53:30.622907
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts._platform == 'HP-UX'
    assert virtual_facts.get_virtual_facts() == {}


# Test get_virtual_facts method of class HPUXVirtual

# Generated at 2022-06-11 05:53:33.305069
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(None)
    assert hpux_virtual.platform == 'HP-UX'
    assert hpux_virtual._platform == 'HP-UX'

# Generated at 2022-06-11 05:53:41.321817
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import HPUXVirtual
    module = AnsibleModule()
    virtual = HPUXVirtual(module)

    module.run_command = MagicMock(side_effect=lambda x, **kwargs:
            (0, '', ''))
    module.os.path.exists = MagicMock(return_value=True)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts == {'virtualization_type': 'host',
                             'virtualization_role': 'HPVM',
                             'virtualization_tech_host': set(['HPVM']),
                             'virtualization_tech_guest': set(['HPVM vPar', 'HPVM IVM', 'HPVM'])}


# Generated at 2022-06-11 05:53:48.214567
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """Routine to test method get_virtual_facts of class HPUXVirtual """

    import inspect
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    hpux_virtual_instance = HPUXVirtual(dict(), '/bin/false')

    # Routine to create dummy file for hpvminfo, parstatus, and vecheck
    def create_test_file(testfile):
        """ Utility routine to create dummy file for testing"""
        import tempfile
        import stat
        tmpdir, dummyfile = tempfile.mkstemp()
        os.write(tmpdir, testfile)
        os.close(tmpdir)
        os.chmod(dummyfile, stat.S_IRWXU)
        return dummyfile

    # Runner to test get_virtual_facts

# Generated at 2022-06-11 05:53:55.915944
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Function to test class HPUXVirtual:get_virtual_facts()
    """
    from ansible.module_utils.facts.virtual import Virtual, VirtualCollector
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.system import System

    class ModuleStub(object):
        def __init__(self):
            self.exit_json = lambda changed=False, ansible_facts=None, **kwargs: None

    virt = HPUXVirtual(AnsibleModule(
        argument_spec = dict()
    ))
    facts = virt.get_virtual_facts()

# Generated at 2022-06-11 05:54:26.620403
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'

# This is a simple unit test for constructor of class HPUXVirtualCollector

# Generated at 2022-06-11 05:54:28.243522
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    constructor of class HPUXVirtual
    """
    hv = HPUXVirtual(dict())
    hv.get_virtual_facts()

# Generated at 2022-06-11 05:54:34.924554
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    class MockAnsibleModule():
        def __init__(self, *args, **kwargs):
            self.run_command_args = []
            self.run_command_rcs = []
            self.run_command_outs = []
            self.run_command_errs = []

        def run_command(self, arg):
            self.run_command_args.append(arg)
            return self.run_command_rcs.pop(), self.run_command_outs.pop(), self.run_command_errs.pop()

    class MockHPVM():
        def __init__(self, *args, **kwargs):
            self.module = MockAnsibleModule()

    # Set up object and data
    hpvm_test = MockHPVM()

    hpvm_test.module.run_command_rcs

# Generated at 2022-06-11 05:54:42.413473
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """Unit test the constructor of HPUXVirtual class,
    a.k.a., test the Virtual collector for HP-UX"""
    module = FakeAnsibleModule()
    virtual = HPUXVirtual(module)

    assert virtual is not None
    assert virtual.platform == 'HP-UX'
    assert virtual.module == module
    assert virtual.virtual_type == 'guest'
    assert virtual.virtual_subtype == 'HPVM IVM'
    assert virtual.containerized is False
    assert virtual.virtual_tech == {'HPVM IVM', 'HPVM', 'HP vPar', 'HP nPar'}
    assert virtual.container_tech == set()


# Generated at 2022-06-11 05:54:49.798966
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class HPUXVirtual
    """
    module = Mock(return_value=None)
    module.run_command = Mock(return_value=(0, 'out', 'err'))
    module.get_bin_path = Mock(return_value=None)
    module.os_family = 'HP-UX'

    hv = HPUXVirtual(module=module)

    module.run_command = Mock(return_value=(1, 'out', 'err'))
    assert hv.get_virtual_facts() == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

    module.run_command = Mock(return_value=(0, 'out', 'err'))

# Generated at 2022-06-11 05:54:54.455182
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    def mock_popen(input):
        pass

    class MockPopen(object):
        def __init__(self, args, **kwargs):
            pass

        def communicate(self):
            return "/usr/sbin/vecheck", ''

    class MockModule(object):
        def __init__(self):
            self.run_command = mock_popen

    vm = HPUXVirtual(MockModule())
    facts = vm.get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP vPar'
    assert facts['virtualization_tech_guest'] == set(['HP vPar'])
    assert facts['virtualization_tech_host'] == set()

# Generated at 2022-06-11 05:55:03.235323
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    test HPUXVirtual Collector
    :return:
    """
    # Date from hosts with HPVM guests, with _hpvm_guest_info.txt file
    virtual_data = {}

# Generated at 2022-06-11 05:55:11.583940
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux_virtual import HPUXVirtual
    hpuxvirt = HPUXVirtual()
    hpuxvirt.module = FakeModule()

    # Test vPar
    hpuxvirt.module.run_command.side_effect = [
        (0, '', ''),  # os.path.exists('/usr/sbin/vecheck')
        (0, 'VE: HP Virtual Partition support: Not Active', ''),
    ]
    out = hpuxvirt.get_virtual_facts()
    assert(out['virtualization_type'] == 'guest')
    assert(out['virtualization_role'] == 'HP vPar')
    assert('HP vPar' in out['virtualization_tech_guest'])

# Generated at 2022-06-11 05:55:13.067888
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_data = HPUXVirtual({})
    assert virtual_data.platform == 'HP-UX'


# Generated at 2022-06-11 05:55:15.026923
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual(None)
    assert h.platform == 'HP-UX'
    assert h.get_virtual_facts()['virtualization_tech_guest'] == set()

# Generated at 2022-06-11 05:56:21.045373
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_module = type('test_module', (object,), {})()
    test_module.run_command = lambda a: (1, '', '')
    hpux = HPUXVirtual(test_module)
    assert hpux.get_virtual_facts() == {'virtualization_tech_host': set([]),
                                    'virtualization_tech_guest': set([])}

    test_module.run_command = lambda a: (0, 'HPVM vPar', '')
    hpux = HPUXVirtual(test_module)