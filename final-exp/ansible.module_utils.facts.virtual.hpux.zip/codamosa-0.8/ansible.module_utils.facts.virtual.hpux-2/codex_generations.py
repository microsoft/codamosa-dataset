

# Generated at 2022-06-11 05:46:36.589897
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    import platform
    import datetime

    fake_virtual = Virtual()
    fake_virtual.module = ansible_module_mock = Mock()
    hpux_virtual = HPUXVirtual(fake_virtual)

    assert hpux_virtual.module == ansible_module_mock
    assert hpux_virtual.platform == "HP-UX"
    assert hpux_virtual.has_hpvminfo == False
    assert hpux_virtual.has_vecheck == False
    assert hpux_virtual.has_parstatus == False
    assert hpux_virtual.is_bundled == False
    assert hpux_virtual.is_hp == True
    assert hpux_virtual.is_ibm == False
    assert hpux_virtual.is_linux == False
    assert hpux_virtual.is_solaris == False

# Generated at 2022-06-11 05:46:38.132743
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual({})
    assert virtual.platform == 'HP-UX'


# Generated at 2022-06-11 05:46:46.479703
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import facts
    from ansible.module_utils.facts.virtual import HPUXVirtual
    module = facts._get_module()
    HPUX_virtual = HPUXVirtual(module)

    # Test case 1 - hpvminfo is not present
    HPUX_virtual.module.run_command = lambda x: (0, '', '')
    virtual_facts = HPUX_virtual.get_virtual_facts()
    assert virtual_facts == {'virtualization_type': None,
                             'virtualization_role': None,
                             'virtualization_tech_guest': set(),
                             'virtualization_tech_host': set()}

    # Test case 2 - hpvminfo is present but does not match the output

# Generated at 2022-06-11 05:46:54.741053
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    def _get_module_mock(params):
        module = MockModule(params=params)
        module.run_command = Mock(return_value=(0, '', ''))
        module.add_file_common_ignores = Mock()
        return module

    # First test case will be for HP-UX IVM and vPar
    params = {'gather_subset': '!all', 'gather_timeout': 10, 'filter': 'ansible_virtual'}
    module = _get_module_mock(params)
    hpux_virtual = HPUXVirtual(module)
    # Create the test directories for class HPUXVirtual
    for directory in ('/usr/sbin', '/opt/hpvm/bin'):
        if not os.path.exists(directory):
            os.mkdir(directory)
   

# Generated at 2022-06-11 05:46:56.827047
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v_object = HPUXVirtual(dict(module=None))
    assert v_object.platform == 'HP-UX'
    assert v_object.module == None

# Generated at 2022-06-11 05:46:58.969812
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual(dict()).platform == 'HP-UX'
    assert HPUXVirtual(dict())._platform == 'HP-UX'


# Generated at 2022-06-11 05:47:03.088497
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    virtual_facts = HPUXVirtual(dict(ANSIBLE_MODULE_ARGS={})).get_virtual_facts()
    keys = [
        'virtualization_type',
        'virtualization_role',
        'virtualization_tech_guest',
        'virtualization_tech_host',
    ]
    for key in keys:
        assert key in virtual_facts

# Generated at 2022-06-11 05:47:04.775659
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(dict())
    assert hv.platform == "HP-UX"

# Generated at 2022-06-11 05:47:07.678252
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec=dict())
    virtual_facts_dict_result = HPUXVirtual.get_virtual_facts(module)
    assert isinstance(virtual_facts_dict_result, dict)

# Generated at 2022-06-11 05:47:12.890470
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    hpux_virtual = HPUXVirtual(module=module)
    hpux_virtual.collect()
    module.run_command = lambda *a, **kw: (0, '', '')
    hpux_virtual_collector = HPUXVirtualCollector(module=module)
    hpux_virtual_collector.collect()
    hpux_virtual.get_virtual_facts()



# Generated at 2022-06-11 05:47:29.776037
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = HPUXVirtual(None)
    module.module.run_command = lambda x: (None, '', '')
    assert module.get_virtual_facts() == {'virtualization_type': 'host', 'virtualization_role': 'HPVM', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}
    module.module.run_command = lambda x: (None, '', '')
    assert module.get_virtual_facts() == {'virtualization_type': 'host', 'virtualization_role': 'HPVM', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}
    module.module.run_command = lambda x: (None, '', '')

# Generated at 2022-06-11 05:47:38.403456
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # input
    module = AnsibleModule({})
    # HPUXVirtual object with module
    hv = HPUXVirtual({}, module)

    module.run_command = MagicMock(return_value=(0, 'hpvminfo output', ''))
    facts = hv.get_virtual_facts()
    assert facts == {'virtualization_tech_host': set(),
                     'virtualization_tech_guest': set(['HPVM']),
                     'virtualization_type': 'host',
                     'virtualization_role': 'HPVM'}

    module.run_command = MagicMock(return_value=(0, 'vecheck output', ''))
    facts = hv.get_virtual_facts()

# Generated at 2022-06-11 05:47:40.163751
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_o = HPUXVirtual({})
    assert virtual_o._fact_class == 'HP-UX'


# Generated at 2022-06-11 05:47:48.982252
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    module = get_module_mock()

    module.run_command.return_value = (0, 'foo', '')

    f = HPUXVirtual(module=module)

    r = f.get_virtual_facts()


# Generated at 2022-06-11 05:47:57.195324
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    imp_mod = __import__('module_utils.facts.virtual.hpux', globals(), locals(), ['AnsibleModule'], -1)
    imp_ext = __import__('module_utils.facts.virtual.hpux', globals(), locals(), ['exec_command'], -1)
    imp_mod.HPUXVirtual.module = imp_mod.AnsibleModule(argument_spec=dict())
    imp_mod.HPUXVirtual.module.run_command = imp_ext.exec_command
    virtual = imp_mod.HPUXVirtual()
    # Test for HP nPar
    os.path.exists = lambda path: path == '/usr/sbin/parstatus'
    imp_ext.exec_command.return_value = (0, None, None)

# Generated at 2022-06-11 05:48:06.014620
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual, HPUXVirtualCollector
    from ansible.module_utils.facts.virtual import VirtualCollector

    class MockModule(object):
        def __init__(self):
            self.run_command_exit_status = 0
            self.run_command_results = ''

        def run_command(self, args, check_rc=False):
            return self.run_command_exit_status, self.run_command_results, ''

    class MockHPUXVirtual(HPUXVirtual):
        def __init__(self):
            pass

        def get_file_content(self, path):
            return ""

    v = MockHPUXVirtual()
    v.module = MockModule()


# Generated at 2022-06-11 05:48:07.190883
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual(dict()).platform == 'HP-UX'


# Generated at 2022-06-11 05:48:10.007520
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})

    assert virtual_facts.platform == 'HP-UX'
    assert virtual_facts.virtualization_type == 'guest'
    assert virtual_facts.virtualization_role == 'HP vPar'


# Generated at 2022-06-11 05:48:12.784085
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    '''
    Unit test for constructor of class HPUXVirtual.
    '''
    hpux_virtual = HPUXVirtual(dict())
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-11 05:48:15.615557
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    config = HPUXVirtual({})
    assert config.platform == 'HP-UX'
    assert config.virtualization_type != config.virtualization_role
    assert config.virtualization_type != config.virtualization_role

# Generated at 2022-06-11 05:48:36.347085
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    m = HPUXVirtual()
    assert m.platform == 'HP-UX'


# Generated at 2022-06-11 05:48:42.999357
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    _module = Mock()
    _module.run_command = Mock()
    _module.run_command.return_value = (0, '', '')
    hpux_virtual = HPUXVirtual(module=_module)
    virtual_facts = hpux_virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_tech_guest'] == set(['HP vPar'])



# Generated at 2022-06-11 05:48:47.209131
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    facts = HPUXVirtual({})
    virtual_facts = facts.get_virtual_facts()
    assert not virtual_facts.get('virtualization_role')
    assert not virtual_facts.get('virtualization_type')
    assert not virtual_facts.get('virtualization_tech_guest')
    assert not virtual_facts.get('virtualization_tech_host')

# Generated at 2022-06-11 05:48:53.980683
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    '''
    HPUXVirtual: Test the correct values are returned by  get_virtual_facts method
    '''
    mod = FakeAnsibleModule()
    facts = HPUXVirtual(mod).get_virtual_facts()
    assert not facts['virtualization_tech_host']
    assert len(facts['virtualization_tech_guest']) == 0
    assert not facts.get('virtualization_type')
    assert not facts.get('virtualization_role')


# Mock the AnsibleModule object so we can set module.run_command return values
from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-11 05:48:55.648501
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-11 05:49:03.889699
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_class = HPUXVirtual()

    # Unit test for output of HPVM IVM
    test_class.module.run_command = lambda x: (0,
                                               'Running HPVM guest.\n',
                                               '')
    virtual_facts = test_class.get_virtual_facts()
    assert('virtualization_type' in virtual_facts)
    assert(virtual_facts['virtualization_type'] == 'guest')
    assert('virtualization_role' in virtual_facts)
    assert(virtual_facts['virtualization_role'] == 'HPVM IVM')
    assert('virtualization_tech_host' in virtual_facts)
    assert(virtual_facts['virtualization_tech_host'] == set())
    assert('virtualization_tech_guest' in virtual_facts)

# Generated at 2022-06-11 05:49:11.342104
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector import get_collector
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual

    # Construct a dummy module for HPUXVirtual.get_virtual_facts()
    class DummyModule(object):
        def __init__(self):
            self.run_command = lambda *args, **kwargs: (0, '', '')

    collector = get_collector('HPUXVirtualCollector')
    assert isinstance(collector, Collector)

    # Get virtual_facts using get_virtual_facts()
    virtual_facts = collector.get_virtual_facts(DummyModule())
    assert isinstance(virtual_facts, HPUXVirtual)

    # Check virtualization_role and virtualization_type

# Generated at 2022-06-11 05:49:14.541319
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.virtualization_type == 'guest'
    assert virtual_facts.virtualization_role == 'HP vPar'
    assert virtual_facts.virtualization_tech_host == set()
    assert virtual_facts.virtualization_tech_guest == {'HP vPar'}

# Generated at 2022-06-11 05:49:22.981519
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux_virtual import HPUXVirtual
    from ansible.module_utils.facts.virtual.posix.collector import PosixVirtualCollector
    from ansible.module_utils.facts.virtual.posix import BasePosixVirtual

    class MockedModule:
        def __init__(self, params):
            self.params = params

        def run_command(self, cmd):
            if re.match('/usr/sbin/vecheck', cmd):
                return 0, '', ''
            if re.match('/opt/hpvm/bin/hpvminfo', cmd):
                return 0, 'Running in HPVM guest', ''
            if re.match('/usr/sbin/parstatus', cmd):
                return 0, 'abc', ''


# Generated at 2022-06-11 05:49:30.498239
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import VirtualCollector
    from ansible.module_utils.facts.virtual.hpu_x import HPUXVirtual
    virtual_collector = VirtualCollector()
    virtual_collector._collectors = [HPUXVirtual]
    virtual_collector._setup_module()
    assert 'virtualization_tech_guest' in virtual_collector.module.params
    assert 'virtualization_tech_host' in virtual_collector.module.params
    virtual_collector.get_virtual_facts()
    assert 'virtualization_type' in virtual_collector.module.params
    assert 'virtualization_role' in virtual_collector.module.params
    assert len(virtual_collector.module.params['virtualization_tech_guest']) == 1

# Generated at 2022-06-11 05:50:01.956498
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # initialize a HPUX Virtual object
    facts = dict()
    module = dict()
    hpvirtual = HPUXVirtual(module, facts)
    hpvirtual.module.run_command = lambda x: (0, 'test', '')
    # run the method _get_virtual_facts
    virtual_facts = hpvirtual.get_virtual_facts()

    # check the returned dict
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts

# Generated at 2022-06-11 05:50:04.124110
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_object = HPUXVirtual(dict())
    assert virtual_object.platform == 'HP-UX'
    assert virtual_object.get_virtual_facts() == {}


# Generated at 2022-06-11 05:50:11.531595
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import ModuleArgsParser

    mock_module = AnsibleModule(
        argument_spec=ModuleArgsParser.parse_kv(dict()),
        supports_check_mode=True
    )

    mock_module.run_command = Mock(return_value=(0, '', ''))

    hpux_virtual_ins = HPUXVirtual(mock_module)

    hpux_virtual_ins.get_virtual_facts()

    assert hpux_virtual_ins.facts['virtualization_type'] == 'guest'

    assert hpux_virtual_ins.facts['virtualization_role'] == 'HP nPar'

    assert hpux_virtual_ins.facts['virtualization_tech_host'] == set()


# Generated at 2022-06-11 05:50:19.937059
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible_collections.ansible.community.tests.unit.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase, set_module_args

    class MockModule1(object):
        def __init__(self):
            self.params = {}
            self.exit_json = AnsibleExitJson
            self.fail_json = AnsibleFailJson

        def run_command(self, cmd):
            if cmd == "/usr/sbin/vecheck":
                return(0, 'Success', '')
            if cmd == "/opt/hpvm/bin/hpvminfo":
                return(0, 'Running on host: HPVM vPar', '')

        def exit_json(self, **kwargs):
            pass

        def fail_json(self, **kwargs):
            pass

   

# Generated at 2022-06-11 05:50:23.611394
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual()
    assert virtual_obj.platform == 'HP-UX'
    assert virtual_obj.virtualization_type == 'host'
    assert virtual_obj.virtualization_role == ''
    assert virtual_obj.virtualization_tech_host == set([])
    assert virtual_obj.virtualization_tech_guest == set([])

# Generated at 2022-06-11 05:50:31.653093
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    test_object = HPUXVirtual(None)
    test_object.module = MockModule()

# Generated at 2022-06-11 05:50:39.968099
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    m = HPUXVirtual()
# Test return of virtualization_type - guest
    m.module.run_command = lambda x: (0, "", "")
    m.module.get_bin_path = lambda x: "/usr/sbin/" + x if x in ["vecheck", "parstatus", "hpvminfo"] else None
    m.platform = 'HP-UX'
    assert m.get_virtual_facts()['virtualization_type'] == 'guest'
# Test return of virtualization_type - host
    m.module.run_command = lambda x: (0, "Running: HPVM host", "")
    m.module.get_bin_path = lambda x: "/usr/sbin/" + x if x in ["vecheck", "parstatus", "hpvminfo"] else None

# Generated at 2022-06-11 05:50:42.382811
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    obj = HPUXVirtual()
    assert obj.platform == 'HP-UX'
    assert obj.virtualization_role is None
    assert obj.virtualization_type is None


# Generated at 2022-06-11 05:50:50.546855
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class HPUXModule:
        @staticmethod
        def run_command(cmd):
            class HPUXOutput:
                stdout = ''
                exit_code = 0
                stderr = ''
            if cmd == '/usr/sbin/vecheck':
                return (0, HPUXOutput(), '')
            elif cmd == '/opt/hpvm/bin/hpvminfo':
                HPUXOutput.stdout = 'HPVM Running: HPVM guest'
            elif cmd == '/usr/sbin/parstatus':
                HPUXOutput.stdout = 'HP nPar'
            return (0, HPUXOutput(), '')
    HPUXVirtual.module = HPUXModule()
    hpx_virtual_facts = HPUXVirtual()

# Generated at 2022-06-11 05:50:58.721332
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec={}
    )
    root_dir = os.path.realpath(os.path.dirname(__file__))
    hpux_virtual = HPUXVirtual(module)
    hpux_virtual._collect = True

    def do_test_get_virtual_facts(path, output):
        if path:
            hpux_virtual.module.run_command = lambda a: (0, '', '')
        else:
            hpux_virtual.module.run_command = lambda a: (1, '', '')
        if output:
            hpux_virtual.module.run_command = lambda a: (
                0,
                output,
                ''
            )
        hpux_virtual.get_virtual_facts()


# Generated at 2022-06-11 05:51:29.274657
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    facts = {
        "kernel": "HP-UX",
        "os_family": "HP-UX",
    }
    hpuxvirtual = HPUXVirtual(facts, None)
    assert hpuxvirtual.platform == 'HP-UX'
    assert hpuxvirtual.facts == facts


# Generated at 2022-06-11 05:51:37.280828
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    hpx = HPUXVirtual(module)

    rc, out, err = module.run_command("/usr/sbin/vecheck")
    if rc == 0:
        expected_result = {
            'virtualization_role': 'HP vPar',
            'virtualization_tech_host': set(),
            'virtualization_type': 'guest',
            'virtualization_tech_guest': set(['HP vPar'])
        }
    else:
        expected_result = {
            'virtualization_tech_host': set(),
            'virtualization_tech_guest': set(),
            'virtualization_role': 'undefined',
            'virtualization_type': 'physical'
        }

   

# Generated at 2022-06-11 05:51:42.295527
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    mock_module = type('module', (object,), {'run_command': lambda x, y: (0, '', '')})()
    virtual = HPUXVirtual(mock_module)
    assert virtual.file_exists('/usr/sbin/vecheck') == True
    assert virtual.file_exists('/opt/hpvm/bin/hpvminfo') == True
    assert virtual.file_exists('/usr/sbin/parstatus') == True

# Generated at 2022-06-11 05:51:52.059460
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # nPartition
    class MockModule:
        def run_command(self, cmd):
            return 0, '10 \n\n', ''
    class MockOs:
        def exists(self, path):
            if path == '/usr/sbin/parstatus':
                return True
            return False
    m = MockModule()
    o = MockOs()
    v = HPUXVirtual(m, o)
    facts = v.get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP nPar'
    assert facts['virtualization_tech_guest'] == set(['HP nPar'])

    # vPar
    class MockModule:
        def run_command(self, cmd):
            return 0, '\n', ''

# Generated at 2022-06-11 05:52:00.840685
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    import sys
    import tempfile
    import textwrap
    import io

    # mock module
    class MockAnsibleModule():
        def __init__(self):
            self.run_command = MockRunCommand('/usr/bin/id')

    # mock run_command
    class MockRunCommand():
        def __init__(self, path_to_id):
            self.path_to_id = path_to_id

        def __call__(self, path, check_rc=True):
            if path == self.path_to_id:
                return 0, 'myuserid', None

# Generated at 2022-06-11 05:52:02.440925
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():

    obj = HPUXVirtual()
    assert obj.platform == 'HP-UX'


# Generated at 2022-06-11 05:52:04.970945
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt = HPUXVirtual(dict())
    assert virt.platform == 'HP-UX'
    assert virt.guest_virtual_facts == dict()
    assert virt.host_virtual_facts == dict()


# Generated at 2022-06-11 05:52:07.589942
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = MockModule()
    hpuxvirtual = HPUXVirtual(module)
    assert hpuxvirtual.platform == 'HP-UX'


# Generated at 2022-06-11 05:52:09.270924
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-11 05:52:12.833686
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_inst = HPUXVirtual({})
    assert virtual_inst.platform == 'HP-UX'
    assert virtual_inst.get_virtual_facts() == {}


# Unit tests for class HPUXVirtualCollector

# Generated at 2022-06-11 05:52:56.325700
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    hpuxvirtual = HPUXVirtual(dict(module=dict()))
    assert hpuxvirtual.get_virtual_facts() == {'virtualization_type': 'guest', 'virtualization_role': 'HP vPar'}

# Generated at 2022-06-11 05:52:58.474920
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = Virtual()
    assert virtual_obj.virtualization_type == ''
    assert virtual_obj.virtualization_role == ''



# Generated at 2022-06-11 05:53:05.832405
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModuleMock({})
    hpux_virtual = HPUXVirtual(module)
    rc, out, err = hpux_virtual.module.run_command.mock.call_args[0]
    assert rc == 0
    assert out == ''
    assert err == ''

    virtual_facts = hpux_virtual.get_virtual_facts()
    assert virtual_facts == {'virtualization_type': 'guest', 'virtualization_role': 'HP vPar', 'virtualization_tech_guest': {'HP vPar'}, 'virtualization_tech_host': set()}



# Generated at 2022-06-11 05:53:07.682224
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual({})
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-11 05:53:12.868495
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import json

    # Test get_virtual_facts of class HPUXVirtual
    # and its super classes
    v = HPUXVirtual()
    facts = v.get_facts()
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    if module.check_mode:
        return facts
    else:
        module.exit_json(**facts)

# Generated at 2022-06-11 05:53:16.421105
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpx import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpx import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpvm import HPVMVirtual
    from ansible.module_utils.facts.virtual.hpvm import HPVMVirtualCollector
    from ansible.module_utils.facts.virtual.hpvpar import HPVParVirtual
    from ansible.module_utils.facts.virtual.hpvpar import HPVParVirtualCollector
    from ansible.module_utils.facts.virtual.hpnpar import HPNParVirtual
    from ansible.module_utils.facts.virtual.hpnpar import HPNParVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
   

# Generated at 2022-06-11 05:53:18.167910
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    assert len(HPUXVirtual(None).get_virtual_facts()) == 5


# Generated at 2022-06-11 05:53:20.290385
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(dict(module=''))
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-11 05:53:29.764375
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    facts = dict()

    def module_run_command(module, *args, **kwargs):
        if args[0] == '/usr/sbin/vecheck':
            return (0, 'any output', '')
        else:
            return (1, 'any output', '')

    def module_fail_json(module, *args, **kwargs):
        raise Exception("FAIL")

    def module_exit_json(module, *args, **kwargs):
        raise Exception("EXIT")

    def module_get_bin_path(module, *args, **kwargs):
        return '/usr/bin/'

    h = HPUXVirtual(module=None)
    h.module.run_command = module_run_command
    h.module.fail_json = module_fail_json
    h.module.exit

# Generated at 2022-06-11 05:53:38.597596
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import os.path
    import mock
    import pytest

    host_tech = set()
    guest_tech = set()
    expected_virtual_facts = {}

    class ModuleMock(mock.MagicMock):
        def run_command(self, cmd):
            if cmd == "/usr/sbin/vecheck":
                rc = 0
                out = "This system is a HP-UX virtual machine."
                err = ""
            elif cmd == "/opt/hpvm/bin/hpvminfo":
                rc = 0
                out = "Running HPVM guest."
                err = ""
            elif cmd == "/usr/sbin/parstatus":
                rc = 0
                out = "This system is a HP-UX virtual partition."
                err = ""
            return rc, out, err

    module_mock = ModuleM

# Generated at 2022-06-11 05:54:46.046174
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpu_hpux import HPUXVirtual
    module = FakeModule()
    hpux_virtual = HPUXVirtual(module)
    result = hpux_virtual.get_virtual_facts()
    assert result['virtualization_type'] == 'guest'
    assert result['virtualization_role'] == 'HP vPar'
    assert result['virtualization_tech_guest'] == {'HP vPar'}
    assert result['virtualization_tech_host'] == set()



# Generated at 2022-06-11 05:54:47.273220
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual("module", "command")
    assert hv.platform == "HP-UX"

# Generated at 2022-06-11 05:54:52.874484
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils._text import to_bytes

    class TestModule(object):
        def __init__(self):
            self.run_command_environ_update = {}

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            rc = 0
            if re.match('\/usr\/sbin\/vecheck', args.strip()):
                out = to_bytes("")
                err = to_bytes("")

# Generated at 2022-06-11 05:55:01.759602
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import ModuleTestCase
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    import ansible.modules.system.facts as module

    temp_path = os.path.join(ModuleTestCase.temp_dir, "hpux_virtual_facts")

    class TestModule(module.AnsibleModule):
        def __init__(self, *args, **kwargs):
            module.AnsibleModule.__init__(self, *args, **kwargs)
            self.run_command = lambda *a, **kw: (0, "Out", "Err")

    test_module = TestModule()
    test_module.exit_json = lambda *a, **kw: None

    hpux_virtual = HPUXVirtual(test_module)


# Generated at 2022-06-11 05:55:04.934355
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    expected_facts = {'virtualization_type':'guest', 'virtualization_role':'HPVM IVM'}
    virtual_fact_instance = HPUXVirtual(dict())
    assert virtual_fact_instance.get_virtual_facts() == expected_facts

# Generated at 2022-06-11 05:55:10.696015
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    m = basic.AnsibleModule(argument_spec={'gather_subset': dict(default=['!all'], type='list')})
    v = HPUXVirtual(m)
    facts = v.get_virtual_facts()

    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts

# Generated at 2022-06-11 05:55:15.508688
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    test_dict = {
        'virtualization_type': 'guest',
        'virtualization_role': 'HP nPar',
        'virtualization_tech_guest': set(['HP nPar']),
        'virtualization_tech_host': set(),
        'virtualization_system': 'HP-UX'
    }
    test_HPUXVirtual = HPUXVirtual()
    assert test_HPUXVirtual.get_virtual_facts() == test_dict

# Generated at 2022-06-11 05:55:19.184068
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual()
    assert virtual.platform == "HP-UX"
    assert virtual.virtualization_type == "unknown"
    assert virtual.virtualization_role == "unknown"
    assert virtual.virtualization_tech_guest == set()
    assert virtual.virtualization_tech_host == set()

# Generated at 2022-06-11 05:55:27.494601
# Unit test for method get_virtual_facts of class HPUXVirtual

# Generated at 2022-06-11 05:55:29.366610
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt = HPUXVirtual(dict(module=dict()))
    assert virt.facts == dict()
    assert virt.module == dict()

