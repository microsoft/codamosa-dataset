

# Generated at 2022-06-11 05:46:30.227236
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual({})
    assert hpux_virtual


# Generated at 2022-06-11 05:46:34.165033
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(None)
    assert hpux_virtual.platform == 'HP-UX'
    assert hpux_virtual.get_virtual_facts() == {'virtualization_type': 'guest', 'virtualization_role': 'HP vPar', 'virtualization_tech_guest': {'HP vPar'}, 'virtualization_tech_host': set()}

# Generated at 2022-06-11 05:46:35.762596
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual(dict()).platform == HPUXVirtual().platform


# Generated at 2022-06-11 05:46:44.351784
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from collections import namedtuple
    from ansible.module_utils.facts.virtual.hpuux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpuux import HPUXVirtualCollector

    def run_command(self, command):
        if command[0] == '/usr/sbin/parstatus':
            return (0, '', '')
        if command[0] == '/usr/sbin/vecheck':
            return (0, '', '')
        if command[0] == '/opt/hpvm/bin/hpvminfo':
            return (0, '', '')
        return (0, '', '')

    fake_module = namedtuple('FakeModule', 'run_command')(run_command)
    hpuuxvirtual = HPUXVirtual(fake_module)


# Generated at 2022-06-11 05:46:45.864062
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-11 05:46:54.083137
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class HPUXVirtual
    """
    fake_module = {'run_command': lambda cmd: [0, '', '']}
    fake_module_not_exist = {'run_command': lambda cmd: [1, '', '']}
    fake_module_is_host = {'run_command': lambda cmd: [0, '', 'Running: HPVM host virtual machine'],
                           'get_bin_path': lambda cmd: '/opt/hpvm/bin'}
    fake_module_is_guest = {'run_command': lambda cmd: [0, '', 'Running: HPVM guest virtual machine'],
                            'get_bin_path': lambda cmd: '/opt/hpvm/bin'}

# Generated at 2022-06-11 05:46:55.334660
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual()
    assert virtual.platform == 'HP-UX'

# Generated at 2022-06-11 05:46:57.661850
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual({})
    assert hpux_virtual.__class__.__name__ == 'HPUXVirtual'
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-11 05:47:01.935735
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = FakeansibleModule()
    virtual_facts = HPUXVirtual(module).get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert len(virtual_facts['virtualization_tech_host']) == 0
    assert len(virtual_facts['virtualization_tech_guest']) == 0


# Generated at 2022-06-11 05:47:08.099534
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # Set up the object
    HPUXVirtualObj = HPUXVirtual(module)
    # Check the virtualization_type
    virtualization_type = 'guest'
    platform = 'HP-UX'
    assert HPUXVirtualObj.get_virtual_facts()['virtualization_type'] == virtualization_type
    # Check the virtualization_role
    virtualization_role = 'HPVM vPar'
    assert HPUXVirtualObj.get_virtual_facts()['virtualization_role'] == virtualization_role

# Generated at 2022-06-11 05:47:26.159911
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    "Test get_virtual_facts for HPUX Virtual"
    facts = {}
    facts['system'] = 'HP-UX'

    mod = AnsibleModule(argument_spec={})
    virt = HPUXVirtual(mod)

    # Test for guest
    facts['virtualization_type'] = 'guest'
    facts['virtualization_role'] = 'HP vPar'
    facts['virtualization_tech_guest'] = set(['HP vPar'])
    facts['virtualization_tech_host'] = set()

    result = virt.get_virtual_facts()
    assert result == facts

    # Test for host
    facts['virtualization_type'] = 'host'
    facts['virtualization_role'] = 'HPVM'
    facts['virtualization_tech_guest'] = set(['HPVM'])
    facts

# Generated at 2022-06-11 05:47:27.191779
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual({})

    assert h.platform == 'HP-UX'

# Generated at 2022-06-11 05:47:35.498513
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils import facts
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual

    # Create an instance of the HPUXVirtual class
    virtual = HPUXVirtual(facts.MY_FACTS)
    virtual_facts = virtual.get_virtual_facts()
    # Check that the returned results are correct
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP nPar'
    assert virtual_facts['virtualization_tech_guest'] == {'HP nPar'}
    assert virtual_facts['virtualization_tech_host'] == set()

    # Create an instance of the HPUXVirtual class
    virtual = HPUXVirtual(facts.MY_FACTS)
    virtual_facts = virtual.get

# Generated at 2022-06-11 05:47:36.916354
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    obj = HPUXVirtual()
    assert(obj.platform == 'HP-UX')

# Generated at 2022-06-11 05:47:45.421289
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    virtual_info = HPUXVirtual(module)

    def run_command():
        # Return the mock output of the command
        if virtual_info.check_file_path('/usr/sbin/vecheck'):
            return (0, '', '')
        elif virtual_info.check_file_path('/opt/hpvm/bin/hpvminfo'):
            return (0, 'Running HPVM guest', '')
        elif virtual_info.check_file_path('/usr/sbin/parstatus'):
            return (0, '', '')
        else:
            return (0, '', '')
    module.run_command = run_command

    virtual_facts = virtual_info.get_virtual_facts()
    assert 'guest' == virtual_

# Generated at 2022-06-11 05:47:47.340499
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_hpux = HPUXVirtual(dict(module=None))
    assert virtual_hpux.platform == 'HP-UX'

# Generated at 2022-06-11 05:47:49.579739
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts._platform == "HP-UX"
    assert virtual_facts._fact_class == HPUXVirtual

# Generated at 2022-06-11 05:47:57.720187
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    m = mock.Mock()
    m.return_value = (0, '', '')
    m.run_command.side_effect = [
        # /usr/sbin/vecheck
        (0, '', ''),
        (1, '', ''),
        # /opt/hpvm/bin/hpvminfo
        (0, 'Running on HPVM vPar', ''),
        (0, 'Running on HPVM guest', ''),
        (0, 'Running on HPVM host', ''),
        (1, '', ''),
        # /usr/sbin/parstatus
        (0, '', ''),
        (1, '', '')
    ]
    HPUXVirtual.module = m
    hpuxvirtual = HPUXVirtual()
    facts = hpuxvirtual.get_virtual_facts()

# Generated at 2022-06-11 05:47:59.434226
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(dict())
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-11 05:48:08.256949
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Initializing HPUXVirtual instance
    test_hpxvirtual = HPUXVirtual({})
    # Testing if virtualization_type of get_virtual_facts is set with expected value
    expected_virtualization_type = 'guest'
    assert test_hpxvirtual.get_virtual_facts()[
        'virtualization_type'] == expected_virtualization_type
    # Testing if virtualization_role of get_virtual_facts is set with expected value
    expected_virtualization_role = 'HP vPar'
    assert test_hpxvirtual.get_virtual_facts()[
        'virtualization_role'] == expected_virtualization_role
    # Testing if virtualization_tech_guest of get_virtual_facts is set with expected value
    expected_virtualization_tech_guest = set(['HP vPar'])
    assert test

# Generated at 2022-06-11 05:48:22.688450
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt = HPUXVirtual(None)
    assert virt is not None

# Generated at 2022-06-11 05:48:31.682463
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import HPUXVirtual
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.utils import get_file_content

    class ModuleStub:
        def __init__(self):
            self.params = {}
            self.run_command_stub = False

        def run_command(self, command, check_rc=False, close_fds=True):
            if self.run_command_stub == False:
                return (0, get_file_content('unit/module_utils/facts/virtual/hpux.get_virtual_facts.txt'), None)

# Generated at 2022-06-11 05:48:33.633294
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-11 05:48:36.347155
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    c = HPUXVirtual()
    assert c.__class__.__name__ == 'HPUXVirtual'
    assert c.platform == 'HP-UX'


# Generated at 2022-06-11 05:48:37.887600
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.platform == 'HP-UX'



# Generated at 2022-06-11 05:48:43.227720
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    virtual_obj = HPUXVirtual()
    virtual_obj._module.run_command = run_command_mock
    virtual_facts = virtual_obj.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    assert virtual_facts['virtualization_tech_guest'] == set(['HP vPar'])
    assert virtual_facts['virtualization_tech_host'] == set()


# Generated at 2022-06-11 05:48:45.925959
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    HPUXVirtual_obj = HPUXVirtual()
    # Unit test for method get_virtual_facts of class HPUXVirtual
    assert HPUXVirtual_obj.get_virtual_facts() is not None


# Generated at 2022-06-11 05:48:55.166051
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import ModuleDataCollector
    from ansible.module_utils.facts.virtual import VirtualCollector

    class Module(object):
        def run_command(self, args):
            if args == '/usr/sbin/vecheck' and os.path.exists('/usr/sbin/vecheck'):
                return 0, 'Running vecheck guest OK', ''
            elif args == '/opt/hpvm/bin/hpvminfo' and os.path.exists('/opt/hpvm/bin/hpvminfo') and os.path.exists('/usr/sbin/vecheck'):
                return 0, 'Running hpvminfo HPVM vPar OK', ''

# Generated at 2022-06-11 05:48:56.510250
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = None
    virt = HPUXVirtual(module)
    assert virt.platform == 'HP-UX'

# Generated at 2022-06-11 05:48:58.270124
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(dict())
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-11 05:49:13.371308
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    guest_tech = set()
    host_tech = set()
    virtual_facts = {}

    virtual = HPUXVirtual()

    virtual_facts = virtual.get_virtual_facts()

    assert virtual_facts['virtualization_tech_guest'] == guest_tech
    assert virtual_facts['virtualization_tech_host'] == host_tech
    assert virtual_facts['virtualization_type'] == 'guest'
    assert 'virtualization_role' not in virtual_facts

# Generated at 2022-06-11 05:49:14.849325
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    hpux_virtual.get_virtual_facts()
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-11 05:49:16.355881
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(None)
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-11 05:49:18.150210
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpv = HPUXVirtual()
    assert hpv.facts == {}

# Generated at 2022-06-11 05:49:19.532444
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual != None

# Generated at 2022-06-11 05:49:20.015357
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual()

# Generated at 2022-06-11 05:49:20.750839
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual()

# Generated at 2022-06-11 05:49:22.570969
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """ Unit test for method get_virtual_facts of class HPUXVirtual """
    # No-op for now
    pass

# Generated at 2022-06-11 05:49:24.499122
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux = HPUXVirtual({})
    assert hpux.platform == 'HP-UX'
    assert hpux.get_virtual_facts() is not None


# Generated at 2022-06-11 05:49:25.879679
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = AnsibleModule()

    v = HPUXVirtual(module)
    assert v.platform == 'HP-UX'

# Generated at 2022-06-11 05:49:42.833449
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():

    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'



# Generated at 2022-06-11 05:49:46.402641
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    instance = HPUXVirtual()
    for key in instance.get_virtual_facts().keys():
        assert key in [
            'virtualization_type',
            'virtualization_role',
            'virtualization_tech_guest',
            'virtualization_tech_host'
        ]


# Generated at 2022-06-11 05:49:49.050347
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpuxvirt_obj = HPUXVirtual(dict(module=dict()))
    assert hpuxvirt_obj
    assert hpuxvirt_obj.module is not None

# Generated at 2022-06-11 05:49:50.568342
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual({})
    assert virtual.platform == 'HP-UX'


# Generated at 2022-06-11 05:49:55.417880
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v1 = HPUXVirtual(dict(module=None))
    assert v1.platform == 'HP-UX'
    assert v1.virtualization_type == 'guest'
    assert v1.virtualization_role == 'HP vPar'
    assert v1.virtualization_role == 'HP nPar'
    assert v1.virtualization_role == 'HPVM IVM'
    assert v1.virtualization_role == 'HPVM vPar'
    assert v1.virtualization_role == 'HPVM'

# Generated at 2022-06-11 05:49:56.568368
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()


# Generated at 2022-06-11 05:49:57.796562
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv._platform == 'HP-UX'

# Generated at 2022-06-11 05:49:59.602494
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual({'module': None})
    assert virtual.platform == 'HP-UX'
    assert not virtual.gather_facts()

# Generated at 2022-06-11 05:50:01.676968
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual({})
    assert hpux_virtual.platform == 'HP-UX'
    assert hpux_virtual.module is not None



# Generated at 2022-06-11 05:50:03.530876
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = FakeAnsibleModule()
    virtual = HPUXVirtual(module)
    assert virtual.platform == 'HP-UX'


# Generated at 2022-06-11 05:50:39.934379
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    #
    # create a test class object; this will be tested
    #
    class mock_module:
        def run_command(self, cmd):
            return rc, out, err
    mod = mock_module()

    #
    # Test 1, rc == 0 and out == 'Running in HPVM guest'
    #
    rc, out, err = 0, 'Running in HPVM guest', ''
    hv = HPUXVirtual(mod)
    r = hv.get_virtual_facts()
    assert r['virtualization_type'] == 'guest' and \
        r['virtualization_role'] == 'HPVM IVM' and \
        r['virtualization_tech_guest'] == set(['HPVM IVM']) and \
        r['virtualization_tech_host'] == set()
    assert r.keys

# Generated at 2022-06-11 05:50:42.653507
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    '''
    Unit test for constructor of class HPUXVirtual
    '''
    module = AnsibleModuleMock()
    virtual = HPUXVirtual(module)
    assert virtual.platform == 'HP-UX'



# Generated at 2022-06-11 05:50:46.798846
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )

    get_virtual_facts_result = HPUXVirtual(module=module).get_virtual_facts()
    assert get_virtual_facts_result.keys() == ['virtualization_tech_guest',
                                               'virtualization_tech_host',
                                               'virtualization_type',
                                               'virtualization_role']

# Generated at 2022-06-11 05:50:54.879804
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import Collector

    class MockModule(object):
        def __init__(self, run_command_return, path_exists_return=True):
            self.run_command_return = run_command_return
            self.path_exists_return = path_exists_return

        def run_command(self, command):
            return self.run_command_return

        def path_exists(self, path):
            return self.path_exists_return

    module = None
    ret = {}

    # test case #1: vecheck is not installed
    module = MockModule((0, '', ''), False)
    v = HPUXVirtual(module)
    ret = v.get_virtual_facts()
    assert ret.get('virtualization_type') is None
    assert ret

# Generated at 2022-06-11 05:50:57.647773
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(module=None)
    assert hpux_virtual.platform == 'HP-UX'
    assert hpux_virtual._platform == 'HP-UX'

# Generated at 2022-06-11 05:51:01.130548
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    Create instance of class HPUXVirtual and checks for the attributes
    """
    collection = HPUXVirtualCollector()
    collection.collect()
    assert isinstance(collection._platform, str)
    assert isinstance(collection._fact_class, type)
    assert isinstance(collection._virtuals, list)


# Generated at 2022-06-11 05:51:10.385679
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils._text import to_bytes
    from tempfile import NamedTemporaryFile

    def py3_run_command(*args, **kwargs):
        """
        This function is used for python 3 and higher.
        This function is used for stubing run_command method of
        ansible.module_utils.basic.AnsibleModule class.
        """
        # The real run_command method throws an error if arguments are incorrect.
        if len(args) != 3:
            raise Exception("arguments should be 3.")

        # First argument is a command.
        command = args[0]

       

# Generated at 2022-06-11 05:51:18.843064
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import VirtualInfo

    # Set up test facts class
    class MockModule(object):
        def __init__(self, params=None):
            if params is None:
                params = {
                    'path': os.getcwd(),
                    'virtual_fact_class': None,
                }
            self.params = params

        def get_bin_path(self, binary):
            if binary == 'vecheck':
                if os.path.exists(binary):
                    return binary
            elif binary == 'hpvminfo':
                if os.path.exists(binary):
                    return binary
            elif binary == 'parstatus':
                if os.path.exists(binary):
                    return binary
            return None

        def run_command(self, _cmd):
            rc = 0

# Generated at 2022-06-11 05:51:20.606802
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = DummyAnsibleModule()
    v = HPUXVirtual(module)
    assert v.platform == 'HP-UX'


# Generated at 2022-06-11 05:51:22.166845
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpxvirtual = HPUXVirtual(None)
    assert 'HP-UX' == hpxvirtual.platform



# Generated at 2022-06-11 05:52:19.425520
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual(dict())
    assert virtual_obj
    assert virtual_obj.__class__.__name__ == 'HPUXVirtual'
    assert virtual_obj.platform == 'HP-UX'


# Generated at 2022-06-11 05:52:21.894962
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = AnsibleModule(argument_spec={})
    hpux_virtual = HPUXVirtual(module)
    assert hpux_virtual.get_virtual_facts() == {}



# Generated at 2022-06-11 05:52:26.833778
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = FakeAnsibleModule()
    virtual_facts = HPUXVirtual(module)
    assert isinstance(virtual_facts, HPUXVirtual)
    assert virtual_facts.platform == 'HP-UX'
    assert virtual_facts.virtualization_type == 'host'
    assert virtual_facts.virtualization_role == 'HPVM'
    assert virtual_facts.virtualization_tech_host == set()
    assert virtual_facts.virtualization_tech_guest == {'HPVM'}


# Generated at 2022-06-11 05:52:34.505091
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    host_facts = {}
    host_facts['virtualization_role'] = 'HPVM vPar'
    host_facts['virtualization_type'] = 'guest'
    host_facts['virtualization_tech_guest'] = set(['HPVM vPar'])
    host_facts['virtualization_tech_host'] = set()
    host_facts['virtualization_system'] = None
    hv = HPUXVirtual(None, host_facts)
    assert hv.get_virtual_facts() == host_facts


# Generated at 2022-06-11 05:52:40.268747
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = type('TestModule', (object, ), {'run_command': fake_run_command})
    virtual = HPUXVirtual(module)
    assert virtual.data['virtualization_type'] == 'guest'
    assert virtual.data['virtualization_role'] == 'HP nPar'
    assert set(virtual.data['virtualization_tech_guest']) == set(['HP nPar', 'HP vPar'])
    assert virtual.data['virtualization_tech_host'] == set()



# Generated at 2022-06-11 05:52:42.525680
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    from ansible.module_utils.facts.virtual.hpux import Virtual
    module = Virtual()
    assert module.platform == 'HP-UX'


# Generated at 2022-06-11 05:52:43.745191
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv

# Generated at 2022-06-11 05:52:53.578439
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import sys
    import os
    import re
    from ansible.module_utils.facts.virtual.hpar import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpvm import HPVMVirtual
    from ansible.module_utils.facts.virtual.par import HPParityVirtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector

    class MockModule(object):
        def __init__(self, params):
            self.params = params

    class MockRunCommand(object):
        def __init__(self, rc, out, err, mod_name='command'):
            self.rc = rc
            self.out = out
            self.err = err
            self.mod_name = mod_name


# Generated at 2022-06-11 05:53:03.625035
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.six import PY3
    if PY3:
        # We only need this when running unit tests on Python 3
        from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict

    module_mock = object()
    module_mock.run_command = lambda arg: [0, to_bytes(arg), '']

    virtual_facts = HPUXVirtual(module_mock).get_virtual_facts()
    assert isinstance(virtual_facts, dict)
    assert isinstance(virtual_facts['virtualization_tech_guest'], set)
    assert isinstance(virtual_facts['virtualization_tech_host'], set)

# Generated at 2022-06-11 05:53:13.394504
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class HPUXVirtual
    """
    module = AnsibleModule(
        argument_spec=dict(
        ),
        supports_check_mode=True
    )
    #
    # HP-UX virtual - HP vPar (hpvmmodule)
    #
    hpvmmodule_out = '''
vecheck: device vpars found
'''
    hpvmmodule_err = ''
    with patch('ansible.module_utils.facts.virtual.hpux.HPUXVirtual.run_command') as run_command:
        run_command.return_value = 0, hpvmmodule_out, hpvmmodule_err
        virtual = HPUXVirtual(module)
        virtual_facts = virtual.get_virtual_facts()
       

# Generated at 2022-06-11 05:54:01.381634
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    vs = HPUXVirtual(dict(ANSIBLE_MODULE_ARGS={}))
    assert vs.platform == 'HP-UX'
    assert vs._virtual_facts == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

# Generated at 2022-06-11 05:54:03.008799
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # This code is used to test get_virtual_facts method of class HPUXVirtual
    # Please see the source code of class HPUXVirtual to understand how it works.
    pass

# Generated at 2022-06-11 05:54:05.344655
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict()
    )
    hpux_virtual = HPUXVirtual(module)
    virtual_facts = hpux_virtual.get_virtual_facts()
    assert 'virtualization_tech_host' in virtual_facts


# Generated at 2022-06-11 05:54:11.136346
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class ModuleStub(object):
        def run_command(self, arg):
            if arg == '/usr/sbin/vecheck':
                return 0, '', ''
            elif arg == '/opt/hpvm/bin/hpvminfo':
                return 0, 'Running HPVM vPar\n', ''
            elif arg == '/usr/sbin/parstatus':
                return 0, '', ''
            else:
                return 256, '', ''

    module = ModuleStub()
    virtual = HPUXVirtual(module=module)
    virtual_facts = virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HPVM vPar'

# Generated at 2022-06-11 05:54:13.009023
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    a = HPUXVirtual(None)
    a.get_virtual_facts()
    assert a.platform == 'HP-UX'

if __name__ == '__main__':
    test_HPUXVirtual()

# Generated at 2022-06-11 05:54:19.053430
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    class MockModule(object):

        def __init__(self):
            self.run_command_result_map = {
                "/usr/sbin/vecheck": [
                    0,
                    "Test vPar (os_name=HP-UX, os_release=B.11.31, os_version=U ia64)",
                    ""
                ],
                "/opt/hpvm/bin/hpvminfo": [
                    0,
                    "Running as a HPVM vPar guest",
                    ""
                ],
                "/usr/sbin/parstatus": [
                    0,
                    "A",
                    "A"
                ]
            }

        def run_command(self, cmd, check_rc=True):
            return self.run_command_result_map[cmd]


# Generated at 2022-06-11 05:54:20.186218
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == "HP-UX"

# Generated at 2022-06-11 05:54:21.973786
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual({})
    if not hpux_virtual.module:
        raise Exception("Failed to instantiate HPUXVirtual object")


# Generated at 2022-06-11 05:54:22.695128
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual(dict(module=dict()))

# Generated at 2022-06-11 05:54:25.062225
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    facts = {}
    module = FakeAnsibleModule(facts)
    verif = HPUXVirtual(module)
    verif.module = FakeAnsibleModule(facts)
    facts = verif.get_virtual_facts()
    return facts


# Generated at 2022-06-11 05:55:35.091760
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Unit test for method get_virtual_facts of class HPUXVirtual
    v1 = {
        "virtualization_type": "guest",
        "virtualization_role": "HP vPar",
        "virtualization_tech_host" : set(),
        "virtualization_tech_guest" : set(["HP vPar"])
    }

    v2 = {
        "virtualization_type": "host",
        "virtualization_role": "HPVM",
        "virtualization_tech_host" : set(["HPVM"]),
        "virtualization_tech_guest" : set(),
    }


# Generated at 2022-06-11 05:55:38.359211
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # As of now, constructor is not called from any where directly
    # so commenting assert statements
    #assert HPUXVirtual().__dict__['platform'] == 'HP-UX'
    #assert HPUXVirtual().__dict__['fact_class'] == HPUXVirtual
    return None


# Generated at 2022-06-11 05:55:46.217268
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    module = MagicMock()
    module.run_command = MagicMock(return_value=(0, '', ''))
    hp_virtual = HPUXVirtual(module)
    virtual_facts = hp_virtual.get_virtual_facts()
    assert len(virtual_facts['virtualization_tech_host']) == 0
    assert len(virtual_facts['virtualization_tech_guest']) == 0
    assert virtual_facts['virtualization_type'] == 'full'
    assert virtual_facts['virtualization_role'] == 'Physical'

# Generated at 2022-06-11 05:55:47.263184
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual({})


# Generated at 2022-06-11 05:55:54.956373
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Create a fake module object
    class FakeModule(object):
        def run_command(self, cmd):
            if cmd == '/usr/sbin/vecheck':
                return (0, 'fake output', 'fake error')
            elif cmd == '/opt/hpvm/bin/hpvminfo':
                return (0, 'fake output Running HPVM vPar', 'fake error')
            elif cmd == '/usr/sbin/parstatus':
                return (0, 'fake output', 'fake error')

    # Create a fake ansible facts
    fake_ansible_facts = {'kernel': 'HP-UX'}

    # Create a instance of HPUXVirtual
    hpx = HPUXVirtual(FakeModule(), fake_ansible_facts)

    # Run get_virtual_facts method
    hpx.get_virtual_

# Generated at 2022-06-11 05:56:05.216943
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.virtual import HPUXVirtual

    argument_spec = dict(
        gather_subset=dict(default=['all'], type='list'),
        filter=dict(default=None, type='list')
    )
    module = basic.AnsibleModule(argument_spec=argument_spec)
    module.exit_json = basic.ansible_module_exit_json
    HPUXVirtualCollector.collect(module)
    virtual_facts = module._result['ansible_facts']
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts

# Generated at 2022-06-11 05:56:06.535569
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual({})
    assert virtual_obj.platform == 'HP-UX'

# Generated at 2022-06-11 05:56:10.695916
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    modules = {}
    module = None
    module = "ansible.module_utils.facts.virtual.hpux.HPUXVirtual(module, callback)".split('.')
    module_name = module.pop()
    module_class_name = module.pop()
    module_obj = __import__('.'.join(module))
    for m in module[1:]:
        module_obj = getattr(module_obj, m)
    module_class = getattr(module_obj, module_class_name)
    module_instance = module_class(module)
    assert module_instance.get_virtual_facts() == {}

# Generated at 2022-06-11 05:56:12.082814
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = MockAnsibleModule()
    _virtual_hpux = HPUXVirtual(module)
    _virtual_hpux.get_virtual_facts()

# Generated at 2022-06-11 05:56:13.010938
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert(HPUXVirtualCollector._platform == 'HP-UX')