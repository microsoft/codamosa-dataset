

# Generated at 2022-06-11 05:46:33.806477
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec = {})
    mock_virtual_facts = {
        'virtualization_type': 'guest',
        'virtualization_role': 'HP vPar',
        'virtualization_tech_guest': set(['HP vPar']),
        'virtualization_tech_host': set(),
    }
    mock_vecheck_cmd = ('/usr/sbin/vecheck', '', 0)
    mock_vecheck_cmd_fail = ('/usr/sbin/vecheck', '', 1)
    mock_hpvminfo_cmd = ('/opt/hpvm/bin/hpvminfo', 'Running HPVM vPar', 0)
    mock_hpvminfo_cmd_1 = ('/opt/hpvm/bin/hpvminfo', 'Running HPVM guest', 0)


# Generated at 2022-06-11 05:46:37.234862
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual('fake_module')
    hpux_virtual.get_virtual_facts()
    assert hpux_virtual.platform == 'HP-UX'
    assert hpux_virtual.guest_facts == hpux_virtual.host_facts

# Generated at 2022-06-11 05:46:38.957077
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual_obj = HPUXVirtual(dict(module=dict()))
    assert hpux_virtual_obj.platform == 'HP-UX'

# Generated at 2022-06-11 05:46:46.979856
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import VirtualCollector
    from ansible.module_utils.facts import ModuleDataCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector

    virtual_facts = HPUXVirtual(base_collector=BaseFactCollector(module=None))
    return_data = virtual_facts.get_virtual_facts()
    assert isinstance(return_data, dict)
    assert isinstance(return_data['virtualization_tech_guest'], set)


# Generated at 2022-06-11 05:46:55.332618
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = type('module', (), {})()
    module.run_command = lambda x: (0, '/usr/sbin/vecheck', '')
    hv = HPUXVirtual(module)
    assert hv.collect() == {'virtualization_tech_guest': set(['HP vPar']),
                            'virtualization_type': 'guest',
                            'virtualization_role': 'HP vPar',
                            'virtualization_tech_host': set()}

    module.run_command = lambda x: (0, 'Running HPVM guest', '')
    hv = HPUXVirtual(module)

# Generated at 2022-06-11 05:46:58.652843
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
  obj = HPUXVirtual({})
  assert obj.virtualization_type == "guest"
  assert obj.virtualization_role == "HP nPar"
  assert obj.virtualization_tech_guest == set(['HP nPar'])
  assert obj.virtualization_tech_host == set()

# Generated at 2022-06-11 05:47:07.515733
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    if not os.path.exists('/usr/sbin/vecheck'):
        return
    if not os.path.exists('/opt/hpvm/bin/hpvminfo'):
        return

    def execute_module(module):
        return module.run_command(module.params['command'])

    def get_ansible_module():
        from ansible.module_utils.facts import virtual
        # Don't load the class, but call its get_virtual_facts method
        virtual_obj = virtual.Virtual()
        return virtual_obj

    from ansible.module_utils.facts.virtual import HPUXVirtual
    import contextlib
    from ansible.module_utils._text import to_bytes

    hpux_virtual = HPUXVirtual()

    # First inject the module object
    hpux_virtual.module

# Generated at 2022-06-11 05:47:09.732746
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = AnsibleModule(argument_spec={})
    virt = HPUXVirtual(module)
    assert virt.module == module

# Generated at 2022-06-11 05:47:11.782986
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    host_facts = {}
    hpux_virtual = HPUXVirtual(module=None, facts=host_facts)
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-11 05:47:20.425358
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock()
    hv = HPUXVirtual(module)

    # If vecheck is present, we are on a vPar
    rc = 0
    out = "some vecheck output"
    err = ""
    module.run_command.return_value = (rc, out, err)
    virtual_facts = hv.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    assert virtual_facts['virtualization_tech_guest'] == set(['HP vPar'])
    assert virtual_facts['virtualization_tech_host'] == set()

    # If hpvminfo reports a vPar, we are on a v

# Generated at 2022-06-11 05:47:34.633413
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    vp = HPUXVirtual({'module': {'run_command': run_command}}, {})
    assert vp.__class__.__name__ == 'HPUXVirtual'
    assert vp.platform == 'HP-UX'
    assert vp._module == {'run_command': run_command}
    assert vp._facts == {}



# Generated at 2022-06-11 05:47:39.902686
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    virt = HPUXVirtual(dict())
    virt.module = MagicMock()
    virt.module.run_command = MagicMock(return_value=(0, 'success', ''))
    virtual_facts = virt.get_virtual_facts()
    assert virtual_facts == {'virtualization_type': 'guest',
                             'virtualization_role': 'HP nPar',
                             'virtualization_tech_guest': {'HP nPar'},
                             'virtualization_tech_host': set()}

# Generated at 2022-06-11 05:47:45.263987
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = AnsibleModule(
        argument_spec = dict()
    )
    virtual_facts = HPUXVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_tech_guest'] == set(['HP vPar'])


# Generated at 2022-06-11 05:47:53.829803
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import ModuleExecutor
    from ansible.module_utils.facts.virtual.hp import HPUXVirtual

    executor = ModuleExecutor()
    executor.find_hostname = lambda: 'host.example.com'

    path = os.path.dirname(__file__)
    class MockModule(object):
        def __init__(self):
            self.run_command = lambda command, check_rc=None: (0, None, None)
            self.params = {'gather_subset': ['!all', 'virtual']}
            self.get_bin_path = lambda executable: executable
            self.exit_json = lambda **kwargs: kwargs

    mod = MockModule()
    plugin = HPUXVirtual(module=mod, executor=executor)

    facts

# Generated at 2022-06-11 05:48:01.949853
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Unit test to check the output of class HPUXVirtual.get_virtual_facts method.
    """
    _module = MockModule()
    _module.run_command = Mock(return_value=(0, None, None))
    _ve = HPUXVirtual(_module)

    _expected_output = {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}
    with patch.object(os.path, 'exists', return_value=False):
        _ve_output = _ve.get_virtual_facts()
    assert _ve_output == _expected_output


# Generated at 2022-06-11 05:48:02.516488
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    pass

# Generated at 2022-06-11 05:48:05.173989
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(dict())
    assert hv.is_linux() is False
    assert hv.is_hpux() is True


# Generated at 2022-06-11 05:48:07.890380
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec=dict())
    module.exit_json = lambda **kwargs: kwargs
    virtual = HPUXVirtual(module)
    virtual.get_virtual_facts()
    print(virtual.virtual_facts)

# Generated at 2022-06-11 05:48:16.538632
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    # Mock module and command outputs
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    module.run_command = mock.Mock(return_value=(0, 'out', 'err'))
    module.run_command.side_effect = [
        (0, 'out', 'err'),
        (0, 'out', 'err'),
        (0, 'out', 'err'),
    ]

    # Mock return data (side_effect) of os.path.exists
    os.path.exists = mock.Mock(return_value=True)

    # Mock return data (side_effect) of re.match
    re.match = mock.Mock(return_value=True)

    # Mock return data (side_effect

# Generated at 2022-06-11 05:48:20.359129
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'
    platform_facts = virtual_facts.get_virtual_facts()
    assert 'virtualization_type' in platform_facts
    assert 'virtualization_role' in platform_facts
    assert 'virtualization_tech_guest' in platform_facts
    assert 'virtualization_tech_host' in platform_facts

# Generated at 2022-06-11 05:48:31.162871
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual({})
    assert h.platform == 'HP-UX'

# Generated at 2022-06-11 05:48:34.969680
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():

    h = HPUXVirtual()
    assert h.platform == 'HP-UX'
    assert h.groups == ('virtual',)
    assert 'virtualization_type' in h.keys
    assert 'virtualization_role' in h.keys


# Generated at 2022-06-11 05:48:42.420547
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = MockModule()
    hv = HPUXVirtual(module)
    assert hv.get_virtual_facts() == {
        'virtualization_role': 'HP vPar',
        'virtualization_type': 'guest',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': {'HP vPar'}
    }

    module.run_command.assert_any_call("/usr/sbin/vecheck")
    module.run_command.assert_any_call("/opt/hpvm/bin/hpvminfo")
    module.run_command.assert_any_call("/usr/sbin/parstatus")



# Generated at 2022-06-11 05:48:46.804279
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # test_input_example = {'virtualization_type': 'HP-UX', 'virtualization_role': 'guest'}
    # test_output_example = {'virtualization_type': 'HP-UX', 'virtualization_role': 'guest'}
    # virtual = HPUXVirtual(test_input_example)
    # assert virtual.fact == test_output_example
    pass

# Generated at 2022-06-11 05:48:52.103535
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    mockmodule = Mock()
    mockmodule.run_command.return_value = (0, '', '')
    hpux_virtual = HPUXVirtual(module=mockmodule)
    assert hpux_virtual.get_virtual_facts() == {'virtualization_tech_host': set(),
                                                'virtualization_tech_guest': set(),
                                                'virtualization_type': '',
                                                'virtualization_role': ''}

# Generated at 2022-06-11 05:48:53.600293
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux = HPUXVirtual()
    assert hpux.platform == 'HP-UX'


# Generated at 2022-06-11 05:48:55.880208
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual({})
    assert v

    v = HPUXVirtual({'ANSIBLE_HPUX': '1'})
    assert v


# Generated at 2022-06-11 05:48:57.166060
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()


# Generated at 2022-06-11 05:48:59.585084
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    result = hpux_virtual.get_virtual_facts()
    assert result['virtualization_tech_guest'] or result['virtualization_tech_host']

# Generated at 2022-06-11 05:49:00.070071
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    return None

# Generated at 2022-06-11 05:49:22.944795
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    This method unit tests get_virtual_facts method of class
    HPUXVirtual
    """
    import sys
    from ansible.module_utils.facts.virtual.hpux_virtual import HPUXVirtual

    if sys.version_info[0] < 3:
        import mock
        from mock import Mock
        from mock import patch
    else:
        from unittest import mock
        from unittest.mock import Mock
        from unittest.mock import patch

    mock_module = Mock()
    mock_module.run_command.return_value = (0, 'Running HPVM guest', '')
    mock_module.check_mode = False

    with patch('ansible.module_utils.facts.virtual.hpux_virtual.os.path.exists') as mock_path_exists:
        mock

# Generated at 2022-06-11 05:49:30.463355
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    facts = dict()
    module = dict()
    hv = HPUXVirtual(facts, module)

    import mock
    mock_run_command = mock.Mock()
    mock_run_command.return_value = 0, 'Running HPVM guest in HPVM vPar', ''
    hv.module.run_command = mock_run_command

    result = hv.get_virtual_facts()
    assert result == {'virtualization_type': 'guest', 'virtualization_role': 'HPVM IVM',
                      'virtualization_tech_host': set(), 'virtualization_tech_guest': {'HPVM vPar', 'HPVM IVM'}}

    mock_run_command.return_value = 0, 'Running HP vPar', ''
    result = hv.get_virtual_facts()

# Generated at 2022-06-11 05:49:31.434941
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hp_virtual = HPUXVirtual(None)


# Generated at 2022-06-11 05:49:32.443963
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual({})
    assert h.platform == "HP-UX"

# Generated at 2022-06-11 05:49:34.092472
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'
    assert virtual_facts._platform == 'HP-UX'

# Generated at 2022-06-11 05:49:35.528706
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    obj = HPUXVirtual({}, {})
    assert 'HP-UX' == obj.platform


# Generated at 2022-06-11 05:49:36.757066
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    virtual_facts.get_virtual_facts()

# Generated at 2022-06-11 05:49:44.171069
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Run method get_virtual_facts of class HPUXVirtual and compare result to
    expected result in virtual_facts dictionary, using 'HPVM' as all_facts
    input.
    Expected result is based on vmware running on HP-UX.
    """
    # pylint: disable=protected-access
    all_facts = {'virtualization_type': 'HPVM'}
    virtual_facts = {'virtualization_tech_guest': {'HPVM'},
                     'virtualization_tech_host': set(),
                     'virtualization_role': 'HPVM',
                     'virtualization_type': 'guest'}
    hpux_virtual = HPUXVirtual(all_facts)
    result = hpux_virtual.get_virtual_facts()
    assert virtual_facts == result



# Generated at 2022-06-11 05:49:52.907457
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    This method is actually the unit test for method get_virtual_facts of class HPUXVirtual
    """
    # Create a module object
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create a HP-UXVirtual object without initializing it
    hpuxvirtual = HPUXVirtual(module)
    hpuxvirtual.module.run_command = MagicMock(return_value=(0, '', ''))
    hpuxvirtual.module.run_command.return_value = (0, '', '')

    # Unset vecheck_path
    hpuxvirtual.vecheck_path = None

    # Check virtualization_type
    # Set vecheck_path
    hpuxvirtual.vecheck_path = '/usr/sbin/vecheck'
    hpux

# Generated at 2022-06-11 05:50:00.875882
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    #
    # mock the module and its methods
    #
    g_hpux_virt = HPUXVirtual()
    g_hpux_virt.module = MagicMock()

    g_hpux_virt.module.run_command.return_value = (0,'Running HPVM vPar guest','')

    hpux_virtual_facts = g_hpux_virt.get_virtual_facts()
    assert hpux_virtual_facts['virtualization_type'] == 'guest'
    assert hpux_virtual_facts['virtualization_role'] == 'HPVM vPar'
    assert hpux_virtual_facts['virtualization_tech_host'] == set()
    assert hpux_virtual_facts['virtualization_tech_guest'] == set(['HPVM vPar'])

    g_hpux_virt.module.run_

# Generated at 2022-06-11 05:50:35.921027
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    import os
    import tempfile
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual

    hv = HPUXVirtual(module=None)
    dirpath = tempfile.gettempdir()

# Generated at 2022-06-11 05:50:37.425100
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    obj = HPUXVirtual({})
    assert obj.platform == 'HP-UX'


# Generated at 2022-06-11 05:50:45.308810
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    unit test for constructor of class HPUXVirtual
    """
    module = FakeModule()
    hpux_virtual = HPUXVirtual(module)
    assert hpux_virtual.module == module
    assert hpux_virtual.platform == 'HP-UX'
    assert hpux_virtual.virtualization_type == None
    assert hpux_virtual.virtualization_role == None
    assert hpux_virtual.virtualization_subrole == None
    assert hpux_virtual.virtualization_system == None
    assert hpux_virtual.virtualization_uuid == None
    assert hpux_virtual.virtualization_product_name == None
    assert hpux_virtual.virtualization_product_version == None
    assert hpux_virtual.virtualization_product_uuid == None
    assert hpux_virtual.virtualization_product_serial

# Generated at 2022-06-11 05:50:47.385334
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    virtual_facts_test = HPUXVirtual()
    assert isinstance(virtual_facts_test.get_virtual_facts(), dict)

# Generated at 2022-06-11 05:50:53.278911
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import HPUXVirtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts import collect_facts

    module = collect_facts.AnsibleModuleMock()
    module.run_command = collect_facts.run_command_mock

    hv = HPUXVirtual(module)
    facts = hv.get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HPVM vPar'



# Generated at 2022-06-11 05:50:58.262027
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    result = HPUXVirtualCollector(dict(module=dict(run_command=run_command))).get_virtual_facts()

    assert result['virtualization_type'] == 'guest'
    assert result['virtualization_role'] == 'HP vPar'
    assert result['virtualization_tech_guest'] == set(['HP vPar'])
    assert result['virtualization_tech_host'] == set([])


# Generated at 2022-06-11 05:50:59.838127
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux = HPUXVirtual(dict(module=None))
    assert hpux.platform == 'HP-UX'

# Generated at 2022-06-11 05:51:01.938075
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'
    assert hpux_virtual.is_hpux_virtual()

# Generated at 2022-06-11 05:51:11.428976
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_native
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from tempfile import NamedTemporaryFile
    import json

    class FakeModule():

        def __init__(self):
            self.params = {}
            self.tmpdir = ''

        def fail_json(self, msg, **kwargs):
            kwargs['failed'] = True
            print(json.dumps(kwargs))

        def exit_json(self, **kwargs):
            print(json.dumps(kwargs))

        def run_command(self, args):
            line = NamedTemporaryFile(mode='w+t', dir=self.tmpdir)

# Generated at 2022-06-11 05:51:14.617770
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = None
    virtual_facts = HPUXVirtual(module)
    assert virtual_facts.platform == 'HP-UX'

# To avoid "missing docstring" complaint from pylint
if __name__ == '__main__':
    test_HPUXVirtual()

# Generated at 2022-06-11 05:51:43.735749
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual()
    assert h is not None


# Generated at 2022-06-11 05:51:48.494467
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_module = type('test', (object,), {'run_command': (lambda self, cmd, use_unsafe_shell: 6, 'out', 'err')})
    test_instance = HPUXVirtual(test_module)
    assert test_instance.get_virtual_facts() == {}


# Generated at 2022-06-11 05:51:57.584947
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    class MockAnsibleModule:
        _result = {}
        params = {}

        def run_command(self, command):
            # NOTE: Expected values are derived from the
            # man page for vecheck, hpvminfo and parstatus
            if command[0] == '/usr/sbin/vecheck':
                return 0, "", ""
            elif command[0] == '/opt/hpvm/bin/hpvminfo':
                return 0, "Running HPVM vPar", ""
            elif command[0] == '/usr/sbin/parstatus':
                return 0, "", ""
            else:
                raise Exception("Unknown command: '%s'" % command)

        def exit_json(self, **kwargs):
            self._result = kwargs


# Generated at 2022-06-11 05:52:06.725092
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """ Unit test for HPUXVirtual.get_virtual_facts() """
    #
    # parstatus
    #
    class ModuleParStatus(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def run_command(self, cmd):
            return self.rc, self.out, self.err

    #
    # vecheck
    #
    class ModuleVecheck(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def run_command(self, cmd):
            return self.rc, self.out, self.err

    #
    # hpvminfo
    #

# Generated at 2022-06-11 05:52:09.121614
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(dict(module=None))
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-11 05:52:15.234899
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpu_x import HPUXVirtual
    # Arrange
    v = HPUXVirtual()
    class mocked_module:
        def run_command(self, cmd):
            return 0, 'foo', ''
    v.module = mocked_module()

    # Act
    virtual_facts = v.get_virtual_facts()

    # Assert
    assert virtual_facts == {}

# Generated at 2022-06-11 05:52:16.923458
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    x = HPUXVirtual()
    assert x.platform == 'HP-UX'


# Generated at 2022-06-11 05:52:25.106166
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )
    module.run_command = MagicMock()
    class MockHPUXVirtual(HPUXVirtual):
        def __init__(self, module):
            self.module = module
            self.info = {}
    hpuxvirtual = MockHPUXVirtual(module)

    # Generate vecheck output
    rc = 0
    out = 'test'
    err = ''
    hpuxvirtual.module.run_command.return_value = (rc, out, err)
    hpuxvirtual.get_virtual_facts()

# Generated at 2022-06-11 05:52:28.787619
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual({})
    assert h.platform == 'HP-UX'

# Generated at 2022-06-11 05:52:30.417038
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtualhpux = HPUXVirtual()
    assert virtualhpux.platform == 'HP-UX'



# Generated at 2022-06-11 05:53:17.044695
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpar import HPUXVirtualCollector, HPUXVirtual
    from ansible.module_utils.facts.virtual.hpvm import HPUXVirtualCollector, HPUXVirtual

    hpar_host = {
        'virtualization_type': 'host',
        'virtualization_role': 'HP vPar',
        'virtualization_tech_host': ['HP vPar'],
        'virtualization_tech_guest': []
    }

    hpar_guest = {
        'virtualization_type': 'guest',
        'virtualization_role': 'HP vPar',
        'virtualization_tech_host': [],
        'virtualization_tech_guest': ['HP vPar']
    }


# Generated at 2022-06-11 05:53:21.413310
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import Virtual, HPUXVirtual
    module = AnsibleModuleMock()
    virt = Virtual(module)
    hpvirt = HPUXVirtual(module)
    assert hpvirt.get_virtual_facts() == virt.get_virtual_facts()



# Generated at 2022-06-11 05:53:23.226658
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-11 05:53:25.218910
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(None)
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-11 05:53:28.324702
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(dict())
    attributes = dir(hv)
    assert 'platform' in attributes
    assert '_platform' in attributes
    assert '_virtual' in attributes
    assert 'get_virtual_facts' in attributes

# Generated at 2022-06-11 05:53:37.370908
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    This unit test is for method get_virtual_facts of class HPUXVirtual.
    In this unit test, we will check if facts 'virtualization_tech_guest' and 'virtualization_tech_host'
    are generated and what the values are.
    """
    # Create a module object
    my_module = AnsibleModule(argument_spec=dict())
    # Create an instance of HPUXVirtual class
    hpuxvirtual = HPUXVirtual(module=my_module)
    # Create a dictionary to store return values from get_virtual_facts method
    my_virtual_facts = dict()
    # Set value for key virtualization_tech_guest
    my_virtual_facts['virtualization_tech_guest'] = set()
    # Set value for key virtualization_tech_host

# Generated at 2022-06-11 05:53:45.359519
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    content = {}
    content['stdout'] = '''
Determining the virtualization state of this system.
This may take a moment.

This machine is a guest in a Virtual Environment.

This machine is not running in VMware.


This machine is a guest in a Virtual Environment.

This machine is running in HPVM.

'''
    content['stdout_lines'] = [
        'Determining the virtualization state of this system.',
        'This may take a moment.',
        '',
        'This machine is a guest in a Virtual Environment.',
        '',
        'This machine is not running in VMware.',
        '',
        '',
        'This machine is a guest in a Virtual Environment.',
        '',
        'This machine is running in HPVM.',
        ''
    ]

    moduleM

# Generated at 2022-06-11 05:53:50.970870
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_module = AnsibleModule(argument_spec={})
    test_module.run_command = MagicMock(
        return_value=(0, 'Running HPVM vPar', ''))
    test_facts = HPUXVirtual({'module': test_module}).get_virtual_facts()
    assert test_facts['virtualization_role'] == 'HPVM vPar'
    assert test_facts['virtualization_type'] == 'guest'
    assert 'HPVM vPar' in test_facts['virtualization_tech_host']
    assert 'HPVM vPar' in test_facts['virtualization_tech_guest']

# Generated at 2022-06-11 05:53:58.155540
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual

    # Mock module object
    class MockConnection(object):
        def __init__(self):
            self.module = None

        def run_command(self, cmd):
            if cmd == '/usr/sbin/vecheck':
                rc, out, err = 0, 'RUNNING_ON_HPVM_VPAR', ''
            elif cmd == '/opt/hpvm/bin/hpvminfo':
                rc, out, err = 0, 'Running on HPVM vPar', ''
            elif cmd == '/usr/sbin/parstatus':
                rc, out, err = 0, 'RUNNING_ON_HPVM_VPAR', ''
            else:
                rc, out, err = -1, '', ''
            return rc,

# Generated at 2022-06-11 05:54:04.469916
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    def test_module(module_args, module_result):
        from ansible.module_utils import basic
        from ansible.module_utils.facts import collector
        from ansible.module_utils.facts import virtual

        facts_collector = collector.get_collector(
            'HPUXVirtualCollector',
            ansible_module=basic.AnsibleModule(
                argument_spec=module_args,
                supports_check_mode=False,
                check_invalid_arguments=False,
            )
        )

# Generated at 2022-06-11 05:56:16.964909
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    headers = {
        'command': 'cat /usr/sbin/vecheck /opt/hpvm/bin/hpvminfo /usr/sbin/parstatus',
        'rc': '0',
        'stdout': '',
        'stdout_lines': [
            "",
            "",
            "",
        ]
    }
    module = AnsibleModule(argument_spec={})
    virtual_facts_obj = HPUXVirtual(module)

    # Test output when /usr/sbin/vecheck and /opt/hpvm/bin/hpvminfo exists
    headers['stdout_lines'][0] = oswalk_output['/usr/sbin/vecheck']
    headers['stdout_lines'][1] = oswalk_output['/opt/hpvm/bin/hpvminfo']