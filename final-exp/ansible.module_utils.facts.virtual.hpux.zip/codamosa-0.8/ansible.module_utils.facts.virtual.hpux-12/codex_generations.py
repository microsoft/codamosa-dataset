

# Generated at 2022-06-11 05:46:33.377768
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    x = HPUXVirtual(dict())
    assert x.platform == 'HP-UX'
    assert x.get_virtual_facts() == {'virtualization_type': False, 'virtualization_role': False,
                                     'virtualization_tech_host': {}, 'virtualization_tech_guest': {}}

# Generated at 2022-06-11 05:46:34.285641
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual()

# Generated at 2022-06-11 05:46:36.729884
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'
    assert virtual_facts.get_virtual_facts() is not None


# Generated at 2022-06-11 05:46:38.849765
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    Unit test for constructor of class HPUXVirtual
    """
    h = HPUXVirtual({})
    assert h.platform == "HP-UX"

# Generated at 2022-06-11 05:46:43.438928
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(None)
    # _platform is 'Linux'
    assert virtual._platform == 'HP-UX'
    # _collector_platforms is a dictionary with two entries
    assert virtual._collector_platforms == {'HP-UX': [HPUXVirtualCollector]}
    # platform is 'Linux'
    assert virtual.platform == 'HP-UX'


# Generated at 2022-06-11 05:46:44.929226
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = FakeAnsibleModule()
    HPUXVirtual(module)



# Generated at 2022-06-11 05:46:46.107555
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual('module')
    assert h.platform == 'HP-UX'

# Generated at 2022-06-11 05:46:50.735459
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import ModuleStub

    module = ModuleStub()
    hpux_virtual_obj = HPUXVirtual(module)
    hpux_virtual_obj.get_virtual_facts()
    assert hpux_virtual_obj.facts.get('virtualization_tech_host') == set()
    assert hpux_virtual_obj.facts.get('virtualization_tech_guest') == set()



# Generated at 2022-06-11 05:46:52.301485
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual({'module': None})
    assert v.platform == 'HP-UX'


# Generated at 2022-06-11 05:47:00.563675
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    test_module.run_command = MagicMock(return_value=(0, '/opt/hpvm/bin/hpvminfo: Running HPVM guest', ''))
    test_module.exists = MagicMock(side_effect=[False, True, True, True, True])

    # test 'virtualization_type':'host'
    hpux_virtual = HPUXVirtual(test_module)
    facts = hpux_virtual.collect()
    assert {
            'virtualization_type': 'host',
            'virtualization_role': 'HPVM',
            'virtualization_tech_guest': {'HPVM'}
    } == facts

    # test 'virtualization_type':'guest

# Generated at 2022-06-11 05:47:10.384087
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'



# Generated at 2022-06-11 05:47:11.210440
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual()


# Generated at 2022-06-11 05:47:18.943273
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual, VirtualCollector
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    # Check get_virtual_facts method of class HPUXVirtual
    name = os.name
    if 'posix' in name:
        os.name = 'posix'
    else:
        os.name = 'nt'
    virtual_facts = HPUXVirtual(module).get_virtual_facts()
    os.name = name
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP nPar'

# Generated at 2022-06-11 05:47:27.737514
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # set the module path and import HPUXVirtual
    module_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
    sys.path.insert(0, module_path)
    from ansible.module_utils.facts.virtual.hpux_virtual import HPUXVirtual
    # set the fact state
    fact_state = {
        'module': MockModule()
    }
    # get the instance of HPUXVirtual
    virtual_obj = HPUXVirtual(fact_state)
    # call the method get_virtual_facts
    virtual_dict = virtual_obj.get_virtual_facts()
    # assert the result
    assert virtual_dict['virtualization_type'] == 'guest'

# Generated at 2022-06-11 05:47:36.099850
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class HPUXMockModule(object):
        def run_command(self, command):
            # For unit testing, we assume vecheck, hpvminfo and parstatus
            # are all installed in the same directory
            if os.path.basename(command) == "vecheck":
                return 0, "running HP vPar", ""
            elif os.path.basename(command) == "hpvminfo":
                return 0, "Running on HPVM guest", ""
            elif os.path.basename(command) == "parstatus":
                return 0, "running HP nPar", ""
            else:
                return 1, "", ""

    obj = HPUXVirtual(module=HPUXMockModule())
    virtual_facts = obj.get_virtual_facts()
    assert virtual_facts['virtualization_type']

# Generated at 2022-06-11 05:47:39.113447
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    vm = HPUXVirtual(dict())
    assert vm.platform == 'HP-UX'
    assert vm.get_virtual_facts() == {'virtualization_tech_guest': set(),
                                      'virtualization_tech_host': set()}


# Generated at 2022-06-11 05:47:40.621264
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual({})
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-11 05:47:41.834683
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-11 05:47:44.832997
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    Test case for constructor and
    - virtualization_type
    - virtualization_role
    """
    virtual_instance = HPUXVirtual()
    assert virtual_instance.get_virtual_facts()



# Generated at 2022-06-11 05:47:50.025221
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    HPUXVirtual_instance = HPUXVirtual(module)
    facts_dictionary = HPUXVirtual_instance.get_virtual_facts()

    assert 'virtualization_type' in facts_dictionary
    assert 'virtualization_role' in facts_dictionary
    assert 'virtualization_tech_guest' in facts_dictionary
    assert 'virtualization_tech_host' in facts_dictionary



# Generated at 2022-06-11 05:48:01.948858
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    facts = HPUXVirtual({},{})
    assert facts.virtualization_role == None

# Generated at 2022-06-11 05:48:03.674455
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-11 05:48:05.534991
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_check = HPUXVirtual(dict())
    assert virtual_check.platform == 'HP-UX'


# Generated at 2022-06-11 05:48:11.346523
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """ Unit test for method get_virtual_facts of class HPUXVirtual """
    class_HPUXVirtual = HPUXVirtual({"module": {"run_command": run_command}})
    (return_value, out, err) = class_HPUXVirtual.get_virtual_facts()
    assert return_value == {'virtualization_type': 'guest',
                            'virtualization_role': 'HP vPar',
                            'virtualization_tech_guest': set(['HP vPar']),
                            'virtualization_tech_host': set([])}



# Generated at 2022-06-11 05:48:19.549253
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import HPUXVirtual
    from ansible.module_utils.facts.virtual.base import AnsibleModule
    from ansible.module_utils.facts import stubs
    module = AnsibleModule(stubs.MODULE_ARGS)
    module.run_command = stubs.stub_run_command
    hpux_virtual = HPUXVirtual(module)
    module.stub_run_command = stubs.stub_run_command
    virtual_facts = hpux_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_tech_guest'] == set('HP vPar HPVM vPar HPVM IVM HP nPar'.split())
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_type']

# Generated at 2022-06-11 05:48:20.326718
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual({}, {}, {})

# Generated at 2022-06-11 05:48:28.809572
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible_collections.os.hpux.tests.unit.compat.mock import MagicMock
    from ansible_collections.os.hpux.tests.unit.compat.mock import patch

    class ModuleStub(object):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.return_value = None

        def run_command(self, *args, **kwargs):
            return self.return_value
            pass

    class RunCmdStub(object):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.script = []

        def __call__(self, *args, **kwargs):

            cmd = args[0]
            print("run command: %s" % " ".join(cmd))


# Generated at 2022-06-11 05:48:30.541345
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert isinstance(virtual_facts, dict)

# Generated at 2022-06-11 05:48:32.932558
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict(ANSIBLE_MODULE_ARGS={}))

    assert virtual.platform == 'HP-UX'

# Generated at 2022-06-11 05:48:34.495800
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts

# Generated at 2022-06-11 05:48:47.578686
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.__name__ == 'HPUXVirtual'
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-11 05:48:56.370161
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.virtual import HPUXVirtualCollector

    class MockModule:
        @staticmethod
        def get_bin_path(binary, required=False, opt_dirs=[]):
            return binary

        @staticmethod
        def run_command(cmd):
            print(cmd)

    class MockFactCollector(FactCollector):
        def __init__(self, *args, **kwargs):
            self.facts = {
                'module_utils': 'ansible/module_utils/facts',
                'kernel': 'HP-UX',
            }

    module = MockModule()
    collector_instance = get_collector_instance(module)

# Generated at 2022-06-11 05:49:03.169105
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    virtual_facts.get_virtual_facts()
    assert virtual_facts.virtualization_type == 'guest'
    assert virtual_facts.virtualization_role == 'HP vPar'
    assert 'HP vPar' in virtual_facts.virtualization_tech_guest
    assert 'HPVM vPar' in virtual_facts.virtualization_tech_guest
    assert 'HPVM IVM' in virtual_facts.virtualization_tech_guest
    assert 'HPVM' in virtual_facts.virtualization_tech_guest
    assert 'HP nPar' in virtual_facts.virtualization_tech_guest

# Generated at 2022-06-11 05:49:09.235138
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    module = AnsibleModule(argument_spec={})
    virtual_facts = HPUXVirtual(module).get_virtual_facts()
    assert len(virtual_facts) == 3
    assert virtual_facts['virtualization_tech_host'] is not None
    assert virtual_facts['virtualization_tech_guest'] is not None
    assert virtual_facts['virtualization_type'] is not None

if __name__ == '__main__':
    from ansible.module_utils.basic import *
    test_HPUXVirtual_get_virtual_facts()

# Generated at 2022-06-11 05:49:11.685389
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual(dict(), dict())
    assert isinstance(h, HPUXVirtual)
    assert h.platform == 'HP-UX'
    assert h.guest_tech == set()
    assert h.host_tech == set()

# Generated at 2022-06-11 05:49:13.269155
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-11 05:49:15.020496
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpx_virtual = HPUXVirtual(None)
    assert hpx_virtual
    assert 'HP-UX' == hpx_virtual.platform

# Generated at 2022-06-11 05:49:23.534775
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Test with vecheck
    module = MockModule({
        'path.exists': (lambda x: True),
        'run_command.rc': (lambda x: 0),
        'run_command.out': (
            lambda x: '''
            This system is a Virtual Machine.
            The Virtual Machine is managed by vem
            '''),
        'run_command.err': (lambda x: None),
    })
    virtual = HPUXVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-11 05:49:31.044503
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import FactModule
    from ansible.module_utils.facts.virtual.hpuux_hpvm import HPUXVirtual, HPUXVirtualCollector

    #HPUXVirtual.get_virtual_facts()
    #HPUXVirtual.get_virtual_facts(), when collector returns facts
    #HPUXVirtual.get_virtual_facts(), when collector returns facts and hpvm facts
    #HPUXVirtual.get_virtual_facts(), when collector returns only hpvm facts
    #HPUXVirtual.get_virtual_facts(), when collector returns facts and vecheck fails
    #HPUXVirtual.get_virtual_facts(), when collector returns facts and vecheck output is invalid
    #HPUXVirtual.get_virtual_facts(), when collector returns facts and hpvminfo fails
    #HPUXVirtual.get

# Generated at 2022-06-11 05:49:38.647454
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # generate an HPUXVirtual object
    hpux_virtual_object = HPUXVirtual()
    # generate a set of virtualization technology of guest
    guest_tech = set()
    # generate a set of virtualization technology of host
    host_tech = set()
    # generate a dictionary of get_virtual_facts
    facts = {
        'virtualization_type': 'host',
        'virtualization_role': 'HPVM IVM'
    }
    # invoke method get_virtual_facts
    hpux_virtual_object.get_virtual_facts()
    # assert the result
    assert hpux_virtual_object._facts['virtualization_tech_guest'] == guest_tech
    assert hpux_virtual_object._facts['virtualization_tech_host'] == host_tech

# Generated at 2022-06-11 05:50:02.327846
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.virtual import base

    MockModule = basic.AnsibleModule
    MockCollector = collector.Collector
    MockVirtual = base.Virtual

    class MockHPUXVirtual(HPUXVirtual):
        def __init__(self, module):
            pass

        def _exec_cmd(self, cmd):
            if cmd == '/usr/sbin/vecheck':
                return 0, "", ""
            elif cmd == '/opt/hpvm/bin/hpvminfo':
                return 0, "Virtual Machine Information\n"

# Generated at 2022-06-11 05:50:07.895579
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual_obj = HPUXVirtual({})
    assert hpux_virtual_obj.platform == 'HP-UX'
    assert hpux_virtual_obj.get_virtual_facts() == {'virtualization_tech_host': set(),
                                                   'virtualization_type': '',
                                                   'virtualization_role': '',
                                                   'virtualization_tech_guest': set()}
    assert hpux_virtual_obj.get_virtual_facts()['virtualization_tech_guest'] == set()


# Generated at 2022-06-11 05:50:16.118994
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = DummyAnsibleModule('/usr/sbin/vecheck', '/opt/hpvm/bin/hpvminfo', '/usr/sbin/parstatus')
    virtual_facts = HPUXVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    module = DummyAnsibleModule('/usr/sbin/vecheck', '/opt/hpvm/bin/hpvminfo')
    virtual_facts = HPUXVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'host'
    assert virtual_facts['virtualization_role'] == 'HPVM'
    module = DummyAnsibleModule()
    virtual_facts = HPU

# Generated at 2022-06-11 05:50:19.711886
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():

    # Constructor should create a HPUXVirtual object
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'
    assert hv.virtualization_type == ''
    assert hv.virtualization_role == ''
    assert hv.virtualization_technologies == set()


# Generated at 2022-06-11 05:50:27.581968
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hporacle import HPUXVirtual

    hv = HPUXVirtual()

    fake_module = FakeModule(
        params={
            'gather_subset': ['!all', 'virtual'],
        }
    )

    # Unit test for vpar
    os.path.exists = lambda path: path == '/usr/sbin/vecheck'
    hv.module = fake_module
    fake_module.run_command = lambda args: (0, '', '')
    virtual_facts = hv.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert len(virtual_facts['virtualization_tech_guest']) == 1

# Generated at 2022-06-11 05:50:35.728724
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hp import HPUXVirtual
    from ansible.module_utils.facts.virtual.hp import HPUXVirtualCollector

    # Test get_virtual_facts when machine is nPar, vPar and HPVM guest
    module = get_module_mock()
    def exists(path):
        if path == '/usr/sbin/vecheck':
            return True
        if path == '/opt/hpvm/bin/hpvminfo':
            return True
        if path == '/usr/sbin/parstatus':
            return True
    module.run_command.side_effect = [
        (0, 'Running on HPVM vPar', ''),
        (0, 'Running on HP vPar', ''),
        (0, 'Running on HP nPar', '')
    ]
   

# Generated at 2022-06-11 05:50:43.716345
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Virtualization platforms that are available in HPUXVirtual
    virtualization_platforms = ['HP vPar', 'HPVM vPar', 'HPVM IVM', 'HPVM', 'HP nPar']
    # Virtualization facts that are expected
    expected_virtualization_facts = {'virtualization_type': 'guest',
                                     'virtualization_role': 'HP vPar',
                                     'virtualization_tech_guest': set(['HP vPar', 'HPVM vPar', 'HPVM IVM', 'HPVM', 'HP nPar']),
                                     'virtualization_tech_host': set()}
    # For each platform check if the method get_virtual_facts() return the correct virtualization facts
    for platform in virtualization_platforms:
        # Instantiate virtualization fact class
        virtual_fact_instance = HPUXVirtual

# Generated at 2022-06-11 05:50:45.413262
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert issubclass(HPUXVirtual, Virtual)
    hv = HPUXVirtual(dict())
    assert isinstance(hv.module, dict)

# Generated at 2022-06-11 05:50:50.015354
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual_obj = HPUXVirtual()
    assert hpux_virtual_obj.platform == 'HP-UX'
    assert hpux_virtual_obj.virtualization_type == 'guest'
    assert hpux_virtual_obj.virtualization_role == 'HP nPar'
    assert 'HP nPar' in hpux_virtual_obj.virtualization_tech_guest


# Generated at 2022-06-11 05:50:58.218824
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpar import (
        Virtual, VirtualCollector, HPUXVirtual, HPUXVirtualCollector)

    class Test_X(object):
        def __init__(self):
            self.run_command_called = False
            self.run_command_rc = 0
            self.run_command_out = "Out"
            self.run_command_err = "Err"

        def run_command(self, cmd):
            self.run_command_called = True
            return self.run_command_rc, self.run_command_out, self.run_command_err

    # test for hpvm guest
    virtual = HPUXVirtual(Test_X())
    virtual.module.run_command_rc = 0

# Generated at 2022-06-11 05:51:26.656123
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt_inst = HPUXVirtual(dict())
    assert virt_inst.platform == 'HP-UX'


# Generated at 2022-06-11 05:51:34.969538
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    os.path.exists = lambda filename: True
    vecheck_out = """
    Running HP-UX vPar
    """
    def run_command(self, cmd):
        return 0, vecheck_out, ''

    hpvminfo_out = """
    Running HPVM vPar
    """
    def run_command2(self, cmd):
        return 0, hpvminfo_out, ''

    parstatus_out = """
    Running HP nPar
    """
    def run_command3(self, cmd):
        return 0, parstatus_out, ''

    h = HPUXVirtual()
    h.module = type('', (), { 'run_command': run_command })()
    h.module = type('', (), { 'run_command': run_command2 })()

# Generated at 2022-06-11 05:51:43.009648
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    sysctl_mock_values = {}

    class MockHPUXVirtual(HPUXVirtual):
        def __init__(self, module):
            mock_values = {}
            for fact, value in sysctl_mock_values.items():
                mock_values[fact] = value
            super(MockHPUXVirtual, self).__init__(module=module, sysctl_facts=mock_values)
        @staticmethod
        def _exec_not_implemented_helper(cmd, module):
            return 0, "test_exec_out", "test_exec_err"

    hpux_virtual_test_inst = MockHPUXVirtual(module)
    result = hpux_virtual_

# Generated at 2022-06-11 05:51:44.139327
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual()
    assert v.platform == 'HP-UX'

# Generated at 2022-06-11 05:51:47.555994
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = AnsibleModule(argument_spec=dict())
    virtual = HPUXVirtual(module)
    assert virtual.platform == 'HP-UX'



# Generated at 2022-06-11 05:51:51.221368
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual({})
    assert HPUXVirtual
    assert v.virtualization_type is None
    assert v.virtualization_role is None
    assert len(v.virtualization_tech_guest) == 0
    assert len(v.virtualization_tech_host) == 0

# Generated at 2022-06-11 05:51:54.355560
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = type('module', (object,), {})
    v = HPUXVirtual(module)
    assert v._module == module
    assert v._platform == 'HP-UX'


# Generated at 2022-06-11 05:52:02.734760
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    m = basic.AnsibleModule(
        argument_spec = dict()
    )
    m.run_command = run_command_mock
    virtual = HPUXVirtual(m)
    facts = virtual.get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HPVM vPar'
    virtual = HPUXVirtual(m)
    facts = virtual.get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP vPar'
    virtual = HPUXVirtual(m)
    facts = virtual.get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'

# Generated at 2022-06-11 05:52:13.258206
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    This test simulates the virtual facts of a HP-UX machine
    without any virtualization
    """
    import os
    import tempfile
    test_amodule = tempfile.NamedTemporaryFile(mode='w', delete=False, dir='/tmp')
    test_amodule.write('#!/usr/bin/env python\n')
    test_amodule.write('\n')
    test_amodule.write('def main():\n')
    test_amodule.write('    module = AnsibleModule(\n')
    test_amodule.write('        argument_spec = dict(\n')
    test_amodule.write('        )\n')
    test_amodule.write('    )\n')

# Generated at 2022-06-11 05:52:19.150370
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'
    assert hv.virtualization_type is None
    assert isinstance(hv.virtualization_role, str)
    assert len(hv.virtualization_role) == 0
    assert isinstance(hv.virtualization_role_guest, str)
    assert hv.virtualization_role_guest == 'HP vPar'
    assert hv.virtualization_role_host is None

# Generated at 2022-06-11 05:52:48.966421
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    m = module_mock()
    hv = HPUXVirtual(m)

    # testing with no virtualization
    hv.module.run_command.return_value = (1, '', '')

    assert hv.get_virtual_facts()['virtualization_tech_guest'] == set()
    assert hv.get_virtual_facts()['virtualization_tech_host'] == set()
    assert 'virtualization_role' not in hv.get_virtual_facts()
    assert 'virtualization_type' not in hv.get_virtual_facts()

    # testing with /usr/sbin/vecheck command
    hv.module.run_command.return_value = (0, 'HP vPar', '')

# Generated at 2022-06-11 05:52:52.914476
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = {}
    module['run_command'] = lambda x, check_rc=False: (0, '', '')
    module['run_command'] = run_command
    virtual = HPUXVirtual(module)
    assert 'HP-UX' in virtual.platform
    assert virtual.get_virtual_facts()


# Generated at 2022-06-11 05:53:02.839984
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class mock_module:
        def __init__(self):
            self.params = {}

        def run_command(self, command):
            if command == '/usr/sbin/vecheck':
                return (0, '', '')
            elif command == '/opt/hpvm/bin/hpvminfo':
                return (0, 'Running HPVM vPar', '')
            elif command == '/usr/sbin/parstatus':
                return (0, '', '')

    class mock_os:
        def __init__(self):
            pass

        def path(self, path_name):
            if path_name == '/usr/sbin/vecheck':
                return True
            elif path_name == '/opt/hpvm/bin/hpvminfo':
                return True

# Generated at 2022-06-11 05:53:04.632494
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXvirtual = HPUXVirtual(dict(module=dict()))
    assert HPUXvirtual


# Generated at 2022-06-11 05:53:06.856176
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual()
    assert virtual.platform == 'HP-UX'
    assert virtual.get_virtual_facts() == 'facts'

# Generated at 2022-06-11 05:53:16.153197
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual import collector as virtcol
    from ansible.module_utils.facts.virtual.collector import VirtualCollector
    import ansible.module_utils.facts.virtual.hpux

    my_virt_hpux = HPUXVirtualCollector(basic.AnsibleModule)

    class fake_module(object):
        def __init__(self):
            self.run_command = None
            self.exit_json = None

    class fake_virt_hpux(HPUXVirtual):
        def __init__(self):
            self.module = fake_module()

        def get_virtual_facts(self):

            rc, out, err = self.module

# Generated at 2022-06-11 05:53:25.996590
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class MockModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def run_command(self, cmd):
            return self.rc, self.out, self.err

    class MockHPUXVirtual(HPUXVirtual):
        def __init__(self, module):
            self.module = module

    # test for HP vPar
    rc = 0
    out = '\n'.join(['HPVM - Virtual Partition (vPar) Checker, Version 3.5.5.0',
                    '\n',
                    'Machine is not a vPar.'])
    err = ''
    mod = MockModule(rc, out, err)
    hp_virtual = MockHPUXVirtual(mod)
    virtual_

# Generated at 2022-06-11 05:53:27.667810
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'



# Generated at 2022-06-11 05:53:34.804923
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_instance = HPUXVirtual({})
    assert virtual_instance.platform == 'HP-UX'
    assert virtual_instance.get_virtual_facts() == {}
    assert virtual_instance.get_virtual_facts().get('virtualization_type', None) is None
    assert virtual_instance.get_virtual_facts().get('virtualization_role', None) is None
    assert virtual_instance.get_virtual_facts().get('virtualization_tech_host', None) is None
    assert virtual_instance.get_virtual_facts().get('virtualization_tech_guest', None) is None


# Generated at 2022-06-11 05:53:43.093430
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import Virtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector

    # dict to pass to the module
    module_args = {}

    # dict to pass to the module's constructor
    module_params = {}

    # ansible abstract class instance
    # defined by the Virtual class
    module = Virtual(module_args, module_params)

    # ansible subclass instance
    # defined by the HPUXVirtual class
    hpux_virtual = HPUXVirtual(module)

    # facts dict to return (set by the subclass)
    facts = {}

    # results from the hpux_virtual.get_virtual_facts method
    hpux_virtual.get_virtual

# Generated at 2022-06-11 05:54:48.377017
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpuxfact = HPXVirtual()
    assert hpuxfact.platform == 'HP-UX'


# Generated at 2022-06-11 05:54:53.692526
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_module = FakeModule()
    # Testing vPar

# Generated at 2022-06-11 05:54:56.388162
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    virtual = HPUXVirtual({})
    if (virtual.get_virtual_facts() != {}):
        return False   # No HP-UX system found
    return True


# Generated at 2022-06-11 05:55:04.658855
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    class HP_UX_module(object):
        def run_command(self, cmd):
            if cmd == "/usr/sbin/vecheck":
                return (0, '', '')
            elif cmd == "/opt/hpvm/bin/hpvminfo":
                return (0, 'Running: HPVM vPar', '')
            elif cmd == "/usr/sbin/parstatus":
                return (0, '', '')
            else:
                raise Exception("TestError: Unexpected command %s" % (cmd))

    class HP_UX_module_fact(object):
        def __init__(self):
            self.module = HP_UX_module()


# Generated at 2022-06-11 05:55:08.292347
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """This function executes constructor of HPUXVirtual.
    :return: Returns true if object creation is successful, else returns false.
    """
    try:
        hv = HPUXVirtual()
    except Exception as e:
        assert False, "Exception occurred: {}".format(e)
    else:
        assert True



# Generated at 2022-06-11 05:55:16.549006
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import ansible.module_utils.facts.virtual.hpux as hpux
    from ansible.module_utils.facts.virtual.hpux import Virtual

    class Module():
        def __init__(self):
            self.run_command_calls = []

        def run_command(self, command):
            self.run_command_calls.append(command)
            if command == "/usr/sbin/vecheck":
                return 0, "", ""
            if command == "/opt/hpvm/bin/hpvminfo":
                return 0, "Running HPVM IVM on Host hostname", ""
            if command == "/usr/sbin/parstatus":
                return 0, "HPVM guest on HPVM hostname", ""
            return 1, "", ""


# Generated at 2022-06-11 05:55:19.809259
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():

    hpux_virtual_collector = HPUXVirtualCollector()

    hpux_virtual = hpux_virtual_collector.collect(None, None)

    assert hpux_virtual.virtual_subtype == "HP-UX"
    assert hpux_virtual.virtual is True

# Generated at 2022-06-11 05:55:28.080539
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    '''
    Unit test for method get_virtual_facts of class HPUXVirtual
    '''

    _module = None
    _result = {'virtualization_tech_guest': set(['HP vPar', 'HPVM vPar', 'HPVM IVM', 'HP nPar']),
               'virtualization_role': 'HP vPar', 'virtualization_tech_host': set(),
               'virtualization_type': 'guest'}
    _HPUX_Virtual = HPUXVirtual(_module)

    _result_test = _HPUX_Virtual.get_virtual_facts()

    # Assert for virtualization_role and virtualization_type
    assert _result['virtualization_role'] == _result_test['virtualization_role']

# Generated at 2022-06-11 05:55:32.111898
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual()
    assert virtual_obj.platform == "HP-UX"
    assert virtual_obj.virtualization_type is None
    assert virtual_obj.virtualization_role is None
    assert virtual_obj.virtualization_tech_guest == set()
    assert virtual_obj.virtualization_tech_host == set()


# Generated at 2022-06-11 05:55:33.501010
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hp_virtual = HPUXVirtual()
    assert hp_virtual is not None
