

# Generated at 2022-06-11 05:46:33.867078
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    '''
    Unit test to test constructor of class HPUXVirtual
    '''
    virtual_data = HPUXVirtual(dict())

    assert virtual_data.data['virtualization_type'] == 'guest'
    assert virtual_data.data['virtualization_role'] == 'HP vPar'
    assert virtual_data.data['virtualization_tech_guest'] == set(['HP vPar'])
    assert virtual_data.data['virtualization_tech_host'] == set()


# Generated at 2022-06-11 05:46:37.932320
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    virt = HPUXVirtual()
    virtual_facts = virt.get_virtual_facts()
    assert virtual_facts.keys() == {'virtualization_type', 'virtualization_role', 'virtualization_tech_guest', 'virtualization_tech_host'}

# Generated at 2022-06-11 05:46:46.260167
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import Collector

    # Define where module_utils are in the filesystem
    module_utils_path = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))

    # If we are in a checkout, move up two directories
    if os.path.exists(os.path.join(module_utils_path, '__init__.py')):
        module_utils_path = os.path.dirname(os.path.dirname(module_utils_path))

    # Use the custom module location
    module_path = os.path.join(module_utils_path, 'module_utils.basic')

    # Add to the Python path
    sys.path.append(module_path)

    # Import the module

# Generated at 2022-06-11 05:46:52.260669
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import Facts

    module_args = {}
    set_module_args(module_args)

    facts = Facts(
        module_name='test',
        module_args=module_args,
        ansible_facts={},
        collectors=[HPUXVirtualCollector],
    )

    facts.populate()

    virtual_facts = facts.ansible_facts['virtual_facts']

    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HPVM vPar'

# Generated at 2022-06-11 05:46:55.452102
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    v_facts = HPUXVirtual({})
    v_facts_facts = v_facts.get_virtual_facts()
    assert v_facts_facts["virtualization_type"] == "guest"
    assert v_facts_facts["virtualization_role"] == "HPVM"

# Generated at 2022-06-11 05:47:02.152144
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    module = FakeModule('/usr/sbin/vecheck')
    module.run_command = run_command
    hpux_virtual = HPUXVirtual(module)
    virtual_facts = hpux_virtual.get_virtual_facts()
    assert(virtual_facts['virtualization_type'] == 'guest' and
           virtual_facts['virtualization_role'] == 'HP vPar' and
           virtual_facts['virtualization_tech_guest'] == set(['HP vPar']) and
           virtual_facts['virtualization_tech_host'] == set())



# Generated at 2022-06-11 05:47:04.191708
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    host = HPUXVirtual()

    assert host.platform == "HP-UX"
    assert host.get_virtual_facts() == {}

# Generated at 2022-06-11 05:47:06.001343
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    n = HPUXVirtual()
    assert isinstance(n.get_virtual_facts(), dict)


# Generated at 2022-06-11 05:47:15.109090
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector

    # test case 1: HP-UX virtualization_type is Host
    module = HPUXVirtualCollector()
    module.module = Facts()
    module.module.run_command = lambda ln: (0, "Running HPVM host", "")
    # module.module.params = {'gather_subset': '!all'}
    # module.gather_block_facts = lambda p: (p['gather_subset'], HPUXVirtual().get_virtual_facts())
    facts = module.populate()
    assert facts['virtualization_type'] == 'host'
   

# Generated at 2022-06-11 05:47:19.634617
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = AnsibleModule(argument_spec={})
    virtual = HPUXVirtual(module)

    keys = [
        'virtualization_role',
        'virtualization_type',
        'virtualization_tech_guest',
        'virtualization_tech_host',
    ]
    for key in keys:
        assert key in virtual.data, '%s not present in virtual.data' % key

# Generated at 2022-06-11 05:47:32.711363
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    sysctl = dict()
    sysctl['hw'] = dict()
    sysctl['hw']['model'] = "ia64 hp Integrity Server"
    module = FakeAnsibleModule(sysctl=sysctl)
    virtual = HPUXVirtual(module)
    facts = virtual.collect()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP vPar'



# Generated at 2022-06-11 05:47:41.268369
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = type('', (object,), dict(run_command=lambda x, **kw: (0, 'sample output', '')))
    module.params = dict()
    module.check_mode = False
    module.debug = False
    mod = HPUXVirtual(module)
    res = mod.get_virtual_facts()
    assert res['virtualization_type'] == 'guest'
    assert res['virtualization_role'] == 'HP nPar'
    assert 'HP vPar' in res['virtualization_tech_guest']
    assert 'HPVM vPar' in res['virtualization_tech_guest']
    assert 'HPVM IVM' in res['virtualization_tech_guest']
    assert 'HPVM' in res['virtualization_tech_host']

# Generated at 2022-06-11 05:47:43.332517
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual()
    assert v.platform == 'HP-UX'
    assert v.get_virtual_facts() == {}

# Generated at 2022-06-11 05:47:51.827935
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpar import HPUXVirtual
    import tempfile
    hpar_module_run_command_output_dict = {'/usr/sbin/parstatus': (0, 'Running nPar', '')}
    vecheck_hpvm_output_dict = {'/usr/sbin/vecheck': (0, 'Running vPar', ''),
                                '/opt/hpvm/bin/hpvminfo': (0, 'Running HPVM vPar', '')}
    vecheck_hpvm_npar_output_dict = {'/usr/sbin/vecheck': (0, 'Running vPar', ''),
                                     '/opt/hpvm/bin/hpvminfo': (0, 'Running HPVM guest', '')}

# Generated at 2022-06-11 05:47:59.898987
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # mocks
    import ansible.module_utils
    from ansible.module_utils.facts import virtual
    import ansible.module_utils.facts.virtual.base

    class ModuleMock:
        def __init__(self):
            self.run_command_mock = MagicMock()

    module = ModuleMock()
    hpux_virtual = HPUXVirtual(module) # pylint: disable=E1101

# Generated at 2022-06-11 05:48:08.549431
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    mock_obj = {
        'run_command.return_value': (0, '', ''),
        'path.exists.return_value': True,
    }
    with patch.multiple(HPUXVirtual, module=mock_obj):
        assert HPUXVirtual(mock_obj).get_virtual_facts() == {
            'virtualization_type': 'guest',
            'virtualization_role': 'HP vPar',
            'virtualization_tech_guest': set(['HP vPar']),
            'virtualization_tech_host': set()
        }
    mock_obj = {
        'run_command.return_value': (0, 'Running HPVM guest', ''),
        'path.exists.return_value': True,
    }

# Generated at 2022-06-11 05:48:17.221297
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = HPUXVirtualCollector()
    module._module.get_bin_path = lambda x: x
    module._module.get_shell_type = lambda: 'csh'

    # Test with no-virtualization technology
    module._module.run_command = lambda x: (0, '', '')
    assert module.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

    # Test with parstatus for nPar
    module._module.run_command = lambda x: (0, 'parstatus', '')

# Generated at 2022-06-11 05:48:18.235008
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict())
    assert virtual


# Generated at 2022-06-11 05:48:19.579992
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpx_virtual = HPUXVirtual()
    assert hpx_virtual.platform == "HP-UX"

# Generated at 2022-06-11 05:48:21.687884
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual({}, {}, {})
    res = hpux_virtual.get_virtual_facts()
    assert res['virtualization_role'] == 'HP nPar'



# Generated at 2022-06-11 05:48:40.917746
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible_collections.ansible.community.tests.unit.modules.utils import AnsibleExitJson
    from ansible_collections.ansible.community.tests.unit.modules.utils import AnsibleFailJson
    from ansible_collections.ansible.community.tests.unit.module_utils.facts.virtual.hpux.hpux_virtual import HPUXVirtual
    from ansible_collections.ansible.community.tests.unit.module_utils.facts.virtual.hpux.hpux_virtual import HPUXVirtualCollector
    from ansible_collections.ansible.community.tests.unit.module_utils.facts.virtual.hpux.hpux_virtual import Virtual

# Generated at 2022-06-11 05:48:49.691180
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    module = FakeAnsibleModule()
    module.run_command.side_effect = [(0, '', '')]
    module.get_bin_path.side_effect = ['/usr/sbin/vecheck', "/opt/hpvm/bin/hpvminfo", "/usr/sbin/parstatus"]
    virtual = HPUXVirtual(module=module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts == {
        'virtualization_type': 'guest',
        'virtualization_role': 'HP nPar',
        'virtualization_tech_host': {},
        'virtualization_tech_guest': {'HP nPar'}
    }



# Generated at 2022-06-11 05:48:57.270346
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpar import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpvm import HPUXVirtual
    from ansible.module_utils.facts.virtual.vecheck import HPUXVirtual
    module = FakeAnsibleModule()
    facts = Virtual(module)
    assert HPUXVirtual_get_virtual_facts(facts) == {
        'virtualization_type': 'guest',
        'virtualization_role': 'HP vPar',
        'virtualization_tech_guest': set(['HP vPar', 'HP nPar']),
        'virtualization_tech_host': set([])
    }


# Generated at 2022-06-11 05:48:58.370330
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual({})
    assert isinstance(virtual, HPUXVirtual)

# Generated at 2022-06-11 05:49:03.059943
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = AnsibleModuleMock()
    HPUXVirtual(module).collect()
    module.exit_json.assert_called_once_with(
        ansible_facts={
            'virtualization_type': 'guest',
            'virtualization_role': 'HP vPar',
            'virtualization_tech_guest': set(['HP vPar']),
            'virtualization_tech_host': set(),
        }
    )

# Generated at 2022-06-11 05:49:10.499228
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    module = MagicMock()
    hpux_virtual = HPUXVirtual(module)
    hpux_virtual.module.run_command = MagicMock(return_value=(0, '', ''))
    hpux_virtual.get_virtual_facts()
    assert hpux_virtual.facts['virtualization_type'] == 'guest'
    assert hpux_virtual.facts['virtualization_role'] == 'HP vPar'
    assert hpux_virtual.facts['virtualization_tech_guest'] == set(['HP vPar'])
    assert hpux_virtual.facts['virtualization_tech_host'] == set()
    hpux_virtual.facts = {}

# Generated at 2022-06-11 05:49:14.315606
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    virtual_facts = dict()
    collector = HPUXVirtualCollector(None, virtual_facts, None)
    virtual = collector.get_virtual_facts()
    assert virtual.virtualization_type == 'guest'
    assert virtual.virtualization_role == 'HP vPar'
    assert virtual.virtualization_tech_guest == {'HP vPar'}
    assert virtual.virtualization_tech_host == set()

# Generated at 2022-06-11 05:49:15.444776
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual()
    assert virtual.platform == 'HP-UX'


# Generated at 2022-06-11 05:49:19.225970
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.virtualization_type == None
    assert hpux_virtual.virtualization_role == None
    assert hpux_virtual.virtualization_tech_guest == set()
    assert hpux_virtual.virtualization_tech_host == set()

# Generated at 2022-06-11 05:49:23.388277
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.__class__.__name__ == 'HPUXVirtual'
    assert virtual_facts.platform == 'HP-UX'
    assert virtual_facts.get_virtual_facts() == {'virtualization_tech_guest': set(),
                                                'virtualization_tech_host': set()}

# Generated at 2022-06-11 05:49:39.112863
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec=dict())
    virt_collector = HPUXVirtualCollector(module)
    virtual_facts = virt_collector.collect()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts



# Generated at 2022-06-11 05:49:47.439407
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule()

    class MockModule(object):
        def __init__(self, module):
            self._result = None
            self.module = module

        def run_command(self, command):
            if command == '/usr/sbin/vecheck':
                self._result = (0, "", "")
            elif command == '/opt/hpvm/bin/hpvminfo':
                self._result = (0, "Running HPVM Host Version 4.2.0", "")
            elif command == '/usr/sbin/parstatus':
                self._result = (0, "", "")
            else:
                raise NotImplementedError("This call to run_command was unexpected")

            return self._result


# Generated at 2022-06-11 05:49:52.658233
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    hpux_virtual = HPUXVirtualCollector()
    virtual_facts = hpux_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_tech_guest'] == set(['HP nPar', 'HP vPar', 'HPVM vPar', 'HPVM IVM'])
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'

# Generated at 2022-06-11 05:49:54.825303
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual()
    assert virtual_obj._platform == 'HP-UX'
    assert virtual_obj._fact_class == HPUXVirtual
    assert virtual_obj.platform == 'HP-UX'

# Generated at 2022-06-11 05:50:02.965185
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # testing HPUXVirtual class
    hpux_virtual = HPUXVirtual()

    # rendering the output of vecheck command
    hpux_virtual.module.run_command = lambda x: (0, '', '')

    # test against vpar
    hpux_virtual.module.run_command = lambda x: (0, '', '')
    virtual_facts = hpux_virtual.get_virtual_facts()
    assert 'HP vPar' in virtual_facts['virtualization_tech_guest']
    assert 'guest' == virtual_facts['virtualization_type']
    assert 'HP vPar' == virtual_facts['virtualization_role']

    # test against hpvm IVM
    hpux_virtual.module.run_command = lambda x: (0, 'Running HPVM guest\n', '')
    virtual_facts

# Generated at 2022-06-11 05:50:10.943604
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class HPUXVirtualModuleMock(object):
        def __init__(self):
            self.params = None
            self.run_command = lambda x: (0, "hp-ux", "")

    class HPUXVirtual2ModuleMock(object):
        def __init__(self):
            self.params = None
            self.run_command = lambda x: (0, "HPVM vPar", "")

    class HPUXVirtual3ModuleMock(object):
        def __init__(self):
            self.params = None
            self.run_command = lambda x: (0, "HPVM guest", "")

    class HPUXVirtual4ModuleMock(object):
        def __init__(self):
            self.params = None

# Generated at 2022-06-11 05:50:19.383661
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class MockModule(object):
        def run_command(self,option):
            rc = 0
            if option == '/usr/sbin/parstatus':
                out = 'Proc Name                 Y/N Mem     CPU     pN Parid(s)  vP Partition'
            elif option == '/usr/sbin/vecheck':
                out = 'SVP /stand/vmunix is valid for the vPars environment'
            elif option == '/opt/hpvm/bin/hpvminfo':
                out = 'Running: HPVM vPar'
            else:
                rc = 1
                out = ''
            return rc, out, ''


    class MockAnsibleModule(object):
        def __init__(self, module_args, params):
            self.params = params

# Generated at 2022-06-11 05:50:26.959594
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    class DummyModule(object):
        def __init__(self, module):
            self.run_command = module.run_command

    class DummyVirtual(HPUXVirtual):
        def __init__(self, module):
            self.module = DummyModule(module)

    module.run_command = run_command
    hv = DummyVirtual(module)
    assert 'guest' == hv.get_virtual_facts()['virtualization_type']
    assert 'guest' == hv.get_virtual_facts()['virtualization_type']
    assert 'guest' == hv.get_virtual_facts()['virtualization_type']



# Generated at 2022-06-11 05:50:28.356773
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual({})
    assert hpux_virtual


# Generated at 2022-06-11 05:50:36.544180
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Test with virtualization_type = guest and virtualization_role = HPVM IVM
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand(rc=0, stdout='Running HPVM guest in IVM environment.')
    module.os.path.exists = FakePathExists(exists=True)
    virtual_obj = HPUXVirtual(module)
    virtual_obj.get_virtual_facts()
    assert module.exit_args['failed'] is False
    assert module.exit_args['changed'] is False
    assert module.exit_args['msg'] is None
    assert module.exit_args['virtualization_type'] == 'guest'
    assert module.exit_args['virtualization_role'] == 'HPVM IVM'

# Generated at 2022-06-11 05:50:48.985128
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict(), 'ansible_module')
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-11 05:50:55.797238
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt_hpux = HPUXVirtual()
    facs = virt_hpux.get_all_facts()
    assert 'virtualization_type' in facs.keys()
    assert 'virtualization_role' in facs.keys()
    assert 'virtualization_tech_host' in facs.keys()
    assert 'virtualization_tech_guest' in facs.keys()
    assert 'virtualization_slave_type' not in facs.keys()
    assert 'virtualization_slot_number' not in facs.keys()
    assert 'virtualization_host' in facs.keys()
    assert 'virtualization_guest' not in facs.keys()

# Generated at 2022-06-11 05:51:01.865078
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(argument_spec={})
    module.params = {}
    module.run_command = mock_run_command

    virtual_facts = HPUXVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_role'] == 'HP nPar'
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['HP nPar'])
    assert virtual_facts['virtualization_tech_host'] == set()



# Generated at 2022-06-11 05:51:06.664173
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(None)
    assert hpux_virtual._virtualization_type == 'guest'
    assert hpux_virtual._virtualization_role == 'HP vPar'
    assert hpux_virtual._virtualization_tech_host == set()
    assert hpux_virtual._virtualization_tech_guest == {'HP vPar'}


# Generated at 2022-06-11 05:51:15.549032
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpar import HPUXVirtual
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.virtual.hpvm import HPUXVirtual
    import ansible.constants as C
    import tempfile
    import shutil
    import random
    import os
    import sys

    def mock_exists(path):
        if re.match('^/usr/sbin/.*', path) or re.match('^/opt/hpvm/bin/.*', path):
            return True
        else:
            return False

    class MockModule(object):
        def __init__(self, facts):
            self.params = {}
            self.exit_args = {}
            self.exit_args['failed'] = False
            self.exit_

# Generated at 2022-06-11 05:51:17.317122
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt = HPUXVirtual(None)
    assert virt.platform == 'HP-UX'
    assert virt.name == 'HP-UX'

# Generated at 2022-06-11 05:51:20.032630
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    test_obj = HPUXVirtual(dict(module=None,
                                tmpdir=None))
    expected_platform = 'HP-UX'
    actual_platform = test_obj.platform
    assert actual_platform == expected_platform



# Generated at 2022-06-11 05:51:22.997009
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h = HPUXVirtual()
    f = h.get_virtual_facts()
    assert f['virtualization_role'] == ''
    assert f['virtualization_type'] == ''
    assert f['virtualization_tech_host'] == set()
    assert f['virtualization_tech_guest'] == set()

# Generated at 2022-06-11 05:51:31.634807
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import HPUXVirtual
    from ansible.module_utils.facts.virtual._utils import FakeModule, FakeCommandResult
    from ansible.module_utils.facts.virtual.hpar import HPUXHParInfo
    import tempfile

    module = FakeModule()
    module.run_command = FakeCommandResult

    # Test case 1 - condition where HPUXHparInfo says hp virtualization is installed
    hpar_info = HPUXHParInfo()
    hpar_info.is_hpar_installed = True
    hpar_info.is_hpvm_host_installed = False
    hpar_info.is_hpvm_guest_installed = False
    hpar_info.is_hpvm_ivm_guest_installed = False

# Generated at 2022-06-11 05:51:33.240105
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'



# Generated at 2022-06-11 05:52:02.225598
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual()
    assert v.platform == 'HP-UX'


# Generated at 2022-06-11 05:52:07.115444
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    hv_dict = hv.get_virtual_facts()
    assert hv_dict['virtualization_type'] == 'guest'
    assert hv_dict['virtualization_role'] == 'HP vPar'
    assert hv_dict['virtualization_tech_guest'] == set(['HP vPar'])



# Generated at 2022-06-11 05:52:08.371638
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual()



# Generated at 2022-06-11 05:52:16.759321
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    m = os.path.join(os.path.dirname(__file__), '../../module_utils/facts/virtual/test_hpux_virtual.py')
    m = 'ansible.module_utils.facts.virtual.test_hpux_virtual'
    mi = __import__(m, globals(), locals(), ['AnsibleModule'])
    module = mi.AnsibleModule
    hpu = HPUXVirtual(module)
    hpu.get_virtual_facts()
    print(hpu.virtual_facts)

if __name__ == '__main__':
    test_HPUXVirtual_get_virtual_facts()

# Generated at 2022-06-11 05:52:18.995432
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    x = HPUXVirtual({})
    assert x.platform == 'HP-UX'
    assert x.get_virtual_facts() is not None


# Generated at 2022-06-11 05:52:22.118936
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual({}, {})
    assert h.platform == 'HP-UX'
    assert h.get_virtual_facts() == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}


# Generated at 2022-06-11 05:52:27.565493
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """Unit test for method get_virtual_facts of class HPUXVirtual

    """
    m = Virtual()
    m.module = type('', (object,), {
        'run_command': lambda *args, **kwargs: (0, 'Running HPVM vPar', ''),
    })()
    assert m.get_virtual_facts() == {'virtualization_type': 'guest', 'virtualization_role': 'HPVM vPar',
                                    'virtualization_tech_guest': set(['HPVM vPar']), 'virtualization_tech_host': set()}

# Generated at 2022-06-11 05:52:30.222698
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    virtual_facts.get_virtual_facts()
    assert virtual_facts.virtualization_type is None

# Generated at 2022-06-11 05:52:39.129829
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Create an instance of argument spec
    argument_spec = dict(
        gather_subset=dict(default=['!all'], type='list')
    )
    # create a mock module
    mock_module = AnsibleModule(argument_spec=argument_spec,
                                supports_check_mode=True)
    # create a mock module
    mock_module = AnsibleModule(argument_spec=argument_spec,
                                supports_check_mode=True)
    # Set environment variables
    os.environ['ANSIBLE_MODULE_ARGS'] = "gather_subset=min"
    # create a instance of HPUXVirtual class
    hpux_virtual_obj = HPUXVirtual(mock_module)
    # get virtual facts
    hpux_virtual_obj.get_virtual_facts()

# Generated at 2022-06-11 05:52:42.241280
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt = HPUXVirtual(dict())
    assert issubclass(type(virt), HPUXVirtual)
    assert type(virt).__name__ == 'HPUXVirtual'
    assert issubclass(type(virt), Virtual)



# Generated at 2022-06-11 05:53:23.960747
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual()
    assert v
    assert v.platform == 'HP-UX'
    assert v.get_virtual_facts() == {'virtualization_type': 'guest',
                                     'virtualization_role': 'HP nPar',
                                     'virtualization_tech_guest': set(['HP nPar']),
                                     'virtualization_tech_host': set()}

# Generated at 2022-06-11 05:53:33.399604
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    collect_data = '''
Running HPVM vPar
Running HPVM guest

Running HPVM IVM

Running HPVM IVM

Running HPVM host

'''

    test_HPUX_vec = HPUXVirtual('TestModule')
    test_HPUX_vec.module.run_command = lambda x: (0, collect_data, '')

    virtual_facts = test_HPUX_vec.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HPVM vPar'

    guest_tech = ('HPVM vPar', 'HPVM IVM')
    assert virtual_facts['virtualization_tech_guest'] == guest_tech
    assert virtual_facts['virtualization_tech_host'] == guest_tech

# Generated at 2022-06-11 05:53:34.913110
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual()
    assert virtual.platform == 'HP-UX'



# Generated at 2022-06-11 05:53:43.207573
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    v = HPUXVirtual()
    v.module = AnsibleModuleMock()
    v.module.run_command = MagicMock(return_value=(0, 'HPVM vPar', ''))
    v.get_virtual_facts()
    assert v.fact_subclass.virtualization_type == 'guest'
    assert v.fact_subclass.virtualization_role == 'HPVM vPar'
    assert 'HPVM vPar' in v.fact_subclass.virtualization_tech_guest
    assert v.fact_subclass.virtualization_tech_host == set()

    v.module.run_command.return_value = (0,'HP vPar','')
    v.get_virtual_facts()
    assert v.fact_subclass.virtualization_type == 'guest'
    assert v.fact

# Generated at 2022-06-11 05:53:44.000712
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual.platform == 'HP-UX'



# Generated at 2022-06-11 05:53:49.862674
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import virt_facts

    module = virt_facts.get_module_mock()
    module.run_command.return_value = 0, to_bytes("Running as a HPVM Guest OS"), None
    hpux_virtual = HPUXVirtual(module)

# Generated at 2022-06-11 05:53:57.354367
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    hw_facts = {
        'virtualization_type': 'host',
        'virtualization_role': 'HPVM',
        'virtualization_tech_guest': set()
    }

    # test on a system where /usr/sbin/vecheck exists and /opt/hpvm/bin/hpvminfo exists
    hw_facts_vecheck_hpvminfo = hw_facts.copy()
    hw_facts_vecheck_hpvminfo['virtualization_type'] = 'guest'
    hw_facts_vecheck_hpvminfo['virtualization_role'] = 'HP vPar'
    hw_facts_vecheck_hpvminfo['virtualization_tech_guest'].add('HP vPar')

# Generated at 2022-06-11 05:53:58.265326
# Unit test for method get_virtual_facts of class HPUXVirtual

# Generated at 2022-06-11 05:53:59.724678
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # NOTE: Since HPUXVirtual is not implemented as a metaclass,
    # this test is not applicable.
    pass


# Generated at 2022-06-11 05:54:00.884090
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual



# Generated at 2022-06-11 05:56:10.093633
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict())
    virtual.get_virtual_facts()

# Generated at 2022-06-11 05:56:16.780113
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_hpu = HPUXVirtual({})
    result = test_hpu.get_virtual_facts()
    if result.has_key('virtualization_type'):
        if result['virtualization_type'] == 'guest':
            if result['virtualization_role'] == 'HP vPar':
                assert os.path.exists('/usr/sbin/vecheck')
            elif result['virtualization_role'] == 'HPVM vPar':
                assert os.path.exists('/opt/hpvm/bin/hpvminfo')
                assert re.match('.*Running.*HPVM vPar.*', 'Running HPVM vPar')
            elif result['virtualization_role'] == 'HPVM IVM':
                assert os.path.exists('/opt/hpvm/bin/hpvminfo')


# Generated at 2022-06-11 05:56:19.878019
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = type('module',(object,), {"run_command":lambda *args, **kwargs: (0, "HPVM running", "")})()
    v = HPUXVirtual(module)
    assert v.platform == 'HP-UX'
