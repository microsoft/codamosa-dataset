

# Generated at 2022-06-11 05:46:34.205418
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict())
    assert virtual.platform == 'HP-UX'
    assert virtual.virtualization_type == 'guest'
    assert virtual.virtualization_role == 'HP vPar'
    assert virtual.virtualization_tech_guest == set(['HP vPar'])
    assert virtual.virtualization_tech_host == set()


# Generated at 2022-06-11 05:46:35.405618
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual()
    assert v.platform == 'HP-UX'

# Generated at 2022-06-11 05:46:44.001630
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import subprocess
    from ansible.module_utils.facts.virtual.hpux.hpux_virtual import HPUXVirtual
    subprocess.check_output = lambda x, y: ''
    from ansible.module_utils.facts.virtual.hpux.hpux_virtual import HPUXVirtual
    obj = HPUXVirtual(None)
    obj.module.run_command = lambda x: (0, '', '')
    obj.module.get_bin_path = lambda x: '/opt/hpvm/bin/hpvminfo'
    data = obj.get_virtual_facts()

# Generated at 2022-06-11 05:46:48.949555
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """ test method get_virtual_facts of class HPUXVirtual """
    module = AnsibleModuleMock()                                                                                                    
    module.run_command.return_value = (0, "Success", "")
    hv = HPUXVirtual(module)
    virtual_facts = hv.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'

# Generated at 2022-06-11 05:46:57.188073
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpu import HPUXVirtual
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import ModuleTestCase

    class RunCommand:
        def __init__(self, cmd, rc=0, out='', err=''):
            self.cmd = cmd
            self.rc = rc
            self.out = out
            self.err = err
            self.set_args()
        def set_args(self):
            self.rc, self.out, self.err = self.rc, self.out, self.err
        def __call__(self, cmd, *args, **kwargs):
            if cmd == self.cmd:
                return self.rc, self.out

# Generated at 2022-06-11 05:47:05.855135
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    Constructor of HP-UX Virtual class.
    """
    from ansible.module_utils.facts import FactCollector

    # Mock test module instance.
    class MockModule:
        def __init__(self, run_command_args_list=None):
            self.run_command_args_list = run_command_args_list
            self.run_command_called = 0

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None):
            if not self.run_command_args_list:
                raise RuntimeError('run_command() not provided any valid arguments.')
            self.run_command_called += 1
            run_command_args = self.run_command_args_list[self.run_command_called - 1]

# Generated at 2022-06-11 05:47:07.596616
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():

    hpx = HPUXVirtual({})
    assert hpx.platform == 'HP-UX'

# Generated at 2022-06-11 05:47:16.486269
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModuleMock(HPUXVirtual)

    v = HPUXVirtual(module)
    v.module = module

    return_value_cmd_vecheck = dict(rc=0, out="", err="")
    return_value_cmd_hpvminfo = dict(rc=0, out="", err="")
    return_value_cmd_parstatus = dict(rc=0, out="", err="")
    module.run_command.return_value = return_value_cmd_vecheck
    module.run_command.return_value = return_value_cmd_hpvminfo
    module.run_command.return_value = return_value_cmd_parstatus

    virtual_facts = v.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'

# Generated at 2022-06-11 05:47:18.460001
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(dict(), None)
    assert hpux_virtual.platform == 'HP-UX'



# Generated at 2022-06-11 05:47:26.821860
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpuxvirtual_object = HPUXVirtual()
    assert hpuxvirtual_object.platform == 'HP-UX'
    assert hpuxvirtual_object.get_virtual_facts() == {'virtualization_type': 'guest', 'virtualization_role': 'HP vPar',
                                                     'virtualization_tech_host': set(),
                                                     'virtualization_tech_guest': set(['HP vPar'])}
    assert hpuxvirtual_object.get_virtual_facts() == {'virtualization_tech_guest': set(['HP vPar']),
                                                     'virtualization_tech_host': set(),
                                                     'virtualization_type': 'guest',
                                                     'virtualization_role': 'HP vPar'}

# Generated at 2022-06-11 05:47:38.095946
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    virtual = HPUXVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts == {
        'virtualization_type': 'guest',
        'virtualization_role': 'HP vPar',
        'virtualization_tech_guest': {'HP vPar'},
        'virtualization_tech_host': {}
        }

# Generated at 2022-06-11 05:47:41.513439
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(dict(module=dict()), 'ansible.module_utils.facts.virtual.hpux.HPUXVirtual')
    assert hpux_virtual
    assert hpux_virtual.module
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-11 05:47:46.864775
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    expected_virtual_facts = {'virtualization_type': 'guest',
                              'virtualization_role': 'HP vPar',
                              'virtualization_tech_guest': set(['HP vPar']),
                              'virtualization_tech_host': set()}
    hw = HPUXVirtual(dict(module=None))
    virtual_facts = hw.get_virtual_facts()
    assert virtual_facts == expected_virtual_facts


# Generated at 2022-06-11 05:47:50.062001
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(dict())
    assert hv.platform == 'HP-UX'
    assert 'virtualization_tech_guest' in  hv.get_virtual_facts()
    assert 'virtualization_tech_host' in hv.get_virtual_facts()

# Generated at 2022-06-11 05:47:51.580598
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual()
    assert virtual.platform == 'HP-UX'


# Generated at 2022-06-11 05:47:59.591089
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    hpuxvirtual_object = HPUXVirtual()

    # Create a test_module & patch the module.run_command
    test_module = get_test_module()
    test_module.add_os_environment(HPUXVirtual.platform)
    test_module.run_command = get_run_command()

    # Create a dummy output of command run_command which returns the required data
    hpvminfo_out = '''HPVM vPar Status: Running'''
    hpuxvirtual_object.module.run_command.results = [0, hpvminfo_out, '']
    # Call the get_virtual_facts method of virtual_object
    hpu_virtual_facts = hpuxvirtual_object.get_virtual_facts()

    assert hpu_virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-11 05:48:04.035959
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX', "Platform should be 'HP-UX', got '%s'" % hv.platform
    assert hv.virtualization_tech_host == set(), "Host virtualization tech should be empty, got '%s'" % hv.virtualization_tech_host


# Generated at 2022-06-11 05:48:12.279766
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import ModuleStub
    from ansible.module_utils.facts.collector import BaseFactsCollector
    from ansible.module_utils.facts.virtual.hpuix import HPUXVirtual
    from ansible.module_utils.facts.virtual import VirtualCollector

    # Create the module stub
    module = ModuleStub()

    # Initialize a facts collector
    facts_collector = BaseFactsCollector
    facts_collector.populate(module)

    hpuix_virtual_collector = HPUXVirtualCollector(module)

    # Run the code to be tested
    virtual_facts = HPUXVirtual.get_virtual_facts(hpuix_virtual_collector)

    # Verify the result
    assert virtual_facts['virtualization_type'] == 'host'
   

# Generated at 2022-06-11 05:48:20.293739
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux_virtual import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux_virtual import HPUXVirtualCollector

    hpux_virtual_collector = HPUXVirtualCollector()
    hpux_virtual = HPUXVirtual(hpux_virtual_collector)

    # Create a dummy module object
    class DummyModule():
        def __init__(self):
            self.run_command = lambda *args, **kwargs: (0, '', '')

    module = DummyModule()
    hpux_virtual.set_module(module)


# Generated at 2022-06-11 05:48:23.598282
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    hw = HPUXVirtual(module)
    virtual_facts = hw.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'host'
    assert virtual_facts['virtualization_role'] == 'HPVM'


# Generated at 2022-06-11 05:48:42.965638
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.utils.path import unfrackpath
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector

    dummy_module = MockAnsibleModule()
    dummy_module.run_command = Mock()
    dummy_module.run_command.return_value = [0, '', '']
    dummy_module.get_bin_path = Mock()
    dummy_module.get_bin_path.return_value = unfrackpath('/usr/sbin/vecheck')
    dummy_virtual_collector = HPUXVirtualCollector(dummy_module)
    dummy_virtual = HPUXVirtual(dummy_module)
    dummy_virtual.get_virtual_facts = Mock()
    dummy_

# Generated at 2022-06-11 05:48:51.874512
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpar import HPUXVirtual
    from ansible.module_utils import basic
    from ansible.module_utils.facts import facts
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.urls import open_url

    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    module.run_command = MagicMock(return_value=(0, b'', ''))
    module.open_url = MagicMock(return_value=to_bytes(''))
    module.params = {}
    m_facts = facts.AnsibleFacts(module)
    m_HPUXVirtual = HPUXVirtual(module, m_facts)
    m_

# Generated at 2022-06-11 05:48:53.020440
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-11 05:48:54.813274
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual(None)
    assert h.platform == 'HP-UX'


# Generated at 2022-06-11 05:48:55.578287
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual(dict())
    assert v

# Generated at 2022-06-11 05:48:57.166042
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpx = HPUXVirtual()
    assert isinstance(hpx, HPUXVirtual)

# Generated at 2022-06-11 05:49:05.103707
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    hpuxv = HPUXVirtual('/usr/bin/python')
    hpuxv.module.run_command = lambda x: (0, '', '')
    hpuxv.module.get_bin_path = lambda x: '/usr/sbin/parstatus'
    assert hpuxv.get_virtual_facts() == {'virtualization_type': 'guest', 'virtualization_role': 'HP nPar',
            'virtualization_tech_host': set(), 'virtualization_tech_guest': set(['HP nPar'])}
    hpuxv.module.get_bin_path = lambda x: '/usr/sbin/vecheck'

# Generated at 2022-06-11 05:49:12.581601
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpu import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpu import HPUXVirtualCollector
    from ansible import constants as C

    mock_module = AnsibleModuleMock()

    # Configure mock module for this unit test
    def mock_run_command(command):
        if command == "/usr/sbin/vecheck":
            rc = 0
        elif command == "/opt/hpvm/bin/hpvminfo":
            rc = 0
            output = "Running in HPVM guest"
        elif command == "/usr/sbin/parstatus":
            rc = 0
        else:
            raise Exception("Unsupported command " + command)

        return (rc, output, '')

    mock_module.run_command = mock_run

# Generated at 2022-06-11 05:49:18.163303
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Test fixture
    class MockModule:
        pass

    class MockOs:
        @staticmethod
        def exists(path):
            # vecheck
            if path == '/usr/sbin/vecheck':
                return True
            # hpvminfo
            elif path == '/opt/hpvm/bin/hpvminfo':
                return True
            # parstatus
            elif path == '/usr/sbin/parstatus':
                return False

    class MockOsModule:
        @staticmethod
        def run_command(cmd):
            # vecheck
            if cmd == '/usr/sbin/vecheck':
                return (0, 'anything', '')
            # hpvminfo
            elif cmd == '/opt/hpvm/bin/hpvminfo':
                return (0, 'something', '')

# Generated at 2022-06-11 05:49:26.046780
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.HP_UX import HPUXVirtual

    fake_module = FakeModule({})
    # Fake class for testing only
    class FakeKernelVirtual(HPUXVirtual):
        platform = 'Linux'

        def __init__(self, module=None):
            self.module = module
            super(FakeKernelVirtual, self).__init__(module=module)

        def get_virtual_facts(self):
            return super(FakeKernelVirtual, self).get_virtual_facts()

    instance = FakeKernelVirtual(module=fake_module)


# Generated at 2022-06-11 05:49:47.319792
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import Facts


# Generated at 2022-06-11 05:49:48.669409
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux = HPUXVirtual(dict(), dict())
    assert hpux is not None

# Generated at 2022-06-11 05:49:50.104682
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(dict())
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-11 05:49:57.873440
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux_virtual import HPUXVirtual
    from ansible.module_utils.basic import AnsibleModule

    # define the module arguments that would be passed to AnsibleModule
    module_args = {}

    # instantiate the module object
    module = AnsibleModule(argument_spec=module_args)

    # instantiate the FactsCollector object
    fact_class_obj = HPUXVirtual(module)

    # get the virtual facts
    data = fact_class_obj.get_virtual_facts()

    assert data['virtualization_role'] == 'HP vPar'
    assert data['virtualization_type'] == 'guest'
    assert data['virtualization_tech_guest'] == set(['HP vPar'])
    assert data['virtualization_tech_host'] == set()

# Generated at 2022-06-11 05:50:00.331441
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpuxvirtual = HPUXVirtual('ansible.module_utils.facts.virtual', 'ansible.module_utils.facts')
    assert hpuxvirtual.platform == 'HP-UX'


# Generated at 2022-06-11 05:50:08.287713
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module_mock = {}
    module_mock['run_command'] = _mock_run_command
    HPVpar_facts = HPUXVirtual(module=module_mock).get_facts()

    module_mock['run_command'] = _mock_run_command_fail
    HPnPar_facts = HPUXVirtual(module=module_mock).get_facts()

    module_mock['run_command'] = _mock_run_command_fail
    HPVMguest_facts = HPUXVirtual(module=module_mock).get_facts()

    module_mock['run_command'] = _mock_run_command_fail
    HPVMvPar_facts = HPUXVirtual(module=module_mock).get_facts()


# Generated at 2022-06-11 05:50:14.048146
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False)
    virtual_facts = HPUXVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    assert virtual_facts['virtualization_tech_guest'] == {'HP vPar', 'HP nPar'}
    assert virtual_facts['virtualization_tech_host'] == set()



# Generated at 2022-06-11 05:50:22.113737
# Unit test for method get_virtual_facts of class HPUXVirtual

# Generated at 2022-06-11 05:50:30.172351
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_module = 'ansible.module_utils.facts.virtual.hpar.HPUXVirtual'
    test_class = 'HPUXVirtual'

    # HP nPar - guest

# Generated at 2022-06-11 05:50:33.270455
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """HPUXVirtual - get_virtual_facts(module)"""
    from ansible.module_utils.facts import ModuleStub

    module = ModuleStub()
    virtual = HPUXVirtual(module)
    virtual_facts = virtual.get_virtual_facts()

    assert(type(virtual_facts) is dict)

# Generated at 2022-06-11 05:51:02.726482
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hp_virtual = HPUXVirtual({})
    assert hp_virtual.platform == 'HP-UX'
    hp_virtual.get_virtual_facts()

# Generated at 2022-06-11 05:51:07.818554
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpar import HPUXVirtual
    import ansible.module_utils.ansible_release
    module = ansible.module_utils.facts.virtual.hpar.AnsibleModule(
        argument_spec=dict())
    hpuxtest_obj = HPUXVirtual(module)
    hpuxtest_obj.get_virtual_facts()

# Generated at 2022-06-11 05:51:16.639587
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpar import HPUXVirtual

    # Make the HPUXVirtual class think we are running on a HP-UX system
    # This can only be done in a unit test. In a real system we are running
    # on a real system, and changing the platform is not possible.
    orig_platform = HPUXVirtual.platform
    HPUXVirtual.platform = 'HP-UX'

    # Create a HPUXVirtual object
    h = HPUXVirtual(object())

    # Set the return values of the system calls executed by the methods
    # called by get_virtual_facts.
    h.module = object()
    h.module.run_command = object()
    h.module.run_command.return_value = (0, 'output', 'error')

    # Get the virtual facts

# Generated at 2022-06-11 05:51:19.722902
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    hpux_virtual = HPUXVirtual(module)
    hpux_virtual.collect()
    hpux_virtual.get_virtual_facts()

# Generated at 2022-06-11 05:51:21.349876
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virt = HPUXVirtual(None)
    assert hpux_virt.platform == 'HP-UX'

# Generated at 2022-06-11 05:51:25.586305
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirt = HPUXVirtual()
    assert HPUXVirt.platform == 'HP-UX'
    assert HPUXVirt.get_virtual_facts() == {'virtualization_type': 'host',
                                            'virtualization_role': None,
                                            'virtualization_tech_guest': set(),
                                            'virtualization_tech_host': set()}

# Generated at 2022-06-11 05:51:33.943348
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils._text import to_bytes
    from ansible.compat.tests.mock import MagicMock, patch
    import json
    import unittest

    class TestHPUXVirtual(unittest.TestCase):
        def setUp(self):
            self.hpx_virtual = HPUXVirtual(MagicMock(), MagicMock())

        def test_get_virtual_facts_no_hpvm(self):
            mock_rc = MagicMock()
            mock_rc.poll.return_value = 0
            mock_out = MagicMock()
            mock_out.read.return_value = to_bytes

# Generated at 2022-06-11 05:51:36.548795
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    '''
    Unit test for constructor of class HPUXVirtual
    '''
    HPUXvirtual = HPUXVirtual(dict())
    assert HPUXvirtual
    assert HPUXvirtual.platform == 'HP-UX'

# Generated at 2022-06-11 05:51:44.912538
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.linux import LinuxVirtual
    facts = { 'virtual_facts': {} }
    fake_module = VirtualCollector._FakeModule(facts)
    hpv = HPUXVirtual(fake_module)
    assert isinstance(hpv, Virtual)
    assert hpv.platform == 'HP-UX'
    assert hpv.virtualization_type is None
    assert hpv.virtualization_role is None
    hpv.get_virtual_facts()
    assert hpv.virtualization_type is not None
    assert hpv.virtualization_role is not None
    assert hpv.virtualization_type == 'host'

# Generated at 2022-06-11 05:51:51.698771
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    HPUXVirtual test - method 'get_virtual_facts'
    """
    import ansible.module_utils.facts.virtual.hpu

    hpu_virt = ansible.module_utils.facts.virtual.hpu.HPUXVirtual()
    assert hpu_virt.get_virtual_facts() == {'virtualization_type': 'guest', 'virtualization_role': 'HP vPar', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set(['HP vPar'])}

# Generated at 2022-06-11 05:52:39.981225
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-11 05:52:41.544849
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-11 05:52:42.776899
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt = HPUXVirtual({})
    assert virt.platform == 'HP-UX'

# Generated at 2022-06-11 05:52:52.561371
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Unit tests for method get_virtual_facts of class HPUXVirtual.
    """
    hv = HPUXVirtual(None, dict())
    hv.module.exit_json = exit_json
    hv.module.run_command = run_command

    # Setting the variable vPar
    hv.module.run_command.side_effect = [
        (0, "output_0", "error_0"),
        (1, "output_1", "error_1"),
        (0, "output_2", "error_2"),
        (1, "output_3", "error_3")
    ]
    hv.module.os.path.exists = os_path_exists
    hv.module.os.path.exists.side_effect = [True, True]
    hv

# Generated at 2022-06-11 05:53:02.477174
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # get_virtual_facts called without vecheck present
    module = AnsibleModule()
    # set up a fake filesystem
    module.run_command = MagicMock()
    module.run_command.side_effect = [(1, '', ''), (0, '', '')]
    module.get_bin_path = MagicMock(return_value="/usr/sbin/vecheck")
    virtual = HPUXVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'host'
    assert virtual_facts['virtualization_role'] == ''
    # get_virtual_facts called with vecheck present
    # set up a fake filesystem
    module.run_command = MagicMock()

# Generated at 2022-06-11 05:53:03.183198
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-11 05:53:04.923820
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv is not None
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-11 05:53:07.546084
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual({})
    assert virtual.__class__.__name__ == 'HPUXVirtual'
    assert virtual.get_virtual_facts() == {}

# Generated at 2022-06-11 05:53:16.793239
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """Unit test for method get_virtual_facts of class HPUXVirtual."""
    # pylint: disable=protected-access
    hpx_virtual = HPUXVirtual()
    hpx_virtual.module = type('', (), {'run_command':
                                       lambda hpx_virtual, cmd, check_rc=True:
                                       (0, '', '')})()

    # Case 1: No virtualization technology is installed
    hpx_virtual._get_virtual_facts = lambda: {}
    assert hpx_virtual.get_virtual_facts() == {'virtualization_tech_guest': {'HP nPar', 'HP vPar', 'HPVM IVM', 'HPVM vPar'}, 'virtualization_tech_host': {}}

    # Case 2: Virtualization technology is installed
    hpx_virtual._get_virtual

# Generated at 2022-06-11 05:53:22.737403
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    hppar = HPUXVirtual({})
    facts = hppar.get_virtual_facts()
    assert facts['virtualization_tech_guest'] == set(['HP nPar', 'HP vPar'])
    assert facts['virtualization_tech_host'] == set(['HPVM'])
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP vPar'

# Generated at 2022-06-11 05:55:29.550866
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.utils import context_objects as co

    facts_params = {'module': co.AnsibleModule(
        argument_spec={},
        supports_check_mode=True)}
    facts = HPUXVirtual(facts_params)
    facts.get_virtual_facts()['virtualization_type'] == 'guest'
    facts.get_virtual_facts()['virtualization_role'] == 'HPVM'

# Generated at 2022-06-11 05:55:31.056388
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-11 05:55:32.740191
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_hpux = HPUXVirtual("/dev/null")
    assert virtual_hpux.platform == 'HP-UX'



# Generated at 2022-06-11 05:55:41.256628
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """Unit test method to get virtual facts"""
    def test_module(module, *args, **kwargs):
        """Fake module.run_command method"""
        class FakePopen:
            """Fake Popen class used in tests"""
            def __init__(self, args, stdout=None, stderr=None):
                """Initialize FakePopen class"""
                self.stdout = stdout
                self.stderr = stderr
                self.returncode = 0

            def communicate(self):
                """Convert FakePopen class to string"""
                return (self.stdout, self.stderr)

        if module == '/usr/sbin/vecheck':
            return FakePopen(args, stdout='version:   B.11.11\n', stderr='')

# Generated at 2022-06-11 05:55:42.970834
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(dict(module=dict()))
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-11 05:55:47.264870
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    facts = HPUXVirtual({})
    virtual_facts = {'virtualization_type': 'guest',
                     'virtualization_role': 'HP vPar',
                     'virtualization_tech_guest': set(['HP vPar']),
                     'virtualization_tech_host': set([])}
    assert facts.get_virtual_facts() == virtual_facts

# Generated at 2022-06-11 05:55:54.954149
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """Unit test for method get_virtual_facts of class HPUXVirtual"""
    # Create a HPUXVirtual instance
    hpux_virtual = HPUXVirtual()

    # Test 'vecheck' is installed
    hpux_virtual.module.run_command = lambda cmd: (0, "Running HPVM vPar", None)
    hpux_virtual_facts = hpux_virtual.get_virtual_facts()
    assert hpux_virtual_facts['virtualization_type'] == 'guest'
    assert hpux_virtual_facts['virtualization_role'] == 'HP vPar'

    # Test 'hpvminfo' is installed
    hpux_virtual.module.run_command = lambda cmd: (0, "Running HPVM vPar", None)
    hpux_virtual_facts = hpux_virtual.get_virtual_facts()

# Generated at 2022-06-11 05:56:02.554185
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt = HPUXVirtual(None)

    assert virt.platform == 'HP-UX'
    assert virt.__doc__ == HPUXVirtual.__doc__
    assert virt.virtualization_type is None
    assert virt.virtualization_role is None
    assert virt.virtualization_type_role is None
    assert virt.virtualization_full is None
    assert virt.virtualization_type_full is None
    assert virt.virtualization_role_full is None
    assert virt.virtualization_tech_host == set()
    assert virt.virtualization_tech_guest == set()

# Generated at 2022-06-11 05:56:03.852870
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    td = HPUXVirtual({})
    td.get_virtual_facts()

# Generated at 2022-06-11 05:56:06.436160
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt = HPUXVirtual({})
    assert virt.platform == 'HP-UX'
    assert virt._fact_class == HPUXVirtual
    assert virt._platform == 'HP-UX'
