

# Generated at 2022-06-11 05:46:33.560069
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
    argument_spec = dict(
        gather_subset=dict(default=['!all'], type='list')
    ),
    supports_check_mode=True)
    hp_virtual = HPUXVirtual(module)

    facts = hp_virtual.get_virtual_facts()
    assert type(facts) is dict
    if os.path.exists('/usr/sbin/vecheck'):
        assert facts['virtualization_type'] == 'guest'
        assert facts['virtualization_role'] == 'HP vPar'
        assert 'HP vPar' in facts['virtualization_tech_guest']
    elif os.path.exists('/opt/hpvm/bin/hpvminfo'):
        assert facts['virtualization_type'] == 'guest'

# Generated at 2022-06-11 05:46:35.148641
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    my_HPUXVirtual = HPUXVirtual()

    assert my_HPUXVirtual.platform == 'HP-UX'

# Generated at 2022-06-11 05:46:37.277111
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_HPUXVirtual = HPUXVirtual()
    assert test_HPUXVirtual.get_virtual_facts() == {}

# Generated at 2022-06-11 05:46:42.455159
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(None)

    assert virtual_facts.platform == 'HP-UX'

    assert not hasattr(virtual_facts, 'virtualization_type')
    assert not hasattr(virtual_facts, 'virtualization_role')
    assert not hasattr(virtual_facts, 'virtualization_system')
    assert not hasattr(virtual_facts, 'virtualization_service')
    assert not hasattr(virtual_facts, 'virtualization_device')

# Generated at 2022-06-11 05:46:50.634570
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    class TestModule(object):
        def __init__(self):
            self.params = dict()

        def fail_json(self, msg, **kwargs):
            raise Exception()

        def run_command(self, cmd):
            if (cmd == "/usr/sbin/vecheck"):
                return (0, "", "")
            elif (cmd == "/opt/hpvm/bin/hpvminfo"):
                return (0, "Running HPVM guest", "")
            elif (cmd == "/usr/sbin/parstatus"):
                return (0, "Running HPVM guest", "")
            return (1, "", "")

    assert(HPUXVirtual(TestModule()).virtual_subclass == {})

# Generated at 2022-06-11 05:46:58.922225
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible_collections.ansible.community.tests.unit.compat.mock import MagicMock
    from ansible_collections.ansible.community.tests.unit.modules.utils import AnsibleModule
    from ansible_collections.ansible.community.plugins.module_utils.facts.virtual.hpux import HPUXVirtual

    mock_module = MagicMock(AnsibleModule)
    mock_module.run_command.return_value = (0, 'output', 'error')
    virtual_collector = HPUXVirtual(mock_module)

# Generated at 2022-06-11 05:47:07.801018
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = MockAnsibleModule('hpx')
    # Test the vPar path
    module.run_command = Mock(return_value=(0, '', ''))
    module.exists = Mock(side_effect=['/usr/sbin/vecheck'])
    obj = HPUXVirtual(module)
    obj._get_distribution = Mock(return_value=('HP-UX', 'B.11.31', 'U'))
    virtual_facts = obj.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    assert virtual_facts['virtualization_tech_guest'] == set(['HP vPar'])
    assert virtual_facts['virtualization_tech_host'] == set()
    #

# Generated at 2022-06-11 05:47:10.013894
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual({})
    assert h.platform == 'HP-UX', 'Platform should be HP-UX'


# Generated at 2022-06-11 05:47:11.439446
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual({})
    assert h.platform == 'HP-UX'


# Generated at 2022-06-11 05:47:12.483836
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual()



# Generated at 2022-06-11 05:47:23.323859
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual({})
    assert h.platform == 'HP-UX'

# Generated at 2022-06-11 05:47:25.429414
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hp_virtual = HPUXVirtual(dict(module=dict()))
    assert hp_virtual.platform == 'HP-UX'
    assert hp_virtual.get_virtual_facts() == {}

# Generated at 2022-06-11 05:47:33.083110
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class TestHPUXModule:
        def __init__(self):
            self.facts = {}

        def run_command(self, cmd):
            if cmd == "/usr/sbin/vecheck":
                return 0, "", ""
            elif cmd == "/opt/hpvm/bin/hpvminfo":
                return 0, "Running HPVM vPar", ""
            elif cmd == "/usr/sbin/parstatus":
                return 0, "", ""

    virtual = HPUXVirtual(TestHPUXModule())
    facts = virtual.get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HPVM vPar'
    assert facts['virtualization_tech_guest'] == set(['HPVM vPar'])

# Generated at 2022-06-11 05:47:41.591141
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # vPar
    results = {'virtualization_type': 'guest',
               'virtualization_role': 'HP vPar',
               'virtualization_tech_guest': {'HP vPar'},
               'virtualization_tech_host': set()}

    module = FakeModule("/usr/sbin/vecheck")
    virtual = HPUXVirtual(module)
    facts = virtual.get_virtual_facts()
    assert facts == results

    # HPVM IVM
    results = {'virtualization_type': 'guest',
               'virtualization_role': 'HPVM IVM',
               'virtualization_tech_guest': {'HPVM IVM'},
               'virtualization_tech_host': set()}

    module = FakeModule("/opt/hpvm/bin/hpvminfo")
    virtual

# Generated at 2022-06-11 05:47:44.314937
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    cls = HPUXVirtual(dict())
    assert cls.platform == 'HP-UX'
    assert cls._platform == 'HP-UX'
    assert cls.get_virtual_facts() == dict()

# Generated at 2022-06-11 05:47:45.766207
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual({})
    assert h
    assert h.platform == 'HP-UX'

# Generated at 2022-06-11 05:47:54.184135
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    virtuals = [('HPVM', {'virtualization_type': 'guest', 'virtualization_role': 'HPVM'}),
                ('HPVM vPar', {'virtualization_type': 'guest', 'virtualization_role': 'HPVM vPar'}),
                ('HP vPar', {'virtualization_type': 'guest', 'virtualization_role': 'HP vPar'}),
                ('HP nPar', {'virtualization_type': 'guest', 'virtualization_role': 'HP nPar'}),
                ('HPVM guest', {'virtualization_type': 'guest', 'virtualization_role': 'HPVM IVM'}),
                ('HPVM host', {'virtualization_type': 'host', 'virtualization_role': 'HPVM'}),
               ]

# Generated at 2022-06-11 05:48:02.389099
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    myv = HPUXVirtual({})
    # Preload the run-command with a list of output strings
    # Create a sample virtualization_tech_host & virtualization_tech_guest as expected with each output
    # The actual run-command will be called only once and the other results will be pulled out of the cache
    # vecheck
    myv.module.run_command = lambda x: (0, 'HP-UX vecheck B.11.31 U ia64 0501094512', '')
    virtual_facts = myv.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    assert 'HP vPar' in virtual_facts['virtualization_tech_guest']
    # hpvminfo
   

# Generated at 2022-06-11 05:48:04.075956
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict())
    assert virtual


# Generated at 2022-06-11 05:48:12.279337
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import json
    import os
    import sys
    import tempfile
    from ansible.module_utils.facts.virtual.hp_ux import HPUXVirtual

    class MockModule(object):
        def run_command(self, cmd, check_rc=True):
            if cmd == '/usr/sbin/vecheck':
                return 0, '', ''
            if cmd == '/opt/hpvm/bin/hpvminfo':
                return 0, 'Running HPVM vPar', ''
            if cmd == '/usr/sbin/parstatus':
                return 0, '', ''
            raise AssertionError('Unexpected command: {}'.format(cmd))


# Generated at 2022-06-11 05:48:24.112242
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """ Unit test for constructor of class HPUXVirtual
    """
    HPUXVirtual()

# Generated at 2022-06-11 05:48:25.859537
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux = HPUXVirtual(dict())
    assert hpux.platform == 'HP-UX'


# Generated at 2022-06-11 05:48:35.522264
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import errno
    import os
    import shutil

    class ModuleStub(object):
        def __init__(self):
            self.exit_args = None
            self.exit_kwargs = None
            self.run_command_args = None
            self.run_command_kwargs = None

        def exit_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs

        def run_command(self, *args, **kwargs):
            self.run_command_args = args
            self.run_command_kwargs = kwargs
            if args[0] == '/usr/sbin/vecheck':
                return 0, 'sbin/vecheck', ''

# Generated at 2022-06-11 05:48:43.811297
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Fake module
    module = FakeModule()

    # Initialize test class
    hv = HPUXVirtual(module)

    # Test scenario 1: No trick
    hv._get_virtual_facts()
    assert hv.facts['virtualization_type'] == 'guest'
    assert hv.facts['virtualization_role'] == 'HP vPar'
    assert 'HP vPar' in hv.facts['virtualization_tech_guest']
    assert not hv.facts['virtualization_tech_host']

    # Test scenario 2: HPVM IVM
    module.run_command_rc.append(0)
    module.run_command_out.append('/opt/hpvm/bin/hpvminfo: Running HPVM guest')
    hv._get_virtual_facts()

# Generated at 2022-06-11 05:48:45.226693
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_data = HPUXVirtual()
    assert  virtual_data.platform == 'HP-UX'


# Generated at 2022-06-11 05:48:46.041166
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    HPUXVirtual.get_virtual_facts()

# Generated at 2022-06-11 05:48:55.202858
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux.hpux import HPUXVirtual
    p = HPUXVirtual()
    if os.path.exists('/usr/sbin/vecheck'):
        rc, out, err = p.module.run_command("/usr/sbin/vecheck")
        if rc == 0:
            assert p.get_virtual_facts()['virtualization_type'] == 'guest'
            assert p.get_virtual_facts()['virtualization_role'] == 'HP vPar'
            assert p.get_virtual_facts()['virtualization_tech_guest'] == set(['HP vPar'])
            assert p.get_virtual_facts()['virtualization_tech_host'] == set()

# Generated at 2022-06-11 05:48:57.058029
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'
    assert not virtual_facts.virtual

# Generated at 2022-06-11 05:49:05.037972
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Test for HP-UX specific get_virtual_facts
    """

    # Create an instance of Virtual
    HPUXVirtual_obj = HPUXVirtual()

    # Test for case when VE is running
    HPUXVirtual_obj.module.run_command = \
        lambda cmd, check_rc=True: (0, "Virtual Environment is running", "")
    virtual_facts = HPUXVirtual_obj.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert virtual_facts['virtualization_type'] == 'guest'

# Generated at 2022-06-11 05:49:12.515395
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import mock, sys
    if sys.version_info[0] > 2:
        from io import StringIO
    else:
        from StringIO import StringIO

    from ansible.module_utils.facts.virtual.hpuux import HPUXVirtual, HPUXVirtualCollector

    module = mock.Mock()
    module.run_command.return_value = (0,'','')

    virtual_obj = HPUXVirtual(module=module)
    virtual_obj._collector = HPUXVirtualCollector()

    virtual_facts = virtual_obj.get_virtual_facts()

# Generated at 2022-06-11 05:49:44.169305
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    o = HPUXVirtual({})
    assert o.platform == 'HP-UX'
    assert o.virtual == 'guest'

# Generated at 2022-06-11 05:49:48.449326
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    obj = HPUXVirtual()
    assert obj.platform == 'HP-UX'
    obj = HPUXVirtual({})
    assert obj.platform == 'HP-UX'
    obj = HPUXVirtual({'platform': 'Linux'})
    assert obj.platform == 'Linux'
    return 0



# Generated at 2022-06-11 05:49:50.797548
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """ Unit test for constructor of class HPUXVirtual """
    module = FakeModule()
    virtual = HPUXVirtual(module)
    assert virtual.platform == 'HP-UX'


# Generated at 2022-06-11 05:49:51.280498
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual()

# Generated at 2022-06-11 05:49:55.913992
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.get_virtual_facts() == {}
    virtual_facts.module.run_command = run_command_mock
    assert virtual_facts.get_virtual_facts() == {'virtualization_type': 'host', 'virtualization_role': 'HPVM', 'virtualization_tech_guest': {'HPVM', 'HP vPar', 'HP nPar'}, 'virtualization_tech_host':set()}


# Generated at 2022-06-11 05:49:59.352561
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    facts = HPUXVirtual(dict()).get_virtual_facts()

    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts


# Generated at 2022-06-11 05:50:01.399245
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpv = HPUXVirtual(dict(module=dict()))
    assert hpv.platform == 'HP-UX'
    assert hpv.get_virtual_facts() == {}

# Generated at 2022-06-11 05:50:09.415003
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Test data
    out = dict()
    out['rc'] = 0
    out['stderr'] = ''

# Generated at 2022-06-11 05:50:13.251900
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    json_output = virtual_facts.get_virtual_facts()
    assert 'virtualization_type' in json_output
    assert 'virtualization_role' in json_output
    assert 'virtualization_tech_guest' in json_output
    assert 'virtualization_tech_host' in json_output

# Generated at 2022-06-11 05:50:14.987386
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict())
    assert virtual.virtualization_type == ''
    assert virtual.virtualization_role == ''

# Generated at 2022-06-11 05:50:45.791783
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    non_linux = dict(HPUXVirtual().get_virtual_facts())
    assert non_linux['virtualization_type'] == 'guest'
    assert non_linux['virtualization_role'] == 'HP vPar'

    # check that it is not running as non_linux.
    assert non_linux['virtualization_type'] != 'guest'
    assert non_linux['virtualization_role'] != 'HP vPar'

# Generated at 2022-06-11 05:50:47.633567
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict())
    assert virtual.platform == 'HP-UX'


# Generated at 2022-06-11 05:50:49.685912
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt_obj = HPUXVirtual({})
    assert isinstance(virt_obj, HPUXVirtual)
    assert virt_obj.platform == 'HP-UX'


# Generated at 2022-06-11 05:50:52.533255
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual(dict())
    assert v.virtualization_type == ''
    assert v.virtualization_role == ''
    assert v.virtualization_tech_guest == set()
    assert v.virtualization_tech_host == set()


# Generated at 2022-06-11 05:51:00.622683
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils._text import to_bytes

    module = AnsibleModule(argument_spec={})
    mock_get_bin_path = MagicMock(return_value="/usr/sbin/")
    mock_run_command = MagicMock(return_value=(0,to_bytes("test"),to_bytes("test")))
    with patch.dict(HPUXVirtual.__dict__, {'get_bin_path': mock_get_bin_path}):
        with patch.dict(HPUXVirtual.__dict__, {'run_command': mock_run_command}):
            obj = HPUXVirtual(module)
            obj.get_virtual_facts()
            mock_get_bin_path.assert_any

# Generated at 2022-06-11 05:51:02.366388
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hp_virtual = HPUXVirtual(dict())
    assert hp_virtual.platform == 'HP-UX'


# Generated at 2022-06-11 05:51:12.087500
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    module = FakeModule()
    obj = HPUXVirtual(module)

# Generated at 2022-06-11 05:51:13.576018
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts_obj = HPUXVirtual()
    assert virtual_facts_obj.platform == 'HP-UX'

# Generated at 2022-06-11 05:51:21.468575
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import HPUXVirtual
    from ansible.module_utils.facts.virtual import VirtualCollector
    from ansible.module_utils.facts.virtual import Virtual
    from ansible.module_utils.facts.virtual.dummy import Module
    import os

    # test normal conditions
    facts = Virtual()
    facts_collector = VirtualCollector(facts, Module())
    virtual_facts = HPUXVirtual(facts_collector)
    assert virtual_facts.get_virtual_facts() == {'virtualization_tech_guest': set(['HP nPar', 'HP vPar']), 'virtualization_tech_host': set(), 'virtualization_type': 'guest', 'virtualization_role': 'HP nPar'}

    # test excluded condition: no vecheck
    os.environ

# Generated at 2022-06-11 05:51:29.668850
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # create ansible module
    module = AnsibleModule(
        argument_spec = dict(),
    )

    # create fact collector
    fact_collector = HPUXVirtual(module)
    # get virtual facts
    virtual_facts = fact_collector.get_virtual_facts()
    # test result
    msg = "%s" % virtual_facts
    assert 'virtualization_type' in virtual_facts, "Missing key in %s" % msg
    assert 'virtualization_role' in virtual_facts, "Missing key in %s" % msg
    assert 'virtualization_tech_host' in virtual_facts, "Missing key in %s" % msg
    assert 'virtualization_tech_guest' in virtual_facts, "Missing key in %s" % msg
    # test usable values
    assert virtual_facts['virtualization_type']

# Generated at 2022-06-11 05:52:29.922021
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # pylint: disable=W0212
    # pylint: disable=E1002
    HPUXVirtual._module = FakeAnsibleModule()
    facts = HPUXVirtual().get_virtual_facts()
    assert facts['virtualization_type'] == 'host'
    assert facts['virtualization_role'] == 'HP vPar'
    assert facts['virtualization_tech_guest'] == set(['HP vPar', 'HPVM'])
    assert facts['virtualization_tech_host'] == set(['HP vPar', 'HPVM'])

# We are using a small ansible module class to mock _module.run_command()

# Generated at 2022-06-11 05:52:38.183519
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    test case for method get_virtual_facts of class HPUXVirtual
    """
    # Create a test module
    from ansible.module_utils.facts.virtual import ansible_virtual_facts
    test_module = ansible_virtual_facts.VirtualFactsModule()
    # Create a test class
    from ansible.module_utils.facts.virtual.hpu import HPUXVirtual
    test_class = HPUXVirtual(module=test_module)
    # Test get_virtual_facts
    virtual_facts = test_class.get_virtual_facts()
    assert(virtual_facts['virtualization_tech_guest'] == set([]))
    assert(virtual_facts['virtualization_tech_host'] == set([]))

# Generated at 2022-06-11 05:52:46.127931
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Create an instance of HPUXVirtual class
    virtual = HPUXVirtual(None)
    # Check it returns correct virtualization type
    assert virtual.get_virtual_facts()['virtualization_type'] == 'guest'
    # Check it returns correct virtualization role
    assert virtual.get_virtual_facts()['virtualization_role'] == 'HP vPar'
    # Check it returns empty list for virtualization technology host
    assert virtual.get_virtual_facts()['virtualization_tech_host'] == set()
    # Check it returns correct list for virtualization technology guest
    assert (virtual.get_virtual_facts()['virtualization_tech_guest'] ==
            {'HP vPar'})


# Generated at 2022-06-11 05:52:56.585574
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import fact_collector
    # Set of virtualization technologies used for testing
    guest_tech = set()
    host_tech = set()
    # Initialize a HPUXVirtual instance to test get_virtual_facts method
    hpux_virtual = HPUXVirtual()
    # Fake AnsibleModule
    hpux_virtual.module = fact_collector.AnsibleModule(
        argument_spec={})
    # Test guest of paravirtualized nPar
    guest_tech.add('HP nPar')
    os.environ['PATH'] = '/usr/sbin'
    rc = 0
    out = None
    err = None
    hpux_virtual.module.run_command = lambda x: (rc, out, err)
    facts = hpux_virtual.get_virtual_facts()

# Generated at 2022-06-11 05:52:57.427133
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_system = HPUXVirtual(dict())
    assert virtual_system.platform == 'HP-UX'


# Generated at 2022-06-11 05:53:01.552994
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualModule
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualFactCollector
    module = HPUXVirtualModule()
    collector = HPUXVirtualFactCollector(module=module)
    fake_module = {}
    fake_module['run_command'] = run_command
    fake_module['get_bin_path'] = lambda x, opt_dirs: '/bin/' + x
    module.module = fake_module
    virtual = HPUXVirtual(module=module)
    # Fake the path of command hpvminfo
   

# Generated at 2022-06-11 05:53:11.478265
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """Unit test module for method get_virtual_facts of class HPUXVirtual"""
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    virtual_hpux = HPUXVirtual(module)

    # Test with no FreeBSD directory
    facts = virtual_hpux.get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP nPar'
    assert list(virtual_hpux.get_virtual_facts()['virtualization_tech_host']
                ) == []
    assert list(virtual_hpux.get_virtual_facts()['virtualization_tech_guest']
                ) == ['HP nPar']

    # Test with no hpvminfo
    facts = virtual_hpux.get_virtual_

# Generated at 2022-06-11 05:53:12.836932
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual()
    assert h.platform == 'HP-UX'

# Generated at 2022-06-11 05:53:22.459685
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    facts = HPUXVirtual({})
    # Test normal case
    expected_virtual_facts = {'virtualization_tech_host': set(),
                              'virtualization_role': 'HP vPar',
                              'virtualization_tech_guest': {'HP vPar'},
                              'virtualization_type': 'guest'}
    real_virtual_facts = facts.get_virtual_facts()
    assert real_virtual_facts == expected_virtual_facts
    # Test other case
    facts = HPUXVirtual({})
    expected_virtual_facts = {'virtualization_tech_host': set(),
                              'virtualization_role': 'HPVM IVM',
                              'virtualization_tech_guest': {'HPVM IVM'},
                              'virtualization_type': 'guest'}
    real_

# Generated at 2022-06-11 05:53:31.656357
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = MagicMock()
    module.run_command.side_effect= [
        (0, '/usr/sbin/vecheck', ''),
        (0, '/opt/hpvm/bin/hpvminfo\nRunning HPVM guest\n', ''),
        (0, '/usr/sbin/parstatus', ''),
        (256, '', ''),
        (256, '', ''),
        ]
    hv = HPUXVirtual(module=module)
    hv_virtual_facts = hv.get_virtual_facts()
    assert hv_virtual_facts['virtualization_type'] == 'guest'
    assert hv_virtual_facts['virtualization_role'] == 'HPVM IVM'

# Generated at 2022-06-11 05:55:37.818791
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec=dict())

    # mock the module
    hpux_virtual = HPUXVirtual(module)
    hpux_virtual.module.run_command = MagicMock(return_value=(0, '', ''))

    # test parstatus
    hpux_virtual.module.run_command.return_value = (0, '', '')
    os.path.exists = MagicMock(return_value=True)
    assert hpux_virtual.get_virtual_facts()['virtualization_type'] == 'guest'
    assert hpux_virtual.get_virtual_facts()['virtualization_role'] == 'HP nPar'

    # test hpvm with HPVM vPar

# Generated at 2022-06-11 05:55:39.331991
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual({})
    assert v.platform == 'HP-UX'


# Generated at 2022-06-11 05:55:41.355167
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpx_virtual = HPUXVirtual(dict())
    assert hpx_virtual.platform == 'HP-UX'


# Generated at 2022-06-11 05:55:47.491535
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'
    assert hpux_virtual._platform == 'HP-UX'
    assert 'virtualization_type' in hpux_virtual.get_virtual_facts()
    assert 'virtualization_role' in hpux_virtual.get_virtual_facts()
    assert 'virtualization_tech_host' in hpux_virtual.get_virtual_facts()
    assert 'virtualization_tech_guest' in hpux_virtual.get_virtual_facts()


# Generated at 2022-06-11 05:55:51.083638
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux = HPUXVirtual({})
    assert hpux.platform == 'HP-UX'
    assert hpux.get_virtual_facts() == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

# Generated at 2022-06-11 05:55:54.423802
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts_instance = HPUXVirtual('/opt/hpvm/bin/hpvminfo', '/usr/sbin/parstatus', '/usr/sbin/vecheck')
    assert virtual_facts_instance.virtualization_type == 'guest'
    assert virtual_facts_instance.virtualization_role == 'HPVM vPar'

# Generated at 2022-06-11 05:56:04.016658
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils import basic

    m = basic.AnsibleModule(
        argument_spec = dict()
    )

    hv = HPUXVirtual(m)
    virtual_facts = hv.get_virtual_facts()

    # test for virtualization_type of guest
    assert virtual_facts['virtualization_type'] == 'guest'

    # test for virtualization_role of HP nPar
    assert virtual_facts['virtualization_role'] == 'HP nPar'

    # test for virtualization_tech_guest of HP nPar
    assert ('HP nPar' in virtual_facts['virtualization_tech_guest'])

    # test for virtualization_tech_host of HPVM
    assert ('HPVM' in virtual_facts['virtualization_tech_host'])

# Generated at 2022-06-11 05:56:05.778878
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpuxvirtual = HPUXVirtual()
    assert hpuxvirtual._platform == 'HP-UX'

# Generated at 2022-06-11 05:56:07.168189
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual({'module':{'run_command':run_command}})
    assert isinstance(h,Virtual)


# Generated at 2022-06-11 05:56:09.849757
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict()
    )

    hpux_virtual = HPUXVirtual(module)

    assert hpux_virtual.get_virtual_facts() == dict(virtualization_type='guest',
                                           virtualization_role='HP nPar',
                                           virtualization_tech_host=[],
                                           virtualization_tech_guest=set(['HP nPar']))