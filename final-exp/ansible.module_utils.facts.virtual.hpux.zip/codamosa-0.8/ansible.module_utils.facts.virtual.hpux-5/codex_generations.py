

# Generated at 2022-06-11 05:46:39.783915
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Test get_virtual_facts with different output of /usr/sbin/vecheck, /usr/sbin/parstatus, /opt/hpvm/bin/hpvminfo
    """

    facts = HPUXVirtual([], {}).get_virtual_facts()

    # vecheck is not exist on host; parstatus is not exists on host; hpvminfo is not exist on host
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''

    # vecheck is not exist on host; parstatus is not exists on host; hpvminfo shows running HPVM vPar

# Generated at 2022-06-11 05:46:44.231881
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    args = {}
    args['ansible_facts'] = {'ansible_architecture': 'IA64W', 'ansible_system': 'HP-UX'}
    hpux_virtual = HPUXVirtual(args)
    assert hpux_virtual.platform == 'HP-UX'
    assert hpux_virtual.fact_class == 'virtual'
    assert hpux_virtual.fact_subclass == 'virtual_facts'

# Generated at 2022-06-11 05:46:45.701253
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-11 05:46:53.929907
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.run_command = mock.Mock()

    # no tech installed
    module.run_command.return_value = (0, '', '')
    virtual_facts = HPUXVirtual(module).get_virtual_facts()
    assert_equals(virtual_facts['virtualization_type'], '')
    assert_equals(virtual_facts['virtualization_role'], '')
    assert_equals(virtual_facts['virtualization_tech_host'], set())
    assert_equals(virtual_facts['virtualization_tech_guest'], set())

    # HP vPar installed
    module.run_command.return_value = (0, '', '')
    virtual_facts = HPUXVirtual(module).get_virtual

# Generated at 2022-06-11 05:46:58.576229
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpar import HPUXVirtual
    hpar = HPUXVirtual()
    facts = hpar.get_virtual_facts()
    assert facts == {'virtualization_type': 'guest',
                     'virtualization_role': 'HP vPar',
                     'virtualization_tech_guest': set(['HP vPar']),
                     'virtualization_tech_host': set([])}

# Generated at 2022-06-11 05:47:07.433096
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # execute the get_virtual_facts method.
    # We need to mock the module so we can control the filesystem.
    hv = HPUXVirtual({})
    hv.module = MockModule()
    virtual_facts = hv.get_virtual_facts()
    # check that the returned data structure is correct:
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HPVM vPar'
    assert virtual_facts['virtualization_tech_guest'] == set(['HPVM', 'HPVM vPar'])
    assert virtual_facts['virtualization_tech_host'] == set()


# Test data for the test_HPUXVirtual_get_virtual_facts() method.

# Generated at 2022-06-11 05:47:08.696429
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv is not None

# Generated at 2022-06-11 05:47:10.455138
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual({})
    assert virtual
    assert virtual.platform == 'HP-UX'

# Generated at 2022-06-11 05:47:16.986685
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    v = HPUXVirtual(dict())
    assert v.platform == 'HP-UX'
    assert v.virtual == 'HP-UX'
    assert v.virtualization_type == 'guest'
    assert v.virtualization_role == 'HP vPar'
    assert v.virtualization_role == 'HPVM vPar'
    assert v.virtualization_role == 'HPVM IVM'
    assert v.virtualization_role == 'HPVM'
    assert v.virtualization_role == 'HP nPar'

# Generated at 2022-06-11 05:47:18.376908
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(None)
    assert virtual_facts

# Generated at 2022-06-11 05:47:32.425599
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    fake_module = type('', (), {'run_command': _fake_run_command})()
    HPUXVirtual().get_virtual_facts()
    HPUXVirtual().get_virtual_facts()
    HPUXVirtual().get_virtual_facts()
    HPUXVirtual().get_virtual_facts()
    HPUXVirtual().get_virtual_facts()
    HPUXVirtual().get_virtual_facts()


# Generated at 2022-06-11 05:47:40.979357
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.six import PY3
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import _get_uname_release
    import os
    import tempfile

    test_uname = 'HP-UX'
    test_uname_release = 'B.11.31'
    test_uname_machine = 'ia64'

    test_files = dict(
        vecheck='/usr/sbin/vecheck',
        hpvminfo='/opt/hpvm/bin/hpvminfo',
        parstatus='/usr/sbin/parstatus',
    )


# Generated at 2022-06-11 05:47:49.698224
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import HPUXVirtual
    from ansible.module_utils.facts.virtual import Virtual
    from ansible.module_utils.facts.virtual import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector

    test_obj = HPUXVirtual()
    virtual_facts = {}
    host_tech = set()
    guest_tech = set()
    virtual_facts['virtualization_tech_host'] = host_tech
    virtual_facts['virtualization_tech_guest'] = guest_tech

    # test case 1: path exists, out content is as expected, guest role
    test_obj.module.run_command = MagicMock()
    test_obj.module.run_command.return_value = 0, "INFORMATION:\n"

# Generated at 2022-06-11 05:47:57.859880
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    ''' test_HPUXVirtual_get_virtual_facts '''
    import platform
    import types
    import json
    from mock import patch
    from ansible.module_utils.facts import collector
    import ansible.module_utils.facts.virtual.hpux_virtual as hpux_virtual

    class FakeModule:
        ''' FakeModule '''
        def __init__(self):
            ''' __init__ '''
            self.params = {}
            self.exit_json = types.MethodType(lambda s, v: True, self)
            self.run_command = types.MethodType(lambda s, v: ("", "", 0), self)

    module = FakeModule()
    hpux_virtual.__salt__ = None

# Generated at 2022-06-11 05:48:06.824232
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.test_hpux import FakeModule
    from ansible.module_utils.facts.virtual.test_hpux import TestGetVirtualFacts
    from ansible.module_utils.facts.virtual.test_hpux import FakeHPVMInfo
    from ansible.module_utils.facts.virtual.test_hpux import FakeVECheck
    from ansible.module_utils.facts.virtual.test_hpux import FakeParStatus

    FakeModule.run_command_stdout['/opt/hpvm/bin/hpvminfo'] = FakeHPVMInfo
    FakeModule.run_command_stdout['/usr/sbin/vecheck'] = FakeVECheck
    FakeModule.run_command_stdout['/usr/sbin/parstatus'] = FakeParStatus

    hpux

# Generated at 2022-06-11 05:48:08.125171
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert isinstance(virtual_facts, HPUXVirtual) is True

# Generated at 2022-06-11 05:48:10.494239
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict(module=dict(run_command=run_command_mock)))
    assert virtual._platform == 'HP-UX'
    assert virtual.platform == 'HP-UX'



# Generated at 2022-06-11 05:48:18.869844
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import FactCollector
    import tempfile
    import json

    # Create temporary test directories
    tmp_root = tempfile.mkdtemp(prefix='facts_virtual_')
    tmp_paths = [
        tempfile.mkdtemp(prefix='facts_virtual_', dir=tmp_root),
        tempfile.mkdtemp(prefix='facts_virtual_', dir=tmp_root),
        tempfile.mkdtemp(prefix='facts_virtual_', dir=tmp_root),
        tempfile.mkdtemp(prefix='facts_virtual_', dir=tmp_root)
    ]

    # Create virtualization executables
    fp = open(tmp_paths[0] + '/vecheck', 'w')
    fp.write('#!/bin/sh\nexit 0')
    f

# Generated at 2022-06-11 05:48:23.974519
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpuxVirtual = HPUXVirtual()
    assert hpuxVirtual.platform == 'HP-UX'
    #assert hpuxVirtual.virtualization_type is None
    assert hpuxVirtual.virtualization_type == 'guest'
    #assert hpuxVirtual.virtualization_role is None
    assert hpuxVirtual.virtualization_role == 'HP vPar'
    assert hpuxVirtual.virtualization_tech_guest == 'HPVM'
    assert hpuxVirtual.virtualization_tech_host == 'HPVM'

# Generated at 2022-06-11 05:48:25.746263
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual()

    assert virtual_obj.platform == 'HP-UX'



# Generated at 2022-06-11 05:48:37.541228
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    result = HPUXVirtual().get_virtual_facts()
    assert result['virtualization_type'] == 'host'
    assert result['virtualization_role'] == 'HPVM'
    assert 'HPVM' in result['virtualization_tech_host']

# Generated at 2022-06-11 05:48:45.733990
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """ Unit test for method get_virtual_facts of class HPUXVirtual """
    failed = False
    try:
        virt = HPUXVirtual()
    except Exception as e:
        failed = True
        print(" (failed) ", end='')
        print("Cannot instantiate HPUXVirtual: %s" % repr(e))

    # Test HP nPar

# Generated at 2022-06-11 05:48:50.883350
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    facts = dict()

    # Initialize the class
    hpuxvirtual = HPUXVirtual(facts, dict())

    # Check the platform property
    assert hpuxvirtual.platform == 'HP-UX'

    # Check the get_virtual_facts method
    assert hpuxvirtual.get_virtual_facts() == dict()

# Generated at 2022-06-11 05:48:53.288949
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    data = {'system': 'HPUX', 'virtual': 'Xen'}
    virtual = HPUXVirtual(data)
    assert isinstance(virtual.get_virtual_facts(), dict)

# Generated at 2022-06-11 05:48:55.023578
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_test = HPUXVirtual(dict())
    assert virtual_test.platform == 'HP-UX'

# Generated at 2022-06-11 05:48:56.090854
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-11 05:49:04.335507
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # create a module object
    from ansible.module_utils.facts.virtual import HPUXVirtual
    my_obj = HPUXVirtual()

    # Put the contents of test vars files into a dictionary
    from ansible.module_utils.facts import HPUXFactCollector
    HPUXFactCollector.COLLECTORS = [
        'HPUXVirtualCollector',
    ]
    # create a module object
    from ansible.module_utils.facts.virtual import HPUXVirtual
    my_obj = HPUXVirtual()

    # Get tokens and values of test file
    filename = 'virtual-HP-UX-1'
    testfile_path = os.path.join(os.path.dirname(__file__), 'fixtures', filename)
    f = open(testfile_path, 'r')
   

# Generated at 2022-06-11 05:49:11.824519
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import stubs
    from ansible.module_utils.facts.collector.util.facts_modules import mock

    my_test = HPUXVirtual(mock)
    my_test.module = stubs.StubModule(
        run_command=lambda x, check_rc=True: (0, '', ''))

    # Test with normal input
    my_test.module.run_command = lambda x, check_rc=True: (0, '', '')


# Generated at 2022-06-11 05:49:17.706243
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux_standalone import HpuxStandaloneModule
    from ansible.module_utils.facts.virtual.hpux_standalone import HpuxStandaloneFacts
    import json
    import tempfile
    import shutil
    import os

    # Create temporary directory with hpux virtual infos
    temp_dir = tempfile.mkdtemp()
    os.mkdir(temp_dir + '/usr/sbin/')
    open(temp_dir + '/usr/sbin/vecheck', 'a').close()
    vecheck_out = tempfile.mkstemp()
    os.write(vecheck_out[0], '\n')
    os.close(vecheck_out[0])
    os.environ['PATH'] = temp_dir + ':' + os

# Generated at 2022-06-11 05:49:19.910237
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts._platform == 'HP-UX'
    assert virtual_facts._fact_class is HPUXVirtual
    assert virtual_facts._fact_subclass is None

# Generated at 2022-06-11 05:49:41.853717
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = type('DummyModule', (object,), {'run_command':lambda cmd, tmp=None: (0, '', '')})
    virtual_class = HPUXVirtual(module)

    # vPar, nPar, IVM
    module.run_command = lambda cmd, tmp=None: (0, '', '')
    virtual_facts = virtual_class.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP nPar'
    guest_tech = virtual_facts['virtualization_tech_guest']
    assert 'HP nPar' in guest_tech
    assert 'HP vPar' in guest_tech
    assert 'HPVM IVM' in guest_tech

# Generated at 2022-06-11 05:49:46.819256
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # mock module
    module = type('module', (object,), {'run_command': HPUXVirtual.run_command})()
    # mock fact
    fact = type('fact', (object,), {'module': module})

    h = HPUXVirtual(fact)
    facts = {'virtualization_type': 'host', 'virtualization_role': 'HPVM'}
    assert facts == h.get_virtual_facts()

# Generated at 2022-06-11 05:49:54.792463
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    module = None  # for type hint
    class HPModule:
        def run_command(command):  # for type hint
            return None  # for type hint
    class HPHostModule(HPModule):
        def run_command(command):  # for type hint
            return (0, 'HPVM host', None)

    class HPVMGuestModule(HPModule):
        def run_command(command):  # for type hint
            return (0, 'Running HPVM guest', None)
    class HPvParGuestModule(HPModule):
        def run_command(command):  # for type hint
            return (0, None, None)

# Generated at 2022-06-11 05:49:56.949766
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual_test_obj = HPUXVirtual(dict())
    assert 'HP-UX' == hpux_virtual_test_obj.platform


# Generated at 2022-06-11 05:49:59.459892
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # Create object of HPUXVirtual class and check that
    # attribute 'platform' contains string 'HP-UX'
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-11 05:50:06.556444
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """__init__() should initialize `_fact_class`"""
    h = HPUXVirtual(dict(module=dict(params=dict())))
    assert h._fact_class == h.__class__

# Test the collection here if we have the Python >= 2.7 required for Ansible
# to properly invoke it.
try:
    import collections.abc
except ImportError:
    # We are on Python 2.6 or earlier, so the check below will fail, and the
    # test will be skipped.
    pass
else:
    # We are on Python 2.7 or later, so the check below should succeed, and
    # the test should be executed.
    test_HPUXVirtualCollector()

# Generated at 2022-06-11 05:50:07.711661
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual({})
    assert virtual_obj


# Generated at 2022-06-11 05:50:15.898944
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpar import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpvm import HPUXVirtual
    module = FakeModule()
    hpar = HPUXVirtual(module)
    hpvm = HPUXVirtual(module)
    facts_hpar = hpar.get_virtual_facts()
    facts_hpvm = hpvm.get_virtual_facts()
    assert facts_hpar['virtualization_type'] == 'guest'
    assert facts_hpar['virtualization_role'] == 'HP vPar'
    assert 'HP vPar' in facts_hpar['virtualization_tech_guest']
    assert 'HPVM IVM' in facts_hpvm['virtualization_tech_guest']

# Generated at 2022-06-11 05:50:17.322730
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(dict())
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-11 05:50:23.502274
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    hv = HPUXVirtual()
    hvc = HPUXVirtualCollector()
    hvc.module = hv.module
    res = hv.get_virtual_facts()
    assert res['virtualization_role'] == ''
    assert res['virtualization_type'] == ''
    assert res['virtualization_tech_host'] == set()
    assert res['virtualization_tech_guest'] == set()

# Generated at 2022-06-11 05:50:46.098668
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import Facts
    import ansible.module_utils.facts.virtual.hpux as hpux_mod
    # Initialize the facts class
    facts = Facts()

    # Create the class instance
    virt_hpux = hpux_mod.HPUXVirtual(module=facts)

    # Initialize module_utils.facts.virtual.hpux.module
    virt_hpux.module = facts.module

    # Initialize module_utils.facts.virtual.hpux.module.run_command
    def run_command(cmd):
        rc = 0
        if cmd == "/usr/sbin/vecheck":
            out = "A VE is detected."
        elif cmd == "/opt/hpvm/bin/hpvminfo":
            out = "HPVM guest"

# Generated at 2022-06-11 05:50:47.597444
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual(dict()) is not None


# Generated at 2022-06-11 05:50:49.655002
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual.platform == 'HP-UX'


# Test if all fields of class HPUXVirtual are initialized after
# constructor of class HPUXVirtual

# Generated at 2022-06-11 05:50:57.794168
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import ansible.module_utils.facts.virtual.hpu_ux as vhpu_ux

    setattr(HPUXVirtualCollector, 'module', module_mock)
    vs = HPUXVirtual()
    vhpu_ux.os.path.exists = os_path_exists
    vhpu_ux.HPUXVirtual.module.run_command = run_command
    result = vs.get_virtual_facts()
    assert result == expected_result

# Mocks for unit test
module_mock = Mock()
module_mock.params = None


# Generated at 2022-06-11 05:51:03.812479
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.base import get_module_mock
    module = get_module_mock()
    module.run_command.return_value = [0, '', ''] # successful command execution
    hpux_virtual = HPUXVirtual(module)
    facts = hpux_virtual.get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP nPar'
    assert facts['virtualization_tech_guest'] == set(['HP nPar'])
    assert facts['virtualization_tech_host'] == set()

# Generated at 2022-06-11 05:51:06.617269
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(dict(module=dict()))
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-11 05:51:08.074620
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-11 05:51:17.009404
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Test data
    test_input1 = {
            'module_utils.basic.AnsibleModule': {
                "run_command.return_value": (0, 'test1', '')
            }
    }
    test_input2 = {
            'module_utils.basic.AnsibleModule': {
                "run_command.return_value": (0, 'test2', '')
            }
    }
    test_input3 = {
            'module_utils.basic.AnsibleModule': {
                "run_command.return_value": (0, 'test3', '')
            }
    }

# Generated at 2022-06-11 05:51:24.602858
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import Virtual, HPUXVirtual
    from ansible.module_utils.facts import ModuleStub
    from ansible.module_utils.facts import ansible_collector

    module_stub = ModuleStub()
    collector = ansible_collector._load_collectors(module_stub, 'HP-UX')['virtual']
    hsup_virtual = HPUXVirtual(module_stub)

    rc, out, err  = module_stub.run_command('/usr/sbin/parstatus')
    if rc == 0:
        virtual_fact = collector.get_virtual_facts()
        assert virtual_fact['virtualization_type'] == 'guest'
        assert virtual_fact['virtualization_role'] == 'HP nPar'
        virtual_fact = hsup_

# Generated at 2022-06-11 05:51:26.949679
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    facts = HPUXVirtual()
    assert isinstance(facts, HPUXVirtual)
    assert repr(facts) == "<hpu_ux_facts ({})>".format(facts.platform)

# Generated at 2022-06-11 05:51:43.316807
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    collector = HPUXVirtualCollector()
    assert isinstance(collector._platform, str)
    assert collector._platform == 'HP-UX'
    assert isinstance(collector._fact_class, object)

# Generated at 2022-06-11 05:51:53.788877
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible_collections.ansible.community.tests.unit.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase, set_module_args
    from ansible.module_utils import basic

    # make collection available for plugins.
    # for this test we need the plugin_loader
    from ansible.module_utils._text import to_bytes

    test_module = type('ansible_module', (basic.AnsibleModule, ), {})
    basic._ANSIBLE_ARGS = to_bytes('')

    # prepare arguments for ansible module
    module_args = dict(
        name='value'
    )

    # import module
    hpux_virtual = HPUXVirtual()
    hpux_virtual.module = test_module

    # prepare mocks

# Generated at 2022-06-11 05:52:02.068242
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    facts = {}
    module = type('MockModule', (), {})()
    module.run_command = type('MockRunCommand', (), {})()
    module.run_command.return_value = 0, '', ''

    from ansible.module_utils.facts.virtual import HPUXVirtual
    v = HPUXVirtual(module)

    # Testing for guest on HPVM IVm

    # Mock for hpvminfo
    hpvminfo = v.module.run_command.mock_calls[0]
    assert hpvminfo[1][0] == '/opt/hpvm/bin/hpvminfo'
    assert hpvminfo[1][1] == 'hpvm info -t'
    v.module.run_command.return_value = 0, 'Running HPVM guest', ''

    # Case

# Generated at 2022-06-11 05:52:03.631711
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtualmodule = HPUXVirtual(dict())
    assert virtualmodule.platform == 'HP-UX'

# Generated at 2022-06-11 05:52:04.817373
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    collect = HPUXVirtual()
    assert collect.platform == 'HP-UX'

# Generated at 2022-06-11 05:52:08.870960
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
        virtual_object = HPUXVirtual(dict(ANSIBLE_MODULE_ARGS={}))
        assert virtual_object.platform == 'HP-UX'
        assert virtual_object.get_virtual_facts() is not None


# Generated at 2022-06-11 05:52:11.087857
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-11 05:52:17.047852
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = None
    virtual = HPUXVirtual(module)
    facts = {'virtualization_type': 'guest', 'virtualization_role': 'HP nPar'}

    with os.popen("echo ''") as cmd_mock:
         rc, out, err = virtual.module.run_command = cmd_mock.close, cmd_mock.read(), cmd_mock.read()
         assert virtual.get_virtual_facts() == facts


# Generated at 2022-06-11 05:52:18.639272
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual(dict())
    assert virtual_obj.platform == 'HP-UX'

# Generated at 2022-06-11 05:52:26.565232
# Unit test for method get_virtual_facts of class HPUXVirtual

# Generated at 2022-06-11 05:52:49.840461
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict())
    assert virtual.facts['virtualization_type'] == 'guest'
    assert virtual.facts['virtualization_role'] == 'HP nPar'
    assert virtual.facts['virtualization_tech_host'] == set()
    assert virtual.facts['virtualization_tech_guest'] == set(['HP nPar'])

# Generated at 2022-06-11 05:52:52.291221
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual({}, {})
    assert v.platform == 'HP-UX'
    assert v.collector == 'HPUXVirtualCollector'


# Generated at 2022-06-11 05:52:59.359701
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    host_facts = {
        'virtualization_type': 'guest',
        'virtualization_role': 'HP nPar',
        'virtualization_tech_guest': set(['HP nPar']),
        'virtualization_tech_host': set()
    }
    virtual = HPUXVirtual(dict())
    virtual.module = FakeModule(dict())
    virtual.module.run_command = FakeCommand(0, '', '')

    result = virtual.get_virtual_facts()
    assert result == host_facts



# Generated at 2022-06-11 05:53:04.827943
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v_data = {
              'virtualization_type': 'host',
              'virtualization_role': 'HPVM',
              'virtualization_tech_guest': set(['HPVM']),
              'virtualization_tech_host': set([])
              }
    virt_facts = HPUXVirtual({}, {})
    virt_facts.populate()
    assert virt_facts.data == v_data


# Generated at 2022-06-11 05:53:06.661286
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-11 05:53:09.487597
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = None
    virtual_facts = HPUXVirtual(module)
    assert virtual_facts.platform == 'HP-UX'
    assert virtual_facts._platform == 'HP-UX'



# Generated at 2022-06-11 05:53:11.643936
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(dict())
    assert hv.get_virtual_facts() is not None


# Generated at 2022-06-11 05:53:12.971847
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual()
    assert virtual


# Generated at 2022-06-11 05:53:16.595953
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():

    module = Mock()
    module.run_command = MagicMock(return_value=(0, "", ""))
    module.get_bin_path = MagicMock(return_value='/usr/bin/')

    platform_virtual = HPUXVirtual(module)

    del platform_virtual


# Generated at 2022-06-11 05:53:18.725589
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(None).get_virtual_facts()
    assert virtual_facts and virtual_facts['virtualization_type'] == 'host'

# Generated at 2022-06-11 05:53:46.805719
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class MockModule(object):
        def __init__(self, out, rc=0):
            self.run_command = lambda x: (rc, out, '')

    def MockExists(path):
        return True

    def MockNotExists(path):
        return False

    out = '''Running vPar
Running HPVM host
'''
    osExists = os.path.exists
    os.path.exists = MockExists
    hpux = HPUXVirtual(MockModule(out))
    virtual_facts = hpux.get_virtual_facts()
    os.path.exists = osExists
    assert virtual_facts['virtualization_type'] == 'host'
    assert virtual_facts['virtualization_role'] == 'HPVM'

# Generated at 2022-06-11 05:53:54.202751
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    test_HPUXVirtual = HPUXVirtual()
    test_HPUXVirtual.module.get_bin_path = lambda x: x

    test_HPUXVirtual.module.run_command = lambda x: (0, '', '')
    assert test_HPUXVirtual.get_virtual_facts() == {'virtualization_tech_host': set(),
                                                    'virtualization_tech_guest': set()}

    test_HPUXVirtual.module.run_command = lambda x: (1, '', '')
    assert test_HPUXVirtual.get_virtual_facts() == {'virtualization_tech_host': set(),
                                                    'virtualization_tech_guest': set()}


# Generated at 2022-06-11 05:53:55.945824
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    return HPUXVirtual({'module':{'run_command': lambda x: [0, '', '']}})


# Generated at 2022-06-11 05:53:57.095048
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == "HP-UX"



# Generated at 2022-06-11 05:53:58.237990
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual_obj = HPUXVirtual()
    assert hpux_virtual_obj.platform == 'HP-UX'

# Generated at 2022-06-11 05:54:00.884663
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual()
    assert v.platform == 'HP-UX'
    assert v.virtualization_type == None
    assert v.virtualization_role == None
    assert v.virtualization_tech_guest == set()
    assert v.virtualization_tech_host == set()


# Generated at 2022-06-11 05:54:06.871720
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_module = AnsibleModuleFake(dict())
    virtual = HPUXVirtual(module=test_module)
    facts = virtual.get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts
    assert len(facts['virtualization_tech_guest']) == 2
    assert facts['virtualization_tech_guest'] == set(['HPVM', 'HP nPar'])
    assert len(facts['virtualization_tech_host']) == 0
    assert not facts['virtualization_tech_host']
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP nPar'



# Generated at 2022-06-11 05:54:12.809257
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = FakeModule()

    hpx_virtual = HPUXVirtual(module)

    # If /usr/sbin/vecheck exists, then HP vPar is added to both host and guest
    module.run_command.return_value = 0, "", ""
    module.stat.side_effect = OSError(2, "No such file or directory: '/usr/sbin/vecheck'")
    module.is_executable.return_value = True
    virtual_facts = hpx_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    assert 'HP vPar' in virtual_facts['virtualization_tech_guest']
    assert not virtual_facts['virtualization_tech_host']



# Generated at 2022-06-11 05:54:18.905091
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    facts_obj = HPUXVirtual({})
    # create a dict which contains all the required info to simulate
    # a vecheck command output
    vecheck_dict = {
        '/usr/sbin/vecheck': '',
        'rc': 0,
        'out': 'This is vecheck output',
        'err': ''
    }
    # invoke mocked run_command method
    facts_obj.module.run_command = Mock(
        side_effect=[
            (
                vecheck_dict['rc'],
                vecheck_dict['out'],
                vecheck_dict['err']
            )
        ]
    )
    # invoke the actual get_virtual_facts method
    virtual_facts = facts_obj.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
   

# Generated at 2022-06-11 05:54:21.081934
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpx_virtual = HPUXVirtual()
    assert hpx_virtual.__class__.__name__ == 'HPUXVirtual'
    assert hpx_virtual.platform == 'HP-UX'


# Generated at 2022-06-11 05:55:22.626271
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    host = HPUXVirtual()
    assert host.platform == 'HP-UX'
    assert host._virtual_facts['virtualization_role'] == 'HP nPar'


# Generated at 2022-06-11 05:55:26.809480
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_HPUXVirtual = HPUXVirtual(None)
    test_virtual_facts = test_HPUXVirtual.get_virtual_facts()
    assert not test_virtual_facts['virtualization_type']
    assert not test_virtual_facts['virtualization_role']
    assert not test_virtual_facts['virtualization_tech_guest']
    assert not test_virtual_facts['virtualization_tech_host']

# Generated at 2022-06-11 05:55:29.973894
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux = HPUXVirtual()
    assert hpux.virtualization_type == 'host'
    assert hpux.virtualization_role == ''
    assert hpux.virtualization_tech_host == 'HPVM'
    assert hpux.virtualization_tech_guest == set()

# Generated at 2022-06-11 05:55:31.722211
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.get_virtual_facts() == { 'virtualization_type': 'none' }

# Generated at 2022-06-11 05:55:40.000678
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class Module(object):
        def __init__(self):
            self.run_command_calls = []

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            out = None
            err = None
            rc = 0

# Generated at 2022-06-11 05:55:41.896230
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    facts = dict()
    virtual = HPUXVirtual(facts)
    assert virtual.platform == 'HP-UX'


# Generated at 2022-06-11 05:55:50.333617
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    ov = HPUXVirtual({})
    # case 1: EXE vecheck exists, output Running HP vPar
    ov.module = Mock(return_value=(0, 'Running HP vPar', ''))
    fact = ov.get_virtual_facts()
    assert fact['virtualization_type'] == 'guest'
    assert fact['virtualization_role'] == 'HP vPar'
    # case 2: EXE vecheck exists, output Running HPVM guest
    ov.module = Mock(return_value=(0, 'Running HPVM guest', ''))
    fact = ov.get_virtual_facts()
    assert fact['virtualization_type'] == 'guest'
    assert fact['virtualization_role'] == 'HPVM IVM'
    # case 3: EXE vecheck exists, output Running HPVM vPar
    ov.module = Mock

# Generated at 2022-06-11 05:55:56.036094
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """Unit test for method get_virtual_facts of class HPUXVirtual."""

    # Create an instance of class HPUXVirtual
    hpux_virtual = HPUXVirtual()

    # Unit test for method get_virtual_facts
    # Should return a dictionary
    facts = hpux_virtual.get_virtual_facts()
    assert isinstance(facts, dict) is True
    assert facts['virtualization_type'] == 'none'
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-11 05:56:02.285538
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # get a HPUXVirtual object
    HPUXVirtualObj = HPUXVirtual()
    assert HPUXVirtualObj.get_virtual_facts() == {'virtualization_tech_guest': {'HP vPar', 'HP nPar', 'HPVM vPar', 'HPVM IVM'}, 'virtualization_tech_host': set(), 'virtualization_type': 'guest', 'virtualization_role': 'HP vPar'}

# Generated at 2022-06-11 05:56:04.179809
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    test_HPUXVirtual = HPUXVirtual({})
    assert isinstance(test_HPUXVirtual, HPUXVirtual)
