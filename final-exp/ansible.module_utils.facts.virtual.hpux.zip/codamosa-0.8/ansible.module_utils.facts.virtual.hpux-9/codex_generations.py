

# Generated at 2022-06-11 05:46:27.801100
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual(dict())
    assert h.platform == 'HP-UX'



# Generated at 2022-06-11 05:46:35.369102
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.virtual import Virtual
    import ansible.module_utils.facts.virtual.hpar as hpar
    import ansible.module_utils.facts.virtual.hpvm as hpvm
    import ansible.module_utils.facts.virtual.hvxvm as hvxvm
    from ansible.module_utils.facts.virtual.hvxvm import HVXVMVirtual
    from ansible.module_utils.facts.virtual.hpvm import HPVMVirtual

    # Setup
    virtual = HPUXVirtual({})
    virtual.module = Facts()
    delattr(virtual.module, 'exit_json')

# Generated at 2022-06-11 05:46:43.327231
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class TestModule():
        def run_command(self, cmd):
            return (0, "Running HPVM guest", "")
    class TestAnsibleModule():
        def __init__(self):
            self.run_command = TestModule.run_command

    module = TestAnsibleModule()
    hp_virtual = HPUXVirtual(module)
    virtual_facts = hp_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HPVM IVM'
    assert virtual_facts['virtualization_tech_guest'] == {'HPVM IVM'}
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-11 05:46:44.752432
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux = HPUXVirtual(dict())
    assert hpux.platform == 'HP-UX'


# Generated at 2022-06-11 05:46:52.986005
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class MockedModule():
        def __init__(self):
            self.params = {}
        def run_command(self, arg):
            if arg == '/usr/sbin/vecheck':
                return (0, 'HP-UX virtualization', '')
            if arg == '/opt/hpvm/bin/hpvminfo':
                return (0, 'Running for HPVM vPar', '')
            if arg == '/usr/sbin/parstatus':
                return (0, 'HP nPar', '')

    mock_module = MockedModule()
    virtual_instance = HPUXVirtual(mock_module)
    virtual_instance.get_virtual_facts()

    assert mock_module.params['virtualization_type'] == 'guest'

# Generated at 2022-06-11 05:46:55.495702
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    results = HPUXVirtual().collect()
    assert 'virtual' in results.keys()
    assert type(results['virtual']) is dict
    assert 'virtualization_type' in results['virtual'].keys()

# Generated at 2022-06-11 05:47:01.245111
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.posix import AnsibleModule
    module = AnsibleModule()
    hp_virtual = HPUXVirtual(module)
    facts = hp_virtual.get_virtual_facts()

    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP vPar'
    assert facts['virtualization_tech_guest'] == set(['HP vPar'])
    assert facts['virtualization_tech_host'] == set()

# Generated at 2022-06-11 05:47:10.582692
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Create a mock module
    import ansible.module_utils.facts.virtual.hpux as hpux
    module = hpux.AnsibleModuleMock()

    # Create a file for the parstatus command
    with open('/usr/sbin/parstatus', 'w+') as file:
        file.write('parstatus')
        file.close()

    # Create a file for the vecheck command
    with open('/usr/sbin/vecheck', 'w+') as file:
        file.write('vecheck')
        file.close()

    # Create a file for the hpvminfo command
    with open('/opt/hpvm/bin/hpvminfo', 'w+') as file:
        file.write('hpvminfo')
        file.close()

    # Create HPUXVirtual Object
   

# Generated at 2022-06-11 05:47:12.852983
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'
    assert hpux_virtual.get_virtual_facts() == {}

# Generated at 2022-06-11 05:47:15.760618
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    Test the constructor of class HPUXVirtual
    """
    # Constructor
    hpux_virtual = HPUXVirtual()
    assert (isinstance(hpux_virtual, HPUXVirtual))



# Generated at 2022-06-11 05:47:26.370770
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual({})
    assert virtual_obj.platform == 'HP-UX'

# Generated at 2022-06-11 05:47:34.464936
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Create the module mock
    module = MockModule()
    # Create the mock for function run_command
    run_command = MockFunction('run_command')
    # Mock the function run_command to return the specified value when called with the specified parameters
    run_command.return_value_when_called_with('/usr/sbin/vecheck', (0, 'Running HP-UX 11iv2 vPar', ''))
    module.run_command = run_command
    # Create the mock for function os.path.exists
    os_path_exists = MockFunction('os.path.exists')
    # Mock the function os.path.exists to return the specified value when called with the specified parameters
    os_path_exists.return_value_when_called_with('/usr/sbin/vecheck', True)
    os_

# Generated at 2022-06-11 05:47:42.839028
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class MyModule:
        def run_command(self, command):
            if command == '/usr/sbin/vecheck' and os.path.exists('/usr/sbin/vecheck'):
                return 0, 'HP-UX vecheck', ''
            if command == '/opt/hpvm/bin/hpvminfo' and os.path.exists('/opt/hpvm/bin/hpvminfo'):
                return 0, 'Running HPVM vPar', ''
            if command == '/usr/sbin/parstatus' and os.path.exists('/usr/sbin/parstatus'):
                return 0, 'HP-UX parstatus', ''
            return 1, 'command not found', ''
    # Test on HP-UX
    m = MyModule()
    hpx = HPUXVirtual(m)
   

# Generated at 2022-06-11 05:47:44.475071
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hvirtual = HPUXVirtual()
    assert hvirtual.platform == 'HP-UX'


# Generated at 2022-06-11 05:47:48.426081
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual(dict()).get_virtual_facts() == {'virtualization_tech_guest': set([]), 'virtualization_tech_host': set([]), 'virtualization_type': None, 'virtualization_role': None}
    assert HPUXVirtual(dict()).platform == 'HP-UX'


# Generated at 2022-06-11 05:47:50.570172
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual_obj = HPUXVirtual(dict(module=dict()))
    assert hpux_virtual_obj.platform == 'HP-UX'


# Generated at 2022-06-11 05:47:52.347518
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux = HPUXVirtual({})
    assert hpux.__class__.__name__ == "HPUXVirtual"


# Generated at 2022-06-11 05:47:54.462135
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual_obj = HPUXVirtual({}, {}, {})
    assert hpux_virtual_obj.platform == 'HP-UX'


# Generated at 2022-06-11 05:47:56.979727
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v1 = HPUXVirtual({}, {}, {})
    assert v1.platform == 'HP-UX'
    assert v1.guest == ''
    assert v1.virtualization_type == ''


# Generated at 2022-06-11 05:48:05.777386
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux.hpux import HPUXVirtual

    s = HPUXVirtual()


# Generated at 2022-06-11 05:48:19.063990
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual(dict())
    assert h.platform == 'HP-UX'
    assert h.get_virtual_facts() == {}

# Generated at 2022-06-11 05:48:27.137387
# Unit test for method get_virtual_facts of class HPUXVirtual

# Generated at 2022-06-11 05:48:30.381267
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    x = HPUXVirtual()
    assert x.platform == 'HP-UX'
    assert x.get_virtual_facts() == {'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}

# Generated at 2022-06-11 05:48:36.323947
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = {
        'virtualization_type': 'guest',
        'virtualization_role': 'HP vPar',
        'virtualization_tech_guest': {'HP vPar'},
        'virtualization_tech_host': set()
        }
    virtual = HPUXVirtual()
    virtual_facts_actual = virtual.get_virtual_facts()
    assert virtual_facts == virtual_facts_actual

# Generated at 2022-06-11 05:48:44.569957
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import os
    module = AnsibleModule(argument_spec={})
    module.params = {}

    virtual_facts = HPUXVirtual(module).get_virtual_facts()

    if os.path.exists('/usr/sbin/parstatus'):
        assert "guest" in virtual_facts['virtualization_type']
        assert "HP nPar" in virtual_facts['virtualization_role']
        assert 'guest' in virtual_facts['virtualization_tech_guest']
        assert 'host' in virtual_facts['virtualization_tech_host']
        assert virtual_facts['virtualization_tech_guest'] == set(('HP nPar'))
        assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-11 05:48:53.487208
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    fake_module = FakeModule()
    fake_module.run_command = lambda x: (0, '', '')
    virtual = HPUXVirtual(fake_module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP nPar'
    assert virtual

# Generated at 2022-06-11 05:48:55.201002
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-11 05:48:59.289163
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual(dict())
    assert h.platform == 'HP-UX'
    assert h.get_virtual_facts() == {
        'virtualization_type': 'host',
        'virtualization_role': 'HPVM',
        'virtualization_tech_guest': {'HPVM'},
        'virtualization_tech_host': set(),
    }

# Generated at 2022-06-11 05:49:00.936284
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict())
    assert virtual
    assert virtual.platform == 'HP-UX'


# Generated at 2022-06-11 05:49:08.486732
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import virtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    import logging
    import unittest

    class MockModule:
        def __init__(self):
            self.run_command = MockModule.run_command

        def run_command(cmd):
            if cmd == "/usr/sbin/parstatus":
                return [0, "Running as /usr/sbin/parstatus", None]
            elif cmd == "/opt/hpvm/bin/hpvminfo":
                return [0, "Running as /opt/hpvm/bin/hpvminfo", None]
            elif cmd == "/usr/sbin/vecheck":
                return [0, "Running as /usr/sbin/vecheck", None]


# Generated at 2022-06-11 05:49:28.758326
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    virtual_collector = HPUXVirtualCollector(module=module)
    virtual_collector.collect(module=module, collected_facts=dict())
    f = HPUXVirtual(module=module, collected_facts=dict())
    virtual_facts = f.get_virtual_facts()
    assert virtual_facts

# Generated at 2022-06-11 05:49:36.449973
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import sys
    import io
    import mock

    class MockModule:
        def __init__(self, *args, **kwargs):
            self.params = {}
            self.run_command_args = []

        def run_command(self, args):
            self.run_command_args.append(args)

            rc = 0
            out = ''
            err = ''
            if args == '/usr/sbin/vecheck':
                out = 'Running: HP vPar'
            elif args == '/opt/hpvm/bin/hpvminfo':
                out = 'Running: HPVM guest'
            elif args == '/usr/sbin/parstatus':
                rc = 1

            return rc, out, err

    # We capture sys.stdout and we transform it into a StringIO object
    # so we can assert

# Generated at 2022-06-11 05:49:43.876310
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.virtual import HPUXVirtual
    from ansible.module_utils.facts.virtual import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.modules.system.setup import SetupModule
    import json

    # create test setup module
    class TestSetupModule(SetupModule):
        def run(self, tmp=None, task_vars=None):
            return super(TestSetupModule, self).run(tmp, task_vars)

    # set some test data
    set_module_args({'gather_subset': 'all'})
    setup_module = TestSetupModule()
    setup

# Generated at 2022-06-11 05:49:47.677497
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    facts = HPUXVirtual({})
    assert facts.platform == 'HP-UX'
    # asserting virtualization_tech_host and virtualization_tech_guest are empty set
    assert not facts.virtualization_tech_host
    assert not facts.virtualization_tech_guest

# Generated at 2022-06-11 05:49:55.418593
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_module = AnsibleModule(argument_spec={})
    test_module.run_command = Mock(return_value=(0, '', ''))
    test_module.os.path.exists = Mock(return_value=True)
    test_module.set_module_args({})

    # Execute the method under test
    hpux_virtual = HPUXVirtual(test_module)
    hpux_virtual_facts = hpux_virtual.get_virtual_facts()

    assert hpux_virtual_facts

    # Verify that the method returns a dictionary
    assert isinstance(hpux_virtual_facts, dict)

    # Verify that the contents of the dictionary match the expected values
    assert hpux_virtual_facts['virtualization_type'] == 'guest'

# Generated at 2022-06-11 05:50:03.567772
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )

    os.path.exists = Mock(return_value = True)
    module.run_command = Mock(return_value = (0, '', ''))

    if os.path.exists('/usr/sbin/vecheck'):
        os.path.exists.return_value = True
        module.run_command.return_value = (0, '', '')

    if os.path.exists('/opt/hpvm/bin/hpvminfo'):
        os.path.exists.return_value = True
        module.run_command.return_value = (0, 'Running HPVM host', '')


# Generated at 2022-06-11 05:50:05.295335
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_subclass = HPUXVirtual()
    assert virtual_subclass.platform == 'HP-UX'


# Generated at 2022-06-11 05:50:10.201413
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = MockModule({})
    m = HPUXVirtual({'module': module})
    # Hard code the facts dictionary to test specific virtual facts
    m.facts = {'virtualization_tech_guest': set(['HP nPar']),
               'virtualization_tech_host': set(),
               'virtualization_type': 'guest',
               'virtualization_role': 'HP nPar'}
    assert m.get_virtual_facts() == m.facts

# Generated at 2022-06-11 05:50:12.655538
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    options = {'module': {'args': '{}'}}
    hpux_virtual = HPUXVirtual(options)
    assert hpux_virtual.platform == "HP-UX"



# Generated at 2022-06-11 05:50:15.651340
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    Unit test for constructor of class HPUXVirtual
    """

    virtual_obj = HPUXVirtual()
    assert virtual_obj is not None
    assert virtual_obj.platform == 'HP-UX'
    assert virtual_obj._virtual_facts == {}


# Generated at 2022-06-11 05:50:53.973069
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    '''
    This method test if get_virtual_facts method return correct virtualization
    type when system is running under HP-UX virtualization
    '''
    from ansible.module_utils.facts import virtual

    module_mock = AnsibleModuleMock()
    hpuxvirtual_instance = HPUXVirtual(module_mock)
    result = hpuxvirtual_instance.get_virtual_facts()
    assert result == {
        'virtualization_type': 'guest',
        'virtualization_role': 'HP nPar',
        'virtualization_tech_guest': set(['HP nPar']),
        'virtualization_tech_host': set([]),
    }

# Generated at 2022-06-11 05:51:02.189649
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import virtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.base import BaseVirtual, Virtual

    class FakeModule(object):
        def run_command(self, command):
            return 0, "Running HPVM Host", ""

    hpux = HPUXVirtual(FakeModule())
    result = hpux.get_virtual_facts()
    assert isinstance(result, dict)
    assert result['virtualization_type'] == 'host'
    assert result['virtualization_role'] == 'HPVM'
    assert result['virtualization_tech_host'] == set(['HPVM'])
    assert result['virtualization_tech_guest'] == set([])
    assert isinstance(hpux, BaseVirtual)


# Generated at 2022-06-11 05:51:03.544046
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-11 05:51:06.151888
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual(dict(ANSIBLE_MODULE_ARGS={}))
    assert h.platform == 'HP-UX'

# Generated at 2022-06-11 05:51:15.119250
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual, HPUXVirtualCollector

    module = FakeModule()
    hpux = HPUXVirtual(module)

    hpux.get_virtual_facts()

    assert 'virtualization_tech_guest' in module.exit_args
    assert 'virtualization_tech_host' in module.exit_args
    assert 'virtualization_type' in module.exit_args
    assert 'virtualization_role' in module.exit_args
    assert 'HPVM IVM' in module.exit_args['virtualization_tech_guest']
    assert 'HPVM vPar' in module.exit_args['virtualization_tech_guest']
    assert 'HP nPar' in module.exit_args['virtualization_tech_guest']

# Generated at 2022-06-11 05:51:16.537987
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual()
    assert v.platform == 'HP-UX'


# Generated at 2022-06-11 05:51:24.160836
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    MockedModule = type('MockedModule', (object,), {'run_command': lambda *_: (0, '', ''), 'params': {}})

    MockedModule.run_command = lambda *_: (0, 'Running HPVM vPar.', '')
    instance = HPUXVirtual(MockedModule)
    facts = instance.get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HPVM vPar'
    assert facts['virtualization_tech_guest'] == set(['HPVM IVM', 'HP vPar', 'HP nPar', 'HPVM vPar', 'HPVM'])
    assert facts['virtualization_tech_host'] == set()


# Generated at 2022-06-11 05:51:27.174253
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv._platform == "HP-UX"
    assert isinstance(hv._fact_class, type(Virtual))
    assert hv._virtual_files == {}


# Generated at 2022-06-11 05:51:29.202055
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    collector = HPUXVirtualCollector()
    assert collector._platform == 'HP-UX'
    assert collector._fact_class.platform == 'HP-UX'

# Generated at 2022-06-11 05:51:30.486933
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict())

    assert virtual.platform == 'HP-UX'

# Generated at 2022-06-11 05:52:30.053323
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Initialize the test
    virtual_data = {}
    virtual_data['virtualization_type'] = {}
    virtual_data['virtualization_role'] = {}
    virtual_data['virtualization_tech_host'] = set()
    virtual_data['virtualization_tech_guest'] = set()
    virtual_data['virtualization_type'] = 'guest'
    virtual_data['virtualization_role'] = 'HP vPar'
    virtual_data['virtualization_tech_guest'].add('HP vPar')
    hpux_virtual = HPUXVirtual()
    hpux_virtual.module.run_command = run_command_mock
    hpux_virtual.file_exists = file_exists_mock

    # Run the get_virtual_facts
    result = hpux_virtual.get_virtual_

# Generated at 2022-06-11 05:52:33.585429
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test = HPUXVirtual(dict(module=None, params=dict(gather_subset='!all,!any,virtual')))
    virtual_facts = test.get_virtual_facts()
    assert virtual_facts['virtualization_role'] == 'HP nPar'



# Generated at 2022-06-11 05:52:39.210737
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec={}
    )
    hpuxvirtual = HPUXVirtual(module)
    hpuxvirtualfacts = hpuxvirtual.get_virtual_facts()
    assert(hpuxvirtualfacts['virtualization_tech_guest'] == set())
    assert(hpuxvirtualfacts['virtualization_tech_host'] == set())
    assert(hpuxvirtualfacts['virtualization_type'] == '')
    assert(hpuxvirtualfacts['virtualization_role'] == '')



# Generated at 2022-06-11 05:52:44.755823
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = AnsibleModule(argument_spec={})
    hpux_virtual_obj = HPUXVirtual(module)
    hpux_virtual_obj.populate()
    assert hpux_virtual_obj.facts == {
        'virtualization_type': 'guest',
        'virtualization_role': 'HPVM IVM',
        'virtualization_tech_guest': {'HPVM IVM'},
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-11 05:52:54.915433
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts import ModuleData

    fact_module = HPUXVirtual()
    fact_module.module_data = ModuleData()
    fact_module.module_data.params = {}

    guest_tech_hpvm = set()
    guest_tech_hpvm.add('HPVM')
    expected_guest_tech_hpvm = {'virtualization_type': 'host', 'virtualization_role': 'HPVM'}
    fact_module.module_data.rc = 0
    fact_module.module_data.stdout = "Running HPVM host (HPVM host)"
    virtual_facts = fact_module.get_virtual_facts()
    assert virtual_facts['virtualization_tech_guest'] == guest_

# Generated at 2022-06-11 05:53:01.226489
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    UNIT_TEST_FILE_NAME = os.path.basename(__file__)
    TEST_CLASS_NAME = 'HPUXVirtual()'
    TEST_CASE_NUMBER = 0
    HPUXVirtual()
    print('{filename}: Testing class {classname} with case number {casenumber}'.format(filename=UNIT_TEST_FILE_NAME,
                                                                                       classname=TEST_CLASS_NAME,
                                                                                       casenumber=TEST_CASE_NUMBER))

# Generated at 2022-06-11 05:53:02.519855
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    assert HPUXVirtual.get_virtual_facts() == {}

# Generated at 2022-06-11 05:53:12.516456
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    # Define module params and results
    module_args = dict()
    module_args['_ansible_check_mode'] = False
    module_args['_ansible_debug'] = False
    module_args['_ansible_diff'] = False
    module_args['_ansible_remote_tmp'] = None
    module_args['_ansible_selinux_special_fs'] = [u'fuse', u'nfs', u'vboxsf', u'ramfs', u'9p', u'vfat']
    module_args['_ansible_shell_executable'] = u'/bin/sh'
    module_args['_ansible_socket'] = None

# Generated at 2022-06-11 05:53:13.768096
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual({})
    assert h.platform == "HP-UX"

# Generated at 2022-06-11 05:53:15.280103
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-11 05:55:03.621233
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(None)
    assert HPUXVirtual.platform == 'HP-UX'



# Generated at 2022-06-11 05:55:05.665578
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = FakeAnsibleModule()
    hpux_devices_virtual = HPUXVirtual(module)
    assert hpux_devices_virtual.get_virtual_facts() is not None

# Generated at 2022-06-11 05:55:12.088196
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(dict(module=False), '/')
    assert hpux_virtual.platform == 'HP-UX'
    assert hpux_virtual.get_virtual_facts() == dict(virtualization_type='guest',
                                                    virtualization_role='HP nPar',
                                                    virtualization_tech_guest={'HPVM',
                                                                               'HPVM vPar',
                                                                               'HP nPar',
                                                                               'HP vPar',
                                                                               'HPVM IVM'},
                                                    virtualization_tech_host={})

# Generated at 2022-06-11 05:55:18.337702
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Unit test for get_virtual_facts method in HPUXVirtual class.
    """
    test_object = HPUXVirtual(file_module=None)

    expected_result = {'virtualization_tech_host': set(),
                       'virtualization_tech_guest': set(['HP nPar',
                                                         'HP vPar',
                                                         'HPVM IVM',
                                                         'HPVM vPar']),
                       'virtualization_type': 'guest',
                       'virtualization_role': 'HPVM vPar'}

    actual_result = test_object.get_virtual_facts()

    assert actual_result == expected_result

# Generated at 2022-06-11 05:55:22.068307
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.__class__.__name__ == 'HPUXVirtual'
    assert virtual_facts.virtual_subclass == 'hpux'
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-11 05:55:30.192357
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = MockModule()
    hpux_virtual = HPUXVirtual(module)
    hpux_virtual.get_virtual_facts()
    assert module.params['gather_subset'] == ['virtual']
    assert module.exit_json.called
    assert 'virtualization_type' in module.exit_json.mock_calls[0][1]['ansible_facts']['virtualization']
    assert 'virtualization_role' in module.exit_json.mock_calls[0][1]['ansible_facts']['virtualization']
    assert 'virtualization_role' in module.exit_json.mock_calls[0][1]['ansible_facts']['virtualization']

# Generated at 2022-06-11 05:55:31.652847
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    facts = HPUXVirtual({}, {}, {}).get_virtual_facts()
    assert 'virtualization_type' in facts

# Generated at 2022-06-11 05:55:33.091310
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual({}, {})
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-11 05:55:37.569699
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h = HPUXVirtual({})
    assert isinstance(h.get_virtual_facts(), dict)
    assert 'virtualization_type' in h.get_virtual_facts()
    assert 'virtualization_role' in h.get_virtual_facts()
    assert 'virtualization_tech_guest' in h.get_virtual_facts()
    assert 'virtualization_tech_host' in h.get_virtual_facts()

# Generated at 2022-06-11 05:55:41.514415
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = AnsibleModule({})
    v = HPUXVirtual(module)
    assert v.platform == 'HP-UX'
    assert v.get_virtual_facts() == {'virtualization_type': None, 'virtualization_role': None, 'virtualization_tech_host': set([]),'virtualization_tech_guest': set([])}