

# Generated at 2022-06-11 05:46:31.047215
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual({}, {})
    assert v.platform == 'HP-UX'
    assert v.module == {}
    assert v.virtual_facts == {}


# Generated at 2022-06-11 05:46:33.451317
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.virtualization_type == 'host'
    assert 'HPVM IVM' not in virtual_facts.virtualization_tech_host


# Generated at 2022-06-11 05:46:42.258802
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():

    # Test with /usr/sbin/vecheck
    if os.path.exists('/usr/sbin/vecheck'):
        virtual = HPUXVirtual(dict(module=dict()))
        assert virtual.platform == 'HP-UX'
        facts = virtual.collect()
        assert 'virtualization_type' in facts
        assert facts['virtualization_type'] == 'guest'
        assert 'virtualization_role' in facts
        assert facts['virtualization_role'] == 'HP vPar'
        assert 'virtualization_tech_guest' in facts
        assert 'virtualization_tech_host' in facts
        assert 'HP vPar' in facts['virtualization_tech_guest']
        assert 'HP VM' not in facts['virtualization_tech_guest']

# Generated at 2022-06-11 05:46:43.965972
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(dict(ansible_facts=dict()), dict())
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-11 05:46:52.221317
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class TestModule():
        def run_command(self, command):
            if command == "/usr/sbin/vecheck":
                rc = 0
                out = "testing"
                return (rc, out, "")
            elif command == "/opt/hpvm/bin/hpvminfo":
                rc = 0
                out = "testing"
                return (rc, out, "")
            elif command == "/usr/sbin/parstatus":
                rc = 0
                out = "testing"
                return (rc, out, "")
            else:
                return (1, '', '')
        def user_id(self):
            return 'root'

    facts = HPUXVirtual(TestModule())
    assert facts.get_virtual_facts()['virtualization_tech_guest'] == set()

# Generated at 2022-06-11 05:46:58.495939
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_obj = HPUXVirtual()
    setattr(test_obj.module, 'run_command', lambda x: (0, "test-output", ""))
    host_tech = set()
    guest_tech = set()
    facts = test_obj.get_virtual_facts()

    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP vPar'
    assert facts['virtualization_tech_guest'] == guest_tech.union(set(['HP vPar']))
    assert facts['virtualization_tech_host'] == host_tech


# Generated at 2022-06-11 05:47:00.927581
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual({}, {}, {})
    assert v.platform == 'HP-UX'
    assert v.module == {}
    assert v.commands == {}
    assert v.file == {}

# Generated at 2022-06-11 05:47:02.531399
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-11 05:47:04.348083
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == "HP-UX"



# Generated at 2022-06-11 05:47:08.282884
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts is not None
    assert virtual_facts.virtualization_type == ''
    assert virtual_facts.virtualization_role == ''
    assert virtual_facts.virtualization_tech_guest == set()
    assert virtual_facts.virtualization_tech_host == set()

# Generated at 2022-06-11 05:47:22.927816
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    m = basic.AnsibleModule(
        argument_spec=dict()
    )
    class MockModule:
        def __init__(self, module):
            self.module = module
        def run_command(self, cmd):
            return (0, '', '')
    h = HPUXVirtual(MockModule(m))
    result = h.get_virtual_facts()
    assert 'virtualization_type' not in result

# Generated at 2022-06-11 05:47:24.405650
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(dict())
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-11 05:47:28.754664
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_test = HPUXVirtual()
    assert virtual_test.platform == 'HP-UX'
    assert not virtual_test.is_linux()
    assert not virtual_test.is_freebsd()
    assert virtual_test.is_hpux()
    assert not virtual_test.is_solaris()
    assert not virtual_test.is_aix()
    assert not virtual_test.is_darwin()


# Generated at 2022-06-11 05:47:37.257028
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Virtualization facts for host
    facts = HPUXVirtual.get_virtual_facts(
        {'module': {'run_command': CommandMock.run_command}})
    assert facts['virtualization_type'] == 'host'
    assert facts['virtualization_role'] == 'HPVM'
    assert facts['virtualization_tech_host'] == {'HPVM'}
    assert facts['virtualization_tech_guest'] == set()

    # Virtualization facts for guest
    facts = HPUXVirtual.get_virtual_facts(
        {'module': {'run_command': CommandMock.run_command_guest}})
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP vPar'
    assert facts['virtualization_tech_host'] == set

# Generated at 2022-06-11 05:47:38.704770
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual({})
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-11 05:47:40.162896
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = HPUXVirtual(dict())
    assert module.platform == 'HP-UX'


# Generated at 2022-06-11 05:47:41.433802
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict())
    assert virtual.virtualization_type == ''

# Generated at 2022-06-11 05:47:42.712901
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    facts = HPUXVirtual()
    assert facts.platform == 'HP-UX'

# Generated at 2022-06-11 05:47:44.034072
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt = HPUXVirtual({})
    assert virt.platform == 'HP-UX'

# Generated at 2022-06-11 05:47:48.024495
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    The HPUXVirtual class defines virtualization_tech_guest and
    virtualization_tech_host methods
    """
    h = HPUXVirtual({})
    assert h.get_virtual_facts() == {'virtualization_tech_host': set(),
                                     'virtualization_tech_guest': set()}


# Generated at 2022-06-11 05:47:59.163269
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual({})
    assert hpux_virtual is not None

# Generated at 2022-06-11 05:48:02.070808
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    '''Unit test for constructor of class HPUXVirtual'''
    hpux_virtual = HPUXVirtual(None)
    assert hpux_virtual.platform == 'HP-UX'
    assert hpux_virtual._platform == 'HP-UX'

# Generated at 2022-06-11 05:48:08.418073
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    hpu = HPUXVirtual()
    hpu.module = MockAnsibleModule()
    hpu.module.run_command = MockRunCommand()

    hpu.get_virtual_facts()

    assert hpu.virtual_facts['virtualization_type'] == 'guest'
    assert hpu.virtual_facts['virtualization_role'] == 'HPVM'
    assert len(hpu.virtual_facts['virtualization_tech_host']) == 0
    assert hpu.virtual_facts['virtualization_tech_guest'] == set('HPVM')



# Generated at 2022-06-11 05:48:09.863900
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual()
    assert virtual.platform == 'HP-UX'


# Generated at 2022-06-11 05:48:18.361762
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual().collect()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_technologies' in virtual_facts

    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts

    assert 'HP vPar' in virtual_facts['virtualization_tech_guest']
    assert 'HPVM vPar' in virtual_facts['virtualization_tech_guest']
    assert 'HPVM IVM' in virtual_facts['virtualization_tech_guest']
    assert 'HPVM' in virtual_facts['virtualization_tech_guest']
    assert 'HP nPar' in virtual_facts['virtualization_tech_guest']


# Generated at 2022-06-11 05:48:20.259703
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert isinstance(hv, HPUXVirtual)
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-11 05:48:26.672779
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    virtual_facts_returned = HPUXVirtual().get_virtual_facts()
    # Assert a Dictionary is returned
    assert isinstance(virtual_facts_returned, dict)
    # Assert 'virtualization_type' key is present in the return results
    assert 'virtualization_type' in virtual_facts_returned
    # Assert 'virtualization_type' key is present in the return results
    assert 'virtualization_type' in virtual_facts_returned
    # Assert 'virtualization_type' key is present in the return results
    assert 'virtualization_type' in virtual_facts_returned

# Generated at 2022-06-11 05:48:28.270260
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts.platform == 'HP-UX'



# Generated at 2022-06-11 05:48:36.105078
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Importing module
    from ansible.module_utils.facts.virtual import HPUXVirtual
    # Creating HPUXVirtual object
    hw = HPUXVirtual()
    # Calling the method get_virtual_facts
    virtual_facts = hw.get_virtual_facts()
    # Asserting the hw virtual facts
    assert virtual_facts['virtualization_tech_guest'] is not None
    assert virtual_facts['virtualization_tech_host'] is not None
    assert virtual_facts['virtualization_role'] is not None
    assert virtual_facts['virtualization_type'] is not None

# Generated at 2022-06-11 05:48:36.941803
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    pass


# Generated at 2022-06-11 05:48:52.979406
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h_virtual = HPUXVirtual(dict())
    assert hasattr(h_virtual, 'get_virtual_facts')
    assert hasattr(h_virtual, 'platform')
    assert h_virtual.platform == 'HP-UX'
    assert hasattr(h_virtual, 'get_virtual_facts')
    assert callable(getattr(h_virtual, 'get_virtual_facts'))


# Generated at 2022-06-11 05:48:55.303623
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = AnsibleModule(argument_spec={})
    virt_module = HPUXVirtual(module)
    assert virt_module.platform == 'HP-UX'

# Generated at 2022-06-11 05:49:01.423324
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Execute method HPUXVirtual.get_virtual_facts
    virtual_facts = HPUXVirtualCollector().get_virtual_facts()
    # Test assertions
    assert virtual_facts['virtualization_type'] in ['guest', 'host', None]
    assert virtual_facts['virtualization_role'] in ['HP vPar', 'HPVM vPar', 'HPVM IVM', 'HP nPar', 'HPVM', None]
    assert virtual_facts['virtualization_tech_host'] == ''
    assert virtual_facts['virtualization_tech_guest'] == ''

# Generated at 2022-06-11 05:49:08.686844
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Test method get_virtual_facts of HPUXVirtual class
    """
    module_args = {}
    module = MockModule(**module_args)
    hv = HPUXVirtual(module)

    # set vpar
    hv.module.run_command = Mock(return_value=(0, '', ''))
    hv.module.stat = Mock(side_effect=[os.stat_result((33188, 5376, 32, 1, 99, 0, 0, 1609059890, 1609059885, 1608869473)), os.stat_result((33188, 5376, 32, 1, 99, 0, 0, 1609059890, 1609059885, 1608869473))])
    virtual_facts = hv.get_virtual_facts()

# Generated at 2022-06-11 05:49:15.737655
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class TestModule(object):
        def __init__(self, run_command_results):
            self.run_command_results = run_command_results
            self.run_command_calls = []

        def run_command(self, cmd, check_rc=True):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    test_module = TestModule([(0, '', ''), (0, '', '')])

    virtual_facts = HPUXVirtual(module=test_module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'host'
    assert virtual_facts['virtualization_role'] == 'HPVM'
    assert virtual_facts['virtualization_tech_guest'] == set('HPVM')
   

# Generated at 2022-06-11 05:49:20.046608
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())

    assert virtual_facts.platform == 'HP-UX'
    assert virtual_facts.virtualization_type is None
    assert virtual_facts.virtualization_role is None
    assert virtual_facts.virtualization_tech_guest is None
    assert virtual_facts.virtualization_tech_host is None


# Generated at 2022-06-11 05:49:21.783137
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual({})
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-11 05:49:23.849118
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False)
    hv = HPUXVirtual(module)
    assert hv is not None

# Generated at 2022-06-11 05:49:28.599566
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = type('Module', (object,), {'run_command': lambda x: (0, '', '')})()
    virtual_facts = HPUXVirtual(module).get_virtual_facts()
    assert (virtual_facts['virtualization_tech_host'] == set())
    assert (virtual_facts['virtualization_tech_guest'] == set())
    assert (virtual_facts['virtualization_type'] == 'guest')
    assert (virtual_facts['virtualization_role'] == 'HP vPar')

# Generated at 2022-06-11 05:49:30.426505
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    HPUXVirtual - Constructor
    """
    virtual = HPUXVirtual(dict())
    assert virtual


# Generated at 2022-06-11 05:50:06.280412
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True)

    class Mock(object):
        """
        Mock class to mock the module.run_command
        """
        def __init__(self):
            pass

        @staticmethod
        def run_command(*_, **__): # pylint: disable=no-method-argument
            return 0, '', ''

    class MockOS(object):
        """
        Mock class to mock os-related filesystem functions like os.path.exists
        """
        def __init__(self):
            pass

        @staticmethod
        def path(*_, **__): # pylint: disable=no-method-argument
            return True


# Generated at 2022-06-11 05:50:07.112083
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual()



# Generated at 2022-06-11 05:50:08.526211
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual(dict())
    assert h.platform == 'HP-UX'


# Generated at 2022-06-11 05:50:12.216518
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict()).populate()
    assert 'virtualization_tech_guest' in virtual_facts.keys()
    assert 'virtualization_tech_host' in virtual_facts.keys()
    assert 'virtualization_type' in virtual_facts.keys()
    assert 'virtualization_role' in virtual_facts.keys()

# Generated at 2022-06-11 05:50:20.613391
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import os
    import sys
    import unittest

    class FakeModule:
        def __init__(self):
            self.run_command_return_value = (0, '', '')
            self.run_command_calls = []

        def run_command(self, args):
            self.run_command_calls.append(args)
            return self.run_command_return_value

    class FakeHPVMVirtual(HPUXVirtual):
        def __init__(self):
            self.module = FakeModule()

    class TestHPUXVirtual(unittest.TestCase):
        def setUp(self):
            self.hpvm = FakeHPVMVirtual()


# Generated at 2022-06-11 05:50:28.448811
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class MockModule:
        def __init__(self, run_command_results):
            self.run_command_results = run_command_results
            self.run_command_calls = []

        def run_command(self, args):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

    class MockOs:
        def __init__(self, path_exists):
            self.path_exists = path_exists

        def exists(self, path):
            return self.path_exists.get(path)

    test_cases = dict()


# Generated at 2022-06-11 05:50:30.518364
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    '''
    Constructor for class HPUXVirtual
    '''
    module = None
    fact = HPUXVirtual(module)
    assert fact.platform == 'HP-UX'

# Generated at 2022-06-11 05:50:32.127098
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HP_UV = HPUXVirtual(dict(), dict())
    assert HP_UV.platform == 'HP-UX'


# Generated at 2022-06-11 05:50:35.805592
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(dict(module=None), None)
    assert hpux_virtual.platform == 'HP-UX'
    assert hpux_virtual.get_virtual_facts() == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}


# Generated at 2022-06-11 05:50:43.784498
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    class MockModule:
        def run_command(self, cmd):
            if cmd == "/usr/sbin/vecheck":
                rc = 0
                out = 'HP vPar'
                err = ''
            elif cmd == "/opt/hpvm/bin/hpvminfo":
                rc = 0
                out = ''
                err = ''
            elif cmd == "/usr/sbin/parstatus":
                rc = 0
                out = ''
                err = ''
            return rc, out, err

    class MockFs:
        def exists(self, path):
            if path == "/usr/sbin/vecheck":
                return True
            elif path == "/opt/hpvm/bin/hpvminfo":
                return True
            elif path == "/usr/sbin/parstatus":
                return True
            return

# Generated at 2022-06-11 05:51:07.558596
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(None)
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-11 05:51:10.478225
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    Creates the object and checks whether it is an instance of class HPUXVirtual
    """
    obj = HPUXVirtual(None)

    assert isinstance(obj, HPUXVirtual)

# Generated at 2022-06-11 05:51:12.586403
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    '''Unit test for class Virtual'''
    virtual = HPUXVirtual()
    assert virtual.platform == 'HP-UX'

# Generated at 2022-06-11 05:51:14.738542
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # TODO: need to implement this test
    module = None
    hpux_virtual_module = HPUXVirtual(module)
    hpux_virtual_module.get_virtual_facts()

# Generated at 2022-06-11 05:51:22.499190
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_module = AnsibleModule(argument_spec=dict())
    test_module.mock_command('/usr/sbin/vecheck', rc=0, stdout="", stderr="")
    test_module.mock_command('/opt/hpvm/bin/hpvminfo', rc=0, stdout="Running HPVM vPar", stderr="")

    obj = HPUXVirtual(module=test_module)
    result = obj.get_virtual_facts()

    assert result['virtualization_type'] == 'guest'
    assert set(result['virtualization_tech_host']) == set()
    assert result['virtualization_tech_guest'] == set(['HPVM vPar'])
    assert result['virtualization_role'] == 'HPVM vPar'


# Generated at 2022-06-11 05:51:30.958117
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # build a mock class to pass to the unit test
    class TestModule(object):
        # Mock AnsibleModule.run_command method
        def run_command(self, module_args):
            # vecheck only exists on guest
            if module_args == "/usr/sbin/vecheck":
                return (0, "", "")
            # hpvminfo only exists on guest or host
            elif module_args == "/opt/hpvm/bin/hpvminfo" and \
                 os.path.exists("/opt/hpvm/bin/hpvminfo"):
                # Running HPVM guest
                if os.path.exists("/var/stm/config/.config_hpvm"):
                    return (0, "Running HPVM guest", "")
                # Running HPVM host

# Generated at 2022-06-11 05:51:31.529523
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual()

# Generated at 2022-06-11 05:51:33.123537
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    pass
    #assert_equals(HPUXVirtual.get_virtual_facts(module), virtual_facts)

# Generated at 2022-06-11 05:51:40.627883
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.virtual.hpux_virtual import HPUXVirtual

    supported_facts_collection = FactCollector.list_facts()
    for fact_name in supported_facts_collection['ansible_local']:
        if 'virtual' in fact_name:
            # Create an instance of HPUXVirtual
            obj = HPUXVirtual()
            # Call get_virtual_facts of HPUXVirtual
            virtual_facts = obj.get_virtual_facts()
            if virtual_facts['virtualization_type'] == 'guest':
                assert virtual_facts['virtualization_role'] in virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-11 05:51:44.286237
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import ModuleDataCollector

    data_collector = ModuleDataCollector(None, None, HPUXVirtual(_module=None))
    module_data = data_collector.get_module_data(None)
    assert 'virtual' in module_data

# Generated at 2022-06-11 05:52:16.632129
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """Method get_virtual_facts of class HPUXVirtual always returns
    {'virtualization_type':'guest', 'virtualization_role':'HP nPar',
    'virtualization_tech_guest': {'HP nPar'}, 'virtualization_tech_host': set()}
    """
    class Module(object):
        def __init__(self):
            self.run_command = mock_run_command

    class HPUXVirtual(HPUXVirtual):
        def __init__(self):
            self.module = Module()

    def mock_run_command(command):
        assert command == "/usr/sbin/vecheck"
        return 0, "", ""

    facts = HPUXVirtual().get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'

# Generated at 2022-06-11 05:52:24.791511
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = MockModule()
    # Load facts with hp-ux host with hpvm
    module.run_command.side_effect = [(0, "Running    HPVM guest.\n", ""), (0, "Virtualization Technology mode is enabled\n", "")]
    module.exists.side_effect = [True]
    module.facts = {}
    #Call get_virtual_facts of class HPUXVirtual
    HPUXVirtual().get_virtual_facts(module)
    assert module.facts['virtualization_type'] == 'guest'
    assert module.facts['virtualization_role'] == 'HPVM IVM'
    assert module.facts['virtualization_tech_guest'] == set(['HPVM IVM'])
    assert module.facts['virtualization_tech_host'] == set()
    # Load facts with hp-

# Generated at 2022-06-11 05:52:28.934172
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import VirtualInfo

    test_module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False
    )

    info = VirtualInfo(test_module)
    instance = HPUXVirtual(info)

    guest_tech = set()
    host_tech = set()

    with patch('os.path.exists', return_value = False):
        virtual_facts = instance.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == guest_tech
    assert virtual_facts['virtualization_tech_host'] == host_tech

    guest_tech.add('HP vPar')

# Generated at 2022-06-11 05:52:29.537877
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual()

# Generated at 2022-06-11 05:52:31.321166
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    c = HPUXVirtual({})
    assert c.platform == 'HP-UX'
    assert c.get_virtual_facts() == {}

# Generated at 2022-06-11 05:52:33.545867
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hypervisor = HPUXVirtual("module")
    assert hypervisor.platform == 'HP-UX'
    assert hypervisor._platform == 'HP-UX'

# Generated at 2022-06-11 05:52:42.402888
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpar import HPUXVirtual
    test_module = HPUXVirtual()

    output = test_module.get_virtual_facts()
    assert output['virtualization_tech_guest'] == set(['HP vPar', 'HPVM vPar', 'HPVM IVM', 'HPVM', 'HP nPar'])

    output = test_module.get_virtual_facts(
        inputdata={
            '/usr/sbin/vecheck': '',
            '/opt/hpvm/bin/hpvminfo': 'Running HPVM vPar',
            '/usr/sbin/parstatus': ''
        })
    assert output['virtualization_type'] == 'guest'
    assert output['virtualization_role'] == 'HPVM vPar'

# Generated at 2022-06-11 05:52:43.619788
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    #assert False, "Failed to find the HP-UX facts module"
    assert True

# Generated at 2022-06-11 05:52:53.432041
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import sys
    import os
    import tempfile
    import unittest
    import StringIO

    from ansible.module_utils import basic
    basic._ANSIBLE_ARGS = None

    # Create a fake ansible module
    test_dir = os.path.dirname(__file__)
    module_path = os.path.join(test_dir, '../../../library')
    sys.path.append(module_path)
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual

    # Create a temp for the fake module
    tmpdir = tempfile.mkdtemp()

    # Fake files and directories for the calls to os.path.exists
    open(os.path.join(tmpdir, "vecheck"), 'a').close()

# Generated at 2022-06-11 05:53:00.864388
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import VirtualInfo

    virtual_info = VirtualInfo()
    virtual_info.gather_subset = set()
    virtual_info.gather_subset.add('!all')
    virtual_info.gather_subset.add('virtual')
    facts = virtual_info.get_facts()
    if facts['virtualization_type'] == 'guest':
        assert facts['virtualization_tech_guest']
    elif facts['virtualization_type'] == 'host':
        assert facts['virtualization_tech_host']

# Generated at 2022-06-11 05:53:20.590601
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModuleMock(facts={})
    hpux = HPUXVirtual(module)

    assert hpux.get_virtual_facts() == {}



# Generated at 2022-06-11 05:53:22.097812
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual()
    assert v.platform == 'HP-UX'

# Generated at 2022-06-11 05:53:31.321981
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Init vars
    module = FakeAnsibleModule()
    module.params = {}
    # Init object
    hpuxVirtual = HPUXVirtual(module)

    # VeCheck is present and reports virtualization
    open('/usr/sbin/vecheck', 'a').close()
    hpuxVirtual.module.run_command = MagicMock(return_value=(0, '', ''))
    assert hpuxVirtual.get_virtual_facts() == {'virtualization_role': 'HP vPar', 'virtualization_tech_guest': set(['HP vPar']), 'virtualization_type': 'guest', 'virtualization_tech_host': set()}
    os.remove('/usr/sbin/vecheck')

    # VeCheck is present and reports no virtualization

# Generated at 2022-06-11 05:53:39.941481
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    This test exercises the method get_virtual_facts of class HPUXVirtual with
    different configurations, as if running under various virtualization
    technologies.

    This is not a unit test in the sense that it does not assert the result
    of the method call. It exercises the code for coverage.
    """
    # initialization
    from ansible.module_utils.facts import virtual
    from ansible.module_utils.facts.virtual.freebsd_sysctl import Sysctl
    from ansible.module_utils.facts.virtual.hpux_pstat import Pstat
    from ansible.module_utils.facts.virtual.hpux_bdf import Bdf
    from ansible.module_utils.facts.virtual.hpux_ioscan import Ioscan

# Generated at 2022-06-11 05:53:41.614178
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual({})
    assert v.platform == 'HP-UX'


# Generated at 2022-06-11 05:53:48.375569
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Test function for get_virtual_facts of class HPUXVirtual
    """
    # pylint: disable=no-self-use
    hpuxvirt = HPUXVirtual()

    hpuxvirt.module.run_command = run_command_mock

    hpuxvirt.get_virtual_facts()

    vfacts = hpuxvirt.get_facts()

    assert vfacts['virtualization_type'] == 'guest'
    assert vfacts['virtualization_role'] == 'HP vPar'
    assert vfacts['virtualization_tech_guest'] == set(['HP vPar'])
    assert vfacts['virtualization_tech_host'] == set()

    hpuxvirt.get_virtual_facts()
    vfacts = hpuxvirt.get_facts()


# Generated at 2022-06-11 05:53:52.196549
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    _test_HPUXVirtual = HPUXVirtual()
    assert _test_HPUXVirtual.platform == "HP-UX"
    assert _test_HPUXVirtual.get_virtual_facts()['virtualization_type'] == "guest"
    assert _test_HPUXVirtual.get_virtual_facts()['virtualization_role'] == "HP nPar"

# Generated at 2022-06-11 05:53:53.528316
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = None
    hpux_virtual = HPUXVirtual(module)
    assert hpux_virtual is not None

# Generated at 2022-06-11 05:54:00.300781
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class HPUXVirtual
    """
    from ansible.module_utils.facts.virtual import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual, HPUXVirtualCollector
    from ansible.module_utils.facts.ssh.file import SSHFile
    from ansible.module_utils.facts.ssh.hpux import SSHHPUXModule
    from ansible.module_utils.facts.ssh.hpux.file import SSHHPUXFile

    # Create a new SSHHPUXModule object instance
    module = SSHHPUXModule(argument_spec={})

    # Create a new SSHHPUXFile object instance
    ssh = SSHHPUXFile(module=module)

    # Create a new VirtualCollector object instance

# Generated at 2022-06-11 05:54:01.905683
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """Unit test for constructor of class HPUXVirtual.
    """
    h = HPUXVirtual(None)
    assert h.platform == 'HP-UX'

# Generated at 2022-06-11 05:55:02.269056
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpu = HPUXVirtual('module')
    assert hpu.platform == 'HP-UX'



# Generated at 2022-06-11 05:55:09.280062
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    from ansible.module_utils.facts import ModuleFactCollector

    ModuleFactCollector.add_collector(HPUXVirtualCollector)
    virtual_facts = dict(ansible_facts=dict(virtual=HPUXVirtual()))
    assert 'HPVM IVM' in virtual_facts['ansible_facts']['virtual'].virtualization_tech_guest
    assert virtual_facts['ansible_facts']['virtual'].platform == 'HP-UX'
    assert virtual_facts['ansible_facts']['virtual'].virtualization_type == 'guest'
    assert virtual_facts['ansible_facts']['virtual'].virtualization_role == 'HPVM IVM'

# Generated at 2022-06-11 05:55:17.332145
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual()
    assert virtual_obj.platform == 'HP-UX'

# Generated at 2022-06-11 05:55:19.766701
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual_fact = HPUXVirtual({})
    assert hpux_virtual_fact
    assert isinstance(hpux_virtual_fact.module, object)



# Generated at 2022-06-11 05:55:28.044000
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.utils.boolean import boolean
    from ansible.compat.tests import unittest
    from ansible.module_utils.facts.virtual.hpar import HPUXVirtual

    # Use separate method to get base class for testing so we can use patch
    def get_base_class_for_testing(self):
        return HPUXVirtual

    class MockModule(object):
        # Mocking only run_command
        def run_command(self, command):
            if command == '/usr/sbin/vecheck':
                rc = 0
                out = 'HP vPar Virtual Environment'
                err = ''
            elif command == '/opt/hpvm/bin/hpvminfo':
                rc = 0
                out = 'Running HPVM guest'
                err = ''

# Generated at 2022-06-11 05:55:31.757470
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    collection = HPUXVirtualCollector(None)
    collection.populate()
    if not collection.facts:
        raise AssertionError("No facts returned")
    for fact in collection.facts['virtualization_tech']:
        assert fact in ['HPVM', 'HP vPar', 'HP nPar', 'HPVM IVM', 'HPVM vPar']

# Generated at 2022-06-11 05:55:33.464988
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpuxv = HPUXVirtual()

    assert hpuxv.platform is not None
    assert hpuxv.platform == 'HP-UX'

# Generated at 2022-06-11 05:55:36.990075
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hw = HPUXVirtual(dict(module=None))
    assert hw.get_virtual_facts() == dict(
        virtualization_type=None,
        virtualization_role=None,
        virtualization_tech_host=set(),
        virtualization_tech_guest=set(),
    )

# Generated at 2022-06-11 05:55:39.757764
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual(dict())

    assert h.platform == 'HP-UX'
    assert h.get_virtual_facts() == dict(virtualization_tech_guest=set(),
                                         virtualization_tech_host=set())

# Generated at 2022-06-11 05:55:48.281996
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import virtual
    module = virtual.AnsibleModuleMock()
    module.run_command = virtual.run_command_mock
    module.run_command.side_effect = [
        (0, """
        VE-Checker - Version A.06.00.04
        Check to see if this system is a virtual partition.
        """ , ""),
        (0, """
        HPVM vPar Guest.
        """ , "")]

    hpux_virtual = HPUXVirtual(module)
    hpux_virtual.get_virtual_facts()