

# Generated at 2022-06-20 20:27:22.875735
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual = HPUXVirtualCollector()
    assert virtual is not None

# Generated at 2022-06-20 20:27:26.266162
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    import platform
    v = HPUXVirtual(dict(module=dict(run_command=None)), None)
    assert v.platform == 'HP-UX'
    assert v.platform_version == platform.release()

# Generated at 2022-06-20 20:27:28.022725
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    h = HPUXVirtualCollector()
    assert h.platform == "HP-UX"
    assert h.fact_class == HPUXVirtual

# Generated at 2022-06-20 20:27:38.729026
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector

    class FakeModule:
        def run_command(self, command):
            return (0, '', '')

    class FakeCollector(HPUXVirtualCollector):
        def __init__(self, module):
            self.module = module

    import sys
    hpux_virtual_obj = HPUXVirtual(FakeModule())
    hpux_virtual_obj.platform = sys.platform
    hpux_virtual_obj.distribution = None
    hpux_virtual_obj.distribution_version = None
    hpux_virtual_obj.module = FakeModule()
    hpux_virtual_obj.virtual = FakeCollector(FakeModule())

   

# Generated at 2022-06-20 20:27:40.873328
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    h = HPUXVirtualCollector()
    assert h.platform == 'HP-UX'
    assert isinstance(h.fact_class, HPUXVirtual)

# Generated at 2022-06-20 20:27:43.900814
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class ModuleStub:
        def run_command(self, cmd):
            return 0, '', ''
    module_stub = ModuleStub()
    hv = HPUXVirtual(module_stub)
    virtual_facts = hv.get_virtual_facts()
    assert virtual_facts is not None

# Generated at 2022-06-20 20:27:49.299154
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """
    Unit test for constructor of class HPUXVirtualCollector
    """
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )
    virt_hpx = HPUXVirtualCollector(module)
    assert virt_hpx.platform == 'HP-UX'
    assert virt_hpx.__class__.__bases__[0] is VirtualCollector

# Generated at 2022-06-20 20:27:53.243237
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpux_virtual_collector = HPUXVirtualCollector()
    assert hpux_virtual_collector._platform == 'HP-UX'

# Generated at 2022-06-20 20:27:54.640408
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    facts = HPUXVirtualCollector().collect()
    assert facts['virtualization_role'] != {}

# Generated at 2022-06-20 20:27:56.020930
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpsu = HPUXVirtual()
    assert hpsu.platform == 'HP-UX'

# Generated at 2022-06-20 20:28:05.173400
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    assert obj._platform == 'HP-UX'
    assert obj._fact_class == HPUXVirtual


# Generated at 2022-06-20 20:28:06.480684
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    v = HPUXVirtual('module')
    assert v.get_virtual_facts() == {}

# Generated at 2022-06-20 20:28:14.507374
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    facts = HPUXVirtual(module).get_virtual_facts()
    assert facts.keys() == set(
        ['virtualization_type', 'virtualization_role', 'virtualization_tech_host', 'virtualization_tech_guest'])
    assert set(facts['virtualization_tech_host']) == set()
    assert set(facts['virtualization_tech_guest']) <= set(['HPVM IVM', 'HPVM', 'HPVM vPar', 'HP vPar', 'HP nPar'])
    if facts['virtualization_type'] == 'host':
        assert facts['virtualization_role'] == 'HPVM'
        assert set(facts['virtualization_tech_guest']) == set(['HPVM IVM'])

# Generated at 2022-06-20 20:28:16.133345
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.platform == 'HP-UX'
    assert hv.module == None


# Generated at 2022-06-20 20:28:21.953497
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Test get_virtual_facts of HPUXVirtual.
    """
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    # Create the module object
    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    # Create an instance of the method to test
    hpux_virtual = HPUXVirtual(module)
    hpux_virtual.module.run_command = lambda args, check_rc=True: (0, '', '')

    # Run the method to test
    facts = hpux_virtual.get_virtual_facts()
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_tech_guest'] == set(['HP vPar'])

# Generated at 2022-06-20 20:28:23.940364
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual(dict()).platform == "HP-UX"

# Generated at 2022-06-20 20:28:26.240224
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-20 20:28:30.397439
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_module = AnsibleModule(argument_spec={})
    virtual_test_obj = HPUXVirtual(module=test_module)
    virtual_facts = virtual_test_obj.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts


# Generated at 2022-06-20 20:28:33.825132
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()

    # Check the default values of the class
    assert hv.platform == 'HP-UX'

    # Check the defintion of the methods
    assert hv.get_virtual_facts() == {}



# Generated at 2022-06-20 20:28:41.057408
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    from ansible.module_utils.facts import collect_facts
    from ansible.module_utils.facts.collector.virtual.hpux import HPUXVirtualCollector

    testobj = HPUXVirtualCollector()

    assert testobj is not None, 'Failed to create HPUXVirtualCollector'
    assert testobj._platform == 'HP-UX', 'Failed to set HPUXVirtualCollector._platform'
    assert isinstance(testobj._fact_class, HPUXVirtual), 'Failed to set HPUXVirtualCollector._fact_class'
    assert testobj._fact_class.platform == 'HP-UX', 'Failed to set HPUXVirtualCollector._fact_class.platform'


# Generated at 2022-06-20 20:28:54.482952
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    h = HPUXVirtualCollector()
    assert h.platform == 'HP-UX'
    assert h.fact_class.platform == 'HP-UX'
    assert h.fact_class().get_virtual_facts() == {'virtualization_tech_guest': set([]), 'virtualization_tech_host': set([]), 'virtualization_type': None, 'virtualization_role': None}



# Generated at 2022-06-20 20:28:56.190966
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-20 20:28:58.671515
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert virtual_collector._platform == 'HP-UX'


# Generated at 2022-06-20 20:29:02.570121
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv.__class__ is HPUXVirtualCollector
    assert hv._platform is 'HP-UX'
    assert hv._fact_class is HPUXVirtual


# Generated at 2022-06-20 20:29:06.881283
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual_obj = HPUXVirtual({})
    assert hpux_virtual_obj._platform == 'HP-UX'
    assert hpux_virtual_obj.get_virtual_facts() == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}


# Generated at 2022-06-20 20:29:08.673939
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    my_obj = HPUXVirtualCollector()
    assert my_obj.platform == "HP-UX"
    assert my_obj._fact_class.platform == "HP-UX"

# Generated at 2022-06-20 20:29:11.302669
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    c = HPUXVirtualCollector()
    assert c._fact_class == HPUXVirtual

# Generated at 2022-06-20 20:29:12.140564
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-20 20:29:19.816096
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import tempfile
    import shutil

    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda x: x
    tmpdir = tempfile.mkdtemp()

    # Test case 1: /usr/sbin/vecheck doesn't exist, /opt/hpvm/bin/hpvminfo doesn't exist and
    # /usr/sbin/parstatus doesn't exist
    hv = HPUXVirtual(module)
    res_facts = hv.get_virtual_facts()
    assert res_facts['virtualization_type'] == 'physical'
    assert res_facts['virtualization_role'] == 'guest'
    assert res_facts['virtualization_tech_guest'] == set()
    assert res_facts['virtualization_tech_host'] == set()

    # Test case 2: /usr

# Generated at 2022-06-20 20:29:21.641204
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-20 20:29:34.200555
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_hpux = HPUXVirtual()
    assert virtual_hpux.platform == 'HP-UX'

# Generated at 2022-06-20 20:29:35.207014
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual()
    assert v.platform == 'HP-UX'

# Generated at 2022-06-20 20:29:35.848818
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual(dict())


# Generated at 2022-06-20 20:29:37.041318
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    test = HPUXVirtual()
    assert test.platform == 'HP-UX'

# Generated at 2022-06-20 20:29:41.572295
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """This is a unit test for constructor of class HPUXVirtualCollector"""
    hphc = HPUXVirtualCollector()
    assert isinstance(hphc, VirtualCollector)
    assert isinstance(hphc._fact_class, HPUXVirtual)

# Generated at 2022-06-20 20:29:52.475609
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    module = basic.AnsibleModule(
        argument_spec = dict()
    )

    # create mock to get_file_content
    mock_file = collector.FileContentCollector()
    mock_file.files['/etc/issue'] = """
        HP-UX
    """
    mock_file.files['/etc/fstab'] = """
        #
        #
        /dev/vg00/lvol2       /tmp                ufs     defaults
    """

# Generated at 2022-06-20 20:29:53.926361
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vc = HPUXVirtualCollector()
    assert vc._fact_class is not None
    assert vc._platform is not None

# Generated at 2022-06-20 20:30:05.235410
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.utils.path import unfrackpath
    from ansible.module_utils import basic

    class TestModule(object):
        def __init__(self, change_os_module):
            self.change_os_module = change_os_module

        def run_command(self, command):
            if self.change_os_module and command == '/usr/sbin/vecheck':
                return (0, '', '')
            elif command == '/usr/sbin/parstatus':
                return (0, '', '')
            else:
                return (1, '', '')

    import tempfile
    import shutil
    import os

    fd, td = tempfile.mkdtemp()
    curr_dir = os.getcwd()
    os.chdir(td)

# Generated at 2022-06-20 20:30:11.928877
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    mock_module = MockModule()
    mock_module.run_command.side_effect = [
        (0, '', ''),
        (0, '      Running HPVM host', ''),
        (0, '', ''),
        (0, '', '')
    ]
    virtual_facts = HPUXVirtual(mock_module).get_virtual_facts()
    assert virtual_facts['virtualization_role'] == 'HPVM'
    assert 'HP vPar' in virtual_facts['virtualization_tech_guest']
    assert 'HP nPar' in virtual_facts['virtualization_tech_guest']


# Generated at 2022-06-20 20:30:15.765301
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    facts = {}
    collector = HPUXVirtualCollector(facts)
    assert isinstance(collector._fact_class, HPUXVirtual)
    assert collector._platform == 'HP-UX'
    assert collector._fact_class.platform == "HP-UX"


# Generated at 2022-06-20 20:30:34.667055
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual =  HPUXVirtualCollector()
    assert virtual.platform == 'HP-UX'
    assert virtual.fact_class == HPUXVirtual


# Generated at 2022-06-20 20:30:35.720742
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector.__name__ == 'HPUXVirtualCollector'

# Generated at 2022-06-20 20:30:39.532158
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    '''Unit test for method  get_virtual_facts of class HPUXVirtual'''

    module = AnsibleModule(
        argument_spec = dict()
    )
    virtual_obj = HPUXVirtual(module)
    module.exit_json(changed=False, ansible_facts=virtual_obj.get_facts())


# Generated at 2022-06-20 20:30:42.092583
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    obj = HPUXVirtualCollector()
    assert obj


# Generated at 2022-06-20 20:30:44.550795
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    f = HPUXVirtual()
    assert f._platform == 'HP-UX'
    assert HPUXVirtual.get_virtual_facts is not Virtual.get_virtual_facts
    assert issubclass(HPUXVirtual, Virtual)


# Generated at 2022-06-20 20:30:54.696838
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux_virtual import HPUXVirtual
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.virtual.base import Virtual

    class MockModule:
        def __init__(self):
            pass

        def run_command(self, command):
            if command == "/usr/sbin/vecheck":
                return (0, to_bytes("HP 9000, 9000/785 running HP-UX 11.31\n"), to_bytes(""))
            elif command == "/opt/hpvm/bin/hpvminfo":
                return (0, to_bytes("Running on an HPVM vPar"), to_bytes(""))

# Generated at 2022-06-20 20:30:56.759945
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpvx = HPUXVirtual('/dev/null')
    assert hpvx
    assert hpvx.module is None
    assert hpvx.platform == 'HP-UX'

# Generated at 2022-06-20 20:30:58.639370
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import ansible_facts
    facts = ansible_facts(dict(module_name='test'))
    hpuxvirtual = HPUXVirtual(facts)
    assert hpuxvirtual.get_virtual_facts() == {}

# Generated at 2022-06-20 20:31:01.494030
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    from ansible.module_utils.facts import facts
    hp_virtual = HPUXVirtual(facts.get_module())
    assert hp_virtual.platform == 'HP-UX'

# Generated at 2022-06-20 20:31:12.514326
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.collector import ModuleCollector
    import sys

    if sys.version_info.major == 2:
        from ansible.module_utils.facts.virtual.hpux import HPUXModuleMock as module

    if sys.version_info.major == 3:
        from ansible.module_utils.facts.virtual.hpux import HPUXModuleMockPy3 as module

    if sys.version_info.major == 2:
        import_module_kv = 'ansible.module_utils.facts.virtual.hpux'
        import_module_kv = import_module_kv + '.HP-UXVirtualCollector'

# Generated at 2022-06-20 20:31:35.441177
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    testing return values of method get_virtual_facts
    """
    # This is the test module
    module = AnsibleModule(argument_spec={})

    # Define the test class
    class TestHPUXVirtual(HPUXVirtual):
        pass

    # Instanciate the test class and run get_virtual_facts
    hpuxvirtual = TestHPUXVirtual(module)
    facts = hpuxvirtual.get_virtual_facts()
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_tech_guest'] in \
        (set(['HP vPar']), set(['HP nPar']), set(['HPVM vPar']),
         set(['HPVM IVM']), set(['HPVM']), set())

# Generated at 2022-06-20 20:31:38.578973
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual({})
    assert v.platform == 'HP-UX'
    assert v.module is None
    assert v.all_facts == dict()


# Generated at 2022-06-20 20:31:41.302114
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpcollector = HPUXVirtualCollector
    assert hpcollector._platform == 'HP-UX'
    assert hpcollector._fact_class == HPUXVirtual

# Generated at 2022-06-20 20:31:43.720615
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv.platform == 'HP-UX'
    assert hv._fact_class == HPUXVirtual


# Generated at 2022-06-20 20:31:45.525623
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    '''
    Unit test for constructor of class HPUXVirtual
    '''
    hv = HPUXVirtual({})
    assert hv.platform == 'HP-UX'



# Generated at 2022-06-20 20:31:48.948719
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector._platform == 'HP-UX'
    assert HPUXVirtualCollector._fact_class == HPUXVirtual


# Generated at 2022-06-20 20:31:55.849324
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.utils.fake_module import FakeModule
    from ansible.utils.fake_module import FakeCommand

    virtual_facts = {}

    module = FakeModule(
        dict(
            command_warnings=dict(
                stderr='WARNING: Ignoring unknown parameter: bad_param'
            )
        )
    )

    if os.path.exists('/usr/sbin/vecheck'):
        vecheck_out = """
System Information
------------------
vPar Support: YES
Mode: Shared
"""
        module.add_cmd(FakeCommand('/usr/sbin/vecheck', (0, vecheck_out, '')))
        virtual_facts['virtualization_type'] = 'guest'
        virtual_facts['virtualization_role'] = 'HP vPar'


# Generated at 2022-06-20 20:31:59.703077
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule({})
    hpux_virtual = HPUXVirtual(module)
    facts = hpux_virtual.get_virtual_facts()
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:32:00.396589
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    pass
    # TODO: implement test

# Generated at 2022-06-20 20:32:01.432415
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    o = HPUXVirtualCollector({})
    assert o._platform == 'HP-UX'



# Generated at 2022-06-20 20:32:19.129432
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual_object = HPUXVirtual({'module': 'test'})
    assert HPUXVirtual_object != None
    assert HPUXVirtual_object.platform == 'HP-UX'
    assert HPUXVirtual_object.module == 'test'


# Generated at 2022-06-20 20:32:20.422615
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpuxv = HPUXVirtual(dict())
    assert hpuxv._platform == 'HP-UX'
    assert hpuxv._fact_class.platform == 'HP-UX'

# Generated at 2022-06-20 20:32:25.537827
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class TestModule:
        def run_command(self, *args, **kwargs):
            pass
    TestModule.run_command.return_value = (0, 'Running HPVM', '')
    TestModule.run_command.return_value = (0, 'Running HPVM vPar', '')
    TestModule.run_command.return_value = (0, 'Running HPVM guest', '')
    TestModule.run_command.return_value = (1, 'Running HPVM host', '')
    testModule = TestModule()
    testModule.run_command = TestModule.run_command
    testObject = HPUXVirtual(testModule)
    virtual_facts = testObject.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'

# Generated at 2022-06-20 20:32:27.221762
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    huxVirt = HPUXVirtual()
    assert huxVirt.platform == 'HP-UX'

# Generated at 2022-06-20 20:32:35.767545
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Initialize a dict that contains platform specific input
    test_input = {
        'platform': 'HP-UX',
        'module_hw': {
            'path': 'ansible.module_utils.facts.virtual.hp_hpux.module_hw',
        }
    }
    # Initialize a dict that contains output returned by get_virtual_facts method
    test_output = {
        'virtualization_type': 'guest',
        'virtualization_role': 'HP vPar',
        'virtualization_tech_guest': {'HP vPar'},
        'virtualization_tech_host': set()
    }

    # Mock module to be used by get_virtual_facts method
    mock_module = MagicMock()

# Generated at 2022-06-20 20:32:44.539936
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import Virtual, VirtualCollector
    virtual_collector = VirtualCollector()
    # method get_virtual_facts should return a dictionary
    # for the platform HP-UX
    assert isinstance(virtual_collector.collect_virtual_facts('HP-UX'), dict)
    # method get_virtual_facts should return a dictionary
    # for the platform hpux
    assert isinstance(virtual_collector.collect_virtual_facts('hpux'), dict)
    # method get_virtual_facts should return a dictionary
    # for the platform HP-UX11
    assert isinstance(virtual_collector.collect_virtual_facts('HP-UX11'), dict)
    # method get_virtual_facts should return a dictionary
    # for the platform HP-UX11i

# Generated at 2022-06-20 20:32:46.534376
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vc = HPUXVirtualCollector()
    assert vc.platform == 'HP-UX'
    assert vc._collectors[0]._fact_class == HPUXVirtual

# Generated at 2022-06-20 20:32:49.513076
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert virtual_collector._fact_class == HPUXVirtual
    assert virtual_collector._platform == 'HP-UX'

# Generated at 2022-06-20 20:32:57.652546
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpu_virtual import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpu_virtual import HPUXVirtualCollector

    hpu_virtual_collector = HPUXVirtualCollector()
    hpu_virtual_instance = HPUXVirtual(hpu_virtual_collector)
    virtual_facts = hpu_virtual_instance.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    assert virtual_facts['virtualization_tech_guest'] == set(['HP vPar'])
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:33:03.380332
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    facts = {}
    fact_class = 'HPUXVirtual'
    fact_subclass = 'Virtual'
    vc = HPUXVirtualCollector(facts, fact_class)
    assert isinstance(vc.facts, dict)
    assert vc.fact_class == fact_class
    assert hasattr(vc, '_platform')
    assert hasattr(vc, '_fact_class')
    assert isinstance(vc.virtual, fact_subclass)
    assert issubclass(vc.virtual.__class__, Virtual)
# End unit test


# Generated at 2022-06-20 20:33:31.264425
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h = HPUXVirtual({})
    facts = dict()
    assert h.get_virtual_facts() == facts

# Generated at 2022-06-20 20:33:34.736110
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector.platform == 'HP-UX'
    assert HPUXVirtualCollector.priority > 1
    assert HPUXVirtualCollector._fact_class == HPUXVirtual

if __name__ == '__main__':
    test_HPUXVirtualCollector()

# Generated at 2022-06-20 20:33:39.574249
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_obj = FactCollector()
    test_method = getattr(HPUXVirtual, "get_virtual_facts", None)
    result = test_method(test_obj)
    assert result is not None

# Generated at 2022-06-20 20:33:45.721425
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    hpx = HPUXVirtual({})
    hpx.module.run_command = run_command
    facts = hpx.get_virtual_facts()
    assert facts == {'virtualization_type': 'host',
                    'virtualization_role': 'HPVM',
                    'virtualization_tech_host': set(['HPVM']),
                    'virtualization_tech_guest': set(['HPVM'])
                    }


# Generated at 2022-06-20 20:33:49.309425
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """
    Constructor Unit Test
    """
    collector = HPUXVirtualCollector()
    assert collector.__class__.__name__ == 'HPUXVirtualCollector'

# Generated at 2022-06-20 20:33:57.949687
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import Virtual, HPUXVirtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector

    class testmodule(object):
        def __init__(self):
            self.run_command_results = [
                (0, '', ''),  # true
            ]

        def run_command(self, cmd):
            return self.run_command_results.pop(0)

    mock_module = testmodule()
    v = HPUXVirtual(mock_module)
    result = v.get_virtual_facts()
    assert result['virtualization_type'] == 'guest'
    assert result['virtualization_role'] == 'HP vPar'
    assert result['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:34:01.275795
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    my_obj = HPUXVirtualCollector()
    assert my_obj
    assert my_obj._platform == 'HP-UX'
    assert my_obj._fact_class == HPUXVirtual


# Generated at 2022-06-20 20:34:04.442703
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpuxvc = HPUXVirtualCollector()
    assert hpuxvc._platform == 'HP-UX'
    assert hpuxvc._fact_class == HPUXVirtual


# Generated at 2022-06-20 20:34:07.751163
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv._platform == 'HP-UX'
    assert hv._fact_class == HPUXVirtual

# Generated at 2022-06-20 20:34:14.038023
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Init with a fake module in order to be able to call
    # access protected members
    testobj = HPUXVirtual({})
    testobj._module = {}
    testobj._module.run_command = lambda cmd: (0, '', '')
    # Without any virtualization technology
    virtual_facts = testobj.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    assert virtual_facts['virtualization_tech_guest'] == set(['HP vPar'])
    assert virtual_facts['virtualization_tech_host'] == set()
    # With hpvm
    testobj._module.run_command = lambda cmd: (0, 'Running HPVM guest', '')

# Generated at 2022-06-20 20:34:40.480592
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpu9000 import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpu9000 import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.test_virtual import TestVirtual
    virtual = HPUXVirtual()

    virtual_collector = HPUXVirtualCollector()
    virtual_collector.collect()
    all_virtual_facts = virtual_collector.get_facts()
    hosts_facts = virtual_collector.get_host_facts()
    guests_facts = virtual_collector.get_guest_facts()

    result = virtual.get_virtual_facts()
    expected_result = {}
    assert result == expected_result

    result = all_virtual_facts
    assert result == expected_result


# Generated at 2022-06-20 20:34:51.271364
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import ModuleData
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector

    # Unit test with a vPar
    HPUXVirtual.module = ModuleData()
    HPUXVirtual._cached_virtual_facts = {}
    HPUXVirtual.module.run_command = run_command_vpar

    hpux_virtual = HPUXVirtual()
    facts = hpux_virtual.get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP vPar'
    assert facts['virtualization_tech_guest'] == set(['HP vPar'])

# Generated at 2022-06-20 20:34:53.190015
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-20 20:34:57.815107
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    abstract_virtual = HPUXVirtual(module=module)
    virtual_facts = {
        'virtualization_type': 'guest',
        'virtualization_role': 'HPVM IVM',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': {'HPVM IVM'},
    }
    assert virtual_facts == abstract_virtual.get_virtual_facts()



# Generated at 2022-06-20 20:34:59.747356
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual()
    assert h.platform == 'HP-UX'

# Generated at 2022-06-20 20:35:06.784027
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.virtual import collector as virtual
    from ansible.module_utils.facts.virtual.hpux import Virtual

    class TestModule(object):

        def __init__(self, params):
            self.params = params

        def run_command(self, args, check_rc=True):
            if args == '/usr/sbin/vecheck':
                return 0, 'some output', ''
            if args == '/opt/hpvm/bin/hpvminfo':
                return 0, 'some output', ''
            if args == '/usr/sbin/parstatus':
                return 0, 'some output', ''
            return 1, '', ''


# Generated at 2022-06-20 20:35:08.621403
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vc = HPUXVirtualCollector()
    assert vc.platform == 'HP-UX'

# Generated at 2022-06-20 20:35:17.099477
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    AnsibleModule object will be created internally by AnsibleModule class.
    We will mock its methods inside the unit test.
    """
    module = MockAnsibleModule()
    module.run_command.return_value = 1, '', ''
    hpux_virtual = HPUXVirtual(module)

    # Check if virtualization_type and virtualization_role are set properly
    module.run_command.return_value = 0, '/usr/sbin/vecheck', ''
    hpux_virtual_facts = hpux_virtual.get_virtual_facts()
    assert hpux_virtual_facts['virtualization_type'] == 'guest'
    assert hpux_virtual_facts['virtualization_role'] == 'HP vPar'
    assert hpux_virtual_facts['virtualization_tech_host'] == set([])
   

# Generated at 2022-06-20 20:35:18.668912
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual_collector = HPUXVirtual({})
    hpux_virtual_collector.collect()
    assert type(hpux_virtual_collector._virtual_facts) == dict

# Generated at 2022-06-20 20:35:24.311002
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = MockModule()
    module.run_command = Mock(return_value=(0, '', ''))
    virtual_inst = HPUXVirtual(module)
    virtual_facts = virtual_inst.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP nPar'
    assert 'HP nPar' in virtual_facts['virtualization_tech_guest']


# Generated at 2022-06-20 20:36:36.333642
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Test setup
    import os
    from ansible.module_utils.facts.virtual import HPUXVirtual
    from ansible.module_utils.facts.virtual import BaseVirtual
    from ansible.module_utils.facts.facts.virtual import Virtual
    from ansible.module_utils.facts import DATA_DIR
    from ansible.module_utils import basic

    # This is a dict of paths to mock data for testing
    MOCK_DATA_DIR = os.path.join(DATA_DIR, 'modules', 'hpux')
    mock_data = {
        'sysparm_vg': os.path.join(MOCK_DATA_DIR, 'sysparm_vg'),
        'sysparm_vg_2': os.path.join(MOCK_DATA_DIR, 'sysparm_vg_2'),
    }

   

# Generated at 2022-06-20 20:36:45.255413
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    from ansible.module_utils.facts.virtual.hpar import HPUXVirtual
    hpar_obj = HPUXVirtual({})
    hpar_obj.module.run_command = run_command_mock
    hpar_obj.get_virtual_facts()

    from ansible.module_utils.facts.virtual.hpvm import HPUXVirtual
    hpvm_obj = HPUXVirtual({})
    hpvm_obj.module.run_command = run_command_mock
    hpvm_obj.get_virtual_facts()

    from ansible.module_utils.facts.virtual.npar import HPUXVirtual
    npar_obj = HPUXVirtual({})
    npar_obj.module.run_command = run_command_mock
    npar_obj.get_virtual_facts()




# Generated at 2022-06-20 20:36:49.010673
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    facts = HPUXVirtualCollector()
    assert isinstance(facts, HPUXVirtualCollector)
    assert facts._platform == 'HP-UX'
    assert facts._fact_class == HPUXVirtual


# Generated at 2022-06-20 20:36:53.219236
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    HP-UX does not have lscpu command. So, calling the method with a value other
    than 0 or 1 will not return anything.
    """
    hpx_virtual = HPUXVirtual()
    virtual_facts = hpx_virtual.get_virtual_facts()
    assert 'virtualization_tech_guest' not in virtual_facts

# Generated at 2022-06-20 20:37:04.445555
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_module = type('TestModule', (object,), dict(
                run_command=lambda self, cmd, check_rc=True: (0, "", ""),
                params=dict()
            )
    )()
    test_module.virtual_node = test_module  # Simulate a real ansible module by using it as virtual_node
    test_module.check_mode = False

    HPUXVirtual_instance = HPUXVirtual(module=test_module)
    facts = HPUXVirtual_instance.get_virtual_facts()
    assert facts == {'virtualization_type': 'guest', 'virtualization_role': 'HP nPar', 'virtualization_tech_guest': set(['HP nPar']), 'virtualization_tech_host': set()}

# Generated at 2022-06-20 20:37:07.975932
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    Constructor of HPUXVirtual class should set
    'virtualization_type' and 'virtualization_role' to 'None'
    """
    hv = HPUXVirtual()
    assert hv.virtualization_type == None
    assert hv.virtualization_role == None



# Generated at 2022-06-20 20:37:15.509465
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual=HPUXVirtual()

    assert hpux_virtual.platform == 'HP-UX', "This is not a HP-UX system"
    assert hpux_virtual.get_virtual_facts() == {
        'virtualization_type': None,
        'virtualization_role': None,
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
        'virtualization_tech': set()
    }, "virtualization_facts is not empty, or has a wrong format"
