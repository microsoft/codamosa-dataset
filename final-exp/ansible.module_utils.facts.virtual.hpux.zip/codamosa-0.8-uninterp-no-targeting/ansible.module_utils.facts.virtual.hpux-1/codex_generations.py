

# Generated at 2022-06-20 20:27:30.969352
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.virtual.hpuxtools import HPUXVirtual
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.virtual.base import Virtual
    import tempfile
    import os

    def create_tmp_fil(path, fil_content):
        path = os.path.join(temp_dir, path)
        file_dir = os.path.dirname(path)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)
        open(path, 'wb').write(fil_content)

    temp_dir = tempfile.mkdtemp()

    # Create vecheck

# Generated at 2022-06-20 20:27:40.826572
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collector.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual import VirtualCollector

    # Test for guest
    hpux_virtual = HPUXVirtual('guest')
    hpux_virtual.module = Facts(
        dict(ANSIBLE_MODULE_ARGS=dict({'gather_subset': ['virtual']}))
    )
    hpux_virtual.module.run_command = lambda x: [0, '', '']
    hpux_virtual.platform = 'HP-UX'

# Generated at 2022-06-20 20:27:43.083392
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpux_collector = HPUXVirtualCollector(None)
    assert hpux_collector._platform == 'HP-UX'
    assert hpux_collector._fact_class.platform == 'HP-UX'

# Generated at 2022-06-20 20:27:49.337191
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpar import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpvm import HPUXVirtual
    from ansible.module_utils.facts.virtual.npar import HPUXVirtual
    module = AnsibleModule(argument_spec={})
    virtual_facts = HPUXVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'

# Generated at 2022-06-20 20:27:57.714516
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    # HP-UX guest on VeCheck
    os.environ['PATH'] = '/usr/sbin/'
    hv = HPUXVirtual(module)
    hv.get_virtual_facts() == {'virtualization_type': 'guest', 'virtualization_role': 'HP vPar', 'virtualization_tech_guest': {'HP vPar'}, 'virtualization_tech_host': set()}

    # HP-UX guest on hpvminfo
    os.environ['PATH'] = '/opt/hpvm/bin/'
    hv = HPUXVirtual(module)
    hv.get

# Generated at 2022-06-20 20:28:01.209697
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """
    Unit test for constructor of class HPUXVirtualCollector
    """
    try:
        instance = HPUXVirtualCollector()
    except Exception:
        assert False

    assert True


# Generated at 2022-06-20 20:28:07.352948
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h = HPUXVirtual({})
    h.module.run_command = run_command_mock

    # Test case 1 when vecheck is not there
    res = h.get_virtual_facts()
    assert res['virtualization_type'] == 'host'
    assert 'HP vPar' not in res['virtualization_tech_guest']
    assert 'HPVM vPar' not in res['virtualization_tech_guest']
    assert 'HPVM IVM' not in res['virtualization_tech_guest']
    assert 'HPVM' not in res['virtualization_tech_guest']
    assert 'HP nPar' not in res['virtualization_tech_guest']
    assert res['virtualization_tech_host'] == set()

    # Test case 2 when vecheck is there and /usr/sbin/vecheck

# Generated at 2022-06-20 20:28:09.042818
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    h = HPUXVirtualCollector(None)
    assert h.platform == 'HP-UX'
    assert h._fact_class == HPUXVirtual

# Generated at 2022-06-20 20:28:16.867423
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    m_params = basic.AnsibleModule(argument_spec={})
    m_run_command = basic.AnsibleModule(argument_spec={})
    m_run_command.run_command = lambda *args, **kw: (0, b"", b"")

    m_params.run_command = m_run_command.run_command
    hpux_virtual = HPUXVirtual(m_params)

    # Test HP vPar
    if os.path.exists('/usr/sbin/vecheck'):
        m_run_command.run_command = lambda *args, **kw: (0, b"", b"")
        hpux_virtual.module = m_run_command
        assert hp

# Generated at 2022-06-20 20:28:26.866642
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Test the get_virtual_facts method of HPUXVirtual.
    """
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch, Mock
    import ansible.module_utils.facts.virtual.hpux

    # Define some variables for the test class.
    ansible.module_utils.facts.virtual.hpux.HPUXVirtual.platform = 'HP-UX'

    # Set up test class.
    class AnsibleExitJson(Exception):
        """Exception class to be raised by module.exit_json and caught by the test case"""
        pass


# Generated at 2022-06-20 20:28:37.706660
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule({})
    vm = HPUXVirtual(module)
    facts = vm.get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts

# Generated at 2022-06-20 20:28:39.489224
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    '''
    Creates a Virtual object from HPUXVirtual class
    '''
    hpux_virtual = HPUXVirtual({})

# Generated at 2022-06-20 20:28:43.349758
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    class_name = "HPUXVirtualCollector"
    obj = HPUXVirtualCollector()
    class_obj = getattr(obj, "_%s__%s" % (class_name, "fact_class"))
    assert HPUXVirtual == class_obj
    class_obj = getattr(obj, "_%s__%s" % (class_name, "platform"))
    assert "HP-UX" == class_obj

# Generated at 2022-06-20 20:28:54.390550
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    class module:
        def run_command(self, *args, **kwargs):
            return (0, '', '')

    class HPUXVirtualTest(HPUXVirtual):
        def __init__(self, module):
            self.module = module

        def _get_mount_point(self, path, mount_table):
            return ''

    def os_path_exists(p):
        return p == '/usr/sbin/vecheck' or p == '/opt/hpvm/bin/hpvminfo' or p == '/usr/sbin/parstatus'

    HPUXVirtualTest.os_path_exists = os_path_exists

    v = HPUXVirtualTest(module())

    # no virtualization detected

# Generated at 2022-06-20 20:29:02.501353
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    virt = HPUXVirtual(module=module)

    # set up the expected result
    expected_virtual_facts = {
        'virtualization_type': 'guest',
        'virtualization_role': 'HP vPar',
        'virtualization_tech_guest': {'HP vPar'},
    }
    assert virt.get_virtual_facts() == expected_virtual_facts


# Generated at 2022-06-20 20:29:04.169440
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    h = HPUXVirtualCollector()

# Generated at 2022-06-20 20:29:06.113311
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector._platform == 'HP-UX'
    assert HPUXVirtualCollector._fact_class == HPUXVirtual

# Generated at 2022-06-20 20:29:07.095498
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    test_obj = HPUXVirtual()
    test_obj.module.run_command = run_command

    test_obj.get_virtual_facts()



# Generated at 2022-06-20 20:29:12.272770
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.params = PARAMS_FOR_TESTS
    hv = HPUXVirtual(module=module)

    assert hv.get_virtual_facts() == EXPECTED_RESULT

PARAMS_FOR_TESTS = {}

# Output from /usr/sbin/vecheck for a vPar

# Generated at 2022-06-20 20:29:20.144487
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import tempfile
    import shutil
    import os
    from ansible.module_utils.facts.virtual import HPUXVirtual

    tempdir = tempfile.mkdtemp()
    #Add a fake hpvminfo file to tempdir
    hpvminfo_file = os.path.join(tempdir, 'hpvminfo')
    shutil.copy(os.path.join('../test/units/module_utils/facts/virtual/data/hpvminfo'), hpvminfo_file)

    #Add a fake parstatus file to tempdir
    parstatus_file = os.path.join(tempdir, 'parstatus')
    shutil.copy(os.path.join('../test/units/module_utils/facts/virtual/data/parstatus'), parstatus_file)


# Generated at 2022-06-20 20:29:35.613807
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = FakeModule()
    hpux_virtual = HPUXVirtual(module)
    assert hpux_virtual.platform == 'HP-UX'
    assert hpux_virtual.module == module

# Unit test get_virtual_facts()

# Generated at 2022-06-20 20:29:42.154366
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    h = HPUXVirtual(dict(module=dict()))
    facts = h.get_virtual_facts()
    assert 'guest' == facts['virtualization_type']
    assert 'HPVM' == facts['virtualization_role']
    assert facts['virtualization_tech_guest'] == set(['HPVM IVM'])
    assert facts['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:29:43.888870
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector()
    assert collector._fact_class._platform == 'HP-UX'


# Generated at 2022-06-20 20:29:45.901428
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    factory = HPUXVirtualCollector()
    assert factory._platform == 'HP-UX'

# Generated at 2022-06-20 20:29:55.373766
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virtual = HPUXVirtual(module)

    # Both parstatus and hpvminfo are present
    with patch('os.path.exists', return_value=True):
        with patch('ansible.module_utils.facts.virtual.hpux.HPUXVirtual.run_command', return_value=(0, 'stdout', 'stderr')):
            with patch('ansible.module_utils.facts.virtual.hpux.HPUXVirtual.collect_cmd_output', return_value={'hpvminfo': ['Running', 'HPVM vPar']}):
                virtual_facts = virtual.get_virtual_facts()
                assert virtual_facts['virtualization_type'] == 'guest'
                assert virtual_facts['virtualization_role'] == 'HPVM vPar'

# Generated at 2022-06-20 20:29:57.461123
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    h = HPUXVirtualCollector()
    assert type(h) == HPUXVirtualCollector


# Generated at 2022-06-20 20:29:59.201543
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert virtual_collector._platform == 'HP-UX'

# Generated at 2022-06-20 20:30:09.300547
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    Class constructor test
    """
    test_virt = HPUXVirtual()
    if test_virt.platform != 'HP-UX':
        raise Exception("Platform type is not set to 'HP-UX' : {0}"
                        .format(test_virt.platform))
    if test_virt._platform != 'HP-UX':
        raise Exception("_platform is not set to 'HP-UX' : {0}"
                        .format(test_virt._platform))
    if test_virt._fact_class != HPUXVirtual:
        raise Exception("_fact_class is not set to 'HPUXVirtual' : {0}".
                        format(test_virt._fact_class))

# Generated at 2022-06-20 20:30:09.874302
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual()

# Generated at 2022-06-20 20:30:19.729799
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual, HPUXVirtualCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    import os

    class TestVirtual(Virtual):
        platform = 'HP-UX'

    class TestVirtualCollector(VirtualCollector):
        _fact_class = TestVirtual
        _platform = 'HP-UX'

    class TestFactCollector(FactCollector):
        _collectors = {'virtual_collector': TestVirtualCollector}



# Generated at 2022-06-20 20:30:36.566456
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    assert obj.platform == 'HP-UX'
    assert obj._fact_class == HPUXVirtual

# Generated at 2022-06-20 20:30:44.351334
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import subprocess
    import select
    import os
    class Module:
        def __init__(self):
            pass

        def run_command(self, args):
            class Popen:
                def __init__(self, command, *args, **kwargs):
                    pass
                def communicate(self):
                    return None, None
            proc = Popen(args)
            rc = proc.wait()
            return rc, '', ''

    class FakeFileObject:
        def __init__(self):
            pass
        def fileno(self):
            return 3
    def stub_select(rlist, wlist, elist, timeout):
        return [FakeFileObject()], [], [], 3

# Generated at 2022-06-20 20:30:47.756926
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    assert obj._platform == 'HP-UX'
    assert obj._fact_class == HPUXVirtual

# Generated at 2022-06-20 20:30:49.070446
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-20 20:30:51.405522
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv._platform == 'HP-UX'
    assert hv._fact_class == HPUXVirtual

# Generated at 2022-06-20 20:30:54.826539
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    virtual = HPUXVirtual({'module_setup': True})
    virtual_facts = virtual.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts

# Generated at 2022-06-20 20:30:57.168968
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = FakeAnsibleModule()
    virt_collector = HPUXVirtualCollector(module)
    assert virt_collector._platform == 'HP-UX'
    assert virt_collector._fact_class == HPUXVirtual


# Generated at 2022-06-20 20:30:59.255935
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    test_HPUXVirtualCollector = HPUXVirtualCollector()
    assert test_HPUXVirtualCollector._platform == 'HP-UX'
    assert test_HPUXVirtualCollector._fact_class == HPUXVirtual


# Generated at 2022-06-20 20:31:00.737054
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = {"ansible_facts": {}}
    hpu = HPUXVirtual(h)
    assert isinstance(hpu, Virtual)



# Generated at 2022-06-20 20:31:04.838098
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts import ModuleStub

    module = ModuleStub()
    hpux_virtual = HPUXVirtual(module=module)
    hpux_virtual_collector = HPUXVirtualCollector(module=module)

    facts_virtual = hpux_virtual.get_virtual_facts()
    if not re.match('^(host|guest)$', facts_virtual['virtualization_type']):
        raise AssertionError("Error - virtual_facts['virtualization_role']: " + facts_virtual['virtualization_role'])

# Generated at 2022-06-20 20:31:30.965331
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # The method get_virtual_facts can't be tested as it calls a run_command which
    # has no equivalent method in test_utils.
    pass

# Generated at 2022-06-20 20:31:33.093904
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})

    assert virtual_facts.platform is 'HP-UX'


# Generated at 2022-06-20 20:31:34.602787
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()


# Generated at 2022-06-20 20:31:38.119443
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    a = HPUXVirtualCollector()
    assert a._fact_class == HPUXVirtual
    assert a._platform == 'HP-UX'

# Generated at 2022-06-20 20:31:48.339604
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # patch module.run_command to simulate "vecheck" and "parstatus" outputs
    from ansible.module_utils.facts.virtual.hpu import HPUXVirtual, VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils._text import to_bytes
    Virtual.module = VirtualCollector.module = HPUXVirtual.module = None
    HPUXVirtual.module = HPUXVirtual._module = None
    HPUXVirtual.module = HPUXVirtual._module = FakeModule()

    out_vecheck = to_bytes('''
Provisioning Agent :  Not Applicable
vPar software  :  Not Installed
HPVM software  :  Not Installed
hpvmstatus   :  Ok
Provisioning Agent :  Not Applicable
''')

   

# Generated at 2022-06-20 20:31:53.551557
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    v = HPUXVirtualCollector('module')
    assert v.get_facts().get('virtualization_tech_guest') == set()
    assert v.get_facts().get('virtualization_tech_host') == set()
    assert v.get_facts().get('virtualization_role') == ''
    assert v.get_facts().get('virtualization_type') == ''

# Generated at 2022-06-20 20:31:54.953056
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual()
    assert virtual_obj.platform == 'HP-UX'
    assert virtual_obj.virtualization_type == 'HP-UX'



# Generated at 2022-06-20 20:31:55.963807
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual(dict())
    assert v.platform == 'HP-UX'

# Generated at 2022-06-20 20:32:04.752030
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class ModuleStub(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err
            self.changed = False
            self.run_command_rc = None
            self.run_command_out = None
            self.run_command_err = None

        def run_command(self, cmd):
            self.run_command_rc = self.rc
            self.run_command_out = self.out
            self.run_command_err = self.err
            return self.rc, self.out, self.err

    class AnsibleModuleStub(object):
        def __init__(self, moduleStub):
            self.params = dict()
            self.check_mode = False
            self.run_command = moduleSt

# Generated at 2022-06-20 20:32:14.164894
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class MockModule(object):
        def __init__(self):
            self.run_command = Mock(return_value=(0, '', ''))
        def fail_json(self, *args, **kwargs):
            raise Exception('Call fail_json')
    mock = MockModule()
    # Testing HPUX virtual guest facts
    #
    # Test case for HP vPar guest facts
    if 'vecheck' in os.path.basename(__file__):
        setattr(mock, 'run_command', Mock(return_value=(0, 'HP vPar', '')))
    virtual_facts = HPUXVirtual(mock).get_virtual_facts()
    assert len(virtual_facts) == 3
    assert 'host' not in virtual_facts['virtualization_type']
    assert 'guest' in virtual_facts

# Generated at 2022-06-20 20:33:10.267498
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vc = HPUXVirtualCollector()
    assert vc
    assert isinstance(vc, VirtualCollector)
    # Expected to be true since HPUXVirtualCollector is a subclass
    assert isinstance(vc, HPUXVirtualCollector)

# Generated at 2022-06-20 20:33:13.243012
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    x = HPUXVirtual(None)
    assert x.platform == 'HP-UX'



# Generated at 2022-06-20 20:33:14.566085
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_object = HPUXVirtual(None)
    assert(virtual_object.platform == "HP-UX")

# Generated at 2022-06-20 20:33:16.944815
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    test_obj = HPUXVirtualCollector(None, {}, {}, None, '')
    assert test_obj._fact_class is HPUXVirtual
    assert test_obj._platform == 'HP-UX'

# Generated at 2022-06-20 20:33:20.339913
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    fact_module = HPUXVirtualCollector(dict())
    assert fact_module.__class__.__name__ == 'HPUXVirtualCollector'
    assert fact_module._platform == 'HP-UX'
    assert fact_module._fact_class.__name__ == 'HPUXVirtual'



# Generated at 2022-06-20 20:33:27.197891
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.virtual import HPUXVirtual
    
    h = HPUXVirtual(dict(ANSIBLE_MODULE_ARGS={}), dict())
    h.module.run_command = lambda x: (0, to_bytes(x), '')

    expected_result = {'virtualization_type': 'guest', 'virtualization_role': 'HP vPar',
    'virtualization_tech_guest': {'HP vPar'},
    'virtualization_tech_host': set()}
    facts = h.get_virtual_facts()
    assert facts == expected_result



# Generated at 2022-06-20 20:33:36.676109
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.module_common import FakeModule
    import os
    import re

    def isfile(path):
        if re.match(r'/usr/sbin/vecheck', path):
            return False
        if re.match(r'/opt/hpvm/bin/hpvminfo', path):
            return False
        if re.match(r'/usr/sbin/parstatus', path):
            return False
        return True

    os.path.isfile = isfile

    test_module = FakeModule()
    virtual_facts = HPUXVirtual().get_virtual_facts(test_module)
    assert virtual_facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-20 20:33:40.100500
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_facts = HPUXVirtualCollector()
    assert virtual_facts._fact_class == HPUXVirtual
    assert virtual_facts._platform == 'HP-UX'



# Generated at 2022-06-20 20:33:42.714034
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpx_virtual = HPUXVirtual({})
    assert hpx_virtual.platform == 'HP-UX'


# Generated at 2022-06-20 20:33:45.630512
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv._platform == 'HP-UX'
    assert hv._fact_class == HPUXVirtual


# Generated at 2022-06-20 20:34:29.760783
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    hv = HPUXVirtual({})
    hv.module = FakeAnsibleModule(
        'fake_host',
        'fake_user',
        '/tmp/fake_executable',
        '/tmp/fake_facts_d'
    )
    facts = hv.get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP vPar'
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_tech_guest'] == {'HP vPar'}



# Generated at 2022-06-20 20:34:33.359941
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    p = hv.get_platform()
    assert p == 'HP-UX'
    assert hv.get_virtual_facts() == {}


# Generated at 2022-06-20 20:34:40.324987
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    class ModuleMock(object):
        def __init__(self):
            self.run_command = run_command

    def run_command(command):
        if command == '/usr/sbin/vecheck':
            return 0, 'Valid vPar'
        elif command == '/opt/hpvm/bin/hpvminfo':
            return 0, 'Running HPVM vPar'
        elif command == '/usr/sbin/parstatus':
            return 0, 'Running HP nPar'
        else:
            return 1, ''

    module = ModuleMock()
    facts = HPUXVirtual(module).get_virtual_facts()
    assert 'virtualization_type' in facts
    assert facts['virtualization_type'] == 'guest'
    assert 'virtualization_role' in facts

# Generated at 2022-06-20 20:34:43.126913
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    mc = HPUXVirtualCollector()

    assert isinstance(mc, VirtualCollector)
    assert mc.platform == 'HP-UX'
    assert mc.fact_class == HPUXVirtual

# Generated at 2022-06-20 20:34:46.349140
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hvc = HPUXVirtualCollector()
    assert hvc.platform == 'HP-UX'
    assert hvc._fact_class == HPUXVirtual

# Generated at 2022-06-20 20:34:56.251459
# Unit test for constructor of class HPUXVirtual

# Generated at 2022-06-20 20:34:58.156187
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv
    assert isinstance(hv, VirtualCollector)


# Generated at 2022-06-20 20:35:02.464169
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vt = HPUXVirtualCollector()
    assert vt._fact_class == HPUXVirtual
    assert vt._platform == 'HP-UX'

# Test return value if /usr/sbin/vecheck exists

# Generated at 2022-06-20 20:35:04.791115
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    obj = HPUXVirtual()
    # TODO: uncomment the following lines after get_virtual_facts() is implemented
    # facts = obj.get_virtual_facts()
    # assert 'virtualization_tech_guest' in facts

# Generated at 2022-06-20 20:35:11.299623
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hypervisor = HPUXVirtual(dict())
    assert hypervisor.platform == 'HP-UX'
    assert hypervisor.get_virtual_facts() == dict(virtualization_type=None,
                                                 virtualization_role=None,
                                                 virtualization_tech_guest=set(),
                                                 virtualization_tech_host=set())

# Generated at 2022-06-20 20:36:27.056543
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = FakeModule()
    virtual = HPUXVirtual(module)
    # Populate some test fact data
    module.params = {'gather_subset': 'all'}
    module.run_command = FakeRunCommand(module)

    # Set empty virtual_facts
    virtual_facts = {'virtualization_role': '',
                     'virtualization_type': '',
                     'virtualization_tech_guest': [],
                     'virtualization_tech_host': []}

    # Test virtualization_role
    virtual_facts['virtualization_role'] = 'HP nPar'
    virtual_facts['virtualization_tech_guest'] = ['HP nPar']
    module.run_command.set_cmd("/usr/sbin/parstatus")
    virtual_facts.update(virtual.get_virtual_facts())


# Generated at 2022-06-20 20:36:29.016963
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(dict())
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-20 20:36:31.727565
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_facts = HPUXVirtualCollector.collect()
    assert isinstance(virtual_facts, dict)
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-20 20:36:34.956466
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector()
    assert collector.__class__.__name__ == 'HPUXVirtualCollector'
    assert collector._fact_class.__name__ == 'HPUXVirtual'
    assert collector._platform == 'HP-UX'



# Generated at 2022-06-20 20:36:36.447816
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual({})
    instance = h.__class__.__name__
    assert instance == "HPUXVirtual"


# Generated at 2022-06-20 20:36:45.434182
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux.HPUXVirtual import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux.HPUXVirtualCollector import HPUXVirtualCollector
    class TestModule(object):
        def __init__(self):
            self.exit_json = exit_json
            self.fail_json = fail_json
            self.run_command = run_command
    def exit_json(rc):
        pass
    def fail_json(rc):
        pass
    def run_command(rc):
        return 0, "", ""

    testmodule = TestModule()
    testmodule.run_command = run_command
    HPUXVirtualCollector(testmodule).collect()
    guest_virtual_facts = HPUXVirtual(testmodule).get_virtual

# Generated at 2022-06-20 20:36:53.963338
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import Virtual
    from ansible.module_utils.facts.virtual.hpu_ux import HPUXVirtual

    m = Virtual()
    m.run_command = lambda x: (0, 'HPVM guest', '')
    hpu_x = HPUXVirtual(m)
    assert hpu_x.get_virtual_facts() == ({
        'virtualization_type': 'guest',
        'virtualization_role': 'HPVM IVM',
        'virtualization_tech_guest': set(['HPVM IVM']),
        'virtualization_tech_host': set(),
    })

    m = Virtual()
    m.run_command = lambda x: (1, '', '')
    hpu_x = HPUXVirtual(m)
    assert hpu_

# Generated at 2022-06-20 20:37:04.814900
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual({})

    assert h is not None, "Check object initialization"
    assert isinstance(h, Virtual), "Check object type"
    assert h.platform == 'HP-UX', "Check platform"
    assert h.guest_tech == set(), "Check guest_tech"
    assert h.host_tech == set(), "Check host_tech"
    assert h.guest_facts == {}, "Check guest_facts"
    assert h.host_facts == {}, "Check host_facts"

    assert h.distribution.lower() == 'hp-ux', "Check distribution"
    assert h.distribution_version.lower() != 'unknown', "Check distribution_version"
    assert h.distribution_major_version.isdigit(), "Check distribution_major_version"


# Generated at 2022-06-20 20:37:10.612600
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    virt = HPUXVirtual()
    virt.module = type('module', (object,), {})
    virt.module.run_command = classmethod(lambda cls, cmd: (0, "", ""))
    facts = virt.get_virtual_facts()
    assert facts['virtualization_type'] is None
    assert facts['virtualization_role'] is None
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_tech_guest'] == set()


# Generated at 2022-06-20 20:37:12.242600
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual()
    assert v.virtual_subclass == 'HP-UX'