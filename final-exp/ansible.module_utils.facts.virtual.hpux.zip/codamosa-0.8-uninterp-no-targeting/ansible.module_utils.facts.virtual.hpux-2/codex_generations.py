

# Generated at 2022-06-20 20:27:17.622313
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert x._platform == 'HP-UX'

# Generated at 2022-06-20 20:27:21.388369
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert isinstance(virtual_collector, VirtualCollector)


# Generated at 2022-06-20 20:27:24.559297
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector._platform == 'HP-UX'
    assert HPUXVirtualCollector._fact_class == HPUXVirtual


# Generated at 2022-06-20 20:27:26.310090
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual({}).platform == 'HP-UX'
    assert HPUXVirtual({})._platform == 'HP-UX'

# Generated at 2022-06-20 20:27:30.763843
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    hpx = HPUXVirtual()
    hpx._module = FakeModule()
    hpx._module.run_command = FakeRunCommand()
    hpx.get_virtual_facts()

# Generated at 2022-06-20 20:27:32.638090
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    m = HPUXVirtualCollector()
    assert m._fact_class is not None
    assert m._fact_class.platform == 'HP-UX'

# Generated at 2022-06-20 20:27:39.182583
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual

    # Test with a hpux machine with no virtualization technology installed
    class Test_module:
        def run_command(self, cmd):
            return 0, '', ''
    hpux = HPUXVirtual(Test_module())
    virtual_facts = hpux.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == None
    assert virtual_facts['virtualization_role'] == None



# Generated at 2022-06-20 20:27:41.927570
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert virtual_collector.platform == 'HP-UX'
    assert virtual_collector.fact_class.platform == 'HP-UX'

# Generated at 2022-06-20 20:27:43.730122
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv
    assert hv.platform == 'HP-UX'
    assert hv.module == {}


# Generated at 2022-06-20 20:27:45.436016
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    with pytest.raises(TypeError):
        HPUXVirtualCollector()

# Generated at 2022-06-20 20:27:53.005929
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-20 20:28:00.214823
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Setup ansible module
    module = AnsibleModule(
        argument_spec=dict(
            filter=dict(default='*', required=False),
        )
    )

    # Setup the facts class
    HPUX_facts = HPUXVirtual(module)

    # Test get_virtual_facts
    facts = HPUX_facts.get_virtual_facts()
    assert facts['virtualization_tech_guest'].intersection(['HP nPar', 'HP vPar', 'HPVM',
                                                            'HPVM IVM', 'HPVM vPar'])
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] in ['HP nPar', 'HP vPar', 'HPVM',
                                            'HPVM IVM', 'HPVM vPar']

# Unit test

# Generated at 2022-06-20 20:28:01.947430
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    c = HPUXVirtualCollector()
    assert c.platform == 'HP-UX'
    assert c._fact_class == HPUXVirtual

# Generated at 2022-06-20 20:28:05.590923
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    # The following asserts are based on the assumption that
    # the class is initialized with a module_utils.facts.virtual.base.Virtual
    # object.
    assert isinstance(virtual_facts.module, object)
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-20 20:28:07.304812
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpxvc = HPUXVirtualCollector()
    assert hpxvc.platform == 'HP-UX'


# Generated at 2022-06-20 20:28:09.005795
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    o = HPUXVirtual(dict())
    assert o
    assert o.platform == 'HP-UX'


# Generated at 2022-06-20 20:28:16.800688
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = {'run_command': run_command,
              'path': {'exists': path_exists}}
    v = HPUXVirtual(module)
    assert v.platform == 'HP-UX'
    assert v.virtualization_type == 'host'
    assert v.virtualization_type == 'host'
    assert v.virtualization_role == 'HPVM'
    assert v.virtualization_role == 'HPVM'
    assert v.virtualization_role_guest == 'HPVM IVM'
    assert v.virtualization_role_guest == 'HPVM IVM'
    assert v.virtualization_role_host == 'HPVM'
    assert v.virtualization_role_host == 'HPVM'
    assert v.virtualization_tech_guest == {'HPVM IVM'}

# Generated at 2022-06-20 20:28:26.731631
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import builtins
    import sys
    import os
    import errno

    # patch the fact class
    fact_class = HPUXVirtual
    fact_class._module = AnsibleModuleMock()


# Generated at 2022-06-20 20:28:29.905061
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    Test to ensure that module attributes are set correctly in
    constructor of class HPUXVirtual
    """
    HPUXVirtualCollector = HPUXVirtualCollector()
    assert HPUXVirtualCollector._platform == 'HP-UX'
    assert isinstance(HPUXVirtualCollector._fact_class, HPUXVirtual)

# Generated at 2022-06-20 20:28:32.291221
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(None)
    assert 'HP-UX' == hpux_virtual.platform

# Generated at 2022-06-20 20:28:47.138870
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv is not None

# Generated at 2022-06-20 20:28:49.365423
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_fact = HPUXVirtual()
    assert virtual_fact.platform == 'HP-UX'

# Generated at 2022-06-20 20:28:51.752077
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    class TestArgs:
        module = None
    self = HPUXVirtual(TestArgs)
    assert self.get_virtual_facts() == {}

# Generated at 2022-06-20 20:28:53.341914
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )
    virt = HPUXVirtual(module)

    assert virt.get_virtual_facts() == {}

# Generated at 2022-06-20 20:29:04.588445
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import ansible.module_utils.facts.virtual.hpux_virtual
    class MockModule():
        def run_command(self, cmd):
            if cmd == "/usr/sbin/vecheck":
                return 0, "vecheck check1", ""
            elif cmd == "/opt/hpvm/bin/hpvminfo":
                return 0, "Running HPVM vPar", ""
            elif cmd == "/usr/sbin/parstatus":
                return 0, "parstatus check1", ""
            else:
                assert False

    class HPUXVirtual(ansible.module_utils.facts.virtual.hpux_virtual.HPUXVirtual):
        def __init__(self, module_reference=None):
            self.module = MockModule()

    virtual = HPUXVirtual()
    virtual.get_virtual_facts()

# Generated at 2022-06-20 20:29:07.419221
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = AnsibleModule(argument_spec={})
    hv = HPUXVirtual(module)
    assert hv.platform == 'HP-UX'
    assert hv.get_virtual_facts() == {}



# Generated at 2022-06-20 20:29:08.912188
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    h_virtual = HPUXVirtualCollector()
    assert h_virtual
    assert h_virtual.platform == HPUXVirtualCollector._platform

# Generated at 2022-06-20 20:29:13.709265
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():

    virtual_object = HPUXVirtual()
    assert virtual_object.virtualization_type == 'guest'
    assert virtual_object.virtualization_role == 'HP vPar'
    assert virtual_object.virtualization_tech_host == set()
    assert virtual_object.virtualization_tech_guest == set(['HP vPar'])

# Generated at 2022-06-20 20:29:15.558462
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = FakeAnsibleModule()
    HPUXVirtualCollector(module)
    assert module.get_virtual_class() == HPUXVirtual


# Generated at 2022-06-20 20:29:22.861225
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.test_virt_util import get_test_module
    from ansible.module_utils.facts.virtual.test_virt_util import get_test_module_return

    module = get_test_module()
    module.run_command = get_test_module_return(
        '',
        '',
        0
    )

    v = HPUXVirtual(module)

    assert v.get_virtual_facts() == {'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}

    module.run_command = get_test_module_return(
        '',
        '',
        0
    )

# Generated at 2022-06-20 20:30:17.693046
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector._platform == 'HP-UX'
    assert HPUXVirtualCollector._fact_class.platform == 'HP-UX'


# Generated at 2022-06-20 20:30:19.362613
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = AnsibleModule(argument_spec={})
    virtual = HPUXVirtual(module)
    assert virtual.platform == 'HP-UX'

# Generated at 2022-06-20 20:30:23.691367
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    v = HPUXVirtual(module)
    assert v.get_virtual_facts() == { 
        'virtualization_role': 'HP nPar',
        'virtualization_type': 'guest',
        'virtualization_tech_host': set([]),
        'virtualization_tech_guest': set(['HP nPar'])
    }

# Generated at 2022-06-20 20:30:25.629769
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpx = HPUXVirtualCollector()
    assert hpx.platform == 'HP-UX'
    assert hpx._fact_class == HPUXVirtual

# Generated at 2022-06-20 20:30:29.501445
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert virtual_collector.fact_class == HPUXVirtual
    assert virtual_collector.platform == 'HP-UX'
    assert virtual_collector.fact_class(collector=virtual_collector)


# Generated at 2022-06-20 20:30:33.691116
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    This function unit test for function get_virtual_facts() of class HPUXVirtual
    """
    module = AnsibleModule(argument_spec=dict())
    virtual = HPUXVirtual(module)
    virtual.get_virtual_facts()

# Unit test case

# Generated at 2022-06-20 20:30:35.986221
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert virtual_collector._platform == 'HP-UX'
    assert virtual_collector._fact_class.platform == 'HP-UX'

# Generated at 2022-06-20 20:30:40.979901
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # test on a Linux system
    hpux_virtual = HPUXVirtual({})
    assert hpux_virtual.platform == 'HP-UX'
    assert hpux_virtual.get_virtual_facts() == {}

    # test on a HP-UX system
    hpux_virtual = HPUXVirtual({'ansible_facts': {'ansible_system': 'HP-UX'}})
    assert hpux_virtual.platform == 'HP-UX'
    return


# Generated at 2022-06-20 20:30:43.842467
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """
    Constructor of class HPUXVirtualCollector.
    """
    virtual_collector = HPUXVirtualCollector()
    assert virtual_collector._fact_class == HPUXVirtual
    assert virtual_collector._platform == 'HP-UX'

# Generated at 2022-06-20 20:30:46.689914
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = FakeModule({}, "fake_fact_module.yml", '/tmp')
    virtual_obj = HPUXVirtual(module)
    virtual_obj.get_virtual_facts()

    assert virtual_obj.platform == 'HP-UX'


# Generated at 2022-06-20 20:32:37.253584
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert x
    assert x._fact_class == HPUXVirtual



# Generated at 2022-06-20 20:32:45.783615
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class mock_module(object):
        def __init__(self):
            self.run_command_count = 0
            self.run_command_rc = {0: 3, 1: 0, 2: 0, 3: 0}
            self.run_command_out = {0: 'Running a HPVM IVM',
                                    1: 'Running a HPVM vPar',
                                    2: 'Running a HPVM guest',
                                    3: 'Running a HPVM host'}
            self.run_command_err = {0: '', 1: '', 2: '', 3: ''}

        def run_command(self, command):
            self.run_command_count += 1
            if self.run_command_count > 3:
                raise Exception('too many run_command() calls')
            i = self.run_command_

# Generated at 2022-06-20 20:32:46.923314
# Unit test for method get_virtual_facts of class HPUXVirtual

# Generated at 2022-06-20 20:32:49.286870
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpuxvirtual = HPUXVirtual(None)
    assert hpuxvirtual.name == "hpux"


# Generated at 2022-06-20 20:32:51.849923
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    facts = HPUXVirtualCollector()
    assert facts == HPUXVirtualCollector

# Unit test function for constructor of class HPUXVirtual

# Generated at 2022-06-20 20:32:55.005939
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    facts_dict = dict()
    HPUX_virtual_obj = HPUXVirtual(facts_dict, None)
    assert HPUX_virtual_obj.platform == 'HP-UX'
    assert HPUX_virtual_obj.module == None

# Generated at 2022-06-20 20:33:04.549866
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    This test ensures that the return value of get_virtual_facts function of HP-UX Virtual class is correct.
    """
    host_virtual_facts = {}
    host_virtual_facts['virtualization_tech_guest'] = set(['HPVM'])
    host_virtual_facts['virtualization_tech_host'] = set(['HPVM'])
    host_virtual_facts['virtualization_type'] = 'host'
    host_virtual_facts['virtualization_role'] = 'HPVM'

    guest_virtual_facts = {}
    guest_virtual_facts['virtualization_tech_guest'] = set(['HPVM IVM'])
    guest_virtual_facts['virtualization_tech_host'] = set()
    guest_virtual_facts['virtualization_type'] = 'guest'
    guest_virtual_facts

# Generated at 2022-06-20 20:33:07.220223
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    my_collector = HPUXVirtualCollector()
    assert my_collector._platform == 'HP-UX'
    assert my_collector._fact_class == HPUXVirtual


# Generated at 2022-06-20 20:33:17.301491
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    import ansible.module_utils.facts.virtual.hpux as hpux
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    import ansible.module_utils.facts.virtual as virtual

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    # create instance of class Virtual and inherit virtualization_type
    virtualization_type = virtual.VirtualizationType(module)
    # create instance of class Virtual and inherit virtualization_role
    virtualization_role = virtual.VirtualizationRole(module)
    # create instance of class Virtual
    virtual_obj = virtual.Virtual(module)
    # create instance of class HPUXVirtual
    hpux_virtual_obj

# Generated at 2022-06-20 20:33:25.806320
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpar import HPUXVirtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpvm import Virtual
    hpar_virtual_facts = HPUXVirtual().get_virtual_facts()

    assert hpar_virtual_facts['virtualization_type'] == 'guest'
    assert hpar_virtual_facts['virtualization_role'] == 'HP vPar'
    assert hpar_virtual_facts['virtualization_tech_guest'] == {'HP vPar'}
    assert hpar_virtual_facts['virtualization_tech_host'] == set()

    hpvm_virtual_facts = Virtual().get_virtual_facts()

    assert hpvm_virtual_facts['virtualization_type'] == 'host'

# Generated at 2022-06-20 20:36:57.701259
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """Constructor of class HPUXVirtualCollector"""
    hpu = HPUXVirtualCollector()
    assert hpu._fact_class == HPUXVirtual
    assert hpu._platform == 'HP-UX'

# Generated at 2022-06-20 20:37:04.877016
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module_mock = MockModule()
    hpuxvirtual = HPUXVirtual(module_mock)
    hpuxvirtual.get_virtual_facts()
    assert hpuxvirtual.virtual_facts
    assert hpuxvirtual.virtual_facts['virtualization_type'] == 'host'
    assert hpuxvirtual.virtual_facts['virtualization_role'] == 'HPVM'
    assert hpuxvirtual.virtual_facts['virtualization_tech_host'] == set(['HPVM'])
    assert hpuxvirtual.virtual_facts['virtualization_tech_guest'] == set([])



# Generated at 2022-06-20 20:37:07.518912
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    #print("Testing HP-UX method 'get_virtual_facts'")
    hphost = HPUXVirtual()
    virtual_facts = hphost.get_virtual_facts()
    assert not virtual_facts['virtualization_tech_guest']