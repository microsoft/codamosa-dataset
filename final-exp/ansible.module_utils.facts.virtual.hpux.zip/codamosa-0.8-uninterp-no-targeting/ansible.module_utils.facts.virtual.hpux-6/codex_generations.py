

# Generated at 2022-06-20 20:27:22.443369
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hps = HPUXVirtualCollector()
    virtual_facts = hps.collect()
    assert(virtual_facts['virtualization_role'] == 'HP vPar')

# Generated at 2022-06-20 20:27:33.082782
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    hpx = HPUXVirtual()

    hpx.module.run_command = MagicMock(return_value=(0, '', ''))
    hpx.module.get_bin_path = MagicMock(return_value=True)
    assert hpx.get_virtual_facts() == {'virtualization_type': 'host', 'virtualization_role': 'HPVM',
                                       'virtualization_tech_guest': {'HPVM'},
                                       'virtualization_tech_host': {'HPVM'}}

    hpx.module.get_bin_path = MagicMock(return_value=False)
    hpx.module.run_command = MagicMock(side_effect=[(0, '', ''), (1, '', ''), (0, '', '')])
    assert hpx.get_virtual_

# Generated at 2022-06-20 20:27:35.801230
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert x.platform == 'HP-UX'
    assert x.fact_class == HPUXVirtual


# Generated at 2022-06-20 20:27:38.728832
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    '''
    Unit test for constructor of class HPUXVirtual.
    '''

    hpx_virtual = HPUXVirtual()
    assert hpx_virtual.platform == 'HP-UX'

# Generated at 2022-06-20 20:27:46.102811
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Example data from
    #   /usr/sbin/vecheck
    #   /opt/hpvm/bin/hpvminfo
    #   /usr/sbin/parstatus
    # as collected with HP-UX 11.31 on an nPars host.
    out1 = (
        "Running as an HP vPar Virtual Partition\n"
        "The virtual partition is managed by the nPars host:\n"
        "myhost.domain.com\n"
    )
    out2 = (
        "Running as an HPVM guest\n"
        "The guest is managed by the HPVM host:\n"
        "myhost.domain.com\n"
    )

# Generated at 2022-06-20 20:27:48.294983
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.utils import ModuleDummy
    module = ModuleDummy(argument_spec={})
    HPUXVirtual(module).get_virtual_facts()

# Generated at 2022-06-20 20:27:56.832017
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import Virtual, HPUXVirtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    import tempfile
    test_file = tempfile.NamedTemporaryFile()
    vecheck_file = '/usr/sbin/vecheck'

    # Testing with vecheck
    with open(vecheck_file, 'w+') as tmp_vecheck_file:
        tmp_vecheck_file.write('')


# Generated at 2022-06-20 20:28:03.128481
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_facts = HPUXVirtualCollector(None).collect()

    assert virtual_facts['virtualization_role'] == 'HPVM vPar' or \
           virtual_facts['virtualization_role'] == 'HP vPar' or \
           virtual_facts['virtualization_role'] == 'HPVM IVM' or \
           virtual_facts['virtualization_role'] == 'HP nPar' or \
           virtual_facts['virtualization_role'] == 'HPVM'

    print(virtual_facts)

# Generated at 2022-06-20 20:28:05.174322
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    mod = HPUXVirtual(dict())
    assert mod._platform == 'HP-UX'
    assert mod.__class__.__name__ == 'HPUXVirtual'

# Generated at 2022-06-20 20:28:13.030977
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = MockModule()
    module.run_command = mock_run_command
    del os.environ['ANSIBLE_HP_VE_CHECK']
    virtual_facts = HPUXVirtual(module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'host'
    assert virtual_facts['virtualization_role'] == 'HPVM'
    assert 'HP vPar' in virtual_facts['virtualization_tech_guest']
    assert 'HPVM vPar' in virtual_facts['virtualization_tech_guest']
    assert 'HPVM IVM' in virtual_facts['virtualization_tech_guest']
    assert 'HPVM' in virtual_facts['virtualization_tech_host']
    assert 'HP nPar' in virtual_facts['virtualization_tech_guest']
    assert not virtual_

# Generated at 2022-06-20 20:28:33.250552
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    '''
    Constructor of class HPUXVirtual
    '''
    hpxvirtual = HPUXVirtual(dict(module=None))
    assert hpxvirtual.platform == 'HP-UX'


# Generated at 2022-06-20 20:28:34.768591
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
     virtual = HPUXVirtual(dict())
     assert virtual.platform == 'HP-UX'


# Generated at 2022-06-20 20:28:42.502165
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.openvz import OpenVZVirtual

    from ansible.module_utils.facts.virtual.lguest import LguestVirtual
    from ansible.module_utils.facts.virtual.xenapi import XenAPIVirtual
    from ansible.module_utils.facts.virtual.solariszone import SolarisZoneVirtual
    from ansible.module_utils.facts.virtual.vserver import VserverVirtual
    from ansible.module_utils.facts.virtual.lxc import LXCVirtual
    from ansible.module_utils.facts.virtual.openvz import OpenVZVirtual
    from ansible.module_utils.facts.virtual.vbox import VBoxVirtual
    from ansible.module_utils.facts.virtual.vmware import VMwareVirtual

# Generated at 2022-06-20 20:28:47.532761
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(dict())
    assert virtual_facts.virtualization_type == 'guest'
    assert virtual_facts.virtualization_role == 'HP vPar'
    assert virtual_facts.virtualization_tech_guest == set(['HP vPar'])
    assert virtual_facts.virtualization_tech_host == set()

# Generated at 2022-06-20 20:28:54.673798
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    # Create a instance of class HPUXVirtual
    virtual = HPUXVirtual()

    # Test the function get_virtual_facts
    virtual_facts = virtual.get_virtual_facts()

    # Check that the facts dict is not empty
    assert virtual_facts
    # Check the virtual_facts dict
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts

# Generated at 2022-06-20 20:28:57.234271
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual()
    assert v.platform == 'HP-UX'
    assert v._platform == 'HP-UX'


# Generated at 2022-06-20 20:29:00.824172
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual(dict()).platform == 'HP-UX'
    assert HPUXVirtual(dict())._platform == 'HP-UX'

# Generated at 2022-06-20 20:29:06.697172
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    virtual_facts = {}
    host_tech = set()
    guest_tech = set()

    HPUXVirtual.get_virtual_facts(self)
    virtual_facts['virtualization_tech_guest'] = guest_tech
    virtual_facts['virtualization_tech_host'] = host_tech

    assert virtual_facts == {'virtualization_tech_guest': 'guest_tech',
                             'virtualization_tech_host': 'host_tech'}


# Generated at 2022-06-20 20:29:10.608730
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class HPUXModule(object):
        def __init__(self):
            self.run_command_counter = 0
            self.run_command_rc = 0
            self.run_command_out = ""
            self.run_command_err = ""
            self.run_command_inject_rc = -1
            self.run_command_inject_run = 0
            self.run_command_inject_out = ""
            self.run_command_inject_err = ""

        def run_command(self, args, **kwargs):
            if self.run_command_inject_run == self.run_command_counter:
                self.run_command_counter += 1
                return self.run_command_inject_rc, self.run_command_inject_out, self.run_command_in

# Generated at 2022-06-20 20:29:12.105600
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_info = HPUXVirtual()
    assert virtual_info is not None


# Generated at 2022-06-20 20:29:33.296002
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector_obj = HPUXVirtualCollector()
    assert collector_obj is not None

# Generated at 2022-06-20 20:29:35.119502
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    from ansible.module_utils.facts.virtual.hpx import HPUXVirtual
    virtual = HPUXVirtual()
    assert virtual.platform  == 'HP-UX'

# Generated at 2022-06-20 20:29:37.855754
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual_obj = HPUXVirtual(dict())
    assert hpux_virtual_obj.platform == 'HP-UX'
    assert hpux_virtual_obj._platform == 'HP-UX'


# Generated at 2022-06-20 20:29:44.706520
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class MockAnsibleModule(object):
        run_command = lambda self, *args, **kwargs: (0, '', '')

    mock = MockAnsibleModule()

    hpux_virtual = HPUXVirtual(mock)
    hpux_virtual_facts = hpux_virtual.get_virtual_facts()
    assert hpux_virtual_facts['virtualization_tech_host'] == set([])
    assert hpux_virtual_facts['virtualization_tech_guest'] == set([])

# Generated at 2022-06-20 20:29:46.874297
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(dict())
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-20 20:29:53.195021
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    from ansible.module_utils.facts import FactCollector

    hpuxvirtualcollector = HPUXVirtualCollector()
    assert hpuxvirtualcollector.__class__.__name__ == 'HPUXVirtualCollector'
    assert hpuxvirtualcollector._platform == 'HP-UX'
    assert hpuxvirtualcollector._fact_class == HPUXVirtual
    assert hpuxvirtualcollector._fact_class.__bases__ == (Virtual, )

# Generated at 2022-06-20 20:30:03.747139
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual

    # Behavior when we run on a HP system with no virtualization technologies in use.
    # We should get no virtualization_tech_host, empty set virtualization_tech_guest and None virtualization_type and virtualization_role
    hpux_virtual = HPUXVirtual(module=None)
    hpux_virtual.module.run_command = lambda x: (1, '', '')
    hpux_virtual.module.get_bin_path = lambda x: ''
    facts_hpux_virtual = hpux_virtual.get_virtual_facts()

# Generated at 2022-06-20 20:30:12.266029
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(
        argument_spec=dict(),
    )
    test_inst = HPUXVirtual(module=module)
    test_inst.module.run_command = lambda x: \
        (0, '', '') if x == '/usr/sbin/vecheck' \
        else (1, '', '') if x == '/opt/hpvm/bin/hpvminfo' \
        else (0, 'HPVM vPar', '') if x == '/usr/sbin/parstatus' \
        else (0, '', '')

# Generated at 2022-06-20 20:30:13.992969
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    print(hpux_virtual)


# Generated at 2022-06-20 20:30:14.765185
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-20 20:30:54.700080
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    vcol = HPUXVirtualCollector()
    vcol.module = AnsibleModuleMock()
    v = HPUXVirtual(vcol)
    assert v.get_virtual_facts() == {'virtualization_type': 'guest',
                                     'virtualization_role': 'HP vPar',
                                     'virtualization_tech_guest': set(['HP vPar']),
                                     'virtualization_tech_host': set()}



# Generated at 2022-06-20 20:30:55.646745
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    virtual_facts = HPUXVirtual().get_virtual_facts()
    print(virtual_facts)



# Generated at 2022-06-20 20:30:56.353910
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-20 20:31:02.162280
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux_virtual import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux_virtual import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual

    class MockModule(object):
        def run_command(self, command):
            if re.match('/opt/hpvm/bin/hpvminfo', command):
                return 0, 'Running. HPVM guest.', ""
            if re.match('/usr/sbin/vecheck', command):
                return 0, "1 1 1 1", ""
            if re.match('/usr/sbin/parstatus', command):
                return 0, "1 1 1 1", ""

    module = MockModule()
    hpux = HPUXVirtual(module)


# Generated at 2022-06-20 20:31:13.077204
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """
    This test verifies that the constructor of the class HPUXVirtualCollector
    works correctly.
    """

# Generated at 2022-06-20 20:31:14.987601
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    assert obj.platform == 'HP-UX'
    assert obj._fact_class == HPUXVirtual
    assert obj.collector is None

# Generated at 2022-06-20 20:31:17.458577
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    facts = HPUXVirtualCollector()
    assert facts.all_facts is None
    assert facts.collect() is not None
    assert facts.all_facts is not None



# Generated at 2022-06-20 20:31:19.422945
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    h = HPUXVirtualCollector()
    assert h._fact_class == HPUXVirtual
    assert h._platform == 'HP-UX'


# Generated at 2022-06-20 20:31:22.880085
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual_obj = HPUXVirtual()
    assert hpux_virtual_obj.kernel == 'HP-UX'


# Generated at 2022-06-20 20:31:26.225949
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpxvc=HPUXVirtualCollector()
    assert hpxvc is not None
    assert hpxvc._platform == 'HP-UX'
    assert hpxvc._fact_class == HPUXVirtual


# Generated at 2022-06-20 20:32:05.112303
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert virtual_collector._fact_class == HPUXVirtual
    assert virtual_collector._platform == 'HP-UX'

# Generated at 2022-06-20 20:32:06.262503
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual({}).platform == 'HP-UX'

# Generated at 2022-06-20 20:32:11.253343
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()

    #assert isinstance(virtual_collector.module, AnsibleModule)
    assert virtual_collector.platform == 'HP-UX'
    assert virtual_collector._fact_class == HPUXVirtual


# Generated at 2022-06-20 20:32:13.403590
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    _platform_virtual_collector = HPUXVirtualCollector()
    assert _platform_virtual_collector._fact_class == HPUXVirtual
    assert _platform_virtual_collector._platform == 'HP-UX'

# Generated at 2022-06-20 20:32:17.745332
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    facts_dict = {}
    test_HPUXVirtualCollector = HPUXVirtualCollector(dict(), facts_dict)
    assert test_HPUXVirtualCollector._platform == 'HP-UX'
    assert test_HPUXVirtualCollector.virtual is not None


# Generated at 2022-06-20 20:32:20.086651
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = HPUXVirtualCollector._create_mock_module()
    assert HPUXVirtualCollector(module)

# Generated at 2022-06-20 20:32:25.253350
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    def mocked_run_command(self, module, command):
        if command == '/usr/sbin/vecheck':
            return (0, "", "")
        elif command == '/opt/hpvm/bin/hpvminfo':
            return (0, "", "")
        elif command == '/usr/sbin/parstatus':
            return (0, "", "")
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    HPUXVirtual.get_virtual_facts = HPUXVirtual.get_virtual_facts
    HPUXVirtual.run_command = mocked_run_command
    hpuxvirtual = HPUXVirtual()
    hpuxvirtual_facts = hpuxvirtual.get_virtual_facts()

# Generated at 2022-06-20 20:32:34.281243
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # DummyModule is a generic class whose instance has same function
    #  as ansible module
    from ansible.test.unit.module_utils.facts.collector.hpux import DummyModule
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual

    # Create object of HPUXVirtual class
    obj = HPUXVirtual(DummyModule())

    # Create a dict that would simulate fact_subset dict of module_args.
    fact_subset = {}

    # Call method HPUXVirtual.get_virtual_facts()
    virtual_facts = obj.get_virtual_facts(fact_subset)

    # Assert that virtual_facts dict has 'virtualization_type' and
    #  'virtualization_role' keys
    assert('virtualization_type' in virtual_facts)

   

# Generated at 2022-06-20 20:32:36.169101
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_instance = HPUXVirtual(dict(module=dict()))
    assert isinstance(virtual_instance, Virtual)
    assert isinstance(virtual_instance, HPUXVirtual)

# Generated at 2022-06-20 20:32:37.590028
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual(None)
    assert v.platform in v.__dict__.values()


# Generated at 2022-06-20 20:33:42.435401
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hw_platform = HPUXVirtualCollector()
    assert hw_platform._platform == 'HP-UX'



# Generated at 2022-06-20 20:33:48.509990
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    test_file = '/proc/cpuinfo'
    expected_facts = {
        'virtualization_type': u'guest',
        'virtualization_role': 'HP nPar',
        'virtualization_tech_guest': 'HP nPar',
        'virtualization_tech_host': '',
    }
    module = AnsibleModuleMock(params={
        'gather_subset': '!all',
        'gather_timeout': 10,
    })
    hpuxvirt = HPUXVirtual(module)
    hpuxvirt.collect_facts()
    assert hpuxvirt.facts == expected_facts

# Generated at 2022-06-20 20:33:52.536673
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    print("Testing HPUXVirtual")
    virtual_hpux = HPUXVirtual('myModule')
    assert virtual_hpux.platform == 'HP-UX'
    assert isinstance(virtual_hpux.get_virtual_facts(), dict)
    assert virtual_hpux.get_virtual_facts() == {}

# Generated at 2022-06-20 20:33:59.685713
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    x = HPUXVirtual({})
    assert x.platform == "HP-UX"
    assert x.virtualization_type == ""
    assert x.virtualization_role == ""
    assert x.virtualization_use == ""
    assert x.virtualization_system == ""
    assert x.virtualization_uuid == ""
    assert x.virtualization_hypervisor == ""
    assert x.virtualization_product_name == ""
    assert x.virtualization_product_version == ""
    assert x.virtualization_product_serial is None
    assert x.virtualization_product_vendor == ""
    assert x.virtualization_product_vendor_version == ""
    assert x.virtualization_product_vendor_serial is None

# Generated at 2022-06-20 20:34:00.938105
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert x._fact_class == HPUXVirtual

# Generated at 2022-06-20 20:34:03.279285
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual({})
    assert v.platform == 'HP-UX'


# Generated at 2022-06-20 20:34:14.682114
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import HPUXVirtual
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux_virtual import HPUXVirtualCollector

    # Initialize the HPUXVirtual class
    hpux = HPUXVirtual()

    # Set the module's run_command method to our own fake method
    hpux.module = type('module', (object,), {})()
    hpux.module.run_command = lambda x: (0, '', '')
    if hpux.virtual_collector._platform == 'HP-UX':
        hpux.virtual_collector.module = hpux.module

    # Set the module_utils.virtual.base.module.run_command
    # to our own fake method

# Generated at 2022-06-20 20:34:23.202547
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec=dict())
    hpux_virtual = HPUXVirtual(module=module)

    results = {
        'virtualization_tech_guest': set(['HP nPar']),
        'virtualization_tech_host': set([]),
        'virtualization_type': 'guest',
        'virtualization_role': 'HP nPar'
    }
    out = hpux_virtual.get_virtual_facts()
    assert out == results

# Generated at 2022-06-20 20:34:30.594486
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpar import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpvm import HPUXVirtual
    from ansible.module_utils.facts.virtual.npar import HPUXVirtual
    from ansible.module_utils.facts.virtual.test_utils import TestAnsibleModule

    testmodule = TestAnsibleModule(module)

    test_set = {'HP vPar': '/usr/sbin/vecheck',
                'HP nPar': '/usr/sbin/parstatus',
                'HPVM vPar': '/opt/hpvm/bin/hpvminfo',
                'HPVM IVM': '/opt/hpvm/bin/hpvminfo',
                'HPVM host': '/opt/hpvm/bin/hpvminfo'}



# Generated at 2022-06-20 20:34:36.474920
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    my_obj = HPUXVirtualCollector()
    assert my_obj._platform == 'HP-UX'
    assert my_obj._fact_class.platform == 'HP-UX'
    assert my_obj._fact_class.__name__ == 'HPUXVirtual'
    assert my_obj._fact_class.__module__ == 'ansible.module_utils.facts.virtual.hpux'