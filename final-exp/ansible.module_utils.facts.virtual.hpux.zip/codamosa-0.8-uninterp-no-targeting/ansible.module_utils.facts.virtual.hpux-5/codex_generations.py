

# Generated at 2022-06-20 20:27:27.452585
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual

    v_facts = HPUXVirtual()
    facts = Facts()
    if not v_facts.get_virtual_facts() == facts.get_virtual_facts():
        return False
    return True

# Generated at 2022-06-20 20:27:35.005077
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import mock
    import collections
    module = mock.MagicMock()
    module.run_command.return_value = 0, "HPVM guest", ""
    hpux_virtual = HPUXVirtual(module)
    hpux_virtual.get_virtual_facts()
    assert hpux_virtual.virtualization_type == 'guest'
    assert hpux_virtual.virtualization_role == 'HPVM IVM'
    assert hpux_virtual.virtualization_tech_guest == set(['HPVM IVM'])
    assert hpux_virtual.virtualization_tech_host == set()


# Generated at 2022-06-20 20:27:44.318986
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts import ModuleTestCase

    class TestModule(ModuleTestCase):
        pass

    test_module = TestModule()
    hpuxv = HPUXVirtual(module=test_module)
    test_module.run_command = MagicMock(return_value=(0, 'test', ''))
    test_module.os.path.exists = MagicMock(return_value=True)
    res = hpuxv.get_virtual_facts()

    assert res['virtualization_type'] == 'guest'
    assert res['virtualization_role'] == 'HP nPar'

    test_module.run_command.return_value = (1, 'test', '')
    res = hpuxv.get_

# Generated at 2022-06-20 20:27:50.343269
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Create a VioServer module object
    module = None

    # Create a HPUXVirtualCollector class object
    HPUXVirtualCollectorObj = HPUXVirtualCollector(module)

    # Create a HPUXVirtual class object
    HPUXVirtualObj = HPUXVirtual(HPUXVirtualCollectorObj.module)

    # Call method get_virtual_facts of class HPUXVirtual
    HPUXVirtualObj.get_virtual_facts()

# Generated at 2022-06-20 20:27:52.710285
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = FakeAnsibleModule()
    hpux_virtual_facts = HPUXVirtual(module)
    assert hpux_virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-20 20:27:59.972560
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import HPUXVirtual
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY2

    if not PY2:
        from io import StringIO
    else:
        from StringIO import StringIO

    class TestModule(object):
        def __init__(self):
            self.run_command_environ_update = {}
            self.run_command_calls = []
            self.run_command_stdout = ''
            self.run_command_stderr = ''

        def run_command(self, args, **kwargs):
            self.run_command_calls.append((args, kwargs))

# Generated at 2022-06-20 20:28:06.251961
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import virtual as virtual_utils
    # initialize a HPUXVirtual object
    hpux_virtual = HPUXVirtual()
    # set the module_utils.virtual_utils.module attribute
    virtual_utils.module = MockModuleUtilsModule()
    # call the method hpux_virtual.get_virtual_facts()
    result = hpux_virtual.get_virtual_facts()
    # test if the result is correct
    assert result == {'virtualization_tech_guest': {'HP nPar', 'HP vPar'}, 'virtualization_tech_host': set(), 'virtualization_type': 'guest', 'virtualization_role': 'HP nPar'}


# Generated at 2022-06-20 20:28:07.369393
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert isinstance(HPUXVirtual(None), HPUXVirtual)


# Generated at 2022-06-20 20:28:15.269951
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = HPUXVirtualCollector()
    if not module:
        assert False, "Unable to instantiate HPUXVirtualCollector"
    if not isinstance(module, HPUXVirtualCollector):
        assert False, "test_module_HPUXVirtualCollector: object created by constructor is not type HPUXVirtualCollector()"
    if not hasattr(module, '_platform'):
        assert False, "test_module_HPUXVirtualCollector: object created by constructor does not have _platform attribute"
    if not module._platform == 'HP-UX':
        assert False, "test_module_HPUXVirtualCollector: object created by constructor does not have _platform attribute set to HP-UX"

# Generated at 2022-06-20 20:28:17.906612
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual(dict())
    assert h.virtualization_type is None
    assert h.virtualization_role is None
    assert h.virtualization_tech_guest == set()
    assert h.virtualization_tech_host == set()


# Generated at 2022-06-20 20:28:39.149354
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    # Test for constructor without argument
    virtual_collector_no_arg = HPUXVirtualCollector()
    assert virtual_collector_no_arg.platform == 'HP-UX'
    assert virtual_collector_no_arg.guest_tech == set()
    assert virtual_collector_no_arg.host_tech == set()

    # Test for constructor with one argument
    virtual_collector_with_one_arg = HPUXVirtualCollector({'fake_key_1': 'fake_value_1'})
    assert virtual_collector_with_one_arg.platform == 'HP-UX'
    assert virtual_collector_with_one_arg.guest_tech == set()
    assert virtual_collector_with_one_arg.host_tech == set()
    assert virtual_collector_with_one_

# Generated at 2022-06-20 20:28:49.594271
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    if not os.path.exists('/usr/sbin/vecheck'):
        rc, out, err = module.run_command("/usr/sbin/vecheck")
        if rc == 0:
            guest_tech.add('HP vPar')
            virtual_facts['virtualization_type'] = 'guest'
            virtual_facts['virtualization_role'] = 'HP vPar'
    if not os.path.exists('/opt/hpvm/bin/hpvminfo'):
        rc, out, err = module.run_command("/opt/hpvm/bin/hpvminfo")
        if rc == 0 and re.match('.*Running.*HPVM vPar.*', out):
            guest_tech.add('HPVM vPar')
            virtual

# Generated at 2022-06-20 20:28:56.497326
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import FactCache
    from ansible.module_utils.facts.virtual.hpar import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpvm import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.test_utils import _TestVirtualFactCache
    import os
    import tempfile

    def _HPUXVirtual_get_virtual_facts(module):
        if module.params['kern_rel'] == 'B.11.31':
            return dict(virtualization_type='host',
                        virtualization_role='HPVM',
                        virtualization_tech_host={'HPVM'},
                        virtualization_tech_guest={'HPVM'})

# Generated at 2022-06-20 20:29:07.382462
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.utils.module_docs import AnsibleModuleLog
    import ansible.module_utils.facts.virtual.hpux as mod
    import mock
    import os
    facts = {}
    ansible_module_log = AnsibleModuleLog()
    # Mock get_virtual_facts method of class HPUXVirtual

# Generated at 2022-06-20 20:29:08.883380
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.platform == 'HP-UX'
    assert hv.has_cmd == False

# Generated at 2022-06-20 20:29:17.718133
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    ''' Used to test get_virtual_facts method of class HPUXVirtual '''
    # Setup
    module_args = {}
    module = MockModule(**module_args)
    fact_class = HPUXVirtual(module)

# Generated at 2022-06-20 20:29:24.361348
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual import Virtual, VirtualCollector
    import os
    class RunCommand:
        def __init__(self):
            pass
        def run_command(self, args):
            if args == "/usr/sbin/vecheck":
                return (0, "/usr/sbin/vecheck", "")
            if args == "/opt/hpvm/bin/hpvminfo":
                return (0, "Running as HPVM vPar guest", "")
            if args == "/usr/sbin/parstatus":
                return (0, "/usr/sbin/parstatus", "")

# Generated at 2022-06-20 20:29:28.914395
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    virtual = HPUXVirtual(dict())
    facts = virtual.get_virtual_facts()
    assert facts['virtualization_type'] is None
    assert facts['virtualization_role'] is None
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-20 20:29:30.556527
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    virtual = HPUXVirtual({}, {})
    virtual._module = MockModule()
    assert isinstance(virtual.get_virtual_facts(), dict)



# Generated at 2022-06-20 20:29:33.223419
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_facts_collector = HPUXVirtualCollector()
    assert virtual_facts_collector._platform == 'HP-UX'


# Generated at 2022-06-20 20:30:03.795316
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    mc = HPUXVirtualCollector()

    assert mc.platform == 'HP-UX'
    assert not mc.guest_facts

# Generated at 2022-06-20 20:30:08.087038
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVC = HPUXVirtualCollector()
    assert HPUXVC._fact_class == HPUXVirtual
    assert HPUXVC._platform == 'HP-UX'


# Generated at 2022-06-20 20:30:12.390603
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = type('', (object,), {'run_command': run_command, 'get_bin_path': get_bin_path})()
    hpuxvirtual = HPUXVirtual(module)
    assert hpuxvirtual.platform == 'HP-UX'
    assert hpuxvirtual.get_virtual_facts() == {
        'virtualization_role': 'HP vPar',
        'virtualization_type': 'guest',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(['HP vPar'])}


# Generated at 2022-06-20 20:30:13.993284
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert virtual_collector is not None

# Generated at 2022-06-20 20:30:16.045765
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = VirtualCollector.factory()
    assert(isinstance(hv, HPUXVirtualCollector))


# Generated at 2022-06-20 20:30:19.510041
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert virtual_collector._platform == 'HP-UX'
    assert isinstance(virtual_collector._fact_class, HPUXVirtual)
    assert virtual_collector._fact_class.platform == 'HP-UX'

# Generated at 2022-06-20 20:30:20.290097
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpuxVirtual = HPUXVirtual({})

# Generated at 2022-06-20 20:30:22.855076
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    collect_obj = HPUXVirtual(module)
    out = collect_obj.get_virtual_facts()
    assert_equals(type(out), dict)


# Generated at 2022-06-20 20:30:24.723074
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpc = HPUXVirtualCollector()
    assert hpc.platform == 'HP-UX'
    assert hpc.fact_class == HPUXVirtual

# Generated at 2022-06-20 20:30:26.690168
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    Constructor HPUXVirtual basic test.
    """
    print('Test constructor of class HPUXVirtual')
    HPUXVirtual()

# Generated at 2022-06-20 20:31:20.913513
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Unit test to verify the virtual_facts returned by method
    get_virtual_facts of class HPUXVirtual
    """

    hpux_virtual = HPUXVirtual()
    hpux_virtual.module = type('', (object,), {'run_command': mock_run_command})
    virtual_facts = hpux_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP nPar'
    assert virtual_facts['virtualization_tech_guest'] == set(['HP nPar'])
    assert virtual_facts['virtualization_tech_host'] == set()


# Generated at 2022-06-20 20:31:24.798107
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpu = HPUXVirtualCollector(None, None, None, None)
    assert hpu._platform == "HP-UX"
    assert hpu._fact_class == HPUXVirtual


# Generated at 2022-06-20 20:31:29.290197
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    # Verify object type
    assert(isinstance(HPUXVirtualCollector(), HPUXVirtualCollector))
    # Verify class name and subclass
    assert(HPUXVirtualCollector._platform == 'HP-UX')
    assert(HPUXVirtualCollector._fact_class == HPUXVirtual)


# Generated at 2022-06-20 20:31:33.125009
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector(None)
    assert virtual_collector.platform == 'HP-UX'
    assert virtual_collector._fact_class.platform == 'HP-UX'
    assert virtual_collector.platform == virtual_collector._fact_class.platform


# Generated at 2022-06-20 20:31:37.549763
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vc = HPUXVirtualCollector('/fake/module/path')
    assert(vc.platform == 'HP-UX')
    assert(vc._fact_class.platform == 'HP-UX')


# Generated at 2022-06-20 20:31:39.528421
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpx = HPUXVirtual({})
    assert hpx.platform == 'HP-UX'


# Generated at 2022-06-20 20:31:42.943479
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpx = HPUXVirtualCollector()
    assert hpx.platform == "HP-UX"
    assert hpx._fact_class == HPUXVirtual


# Generated at 2022-06-20 20:31:45.497132
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert virtual_collector._fact_class._platform == 'HP-UX'
    assert virtual_collector._platform == 'HP-UX'
    assert virtual_collector._fact_class.platform == 'HP-UX'

# Generated at 2022-06-20 20:31:48.132305
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
   assert HPUXVirtualCollector().platform == 'HP-UX'

# Generated at 2022-06-20 20:31:49.315750
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hhpux = HPUXVirtual()
    assert hhpux.platform == 'HP-UX'

# Generated at 2022-06-20 20:32:44.222677
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    facts = HPUXVirtual({})
    assert facts.platform == 'HP-UX'


# Generated at 2022-06-20 20:32:53.716171
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual()
    assert virtual_obj
    assert type(virtual_obj.data) == dict
    assert type(virtual_obj.data['virtualization_type']) == str or virtual_obj.data['virtualization_type'] == None
    assert type(virtual_obj.data['virtualization_role']) == str or virtual_obj.data['virtualization_role'] == None
    assert type(virtual_obj.data['virtualization_tech_host']) == set or virtual_obj.data['virtualization_tech_host'] == set()
    assert type(virtual_obj.data['virtualization_tech_guest']) == set or virtual_obj.data['virtualization_tech_guest'] == set()
    return


# Generated at 2022-06-20 20:32:55.450370
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert x.fact_class == HPUXVirtual
    assert x.platform == 'HP-UX'

# Generated at 2022-06-20 20:32:59.898214
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    vobj = HPUXVirtual({'module': module}, 'posix', 'linux')
    assert vobj
    assert vobj.module
    assert vobj.platform
    assert vobj.distribution
    assert vobj._collector
    assert vobj._fact_class

# Generated at 2022-06-20 20:33:00.663519
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual({})
    assert virtual

# Generated at 2022-06-20 20:33:02.107012
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == "HP-UX"


# Generated at 2022-06-20 20:33:04.335468
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv.platform == 'HP-UX'
    assert isinstance(hv.get_virtual_facts(), dict)

# Generated at 2022-06-20 20:33:05.129463
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-20 20:33:07.813398
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt = HPUXVirtual()
    assert virt.platform == 'HP-UX'
    assert virt.virtualization_type == "guest"
    assert virt.virtualization_role == "HPVM vPar"

# Generated at 2022-06-20 20:33:11.561887
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_hpux = HPUXVirtual(dict())
    assert virtual_hpux.__class__.__name__ == 'HPUXVirtual'
    assert virtual_hpux.platform == 'HP-UX'



# Generated at 2022-06-20 20:34:36.181862
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """
    Test for constructor of class HPXVirtualCollector.
    """
    facts_collector = HPUXVirtualCollector()
    assert facts_collector._fact_class == HPUXVirtual
    assert facts_collector._platform == 'HP-UX'

# Generated at 2022-06-20 20:34:41.572721
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Create the class that we are testing
    test_class = HPUXVirtual()
    # Ensure we have a module to communicate with
    test_class._module = MockModule()
    test_class._module.run_command.side_effect = (
        (0, 'this is vecheck output', 'this is vecheck error'),
        (0, 'this is hpvminfo output', 'this is hpvminfo error'),
        (0, 'this is parstatus output', 'this is parstatus error'))

    # Run the method and get the results
    facts = test_class.get_virtual_facts()

    # Assert that the right shell command was executed
    assert test_class._module.run_command.call_count == 3

# Generated at 2022-06-20 20:34:46.121382
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    m = HPUXVirtual({})
    virtual_facts = m.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP nPar'

# Generated at 2022-06-20 20:34:51.866170
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():

    VirtualCollector.collectors['HP-UX'] = HPUXVirtualCollector()
    virtual_facts = VirtualCollector.collectors['HP-UX'].get_all_facts()
    print(virtual_facts)
    print("\n")
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-20 20:34:54.036305
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(dict())
    assert hv
    assert hv._platform == 'HP-UX'

# Generated at 2022-06-20 20:34:56.319263
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    # test object initialization
    x = HPUXVirtualCollector()
    assert x
    assert x._fact_class is HPUXVirtual
    assert x._platform == "HP-UX"

# Generated at 2022-06-20 20:34:57.823357
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual()
    assert HPUXVirtual.platform == 'HP-UX'


# Generated at 2022-06-20 20:34:59.747487
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtualCollector.factory()
    assert hv is not None

# Generated at 2022-06-20 20:35:01.990385
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert type(x) == HPUXVirtualCollector

# Generated at 2022-06-20 20:35:04.374262
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector.__name__ == "HPUXVirtualCollector"
    assert HPUXVirtualCollector._platform == "HP-UX"
    assert HPUXVirtualCollector._fact_class == HPUXVirtual


# Generated at 2022-06-20 20:37:11.409907
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual()

# Generated at 2022-06-20 20:37:15.548240
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.virtualization_type == ''
    assert virtual_facts.virtualization_role == ''
    assert virtual_facts.virtualization_tech_guest == set()
    assert virtual_facts.virtualization_tech_host == set()