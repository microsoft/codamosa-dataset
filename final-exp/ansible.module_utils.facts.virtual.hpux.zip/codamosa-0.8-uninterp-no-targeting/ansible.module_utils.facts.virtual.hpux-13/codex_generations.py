

# Generated at 2022-06-20 20:27:21.843810
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert 'Platform' in dir(hv)

# Generated at 2022-06-20 20:27:32.488264
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.virtual import Virtual
    import tempfile
    import os
    import shutil
    # Check for virtualization type 'guest'
    fake_file = {'/usr/sbin/vecheck': 'Fake content', '/usr/sbin/parstatus': 'Fake content', '/opt/hpvm/bin/hpvminfo': 'Running HPVM guest'}
    temp_directory = tempfile.mkdtemp()
    for file_name, file_content in fake_file.items():
        file_path = os.path.join(temp_directory, file_name)
        file_handler = open(file_path, 'w')
        file_handler.write(file_content)
        file_handler.close()
    os.environ

# Generated at 2022-06-20 20:27:34.726346
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert HPUXVirtualCollector._platform == hv.platform
    assert HPUXVirtualCollector._fact_class == hv.fact_class
    assert hv.config

# Generated at 2022-06-20 20:27:36.954556
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert x.platform == 'HP-UX'

# Generated at 2022-06-20 20:27:45.067746
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector

    h_virtual = HPUXVirtual()
    guest_tech = set()
    h_virtual.get_virtual_facts()
    host_tech = set()
    h_virtual.get_virtual_facts()
    virtual_facts = h_virtual._virtual_facts
    assert virtual_facts == {'virtualization_type': 'guest', 'virtualization_role': 'HP vPar',
                             'virtualization_tech_guest': guest_tech, 'virtualization_tech_host': host_tech}
    h_virtual.get_virtual_facts()
    virtual

# Generated at 2022-06-20 20:27:47.310437
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual({})
    assert h.platform == 'HP-UX'
    assert h.virtualization_type is None
    assert h.virtualization_role is None

# Generated at 2022-06-20 20:27:48.450842
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt = HPUXVirtual()
    assert virt.platform == 'HP-UX'

# Generated at 2022-06-20 20:27:56.975453
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import subprocess
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual

    class Mock(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    class MockObj(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    class Module(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def run_command(self, cmd):
            return (self.rc, self.out, self.err)

# Generated at 2022-06-20 20:28:05.754807
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    " Unit test for method get_virtual_facts of HPUXVirtual "

    class MockModule(object):
        def run_command(self, cmd):
            cmd = cmd.split()
            if cmd == ['/usr/sbin/parstatus']:
                return (0, '', '')
            elif cmd == ['/usr/sbin/vecheck']:
                return (0, '', '')
            elif cmd == ['/opt/hpvm/bin/hpvminfo']:
                return (0, '', '')
            else:
                raise Exception("mocked run_command got unexpected command: %s" % ' '.join(cmd))

    mock = MockModule()
    virtual_facts = HPUXVirtual(module=mock).get_virtual_facts()

# Generated at 2022-06-20 20:28:12.186475
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    if not HAS_PARSTATUS:
        module.fail_json(msg="The 'parstatus' binary is not installed")

    virtual_facts = {
        'virtualization_tech_guest': set(['HP nPar']),
        'virtualization_tech_host': set(),
        'virtualization_type': 'guest',
        'virtualization_role': 'HP nPar'
    }

    hpux_virtual = HPUXVirtual(module)
    assert hpux_virtual.get_virtual_facts() == virtual_facts

# Generated at 2022-06-20 20:28:27.633071
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    facts = {'product_name': 'HP-UX'}
    hpux = HPUXVirtual(fact_module=None, facts=facts)
    assert hpux.platform == 'HP-UX'
    assert hpux.product_name == 'HP-UX'


# Generated at 2022-06-20 20:28:29.398964
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # get the test class instance
    test_instance = HPUXVirtual()
    assert test_instance.platform == "HP-UX", "Test setting the instance platform failed"


# Generated at 2022-06-20 20:28:33.543554
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    h = HPUXVirtualCollector()
    assert h is not None
    assert h._platform == 'HP-UX'
    assert h.guest_tech == set()
    assert h.host_tech == set()


# Generated at 2022-06-20 20:28:41.631054
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual

    try:
        from ansible.module_utils.ansible_release import __version__
    except ImportError:
        from ansible.release import __version__

    module = MockModule()

    # required for module_utils/facts/virtual/base.py
    module.params = {}
    module.params['gather_subset'] = ['all']
    module.params['gather_timeout'] = 10
    module.params['filter'] = ''
    module.params['gather_network_resources'] = 'no'
    module.params['fact_path'] = '/etc/ansible/facts.d'
    module.ansible_version = __version__

# Generated at 2022-06-20 20:28:43.150181
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv
    assert hv._fact_class
    assert hv._platform

# Generated at 2022-06-20 20:28:47.030709
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(dict(module=dict()))
    assert hv is not None
    assert hv.module is not None
    assert hv.platform == 'HP-UX'



# Generated at 2022-06-20 20:28:48.148997
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    test = HPUXVirtual(None)
    assert test is not None

# Generated at 2022-06-20 20:28:55.382871
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = AnsibleFakeModule()
    virtual = HPUXVirtual(module)
    assert virtual
    assert virtual.platform == 'HP-UX'
    rc, out, err = module.run_command.call_args[0]
    assert rc == '/usr/sbin/vecheck'
    rc, out, err = module.run_command.call_args[0]
    assert rc == '/opt/hpvm/bin/hpvminfo'
    rc, out, err = module.run_command.call_args[0]
    assert rc == '/usr/sbin/parstatus'



# Generated at 2022-06-20 20:29:04.970377
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )

    module.run_command = MagicMock(return_value=(0, 'text', ''))
    hv = HPUXVirtual(module)
    result = hv.get_virtual_facts()

    assert result.keys() == {'virtualization_type', 'virtualization_role',
                             'virtualization_tech_guest', 'virtualization_tech_host'}
    assert result['virtualization_tech_guest'] == set()
    assert result['virtualization_tech_host'] == set()
    assert result['virtualization_role'] == ''
    assert result['virtualization_type'] == ''

# Generated at 2022-06-20 20:29:08.053757
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """Unit test for method get_virtual_facts of class HPUXVirtual"""
    # Method invocation will return false as the platform is not HP-UX
    HXV = HPUXVirtual(dict())
    assert HXV.get_virtual_facts() == dict()

# Generated at 2022-06-20 20:29:38.223802
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_module = type('test_module', (), {
        'run_command': lambda *cmd: (0, "Running HPVM guest", None),
        '_fail_json': lambda s, m: True,
    })
    test_platform = type('test_platform', (object,), {
        'platform': 'HP-UX'
    })

    test_virtual = HPUXVirtual(test_module, test_platform)
    test_virtual.get_virtual_facts()

# Generated at 2022-06-20 20:29:41.299145
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    c = HPUXVirtualCollector()
    assert c
    assert c.platform == 'HP-UX'
    assert c._fact_class == HPUXVirtual

# Generated at 2022-06-20 20:29:52.212030
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Test the get_virtual_facts method of class HPUXVirtual
    """
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import MagicMock
    from ansible.module_utils.facts.virtual import HPUXVirtual
    from ansible.module_utils.facts import facts
    from ansible.module_utils.facts.virtual.base import Virtual


# Generated at 2022-06-20 20:29:53.753260
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(dict(module=dict()))
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-20 20:30:02.547138
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    module = basic.AnsibleModule(
        argument_spec=dict()
    )
    module.run_command = lambda cmd, check_rc=True, close_fds=True: (0, '', '')
    module.exit_json = lambda **kwargs: kwargs
    module.from_json = lambda *args: args

    v = HPUXVirtual(module)
    assert type(v) == HPUXVirtual

    assert type(v.get_virtual_facts()) == dict

# Generated at 2022-06-20 20:30:04.851093
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-20 20:30:07.689555
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpu = HPUXVirtual()
    assert hpu.platform == 'HP-UX'


# Generated at 2022-06-20 20:30:09.649551
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    '''
    Unit test for constructor of class HPUXVirtual
    '''
    obj = HPUXVirtual()
    assert obj.platform == 'HP-UX'


# Generated at 2022-06-20 20:30:14.302871
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector(None)
    assert isinstance(virtual_collector, HPUXVirtualCollector)
    assert virtual_collector._platform == 'HP-UX'
    assert virtual_collector._fact_class.platform == 'HP-UX'


# unit test for HPUXVirtual.get_virtual_facts

# Generated at 2022-06-20 20:30:19.654198
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual()
    facts = virtual.get_virtual_facts()

    assert virtual.platform == 'HP-UX'
    assert isinstance(facts['virtualization_tech_guest'], set)
    assert isinstance(facts['virtualization_tech_host'], set)
    for k in ['virtualization_type',
              'virtualization_role',
              'virtualization_role_id']:
        assert k in facts


# Generated at 2022-06-20 20:31:15.296685
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert virtual_collector.__class__.__name__ == 'HPUXVirtualCollector'
    assert virtual_collector.platform == 'HP-UX'
    assert isinstance(virtual_collector.fact_class(), HPUXVirtual)


# Generated at 2022-06-20 20:31:19.028030
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module_mock = type('module_mock', (), {})()
    module_mock.run_command = type('run_command_mock', (), {'return_value': (0, '', '')})

    virtual = HPUXVirtual(module_mock)

    assert virtual.platform == 'HP-UX'

# Generated at 2022-06-20 20:31:24.805593
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.virtual import HPUXVirtual
    from ansible.module_utils._text import to_bytes

    def fake_HPUX_system(module):
        module.run_command = fake_HPUX_run_command
        return 'HP-UX'

    def fake_HPUX_run_command(module, cmd):
        if cmd == '/usr/sbin/vecheck':
            stdout = to_bytes(str(""))
            stderr = to_bytes(str(""))
            return 0, stdout, stderr

        if cmd == '/opt/hpvm/bin/hpvminfo':
            stdout = to_bytes(str(""))
            stderr = to_bytes(str(""))
            return 0

# Generated at 2022-06-20 20:31:25.900994
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt = HPUXVirtual()


# Generated at 2022-06-20 20:31:29.140505
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpux_virtual_collector = HPUXVirtualCollector()
    assert hpux_virtual_collector.platform == "HP-UX"
    assert hpux_virtual_collector.fact_class == HPUXVirtual

# Generated at 2022-06-20 20:31:36.180164
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    # Case:
    #   When /usr/sbin/vecheck exists and vecheck output contains "Running in HP vPar"
    #   Expected result:
    #       virtualization_type == 'guest'
    #       virtualization_role == 'HP vPar'
    #       virtualization_tech_guest == set(['HP vPar'])
    #       virtualization_tech_host == set()

    import ansible.module_utils.facts.virtual.hpux
    module = object()
    module.run_command = ansible.module_utils.facts.virtual.hpux.run_command

# Generated at 2022-06-20 20:31:45.409648
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Create a mock module
    mock_module = type('AnsibleModule', (object,), {
        'params': {},
        'run_command': create_run_command_mock(),
        'get_bin_path': create_get_bin_path_mock()
    })

    # Create a instance of HPUXVirtual
    hux_virtual = HPUXVirtual(mock_module)

    # Test case when vecheck is present and output from it is
    # 'Running in a HP-UX Virtual Partition (VPAR)'
    hux_virtual.module.run_command.return_value = (0, 'Running in a HP-UX Virtual Partition (VPAR)', '')
    facts = hux_virtual.get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'
   

# Generated at 2022-06-20 20:31:48.034326
# Unit test for method get_virtual_facts of class HPUXVirtual

# Generated at 2022-06-20 20:31:50.506641
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    # Constructor for class HPUXVirtualCollector:
    hpux_virtual = HPUXVirtualCollector()
    # testing members of object hpux_virtual
    assert hpux_virtual._fact_class == HPUXVirtual
    assert hpux_virtual._platform == 'HP-UX'

# Generated at 2022-06-20 20:31:54.249903
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual()
    assert virtual_obj.get_virtual_facts() == {
        'virtualization_type': None,
        'virtualization_role': None,
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

# Generated at 2022-06-20 20:33:48.004977
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Partial execution of class HPUXVirtual
    class HPUXVirtualHalfWay(HPUXVirtual):
        def __init__(self, module):
            self.module = module
            self.data = {}
    # we need to mock module arguments and the module itself
    # module arguments
    module_args = {}
    # instantiate the module object
    module = FakeModule(module_args)
    # instantiate HPUXVirtualHalfWay and call get_virtual_facts method
    v = HPUXVirtualHalfWay(module)
    virtual_facts = v.get_virtual_facts()
    # check that expectations are ok
    assert not 'virtualization_type' in virtual_facts
    assert not 'virtualization_role' in virtual_facts
    assert not 'virtualization_tech_guest' in virtual_facts

# Generated at 2022-06-20 20:33:54.803532
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_test = HPUXVirtual()
    assert virtual_test.platform == "HP-UX"
    assert virtual_test.get_virtual_facts() == {'virtualization_type': 'guest',
                                                'virtualization_role': 'HP vPar',
                                                'virtualization_tech_host': set(),
                                                'virtualization_tech_guest': {'HP vPar'}}

# Generated at 2022-06-20 20:34:02.299755
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    import ansible.module_utils.facts.virtual.hpux as hpux_virtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual

    # Create a mock module
    mock_module = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    # Create a mock set of facts
    mock_facts = dict()

    # Instantiate the HPUXVirtual class
    hpux_virtual_obj = HPUXVirtual(mock_module)

    # Test execution when /usr/sbin/vecheck exists, a HP vPar is detected and
    # the machine has a guest role
    hpux_virtual_obj.module.run_command = mock_vecheck_vepar_exist
    facts = hp

# Generated at 2022-06-20 20:34:03.927966
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert isinstance(virtual_facts, Virtual)
    assert isinstance(virtual_facts, HPUXVirtual)


# Generated at 2022-06-20 20:34:15.199917
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import Virtual
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    import sys
    import mock

    def run_command(module, args, check_rc=True, close_fds=True):
        if args[0] == '/usr/sbin/vecheck':
            return 0, '', ''
        elif args[0] == '/opt/hpvm/bin/hpvminfo':
            return 0, 'Running HPVM guest', ''
        elif args[0] == '/usr/sbin/parstatus':
            return 0, '', ''


# Generated at 2022-06-20 20:34:26.813308
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    facts = {}
    v = HPUXVirtual(module=None)

    rc, out, err = v.module.run_command.return_value = 0, '', ''
    virtual_facts = v.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    assert virtual_facts['virtualization_tech_guest'] == set(['HP vPar'])
    assert virtual_facts['virtualization_tech_host'] == set()

    v.module.run_command.return_value = 1, '', ''
    virtual_facts = v.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'

# Generated at 2022-06-20 20:34:30.085789
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpvirtual = HPUXVirtual(dict())
    assert hpvirtual.platform == 'HP-UX'



# Generated at 2022-06-20 20:34:33.360579
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv.platform == 'HP-UX'
    assert hv.fact_class.platform == 'HP-UX'

# Generated at 2022-06-20 20:34:40.326949
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.basic import AnsibleModule
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils._text import to_bytes
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False,
        )
    module.run_command = run_command_mock
    module.read_file = read_file_mock

    hpux_virtual = HPUXVirtual(module)
    virtual_facts = hpux_virtual.get_virtual_facts()
    assert virtual_facts == {'virtualization_type': 'guest',
                             'virtualization_role': 'HP nPar',
                             'virtualization_tech_guest': {'HP nPar'},
                             'virtualization_tech_host': set()}



# Generated at 2022-06-20 20:34:42.397286
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    testobj = HPUXVirtualCollector()
    assert testobj._fact_class == HPUXVirtual
    assert testobj._platform == 'HP-UX'