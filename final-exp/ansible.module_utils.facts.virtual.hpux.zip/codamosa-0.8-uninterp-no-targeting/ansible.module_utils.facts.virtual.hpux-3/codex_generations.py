

# Generated at 2022-06-20 20:27:21.917459
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpuxvc = HPUXVirtualCollector()
    assert hpuxvc


# Generated at 2022-06-20 20:27:24.547511
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hp_virtual = HPUXVirtual()
    assert hp_virtual.platform == 'HP-UX'

# Generated at 2022-06-20 20:27:26.139612
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual({})
    assert h.platform == 'HP-UX'

# Generated at 2022-06-20 20:27:27.567873
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual(dict(module=dict()))
    assert v


# Generated at 2022-06-20 20:27:38.253213
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    module = AnsibleModule(argument_spec={})
    v = HPUXVirtual(module)

    # Case 1: HPVM host
    v.module.run_command = MagicMock(return_value=(0, "Running on HPVM HPVM host", ""))
    v.get_virtual_facts()
    assert v.virtual_facts['virtualization_type'] == 'host'
    assert v.virtual_facts['virtualization_role'] == 'HPVM'
    assert v.virtual_facts['virtualization_tech_guest'] == {'HPVM'}
    assert v.virtual_facts['virtualization_tech_host'] == set()

    # Case 2: HPVM IVM
    v.module.run_command = MagicMock(return_value=(0, "Running on HPVM HPVM guest", ""))
    v.get

# Generated at 2022-06-20 20:27:41.554569
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    my_HPUXVirtualCollector = HPUXVirtualCollector()
    assert my_HPUXVirtualCollector._fact_class == HPUXVirtual
    assert my_HPUXVirtualCollector._platform == 'HP-UX'

# Generated at 2022-06-20 20:27:43.386935
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert x._platform == 'HP-UX'
    assert x._fact_class.__name__ == 'HPUXVirtual'

# Generated at 2022-06-20 20:27:45.766972
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual_obj = HPUXVirtual()
    assert hpux_virtual_obj._platform == 'HP-UX'


# Generated at 2022-06-20 20:27:48.256583
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.system == u'HP-UX'
    assert hv.type == u'guest'
    assert hv.role == u'HP vPar'

# Generated at 2022-06-20 20:27:50.452516
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual_facts = HPUXVirtual()
    assert hpux_virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-20 20:28:00.840367
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual(None)
    assert virtual_facts.platform == 'HP-UX'

# Generated at 2022-06-20 20:28:06.050605
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    This is a test stub.
    """
    module_mock = AnsibleModuleMock()
    module_mock.run_command = MagicMock(return_value=(0, '', ''))
    module_mock.exit_json = MagicMock(return_value=None)

    h = HPUXVirtual(module_mock)
    data = h.get_virtual_facts()
    assert data is not None
    assert data == {}


# Generated at 2022-06-20 20:28:14.094942
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    '''
    Unit test for method get_virtual_facts of class HPUXVirtual
    '''
    HPUXVirtualCollector.collect()

    if os.path.exists('/usr/sbin/parstatus'):
        assert HPUXVirtualCollector.get_virtual_facts()['virtualization_type'] == 'guest'
        assert HPUXVirtualCollector.get_virtual_facts()['virtualization_role'] == 'HP nPar'
        assert HPUXVirtualCollector.get_virtual_facts()['virtualization_tech_host'] == set()
        assert HPUXVirtualCollector.get_virtual_facts()['virtualization_tech_guest'] == set(['HPVM IVM', 'HP nPar'])

# Generated at 2022-06-20 20:28:15.997800
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    virtual_facts.get_virtual_facts()
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-20 20:28:17.029805
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    test = HPUXVirtual(dict(module=None))
    assert test.platform == 'HP-UX'

# Generated at 2022-06-20 20:28:18.891978
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    facts = HPUXVirtualCollector()
    assert(facts == 'HPUXVirtualCollector')

# Generated at 2022-06-20 20:28:25.196655
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = FakeAnsibleModule()
    virtual = HPUXVirtual(module)
    virtual.collect()
    assert virtual.platform == 'HP-UX'
    assert virtual.data['virtualization_type'] == 'guest'
    assert virtual.data['virtualization_role'] == 'HP vPar'
    assert virtual.data['virtualization_tech_guest'] == {'HP vPar'}
    assert not virtual.data['virtualization_tech_host']


# Generated at 2022-06-20 20:28:27.592807
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    test_object = HPUXVirtualCollector()
    assert test_object._platform == "HP-UX"
    assert isinstance(test_object._fact_class(), HPUXVirtual)

# Generated at 2022-06-20 20:28:28.343037
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()


# Generated at 2022-06-20 20:28:38.543996
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import collector
    import pytest
    from ansible_collections.community.general.plugins.module_utils.facts import virtual
    facts = collector.collect(['virtual'], gather_subset=[], filter_value=None)

    virtual_facts = virtual.HPUXVirtual(None, facts).get_virtual_facts()
    assert virtual_facts['virtualization_role'] == 'HPVM vPar'
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_tech_guest'] == set(['HPVM IVM', 'HP vPar', 'HP nPar', 'HPVM vPar'])

# Generated at 2022-06-20 20:28:52.224217
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    assert obj.platform == "HP-UX"
    assert isinstance(obj._fact_class, HPUXVirtual)
    assert obj._fact_class.platform == "HP-UX"


# Generated at 2022-06-20 20:28:53.822685
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict())

    assert virtual.platform == 'HP-UX'

    # Nothing changed
    assert virtual.get_virtual_facts() == {}



# Generated at 2022-06-20 20:28:58.324067
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    obj = HPUXVirtualCollector()
    assert obj._platform == 'HP-UX'
    assert obj._fact_class == HPUXVirtual


# Generated at 2022-06-20 20:29:03.970231
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert hasattr(HPUXVirtualCollector, '_fact_class')
    assert HPUXVirtualCollector._fact_class == HPUXVirtual
    assert hasattr(HPUXVirtualCollector, '_platform')
    assert HPUXVirtualCollector._platform == 'HP-UX'

#  Unit test for constructor of class HPUXVirtual

# Generated at 2022-06-20 20:29:06.227738
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert virtual_collector._platform is 'HP-UX'
    assert virtual_collector._fact_class is HPUXVirtual

# Generated at 2022-06-20 20:29:07.909124
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv.platform == 'HP-UX' and hv._fact_class is HPUXVirtual

# Generated at 2022-06-20 20:29:11.231925
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    facts = hv.collect()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts

# Generated at 2022-06-20 20:29:17.960642
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    v = Virtual()
    v.module.run_command =  lambda x: (0, '', '')
    assert HPUXVirtual(v).get_virtual_facts() == {
        'virtualization_role': 'HP nPar',
        'virtualization_type': 'guest',
        'virtualization_tech_guest': {'HP nPar'},
        'virtualization_tech_host': set()
    }
    v.module.run_command =  lambda x: (1, '', '')
    assert HPUXVirtual(v).get_virtual_facts() == {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-20 20:29:24.516472
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """docstring for test_HPUXVirtual_get_virtual_facts"""
    print('Testing virtual facts of class HPUXVirtual')

    def main_mock_run_command(module, command, check_rc=True):
        rc = 0
        stdout = 'stdout'
        stderr = 'stderr'
        return rc, stdout, stderr

    module = AnsibleModule({})
    module.run_command = main_mock_run_command
    HPUXVirtual_obj = HPUXVirtual(module)

    virtual_facts = HPUXVirtual_obj.get_virtual_facts()
    virtualization_type = virtual_facts.get('virtualization_type', None)
    virtualization_role = virtual_facts.get('virtualization_role', None)

# Generated at 2022-06-20 20:29:25.227761
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-20 20:29:51.183354
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible_collections.community.general.tests.unit.compat import unittest
    from ansible_collections.community.general.tests.unit.compat.mock import patch
    from ansible_collections.community.general.plugins.module_utils.facts import virtual

    class TestVirtualModule(object):
        def __init__(self):
            self.params = {}

        def run_command(self, command):
            return 0, '', ''

    class TestHPUXVirtual(HPUXVirtual):
        def __init__(self, module):
            self.module = module

    class TestHPUXVirtualCollector(HPUXVirtualCollector):
        def __init__(self, module):
            test_module = TestVirtualModule()

# Generated at 2022-06-20 20:29:55.704046
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import sys
    import os
    print(os.path.dirname(os.path.realpath(__file__)))
    sys.path.append(os.path.dirname(os.path.realpath(__file__)))
    import unit_test_utils
    import module_utils.facts.virtual.hpux as hpux
    hp = hpux.HPUXVirtual()
    virtual_facts = hp.get_virtual_facts()
    assert virtual_facts['virtualization_type'] is not None

# Generated at 2022-06-20 20:30:04.343425
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # In HPUX, Virtual Fact class must be instantiated with the module object

    import ansible.module_utils.facts.virtual.hpux
    # Create a Mock module object
    module = ansible.module_utils.facts.virtual.hpux.AnsibleModule(
        argument_spec=dict()
    )
    # Instantiate HP-UX subclass of class Virtual
    hpx_virtual_fact_instance = HPUXVirtual(module)

    # The method get_virtual_facts should return a dictionary
    assert hpx_virtual_fact_instance.get_virtual_facts()

# Generated at 2022-06-20 20:30:08.513307
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    mytest = HPUXVirtual({})
    fvt = mytest.get_virtual_facts()
    assert fvt['virtualization_type'] == 'guest' or fvt['virtualization_type'] == 'host'

# Generated at 2022-06-20 20:30:11.231111
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """
    Create an instance of HPUXVirtualCollector class
    """
    hpux_virtual = HPUXVirtualCollector()
    assert hpux_virtual is not None


# Generated at 2022-06-20 20:30:14.065814
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    Unit test for constructor of class HPUXVirtual
    """
    hpux_virtual = HPUXVirtual(dict())
    assert False is not hpux_virtual

# Generated at 2022-06-20 20:30:21.747073
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts import facts

    HPUXVirtual._module = Virtual._module
    HPUXVirtualCollector._platform = VirtualCollector._platform

    collect_v = HPUXVirtualCollector(module=facts.module)
    virtual_facts = HPUXVirtual(module=facts.module).get_virtual_facts()

    # print (virtual_facts)

# Generated at 2022-06-20 20:30:23.268960
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert x.platform == 'HP-UX'
    assert x._fact_class == HPUXVirtual

# Generated at 2022-06-20 20:30:26.543428
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv.platform == 'HP-UX'
    assert hv._fact_class.platform == 'HP-UX'

if __name__ == '__main__':
    test_HPUXVirtualCollector()

# Generated at 2022-06-20 20:30:29.106326
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector({}, None)
    assert obj
    assert obj._platform == 'HP-UX'


# Generated at 2022-06-20 20:30:43.527777
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert issubclass(HPUXVirtual, Virtual)
    hv = HPUXVirtual(None)
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-20 20:30:44.918728
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    test_obj = HPUXVirtual(dict())
    assert test_obj.platform == 'HP-UX'



# Generated at 2022-06-20 20:30:50.381015
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict())
    assert virtual.data['virtualization_type'] == 'guest'
    assert virtual.data['virtualization_role'] == 'HPVM IVM'
    assert 'HPVM IVM' in virtual.data['virtualization_tech_guest']
    assert virtual.data['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:30:52.297744
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt = HPUXVirtual()
    assert virt.platform == 'HP-UX'


# Generated at 2022-06-20 20:30:59.118372
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    _module = FakeModule()
    _module.run_command = FakeRunCommand()
    _resolution = {
        '/usr/sbin/vecheck': 0,
        '/opt/hpvm/bin/hpvminfo': 0,
        '/usr/sbin/parstatus': 0,
        }
    _mock_class = FakeRunCommand(_resolution)
    _module.run_command = _mock_class

    with patch('os.path.exists'):
        hpux_virtual_facts = HPUXVirtual()
        hpux_virtual_facts.module = _module

# Generated at 2022-06-20 20:31:10.129716
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    class TestModule(object):
        def __init__(self):
            self.run_command_answer = {
                ('/usr/sbin/vecheck',): ('', '', 0),
                ('/opt/hpvm/bin/hpvminfo',): ('Running HPVM guest', '', 0),
                ('/usr/sbin/parstatus',): ('', '', 0),
            }

        def run_command(self, cmd, check_rc=True):
            return self.run_command_answer[tuple(cmd)]

    def test_get_virtual_facts():
        module = TestModule()
        virtual_facts = HPUXVirtual(module).get_virtual_facts()

        assert virtual_facts['virtualization_type'] == 'guest'

# Generated at 2022-06-20 20:31:15.183482
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    facts = HPUXVirtual()

    # check for hypervisor facts
    assert facts.data.get('virtualization_tech_host') == set()
    assert facts.data.get('virtualization_tech_guest') == set()
    assert facts.data.get('virtualization_type') is None
    assert facts.data.get('virtualization_role') is None
    assert facts.data.get('virtualization_system') is None



# Generated at 2022-06-20 20:31:20.860451
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = AnsibleModule(
        argument_spec = dict()
    )
    virtual_facts = HPUXVirtual(module).collect()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert isinstance(virtual_facts['virtualization_tech_guest'], set)
    assert isinstance(virtual_facts['virtualization_tech_host'], set)



# Generated at 2022-06-20 20:31:32.039237
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import Virtual
    from ansible.module_utils.facts.virtual.hpu import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpu import HPUXVirtualCollector
    module = Virtual._create_module_mock()
    hpu_virtual = HPUXVirtual(module)
    hpu_collector_obj = HPUXVirtualCollector(hpu_virtual)
    hpu_collector_obj.populate()
    hpu_collector_obj.fail_if_not_supported()
    result = hpu_collector_obj.get_virtual_facts()
    assert type(result) == dict
    assert result['virtualization_type'] == 'guest'
    assert result['virtualization_role'] == 'HP vPar'

# Unit test

# Generated at 2022-06-20 20:31:34.814451
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    h = HPUXVirtualCollector()
    assert h.platform == 'HP-UX'
    assert h._fact_class == HPUXVirtual
    assert h._platform == 'HP-UX'


# Generated at 2022-06-20 20:32:11.252695
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual_obj = HPUXVirtual()
    assert hpux_virtual_obj.platform == 'HP-UX'
    assert hpux_virtual_obj.get_virtual_facts() == \
        {'virtualization_tech_guest': set(),
         'virtualization_tech_host': set()}
    assert hpux_virtual_obj.get_virtual_facts() is not None

# Generated at 2022-06-20 20:32:17.054068
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class Opts:
        module_path = ''

    class Cmd:
        def __init__(self, result, rc, out, err):
            self.rc = rc
            self.stdout = out
            self.stderr = err
            self.result = result
        def __call__(self, cmd, *args, **kwargs):
            return self.result

    class Run:
        def __init__(self, run_command):
            self.run_command = run_command
            self.changed = True
            self.failed = False
            self.invocation = {}
        def __call__(self, *args, **kwargs):
            return self.run_command

    module = Opts()
    module.run_command = Run(Cmd('', 0, '', ''))

    import os

# Generated at 2022-06-20 20:32:25.800418
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.base import FakeModule

    test_obj = HPUXVirtual(FakeModule())
    actual = test_obj.get_virtual_facts()
    expected = {'virtualization_type': 'guest',
                'virtualization_role': 'HP vPar',
                'virtualization_tech_guest': set(['HP vPar']),
                'virtualization_tech_host': set()}
    assert actual == expected

# Generated at 2022-06-20 20:32:28.686342
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """Test class HPUXVirtualCollector"""
    hpux_vc = HPUXVirtualCollector()
    assert hpux_vc._fact_class
    assert hpux_vc._platform == 'HP-UX'



# Generated at 2022-06-20 20:32:35.694794
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual

    params = {}
    m_params = basic.AnsibleModule(argument_spec=params)
    collector.collector.add_platform_facts('virtual', HPUXVirtual, m_params)
    facts_result = dict()
    facts_result['virtualization_type'] = 'guest'
    facts_result['virtualization_role'] = 'HPVM'
    assert collector.get_all_facts()['virtualization'] == facts_result

# Generated at 2022-06-20 20:32:37.991574
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    my_object = HPUXVirtualCollector()
    assert(my_object.platform == 'HP-UX')
    assert(my_object._fact_class == HPUXVirtual)

# Generated at 2022-06-20 20:32:38.771912
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector(None)

# Generated at 2022-06-20 20:32:40.949461
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hvm = HPUXVirtual({})
    assert hvm.platform == 'HP-UX'


# Generated at 2022-06-20 20:32:43.320172
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual()
    assert virtual_obj._platform == 'HP-UX'
    assert virtual_obj.get_virtual_facts() == {}
    return virtual_obj


# Generated at 2022-06-20 20:32:46.175910
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpv = HPUXVirtual()
    assert hpv.platform == 'HP-UX', 'incorrect value for hpv.platform'
    assert hpv.virtualization_type == 'none', 'incorrect value for hpv.virtualization_type'


# Generated at 2022-06-20 20:33:46.351734
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Unit test to check if the method get_virtual_facts is working fine
    # creating the mock object
    class HPFactsModule(object):
        def __init__(self):
            self._ansible_version = '1.9.1'
        def get_bin_path(self, arg, *args, **kwargs):
            return "/usr/sbin/vecheck"
        def run_command(self, arg, *args, **kwargs):
            return (0, 'HPVM vPar running', '')

    module = HPFactsModule()
    # creating virtual instance
    virtual = HPUXVirtual(module)
    # getting virtual facts
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role']

# Generated at 2022-06-20 20:33:50.031655
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    test_obj = HPUXVirtualCollector()
    assert test_obj._platform == 'HP-UX'
    assert type(test_obj._fact_class) == type(HPUXVirtual())


# Generated at 2022-06-20 20:33:58.652331
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux_hpvm_info import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux_parstatus import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux_vecheck import HPUXVirtual
    from ansible.module_utils.basic import AnsibleModule

    # The following test is for HPVM IVM
    module_hpvm_ivm = AnsibleModule(
        argument_spec=dict()
    )
    with open("tests/unit/module_utils/facts/virtual/hpvm_ivm.txt", "r") as hpvminfo_out:
        hpvminfo_out_content = hpvminfo_out.read()

# Generated at 2022-06-20 20:34:01.077774
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    v = HPUXVirtualCollector()
    assert v.platform == 'HP-UX'
    assert isinstance(v, VirtualCollector)


# Generated at 2022-06-20 20:34:03.125841
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual()
    assert v.platform == 'HP-UX'

# Generated at 2022-06-20 20:34:09.820047
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import subprocess
    from ansible.module_utils.facts.virtual import VirtualCollector

    class ModuleStub(object):
        def __init__(self):
            self.run_command = subprocess.Popen(['/bin/cat', '../tests/virtual_hp-ux'],
                                                stdout=subprocess.PIPE).communicate()[0]

    class CollectorStub(object):
        def __init__(self):
            self.module = ModuleStub()
            self.get_virtual_facts = HPUXVirtual.get_virtual_facts

    collector = CollectorStub()

# Generated at 2022-06-20 20:34:18.440754
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    data_dir = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(data_dir, 'ansible_module_mock.py')
    tmp_path = '/tmp/ansible_module_mock.py'

# Generated at 2022-06-20 20:34:21.696216
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    from ansible.module_utils.facts import __virtualname__

    assert HPUXVirtualCollector.__module__ == 'ansible.module_utils.facts.virtual.hpux'
    assert HPUXVirtualCollector.__virtualname__ == 'virtual'

# Generated at 2022-06-20 20:34:24.907186
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(None)
    assert virtual.platform == 'HP-UX'
    assert virtual._fact_class == HPUXVirtual

# Generated at 2022-06-20 20:34:26.307192
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual({})
    assert h.platform == 'HP-UX'

# Generated at 2022-06-20 20:36:28.106750
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    mc = HPUXVirtualCollector()
    assert mc._fact_class == HPUXVirtual
    assert mc._platform == 'HP-UX'



# Generated at 2022-06-20 20:36:30.570566
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpx = HPUXVirtual(None)
    hpx.collect()
    hpx.get_virtual_facts()


# Generated at 2022-06-20 20:36:32.358505
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpxvc = HPUXVirtualCollector()
    assert hpxvc.platform == 'HP-UX'

# Generated at 2022-06-20 20:36:34.445073
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    assert obj.platform == 'HP-UX'
    assert obj._fact_class == HPUXVirtual

# Generated at 2022-06-20 20:36:36.948653
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    Hpux_virtual = HPUXVirtual()
    assert(Hpux_virtual != None)
    assert(Hpux_virtual.platform == 'HP-UX')
    assert(Hpux_virtual.get_virtual_facts() != None)


# Generated at 2022-06-20 20:36:39.172916
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = DummyAnsibleModule()
    result = HPUXVirtualCollector(module)
    assert result.platform == 'HP-UX'
    assert result._fact_class == HPUXVirtual


# Generated at 2022-06-20 20:36:43.566359
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert x._platform == 'HP-UX'
    assert x._fact_class.platform == 'HP-UX'
    assert x._fact_class.__name__ == 'HPUXVirtual'


# Generated at 2022-06-20 20:36:45.674550
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector._platform == 'HP-UX'
    assert HPUXVirtualCollector._fact_class == HPUXVirtual


# Generated at 2022-06-20 20:36:49.378101
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    modules_mock = basic.AnsibleModule
    collector._load_platform_subclass(HPUXVirtualCollector, modules_mock)

# Generated at 2022-06-20 20:36:55.489656
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.virtual import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector

    class ModuleMock(object):
        def __init__(self):
            self.run_command = lambda x: (0, '', '')

    class AnsibleModuleMock(object):
        def __init__(self):
            self.module = ModuleMock()
            self.params = {}
            self.exit_json = lambda x: False

    class FactMock(object):
        def __init__(self):
            self.collector