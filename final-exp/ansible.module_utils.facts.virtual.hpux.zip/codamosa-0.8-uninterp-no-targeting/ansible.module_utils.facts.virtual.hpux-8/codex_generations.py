

# Generated at 2022-06-20 20:27:30.927916
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    import json

    virtual = HPUXVirtual()

    # Test is vecheck is installed
    if os.path.exists('/usr/sbin/vecheck'):
        class ModuleMock(object):
            def __init__(self):
                self.rc = 0
                self.err = ''
                self.out = '1 vPar(s) installed and running.  1 guest(s) are configured'

            def run_command(self, path):
                return(self.rc, self.out, self.err)

        module = ModuleMock()
        virtual.module = module

        virtual_facts = virtual.get_virtual_facts()

        # Test if virtualization_type is guest
        assert virtual_facts['virtualization_type'] == 'guest'

        # Test if virtualization_role is HP vPar

# Generated at 2022-06-20 20:27:32.749449
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert str(HPUXVirtualCollector) == "<class 'ansible.module_utils.facts.virtual.hpux.HPUXVirtualCollector'>"

# Generated at 2022-06-20 20:27:42.425917
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import get_virtual_facts

    class MockHPModule:
        """
        This class is a mock of AnsibleModule.
        It simulates the behavior of the run_command method.
        When True is passed as value of the run_command_enforce_rc parameter
        the rc value is forced to 0.
        """

        def __init__(self, params):
            self.params = params

        def run_command(self, cmd):
            if self.params.get('run_command_enforce_rc'):
                return (0, '', '')

# Generated at 2022-06-20 20:27:43.840054
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual()
    assert v.platform == 'HP-UX'


# Generated at 2022-06-20 20:27:46.940337
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = type('FakeModule', (object,), dict())
    obj = HPUXVirtualCollector(module)
    assert obj._platform == 'HP-UX'
    assert obj._fact_class == HPUXVirtual

# Generated at 2022-06-20 20:27:53.833025
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    name = "ansible.module_utils.facts.virtual.hpux.HPUXVirtualCollector"
    obj = HPUXVirtualCollector({})
    assert obj._fact_class.__name__ == "HPUXVirtual", \
    "Constructor of " + name + " has failed test of _fact_class. Expected: a inherited from Virtual class. Actual: " + obj._fact_class.__name__
    assert obj._platform == "HP-UX", \
    "Constructor of " + name + " has failed test of _platform. Expected: HP-UX. Actual: " + obj._platform

# Generated at 2022-06-20 20:28:00.773166
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = 'ansible.module_utils.facts.virtual.hpu.x'
    m_args = dict(path='/bin:/usr/bin:/sbin:/usr/sbin',
                  executable='/bin/sh',
                  no_log=False,
                  uri=None,
                  http_agent='ansible-httpget',
                  resource=None,
                  status=None,
                  body=None,
                  headers=None,
                  follow=False,
                  client_cert=None,
                  timeout=300,
                  force_basic_auth=True,
                  env_use_unsafe_shell=True,
                  unsafe_shell=False)
    hpu_virtual = HPUXVirtual(module, m_args)
    for fact in hpu_virtual.get_virtual_facts():
        assert fact != ''

# Generated at 2022-06-20 20:28:02.722478
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vc = HPUXVirtualCollector()
    assert vc is not None
    assert vc._platform == 'HP-UX'
    assert vc._fact_class == HPUXVirtual

# Generated at 2022-06-20 20:28:10.670982
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpar import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpvm import HPUXVirtual
    from ansible.module_utils.facts.virtual.npar import HPUXVirtual

    hpar_facts = {'virtualization_type': 'guest', 'virtualization_role': 'HP vPar', 'virtualization_tech_guest': {'HP vPar'}, 'virtualization_tech_host': set()}
    hpvm_facts = {'virtualization_type': 'guest', 'virtualization_role': 'HPVM vPar', 'virtualization_tech_guest': {'HPVM vPar'}, 'virtualization_tech_host': set()}

# Generated at 2022-06-20 20:28:13.216099
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert Virtual().__class__.__name__ == 'Virtual'
    assert HPUXVirtual().__class__.__name__ == 'HPUXVirtual'
    assert HPUXVirtual().platform == 'HP-UX'


# Generated at 2022-06-20 20:28:25.602199
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = FakeAnsibleModule()
    virtual_collector = HPUXVirtualCollector(module)


# Generated at 2022-06-20 20:28:28.762119
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    from ansible.module_utils.facts import virtual
    data = virtual.HPUXVirtualCollector.collect()
    assert data.keys() == ['virtualization_role', 'virtualization_tech_host', 'virtualization_tech_guest', 'virtualization_type']

# Generated at 2022-06-20 20:28:31.270119
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    # no need to test conctor
    pass

# Generated at 2022-06-20 20:28:33.369859
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hu = HPUXVirtualCollector()
    assert hu._platform == 'HP-UX', \
        'Analyze class HPUXVirtualCollector'

# Generated at 2022-06-20 20:28:41.501533
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import json
    # Create HPUXVirtual instance
    virtual = HPUXVirtual({})
    # Run get_virtual_facts method
    virtual_facts = virtual.get_virtual_facts()
    # Convert dict to JSON
    json_files = json.dumps(virtual_facts)
    # Assert sharp of json_files is 100
    assert len(json_files) is 100
    # Assert json_files contains virtualization_type
    assert 'virtualization_type' in virtual_facts
    # Assert json_files contains virtualization_role
    assert 'virtualization_role' in virtual_facts
    # Assert json_files contains virtualization_tech_guest
    assert 'virtualization_tech_guest' in virtual_facts
    # Assert json_files contains virtualization_tech_host

# Generated at 2022-06-20 20:28:43.045096
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual_obj = HPUXVirtual()
    assert hpux_virtual_obj.platform == 'HP-UX'


# Generated at 2022-06-20 20:28:45.919204
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hm = HPUXVirtualCollector()
    assert hm._platform == 'HP-UX'
    assert hm._fact_class == HPUXVirtual

# Generated at 2022-06-20 20:28:48.550572
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpu = HPUXVirtual({}, {}, [])
    assert hpu.virtualization_type == None
    assert hpu.virtualization_role == None


# Generated at 2022-06-20 20:28:51.845111
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    my_obj = HPUXVirtualCollector()
    my_obj._platform = 'HP-UX'
    my_obj._fact_class = HPUXVirtual



# Generated at 2022-06-20 20:28:52.520516
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-20 20:29:10.403130
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class AnsibleModuleMock():
        def __init__(self):
            self.params = {'virtual': 'guest'}
            self.run_command_count = 0
            self.running_undef_in_hpvm = False

        def run_command(self, cmd):
            if self.run_command_count == 0:
                self.run_command_count += 1
                if "vecheck" in cmd:
                    return 0, "This is an HP vPar", ""
                if "hpvminfo" in cmd:
                    return 0, "This is an HPVM guest", ""
            elif self.run_command_count == 1:
                self.run_command_count += 1
                if "vecheck" in cmd:
                    return 0, "This is an HP vPar", ""

# Generated at 2022-06-20 20:29:18.161727
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # _file_exists is mocked in order to make sure that the code checks for
    # each type of virtualization present on the platform.
    # If the code is changed, this test must be updated.
    virtual = HPUXVirtual({'file_exists': lambda x: x == "/usr/sbin/parstatus" or x == "/opt/hpvm/bin/hpvminfo" or x == "/usr/sbin/vecheck"})
    assert virtual.get_virtual_facts()['virtualization_tech_host'] == set()
    assert virtual.get_virtual_facts()['virtualization_tech_guest'] == {'HP nPar', 'HPVM IVM', 'HP vPar', 'HPVM vPar'}
    assert virtual.get_virtual_facts()['virtualization_type'] == 'guest'

# Generated at 2022-06-20 20:29:24.649833
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import tempfile
    import shutil

    vecheck_content = "Firmware updated to support VE\n"
    hpvminfo_content = "Running under HPVM vPar\n"
    parstatus_content = "Running under nPar\n"

    module = AnsibleModule(argument_spec={})
    tmpdir = tempfile.mkdtemp()
    # Add some files to the temp directory
    test_vecheck_file = os.path.join(tmpdir, "vecheck")
    test_hpvminfo_file = os.path.join(tmpdir, "hpvminfo")
    test_parstatus_file = os.path.join(tmpdir, "parstatus")
    with open(test_vecheck_file, "w") as f:
        f.write(vecheck_content)

# Generated at 2022-06-20 20:29:27.561372
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv._platform == 'HP-UX'


# Generated at 2022-06-20 20:29:33.999737
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    # check if ansible facts module is really installed:
    try:
        import ansible.modules.extras.system.facts as Facts
        c = HPUXVirtualCollector(Facts.AnsibleModule(
            dict(ANSIBLE_MODULE_ARGS={})
        ))
    except ImportError:
        # unit test executed directly, not through ansible
        import ansible.module_utils.facts.virtual.hpar as Virtual
        c = HPUXVirtualCollector(Virtual.AnsibleModule(
            dict(ANSIBLE_MODULE_ARGS={})
        ))
    assert c != None

# Generated at 2022-06-20 20:29:39.612036
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux_virtual import HPUXVirtual
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.virtual.hpux_virtual import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux_virtual import HPUXVirtualCollector
    import ansible.module_utils.facts.virtual.base
    import ansible.module_utils.facts.virtual.hpux_virtual
    import os
    import re

    m = HPUXVirtual()
    # Need to initialze the module
    m.module = ansible.module_utils.facts.virtual.base.AnsibleModule(
            argument_spec={},
            supports_check_mode=False)


# Generated at 2022-06-20 20:29:41.610144
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual({}, None)
    assert v.platform == 'HP-UX'

# Generated at 2022-06-20 20:29:43.048784
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector('module')
    assert collector.fact_class.platform == 'HP-UX'

# Generated at 2022-06-20 20:29:53.853631
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import collector

    # Create a dummy module
    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create a dummy class to mock the module
    test_class = HPUXVirtual(module)

    def mock_run_command(command, check_rc=False, close_fds=False, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, raise_err=True, environ_update=None, umask=None, encoding=None):
        filename = '/tmp/test_HPUXVirtual_get_virtual_facts'

# Generated at 2022-06-20 20:29:55.701848
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vc = HPUXVirtualCollector()
    assert vc._fact_class.platform == 'HP-UX'

# Generated at 2022-06-20 20:30:25.069852
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class ModuleStub():
        def __init__(self):
            self.run_command_called = 0
            self.rc = 0
            self.out = ''
            self.err = ''
        def run_command(self, command):
            self.run_command_called += 1
            return self.rc, self.out, self.err
    module_stub = ModuleStub()
    # Test if it returns the expected dictionary
    virtual = HPUXVirtual(module_stub)
    assert module_stub.run_command_called == 0
    assert virtual.get_virtual_facts() == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}
    # Test if it detects HP vPar
    module_stub.out = 'HP vPar'
    assert virtual.get_

# Generated at 2022-06-20 20:30:27.596538
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(dict())
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-20 20:30:34.873363
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_data = {
        'virtualization_type': 'guest',
        'virtualization_role': 'HP nPar',
        'virtualization_tech_guest': set(['HPVM IVM', 'HPVM vPar', 'HPVM', 'HP nPar']),
        'virtualization_tech_host': set(['HPVM IVM', 'HPVM vPar', 'HPVM'])
    }
    module = MockModule()
    hpvx_virtual = HPUXVirtual(module)
    assert hpvx_virtual.get_virtual_facts() == test_data



# Generated at 2022-06-20 20:30:40.179663
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule()
    module.run_command = MagicMock(return_value=(0, '', ''))
    h = HPUXVirtual(module)
    facts = h.get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP vPar'
    assert facts['virtualization_tech_guest'] == set(['HP vPar'])
    assert facts['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:30:42.162816
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpuxv = HPUXVirtual(dict())
    assert hpuxv.platform == 'HP-UX'

# Generated at 2022-06-20 20:30:48.033963
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtuals_hpux = HPUXVirtual()
    assert virtuals_hpux.platform == 'HP-UX'
    assert virtuals_hpux.get_virtual_facts() == {
        'virtualization_type': 'guest',
        'virtualization_role': 'HP vPar',
        'virtualization_tech_guest': set(['HP vPar']),
        'virtualization_tech_host': set()
    }


# Generated at 2022-06-20 20:30:53.039688
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import ansible.module_utils.facts.virtual.hpux.HPUXVirtual as hpux_virtual
    h = hpux_virtual.HPUXVirtual()

    class Module:
        def __init__(self):
            self.run_command = lambda x: (0, '', '')

    h.module = Module()
    assert 'virtualization_type' not in h.get_virtual_facts()

# Generated at 2022-06-20 20:30:59.673347
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Setup - create a fake ansible module for mocking 'module.run_command'.
    class MockModule(object):
        def __init__(self):
            self.params = {}

        def run_command(self, command):
            if command == '/usr/sbin/vecheck':
                return 0, 'Is a HP vPar', ''
            elif command == '/opt/hpvm/bin/hpvminfo':
                return 0, 'Running under HPVM guest', ''
            elif command == '/usr/sbin/parstatus':
                return 0, 'Is a HP nPar', ''

    mock_module = MockModule()
    hpux_virtual = HPUXVirtual(module=mock_module)
    virtual_facts = hpux_virtual.get_virtual_facts()


# Generated at 2022-06-20 20:31:00.690992
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert x._platform == 'HP-UX'
    assert x._fact_class == HPUXVirtual

# Generated at 2022-06-20 20:31:03.624622
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual({})
    assert virtual.get_virtual_facts() == {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-20 20:32:14.164810
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(dict())
    assert 'HP-UX' == hpux_virtual.platform
    assert 'HP-UX' == hpux_virtual.get_platform()
    assert hpux_virtual.virt_what('1') == 'HP-UX'
    assert hpux_virtual.virt_type('1') == 'HP-UX'
    assert hpux_virtual.virt_what('host') == 'HPVM host'
    assert hpux_virtual.virt_type('host') == 'HPVM host'



# Generated at 2022-06-20 20:32:15.427371
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux = HPUXVirtual()
    assert hpux.platform == 'HP-UX'

# Generated at 2022-06-20 20:32:19.131038
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert virtual_collector
    assert virtual_collector._platform == 'HP-UX'
    assert virtual_collector._fact_class == HPUXVirtual

# Generated at 2022-06-20 20:32:29.353312
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts import ModuleArgsParser
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    # Create a mock module
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.params = ModuleArgsParser(dict(), module).parse_args()

    # Create a mock ansible module class
    class MockAnsibleModule:
        def __init__(self, module_args, check_mode=False, dummy_arg=None):
            self.params = module_args
            self.check_mode = check_mode


# Generated at 2022-06-20 20:32:33.189666
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import VirtualInfoModule
    hpuxvirtual = HPUXVirtual(VirtualInfoModule())
    facts = hpuxvirtual.get_virtual_facts()

    # If there is no any virtualization technology found, the facts should
    # be an empty dictionary
    assert len(facts) == 0

# Generated at 2022-06-20 20:32:33.965218
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-20 20:32:39.603059
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import sys
    import json
    if sys.version_info.major > 2:
        from io import StringIO
    else:
        from StringIO import StringIO
    from ansible.module_utils.facts.virtual.hpu import HPUXVirtual
    from ansible.module_utils.basic import AnsibleModule

    out = StringIO()
    tmp_path = tempfile.mkdtemp()
    sys.path.append(tmp_path)
    os.chdir(tmp_path)
    open('/usr/sbin/vecheck', 'w').close()
    open('/opt/hpvm/bin/hpvminfo', 'w').close()
    open('/usr/sbin/parstatus', 'w').close()

# Generated at 2022-06-20 20:32:43.286866
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    facts = None
    module = None
    hv = HPUXVirtualCollector(module)
    assert isinstance(hv, VirtualCollector)
    assert hv.platform == "HP-UX"
    assert hv.facts is None
    assert hv.module is None

# Generated at 2022-06-20 20:32:53.320863
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_class = HPUXVirtual()
    test_class.module = MockModule()
    # HPVM host
    test_class.module.run_command.return_value = (0, "Running HPVM host.", "")
    result = test_class.get_virtual_facts()
    assert result['virtualization_tech_host'] == set(['HPVM'])
    assert result['virtualization_tech_guest'] == set()
    assert result['virtualization_type'] == 'host'
    assert result['virtualization_role'] == 'HPVM'

    # HPVM guest
    test_class.module.run_command.return_value = (0, "Running HPVM guest.", "")
    result = test_class.get_virtual_facts()
    assert result['virtualization_tech_host'] == set()
    assert result

# Generated at 2022-06-20 20:33:02.702462
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import tempfile
    import os
    name = os.path.basename(__file__)
    name = name[0:name.rfind('.')]
    mod_path = os.path.join(os.path.dirname(__file__), 'test')
    tmp_path = tempfile.mkdtemp(prefix='ansible-local-%s' % name)

    module = type(sys)('test_module')
    module.params = {}
    module.run_command = lambda *cmd, **kwargs: (0, 'running', '')
    module.__file__ = os.path.join(mod_path, 'test_%s.py' % name)
    module.tmpdir = tmp_path
    module.exit_json = lambda **kwargs: True


# Generated at 2022-06-20 20:33:41.096031
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    c = HPUXVirtualCollector()
    assert c.get_facts() == {}
    assert c._platform == 'HP-UX'
    assert c._fact_class == HPUXVirtual

# Generated at 2022-06-20 20:33:43.922875
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual('')
    assert v.platform == 'HP-UX'


# Generated at 2022-06-20 20:33:55.136184
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    facts = {"ansible_fake": "fake", "ansible_other_fake": "other_fake"}

    class FakeModule:
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['!all', 'virtual']

        def run_command(self, command):
            if command == "/usr/sbin/vecheck":
                return 0, "HP vPar is running", ""
            elif command == "/opt/hpvm/bin/hpvminfo":
                return 0, "Running HPVM guest", ""
            else:
                return 1, "", ""

    class FakeFacts:
        def __init__(self):
            self.facts = facts

    class FakeAnsibleModule:
        def __init__(self):
            self.run_command = FakeModule

# Generated at 2022-06-20 20:33:59.348410
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual({})
    assert v.platform == 'HP-UX'
    assert v.virtualization_type is None
    assert v.virtualization_role is None
    assert v.virtualization_technologies == set()



# Generated at 2022-06-20 20:34:04.511234
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpuxvirtual = HPUXVirtual(module=None)
    assert hpuxvirtual.platform == 'HP-UX'
    assert hpuxvirtual.virtualization_type == 'host'
    assert hpuxvirtual.virtualization_role == 'HPVM'
    assert hpuxvirtual.virtualization_tech_guest == set(['HPVM'])
    assert hpuxvirtual.virtualization_tech_host == set()

# Generated at 2022-06-20 20:34:15.878707
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class ModuleStub:
        def run_command(self, cmd):
            if cmd == "/usr/sbin/vecheck":
                return 0, '', ''
            elif cmd == "/opt/hpvm/bin/hpvminfo":
                return 0, 'Running HPVM guest', ''
            elif cmd == "/usr/sbin/parstatus":
                return 0, '', ''

    class HPUXVirtualStub(HPUXVirtual):
        def __init__(self, module):
            self.module = module

    hpux_virtual_stub = HPUXVirtualStub(ModuleStub())
    virtual_facts = hpux_virtual_stub.get_virtual_facts()

# Generated at 2022-06-20 20:34:18.852519
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual()
    assert virtual_obj.platform == 'HP-UX'

# Generated at 2022-06-20 20:34:21.296078
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    c = HPUXVirtualCollector()
    assert c.platform == 'HP-UX'
    assert c._fact_class == HPUXVirtual



# Generated at 2022-06-20 20:34:23.585977
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpux_virtual_collector = HPUXVirtualCollector()
    assert hpux_virtual_collector

# Generated at 2022-06-20 20:34:28.808843
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """Test module for get_virtual_facts method."""

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create instance of HPUXVirtual
    hpuxvirtual = HPUXVirtual(module)

    # Check if the method get_virtual_facts exists
    assert hasattr(hpuxvirtual, 'get_virtual_facts')

    # Test method get_virtual_facts of class HPUXVirtual
    hpuxvirtual.get_virtual_facts()

# Generated at 2022-06-20 20:35:42.153259
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    obj = HPUXVirtual(None)
    assert obj

# Generated at 2022-06-20 20:35:46.240074
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    Constructor of class HPUXVirtual is tested
    """
    virtual = HPUXVirtual(None)
    assert set(['virtualization_type', 'virtualization_role', 'virtualization_tech_guest',
                'virtualization_tech_host']) == set(virtual.data.keys())

# Generated at 2022-06-20 20:35:48.108005
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv._fact_class == HPUXVirtual
    assert hv._platform == 'HP-UX'

# Generated at 2022-06-20 20:35:52.312684
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """
    Test the constructor of class HPUXVirtualCollector
    """
    hpux_virtual_collector = HPUXVirtualCollector('TestModule')
    assert hpux_virtual_collector.__class__.__name__ == 'HPUXVirtualCollector'
    assert hpux_virtual_collector._platform == 'HP-UX'
    assert hpux_virtual_collector._fact_class == HPUXVirtual

# Generated at 2022-06-20 20:35:57.619111
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import sys
    import ansible.module_utils.facts.virtual.hpux.hpux_virtual


# Generated at 2022-06-20 20:36:00.568498
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv.platform == 'HP-UX'
    assert hv._fact_class == HPUXVirtual


# Generated at 2022-06-20 20:36:06.684305
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hypervisor = HPUXVirtual(dict(module=dict()))
    assert hypervisor.platform == 'HP-UX'
    assert hypervisor.get_virtual_facts() == {
        'virtualization_type': 'guest',
        'virtualization_role': 'HP vPar',
        'virtualization_tech_guest': {'HP vPar'},
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-20 20:36:09.924401
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector._platform == 'HP-UX'
    assert HPUXVirtualCollector._fact_class == HPUXVirtual
    assert HPUXVirtualCollector.plat_spec_funcs == []

# Generated at 2022-06-20 20:36:13.302525
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    o = HPUXVirtual(dict())
    assert isinstance(o, Virtual)
    assert o.platform == 'HP-UX'
    assert o.get_virtual_facts() == dict(virtualization_tech_guest=set(), virtualization_tech_host=set())

# Generated at 2022-06-20 20:36:21.525573
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import os
    import tempfile
    from ansible.module_utils.facts.virtual.hpux.HPUXVirtual import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux.HPUXVirtual import get_virtual_facts
    from ansible.module_utils.facts.virtual.hpux.HPUXVirtual import _get_virtual_facts_from_parstatus
    from ansible.module_utils.facts.virtual.hpux.HPUXVirtual import _get_virtual_facts_from_hpvminfo
    from ansible.module_utils.facts.virtual.hpux.HPUXVirtual import _get_virtual_facts_from_vecheck

    hp_ux_virtual = HPUXVirtual()
    hp_ux_virtual.module = DummyAnsibleModule()
