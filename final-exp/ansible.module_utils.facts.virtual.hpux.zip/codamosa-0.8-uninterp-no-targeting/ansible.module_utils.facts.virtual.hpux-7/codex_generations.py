

# Generated at 2022-06-20 20:27:28.292514
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = {'run_command': HPUXVirtual.run_command, 'module_utils': {'basic': {'AnsibleModule': {'fail_json': HPUXVirtual.exit}}} }
    fake_hpxvpar_comamnd_out = "fake output from vecheck"
    fake_hpxvm_comamnd_out = "fake output from hpvminfo"
    fake_hpxnpar_comamnd_out = "fake output from parstatus"
    # test vecheck
    # vecheck succeed and return empty output
    HPUXVirtual.run_command = lambda self: (0, '', '')
    virtual = HPUXVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert 'virtualization_type' not in virtual_facts
    # vecheck succeed and return

# Generated at 2022-06-20 20:27:33.474904
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import get_virtual_facts
    from ansible.module_utils.facts import FactCollector
    import os
    import mock
    import sys
    import types

    fact_collector = FactCollector()
    hpuxVirtual = HPUXVirtual(fact_collector)

    # Test running in HPVM-host.
    hpvminfo_result = '''
Virtual Machine Information
---------------------------
Name                        State            Memory
---------------------------
hpvm_testvm                 Running          1024 MB
'''

# Generated at 2022-06-20 20:27:34.866677
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    Create a instance of HPUXVirtual.
    """
    virtual_collector = HPUXVirtual()

# Generated at 2022-06-20 20:27:38.204941
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(dict())
    assert hv.platform == 'HP-UX'
    assert hv.get_virtual_facts() is None


# Generated at 2022-06-20 20:27:39.601722
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv


# Generated at 2022-06-20 20:27:46.461790
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    m_ansible_module = AnsibleModule(argument_spec=module.argument_spec)
    virtual_facts = HPUXVirtual(m_ansible_module)
    out_dict = virtual_facts.get_virtual_facts()

    # Test with HP vPar
    m_ansible_module = AnsibleModule(argument_spec=module.argument_spec)
    virtual_facts = HPUXVirtual(m_ansible_module)
    rc = '/usr/sbin/vecheck'
    out = 'HP-UX Virtual Partition Manager'
    err = ''
    vecheck_ret = (0, out, err)
    m_ansible_module.run_command = MagicMock(return_value=vecheck_ret)

# Generated at 2022-06-20 20:27:55.147865
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual._common import AnsibleModuleMock
    from ansible.module_utils.facts.virtual._common import run_command_mock
    from ansible.module_utils.facts.virtual._common import get_platform_mock

    # get_platform_mock
    platform = 'HP-UX'
    get_platform_mock.return_value = platform

    # run_command_mock
    vecheck_cmd = {
        '/usr/sbin/vecheck': (0, 'HP vPar', ''),
        '/opt/hpvm/bin/hpvminfo': (0, 'Running HPVM vPar', ''),
        '/usr/sbin/parstatus': (0, 'HP nPar', ''),
    }

# Generated at 2022-06-20 20:28:02.449933
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # pylint: disable=import-error
    from ansible.module_utils.facts.processors.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.processors.virtual.hpux import HPUXVirtualCollector
    import ansible.module_utils.facts.virtual.hpux as hpux_lib
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.six import PY3
    hpux_virtual_obj = HPUXVirtual()
    host_lines = []
    guest_lines = []
    expected_virtual_facts = {}

    host_lines = get_file_lines('/opt/hpvm/bin/hpvminfo', host_lines)


# Generated at 2022-06-20 20:28:04.603454
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    my_obj = HPUXVirtualCollector()
    assert my_obj.platform == 'HP-UX'
    assert my_obj._fact_class == HPUXVirtual

# Generated at 2022-06-20 20:28:08.969395
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """Unit test for method get_virtual_facts of class HPUXVirtual"""

    hp_virtual = HPUXVirtual({})

    if hp_virtual._platform != 'HP-UX':
        raise AssertionError("Platform of Virtual class expected to be HP-UX")
    if hp_virtual.get_virtual_facts()['virtualization_type'] != 'guest':
        raise AssertionError("Virtualization type expected to be guest")

# Generated at 2022-06-20 20:28:23.241722
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    This Unit test mocks a HP-UX host and checks virtual facts
    """
    # Mocked class
    class Module(object):
        def __init__(self):
            self.run_command = self.mock_run_command

        @staticmethod
        def mock_run_command(command):
            """
            Mocked method run_command
            """
            if command == "/usr/sbin/vecheck":
                if os.path.exists(command):
                    return 0, "is HP vPar", None
                else:
                    return 255, "", None
            elif command == "/opt/hpvm/bin/hpvminfo":
                if os.path.exists(command):
                    return 0, "Running HPVM vPar", None
                else:
                    return 255, "", None

# Generated at 2022-06-20 20:28:25.914149
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hp = HPUXVirtual()
    if hp.platform != 'HP-UX':
        raise Exception("Platform should be HP-UX")


# Generated at 2022-06-20 20:28:28.981896
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert isinstance(hv, VirtualCollector)
    assert hv.platform == 'HP-UX'
    assert hv._fact_class == HPUXVirtual
    assert hv._platform == 'HP-UX'


# Generated at 2022-06-20 20:28:32.833743
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv
    assert hv._platform == 'HP-UX'
    assert hv._fact_class == HPUXVirtual

# Generated at 2022-06-20 20:28:34.040017
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert isinstance(HPUXVirtualCollector(), HPUXVirtualCollector)

# Generated at 2022-06-20 20:28:35.677482
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    c = HPUXVirtualCollector()
    assert c.platform == 'HP-UX'

# Generated at 2022-06-20 20:28:42.980372
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    # Create an instance of class HPUXVirtual
    virtual = HPUXVirtual()

    # Create an instance of class ModuleFake
    module_fake = ModuleFake()

    # Set the command_warnings in the module_fake object
    module_fake.command_warnings = [
        "[Errno 2] No such file or directory: '/usr/sbin/vecheck'",
        "[Errno 2] No such file or directory: '/opt/hpvm/bin/hpvminfo'",
        "[Errno 2] No such file or directory: '/usr/sbin/parstatus'"
    ]

    # Set the command_results in the module_fake object

# Generated at 2022-06-20 20:28:54.154647
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(
        )
    )

    if not os.path.exists('/usr/sbin/vecheck'):
        pytest.skip("/usr/sbin/vecheck not found on system")
    if not os.path.exists('/opt/hpvm/bin/hpvminfo'):
        pytest.skip("/opt/hpvm/bin/hpvminfo not found on system")
    if not os.path.exists('/usr/sbin/parstatus'):
        pytest.skip("/usr/sbin/parstatus not found on system")

    hpu = HPUXVirtual(module)
    facts = hpu.get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'

# Generated at 2022-06-20 20:29:06.012974
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    vecheck_out = ' Running HPVM vPar or vecheck -h for more information'
    hpvminfo_out = 'Running HPVM vPar or vecheck -h for more information'
    parstatus_out = 'Running HPVM vPar or vecheck -h for more information'

    hpux_virtual = HPUXVirtual({'module': {'run_command': mock_run_command}},
                               None, 0)
    # Test with no virtualization software on host
    virtual_facts = hpux_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] is None
    assert virtual_facts['virtualization_role'] is None
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_tech_guest'] == set()

    # Test with HP

# Generated at 2022-06-20 20:29:11.749152
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # There is no way to test this class in isolation if not by mocking os.path.exists.
    # The class in fact relies heavily on what is installed on the system.
    # The test here will only verify the proper behavior of the class when no virtualization is found.
    h = HPUXVirtual({})
    h.module = MockAnsibleModule()
    h.module.run_command = MockRunCommand()
    v = h.get_virtual_facts()
    assert v['virtualization_type'] == 'NA'
    assert v['virtualization_type_id'] == 'NA'
    assert v['virtualization_role'] == 'NA'
    assert v['virtualization_role_id'] == 'NA'
    assert v['virtualization_tech_guest'] == set()

# Generated at 2022-06-20 20:29:27.748770
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    try:
        virtual_obj = HPUXVirtualCollector()
    except:
        raise AssertionError("Expected result was not obtained")


# Generated at 2022-06-20 20:29:29.086751
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert x.virtual._platform == 'HP-UX'

# Generated at 2022-06-20 20:29:32.401363
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=[], type='list'),
        }
    )
    instance = HPUXVirtual(module=module)

    assert instance.get_virtual_facts() == None

# Generated at 2022-06-20 20:29:33.999796
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpvm = HPUXVirtual({})
    assert hpvm.platform == 'HP-UX'


# Generated at 2022-06-20 20:29:34.725024
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-20 20:29:37.138100
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    from ansible.module_utils.facts.virtual.hpar import HPUXVirtualCollector
    hvirt = HPUXVirtualCollector()
    assert hvirt.platform == 'HP-UX'
    assert hvirt.fact_class.platform == 'HP-UX'


# Generated at 2022-06-20 20:29:39.834381
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv.platform == 'HP-UX'
    assert hv.fact_class == HPUXVirtual

# Generated at 2022-06-20 20:29:43.375060
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    # Create a new instance of the class.
    x = HPUXVirtualCollector()
    # Test the platform property.
    assert x.platform == 'HP-UX'
    # Test the fact_class property.
    assert x.fact_class == HPUXVirtual

# Generated at 2022-06-20 20:29:54.900936
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpu_virtual import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpu_virtual import Virtual

    module = FakeModule()
    v = HPUXVirtual(module)
    v.module.run_command = FakeRunCommand(vpars=True, ivms=False, ivm_host=False)
    facts = v.get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP vPar'
    assert 'HP vPar' in facts['virtualization_tech_guest']

    v.module.run_command = FakeRunCommand(vpars=True, ivms=False, ivm_host=False)
    facts = v.get_virtual_facts()

# Generated at 2022-06-20 20:29:57.535441
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    l = HPUXVirtualCollector()
    assert l._fact_class == HPUXVirtual
    assert l._platform == 'HP-UX'

# Generated at 2022-06-20 20:30:12.797089
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual({})
    assert v.platform == 'HP-UX'


# Generated at 2022-06-20 20:30:17.807060
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    hpux_virtual = HPUXVirtual({})
    test_facts = hpux_virtual.get_virtual_facts()
    expected_facts = {'virtualization_type': 'guest',
                      'virtualization_role': 'HPVM',
                      'virtualization_tech_guest': set(['HPVM']),
                      'virtualization_tech_host': set()}
    assert test_facts == expected_facts

# Generated at 2022-06-20 20:30:24.558389
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict()
    )

    # Set up a class instance
    hpux_virtual = HPUXVirtual(module)
    virtual_facts = hpux_virtual.get_virtual_facts()

    # Perform assertions
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP nPar'
    assert 'HP nPar' in virtual_facts['virtualization_tech_guest']
    assert 'HP vPar' not in virtual_facts['virtualization_tech_guest']
    assert virtual_facts['virtualization_tech_host'] == set()



# Generated at 2022-06-20 20:30:27.911533
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert virtual_collector._platform == 'HP-UX'
    assert virtual_collector._fact_class.platform == 'HP-UX'


# Generated at 2022-06-20 20:30:29.980070
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    fact_class = HPUXVirtualCollector()
    assert fact_class._fact_class == HPUXVirtual
    assert fact_class._platform == 'HP-UX'

# Generated at 2022-06-20 20:30:33.506013
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    # Test with no arguments
    x = HPUXVirtualCollector()
    assert (x._fact_class == HPUXVirtual)
    assert (x._platform == 'HP-UX')

# Generated at 2022-06-20 20:30:35.475726
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """unit test for class HPUXVirtualCollector
    """
    collector = HPUXVirtualCollector()
    assert collector._fact_class == HPUXVirtual

# Generated at 2022-06-20 20:30:41.644444
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    fake_module = None
    virtual_facts = {}
    hpux_virtual = HPUXVirtual(fake_module)
    virtual_facts = hpux_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] in [None, 'guest', 'host']
    assert virtual_facts['virtualization_role'] in [None, 'HP vPar', 'HPVM vPar', 'HP nPar', 'HPVM IVM']
    assert isinstance(virtual_facts['virtualization_tech_host'], set)
    assert isinstance(virtual_facts['virtualization_tech_guest'], set)

# Generated at 2022-06-20 20:30:43.901946
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual(None)
    assert h.platform == 'HP-UX'
    assert h.guest_tech is None
    assert h.host_tech is None


# Generated at 2022-06-20 20:30:49.719237
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    fake_module = FakeAnsibleModule()
    fake_module.run_command = FakeRunCommand()

    class FakeSysModule:
        def __init__(self):
            pass

        def getfilesystemencoding(self):
            return 'UTF-8'

    fake_sys = FakeSysModule()
    fake_module.sys = fake_sys

    virtual_collector = HPUXVirtualCollector(fake_module)
    virtual_collector.get_virtual_facts()
    assert virtual_collector.platform == 'HP-UX'
    assert virtual_collector._fact_class.platform == 'HP-UX'



# Generated at 2022-06-20 20:31:06.990593
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual({})
    assert virtual
    assert virtual.platform == 'HP-UX'


# Generated at 2022-06-20 20:31:08.585860
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt_info = HPUXVirtual()
    assert virt_info.platform == 'HP-UX'


# Generated at 2022-06-20 20:31:17.456951
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import DefaultCollector
    from io import BytesIO

    # Create a mock module
    test_module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    # Create an instance of HPUXVirtual
    hpux_virtual_ins = HPUXVirtual(module=test_module)
    # Create a mock subprocess
    hp_stdout = BytesIO(b'Running in a vPar')

    hpvm_stdout = BytesIO(b'Running in an HPVM guest')
    hpvm_stdout2 = BytesIO(b'Running in an HPVM vPar')
    hpvm_stdout3 = BytesIO(b'Running in an HPVM host')
   

# Generated at 2022-06-20 20:31:26.000191
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible_collections.ansible.community.tests.unit.compat.mock import Mock
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch

    class TestModule():
        pass

    test_module = TestModule()
    test_module.run_command = Mock(return_value=(0, 'out', 'err'))
    test_module.run_command.side_effect = [(0, 'out1', 'err1'), (0, 'out2', 'err2'), (0, 'out3', 'err3')]

    with patch('os.path.exists') as mock_exists:
        mock_exists.side_effect = [True, True, True]
        HPUXVirtualClass = HPUXVirtual(test_module)

# Generated at 2022-06-20 20:31:28.614693
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpuxvirtual = HPUXVirtual(dict())
    assert hpuxvirtual.virtual_collector_class == HPUXVirtualCollector


# Generated at 2022-06-20 20:31:29.399169
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-20 20:31:31.037875
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_instance = HPUXVirtual()
    if not isinstance(virtual_instance, Virtual):
        raise AssertionError()


# Generated at 2022-06-20 20:31:33.332998
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector()
    assert collector.platform == 'HP-UX'
    assert collector.fact_class == HPUXVirtual

# Generated at 2022-06-20 20:31:38.438616
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    # Unit test use of property -> platform
    assert HPUXVirtualCollector._platform == 'HP-UX'

    # Unit test use of property -> fact_class
    assert HPUXVirtualCollector._fact_class.__name__ == 'HPUXVirtual'


# Generated at 2022-06-20 20:31:42.228178
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpx_virtual = HPUXVirtualCollector(None)
    assert hpx_virtual.platform == 'HP-UX'
    assert hpx_virtual.fact_class.platform == 'HP-UX'

# Generated at 2022-06-20 20:31:59.132820
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.get_virtual_facts() == {}

# Generated at 2022-06-20 20:32:04.223016
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    virt = HPUXVirtual(module)
    facts = virt.get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP vPar'
    assert facts['virtualization_tech_guest'] == set(['HP vPar'])

# Generated at 2022-06-20 20:32:06.383457
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    m = HPUXVirtual({})
    assert m.get_virtual_facts()['virtualization_type'] == 'guest'
    assert m.get_virtual_facts()['virtualization_role'] == 'HP vPar'

# Generated at 2022-06-20 20:32:15.015076
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import os

    module = FakeAnsibleModule()
    virtual = HPUXVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert ('virtualization_type' in virtual_facts) == True
    assert ('virtualization_role' in virtual_facts) == True
    assert ('virtualization_tech_guest' in virtual_facts) == True
    assert ('virtualization_tech_host' in virtual_facts) == True
    os.unlink('/usr/sbin/vecheck')
    os.unlink('/opt/hpvm/bin/hpvminfo')
    os.unlink('/usr/sbin/parstatus')
    print('test_HPUXVirtual_get_virtual_facts OK')



# Generated at 2022-06-20 20:32:17.949016
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    v = HPUXVirtual(dict(module=dict()))
    v.module.run_command = lambda x: (0, "", "")
    v.get_virtual_facts()


# Generated at 2022-06-20 20:32:19.995500
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-20 20:32:22.828107
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    unit test for constructor of class HPUXVirtual
    """
    hpux_virtual = HPUXVirtual(dict())
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-20 20:32:32.232354
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    HPUXVirtualCollector._module = None

    # Create instance of class Virtual
    test_virtual = HPUXVirtual()

    # set _module
    test_virtual._module = {'run_command': test_virtual.run_command}

    # Execute method get_virtual_facts, save result to result
    result = test_virtual.get_virtual_facts()

    # Assert result
    assert result['virtualization_tech_guest'] == {'HPVM', 'HP vPar', 'HP nPar'}
    assert result['virtualization_tech_host'] == {'HPVM'}
    assert result['virtualization_type'] == 'host'
    assert result['virtualization_role'] == 'HPVM'

# Generated at 2022-06-20 20:32:33.061967
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert x


# Generated at 2022-06-20 20:32:35.517703
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vc = HPUXVirtualCollector()
    assert vc.platform == 'HP-UX'
    assert vc._platform == 'HP-UX'
    assert vc._fact_class == HPUXVirtual


# Generated at 2022-06-20 20:32:50.228253
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector()
    assert collector.platform == 'HP-UX'
    assert HPUXVirtualCollector._platform == 'HP-UX'
    assert isinstance(collector.get_virtual_facts(), HPUXVirtual)

# Generated at 2022-06-20 20:32:58.427025
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpuxtest.regression_fixture import mock_command, mock_module

    # Construct input data
    data = dict()

    # Construct expected result
    expected_result = dict()
    expected_result['virtualization_type'] = 'guest'
    expected_result['virtualization_role'] = 'HP vPar'
    expected_result['virtualization_tech_guest'] = set(['HP vPar'])
    expected_result['virtualization_tech_host'] = set()

    # Construct mock_module and mock_command objects
    module = mock_module(parse_argv=False)
    command = mock_command(stdout='.*Running.*HPVM guest.*', rc=0)



# Generated at 2022-06-20 20:33:03.457247
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    my_obj = HPUXVirtual()
    # Return a fact_subset and an empty string for virtualization_role
    my_obj.module.run_command.return_value = (0, 'out', 'err')
    my_obj.generator.get_virtual_facts.return_value = ({'something': 'something_else'}, '')
    assert my_obj.get_virtual_facts() == {'something': 'something_else',
                                          'virtualization_role': ''}

# Generated at 2022-06-20 20:33:08.909272
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # initialize the test
    testobj = HPUXVirtual()
    testobj.module = FakeAnsibleModule()

    # obtain virtual facts
    virtual_facts = testobj.get_virtual_facts()

    # verify virtual facts
    assert virtual_facts['virtualization_type'] in ['host', 'guest']
    assert virtual_facts['virtualization_role'] in ['HP vPar', 'HPVM vPar', 'HPVM IVM', 'HP nPar']



# Generated at 2022-06-20 20:33:14.811683
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    assert HPUXVirtualCollector.__name__ == 'HPUXVirtualCollector'
    assert HPUXVirtualCollector._platform == 'HP-UX'
    assert issubclass(HPUXVirtualCollector, Collector)

# Generated at 2022-06-20 20:33:18.864849
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpx = HPUXVirtual()

    assert hpx.platform == 'HP-UX'
    assert hpx.get_virtual_facts() == dict(virtualization_role='guest',
                                           virtualization_type='guest',
                                           virtualization_tech_host=set(),
                                           virtualization_tech_guest=set(['HP nPar']))

# Generated at 2022-06-20 20:33:20.556655
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert x.platform == 'HP-UX'
    assert x._fact_class == HPUXVirtual

# Generated at 2022-06-20 20:33:25.099928
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # execute the code to test
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    virtual_facts = HPUXVirtual().get_virtual_facts()

    # assert the result
    assert virtual_facts['virtualization_type'] == 'host'

# Generated at 2022-06-20 20:33:28.932133
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert set(hv.get_supported_facts()) == set([
        'virtualization_type',
        'virtualization_role',
        'virtualization_tech_guest',
        'virtualization_tech_host'])


# Generated at 2022-06-20 20:33:39.948524
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    if os.path.exists('/usr/sbin/vecheck'):
        guest_tech = set()
        guest_tech.add('HP vPar')
        assert HPUXVirtual(None).get_virtual_facts() == {'virtualization_type': 'guest',
                                                         'virtualization_role': 'HP vPar',
                                                         'virtualization_tech_guest': guest_tech,
                                                         'virtualization_tech_host': set()}
    if os.path.exists('/opt/hpvm/bin/hpvminfo'):
        guest_tech = set()
        guest_tech.add('HPVM vPar')

# Generated at 2022-06-20 20:34:00.843857
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    h = HPUXVirtualCollector()
    assert h.get_virtual_facts()['ansible_virtualization_type'] == 'guest'

# Generated at 2022-06-20 20:34:06.065000
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    my_v = HPUXVirtual()
    my_v.module.params = {'gather_subset': '!all,!any'}
    my_v.module.run_command = lambda args, **kwargs: (1, '', '')
    my_v.module.run_command = lambda args, **kwargs: (0, '', '')
    vf = my_v.get_virtual_facts()
    assert 'virtualization_tech_guest' in vf
    assert 'virtualization_tech_host' in vf
    assert vf['virtualization_tech_guest'] == set()
    assert vf['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:34:12.429747
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    hpuxvirtual = HPUXVirtual(module)

    assert hpuxvirtual.get_virtual_facts() == {
        'virtualization_tech_guest': set(['HP vPar']),
        'virtualization_type': 'guest',
        'virtualization_role': 'HP vPar',
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-20 20:34:15.927072
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    virtual_facts = {}

    if_class = HPUXVirtual()
    virtual_facts = if_class.get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-20 20:34:20.257853
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert hasattr(HPUXVirtualCollector, '_platform') and HPUXVirtualCollector._platform == 'HP-UX'
    assert issubclass(HPUXVirtualCollector._fact_class, HPUXVirtual)

# Generated at 2022-06-20 20:34:21.070286
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual()


# Generated at 2022-06-20 20:34:24.943431
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    facts = dict()
    virtual_collector = HPUXVirtualCollector(facts, None)
    assert virtual_collector._platform == 'HP-UX'
    assert virtual_collector._fact_class == HPUXVirtual


# Generated at 2022-06-20 20:34:26.080077
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-20 20:34:26.887510
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-20 20:34:30.451049
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    Test class HPUXVirtual.
    """
    obj = HPUXVirtual()
    assert obj.platform == 'HP-UX'

# Generated at 2022-06-20 20:35:27.758706
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    import mock
    test_class = HPUXVirtualCollector()
    assert isinstance(test_class, VirtualCollector)
    assert test_class._platform == 'HP-UX'
    assert test_class._fact_class == HPUXVirtual



# Generated at 2022-06-20 20:35:29.544898
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual({})

    assert h.platform == 'HP-UX'
    assert h.virtual_facts == {}



# Generated at 2022-06-20 20:35:31.613079
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector._fact_class == HPUXVirtual
    assert HPUXVirtualCollector._platform == 'HP-UX'

# Generated at 2022-06-20 20:35:35.667666
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpx_virtual = HPUXVirtual(None)
    assert hpx_virtual.platform == "HP-UX"
    assert hpx_virtual.get_virtual_facts()
    assert hpx_virtual.get_virtual_facts()['virtualization_type'] == 'guest'
    assert hpx_virtual.get_virtual_facts()['virtualization_role'] == 'HP vPar'



# Generated at 2022-06-20 20:35:36.756784
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    c = HPUXVirtualCollector()
    assert c.fact_class.platform == 'HP-UX'

# Generated at 2022-06-20 20:35:39.000271
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt = HPUXVirtual({'module_setup': {'filter': 'ansible.module_utils.facts.virtual.hpux.HPUXVirtual'}})
    assert virt.module_setup['filter'] == 'ansible.module_utils.facts.virtual.hpux.HPUXVirtual'


# Generated at 2022-06-20 20:35:40.415846
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-20 20:35:50.098992
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import os
    import tempfile
    from ansible.module_utils.facts.virtual import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector

    mock_module = MockModule()

    def fake_run_command(args):
        if args == "/usr/sbin/vecheck" and os.path.exists('/usr/sbin/vecheck'):
            return 0, "Running in HP vPar", ''
        if args == "/opt/hpvm/bin/hpvminfo" and os.path.exists('/opt/hpvm/bin/hpvminfo'):
            return 0, "Running in HPVM guest", ''

# Generated at 2022-06-20 20:35:56.215734
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    '''
    Unit test for method get_virtual_facts of class HPUXVirtual
    '''
    import sys

    # Python 2.6 support
    if sys.version_info[0:2] != (2, 6):
        import unittest

    else:
        try:
            import unittest2 as unittest
        except ImportError:
            import unittest

    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual

    class AnsibleModuleMock(object):
        def __init__(self, **kwargs):
            for key, val in iteritems(kwargs):
                setattr(self, key, val)


# Generated at 2022-06-20 20:36:06.994580
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(ArgumentSpec())
    # Mock class HP-UXVirtual with static method mocks.
    class HP_UXVirtual():
        @staticmethod
        def get_virtual_facts():
            return {
                'virtualization_type': 'none',
                'virtualization_role': 'none',
                'virtualization_tech_guest': set([]),
                'virtualization_tech_host': set([])
            }

    # Mock class AnsibleModule with static method mocks