

# Generated at 2022-06-20 20:27:25.122735
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_platform = HPUXVirtual({})
    assert virtual_platform.platform == 'HP-UX'
    assert virtual_platform.get_virtual_facts() == {}

# Generated at 2022-06-20 20:27:27.714986
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    facts = dict()
    virtual_collector = HPUXVirtualCollector(facts=facts, module=None)
    assert type(virtual_collector).__name__ == 'HPUXVirtualCollector'

# Generated at 2022-06-20 20:27:31.248981
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    d = HPUXVirtualCollector(None)
    assert d._platform == 'HP-UX'
    assert d._fact_class == HPUXVirtual


# Generated at 2022-06-20 20:27:32.450184
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt = HPUXVirtual(dict())
    assert virt.platform == 'HP-UX'

# Generated at 2022-06-20 20:27:34.376020
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert x._platform == 'HP-UX'
    assert x._fact_class.__name__ == 'HPUXVirtual'


# Generated at 2022-06-20 20:27:37.148047
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv.platform == 'HP-UX'
    assert hv.fact_class == HPUXVirtual

# Generated at 2022-06-20 20:27:40.964953
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    v = HPUXVirtualCollector()
    assert isinstance(v, VirtualCollector)
    assert isinstance(v, HPUXVirtualCollector)
    assert v._fact_class == HPUXVirtual
    assert v._platform == 'HP-UX'


# Generated at 2022-06-20 20:27:47.049988
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    try:
        import ansible.module_utils.facts.virtual.hpar
    except:
        pass
    AnsibleModule = VirtualCollector.get_ansible_module_mock()
    if AnsibleModule is not None:
        module = AnsibleModule.params
        virtual = HPUXVirtual(module)
        virtual_facts = virtual.get_virtual_facts()
        if 'virtualization_tech_guest' in virtual_facts and 'virtualization_tech_host' in virtual_facts:
            assert virtual_facts['virtualization_tech_guest'] == ['HP vPar']
            assert virtual_facts['virtualization_tech_host'] == []
            assert virtual_facts['virtualization_type'] == 'guest'
            assert virtual_facts['virtualization_role'] == 'HP vPar'

# Generated at 2022-06-20 20:27:48.217815
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert isinstance(HPUXVirtual(), HPUXVirtual)

# Generated at 2022-06-20 20:27:53.492705
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpx_virtual = HPUXVirtual()
    assert hpx_virtual.get_virtual_facts()['virtualization_tech_guest'] == set()
    assert hpx_virtual.get_virtual_facts()['virtualization_tech_host'] == set()
    assert hpx_virtual.get_virtual_facts()['virtualization_role'] is None
    assert hpx_virtual.get_virtual_facts()['virtualization_type'] == 'host'

# Generated at 2022-06-20 20:28:04.141549
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux = HPUXVirtual()
    assert hpux.virtualization_type == 'guest'
    assert hpux.virtualization_role == 'HP nPar'

# Generated at 2022-06-20 20:28:06.015782
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector()
    assert collector._fact_class == HPUXVirtual
    assert collector._platform == 'HP-UX'


# Generated at 2022-06-20 20:28:08.354636
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # path to the module that produces the virtual facts
    hpux_virtual_module = HPUXVirtual()
    # check if some important attributes are set
    assert hpux_virtual_module.platform == 'HP-UX'

# Generated at 2022-06-20 20:28:13.955253
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpar import HPUXVirtual
    hpar_virtual = HPUXVirtual({'module': None})
    assert hpar_virtual.get_virtual_facts() == {'virtualization_type': 'guest', 
                                                'virtualization_role': 'HP vPar', 
                                                'virtualization_tech_guest': set(['HP vPar']), 
                                                'virtualization_tech_host': set([])
                                                }


# Generated at 2022-06-20 20:28:15.577376
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict())
    assert virtual.data == dict()
    assert virtual.platform == 'HP-UX'


# Generated at 2022-06-20 20:28:16.571188
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():

    virtual = HPUXVirtual()
    assert virtual


# Generated at 2022-06-20 20:28:18.554141
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(None)
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-20 20:28:21.321807
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual(dict(ANSIBLE_MODULE_ARGS='{}')).get_virtual_facts() == {
            'virtualization_tech_host': set(),
            'virtualization_type': 'guest',
            'virtualization_role': 'HP nPar',
            'virtualization_tech_guest': {'HP nPar'}
            }

# Generated at 2022-06-20 20:28:30.479931
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class HPUXVirtual'''
    from ansible.module_utils.facts.utils import get_reader
    from ansible.module_utils.facts.collector import get_collector

    reader = get_reader(HPUXVirtualCollector._platform)
    collector = get_collector(HPUXVirtualCollector._platform, reader)

    # Case 1: vecheck present and out matches:
    reader.exists_side_effect = ['False', 'False', 'True', 'True', 'False']
    reader.run_command_result = [(0, '', ''), (0, '', ''), (0, '', ''), (0, 'HPVM Host Name:   test_host_name\nRunning:           HPVM vPar\n', ''), (0, '', '')]

# Generated at 2022-06-20 20:28:34.196640
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt = HPUXVirtual(dict())
    assert virt.platform == 'HP-UX'
    assert virt.get_virtual_facts() == {'virtualization_tech_guest': set(),
                                        'virtualization_tech_host': set()}


# Generated at 2022-06-20 20:28:51.393111
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # pylint: disable=protected-access
    virt_fact = HPUXVirtual(dict(), dict())
    assert virt_fact
    assert virt_fact._platform == 'HP-UX'
    assert virt_fact._fact_class == HPUXVirtual
    assert virt_fact._command == "uname -s"
    assert virt_fact._file == "/usr/sbin/parstatus"
    assert virt_fact._fact_class._platform == 'HP-UX'
    # pylint: disable=line-too-long
    assert virt_fact._fact_class._file == "/usr/sbin/vecheck,/opt/hpvm/bin/hpvminfo,/usr/sbin/parstatus"

# Generated at 2022-06-20 20:28:54.616228
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hux_virtual = HPUXVirtual({}, [], {})
    assert hux_virtual._platform == 'HP-UX'

# Generated at 2022-06-20 20:28:57.235032
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux = HPUXVirtual()

    # Check that we get the right platform back
    assert hpux.platform == 'HP-UX'

# Generated at 2022-06-20 20:29:05.046994
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpar import HPUXVirtual

    test_hpar = HPUXVirtual(None)
    test_facts = test_hpar.get_virtual_facts()

    assert test_facts["virtualization_type"] is None
    assert test_facts["virtualization_role"] is None
    assert set(test_facts["virtualization_tech_host"]) == set()
    assert set(test_facts["virtualization_tech_guest"]) == set()

# Generated at 2022-06-20 20:29:11.357053
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import ansible.module_utils.facts.virtual.hpux_virtual as hpux_virtual
    import ansible.module_utils.facts.virtual.base as virtual_base
    module = virtual_base._FakeModule()
    hpux_virtual.os.path.exists = virtual_base._MarkTrue
    hpux_virtual.re.match = virtual_base._MarkTrue
    hpux_virtual.re.VERBOSE = virtual_base._MarkTrue
    hpux_virtual.AnsibleModule = virtual_base._FakeAnsibleModule
    hpux_virtual.AnsibleModule.run_command = virtual_base._MockRunCommand

# Generated at 2022-06-20 20:29:12.955988
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual({})
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-20 20:29:20.703609
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():

    # Test constructor with no argument
    empty_params = {}
    virtual = HPUXVirtual(empty_params)

    # Check platform
    platform = virtual.get_platform()
    assert platform == virtual.platform

    # Test get_virtual_facts() with no argument
    virtual_facts = virtual.get_virtual_facts()
    assert len(virtual_facts) == 3
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts

    # Test get_virtual_facts() with parameter 'gather_subset=min'
    virtual_facts = virtual.get_virtual_facts(gather_subset='min')
    assert len(virtual_facts) == 2
    assert 'virtualization_type' in virtual_facts
   

# Generated at 2022-06-20 20:29:29.478842
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # Test for empty case
    result = HPUXVirtual({}, {})
    assert isinstance(result, dict)
    assert result == {}, "Empty input failed"
    # Test for non empty case
    result = HPUXVirtual(dict(module=None), dict())
    assert isinstance(result, dict)
    assert isinstance(result.get('virtualization_type'), str)
    assert result.get('virtualization_type') in ['guest', 'host'], \
        "Incorrect virtualization_type found"
    assert isinstance(result.get('virtualization_role'), str)

# Generated at 2022-06-20 20:29:32.331344
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector({}, {})
    assert virtual_collector
    assert virtual_collector.platform == 'HP-UX'
    assert virtual_collector.fact_class == HPUXVirtual

# Generated at 2022-06-20 20:29:34.450356
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector('')
    assert collector.platform == 'HP-UX'
    assert collector.fact_class == HPUXVirtual



# Generated at 2022-06-20 20:29:52.203575
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv._fact_class is HPUXVirtual

# Generated at 2022-06-20 20:29:53.517074
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert (hv.platform == 'HP-UX')


# Generated at 2022-06-20 20:30:02.503540
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = AnsibleModuleMock()
    hpuxvirt = HPUXVirtual(module)
    result = hpuxvirt.get_virtual_facts()
    assert type(result) is dict
    assert len(result.keys()) > 0
    assert 'virtualization_tech_guest' in result.keys()
    assert 'virtualization_tech_host' in result.keys()
    assert 'virtualization_role' in result.keys()
    assert 'virtualization_type' in result.keys()
    assert type(result['virtualization_tech_guest']) is set
    assert type(result['virtualization_tech_host']) is set


# Generated at 2022-06-20 20:30:04.458256
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv._fact_class is HPUXVirtual



# Generated at 2022-06-20 20:30:06.556994
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    class_under_test = VirtualCollector()
    assert class_under_test._fact_class is not None

# Generated at 2022-06-20 20:30:08.338787
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    obj = HPUXVirtual(dict())
    assert obj.platform == 'HP-UX'

# Generated at 2022-06-20 20:30:10.129210
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv._platform == 'HP-UX'
    assert hv.platforms == ('HP-UX',)

# Generated at 2022-06-20 20:30:20.042929
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    class AnsibleModule(object):
        def __init__(self):
            self.run_command_results = [(0, "", ""), (1, "", "")]
            self.run_command_calls = [['/usr/sbin/vecheck'], ['/opt/hpvm/bin/hpvminfo'], ['/usr/sbin/parstatus']]
            self.run_command_current = -1
            self.command_results = {
                'uname -a': "HP-UX B.11.31 U ia64",
                '/usr/sbin/ioinfo -v': 'HP-UX',
            }
            self.command_calls = []
            self.command_current = -1

        def run_command(self, args, check_rc=True):
            self.run_command_

# Generated at 2022-06-20 20:30:23.535711
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    mod_args = {}
    h_o = HPUXVirtualCollector(module=mod_args)
    assert h_o.platform == 'HP-UX'
    assert isinstance(h_o.facts, Virtual)

# Generated at 2022-06-20 20:30:25.733475
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(dict(module=dict()), '/')
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-20 20:30:54.528120
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(None)
    assert virtual.platform == 'HP-UX'

# Generated at 2022-06-20 20:30:55.872478
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():

    hp_virtual = HPUXVirtual()
    assert hp_virtual.platform == 'HP-UX'

# Generated at 2022-06-20 20:31:01.801175
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    # Make a module that we can use to mock up sub processes
    class test_ansible_module():
        def __init__(self):
            self.run_command_args = ''
            self.run_command_rc = 0
            self.run_command_stdout = ''
            self.run_command_stderr = ''

        def fail_json(self, **kwargs):
            pass

    module = test_ansible_module()

    # Mock commands
    # These are the commands run by get_virtual_facts and the expected return
    # values. The commands are:
    # 1. /usr/sbin/vecheck
    # 2. /opt/hpvm/bin/hpvminfo
    # 3. /usr/sbin/parstatus

    # None of these commands return the string "HPVM guest"
   

# Generated at 2022-06-20 20:31:09.178010
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hp_ux import HPUXVirtual

    module = MockModule()

    virtual = HPUXVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP nPar'
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_tech_guest'] == set(['HP nPar'])



# Generated at 2022-06-20 20:31:17.719010
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    module = basic.AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    hv = HPUXVirtual(module)
    facts = hv.get_virtual_facts()

    assert facts['virtualization_tech_host'] == set([])
    assert facts['virtualization_tech_guest'] in (set([]), set(['HPVM']))
    assert facts['virtualization_type'] in ('host', 'guest')
    assert facts['virtualization_role'] in (None, 'HPVM', 'HPVM IVM', 'HPVM vPar',
                                            'HP vPar', 'HP nPar')

# Generated at 2022-06-20 20:31:19.609630
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    v_c = HPUXVirtualCollector()
    assert v_c.platform == 'HP-UX'
    assert v_c.fact_class._platform == 'HP-UX'

# Generated at 2022-06-20 20:31:23.057471
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpu = HPUXVirtual(dict(module=None))
    platform = hpu.platform
    assert platform == 'HP-UX'


# Generated at 2022-06-20 20:31:24.356808
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual()
    assert h.platform == 'HP-UX'

# Generated at 2022-06-20 20:31:27.612670
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    c = HPUXVirtualCollector()
    assert c.platform == 'HP-UX'
    assert c.fact_class == HPUXVirtual


# Generated at 2022-06-20 20:31:29.362493
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    # Constructor should fail without a valid module argument
    try:
        HPUXVirtualCollector()
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-20 20:32:32.346503
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector._platform == 'HP-UX'
    assert HPUXVirtualCollector._fact_class == HPUXVirtual



# Generated at 2022-06-20 20:32:37.877544
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import ansible.module_utils.facts.virtual.hpsux
    import ansible.module_utils.facts.virtual.base
    class FakeModule(object):
        def __init__(self):
            self.run_command = ansible.module_utils.facts.virtual.base.FakeModule.FakeRunCommand(self)
    class FakeRunCommand(object):
        def __init__(self, module):
            self.module = module
        class FakeRC(object):
            def __init__(self, rc, out, err):
                self.rc = rc
                self.stdout = out
                self.stderr = err

# Generated at 2022-06-20 20:32:39.308290
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual()
    assert virtual.platform == 'HP-UX'


# Generated at 2022-06-20 20:32:42.113653
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    assert obj._platform == 'HP-UX'
    assert issubclass(obj._fact_class, Virtual)


# Generated at 2022-06-20 20:32:44.392246
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpuxvirtualcollector = HPUXVirtualCollector()
    assert hpuxvirtualcollector.platform == 'HP-UX'
    assert hpuxvirtualcollector._fact_class == HPUXVirtual



# Generated at 2022-06-20 20:32:48.830249
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    get_virtual_facts should return a dict containing
    virtualization_type and virtualization_role when
    one of the virtualization software is installed
    """
    module = AnsibleModule(argument_spec={})
    facts = HPUXVirtual(module).get_virtual_facts()
    assert 'virtualization_type' in facts

# Generated at 2022-06-20 20:32:50.048018
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert(bool(HPUXVirtual(None)))


# Generated at 2022-06-20 20:32:53.032630
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpv = HPUXVirtual()
    assert hpv.platform == 'HP-UX'
    assert hpv.virtual_facts == {}


# Generated at 2022-06-20 20:32:55.058071
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vc = HPUXVirtualCollector()
    assert vc.platform == 'HP-UX'
    assert vc._fact_class.platform == 'HP-UX'

# Generated at 2022-06-20 20:33:04.550720
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Test data
    out_hpvm_host = '''
    Running as HPVM host
    '''
    out_hpvm_vm = '''
    Running as HPVM guest (HPVM vPar)
    '''
    out_hpvm_ivm = '''
    Running as HPVM guest (HPVM IVM)
    '''
    out_vpar = '''
    Active vPar: 1
    '''
    out_npar = '''
    System is in nPar configuration
    '''

    # get_virtual_facts test
    hpux_virtual = HPUXVirtual()

    # test1: hpvm
    hpux_virtual.module.run_command = mock_run_command('hpvminfo', out_hpvm_host, 0)
    assert hpux_virtual.get_virtual_facts

# Generated at 2022-06-20 20:34:39.735278
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    def test_module_mock(**kwargs):
        class TestModule:
            def __init__(self, kwargs):
                self.params = kwargs

            def run_command(self, cmd, check_rc=None):
                if cmd == "/usr/sbin/vecheck":
                    return 0, "",""
                elif cmd == "/opt/hpvm/bin/hpvminfo":
                    return 0, "",""
                elif cmd == "/usr/sbin/parstatus":
                    return 0, "",""
                elif cmd == "/usr/bin/sudo":
                    return 0, "",""
                else:
                    raise Exception("Unexpected Command")

        return TestModule(kwargs)

    HPUXVirtualCollector(test_module_mock)

# Generated at 2022-06-20 20:34:46.923268
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = type('', (), {})
    module.run_command = lambda command, check_rc=True: (0, '', '')
    module.params = lambda: dict(collect_all=True)
    hv = HPUXVirtualCollector(module)
    assert hv._platform == 'HP-UX'
    assert isinstance(hv._fact_class, HPUXVirtual)
    assert isinstance(hv._fact_class(module), HPUXVirtual)


# Generated at 2022-06-20 20:34:48.940503
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    assert obj._fact_class == HPUXVirtual
    assert obj._platform == 'HP-UX'

# Generated at 2022-06-20 20:34:56.668535
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class Module(object):

        def __init__(self):
            self.run_command_count = 0
            self.run_command_rcs = []
            self.run_command_outs = []
            self.run_command_errs = []

        def run_command(self, cmd):
            self.run_command_count += 1
            return self.run_command_rcs.pop(0), self.run_command_outs.pop(0), self.run_command_errs.pop(0)

    class MockFile():
        def __init__(self, filename, return_value):
            self.filename = filename
            self.return_value = return_value

        def exists(self):
            return self.return_value


# Generated at 2022-06-20 20:35:05.565971
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModuleMock()

# Generated at 2022-06-20 20:35:07.058288
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-20 20:35:10.515270
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert x._fact_class == HPUXVirtual
    assert x._platform == 'HP-UX'

# Generated at 2022-06-20 20:35:11.616292
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert issubclass(HPUXVirtualCollector, VirtualCollector)



# Generated at 2022-06-20 20:35:13.132993
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    # Create object for testing
    obj = HPUXVirtualCollector()

    # Check for class attributes
    assert obj._fact_class == HPUXVirtual
    assert obj._platform == 'HP-UX'

# Generated at 2022-06-20 20:35:17.124251
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    v = HPUXVirtual(dict(module=dict()))
    assert v.platform == 'HP-UX'
    # TODO: add test for non virtualized system
    # TODO: add test for HP vPar
    # TODO: add test for HPVM vPar
    # TODO: add test for HPVM IVM
    # TODO: add test for HPVM
    # TODO: add test for HP nPar
