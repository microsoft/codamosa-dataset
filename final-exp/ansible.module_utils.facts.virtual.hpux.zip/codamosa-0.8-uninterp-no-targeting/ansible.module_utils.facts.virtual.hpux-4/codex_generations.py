

# Generated at 2022-06-20 20:27:21.955677
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    assert obj.__class__.__name__ == 'HPUXVirtualCollector'

# Generated at 2022-06-20 20:27:22.875446
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-20 20:27:25.080491
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual({})
    assert isinstance(v, HPUXVirtual)


# Generated at 2022-06-20 20:27:27.338369
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector()
    assert collector.platform == 'HP-UX'
    assert collector._get_fact_class() == HPUXVirtual


# Generated at 2022-06-20 20:27:33.698203
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    fake_module = type('obj', (object,), {'params': {'gather_subset': ['all']}, 'run_command': run_command_mock})()
    virtual_hpux_obj = HPUXVirtual(fake_module)

    assert virtual_hpux_obj._platform == "HP-UX"
    assert virtual_hpux_obj.platform == "HP-UX"
    assert virtual_hpux_obj.collector._fact_class is HPUXVirtual



# Generated at 2022-06-20 20:27:38.559063
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpuxvirtual = HPUXVirtual()
    facts = hpuxvirtual.get_virtual_facts()
    assert facts['virtualization_type'] is None
    assert facts['virtualization_role'] is None
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-20 20:27:40.494513
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    test_obj = HPUXVirtualCollector()
    assert test_obj is not None


# Generated at 2022-06-20 20:27:46.869486
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class ModuleStub():
        def __init__(self):
            self.run_command_called = False
            self.run_command_output = None
            self.run_command_return_code = None

        def run_command(self, command):
            self.run_command_called = True
            if command == "/usr/sbin/vecheck":
                self.run_command_output = "output1"
                self.run_command_return_code = 0
            elif command == "/opt/hpvm/bin/hpvminfo":
                self.run_command_output = "output2"
                self.run_command_return_code = 0
            elif command == "/usr/sbin/parstatus":
                self.run_command_output = "output3"
                self.run_command_return_code

# Generated at 2022-06-20 20:27:48.704992
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv.platform == 'HP-UX'
    assert hv.fact_class == HPUXVirtual

# Generated at 2022-06-20 20:27:55.079407
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """
    Unit test for class HPUXVirtualCollector
    """
    results = dict(changed=False, ansible_facts=dict(virtualization=dict()))
    hpux_virtual_obj = HPUXVirtualCollector()
    hpux_virtual_obj.collect(module=None, results=results)

    assert results['ansible_facts']['virtualization']['platform'] == 'HP-UX'

# Generated at 2022-06-20 20:28:04.836711
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv._platform == 'HP-UX'
    assert hv._fact_class._platform == 'HP-UX'

# Generated at 2022-06-20 20:28:06.155027
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vcol = HPUXVirtualCollector()
    assert vcol.virtual._platform == 'HP-UX'

# Generated at 2022-06-20 20:28:14.160405
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class Module(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def run_command(self, args):
            if "vecheck" in args:
                return 0, "", ""
            elif "hpvminfo" in args:
                return 0, "Running HPVM host", ""
            elif "parstatus" in args:
                return 0, "", ""
            else:
                return 1, "", ""

    virtual_facts = {}
    vm_module = Module()

    hv = HPUXVirtual(vm_module)
    virtual_facts = hv.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts

# Generated at 2022-06-20 20:28:18.365501
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = FakeModule()
    hv = HPUXVirtual(module)
    virtual_facts = hv.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP nPar'
    assert virtual_facts['virtualization_tech_guest'] == set(['HP nPar'])
    assert virtual_facts['virtualization_tech_host'] == set()



# Generated at 2022-06-20 20:28:24.861197
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    basic._ANSIBLE_ARGS = [{}]
    class DummyModule(object):
        @staticmethod
        def run_command(cmd):
            if cmd == "/usr/sbin/vecheck":
                return (0, "some data from vecheck", "")
            elif cmd == "/opt/hpvm/bin/hpvminfo":
                return (0, "some data from hpvminfo", "")
            elif cmd == "/usr/sbin/parstatus":
                return (0, "some data from parstatus", "")
            else:
                return (1, "", "fake error msg")

    fh = HPUXVirtual(DummyModule())
    ret = fh.get_virtual_facts()
    # check to see if 'virtualization_tech_

# Generated at 2022-06-20 20:28:25.395360
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual(dict()).platform == 'HP-UX'



# Generated at 2022-06-20 20:28:26.825592
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    obj = HPUXVirtual({})
    assert obj

# Generated at 2022-06-20 20:28:28.787760
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual(dict(module=dict()))
    assert virtual_obj.platform == 'HP-UX'
    assert virtual_obj.module is not None

# Generated at 2022-06-20 20:28:33.168195
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = FakeModule()
    virtualfact = HPUXVirtual(module)
    virtualfact.get_virtual_facts()
    module.fail_json.assert_called_with(msg="No matching facts found")

# Generated at 2022-06-20 20:28:34.690823
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpu_x_virtual = HPUXVirtual({})
    assert hpu_x_virtual


# Generated at 2022-06-20 20:28:44.413354
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv._platform == 'HP-UX'
    assert isinstance(hv.virtual, HPUXVirtual)
    assert hv.virtual._platform == 'HP-UX'

# Generated at 2022-06-20 20:28:46.555371
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    # create HPUXVirtualCollector object
    virtual_collector = HPUXVirtualCollector()
    # Checking _fact_class of object
    assert virtual_collector._fact_class == HPUXVirtual
    # Checking _platform of object
    assert virtual_collector._platform == 'HP-UX'

# Generated at 2022-06-20 20:28:55.530463
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    test_module = 'ansible.module_utils.facts.virtual.HPUXVirtual'
    test_class = 'HPUXVirtual'
    test_obj = 'HPUXVirtual(module=None)'

    # initialize module
    from ansible.module_utils import basic
    from ansible.module_utils.facts import virtual
    from ansible.module_utils._text import to_bytes
    # Replace basic.AnsibleModule's `run_command` method with a mock method
    # that returns a particular response for the command
    import mock
    original_run_command = basic.AnsibleModule.run_command

# Generated at 2022-06-20 20:28:58.671205
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    vh = {'virtual_facts': {}, 'all_facts': {}, 'fail_json': {}}
    hv = HPUXVirtual(vh)

    assert hv.platform == "HP-UX"

# Generated at 2022-06-20 20:29:01.408312
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    virtual = HPUXVirtual(None)
    virtual.get_virtual_facts()


# Generated at 2022-06-20 20:29:03.271057
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = FakeAnsibleModule()
    hv = HPUXVirtual(module)
    assert hv.module == module

# Generated at 2022-06-20 20:29:07.275960
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    facts = dict()
    virtual_facts = dict()
    virtualCollector = HPUXVirtualCollector(facts, virtual_facts)
    assert virtualCollector._fact_class == HPUXVirtual
    assert virtualCollector._platform == 'HP-UX'
    assert virtualCollector.platform == 'HP-UX'


# Generated at 2022-06-20 20:29:11.155091
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import os
    import tempfile
    import subprocess
    import unittest

    class MockAnsibleModule:
        def __init__(self):
            pass
        def debug(self, msg):
            pass
        def run_command(self, cmd, check_rc=True):
            if cmd == '/usr/sbin/vecheck':
                return 0, "''", ''
            elif cmd == '/opt/hpvm/bin/hpvminfo':
                return 0, "Running HPVM guest", ''
            elif cmd == '/usr/sbin/parstatus':
                return 0, "", ''
            else:
                raise RuntimeError('unexpected command {}'.format(cmd))
            
    class MyTestCase(unittest.TestCase):
        def setUp(self):
            self.mock_ansible_

# Generated at 2022-06-20 20:29:12.381232
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpx = HPUXVirtual()
    assert hpx.platform == 'HP-UX'

# Generated at 2022-06-20 20:29:20.251250
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual, HPUXVirtualCollector
    import os
    test_module = ModuleFacts()
    # If a file exists, we should be able to create the Virtual object
    test_module.exists = lambda x: True
    virtual = Virtual(module=test_module)
    assert virtual.__class__ is Virtual
    hpux_virtual = HPUXVirtual(module=test_module)
    assert hpux_virtual.__class__ is HPUXVirtual
    # The method get_virtual_facts() should return a dict
    result = hpux_virtual.get_virtual_facts()
    assert isinstance

# Generated at 2022-06-20 20:29:37.956230
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector()
    my_facts = collector.collect()
    assert 'HPUXVirtual' in str(my_facts)
    assert my_facts['ansible_virtualization_type'] == 'guest'
    assert 'ansible_virtualization_tech_host' not in my_facts

# Generated at 2022-06-20 20:29:40.024387
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    huvirt = HPUXVirtual({})
    assert huvirt.platform == 'HP-UX'

# Generated at 2022-06-20 20:29:42.039428
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert isinstance(x, HPUXVirtualCollector)


# Generated at 2022-06-20 20:29:52.934219
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module_mock = MockModule()
    virtual_mock = HPUXVirtual(module_mock)

    assert virtual_mock._platform == 'HP-UX'

    # TODO
    # Add condition for the presence of /usr/sbin/vecheck
    # Add condition for the presence of /opt/hpvm/bin/hpvminfo
    # Add condition for the presence of /usr/sbin/parstatus

    virtual_facts = virtual_mock.get_virtual_facts()

    assert set(virtual_facts.keys()) == set(['virtualization_type',
                                             'virtualization_role',
                                             'virtualization_tech_host',
                                             'virtualization_tech_guest'])

    assert virtual_facts['virtualization_type'] == 'guest'

# Generated at 2022-06-20 20:29:54.051298
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vc=HPUXVirtualCollector()
    assert vc.platform == 'HP-UX'

# Generated at 2022-06-20 20:29:56.210237
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv
    print("Created hv: ", hv)


# Generated at 2022-06-20 20:30:05.538455
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict()
    )
    hpux_virtual = HPUXVirtual(module)
    hpux_virtual.module.run_command = run_command
    virtual_facts = hpux_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    assert virtual_facts['virtualization_tech_guest'] == {'HP vPar'}
    assert virtual_facts['virtualization_tech_host'] == set()


# Unit tests for class HPUXVirtualCollector

# Generated at 2022-06-20 20:30:08
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_instance = HPUXVirtual()
    assert virtual_instance


# Generated at 2022-06-20 20:30:09.897148
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt_obj = HPUXVirtual(None)
    assert virt_obj.module is None
    assert virt_obj.platform == 'HP-UX'


# Generated at 2022-06-20 20:30:15.573161
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    host_tech = set()
    guest_tech = set()

    virtual_facts = {}
    virtual_facts['virtualization_type'] = 'guest'
    virtual_facts['virtualization_role'] = 'HP nPar'
    virtual_facts['virtualization_tech_host'] = host_tech
    virtual_facts['virtualization_tech_guest'] = guest_tech
    return virtual_facts

# Generated at 2022-06-20 20:30:30.474292
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector.platform == 'HP-UX'

# Generated at 2022-06-20 20:30:39.531903
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import tempfile
    import shutil
    from ansible_collections.ansible.community.tests.unit.compat import mock
    from ansible_collections.ansible.community.tests.unit.module_utils.facts.virtual.test_virtual import MockModule

    tmpdir = tempfile.mkdtemp()
    # Mock the tmpdir to something that can be written to
    tmpdir = "/tmp"
    # Write a dummy file to /usr/sbin/vecheck to simulate vecheck utility
    vecheck_file = os.path.join(tmpdir, 'vecheck')
    with open(vecheck_file, 'w') as f:
        f.write('This is a dummy vecheck file')
    os.chmod(vecheck_file, 0o755)
    # Add the dummy vecheck file to PATH

# Generated at 2022-06-20 20:30:42.162947
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """ Constructor test for class HPUXVirtualCollector """
    hpuxvirtualcollector = HPUXVirtualCollector()
    assert hpuxvirtualcollector._fact_class == HPUXVirtual

# Generated at 2022-06-20 20:30:48.423458
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """ Constructor of HPUXVirtualCollector should return instance of class HPUXVirtualCollector
    """
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    virt_collector = HPUXVirtualCollector()
    assert isinstance(virt_collector,HPUXVirtualCollector)
    assert virt_collector._platform == "HP-UX"
    assert virt_collector._fact_class == HPUXVirtual

# Generated at 2022-06-20 20:30:51.161297
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv.platform == 'HP-UX'
    assert hv._fact_class == HPUXVirtual


# Generated at 2022-06-20 20:30:58.233919
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class HPUXVirtual
    """
    # Create a HPUXVirtual object
    hpux_virtual_object = HPUXVirtual()

    # Create a facts object
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    # Check if the fact_subset option is present in the argument.
    # If yes, then update the module.params['gather_subset'] with
    # the value of fact_subset option.
    if module.params['fact_subset']:
        module.params['gather_subset'] = module.params['fact_subset']

    # Set the ansible_module_object

# Generated at 2022-06-20 20:30:59.089068
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict(module=dict()))
    assert virtual.platform == 'HP-UX'

# Generated at 2022-06-20 20:31:01.676734
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_facts = HPUXVirtual({})
    assert hpux_facts.platform == 'HP-UX'

# Generated at 2022-06-20 20:31:07.807434
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # Constructor of HPUXVirtual
    # Test type of fact_class
    assert isinstance(HPUXVirtualCollector._fact_class, type(Virtual))
    # Test platform supported
    assert HPUXVirtualCollector._platform == 'HP-UX'
    # Test facts retrieved
    module = None
    hpxvirtual = HPUXVirtual(module)
    assert isinstance(hpxvirtual, object)

# Generated at 2022-06-20 20:31:09.513407
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector._fact_class == HPUXVirtual
    assert HPUXVirtualCollector._platform == 'HP-UX'

# Generated at 2022-06-20 20:31:27.331341
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict())
    assert virtual.__doc__ is not None

# Generated at 2022-06-20 20:31:29.189318
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector(None)
    assert virtual_collector._fact_class == HPUXVirtual

# Generated at 2022-06-20 20:31:32.030354
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    test_obj = HPUXVirtualCollector()
    assert test_obj
    assert test_obj._fact_class == HPUXVirtual
    assert test_obj._platform == 'HP-UX'


# Generated at 2022-06-20 20:31:33.415483
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    '''
    This function unit test for constructor of class VirtualCollector
    '''
    hv = HPUXVirtualCollector()

# Generated at 2022-06-20 20:31:44.533890
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Test case to check method get_virtual_facts of class HPUXVirtual
    with following test scenarios,
    1) HP vPar guest
    2) HPVM vPar guest
    3) HPVM IVM guest
    4) HPVM host
    5) HP nPar guest
    """

    # Test case to check HP vPar guest
    hp_vpar_guest_virtual = HPUXVirtual({'module': None})
    hp_vpar_guest_virtual.module.run_command = MagicMock(side_effect=[(0, "", ""), (0, "", "")])
    hp_vpar_guest_virtual.os.path.exists = MagicMock(side_effect=[True, False, False, False, False])
    hp_vpar_guest_virtual_facts = hp_v

# Generated at 2022-06-20 20:31:48.469455
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = AnsibleModuleMock()
    v = HPUXVirtualCollector(module)
    assert v.platform == 'HP-UX'

# Generated at 2022-06-20 20:31:49.970149
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict()
    )
    HPUXVirtual(module).get_virtual_facts()

# Generated at 2022-06-20 20:31:52.794842
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert issubclass(HPUXVirtualCollector, VirtualCollector)
    assert HPUXVirtualCollector._platform == 'HP-UX'


# Generated at 2022-06-20 20:31:57.566934
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    '''
    The get_virtual_facts() method of class HPUXVirtual should return
    a dictionary with the following keys, with values set according
    to the underlying platform:
        virtualization_type
        virtualization_tech_guest
        virtualization_tech_host
        virtualization_role
        virtualization_subrole
    '''
    import tempfile
    import shutil
    from ansible.module_utils.facts.virtual import HPUXVirtual
    from ansible.module_utils.common.collections import ImmutableDict

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    vcheck_file = os.path.join(tmpdir, "vecheck")
    open(vcheck_file, 'a').close()

    # Create a HPUX

# Generated at 2022-06-20 20:32:04.783490
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = type('', (object,), {"run_command": run_command})
    module.run_command = run_command
    virtual = HPUXVirtual(module=module)
    virtual_facts = virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'guest'
    assert 'HP nPar' in virtual_facts['virtualization_tech_guest']
    assert 'HP vPar' in virtual_facts['virtualization_tech_guest']
    assert 'HPVM vPar' in virtual_facts['virtualization_tech_guest']
    assert 'HPVM IVM' in virtual_facts['virtualization_tech_guest']
    assert 'HPVM' in virtual_facts['virtualization_tech_host']


# Mock AnsibleModule object

# Generated at 2022-06-20 20:32:22.189559
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector_obj = HPUXVirtualCollector(None)
    assert virtual_collector_obj._platform == "HP-UX"
    assert virtual_collector_obj._fact_class.platform == "HP-UX"

# Generated at 2022-06-20 20:32:25.333237
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    d = HPUXVirtualCollector()
    assert d._platform == 'HP-UX'
    assert d._fact_class == HPUXVirtual



# Generated at 2022-06-20 20:32:27.180273
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual({})
    assert hpux_virtual.platform == platform


# Generated at 2022-06-20 20:32:28.609691
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual


# Generated at 2022-06-20 20:32:30.981401
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(None)
    assert 'platform' in virtual.__dict__
    assert virtual.platform == 'HP-UX'
    assert not virtual.guest_tech_set

# Generated at 2022-06-20 20:32:38.194351
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """Test HPUXVirtual.get_virtual_facts() with various paths
    """
    from ansible.module_utils.facts import ModuleExitException
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual

    # Prepare a test module
    class TestModule:
        def __init__(self, params):
            self._params = params

        def fail_json(self, msg, **kwargs):
            raise Exception(msg)

        def get_bin_path(self, executable, required=True, opt_dirs=[]):
            return executable

        def run_command(self, command, check_rc=True):
            if command == '/usr/sbin/vecheck':
                if self._params['vecheck'] == 'success':
                    return 0, '', ''
                else:
                    return 1,

# Generated at 2022-06-20 20:32:38.957189
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-20 20:32:41.444787
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual({})
    assert v.virtualization_type == {}
    assert v.virtualization_role == {}

# Generated at 2022-06-20 20:32:43.740942
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = fake_module()
    hpux_virtual = HPUXVirtual(module)
    assert hpux_virtual.module == module
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-20 20:32:49.399300
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class HPUXVirtual
    """
    hpx_virtual_obj = HPUXVirtual({})
    virtual_facts = hpx_virtual_obj.get_virtual_facts()
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-20 20:33:20.663961
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    c = HPUXVirtualCollector({}, None)
    assert c.__class__.__name__ == 'HPUXVirtualCollector'
    assert c._platform == 'HP-UX'
    assert c._fact_class.__name__ == 'HPUXVirtual'
    assert c._fact_class.platform == 'HP-UX'

if __name__ == '__main__':
    test_HPUXVirtualCollector()

# Generated at 2022-06-20 20:33:28.454994
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts import Module
    from ansible.module_utils.facts.virtual import VirtualCollector
    import tempfile
    import os
    test_module = Module()
    test_module.run_command = lambda cmd: (0, '', '')
    test_module.params = []
    test_module.virtual_collector = VirtualCollector()
    test_module.virtual_collector.module = test_module
    test_module.virtual_collector.add_platform_subclass(HPUXVirtual(test_module))

    v = HPUXVirtual(test_module)
    v.module = test_module
    # Test hpvm guest

# Generated at 2022-06-20 20:33:30.417524
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict(module=None, command_runner=None))
    assert virtual.platform == 'HP-UX'


# Generated at 2022-06-20 20:33:31.226922
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-20 20:33:43.049461
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector

    os.environ['PATH'] += ':/opt/hpvm/bin'
    basedir = os.path.join(os.path.dirname(__file__), '../../../../')
    module_path = os.path.join(basedir, 'module_utils/facts/virtual/hpux.py')

# Generated at 2022-06-20 20:33:50.229697
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.virtual.hpux
    from ansible.module_utils.facts import VirtualCollector

    class MockModule(object):
        class RunCommand(object):
            def __init__(self, fout, rcout, errout):
                self.fout = fout
                self.rcout = rcout
                self.errout = errout
            def __call__(self, dummy):
                if self.fout == 'vecheck':
                    return self.rcout, self.fout, self.errout
                elif self.fout == 'hpvminfo':
                    return self.rcout, self.fout, self.errout
                elif self.fout == 'parstatus':
                    return self.rcout, self

# Generated at 2022-06-20 20:33:51.826418
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(None)
    assert virtual



# Generated at 2022-06-20 20:33:59.922214
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Test HPUXVirtual.get_virtual_facts.
    """
    def run_mock(self, *cmd, **kwargs):
        """
        Mock method for module.run_command.
        """
        if cmd[0] == '/usr/sbin/vecheck':
            return 0, '', ''
        if cmd[0] == '/opt/hpvm/bin/hpvminfo':
            return 0, 'Running HPVM vPar', ''
        if cmd[0] == '/usr/sbin/parstatus':
            return 0, '', ''
        return (1, '', '')
    vfacts = {}

    # Assign mock method to module
    HPUXVirtual.module.run_command = run_mock

    # Create a HPUXVirtual object
    hpuxv = HPUXVirtual

# Generated at 2022-06-20 20:34:02.105204
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    assert obj._fact_class is HPUXVirtual
    assert obj._platform == 'HP-UX'



# Generated at 2022-06-20 20:34:04.313276
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert type(hv) == HPUXVirtualCollector

# Generated at 2022-06-20 20:34:26.107072
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    c = HPUXVirtualCollector()
    assert c.platform == 'HP-UX'
    assert c.fact_class == HPUXVirtual


# Generated at 2022-06-20 20:34:37.483945
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True)
    hpux_virtual = HPUXVirtual(module)
    result = hpux_virtual.get_virtual_facts()
    # nPar
    if os.path.exists('/usr/sbin/parstatus'):
        assert 'virtualization_type' in result.keys()
        assert result['virtualization_type'] == 'guest'
        assert 'virtualization_role' in result.keys()
        assert result['virtualization_role'] == 'HP nPar'
        assert 'virtualization_tech_guest' in result.keys()
        assert 'HP nPar' in result['virtualization_tech_guest']
    # IVM

# Generated at 2022-06-20 20:34:40.518025
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-20 20:34:51.308012
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class MockModule(object):
        def __init__(self, rc=0, out='', err='', fail_json_rc=None, fail_json_msg=''):
            self.rc = rc
            self.out = out
            self.err = err
            self.fail_json_rc = fail_json_rc
            self.fail_json_msg = fail_json_msg

        def run_command(self, cmd):
            return self.rc, self.out, self.err

    class MockOs(object):
        def __init__(self, path_exists=False):
            self.path_exists = path_exists

        def path(self, path):
            return MockPath(self.path_exists)


# Generated at 2022-06-20 20:34:54.123217
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert virtual_collector._fact_class == HPUXVirtual
    assert virtual_collector._platform == 'HP-UX'

# Generated at 2022-06-20 20:34:56.153365
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'
    assert hv.get_virtual_facts() == {}

# Generated at 2022-06-20 20:35:05.335886
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = type('Module', (object,), dict(run_command=lambda *_: (0, '', '')))
    mock_os = type('MockOs', (object,), dict(path=type('MockPath', (object,), dict(exists=lambda *_: True))))
    mock_os_path = type('MockOsPath', (object,), dict(exists=lambda *_: True))
    test_obj = HPUXVirtual(module)
    test_obj.os = mock_os
    test_result = test_obj.get_virtual_facts()
    assert test_result['virtualization_role'] == 'HPVM IVM'
    assert 'HPVM vPar' in test_result['virtualization_tech_guest']

# Generated at 2022-06-20 20:35:15.276440
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import ansible_collection_mock
    from ansible.module_utils.facts.virtual import HPUXVirtual

    def mock_run_command(self, cmd, **kw):
        if cmd == '/usr/sbin/vecheck':
            # Return fake output if /usr/sbin/vecheck exists
            return (0, to_bytes('/opt/ansible/bin/vecheck'))
        elif cmd == '/opt/ansible/bin/vecheck':
            return (0, to_bytes('HP Virtual Server Environment'))
        elif cmd == '/opt/hpvm/bin/hpvminfo':
            return (0, to_bytes('Running inside HPVM vPar'))

# Generated at 2022-06-20 20:35:16.110769
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_facts = HPUXVirtualCollector()
    assert virtual_facts._platform == 'HP-UX'


# Generated at 2022-06-20 20:35:18.886576
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'
    assert hv.virtualization_type is None
    assert hv.virtualization_role is None
    assert hv.virtualization_tech_host is None
    assert hv.virtualization_tech_guest is None

# Generated at 2022-06-20 20:35:53.930799
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector._fact_class == HPUXVirtual


# Generated at 2022-06-20 20:35:55.193123
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual()
    assert virtual.platform == "HP-UX"

# Generated at 2022-06-20 20:36:06.166282
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """Unit test for method get_virtual_facts of class DellVirtual"""
    from ansible.module_utils.facts.virtual import Virtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    import sys

    # Create object of HPUXVirtual class
    virtual_func = HPUXVirtual()

    # Create object of Virtual class
    virtual = Virtual()

    # Set module argument "gather_subset" to "all"
    virtual.module.params['gather_subset'] = ['all']

    # Call method get_virtual_facts on object virtual_func
    virtual_facts = virtual_func.get_virtual_facts()

    # Validate the returned value with expected value
    if not virtual_facts:
        sys.exit(1)
    else:
        sys.exit(0)




# Generated at 2022-06-20 20:36:14.726838
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual import Collector
    from ansible.module_utils.facts import BaseFactModule
    from ansible.module_utils._text import to_bytes

    class TestModule(BaseFactModule):

        def __init__(self, *args, **kwargs):
            BaseFactModule.__init__(self, *args, **kwargs)
            self._ansible_facts = {}

        def get_ansible_facts(self):
            return self._ansible_facts

        def run_command(self, cmd):
            return 0, '', ''


# Generated at 2022-06-20 20:36:18.563281
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    Instantiate a HPUXVirtual object and return it.
    It will be used by tests.
    """
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    module = FakeAnsibleModule()
    hpux_virtual = HPUXVirtual(module)
    return hpux_virtual



# Generated at 2022-06-20 20:36:21.328502
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector()
    assert collector.__class__.__name__ == 'HPUXVirtualCollector'
    assert collector.platform == 'HP-UX'
    assert collector._fact_class.__name__ == 'HPUXVirtual'


# Generated at 2022-06-20 20:36:21.971719
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()


# Generated at 2022-06-20 20:36:26.714583
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    if os.path.exists('/opt/hpvm/bin/hpvminfo'):
        virtual_collector = HPUXVirtualCollector()
        assert virtual_collector._platform == 'HP-UX'
        assert virtual_collector._fact_class is HPUXVirtual
    else:
        pass

# Generated at 2022-06-20 20:36:28.071758
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == "HP-UX"


# Generated at 2022-06-20 20:36:30.864434
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hp_virtual = HPUXVirtual()
    assert hp_virtual.platform == 'HP-UX'
    assert hp_virtual.get_virtual_facts() == {}


# Generated at 2022-06-20 20:37:08.135748
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Test data.
    out_hpvminfo_1 = """
    Running HPVM host (2) [C790]:{
        Host: HPVM host (2) [C790]
    }
    """
    out_hpvminfo_2 = """
    Running HPVM guest (1) [C370]:{
        Host: HPVM guest (1) [C370]
    }
    """

    out_hpvminfo_3 = """
    Running HPVM vPar (0) [C370,C790]:{
       C370: HPVM vPar (0) [C370]
       C790: HPVM vPar (0) [C790]
    }
    """
    out_vecheck = """
    HP-UX Virtual Environment
    Dual Partition: 2
    """

# Generated at 2022-06-20 20:37:11.778511
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    assert obj.platform == 'HP-UX'
    assert obj.fact_class._platform == 'HP-UX'
    assert obj.fact_class._fact_class == HPUXVirtual