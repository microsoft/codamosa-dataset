

# Generated at 2022-06-20 20:27:21.273530
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    HPUXVirtual_inst = HPUXVirtual(None)
    HPUXVirtual_inst.module.run_command = fa

# Generated at 2022-06-20 20:27:24.547863
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpuxVirtual = HPUXVirtual({})
    assert hpuxVirtual
    assert hpuxVirtual.platform == 'HP-UX'



# Generated at 2022-06-20 20:27:26.531381
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    vc = HPUXVirtual()
    assert vc.platform == 'HP-UX'



# Generated at 2022-06-20 20:27:33.227691
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'
    assert hv.get_virtual_facts() == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}
    assert hv._collect() == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

# Generated at 2022-06-20 20:27:42.915083
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible_collections.ansible.community.plugins.module_utils import basic
    from ansible_collections.ansible.community.plugins.module_utils.facts import virtual

    def fake_run_command(args):
        if args == ['/usr/sbin/vecheck']:
            return (0, 'HP-UX is a virtualized operating system', '')
        if args == ['/opt/hpvm/bin/hpvminfo']:
            return (0, 'Running on HPVM guest', '')
        if args == ['/usr/sbin/parstatus']:
            return (0, 'HP-UX is a virtualized operating system', '')


# Generated at 2022-06-20 20:27:45.093846
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual({})
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-20 20:27:46.940694
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    from ansible.module_utils._text import to_bytes
    obj = HPUXVirtualCollector()
    assert obj


# Generated at 2022-06-20 20:27:55.615384
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpuxvirtual = HPUXVirtual()
    assert hpuxvirtual.platform == "HP-UX"
    assert hpuxvirtual.virtualization_type == "unknown"
    assert hpuxvirtual.virtualization_role == "unknown"
    assert hpuxvirtual.virtualization_system == "unknown"
    assert hpuxvirtual.virtualization_host_name == "unknown"
    assert hpuxvirtual.virtualization_guest_name == "unknown"
    assert hpuxvirtual.virtualization_host_uuid == "unknown"
    assert hpuxvirtual.virtualization_guest_uuid == "unknown"
    assert hpuxvirtual.virtualization_host_serial == "unknown"
    assert hpuxvirtual.virtualization_guest_serial == "unknown"
    assert hpuxvirtual.virtualization_host_vendor == "unknown"
    assert hpux

# Generated at 2022-06-20 20:27:58.040391
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    my_HPUXVirtualCollector = HPUXVirtualCollector()
    assert my_HPUXVirtualCollector.platform == 'HP-UX'
    assert my_HPUXVirtualCollector.fact_class == HPUXVirtual

# Generated at 2022-06-20 20:28:06.163521
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Create HPUXVirtual class object
    hpv = HPUXVirtual()

    # Create an argument dictionary for the function test
    test_dict = {'REGISTER': {'_ansible_virtual_facts': '_ansible_virtual_facts'}}

    # Run get_virtual_facts method and assert virtualization_type
    hpv.get_virtual_facts()
    assert hpv.virtual_facts['virtualization_type'] == 'guest' or hpv.virtual_facts['virtualization_type'] == 'host'

    # Run get_virtual_facts method and assert virtualization_role
    hpv.get_virtual_facts()
    # assert hpv.virtual_facts['virtualization_role'] == 'HP nPar' \
    #     or hpv.virtual_facts['virtualization_role'] == 'HP vPar' \

# Generated at 2022-06-20 20:28:15.963129
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()


# Generated at 2022-06-20 20:28:20.729923
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    hv = HPUXVirtualCollector()
    assert hv.__class__.__name__ == 'HPUXVirtualCollector'
    assert hv.__class__.platform == 'HP-UX'
    assert hv.__class__.__bases__[0].__name__ == 'VirtualCollector'
    assert hv.get_virtual_facts().__class__.__name__ == 'HPUXVirtual'

if __name__ == '__main__':
    pytest.main([__file__])

# Generated at 2022-06-20 20:28:30.199301
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector

    # Create a mock instance of a module
    class MockModule:
        def __init__(self):
            self.run_command_calls = []
            self.run_command_results = []

        def run_command(self, command):
            self.run_command_calls.append(command)
            return self.run_command_results.pop(0)

        def fail_json(self, **kwargs):
            pass

        def exit_json(self, **kwargs):
            pass

    # Create a mock instance of a HPUXVirtualCollector

# Generated at 2022-06-20 20:28:39.318208
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class MockModule():
        def run_command(self, cmd):
            if cmd == '/usr/sbin/vecheck':
                return 0, '', ''
            if cmd == '/opt/hpvm/bin/hpvminfo':
                return 0, 'Running HPVM guest on HPVM host', ''
            if cmd == '/usr/sbin/parstatus':
                return 0, '', ''
            return -1, '', ''

    mod = MockModule()
    obj = HPUXVirtual(mod)
    virtual_facts = obj.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HPVM IVM'
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:28:39.804159
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-20 20:28:45.826605
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    vm = HPUXVirtual(module)

    def mock_run_command(cmd):
        rc = 0
        if cmd == '/usr/sbin/vecheck':
            out = ''
            err = ''
        elif cmd == '/opt/hpvm/bin/hpvminfo':
            out = 'Running on: HPVM host'
            err = ''
        elif cmd == '/usr/sbin/parstatus':
            out = ''
            err = ''
        return rc, out, err

    vm.module.run_command = mock_run_command
    vm.get_virtual_facts()
    assert vm.facts['virtualization_type'] == 'host'
    assert vm.facts['virtualization_role'] == 'HPVM'

# Generated at 2022-06-20 20:28:55.359487
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    '''
    Unit test for method get_virtual_facts of class HPUXVirtual
    '''
    from ansible.module_utils.facts.virtual.hpar import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpvm import HPUXVirtual
    from ansible.module_utils.facts.virtual.npar import HPUXVirtual
    from ansible.module_utils.facts.virtual.ivm import HPUXVirtual

    hpar_hvm = HPUXVirtual(dict(module=dict(run_command=run_command), ansible_facts={}))
    hpvm_ivm = HPUXVirtual(dict(module=dict(run_command=run_command), ansible_facts={}))

# Generated at 2022-06-20 20:28:56.913304
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual(None)
    assert hpux_virtual.platform == 'HP-UX'

# Generated at 2022-06-20 20:29:07.734818
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    facts = {'ansible_system_vendor': 'Hewlett-Packard'}
    module = FakeAnsibleModule(facts)
    virtual = HPUXVirtual(module)

    if os.path.exists('/usr/sbin/vecheck'):
        rc = 0
        out = 'HP-UX is included in HP-UX virtual partition (vPar) software.\n'
        err = ''
    else:
        rc = 1
        out = ''
        err = ''
    module.run_command.return_value = (rc, out, err)

    guest_tech = set()
    host_tech = set()
    virtual_facts = {}
    virtual_facts['virtualization_tech_guest'] = guest_tech
    virtual_facts['virtualization_tech_host'] = host_tech


# Generated at 2022-06-20 20:29:11.158895
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vc = HPUXVirtualCollector(None)
    assert vc._platform == 'HP-UX'
    assert vc._fact_class == HPUXVirtual


# Generated at 2022-06-20 20:29:22.179209
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    my_hpuxv = HPUXVirtualCollector()
    assert my_hpuxv.platform == 'HP-UX'
    assert isinstance(my_hpuxv._fact_class, HPUXVirtual)

# Generated at 2022-06-20 20:29:30.527121
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = type('', (), {})()
    module.run_command = lambda x: (0, '', '')

    h = HPUXVirtual(module)
    f_get_virtual_facts = h.get_virtual_facts()

    assert f_get_virtual_facts.get('virtualization_type') == 'guest'
    assert f_get_virtual_facts.get('virtualization_role') == 'HPVM vPar'
    assert f_get_virtual_facts.get('virtualization_tech_guest') == set(['HPVM vPar'])
    assert f_get_virtual_facts.get('virtualization_tech_host') == set([])

    module.run_command = lambda x: (1, '', '')
    h = HPUXVirtual(module)

# Generated at 2022-06-20 20:29:33.187553
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-20 20:29:36.430510
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    c = HPUXVirtual({}, {})
    v = c.get_virtual_facts()
    assert v['virtualization_type'] == 'host'
    assert v['virtualization_role'] == 'HPVM'
    assert v['virtualization_tech_guest'] == set(['HPVM'])
    assert v['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:29:39.570040
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict())
    assert virtual.virtualization_type == 'guest'
    assert virtual.virtualization_role == 'HP vPar'
    assert 'HP vPar' in virtual.virtualization_tech_guest
    assert 'HP vPar' not in virtual.virtualization_tech_host



# Generated at 2022-06-20 20:29:43.123264
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv._platform == 'HP-UX'
    assert isinstance(hv._fact_class(), HPUXVirtual)

if __name__ == '__main__':
    test_HPUXVirtualCollector()

# Generated at 2022-06-20 20:29:46.960676
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # Check if values are correct,
    # if this test fails all other HP-UX tests will fail.
    # Use it as unit test for constructor.
    virtual = HPUXVirtual()
    assert virtual.platform == 'HP-UX'

# Generated at 2022-06-20 20:29:50.865242
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v_obj = HPUXVirtual({})
    assert v_obj.platform == 'HP-UX'
    assert v_obj._virtual_facts == {}
    assert v_obj.module == {}



# Generated at 2022-06-20 20:29:51.619425
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hp_virtual = HPUXVirtual()
    return hp_virtual

# Generated at 2022-06-20 20:29:53.749883
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    Constructor of class HPUXVirtual.
    """
    virtual = HPUXVirtual()
    assert isinstance(virtual, HPUXVirtual)



# Generated at 2022-06-20 20:30:22.063604
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux_virtual import HPUXVirtual
    HPUXVirtual_obj = HPUXVirtual()
    virtual_facts = HPUXVirtual_obj.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_tech_guest'] == set(['HP vPar'])

# Generated at 2022-06-20 20:30:27.064045
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Note: To mock module.run_command, class Virtual must be instanced
    # in module.run_command. This is done in __init__ of class HPUXVirtual
    mocked_module = MockAnsibleModule()
    mocked_module.run_command.return_value = (0, "Running VM - HPVM guest")
    hpx = HPUXVirtual(mocked_module)
    facts = hpx.get_virtual_facts()
    assert 'virtualization_type' in facts.keys()
    assert facts['virtualization_type'] == 'guest'
    assert 'virtualization_role' in facts.keys()
    assert facts['virtualization_role'] == 'HPVM'
    assert 'virtualization_tech_guest' in facts.keys()
    assert 'HPVM' in facts['virtualization_tech_guest']

# Generated at 2022-06-20 20:30:28.243369
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    c = HPUXVirtualCollector()

# Generated at 2022-06-20 20:30:37.353616
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils._text import to_bytes

    module = AnsibleModule(
        argument_spec=dict()
    )

    def mock_check_output(command):
        if command == '/usr/sbin/vecheck':
            return to_bytes('hpvpar is running')
        if command == '/opt/hpvm/bin/hpvminfo':
            return to_bytes('Running HPVM guest')
        if command == '/usr/sbin/parstatus':
            return to_bytes('There is no nPar')

    hpux = HPUXVirtual(module)
    hpux.module.run_command = mock_check_output
    virtual_facts = hpux.get_virtual_facts()


# Generated at 2022-06-20 20:30:39.817584
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virtual_facts = HPUXVirtual.get_virtual_facts(module)
    assert virtual_facts['virtualization_tech_guest'] == {'HP nPar'}

# Generated at 2022-06-20 20:30:47.330116
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class TestModule(object):
        def run_command(self, cmd):
            if cmd == '/usr/sbin/vecheck':
                return 0, 'some output', ''
        def get_bin_path(self, arg):
            return arg

    module = TestModule()

    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    virtual_facts_module = HPUXVirtual(module)

    virtual_facts = virtual_facts_module.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    assert virtual_facts['virtualization_tech_guest'] == set(['HP vPar'])
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:30:55.803806
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class ModuleMock(object):
        def run_command(self, cmd):
            return_code = 0
            stdout = ""
            stderr = ""
            if cmd == "/bin/uname -s" and stdout == "HP-UX":
                stdout = "HP-UX"
            elif cmd == "/usr/sbin/vecheck" and "vPar" in stdout:
                stdout = "vPar"
            elif cmd == "/opt/hpvm/bin/hpvminfo" and "HPVM guest" in stdout:
                stdout = "HPVM guest"
            elif cmd == "/opt/hpvm/bin/hpvminfo" and "HPVM host" in stdout:
                stdout = "HPVM host"

# Generated at 2022-06-20 20:31:01.737822
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """Test for method get_virtual_facts of class HPUXVirtual"""
    module = type('', (), {"run_command": lambda x: (0, "Running HPVM IVM", "")})
    module.exit_json = lambda x: x
    module.fail_json = lambda x: x
    mock_dict = {
        'path.exists': lambda x: True,
        'os.path.exists': lambda x: True,
        'get_distribution.get_distribution': lambda: "HP-UX",
        'get_platform_subclass.get_platform_subclass': lambda x: HPUXVirtual,
        'HPUXVirtual.__init__': lambda x: None,
        'HPUXVirtual.platform': 'HP-UX',
    }
    virtual = HPUXVirtual(module)
    virtual

# Generated at 2022-06-20 20:31:12.686037
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    facts = dict()
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    hpux_virtual = HPUXVirtual(module)
    facts = hpux_virtual.get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP nPar'
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_tech_guest'] == {'HP nPar'}
    #
    #
    #
    global rc
    rc = 1
    facts = hpux_virtual.get_virtual_facts()
    assert facts['virtualization_type'] == None
    assert facts['virtualization_role'] == None
    assert facts['virtualization_tech_host'] == set()
   

# Generated at 2022-06-20 20:31:14.176873
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpar = HPUXVirtual()
    assert hpar.platform == 'HP-UX'
    assert hpar.virtual_facts == {}
    return

# Generated at 2022-06-20 20:32:25.414567
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible_collections.ansible.community.tests.unit.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase
    from ansible_collections.ansible.community.tests.unit.modules.utils import set_module_args

    class AnsibleModuleMock(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs

        def exit_json(self, *args, **kwargs):
            raise AnsibleExitJson(args)

        def fail_json(self, *args, **kwargs):
            raise AnsibleFailJson(args)

    class HPVecheck(object):
        def __init__(self, *args, **kwargs):
            pass

        def read(self):
            return 'HPVM vPar'

# Generated at 2022-06-20 20:32:32.456872
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_hpx = HPUXVirtual()
    assert virtual_hpx.platform == 'HP-UX'
    assert virtual_hpx.get_virtual_facts() == {'virtualization_type': 'host', 'virtualization_role': 'HPVM',
                                               'virtualization_tech_host': {'HPVM'}, 'virtualization_tech_guest': {'HPVM'}}
    assert virtual_hpx.get_keys() == ['virtualization_type', 'virtualization_role', 'virtualization_tech_host', 'virtualization_tech_guest']

# Generated at 2022-06-20 20:32:33.380995
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-20 20:32:35.833952
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    if HPUXVirtualCollector._platform != 'HP-UX':
        raise Exception("Wrong platform")
    if HPUXVirtualCollector._fact_class.platform != 'HP-UX':
        raise Exception("Wrong platform")

# Generated at 2022-06-20 20:32:37.265510
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict())
    assert virtual


# Generated at 2022-06-20 20:32:39.347763
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Function to test method get_virtual_facts of class HPUXVirtual
    """
    h = HPUXVirtual()
    assert h.get_virtual_facts() == {}

# Generated at 2022-06-20 20:32:41.484977
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-20 20:32:50.228730
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    class fake_module(object):
        def __init__(self, params):
            self.params = params

        def run_command(self, command):
            return 0, out, ''

    virtual_obj = HPUXVirtual()
    setattr(virtual_obj, 'module', fake_module)

    out = 'Running in a HP vPar environment'
    virtual_facts = virtual_obj.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_tech_guest'] == set(['HP vPar'])

    out = 'Running in a HPVM environment'

# Generated at 2022-06-20 20:32:56.487290
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = type('MockModule', (object,), {'run_command': MockHPUXVirtual.run_command})
    virtual = HPUXVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts == {'virtualization_role': 'HP vPar', 'virtualization_type': 'guest', 'virtualization_tech_host': set(), 'virtualization_tech_guest': {'HP vPar'}}

# Unit test class MockHPUXVirtual

# Generated at 2022-06-20 20:32:59.047900
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = VirtualCollector._get_module()
    hpux_virtual_obj = HPUXVirtualCollector(module)


# Generated at 2022-06-20 20:33:57.130282
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class MockModule(object):
        def __init__(self, rc, stdout, stderr):
            self.rc = rc
            self.stdout = stdout
            self.stderr = stderr

        def run_command(self, cmd):
            return (self.rc, self.stdout, self.stderr)

    class MockFs(object):
        @staticmethod
        def exists(path):
            if path == '/usr/sbin/vecheck':
                return True
            elif path == '/opt/hpvm/bin/hpvminfo':
                return True
            elif path == '/usr/sbin/parstatus':
                return True
            else:
                return False

    m = HPUXVirtual(MockModule(0, "", ""))
    m.fs = MockFs()


# Generated at 2022-06-20 20:34:00.017656
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    c = HPUXVirtualCollector()
    v = c.get_virtual_facts()
    assert v is not None

# Generated at 2022-06-20 20:34:01.933135
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpx = HPUXVirtualCollector()
    assert hpx.platform == 'HP-UX'
    assert hpx._fact_class == HPUXVirtual

# Generated at 2022-06-20 20:34:05.915993
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hp_ux_vcol = HPUXVirtualCollector()
    assert hp_ux_vcol._platform is 'HP-UX'
    assert hp_ux_vcol._fact_class is HPUXVirtual


# Generated at 2022-06-20 20:34:11.593526
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'
    assert hpux_virtual.virtualization_type == 'host'
    assert len(hpux_virtual.virtualization_tech_host) == 0
    assert len(hpux_virtual.virtualization_tech_guest) == 0

# Generated at 2022-06-20 20:34:12.786851
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual()
    assert virtual.get_virtual_facts() == {}

# Generated at 2022-06-20 20:34:19.550793
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_facts = HPUXVirtualCollector().collect()
    assert virtual_facts['virtualization_type'] == 'guest' or \
        virtual_facts['virtualization_type'] == 'host' or \
        virtual_facts['virtualization_type'] == 'physical'
    assert virtual_facts['virtualization_role'] == 'HP vPar' or \
        virtual_facts['virtualization_role'] == 'HPVM vPar' or \
        virtual_facts['virtualization_role'] == 'HPVM IVM' or \
        virtual_facts['virtualization_role'] == 'HPVM' or \
        virtual_facts['virtualization_role'] == 'HP nPar' or \
        virtual_facts['virtualization_role'] == 'physical'

# Generated at 2022-06-20 20:34:23.446972
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    Test the constructor of class HPUXVirtual
    """
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'
    assert hv.virtualization_type == {}
    assert hv.virtualization_role == {}


# Generated at 2022-06-20 20:34:30.696810
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    #
    # Case 1
    #
    # A HP-UX vPar guest
    module.mock_command("/usr/sbin/vecheck", stdout="""
Value of guest_id (or ve_id) is not set.
 
Verifying if the boot device is shared...
The boot device is not shared.
 
Verifying if the root filesystem is shared...
The root filesystem is shared.
 
Checking the system is HP-UX vPars enabled...
The system is HP-UX vPars enabled.
 
Verifying if the system is configured with vPars...
The system is configured with vPars.
 
Checking if the system is running as a vPar...
The system is running as a vPar.
""")

# Generated at 2022-06-20 20:34:35.365528
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    '''
    Unit test to verify constructor of class HPUXVirtualCollector
    '''
    virtual_hpux = HPUXVirtualCollector()
    assert virtual_hpux._platform == 'HP-UX'
    assert virtual_hpux._fact_class == HPUXVirtual

# Generated at 2022-06-20 20:36:47.236728
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()

    assert hpux_virtual.platform == 'HP-UX'
    assert hpux_virtual.virtualization_type == 'guest'
    assert hpux_virtual.virtualization_role == 'HP nPar'
    assert hpux_virtual.virtualization_tech_guest == {'HP nPar'}
    assert hpux_virtual.virtualization_tech_host == set()


# Generated at 2022-06-20 20:36:50.616509
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual()

    assert virtual_obj._platform == 'HP-UX'
    assert virtual_obj.platform == 'HP-UX'


# Generated at 2022-06-20 20:36:54.936761
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    # The following arguments are required to instantiate a HPUXVirtual object
    module = MagicMock()
    # Arguments to instantiate a HPUXVirtual object
    args = (module)
    # Instantiate a HPUXVirtual object
    hpux_virtual = HPUXVirtual(*args)
    # Validate the instance created above is of type HPUXVirtual
    assert isinstance(hpux_virtual, HPUXVirtual)


# Generated at 2022-06-20 20:36:57.440579
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual()
    assert virtual_obj.platform == 'HP-UX'

# Generated at 2022-06-20 20:37:00.112640
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virt = HPUXVirtual(module)
    virt.get_virtual_facts()

# Unit test class

# Generated at 2022-06-20 20:37:02.421292
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = AnsibleModule(
        argument_spec={})
    hpux_virtual_obj = HPUXVirtual(module)
    assert hpux_virtual_obj.module == module

# Generated at 2022-06-20 20:37:08.422381
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    facts = dict()
    facts['virtualization_type'] = 'host'
    facts['virtualization_role'] = 'host'
    facts['virtualization_tech_host'] = {'HP vPar', 'HPVM vPar'}
    facts['virtualization_tech_guest'] = {'HP nPar'}
    hpux_virtual_collector = HPUXVirtualCollector(module=None, facts=facts)
    assert hpux_virtual_collector._fact_class is HPUXVirtual
    assert hpux_virtual_collector._platform == 'HP-UX'
    assert hpux_virtual_collector._facts == facts
    assert hpux_virtual_collector._virtual == None

# Unit test get_virtual_facts of class HPUXVirtual