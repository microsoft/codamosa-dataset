

# Generated at 2022-06-20 20:27:28.687905
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    "Test the get_virtual_facts method of class HPUXVirtual"
    import sys
    import os

    class MockModule(object):
        def __init__(self):
            self.run_command = MockRunCommand()
            self.exit_json = MockExitJson()
            self.fail_json = MockFailJson()

    class MockRunCommand(object):
        def __init__(self):
            self.command = None
            self.output = None
            self.rc = 0

        def __call__(self, command):
            self.command = command
            if self.rc == 0:
                return (0, self.output, '')
            else:
                return (self.rc, '', self.output)


# Generated at 2022-06-20 20:27:31.291803
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual(dict()) is not None


# Generated at 2022-06-20 20:27:33.960821
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpu = HPUXVirtualCollector()
    hpu.collect()
    return hpu

if __name__ == '__main__':
    hpu = test_HPUXVirtualCollector()
    print(hpu)

# Generated at 2022-06-20 20:27:36.760183
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv
    assert hv._fact_class
    assert hv._platform

# Generated at 2022-06-20 20:27:38.426898
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    test_obj = HPUXVirtual()
    assert test_obj.platform == 'HP-UX'

# Generated at 2022-06-20 20:27:45.928066
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    hpux_virtual = HPUXVirtual(module)

    guest_tech = set(['HP nPar', 'HP vPar', 'HPVM vPar'])
    host_tech = set(['HPVM'])
    virtual_facts = {'virtualization_type': 'guest',
                     'virtualization_role': 'HP nPar',
                     'virtualization_tech_guest': guest_tech,
                     'virtualization_tech_host': host_tech}
    hpux_virtual.module.run_command.return_value = (0, "Success", "Success")
    hpux_virtual.module.get_bin_path.return_value = '/usr/sbin'
    hpux_virtual.os.path.exists.side_effect = [True] * 4 + [False]


# Generated at 2022-06-20 20:27:48.138911
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    assert obj.platform == 'HP-UX'
    assert obj._fact_class == HPUXVirtual


# Generated at 2022-06-20 20:27:56.683255
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpar import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpvm import HPUXVirtual as hpvm
    from ansible.module_utils.facts.virtual.hpvm import HPUXVirtual
    from ansible.module_utils.facts.virtual.npar import HPUXVirtual
    from ansible.module_utils.facts.virtual.ivm import HPUXVirtual
    from ansible.module_utils.facts.virtual.common import Virtual
    from ansible.module_utils.facts.virtual import VirtualCollector
    import os

    # Create a 'HPUXVirtual' object
    v = HPUXVirtual()

    # Set module variable
    v.module = Virtual()

    # Create a 'VirtualCollector' object.
    vc = VirtualCollect

# Generated at 2022-06-20 20:28:01.768150
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({})
    virtual_facts = hv.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    assert 'HPVM vPar' in virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-20 20:28:03.835370
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """ Verify the constructor for HPUXVirtualCollector directly. """
    hv = HPUXVirtualCollector()
    assert hv is not None

# Generated at 2022-06-20 20:28:13.442029
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual({}, {}, {})
    assert virtual.platform == 'HP-UX'


# Generated at 2022-06-20 20:28:20.147880
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ..testing.mock import MockModule
    import os.path

    def mock_run_command(module, command):
        if command == '/usr/sbin/vecheck':
            return 0, '', ''
        else:
            return 1, '', ''

    def mock_path_exists(module, path):
        if path == '/usr/sbin/vecheck':
            return True
        else:
            return False

    module = MockModule(run_command=mock_run_command,
                        path_exists=mock_path_exists)
    hpux_virtual = HPUXVirtual(module)
    virtual_facts = hpux_virtual.get_virtual_facts()

# Generated at 2022-06-20 20:28:29.739484
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import builtins

    # Create a definition of python module 'ansible.module_utils.facts.virtual.hpu_ux'
    # that is required when the tested module executes.
    # The test data has been created from an instance of the tested module
    # executed on a HP-UX system that is neither HP vPar, nor HPVM vPar, nor HPVM guest,
    # nor HPVM host, nor HP nPar.
    # This definition of python module 'ansible.module_utils.facts.virtual.hpu_ux'
    # is sufficient to execute the tested method.
    module_name = 'ansible.module_utils.facts.virtual.hpu_ux'

# Generated at 2022-06-20 20:28:32.246836
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual({})
    assert virtual_obj.platform == 'HP-UX'


# Generated at 2022-06-20 20:28:37.572175
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    virtual_facts = HPUXVirtual(module)
    assert virtual_facts.get_virtual_facts() == dict(virtualization_type='guest',
                                                     virtualization_role='HP vPar',
                                                     virtualization_tech_guest=set(['HP vPar']),
                                                     virtualization_tech_host=set())


# Generated at 2022-06-20 20:28:40.502582
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'
    assert hv.get_virtual_facts() == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}


# Generated at 2022-06-20 20:28:42.038719
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert x.__class__.__name__ == 'HPUXVirtualCollector'


# Generated at 2022-06-20 20:28:43.301147
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict())
    assert virtual.platform == 'HP-UX'
    assert virtual.module is None

# Generated at 2022-06-20 20:28:51.392669
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec={
            'filter': {'required': False, 'type': 'list'},
        }
    )
    virtual = HPUXVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    assert set(virtual_facts['virtualization_tech_guest']) == set(['HP vPar'])
    assert virtual_facts['virtualization_tech_host'] == set([])

# Generated at 2022-06-20 20:28:52.333741
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert VirtualCollector.platforms['HP-UX'] == HPUXVirtualCollector

# Generated at 2022-06-20 20:29:04.639257
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector()

# Generated at 2022-06-20 20:29:06.298053
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    assert obj._fact_class == HPUXVirtual


# Generated at 2022-06-20 20:29:07.100482
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpvirtual = HPUXVirtual()
    assert hpvirtual

# Generated at 2022-06-20 20:29:09.883142
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import VirtualCollector as HPUXVirtualCollector
    from ansible.module_utils.facts.virtual.hpux import Virtual as HPUXVirtual
    facts = HPUXVirtual().get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP vPar'
    assert facts['virtualization_tech_guest'] == set(['HP vPar'])
    assert facts['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:29:12.703251
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    v = HPUXVirtual(dict())
    assert v.get_virtual_facts() == {'virtualization_type': 'guest',
                                     'virtualization_role': 'HP nPar',
                                     'virtualization_tech_host': set(),
                                     'virtualization_tech_guest': set(['HP nPar','HP vPar','HPVM vPar','HPVM IVM','HPVM'])}

if __name__ == '__main__':
    test_HPUXVirtual_get_virtual_facts()

# Generated at 2022-06-20 20:29:13.878202
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv.platform == 'HP-UX'
    assert hv._fact_class == HPUXVirtual


# Generated at 2022-06-20 20:29:15.423259
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpuxvirtual_platform = HPUXVirtual(dict())
    assert hpuxvirtual_platform.platform == 'HP-UX'



# Generated at 2022-06-20 20:29:18.257742
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = FakeAnsibleModule()
    hpux_virtual = HPUXVirtualCollector(module)
    hpux_virtual.collect()
    assert hpux_virtual._platform == 'HP-UX'
    assert hpux_virtual._fact_class == HPUXVirtual



# Generated at 2022-06-20 20:29:19.817430
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_collector = HPUXVirtual()
    assert virtual_collector.platform == 'HP-UX'

# Generated at 2022-06-20 20:29:22.312861
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpux_collector = HPUXVirtualCollector()
    assert hpux_collector._platform == 'HP-UX'
    assert issubclass(hpux_collector._fact_class, HPUXVirtual)

# Generated at 2022-06-20 20:29:47.909628
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt = HPUXVirtual({})
    assert virt.platform == 'HP-UX'
    assert virt.virtualization_type is None
    assert virt.virtualization_role is None
    assert virt.virtualization_system is None
    assert virt.virtualization_uuid is None
    assert virt.virtualization_hypervisor is None
    assert virt.virtualization_product_name is None
    assert virt.virtualization_product_version is None
    assert virt.virtualization_product_serial is None
    assert virt.virtualization_product_uuid is None
    assert virt.virtualization_product_family is None
    assert virt.virtualization_product_vendor is None
    assert virt.virtual_interfaces is None
    assert virt.virtualization_tech_guest is None
    assert virt.virtualization_tech_host is None

# Generated at 2022-06-20 20:29:56.135108
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # This function returns a class object to be used to in test cases
    class ModuleMock:
        def __init__(self):
            self.run_command = run_command_mock
    obj = ModuleMock()

    # Note : For testing purpose, we mock ansible.module_utils.basic.AnsibleModule.run_command
    # To ensure test cases are independent, we pass run_command_mock as method of an object rather than a global function
    def run_command_mock(self, cmd, check_rc=True, close_fds=True, executable=None, data=None, binary_data=True):
        """
        run_command_mock is a custom method used to mock AnsibleModule.run_command
        This method is passed as a parameter to HPUXVirtual.get_virtual_facts
        """


# Generated at 2022-06-20 20:30:08.553730
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict()
    )

    virtual_facts = HPUXVirtual(module).get_virtual_facts()

    assert (virtual_facts['virtualization_tech_host'] == set())
    assert len(virtual_facts['virtualization_tech_guest']) <= 5

    if os.path.exists('/usr/sbin/vecheck'):
        assert "HP vPar" in virtual_facts['virtualization_tech_guest']
        assert virtual_facts['virtualization_type'] == "guest"
        assert virtual_facts['virtualization_role'] == "HP vPar"

# Generated at 2022-06-20 20:30:15.092659
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = type('', (object,), {'run_command': lambda s, c: (0, 'somename\nsomestring', '')})()
    hpuxv = HPUXVirtual(module)
    assert hpuxv.get_virtual_facts() == {
        'virtualization_type': 'guest',
        'virtualization_role': 'HP vPar',
        'virtualization_tech_guest': {'HP vPar'},
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-20 20:30:18.088532
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    facts = {'distribution': 'HP-UX'}
    virtual_collector = HPUXVirtualCollector(facts, None)
    assert virtual_collector._platform == 'HP-UX'

# Generated at 2022-06-20 20:30:20.974652
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual({'module_name': 'Test', 'module_args': {}})
    assert v.platform == 'HP-UX'
    if hasattr(v, '_cache_dir'):
        assert v._cache_dir == '/tmp/ansible_facts'

# Generated at 2022-06-20 20:30:24.636571
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    class ModuleStub(object):
        def __init__(self):
            self.run_command = ['rc', 'out', 'err']

    h_facts = HPUXVirtual(ModuleStub())
    # test get_virtual_facts method
    hfacts = h_facts.get_virtual_facts()

    assert hfacts['virtualization_tech_guest'] == set()
    assert hfacts['virtualization_tech_host'] == set()



# Generated at 2022-06-20 20:30:28.719303
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    facts = HPUXVirtualCollector(None).collect()
    assert 'virtualization_role' in facts
    assert 'virtualization_type' in facts
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_tech_guest' in facts

# Generated at 2022-06-20 20:30:29.732279
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    obj = HPUXVirtual({}, {})
    obj.get_virtual_facts()

# Generated at 2022-06-20 20:30:39.169886
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible_collections.ansible.community.tests.unit.compat.mock import MagicMock
    from ansible_collections.ansible.community.tests.unit.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase, set_module_args
    mock_module = MagicMock(return_value=AnsibleExitJson(changed=False, ansible_facts=dict(virtualization_tech_guest = ['HPVM IVM', 'HPVM vPar', 'HP nPar'], virtualization_tech_host = ['HPVM'], virtualization_type = 'guest', virtualization_role = 'HPVM IVM')))
    with set_module_args(dict(gather_subset='all')):
        with mock_module as testcase:
            testobj = HPUXVirtual

# Generated at 2022-06-20 20:31:09.923790
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    import ansible.module_utils.facts.collector

    class FakeModule():
        def __init__(self, params):
            self.params = params
            self.run_command_calls = []
            self.run_command_rcs = []
            self.run_command_outs = []
            self.run_command_errs = []

        def fail_json(self, params):
            pass

        def run_command(self, args):
            self.run_command_calls.append(args)
            return (self.run_command_rcs.pop(), self.run_command_outs.pop(),
                    self.run_command_errs.pop())

    # Testing HP vPar
    module = FakeModule({})


# Generated at 2022-06-20 20:31:12.502423
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict())
    assert virtual.platform == 'HP-UX'


# Generated at 2022-06-20 20:31:14.679027
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    collector = HPUXVirtualCollector()
    assert collector._platform == 'HP-UX'
    assert collector._fact_class.platform == 'HP-UX'
    assert collector._fact_class.__name__ == 'HPUXVirtual'

# Generated at 2022-06-20 20:31:15.783478
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'


# Generated at 2022-06-20 20:31:20.072061
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_obj = HPUXVirtualCollector()
    assert virtual_obj._platform == 'HP-UX'
    assert isinstance(virtual_obj._fact_class, type)
    assert virtual_obj._fact_class.__name__ == 'HPUXVirtual'
    assert virtual_obj._fact_class.__module__ == 'ansible.module_utils.facts.virtual.HP_UX'

# Generated at 2022-06-20 20:31:24.751950
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    facts = dict()
    virtual_collector = HPUXVirtualCollector(facts, None)
    assert virtual_collector.platform == 'HP-UX'
    assert virtual_collector._fact_class.platform == 'HP-UX'

# Generated at 2022-06-20 20:31:26.259950
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual({}).platform == 'HP-UX'

# Generated at 2022-06-20 20:31:33.566537
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = type('module', (object,), {})()
    module.run_command = lambda: (0, '', '')
    module.params = {}
    fact = HPUXVirtual(module)
    assert fact.get_virtual_facts() == {
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': {'HP vPar', 'HP nPar', 'HPVM IVM',
                                      'HPVM vPar', 'HPVM'},
        'virtualization_role': 'HPVM IVM',
        'virtualization_type': 'guest'}

# Generated at 2022-06-20 20:31:37.121158
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({'module': ''})
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-20 20:31:40.553119
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    assert virtual_facts._platform == 'HP-UX'
    for key in virtual_facts._data.keys():
        assert key in ('virtualization_type', 'virtualization_role',
                       'virtualization_tech_host', 'virtualization_tech_guest')


# Generated at 2022-06-20 20:32:38.593032
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = MockModule()
    facts = HPUXVirtual(module).get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP vPar'
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_tech_guest'] == {'HP vPar'}


# Generated at 2022-06-20 20:32:41.072232
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    x = HPUXVirtualCollector()
    assert x.__class__.__name__ == 'HPUXVirtualCollector'


# Generated at 2022-06-20 20:32:49.726765
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
        from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
        from ansible.module_utils.facts.virtual import Virtual
        from ansible.module_utils.facts import ModuleFacts

        hpux_virtual = HPUXVirtual()

        # Test get_virtual_facts for HPVM host
        # Test hpvm host with vpar.
        module = ModuleFacts(
             '',
             '',
             {
                 'virtualization_type': 'host',
                 'virtualization_role': 'HPVM',
                 'virtualization_tech_host': ['HPVM'],
                 'virtualization_tech_guest': ['HPVM vPar']
             }
         )
        hpux_virtual.module = module
        hpux_virtual.get_virtual_facts()

        # Test hpvm host with ivm

# Generated at 2022-06-20 20:32:52.685472
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_object = HPUXVirtual(dict())
    assert virtual_object.platform == 'HP-UX'


# Generated at 2022-06-20 20:32:56.517607
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    x = HPUXVirtual(dict(ANSIBLE_MODULE_ARGS={}))
    print("virtual_facts: %s" % x.get_virtual_facts())

if __name__ == '__main__':
    test_HPUXVirtual_get_virtual_facts()

# Generated at 2022-06-20 20:33:00.878316
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    facts = {}
    facts['virtualization_type'] = 'guest'
    facts['virtualization_role'] = 'HP vPar'
    hpuxVirt = HPUXVirtual(facts, None)
    assert hpuxVirt.virtualization_type == 'guest'
    assert hpuxVirt.virtualization_role == 'HP vPar'

# Generated at 2022-06-20 20:33:02.919563
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    x = HPUXVirtual({})
    assert x.platform == 'HP-UX'
    assert x.get_virtual_facts() == {}


# Generated at 2022-06-20 20:33:05.417224
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual(dict(), dict())
    assert v.platform == 'HP-UX'
    assert v.guest_tech == set()
    assert v.host_tech == set()


# Generated at 2022-06-20 20:33:09.327849
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtualClass = HPUXVirtual(dict())
    assert virtualClass.__class__.__name__ == 'HPUXVirtual'
    assert virtualClass.platform == 'HP-UX'
    assert virtualClass.get_virtual_facts.__class__.__name__ == 'function'


# Generated at 2022-06-20 20:33:15.253599
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    import platform

    module = platform.system()
    virtual = HPUXVirtual(module)
    facts = virtual.get_facts()
    assert virtual.platform == 'HP-UX'
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts

# Generated at 2022-06-20 20:34:00.079124
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    # initialize a HPUXVirtualCollector object
    HPUXVirtualCollector()

# Generated at 2022-06-20 20:34:06.434710
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(dict())

    assert hv.platform == 'HP-UX'
    assert hv.get_virtual_facts() == {
          'virtualization_type': 'guest',
          'virtualization_role': 'HP nPar',
          'virtualization_technologies': {'host': set(), 'guest': set()},
          'virtualization_tech_host': set(),
          'virtualization_tech_guest': set()}



# Generated at 2022-06-20 20:34:10.189289
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpx_virtual = HPUXVirtual({})
    assert hpx_virtual.collect() == {"virtualization_tech_guest": set(), "virtualization_tech_host": set()}

# Generated at 2022-06-20 20:34:18.674977
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.six import PY3
    hpux_virtual_fact = HPUXVirtual()
    if PY3:
        from ansible.module_utils.facts.virtual.hpux import Virtual, VirtualCollector
        hpux_rc, hpux_out, hpux_err = hpux_virtual_fact.module.run_command("/usr/sbin/parstatus")
        assert hpux_rc == 0
        hpux_rc, hpux_out, hpux_err = hpux_virtual_fact.module.run_command("/usr/sbin/vecheck")
        assert hpux_rc == 0
        hpux_rc, hpux_out, hpux_err = hpux_virtual_fact.module

# Generated at 2022-06-20 20:34:25.143822
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtualCollector().collect()[0]
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HPVM'
    assert 'HPVM vPar' in virtual_facts['virtualization_tech_guest']
    assert 'HPVM guest' in virtual_facts['virtualization_tech_guest']
    assert 'HPVM IVM' in virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-20 20:34:36.362306
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    v = HPUXVirtual()
    v._module.run_command = run_command_mock
    v._module.get_bin_path = get_bin_path_mock
    assert v.get_virtual_facts() == {'virtualization_type': 'guest', 'virtualization_role': 'HP nPar',
                                     'virtualization_tech_guest': {'HP nPar', 'HP vPar'}, 'virtualization_tech_host': set()}
    v._module.run_command = run_command_mock_nopar
    assert v.get_virtual_facts() == {'virtualization_type': 'guest', 'virtualization_role': 'HP vPar',
                                     'virtualization_tech_guest': {'HP vPar'}, 'virtualization_tech_host': set()}




# Generated at 2022-06-20 20:34:37.728213
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXvirtual = HPUXVirtual()
    assert HPUXvirtual.platform == 'HP-UX'

# Generated at 2022-06-20 20:34:42.196950
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector(dict())
    assert hv.__str__() == 'HP-UX'
    assert hv.__repr__() == '<hpxvirtual.HPUXVirtualCollector(name=HP-UX)>'

# Generated at 2022-06-20 20:34:53.099229
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts import Collector

    fake_ansible_module = object()
    collector = Collector(fake_ansible_module)

    hpx = HPUXVirtual(collector)
    result = hpx.get_virtual_facts()

    # result is not None
    assert result is not None

    # virtualization_role is correct
    assert result['virtualization_role'] == 'HP nPar'

    # virtualization_type is correct
    assert result['virtualization_type'] == 'guest'

    # virtualization_tech_guest is correct
    assert 'HP nPar' in result['virtualization_tech_guest']
    assert len(result['virtualization_tech_guest']) == 1

    # virtualization_tech_host is correct

# Generated at 2022-06-20 20:34:59.585390
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class
    HPUXVirtualCollector
    """
    from ansible.module_utils.facts import ModuleStub
    from ansible.module_utils.facts.virtual.hpx import HPUXVirtual
    import sys
    import re
    import os

    if sys.version_info.major < 3:
        # In Python 2, Mock() is a class, and you instantiate it by calling
        # it. In Python 3, Mock() is a function that returns an instance of a
        # class, and you instantiate it by calling the function.
        from mock import Mock as mock_class
    else:
        from unittest.mock import Mock as mock_class

    hpx_virtual = HPUXVirtual(ModuleStub())

# Generated at 2022-06-20 20:37:06.601161
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    hpux = HPUXVirtual({})
    assert hpux.get_virtual_facts() == {}