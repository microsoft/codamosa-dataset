

# Generated at 2022-06-20 20:27:25.595884
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    When we create a HPUXVirtual instance with a dict, we should get back
    a dict with the following keys, with the correct values
    """
    expected_result = {
        'virtualization_type': 'guest',
        'virtualization_role': 'HP vPar',
        'virtualization_tech_guest': set(['HP vPar']),
        'virtualization_tech_host': set()
    }
    hpxv = HPUXVirtual({})
    assert hpxv.get_virtual_facts() == expected_result


# Generated at 2022-06-20 20:27:35.413465
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class HPUXVirtual.

    HPUXVirtual.get_virtual_facts()
    """
    # Set up mock modules and command results.
    # def run_command(self, args, check_rc=True, close_fds=True, executable=None,
    #        data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False,
    #        prompt_regex=None)
    # command_results[command] = (rc, stdout, stderr)
    command_results = {}
    command_results["/usr/sbin/vecheck"] = (0, "out1", "")

# Generated at 2022-06-20 20:27:38.601887
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.__dict__ == {
        'module': {},
        'platform': 'HP-UX',
    }


# Generated at 2022-06-20 20:27:45.394246
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():

    module = AnsibleModule()
    hpux_virtual_obj = HPUXVirtual(module)

    assert hpux_virtual_obj.platform == 'HP-UX'
    assert hpux_virtual_obj._platform == 'HP-UX'
    assert hpux_virtual_obj.get_virtual_facts()['virtualization_tech_host'] == set()
    assert hpux_virtual_obj.get_virtual_facts()['virtualization_tech_guest'] == set()
    assert hpux_virtual_obj.get_virtual_facts()['virtualization_type'] == 'host'
    assert hpux_virtual_obj.get_virtual_facts()['virtualization_role'] == 'HPVM'



# Generated at 2022-06-20 20:27:54.235708
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    '''
    Test HPUXVirtual
    '''
    mock_module = type('module', (object,), {'run_command':
                                             lambda x: (0,
                                                        '',
                                                        '')})
    mock_module.exit_json = lambda x: x
    mock_module.fail_json = lambda x: x

    hv = HPUXVirtual(mock_module)

    hv._get_virtual_facts()

    assert hv.data['virtualization_type'] == 'guest'
    assert hv.data['virtualization_role'] == 'HP vPar'
    assert hv.data['virtualization_tech_guest'] == set(['HP vPar'])
    assert hv.data['virtualization_tech_host'] == set()



# Generated at 2022-06-20 20:27:55.909793
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    HPUXVirtualCollector()

# Generated at 2022-06-20 20:28:03.098181
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    _HPUXVirtual = HPUXVirtual(basic.AnsibleModule(argument_spec={}))
    _HPUXVirtual.get_virtual_facts()
    assert _HPUXVirtual.facts['virtualization_type'] == 'guest'
    assert _HPUXVirtual.facts['virtualization_role'] == 'HP vPar'
    assert to_bytes('HP vPar') in _HPUXVirtual.facts['virtualization_tech_guest']

# Generated at 2022-06-20 20:28:11.033494
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import sys, io
    import ansible.module_utils.facts.virtual.hpux_virtual as HPUXVirtual
    from ansible.module_utils.facts.virtual import VirtualCollector

    # create a subclass of HPUXVirtual with a dummy module object
    class HPUXVirtualTest(HPUXVirtual.HPUXVirtual):
        def __init__(self, module):
            self.module=module

    # create dummy module object
    module = AnsibleModuleMock()

    # create a simple dictionary of return values for get_virtual_facts
    virtual_facts = {
        'virtualization_type': 'host',
        'virtualization_role': 'HPVM',
        'virtualization_tech_host': set(['HPVM']),
        'virtualization_tech_guest': set()
        }

    # create a subclass

# Generated at 2022-06-20 20:28:12.996560
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    assert obj.platform == 'HP-UX'
    assert obj._fact_class == HPUXVirtual



# Generated at 2022-06-20 20:28:15.387742
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module_mock = MockModule()
    fact_class_mock = MockHPUXVirtual()
    hpux_virtual_collector = HPUXVirtualCollector(module_mock, fact_class_mock)

    assert hpux_virtual_collector._platform == 'HP-UX'
    assert hpux_virtual_collector._fact_class == fact_class_mock
    assert hpux_virtual_collector._supported_facts == ['virtual_facts', 'all']
    assert hpux_virtual_collector._facts == {}


# Generated at 2022-06-20 20:28:34.573218
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual()
    assert h.platform == 'HP-UX'
    assert h.get_virtual_facts() == {}


# Generated at 2022-06-20 20:28:36.987167
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert virtual_collector._platform == 'HP-UX'
    assert virtual_collector._fact_class == HPUXVirtual

# Generated at 2022-06-20 20:28:38.838121
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual()
    # Testing existence of correct platform
    assert virtual_facts.platform == 'HP-UX'



# Generated at 2022-06-20 20:28:42.533412
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = AnsibleModuleMock()
    collector = HPUXVirtualCollector(module)
    assert collector.platform == 'HP-UX'
    assert collector._fact_class == HPUXVirtual
    assert collector._fact_class.platform == 'HP-UX'
    assert collector.collect() == dict(virtual=dict(virtualization_tech_guest=set(), virtualization_tech_host=set()))

# Generated at 2022-06-20 20:28:43.834601
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'
    assert hv._platform == 'HP-UX'

# Generated at 2022-06-20 20:28:47.154707
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    m = {'run_command.return_value': (0, 'Running HPVM guest with Virtual CPU(s) 1', '')}
    module = Mock(**m)
    myobj = HPUXVirtual(module)
    assert myobj.get_virtual_facts() == {'virtualization_type': 'guest',
                                         'virtualization_role': 'HPVM IVM',
                                         'virtualization_tech_guest': set(['HPVM IVM']),
                                         'virtualization_tech_host': set()}

# Generated at 2022-06-20 20:28:55.838154
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    testmodule = get_testmodule()
    HPUXVirtual.module = testmodule

    if os.path.exists('/usr/sbin/vecheck'):
        from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
        rc, out, err = HPUXVirtual.module.run_command("/usr/sbin/vecheck")
        if rc == 0:
            facts = HPUXVirtual.get_virtual_facts()
            assert facts['virtualization_type'] == 'guest'
            assert facts['virtualization_role'] == 'HP vPar'

    if os.path.exists('/opt/hpvm/bin/hpvminfo'):
        from ansible.module_utils.facts.virtual.hpux import HPUXVirtual

# Generated at 2022-06-20 20:28:58.671442
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """Tests if necessary class attributes are initialised properly."""
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-20 20:29:09.183447
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpar import Virtual
    from ansible.module_utils.facts.virtual.hpar import VirtualCollector

    class FakeModule(object):
        def run_command(self, cmd):
            if cmd == "/usr/sbin/vecheck":
                return (0, "", "")
            elif cmd == "/opt/hpvm/bin/hpvminfo":
                return (0, "Running HPVM vPar", "")
            elif cmd == "/usr/sbin/parstatus":
                return (0, "", "")
            else:
                return (-1, "", "")

    module = FakeModule()
    virtual = HPUXVirtual(module)

    res = virtual.get_virtual_facts()
    assert 'virtualization_type' in res

# Generated at 2022-06-20 20:29:17.791469
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    '''
    Positive test:
        Try to obtain virtualization facts from a HPUX machine that
        has been configured as HPVM guest and HPVM vPar

    Negative test:
        Try to obtain virtualization facts from a HPUX machine that
        has not been configured as HPVM guest and HPVM vPar
    '''
    virtual_facts = dict()
    hpux_virtual = HPUXVirtual()

    if (os.path.exists('/opt/hpvm/bin/hpvminfo') and os.path.exists('/usr/sbin/vecheck')
        and os.path.exists('/usr/sbin/parstatus')):
        virtual_facts = hpux_virtual.get_virtual_facts()
        assert virtual_facts['virtualization_tech_host'] == set([])

# Generated at 2022-06-20 20:29:49.464065
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpx = HPUXVirtual(None)
    assert True

# Generated at 2022-06-20 20:29:52.116979
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector._platform == 'HP-UX'
    assert HPUXVirtualCollector._fact_class._platform == 'HP-UX'

# Generated at 2022-06-20 20:29:59.236515
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    facts = dict(
        ANSIBLE_MODULE_ARGS=dict(
            gather_subset='all',
            fact_path='/etc/ansible/facts.d',
        ),
        ansible_facts=dict(
            ansible_cmdline=dict(
                ansible_facts=None,
                gather_subset=['all'],
            ),
            ansible_local=dict(
                fact_path='/etc/ansible/facts.d',
            ),
        )
    )
    collector = HPUXVirtualCollector(facts, None)
    assert collector is not None

# Generated at 2022-06-20 20:30:00.938141
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict())

# Generated at 2022-06-20 20:30:04.618006
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert virtual_collector._facts is None
    assert virtual_collector._platform == 'HP-UX'
    assert virtual_collector._fact_class == HPUXVirtual

# Generated at 2022-06-20 20:30:12.452126
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import HPUXVirtual
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.hpux_virtual import HPUXVirtualCollector

    class AnsibleModule(object):

        def __init__(self):
            self.params = {}

        def get_bin_path(self, arg, **kwargs):
            return arg

    class TestFactCollector(BaseFactCollector):
        _fact_class = Virtual
        _platform = 'HP-UX'

    module = AnsibleModule()
    hpux_virtual = HPUXVirtual(module)

# Generated at 2022-06-20 20:30:13.993372
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux = HPUXVirtual(dict())
    assert hpux.platform == 'HP-UX'

# Generated at 2022-06-20 20:30:18.731965
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpux_virtual_collector = HPUXVirtualCollector(None)
    assert hpux_virtual_collector is not None
    assert isinstance(hpux_virtual_collector, VirtualCollector)
    assert hpux_virtual_collector._platform == 'HP-UX'
    assert hpux_virtual_collector._fact_class == HPUXVirtual


# Generated at 2022-06-20 20:30:21.852815
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class MockModule(object):
        def run_command(self, command, check_rc=True):
            pass
    module = MockModule()
    hpuxvirt = HPUXVirtual(module)
    assert isinstance(hpuxvirt, HPUXVirtual)
    hpuxvirt.get_virtual_facts()

# Generated at 2022-06-20 20:30:23.384279
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-20 20:30:55.207045
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    v = HPUXVirtualCollector()
    assert v.platform == 'HP-UX'
    assert v._fact_class == HPUXVirtual


# Generated at 2022-06-20 20:30:55.988739
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual({}, {}, {}, {})
    assert hv.virtual

# Generated at 2022-06-20 20:31:03.624857
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Set up a module
    module = AnsibleModule(
        argument_spec = dict()
    )

    # Set up a HPUXVirtual
    hv = HPUXVirtual(module)

    # Set up virtual facts
    virtual_facts = dict()
    guest_tech = set()
    guest_tech.add('HP vPar')
    guest_tech.add('HPVM vPar')
    guest_tech.add('HPVM IVM')
    guest_tech.add('HP nPar')
    host_tech = set()

    virtual_facts['virtualization_type'] = 'guest'
    virtual_facts['virtualization_role'] = 'HP nPar'
    virtual_facts['virtualization_tech_guest'] = guest_tech
    virtual_facts['virtualization_tech_host'] = host_tech

    #

# Generated at 2022-06-20 20:31:04.936945
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    a = HPUXVirtual({})
    return a.virtual

# Generated at 2022-06-20 20:31:14.176715
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        )
    )
    # Initializing HP-UX virtual collector instance
    hpux_virtual_collector = HPUXVirtualCollector(module)
    # Checking if the variables defined in the constructor are set correctly
    assert hpux_virtual_collector._fact_class is not None
    assert hpux_virtual_collector._platform == 'HP-UX'
    assert hpux_virtual_collector._gather_subset == ['!all']
    assert hpux_virtual_collector._gather_network is False


# Generated at 2022-06-20 20:31:14.965941
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    r = HPUXVirtual({}, None)
    assert r.platform == 'HP-UX'


# Generated at 2022-06-20 20:31:17.013551
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector.platform == 'HP-UX'
    assert HPUXVirtualCollector._fact_class.platform == 'HP-UX'

# Generated at 2022-06-20 20:31:19.892383
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """
    Unit test for constructor of class HPUXVirtualCollector.
    """
    huxvirtual = HPUXVirtualCollector()
    assert huxvirtual.platform == 'HP-UX'
    assert huxvirtual.fact_class._platform == 'HP-UX'

# Generated at 2022-06-20 20:31:24.070617
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    Unit test for constructor of class HPUXVirtual
    """
    hpux_virtual = HPUXVirtual({})
    assert type(hpux_virtual) == HPUXVirtual


# Generated at 2022-06-20 20:31:32.198630
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    class X:
        def __init__(self, x=None):
            self.x = x
    x = X('bar')
    hpuxvirtualcollector = HPUXVirtualCollector(x)
    if hasattr(hpuxvirtualcollector, '_fact_class'):
        assert hpuxvirtualcollector._fact_class == HPUXVirtual
    if hasattr(hpuxvirtualcollector, '_platform'):
        assert hpuxvirtualcollector._platform == 'HP-UX'
    if hasattr(hpuxvirtualcollector, 'module'):
        assert hpuxvirtualcollector.module == x


# Generated at 2022-06-20 20:32:12.512733
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = type('', (), {})()
    module.run_command = lambda x: (0, None, None)
    module.run_command.__name__ = 'run_command()'
    virtual = HPUXVirtual(module)
    virtual.get_virtual_facts()
    print(virtual._Virtual__virtual_facts)
    assert 'virtualization_tech_host' in virtual._Virtual__virtual_facts
    assert 'virtualization_tech_guest' in virtual._Virtual__virtual_facts
    assert virtual._Virtual__virtual_facts['virtualization_tech_guest'] == set()
    assert virtual._Virtual__virtual_facts['virtualization_tech_host'] == set()


if __name__ == '__main__':
    test_HPUXVirtual_get_virtual_facts()

# Generated at 2022-06-20 20:32:14.040833
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector._fact_class == HPUXVirtual
    assert HPUXVirtualCollector._platform == 'HP-UX'

# Generated at 2022-06-20 20:32:25.205997
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Mock a Module
    from ansible.module_utils.facts import ModuleStub
    module = ModuleStub()

    # Mock a Virtual instance
    import ansible.module_utils.facts.virtual.hphpu as hphpu
    v = hphpu.HPUXVirtual(module)

    # Define a test case where parstatus output contains 
    # the string parstatus:info:nPar
    # and vecheck output contains the string vecheck:info:vPar
    # and hpvminfo output contains the string hpvminfo:info:Running on HPVM guest
    # No hpvminfo installed
    hphpu.os.path.exists = lambda x: True if x == '/usr/sbin/parstatus' else False

# Generated at 2022-06-20 20:32:27.023052
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_facts = HPUXVirtualCollector().collect()
    assert len(virtual_facts) == 1

# Generated at 2022-06-20 20:32:30.007229
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """
    Test the constructor of HPUXVirtual.
    """
    virtual = HPUXVirtual(dict())
    assert virtual.platform == 'HP-UX'
    assert virtual.guest_tech == set()
    assert virtual.host_tech == set()

# Generated at 2022-06-20 20:32:30.860660
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()



# Generated at 2022-06-20 20:32:38.133247
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hp_ux import HPUXVirtual
    import sys

    if sys.version_info.major == 2:
        import __builtin__ as builtins  # pylint: disable=import-error
    else:
        import builtins  # pylint: disable=import-error

    # mock module class
    class MockModule:
        def __init__(self):
            self.params = {}
            self.check_mode = False
            self.exit_json = None
            self.fail_json = None

        def run_command(self, command):
            if command == '/usr/sbin/parstatus':
                return 0, 'Running HP nPar', None
            return 1, None, None

    # mock AnsibleModule class

# Generated at 2022-06-20 20:32:46.574329
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # We mock the module object, as it's used inside of Virtual class __init__
    # Unfortunately we can't just patch the module object, as the module object
    # is not a subclass of object, so the magic methods are not there.
    # So we create a subclass of Virtual and patch this.
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual

    class VirtualMock(HPUXVirtual):
        def __init__(self, *args, **kwargs):
            self.module = MockModule()

    class MockModule(object):
        def __init__(self):
            self.run_command = MockFunction()
            self.exit_json = MockFunction()
            self.fail_json = MockFunction()
            self.check_mode = False


# Generated at 2022-06-20 20:32:48.946080
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-20 20:32:57.680827
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import json

    c = HPUXVirtualCollector(dict(ANSIBLE_MODULE_ARGS=dict(gather_subset='!all,min')), basic.AnsibleModule(
    ))
    c.collect()
    facts = c.get_facts()
    virtual_facts = facts['virtualization']
    assert len(virtual_facts) == 4
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()
    assert 'virtualization_type' not in virtual_facts
    assert 'virtualization_role' not in virtual_facts


# Unit test get_virtual_facts() of class HPUXVirtual

# Generated at 2022-06-20 20:33:26.130784
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(dict())
    assert virtual

# Generated at 2022-06-20 20:33:27.115754
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    obj = HPUXVirtual(dict())
    assert obj

# Generated at 2022-06-20 20:33:28.441531
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual(module=None)
    assert virtual.platform == 'HP-UX'

# Generated at 2022-06-20 20:33:30.968205
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert virtual_collector._fact_class is HPUXVirtual
    assert virtual_collector._platform is 'HP-UX'


# Generated at 2022-06-20 20:33:31.488361
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    HPUXVirtual()

# Generated at 2022-06-20 20:33:32.877577
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hw = HPUXVirtual(dict(module=None), None)
    assert hw.platform == 'HP-UX'

# Generated at 2022-06-20 20:33:37.736329
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import zlib
    from ansible.module_utils.facts.virtual import HPUXVirtual
    module = None
    set_module_args = dict()
    v = HPUXVirtual(module)
    virtual_facts = v.get_virtual_facts()
    assert virtual_facts == {}

# Generated at 2022-06-20 20:33:42.575969
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    from ansible.module_utils.facts.virtual.hpubs_virtual import HPUXVirtualCollector
    avc = HPUXVirtualCollector("./ansible/module_utils/facts/virtual")
    assert avc is not None


# Generated at 2022-06-20 20:33:44.983014
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    assert HPUXVirtualCollector._fact_class == HPUXVirtual
    assert HPUXVirtualCollector._platform == 'HP-UX'

# Generated at 2022-06-20 20:33:48.849870
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    result = HPUXVirtualCollector()
    assert result.platform == 'HP-UX'
    assert result.__class__.__name__ == 'HPUXVirtualCollector'

# Generated at 2022-06-20 20:34:17.328020
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    class TestModule(object):
        def __init__(self):
            self.run_command_was_called = False
            self.rc = 0
            self.out = "HPVM guest running on HPVM host"
            self.err = ""

        def run_command(self, cmd):
            self.run_command_was_called = True
            if cmd == "/usr/sbin/vecheck":
                self.rc = 0
                self.out = "HPVM guest running on HPVM host"
                self.err = ""
            elif cmd == "/opt/hpvm/bin/hpvminfo":
                self.rc = 0
                self.out = "HPVM guest running on HPVM host"
                self.err = ""
            elif cmd == "/usr/sbin/parstatus":
                self.rc = 0


# Generated at 2022-06-20 20:34:20.777826
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    a = HPUXVirtualCollector()
    b = HPUXVirtualCollector()

    assert a.__class__ == b.__class__, 'Class mismatch'

# Generated at 2022-06-20 20:34:24.278368
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpux_vc = HPUXVirtualCollector()
    assert hpux_vc.platform == 'HP-UX'
    assert hpux_vc._fact_class == HPUXVirtual


# Generated at 2022-06-20 20:34:34.845927
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():

    from ansible.module_utils.facts.virtual import HPUXVirtual
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path

    fake_module = type('FakeModule', (object, ), {'run_command': _run_command})
    #make sure the 'vecheck' command is available in the path
    assert get_bin_path('vecheck') is not None
    hphpux_virt_collector = HPUXVirtual(fake_module)
    hpux_virtual_facts = hphpux_virt_collector.get_virtual_facts()

# Generated at 2022-06-20 20:34:36.906487
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vc = HPUXVirtualCollector()
    assert vc._fact_class.platform == "HP-UX"
    assert vc.platform == "HP-UX"

# Generated at 2022-06-20 20:34:40.557209
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
        test_object = HPUXVirtualCollector()
        assert test_object._platform == 'HP-UX'
        assert test_object._fact_class == HPUXVirtual



# Generated at 2022-06-20 20:34:45.741774
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virt_obj = HPUXVirtual({})
    assert virt_obj.virtualization_type == 'host'
    assert virt_obj.virtualization_role is None
    assert virt_obj.virtualization_tech_host == set()
    assert virt_obj.virtualization_tech_guest == set()

# Generated at 2022-06-20 20:34:48.269067
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual()
    assert v
    assert v.virtualization_type is None
    assert v.virtualization_role is None


# Generated at 2022-06-20 20:34:50.015240
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual(dict())
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-20 20:34:51.942053
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hv = HPUXVirtualCollector()
    assert hv._fact_class.platform == 'HP-UX'

# Generated at 2022-06-20 20:35:51.686279
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv is not None

# Generated at 2022-06-20 20:35:55.027877
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    facts = dict()
    virtual = HPUXVirtual(module)

    virtual.get_virtual_facts(facts)
    assert facts['virtualization_role'] == 'HP vPar'
    assert facts['virtualization_type'] == 'guest'
    assert 'HPVM' in facts['virtualization_tech_guest']

# Generated at 2022-06-20 20:35:59.056488
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual({})
    assert virtual.data['virtualization_type'] == 'guest'
    assert virtual.data['virtualization_role'] == 'HP nPar'
    assert 'HP nPar' in virtual.data['virtualization_tech_guest']

# Generated at 2022-06-20 20:36:01.951508
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpux = HPUXVirtualCollector()
    assert hpux._platform == 'HP-UX'
    assert hpux._fact_class == HPUXVirtual


# Generated at 2022-06-20 20:36:12.579587
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import ansible.utils.virtual_facts
    import ansible.module_utils.facts.virtual.hpux

    class TestModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.stdout = out
            self.stderr = err
        # Mock of function run_command
        def run_command(self, cmd):
            return self.rc, self.stdout, self.stderr

    # Testing HP vPar
    results = {
        'virtualization_type': 'guest',
        'virtualization_role': 'HP vPar',
        'virtualization_tech_host': set([]),
        'virtualization_tech_guest': set(["HP vPar"])}
    module = TestModule(0, "", "")
    ansible.utils

# Generated at 2022-06-20 20:36:17.555231
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Build the module
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    # Set module.params since it is read only
    module.params = {}

    # Run the module code
    fake_module = imp.new_module('ansible.module_utils.facts.virtual.hpux')
    fake_module.HPUXVirtualCollector = HPUXVirtualCollector
    fake_module.HPUXVirtual = HPUXVirtual
    sys.modules['ansible.module_utils.facts.virtual.hpux'] = fake_module

    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    virtual = HPUXVirtual(module)
    facts = virtual.get_virtual_facts()
    # Check results

# Generated at 2022-06-20 20:36:19.434669
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual()
    assert virtual.platform == 'HP-UX'

# Generated at 2022-06-20 20:36:24.374143
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    This is a unit test which checks that get_virtual_facts()
    of class HPUXVirtual correctly returns virtual facts
    """
    # Test class
    hpuxvirtual = HPUXVirtual()
    facts = hpuxvirtual.get_virtual_facts()
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP nPar'


# Generated at 2022-06-20 20:36:33.837915
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import HPUXVirtual
    from ansible.module_utils.facts.virtual.collector import HPUXVirtualCollector
    obj_HPVmini = HPUXVirtual()
    obj_HPVmini._module = HPUXVirtualCollector._mock_module('HP-UX')
    obj_HPVmini._module.run_command = HPUXVirtualCollector._mock_run_command
    obj_HPVmini._module.run_command.side_effect = [("", "", ""),("", "", ""),("", "", "")]
    obj_HPVmini._module.params = {'gather_subset': "virtual"}
    obj_HPVmini._module.params['gather_subset'] = ['!all', 'virtual']
    obj_HPV

# Generated at 2022-06-20 20:36:38.268134
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = type('obj', (object,), {'run_command': lambda _1, _2: (0, '', '')})
    _HPUXVirtualCollector = HPUXVirtualCollector(module)
    virtual_facts = _HPUXVirtualCollector.collect()
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HP vPar'
    assert 'HP vPar' in virtual_facts['virtualization_tech_guest']