

# Generated at 2022-06-20 20:27:26.115562
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """Test a Constructor of HPUXVirtualCollector Class
    """
    virtual_collector_obj = HPUXVirtualCollector()
    assert virtual_collector_obj._platform == 'HP-UX'
    assert virtual_collector_obj._fact_class.platform == 'HP-UX'

# Generated at 2022-06-20 20:27:36.559047
# Unit test for method get_virtual_facts of class HPUXVirtual

# Generated at 2022-06-20 20:27:38.205682
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpu = HPUXVirtualCollector()
    assert hpu.platform == 'HP-UX'

# Generated at 2022-06-20 20:27:39.634182
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    obj = HPUXVirtualCollector()
    assert obj.platform == 'HP-UX'
    assert obj.fact_class == HPUXVirtual
    assert obj.fact_class().platform == 'HP-UX'

# Generated at 2022-06-20 20:27:43.602249
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.virtualization_type == 'guest'
    assert virtual_facts.virtualization_role == 'HP vPar'
    assert virtual_facts.virtualization_tech_guest == set(['HP vPar'])
    assert virtual_facts.virtualization_tech_host == set()



# Generated at 2022-06-20 20:27:46.302192
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    virtual_collector = HPUXVirtualCollector()
    assert virtual_collector._fact_class == HPUXVirtual
    assert virtual_collector._platform == 'HP-UX'

# Generated at 2022-06-20 20:27:48.178021
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    assert hv
    assert hv.platform == 'HP-UX'


# Generated at 2022-06-20 20:27:50.714145
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual()
    assert h.platform == 'HP-UX'
    assert h.get_virtual_facts() == {}



# Generated at 2022-06-20 20:27:55.723541
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    test_virtual = HPUXVirtual(module=module)
    virtual_facts = test_virtual.get_virtual_facts()
    assert virtual_facts
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-20 20:28:03.072960
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # in this test we only care about HP-UX platform
    # and don't care about module.run_command
    def fake_run_command(command, module):
        """
        This is a fake of module.run_command
        """
        if command == "/usr/sbin/vecheck":
            return (0, '', '')
        if command == "/opt/hpvm/bin/hpvminfo":
            return (0, 'Running on HPVM vPar', '')
        if command == "/usr/sbin/parstatus":
            return (0, '', '')
        else:
            return (1, '', '')

    # mock 'ansible/module_utils/basic.py', we actually don't need basic.py
    # but unfortunately HPUXVirtual is not a class defined in one file,
    # so

# Generated at 2022-06-20 20:28:18.567826
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Test case 1 of get_virtual_facts
    # /usr/sbin/vecheck exists and
    # /usr/sbin/vecheck returns vpar
    # Guest is HP vPar
    # virtualization_type is guest
    # virtualization_role is HP vPar
    # virtualization_tech_guest is set(['HP vPar'])
    # virtualization_tech_host is set([])
    # virtualization_system is not set
    # virtualization_role is not set
    class ModuleMock(object):
        @staticmethod
        def run_command(cmd, check_rc=True):
            if cmd == "/usr/sbin/vecheck":
                return (0, 'vpar', None)
            return (0, None, None)

    virtual_obj = HPUXVirtual(ModuleMock())


# Generated at 2022-06-20 20:28:19.406958
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual()
    assert h.platform == 'HP-UX'

# Generated at 2022-06-20 20:28:21.677458
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    m = HPUXVirtualCollector()
    assert isinstance(m.get_virtual_facts(), dict)
    assert isinstance(m.get_virtual_facts()['virtualization_tech_guest'], set)

# Generated at 2022-06-20 20:28:28.272734
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    '''
    Test for the method get_virtual_facts.
    '''
    HPUXVirtual_obj = HPUXVirtual()
    result = HPUXVirtual_obj.get_virtual_facts()
    assert type(result) == dict
    assert sorted(result.keys()) == sorted(['virtualization_role', 'virtualization_tech_host',
                                            'virtualization_tech_guest', 'virtualization_type'])

# Generated at 2022-06-20 20:28:39.150112
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    import sys
    if sys.version_info.major == 2:
        from mock import MagicMock
        import __builtin__ as builtins
    else:
        from unittest.mock import MagicMock
        import builtins
    mock_module = MagicMock()
    mock_module.run_command = MagicMock(return_value=(0, "", ""))
    if sys.version_info.major == 2:
        mock_module.__builtin__ = MagicMock(return_value=builtins)
    else:
        mock_module.builtins = MagicMock(return_value=builtins)

    obj = HPUXVirtual(mock_module)
    result = obj.get_virtual_facts()


# Generated at 2022-06-20 20:28:45.381753
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    global module
    import ansible.module_utils.facts.virtual.hpux
    import ansible.module_utils.facts.virtual.base
    import ansible.module_utils.facts.virtual.common
    global HPUXVirtual
    global Virtual
    global VirtualCollector
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.common import VirtualCollector

    module = ansible.module_utils.facts.virtual.hpux.AnsibleModule(
        argument_spec={})
    vm_obj = HPUXVirtual(module)
    facts = vm_obj.get_virtual_facts()
    assert facts['virtualization_role'] == 'HP nPar'

# Generated at 2022-06-20 20:28:47.138824
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    coll = HPUXVirtualCollector([])
    assert isinstance(coll._fact_class, HPUXVirtual)

# Generated at 2022-06-20 20:28:48.759733
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    """ Unit test for constructor of class HPUXVirtualCollector"""
    hpv = HPUXVirtualCollector
    try:
        assert hpv.platform == 'HP-UX'
        assert hpv._fact_class == HPUXVirtual
    except AssertionError:
        raise

# Generated at 2022-06-20 20:28:51.593906
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpux_virtual_collector = HPUXVirtualCollector()
    assert hpux_virtual_collector._platform == 'HP-UX'

# Generated at 2022-06-20 20:28:54.616630
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    # Test whether the HPUXVirtualCollector class can be instantiated.
    # This test also serves as a canary in a coal mine to warn us if
    # changes to __init__ break the class.
    assert HPUXVirtualCollector(None)

# Generated at 2022-06-20 20:29:21.269287
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    module.run_command.return_value = (0, '', '')
    virtual_obj = HPUXVirtual(module)
    virtual_obj.get_virtual_facts()
    assert module.exit_json.called
    args = module.exit_json.call_args[0]
    facts = args[0]
    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP vPar'
    assert facts['virtualization_tech_guest'] == set(['HP vPar'])
    assert facts['virtualization_tech_host'] == set()


# Generated at 2022-06-20 20:29:22.905296
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = HPUXVirtualCollector(None, None, {})
    assert module._fact_class == HPUXVirtual
    assert module._platform == 'HP-UX'

# Generated at 2022-06-20 20:29:28.625694
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    module = type('testmodule', (), {})()
    module.run_command = lambda command: (0, '', '')

    facts = HPUXVirtual(module)
    expected = {'virtualization_type': 'guest', 'virtualization_role': 'HP vPar',
                'virtualization_tech_guest': {'HP vPar'}, 'virtualization_tech_host': set()}

    assert facts.get_virtual_facts() == expected

# Generated at 2022-06-20 20:29:29.832268
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    h = HPUXVirtual(None)

    assert h.platform == 'HP-UX'


# Generated at 2022-06-20 20:29:33.610508
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    facts = HPUXVirtual({}, {}).get_virtual_facts()
    if facts:
        TestAnsibleModule().assertFalse(
            True,
            msg='get_virtual_facts should return an empty dictionary when '
                'there are no virtualization clues in the system.')



# Generated at 2022-06-20 20:29:39.434954
# Unit test for method get_virtual_facts of class HPUXVirtual

# Generated at 2022-06-20 20:29:42.384366
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    module = ansible_module_mock()
    virtual = HPUXVirtualCollector(module)
    assert virtual.platform == 'HP-UX'
    assert virtual._fact_class == HPUXVirtual


# Generated at 2022-06-20 20:29:47.498792
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual(dict())
    assert v.platform == 'HP-UX'
    assert v.get_virtual_facts() == {
        'virtualization_type': None,
        'virtualization_role': None,
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()}


# Generated at 2022-06-20 20:29:49.123432
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    isinstance(HPUXVirtualCollector(), VirtualCollector)


# Generated at 2022-06-20 20:29:53.979787
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    sample = HPUXVirtual()
    assert sample._platform == 'HP-UX'
    assert sample.get_virtual_facts() == {'virtualization_tech_guest': set(),
                                          'virtualization_tech_host': set(),
                                          'virtualization_type': None,
                                          'virtualization_role': None}


# Generated at 2022-06-20 20:30:23.982953
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual({})
    assert virtual_obj.platform == 'HP-UX'

# Generated at 2022-06-20 20:30:26.332318
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_facts = HPUXVirtual({})
    assert virtual_facts.platform == 'HP-UX'
    assert HPUXVirtual.platform == 'HP-UX'

# Generated at 2022-06-20 20:30:30.105569
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    """ Constructs a HPUXVirtual object and then check few attributes.
    """
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    virtual_object = HPUXVirtual()
    assert virtual_object.platform == 'HP-UX'

# Generated at 2022-06-20 20:30:31.862948
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual = HPUXVirtual({})
    assert virtual._platform == 'HP-UX'

# Generated at 2022-06-20 20:30:40.223206
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Initialize a module for testing
    module = AnsibleModule(argument_spec=dict())
    module.params['gather_subset'] = ['!all', 'virtual']
    module.params['filter'] = 'virtual'

    # Mock the module commands
    mock_run_command = MagicMock()
    def mock_run_command_vecheck(*args, **kwargs):
        return 1, '', ''
    def mock_run_command_vecheck_success(*args, **kwargs):
        return 0, 'Virtual Environment Check Program (vecheck), Version A.01.00\n\nHP-UX is not running in a virtualized environment.', ''
    def mock_run_command_hpvminfo(*args, **kwargs):
        return 1, '', ''

# Generated at 2022-06-20 20:30:47.436204
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import ansible.module_utils.facts.virtual.hpu
    obj = ansible.module_utils.facts.virtual.hpu.HPUXVirtual()

    # This is expected to fail since there are no files
    virtual_facts = obj.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == None
    assert virtual_facts['virtualization_role'] == None
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:30:55.935635
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    module = type('AnsibleModule', (), dict(run_command=lambda *x, **y: (0, '', ''), params=dict()))()

# Generated at 2022-06-20 20:30:57.851010
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    hpux_facts = HPUXVirtualCollector()
    assert hpux_facts.platform == 'HP-UX'
    assert hpux_facts._fact_class == HPUXVirtual


# Generated at 2022-06-20 20:30:58.802620
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    assert HPUXVirtual(dict()).platform == 'HP-UX'


# Generated at 2022-06-20 20:31:02.485686
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    collection = HPUXVirtualCollector()
    collection.module.run_command = run_command_mock

    virtual_facts_dict = collection.get_virtual_facts()

    assert virtual_facts_dict['virtualization_role'] == 'guest'
    assert virtual_facts_dict['virtualization_type'] == 'HP nPar'
    assert virtual_facts_dict['virtualization_tech_guest'] == set(['HP nPar'])
    assert virtual_facts_dict['virtualization_tech_host'] == set()



# Generated at 2022-06-20 20:32:11.737947
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Unit test that verifies the value returned by get_virtual_facts when calling on a
    HP-UX virtualized guest, HP-UX virtualized host, and non-virtualized host.
    """
    # Fake class for module
    class Module(object):
        def __init__(self, **kwargs):
            pass
        def run_command(self, cmd=None, **kwargs):
            if cmd == "/usr/sbin/vecheck":
                return 0, "X(vPar)", None
            elif cmd == "/opt/hpvm/bin/hpvminfo":
                return 0, "X(vPar)", None
            elif cmd == "/usr/sbin/parstatus":
                return 0, "X(nPar)", None
            else:
                return 1, None, None

    # Fake class for module_

# Generated at 2022-06-20 20:32:12.512708
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    HPUXVirtualCollector()

# Generated at 2022-06-20 20:32:24.741153
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    Test HPUXVirtual.get_virtual_facts()
    """
    from ansible.module_utils.facts.virtual import HPUXVirtual
    from ansible.module_utils.facts.virtual.hpux import HPUXVirtualCollector
    from ansible.module_utils import basic
    import os
    import pytest
    import test.support
    import test.utils.module_utils

    class FakeModuleUtils(object):
        def __init__(self):
            self.run_command_called = False

        def run_command(self, cmd):
            assert cmd == '/usr/sbin/vecheck'
            self.run_command_called = True

# Generated at 2022-06-20 20:32:34.001986
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import platform
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()

    # Mocking platform.system()
    saved_system = platform.system
    platform.system = lambda: 'HP-UX'
    hpux_virtual = HPUXVirtual()

    # Virtualization_type = guest, virtualization_role = HP vPar
    # Mocking content of /usr/sbin/vecheck file
    fp = open(tmpdir+'/usr/sbin/vecheck', 'w')
    fp.write("vecheck: HP vPar detected\n")
    fp.close()
    saved_isdir = os.path.isdir
    os.path.isdir = lambda x: True if x == tmpdir+'/usr/sbin/' else saved_isdir(x)
    saved_

# Generated at 2022-06-20 20:32:39.355409
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Create an instance of class HPUXVirtual
    hv = HPUXVirtual()

    out = dict()
    out['stdout_lines'] = '''
    OUTPUT for vecheck
    OUTPUT for hpvminfo
    OUTPUT for parstatus
    '''
    # Run method get_virtual_facts with given parameters
    ret = hv.get_virtual_facts()
    assert ret['virtualization_tech_guest'] == set(['HP vPar', 'HPVM vPar', 'HPVM guest', 'HP nPar'])
    assert ret['virtualization_tech_host'] == set()
    assert ret['virtualization_type'] == 'guest'
    assert ret['virtualization_role'] == 'HP nPar'

# Generated at 2022-06-20 20:32:42.704657
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    vc = HPUXVirtualCollector(None,
                              None,
                              "",
                              "",
                              "",
                              "",
                              "",
                              "",
                              "")
    assert vc is not None

# Generated at 2022-06-20 20:32:46.776521
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    v = HPUXVirtual({}, {}, {})
    assert v.platform == 'HP-UX'
    assert 'virtualization_type' in v.facts
    assert 'virtualization_role' in v.facts
    assert len(v.facts['virtualization_tech_guest']) == 0
    assert len(v.facts['virtualization_tech_host']) == 0
    assert v.__doc__ is not None

# Generated at 2022-06-20 20:32:56.258996
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.hpar import VirtualCollector
    from ansible.module_utils.facts.virtual.base import Virtual

    class FakeModule(object):
        def __init__(self):
            self.run_command = lambda x: (0, "Running as HPVM guest.", "")

    class TestHPUXVirtual(HPUXVirtual):
        module = FakeModule()

    virtual = TestHPUXVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert sorted(virtual_facts['virtualization_tech_guest']) == ['HPVM']
    assert virtual_facts['virtualization_type'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'HPVM IVM'

# Generated at 2022-06-20 20:33:05.023916
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    # Setup mocks
    class Module(object):
        def __init__(self):
            self.params = {'gather_subset': '!all'}
            self.run_command_calls = []
            self.run_command_result = []

        def run_command(self, cmd, check_rc=True):
            self.run_command_calls.append((cmd, check_rc))
            return self.run_command_result.pop(0)

    class ModuleUtil(object):
        def __init__(self):
            self.get_platform_calls = []
            self.get_platform_result = []

        def get_platform(self):
            self.get_platform_calls.append(())
            return self.get_platform_result.pop(0)

    module = Module()

# Generated at 2022-06-20 20:33:07.812904
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """Unit test for method get_virtual_facts of class HPUXVirtual
    """
    HPUXVirtual.get_virtual_facts()

# Generated at 2022-06-20 20:34:34.210779
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-20 20:34:40.642134
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    def run_command(self, cmd, check_rc=True, close_fds=True, executable=None,
                    data=None, binary_data=False):
        if cmd == "/usr/sbin/vecheck":
            rc = 0
            out = "Running HP-UX vPar guest"
            err = ""
            return rc, out, err
        elif cmd == "/opt/hpvm/bin/hpvminfo":
            rc = 0
            out = "Running HPVM host"
            err = ""
            return rc, out, err
        elif cmd == "/usr/sbin/parstatus":
            rc = 0
            out = "Running HP-UX nPar guest"
            err = ""
            return rc, out

# Generated at 2022-06-20 20:34:42.761084
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hpux_virtual = HPUXVirtual()
    assert hpux_virtual.platform == 'HP-UX'


# Generated at 2022-06-20 20:34:47.212894
# Unit test for constructor of class HPUXVirtualCollector
def test_HPUXVirtualCollector():
    from ansible.module_utils.facts import Collector
    x = Collector.fetch_fact_names('setup')
    assert 'virtual' in x
    y = HPUXVirtualCollector()
    assert y._platform == 'HP-UX'

# Generated at 2022-06-20 20:34:49.290015
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    hv = HPUXVirtual()
    hv.get_virtual_facts()
    assert hv.platform == 'HP-UX'

# Generated at 2022-06-20 20:34:56.667021
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    mock_module = MockModule()
    mock_module.run_command = Mock(return_value=(0, "", ""))

    hpux_virtual = HPUXVirtual(mock_module)
    # test the case when the host is a vPar and the host is running under HPVM
    hpux_virtual.module.run_command = Mock(side_effect=[(0, "", ""), (0, "Running, HPVM vPar", "")])
    virtual_facts = hpux_virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'guest'
    assert len(virtual_facts['virtualization_tech_guest']) == 2
    assert virtual_facts['virtualization_tech_guest'] == set(['HP vPar', 'HPVM vPar'])



# Generated at 2022-06-20 20:35:04.466849
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    """
    This is a unit test for method get_virtual_facts of class HPUXVirtual
    """
    h = HPUXVirtual()
    h._module = FakeAnsibleModule()

    # Get facts that can't be tested automatically
    h._module.run_command = title_run_command

    facts = h.get_virtual_facts()

    assert facts['virtualization_type'] == 'guest'
    assert facts['virtualization_role'] == 'HP nPar'
    assert facts['virtualization_tech_guest'] == {'HP nPar'}
    assert facts['virtualization_tech_host'] == set()


# Generated at 2022-06-20 20:35:10.643029
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    virtual_obj = HPUXVirtual({})
    assert virtual_obj.platform == 'HP-UX'
    assert virtual_obj._platform == 'HP-UX'
    assert virtual_obj.get_virtual_facts() == {'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}

# Generated at 2022-06-20 20:35:12.482161
# Unit test for constructor of class HPUXVirtual
def test_HPUXVirtual():
    facts = HPUXVirtual({})
    assert facts.platform == 'HP-UX'
    assert facts.get_virtual_facts() == {}


# Generated at 2022-06-20 20:35:18.850715
# Unit test for method get_virtual_facts of class HPUXVirtual
def test_HPUXVirtual_get_virtual_facts():
    import platform
    import sys

    class ModuleMock():
        def __init__(self):
            self.run_command = self._run_command
            self.platform = platform
            self.platform.system = self._system
            self.platform.release = self._release

        def _system(self):
            return 'HP-UX'

        def _release(self):
            return 'B.11.31'

        def _run_command(self, cmd):
            if cmd == '/usr/sbin/parstatus':
                return 0, 'parstatus', ''
            elif cmd == '/opt/hpvm/bin/hpvminfo':
                return 0, 'Running on HPVM guest', ''
            elif cmd == '/usr/sbin/vecheck':
                return 0, 'vecheck', ''
