

# Generated at 2022-06-25 14:36:44.791542
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    # Default
    test_case_0()



# Generated at 2022-06-25 14:36:48.356789
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load(file_path_0)


file_path_0 = "../tokens"


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-25 14:36:49.354694
# Unit test for method load of class Grammar
def test_Grammar_load():
    assert False


# Generated at 2022-06-25 14:36:54.501230
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.number2symbol = {256: 'file_input', 257: 'stmt', 258: 'simple_stmt', 259: 'small_stmt', 260: 'expr_stmt'}
    g.symbol2number = {'file_input': 256, 'stmt': 257, 'simple_stmt': 258, 'small_stmt': 259, 'expr_stmt': 260}
    g.start = 256
    fd, name = tempfile.mkstemp()
    os.close(fd)
    g.dump(name)


# Generated at 2022-06-25 14:37:04.382447
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()

    # test_case_0
    grammar_0 = Grammar()

# Generated at 2022-06-25 14:37:05.744410
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump("A_filename")


# Generated at 2022-06-25 14:37:08.939267
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    print("# grammar_0.dump(\"<tempfile>\")")
    grammar_0.dump("<tempfile>")


# Generated at 2022-06-25 14:37:10.732483
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()

    # Call method dump of class Grammar on the instance grammar_0
    grammar_0.dump("grammar_0")


# Generated at 2022-06-25 14:37:12.627886
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    test_case_0()
    test_case_0()



# Generated at 2022-06-25 14:37:17.886923
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('Razna/razna_data_gen/razna_3_2/proposal_grammar.pkl')
    print(grammar_0.__dict__)

if __name__ == "__main__":
    test_case_0()
    test_Grammar_load()

# Generated at 2022-06-25 14:37:24.059343
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load(os.path.join(os.path.dirname(__file__), "Grammar.txt"))


# Generated at 2022-06-25 14:37:25.510967
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.loads(grammar_pickle_0)


# Generated at 2022-06-25 14:37:26.276105
# Unit test for method load of class Grammar
def test_Grammar_load():
    test_case_0()


# Generated at 2022-06-25 14:37:28.512176
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load('Grammars/Grammar.pickle')

if __name__ == "__main__":
    test_case_0()
    test_Grammar_load()

# Generated at 2022-06-25 14:37:37.180761
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import tempfile
    import os
    import io
    grammar_0 = Grammar()
    with tempfile.TemporaryDirectory() as temp_dir:
        grammar_0.dump(os.path.join(temp_dir, "test.pkl"))
        with open(os.path.join(temp_dir, "test.pkl"), "rb") as f:
            grammar_1 = pickle.load(f)
    assert grammar_1
    grammar_1.report()
    grammar_1.loads(b"")


# Generated at 2022-06-25 14:37:38.308114
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('tempfile.pkl')


# Generated at 2022-06-25 14:37:43.851598
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()

# Generated at 2022-06-25 14:37:46.475120
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    file = tempfile.mkdtemp() + '/dump_grammar_tables.pkl'
    grammar = Grammar()
    grammar.dump(file)



# Generated at 2022-06-25 14:37:48.019176
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("grammar.pickle")


# Generated at 2022-06-25 14:37:49.961604
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("./Grammar.pickle")



# Generated at 2022-06-25 14:37:53.947856
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    Grammar().dump(tempfile.mkstemp()[1])

# Generated at 2022-06-25 14:37:55.890663
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load([])


# Generated at 2022-06-25 14:37:59.394082
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    try:
        grammar_0.dump(Path("/home/hchen/pycparser/tests/data/PickleTestFile.pickle"))
    except Exception as e:
        print(e)


# Generated at 2022-06-25 14:38:07.340465
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load("/Users/usr/PycharmProjects/python/cpython/Lib/test/grammar_dump.pkl")
    assert grammar_1.start == 256
    assert grammar_1.symbol2number["dictsetmaker"][1] == 2
    assert grammar_1.symbol2number["dictsetmaker"][2] == 4
    assert grammar_1.symbol2number["dictsetmaker"][3] == 4
    assert grammar_1.symbol2number["dictsetmaker"][4] == 4
    assert grammar_1.symbol2number["dictsetmaker"][5] == 4
    assert grammar_1.symbol2number["dictsetmaker"][6] == 4
    assert grammar_1.symbol2number["dictsetmaker"][7]

# Generated at 2022-06-25 14:38:12.376634
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_1 = Grammar()
    grammar_1.load("grammar_1.pkl")
    grammar_0.loads(pickle.dumps(grammar_1, protocol=pickle.HIGHEST_PROTOCOL))

if __name__ == "__main__":
    test_Grammar_load()
    print("Done testing")

# Generated at 2022-06-25 14:38:15.632321
# Unit test for method load of class Grammar
def test_Grammar_load():
    pickle_path = os.path.join(
        "test", "data", "Grammar_load_0.pkl"
    )
    grammar_0 = Grammar()
    grammar_0.load(pickle_path)


# Generated at 2022-06-25 14:38:19.183058
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('graminit.py')


# Generated at 2022-06-25 14:38:22.702268
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('/usr/local/lib/python3.6/lib2to3/Grammar.pickle')
    grammar_0.loads(b'\x80\x03clib2to3.pgen2\ngrammar\n)\x81q\x00.')


# Generated at 2022-06-25 14:38:25.211054
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('/dev/null')


# Generated at 2022-06-25 14:38:28.250191
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = "./pgen2_dump.py"
    grammar_0 = Grammar()
    grammar_0.dump(filename)
    assert os.path.exists(filename), "File not available"
    os.unlink(filename)


# Generated at 2022-06-25 14:38:33.172068
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    file_path = "./test_grammar_dump.pickle"
    grammar_1 = Grammar()
    grammar_1.dump(file_path)


# Generated at 2022-06-25 14:38:36.251315
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    if not grammar_0:
        grammar_0.load("")



# Generated at 2022-06-25 14:38:40.300689
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # test setup
    from .fake_pgen import FakePgen

    fp = FakePgen()

    grammar_2 = Grammar()
    grammar_2.dump("test_grammar.pickle")
    grammar_2.load("test_grammar.pickle")
    grammar_2.report()


# Generated at 2022-06-25 14:38:42.435162
# Unit test for method load of class Grammar
def test_Grammar_load():
    fn = "test_data.grammar_0"
    grammar_0 = Grammar()
    grammar_0.load(fn)


# Generated at 2022-06-25 14:38:48.541202
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_0 = Grammar()
    #Test type of dump.
    assert isinstance(grammar_0.dump(""), type(None))
    assert not hasattr(grammar_1, "grammar_1")
    #Test dict of grammar_1.
    grammar_0.dump("")
    assert isinstance(grammar_1.symbol2number, type({}))
    assert isinstance(grammar_1.number2symbol, type({}))
    assert isinstance(grammar_1.states, type([]))
    assert isinstance(grammar_1.dfas, type({}))
    assert isinstance(grammar_1.labels, type([]))
    assert isinstance(grammar_1.keywords, type({}))

# Generated at 2022-06-25 14:38:51.835080
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump("C:\\Users\\pankaj\\PycharmProjects\\python-master\\Python-3.7.2\\Lib\\_parser\\parser_dump_file.bin")


# Generated at 2022-06-25 14:38:54.585688
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    try:
        grammar_1.dump("/home/hgeunlee/grammar_1.pickle")
    except OSError as e:
        print("Error: {0}".format(e))


# Generated at 2022-06-25 14:38:55.895302
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    filename = '<todo>'
    grammar.dump(filename)

# Generated at 2022-06-25 14:38:57.188052
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump(os.devnull)


# Generated at 2022-06-25 14:39:00.136739
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    #
    grammar = Grammar()
    filename = 'pgen_test.txt'
    #
    grammar_0 = test_case_0()
    grammar_0.dump(filename)


# Generated at 2022-06-25 14:39:09.205331
# Unit test for method load of class Grammar
def test_Grammar_load():
    # class Grammar
    grammar_0 = Grammar()

    # test with grammar_0.loads(b'');
    # mypyc generates objects that don't have a __dict__, but they
    # do have __getstate__ methods that will return an equivalent
    # dictionary
    if hasattr(grammar_0, "__dict__"):
        d = grammar_0.__dict__
    else:
        d = grammar_0.__getstate__()  # type: ignore

    grammarg = pickle.dumps(d, pickle.HIGHEST_PROTOCOL)
    grammar_0.loads(grammarg)

    # test with grammar_0.load(os.path.join(os.path.expanduser('~'), 'tmp'
    # , 'tmp918xbf.pkl'));
   

# Generated at 2022-06-25 14:39:10.691818
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Initialize grammar_0
    grammar_0 = Grammar()
    grammar_0.dump("")



# Generated at 2022-06-25 14:39:14.498939
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Create an instance of the 'Grammar' class
    grammar = Grammar()
    # Call the method
    filename = os.path.join(os.path.dirname(__file__), "Grammar.out")
    grammar.dump(filename)
    grammar.loads(grammar.dumps())


# Generated at 2022-06-25 14:39:17.576093
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    load_grammar()
    output_file = "./pythonparse_output.pkl"
    grammar_0.dump(output_file)
    assert os.path.isfile(output_file)


# Generated at 2022-06-25 14:39:23.469684
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import conv

    gf = conv.gen_grammar_for_pgen()
    grammar = Grammar()
    grammar.load(gf)

    with tempfile.TemporaryDirectory() as tmpdir:
        filename = os.path.join(tmpdir, "tmp.pickle")
        grammar.dump(filename)
        grammar.load(filename)
        grammar.dump(filename)
        grammar.load(filename)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 14:39:24.393114
# Unit test for method load of class Grammar
def test_Grammar_load():
    test_case_0()
    test = Grammar()
    test.load("./Grammar.pickle")

# Generated at 2022-06-25 14:39:25.539932
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('grammar')


# Generated at 2022-06-25 14:39:35.956906
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    gram = Grammar()

    gram.symbol2number = {'str': 2062, 'encoding': 2087}
    gram.number2symbol = {2062: 'str', 2087: 'encoding'}
    gram.states = [
        [(258, 1), (2062, 1), (2087, 1), (2063, 1), (0, 1)],
        [(0, 2)],
        []
    ]
    gram.dfas = {
        2062: ([[(258, 1), (2062, 1), (2063, 1), (0, 1)], [(0, 2)], []],
                {258: 1, 2062: 1, 2063: 1})
    }

# Generated at 2022-06-25 14:39:38.509615
# Unit test for method load of class Grammar
def test_Grammar_load():
    fn = os.path.join(os.path.dirname(__file__), "Grammar.pickle")
    grammar_20 = Grammar()
    grammar_20.load(fn)

# Generated at 2022-06-25 14:39:40.998453
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    assert grammar_0.dump('./data/grammar_tables.pickle') is None


# Generated at 2022-06-25 14:39:47.747617
# Unit test for method load of class Grammar
def test_Grammar_load():
    if __name__ == '__main__':
        test_case_0()
        test_Grammar_load()
        print('Module test success')

# Generated by MyPy.

# Generated at 2022-06-25 14:39:52.642707
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    fname_0 = tempfile.NamedTemporaryFile()
    grammar_0.dump(fname_0)
    grammar_0.load(fname_0)


if __name__ == "__main__":
    import pytest

    pytest.main(args=["."])

# Generated at 2022-06-25 14:39:55.534030
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # temp_file_name = tempfile.mktemp('.xxx')
    temp_file_name = 'test_grammar.pickle'
    test_case_0()
    grammar_0.dump(temp_file_name)


# Generated at 2022-06-25 14:39:56.838781
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump("file_name")


# Generated at 2022-06-25 14:39:59.652676
# Unit test for method load of class Grammar
def test_Grammar_load():
    global grammar_0
    #case 0
    grammar_0.load("python_grammar.pkl")




# Generated at 2022-06-25 14:40:01.635243
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load('Grammar.pkl')


# Generated at 2022-06-25 14:40:03.163122
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.load()

test_Grammar_dump()

# Generated at 2022-06-25 14:40:11.550568
# Unit test for method dump of class Grammar
def test_Grammar_dump():
  grammar_0 = Grammar()
  grammar_0.tokens = {2: 0}
  grammar_0.symbol2number = {'ab': 0}
  grammar_0.start = 256
  grammar_0.labels = [0, 0]
  grammar_0.symbol2label = {'df': 0}
  grammar_0.dfas = {0: 0}
  grammar_0.number2symbol = {0: 'abc'}
  grammar_0.states = [0]
  grammar_0.keywords = {'df': 0}
  filename_0 = 'python/Grammar/dump.pkl'
  grammar_0.dump(filename_0)


# Generated at 2022-06-25 14:40:12.902281
# Unit test for method load of class Grammar
def test_Grammar_load():
    test_case_0()


# Generated at 2022-06-25 14:40:15.142794
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load('_pickle_data/Grammar_0.data')


# Generated at 2022-06-25 14:40:24.480493
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .conv import make_pgen
    from .pgen2 import tokenize
    from .pygram import python_grammar, python_grammar_no_print_statement

    grammar_0 = make_pgen()
    assert grammar_0 is not None
    grammar_0.dump("Grammar_load.pkl")
    grammar_1 = Grammar()
    grammar_1.load("Grammar_load.pkl")
    assert grammar_0 is not grammar_1
    assert grammar_0.async_keywords is not grammar_1.async_keywords
    assert grammar_0.async_keywords == grammar_1.async_keywords



# Generated at 2022-06-25 14:40:27.894667
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('test/test_grammar.grammar_0.py')



# Generated at 2022-06-25 14:40:31.406681
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    with tempfile.NamedTemporaryFile(mode="w", delete=False) as pf:
        pf.write("grammar_0.pkl")
    grammar_0 = test_case_0();
    grammar_0.dump(pf.name)


# Generated at 2022-06-25 14:40:33.538521
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_1 = grammar_0.load('grammar.py')



# Generated at 2022-06-25 14:40:35.377573
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('/tmp/grammar.out')


# Generated at 2022-06-25 14:40:37.488517
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    print("Dumping grammar to grammar.pickle")
    grammar.dump('grammar.pickle')


# Generated at 2022-06-25 14:40:44.196845
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()

    with tempfile.TemporaryDirectory() as directory:
        expected = {
            'async_keywords': False,
            'density': None,
            'dfas': {},
            'errors_seen': set(),
            'keywords': {},
            'labels': [(0, 'EMPTY')],
            'number2symbol': {},
            'start': None,
            'states': [],
            'symbol2label': {},
            'symbol2number': {},
            'symbol_table': [],
            'tokens': {},
            'version': 1,
        }

        grammar_1.dump(directory + '/grammar.pickle')

        with open(directory + '/grammar.pickle', 'rb') as f:
            actual = pickle

# Generated at 2022-06-25 14:40:49.797578
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    import six
    from os.path import dirname, join

    candidate = Grammar()
    filename = join(dirname(__file__), 'Grammar.pickle')
    with open(filename, 'rb') as f:
        if six.PY2:
            candidate.load(pickle.load(f))
        else:
            candidate.load(pickle.load(f, encoding='latin1'))


if __name__ == "__main__":
    test_case_0()
    test_Grammar_load()

# Generated at 2022-06-25 14:40:50.900104
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    Grammar_0 = Grammar()
    Grammar_0.dump('test_0.txt')


# Generated at 2022-06-25 14:40:56.141292
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    path_1: Path = "DUMMY.pkl"

# Generated at 2022-06-25 14:41:00.162485
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("grammar.pickle")


# Generated at 2022-06-25 14:41:00.904891
# Unit test for method load of class Grammar
def test_Grammar_load():
    assert True


# Generated at 2022-06-25 14:41:03.196192
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("tests/sample_grammar.pkl")


# Generated at 2022-06-25 14:41:08.269578
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    filename = tempfile.NamedTemporaryFile(dir=os.path.dirname("/home/lucas/PycharmProjects/python-3.7.2/"), delete=False)

    grammar_0.dump(filename.name)


# Generated at 2022-06-25 14:41:10.287050
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    p = Grammar()
    p.dump("test_dump.txt")


# Generated at 2022-06-25 14:41:13.460717
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    tempdir = tempfile.mkdtemp()
    grammar_0.dump(tempdir + os.path.sep + "grammar_0")


# Generated at 2022-06-25 14:41:15.492975
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    filename = tempfile.NamedTemporaryFile().name
    grammar_0.dump(filename)


# Generated at 2022-06-25 14:41:18.360750
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = "temp.pickle"
    grammar = Grammar(None)
    grammar.dump(filename)


# Generated at 2022-06-25 14:41:20.408282
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("test_Grammar_dump")


# Generated at 2022-06-25 14:41:24.624553
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Construct an instance of the Grammar class with empty initializer
    grammar_0 = Grammar()
    # Initialize a variable with type Path
    filename_0 = './pgen_py3_test_grammar.py'
    # Method dump of Grammar is called with the arguments grammar_0 and filename_0
    grammar_0.dump(filename_0)


# Generated at 2022-06-25 14:41:29.987711
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("test_grammar_0.pkl")


# Generated at 2022-06-25 14:41:31.513911
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump(os.devnull)


# Generated at 2022-06-25 14:41:35.977497
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Test for simple case
    grammar_0 = Grammar()
    grammar_0.dump('test.out')
    grammar_1 = Grammar()
    grammar_1.loads(open('test.out', 'rb').read())
    os.remove('test.out')
    assert grammar_0.__dict__ == grammar_1.__dict__


# Generated at 2022-06-25 14:41:37.988041
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    with tempfile.NamedTemporaryFile(delete=False) as f:
        grammar.dump(f.name)


# Generated at 2022-06-25 14:41:40.160909
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("test_grammar_dump.pkl")


# Generated at 2022-06-25 14:41:43.477389
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    # grammar = Grammar()
    grammar.load("pygram_1.pickle")



# Generated at 2022-06-25 14:41:52.640496
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    tmpdir = tempfile.TemporaryDirectory()

# Generated at 2022-06-25 14:41:54.419225
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    for i in range(1000):
        grammar_0.load('test_case_0')


# Generated at 2022-06-25 14:41:57.542827
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    with open('test_parse_grammar.pkl', 'rb') as f:
        grammar_1.loads(f.read())  # This is where a read error or something occurs.
        grammar_1.report()  # This is where a read error or something occurs.


# Generated at 2022-06-25 14:42:07.544921
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('/tmp/grammar_0.pickle')
    grammar_1 = Grammar()
    grammar_1.load('/tmp/grammar_0.pickle')
    assert grammar_0.symbol2number == grammar_1.symbol2number
    assert grammar_0.number2symbol == grammar_1.number2symbol
    assert grammar_0.states == grammar_1.states
    assert grammar_0.dfas == grammar_1.dfas
    assert grammar_0.labels == grammar_1.labels
    assert grammar_0.keywords == grammar_1.keywords
    assert grammar_0.tokens == grammar_1.tokens
    assert grammar_0.symbol2label == grammar_1.symbol2label
    assert grammar

# Generated at 2022-06-25 14:42:11.258065
# Unit test for method load of class Grammar
def test_Grammar_load():

    grammar_1 = Grammar()

    grammar_1.load("""this is just a file test""")


# Generated at 2022-06-25 14:42:14.586761
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("/usr/local/lib/python3.7/lib2to3/Grammar.pkl")


# Generated at 2022-06-25 14:42:16.513560
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    dump_0 = grammar_0.dump
    dump_0("pkl")


# Generated at 2022-06-25 14:42:26.985023
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Creates an instance of class Grammar
    grammar_0 = Grammar()

# Generated at 2022-06-25 14:42:33.094866
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {"x": 256, "y": 257}
    g_copy = g.copy()
    with tempfile.TemporaryDirectory() as dirname:
        filename = os.path.join(dirname, "test_pickle.pkl")
        g.dump(filename)
        g_copy.load(filename)
        g_copy.report()
        assert g_copy.symbol2number == {"x": 256, "y": 257}


if __name__ == "__main__":
    import pytest

    pytest.main([__file__, "-v"])

# Generated at 2022-06-25 14:42:41.180701
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load(os.path.join("data", "Grammar-py{}.pkl".format(3)))
    grammar_0.load(os.path.join("data", "Grammar-py{}.pkl".format(3)))



if __name__ == "__main__":
    import sys
    import doctest

    verbose = "-v" in sys.argv
    if "-g" in sys.argv:
        print("Recreating grammar pickles")
        from .pgen2 import driver

        driver.Driver().run(sys.argv[1:])
    else:
        print("Testing Grammar class")
        doctest.testmod(verbose=verbose)

# Generated at 2022-06-25 14:42:46.651985
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename_0 = ".test.parsing.grammar.1708"
    try:
        # Test case:
        fn_0 = os.path.basename(filename_0)
        _setUp(fn_0)
        grammar_0 = Grammar()
        grammar_0.dump(filename_0)
        # Evaluation:
        pass
    finally:
        _tearDown(filename_0)


# Generated at 2022-06-25 14:42:48.484183
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_2 = Grammar()
    grammar_2.load("GrammarTables.txt")



# Generated at 2022-06-25 14:42:56.465675
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = test_case_0()

# Generated at 2022-06-25 14:42:58.331875
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("/dev/null")



# Generated at 2022-06-25 14:43:02.239409
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump(grammar.load)

# Generated at 2022-06-25 14:43:06.471549
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    # -- Missing module
    filename_1 = "./grammar_1.pkl"
    # Must raise FileNotFoundError
    try:
        grammar_1.load(filename_1)
    except FileNotFoundError:
        pass
    else:
        assert False, "Expected exception"


# Generated at 2022-06-25 14:43:09.582096
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('./data/python_pickle_dump.pkl')


# Generated at 2022-06-25 14:43:17.847196
# Unit test for method load of class Grammar
def test_Grammar_load():
    def setUp(self):
        self.grammar = Grammar()
        self.filename = tempfile.mktemp()
        self.grammar.dump(self.filename)

    def tearDown(self):
        if os.path.isfile(self.filename):
            os.unlink(self.filename)

    def test_load(self):
        grammar = Grammar()
        grammar.load(self.filename)
        self.assertEqual(grammar.symbol2number, self.grammar.symbol2number)
        self.assertEqual(grammar.number2symbol, self.grammar.number2symbol)
        self.assertEqual(grammar.dfas, self.grammar.dfas)
        self.assertEqual(grammar.labels, self.grammar.labels)
       

# Generated at 2022-06-25 14:43:28.469565
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.start = 257
    grammar.states = []
    grammar.dfas = {257: ([[(0, 0), (0, 1)]], {0: 1, 1: 1})}
    grammar.symbol2number = {'test': 257}
    grammar.number2symbol = {257: 'test'}
    grammar.labels = [(0, 'EMPTY'), (0, 'test')]
    grammar.tokens = {0: 1}
    grammar.keywords = {'test': 1}
    grammar.symbol2label = {'test': 1}
    grammar.dump("data/test_1")
    grammar2 = Grammar()
    grammar2.load("data/test_1")
    assert grammar.states == grammar2.states
    assert grammar.number2symbol

# Generated at 2022-06-25 14:43:30.499676
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('/tmp/grammar_0.pickle')


# Generated at 2022-06-25 14:43:39.414019
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()

# Generated at 2022-06-25 14:43:40.957877
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("../../nodes/Grammar.pickle")


# Generated at 2022-06-25 14:43:43.131244
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("/tmp/testcase")


# Generated at 2022-06-25 14:43:45.128718
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    try:
        assert grammar_0.dump("/var/lib/version") == None
    except:
        pass


# Generated at 2022-06-25 14:43:49.362296
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    dump_1 = grammar_1.dump()
    assert dump_1 is None
    # TODO: Check output


# Generated at 2022-06-25 14:43:49.999853
# Unit test for method load of class Grammar
def test_Grammar_load():
    assert Grammar().load() == None


# Generated at 2022-06-25 14:43:52.644700
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    filename = "dummy_file"
    grammar_0.load(filename)


# Generated at 2022-06-25 14:43:56.731635
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    grammar_0 = Grammar()
    grammar_0.load('/tmp/grammar-dump-127.0.0.1-2328.pickle')


# Generated at 2022-06-25 14:43:58.910667
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test that an Integer is in a Range
    grammar_0 = Grammar()
    grammar_0.load("Grammar")


# Generated at 2022-06-25 14:44:00.655730
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("Grammar.test")


# Generated at 2022-06-25 14:44:01.755518
# Unit test for method load of class Grammar
def test_Grammar_load():
    test_case_0()


# Generated at 2022-06-25 14:44:07.629395
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    try:
        # Create a temporary file
        tmp_file = tempfile.NamedTemporaryFile()

        # Define arg for test
        grammar_dump_arg_0 = grammar_0
        grammar_dump_arg_1 = tmp_file.name

        # Call the test function
        grammar_dump_ret = grammar_dump_arg_0.dump(grammar_dump_arg_1)

        # Check the return value
        assert type(grammar_dump_ret) == type(None)
    finally:
        try:
            # Cleanup
            tmp_file.close()
        except:
            pass



# Generated at 2022-06-25 14:44:08.477703
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # self.pycparse is not defined
    pass


# Generated at 2022-06-25 14:44:10.406879
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("../ast_dump/dump_1")
    grammar.dump("../ast_dump/dump_2")


# Generated at 2022-06-25 14:44:14.925152
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    assert grammar_0.dump('./a/b/c.pkl') is None


# Generated at 2022-06-25 14:44:15.977118
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("")


# Generated at 2022-06-25 14:44:23.137036
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_2 = Grammar()

    grammar_1.copy(grammar_2)
    grammar_1.report()
    grammar_1.dump('./test/test_Grammar.pkl')
    grammar_2.load('./test/test_Grammar.pkl')
    grammar_2.loads(b'\x80\x03}q\x00(U\x01)\x91q\x01.')



# Generated at 2022-06-25 14:44:25.534362
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("..\\grammar\\Grammar_testcase_0")


# Generated at 2022-06-25 14:44:32.985312
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.labels = [(0, "EMPTY")]
    grammar.keywords = {}
    grammar.tokens = {}
    grammar.symbol2label = {}
    grammar.start = 256
    tmp1_fd, tmp1 = tempfile.mkstemp()
    try:
        grammar.dump(tmp1)
        grammar.load(tmp1)
        assert grammar.labels == [(0, "EMPTY")]
        assert grammar.keywords == {}
        assert grammar.tokens == {}
        assert grammar.symbol2label == {}
        assert grammar.start == 256
    finally:
        os.unlink(tmp1)


# Generated at 2022-06-25 14:44:35.168263
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("Grammar_dump.pkl")


# Generated at 2022-06-25 14:44:36.457064
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("public.pickle")


if __name__ == "__main__":
    # Run the unit tests
    test_case_0()
    test_Grammar_load()

# Generated at 2022-06-25 14:44:37.490275
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("grammar_dump_test.txt")



# Generated at 2022-06-25 14:44:38.280856
# Unit test for method load of class Grammar
def test_Grammar_load():
    Grammar().load(__file__)  # empty


# Generated at 2022-06-25 14:44:39.359123
# Unit test for method load of class Grammar

# Generated at 2022-06-25 14:44:44.446082
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("grammar.mpy")

# Generated at 2022-06-25 14:44:53.588930
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(r"C:\Users\conda\.pyenv\versions\3.9.0\envs\myenv\lib\lib2to3\Grammar.txt")
    p0 = r"C:\Users\conda\.pyenv\versions\3.9.0\envs\myenv\lib\lib2to3\Grammar.txt"
    if not os.path.isfile(p0):
        unittest.skip("File not found: %s" % p0)
    g.load(r"C:\Users\conda\.pyenv\versions\3.9.0\envs\myenv\lib\lib2to3\Grammar.txt")


# Generated at 2022-06-25 14:44:55.074734
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("load_param")



# Generated at 2022-06-25 14:45:02.774320
# Unit test for method dump of class Grammar

# Generated at 2022-06-25 14:45:08.742237
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import pickle
    from types import ModuleType

    temp_dir = tempfile.gettempdir()
    tmp_filename = os.path.join(temp_dir, 'grammar_test.pkl')
    grammar_1 = Grammar()

    # Create a random pickle file
    with open(tmp_filename, "wb") as f:
        pickle.dump(grammar_1, f, pickle.HIGHEST_PROTOCOL)

    # Check that the dump() method produces an identical file
    grammar_1.dump(tmp_filename)
    with open(tmp_filename, "rb") as f:
        if pickle.load(f) != pickle.load(open(tmp_filename, "rb")):
            sys.exit(-1)

    # Check that the dump() method produces an identical file

# Generated at 2022-06-25 14:45:10.943512
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('<string>')


# Generated at 2022-06-25 14:45:13.391627
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    test_Grammar_load.test_case_0()

test_Grammar_load()


# Generated at 2022-06-25 14:45:14.870377
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("Grammar.py")



# Generated at 2022-06-25 14:45:18.208303
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    # filename is a temporary file that is guaranteed to
    # be deleted when the test finishes
    with tempfile.TemporaryDirectory() as tempdir:
        filename = tempdir + '/test_pgen_dump.pkl'
        grammar_1.dump(filename)



# Generated at 2022-06-25 14:45:24.398091
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.states = [[(0, 0)]]
    grammar.labels = [(0, '')]
    grammar.keywords = {}
    grammar.tokens = {}
    grammar.symbol2label = {}
    grammar.start = 0
    grammar.async_keywords = False
    grammar_0 = Grammar()
    grammar_0.dump('/tmp/grammar.pickle')

# Generated at 2022-06-25 14:45:30.997256
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump('<filename>')


# Generated at 2022-06-25 14:45:34.668860
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump(grammar_1)


# Generated at 2022-06-25 14:45:42.589221
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_1 = Grammar()
    grammar_2 = Grammar()
    grammar_3 = Grammar()
    grammar_4 = Grammar()
    grammar_5 = Grammar()
    grammar_6 = Grammar()
    grammar_7 = Grammar()
    grammar_8 = Grammar()
    grammar_9 = Grammar()
    grammar_10 = Grammar()
    grammar_11 = Grammar()
    grammar_12 = Grammar()
    grammar_13 = Grammar()
    grammar_14 = Grammar()
    grammar_15 = Grammar()
    grammar_16 = Grammar()
    grammar_17 = Grammar()
    grammar_18 = Grammar()



# Generated at 2022-06-25 14:45:46.012105
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_2 = Grammar()
    grammar_2.load("/tmp/grammar.pickle")


# Generated at 2022-06-25 14:45:50.881726
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g1 = Grammar()
    g2 = Grammar()
    g1.load('python3.7.pkl')
    g1.dump('out.pkl')
    g2.load('out.pkl')
    assert g1.__dict__ == g2.__dict__


# Generated at 2022-06-25 14:45:56.214847
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.tokens = {0 : 1}
    g.symbol2label = {0 : 1}
    g.symbol2number = {0 : 1}
    g.keywords = {0 : 1}
    g.start = 0
    g.number2symbol = {0 : 1}
    g.dfas = {0 : 1}
    g.states = [1]
    g.labels = [1]
    g.dump(os.path.join(os.path.dirname(__file__), 'grammar.pickle'))  # Example
    assert os.path.exists(os.path.join(os.path.dirname(__file__), 'grammar.pickle'))

# Generated at 2022-06-25 14:46:06.836130
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_1 = Grammar()
    filename = "pgen.pickle"
    grammar_0.dump(filename)
    grammar_1.load(filename)
    assert grammar_0.labels == grammar_1.labels
    assert grammar_0.keywords == grammar_1.keywords
    assert grammar_0.tokens == grammar_1.tokens
    assert grammar_0.symbol2label == grammar_1.symbol2label
    assert grammar_0.dfas == grammar_1.dfas
    assert grammar_0.states == grammar_1.states
    assert grammar_0.start == grammar_1.start
    assert grammar_0.async_keywords == grammar_1.async_keywords
    assert grammar_0.number2symbol == grammar_1

# Generated at 2022-06-25 14:46:10.309975
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    # file name is a value, rather than a reference
    grammar_0.dump("pgen_grammar")


# Generated at 2022-06-25 14:46:11.614324
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("grammar_pickle.0")


# Generated at 2022-06-25 14:46:12.962342
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("Grammar")


# Generated at 2022-06-25 14:46:37.684403
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    # Test the case where the following condition is true
    #   filename==tempfile.NamedTemporaryFile(dir=os.path.dirname(filename), delete=False).name
    #   os.replace(f.name, filename)==None
    #   tempfile.NamedTemporaryFile
    #   tempfile.NamedTemporaryFile.__init__
    #   os.path.dirname(filename)=='.'
    #   os.replace
    #   pickle.dump(d, f, pickle.HIGHEST_PROTOCOL)==None
    #   tempfile.NamedTemporaryFile.__enter__
    #   pickle.HIGHEST_PROTOCOL==4
    #   f.close==None
    #   f.fileno==None
   