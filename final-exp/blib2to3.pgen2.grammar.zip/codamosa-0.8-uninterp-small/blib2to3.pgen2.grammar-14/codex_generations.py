

# Generated at 2022-06-25 14:36:45.167578
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Python.pkl"))
    # make sure it parses itself
    g.loads(g.dumps())



# Generated at 2022-06-25 14:36:47.764383
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('./grammar_1.pickle')



# Generated at 2022-06-25 14:36:53.744117
# Unit test for method load of class Grammar
def test_Grammar_load():
    import io

    # test that a valid pickle file is loaded correctly
    grammar = Grammar()
    valid_pickle_data = io.BytesIO(b"\x80\x03]q\x00.")
    grammar.loads(valid_pickle_data.read())
    assert grammar.number2symbol == {}

    # test that a pickle with an invalid path is ignored
    grammar = Grammar()
    invalid_pickle_data = io.BytesIO(b"\x80\x03]q\x00.")
    grammar.loads(invalid_pickle_data.read())
    assert grammar.number2symbol == {}


# Generated at 2022-06-25 14:37:03.617650
# Unit test for method load of class Grammar
def test_Grammar_load():
    # A few simple tests for Grammar

    g = Grammar()
    g.symbol2number = {"foo": 42}
    g.number2symbol = {42: "foo"}
    g.states = [[[(1, 2), (2, 3)], [(3, 4)], []]]
    g.dfas = {42: (g.states[0], {3: 1})}
    g.labels = [(1, "bar"), (2, None), (3, "baz")]
    g.keywords = {"baz": 3}
    g.tokens = {4: 0}
    g.symbol2label = {"foo": 1}
    g.start = 42


# Generated at 2022-06-25 14:37:05.567788
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Test of method dump of class Grammar
    grammar_1 = Grammar()

    # call test_case_0()
    test_case_0()


# Generated at 2022-06-25 14:37:14.122998
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    # Path: ./Grammar/Grammar_0.pkl

# Generated at 2022-06-25 14:37:24.568224
# Unit test for method load of class Grammar
def test_Grammar_load():
    import random

    grammar = Grammar()
    with tempfile.NamedTemporaryFile() as f:
        pickle.dump(grammar.__dict__, f, pickle.HIGHEST_PROTOCOL)
        f.seek(0)
        new = Grammar()
        new.load(f.name)
    for k, v in new.__dict__.items():
        assert v == grammar.__dict__[k]
    os.unlink(f.name)

    grammar = Grammar()
    with tempfile.NamedTemporaryFile() as f:
        pickle.dump(grammar.__dict__, f, pickle.HIGHEST_PROTOCOL)
        f.seek(0)
        new = Grammar()
        new.loads(f.read())

# Generated at 2022-06-25 14:37:27.206357
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    filename_0 = "../../../../usr/local/src/pgen/grammar/Grammar"
    # grammar_0.dump(filename_0)


# Generated at 2022-06-25 14:37:38.310168
# Unit test for method dump of class Grammar

# Generated at 2022-06-25 14:37:43.876814
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.symbol2number = {"(": 257, "*": 258, "NAME": 259, ")": 260}
    grammar_0.number2symbol = {257: "(", 258: "*", 259: "NAME", 260: ")"}
    grammar_0.states = [[[(259, 1), (257, 1), (260, 2)], [(258, 3), (260, 3)]]]
    grammar_0.dfas = {
        257: ([[(257, 5), (258, 7)]], {257: 1, 259: 1}),
        258: ([[(259, 6), (257, 6), (260, 8)]], {258: 1, 260: 1}),
    }

# Generated at 2022-06-25 14:37:48.786506
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(token.__file__)



# Generated at 2022-06-25 14:37:51.746918
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = test_case_0()
    grammar_1.dump(None)



# Generated at 2022-06-25 14:37:53.829892
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_10 = Grammar()
    s_0 = tempfile.NamedTemporaryFile()
    grammar_10.dump(s_0.name)


# Generated at 2022-06-25 14:37:57.125717
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    try:
        grammar_0.dump('')
    except SystemExit:
        raise SystemExit(0)


# Generated at 2022-06-25 14:37:58.774923
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("grammar_0.pkl")


# Generated at 2022-06-25 14:38:00.527566
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load(grammar_0)


# Generated at 2022-06-25 14:38:06.091507
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    assert grammar.number2symbol == {}
    assert grammar.symbol2number == {}
    assert grammar.dfas == {}
    assert grammar.keywords == {}
    assert grammar.tokens == {}
    assert grammar.symbol2label == {}
    assert grammar.labels == [(0, 'EMPTY')]
    assert grammar.states == []
    assert grammar.start == 256
    assert grammar.async_keywords == False
    assert isinstance(grammar, Grammar)



# Generated at 2022-06-25 14:38:07.594411
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.load('graminit.txt')
    grammar_1.report()


# Generated at 2022-06-25 14:38:10.699852
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("./pygram_data/grammar.pkl")
    grammar_0.report()



# Generated at 2022-06-25 14:38:12.375743
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Test case 0
    grammar_0 = Grammar()
    grammar_0.dump("grammar.pickle")


# Generated at 2022-06-25 14:38:20.084178
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    #
    # Testing a grammar on an empty grammar
    #
    grammar_1 = Grammar()
    grammar_1.load("./test/data/Grammar_test_data_0")
    assert grammar_0.symbol2number == grammar_1.symbol2number
    assert grammar_0.number2symbol == grammar_1.number2symbol
    assert grammar_0.states == grammar_1.states
    assert grammar_0.dfas == grammar_1.dfas
    assert grammar_0.labels == grammar_1.labels
    assert grammar_0.keywords == grammar_1.keywords
    assert grammar_0.tokens == grammar_1.tokens
    assert grammar_0.symbol2label == grammar_1.symbol2label
   

# Generated at 2022-06-25 14:38:22.607852
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load("./test_data/grammar_0.p")


# Generated at 2022-06-25 14:38:26.040592
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("/home/hgeier/pytype/test-input/grammar_0/grammar_0.pkl")


# Generated at 2022-06-25 14:38:28.492697
# Unit test for method load of class Grammar
def test_Grammar_load():
    def do(filepath):
        grammar = Grammar()
        grammar.load(filename=filepath)
        return grammar
    do("/tmp/test_pgen_0.pkl")



# Generated at 2022-06-25 14:38:35.139847
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.symbol2number = {}
    grammar.number2symbol = {}
    grammar.states = []
    grammar.dfas = {}
    grammar.labels = [(0, "EMPTY")]
    grammar.keywords = {}
    grammar.tokens = {}
    grammar.start = 256
    grammar.dump('grammar.pickle')


# Generated at 2022-06-25 14:38:42.745500
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Create a dummy grammar to load
    grammar_0 = Grammar()
    grammar_1 = Grammar()
    grammar_1.load(grammar_0)
    assert grammar_1.states == []
    assert grammar_1.number2symbol == {}
    assert grammar_1.symbol2label == {}
    assert grammar_1.tokens == {}
    assert grammar_1.dfas == {}
    assert grammar_1.labels == [(0, "EMPTY")]
    assert grammar_1.keywords == {}
    assert grammar_1.symbol2number == {}
    assert grammar_1.start == 256
    assert grammar_1.async_keywords == False

# Generated at 2022-06-25 14:38:47.241872
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    try:
        g = Grammar()
        g.dump(None)
    except Exception:
        print("Failed to dump.")


# Generated at 2022-06-25 14:38:50.348110
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("/tmp/dt_py_grammar_dump")


# Generated at 2022-06-25 14:38:51.666329
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load("Grammar.pickle")


# Generated at 2022-06-25 14:38:54.408753
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    with tempfile.NamedTemporaryFile() as f:
        grammar.dump(f.name)
        f.seek(0)
        copy = pickle.load(f)
    assert copy["tokens"][token.DIVIDE] == 1


# Generated at 2022-06-25 14:38:59.788016
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("./grammar.pickle")


# Generated at 2022-06-25 14:39:01.033025
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump("dump.pickle")


# Generated at 2022-06-25 14:39:02.939264
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    file_0 = os.path.dirname(__file__) + "\\grammar.pkl"
    grammar_0.load(file_0)


# Generated at 2022-06-25 14:39:06.519988
# Unit test for method load of class Grammar
def test_Grammar_load():
    try:
        g = Grammar()
        g.load("/usr/lib/python3.6/tkinter/parsetok.pkl")
    except Exception:
        print("Test case 0 (test_Grammar_load) failed")
    else:
        print("Test case 0 (test_Grammar_load) passed")

test_case_0()
test_Grammar_load()

# Generated at 2022-06-25 14:39:11.474473
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    assert isinstance(grammar, Grammar)
    filename = "Python-3.6.4/Lib/token.pickle"
    grammar.load(filename)
    assert grammar.number2symbol[256] == 'single_input'
    assert grammar.number2symbol[257] == 'file_input'
    assert grammar.number2symbol[258] == 'eval_input'
    assert grammar.number2symbol[259] == 'decorator'
    assert grammar.number2symbol[260] == 'decorators'
    assert grammar.number2symbol[261] == 'decorated'
    assert grammar.number2symbol[262] == 'async_funcdef'
    assert grammar.number2symbol[263] == 'funcdef'
    assert grammar.number2sy

# Generated at 2022-06-25 14:39:13.466398
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('/tmp/grammar.pickle')


# Generated at 2022-06-25 14:39:22.798560
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_1 = Grammar()
    grammar_0.load("fixtures/grammar_pickle")
    grammar_1.load("fixtures/grammar_pickle")

    assert grammar_0.states == grammar_1.states
    assert grammar_0.symbol2number == grammar_1.symbol2number
    assert grammar_0.number2symbol == grammar_1.number2symbol
    assert grammar_0.dfas == grammar_1.dfas
    assert grammar_0.labels == grammar_1.labels
    assert grammar_0.keywords == grammar_1.keywords
    assert grammar_0.tokens == grammar_1.tokens
    assert grammar_0.symbol2label == grammar_1.symbol2label
    assert grammar_0.start

# Generated at 2022-06-25 14:39:24.166212
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = './test/test_grammar'
    grammar_0 = Grammar()
    from pathlib import Path
    filename = Path(filename)
    grammar_0.dump(filename)



# Generated at 2022-06-25 14:39:27.527190
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    test_0 = Grammar()
    try:
        test_0.dump("grammar_dump_python_test_0.pkl")
    except Exception:
        raise AssertionError


# Generated at 2022-06-25 14:39:29.614801
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load(source_path + "Grammar.pkl")


# Generated at 2022-06-25 14:39:58.794330
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test the specific case that the grammar has not been initialized,
    # and the tables cannot be loaded from the file 'tables'

    grammar_1 = Grammar()
    grammar_1.load('tables')


# Generated at 2022-06-25 14:40:09.536417
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()

    grammar_0.load(r'./Grammar/Grammar_load.gram')
    assert grammar_0.keywords == {'async': 629, 'def': 638, 'for': 639, 'if': 640}
    assert grammar_0.labels == [
        (0, "EMPTY"),
        (token.NAME, None),
        (token.NEWLINE, None),
        (token.INDENT, None),
        (token.DEDENT, None),
        (token.ENDMARKER, None),
        (token.ASYNC, "async"),
        (token.DEF, "def"),
        (token.FOR, "for"),
        (token.IF, "if"),
        (token.COLON, None),
    ]
    assert grammar_0

# Generated at 2022-06-25 14:40:19.173623
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """ Unit tests for Grammar.dump """
    grammar_0 = Grammar()
    grammar_0.symbol2number = {'test_symbol2number_0': 2, 'test_symbol2number_1': 1, 'test_symbol2number_2': 0}
    grammar_0.number2symbol = {'test_number2symbol_0': 2, 'test_number2symbol_1': 1, 'test_number2symbol_2': 0}

# Generated at 2022-06-25 14:40:20.506743
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    test_case_0()


# Generated at 2022-06-25 14:40:21.913549
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("tempfile.a")


# Generated at 2022-06-25 14:40:24.566382
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.load(b'_6.2.pickle')
    if verbose:
        print("grammar_1.dump")
    grammar_1.dump(b'_9.pickle')


# Generated at 2022-06-25 14:40:28.408604
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    try:
        grammar.dump('/tmp/foo.pkl')
    except Exception as e:
        print(e)


# Generated at 2022-06-25 14:40:30.780169
# Unit test for method load of class Grammar
def test_Grammar_load():
    g_0 = Grammar()
    g_0.load("./grammar_pgen_parsetab.py")

# Generated at 2022-06-25 14:40:39.493364
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    test_file_0 = tempfile.TemporaryFile()
    grammar_0.dump(test_file_0)
    test_file_0.close()
    try:
        test_file_1 = tempfile.TemporaryFile()
        grammar_0.dump(test_file_1)
        test_file_1.close()
    except:
        test_file_1.close()
    # -- end try

    try:
        test_file_2 = tempfile.TemporaryFile()
        grammar_0.dump(test_file_2)
        test_file_2.close()
    except:
        test_file_2.close()
    # -- end try



# Generated at 2022-06-25 14:40:40.276543
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    pass


# Generated at 2022-06-25 14:40:48.657384
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    try:
        grammar_0 = Grammar()
        f = tempfile.NamedTemporaryFile()
        grammar_0.dump(f.name)
    finally:
        if os.path.isfile(f.name):
            os.remove(f.name)



# Generated at 2022-06-25 14:40:53.030224
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    x = Grammar()
    assert isinstance(x, Grammar)
    assert x.symbol2number == {}
    assert x.number2symbol == {}
    assert x.states == []
    assert x.dfas == {}
    assert x.labels == [(0, "EMPTY")]
    assert x.keywords == {}
    assert x.tokens == {}
    assert x.symbol2label == {}
    assert x.start == 256
    assert x.async_keywords == False

    x.start = 256
    test_case_0()

test_Grammar_dump()

# Generated at 2022-06-25 14:40:55.290836
# Unit test for method load of class Grammar
def test_Grammar_load():
    with open("Lib/lib2to3/PatternGrammar.txt", "rb") as f:
        grammar = Grammar()
        grammar.loads(f.read())


# Generated at 2022-06-25 14:40:57.394177
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('/data/home/otp/jython/Lib/lib2to3/Grammar.pickle')


# Generated at 2022-06-25 14:40:59.589251
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    filename = ""
    grammar_0.dump(filename)


# Generated at 2022-06-25 14:41:03.354450
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    # Create an instance of Grammar called grammar_0.
    grammar_0 = Grammar()
    # Call the method dump() of class Grammar: output_0.
    output_0 = grammar_0.dump(filename=filename)
    print(output_0)



# Generated at 2022-06-25 14:41:11.028461
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Define a temporary file and its name.
    with tempfile.NamedTemporaryFile(mode="wt") as f:
        filename = f.name
        # Create a temporary Grammar object.
        grammar_0 = Grammar()
        # Save the Grammar object to the temporary file.
        grammar_0.dump(filename)
        # Create a temporary Grammar object.
        grammar_1 = Grammar()
        # Load the Grammar object from the temporary file.
        grammar_1.load(filename)


# Generated at 2022-06-25 14:41:14.303242
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("/tests/example_grammar.pickle")


# Generated at 2022-06-25 14:41:24.261466
# Unit test for method dump of class Grammar

# Generated at 2022-06-25 14:41:27.974740
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    tmp_dir = tempfile.gettempdir()
    grammar_0 = Grammar()
    grammar_0.dump(os.path.join(tmp_dir, 'grammar_dump.txt'))
    # Test new object
    grammar_1 = Grammar()
    grammar_1.load(os.path.join(tmp_dir, 'grammar_dump.txt'))


# Generated at 2022-06-25 14:41:50.928483
# Unit test for method load of class Grammar
def test_Grammar_load():
    with open("pgen_data/python36.pkl") as f:
        grammar_tails_test1 = pickle.load(f)
    grammar_test1 = Grammar()
    grammar_test1.load("pgen_data/python36.pkl")
    assert grammar_test1.symbol2number == grammar_tails_test1["symbol2number"]
    assert grammar_test1.number2symbol == grammar_tails_test1["number2symbol"]
    assert grammar_test1.states == grammar_tails_test1["states"]
    assert grammar_test1.dfas == grammar_tails_test1["dfas"]
    assert grammar_test1.labels == grammar_tails_test1["labels"]
    assert grammar_test1.keywords == grammar_tails_test1["keywords"]

# Generated at 2022-06-25 14:41:58.485378
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.tokens = {1:1, 2:2, 3:3}
    grammar.keywords = {'a':1, 'b':2, 'c':3}
    grammar.states = [4, 5, 6, 7]
    grammar.symbol2label = {'t':1, 's':2, 'j':3}
    grammar.symbol2number = {'t':1, 's':2, 'j':3}
    grammar.number2symbol = {1:'t', 2:'s', 3:'j'}
    grammar.labels = [1, 2, 3]
    grammar.dfas = {1:(1, 2), 2:(3, 4)}
    grammar.start = 256
    test_case_0()

# Generated at 2022-06-25 14:42:06.741540
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # open a file for reading and write data to it
    with tempfile.NamedTemporaryFile(delete=False) as f:
        grammar_0 = Grammar()
        # Call method dump of grammar_0
        grammar_0.dump(f.name)
        del grammar_0
        with open(f.name, "r") as f:
            assert f.readline() == "cos\n"
            assert f.readline() == "2\n"
            assert f.readline() == "sin\n"
        # close the file
    os.remove(f.name)


# Generated at 2022-06-25 14:42:08.546247
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    filename_0 = ""
    grammar_0.load(filename_0)


# Generated at 2022-06-25 14:42:14.012366
# Unit test for method load of class Grammar

# Generated at 2022-06-25 14:42:17.764531
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load(
        "/usr/lib/python3.6/pickle.cpython-36m-i386-linux-gnu.so"
    ) # TODO: check if this entry exists in sys.path


# Generated at 2022-06-25 14:42:27.493560
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filenames = [ "./b.pkl", "./b.pkl", "./b.pkl", "./b.pkl", "./b.pkl", "./b.pkl", "./b.pkl", "./b.pkl", "./b.pkl", "./b.pkl", "./b.pkl", "./b.pkl", "./b.pkl", "./b.pkl", "./b.pkl", "./b.pkl", ]
    grammar_1 = Grammar()
    grammar_0 = Grammar()
    grammar_0._update(grammar_1.symbol2number)
    grammar_0._update(grammar_1.number2symbol)
    grammar_0._update(grammar_1.dfas)

# Generated at 2022-06-25 14:42:30.893421
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    #Copy
    grammar_2 = grammar_1.copy()
    #test dump
    grammar_2.dump("test.pkl")

if __name__ == "__main__":
    test_case_0()
    test_Grammar_dump()

# Generated at 2022-06-25 14:42:33.639622
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_ = Grammar()
    filename = "None"
    grammar_.dump(filename)


# Generated at 2022-06-25 14:42:42.181311
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .conv import parse_grammar

    gram = parse_grammar("Grammar/Grammar", "Grammar.txt", "Grammar.pickle")
    copy = Grammar()
    copy.load(os.path.join(os.path.dirname(__file__), "Grammar.pickle"))

    def eq(a, b):
        try:
            assert a == b
        except Exception:
            print(a)
            print(b)
            raise

    eq(gram.symbol2number, copy.symbol2number)
    eq(gram.number2symbol, copy.number2symbol)
    eq(gram.dfas, copy.dfas)
    eq(gram.labels, copy.labels)
    eq(gram.start, copy.start)

# Generated at 2022-06-25 14:43:24.824005
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('')
    assert True


# Generated at 2022-06-25 14:43:28.963348
# Unit test for method load of class Grammar
def test_Grammar_load():
    # TODO: implement properly
    grammar = Grammar()
    grammar.load("./non-existent.pickle")

# Generated at 2022-06-25 14:43:30.366308
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load('./pgen/grammar3.6')


# Generated at 2022-06-25 14:43:32.122013
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("grammar.pickle")


# Generated at 2022-06-25 14:43:40.742781
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # From issue https://github.com/python/typeshed/pull/539
    grammar_0 = Grammar()
    grammar_0.dump(filename=os.path.dirname(os.path.dirname(__file__)))
    grammar_0.dump(filename=os.path.dirname(os.path.dirname(__file__)))
    grammar_0.dump(filename=os.path.dirname(os.path.dirname(__file__)))
    grammar_0.dump(filename=os.path.dirname(os.path.dirname(__file__)))
    grammar_0.dump(filename=os.path.dirname(os.path.dirname(__file__)))
    grammar_0.dump(filename=os.path.dirname(os.path.dirname(__file__)))
    grammar

# Generated at 2022-06-25 14:43:49.366853
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()

# Generated at 2022-06-25 14:43:50.400761
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load(tempfile.mktemp())

# Generated at 2022-06-25 14:43:52.806992
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_load = Grammar()
    grammar_load.load('<string>')


# Generated at 2022-06-25 14:43:54.537211
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('/dev/null')


# Generated at 2022-06-25 14:43:59.750334
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_1 = Grammar()
    try:
        grammar_1.load("_Grammar_dump")
    except FileNotFoundError:
        grammar_0.dump("_Grammar_dump")


# Generated at 2022-06-25 14:44:23.561549
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('grammar.pkl')


# Generated at 2022-06-25 14:44:26.742028
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.load('./tests/data/Grammar')
    grammar_0.dump('./tests/data/Grammar_dump')


# Generated at 2022-06-25 14:44:28.867199
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('/tmp/grammar_dump.pkl')


# Generated at 2022-06-25 14:44:30.383255
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump(__file__ + ".pickle")


# Generated at 2022-06-25 14:44:32.345840
# Unit test for method load of class Grammar
def test_Grammar_load():
    """
    Make sure Grammar.loads has no syntax errors
    """
    Grammar.loads(grammar_0, bytes("", "ascii"))


# Generated at 2022-06-25 14:44:36.532509
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.start = 257
    grammar_0.dump("/home/kurt/test_files/test_files_2/test_files_2/test_files_4/test_files_4/test_files_4/test_files_4")


# Generated at 2022-06-25 14:44:39.053144
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    try:
        grammar_0.dump(os.devnull)
    except Exception:
        assert False

# Generated at 2022-06-25 14:44:44.576560
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    global grammar_0
    import os

    f = tempfile.NamedTemporaryFile(mode="w+b", delete=False)
    f.close()
    try:
        grammar_0.dump(f.name)
        assert os.path.isfile(f.name)
    finally:
        os.unlink(f.name)



# Generated at 2022-06-25 14:44:48.065243
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("/home/hgeunlee/pycharmprojects/untitled4/venv/lib/python3.7/wsgiref/grammar/grammar_0.pickle")


# Generated at 2022-06-25 14:44:50.362447
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("dump_test.pickle")
    # clean up after the test
    os.remove("dump_test.pickle")


# Generated at 2022-06-25 14:45:55.984165
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump('pgen_grammar')

# Generated at 2022-06-25 14:45:57.640383
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('<file name>')


# Generated at 2022-06-25 14:46:00.968341
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("grammar.pickle")
    assert os.path.isfile("grammar.pickle")
    os.remove("grammar.pickle")


# Generated at 2022-06-25 14:46:04.300937
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump(r'C:\Users\akumar\git\python\mypyc\mypyc\Grammar.py')



# Generated at 2022-06-25 14:46:06.622581
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("test.pkl")  # should not raise an exception



# Generated at 2022-06-25 14:46:10.976943
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.start = 256
    g.states = [[]]
    g.keywords = {'None': 1}
    g.labels = [(256, 'None')]
    g.symbol2number = {'None': 256}
    g.number2symbol = {256: 'None'}
    g.dfas = {256: ([[(1, 0)]], {1: 1})}
    g.dump('tmp.pickle')



# Generated at 2022-06-25 14:46:12.655960
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = "foo.pkl"
    grammar = Grammar()
    grammar.load(filename)
    assert filename == "foo.pkl"

# Generated at 2022-06-25 14:46:17.604748
# Unit test for method load of class Grammar
def test_Grammar_load():
    from pgen2.parse import pgen
    from pgen2.pgen import _Grammar

    grammar = _Grammar(token)
    _ = pgen(grammar, "python3-3-8.grm")
    grs = Grammar()
    grs.load(grammar.pickle_file)

# Generated at 2022-06-25 14:46:20.482581
# Unit test for method load of class Grammar
def test_Grammar_load():
    # XXX This is duplicated from test_conv.  Do we need this test?
    grammar_0 = Grammar()
    grammar_0.load('Grammar.pickle')

# Generated at 2022-06-25 14:46:23.719186
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # dump test case
    grammar = Grammar()
    filename = "nofile"
    grammar.dump(filename)

