

# Generated at 2022-06-25 14:36:46.254639
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()

    def check_exception(name, value):
        pass

    # Check raised exceptions
    try:
        grammar_0.dump('/home/benjamin/workspace/pypy/bin/lib-python/modified-2.7.13/test/tokenize_grammar.txt')
    except Exception as e:
        check_exception('dump', e)


# Generated at 2022-06-25 14:36:54.473223
# Unit test for method load of class Grammar
def test_Grammar_load():
    p = Grammar()
    # pickle file 1

# Generated at 2022-06-25 14:36:56.813585
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = "ast_grammar.py"
    if os.path.isfile(filename):
        grammar = Grammar()
        grammar.load(filename)
    else:
        # It would be better to skip this test if the file is not
        # present.
        assert False


# Generated at 2022-06-25 14:37:04.392233
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # dump() evaluates to None
    assert test_case_0.grammar_0.dump("/tmp") is None

    # dump() raises FileNotFoundError if no such file
    try:
        filename = "/no/such/file"
        grammar = test_case_0.grammar_0
        grammar.dump(filename)
    except OSError as exc:
        assert exc.errno == 2
        assert exc.strerror == 'No such file or directory'
        assert exc.filename == filename
    else:
        raise AssertionError("OSError not raised")



# Generated at 2022-06-25 14:37:12.687576
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pickletools
    from . import longintrepr
    from . import sre_constants
    from . import _abcoll
    from . import _bootlocale
    from . import _collections_abc
    from . import _compat_pickle
    from . import _collections
    from . import _heapq
    from . import _bisect
    from . import _symtable
    from . import _weakrefset
    from . import _random
    from . import _elementtree
    from . import _hashlib
    from . import _heapq
    from . import _json
    from . import _locale
    from . import _lsprof
    from . import _multibytecodec
    from . import _opcode
    from . import _posixsubprocess
    from . import _random


# Generated at 2022-06-25 14:37:16.732693
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    # change this to point to a pickle file
    grammar.load(os.path.dirname(__file__) + "/Grammar.pkl")



# Generated at 2022-06-25 14:37:20.841167
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump('test_out.pickle')
    grammar_2 = Grammar()
    grammar_2.load('test_out.pickle')
    assert grammar_1.symbol2number == grammar_2.symbol2number


# Generated at 2022-06-25 14:37:21.680038
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    test_case_0()


# Generated at 2022-06-25 14:37:24.178945
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load(os.path.dirname(__file__) + "/Grammar.pkl")


# Generated at 2022-06-25 14:37:26.205901
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("grammar.pickle")
    grammar.loads(b"")

test_case_0()
test_Grammar_load()

# Generated at 2022-06-25 14:37:34.566498
# Unit test for method load of class Grammar
def test_Grammar_load():
    st0 = os.stat('/dev/null')
    grammar_0 = Grammar()
    grammar_0.load('/dev/null')
    st1 = os.stat('/dev/null')
    assert (st0.st_size == st1.st_size)



# Generated at 2022-06-25 14:37:37.466361
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    grammar_0 = Grammar()
    grammar_0.dump(r"C:\windows\temp\test\test.pkl")
    grammar_0.dump(r"C:\windows\temp\test\test.pkl")


# Generated at 2022-06-25 14:37:40.578612
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('/tmp/grammar_0.dump')


# Generated at 2022-06-25 14:37:42.491542
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/tmp/test_Grammar_dump.py.pickle")


# Generated at 2022-06-25 14:37:44.084494
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("Grammar.pickle")



# Generated at 2022-06-25 14:37:51.880565
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('/tmp/grammar_load_file_5.tmp')
    assert grammar_0.symbol2number['symbol2number'] == 0
    grammar_0 = Grammar()
    grammar_0.load('/tmp/grammar_load_file_0.tmp')
    assert grammar_0.symbol2number['symbol2number'] == 1
    grammar_0 = Grammar()
    grammar_0.load('/tmp/grammar_load_file_2.tmp')
    assert grammar_0.symbol2number['symbol2number'] == 2
    grammar_0 = Grammar()
    grammar_0.load('/tmp/grammar_load_file_8.tmp')
    assert grammar_0.symbol2number['symbol2number'] == 3

# Generated at 2022-06-25 14:38:01.665291
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.symbol2number = {'b': 1, 'c': 2, 'd': 3}
    grammar_0.number2symbol = {1: 'b', 2: 'c', 3: 'd'}
    grammar_0.states = [[[(2, 1), (3, 4)], [(4, 2)], [(4, 4)]], [], []]
    grammar_0.dfas = {1: ([[(2, 1), (3, 4)], [(4, 2)], [(4, 4)]], {1: 1, 2: 1}), 2: ([[(2, 1)]], {1: 1}), 3: ([[(2, 1)], [(2, 3)]], {1: 1, 2: 1})}

# Generated at 2022-06-25 14:38:03.144463
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_obj = Grammar()
    assert grammar_obj.load() == None


# Generated at 2022-06-25 14:38:05.884747
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    for filename, grammar in (
        # filename, grammar
        ("Grammar_0.py", "grammar_0"),
    ):
        yield grammar_0_dump, filename, grammar

# Test for method dump for grammar_0

# Generated at 2022-06-25 14:38:12.782828
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Setup
    grammar_0 = Grammar()

    # Exercise
    grammar_0.dump('/tmp/python_grammar_dump.txt')

    # Verify
    # module.parse()
    # module.parse_file()
    # module.parse_errors()
    # module.parse_file_errors()
    # module.parse_tokens()
    # module.parse_file_tokens()
    # module.parse_tokens_raw()
    # module.parse_file_tokens_raw()
    # module.parse_tree()
    # module.parse_file_tree()
    # module.parse_format()
    # module.parse_file_format()


# Generated at 2022-06-25 14:38:19.671895
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    # Make sure this function call raises an error if the dump fails
    grammar_0.dump("test_file")


# Generated at 2022-06-25 14:38:23.938187
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()

    # Use a temporary pkl file for the pickle
    temp_file = tempfile.NamedTemporaryFile(delete=False)
    try:
        grammar.dump(temp_file.name)
    finally:
        temp_file.close()



# Generated at 2022-06-25 14:38:30.782943
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(os.path.join(os.path.dirname(__file__), 'Grammar.pkl'))
    grammar.load(os.path.join(os.path.dirname(__file__), 'Python2.pkl'))
    grammar.load(os.path.join(os.path.dirname(__file__), 'Python3.pkl'))

# Unit tests for method loads of class Grammar

# Generated at 2022-06-25 14:38:41.258176
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar = Grammar()
    grammar.load("../Grammar/Grammar")

# Generated at 2022-06-25 14:38:47.711138
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    # Pickle dictionary for this test case

# Generated at 2022-06-25 14:38:50.943310
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))


# Generated at 2022-06-25 14:38:53.187569
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test the load() method with a non-existent pickle file.
    try:
        test_case_0().load("pgen_test")
        assert False, "unexpected success"
    except IOError:
        pass



# Generated at 2022-06-25 14:38:56.200340
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
# Use of method dump of class Grammar
    filename = "temp_dump.pickle"
    grammar.dump(filename)
    filename = "temp_load.pickle"
# Use of method load of class Grammar
    grammar.load(filename)


# Generated at 2022-06-25 14:38:57.518105
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    assert Grammar().dump('src/pgen2/grammar.py') is None


# Generated at 2022-06-25 14:39:00.472198
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load(
        os.path.join(os.path.dirname(__file__), "Grammar.pickle")
    )


# Generated at 2022-06-25 14:39:05.402918
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g0 = Grammar()
    f0 = tempfile.NamedTemporaryFile(delete=False)
    g0.dump(f0.name)
    g0.load(f0.name)
    os.remove(f0.name)


# Generated at 2022-06-25 14:39:06.108708
# Unit test for method load of class Grammar
def test_Grammar_load():
    pass


# Generated at 2022-06-25 14:39:07.491165
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("./python_grammar.pkl")


# Generated at 2022-06-25 14:39:10.185526
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    with tempfile.TemporaryDirectory() as tempdir:
        grammar_0 = Grammar()
        grammar_0.dump(os.path.join(tempdir, 'grammar_0.pkl'))


# Generated at 2022-06-25 14:39:12.434511
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filepath = "temp_parse.pkl"
    grammar_0 = Grammar()
    grammar_0.dump(filepath)


# Generated at 2022-06-25 14:39:13.886362
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("/tmp/grammar")


# Generated at 2022-06-25 14:39:15.753200
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    file_1 = 'test_files/test_case_0.pkl'
    grammar_0.dump(file_1)


# Generated at 2022-06-25 14:39:19.136411
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    with tempfile.NamedTemporaryFile(delete=False) as f:
        grammar_0.dump(f.name)


# Generated at 2022-06-25 14:39:25.947564
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    global grammar_0
    assert grammar_0.symbol2number == {}
    assert grammar_0.number2symbol == {}
    assert grammar_0.states == []
    assert grammar_0.dfas == {}
    assert grammar_0.labels == [(0, 'EMPTY')]
    assert grammar_0.keywords == {}
    assert grammar_0.tokens == {}
    assert grammar_0.symbol2label == {}
    assert grammar_0.start == 256

if __name__ == "__main__":
    #import sys
    #sys.modules['_ast'] = sys.modules['syntax']
    #import _pgen
    #Grammar()
    #import test_Grammar
    pass

# Generated at 2022-06-25 14:39:27.885522
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump("dump_grammar_1.pickle")


# Generated at 2022-06-25 14:39:32.685647
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('/dev/null')


# Generated at 2022-06-25 14:39:34.019410
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('Grammar1')


# Generated at 2022-06-25 14:39:36.172948
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('grammar.pkl')


# Generated at 2022-06-25 14:39:37.507758
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    load(grammar, "grammar.pkl")



# Generated at 2022-06-25 14:39:39.252372
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("/a/b")



# Generated at 2022-06-25 14:39:42.286098
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump(filename='/home/benpoehling/projects/python/cpython/Lib/pickle_protocol_test/test_pickle_dump_Grammar_0')


# Generated at 2022-06-25 14:39:46.161493
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("/ram/SciELO/Scielo-Projects/oarepo-marc21/tests/__output_0/hopper_grammar/hopper_grammar.pickle")


# Generated at 2022-06-25 14:39:53.747598
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from typing import Callable, Union
    import io
    # No type annotation available.
    g = Grammar()
    class T(io.StringIO):
        def close(self): pass
    f = T()
    # Pickling requires a file descriptor, so StringIO won't work.
    # However, if the file is closed before unpickling, you don't
    # need to seek back to the beginning.
    expected = pickle.dumps(g)
    # No type annotation available.
    g.dump(f)
    assert f.getvalue() == expected



# Generated at 2022-06-25 14:40:00.387868
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    grammar_1 = Grammar()

    if not hasattr(os, 'unlink'):
        # this function used to work on Windows for me but I rolled back
        # to a version without it. I think it's still needed but I don't
        # have time to find out why.
        return

    f = None

# Generated at 2022-06-25 14:40:01.900157
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    test = Grammar()
    test.dump(Path(""))


# Generated at 2022-06-25 14:40:08.793805
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    assert grammar_0.dump(
        "C:/Users/Biniam/Documents/GitHub/calculator/calculator/calculator/third-party/ply/ply/python3/"
    ) is None


# Generated at 2022-06-25 14:40:11.399431
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("/Users/nathansuberi/.virtualenvs/umap-QLUpiKj1/lib/python3.7/grammar_py_345.pkl")


# Generated at 2022-06-25 14:40:21.592376
# Unit test for method load of class Grammar
def test_Grammar_load():
    import ast
    import io
    import tempfile
    from . import conv
    from . import pgen2

    pgen = conv.ParserGenerator("Grammar")
    pgen.prepare_pgen()

    # read Python 2 grammar
    f = io.StringIO(_GRAMMAR_1)
    grammar = pgen.generate_grammar(f)

    # test load method with a pickle file
    with tempfile.NamedTemporaryFile(dir=".") as f:
        grammar.dump(f.name)
        grammar_copy = Grammar()
        grammar_copy.load(f.name)

        assert grammar.start == grammar_copy.start

        assert len(grammar.symbol2number) == len(grammar_copy.symbol2number)

# Generated at 2022-06-25 14:40:23.755729
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    try:
        Grammar.dump(grammar_0, "")
    except OSError:
        raise AssertionError


# Generated at 2022-06-25 14:40:32.547379
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    print("grammar_1: " + str(grammar_1))
    assert grammar_1 is not None, "grammar_1 is None"
    filename = "../pgen2/Python.asdl"
    print("filename: " + str(filename))
    assert filename is not None, "filename is None"
    grammar_1.load(filename)
    print("grammar_1: " + str(grammar_1))
    assert grammar_1 is not None, "grammar_1 is None"



# Generated at 2022-06-25 14:40:34.373763
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("test.grammar")


# Generated at 2022-06-25 14:40:35.837877
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2

    grammar_1 = pgen2.driver.load_grammar()


# Generated at 2022-06-25 14:40:38.617140
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    path_0_0 = tempfile.mktemp(suffix='_0_0')
    grammar_0.dump(path_0_0)


# Generated at 2022-06-25 14:40:39.852363
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    assert grammar_0.dump("tests/test_grammar.out") is None

# Generated at 2022-06-25 14:40:45.757029
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Now test dump() and loads()
    grammar = Grammar()
    # test raw grammar
    from . import pgen2
    pgen2.drivers.driver(grammar)
    # Now test dump() and load()
    grammar.dump("Grammar_dump.py")
    for temp in ("Grammar_dump.py", "Grammar_dump.py.tmp"):
        assert os.path.isfile(temp)
    grammar2 = Grammar()
    grammar2.load("Grammar_dump.py")
    assert grammar._dump_attrs == grammar2._dump_attrs
    grammar3 = Grammar()
    grammar3.loads(grammar2.dumps())
    assert grammar._dump_attrs == grammar3._dump_attrs
    grammar4 = grammar3.copy()
    assert grammar._

# Generated at 2022-06-25 14:40:49.913540
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump('pgen_test_0')


# Generated at 2022-06-25 14:40:51.225043
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump(filename="./Grammar_pytd2.pickle")


# Generated at 2022-06-25 14:40:53.256215
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    print('test_Grammar_dump')
    grammar_0 = Grammar()
    file_name_0 = tempfile._get_default_tempdir() + os.path.sep + 'tmp_0'
    grammar_0.dump(file_name_0)



# Generated at 2022-06-25 14:40:56.141709
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from random import randint
    randint(1, 1)
    filename = "test.pickle"
    g = Grammar()
    g.symbol2number["a"] = 1
    g.dump(filename)

# Generated at 2022-06-25 14:40:57.842793
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('/tmp/grammar_0.pickle')



# Generated at 2022-06-25 14:40:59.142463
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("test_Grammar_dump")


# Generated at 2022-06-25 14:41:00.970825
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    # noinspection PyUnresolvedReferences
    grammar_0.load("/../testdata/Lib/lib2to3/Grammar.pickle")

# Generated at 2022-06-25 14:41:03.355904
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = "test_filename"
    grammar_0 = Grammar()
    grammar_0.dump(filename)

# Generated at 2022-06-25 14:41:04.391542
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()


# Generated at 2022-06-25 14:41:05.841024
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    test_case_0()
    test_case_0()


# Generated at 2022-06-25 14:41:14.302750
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("./temp.pickle")


# Generated at 2022-06-25 14:41:16.357784
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    with tempfile.NamedTemporaryFile() as f:
        test_case_0().dump(f.name)


# Generated at 2022-06-25 14:41:25.974539
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()

    grammar.symbol2number = {'SYMBOL2NUMBER': 1}
    grammar.number2symbol = {1: 'NUMBER2SYMBOL'}
    grammar.states = [[[(0, 1), (1, 0)]]]
    grammar.dfas = {1: [[(1, 0), (0, 1)], [1, 2]]}
    grammar.labels = [(0, 'EMPTY')]
    grammar.keywords = {'KEY': 1}
    grammar.tokens = {1: 1}
    grammar.symbol2label = {'SYMBOL2LABEL': 1}
    grammar.start = 256
    grammar.async_keywords = False

    grammar.dump('dump')

    with open('dump', 'rb') as f:
        assert pick

# Generated at 2022-06-25 14:41:34.859983
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("test_dump.pkl")
    try:
        os.remove("test_dump.pkl")
    except IOError:
        pass
    grammar_0 = Grammar()
    grammar_0.dump("test_dump.pkl")
    try:
        os.remove("test_dump.pkl")
    except IOError:
        pass
    grammar_1 = Grammar()
    grammar_1.symbol2number = {'a': 0}
    grammar_1.number2symbol = {0: 'a'}
    grammar_1.states = [1, 0, []]
    grammar_1.dfas = {'a': [0, 1]}
    grammar_1.labels = [0, 1]

# Generated at 2022-06-25 14:41:39.948199
# Unit test for method load of class Grammar
def test_Grammar_load():
    fd = None
    try:
        (fd, path) = tempfile.mkstemp()
        grammar_0 = Grammar()
        grammar_0.dump(path)
        grammar_1 = Grammar()
        grammar_1.load(path)
        assert grammar_0.labels == grammar_1.labels
    finally:
        os.close(fd)
        os.remove(path)


# Generated at 2022-06-25 14:41:44.553119
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    with tempfile.TemporaryDirectory() as tmpdirname:
        file_0 = os.path.join(tmpdirname, '_test0_grammar.pkl')
        grammar_0 = Grammar()
        grammar_0.dump(file_0)


# Generated at 2022-06-25 14:41:47.148253
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("/home/ubuntu/projects/git/python-parse/lib/python3.7/pyfastparsegrammar.pkl")

# Generated at 2022-06-25 14:41:50.329649
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    test_case_0()
    grammar_0 = Grammar()
    with tempfile.TemporaryDirectory() as tmpdir:
        grammar_0.dump(tmpdir + "/grammar.pickle")
        grammar_1 = Grammar()
        grammar_1.load(tmpdir + "/grammar.pickle")
        original = grammar_0.number2symbol
        copied = grammar_1.number2symbol
        assert original is not copied
        assert original == copied


# Generated at 2022-06-25 14:41:52.486169
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(os.path.join(os.path.dirname(__file__), "../grammar/Grammar.txt"))


# Generated at 2022-06-25 14:41:54.265250
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("./test_tables.pyc")


# Generated at 2022-06-25 14:42:03.682314
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("grammar.pkl")
    grammar.number2symbol[1] = "test"
    grammar.symbol2number["test"] = 1
    grammar.keywords["test"] = 1
    grammar.tokens[1] = 1
    grammar.symbol2label["test"] = 1
    grammar.labels[1] = (1, "test")
    grammar.start = 257
    grammar.async_keywords = True
    grammar.dump("grammar.pkl")
    os.remove("grammar.pkl")


# Generated at 2022-06-25 14:42:07.291252
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    filename_0 = "test_file.txt"
    # Call Grammar.dump with arguments filename_0
    grammar_0.dump(filename_0)


# Generated at 2022-06-25 14:42:09.849084
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    with tempfile.TemporaryDirectory() as tmpdir:
        grammar = Grammar()
        outfile = os.path.join(tmpdir, "dump_test.py")
        grammar.dump(outfile)
        grammar.load(outfile)

# Generated at 2022-06-25 14:42:11.034247
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("./Grammar.pkl")


# Generated at 2022-06-25 14:42:13.674955
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump(filename=None)


# Generated at 2022-06-25 14:42:15.941686
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Create an instance of class Grammar
    grammar_1 = Grammar()
    # The data structure to be dumped is unknown, so that the dump
    # method cannot be tested
    pass



# Generated at 2022-06-25 14:42:18.228805
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("data/Grammar/graminit.pickle")
    assert g


# Generated at 2022-06-25 14:42:21.274935
# Unit test for method load of class Grammar
def test_Grammar_load():

    grammar = Grammar()
    grammar.load(
        os.path.join(os.path.dirname(__file__), "Grammar.pkl")
    )  # This should not raise an exception.



# Generated at 2022-06-25 14:42:23.622877
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('./pgen.pickle')


# Generated at 2022-06-25 14:42:26.889120
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    path_0 = "/ywG1fUg7VUie0n5cvq3Z.pkl"

    def check_exception_0() -> None:
        grammar_0.dump(path_0)

    check_exception_0()



# Generated at 2022-06-25 14:42:31.393388
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump("grammars/python/Grammar.txt")


# Generated at 2022-06-25 14:42:35.200689
# Unit test for method dump of class Grammar
def test_Grammar_dump():
  grammar_0 = Grammar()
  grammar_0.dump('./test/test_pickle_grammar1.pickle')
  grammar_0.load('./test/test_pickle_grammar1.pickle')


# Generated at 2022-06-25 14:42:37.867357
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump(os.path.join(os.path.dirname(os.path.dirname(__file__)), "Grammar.pkl"))



# Generated at 2022-06-25 14:42:47.440072
# Unit test for method load of class Grammar
def test_Grammar_load():
    assert 0


if __name__ == "__main__":
    prop = property
    import types

    # FIXME: this isn't working yet, because it uses properties that are
    # missing from the tree nodes, and it traces to code that isn't
    # present in a tree-only build.

    tokenizer_0 = token
    # g.report()
    # print("Tokens:")
    # for k, v in list(g.keywords.items()) + list(g.tokens.items()):
    #     print("%3d %s" % (v, k))
    # print("Symbols:")
    # for k, v in list(g.symbol2number.items()):
    #     print("%3d %s" % (v, k))

# Generated at 2022-06-25 14:42:56.029270
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle

    with tempfile.TemporaryDirectory() as tmpdirname:
        with tempfile.NamedTemporaryFile(dir=tmpdirname) as f:
            grammar_0 = Grammar()
            grammar_0.dump(f.name)
            with open(f.name, 'rb') as f2:
                d = pickle.load(f2)
            for dict_attr in (
                'symbol2number',
                'number2symbol',
                'dfas',
                'keywords',
                'tokens',
                'symbol2label',
            ):
                assert dict_attr in d
            assert 'labels' in d
            assert 'states' in d
            assert 'start' in d
            assert 'async_keywords' in d


# Generated at 2022-06-25 14:43:04.576283
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    temp_file_0 = tempfile.NamedTemporaryFile()
    grammar_0.dump(temp_file_0.name)
    temp_file_0.close()
    grammar_0.load(temp_file_0.name)

    def Grammar_load_test_lambda__0():
        # Test case for method load of class Grammar
        grammar_0 = Grammar()
        temp_file_0 = tempfile.NamedTemporaryFile()
        grammar_0.dump(temp_file_0.name)
        pickle.dump(grammar_0.__dict__, temp_file_0)
        temp_file_0.close()
        grammar_0.load(temp_file_0.name)



# Generated at 2022-06-25 14:43:14.908395
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('./test/test_grammar.pkl')

# Generated at 2022-06-25 14:43:16.158025
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("./pgen_data/simple_grammar.pkl")


# Generated at 2022-06-25 14:43:18.397119
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('')



# Generated at 2022-06-25 14:43:25.763709
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # test no argument
    grammar_1 = Grammar()
    try:
        grammar_1.dump()
    except TypeError:
        pass
    else:
        assert False, "Unexpected success!"
    # test argument of wrong type
    grammar_2 = Grammar()
    try:
        grammar_2.dump(0)
    except TypeError:
        pass
    else:
        assert False, "Unexpected success!"

# Generated at 2022-06-25 14:43:31.509597
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    print("Testing Grammar.dump")
    grammar_0 = Grammar()
    with tempfile.NamedTemporaryFile(mode="wb", delete=False) as temp:
        grammar_0.dump(temp.name)


# Generated at 2022-06-25 14:43:40.265079
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    for _ in range(10):
        grammar_0.load('D:\\dev\\LN\\lnpy\\grammar_pgen.pkl.py3k')
        grammar_0.load('D:\\dev\\LN\\lnpy\\grammar_pgen.pkl.py3k')
        grammar_0.load('D:\\dev\\LN\\lnpy\\grammar_pgen.pkl.py3k')
        grammar_0.load('D:\\dev\\LN\\lnpy\\grammar_pgen.pkl.py3k')
        grammar_0.load('D:\\dev\\LN\\lnpy\\grammar_pgen.pkl.py3k')

# Generated at 2022-06-25 14:43:41.788625
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar0 = Grammar()
    grammar0.load(r'Grammar')


# Generated at 2022-06-25 14:43:49.881883
# Unit test for method load of class Grammar

# Generated at 2022-06-25 14:43:54.873012
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    from . import conv, pgen
    from . import token

    from .tokenize import generate_tokens
    from .tokenize import COMMENT, ENCODING, NEWLINE, NL, NAME, NUMBER, OP, STRING

    with open(f"Grammar.pickle", "rb") as f:
        d = pickle.loads(f.read())
        grammar = Grammar()
        grammar._update(d)
    assert grammar.symbol2number[";"] == 258
    assert grammar.number2symbol[grammar.symbol2number[";"]] == ";"
    assert grammar.start == 258
    assert grammar.tokens[grammar.keywords[";"]] == grammar.tokens[58]
    assert grammar.dfas[258][1][58] == 1
   

# Generated at 2022-06-25 14:43:57.860245
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('./test_data/test_pgen/Grammar/pickle')

# Generated at 2022-06-25 14:44:03.410950
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    pickle.dump({'symbol2number':{'x': 1, 'y': 2}}, open('/tmp/pyparse_grammar_0.pkl', 'wb'))
    grammar_0.load('/tmp/pyparse_grammar_0.pkl')
    assert grammar_0.symbol2number == {'x': 1, 'y': 2}

# Generated at 2022-06-25 14:44:04.271082
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    assert 0


# Generated at 2022-06-25 14:44:07.499561
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("Grammar.pkl")

# Generated at 2022-06-25 14:44:08.608184
# Unit test for method dump of class Grammar

# Generated at 2022-06-25 14:44:16.819110
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.pickle")



# Generated at 2022-06-25 14:44:20.147156
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    with tempfile.NamedTemporaryFile(delete=False) as f:
        grammar.dump(f.name)


# Generated at 2022-06-25 14:44:22.962989
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("{}.py".format(__file__))

    grammar_0 = Grammar()
    grammar_0.load("{}.py".format(__file__))


# Generated at 2022-06-25 14:44:23.791947
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    Grammar()



# Generated at 2022-06-25 14:44:26.621537
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    # test if file exists
    filename = "random.pkl"
    grammar_0.load(filename)


# Generated at 2022-06-25 14:44:34.422814
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.dump("/tmp/temp_store")
    grammar_1 = Grammar()
    grammar_1.load("/tmp/temp_store")
    dict_attr_0 = "symbol2number"
    dict_attr_1 = "number2symbol"
    dict_attr_2 = "dfas"
    dict_attr_3 = "keywords"
    dict_attr_4 = "tokens"
    dict_attr_5 = "symbol2label"
    grammar_1.labels = grammar_0.labels[:]
    grammar_1.states = grammar_0.states[:]
    grammar_1.start = grammar_0.start
    grammar_1.async_keywords = grammar_0.async_keywords

# Generated at 2022-06-25 14:44:38.402268
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load('PgenGrammar.pkl')
    print(grammar)
    print(grammar.dfas)
    print(grammar.keywords)
    print(grammar.labels)
    print(grammar.number2symbol)
    print(grammar.states)
    print(grammar.symbol2label)
    print(grammar.symbol2number)
    print(grammar.tokens)
    print(grammar.start)


# Generated at 2022-06-25 14:44:39.351977
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_load = Grammar()
    grammar_load.load("/")


# Generated at 2022-06-25 14:44:42.670832
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    try:
        grammar.load("/tmp/grammar_pkl_example")
    except Exception as e:
        raise Exception("Failed to execute load for Grammar: %s" % repr(e))


# Generated at 2022-06-25 14:44:44.826220
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load('grammar.pickle')


# Generated at 2022-06-25 14:45:00.733162
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Declarations
    _Grammar_dump_grammar_0 = Grammar()
    # Setup
    # Testing
    with tempfile.NamedTemporaryFile(delete=False) as _Grammar_dump_f:
        _Grammar_dump_grammar_0.dump(_Grammar_dump_f.name)
    os.remove(_Grammar_dump_f.name)



# Generated at 2022-06-25 14:45:02.044128
# Unit test for method load of class Grammar
def test_Grammar_load():
    gr = Grammar()
    gr.load("./grammar_grammar")



# Generated at 2022-06-25 14:45:11.096101
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load(
        "/usr/local/lib/python/site-packages/black/py36/python.pkl"
    )
    grammar_2 = Grammar()
    grammar_2.load(
        "/usr/local/lib/python/site-packages/black/py36/python.pkl"
    )
    grammar_3 = Grammar()
    grammar_3.load(
        "/usr/local/lib/python/site-packages/black/py36/python.pkl"
    )
    grammar_4 = Grammar()
    grammar_4.load(
        "/usr/local/lib/python/site-packages/black/py36/python.pkl"
    )
    grammar_5 = Grammar()

# Generated at 2022-06-25 14:45:13.239831
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load('./lib2to3/grammar.py.pickle')



# Generated at 2022-06-25 14:45:14.723590
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('python/graminit.py')

# Generated at 2022-06-25 14:45:22.131144
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.tokens[token.NAME] = grammar_1.labels.index((token.NAME, None))
    grammar_1.symbol2label["string"] = grammar_1.labels.index((256, "string"))
    grammar_1.labels.append((256, "string"))
    grammar_1.symbol2number["string"] = 256
    grammar_1.number2symbol[256] = "string"

# Generated at 2022-06-25 14:45:24.093676
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """Test method Grammar.dump."""
    grammar = Grammar()
    grammar.dump('grammar.pickle')


# Generated at 2022-06-25 14:45:25.027250
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load(tempfile.mktemp())



# Generated at 2022-06-25 14:45:33.395458
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_1 = Grammar()
    grammar_0.symbol2number = {}
    grammar_0.number2symbol = {}
    grammar_0.states = []
    grammar_0.dfas = {}
    grammar_0.labels = [(0, "EMPTY")]
    grammar_0.keywords = {}
    grammar_0.tokens = {}
    grammar_0.symbol2label = {}
    grammar_0.start = 256
    # Python 3.7+ parses async as a keyword, not an identifier
    grammar_0.async_keywords = False
    grammar_1.symbol2number = {}
    grammar_1.number2symbol = {}
    grammar_1.states = []
    grammar_1.dfas = {}

# Generated at 2022-06-25 14:45:36.206068
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    with tempfile.NamedTemporaryFile() as f:
        grammar_0 = Grammar()
        grammar_0.dump(f.name)


# Generated at 2022-06-25 14:45:51.663239
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load(os.path.normcase(os.path.abspath(os.getcwd() + "/Grammar.pickle")))


# Generated at 2022-06-25 14:45:55.587932
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    filename = "test_00_dump.txt"
    grammar_0.dump(filename)

    grammar_0 = Grammar()
    filename = "test_01_dump.txt"
    grammar_0.dump(filename)


# Generated at 2022-06-25 14:45:57.383304
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('test/test_case_1.pickle')


# Generated at 2022-06-25 14:46:03.965633
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Create a grammar object
    grammar = Grammar()
    grammar.start = 0
    # Pickle the object to the file
    filename = 'test_grammar.pickle'
    grammar.dump(filename)
    # Read the object from the pickle file
    grammar = Grammar()
    grammar.load(filename)
    # Check the object is correct
    assert grammar.start == 0
    # Delete the object
    os.unlink(filename)

# Generated at 2022-06-25 14:46:07.324808
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('grammar.pkl')
    grammar_1 = Grammar()
    grammar_1.load('grammar.pkl')
    assert grammar_0 == grammar_1


# Generated at 2022-06-25 14:46:10.413308
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('/tmp/grammar_dump_test0.txt')


# Generated at 2022-06-25 14:46:12.857689
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump(filename=('/' +
        'af2f005944b9d3fe3a07f9864b7d7d82'))


# Generated at 2022-06-25 14:46:15.821385
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('/dev/null')
    grammar_0.load('/dev/null')


# Generated at 2022-06-25 14:46:19.539885
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load(b"/Users/yunfeiluo/Programming/typescript-parser/python/grammar/Grammar.txt")
    assert grammar_1.start == 256
    assert grammar_1.tokens == {}



# Generated at 2022-06-25 14:46:22.724001
# Unit test for method load of class Grammar
def test_Grammar_load():
    expected = ["dfas", "labels", "number2symbol", "start", "states", "symbol2label", "symbol2number", "tokens"]
    grammar = Grammar()
    grammar.load('<path>')
    actual = [i for i in grammar.__dict__ if i[0] != '_']
    assert expected == actual
