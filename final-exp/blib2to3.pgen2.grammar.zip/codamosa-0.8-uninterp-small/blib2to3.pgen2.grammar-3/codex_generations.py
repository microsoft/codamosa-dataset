

# Generated at 2022-06-25 14:36:46.751934
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = "./data/Grammar.pkl"
    grammar = Grammar()
    grammar.load(filename)



# Generated at 2022-06-25 14:36:49.556866
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    with tempfile.TemporaryDirectory() as tempdir:
        filename = os.path.join(tempdir, "symbols.pkl")
        grammar.dump(filename)



# Generated at 2022-06-25 14:36:51.793768
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    with tempfile.NamedTemporaryFile(suffix=".pickle") as f:
        grammar_0.dump(f.name)


# Generated at 2022-06-25 14:36:57.566611
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    from .graminit import grammar_0
    from .grammar import load_grammar

    if os.path.exists(grammar_0):
        os.unlink(grammar_0)
    try:
        g = load_grammar(grammar_0)
    except OSError:
        raise unittest.SkipTest
    else:
        g.dump(grammar_0)



# Generated at 2022-06-25 14:37:06.260844
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()

# Generated at 2022-06-25 14:37:10.863809
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    dump_0 = Grammar()
    temp_file_0 = tempfile.NamedTemporaryFile(delete=False)
    # Note, this is not a valid pickle file, but we just need a filename.
    dump_0.dump(temp_file_0.name)
    temp_file_0.close()
    os.unlink(temp_file_0.name)



# Generated at 2022-06-25 14:37:12.892751
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    file_path = './test_file.pkl'
    grammar_0.dump(file_path)
    grammar_1 = Grammar()
    grammar_1.load(file_path)


# Generated at 2022-06-25 14:37:16.922213
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('/home/benjamin/pytype-master/pytype/tests/data/Grammar_0.pkl')


# Generated at 2022-06-25 14:37:18.955258
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    Grammar.load(grammar, "test_data/Grammar_0.data")


# Generated at 2022-06-25 14:37:19.809620
# Unit test for method load of class Grammar
def test_Grammar_load():
    pass


# Generated at 2022-06-25 14:37:25.797105
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump("grammar.pickle")


# Generated at 2022-06-25 14:37:27.076387
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("Grammar.pickle")


# Generated at 2022-06-25 14:37:28.278661
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """
    grammar.dump(filename)
    """
    test_case_0()


# Generated at 2022-06-25 14:37:31.164832
# Unit test for method load of class Grammar
def test_Grammar_load():
    pass



# Generated at 2022-06-25 14:37:33.366036
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()

    # Call method load.  Expected no exception
    test_cases = [r"test/test_grammar_load/test_grammar_0.py"]
    for test_filename in test_cases:
        grammar_0.load(test_filename)


# Generated at 2022-06-25 14:37:36.986856
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    grammar = Grammar()

    with tempfile.TemporaryFile('w+b') as f:
        grammar.dump(f)
        f.seek(0)
        grammar2 = Grammar()
        grammar2.load(f)
        assert grammar == grammar2


# Generated at 2022-06-25 14:37:38.336174
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_1 = Grammar()
    grammar_0.load(grammar_1)


# Generated at 2022-06-25 14:37:47.405914
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    tmpdir = tempfile.gettempdir()
    import os
    import sys
    filename = os.path.join(tmpdir, "grammar_dump.pkl")
    if sys.version_info[0] >= 3:
        # Python 3.x
        with open(filename, "wb") as f:
            grammar_0 = Grammar()
            grammar_0.dump(f)
    else:
        # Python 2.x
        with open(filename, "wb") as f:
            grammar_0 = Grammar()
            grammar_0.dump(f)
    if os.path.exists(filename):
        os.remove(filename)


# Generated at 2022-06-25 14:37:48.786725
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("f")



# Generated at 2022-06-25 14:37:51.711964
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_dump = Grammar()
    grammar_dump.dump('pgen')


# Generated at 2022-06-25 14:37:58.356801
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    filename_0 = "tmp/grammar.pickle"
    grammar_0.dump(filename_0)


# Generated at 2022-06-25 14:38:01.823309
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar1 = Grammar()
    grammar1.dump("grammar1.dump")
    grammar2 = Grammar()
    grammar2.loads(open("grammar1.dump", 'rb').read())

    assert grammar1.__dict__ == grammar2.__dict__


# Generated at 2022-06-25 14:38:09.172498
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load('test/data/test_grammar.pkl')
    grammar_2 = grammar_1.copy()
    assert grammar_1.symbol2number == grammar_2.symbol2number
    assert grammar_1.number2symbol == grammar_2.number2symbol
    assert grammar_1.states == grammar_2.states
    assert grammar_1.dfas == grammar_2.dfas
    assert grammar_1.labels == grammar_2.labels
    assert grammar_1.keywords == grammar_2.keywords
    assert grammar_1.tokens == grammar_2.tokens
    assert grammar_1.symbol2label == grammar_2.symbol2label
    assert grammar_1.start == grammar_2.start
    assert grammar_

# Generated at 2022-06-25 14:38:20.737685
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from collections import OrderedDict
    d = OrderedDict()
    d['a'] = 1
    d['b'] = 2
    d['c'] = 3
    g = Grammar()
    g.symbol2number = d
    g.dfas = d
    g.keywords = d
    g.tokens = d
    g.symbol2label = d

# Generated at 2022-06-25 14:38:26.954510
# Unit test for method load of class Grammar
def test_Grammar_load():
    known_path = "lib2to3/Grammar.pickle"
    grammar = Grammar()
    grammar.load(known_path)

    assert grammar.symbol2number["single_input"] == 258
    assert grammar.number2symbol[258] == "single_input"
    assert grammar.number2symbol[259] == "file_input"
    assert grammar.number2symbol[2] == "and_test"


# Generated at 2022-06-25 14:38:28.435993
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_3 = Grammar()
    grammar_3.dump(filename='grammar3.pkl')


# Generated at 2022-06-25 14:38:30.432230
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("grammar_db")

# Generated at 2022-06-25 14:38:31.644366
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump()


# Generated at 2022-06-25 14:38:33.899137
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0=Grammar()
    assert grammar_0.load('./Grammar.pickle.rule') == None

# Generated at 2022-06-25 14:38:38.751244
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    print("Creating Grammar object")
    grammar_1 = Grammar()
    print("Calling Grammar.dump with parameters:")
    print("./conv/Grammar_dump.pkl")
    grammar_1.dump("./conv/Grammar_dump.pkl")


# Generated at 2022-06-25 14:38:45.504895
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    filename = "Grammar.dump"
    try:
        grammar_0.dump(filename)
    except IOError as e:
        print("Caught I/O Error:", e)
    finally:
        # Clean up
        try:
            os.remove(filename)
        except OSError as e:
            print("I/O Error:", e)


# Generated at 2022-06-25 14:38:46.665303
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    return


# Generated at 2022-06-25 14:38:49.138581
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('/tmp/grammar_dump.p')



# Generated at 2022-06-25 14:38:52.433100
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    fd = tempfile.NamedTemporaryFile(delete=False)
    try:
        grammar_1.dump(fd.name)
    finally:
        fd.close()
        os.remove(fd.name)



# Generated at 2022-06-25 14:38:59.444813
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.copy()
    grammar_0.dump("testGrammar.out")
    grammar_0.load("testGrammar.out")

# Generated at 2022-06-25 14:39:01.271829
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load("./parser/Grammar.pickle")
    grammar_1 = grammar_1.copy()


# Generated at 2022-06-25 14:39:04.631280
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_1 = Grammar()
    grammar_0.load('hq3/data/grammar.dll/hq3.data.grammar.Grammar')
    grammar_1.load('hq3/data/grammar.dll/hq3.data.grammar.Grammar')
    assert grammar_0 is not grammar_1


# Generated at 2022-06-25 14:39:05.494369
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    pass


# Generated at 2022-06-25 14:39:06.906152
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(os.path.join(os.path.dirname(__file__), "Grammar.pickle"))

# Generated at 2022-06-25 14:39:11.728788
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(__file__.replace(".py", ".dump"))
    assert (
        list(grammar.symbol2number.items())[:10][-1]
        == ('decorator_3', 311)
    )
    assert (
        list(grammar.number2symbol.items())[:10][-1]
        == (38, 'with_item')
    )

# Generated at 2022-06-25 14:39:16.699011
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("test.grammar")


# Generated at 2022-06-25 14:39:17.805136
# Unit test for method load of class Grammar
def test_Grammar_load():
    test_case_0()


# Generated at 2022-06-25 14:39:21.581450
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    file_name = "/tmp/tokenizer-dump-test.pkl"
    grammar_1.dump(file_name)
    grammar_1.start = 257
    grammar_1.dump(file_name)


# Generated at 2022-06-25 14:39:23.541248
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump(os.path.join(tempfile.gettempdir(), 'temp_file_0.pkl'))


# Generated at 2022-06-25 14:39:26.449705
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    filename = test_pickle_dump(grammar)
    grammar2 = Grammar()
    grammar2.load(filename)
    assert grammar == grammar2


# Generated at 2022-06-25 14:39:36.256885
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    assert "symbol2number" not in grammar.__dict__
    assert "number2symbol" not in grammar.__dict__
    assert "states" not in grammar.__dict__
    assert "dfas" not in grammar.__dict__
    assert "labels" not in grammar.__dict__
    assert "keywords" not in grammar.__dict__
    assert "tokens" not in grammar.__dict__
    assert "symbol2label" not in grammar.__dict__
    assert "start" not in grammar.__dict__
    assert "async_keywords" not in grammar.__dict__
    grammar_load_0 = Grammar()
    grammar_load_0.load("var")
    assert "symbol2number" in grammar_load_0.__dict__

# Generated at 2022-06-25 14:39:43.790323
# Unit test for method load of class Grammar
def test_Grammar_load():
    global grammar_0

    gr = Grammar()
    gr.load("grammar.pkl")

    # XXX do some better checking here?
    # assert gr.symbol2number == grammar_0.symbol2number
    # assert gr.number2symbol == grammar_0.number2symbol
    # assert gr.states == grammar_0.states
    # assert gr.dfas == grammar_0.dfas
    # assert gr.labels == grammar_0.labels
    # assert gr.keywords == grammar_0.keywords
    # assert gr.tokens == grammar_0.tokens
    # assert gr.symbol2label == grammar_0.symbol2label
    # assert gr.start == grammar_0.start


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 14:39:47.706523
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("pgen_test_dump.py")


if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-25 14:39:50.822209
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("./test/test_data/py15_grammar_dump.pickle")


# Generated at 2022-06-25 14:39:58.292567
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("./Grammar/testdata/Grammar_0007_data.pkl")
    grammar_0.load("./Grammar/testdata/Grammar_0005_data.pkl")
    grammar_0.load("./Grammar/testdata/Grammar_0006_data.pkl")
    grammar_0.load("./Grammar/testdata/Grammar_0004_data.pkl")
    grammar_0.load("./Grammar/testdata/Grammar_0002_data.pkl")
    grammar_0.load("./Grammar/testdata/Grammar_0000_data.pkl")

# Generated at 2022-06-25 14:40:10.329649
# Unit test for method dump of class Grammar
def test_Grammar_dump():    
    grammar_0 = Grammar()
    grammar_0.symbol2label = {'parameter_name' : 2}
    grammar_0.tokens = {1 : 2}
    grammar_0.start = 256
    grammar_0.labels = [('EMPTY', 0), ('value', 'keyword'), ('name', 'keyword')]
    grammar_0.states = [[(2, 0), (3, 0), (4, 1)], [(4, 1), (0, 1)]]
    grammar_0.keywords = {'value' : 'keyword', 'name' : 'keyword'}
    grammar_0.dfas = {258 : ([[(2, 0), (3, 0), (4, 1)], [(4, 1), (0, 1)]], {'keyword' : 1})}


# Generated at 2022-06-25 14:40:11.735483
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("test_Grammar.txt")


# Generated at 2022-06-25 14:40:14.232205
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_dump = Grammar()
    grammar_dump.dump('test_file')


# Generated at 2022-06-25 14:40:16.996732
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('/home/benjamin/PycharmProjects/pysonar2/pysonar2/pysonar/grammar_pickle_new')



# Generated at 2022-06-25 14:40:20.014536
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('.test_0.test_Grammar_dump.test_gen.pickle')


# Generated at 2022-06-25 14:40:26.443374
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Test method load of class Grammar."""

    # Revision ID: 4f5fd3c3c9fd
    # Repository: pypy/trunk
    # Date: 2012-02-27 13:41:49 +0200 (Mon, 27 Feb 2012)
    #
    # Branch: py3.5
    # Changes by: arigo
    #
    # Files affected:
    #   Lib/lib2to3/pygram.pickle
    #
    # Files affected (by file):
    #   Lib/lib2to3/pygram.pickle:
    #     4f5fd3c3c9fd
    #
    # Description:
    #   Add PY3.5 grammar
    #
    # Summary (architecture):
    #   x86

    grammar_0 = Grammar()
   

# Generated at 2022-06-25 14:40:30.679690
# Unit test for method load of class Grammar
def test_Grammar_load():
    f = tempfile.NamedTemporaryFile(delete=False)
    g = Grammar()
    g.dump(f)
    f.close()
    g1 = Grammar()
    g1.load(f)


# Generated at 2022-06-25 14:40:33.090274
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    assert grammar_1.dump("/tmp/grammar_1.pkl") is None



# Generated at 2022-06-25 14:40:34.187043
# Unit test for method load of class Grammar
def test_Grammar_load():
    # No test coverage yet
    assert False

# Generated at 2022-06-25 14:40:35.682476
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump(filename="test.pkl")

# Generated at 2022-06-25 14:40:41.131133
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    try:
        grammar_0.dump(('/', 'data', 'python', 'test', 'parser', 'Python-2.7.12', 'Grammar.dump'))
    except (AttributeError, BaseException):
        traceback.print_exc()


# Generated at 2022-06-25 14:40:42.375013
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load("./Grammar.pickle")

# Generated at 2022-06-25 14:40:45.612549
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    filename_0 = "python-3.6.2/Lib/asyncio/coroutines.py"
    grammar_0.load(filename_0)


# Generated at 2022-06-25 14:40:53.587062
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()

# Generated at 2022-06-25 14:40:55.161249
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("grammar_0.pkl")


# Generated at 2022-06-25 14:40:56.663410
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump(filename="test_Grammar.pkl")


# Generated at 2022-06-25 14:40:59.981603
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load("/home/sireesh/Documents/QDaS_GIT_Repo/QDAS/test/test_grammar.txt")


# Generated at 2022-06-25 14:41:11.266629
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.labels = [
        (0, "EMPTY"),
        (2, None),
    ]
    grammar_1.symbol2number = {
        "NAME": 257,
        "ENDMARKER": 258,
    }
    grammar_1.number2symbol = {
        257: "NAME",
        258: "ENDMARKER",
    }
    grammar_1.tokens = {
        1: 2,
        2: 3,
    }
    grammar_1.start = 256

# Generated at 2022-06-25 14:41:16.450986
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import driver

    grammar = driver.load_grammar("/usr/local/lib/python3.6/lib2to3/Grammar.txt")
    # grammar.report()


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-25 14:41:18.768080
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump(str(123))




# Generated at 2022-06-25 14:41:28.476937
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    # ./pgen/grammar.pickle is a pickle of Grammar so we use it as a
    # test file.
    grammar.load("./pgen/grammar.pickle")
    grammar.dump("./pgen/grammar.pickle")

# Generated at 2022-06-25 14:41:31.172151
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()

    fn = os.path.join(os.path.dirname(__file__), "Grammar.pickle")
    grammar_0.load(fn)


# Generated at 2022-06-25 14:41:33.719807
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_load = Grammar()
    grammar_load.load('data.pkl')
    assert type(grammar_load.number2symbol) == dict


# Generated at 2022-06-25 14:41:35.545042
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump('/tmp/_grammar_dump.py')


# Generated at 2022-06-25 14:41:39.918144
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.a = 1
    grammar.b = "2"
    grammar.c = (3, 4)
    grammar.d = {5: 6, 7: 8}
    grammar.dump('test.pickle')
    grammar_1 = Grammar()
    grammar_1.load('test.pickle')
    assert grammar == grammar_1



# Generated at 2022-06-25 14:41:42.640482
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import tokenize

    grammar_0 = Grammar()
    grammar_0.load(tokenize)


# Generated at 2022-06-25 14:41:45.216540
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("/home/benp/proj/typed-ast/lib2to3/Grammar.txt")


# Generated at 2022-06-25 14:41:48.716369
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    try:
        grammar = Grammar()
        grammar.dump("/tmp/test_Grammar.dump")
    except OSError as e:
        assert isinstance(e, OSError)


# Generated at 2022-06-25 14:41:52.176457
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys

    try:
        grammar_0 = Grammar()
        grammar_1 = Grammar()
        grammar_0.load(sys.executable)
        grammar_1.load(sys.executable)
    except IOError:
        assert False, 'Grammar.load raised IOError unexpectedly'


# Generated at 2022-06-25 14:41:58.440730
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # create grammar
    grammar_dump = Grammar()

    # initialize instance variables
    grammar_dump.symbol2number = {'x': 100, 'y': 101}
    grammar_dump.number2symbol = {100: 'x', 101: 'y'}
    grammar_dump.states = [
        None,
        [
            [(0, 2)],
            [(100, 2), (101, 3)]
        ],
        [ [(257, 0)] ],
        [ [(257, 0)] ]
    ]
    grammar_dump.dfas = {100: ([[(0, 2)]], {0: 1}), 101: ([[(0, 3)]], {0: 1})}

# Generated at 2022-06-25 14:42:02.863053
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump()

# Generated at 2022-06-25 14:42:04.202382
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump('test.pkl')


# Generated at 2022-06-25 14:42:09.286312
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    with tempfile.NamedTemporaryFile() as f:
        filename = f.name
        grammar_0 = Grammar()
        grammar_1 = Grammar()
        grammar_1.load(filename)
        grammar_2 = Grammar()
        grammar_2.loads(b"")


# Generated at 2022-06-25 14:42:10.538958
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('Grammar_0.pickle')


# Generated at 2022-06-25 14:42:13.436077
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump('grammar.pkl')
    grammar.load('grammar.pkl')


# Generated at 2022-06-25 14:42:14.904637
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("grammar.pkl")


# Generated at 2022-06-25 14:42:18.197542
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    obj_0 = Grammar()
    grammar_0 = obj_0
    path_0 = ""
    grammar_0.dump(path_0)


# Generated at 2022-06-25 14:42:20.049086
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('test.pickle')


# Generated at 2022-06-25 14:42:22.712914
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load("C:/Python36/lib/tel_grammar_pickle.p")

# Generated at 2022-06-25 14:42:24.997825
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), 'Grammar.pkl'))



# Generated at 2022-06-25 14:42:28.968641
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load(r"C:\temp\parse1.out")


# Generated at 2022-06-25 14:42:30.879014
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Test load"""
    grammar_0 = Grammar()

    # case 0
    grammar_0.copy()


# Generated at 2022-06-25 14:42:33.966605
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    test_filename = tempfile.gettempdir()
    grammar.dump(test_filename)

# Generated at 2022-06-25 14:42:36.518865
# Unit test for method load of class Grammar
def test_Grammar_load():
    print('Testing method load of class Grammar')
    grammar_0 = Grammar()
    grammar_0.load('../data/Grammar.pickle')


# Generated at 2022-06-25 14:42:38.789978
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    filename_0: Path = "test_case_0.pkl"
    grammar_0.dump(filename_0)


# Generated at 2022-06-25 14:42:40.655438
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()

    # This should not throw any exceptions
    grammar_0.dump('./pytest.txt')


# Generated at 2022-06-25 14:42:42.378082
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()

    # test not implemented


# Generated at 2022-06-25 14:42:52.922435
# Unit test for method load of class Grammar
def test_Grammar_load():
    fname = os.path.join(tempfile.gettempdir(), "Grammar.pickle")
    if os.path.exists(fname):
        os.unlink(fname)
    grammar = Grammar()
    grammar.dump(fname)
    grammar.load(fname)
    assert isinstance(grammar.symbol2number, dict)
    assert isinstance(grammar.number2symbol, dict)
    assert isinstance(grammar.states, list)
    assert len(grammar.states) == 1
    assert isinstance(grammar.states[0], list)
    assert len(grammar.states[0]) == 1
    assert isinstance(grammar.dfas, dict)
    assert isinstance(grammar.labels, list)

# Generated at 2022-06-25 14:42:58.198887
# Unit test for method load of class Grammar
def test_Grammar_load():
    # pgen = os.path.join(sysconfig.get_path('data'), 'Grammar.pickle')
    pgen = "Grammar.pickle"
    g = Grammar()
    g.load(pgen)
    g.report()
    g.dump("Grammar.py")


if __name__ == "__main__":
    import sys
    import types
    import unittest

    from . import conv

    # pgen = os.path.join(sysconfig.get_path('data'), 'Grammar.pickle')
    pgen = "Grammar.pickle"

    # p = pgen/'Grammar.pickle'
    # print(p)
    # g = Grammar()
    # g.load(p)
    # g.report()

    #

# Generated at 2022-06-25 14:42:59.406083
# Unit test for method load of class Grammar
def test_Grammar_load():
    assert Grammar().load('') == None


# Generated at 2022-06-25 14:43:12.453990
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.start = 256
    grammar.symbol2label = {'trailer': 1, 'arglist': 0, 'arg': 2}
    grammar.symbol2number = {'SUBSCRIPTLIST': 258, 'SUBSCRIPT': 259}
    grammar.dfas = {258: (
        [[(1, 5), (1, 1), (1, 2), (1, 3), (1, 4)], [(2, 6), (2, 0)], [(2, 6), (1, 0)]],
        {0: 2, 258: 0, 259: 1})}
    grammar.number2symbol = {258: 'SUBSCRIPTLIST', 259: 'SUBSCRIPT'}
    grammar.tokens = {460: 9}
    grammar.keywords = {'for': 38}

# Generated at 2022-06-25 14:43:14.555933
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("./Grammar/pgen/../src/Grammar/Python.pkl")


# Generated at 2022-06-25 14:43:16.125105
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump(b'`')


# Generated at 2022-06-25 14:43:19.745956
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('/tmp/grammar')

if __name__ == "__main__":
    test_case_0()
    test_Grammar_load()

# Generated at 2022-06-25 14:43:24.157679
# Unit test for method load of class Grammar
def test_Grammar_load():
    # test correctness
    grammar_1 = Grammar()
    grammar_1.load("string.pgen2")
    grammar_1.load("initgrammar.pgen2")


# Generated at 2022-06-25 14:43:26.522393
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    path_1 = tempfile.NamedTemporaryFile()
    grammar_1.dump(path_1.name)



# Generated at 2022-06-25 14:43:30.002571
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump(Path("grammar.pickle"))


# Generated at 2022-06-25 14:43:38.899333
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2.parse import Driver

    driver = Driver()
    # process the grammar to get an instance of Grammar and a set of
    # tokens
    grammar, first = driver.parse_grammar("Grammar/Grammar")
    try:
        grammar_dump = tempfile.mktemp()
        # save the instance of Grammar to grammar_dump
        grammar.dump(grammar_dump)
        # create a new instance of Grammar
        grammar_0 = Grammar()
        # load the saved instance of Grammar
        grammar_0.load(grammar_dump)
        assert grammar_0 is not None
    finally:
        # remove the temporary file
        os.remove(grammar_dump)


if __name__ == "__main__":
    test_case_0()
    test_Grammar_

# Generated at 2022-06-25 14:43:41.249502
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("samples/sample_grammar.pkl")
    grammar_0.report()


# Generated at 2022-06-25 14:43:43.468193
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("/tmp/t.pkl")

# Generated at 2022-06-25 14:43:47.081916
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("/some/file.pickle")



# Generated at 2022-06-25 14:43:52.667516
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import os
    from os.path import isfile
    from .conv import pgen

    # Check normal case
    # Create pgen-parsed grammar
    grammar = pgen.parse_grammar()

    # Dump data to a temp file
    tmp_fd, tmp_file = tempfile.mkstemp()
    grammar.dump(tmp_file)

    # Create a new Grammar object and load data from dumped file
    grammar_test = Grammar()
    grammar_test.load(tmp_file)

    # Check that data is equal
    assert grammar_test.symbol2number == grammar.symbol2number
    assert grammar_test.number2symbol == grammar.number2symbol
    assert grammar_test.states == grammar.states
    assert grammar_test.dfas == grammar.dfas

# Generated at 2022-06-25 14:43:56.777086
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    fd, fn = tempfile.mkstemp()
    with os.fdopen(fd, "w") as f:
        grammar_0.dump(f)


# Generated at 2022-06-25 14:44:05.994319
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    symbol2number = {}
    number2symbol = {}
    states = []
    dfas = {}
    labels = [(0, "EMPTY")]
    keywords = {}
    tokens = {}
    symbol2label = {}
    start = 256
    async_keywords = False
    grammar_0 = Grammar(symbol2number, number2symbol, states, dfas, labels, keywords, tokens, symbol2label, start, async_keywords)
    assert grammar_0.symbol2number == symbol2number
    assert grammar_0.number2symbol == number2symbol
    assert grammar_0.states == states
    assert grammar_0.dfas == dfas
    assert grammar_0.labels == labels
    assert grammar_0.keywords == keywords
    assert grammar_0.tokens == tokens
    assert grammar

# Generated at 2022-06-25 14:44:09.911006
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    with tempfile.NamedTemporaryFile(delete=False) as f:
        grammar.dump(f.name) # Saves pickle file
    grammar.load(f.name)

# Generated at 2022-06-25 14:44:17.602205
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io
    grammar_1 = Grammar()
    # test case: load the grammar tables from a pickle file.
    with open("grammar.pkl", "rb") as f:
        expected_result = pickle.load(f)
    grammar_1.load("grammar.pkl")
    assert grammar_1.__eq__(expected_result)
    # test case: load the grammar tables from a pickle bytes object.
    with open("grammar.pkl", "rb") as f:
        pkl = pickle.load(f)
    grammar_2 = Grammar()
    grammar_2.loads(pkl)
    assert grammar_2.__eq__(expected_result)
    # test case: test if your version of the grammar dump is compatible with
    #

# Generated at 2022-06-25 14:44:21.566340
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("../test_data/test_dump")
    grammar_1 = Grammar()
    grammar_1.load("../test_data/test_dump")


# Generated at 2022-06-25 14:44:31.079870
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # initializing Grammar
    grammar = Grammar()
    # initializing DFA
    DFA = [[(257, 1)]]
    # initializing states
    states = [DFA]
    # initializing DFAS
    DFAS = (DFA, {0: 1})
    # initializing labels
    labels = [(0, "EMPTY"), (257, "name")]
    # initializing keywords
    keywords = {"name": 257}
    # initializing tokens
    tokens = {257: 257}
    # initializing symbol2number
    symbol2number = {"name": 257}
    # initializing number2symbol
    number2symbol = {257: "name"}
    # initializing dfas
    dfas = {257: DFAS}
    # initializing symbol2label
    symbol2label = {"name": 257}

# Generated at 2022-06-25 14:44:32.452013
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump()
#print(grammar_0)

# Generated at 2022-06-25 14:44:35.034374
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Test dump method with a non-existent file
    Grammar().dump(Path("-nonexistent-"))



# Generated at 2022-06-25 14:44:40.150850
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Grammar.load"""

    grammar_0 = Grammar()
    grammar_0.load("Grammar.pickle")



# Generated at 2022-06-25 14:44:43.981975
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # You can't really unit test this one, you have to look at the result by hand.
    # Put up a test file and compare it to another file generated with the C code.
    return



# Generated at 2022-06-25 14:44:44.865905
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    test_case_0()


# Generated at 2022-06-25 14:44:46.269173
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump('pickle1')


# Generated at 2022-06-25 14:44:55.747381
# Unit test for method load of class Grammar
def test_Grammar_load():
    import io
    import unittest


    class Grammar_load_TestCase(unittest.TestCase):
        def test_normal_0(self):
            grammar = Grammar()

# Generated at 2022-06-25 14:45:01.066101
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar1 = Grammar()
    grammar.load('Grammar.pickle')
    grammar1._update(pickle.load(open('Grammar.pickle', 'rb')))
    assert grammar.number2symbol == grammar1.number2symbol
    assert grammar.states == grammar1.states
    assert grammar.labels == grammar1.labels
    assert grammar.start == grammar1.start


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-25 14:45:01.859491
# Unit test for method load of class Grammar
def test_Grammar_load():
    test_case_0()



# Generated at 2022-06-25 14:45:07.894565
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    print("")
    print("Dump and load the grammar")
    grammar_1 = Grammar()
    grammar_1.dump("Grammar.pkl")
    grammar_2 = Grammar()
    grammar_2.load("Grammar.pkl")
    assert not grammar_1.symbol2number
    assert not grammar_1.number2symbol
    assert not grammar_1.states
    assert not grammar_1.dfas
    assert grammar_1.labels == [(0, "EMPTY")]
    assert not grammar_1.keywords
    assert not grammar_1.tokens
    assert not grammar_1.symbol2label
    assert grammar_1.start == 256
    assert grammar_1.async_keywords == False


# Generated at 2022-06-25 14:45:16.987223
# Unit test for method load of class Grammar
def test_Grammar_load():
    from typing import Any
    from .test.test_support import findfile, run_unittest

    global grammar_0

    file_name = findfile("grammar_0.pkl")

    grammar_0.load(file_name)
    assert isinstance(grammar_0.symbol2number, dict)
    assert isinstance(grammar_0.number2symbol, dict)
    assert isinstance(grammar_0.states, list)
    assert isinstance(grammar_0.dfas, dict)
    assert isinstance(grammar_0.labels, list)
    assert isinstance(grammar_0.keywords, dict)
    assert isinstance(grammar_0.tokens, dict)

    # unit test for dump
    file_name = findfile("grammar_1.pkl")


# Generated at 2022-06-25 14:45:19.997705
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_2 = Grammar()
    # Make sure we're not hitting a cache
    grammar_2.dump(
        os.path.join(os.path.dirname(__file__), "Grammar.py.pickle")
    )



# Generated at 2022-06-25 14:45:27.450221
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("test_grammar_1.pkl")
    grammar_1 = Grammar()
    grammar_1.load("test_grammar_1.pkl")


# Generated at 2022-06-25 14:45:30.755757
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    pickle_path = os.path.join(os.path.dirname(__file__), '../pickle.pk')
    grammar.load(pickle_path)
    assert isinstance(grammar.states, list)
    assert isinstance(grammar.symbol2number, dict)

# Generated at 2022-06-25 14:45:39.306604
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load('Grammar.txt')
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, 'EMPTY')]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords == False


# Generated at 2022-06-25 14:45:41.059713
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    filename = tempfile.NamedTemporaryFile().name
    grammar_0.dump(filename)


# Generated at 2022-06-25 14:45:42.377951
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("./parse.pkl")


# Generated at 2022-06-25 14:45:46.285787
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Build Grammar
    grammar_0 = Grammar()
    grammar_0.dump("frozen.grammar")
    # Invoke method
    grammar_0.load("frozen.grammar")



# Generated at 2022-06-25 14:45:50.636702
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump('test')
    grammar_2 = Grammar()
    try:
        grammar_2.load('test')
    except OSError:
        grammar_2.load('test-1')

# Generated at 2022-06-25 14:45:52.125363
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_6 = Grammar()
    grammar_6.load("./Lib/parser/parser-data/Grammar.pickle")


# Generated at 2022-06-25 14:46:00.062887
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(
        os.path.join(
            os.path.dirname(__file__), "..", "..", "Lib", "lib2to3", "Grammar.txt"
        )
    )
    assert grammar.symbol2number != {}
    assert grammar.number2symbol != {}
    assert grammar.states != []
    assert grammar.dfas != {}
    assert grammar.labels != []
    assert grammar.keywords != {}
    assert grammar.tokens != {}
    assert grammar.symbol2label != {}

# Generated at 2022-06-25 14:46:09.571797
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    from . import _ast_test_data
    from . import tokenize, convert
    grammar_0 = Grammar()

    # generate the grammar
    root = convert.convert_test_data('test_data.test_grammar')
    rname = os.path.splitext(os.path.basename(_ast_test_data.__file__))[0]
    print("root =", rname)

    if 0:
        # use this if the new grammar is to be used in Python
        grammar_0.symbol2number = {rname: 256}
        grammar_0.number2symbol = {256: rname}
        grammar_0.start = 256
    else:
        # use this if the new grammar is to be used in GrammarCase
        grammar_0.sy

# Generated at 2022-06-25 14:46:25.389317
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # The following test case is an example of a test case, which will create an array
    # and check if the values of the elements in the array is correct.
    grammar = Grammar()
    # The following test case is an example of a test case, which will test the
    # correctness of a method. The methods being tested are:
    # Grammar.dump
    # pickle.dump
    # tempfile.NamedTemporaryFile
    # os.replace
    with tempfile.NamedTemporaryFile(delete=False) as f:
        with open(f.name, 'wb') as g:
            pickle.dump(grammar, g)
        os.replace(f.name, "tmp_file")


# Generated at 2022-06-25 14:46:27.350142
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load("C:\\Python35\\lib\\lib2to3\\Grammar.pickle")


# Generated at 2022-06-25 14:46:35.772611
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('.\\parse_dump_temp.pkl')
    with open('.\\parse_dump_temp.pkl', 'rb') as f:
        d = pickle.load(f)
    assert d['keywords'] == {}, 'Expected keywords to be {}'
    assert d['labels'] == [(0, 'EMPTY')], 'Expected labels to be [(0, \'EMPTY\')]'
    assert d['number2symbol'] == {}, 'Expected number2symbol to be {}'
    assert d['states'] == [], 'Expected states to be []'
    assert d['start'] == 256, 'Expected start to be 256'
    assert d['symbol2label'] == {}, 'Expected symbol2label to be {}'

# Generated at 2022-06-25 14:46:43.196455
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    # Try to load a pickle file with a different Python version
    filename = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'Grammar.pickle')
    save_version = sys.version_info[:2]
    # This should not raise any exception
    try:
        grammar_0.load(filename)
    except Exception as e:
        raise AssertionError('Error: '.format(e))
    finally:
        # patch Python version back
        sys.version_info = save_version
