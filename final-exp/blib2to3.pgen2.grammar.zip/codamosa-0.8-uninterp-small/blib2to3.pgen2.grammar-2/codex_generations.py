

# Generated at 2022-06-25 14:36:57.478828
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import sys
    from .parse import create_pgen_source
    from .pgen2 import driver as pgen2_driver

    try:
        os.mkdir("tmp")
    except OSError:
        pass

    with open("tmp/tmp.txt", "w") as f:
        print("1", file=f)

    pgen_source = create_pgen_source("testdata/Grammar.grammar", "tmp/tmp.txt")

    with open("tmp/tmp2.txt", "w") as f:
        print("1", file=f)

    grammar_1 = Grammar()
    pgen2_driver.parse_grammar(pgen_source, grammar_1)

    grammar_1.dump("tmp/tmp3.txt")

    grammar_2 = Grammar()

# Generated at 2022-06-25 14:36:59.486536
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    print("Dump test: ")
    grammar_0.dump("")


# Generated at 2022-06-25 14:37:01.050626
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("test_Grammar.py")


# Generated at 2022-06-25 14:37:09.485980
# Unit test for method load of class Grammar
def test_Grammar_load():
  import sys
  import tempfile
  import os
  import pickle

  grammar = Grammar()

  r, fn = None, None

# Generated at 2022-06-25 14:37:16.359984
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    global grammar_0
    filename_0 = tempfile.NamedTemporaryFile().name
    grammar_0.dump(filename_0)
    grammar_1 = Grammar()
    filename_1 = tempfile.NamedTemporaryFile().name
    grammar_1.dump(filename_1)
    grammar_2 = Grammar()
    filename_2 = tempfile.NamedTemporaryFile().name
    grammar_2.dump(filename_2)
    grammar_3 = Grammar()
    filename_3 = tempfile.NamedTemporaryFile().name
    grammar_3.dump(filename_3)



# Generated at 2022-06-25 14:37:18.520142
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()

    grammar_0.load(get_path())



# Generated at 2022-06-25 14:37:27.173889
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    s = Grammar.__init__
    assert s is not None
    grammar_0 = Grammar()
    s = Grammar.dump
    assert s is not None
    filename_0 = "wnat6x"
    s(grammar_0, filename_0)
    grammar_1 = Grammar()
    s = Grammar.load
    assert s is not None
    filename_1 = "5if5fh"
    s(grammar_1, filename_1)
    grammar_2 = Grammar()
    s = Grammar.loads
    assert s is not None

# Generated at 2022-06-25 14:37:29.016164
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump(tempfile.mktemp())


# Generated at 2022-06-25 14:37:32.335520
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump('dump_0.pkl')


# Generated at 2022-06-25 14:37:36.120084
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Instantiate a Grammar object
    grammar_1 = Grammar()
    grammar_1.dump("grammar_1.pkl") # Write the pickle file to disk
    grammar_1.report() # Generate a grammar report containing raw grammar contents


# Generated at 2022-06-25 14:37:41.783611
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('/grm.pkl')


# Generated at 2022-06-25 14:37:42.672672
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()

    grammar_0.dump(filename = './data/Grammar.pkl')


# Generated at 2022-06-25 14:37:45.846997
# Unit test for method load of class Grammar
def test_Grammar_load():
    f = tempfile.NamedTemporaryFile()
    path = f.name
    g0 = Grammar()
    g0.dump(path)
    g1 = Grammar()
    g1.load(path)
    f.close()

# Generated at 2022-06-25 14:37:49.233270
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Create a pickle file to load
    f = tempfile.NamedTemporaryFile(delete=False)
    f.write(b'(dp0\n.')
    f.close()

    grammar_0 = Grammar()
    grammar_0.load(f.name)


# Generated at 2022-06-25 14:37:52.415115
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump("pytree.pgen.pickle.dump_test.test")



# Generated at 2022-06-25 14:37:53.831294
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('test_case_0')



# Generated at 2022-06-25 14:37:57.167667
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump(os.path.join(os.path.dirname(__file__), "Grammar.pickle"))


# Generated at 2022-06-25 14:38:01.704621
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    assert grammar.states == []
    assert grammar.dfas == {}
    assert grammar.labels == [(0, "EMPTY")]
    assert grammar.keywords == {}
    assert grammar.tokens == {}
    assert grammar.symbol2label == {}
    assert grammar.start == 256
    assert grammar.async_keywords == False

# Generated at 2022-06-25 14:38:02.901428
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump('/tmp/Grammar_dump.py')
    #self.assertTrue(open('/tmp/Grammar_dump.py','r') != None)


# Generated at 2022-06-25 14:38:06.489008
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os, os.path
    import tempfile
    grammar_0 = Grammar()
    temp_fd,temp_path = tempfile.mkstemp('py_parse')
    grammar_0.dump(temp_path)
    os.close(temp_fd)
    os.remove(temp_path)


# Generated at 2022-06-25 14:38:13.798530
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    try:
        temp_f = tempfile.NamedTemporaryFile(delete=False)
        temp_f.close()
        try:
            grammar_0.dump(temp_f.name)
        finally:
            os.unlink(temp_f.name)
    except Exception:
        pass


# Generated at 2022-06-25 14:38:20.192826
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    # Call test_case_0()
    test_case_0()

    # Call dump method of grammar_0
    dump_0 = grammar_0.dump("C:\\Users\\user\\Documents\\Python_Scripts\\mypy\\pgen2\\pgen2\\test.pickle")


# Generated at 2022-06-25 14:38:25.535290
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    from . import pgen2
    pgen2_1 = pgen2.pgen(grammar_1)
    pgen2_1.write_tables()
    grammar_2 = Grammar()
    grammar_2.loads(pgen2_1.pickle_grammar())


# Generated at 2022-06-25 14:38:28.658215
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Test case 0
    dump_0 = grammar_0.dump('/var/folders/j_/l_f_spbd7sxjyvxn92_zk_r9_2/T/tmpfjgwxczw')



# Generated at 2022-06-25 14:38:39.766770
# Unit test for method load of class Grammar

# Generated at 2022-06-25 14:38:41.933780
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load(str())
    grammar_0.loads(str())


# Generated at 2022-06-25 14:38:44.253426
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('grammar.pickle')
    grammar_1 = Grammar()
    grammar_1.load('grammar.pickle')
    os.remove('grammar.pickle')


# Generated at 2022-06-25 14:38:48.528860
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(os.path.join(os.path.dirname(__file__), "..", "pgen2", "Grammar.pkl"))


# Generated at 2022-06-25 14:38:51.606418
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    with open("grammar.pickle", "rb") as f:
        d = pickle.load(f)
    grammar_0._update(d)


# Generated at 2022-06-25 14:38:53.504117
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_d = Grammar()
    grammar_d.load('/tmp/grammar_dump')
    grammar_d.dump('/tmp/grammar_dump')


# Generated at 2022-06-25 14:39:04.075975
# Unit test for method load of class Grammar
def test_Grammar_load():
    import random
    import string
    random.seed(0)
    symbols_0 = [None] * random.randrange(1,10)
    for i in range(0, len(symbols_0)):
        symbols_0[i] = [None] * random.randrange(1,10)
        for j in range(0, len(symbols_0[i])):
            symbols_0[i][j] = ''.join(random.choice(string.digits) for k in range(random.randrange(1,10)))
    code_0 = []
    for i in range(0, len(symbols_0)):
        code_0.append(''.join(random.choice(string.digits) for k in range(random.randrange(1,10))))

    import pickle
    grammar

# Generated at 2022-06-25 14:39:04.929557
# Unit test for method load of class Grammar
def test_Grammar_load():
    assert False, 'test failed'


# Generated at 2022-06-25 14:39:08.744131
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('/tmp/grammar_0.pkl')
    grammar_1 = Grammar()
    grammar_1.async_keywords = False

# Generated at 2022-06-25 14:39:12.293251
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    temp_file = tempfile.NamedTemporaryFile()
    grammar_0.dump(os.path.basename(temp_file.name))
    temp_file.close()


# Generated at 2022-06-25 14:39:21.660188
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.start = 1
    grammar_1.async_keywords = False
    grammar_1.tokens[1] = 1
    grammar_1.number2symbol[1] = "A"
    grammar_1.keywords["a"] = 1
    grammar_1.labels[1] = (1, None)
    grammar_1.symbol2number["a"] = 1
    grammar_1.dfas[1] = ([[(1, 1)]], {1: 1})
    grammar_1.states = [[(1, 1)]]
    grammar_1.symbol2label["b"] = 1
    grammar_1.dump("test.pkl")
    grammar_2 = Grammar()
    grammar_2.load("test.pkl")
    grammar

# Generated at 2022-06-25 14:39:23.051588
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("test")


# Generated at 2022-06-25 14:39:24.529647
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    try:
        grammar.load('doesnt_exist.pkl')
    except FileNotFoundError:
        pass


# Generated at 2022-06-25 14:39:25.648491
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(string_io_object)


# Generated at 2022-06-25 14:39:28.645803
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('/tmp/test_Grammar.pickle')
    grammar_0.dump('/tmp/test_Grammar.pickle')


# Generated at 2022-06-25 14:39:31.026713
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("Grammar.py")


# Generated at 2022-06-25 14:39:38.661969
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_1 = Grammar()

    grammar_0.load("astroid/test/input/test_Grammar_load.pkl")
    grammar_1.loads(grammar_0.loads("astroid/test/input/test_Grammar_load.pkl"))


# Generated at 2022-06-25 14:39:40.563669
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    t = Grammar()
    t.dump("/tmp/outfile.pkl")

# Generated at 2022-06-25 14:39:42.532894
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump(r"C:\Users\Adrian\Documents\GitHub\tdqm-hook\test\test_grammar\test_case_0\grammar_0.dump")


# Generated at 2022-06-25 14:39:53.369745
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()


# Generated at 2022-06-25 14:39:55.288885
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('/tmp/pgen_8W4sXs.py.pickle')


# Generated at 2022-06-25 14:39:56.607611
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("test.pickle")


# Generated at 2022-06-25 14:39:57.931567
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('grammar.pickle')


# Generated at 2022-06-25 14:39:59.304809
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump('/tmp/ramdisk/tmp_dump')


# Generated at 2022-06-25 14:40:00.844687
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    filename = 'grammar_test_cases.test_case_0.dat'
    grammar_0.load(filename)



# Generated at 2022-06-25 14:40:02.260879
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_1 = Grammar()
    grammar_1.load("/tests/grammar_tables.pickle")



# Generated at 2022-06-25 14:40:06.889274
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load("./etc/parser/Python.asdl")


# Generated at 2022-06-25 14:40:09.263267
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("fixtures/test_Grammar_dump")


# Generated at 2022-06-25 14:40:10.404396
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("grammar.pickle")

# Generated at 2022-06-25 14:40:13.105181
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump("D:/_MyProjects/phd/python-grammar/Grammar.pkl")


# Generated at 2022-06-25 14:40:14.908110
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()

    return grammar_0.dump(filename_0)


# Generated at 2022-06-25 14:40:23.598144
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load(Path(os.path.join(os.environ["TEST_HOME"], "Lib", "test", "badgrammar.pickle")))
    grammar_2 = Grammar()

# Generated at 2022-06-25 14:40:34.955321
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()

# Generated at 2022-06-25 14:40:38.349373
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import tempfile
    import os
    grammar_0 = Grammar()
    assert os.path.exists(tempfile.gettempdir())
    grammar_0.dump(tempfile.gettempdir() + os.path.sep + 'test')


# Generated at 2022-06-25 14:40:40.859321
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('test_0.pkl')
    # Check that grammar_0.async_keywords has the expected value
    assert grammar_0.async_keywords == False


# Generated at 2022-06-25 14:40:42.972152
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g0 = Grammar()
    fd, fname = tempfile.mkstemp()
    # Method dump of class Grammar
    g0.dump(fname)


# Generated at 2022-06-25 14:40:47.352325
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    filename = "Test1.pickle"
    grammar.dump(filename)
    os.remove(filename)
    grammar.dump(filename)


# Generated at 2022-06-25 14:40:48.775695
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    # filename: Path = 
    grammar_0.dump(filename)


# Generated at 2022-06-25 14:40:56.294901
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .tokenize import detect_encoding
    from .tokenize import tokenize
    from . import token
    import tempfile
    import pickle
    from . import parsetok

    grammar_0 = Grammar()
    temp_file = tempfile.NamedTemporaryFile()
    fp = Grammar.open(temp_file.name)
    try:
        tokenize(fp.readline, grammar_0)
    finally:
        fp.close()
        temp_file.close()
    grammar_0.dump(temp_file.name)
    temp_file.seek(0)
    actual = pickle.load(temp_file)
    expected = grammar_0.__dict__
    assert actual == expected


# Generated at 2022-06-25 14:40:58.674199
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load("./Grammar.pickle")

# Generated at 2022-06-25 14:41:04.725776
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dfas = {256: ([[(1, 0)]], {0: 1}), 257: ([[(2, 0)]], {0: 1})}
    grammar.start = 256
    grammar.number2symbol = {256: 'file_input', 257: 'eval_input'}
    grammar.states = [[]]
    grammar.symbol2number = {'file_input': 256, 'eval_input': 257}
    grammar.symbol2label = {'file_input': 1, 'eval_input': 2}
    grammar.tokens = {256: 1, 257: 2}
    grammar.keywords = {'file_input': 1, 'eval_input': 2}

# Generated at 2022-06-25 14:41:11.117877
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('./grammar_0_dump.pkl')

    grammar_1 = Grammar()
    grammar_1.load('./grammar_0_dump.pkl')

    assert grammar_0.labels == grammar_1.labels
    assert grammar_0.symbol2number == grammar_1.symbol2number



# Generated at 2022-06-25 14:41:13.902872
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("__test_Grammar_dump.pickle")


# Generated at 2022-06-25 14:41:22.924034
# Unit test for method load of class Grammar
def test_Grammar_load():
    s = """\
    symbol2number = {}

    number2symbol = {}
    
    states        = []
    
    dfas          = {}
    
    labels        = [(0, 'EMPTY')]
    
    start         = 256
    
    keywords      = {}
    
    tokens        = {}
    
    """

    g1 = Grammar()
    fd, name = tempfile.mkstemp()
    with os.fdopen(fd, "wb") as f:
        f.write(s.encode("utf-8"))
    g1.load(name)
    os.remove(name)
    # Simply making sure the load method doesn't crash
    assert 1



# Generated at 2022-06-25 14:41:24.458903
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("tests/pgen/Grammar.pickle")


# Generated at 2022-06-25 14:41:25.330037
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    test_case_0()


# Generated at 2022-06-25 14:41:29.687140
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    try:
        grammar_0.load("./grammar.example")
        print(grammar_0.symbol2number)
    except Exception:
        pass


# Generated at 2022-06-25 14:41:30.319721
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    test_case_0()


# Generated at 2022-06-25 14:41:31.917047
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    try:
        Grammar().dump()
    except (TypeError, AttributeError):
        pass


# Generated at 2022-06-25 14:41:32.870625
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
#    grammar_0.dump(Path)


# Generated at 2022-06-25 14:41:34.781030
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("./pyparse.pickle")


# Generated at 2022-06-25 14:41:41.566701
# Unit test for method load of class Grammar
def test_Grammar_load():
    # the following line must be the very first in this file
    temp_dir_0 = tempfile.TemporaryDirectory()
    grammar_0 = Grammar()
    filename_0 = os.path.join(temp_dir_0.name, "grammar.pkl")
    grammar_0.dump(filename_0)
    grammar_1 = Grammar()
    grammar_1.load(filename_0)


if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1:
        g = Grammar()
        g.load(sys.argv[1])
        g.report()
    else:
        import unittest
        unittest.main("Grammar")

# Generated at 2022-06-25 14:41:44.774767
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Create an instance of Grammar
    grammar = Grammar()
    # Try to dump the grammar tables to a pickle file.
    grammar.dump("dummy_file")


# Generated at 2022-06-25 14:41:47.047223
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    grammar = Grammar()

    filename = tempfile.gettempdir() + 'tmp'

    grammar.dump(filename)
    #
    #
    #



# Generated at 2022-06-25 14:41:55.076405
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    gram1 = Grammar()
    gram1.dump('t1.pkl')
    gram1.load('t1.pkl')
    gram2 = Grammar()
    gram2.dump('t2.pkl')
    gram2.load('t2.pkl')
    gram3 = Grammar()
    gram3.dump('t3.pkl')
    gram3.load('t3.pkl')
    gram4 = Grammar()
    gram4.dump('t4.pkl')
    gram4.load('t4.pkl')
    gram5 = Grammar()
    gram5.dump('t5.pkl')
    gram5.load('t5.pkl')

# Generated at 2022-06-25 14:41:56.566608
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump('/tmp/Grammar.dump')

# Generated at 2022-06-25 14:42:01.773886
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    dir_name = tempfile.mkdtemp()
    grammar_0.dump(dir_name + '/t5')


# Generated at 2022-06-25 14:42:06.027378
# Unit test for method load of class Grammar
def test_Grammar_load():
    # grammar = Grammar()
    static_path = os.path.join(os.path.dirname(__file__), "..", "Grammar.pickle")
    grammar = Grammar()
    grammar.load(static_path)
    return grammar


# Generated at 2022-06-25 14:42:07.974138
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("./test/fixtures/tmp6azj0smm")


# Generated at 2022-06-25 14:42:09.913538
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    myGrammar = Grammar()
    filename = "dumpedGrammar"
    myGrammar.dump(filename)
    os.remove(filename)


# Generated at 2022-06-25 14:42:12.094328
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump('../../python/tmp/grammar.pkl')
    grammar.dump(os.path.join(os.path.dirname(__file__), '../../python/tmp/grammar.pkl'))


# Generated at 2022-06-25 14:42:20.132118
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()

# Generated at 2022-06-25 14:42:22.925229
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    result = grammar_0.load("")
    assert isinstance(result, object)


# Generated at 2022-06-25 14:42:24.579392
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('test')


# Generated at 2022-06-25 14:42:26.435555
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    try:
        grammar.load(__file__)
    except Exception:
        pass


# Generated at 2022-06-25 14:42:27.796390
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("test.pickle")


# Generated at 2022-06-25 14:42:33.213643
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("<string>")


# Generated at 2022-06-25 14:42:34.446336
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()

    grammar_0.load(None)


# Generated at 2022-06-25 14:42:38.914939
# Unit test for method load of class Grammar
def test_Grammar_load():
    tempdir = tempfile.mkdtemp()
    try:
        token_0 = Grammar()
        token_1 = Grammar()
        #dump(token_1, os.path.join(tempdir, "pickle_0"))
        #load(token_0, os.path.join(tempdir, "pickle_0"))
    finally:
        pass

# Generated at 2022-06-25 14:42:41.971567
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('/tmp/grammar.gen/Grammar.dump')


# Generated at 2022-06-25 14:42:45.688570
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    grammar_0 = test_case_0()

    import tempfile

    temp_file_0 = tempfile.NamedTemporaryFile(delete=False)

    grammar_0.dump(temp_file_0)

    temp_file_0.close()


# Generated at 2022-06-25 14:42:47.582734
# Unit test for method load of class Grammar
def test_Grammar_load():
    test_case_0()

if __name__ == "__main__":
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-25 14:42:49.241154
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.loads(b'cnumpy.distutils.__init__\x80\x02}q\x00.')

# Generated at 2022-06-25 14:42:52.715896
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar_0 = Grammar()
    s = pickle.dumps(grammar_0, pickle.HIGHEST_PROTOCOL)
    grammar.loads(s)
    assert grammar.start == 256

# Generated at 2022-06-25 14:42:56.063822
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("../../grammar/Grammar.pkl")
    #grammar_0.loads(b"")
    grammar_0.report()

if __name__ == "__main__":
    test_case_0()
    test_Grammar_load()

# Generated at 2022-06-25 14:42:59.835795
# Unit test for method load of class Grammar
def test_Grammar_load():
    from typing import List, IO

    grammar_0 = Grammar()
    grammar_0.load(f'stock_data/parser-grammar3-pgen.pickle')


if __name__ == "__main__":
    test_case_0()
    test_Grammar_load()

# Generated at 2022-06-25 14:43:07.084648
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("./python/lib/grammar.pickle")


# Generated at 2022-06-25 14:43:09.865304
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump('grammar1.pickle')


# Generated at 2022-06-25 14:43:12.899543
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test 0: Doesn't crash
    grammar_0 = Grammar()
    grammar_0.load("/tmp/grammar_tables.pickle")
    grammar_0.load("/tmp/grammar_tables.pickle")


# Generated at 2022-06-25 14:43:17.456827
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    try:
        with tempfile.TemporaryDirectory() as dir_name:
            pkl_name = os.path.join(dir_name, "dump.pkl")
            grammar_1.dump(pkl_name)
            grammar_2 = Grammar()
            grammar_2.load(pkl_name)
    except:
        print("Unexpected error:", sys.exc_info()[0])



# Generated at 2022-06-25 14:43:19.153892
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    assert grammar.load(None) is None

if __name__ == "__main__":
    grammar = Grammar()
    grammar.load(None)

# Generated at 2022-06-25 14:43:23.058531
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load(r'd:/work/github/typed_ast/test/data/Grammar.pkl')


# Generated at 2022-06-25 14:43:30.449382
# Unit test for method load of class Grammar
def test_Grammar_load():
    tbl_0 = Grammar()
    tbl_0.load("testdata/Grammar.pickle")
    assert tbl_0.start == 259

# Generated at 2022-06-25 14:43:39.335296
# Unit test for method load of class Grammar
def test_Grammar_load():
    import shutil
    import sys
    from tempfile import mkdtemp
    from os.path import join
    from pypy.translator.goal import pypytargets as targets
    from pypy.config.pypyoption import get_pypy_config
    from pypy.tool.udir import udir
    from pypy.module.parser.pgen2 import main, dump_grammar

    # This unit test tests the loading of a grammar tables file.  So
    # that almost the whole test can be run on top of the JIT, we
    # run the dumped grammar generation in the target pypy-c process.
    # First, we create and run the program to generate the grammar
    # tables:
    dir = str(udir)
    executable = join(dir, "pypy-c")


# Generated at 2022-06-25 14:43:45.860478
# Unit test for method load of class Grammar

# Generated at 2022-06-25 14:43:46.945998
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("../../test/test_dump_pickle")



# Generated at 2022-06-25 14:44:02.641520
# Unit test for method load of class Grammar
def test_Grammar_load():
    import os
    import tempfile
    import pickle
    # Improved version of test_Grammar_load()
    grammar_2 = Grammar()
    filename = "test_Grammar_load.pickle"
    try:
        with open(filename, "r") as f:
            grammar_2 = pickle.load(f)
    except IOError:
        pass

    temp = tempfile.NamedTemporaryFile()
    pkl = pickle.dumps(grammar_2)
    temp.write(pkl)
    temp.flush()
    grammar_0 = Grammar()
    grammar_0.loads(pkl)
    assert grammar_0 == grammar_2
    grammar_1 = Grammar()
    grammar_1.load(temp.name)
    assert grammar_1 == grammar_2


#

# Generated at 2022-06-25 14:44:04.789448
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('./Grammar.tec')
    grammar_0.load('./Grammar.tec')


# Generated at 2022-06-25 14:44:09.781044
# Unit test for method load of class Grammar
def test_Grammar_load():
    temp_file = tempfile.NamedTemporaryFile()
    grammar = Grammar()
    grammar.load(temp_file.name)
    temp_file.delete = False
    temp_file.close()


# Generated at 2022-06-25 14:44:11.103974
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load(str(''))

# Generated at 2022-06-25 14:44:13.334674
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("./test/Grammar/test_grammar.pickle")


# Generated at 2022-06-25 14:44:14.408923
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump(filename='test_files/test_Grammar_dump.pkl')


# Generated at 2022-06-25 14:44:15.741591
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load("Grammar.pickle")


# Generated at 2022-06-25 14:44:23.001554
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """
    Defines a null grammar and pickles it.
    """

    file_path = "./test_grammar_"

    # Construct a grammar
    grammar_0 = Grammar()

    # Try to pickle the grammar (making sure a temporary file is used)
    os.remove(file_path)
    try:
        grammar_0.dump(file_path)
    except pickle.PicklingError:
        assert False

    # Remove the temporary file
    os.remove(file_path)



# Generated at 2022-06-25 14:44:26.458694
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # This is a placeholder for a test.
    # See the following URL for the implementation of this test:
    # https://github.com/python/typeshed/blob/master/stdlib/2and3/_ast.pyi
    pass


# Generated at 2022-06-25 14:44:27.941836
# Unit test for method load of class Grammar
def test_Grammar_load():
    """
    Test that the load method of class Grammar works.
    """


# Generated at 2022-06-25 14:44:33.397787
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('./Grammar.pic')
    # note: this is tested in test_grammar.py


# Generated at 2022-06-25 14:44:35.199320
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("samples/sample_0.py")


# Generated at 2022-06-25 14:44:37.009070
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load("~/pgen/python.pgen")


# Generated at 2022-06-25 14:44:48.187799
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()

# Generated at 2022-06-25 14:44:49.840262
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load('data/Grammar.pkl')


# Generated at 2022-06-25 14:44:51.783385
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump(3)


# Generated at 2022-06-25 14:44:54.206942
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    # Test for path
    #file_name = grammar_0.dump(file_name)
    pass


# Generated at 2022-06-25 14:45:02.131875
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load('../../ThirdParty/pgen2/Grammar.pickle')
    assert grammar_1.symbol2number['funcname'] == 757
    assert grammar_1.number2symbol[757] == 'funcname'
    assert grammar_1.states[0][0][0][1] == 1
    assert grammar_1.states[0][1][0][1] == 1
    assert grammar_1.dfas[757][0][0][0][0] == 258
    assert grammar_1.dfas[757][0][1][0][0] == 1
    assert grammar_1.dfas[757][0][2][0][0] == 257
    assert grammar_1.labels[0] == (0, 'EMPTY')
    assert grammar_1

# Generated at 2022-06-25 14:45:06.792495
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    filename = os.path.abspath("temp_file")
    try:
        grammar_0.dump(filename)
        grammar_1 = Grammar()
        grammar_1.load(filename)
        if grammar_1.states != grammar_0.states:
            return 1
    finally:
        os.remove(filename)
    return 0


# Generated at 2022-06-25 14:45:08.834663
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("./test/test-data/test_case_0")

test_Grammar_dump()


# Generated at 2022-06-25 14:45:13.508612
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    test_case_0()


# Generated at 2022-06-25 14:45:16.210565
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_1 = Grammar()
    grammar_1.load("fixtures/grammar.pkl")
    grammar_0.loads(grammar_1.dumps())


# Generated at 2022-06-25 14:45:17.687474
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump(str())


# Generated at 2022-06-25 14:45:20.448770
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    with tempfile.TemporaryDirectory() as dir_name:
        grammar_0.dump(os.path.join(dir_name,"grammar_0.pickle"))



# Generated at 2022-06-25 14:45:22.549766
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('./Grammar_dump_0')

if __name__ == "__main__":
    test_case_0()
    test_Grammar_load()

# Generated at 2022-06-25 14:45:24.156926
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("grammar_0_dump")

# Generated at 2022-06-25 14:45:25.579700
# Unit test for method load of class Grammar
def test_Grammar_load():

    #
    # Grammar load test 0.
    #
    grammar = Grammar()
    grammar.load(b"i\n0\n.")
    assert grammar.start == 256



# Generated at 2022-06-25 14:45:27.081502
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('/tmp/grammar_0.dump')
    grammar_1 = Grammar()
    grammar_1.load('/tmp/grammar_0.dump')


# Generated at 2022-06-25 14:45:28.434242
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('grammar_0.pkl')


# Generated at 2022-06-25 14:45:34.906419
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Create object
    grammar = Grammar()
    # Call method dump
    try:
        grammar.dump('tmp.txt')
    # Call method loads
        grammar.loads(open('tmp.txt', 'rb').read())
    except:
        pass
    # Delete temporary file
    os.remove('tmp.txt')
test_case_0()
test_Grammar_dump()

# Generated at 2022-06-25 14:45:41.584587
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump("grammar.pickle")
    grammar_2 = Grammar()
    grammar_2.load("grammar.pickle")


# Generated at 2022-06-25 14:45:42.986972
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_1 = Grammar()
    grammar_1.dump("Grammar.dump")


# Generated at 2022-06-25 14:45:53.160897
# Unit test for method dump of class Grammar

# Generated at 2022-06-25 14:45:56.612573
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Dump the grammar tables to a pickle file
    grammar_1 = Grammar()
    grammar_1.dump(filename, *args)


# Generated at 2022-06-25 14:46:01.117915
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    with tempfile.NamedTemporaryFile(delete=False) as f:
        pickle.dump({'foo': 'bar'}, f, 0)
    grammar_0.load(f.name)
    os.unlink(f.name)


# Generated at 2022-06-25 14:46:03.127493
# Unit test for method load of class Grammar
def test_Grammar_load():
    t = Grammar()
    t.load("test/test_pickles/20/Grammar.pickle")


# Generated at 2022-06-25 14:46:05.922686
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = "test.pickle"
    grammar_0 = Grammar()
    grammar_0.dump(filename)
    grammar_0.load(filename)


# Generated at 2022-06-25 14:46:08.164029
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = "grammar-test.pkl"
    grammar_dump = Grammar()
    grammar_dump.dump(filename)



# Generated at 2022-06-25 14:46:11.014317
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    filename = "../../Parser/Grammar/Grammar.py"
    grammar_0.dump(filename)


# Generated at 2022-06-25 14:46:20.165645
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    # state 0
    grammar_1.start = 256
    grammar_1.symbol2number["S"] = 0
    grammar_1.number2symbol[0] = "S"
    grammar_1.states.append(
        [
            [
                (256, 1),
                (257, 2),
            ],
            [
                (257, 2),
                (258, 2),
            ],
            [
                (0, 2),
            ],
        ]
    )

# Generated at 2022-06-25 14:46:39.938874
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = "./test.pkl"
    grammar_0 = Grammar()
    grammar_0.dump(filename)
    grammar_1 = Grammar()
    grammar_1.load(filename)
    grammar_2 = grammar_1.copy()
    grammar_2.loads(grammar_1.dumps())


# Generated at 2022-06-25 14:46:47.176398
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0_dump_filename = os.path.abspath(__file__ + ".grammar_0.dump")
    grammar_0 = Grammar()
    try:
        grammar_0.dump(grammar_0_dump_filename)
        f = open(grammar_0_dump_filename, "rb")
        magic = f.read(4)
        assert magic == b"PYTH", "test_Grammar_dump: magic"
        grammar_0_dump_version = int.from_bytes(f.read(4), "little")
        assert grammar_0_dump_version == 4, "test_Grammar_dump: version"
        f.close()
    finally:
        os.remove(grammar_0_dump_filename)