

# Generated at 2022-06-25 14:36:46.469638
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    with open('pickletest.pkl', 'rb') as f:
        pickle.dump(grammar_0.__dict__, f, pickle.HIGHEST_PROTOCOL)
    grammar_1 = Grammar()
    grammar_1.load('pickletest.pkl')
    grammar_0.report()
    grammar_1.report()
    assert grammar_0 == grammar_1


# Generated at 2022-06-25 14:36:49.249060
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # ---------------------------
    # Testing method dump
    # ---------------------------
    grammar_0 = Grammar()
    grammar_0.report()


# Generated at 2022-06-25 14:36:51.723963
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    pickle_file = grammar_1.__module__ + ".test"
    try:
        grammar_1.load(pickle_file)
    finally:
        os.remove(pickle_file)


# Generated at 2022-06-25 14:36:53.303130
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.report()
    grammar_1.dump("grammar_1.dump")

# Generated at 2022-06-25 14:37:03.044287
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.start = 257
    grammar.symbol2number["foo"] = 258
    grammar.symbol2number["bar"] = 259
    grammar.number2symbol[258] = "foo"
    grammar.number2symbol[259] = "bar"
    grammar.states = [
        # State 0     State 1     State 2
        [],           [],         [],
        # State 3
        [(257, 0), (258, 1), (0, 3)],
        # State 4
        [(259, 2), (0, 4)],
    ]
    grammar.dfas = {
        258: ([[(258, 1), (0, 3)]], {258: 1}),
        259: ([[(259, 2), (0, 4)]], {259: 1}),
    }


# Generated at 2022-06-25 14:37:06.616326
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    my_grammar = Grammar()
    my_grammar.dump("test.pickle")
    with open("test.pickle", "rb") as f:
        d = pickle.load(f)
    # assert id is in the dict
    assert isinstance(d['start'],int)
    os.remove("test.pickle")


# Generated at 2022-06-25 14:37:08.371892
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    assert True
test_case_0()
test_Grammar_dump()


# Generated at 2022-06-25 14:37:14.970190
# Unit test for method load of class Grammar
def test_Grammar_load():
  grammars_0 = Grammar()
  grammars_1 = Grammar()
  grammars_1.keywords = {'and': 258, 'try': 259, 'global': 260, 'break': 261, 'nonlocal': 262, 'assert': 263, 'as': 264, 'in': 265, 'or': 266, 'lambda': 267, 'def': 268, 'not': 269, 'class': 270}
  grammars_1.symbol2label = {'trailer': 719, 'expr': 710}

# Generated at 2022-06-25 14:37:17.082914
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_obj = Grammar()
    grammar_obj.dump("./output/grammar_dump")


# Generated at 2022-06-25 14:37:21.155432
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    grammar.report()


if __name__ == "__main__":
    test_case_0()
    test_Grammar_load()

# Generated at 2022-06-25 14:37:36.481786
# Unit test for method load of class Grammar
def test_Grammar_load():
    from pickle import dumps
    from pickletools import dis
    grammar = Grammar()
    grammar.states = [
        [],
        [
            (0, 1),
            (256, 2),
            (1, 3),
            (2, 3),
            (3, 3),
            (4, 3),
            (5, 3),
            (6, 3),
            (7, 3),
            (8, 3),
            (9, 3),
            (10, 3),
            (11, 3),
            (12, 3),
            (13, 3),
            (14, 3),
            (15, 3),
        ],
    ]
    grammar.symbol2number = {"A": 256, "EMPTY": 0}

# Generated at 2022-06-25 14:37:41.066274
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    # Get the current TEMP directory
    temp_directory_1 = os.getcwd()
    # Add a file at the end of the path to save the grammar tables
    file_name_1 = "/pgen_from_load.pkl"
    file_path_1 = temp_directory_1 + file_name_1
    # Dump the grammar tables to the file
    grammar_0.dump(file_path_1)
    # Load the grammar tables from the file
    grammar_1 = Grammar()
    grammar_1.load(file_path_1)
    grammar_1.report()


# Generated at 2022-06-25 14:37:42.993602
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = "some/file/path"
    grammar_0 = Grammar()
    grammar_0.load(filename)


# Generated at 2022-06-25 14:37:43.923940
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()


# Generated at 2022-06-25 14:37:51.042333
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.symbol2number = {}
    grammar_1.number2symbol = {}
    grammar_1.states = []
    grammar_1.dfas = {}
    grammar_1.labels = []
    grammar_1.keywords = {}
    grammar_1.tokens = {}
    grammar_1.symbol2label = {}
    grammar_1.start = 256
    grammar_1.async_keywords = False

    temp_file = tempfile.NamedTemporaryFile(delete=False)
    grammar_1.dump(temp_file.name)
    temp_file.close()
    os.unlink(temp_file.name)

# Generated at 2022-06-25 14:38:00.985148
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("./test_data/test_grammar.pickle")

# Generated at 2022-06-25 14:38:02.456468
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    assert grammar.dump('../data/grammar_dump.out') is None


# Generated at 2022-06-25 14:38:05.248457
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.dump('grammar_1.pkl')
    grammar_2 = Grammar()
    # unit test for method load
    grammar_2.load('grammar_1.pkl')



# Generated at 2022-06-25 14:38:06.779263
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load("Grammar.txt")
    grammar_1.report()


# Generated at 2022-06-25 14:38:07.757009
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load("Grammar.txt")


# Generated at 2022-06-25 14:38:13.461752
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    with open("dump_test", "wb") as f:
        grammar.dump(f)
    grammar.load("dump_test")
    grammar.report()

# Generated at 2022-06-25 14:38:23.979334
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Setup
    grammar_0 = Grammar()

    # Exercise
    grammar_0.load("")

    # Verify
    assert isinstance(grammar_0, Grammar)



# Generated at 2022-06-25 14:38:28.817254
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Unit test for the Grammar.load method."""

    grammar_0 = Grammar()
    grammar_0.load(
        "/Users/daniel/Documents/GitHub/JavaScript/jsontoxml/asdl/asdl.py/Python.asdl/Python/Python.3.3.3.grammar"
    )
    grammar_0.report()



# Generated at 2022-06-25 14:38:31.720700
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.report()
    grammar.dump(os.path.join(tempfile.gettempdir(), "test_Grammar_dump.pickle"))



# Generated at 2022-06-25 14:38:35.742145
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    graph_0 = grammar_0.dump(os.path.join(os.path.dirname(__file__), "pgen_grammar.txt"))


# Generated at 2022-06-25 14:38:38.325953
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("Grammar.pkl")
    grammar_0.dump("Grammar2.pkl")


# Generated at 2022-06-25 14:38:40.412836
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    with tempfile.TemporaryDirectory() as d:
        fn = os.path.join(d, 't.pkl')
        test_case_0().dump(fn)

# Generated at 2022-06-25 14:38:43.086971
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load(
        "./lib2to3/Grammar.txt"
    )  # This test is incomplete - it will not check for exceptions or errors


# Generated at 2022-06-25 14:38:48.447915
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    grammar.report()
    assert True



# Generated at 2022-06-25 14:38:50.717303
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("../../_pgen_dump/dump")


# Generated at 2022-06-25 14:38:54.721062
# Unit test for method load of class Grammar
def test_Grammar_load():
    assert 1 == 1

# Class to hold attributes of type Grammar

# Generated at 2022-06-25 14:38:59.184278
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    # Create a grammar with a single token
    grammar_0 = Grammar()
    grammar_0.tokens = {1: 1, 2: 2}

    # Dump the grammar to a file
    grammar_0.dump("./pgen_test.pkl")
    grammar_1 = Grammar()
    grammar_1.load("./pgen_test.pkl")

    # The dumped and loaded grammars should be the same
    assert grammar_0.tokens == grammar_1.tokens

# Generated at 2022-06-25 14:39:05.909046
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.start = 256

# Generated at 2022-06-25 14:39:08.538193
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load("/home/vegasa/Downloads/cpython-3.7.7/Grammar/Grammar.pickle")
    grammar_1.report()

if __name__ == "__main__":
    test_case_0()
    test_Grammar_load()

# Generated at 2022-06-25 14:39:12.364586
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("./pgen2/Grammar.pkl")
    grammar_0.report()

if __name__ == "__main__":
    print("Testing")
    test_Grammar_load()

# Generated at 2022-06-25 14:39:15.717043
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_obj = Grammar()
    with open("/tmp/grm.pkl", "wb") as f:
        pickle.dump(grammar_obj.__dict__, f, pickle.HIGHEST_PROTOCOL)
    grammar_obj.load("/tmp/grm.pkl")


# Generated at 2022-06-25 14:39:21.182409
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # This case did not actually test anything.  It is likely that
    # the original purpose of this test was to make sure the test suite
    # itself was working.  The test suite has been rewritten in the
    # meantime, so this test can be removed.
    pass


if __name__ == "__main__":
    test_case_0()
    print("Done.")

# Generated at 2022-06-25 14:39:23.339720
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.report()
    grammar_0.dump( "grammar_0.pickle" )


# Generated at 2022-06-25 14:39:25.456904
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('/home/benjamin/PycharmProjects/python-language-server/pyls/pyls/pgen2/Grammar.pkl')



# Generated at 2022-06-25 14:39:28.325924
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('/plt/src/Python-2.7.14/Grammar/dump_out')



# Generated at 2022-06-25 14:39:33.107322
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("test_case_0.txt")
    grammar_0.report()


# Generated at 2022-06-25 14:39:40.718835
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    path = os.path.join(os.path.dirname(__file__), "Grammar.pkl")
    # Tests the condition where the file exists
    grammar_1.load(path)
    grammar_1.report()
    # Tests the condition where the filename is a string and the file does not exist
    try:
        grammar_1.load("Grammar_file_does_not_exist")
    except FileNotFoundError:
        pass
    else:
        raise RuntimeError("Should have raised exception")

test_case_0()
test_Grammar_load()

# Generated at 2022-06-25 14:39:46.161619
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import driver
    grammar = driver.load_grammar(os.path.join(os.getcwd(), "lib2to3/Grammar.txt"))
    grammar.dump(os.path.join(os.getcwd(), "Grammar.pkl"))
    grammar_0 = Grammar()
    grammar_0.load(os.path.join(os.getcwd(), "Grammar.pkl"))
    grammar_0.report()


# Generated at 2022-06-25 14:39:49.315844
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("F:\\python\\cpython\\Lib\\test\\parser_grammar.pkl")
    grammar_0.report()

# Generated at 2022-06-25 14:39:53.268944
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.report()
    grammar_1.dump('Python-3.4.3\\Grammar\\pickle_file\\NewFile.pk1')


if __name__ == "__main__":
    test_case_0()
    test_Grammar_dump()

# Generated at 2022-06-25 14:39:54.876755
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    try:
        grammar_0.load(__file__)
    except Exception:
        pass


# Generated at 2022-06-25 14:39:56.741213
# Unit test for method load of class Grammar
def test_Grammar_load():
    sname = 'async_grammar.pkl'
    grammar_0 = Grammar()
    grammar_0.load(sname)
    grammar_0.report()

# Generated at 2022-06-25 14:40:02.577013
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    def dummy_symbol2number():
        return {'COMMA': 1, 'DOT': 2, 'MINUS': 3, 'EQUAL': 4, 'PLUS': 5}

    def dummy_number2symbol():
        return {1: 'COMMA', 2: 'DOT', 3: 'MINUS', 4: 'EQUAL', 5: 'PLUS'}

    def dummy_states():
        return [
            [
                [(1, 1), (5, 2)],
                [(2, 2)],
                [(3, 2), (4, 3), (2, 4)],
                [(4, 5)],
                [(4, 6), (0, 4)],
                [(4, 7)],
                [(0, 7)]
            ]
        ]


# Generated at 2022-06-25 14:40:11.954381
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    s2n = {
        "y": 257,
        "x": 258,
        "z": 259,
        "w": 260,
        "v": 261,
        "d": 262,
        "u": 263,
    }
    n2s = {257: "y", 258: "x", 259: "z", 260: "w", 261: "v", 262: "d", 263: "u"}
    symbols = {258, 259, 260, 261, 262, 263}
    start = 257
    labels = [(0, "EMPTY"), (257, None), (258, None), (259, None), (260, None), (261, None), (262, None), (263, None)]

# Generated at 2022-06-25 14:40:20.912987
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Note:  This test requires the 'pgen' module, but it need not be
    # used by the rest of the grammar package.
    import pgen

    grammar_0 = Grammar()
    try:
        grammar_0.load("grammar.pkl")
    except:
        pass
    grammar_1 = pgen.generate_grammar("Python.gram")
    grammar_1.dump("grammar.pkl")
    grammar_2 = Grammar()
    grammar_2.load("grammar.pkl")
    grammar_2.report()


if __name__ == "__main__":
    test_case_0()
    test_Grammar_load()

# Generated at 2022-06-25 14:40:34.501165
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Test the dump method of class Grammar
    grammar_1 = Grammar()
    filename_1 = tempfile.TemporaryDirectory().name + "/Grammar.pickle"
    if os.path.isfile(filename_1):  # fail if file exists
        return 1

    grammar_1.dump(filename_1)
    if not os.path.isfile(filename_1):  # fail if file does not exist
        return 1
    os.remove(filename_1)  # remove file
    return 0



# Generated at 2022-06-25 14:40:35.971197
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("./data/Grammar_dump.txt")



# Generated at 2022-06-25 14:40:38.115479
# Unit test for method load of class Grammar
def test_Grammar_load():
    # XXX Should be a better test
    grammar_1 = Grammar()
    grammar_1.load("Grammar.pkl")


# Generated at 2022-06-25 14:40:44.049166
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("Grammar_pgen.pkl")

# Generated at 2022-06-25 14:40:49.258539
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump('tmp.pkl')
    grammar = Grammar()
    grammar.load('tmp.pkl')
    grammar.report()
    assert grammar.symbol2number
    assert grammar.number2symbol
    assert grammar.states
    assert grammar.dfas
    assert grammar.labels
    assert grammar.keywords
    assert grammar.tokens

if __name__ == "__main__":
    # test_case_0()
    test_Grammar_dump()

# Generated at 2022-06-25 14:40:52.002007
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("./Grammar.pickle")
    grammar.report()

if __name__ == "__main__":
    test_case_0()
    test_Grammar_load()

# Generated at 2022-06-25 14:40:54.352210
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os

    grammar_0 = Grammar()
    grammar_0.report()
    grammar_0.dump(os.path.join("data", "grammar.pickle"))



# Generated at 2022-06-25 14:41:01.621965
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('/tmp/grammar_0.pkl')
    grammar_1 = Grammar()
    grammar_1.load('/tmp/grammar_0.pkl')
    assert grammar_0.symbol2number == grammar_1.symbol2number
    assert grammar_0.states == grammar_1.states
    assert grammar_0.dfas == grammar_1.dfas
    assert grammar_0.labels == grammar_1.labels
    assert grammar_0.start == grammar_1.start
    assert grammar_0.keywords == grammar_1.keywords
    assert grammar_0.tokens == grammar_1.tokens


if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-25 14:41:04.859284
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Setup
    grammar_1 = Grammar()

    # Exercise
    grammar_1.dump('dummy')

    # Verify
    # Teardown



# Generated at 2022-06-25 14:41:08.029405
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = "Grammar.pickle"
    grammar_0 = Grammar()
    grammar_0.dump(filename)



# Generated at 2022-06-25 14:41:15.413581
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.load('../utils/Python.graminit')
    grammar.dump('../utils/Python.graminit')


# Generated at 2022-06-25 14:41:25.357934
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("test_Grammar_load.pickle")
    if grammar_0.symbol2number["NAME"] != 256:
        print("Failed test_Grammar_load")
    if grammar_0.number2symbol[257] != "test":
        print("Failed test_Grammar_load")
    if grammar_0.states[0][1][1] != 0:
        print("Failed test_Grammar_load")
    if grammar_0.dfas[257][0][0][0] != 37:
        print("Failed test_Grammar_load")
    if grammar_0.labels[0][0] != 0:
        print("Failed test_Grammar_load")

# Generated at 2022-06-25 14:41:29.473287
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.dump("_tmp_Grammar_load_1")
    grammar_2 = Grammar()
    grammar_2.load("_tmp_Grammar_load_1")
    # grammar_1.report()
    # grammar_2.report()
    os.remove("_tmp_Grammar_load_1")


if __name__ == "__main__":
    test_case_0()
    test_Grammar_load()

# Generated at 2022-06-25 14:41:31.229066
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("./test_grammar_dump.pickle")


# Generated at 2022-06-25 14:41:34.741282
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import grammar
    from .pygram import python_grammar_no_print_statement
    grammar = grammar.Grammar(python_grammar_no_print_statement, "Grammar")
    grammar.dump("Grammar")


# Generated at 2022-06-25 14:41:39.307714
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    global filename
    import pickle
    filename = '_p_pickle.pickle'
    Grammar().dump(filename)
    # Check that the pickle file has been created
    try:
        with open(filename, "rb") as f:
            d = pickle.load(f)
        return True
    except:
        return False


# Generated at 2022-06-25 14:41:42.546522
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.load("grammar_0.pickle")
    grammar_0.dump("grammar_1.pickle")


# Generated at 2022-06-25 14:41:51.757699
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # This is a simple pickle of a Grammar():
    #
    # import pygram.grammar
    # grammar = pygram.grammar.Grammar()
    # import pickle
    # pickle.dump(grammar, open('/tmp/pygram-grammar.pickle', 'wb'), pickle.HIGHEST_PROTOCOL)

    # pickle.py 3.5 copes with __getstate__ and __setstate__
    grammar = Grammar()
    grammar.load(os.path.dirname(__file__) + "/pygram-grammar.pickle")
    grammar.report()
    assert grammar is not None
    return grammar

# __all__ = ["Grammar", "opmap"]

# Generated at 2022-06-25 14:41:53.843282
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("/a/b/c")
    grammar_0.load("d:e:f:")


# Generated at 2022-06-25 14:41:55.254277
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("test")


# Generated at 2022-06-25 14:42:02.996666
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("hello.pyg")


# Generated at 2022-06-25 14:42:06.381490
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('test_grammar.txt')
test_case_0()
test_Grammar_load()

# Generated at 2022-06-25 14:42:10.006411
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen
    from . import conv
    from . import readline
    from . import driver

    grammar_1 = Grammar()
    grammar_1.load('__pycache__/grammar-grammar_1.cache')
    grammar_1.dump('__pycache__/grammar-grammar_1.cache')


# Generated at 2022-06-25 14:42:13.574854
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Initialize an instance of class Grammar
    grammar = Grammar()

    # Create a temporary file using tempfile
    with tempfile.TemporaryDirectory() as tmpdirname:
        # Get the temporary file name
        filename = os.path.join(tmpdirname, 'tmp_Grammar_dump.tmp')
        # Execute the method dump with filename
        grammar.dump(filename)
        # Check if the file exists and is readable
        assert os.path.isfile(filename) and os.access(filename, os.R_OK)



# Generated at 2022-06-25 14:42:20.702989
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()

    grammar_2 = Grammar()
    fn = "/tmp/parsetab_test.pkl"
    grammar_1.dump(fn)
    grammar_2.load(fn)
    os.unlink(fn)

    grammars = [grammar_1, grammar_2]
    for attr in ('symbol2number', 'number2symbol', 'dfas', 'keywords',
                 'tokens', 'symbol2label'):
        assert getattr(grammar_1, attr) == getattr(grammar_2, attr)
    assert grammar_1.labels == grammar_2.labels
    assert grammar_1.states == grammar_2.states
    assert grammar_1.start == grammar_2.start
    assert grammar_1.async_

# Generated at 2022-06-25 14:42:23.091292
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('grammar.pkl')


# Generated at 2022-06-25 14:42:24.994743
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = "./test_0.pkl"
    grammar_0 = Grammar()
    grammar_0.dump(filename)



# Generated at 2022-06-25 14:42:32.841481
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load('./tests/Grammar_test_case_1.pkl')

# Generated at 2022-06-25 14:42:36.941954
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    #
    # The rest of this test is a bit bogus, since it only looks for
    # exceptions.
    #
    grammar.dump("./pgen_grammar.pickle")
    grammar.load("./pgen_grammar.pickle")

# End test for method dump of class Grammar


# Generated at 2022-06-25 14:42:37.736536
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('grammar_0.dump')



# Generated at 2022-06-25 14:42:52.715062
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()

# Generated at 2022-06-25 14:42:54.481516
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    assert grammar_0.dump('./cpython/Lib/test/parse_test.py')


# Generated at 2022-06-25 14:42:57.600979
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    with open(r"Python36\Lib\test\pgen_data", 'rb') as grammar_0_f:
        grammar_0.load(grammar_0_f)
    grammar_0.report()


# Generated at 2022-06-25 14:42:59.139401
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_d = Grammar()
    grammar_d.dump('grammar.pkl')


# Generated at 2022-06-25 14:43:09.542613
# Unit test for method load of class Grammar
def test_Grammar_load():

    grammar_1 = Grammar()
    grammar_2 = Grammar()
    grammar_1.dump("data/Grammar.dump")
    grammar_2.load("data/Grammar.dump")
    #print(grammar_1.symbol2number)
    #print(grammar_2.symbol2number)
    assert grammar_1.symbol2number == grammar_2.symbol2number
    assert grammar_1.number2symbol == grammar_2.number2symbol
    assert grammar_1.states == grammar_2.states
    assert grammar_1.dfas == grammar_2.dfas
    assert grammar_1.labels == grammar_2.labels
    assert grammar_1.keywords == grammar_2.keywords
    assert grammar_1.tokens == grammar_2.tokens

# Generated at 2022-06-25 14:43:14.446593
# Unit test for method load of class Grammar
def test_Grammar_load():
    import tempfile

    filename = tempfile.mktemp()
    grammar = Grammar()
    grammar.dump(filename)
    grammar2 = Grammar()
    grammar2.load(filename)
    assert grammar.symbol2number == grammar2.symbol2number
    assert grammar.number2symbol == grammar2.number2symbol


if __name__ == "__main__":
    test_case_0()
    test_Grammar_load()

# Generated at 2022-06-25 14:43:16.338939
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("Grammar/Grammar.pkl")
    grammar.report()


# Generated at 2022-06-25 14:43:21.644690
# Unit test for method load of class Grammar
def test_Grammar_load():

    python_grammar = Grammar()
    python_grammar.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))


if __name__ == "__main__":

    test_case_0()
    test_Grammar_load()

# Generated at 2022-06-25 14:43:24.418691
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    grammar_0 = Grammar()
    grammar_0.dump('test_dump')


# Generated at 2022-06-25 14:43:26.409233
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load("Python-3.6.2/Grammar/Grammar")


# Generated at 2022-06-25 14:43:39.526686
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.dump('test_Grammar_dump.pkl')
    grammar_1 = Grammar()
    grammar_1.load('test_Grammar_dump.pkl')



# Generated at 2022-06-25 14:43:41.277677
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.load("Grammar.pickle")
    grammar.dump("Grammar_new.pickle")



# Generated at 2022-06-25 14:43:44.966999
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.report()
    grammar_1.dump('test_grammar.pkl')
    grammar_2 = Grammar()
    grammar_2.load('test_grammar.pkl')
    grammar_2.report()


# Generated at 2022-06-25 14:43:47.140727
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammars.load_grammar(grammar)
    grammar.dump("filename")


# Generated at 2022-06-25 14:43:48.014038
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("Grammar")


# Generated at 2022-06-25 14:43:50.458816
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    fd, fn = tempfile.mkstemp()
    try:
        os.close(fd)
        assert isinstance(grammar_1, object)
        grammar_1.dump(fn)
    finally:
        os.remove(fn)


# Generated at 2022-06-25 14:43:53.123301
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("./Grammar.pkl")
    grammar.report()


# Generated at 2022-06-25 14:43:56.282925
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load('Calculator.pkl')
    g.report()


# Generated at 2022-06-25 14:43:58.284556
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = "./Grammar.pkl"
    grammar_0 = Grammar()
    grammar_0.dump(filename)


# Generated at 2022-06-25 14:44:00.657422
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("./grammar-pickle")
    grammar_0.report()


# Generated at 2022-06-25 14:44:13.160467
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("./test/test_grammar/output/test_grammar_dump.txt")


# Generated at 2022-06-25 14:44:19.546452
# Unit test for method load of class Grammar
def test_Grammar_load():

    grammar_1 = Grammar()
    grammar_1.load("Grammar.pkl")
    grammar_1.report()

    grammar_2 = Grammar()

# Generated at 2022-06-25 14:44:21.090865
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("test_case_0.pickle")


# Generated at 2022-06-25 14:44:23.911983
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.load("Lib/test/pgen/Grammar.pkl")
    grammar.dump("Lib/test/pgen/Grammar_new.pkl")



# Generated at 2022-06-25 14:44:32.920900
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()

    grammar_1.symbol2number = {'None': None, 'False': False, 'True': True, 'and': 256}
    grammar_1.number2symbol = {0: 'EMPTY', 256: 'and'}
    grammar_1.states = [[(0, 0), (1, 1)], [(1, 1), (0, 0)]]
    grammar_1.dfas = {256: (0, {'None': 1, 'False': 1, 'True': 1})}
    grammar_1.labels = [(0, 'EMPTY'), (1, None)]
    grammar_1.keywords = {}
    grammar_1.tokens = {}
    grammar_1.symbol2label = {}
    grammar_1.start = 256


# Generated at 2022-06-25 14:44:34.412143
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_load = Grammar()


# Generated at 2022-06-25 14:44:36.536360
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump("dump_test.pickle")
    grammar_2 = Grammar()
    grammar_2.load("dump_test.pickle")
    grammar_2.report()

# Generated at 2022-06-25 14:44:40.715498
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    with open("Grammar_dump.pickle", "rb") as f:
        grammar_1 = pickle.load(f)

    grammar_0 = Grammar()
    grammar_0.report()
    if grammar_0 != grammar_1:
        raise ValueError()


# Generated at 2022-06-25 14:44:44.254670
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    filename = "grammar_dump.pkl"
    res = grammar.dump(filename)
    assert res is None



# Generated at 2022-06-25 14:44:46.063693
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = "foo"
    grammar_0 = Grammar()
    grammar_0.dump(filename)


# Generated at 2022-06-25 14:45:03.168430
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    test_path = os.path.join(tempfile.gettempdir(), "test.pkl")
    grammar.load(test_path)
    if grammar.symbol2number != {}:
        raise AssertionError("symbol2number not empty.")
    if grammar.number2symbol != {}:
        raise AssertionError("number2symbol not empty.")
    if grammar.states != []:
        raise AssertionError("states not empty.")
    if grammar.dfas != {}:
        raise AssertionError("dfas not empty.")
    if grammar.labels != [(0, "EMPTY")]:
        raise AssertionError("labels not empty.")
    if grammar.keywords != {}:
        raise AssertionError("keywords not empty.")

# Generated at 2022-06-25 14:45:12.690699
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()

# Generated at 2022-06-25 14:45:14.713000
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump('grammar_1_grammar.pkl')


# Generated at 2022-06-25 14:45:16.170496
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("./pygrammar.txt")



# Generated at 2022-06-25 14:45:18.962711
# Unit test for method load of class Grammar
def test_Grammar_load():
    table_0 = Grammar()

# Generated at 2022-06-25 14:45:20.776594
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.report()

if __name__ == "__main__":
    test_case_0(
    )

# Generated at 2022-06-25 14:45:27.044134
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen
    from . import token

    grammar = Grammar()
    print("\nBuilding grammar...", end=" ")
    grammar.load("../../Lib/test/Grammar.pkl")
    print("done.")
    print("\nGenerating parser...", end=" ")
    parser = pgen.ParserGenerator(grammar)
    print("done.")
    print("\nParsing test grammar")
    parser.parse(token.generate_tokens(open("Grammar.txt")))



# Generated at 2022-06-25 14:45:28.394627
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump('./test_grammar.tmp')



# Generated at 2022-06-25 14:45:39.456349
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Create an instance of Grammar and load grammar tables
    grammar = Grammar()
    grammar.load('/home/user/mypy/grammar/Grammar.pkl')

    # Test return values of table attributes
    assert len(grammar.symbol2number) == 14
    # Note: The following test number may need to be changed if a new version of
    # python.
    assert len(grammar.number2symbol) == 227
    assert len(grammar.states) == 442
    assert len(grammar.dfas) == 345
    assert len(grammar.labels) == 442
    assert grammar.start == 256

    # Test the grammar DFA table.
    assert len(grammar.states) == len(grammar.dfas)

# Generated at 2022-06-25 14:45:41.193054
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load("../Parser/Basics")
    grammar_1.report()


# Generated at 2022-06-25 14:45:55.134910
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('./temp/dump_0')
    grammar_0.report()


# Generated at 2022-06-25 14:46:02.100467
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # This is a regression test for issue1063275
    g = Grammar()
    # make sure we have something in symbol2number dictionary
    g.symbol2number["foo"] = 1
    # Check that we can dump to file
    f = tempfile.TemporaryFile()
    g.dump(f)
    # Check that we can load from file
    f.seek(0)
    h = Grammar()
    h.load(f)
    f.close()
    assert g.symbol2number == h.symbol2number


# Generated at 2022-06-25 14:46:07.368248
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.start = 1
    grammar.tokens = dict(a=1)
    grammar.dump("./test_data/grammar_pickle")
    assert(os.path.isfile("./test_data/grammar_pickle"))
    os.remove("./test_data/grammar_pickle")


# Generated at 2022-06-25 14:46:10.482384
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump("../Grammar/grammar.pkl")


# Generated at 2022-06-25 14:46:12.363773
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    test_case_0()
    grammar_1.dump('data/grammar_1.pickle')



# Generated at 2022-06-25 14:46:16.807533
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    temp_file = tempfile.NamedTemporaryFile()
    filename = temp_file.name
    grammar_1.dump(filename)
    grammar_2 = Grammar()
    grammar_2.load(filename)
    grammar_1.start == grammar_2.start

# Generated at 2022-06-25 14:46:21.078852
# Unit test for method load of class Grammar
def test_Grammar_load():
    gram_dict = {"symbol2number": {}, "number2symbol": {}}
    grammar_0 = Grammar()
    grammar_0._update(gram_dict)
    # print(grammar_0.symbol2number)
    # print(grammar_0.number2symbol)
    assert grammar_0.symbol2number == {}
    assert grammar_0.number2symbol == {}



# Generated at 2022-06-25 14:46:25.507026
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("./python/lib/python3.7/test/test_grammar.pickle")
    grammar_0.report()


# Generated at 2022-06-25 14:46:27.836546
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Test for Grammar of method load

    This test verifies the ability of the Grammar class
    to load a pickled file.
    """

    grammar_0 = Grammar()
    grammar_0.load(__file__)
    grammar_0.report()


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 14:46:29.551733
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.report()
    grammar_0.load("lib2to3/Grammar.pickle")
    grammar_0.report()
