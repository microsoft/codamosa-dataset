

# Generated at 2022-06-25 14:36:52.134523
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.dump("grammar1.pkl")
    grammar_2 = Grammar()
    grammar_2.load("grammar1.pkl")


# Generated at 2022-06-25 14:36:53.291448
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    pass



# Generated at 2022-06-25 14:36:54.044296
# Unit test for method load of class Grammar
def test_Grammar_load():
    pass


# Generated at 2022-06-25 14:36:56.467996
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = 'grammar_0'
    try:
        os.remove(filename)
    except OSError:
        pass
    grammar_0 = Grammar()
    grammar_0.dump(filename)
    grammar_0.loads(open(filename, "rb").read())


# Generated at 2022-06-25 14:36:58.404749
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("pgen_dump")


# Generated at 2022-06-25 14:37:01.009419
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    filename = grammar.dump(test_Grammar_dump.__name__)
    assert os.path.exists(filename)
    os.remove(filename)



# Generated at 2022-06-25 14:37:03.044061
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    assert Grammar().dump("test_dump_grammar.out") == None



# Generated at 2022-06-25 14:37:09.613075
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Create the grammar
    grammar = Grammar()
    test_file = "/tmp/test.pkl"

    # Dump the tables to a file
    grammar.dump(test_file)

    # Load the tables from the file
    grammar_in = Grammar()
    grammar_in.load(test_file)

    # Check the tables
    assert grammar == grammar_in


if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1:
        grammar = Grammar()
        grammar.load(sys.argv[1])
        grammar.report()
    else:
        print("usage: python Grammar.py grammar.pkl")

# Generated at 2022-06-25 14:37:11.626895
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('/home/benjamin/pylint-env/.py3/lib/python3.6/grammar.pkl')


# Generated at 2022-06-25 14:37:14.245950
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('/tmp/grammar_dump_test.pkl')
    grammar_0.load('/tmp/grammar_dump_test.pkl')


# Generated at 2022-06-25 14:37:21.894857
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    path_0 = "test/test_grammar_data.dat"
    grammar_0.dump(path_0)


# Generated at 2022-06-25 14:37:26.206215
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    grammar_0 = Grammar()
    with open('tests/pickle-test-cases/test-case-0.pkl', 'rb') as f:
        g = pickle.load(f)
    grammar_0.load('tests/pickle-test-cases/test-case-0.pkl')
    assert grammar_0.__dict__ == g

# Generated at 2022-06-25 14:37:27.463424
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("Grammar.pickle")



# Generated at 2022-06-25 14:37:28.849593
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump("./syntax_grammar.pickle")


# Generated at 2022-06-25 14:37:40.886205
# Unit test for method load of class Grammar
def test_Grammar_load():
    f = tempfile.NamedTemporaryFile()
    grammar_0 = Grammar()
    grammar_0.dump(f.name)
    grammar_1 = Grammar()
    grammar_1.load(f.name)
    assert grammar_0.tokens == grammar_1.tokens
    assert grammar_0.async_keywords == grammar_1.async_keywords
    assert grammar_0.start == grammar_1.start
    assert grammar_0.keywords == grammar_1.keywords
    assert grammar_0.labels == grammar_1.labels
    assert grammar_0.number2symbol == grammar_1.number2symbol
    assert grammar_0.states == grammar_1.states
    assert grammar_0.dfas == grammar_1.dfas
    assert grammar_0.symbol

# Generated at 2022-06-25 14:37:42.114423
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("")


# Generated at 2022-06-25 14:37:44.742444
# Unit test for method load of class Grammar
def test_Grammar_load():
    case_0 = Grammar()
    with tempfile.NamedTemporaryFile() as f:
        case_0.dump(f.name)
        case_0.load(f.name)

# Generated at 2022-06-25 14:37:47.031878
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    file_0 = tempfile.TemporaryFile()
    grammar_0.dump(file_0)


# Generated at 2022-06-25 14:37:58.008500
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    # Non-existent file
    try:
        grammar_0.load('/nonexistent')
    except FileNotFoundError:
        pass
    else:
        #print('Failed to raise FileNotFoundError')
        raise AssertionError('Failed to raise FileNotFoundError')
    # Arbitrary file
    # Unpickleable
    try:
        grammar_0.loads(b'')
    except pickle.UnpicklingError:
        pass
    else:
        #print('Failed to raise UnpicklingError')
        raise AssertionError('Failed to raise UnpicklingError')
    # Corrupted
    try:
        grammar_0.loads(b'\x80\x02F\n.')
    except pickle.UnpicklingError:
        pass

# Generated at 2022-06-25 14:38:01.508851
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    assert grammar_0.load('/home/benjello/.vscode/extensions/ms-python.python-2020.7.96456/pythonFiles/PythonTools/pyc_grammar/Grammar.py')


# Generated at 2022-06-25 14:38:07.468289
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    filename_0 = "/tmp/grammar/dump.pkl"
    grammar_0.load(filename_0)


# Generated at 2022-06-25 14:38:11.062374
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('pytree.pgen')
    grammar_0.load('pytree.pgen')
    grammar_0.load('pytree.pgen')
    grammar_0.load('pytree.pgen')
    grammar_0.load('pytree.pgen')
    grammar_0.load('pytree.pgen')
    grammar_0.report()


# Generated at 2022-06-25 14:38:21.776655
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    import io
    grammar_0 = Grammar()

# Generated at 2022-06-25 14:38:24.500381
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("Grammar_0")
    return grammar_0


# Generated at 2022-06-25 14:38:35.448441
# Unit test for method load of class Grammar
def test_Grammar_load():
    fd, fname = tempfile.mkstemp()
    os.close(fd)

# Generated at 2022-06-25 14:38:41.561867
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("./Grammar.pickle")
    grammar_1 = Grammar()
    grammar_1.loads(grammar_0.dump("./Grammar.pickle"))
    grammar_1.dump("./Grammar_copy.pickle")

if __name__ == "__main__":
    # TODO: here we will generate a test file
    test_case_0()
    test_Grammar_load()

# Generated at 2022-06-25 14:38:45.424962
# Unit test for method load of class Grammar
def test_Grammar_load():
    path = 'test.pkl'
    grammar_0 = Grammar()
    grammar_0.dump(path)
    grammar_1 = Grammar()
    grammar_1.load(path)
    assert grammar_0 is not grammar_1
    assert grammar_0.__dict__ == grammar_1.__dict__
    try:
        os.remove(path)
    except OSError:
        pass


# Generated at 2022-06-25 14:38:47.722780
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    filename = "test_dump_file"
    grammar_0.dump(filename)


# Generated at 2022-06-25 14:38:51.225420
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load(r"C:\Users\luotao\PycharmProjects\python-tokenize\Lib\Grammar.py")


# Generated at 2022-06-25 14:38:58.260723
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()

# Generated at 2022-06-25 14:39:06.982745
# Unit test for method load of class Grammar
def test_Grammar_load():
    import test.support
    from test.support import TESTFN
    from io import BytesIO as StringIO

    try:
        os.remove(TESTFN)
    except OSError:
        pass

    # Create a pickle file
    f = open(TESTFN, "w")

# Generated at 2022-06-25 14:39:15.854614
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()

# Generated at 2022-06-25 14:39:18.952319
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('grammar.pickle')
    assert grammar_0 is not None


# Generated at 2022-06-25 14:39:21.257722
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('/tmp/poetry/23322-Grammar.pickle')
    grammar_0._update({})


# Generated at 2022-06-25 14:39:27.346885
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('./test/unit/out0.pkl')
    expected_0 = open("./test/unit/expected0.pkl", "rb").read()
    actual_0 = open("./test/unit/out0.pkl", "rb").read()
    assert actual_0 == expected_0
    grammar_1 = Grammar()
    grammar_1.dump('./test/unit/out1.pkl')
    expected_1 = open("./test/unit/expected1.pkl", "rb").read()
    actual_1 = open("./test/unit/out1.pkl", "rb").read()
    assert actual_1 == expected_1
    grammar_2 = Grammar()

# Generated at 2022-06-25 14:39:31.797710
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    with tempfile.NamedTemporaryFile(delete=False) as f:
        grammar.dump(f.name)
    os.remove(f.name)

if __name__ == "__main__":
    import unittest
    unittest.main()

# Generated at 2022-06-25 14:39:34.573709
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_1 = Grammar()
    grammar_1.load('/home/benjamin/anaconda3/lib/python3.7/site-packages/tables/grammar_table')


# Generated at 2022-06-25 14:39:43.204007
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = "foo.pkl"
    grammar_0 = test_case_0()
    grammar_0.load(filename)

if __name__ == "__main__":
    import sys

    def _n(filename: Path) -> None:
        grammar_0 = Grammar()
        grammar_0.load(filename)
        sys.stdout.write(
            "s2n:\n" + str(grammar_0.symbol2number) + "\n"
        )
        sys.stdout.write(
            "n2s:\n" + str(grammar_0.number2symbol) + "\n"
        )
        sys.stdout.write("states:\n" + str(grammar_0.states) + "\n")

# Generated at 2022-06-25 14:39:45.371498
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = "some file"
    grammar_0.load(filename)


# Generated at 2022-06-25 14:39:48.126807
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    filename = tempfile.NamedTemporaryFile().name
    grammar.dump(filename)
    os.remove(filename)

# Generated at 2022-06-25 14:40:01.110031
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump(b'temp.cpython-37.pickle')
    grammar.load('temp.cpython-37.pickle')

# Generated at 2022-06-25 14:40:02.512401
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_dump = Grammar()
    grammar_dump.dump(grammar_dump)


# Generated at 2022-06-25 14:40:11.889426
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = "./data/Grammar/Grammar_load.txt"  # EXAMPLE FILE; NOT USED IN UNIT TEST
    grammar_0 = Grammar()
    grammar_0.load(filename)
    assert grammar_0.symbol2number == {}, "symbol2number wrong: {}".format(grammar_0.symbol2number)
    assert grammar_0.number2symbol == {}, "number2symbol wrong: {}".format(grammar_0.number2symbol)
    assert grammar_0.states == [], "states wrong: {}".format(grammar_0.states)
    assert grammar_0.dfas == {}, "dfas wrong: {}".format(grammar_0.dfas)

# Generated at 2022-06-25 14:40:15.423997
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    try:
        grammar_0.dump("/tmp/grammar.out")
    except:
        pass
    else:
        raise AssertionError


# Generated at 2022-06-25 14:40:21.736876
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    #import sys
    #if len(sys.argv) > 1:
    #    filename = sys.argv[1]
    #else:
    #    filename = 'Grammar.dump'

    # Use a temporary file.
    fd, filename = tempfile.mkstemp()
    os.close(fd)
    unlink = True

    grammar = Grammar()
    grammar.dump(filename)

    if unlink:
        os.unlink(filename)



# Generated at 2022-06-25 14:40:30.314546
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .conv import convert
    from .pgen import driver

    grammar = convert(driver.parse_grammar('Grammar.txt'))
    # Replace in_file by temp file so it does not pollute the directory
    # and is easy to remove
    temp_grammar = os.path.join(os.path.dirname(__file__), "__Grammar.pickle")
    grammar.dump(temp_grammar)
    new_grammar = Grammar()
    new_grammar.load(temp_grammar)
    assert new_grammar.labels == grammar.labels

test_Grammar_load()

# Generated at 2022-06-25 14:40:32.504585
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump(str())



# Generated at 2022-06-25 14:40:34.667619
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("example.pickle")
    os.unlink("example.pickle")


# Generated at 2022-06-25 14:40:35.889249
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load('Grammar.pkl')


# Generated at 2022-06-25 14:40:43.338945
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.symbol2number = {'and': 257, 'POLY': 258, '(': 259, ')': 260, 'NAME': 261, 'NUM': 262, 'PLUS': 263, 'MINUS': 264, 'STAR': 265, 'SLASH': 266}
    grammar.number2symbol = {257: 'and', 258: 'POLY', 259: '(', 260: ')', 261: 'NAME', 262: 'NUM', 263: 'PLUS', 264: 'MINUS', 265: 'STAR', 266: 'SLASH'}
    grammar.states = [[(0, 1), (-1, 2)], [(259, 1), (261, 1), (0, 2)], [(260, 1), (0, 3)], []]

# Generated at 2022-06-25 14:40:50.343900
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load('Grammar.pickle')


# Generated at 2022-06-25 14:40:52.914773
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = test_case_0()
    for fname in ("Grammar.pkl", "Grammar.pyd"):
        grammar_0.load(fname)

test_Grammar_load()

# Generated at 2022-06-25 14:40:54.509782
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load("Grammar_pgen.py")



# Generated at 2022-06-25 14:41:01.770843
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(os.path.join(os.path.dirname(os.path.realpath(__file__)), "Grammar.pkl"))

# Generated at 2022-06-25 14:41:06.393820
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("./test/data/Grammar.8.pickle")
    grammar.report()


if __name__ == "__main__":
    test_case_0()
    test_Grammar_load()

# Generated at 2022-06-25 14:41:08.981568
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("./out.pkl")



# Generated at 2022-06-25 14:41:13.040334
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    fd, gramfile = tempfile.mkstemp()
    grammar_1.dump(gramfile)
    os.close(fd)
    grammar_2 = Grammar()
    grammar_2.load(gramfile)
    os.remove(gramfile)

test_case_0()
test_Grammar_dump()
print("Done.")

# Generated at 2022-06-25 14:41:15.687610
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("/tmp/pyi-dir-Grammar-Grammar" + "grammar_0")
    pass



# Generated at 2022-06-25 14:41:18.020372
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    if grammar.load == grammar.load:
        pass


# Generated at 2022-06-25 14:41:26.821221
# Unit test for method load of class Grammar
def test_Grammar_load():
    gram_1 = Grammar()
    gram_1.start = 256

    gram_1.keywords = {"abc": 257}
    gram_1.tokens = {"+": 259}
    gram_1.symbol2number = {"abc": 256}
    gram_1.number2symbol = {256: "abc"}
    gram_1.symbol2label = {"abc": 257}
    gram_1.labels = [(0, "EMPTY"), (257, "abc")]
    gram_1.states = [[[(259, 1)]]]
    gram_1.dfas = {
        256: ([[(259, 1)]], {258: 1}),
    }

    gram_1.dump("test.pkl")

    gram_2 = Grammar()

# Generated at 2022-06-25 14:41:41.567184
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load('nuitka/PythonGrammar25.pickle')
    grammar_1.load('nuitka/PythonGrammar27.pickle')
    grammar_1.load('nuitka/PythonGrammar30.pickle')
    grammar_1.load('nuitka/PythonGrammar32.pickle')


# Generated at 2022-06-25 14:41:45.353698
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load('/Users/cpz/PycharmProjects/ruamel.pgen2/ruamel/pgen2/pgen2/Grammar.py.pickle'.lower())


# Generated at 2022-06-25 14:41:46.981192
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('/tmp/grammar.pkl')


# Generated at 2022-06-25 14:41:49.691511
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('/tmp/grammar_test_case_0_0.tmp')


# Generated at 2022-06-25 14:41:57.511177
# Unit test for method load of class Grammar
def test_Grammar_load():
    #
    # Create a temporary file and dump the dictionary to it
    #
    temp_fd, temp_path = tempfile.mkstemp()
    os.close(temp_fd)

# Generated at 2022-06-25 14:41:59.069917
# Unit test for method load of class Grammar
def test_Grammar_load():
    # test_case_0()
    grammar_0 = Grammar()
    grammar_0.load("pgen_grammar.pickle")  # Calls load()



# Generated at 2022-06-25 14:42:01.784778
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()

    grammar.load(b'pygram.pkl')

    grammar.loads(b'pygram.pkl')


# Generated at 2022-06-25 14:42:03.280395
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("abc")


# Generated at 2022-06-25 14:42:05.847565
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_dump = Grammar()
    grammar_dump.dump("test_case_0")


# Generated at 2022-06-25 14:42:14.386056
# Unit test for method load of class Grammar
def test_Grammar_load():
    # read the grammar tables
    g_1 = Grammar()
    g_1.load('data/Grammar.pkl')
    # assert the grammar's start symbol is the number 256
    assert (g_1.start == 256)
    # assert the grammar's start symbol is the string 'file_input'
    assert (g_1.number2symbol[256] == 'file_input')
    # assert the grammar's start symbol is 'file_input'
    assert ('file_input' in g_1.symbol2number)
    # assert the grammar's start symbol 'file_input' maps to 256
    assert (g_1.symbol2number['file_input'] == 256)


# Generated at 2022-06-25 14:42:33.847142
# Unit test for method load of class Grammar
def test_Grammar_load():
    G = Grammar()

# Generated at 2022-06-25 14:42:36.597809
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    a = g.load("testdata/grammar1.pkl")
    b = g.load("testdata/grammar2.pkl")


# Generated at 2022-06-25 14:42:44.188761
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("lib2to3/Grammar.pickle")

# Generated at 2022-06-25 14:42:46.780002
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    filename = os.path.join(os.path.dirname(__file__), "Grammar.pkl")
    grammar_0.dump(filename)





# Generated at 2022-06-25 14:42:52.096751
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pytest
    import tempfile
    tmpdir = tempfile.TemporaryDirectory()
    grammar_0 = Grammar()
    filename_0 = os.path.join(tmpdir.name, "dump")
    grammar_0.dump(filename_0)
    grammar_0.dump(filename_0)


# Generated at 2022-06-25 14:42:57.765072
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    from typing import Dict, List, Tuple
    grammar_0 = Grammar()
    grammar_0.dump("parse.tables.pickle")
    dfa_0: List[List[Tuple[int, int]]] = []
    dfas_0: Dict[int, Tuple[List[List[Tuple[int, int]]], Dict[int, int]]] = {}
    labels_0: List[Tuple[int, Optional[str]]] = [(0, "EMPTY")]
    number2symbol_0: Dict[int, str] = {"86": "d"}
    symbol2number_0: Dict[str, int] = {"d": 86}
    keywords_0: Dict[str, int] = {}
    tokens_0: Dict[int, int] = {}

# Generated at 2022-06-25 14:43:01.569850
# Unit test for method dump of class Grammar
def test_Grammar_dump():
 
    # Create a temporary file to test the dump method
    tmp_f = tempfile.NamedTemporaryFile()
    filename = tmp_f.name
    del tmp_f
 
    # Create a Grammar object and try to dump it
    grammar_0 = Grammar()
    grammar_0.dump(filename)

# Generated at 2022-06-25 14:43:03.031556
# Unit test for method load of class Grammar
def test_Grammar_load():
    assert Grammar().load('./data/Grammar.pickle') is None


# Generated at 2022-06-25 14:43:05.030498
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = "build/parser.pickle"
    grammar = Grammar()
    grammar.load(filename)



# Generated at 2022-06-25 14:43:10.773164
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    with open("<setup>") as f:
        grammars = pickle.load(f)
    for grammar in grammars:
        grammar.dump("<setup>")
        grammar_1 = Grammar()
        grammar_1.load("<setup>")
        assert grammar_1.__dict__ == grammar.__dict__

# Generated at 2022-06-25 14:43:55.746106
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    with pytest.raises(TypeError):
        grammar_0.load()



# Generated at 2022-06-25 14:43:56.526458
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    filename = ""

    grammar_0.load(filename)


# Generated at 2022-06-25 14:43:58.485748
# Unit test for method load of class Grammar
def test_Grammar_load():
    test_object = Grammar()
    test_object.load("./tests/data/grammar_0.pkl")


# Generated at 2022-06-25 14:44:03.247055
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    tmp_path = tempfile.mkdtemp()
    tmp_file = tempfile.NamedTemporaryFile(dir=tmp_path)
    grammar_0 = Grammar()
    grammar_0.dump(tmp_file.name)
    os.remove(tmp_file.name)
    os.rmdir(tmp_path)


# Generated at 2022-06-25 14:44:06.054816
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    # Pickle file written by dump() in python/lib/python3.8/_compile_pyc.py
    grammar_0.load("./tests/pgen/data/Grammar.pickle")


# Generated at 2022-06-25 14:44:09.059434
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load(None)



# Generated at 2022-06-25 14:44:10.407284
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('test_grammar.pickle')


# Generated at 2022-06-25 14:44:17.998627
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_dump_0 = Grammar()
    grammar_dump_0.dump('/tmp/pygram_0.6.4_grammar_dump.dat')
    grammar_dump_1 = Grammar()
    grammar_dump_1.load('/tmp/pygram_0.6.4_grammar_dump.dat')
    assert grammar_dump_0.symbol2number == grammar_dump_1.symbol2number
    assert grammar_dump_0.keywords == grammar_dump_1.keywords
    assert grammar_dump_0.dfas == grammar_dump_1.dfas
    assert grammar_dump_0.number2symbol == grammar_dump_1.number2symbol
    assert grammar_dump_0.tokens == grammar_dump_1.tokens
    assert grammar_dump_0.lab

# Generated at 2022-06-25 14:44:25.577403
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import tokenize

    gram = Grammar()
    tokenize.tokenize_from_file(
        gram.load, 'Lib/Lib/pgen2/pgen.out', 'exec', 'utf-8'
    )

if __name__ == '__main__':
    test_case_0()
    test_Grammar_load()
    print('All Done')

# Import a grammar in the old format used by conv.py.  This is not
# used normally; it's only used by the test suite.

from .conv import convert

# Generated at 2022-06-25 14:44:26.365695
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load(suffix=None)


# Generated at 2022-06-25 14:46:01.952516
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    # Empty file
    filename = tempfile.mkstemp()[1]
    grammar.load(filename)
    assert grammar.keywords == {}
    assert grammar.labels == [(0, 'EMPTY')]
    assert grammar.number2symbol == {}
    assert grammar.start == 256
    assert grammar.states == []
    assert grammar.symbol2label == {}
    assert grammar.symbol2number == {}
    assert grammar.tokens == {}
    # Real file
    from . import pgen
    grammar = pgen.generate_grammar()
    filename = tempfile.mkstemp()[1]
    grammar.dump(filename)
    new_grammar = Grammar()
    new_grammar.load(filename)
    assert new_grammar.keywords == {}
   

# Generated at 2022-06-25 14:46:05.837739
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    grammar_0 = Grammar()

    # Call Grammar.dump from function test_case_0
    grammar_0.dump("C:\\Users\\Cristina\\PycharmProjects\\pycparser-master\\pycparser\\ply\\yacc.py")



# Generated at 2022-06-25 14:46:09.454512
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    try:
        grammar_1.load("./pgen2/Grammar.pickle")
    except Exception as e:
        print(e)


if __name__ == "__main__":
    test_case_0()
    test_Grammar_load()

# Generated at 2022-06-25 14:46:10.879908
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("file_name_17")



# Generated at 2022-06-25 14:46:11.936398
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """
    Test dump(filename: Path)
    """
    pass



# Generated at 2022-06-25 14:46:13.373945
# Unit test for method load of class Grammar
def test_Grammar_load():
    assert(grammar_0.load)


# Generated at 2022-06-25 14:46:16.090666
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    dummy_file = tempfile.NamedTemporaryFile()
    grammar_0.dump(dummy_file)


# Generated at 2022-06-25 14:46:17.074745
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("./grammar_test.txt")


# Generated at 2022-06-25 14:46:19.974473
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    try:
        from tempfile import gettempdir as tempdir
    except ImportError:
        from os import gettempdir as tempdir
    gram = Grammar()
    gram.dump(os.path.join(tempdir(), "S"))


# Generated at 2022-06-25 14:46:21.735204
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    assert grammar_1.dump('/tmp/test_Grammar_dump_0.pkl') == None
