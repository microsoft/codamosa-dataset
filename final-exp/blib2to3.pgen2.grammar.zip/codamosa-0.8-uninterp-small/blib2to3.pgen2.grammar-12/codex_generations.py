

# Generated at 2022-06-25 14:36:48.455313
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """
    Grammar.dump() should dump a file and the contents of that file
    should be pickleable
    """
    grammar = Grammar()
    with tempfile.NamedTemporaryFile(delete=False) as f:
        filename = f.name
    grammar.dump(filename)
    grammar = Grammar()  # clear grammar in memory
    grammar.load(filename)



# Generated at 2022-06-25 14:36:55.558831
# Unit test for method load of class Grammar
def test_Grammar_load():

    grammar = Grammar()
    grammar.start = 258
    grammar.keywords = {'if': 1}
    grammar.number2symbol = {257: 'foo', 258: 'bar'}
    grammar.tokens = {258: 5}
    grammar.symbol2number = {'foo': 257, 'bar': 258}
    grammar.labels = [(0, 'EMPTY'), (258, None), (2, 'if')]
    grammar.states = [[(1, 1), (0, 1), (2, 0)]]
    grammar.dfas = {258: ([[(1, 1), (0, 1), (2, 0)]], {1: 2, 0: 2})}

    saved_grammar = Grammar()
    saved_grammar.start = 258

# Generated at 2022-06-25 14:36:58.570347
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('/test/test_grammar/test1.pickle')



# Generated at 2022-06-25 14:36:59.487571
# Unit test for method load of class Grammar
def test_Grammar_load():
    assert True


# Generated at 2022-06-25 14:37:08.240049
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_1 = Grammar()
    grammar_1.load(os.path.abspath(__file__))
    grammar_1.load(".")
    grammar_1.load("..")
    grammar_2 = Grammar()
    grammar_2.load(__file__)
    grammar_2.load("<lambda>")
    grammar_3 = Grammar()
    grammar_3.load(__file__)
    grammar_3.load("<lambda>")
    grammar_4 = Grammar()
    grammar_4.load(__file__)
    grammar_4.load("<lambda>")
    grammar_5 = Grammar()
    grammar_5.load(__file__)
    grammar_5.load("<lambda>")
    grammar_6 = Grammar()
   

# Generated at 2022-06-25 14:37:09.509117
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    _test_load(grammar_1)


# Generated at 2022-06-25 14:37:12.657823
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar_dump = grammar.dump
    assert grammar_dump!= None
    try:
        grammar_dump()
    except AttributeError as e:
        pass
    else: 
        assert False


# Generated at 2022-06-25 14:37:23.464547
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import tempfile
    import os
    import pickle
    from typing import Dict, List
    grammar_1 = Grammar()
    grammar_1.symbol2number = {'async_stmt': 257}
    grammar_1.number2symbol = {257: 'async_stmt'}
    grammar_1.states = [[(1, 1), (0, 0)], [(1, 0), (0, 1)]]
    grammar_1.dfas = {257: ([[(1, 1), (0, 0)], [(1, 0), (0, 1)]], {256: 1})}
    grammar_1.labels = [(0, 'EMPTY'), (257, None), (256, None)]
    grammar_1.keywords = {'await': 257}

# Generated at 2022-06-25 14:37:25.597515
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    # test_Grammar_dump_0_0
    grammar_0.dump("grammar_0.pickle")


# Generated at 2022-06-25 14:37:27.609948
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('fixtures/sample_grammar.pickle')


# Generated at 2022-06-25 14:37:32.982386
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    filename = '/tmp/pgen'
    grammar.dump(filename)



# Generated at 2022-06-25 14:37:36.036059
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    filename = 'example.pkl'
    grammar_0.dump(filename)
    assert os.path.isfile(filename)
    os.remove(filename)


# Generated at 2022-06-25 14:37:36.605682
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # No-op
    return


# Generated at 2022-06-25 14:37:37.883886
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = pth('Grammar.pk')
    grammar_1 = Grammar()
    grammar_1.load(filename)


# Generated at 2022-06-25 14:37:40.530536
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    global grammar_0
    if grammar_0 is None:
        test_case_0()
    global f
    f = tempfile.NamedTemporaryFile(delete=False)
    try:
        grammar_0.dump(f.name)
    finally:
        if not f.closed:
            f.close()


# Generated at 2022-06-25 14:37:41.771986
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    assert grammar_0.dump(filename,dfcfcdf) == None


# Generated at 2022-06-25 14:37:43.334612
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump(r"test/Grammar")


# Generated at 2022-06-25 14:37:45.066311
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("../Parser/Grammar.pickle")



# Generated at 2022-06-25 14:37:50.586098
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import sys
    import os.path as path

    grammar = Grammar()

    grammar.dump(path.realpath(path.join(path.dirname(__file__), 'Grammar.pickle')))
    assert path.isfile(path.realpath(path.join(path.dirname(__file__), 'Grammar.pickle'))) == True
    os.remove(path.realpath(path.join(path.dirname(__file__), 'Grammar.pickle')))


# Generated at 2022-06-25 14:38:00.865272
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_1 = Grammar()
    grammar_0.symbol2number = {'from': 266, 'import': 267, '*': 269, 'as': 270, ',': 271, ':': 272}
    grammar_0.number2symbol = {266: 'from', 267: 'import', 269: '*', 270: 'as', 271: ',', 272: ':'}

# Generated at 2022-06-25 14:38:05.774760
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump(os.path.join(tempfile.gettempdir(), 'python_grammar.pkl'))



# Generated at 2022-06-25 14:38:06.745423
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load(filename=const_0)



# Generated at 2022-06-25 14:38:10.427286
# Unit test for method load of class Grammar
def test_Grammar_load():
    from tmpdir import Tempdir
    from os.path import basename
    from pickle import dumps
    d = Tempdir()
    g = d.mksubfile(basename(__file__), 'wb', dumps(grammar_0.__getstate__(),4))
    grammar_1 = Grammar()
    grammar_1.load(g)
    assert grammar_0==grammar_1
    d.deltree()


# Generated at 2022-06-25 14:38:15.071892
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()

    # Pickle the grammar to a file, then load it back in
    import pickle

    pickle.dump(g, open('/tmp/pygram.pkl', 'wb'))
    g2 = Grammar()
    g2.load('/tmp/pygram.pkl')
    g3 = Grammar()
    g3.loads(pickle.dumps(g))


if __name__ == "__main__":
    import unittest

    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(test_case_0))
    runner = unittest.TextTestRunner()
    runner.run(suite)

# Generated at 2022-06-25 14:38:20.444510
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_load = Grammar()

    # TODO: implement Grammar.load()
    raise NotImplementedError()
    # try:
    #     pickle.dumps(grammar_load)
    # except Exception as e:
    #     assert False, e


# Generated at 2022-06-25 14:38:23.407805
# Unit test for method load of class Grammar
def test_Grammar_load():

    grammar = Grammar()
    tmp_grammar = grammar.__class__()
    grammar.load("pgen_data/Grammar.txt")
    assert grammar.__dict__ == tmp_grammar.__dict__

# Generated at 2022-06-25 14:38:25.847546
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    grammar_0 = Grammar()

    grammar_0.dump(None)



# Generated at 2022-06-25 14:38:27.984805
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    Grammar.dump(grammar_0, "/home/rodrigo/src/grammar-test/test.txt")


# Generated at 2022-06-25 14:38:30.862685
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), 'grammar.pkl'))

# Generated at 2022-06-25 14:38:32.596969
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('test_grammar_files/grammar_test_case_1')



# Generated at 2022-06-25 14:38:44.103658
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Load the grammar from an empty pickle file
    grammar = Grammar()
    grammar.load(__file__.replace(".py", ".empty_pkl"))
    assert isinstance(grammar.symbol2number, dict)
    assert isinstance(grammar.number2symbol, dict)
    assert isinstance(grammar.states, list)
    assert isinstance(grammar.dfas, dict)
    assert isinstance(grammar.labels, list)
    assert isinstance(grammar.start, int)
    assert grammar.start == -1
    assert isinstance(grammar.keywords, dict)
    assert isinstance(grammar.tokens, dict)


if __name__ == "__main__":
    test_case_0()
    test_Grammar_load()

# Generated at 2022-06-25 14:38:46.477350
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # dump(self, filename: str)
    grammar_0 = Grammar()
    try:
        grammar_0.dump('/home/benjamin/workspace/python-stdlib/Lib/test/data/junk')
    except IOError as e:
        pass



# Generated at 2022-06-25 14:38:49.287821
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("/home/hgeunlee/PycharmProjects/untitled1/pycparser/utils/")


# Generated at 2022-06-25 14:38:51.835494
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump(r"C:\Users\jrubio\Documents\prueba.pkl")


# Generated at 2022-06-25 14:38:53.723751
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    # FileNotFoundError
    try:
        grammar_0.dump(None)
    except FileNotFoundError:
        pass


# Generated at 2022-06-25 14:38:55.073086
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    assert grammar_0.dump('.') == None


# Generated at 2022-06-25 14:38:59.734717
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    assert isinstance(g.states, list)
    assert isinstance(g.dfas, dict)
    assert isinstance(g.labels, list)
    assert isinstance(g.keywords, dict)
    assert isinstance(g.tokens, dict)
    assert isinstance(g.symbol2label, dict)
    assert isinstance(g.symbol2number, dict)
    assert isinstance(g.number2symbol, dict)
    assert isinstance(g.start, int)

# Generated at 2022-06-25 14:39:01.296377
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    Path = os.path.join(tempfile.gettempdir(), "grammar.tables")
    grammar_0.dump(Path)


# Generated at 2022-06-25 14:39:03.201724
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_1 = Grammar()
    grammar_0.load("test.pickle")
    grammar_1.loads("pickled_grammar_0")


# Generated at 2022-06-25 14:39:09.295865
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_2 = Grammar()
    grammar_3 = Grammar()
    grammar_4 = Grammar()
    grammar_5 = Grammar()
    grammar_6 = Grammar()
    grammar_7 = Grammar()
    grammar_8 = Grammar()
    grammar_9 = Grammar()
    grammar_10 = Grammar()
    grammar_1.dump("tests/data/grammar-json-grammar")
    grammar_2.dump("tests/data/grammar-json")
    grammar_3.dump("tests/data/grammar-python-grammar")
    grammar_4.dump("tests/data/grammar-python")
    grammar_5.dump("tests/data/grammar-python-3-grammar")

# Generated at 2022-06-25 14:39:16.412334
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Test exception raising
    # tests.support.run_unittest(GrammarTestCase)
    grammar_0 = Grammar()
    filename_0 = "test.pkl"
    grammar_0.dump(filename_0)

if __name__ == "__main__":
    test_case_0()
    test_Grammar_dump()

# Generated at 2022-06-25 14:39:18.989385
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("tests/testdata/Grammar_dump_0")


# Generated at 2022-06-25 14:39:22.078986
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar1 = Grammar()
    grammar_0 = test_case_0()
    pickle.load(grammar_0)
    grammar1.load(grammar_0)
    grammar1.report()


# Generated at 2022-06-25 14:39:23.437533
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = None
    grammar_0 = Grammar()
    grammar_0.dump(filename)


# Generated at 2022-06-25 14:39:24.619999
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump('test_Grammar_dump')


# Generated at 2022-06-25 14:39:27.062849
# Unit test for method load of class Grammar
def test_Grammar_load():
    # test_case_1
    grammar_1 = Grammar()



# Generated at 2022-06-25 14:39:30.065102
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # .pickle file already generated by pgen module
    grammar_0 = Grammar()
    grammar_0.load("grammar.pickle")
    grammar_0.dump("dump.pickle")
    assert True


# Generated at 2022-06-25 14:39:32.721076
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("tests/test_grammar_tree.pickle")


# Generated at 2022-06-25 14:39:37.114825
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os, sys
    tempFile = tempfile.NamedTemporaryFile()
    try:
        from test import test_grammar
        g = test_grammar
    except ImportError:
        g = Grammar()
    g.dump(tempFile.name)
    g.load(tempFile.name)
    os.remove(tempFile.name)


# Generated at 2022-06-25 14:39:40.251984
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('dump.txt')
    grammar_0 = Grammar()
    grammar_0.load('dump.txt')


# Generated at 2022-06-25 14:39:46.024557
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump("<Path>")


# Generated at 2022-06-25 14:39:50.781113
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    fd, filename = tempfile.mkstemp()
    with open(filename, 'w') as f:
        grammar_1.dump(f)
    os.close(fd)
    os.remove(filename)


# Generated at 2022-06-25 14:39:53.028376
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Make sure dump works with no filename
    grammar_0 = Grammar()
    try:
        grammar_0.dump()
    except IOError:
        pass



# Generated at 2022-06-25 14:39:54.628034
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Unit test for method load of class Grammar"""
    grammar = Grammar()
    grammar.load("./pgen_0")


# Generated at 2022-06-25 14:39:57.575570
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump("/tmp/test-grammar.pickle")
    grammar_2 = Grammar()
    grammar_2.load("/tmp/test-grammar.pickle")

test_case_0()
test_Grammar_dump()

# Generated at 2022-06-25 14:40:03.158383
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load("Python37/Grammar.pkl")

# Generated at 2022-06-25 14:40:04.404149
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.s = [1]
    grammar_0.t = [1]
    grammar_0.load('boyle')


# Generated at 2022-06-25 14:40:05.445563
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('/tmp/grammar_0.dump')



# Generated at 2022-06-25 14:40:07.441988
# Unit test for method dump of class Grammar
def test_Grammar_dump():
        grammar_1 = Grammar()
        #case1
        grammar_1.dump("./test.pickle")


# Generated at 2022-06-25 14:40:09.806077
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('/tmp/_pytest/test_grammar.py')


# Generated at 2022-06-25 14:40:16.376964
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    temp_file = tempfile.NamedTemporaryFile(delete=False)
    grammar_0.dump(temp_file.name)
    temp_file.close()
    os.remove(temp_file.name)


# Generated at 2022-06-25 14:40:19.367889
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    try:
        grammar_0.dump('<temp>')
    except IOError:
        # Covered by test_Grammar_dump_ioerror
        pass


# Generated at 2022-06-25 14:40:23.378667
# Unit test for method load of class Grammar
def test_Grammar_load():
    try:
        os.remove("Grammar.pickle")
    except FileNotFoundError:
        pass
    grammar_1 = Grammar()
    grammar_1.dump("Grammar.pickle")
    grammar_2 = Grammar()
    grammar_2.load("Grammar.pickle")
    os.remove("Grammar.pickle")


# Generated at 2022-06-25 14:40:24.929699
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/tmp/parser-test")



# Generated at 2022-06-25 14:40:29.253522
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar_load_0 = grammar.load('/Users/benjamin/Documents/workspace/pegen/tests/support_files/grammar.pickle')


# Generated at 2022-06-25 14:40:33.174138
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    def Grammar_dump():
        out = tempfile.mktemp()
        f = tempfile.TemporaryFile()
        grammar_0 = Grammar()
        grammar_0.dump(out)
    try:
        Grammar_dump()
    except:
        pass


# Generated at 2022-06-25 14:40:36.256829
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Create an instance of class Grammar
    grammar = Grammar()
    # Load the grammar tables from a pickle file
    filename = "filename"
    try:
        grammar.load(filename)
    except:
        # We expect this call to raise an IOError
        pass


# Generated at 2022-06-25 14:40:38.617047
# Unit test for method load of class Grammar
def test_Grammar_load():
    pytree_0 = Grammar()
    pytree_1 = Grammar()
    # test example
    pytree_1.load(pytree_0)


# Generated at 2022-06-25 14:40:41.854602
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    with open("test_grammar_pickle", "rb") as f:
        pkl = f.read()
        grammar_1.loads(pkl)
    grammar_2 = grammar_1.copy()
    grammar_1.loads(pkl)
    return grammar_1, grammar_2


# Generated at 2022-06-25 14:40:47.897693
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.symbol2number = {}
    grammar.number2symbol = {}
    grammar.states = []
    grammar.dfas = {}
    grammar.labels = [(0, "EMPTY")]
    grammar.keywords = {}
    grammar.tokens = {}
    grammar.symbol2label = {}
    grammar.start = 256
    grammar.dump("1.grammar")
    grammar.load("1.grammar")

if __name__ == "__main__":
    print(opmap)

# Generated at 2022-06-25 14:40:55.583428
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from tempfile import TemporaryFile
    from pickle import HIGHEST_PROTOCOL
    # Test for path-like objects
    with TemporaryFile() as ostream:
        Grammar().dump(ostream)
    # Test for file-like objects
    with TemporaryFile() as ostream:
        Grammar().dump(ostream)



# Generated at 2022-06-25 14:40:56.987527
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    test_pickle_path_0: Path = "None"
    grammar_0.dump(test_pickle_path_0)


# Generated at 2022-06-25 14:41:01.123213
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    value_0 = pickle.load(open("parse_grammar.pickle", "rb"))
    grammar_0.load("parse_grammar.pickle")
    grammar_0_0 = grammar_0
    grammar_0_0.start


# Generated at 2022-06-25 14:41:03.829714
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    assert callable(Grammar.dump)
    assert isinstance(Grammar.dump(object()), None)



# Generated at 2022-06-25 14:41:10.328862
# Unit test for method load of class Grammar
def test_Grammar_load():
    open = open
    grammar_0 = Grammar()
    filename = 'test_file_tmp'
    grammar_0.dump(filename)
    grammar_0.load(filename)
    grammar_0.dump(filename)
    grammar_0.load(filename)
    grammar_0.dump(filename)
    grammar_0.load(filename)
    os.remove(filename)


# Generated at 2022-06-25 14:41:11.074491
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump()



# Generated at 2022-06-25 14:41:14.340628
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("./frozen_grammar.pickle")
    grammar_0.report()

# Generated at 2022-06-25 14:41:17.658051
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar_dump = grammar.dump
    grammar_dump_value = grammar.dump()
    assert grammar_dump_value is None, grammar_dump_value


# Generated at 2022-06-25 14:41:22.250759
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0_copy = grammar_0.copy()
    grammar_0.dump("/tmp/grammar_0.pickle")

    grammar_1 = Grammar()
    grammar_1.load("/tmp/grammar_0.pickle")
    assert grammar_1 == grammar_0_copy


# Generated at 2022-06-25 14:41:24.498166
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = 'Grammar.dat'
    grammar = Grammar()
    grammar.dump(filename)
    grammar.load(filename)
    grammar.report()


# Generated at 2022-06-25 14:41:32.863055
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar0 = Grammar()
    with tempfile.NamedTemporaryFile(delete=False) as f:
        grammar0.dump(f.name)
    os.remove(f.name)


# Generated at 2022-06-25 14:41:33.966929
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # test the dump function
    grammar_0 = Grammar()
    grammar_0.dump('Grammar_dump_0.out')



# Generated at 2022-06-25 14:41:36.427408
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump('/home/daniel/src/python/mypy/mypy/typing/tests/test.pkl')



# Generated at 2022-06-25 14:41:38.382790
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("/Users/marinagratzer/Code/compsci/python-parsing/Grammar-f572d96a7bc8/Grammar/Grammar/Grammar_load_0.out")



# Generated at 2022-06-25 14:41:39.946438
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("Grammar.dump")
    g2 = Grammar()
    g2.load("Grammar.dump")
    assert g2.async_keywords == False


# Generated at 2022-06-25 14:41:42.624446
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump(tempfile.mkstemp()[1])


# Generated at 2022-06-25 14:41:45.220248
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("test.pkl")
    grammar1 = Grammar()
    grammar1.load("test.pkl")


# Generated at 2022-06-25 14:41:46.330729
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump('pickle')


# Generated at 2022-06-25 14:41:48.218701
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()


# Generated at 2022-06-25 14:41:51.473100
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    _filename = os.path.join(os.path.dirname(__file__), "temp.pkl")
    # ERROR: assert_raises
    grammar_0.dump(  # type: ignore
        _filename
    )


# Generated at 2022-06-25 14:42:02.082227
# Unit test for method load of class Grammar
def test_Grammar_load():
    from io import BytesIO
    from pickle import HIGHEST_PROTOCOL, dump

    grammar_0 = Grammar()

# Generated at 2022-06-25 14:42:11.542123
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    if os.path.exists("Grammar.pickle"):  # load from local file
        g.load("Grammar.pickle")

# Generated at 2022-06-25 14:42:20.104752
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()

# Generated at 2022-06-25 14:42:23.622096
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    if (not g.load(os.path.join(os.path.dirname(__file__), "Grammar.pickle"))):
        assert False


# Generated at 2022-06-25 14:42:31.807155
# Unit test for method load of class Grammar
def test_Grammar_load():

    grammar_1 = Grammar()
    grammar_2 = Grammar()

    # Dump it to a pickle file
    grammar_1.dump("test/Grammar_load.pickle")

    # Load it from the pickle file
    grammar_2.load("test/Grammar_load.pickle")

    from pprint import pprint

    # Are the dumped and loaded grammars the same?
    if grammar_1.symbol2number != grammar_2.symbol2number:
        pprint(grammar_1.symbol2number)
        pprint(grammar_2.symbol2number)

        assert(False)

    if grammar_1.number2symbol != grammar_2.number2symbol:
        pprint(grammar_1.number2symbol)

# Generated at 2022-06-25 14:42:33.801673
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    assert grammar_0.dump("grammar_0.dump") == None



# Generated at 2022-06-25 14:42:37.447094
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load(bytes.fromhex('0a0018706172656e745f6d616e6167656d656e745f6c656e6774683a1c0a000a706172656e745f696e69745f6d6f64650a0a0018706172656e745f6d616e6167656d656e745f6c656e6774683a1c0a000a706172656e745f696e69745f6d6f64650a0a000a706172656e745f696e69745f6d6f64650a0a000a706172656e745f696e69745f6d6f6465'))


# Generated at 2022-06-25 14:42:38.333056
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()


# Generated at 2022-06-25 14:42:39.905370
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('/tmp/grammar_0.out')



# Generated at 2022-06-25 14:42:42.820281
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    path = "grammar.pickle"
    grammar_0.load(path)


# Generated at 2022-06-25 14:42:51.784627
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump("C:/Users/neeky/PycharmProjects/untitled/antlr4_3_4/pgen_parsing/data/Grammar.pickle")


# Generated at 2022-06-25 14:42:52.638393
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    test_case_0()



# Generated at 2022-06-25 14:42:54.276677
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load('./data/Grammar.pickle')


# Generated at 2022-06-25 14:42:55.277450
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    x = Grammar()
    x.dump('test')


# Generated at 2022-06-25 14:42:56.630097
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load('Grammar.pickle')


# Generated at 2022-06-25 14:43:00.029088
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    with tempfile.NamedTemporaryFile(
        dir=os.path.dirname(""), delete=False
    ) as temp_0:
        temp_0.name
    grammar_0.dump(temp_0.name)


# Generated at 2022-06-25 14:43:10.611790
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test an empty grammar
    grammar_0 = Grammar()
    grammar_1 = Grammar()
    grammar_1.load("./pgen/Grammar_pickle")
    assert grammar_0 is not grammar_1
    assert grammar_1.dfas == {}
    assert grammar_1.keywords == {'False': 19, 'None': 20, 'True': 18}

# Generated at 2022-06-25 14:43:15.017939
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("/home/vagrant/plaso/plaso/lib/python/pyparsing/pyparsing_py3.6.pickle")
    grammar_0.load("/home/vagrant/plaso/plaso/lib/python/pyparsing/pyparsing_py3.6.pickle")



# Generated at 2022-06-25 14:43:19.365804
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()

# Generated at 2022-06-25 14:43:21.971030
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump("test_files/test_Grammar.test_1")


# Generated at 2022-06-25 14:43:37.564948
# Unit test for method load of class Grammar
def test_Grammar_load():
    g0 = Grammar()
    fpath = os.path.join(os.path.dirname(__file__), "Grammar.pkl")
    g0.load(fpath)
    assert g0.symbol2number["term"] == 258
    assert g0.symbol2number["expr"] == 259
    assert g0.symbol2number["factor"] == 260
    assert g0.symbol2number["power"] == 261
    assert g0.number2symbol[258] == "term"
    assert g0.number2symbol[259] == "expr"
    assert g0.number2symbol[260] == "factor"
    assert g0.number2symbol[261] == "power"
    assert g0.dfas[258][0][0][0] == 0
    assert g0

# Generated at 2022-06-25 14:43:40.265906
# Unit test for method load of class Grammar
def test_Grammar_load():
    _GRAMMAR_FILE = os.path.join(os.path.dirname(__file__), "Grammar.pkl")
    grammar_0 = Grammar()
    grammar_0.load(_GRAMMAR_FILE)

# Generated at 2022-06-25 14:43:42.294390
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('/tmp/grammar.pickle')


# Generated at 2022-06-25 14:43:43.730072
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('grammar.txt')


# Generated at 2022-06-25 14:43:52.395073
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    grammar_f = Grammar()


# Generated at 2022-06-25 14:43:56.776766
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    tmp_f = tempfile.mkstemp()
    os.close(tmp_f[0])
    os.unlink(tmp_f[1])
    Grammar().dump(tmp_f[1])


# Generated at 2022-06-25 14:43:58.504535
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('/tmp/grammar.pkl')



# Generated at 2022-06-25 14:44:00.498228
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('/tmp/graminit.pickle')



# Generated at 2022-06-25 14:44:01.302311
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    pass


# Generated at 2022-06-25 14:44:04.271469
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    filename = "/Users/travis/build/python-astroid/astroid/test/testcases_dump.txt"
    grammar_0.dump(filename)


# Generated at 2022-06-25 14:44:17.455815
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    try:
        grammar_0.dump("grammar.pickle")
    except IOError as exc:
        assert False, (
            "IOError raised trying to dump the Grammar "
            "grammar_0: {!r}".format(exc)
        )

    tmpdir = grammar_0.tempdir
    assert os.path.exists(tmpdir), (
        "Expected Grammar grammar_0 to have a 'tempdir' which "
        "indicates where to write files, but got None"
    )
    assert os.path.isdir(tmpdir), (
        "Expected the Grammar grammar_0 'tempdir' to be a directory, "
        "got {!r}".format(tmpdir)
    )



# Generated at 2022-06-25 14:44:20.679364
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    temp_file = tempfile.NamedTemporaryFile()
    grammar_0.dump(temp_file.name)


# Generated at 2022-06-25 14:44:30.393847
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Test Grammar.load()."""
    from tempfile import NamedTemporaryFile

    grammar = Grammar()

    grammar.labels.extend([(i, None) for i in range(1, 10)])
    grammar.symbol2number["foo"] = 1
    grammar.number2symbol[1] = "foo"
    grammar.keywords["baz"] = 3
    grammar.tokens[2] = 4
    grammar.start = 22
    grammar.async_keywords = "async" in grammar.keywords

    with NamedTemporaryFile() as f:
        grammar.dump(f.name)
        grammar2 = Grammar()
        grammar2.load(f.name)

    assert grammar.labels == grammar2.labels
    assert grammar.symbol2number == grammar2.symbol2

# Generated at 2022-06-25 14:44:31.461580
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("/home/user/grammar.pickle")



# Generated at 2022-06-25 14:44:34.194782
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("/tmp/grammar_0.py_grammar.pickle")  # Null test


# Generated at 2022-06-25 14:44:41.909472
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar1 = Grammar()
    grammar1.dump("./grammar_temp")
    grammar2 = Grammar()
    grammar2.load("./grammar_temp")

    assert grammar1.dfas == grammar2.dfas
    assert grammar1.labels == grammar2.labels
    assert grammar1.number2symbol == grammar2.number2symbol
    assert grammar1.states == grammar2.states
    assert grammar1.symbol2number == grammar2.symbol2number
    assert grammar1.symbol2label == grammar2.symbol2label
    assert grammar1.tokens == grammar2.tokens

# Generated at 2022-06-25 14:44:44.576578
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("./Grammar.pickle")



# Generated at 2022-06-25 14:44:46.350813
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar0 = Grammar()
    grammar0.dump("./pickle_result.pkl")


# Generated at 2022-06-25 14:44:55.823858
# Unit test for method load of class Grammar
def test_Grammar_load():
    # FIXME: This should be replaced by something less hackish
    grammar_0 = Grammar()
    temp_file_0 = tempfile.NamedTemporaryFile(mode='w')
    temp_file_0.close()
    grammar_0.load(temp_file_0.name)
    grammar_0 = Grammar()
    temp_file_0 = tempfile.NamedTemporaryFile(mode='wb')
    temp_file_0.close()
    grammar_0.load(temp_file_0.name)
    grammar_0 = Grammar()
    temp_file_0 = tempfile.NamedTemporaryFile(mode='wb')
    temp_file_0.write(b'\n')
    temp_file_0.flush()
    grammar_0.load(temp_file_0.name)
   

# Generated at 2022-06-25 14:44:57.355623
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("/tmp/grammar.pickle")


# Generated at 2022-06-25 14:45:03.824131
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load()


# Generated at 2022-06-25 14:45:05.134685
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    assert True  #TODO



# Generated at 2022-06-25 14:45:07.913394
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    try:
        grammar_0.dump(path='.')
    except Exception:
        pass
    else:
        assert False


# Generated at 2022-06-25 14:45:12.223662
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    _file = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'temp.pkl')
    if os.path.isfile(_file):
        os.remove(_file)
    test_case_0()


if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-25 14:45:20.501770
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Since Grammar.dump can't be unit tested as-is, we're going to
    # use the Grammar subclass defined in the pgen module, convert an
    # existing grammar file to a pickle, then read it back in and make
    # sure the data is identical to what was there before.
    from .pgen import Grammar as Grammar_pgen

    grammar_in_path = os.path.join(os.path.dirname(__file__), "Grammar")
    grammar_in = Grammar_pgen(grammar_in_path)

    pickle_path = os.path.join(os.path.dirname(__file__), "Grammar.pickle")
    grammar_in.dump(pickle_path)

    grammar_out = Grammar()

# Generated at 2022-06-25 14:45:23.618873
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # FIXME: This test isn't getting run.  Might want to fix this.
    grammar_0 = Grammar()

    def check_case_0():
        # FIXME: This test isn't getting run.  Might want to fix this.
        try:
            grammar_0.dump('grammar.pickle')
        except Exception as error:
            print(error)

    check_case_0()


# Generated at 2022-06-25 14:45:25.031147
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar ()
    grammar_0.dump('grammar_pgen.pkl')


# Generated at 2022-06-25 14:45:27.150223
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    with tempfile.NamedTemporaryFile() as f:
        grammar_1.dump(f.name)


# Generated at 2022-06-25 14:45:30.175002
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("/src/parser/test_results/test_Grammar_dump.tmp")
    assert not open("/src/parser/test_results/test_Grammar_dump.tmp", "r").read()


# Generated at 2022-06-25 14:45:41.088150
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    def check_Grammar_dump(grammar : Grammar) -> None:
        def check_grammar_with_file(path: str) -> None:
            grammar.dump(path)
            new_grammar = Grammar()
            new_grammar.load(path)
            for item in dir(new_grammar):
                if item not in ("load", "dump"):
                    assert getattr(new_grammar, item) == getattr(grammar, item)
            os.remove(path)

        check_grammar_with_file('grammar.pickle')
        with tempfile.TemporaryDirectory() as tempdir:
            check_grammar_with_file(os.path.join(tempdir, 'grammar.pickle'))

    grammar_0 = Grammar()
    check_Grammar_dump

# Generated at 2022-06-25 14:45:51.074350
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    with tempfile.NamedTemporaryFile() as f:
        grammar_1.dump(f.name)


# Generated at 2022-06-25 14:45:52.739665
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    fp = open("_dump_test.txt", "wb")
    grammar.dump(fp)
    fp.close()


# Generated at 2022-06-25 14:45:56.534701
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load(None)


if __name__ == "__main__":
    test_case_0()
    test_Grammar_load()

# Generated at 2022-06-25 14:45:58.256985
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    filename = ""
    grammar_0.dump(filename)


# Generated at 2022-06-25 14:46:02.829605
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Create a "Grammar" instance
    grammar_0 = Grammar()

    # Call method load with argument "tests/grammar.pickle"
    grammar_0.load("tests/grammar.pickle")

    # Call method report on "grammar_0"
    grammar_0.report()



# Generated at 2022-06-25 14:46:10.727637
# Unit test for method load of class Grammar
def test_Grammar_load():

    # Test for empty grammar_0
    grammar_0 = Grammar()
    grammar_0.load("./pgen_test/empty.pkl")
    assert grammar_0.symbol2number == {}
    assert grammar_0.number2symbol == {}
    assert grammar_0.states == []
    assert grammar_0.dfas == {}
    assert grammar_0.labels == [(0, "EMPTY")]
    assert grammar_0.keywords == {}
    assert grammar_0.tokens == {}
    assert grammar_0.symbol2label == {}
    assert grammar_0.start == 256
    assert grammar_0.async_keywords == False

test_case_0()
test_Grammar_load()

# Generated at 2022-06-25 14:46:16.272320
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load('Grammar.pickle')
    assert grammar.__getstate__() == {"symbol2number": {}, "number2symbol": {}, "states": [], "dfas": {}, "labels": [(0, 'EMPTY')], "keywords": {}, "tokens": {}, "symbol2label": {}, "start": 256, "async_keywords": False}


# Generated at 2022-06-25 14:46:18.878861
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    assert grammar_0.symbol2number is not None
    assert grammar_0.number2symbol is not None
    assert grammar_0.states is not None
    assert grammar_0.dfas is not None
    assert grammar_0.labels is not None
    assert grammar_0.keywords is not None
    assert grammar_0.tokens is not None
    assert grammar_0.start is not None


# Generated at 2022-06-25 14:46:24.855846
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Create a new Grammar object
    grammar = Grammar()

    # Insert code to set up the Grammar object here
    grammar.symbol2number['test_symbol'] = 1
    grammar.number2symbol[2] = 'test_symbol2'
    grammar.states = ['test_state1', 'test_state2']
    grammar.dfas = {1: ('test_DFA1_1', 'test_DFA1_2'), 2: ('test_DFA2_1', 'test_DFA2_2')}
    grammar.labels = [('test_label1_1', 'test_label1_2'), ('test_label2_1', 'test_label2_2')]

# Generated at 2022-06-25 14:46:29.702158
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Test dump method of Grammar
    from io import BytesIO
    # Create a new Grammar object
    grammar_0 = Grammar()
    # Extract the pickle representation
    grammar_0.dump('graminit.pickle')
    with open('graminit.pickle', 'rb') as f:
        native_contents = f.read()
    # Create a BytesIO object
    f = BytesIO()
    # Use dump method of Grammar object to write the object to f
    grammar_0.dump(f)
    # Retrieve contents from f as byte string
    actual_contents = f.getvalue()
    assert native_contents == actual_contents
    # Return contents of f to the starting point
    f.seek(0)
    # Create a BytesIO object
    f = BytesIO()
