

# Generated at 2022-06-25 14:36:45.592892
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('.data/test/test_parse/pickle_0.pkl')


# Generated at 2022-06-25 14:36:47.844398
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load("GrammarTables")


# Generated at 2022-06-25 14:36:54.858245
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    with tempfile.TemporaryDirectory() as td:
        def test_try(pkl: bytes) -> None:
            grammar_1.loads(pkl)
            grammar_2 = Grammar()
            grammar_2.load(os.path.join(td, "test.pkl"))
            assert isinstance(grammar_2.symbol2label, dict)
            assert isinstance(grammar_2.states, list)
            assert isinstance(grammar_2.keywords, dict)
            assert isinstance(grammar_2.labels, list)
        test_try(b"\x80\x03.}q\x00.")
        test_try(b"\x80\x02}q\x00.")



# Generated at 2022-06-25 14:36:59.093885
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Refer to function test_case_0 to setup the test case.
    # Replace 'pass' statement by your code that should be executed.
    # The method should be called with argument ''.
    assert grammar_0.load('') == \
        None


# Generated at 2022-06-25 14:37:02.836222
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # No pickle, just make sure it doesn't crash.
    grammar_0 = Grammar()
    grammar_0.dump('/dev/null')


if __name__ == "__main__":
    test_Grammar_dump()
    test_case_0()

# Generated at 2022-06-25 14:37:10.516051
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_test_case_0 = Grammar()
    grammar_test_case_0.states = [[(0, 1)]]
    grammar_test_case_0.dfas = {
        257: ([(0, 1)], {1: 0}),
        258: ([(0, 1)], {1: 0}),
    }
    grammar_test_case_0.symbol2number = {
        "__e": 257,
        "__main__": 258,
    }
    grammar_test_case_0.number2symbol = {
        257: "__e",
        258: "__main__",
    }
    grammar_test_case_0.labels = [(0, None)]
    grammar_test_case_0.keywords = {}
    grammar_test_case_0.tokens

# Generated at 2022-06-25 14:37:13.093797
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    filename = os.path.basename(__file__) + '.tmp'
    grammar_1.dump(filename)


# Generated at 2022-06-25 14:37:15.811992
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump(filename = "")


# Generated at 2022-06-25 14:37:17.361033
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("test")


# Generated at 2022-06-25 14:37:19.446779
# Unit test for method load of class Grammar
def test_Grammar_load():
    # SyntaxError: unexpected EOF while parsing (line:1, col:0)
    grammar_0 = Grammar()


# Generated at 2022-06-25 14:37:26.939514
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    file_1 = None
    grammar_1.load(file_1)


# Generated at 2022-06-25 14:37:37.871505
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    filename = './test_files/Grammar_load_pkl.pkl'
    if os.path.exists(filename):
        grammar.load(filename)

# Generated at 2022-06-25 14:37:48.129517
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    # TODO: once grammar is a dataclass, this isn't required
    grammar.symbol2number = {'test': 0}
    grammar.number2symbol = {0: 'test'}
    grammar.states = [[(0, 1)]]
    grammar.dfas = {0: (grammar.states[0], {})}
    grammar.labels = [(0, None)]
    grammar.keywords = {'test': 0}
    grammar.tokens = {0: 0}
    grammar.symbol2label = {'test': 0}
    grammar.start = 256
    grammar.async_keywords = False

    # Call dump with parameter filename
    grammar.dump('test_files/pgen/grammar.pickle')

    # Load in a new grammar object and test that it

# Generated at 2022-06-25 14:37:49.505833
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar_load")


# Generated at 2022-06-25 14:38:00.402444
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    path = "test.out"
    grammar.dump(path)
    grammar2 = Grammar()
    grammar2.load(path)
    assert grammar.number2symbol == grammar2.number2symbol
    assert grammar.symbol2number == grammar2.symbol2number
    assert grammar.states == grammar2.states
    assert grammar.dfas == grammar2.dfas
    assert grammar.labels == grammar2.labels
    assert grammar.keywords == grammar2.keywords
    assert grammar.tokens == grammar2.tokens
    assert grammar.symbol2label == grammar2.symbol2label
    assert grammar.start == grammar2.start
    assert grammar.async_keywords == grammar2.async_keywords
    os.remove(path)

# Generated at 2022-06-25 14:38:05.102347
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load(__file__)
    assert len(grammar_0.labels) == 34
    assert grammar_0.tokens[grammar_0.labels[21][0]] == 21
    assert len(grammar_0.symbol2number) == 34
    assert grammar_0.number2symbol[grammar_0.labels[33][0]] == "endmarker"

# Generated at 2022-06-25 14:38:05.772962
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('')

# Generated at 2022-06-25 14:38:13.462036
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    filename_0 = "pycparser\\tests\\c_files\\empty.c"
    grammar_0.dump(filename_0)
    filename_1 = "pycparser\\tests\\c_files\\empty.c"
    grammar_1 = Grammar()
    grammar_1.load(filename_1)

# Generated at 2022-06-25 14:38:16.828883
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    filename = "./test/test_Grammar.test_Grammar_load.1"
    grammar_0.load(filename)

# Generated at 2022-06-25 14:38:24.367809
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    node_list_1 = []
    grammar_1.load(node_list_1)
    grammar_2 = Grammar()
    node_list_2 = []
    grammar_2.load(node_list_2)

if __name__ == "__main__":
    import sys

    def test_failed(msg):
        print(f"test failed: {msg}")
        sys.exit(1)

    # Unit test for class Grammar
    test_case_0()
    test_case_1()

    print("Grammar.py: All unit tests passed.")
    sys.exit(0)

# Generated at 2022-06-25 14:38:36.911963
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load("./test/test_data/test_Grammar/test.pkl")


# Generated at 2022-06-25 14:38:41.257183
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Testing the dump method of Grammar class
    filename = "grammar_0.pickle"
    grammar_0 = Grammar()
    grammar_0.dump(filename)
    with open(filename, "rb") as f:
        d = pickle.load(f)
    grammar_0._update(d)
    grammar_0.report()



# Generated at 2022-06-25 14:38:42.483293
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump(os.path.join(tempfile.gettempdir(),"test_grammar_tables.pickle"))


# Generated at 2022-06-25 14:38:43.759423
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()

    grammar_0.dump(filename=None)


# Generated at 2022-06-25 14:38:44.924118
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()

    filename = ""
    grammar_0.dump(filename)



# Generated at 2022-06-25 14:38:46.302801
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("./test_grammar.pickle")



# Generated at 2022-06-25 14:38:50.085276
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Run this with -m coverage run -p -m test.test_grammar.TestGrammar.test_case_0
    # coverage run -p -m unittest test.test_grammar.TestGrammar.test_Grammar_dump
    grammar_0 = Grammar()
    filename_0: Path = "grammar-dump.pkl"
    grammar_0.dump(filename_0)


if __name__ == "__main__":
    test_case_0()
    test_Grammar_dump()

# Generated at 2022-06-25 14:38:55.971481
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.pkl")
    assert g.symbol2number["expr_stmt"] == 258
    assert g.symbol2number["power"] == 261
    assert g.symbol2number["import_as_name"] == 269
    assert g.symbol2number["dotted_as_name"] == 270
    assert g.symbol2number["with_var"] == 280
    assert g.symbol2number["name"] == 290
    assert g.symbol2number["attr"] == 294
    assert g.symbol2number["any_name"] == 296
    assert g.symbol2number["decorator"] == 303


# Generated at 2022-06-25 14:38:57.601394
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load(os.path.join('.', 'grammar', 'Grammar.pkl'))


# Generated at 2022-06-25 14:38:59.631976
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """Test case for method dump of class Grammar"""
    test_case_0()


# Generated at 2022-06-25 14:39:14.074982
# Unit test for method load of class Grammar
def test_Grammar_load():
    this_path = os.path.dirname(os.path.realpath(__file__))
    grammar = Grammar()
    grammar.load(os.path.join(this_path, '../pickle/Grammar.pickle'))
    assert len(grammar.number2symbol) == 618
    assert len(grammar.symbol2number) == 618
    assert len(grammar.states) == 479
    assert len(grammar.dfas) == 549
    assert len(grammar.labels) == 614
    assert grammar.start == 256


# Generated at 2022-06-25 14:39:15.398085
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    grammar_0 = Grammar()

    grammar_0.dump(tempfile.mktemp())


# Generated at 2022-06-25 14:39:21.145184
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    # The line below causes a warning because in 3.5 we have no way of specifying
    # that the value is Optional[Path] and we have to keep the type checker happy.
    with tempfile.TemporaryDirectory() as directory:  # type: ignore
        grammar_0.dump(os.path.join(directory, 'foo.pickle'))


# Generated at 2022-06-25 14:39:27.227143
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    try:
        grammar_1.load("/home/bcc/Desktop/Pyt/test_0")
        print("test_Grammar_load_0")
    except Exception:
        print("test_Grammar_load_1")
    try:
        grammar_1.load("/home/bcc/Desktop/Pyt/test_1")
        print("test_Grammar_load_2")
    except Exception:
        print("test_Grammar_load_3")
    try:
        grammar_1.load("/home/bcc/Desktop/Pyt/test_2")
        print("test_Grammar_load_4")
    except Exception:
        print("test_Grammar_load_5")

# Generated at 2022-06-25 14:39:33.072803
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.load('/Users/rgrinberg/Documents/PyCharm Projects/CSSE1001-Assignment-3-master/ast_util/Grammar.pkl')
    assert grammar_1.dump('/Users/rgrinberg/Documents/PyCharm Projects/CSSE1001-Assignment-3-master/ast_util/Grammar.pkl') == None


# Generated at 2022-06-25 14:39:42.206299
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    try:
        filename = None
        with tempfile.NamedTemporaryFile(
            dir=os.path.dirname(filename), delete=False
        ) as f:
            pickle.dump(d, f, pickle.HIGHEST_PROTOCOL)
        os.replace(f.name, filename)
    except:
        pass

if __name__ == "__main__":
    import sys
    import types

    if not sys.argv[1:]:
        print("No grammar file specified")
        sys.exit(1)
    elif len(sys.argv) > 2:
        print("Only one grammar file permitted")
        sys.exit(1)

    if sys.argv[1].endswith(".py"):
        p = sys.argv[1].rfind("/")

# Generated at 2022-06-25 14:39:45.561676
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_2 = Grammar()
    path = os.path.dirname(__file__)
    filename = os.path.join(path, "Grammar.pkl")
    grammar_2.load(filename)

# Generated at 2022-06-25 14:39:50.214269
# Unit test for method load of class Grammar
def test_Grammar_load():
    for d in [{}, {1:2}, {1:2,3:4}]:
        g = Grammar()
        g.loads(pickle.dumps(d))
        assert g.__dict__ == d


# Generated at 2022-06-25 14:39:51.380340
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    # _ = grammar.load()



# Generated at 2022-06-25 14:39:53.064641
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    assert grammar_1.load(b'') == None


# Generated at 2022-06-25 14:40:09.586127
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('./tests/data/grammar_0.pickle')
    assert grammar_0.symbol2number == {'start': 256}
    assert grammar_0.number2symbol == {256: 'start'}
    assert grammar_0.states == [[[(556, 1)]]]
    assert grammar_0.dfas == {256: ([[(556, 1)]], {1: 1})}
    assert grammar_0.labels == [(0, 'EMPTY'), (556, 'start')]
    assert grammar_0.keywords == {'start': 556}
    assert grammar_0.tokens == {}
    assert grammar_0.symbol2label == {}
    assert grammar_0.start == 256


# Generated at 2022-06-25 14:40:11.589428
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load(os.path.join(os.path.dirname(__file__), "Grammar.txt"))


# Generated at 2022-06-25 14:40:16.681367
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("grammar_pkl")  # write to a temporary pickle file
    grammar_1 = Grammar()
    grammar_1.load("grammar_pkl")
    # force garbage collection to avoid false positive in memleak test
    import gc

    gc.collect()
    os.remove("grammar_pkl")

# Generated at 2022-06-25 14:40:19.058015
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Test case 0
    grammar_0 = Grammar()
    grammar_0.dump("./Grammar")



# Generated at 2022-06-25 14:40:21.913251
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load('Grammar/Python.pkl')
    grammar.report()


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-25 14:40:30.324869
# Unit test for method load of class Grammar
def test_Grammar_load():
    #
    # First, create a temporary file, write some data to it, and
    # then load that data back in.
    #
    test_filename = "test_data/test_grammar.pkl"
    # Construct the pkl before we read it
    test_grammar = test_case_0()
    # Write the pkl to the test file
    with open(test_filename, "wb") as f:
        test_grammar.dump(f)
    # Read the pkl back in
    with open(test_filename, "rb") as f:
        grammar = Grammar()
        grammar.load(f)


# Generated at 2022-06-25 14:40:31.290587
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump(grammar)



# Generated at 2022-06-25 14:40:34.663171
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    try:
        grammar_1.load('grammar_pickle_file_not_found.pk')
    except FileNotFoundError:
        pass


# Generated at 2022-06-25 14:40:37.052971
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()

    try:
        grammar_0.dump("grammar_0.dump")

    except:
        print("Test failed")


# Generated at 2022-06-25 14:40:38.882804
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    filename_0 = tempfile.mktemp()
    grammar_0.dump(filename_0)


# Generated at 2022-06-25 14:40:57.183917
# Unit test for method load of class Grammar
def test_Grammar_load():
    p = Grammar()
    p.load("./test/Grammar_0.pickle")
    assert isinstance(p.symbol2number, dict)
    assert isinstance(p.number2symbol, dict)
    assert isinstance(p.states, list)
    assert isinstance(p.dfas, dict)
    assert isinstance(p.labels, list)
    assert isinstance(p.keywords, dict)
    assert isinstance(p.tokens, dict)
    assert isinstance(p.symbol2label, dict)
    assert isinstance(p.start, int)
    assert isinstance(p.async_keywords, bool)


# Generated at 2022-06-25 14:40:59.880952
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = 'test.pkl'
    grammar_1 = test_case_0()
    grammar_1.dump(filename)


# Generated at 2022-06-25 14:41:03.756103
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    with tempfile.NamedTemporaryFile(delete=False) as f:
        pickle.dump({}, f, pickle.HIGHEST_PROTOCOL)
    grammar_0.load(f.name)


# Generated at 2022-06-25 14:41:07.174287
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("/home/hgeg/pypy3/lib-python/3/test/grammar_grammar_dump.txt")


# Generated at 2022-06-25 14:41:14.762377
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
# Test normal operation
    filename = '/usr/lib/python3.2/asyncio/tasks.py'
    grammar.load(filename)
# Test normal operation
    filename = '/usr/lib/python3.2/asyncio/coroutines.py'
    grammar.load(filename)
# Test normal operation
    filename = '/usr/lib/python3.2/asyncio/constants.py'
    grammar.load(filename)
# Test normal operation
    filename = '/usr/lib/python3.2/asyncio/coroutines.py'
    grammar.load(filename)
# Test normal operation
    filename = '/home/brian/projects/parso/parso/pgen2/grammar.py'
    grammar.load(filename)
# Test normal operation
   

# Generated at 2022-06-25 14:41:24.704131
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_2 = Grammar()
    grammar_3 = Grammar()
    filename = "../test/test_grammar.pkl"
    grammar_1.load(filename)
    grammar_2.loads(grammar_1.dumps())
    grammar_3.loads(grammar_1.dumps())
    assert len(grammar_1.symbol2number) == len(grammar_2.symbol2number) == len(
        grammar_3.symbol2number
    )
    assert len(grammar_1.number2symbol) == len(grammar_2.number2symbol) == len(
        grammar_3.number2symbol
    )

# Generated at 2022-06-25 14:41:29.179509
# Unit test for method load of class Grammar
def test_Grammar_load():
    #
    # Set up
    #
    grammar = test_case_0()
    ## This is the pickle of Grammar (which only contains the
    ## _PyParser_Grammar object)
    if hasattr(grammar, "__dict__"):
        data = pickle.dumps(grammar.__dict__)
    else:
        data = pickle.dumps(grammar.__getstate__())  # type: ignore
    #
    # Exercise
    #
    grammar.loads(data)
    #
    # Verify
    #
    assert grammar.symbol2number == {}, "Bad grammar.symbol2number"



# Generated at 2022-06-25 14:41:30.787250
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()

    grammar_0.dump('testfile')


# Generated at 2022-06-25 14:41:31.971108
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('file.pickle')
    grammar_0.loads(b'')


# Generated at 2022-06-25 14:41:35.558688
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    filename = 'file_0'
    grammar_0.dump(filename)
    grammar_0.dump("file_1")
    grammar_0.dump("file_2")
    grammar_0.dump("file_3")

# Generated at 2022-06-25 14:41:55.593655
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from typing import Any, Dict, List
    from mypy_extensions import TypedDict

    class DumpArgs(TypedDict):
        filename: str

    grammar_dump_args_0 = DumpArgs()
    grammar_dump_args_0.filename = 'file'

    def _callback_0(self_0: Grammar) -> None:
        # mypyc generates objects that don't have a __dict__, but they
        # do have __getstate__ methods that will return an equivalent
        # dictionary
        if hasattr(self_0, "__dict__"):
            d = self_0.__dict__
        else:
            d = self_0.__getstate__()  # type: ignore

# Generated at 2022-06-25 14:41:57.541215
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("Lib/test/pgen_data/Grammar.pkl")
    grammar.load("Grammar.pkl")


# Generated at 2022-06-25 14:41:58.280266
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_load = Grammar()


# Generated at 2022-06-25 14:42:00.130292
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("..\\data\\tmp\\grammar.pickle")


# Generated at 2022-06-25 14:42:02.546802
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('./data/python2_grammar_pgen.pickle')


# Generated at 2022-06-25 14:42:03.599077
# Unit test for method load of class Grammar
def test_Grammar_load():
    test_case_0()

# Generated at 2022-06-25 14:42:08.848091
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    filename = "Grammar.pickle"
    try:
        grammar.load(filename)
    except Exception:
        raise AssertionError(
            "unable to call method load of class Grammar",
            "Grammar", "load",
        )


# Generated at 2022-06-25 14:42:09.565847
# Unit test for method load of class Grammar
def test_Grammar_load():
    assert False


# Generated at 2022-06-25 14:42:10.772418
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("test_data/grammar.pickle")


# Generated at 2022-06-25 14:42:16.004738
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump("grammar.dump")
    grammar_1 = Grammar()
    grammar_1.load("grammar.dump")
    grammar_1 = Grammar()
    grammar_1.load(b"grammar.dump")
    grammar_1 = Grammar()
    grammar_1.loads(b"grammar.dump")



# Generated at 2022-06-25 14:42:26.904599
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("test_dump")


# Generated at 2022-06-25 14:42:34.195050
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .conv import parse_grammar_file
    from .pgen import generate_grammar_tables
    from .tokenize import tokenize
    from io import BytesIO
    import pickle

    # The following strings were generated to contain the
    # tokenize.detect_encoding()
    grammar_0 = Grammar()

# Generated at 2022-06-25 14:42:36.270079
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('/tmp/grammar_0.dump')


# Generated at 2022-06-25 14:42:37.865999
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump('TEST_Grammar_dump')



# Generated at 2022-06-25 14:42:40.101340
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('/tmp/guest-iiw2gx/grammar_py37')


# Generated at 2022-06-25 14:42:40.956152
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()



# Generated at 2022-06-25 14:42:42.926136
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("03-grammar1.txt")
    assert grammar_0 is not None

# Generated at 2022-06-25 14:42:44.823696
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    t: Grammar = Grammar()
    t.dump("test")


# Generated at 2022-06-25 14:42:54.459537
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()

# Generated at 2022-06-25 14:42:56.262334
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Init
    f = ("pgen-data/grammar.pkl")
    grammar_0 = Grammar()
    # Operation
    grammar_0.dump(f)


# Generated at 2022-06-25 14:43:28.407094
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.start = 256
    g.tokens = {1: 2, 3: 4}
    g.states = [[(2, 3)], [(token.ENDMARKER, 3)]]
    g.dfas = {0: (0, {1: 1}), 1: (1, {4: 1})}
    g.labels = [
        (0, None),
        (1, None),
        (3, None),
        (token.ENDMARKER, None),
    ]
    g.keywords = {}
    g.symbol2number = {'start_symbol': 256, 'keyword': 257, 'name': 258}
    g.number2symbol = {256: 'start_symbol', 257: 'keyword', 258: 'name'}

# Generated at 2022-06-25 14:43:37.674400
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()

# Generated at 2022-06-25 14:43:39.082706
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("pgen.pickle")


# Generated at 2022-06-25 14:43:45.686371
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()

    with tempfile.NamedTemporaryFile(mode="w") as f:
        grammar_0.dump(f.name)
        f.seek(0)
        grammar_1 = Grammar()
        grammar_1.load(f.name)

    assert grammar_0.number2symbol == grammar_1.number2symbol
    assert grammar_0.symbol2number == grammar_1.symbol2number
    assert grammar_0.labels == grammar_1.labels
    assert grammar_0.keywords == grammar_1.keywords
    assert grammar_0.tokens == grammar_1.tokens
    assert grammar_0.symbol2label == grammar_1.symbol2label
    assert grammar_0.start == grammar_1.start



# Generated at 2022-06-25 14:43:48.078857
# Unit test for method load of class Grammar
def test_Grammar_load():
    tmp = '_%s' % turtle.tests.test_Grammar.__name__
    with tempfile.NamedTemporaryFile(delete=False, suffix=tmp) as f:
        grammar_1 = Grammar()
        grammar_1.dump(f.name)
        grammar_1.load(f.name)

# Generated at 2022-06-25 14:43:49.488786
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = test_case_0()
    grammar_0.dump(filename_0)



# Generated at 2022-06-25 14:43:52.700106
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.dump("test/test.pkl")
    grammar_0 = Grammar()
    grammar_0.load("test/test.pkl")


# Generated at 2022-06-25 14:43:54.402007
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('./g_0.pickle')


# Generated at 2022-06-25 14:43:58.021473
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump(os.path.join(tempfile.gettempdir(), "grammar_0.pickle"))


# Generated at 2022-06-25 14:44:00.113252
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('grammar.pickle')


# Generated at 2022-06-25 14:44:43.424789
# Unit test for method load of class Grammar
def test_Grammar_load():

    grammar_0 = Grammar()
    grammar_0.load('grammar.pkl')


# Generated at 2022-06-25 14:44:45.641607
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))

# Generated at 2022-06-25 14:44:55.158579
# Unit test for method dump of class Grammar

# Generated at 2022-06-25 14:44:59.317612
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Loads the grammar tables from a pickle file.
    grammar_0 = Grammar()
    path_temp = 'tempfile.pkl'
    grammar_0.dump(path_temp)
    grammar_0.load(path_temp)

if __name__ == "__main__":
    test_case_0()
    test_Grammar_load()

# Generated at 2022-06-25 14:45:07.378316
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.loads(b"\x80\x03}q\x00U\x05startq\x01M\xa0\x03U\x06tokensq\x02}q\x03U\x05EMPTYq\x04K\x00sb.")
    assert grammar.start == 256
    assert grammar.tokens == {0: 0}

    grammar_1 = Grammar()
    grammar_1.loads(b"\x80\x03}q\x00U\x05startq\x01M\xa0\x03U\x06tokensq\x02}q\x03U\x05EMPTYq\x04K\x00sb.")
    assert grammar_1.start == 256
    assert grammar_1.tokens == {0: 0}

# Generated at 2022-06-25 14:45:09.060778
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("./Grammar.dump")

    grammar.dump(tempfile.mktemp())


# Generated at 2022-06-25 14:45:15.686271
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    # test_Grammar_load
    assert grammar_0.states == list()
    assert grammar_0.keywords == dict()
    assert grammar_0.tokens == dict()
    assert grammar_0.number2symbol == dict()
    assert grammar_0.symbol2number == dict()
    assert grammar_0.symbol2label == dict()
    assert grammar_0.dfas == dict()
    assert grammar_0.labels == list()
    return


# Generated at 2022-06-25 14:45:16.831765
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("/tmp/grammar.pkl")

# Generated at 2022-06-25 14:45:18.961888
# Unit test for method load of class Grammar
def test_Grammar_load():
   with Grammar() as grammar:
      # Test path is valid
      assert grammar.load(os.path.abspath(__file__)) is None



# Generated at 2022-06-25 14:45:28.248096
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    r_0 = grammar_0.symbol2number == {}
    assert r_0
    r_1 = grammar_0.number2symbol == {}
    assert r_1
    r_2 = grammar_0.states == []
    assert r_2
    r_3 = grammar_0.dfas == {}
    assert r_3
    r_4 = grammar_0.labels == [(0, 'EMPTY')]
    assert r_4
    r_5 = grammar_0.keywords == {}
    assert r_5
    r_6 = grammar_0.tokens == {}
    assert r_6
    r_7 = grammar_0.symbol2label == {}
    assert r_7
    r_8 = grammar_0.start == 256
    assert r_