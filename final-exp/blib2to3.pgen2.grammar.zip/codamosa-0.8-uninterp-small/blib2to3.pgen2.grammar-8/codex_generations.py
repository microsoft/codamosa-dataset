

# Generated at 2022-06-25 14:36:52.306286
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # No exception should be thrown when calling dump
    grammar_0 = Grammar()
    test_data = ['./tokens.txt', './tokens.0.txt', './tokens.1.txt', './tokens.2.txt', './tokens.3.txt', './tokens.4.txt', './tokens.5.txt']
    grammar_0.dump(test_data[0])
    grammar_0.dump(test_data[1])
    grammar_0.dump(test_data[2])
    grammar_0.dump(test_data[3])
    grammar_0.dump(test_data[4])
    grammar_0.dump(test_data[5])
    grammar_0.dump(test_data[6])
    # No exception should be

# Generated at 2022-06-25 14:36:56.725323
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    if os.path.exists('test_Grammar_dump'): os.remove('test_Grammar_dump')
    with open('test_Grammar_dump', 'w') as f: Grammar().dump(f)
    assert os.path.exists('test_Grammar_dump')
    os.remove('test_Grammar_dump')


# Generated at 2022-06-25 14:36:59.953180
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    import os.path
    grammar_0 = Grammar()
    grammar_0.load(os.path.join("Python", "Grammar.pkl"))


# Generated at 2022-06-25 14:37:02.282740
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("./pgen2/Grammar.gram")

# Generated at 2022-06-25 14:37:05.850153
# Unit test for method load of class Grammar
def test_Grammar_load():
    
    grammar_1 = Grammar()
    grammar_1.dump("grammar_1.pickle")
    grammar_2 = Grammar()
    grammar_2.load("grammar_1.pickle")

if __name__ == "__main__":
    test_case_0()
    test_Grammar_load()

# Generated at 2022-06-25 14:37:08.147190
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("python37.pickle")

# Generated at 2022-06-25 14:37:09.667192
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load(__file__[:-2] + 'pickle')


# Generated at 2022-06-25 14:37:10.884104
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('test_dump.pickle')


# Generated at 2022-06-25 14:37:13.709431
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    #
    # Grammar p = new Grammar();
    # p.dump( 'Grammar.pickle' );
    grammar_0.dump("Grammar.pickle")



# Generated at 2022-06-25 14:37:16.491231
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("Grammar/Grammar.pkl")


# Generated at 2022-06-25 14:37:24.293537
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    test_case_0()
    filename = ""
    grammar_0.dump(filename)



# Generated at 2022-06-25 14:37:25.968784
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar_0 = Grammar()
    grammar.load("Grammar.pickle")
    grammar_0.load("Grammar.pickle")

# Generated at 2022-06-25 14:37:37.538484
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()

# Generated at 2022-06-25 14:37:41.055976
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("./python/Lib/lib2to3/Grammar.pgen")


# Generated at 2022-06-25 14:37:49.697476
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    fd, temp_file = tempfile.mkstemp()

# Generated at 2022-06-25 14:37:53.108671
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("pgen_case_0.txt")
    grammar_0.load("pgen_case_0.bin")


# Generated at 2022-06-25 14:37:56.076633
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()

    # Here's what we're testing here:
    grammar_1.load("Grammar.pickle")



# Generated at 2022-06-25 14:37:58.009536
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load(file)



# Generated at 2022-06-25 14:37:59.815941
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("Grammar.pickle")


# Generated at 2022-06-25 14:38:01.348835
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("test.pickle")


# Generated at 2022-06-25 14:38:06.663140
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load('GrammarTables.pkl')


# Generated at 2022-06-25 14:38:08.650433
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    try:
        grammar.dump("hello.grammar")
    except Exception as e:
        print("Exception caught while executing Grammar.dump: " + str(e))


# Generated at 2022-06-25 14:38:10.513132
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    # Create a Grammar instance
    grammar_0 = Grammar()

    # Call method dump of grammar_0
    grammar_0.dump("c:\\test_dir\\test_python.pickle")


# Generated at 2022-06-25 14:38:11.865784
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump("test/test_grammar.txt")


# Generated at 2022-06-25 14:38:13.737535
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Temporary file for testing
    filename = '/dev/null'

    grammar_0 = Grammar()
    grammar_0.dump(filename)



# Generated at 2022-06-25 14:38:15.672903
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("test")

# Generated at 2022-06-25 14:38:17.323959
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()


# Generated at 2022-06-25 14:38:21.811735
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    test_0 = Grammar()
    with tempfile.NamedTemporaryFile(
        dir=os.path.dirname(__file__), delete=False
    ) as f:
        test_0.dump(f.name)
        # test that dump creates the file
        test_0.report()



# Generated at 2022-06-25 14:38:25.965649
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    filename_0 = './fixtures/tempfile_dump-1'
    # Exception has occurred: IndexError
    # list index out of range
    grammar_0.dump(filename_0)


# Generated at 2022-06-25 14:38:27.498275
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(b"sample.pkl")



# Generated at 2022-06-25 14:38:32.311146
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('/tmp/pycharm-management/pgen_test.pkl')


# Generated at 2022-06-25 14:38:35.657208
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(test_case_0)
    # return value is not used
    return g


# Generated at 2022-06-25 14:38:44.164001
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()

# Generated at 2022-06-25 14:38:46.067493
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    with tempfile.NamedTemporaryFile(mode="w+b", delete=False) as f:
        grammar_0.dump(f.name)


# Generated at 2022-06-25 14:38:46.962432
# Unit test for method load of class Grammar
def test_Grammar_load():
    assert b"Grammar" in pickle.dumps(Grammar())


# Generated at 2022-06-25 14:38:49.656436
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from tempfile import TemporaryDirectory
    from .parser import ParserError, Parser

    with TemporaryDirectory() as tmpdir:
        grammar_0 = Grammar()
        parser_0 = Parser(grammar_0)
        try:
            Grammar.dump(grammar_0, tmpdir)
        except Exception :
            raise AssertionError


# Generated at 2022-06-25 14:38:52.247952
# Unit test for method load of class Grammar
def test_Grammar_load():
    with open("GrammarTables.pickle_0", "rb") as f:
        bytes_0 = f.read()
    grammar_0 = Grammar()
    grammar_0.loads(bytes_0)


if __name__ == "__main__":
    test_case_0()
    test_Grammar_load()

# Generated at 2022-06-25 14:38:53.330276
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('')



# Generated at 2022-06-25 14:38:54.682383
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump("Grammar_dump.txt")

# Generated at 2022-06-25 14:39:01.243835
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_1 = Grammar()
    temp_0 = tempfile.NamedTemporaryFile()
    grammar_0.dump(temp_0.name)
    grammar_1.load(temp_0.name)
    assert grammar_0.symbol2number == grammar_1.symbol2number
    assert grammar_0.number2symbol == grammar_1.number2symbol
    assert grammar_0.states == grammar_1.states
    assert grammar_0.dfas == grammar_1.dfas
    assert grammar_0.labels == grammar_1.labels
    assert grammar_0.keywords == grammar_1.keywords
    assert grammar_0.tokens == grammar_1.tokens
    assert grammar_0.symbol2label == grammar_1.symbol2

# Generated at 2022-06-25 14:39:06.549232
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(os.path.join(os.path.dirname(__file__), "Python.grammar"))


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-25 14:39:09.108591
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    temp_file = tempfile.NamedTemporaryFile()
    grammar.dump(temp_file.name)

    # Make sure file is not empty
    if os.stat(temp_file.name).st_size == 0:
        raise Exception("temp file is empty")

    temp_file.close()



# Generated at 2022-06-25 14:39:10.944732
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    filename = "/tmp/tmp-grammar.pickle"
    grammar.dump(filename)



# Generated at 2022-06-25 14:39:20.835507
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.symbol2number = {'foo': 42}
    grammar.number2symbol = {42: 'foo'}
    grammar.states = [[[(1, 2)]]]
    grammar.dfas = {42: ([[(1, 2)]], {1: 1})}
    grammar.labels = [(0, None), (1, None)]
    grammar.start = 42
    grammar.keywords = {'x': 1}
    grammar.tokens = {0: 1}
    grammar.symbol2label = {'foo': 1}
    grammar.async_keywords = True

    f = tempfile.TemporaryFile("w+b")
    grammar.dump(f)
    dumps = f.getvalue()
    f.close()

    grammar2 = Grammar()


# Generated at 2022-06-25 14:39:23.014782
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    assert isinstance(grammar_0, Grammar)
    grammar_0.dump('t_Grammar_dump')


# Generated at 2022-06-25 14:39:24.499661
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    pkl = grammar.dump('test_Grammar.pkl')
    assert pkl is None


# Generated at 2022-06-25 14:39:27.899618
# Unit test for method load of class Grammar
def test_Grammar_load():
    cur_dir = os.path.dirname(__file__)
    g = Grammar()
    g.load(os.path.join(cur_dir, 'Grammar.pkl'))


if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1:
        g = Grammar()
        g.loads(sys.argv[1].encode("ascii"))
        g.report()
    else:
        import doctest

        doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-25 14:39:37.578357
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Assuming this is tested with grammars full of data
    grammar_1 = Grammar()  # Test an empty grammar
    # Test a non-empty grammar
    grammar_2 = Grammar()
    grammar_2.states = [[(0, 0)]]
    grammar_2.dfas = {0: (grammar_2.states[0], {"ENDMARKER": 0})}
    grammar_2.labels = [(0, "EMPTY")]
    grammar_2.number2symbol = {0: "START", 1: "EMPTY"}
    grammar_2.symbol2number = {"START": 0, "EMPTY": 1}
    grammar_2.symbol2label = {0: 0}
    grammar_2.start = 0
    grammar_2.async_keywords = False

    # Check output

# Generated at 2022-06-25 14:39:39.332689
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump(filename = None)


# Generated at 2022-06-25 14:39:41.829397
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    try:
        grammar.dump("/tmp/dump-0.grammar")
    except:
        print("Exception in testcase 0")


# Generated at 2022-06-25 14:39:48.242184
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = os.path.join(os.path.dirname(__file__), "Grammar.pkl")
    grammar_0 = Grammar()
    grammar_0.load(filename)

# Generated at 2022-06-25 14:39:51.883319
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_1 = Grammar()
    grammar_1.dump("test.pkl")
    grammar_1.load("test.pkl")
    assert grammar_1 == grammar_0



# Generated at 2022-06-25 14:39:54.952147
# Unit test for method dump of class Grammar
def test_Grammar_dump(): pass

    # TODO: Uncomment and write test case
# def test_Grammar_dump():
#     grammar_0 = Grammar()
#     tmpFileName = tempfile.NamedTemporaryFile()
#     grammar_0.dump(tmpFileName)


# Generated at 2022-06-25 14:39:56.251321
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    s = ""
    grammar_1.dump(s)


# Generated at 2022-06-25 14:40:07.005925
# Unit test for method load of class Grammar
def test_Grammar_load():
    import io
    import pickle
    grammar_1 = Grammar()

# Generated at 2022-06-25 14:40:09.996786
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    test_case_0()
    filename = "pgen2_temp.py"
    grammar_0.dump(filename)
    grammar_0.load(filename)
    grammar_0.report()



# Generated at 2022-06-25 14:40:19.975575
# Unit test for method load of class Grammar
def test_Grammar_load():

    # Test case 0:
    #    Load sample grammar from stdout.
    #    The grammar tables are dumped using stdout in this case.
    a = Grammar()

# Generated at 2022-06-25 14:40:20.952682
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    test_case_0()


# Generated at 2022-06-25 14:40:31.367681
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load('./test_pgen/g_0.pickle')
    assert grammar.keywords == {'False': 8, 'None': 7, 'True': 9}
    assert grammar.symbol2number == {'error_leaf': 260, 'error_node': 261, 'file_input': 5, 'funcdef': 257, 'lambdef': 258, 'stmt': 259, 'trailer': 33, 'varargslist': 37, 'fpdef': 271, 'simple_stmt': 256}
    assert grammar.start == 5

# Generated at 2022-06-25 14:40:33.497814
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('pytree.pickle.grammar')


# Generated at 2022-06-25 14:40:39.705515
# Unit test for method load of class Grammar
def test_Grammar_load():
    try:
        grammar_1 = Grammar()
        filename_1 = "data/pickle/Grammar.pkl"
        grammar_1.load(filename_1)
    except:
        assert False, "Cannot load data/pickle/Grammar.pkl"


# Generated at 2022-06-25 14:40:41.328162
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('/tmp/grammar_0.pkl')


# Generated at 2022-06-25 14:40:42.030185
# Unit test for method dump of class Grammar

# Generated at 2022-06-25 14:40:43.494407
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump('/tmp/test_Grammar_dump')


# Generated at 2022-06-25 14:40:46.457051
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    import tempfile
    with tempfile.NamedTemporaryFile() as f:
        grammar_0.dump(f.name)


# Generated at 2022-06-25 14:40:47.706478
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    grammar_0 = Grammar()
    grammar_0.dump(None)

    assert True


# Generated at 2022-06-25 14:40:49.493233
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("grammar_0.pkl")


# Generated at 2022-06-25 14:40:50.355662
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()


# Generated at 2022-06-25 14:40:52.115139
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = test_case_0()
    grammar.dump(os.path.abspath('filename'))


# Generated at 2022-06-25 14:40:53.830979
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("test_data/test_case_0.pickle")


# Generated at 2022-06-25 14:40:59.455672
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = None
    grammar_0 = Grammar()
    grammar_0.load(filename)


# Generated at 2022-06-25 14:41:01.379786
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('/tmp/grammar.py')
    grammar_0.load('/tmp/grammar.py')


# Generated at 2022-06-25 14:41:06.392756
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump("test/test_grammar-1.pickle")
    assert os.path.exists("test/test_grammar-1.pickle")
    os.remove("test/test_grammar-1.pickle")



# Generated at 2022-06-25 14:41:08.983792
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("Grammar.pickle")


# Generated at 2022-06-25 14:41:12.604385
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump("dump_dump.out")  # pickle.dump
    grammar_1.dump("dump_dump.pkl")  # pickle.dump
    grammar_1.dump("dump_dump.pickle")  # pickle.dump


# Generated at 2022-06-25 14:41:14.806598
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('./pgen2-ast/test/test_grammar.py')


# Generated at 2022-06-25 14:41:22.127573
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import tempfile
    import os
    temp_dir = tempfile.TemporaryDirectory()
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir.name)
    # We want the file name but not the file handle
    temp_file_name = temp_file.name
    temp_file.close()
    grammar = Grammar()
    grammar.dump(temp_file_name)
    assert os.path.isfile(temp_file_name)
    temp_dir.cleanup()


# Generated at 2022-06-25 14:41:23.651493
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump("test_ast.t")


# Generated at 2022-06-25 14:41:25.430625
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    try:
        grammar_0.load("test")
    except:
        pass


# Generated at 2022-06-25 14:41:27.196365
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    try:
        grammar_0.dump(str)
    except TypeError:
        assert True
    else:
        assert False



# Generated at 2022-06-25 14:41:33.955411
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Replace with using temp file for pytest
    grammar_1 = Grammar()
    base = './test_grammar_dump'
    grammar_1.dump(base)
    grammar_2 = Grammar()
    grammar_2.load(base)
    grammar_2.dump(base)



# Generated at 2022-06-25 14:41:34.820597
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_load = Grammar()


# Generated at 2022-06-25 14:41:39.139620
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    # Prepare data
    grammar_1.symbol2number = {'test_symbol2number_0': 0}
    grammar_1.number2symbol = {0: 'test_number2symbol_0'}
    # testing method dump
    grammar_1.dump('testfile')


# Generated at 2022-06-25 14:41:43.788756
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load("./Parser/Grammar.py")
    assert grammar_1.labels == [(0, 'EMPTY')]
    assert grammar_1.states == []


# Generated at 2022-06-25 14:41:48.363346
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    with tempfile.TemporaryDirectory() as tmpdirname:
        grammar.dump(os.path.join(tmpdirname, "test_Grammar_dump.pkl"))
        grammar.load(os.path.join(tmpdirname, "test_Grammar_dump.pkl"))


# Generated at 2022-06-25 14:41:50.032305
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_1 = Grammar()
    filename_1 = "py25.grammar"
    grammar_1.dump(filename_1)


# Generated at 2022-06-25 14:41:50.536743
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    test_case_0()

# Generated at 2022-06-25 14:41:52.058282
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("foo.pickle")


# Generated at 2022-06-25 14:41:53.175535
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump('test')


# Generated at 2022-06-25 14:41:54.303444
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("grammar.txt")

# Generated at 2022-06-25 14:42:03.982528
# Unit test for method load of class Grammar
def test_Grammar_load():
    # pylint: disable=no-self-use

    g = Grammar()

    (fd, filename) = tempfile.mkstemp()
    with os.fdopen(fd, "wb") as f:
        g.dump(f)
    g2 = Grammar()
    g2.load(filename)

    # (IOW, Grammar.dump serializes in a way that Grammar.load
    # consumes.  We aren't testing the actual format of the pickle,
    # just that Grammar.dump produces a serialization that
    # Grammar.load consumes.)

    os.unlink(filename)



# Generated at 2022-06-25 14:42:07.746085
# Unit test for method load of class Grammar
def test_Grammar_load():
    f = "/home/mpaul/python/lib/python3.5/lib2to3/Grammar.pickle"
    g = Grammar()
    g.load(f)


# Generated at 2022-06-25 14:42:11.424181
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load("Lib/test/badsyntax_3141.grammar")
    grammar_1.load("Tokens.grammar")
    grammar_1.load("Lib/test/badsyntax_3141.grammar")


if __name__ == "__main__":
    test_case_0()
    test_Grammar_load()

# Generated at 2022-06-25 14:42:17.776487
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    import os, os.path
    from pygram.pgen2.pgen import driver

    rcp = driver.main(["-o", ".pygram-test.%s.pickle" % (os.getpid(),), "Grammar.txt"])
    if rcp:
        raise SystemExit(rcp)

    grammar_1 = Grammar()
    grammar_1.load(".pygram-test.%s.pickle" % (os.getpid(),))
    os.unlink(".pygram-test.%s.pickle" % (os.getpid(),))

# Generated at 2022-06-25 14:42:20.216433
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.start = 256

    grammar_0.dump('/tmp/grammar.pickle')


# Generated at 2022-06-25 14:42:24.744742
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("grammar1.txt")
    f = open("grammar1.txt")
    try:
        grammar = pickle.load(f)
    except (EOFError, pickle.UnpicklingError):
        assert False
    else:
        assert True



# Generated at 2022-06-25 14:42:26.591826
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump("../tests/build/t_pickle.pickle")


# Generated at 2022-06-25 14:42:31.225675
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
# Assigning to attribute __file__ of built-in module os
    os.__file__ = '__builtin__'
# Assigning to attribute __file__ of built-in module os
    os.__file__ = '/usr/local/Cellar/python@3.8/3.8.2_1/Frameworks/Python.framework/Versions/3.8/lib/python3.8/os.py'

# Generated at 2022-06-25 14:42:33.055775
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()


# Generated at 2022-06-25 14:42:34.656107
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("python_files")


# Generated at 2022-06-25 14:42:37.625520
# Unit test for method load of class Grammar
def test_Grammar_load():
    pass

# Generated at 2022-06-25 14:42:44.871729
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("./fixtures/single.pkl")
    assert grammar.start == 256
    assert grammar.symbol2number == {'single_input': 257}
    assert grammar.number2symbol == {256: 'file_input', 257: 'single_input'}

# Generated at 2022-06-25 14:42:54.518998
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    with tempfile.NamedTemporaryFile(mode='r+b') as tmpfile:
        tmp_name = tmpfile.name
        grammar_0 = Grammar()
        grammar_0.dump(tmp_name)
        with open(tmp_name, "rb") as f:
            d = pickle.load(f)
        for dict_attr in (
            "symbol2number",
            "number2symbol",
            "dfas",
            "keywords",
            "tokens",
            "symbol2label",
        ):
            assert d[dict_attr] == getattr(grammar_0, dict_attr)
        assert d["labels"] == grammar_0.labels
        assert d["states"] == grammar_0.states
        assert d["start"] == grammar_0.start
        assert d

# Generated at 2022-06-25 14:43:03.111562
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = "Grammar.pickle"
    grammar = Grammar()
    grammar.load(filename)
    import sys
    import io
    import token
    import tokenize
    import builtins
    from typing import List

    def runTest () -> None:
        old_stdin = sys.stdin
        sys.stdin = io.StringIO("a = 255 * 2")

# Generated at 2022-06-25 14:43:05.731232
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Instance to test load
    grammar_0 = Grammar()
    assert grammar_0.load(None) is None
    grammar_0.dump(None)


# Generated at 2022-06-25 14:43:09.197571
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("C:/Users/H/PycharmProjects/untitled2/venv/test/test_dump.py")


# Generated at 2022-06-25 14:43:12.899179
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    fn_0 = tempfile.mktemp()
    try:
        g_0 = Grammar()
        g_0.dump(fn_0)
    finally:
        try:
            os.remove(fn_0)
        except (OSError, IOError):
            pass



# Generated at 2022-06-25 14:43:14.335736
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('/tmp/pgen_test')


# Generated at 2022-06-25 14:43:15.951675
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump("grammar.pickle")


# Generated at 2022-06-25 14:43:18.577413
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar() # 
    grammar_1 = Grammar() # 
    grammar_2 = Grammar() # 
    grammar_2.dump(grammar_1) # 
    grammar_0.dump(grammar_1) # 


# Generated at 2022-06-25 14:43:24.372302
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("g.pickle")

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 14:43:25.438219
# Unit test for method load of class Grammar
def test_Grammar_load():
    test_case_0()



# Generated at 2022-06-25 14:43:27.401982
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("test_dump.py")
    assert os.path.isfile("test_dump.py")


# Generated at 2022-06-25 14:43:30.405968
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = "Filename.txt"
    grammar_0 = Grammar()
    grammar_0.dump(filename)


# Generated at 2022-06-25 14:43:36.545347
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.number2symbol[256] = "file_input"
    fp = tempfile.NamedTemporaryFile(mode="w+b", delete=False)
    pickle.dump(vars(g), fp, pickle.HIGHEST_PROTOCOL)
    fp.close()
    g2 = Grammar().load(fp.name)
    os.unlink(fp.name)
    assert vars(g) == vars(g2)

# Generated at 2022-06-25 14:43:40.226710
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()

    # Pickle file is created in current directory, should be
    # able to load it
    grammar_0.dump('test_Grammar_load.pkl')
    grammar_0.load('test_Grammar_load.pkl')

    os.remove('test_Grammar_load.pkl')

# Generated at 2022-06-25 14:43:43.469030
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    temp_file_0 = tempfile.NamedTemporaryFile()
    filename = temp_file_0.name
    grammar_1.dump(filename)
    temp_file_0.close()
    os.remove(filename)
    # Delete tempfile created by method dump of class Grammar


# Generated at 2022-06-25 14:43:50.596223
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    filename_0 = "pytree_dump.txt"
    # Pickle the default grammar
    grammar_0.dump(filename_0)
    # Pickle the case grammar
    grammar_0 = Grammar()
    grammar_0.start = 257
    grammar_0.dfas = {}
    grammar_0.keywords = {}
    grammar_0.number2symbol = {}
    grammar_0.states = []
    grammar_0.symbol2number = {}
    grammar_0.symbol2label = {}
    grammar_0.tokens = {}
    filename_0 = "pytree_dump.txt"
    grammar_0.dump(filename_0)


# Generated at 2022-06-25 14:43:54.096618
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    fd, filename = tempfile.mkstemp(text=False)
    os.close(fd)
    try:
        g = Grammar()
        g.dump(filename)
    finally:
        os.remove(filename)


# Generated at 2022-06-25 14:44:00.085257
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    assert grammar.start == 256
    temp_file_name = tempfile.NamedTemporaryFile(delete=False).name
    grammar.dump(temp_file_name)
    grammar.load(temp_file_name)
    assert grammar.start == 256
    os.remove(temp_file_name)

# Generated at 2022-06-25 14:44:03.658938
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    test_case_0()


# Generated at 2022-06-25 14:44:05.079362
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("__init__.pyi")


# Generated at 2022-06-25 14:44:06.931513
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()



# Generated at 2022-06-25 14:44:11.102663
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    old_start = grammar.start
    grammar.loads(pickle.dumps(grammar.__dict__))
    assert grammar.start == old_start
    grammar.loads(pickle.dumps(grammar.__getstate__()))
    assert grammar.start == old_start



# Generated at 2022-06-25 14:44:13.635512
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Test for Grammar.load."""
    grammar = Grammar()
    grammar.load("Grammar.pickle")
    grammar.report()



# Generated at 2022-06-25 14:44:14.996217
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("grammar.pickle")


# Generated at 2022-06-25 14:44:17.310476
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    # Pickling with HIGHEST_PROTOCOL is a lot faster than pickling
    # with the default protocol.
    grammar.dump(os.path.join(tempfile.gettempdir(), "grammar.pickle"))

# Generated at 2022-06-25 14:44:21.674166
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename=tempfile.NamedTemporaryFile()
    Grammar().dump(filename)
    assert os.path.isfile(filename)
    # filename is not a real file but a in-memory file
    os.remove(filename.name)


# Generated at 2022-06-25 14:44:23.989121
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    assert grammar_0.dump(filename="./test/Grammar/out0.pickle") is None


# Generated at 2022-06-25 14:44:26.702595
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load(os.path.join(os.path.dirname(__file__),"Grammar.py"))


# Generated at 2022-06-25 14:44:34.395589
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.start = 256
    grammar_1.number2symbol = {}
    grammar_1.tokens = {}
    grammar_1.labels = []
    grammar_1.async_keywords = False
    grammar_1.keywords = {}
    grammar_1.symbol2label = {}
    grammar_1.states = []
    grammar_1.symbol2number = {}
    grammar_1.dfas = {}
    grammar_1.dump("test_pgen_grammar_dump.pickle")


# Generated at 2022-06-25 14:44:35.563153
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump('file.pickle')


# Generated at 2022-06-25 14:44:37.357242
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    with pytest.raises(AttributeError):
        grammar_0.dump(filename=None)



# Generated at 2022-06-25 14:44:48.618820
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.symbol2number = {'test_symbol2number_0': 0}
    grammar_0.number2symbol = {0: 'test_number2symbol_0'}

# Generated at 2022-06-25 14:44:57.633178
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    fd = open('Grammar_t06.pkl', 'wb+')

# Generated at 2022-06-25 14:44:59.213309
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump("grammar")


# Generated at 2022-06-25 14:45:02.686690
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    with tempfile.NamedTemporaryFile(delete=False) as f:
        dumpf = f.name
    try:
        grammar_1.dump(dumpf)
    except AttributeError:
        pass
    else:
        assert False, "Dump failed"
    finally:
        os.unlink(dumpf)


# Generated at 2022-06-25 14:45:04.724632
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    filename_0 = "py3.6/Grammar/Grammar.pickle"
    grammar_0.load(filename_0)


# Generated at 2022-06-25 14:45:10.931909
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    try:
        f = open('test_Grammar_dump.pkl', 'wb')
        grammar_0.dump(f)
    except Exception as e:
        raise Exception('Failed in dumping grammar. ' + str(e))
    finally:
        f.close()

if __name__ == "__main__":
    test_case_0()
    test_Grammar_dump()

# Generated at 2022-06-25 14:45:13.663532
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    dump_0 = Grammar()
    try:
        dump_0.dump("/home/vagrant/pycharm-debug.egg")
    except IOError:
        assert False
    assert True


# Generated at 2022-06-25 14:45:19.037160
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump(r"C:\dev\py\test.pkl")


if __name__ == "__main__":
    import sys

    sys.exit(unittest.main())

# Generated at 2022-06-25 14:45:20.349469
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    assert grammar_0.dump(token.NAME)



# Generated at 2022-06-25 14:45:22.856999
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump("../data/Grammar-dump")


# Generated at 2022-06-25 14:45:26.739937
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump(tempfile.mktemp())
    grammar_1.loads(grammar_1.dump(""))

if __name__ == "__main__":
    test_case_0()
    print("test_case_0")
    test_Grammar_dump()
    print("test_Grammar_dump")

# Generated at 2022-06-25 14:45:27.828196
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump()


# Generated at 2022-06-25 14:45:29.724767
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    filename = "test_dump.dat"
    grammar_0.dump(filename)



# Generated at 2022-06-25 14:45:40.607892
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.symbol2number = {"key": 1}
    grammar_0.number2symbol = {1: "value"}
    grammar_0.states = [[(0, 1), (1, 2)], [(3, 2)]]
    grammar_0.dfas = {1: ([(2, 3)], {"key": 1}), 2: ([(0, 1)], {"key": 2})}
    grammar_0.labels = [(1, "value"), (2, "value1")]
    grammar_0.keywords = {"key": 1}
    grammar_0.tokens = {1: 1, 2: 3}
    grammar_0.symbol2label = {"key": 1}
    grammar_0.start = 256
    grammar_0.async_keywords

# Generated at 2022-06-25 14:45:43.089081
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = "test.pkl"
    if os.path.exists(filename):
        os.unlink(filename)
    test_case_0().dump(filename)
    assert os.path.exists(filename)
    os.unlink(filename)


# Generated at 2022-06-25 14:45:50.217634
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load('/python/version/source/pypy/pypy/interpreter/pyparser/Grammar.py')


if __name__ == "__main__":
    grammar = Grammar()
    grammar.load('/python/version/source/cpython/Lib/pypy/pypy/interpreter/pyparser/Grammar.py')

# Generated at 2022-06-25 14:45:51.465995
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump(grammar_0)


# Generated at 2022-06-25 14:45:57.051733
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    filename = "temp.pickle"
    grammar.dump(filename)
    if os.path.exists(filename):
        os.remove(filename)


# Generated at 2022-06-25 14:46:07.853588
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import stat
    import errno
    import sys
    try:
        test_case_0()
    except OSError as e:
        if e.errno != errno.EEXIST:
            raise
    else:
        grammar_0 = Grammar()
        os.mkdir("/tmp/tmp_1")
        try:
            grammar_0.dump("/tmp/tmp_1/tmp_2")
            os.remove("/tmp/tmp_1/tmp_2")
        finally:
            os.rmdir("/tmp/tmp_1")

        grammar_0 = Grammar()
        os.makedirs("/tmp/tmp_3/tmp_4")

# Generated at 2022-06-25 14:46:10.982756
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    print("Test dump() method on Grammar class")
    grammar_0 = Grammar()
    grammar_0.dump("grammar.pickle")


# Generated at 2022-06-25 14:46:14.440069
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    fname = os.path.join(tempfile.gettempdir(), "test_dump.pkl")
    grammar_0 = Grammar()
    grammar_0.dump(fname)
    os.remove(fname)


# Generated at 2022-06-25 14:46:21.615095
# Unit test for method load of class Grammar
def test_Grammar_load():
    #the code came from the parse module
    #the changes are documented by the comments
    path = "./"

    def get_filename():
        for fn in ("python3.4", "python3.5", "python3.6", "python3.7", "python3.8"):
            ffn = os.path.join(path, fn + ".grammar.pickle")
            if os.path.exists(ffn):
                return ffn
            ffn = os.path.join(path, fn + ".grammar.pickle.out")
            if os.path.exists(ffn):
                return ffn

    grammar_1 = grammar_0.load(get_filename())


# Generated at 2022-06-25 14:46:30.808344
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("D:\\data\\bro\\grammar.pickle")
    grammar_0.load("D:\\data\\bro\\grammar.pickle")

# Generated at 2022-06-25 14:46:33.244238
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load('test/data/grammar.py')



# Generated at 2022-06-25 14:46:35.907278
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("grammar.pgen")
    gamma = Grammar()
    gamma.load("grammar.pgen")
    gamma.report()

test_case_0()
test_Grammar_dump()