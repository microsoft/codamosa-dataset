

# Generated at 2022-06-25 14:36:54.638074
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    # grammar_0.load()
    # grammar_0.load()
    # assert grammar_0.load() == "load", "Wrong result for Grammar.load()"



# Generated at 2022-06-25 14:36:55.403984
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump()

# Generated at 2022-06-25 14:36:57.969866
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("Grammar_dump.pkl")


# Generated at 2022-06-25 14:36:59.612025
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('test_file_0')


# Generated at 2022-06-25 14:37:03.651596
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    try:
        grammar.load('lib2to3/Grammar.pickle')
    except OSError:
        raise unittest.SkipTest("no Grammar.pickle, test skipped")
    grammar.loads(grammar.loads.__wrapped__())

# Generated at 2022-06-25 14:37:06.615357
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    filename_0 = (os.path.dirname(__file__))
    grammar_0.dump(filename_0)
    grammar_0.load(filename_0)
    grammar_0.loads(b'')
    grammar_0.copy()


# Generated at 2022-06-25 14:37:08.508166
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("/dev/null")


# Generated at 2022-06-25 14:37:10.546698
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    assert grammar_0.dump('python3.7/Grammar.pickle') == None,\
        "Return value from test is not as expected"


# Generated at 2022-06-25 14:37:13.324767
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("/home/emma/Documents/python/python3-t3-master/pgen/Grammar.pickle")


# Generated at 2022-06-25 14:37:17.126346
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    try:
        grammar_1.load("grammar")
        raise Exception("TODO: load the grammar from a file")
    except EOFError:
        pass


# Generated at 2022-06-25 14:37:24.682528
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    # grammar_0.dump("/Users/david/workspace/python/python/build/lib/lib2to3/Grammar.dump")


# Generated at 2022-06-25 14:37:27.661014
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()

    grammar_0.dump(filename = "grammar_0.pickle")
    # Implemented using temporary file and atomic rename
    # to avoid exposure of a partially created file.
    os.unlink("grammar_0.pickle")



# Generated at 2022-06-25 14:37:29.037022
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("gen_00/__main__.py.grammar")


# Generated at 2022-06-25 14:37:31.968886
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("reader.pickle")


# Generated at 2022-06-25 14:37:35.032108
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(__file__[:-1] + 'pkl')
    Grammar().loads(open(__file__[:-1] + 'pkl', 'rb').read())


# Generated at 2022-06-25 14:37:44.873987
# Unit test for method dump of class Grammar
def test_Grammar_dump(): # Grammar_dump_test
    grammar_1 = Grammar()
    grammar_1.dfas = {}
    grammar_1.keywords = {}
    grammar_1.labels = [(0, "EMPTY")]
    grammar_1.number2symbol = {}
    grammar_1.start = 256
    grammar_1.states = []
    grammar_1.symbol2number = {}
    grammar_1.symbol2label = {}
    grammar_1.tokens = {}

# Write the file name to a pickle file
    grammar_1.dump("./temp/parse_py_grammar")

# Open the file and read to check correctness
    with open("./temp/parse_py_grammar", "r") as f:
        file_content = f.readlines()

# Generated at 2022-06-25 14:37:46.765366
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.report()
#
# test_Grammar_load()
#

# Generated at 2022-06-25 14:37:48.457252
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("test/test_grammar_0.pkl")


# Generated at 2022-06-25 14:37:54.603188
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    with tempfile.NamedTemporaryFile(delete=False) as tmp_file:
        fn = tmp_file.name
    grammar_1.dump(fn)
    with open(fn, "rb") as tmp_file:
        grammar_2 = Grammar()
        grammar_2.loads(tmp_file.read())


if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-25 14:38:04.447040
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()

# Generated at 2022-06-25 14:38:20.738487
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()

# Generated at 2022-06-25 14:38:31.474498
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()

# Generated at 2022-06-25 14:38:41.970449
# Unit test for method load of class Grammar
def test_Grammar_load():
    f = open(os.path.join(os.path.dirname(__file__), "Grammar.pkl"), "rb")
    grammar_0 = Grammar()
    grammar_0.loads(f.read())
    f.close()

if __name__ == "__main__":
    import sys
    import argparse
    from .pgen2 import driver

    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--test",
        action="store_true",
        help="run built-in test cases",
    )
    options = parser.parse_args()

    if options.test:
        test_case_0()
        test_Grammar_load()
    else:
        driver.Driver(Grammar, sys.argv[1:])

# Generated at 2022-06-25 14:38:46.762920
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    paths_0 = grammar_0.dump("D:\\USERS\\A6U5W8\\PycharmProjects\\test_python_jedi\\Parser\\temp\\tmp.pkl")


# Generated at 2022-06-25 14:38:55.330089
# Unit test for method dump of class Grammar

# Generated at 2022-06-25 14:39:02.524249
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g0 = Grammar()
    g0.dump("/tmp/parsetab.pkl")
    g1 = Grammar()
    g1.load("/tmp/parsetab.pkl")
    g1.dump("/tmp/parsetab2.pkl")
    g2 = Grammar()
    g2.load("/tmp/parsetab2.pkl")
    assert g0.__dict__ == g1.__dict__
    assert g1.__dict__ == g2.__dict__

if __name__ == "__main__":
    import types
    import sys
    import inspect
    import pprint

# Generated at 2022-06-25 14:39:03.685702
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("./Grammar.pkl")


# Generated at 2022-06-25 14:39:05.334214
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("./pgen/Grammar_1.pickle")


# Generated at 2022-06-25 14:39:07.196088
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2

    s = pgen2.driver.load_grammar("Python37.g4")
    grammar_0 = Grammar()
    grammar_0.loads(s)

# Generated at 2022-06-25 14:39:10.154644
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    filename = tempfile.NamedTemporaryFile().name
    grammar.dump(filename)
    grammar.load(filename)
    grammar.loads(open(filename, "rb").read())

# Generated at 2022-06-25 14:39:23.304975
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("graphics/tokenize.grammar")

# Generated at 2022-06-25 14:39:24.500158
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("test.txt")


# Generated at 2022-06-25 14:39:27.739749
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    try:
        grammar_0.load('test_grammar.pkl')
    except IOError:
        pass


# Generated at 2022-06-25 14:39:37.470764
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_1 = Grammar()

# Generated at 2022-06-25 14:39:40.286399
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("./Grammar_data.pickle")


# Generated at 2022-06-25 14:39:41.326242
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_dump = Grammar()
    grammar_dump.dump('dump')


# Generated at 2022-06-25 14:39:42.072942
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("Grammar.txt")

# Generated at 2022-06-25 14:39:43.238721
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("f.pkl")


# Generated at 2022-06-25 14:39:48.236133
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    tf = tempfile.NamedTemporaryFile(delete=False)
    tf.close()
    try:
        grammar_1 = Grammar()

        grammar_1.dump(tf.name)
    finally:
        os.remove(tf.name)



# Generated at 2022-06-25 14:39:51.305412
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    with tempfile.NamedTemporaryFile(delete=False) as f:
        grammar_1.dump(f.name)


# Generated at 2022-06-25 14:39:57.575890
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("./Python-3.7.3/Lib/compileall.py")


# Generated at 2022-06-25 14:40:01.191554
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_dump_0 = Grammar()
    grammar_dump_0.dump('/tmp/test_case_1.py')


# Generated at 2022-06-25 14:40:02.997096
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_dump = Grammar()
    assert grammar_dump is not None

    grammar_dump.dump('test_Grammar_dump')


# Generated at 2022-06-25 14:40:06.023365
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()

    filename = './testdata/output/grammar_0.test_Grammar_dump.test.pickle'
    grammar_0.dump(filename)


# Generated at 2022-06-25 14:40:08.454638
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_2 = Grammar()
    grammar_2.load('./pgen2/python37.pkl')


# Generated at 2022-06-25 14:40:09.959079
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = 'filename'
    grammar = Grammar()
    grammar.load(filename)


# Generated at 2022-06-25 14:40:14.616879
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load('/Users/dan/pylint/pylint/pylint/utils/pgen2/Grammar')
    grammar_1.load('/Users/dan/pylint/pylint/pylint/utils/pgen2/Grammar')


# Generated at 2022-06-25 14:40:20.913198
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    dump_test_file = os.path.join(tempfile.gettempdir(), "test_dump")
    try:
        grammar_0 = Grammar()

        # Case 1: dump to test file
        grammar_0.dump(dump_test_file)

        # Case 2: dump again to the same test file
        grammar_0.dump(dump_test_file)
    finally:
        if os.path.exists(dump_test_file):
            os.remove(dump_test_file)


# Generated at 2022-06-25 14:40:31.369118
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load(os.path.join(os.path.dirname(__file__), 'Grammar.pickle'))
    assert len(grammar_0.keywords) == 133
    assert grammar_0.symbol2number['stmt'] == 261
    assert grammar_0.number2symbol[261] == 'stmt'
    assert grammar_0.symbol2number['factor'] == 296
    assert grammar_0.number2symbol[296] == 'factor'
    assert grammar_0.states[0][0][0][1] == 2
    assert len(grammar_0.tokens) == 103
    assert len(grammar_0.labels) == 611
    assert grammar_0.dfas[286][1][token.STRING] == 1

# Generated at 2022-06-25 14:40:35.099868
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('/Users/mstarmans/code/mstarmans/Typed-ast-repr/test_fixtures/grammar_0.pickle')



# Generated at 2022-06-25 14:40:39.156071
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_1 = Grammar()


# Generated at 2022-06-25 14:40:40.481715
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    # grammar_0.dump(filename_0)


# Generated at 2022-06-25 14:40:43.184105
# Unit test for method load of class Grammar
def test_Grammar_load():
    """
    This is a test for Grammar.load(), 
    """
    grammar_0 = test_case_0()
    grammar_0.load("test_data")


# Generated at 2022-06-25 14:40:46.144404
# Unit test for method load of class Grammar
def test_Grammar_load():
    file_name = "./Syntax/Grammar.pkl"
    grammar_0 = Grammar()
    grammar_0.load(file_name)



# Generated at 2022-06-25 14:40:49.924982
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("/usr/local/lib/python3.5/dist-packages/pgen/grammar-1.5")
    # verify that grammar_0 has the right number of states
    assert len(grammar_0.states) == 1


# Generated at 2022-06-25 14:40:52.003711
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_1 = Grammar()
    grammar_0.load('')
    grammar_1.load('')


# Generated at 2022-06-25 14:40:55.046412
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    filename_0 = "test_Grammar_load.str"
    grammar_0.dump(filename_0)
    grammar_0.load(filename_0)
    os.remove(filename_0)


# Generated at 2022-06-25 14:40:56.283571
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))


# Generated at 2022-06-25 14:40:57.625940
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load()


# Generated at 2022-06-25 14:41:00.673656
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Testing for failure when attempting to dump grammar tables to a pickle file.
    grammar_1 = Grammar()
    with pytest.raises(pickle.PicklingError):
        grammar_1.dump('/tmp/None.py')


# Generated at 2022-06-25 14:41:06.392396
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    s = 'asdf'
    try:
        g.load(s)
        raise AssertionError('expected TypeError')
    except TypeError:
        pass



# Generated at 2022-06-25 14:41:08.950278
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load("../Grammar.pkl")


# Generated at 2022-06-25 14:41:12.565178
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    # Change the following lines for testing
    temp_file = tempfile.NamedTemporaryFile()
    temp_file_name = temp_file.name
    grammar_0.dump(temp_file_name)
    temp_file.close()


# Generated at 2022-06-25 14:41:22.882300
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()

    # First run
    grammar_0.dump('/tmp/tmp4c_bfh.out')
    grammar_1 = Grammar()
    grammar_1.load('/tmp/tmp4c_bfh.out')

    assert grammar_1.symbol2number == grammar_0.symbol2number
    assert grammar_1.number2symbol == grammar_0.number2symbol
    assert grammar_1.states == grammar_0.states
    assert grammar_1.dfas == grammar_0.dfas
    assert grammar_1.labels == grammar_0.labels
    assert grammar_1.keywords == grammar_0.keywords
    assert grammar_1.tokens == grammar_0.tokens
    assert grammar_1.symbol2label == grammar_0.sy

# Generated at 2022-06-25 14:41:24.379300
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('/tmp/grammar.pkl')


# Generated at 2022-06-25 14:41:25.801557
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = "data/tmp/test.pickle"
    test_case_0().dump(filename)


# Generated at 2022-06-25 14:41:27.019965
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('./grammar.pickle')


# Generated at 2022-06-25 14:41:32.584744
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("Grammar.pickle")
    assert grammar.symbol2number["LPAR"] == 256, "Failed to load Grammar.pickle"
    assert grammar.symbol2number["STAR"] == 264, "Failed to load Grammar.pickle"
    assert grammar.symbol2number["ASSIGN"] == 275, "Failed to load Grammar.pickle"
    assert grammar.symbol2number["break_stmt"] == 306, "Failed to load Grammar.pickle"
    assert grammar.symbol2number["decorated"] == 438, "Failed to load Grammar.pickle"
    assert grammar.symbol2number["encoding_decl"] == 495, "Failed to load Grammar.pickle"

# Generated at 2022-06-25 14:41:37.363519
# Unit test for method load of class Grammar
def test_Grammar_load():
    """grammar.load

    Check a grammar can be pickled and loaded again."""

    grammar_0 = test_case_0()

    with tempfile.NamedTemporaryFile() as tf:
        fname = tf.name

    grammar_0.dump(fname)
    # is this needed?
    grammar_0 = Grammar()
    grammar_0.load(fname)



# Generated at 2022-06-25 14:41:41.654043
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    grammar_tmp = Grammar()
    grammar_tmp.dump("grammar.pickle")

    grammar_loaded = Grammar()
    grammar_loaded.load("grammar.pickle")

    assert grammar_tmp.symbol2number == grammar_loaded.symbol2number
    assert grammar_tmp.number2symbol == grammar_loaded.number2symbol
    assert grammar_tmp.states == grammar_loaded.states
    assert grammar_tmp.dfas == grammar_loaded.dfas
    assert grammar_tmp.labels == grammar_loaded.labels
    assert grammar_tmp.keywords == grammar_loaded.keywords
    assert grammar_tmp.tokens == grammar_loaded.tokens
    assert grammar_tmp.symbol2label == grammar_loaded.symbol2label
    assert grammar_tmp.start == grammar_loaded.start

# Generated at 2022-06-25 14:41:47.046714
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    path_0 = os.path.join(os.path.dirname(__file__), "Grammar.pkl")
    grammar_1.load(path_0)


# Generated at 2022-06-25 14:41:49.820272
# Unit test for method load of class Grammar
def test_Grammar_load():

    # Initialization
    grammar_0 = Grammar()

    grammar_0.load(".\\Grp_Cmplx_0")


# Generated at 2022-06-25 14:41:57.672388
# Unit test for method load of class Grammar
def test_Grammar_load():

    from .conv import Convertor
    from .pgen import tokenize

    grammar_0 = Grammar()
    grammar_1 = Grammar()
    grammar_2 = Grammar()
    grammar_3 = Grammar()
    grammar_4 = Grammar()
    grammar_5 = Grammar()
    grammar_6 = Grammar()
    grammar_7 = Grammar()
    grammar_8 = Grammar()
    grammar_9 = Grammar()
    grammar_10 = Grammar()
    grammar_11 = Grammar()
    grammar_12 = Grammar()
    grammar_13 = Grammar()
    grammar_14 = Grammar()
    grammar_15 = Grammar()
    grammar_16 = Grammar()
    grammar_17 = Grammar()
    grammar_18 = Grammar()
    grammar_19 = Grammar()
    grammar

# Generated at 2022-06-25 14:41:59.025439
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load("Grammar.pickle")


# Generated at 2022-06-25 14:42:00.743271
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("tests/data/pgen_dump.pickle")


# Generated at 2022-06-25 14:42:03.248137
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("Parser/Grammar.pickle")
    assert grammar.start == 256



# Generated at 2022-06-25 14:42:05.847490
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load(BytesIO())


# Generated at 2022-06-25 14:42:12.598981
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import tempfile

    # mypyc generates objects that don't have a __dict__, but they
    # do have __getstate__ methods that will return an equivalent
    # dictionary
    if hasattr(grammar_0, "__dict__"):
        d = grammar_0.__dict__
    else:
        d = grammar_0.__getstate__()  # type: ignore

    with tempfile.NamedTemporaryFile(delete=False) as f:

        grammar_0.dump(f)

        f.seek(0, 0)
        assert pickle.load(f) == d
    os.unlink(f.name)


if __name__ == "__main__":

    import sys

    args = sys.argv[1:]
    if args and args[0] == "--test":
        import py

# Generated at 2022-06-25 14:42:14.656263
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("grammar_0.pkl")   #



# Generated at 2022-06-25 14:42:16.575409
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    assert grammar_0.dump("test")


# Generated at 2022-06-25 14:42:20.628301
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load("./test_data/grammar.pickle")

# Generated at 2022-06-25 14:42:25.117481
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("../../../.mypy_cache/cpython-37/pgen2/Grammar.pickle")
    grammar_0.load("../../../.mypy_cache/cpython-37/pgen2/Grammar.pickle")


# Generated at 2022-06-25 14:42:29.534106
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    f, a, b = tempfile.mkstemp(), grammar_0.start, grammar_0.states
    grammar_0.dump(f)
    pprint(a)
    pprint(b)
    assert (a == 256)
    assert (len(b) == 1)
    assert (b[0] == [[(0, 1)]])


# Generated at 2022-06-25 14:42:31.023242
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_0 = Grammar()
    grammar_0.load(grammar_1)

# Generated at 2022-06-25 14:42:40.886358
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Create object
    grammar = Grammar()
    # Call method
    grammar.load('\tmp\grammar.pickle')
    # Check if attribute 'symbol2number' is equal to expected value
    assert grammar.symbol2number == {1}, 'symbol2number should be equal to {1}'
    # Check if attribute 'number2symbol' is equal to expected value
    assert grammar.number2symbol == {1}, 'number2symbol should be equal to {1}'
    # Check if attribute 'states' is equal to expected value
    assert grammar.states == [2], 'states should be equal to [2]'
    # Check if attribute 'dfas' is equal to expected value
    assert grammar.dfas == {1: (3, 4)}, 'dfas should be equal to {1: (3, 4)}'


# Generated at 2022-06-25 14:42:44.905705
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    open(os.path.join(tempfile.gettempdir(),
                      "foo"), "w").close()
    grammar_1.dump(os.path.join(tempfile.gettempdir(),
                                "foo"))


# Generated at 2022-06-25 14:42:46.486330
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump(filename=None)



# Generated at 2022-06-25 14:42:50.212690
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    # Test Exception:
    try:
        grammar_0.dump(' grammar_0.dump')
    except Exception:
        pass



# Generated at 2022-06-25 14:42:52.331551
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump("..//Python37/lib/python3.7/grammar_2.py")



# Generated at 2022-06-25 14:42:53.706628
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load(b"<bytes>")



# Generated at 2022-06-25 14:42:58.811637
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import perl_grammar

    # Test with a real grammar
    grammar_1 = perl_grammar.perl_grammar
    grammar_1.dump("perl.pickle")



# Generated at 2022-06-25 14:43:01.336411
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('./grammar3_1.pickle')
    grammar_0.states
    grammar_0.start


# Generated at 2022-06-25 14:43:03.734142
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('/Users/cmurray/Documents/dev/cpython/Lib/test/grammar_pgen_test_0_0.pyc')


# Generated at 2022-06-25 14:43:05.682282
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load(file)


# Generated at 2022-06-25 14:43:09.501134
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump("tmp0.pkl")

    grammar_2 = Grammar()
    grammar_2.load("tmp0.pkl")


# Generated at 2022-06-25 14:43:17.749776
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("<string>")
    grammar_0.load("<string>")
    grammar_0.load("<string>")
    grammar_0.load("<string>")
    grammar_0.load("<string>")
    grammar_0.load("<string>")
    grammar_0.load("<string>")
    grammar_0.load("<string>")
    grammar_0.load("<string>")
    grammar_0.load("<string>")
    grammar_0.load("<string>")
    grammar_0.load("<string>")
    grammar_0.load("<string>")
    grammar_0.load("<string>")
    grammar_0.load("<string>")

# Generated at 2022-06-25 14:43:25.725073
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    # Create a temporary file for the grammar tables
    # Call method dump() to save the grammar tables in that file
    with tempfile.NamedTemporaryFile(delete=False) as f:
        filename = f.name
        grammar_1.dump(filename)
    # Open the file and try to read it as a pickle
    with open(filename, "rb") as g:
        pickle.load(g)



# Generated at 2022-06-25 14:43:26.559717
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_2 = Grammar()

# Generated at 2022-06-25 14:43:30.282886
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump(filename = "fixtures/test_grammar_0.py")


# Generated at 2022-06-25 14:43:35.036463
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    path_0 = os.path.join(os.getcwd(), 'grammar.pkl')

    grammar_0.dump(path_0)

    grammar_1 = Grammar()

    grammar_1.load(path_0)

    grammar_2 = Grammar()

    grammar_2.loads('')


# Generated at 2022-06-25 14:43:41.306405
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g_0 = Grammar()
    g_0.dump("test_pgen.pkl")


# Generated at 2022-06-25 14:43:43.205064
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    pass  # To be implemented or nothing to test()


# Generated at 2022-06-25 14:43:47.824058
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    try:
        grammar_0.dump('E:\\My Programs\\Python\\Ninja-IDE-master\\ninja_ide\\tools\\pynames\\pgen2\\grammar.py')
    except:
        print("Test Case 0 FAILED: Grammar.dump")

test_case_0()
test_Grammar_dump()
# End of unit test dump


# Generated at 2022-06-25 14:43:58.403112
# Unit test for method load of class Grammar
def test_Grammar_load():
    test_case_0()

if __name__ == "__main__":
    import sys
    import subprocess
    import timeit
    import random
    import math

    # Unit test
    random.seed(0)

    def test_case_0():
        grammar_0 = Grammar()

    def test_case_2():
        test_case_1()

    def test_case_1():
        test_case_0()
        grammar_0 = Grammar()

    def test_case_3():
        if grammar_0.keywords['except'] != 294:
            print("Failed")
            sys.exit(1)
        if grammar_0.tokens[-1] != 1:
            print("Failed")
            sys.exit(1)


# Generated at 2022-06-25 14:44:07.055612
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Unit test for method dump of class Grammar

    # Setup
    grammar = Grammar()
    grammar.symbol2number = {'class': 257, 'def': 258}
    grammar.number2symbol = {258: 'def', 257: 'class'}
    grammar.labels = [(0, 'EMPTY'), (1, 'NAME'), (257, 'NAME'), (258, 'NAME')]
    grammar.keywords = {'class': 257, 'def': 258}
    grammar.tokens = {1: 1}
    grammar.symbol2label = {'class': 257, 'def': 258}
    grammar.start = 257
    grammar.async_keywords = False


# Generated at 2022-06-25 14:44:09.746741
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    string_0 = """abc"""
    grammar_0.dump(string_0)


# Generated at 2022-06-25 14:44:13.100075
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    with tempfile.NamedTemporaryFile(delete=False) as f:
        grammar.dump(f.name)
    assert os.path.exists(f.name)
    os.remove(f.name)


# Generated at 2022-06-25 14:44:14.458673
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('../grammar/Grammar.pickle')


# Generated at 2022-06-25 14:44:16.443704
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_dump = Grammar()
    grammar_dump.dump(b"grammar_dump.txt")


# Generated at 2022-06-25 14:44:19.512525
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('t1')
    grammar_0.load('t1')


# Generated at 2022-06-25 14:44:34.612468
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("omnilib/pytree/pickle_grammar")


# Generated at 2022-06-25 14:44:36.007339
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load("../../Grammar/Grammar")


# Generated at 2022-06-25 14:44:38.113136
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    try:
        grammar.load('../Grammar/Grammar')
    except OSError as e:
        assert e.errno == 2
        return
    raise RuntimeError('Failed to raise OSError as expected')

# Generated at 2022-06-25 14:44:39.930235
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump(os.getcwd())

# Generated at 2022-06-25 14:44:41.424649
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_2 = Grammar()
    grammar_2.dump('/tmp/grammar')


# Generated at 2022-06-25 14:44:47.388236
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    for x0 in range(10):
        for x1 in range(10):
            x2 = "".join(chr(ord("a") + (x0 % 26)) for x0 in range(x1))
            x3 = f"{x2}.pickle"
            test_case_0()
            grammar_0.dump(x3)


# Generated at 2022-06-25 14:44:50.110562
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    with tempfile.TemporaryDirectory() as tmpdir:
        filename = tmpdir + "/something"
        grammar.dump(filename)
        grammar.load(filename)



# Generated at 2022-06-25 14:44:55.197093
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    tempdir = tempfile.TemporaryDirectory()
    try:
        grammar_dump = Grammar()
        import os
        try:
            grammar_dump.dump(os.path.join(tempdir.name, ".temp"))
        except IOError:
            assert 0, "Could not dump the grammar tables to a pickle file."
    finally:
        tempdir.cleanup()


# Generated at 2022-06-25 14:44:59.368827
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Test for method dump of class Grammar (1 of 2)
    grammar_0 = Grammar()
    grammar_0.dump(".\\test_case_0.txt")

    # Test for method dump of class Grammar (2 of 2)
    grammar_0 = Grammar()
    grammar_0.dump(".\\test_case_0.txt")


# Generated at 2022-06-25 14:45:01.612925
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("data/Grammar.pickle")


# Generated at 2022-06-25 14:45:15.536119
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import pickle
    from typing import Dict, List, Optional, Text, Tuple
    import unittest
    import os

    class TestGrammar(unittest.TestCase):
        def test_0(self):
            grammar_0 = Grammar()

            grammar_0.symbol2number = {
                "'&'": 258,
                "'else'": 257,
                "NAME": 256,
                "'and'": 259,
                "':'": 260,
                "'in'": 261,
            }
            grammar_0.number2symbol = {
                258: "'&'",
                257: "'else'",
                256: "NAME",
                259: "'and'",
                260: "':'",
                261: "'in'",
            }

# Generated at 2022-06-25 14:45:17.293781
# Unit test for method load of class Grammar
def test_Grammar_load():

    grammar_0 = Grammar()
    grammar_0.load("")
    grammar_0.loads("")
    assert grammar_0 is not None

# Generated at 2022-06-25 14:45:18.812509
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = "grammar.dump"
    test_case_0().dump(filename)



# Generated at 2022-06-25 14:45:20.411696
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("w/ou/t/d/t.py")


# Generated at 2022-06-25 14:45:28.710136
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    # The grammar tables aren't loaded from a data file at this point,
    # so set up some fake instance variables.
    grammar.symbol2number = {"foo": 256}
    grammar.number2symbol = {256: "foo"}
    grammar.states = [[[]]]
    grammar.dfas = {256: (0, None)}
    grammar.labels = [
        (0, "EMPTY"),
        (token.PLUS, None),
    ]
    grammar.keywords = {}
    grammar.tokens = {}
    grammar.symbol2label = {}
    grammar.start = 256
    # Invoke the method on the Grammar instance.
    grammar.dump("test_Grammar_dump")
 

# Generated at 2022-06-25 14:45:30.574915
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("simple.pickle")

    # Unit test for method dump of class Grammar

# Generated at 2022-06-25 14:45:41.516567
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .symbol import Symbol
    from .token import Token
    from ..pgen2 import generate_grammar, yacc, dump_grammar
    from .pygram import python_grammar, python_symbol2label, python_symbol2number
    from tempfile import TemporaryDirectory
    import os
    import mypy.codegen

    with TemporaryDirectory() as d:
        out = os.path.join(d, "Grammar.py")
        with open(out, "w") as f:
            # mypyc doesn't support the codegen module yet
            code = mypy.codegen.SourceCodeGenerator(f)

            with code.function("test_case_0"):
                with code.block("grammar_0 = Grammar()"):
                    code.write("pass")


# Generated at 2022-06-25 14:45:42.759259
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Checks if load returns a dictionary
    assert isinstance(Grammar().load(None), dict)



# Generated at 2022-06-25 14:45:45.469815
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('/tmp/grammar.pickle')


# Generated at 2022-06-25 14:45:50.069358
# Unit test for method load of class Grammar
def test_Grammar_load():

    grammar = Grammar()

    # Test by loading a valid file.
    grammar.load("/home/selmf/projects/python-private-repo/Lib/test/grammar_init_0.pkl")




# Generated at 2022-06-25 14:46:12.039701
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Note that this test assumes a specific implementation of the
    # pickle file and the implementation of Grammar._update.  These
    # can be changed without breaking the contract, but will
    # probably break the test.

    # Test that a newly created Grammar is empty.
    grammar = Grammar()
    assert grammar.tokens == {}
    assert grammar.symbol2number == {}
    assert grammar.number2symbol == {}
    assert grammar.dfas == {}
    assert grammar.keywords == {}
    assert grammar.tokens == {}
    assert grammar.symbol2label == {}
    assert grammar.labels == [(0, "EMPTY")]
    assert grammar.states == []
    assert grammar.start == 256

    # write the pickle
    fd, file_name = tempfile.mkstemp()

# Generated at 2022-06-25 14:46:14.662881
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('/tmp/test_pickle.py')


# Generated at 2022-06-25 14:46:22.499800
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.start = 256
    grammar.symbol2number["name"] = 0
    grammar.symbol2label["name"] = 1
    grammar.tokens[0] = 1
    grammar.tokens[1] = 2
    grammar.tokens[2] = 3
    grammar.tokens[3] = 4
    grammar.tokens[4] = 5
    grammar.tokens[5] = 6
    grammar.tokens[6] = 7
    grammar.tokens[7] = 8
    grammar.tokens[8] = 9
    grammar.tokens[9] = 10
    grammar.tokens[10] = 11
    grammar.tokens[11] = 12
    grammar.tokens[12] = 13

# Generated at 2022-06-25 14:46:25.030254
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("Grammar.dump")



# Generated at 2022-06-25 14:46:27.810349
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    grammar = Grammar()

    # Verify that the file has been successfully written
    try:
        grammar.dump("Grammar_dump.pickle")
    except:
        print ("Unexpected error:", sys.exc_info()[0])
        raise



# Generated at 2022-06-25 14:46:28.935535
# Unit test for method load of class Grammar
def test_Grammar_load():
    result = test_case_0()
    assert result is not None


# Generated at 2022-06-25 14:46:37.781951
# Unit test for method load of class Grammar
def test_Grammar_load():
    # grammar.load
    # Grammar.load
    grammar_1 = Grammar()

# Generated at 2022-06-25 14:46:45.858124
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import token, parse
    g = Grammar()
    g.start = 39
    g.tokens = {1: (3, 'x')}
    g.labels = [(0, 'EMPTY'), (3, 'x')]
    g.states = [
        [(1, 1)],
        [(2, 2)],
        [],
    ]
    g.dfas = {
        39: ([0, 1, 2], {1: 1})
    }
    g.keywords = {}
    g.symbol2number = {}
    g.number2symbol = {}
    g.symbol2label = {}
    f = parse.PyCF_ONLY_AST
    symbol2label = {}
    for _, v in g.labels:
        if v is not None:
            symbol2

# Generated at 2022-06-25 14:46:51.001470
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest

    class test_Grammar_dump(unittest.TestCase):
        def test_test_case_0(self):
            grammar_0 = Grammar()
            grammar_0.dump(r"C:\Users\raym\AppData\Local\Temp\python-astgen-vq8jca0x\expected_Grammar_dump_test_case_0.pkl")

            with open(r"C:\Users\raym\AppData\Local\Temp\python-astgen-vq8jca0x\expected_Grammar_dump_test_case_0.pkl", "rb") as f:
                expected_Grammar_dump_test_case_0 = pickle.load(f)
