

# Generated at 2022-06-25 14:36:54.647551
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    filename_1 = "fixtures/test_grammar.py"
    grammar_0.dump(filename_1)
    assert os.path.exists(filename_1)

# Test for method load of class Grammar

# Generated at 2022-06-25 14:36:57.745032
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    try:
        grammar_0.dump('/tmp/test.pickle')
    except IOError as e:
        pass


# Generated at 2022-06-25 14:37:06.379053
# Unit test for method load of class Grammar
def test_Grammar_load():
    """test Grammar.load method
    """
    grammar_0 = Grammar()
    grammar_0.load("../Lib/compile.pgenc")

    actual = grammar_0.symbol2number

# Generated at 2022-06-25 14:37:14.134677
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test Grammar.load method.
    # Test using the empty grammar defined above.
    grammar_1 = Grammar()
    fd, filename = tempfile.mkstemp(prefix="grammar_load")
    try:
        os.close(fd)
        grammar_0.dump(filename)
        grammar_1.load(filename)
    finally:
        os.remove(filename)

# Generated at 2022-06-25 14:37:20.040807
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    try:
        os.remove("test_grammar.pkl")
    except OSError:
        pass

    start = 256
    grammar_0 = Grammar()
    grammar_0.dump("test_grammar.pkl")
    assert os.path.exists("test_grammar.pkl")
    os.remove("test_grammar.pkl")


# Generated at 2022-06-25 14:37:21.895989
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load(__file__)


# Generated at 2022-06-25 14:37:27.267383
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    dump_filename = "/tmp/parse_grammar.tab.pickle"
    if os.path.isfile(dump_filename):
        os.unlink(dump_filename)
    assert not os.path.isfile(dump_filename)
    grammar_0 = Grammar()
    grammar_0.dump(filename = "/tmp/parse_grammar.tab.pickle")
    assert os.path.isfile(dump_filename)
    os.unlink(dump_filename)


# Generated at 2022-06-25 14:37:31.166377
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("test_Grammar.pickle1")


# Generated at 2022-06-25 14:37:32.888618
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('build/pgen.pickle')


# Generated at 2022-06-25 14:37:35.198674
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))

# Generated at 2022-06-25 14:37:41.644795
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("grammar1.pkl")


# Generated at 2022-06-25 14:37:43.206898
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    try:
        test_case_0()
    except Exception as e:
        print(e)


# Generated at 2022-06-25 14:37:48.165722
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    path = os.path.join(os.path.dirname(__file__), "Grammar.dump")
    g.load(path)

if __name__ == "__main__":
    g = Grammar()
    path = os.path.join(os.path.dirname(__file__), "Grammar.dump")
    g.load(path)

# Generated at 2022-06-25 14:37:50.180784
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump("test.pkl")


# Generated at 2022-06-25 14:37:53.146488
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    tempfile_0 = tempfile.NamedTemporaryFile()
    grammar_0.dump(tempfile_0.name)


# Generated at 2022-06-25 14:37:57.373009
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("test.pickle")
    grammar_1 = Grammar()
    grammar_1.load("test.pickle")
    assert grammar_0 == grammar_1
    os.remove("test.pickle")


# Generated at 2022-06-25 14:38:00.904178
# Unit test for method load of class Grammar
def test_Grammar_load():
    print("test_Grammar_load")
    grammar = Grammar()
    grammar.load("test.pickle")
    grammar.report()

if __name__ == "__main__":
    test_case_0()
    test_Grammar_load()

# Generated at 2022-06-25 14:38:02.377064
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load('grammar_data.pkl')


# Generated at 2022-06-25 14:38:03.918332
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load('py3grammar.dat')


# Generated at 2022-06-25 14:38:05.064038
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test only: no test
    return


# Generated at 2022-06-25 14:38:11.411374
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('Grm/grammar.pickle')


# Generated at 2022-06-25 14:38:18.261770
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    filename_0 = 'pytype/test_files/test_data/test_pgen.out'
    grammar_0.dump(filename_0)
    # Ensure file is created
    assert os.path.exists(filename_0)
    # Ensure file is not empty
    assert os.path.getsize(filename_0) != 0
    # Remove the file
    os.remove(filename_0)



# Generated at 2022-06-25 14:38:25.640991
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    with tempfile.TemporaryDirectory() as temp_dir:
        # Set up grammar
        grammar_0 = Grammar()
        grammar_0.symbol2number["test"] = 1
        grammar_0.number2symbol[1] = "test"

# Generated at 2022-06-25 14:38:27.150598
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("./grammar_example")

# Generated at 2022-06-25 14:38:28.616462
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump(__file__)


# Generated at 2022-06-25 14:38:31.122347
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("grammar_0.pkl")


# Generated at 2022-06-25 14:38:34.277589
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load(r"C:\Users\student\AppData\Local\Temp\py_to_mypy2\test_grammar.pkl")


# Generated at 2022-06-25 14:38:36.951574
# Unit test for method load of class Grammar
def test_Grammar_load():

    grammar_1 = Grammar()
    grammar_1.load("./data.pkl")


# Generated at 2022-06-25 14:38:38.271602
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    try:
        grammar_1.load("./src/parser/Grammar.ll")
    except Exception as e:
        print(e)
    else:
        print("no exception")

# Generated at 2022-06-25 14:38:39.726085
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('')


# Generated at 2022-06-25 14:38:47.242966
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump(r"C:\Users\rv\Desktop\testfile")


# Generated at 2022-06-25 14:38:49.112516
# Unit test for method load of class Grammar
def test_Grammar_load():
    assert grammar_0.load( "Grammar.pickle" ) == None


# Generated at 2022-06-25 14:38:51.294312
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load('./Grammar.txt')
    return grammar



# Generated at 2022-06-25 14:38:53.365574
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # === Unit tests for dump method of class Grammar
    # === Body of test case 0
    test_case_0()
    # === End unit tests for dump method of class Grammar


# Generated at 2022-06-25 14:39:00.194355
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()

# Generated at 2022-06-25 14:39:01.419689
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("grammar.pickle")


# Generated at 2022-06-25 14:39:03.565670
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Verify that we can read a pickle file
    g_path = os.path.join(os.path.dirname(__file__), "Grammar.pkl")
    g = Grammar()
    g.load(g_path)

# Generated at 2022-06-25 14:39:05.196717
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    filename = "Grammar_load"
    grammar_1.load(filename)


# Generated at 2022-06-25 14:39:06.886079
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    filename_0 = test_grammar.get_pgen_grammar()

    grammar_0.load(filename_0)


# Generated at 2022-06-25 14:39:10.006321
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('/tmp/rules.30')

if __name__ == "__main__":
    test_case_0()
    test_Grammar_dump()

# Generated at 2022-06-25 14:39:19.995680
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_test = Grammar()
    test_file = "test_grammar.txt"
    if os.path.exists(test_file):
        os.remove(test_file)
    # The method named 'dump' should exist
    assert hasattr(Grammar, 'dump')
    # The method named 'dump' should be callable
    assert callable(getattr(Grammar, 'dump', None))
    grammar_test.dump(test_file)
    assert os.path.exists(test_file)


# Generated at 2022-06-25 14:39:21.693503
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('<pickle_file>')


# Generated at 2022-06-25 14:39:24.133549
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('spec/test_data/test_grammar/Grammar.pickle')
    assert grammar_0._Grammar__dict__['start'] == 256


# Generated at 2022-06-25 14:39:25.922322
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # create an instance of the class to test (Grammar class)
    grammar_0 = Grammar()
    # test dump(self, filename)
    grammar_0.dump('test.pkl')



# Generated at 2022-06-25 14:39:35.993093
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load(r'test_grammar.pickle')

# Generated at 2022-06-25 14:39:38.248749
# Unit test for method load of class Grammar
def test_Grammar_load():
    def test_Grammar_load_0(self):
        grammar_0 = Grammar()
        path_0 = ""
        grammar_0.load(path_0)


# Generated at 2022-06-25 14:39:41.031829
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    filename = "./pycparser_fake_libc_include/stdio.h"
    grammar.load(filename)


# Generated at 2022-06-25 14:39:42.206380
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('/dev/null')


# Generated at 2022-06-25 14:39:47.383539
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    try:
        import os

        with tempfile.TemporaryDirectory() as tmpdirname:
            f = os.path.join(tmpdirname, "grammar.pickle")
            grammar_0 = Grammar()
            grammar_0.dump(f)
    except Exception as e:
        raise AssertionError(e) from e


# Generated at 2022-06-25 14:39:50.823747
# Unit test for method load of class Grammar
def test_Grammar_load():
    test_0 = Grammar()
    assert test_0.load('')
    assert test_0.loads(b'')
    assert test_0.copy()
    assert test_0.report()

# Generated at 2022-06-25 14:39:55.863708
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_1 = grammar_0.load(b'pickled_grammar_tables')


# Generated at 2022-06-25 14:40:00.953380
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Create a Grammar object
    grammar_0 = Grammar()

    # Invoke method load
    grammar_0.load("Grammar.pickle")

    assert grammar_0.start == 268


if __name__ == "__main__":
    import sys

    print("Testing Grammar class...", file=sys.stderr)
    if len(sys.argv) == 2 and sys.argv[1] == "-l":
        g = Grammar()
        g.load("Grammar.pickle")
    else:
        g = Grammar()
        g.report()
    print("done", file=sys.stderr)

# Generated at 2022-06-25 14:40:10.404448
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2

    grammar = pgen2.driver.load_grammar(b"/usr/local/lib/python3.9/lib2to3/Grammar.txt")
    grammar.dump(b"/tmp/test_data/test_python_Grammar_load.pickle")
    grammar_0 = Grammar()
    grammar_0.load(b"/tmp/test_data/test_python_Grammar_load.pickle")
    print(grammar_0.dfas[258])

try:
    import fastpickle
except ImportError:
    pass
else:
    # Unit test for method load of class Grammar
    def test_Grammar_load_fastpickle():
        from . import pgen2


# Generated at 2022-06-25 14:40:11.809099
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load("Grammar/Grammar.pkl")


# Generated at 2022-06-25 14:40:14.697448
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import grammar_1
    grammar = grammar_1.Grammar()
    grammar.load("Grammar.pkl")


# Generated at 2022-06-25 14:40:17.113673
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('/usr/share/doc/python2.7/examples/Tools/i18n/pygettext.py')


# Generated at 2022-06-25 14:40:19.523074
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('pickles/Grammar_load.pickle')


# Generated at 2022-06-25 14:40:23.893368
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    path = os.path.abspath(os.path.join(os.path.dirname(__file__), "Grammar.pickle"))
    grammar_0 = Grammar()
    grammar_0.dump(path)
    grammar_1 = Grammar()
    grammar_1.loads(open(path, 'rb').read())


if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-25 14:40:25.445804
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('/tmp/grammar.pickle')


# Generated at 2022-06-25 14:40:28.853112
# Unit test for method load of class Grammar
def test_Grammar_load():
    # TODO: Some unit test for Grammar load functionality
    return test_case_0()



# Generated at 2022-06-25 14:40:32.710635
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    pass


# Generated at 2022-06-25 14:40:35.797012
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()

    # Testing the grammar loading from pickled file
    grammar_1.dump("/tmp/tmpgrmrcw")
    grammar_1.load("/tmp/tmpgrmrcw")



# Generated at 2022-06-25 14:40:37.925066
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("_stub")
    grammar_0.dump("_stub")


# Generated at 2022-06-25 14:40:40.270450
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("/home/hgeg/PycharmProjects/type-infer-py/test/test_files/test_case_5/test_5_pgen_parse.py")


# Generated at 2022-06-25 14:40:41.823877
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("../resources/grammar_0.pickle")


# Generated at 2022-06-25 14:40:43.805838
# Unit test for method load of class Grammar
def test_Grammar_load():
    file = os.path.join(os.getcwd(), "Grammar.py")
    test_case_0().load(file)



# Generated at 2022-06-25 14:40:47.286287
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    with tempfile.NamedTemporaryFile(dir=os.path.dirname(0), delete=False) as f:
        grammar_0.dump(f.name)


# Generated at 2022-06-25 14:40:48.769120
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_dump = Grammar()
    assert grammar_dump.dump("Grammar.dump.grammar") == None


# Generated at 2022-06-25 14:40:49.944723
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('Grammar.dat')


# Generated at 2022-06-25 14:40:50.780780
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load("../../Lib/test/grammar.pkl")

# Generated at 2022-06-25 14:40:54.738391
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    try:
        Grammar().dump('')
    except:
        pass



# Generated at 2022-06-25 14:40:56.296016
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('')


# Generated at 2022-06-25 14:41:03.029376
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert grammar.symbol2number["single_input"] == 257
    assert grammar.number2symbol[258] == "file_input"
    assert len(grammar.states) == 502
    assert len(grammar.dfas) == 113
    assert len(grammar.labels) == 1081
    assert grammar.start == 257
    assert (
        grammar.keywords["elif"] == 2770
    )  # this depends on the version of Python
    assert grammar.tokens[token.AS] == 843


if __name__ == "__main__":
    import sys
    import os

    # First argument is a pickle file to read, default Grammar

# Generated at 2022-06-25 14:41:08.169823
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    # Simple test
    grammar_0 = Grammar()
    grammar_0.dump("../Grammar/python3.6/Grammar.pickle")
    grammar_1 = Grammar()
    grammar_1.load("../Grammar/python3.6/Grammar.pickle")


# Generated at 2022-06-25 14:41:09.512876
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    test_case_0()

test_case_0()

# Generated at 2022-06-25 14:41:15.513258
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test basic functionality
    grammar = Grammar()
    # Grammar should have some attributes
    assert hasattr(grammar, "symbol2number")
    assert hasattr(grammar, "number2symbol")
    assert hasattr(grammar, "states")
    assert hasattr(grammar, "dfas")
    assert hasattr(grammar, "keywords")
    assert hasattr(grammar, "tokens")
    assert hasattr(grammar, "symbol2label")
    assert hasattr(grammar, "labels")
    assert hasattr(grammar, "start")
    assert hasattr(grammar, "async_keywords")
    grammar_dict = grammar.__dict__
    # Grammar should have some default values
    assert grammar_dict["symbol2number"] == {}
    assert grammar_

# Generated at 2022-06-25 14:41:18.685836
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('./testdata/grammar_method_test.test_Grammar_dump')


# Generated at 2022-06-25 14:41:21.478954
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    filename_0 = '2Z88C1'
    Grammar.dump(grammar_0, filename_0)



# Generated at 2022-06-25 14:41:28.764319
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    save_name = tempfile.mktemp(suffix='.pgen')
    grammar_0.dump(save_name)
    grammar_1 = Grammar()
    grammar_1.load(save_name)
    assert grammar_1.symbol2number == grammar_0.symbol2number
    assert grammar_1.number2symbol == grammar_0.number2symbol
    assert grammar_1.states == grammar_0.states
    assert grammar_1.dfas == grammar_0.dfas
    assert grammar_1.labels == grammar_0.labels
    assert grammar_1.keywords == grammar_0.keywords
    assert grammar_1.tokens == grammar_0.tokens
    assert grammar_1.symbol2label == grammar_0.symbol2

# Generated at 2022-06-25 14:41:30.207540
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(grammar_0)


# Generated at 2022-06-25 14:41:35.091507
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.load(Grammar)
    assert isinstance(grammar.dump(), str)


# Generated at 2022-06-25 14:41:36.838198
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    filename_0 = 0
    grammar_0.load(filename_0)


# Generated at 2022-06-25 14:41:39.504851
# Unit test for method load of class Grammar
def test_Grammar_load():
    # test 0
    grammar_0 = Grammar()
    grammar_0.load("test.pickle")
    assert grammar_0 == Grammar()


# Generated at 2022-06-25 14:41:42.624918
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()

    grammar_0.load('/home/benjamin/PycharmProjects/pgen2/Grammar.pickle')



# Generated at 2022-06-25 14:41:45.216593
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load('../../../grammar_files/Grammar.pickle')
    grammar_1.report()


# Generated at 2022-06-25 14:41:49.064842
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("/home/marco/Desktop/pycharm/plugins/python-ce/helpers/pgen2/pgen_test/test_grammar_dump.pkl")


# Generated at 2022-06-25 14:41:52.177498
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_2 = Grammar()
    grammar_2.load(r"C:\pylib\grammar.pickle")
    grammar_3 = Grammar()
    grammar_3.load(r"C:\pylib\grammar.pickle")


# Generated at 2022-06-25 14:41:53.601549
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_load = Grammar()
    grammar_load.load('Grammar_load.pickle')



# Generated at 2022-06-25 14:41:55.038687
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('grammar.pickle')


# Generated at 2022-06-25 14:41:58.069165
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Tests the load method."""
    grammar = Grammar()
    with tempfile.TemporaryDirectory() as directory:
        filename = os.path.join(directory, "grammar.pkl")
    grammar.dump(filename)
    grammar = Grammar()
    grammar.load(filename)
