

# Generated at 2022-06-25 14:36:47.724621
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Test case for load method of class Grammar."""
    # Test data
    tempfile_1 = tempfile.NamedTemporaryFile()
    # Call function to exercise code path
    test_case_0().load(tempfile_1.name)
    # Check results


# Generated at 2022-06-25 14:36:49.557429
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('/tmp/test_Grammar_dump.pkl')


# Generated at 2022-06-25 14:36:50.939477
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('grammar0.pkl')


# Generated at 2022-06-25 14:36:54.144614
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Test case with 'no' filename.
    def test_Grammar_dump_case_0():
        grammar_0 = Grammar()
        try:
            grammar_0.dump('')
        except Exception as e:
            raise exceptionAssertionFailed('dump')

    test_Grammar_dump_case_0()

# Generated at 2022-06-25 14:36:55.729201
# Unit test for method load of class Grammar
def test_Grammar_load():
    test_case_0()  # case_0

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-25 14:36:58.404857
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('/tmp/graminit.pickle')


# Generated at 2022-06-25 14:37:00.334741
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1_ = Grammar()
    grammar_1_.dump(str(tempfile.mkdtemp()))


# Generated at 2022-06-25 14:37:05.472959
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    test_case_0()
    assert not os.path.isfile('bin/Test/test_dump_out.txt')
    grammar_0.dump('bin/Test/test_dump_out.txt')
    assert os.path.isfile('bin/Test/test_dump_out.txt')
    os.remove('bin/Test/test_dump_out.txt')


# Generated at 2022-06-25 14:37:07.160572
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('../../src/grammar/Grammar.pickle')


# Generated at 2022-06-25 14:37:12.296581
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar1 = Grammar()
    data = pickle.dumps({
        "symbol2number": {
            "": 256
        },
        "number2symbol": {
            256: ""
        }
    })
    grammar1.loads(data)
    assert grammar1.symbol2number == {""}
    assert grammar1.number2symbol == {256: ""}

    # TODO: test dump() and load()

# Generated at 2022-06-25 14:37:20.154510
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("/tmp/pgen.pickle")



# Generated at 2022-06-25 14:37:25.547997
# Unit test for method load of class Grammar
def test_Grammar_load():
    tmpdir = tempfile.TemporaryDirectory()
    with open(os.path.join(tmpdir.name, "Grammar.pkl"), "wb") as f:
        pickle.dump({}, f, pickle.HIGHEST_PROTOCOL)

    grammar = Grammar()
    grammar.load(os.path.join(tmpdir.name, "Grammar.pkl"))
    tmpdir.cleanup()

# Generated at 2022-06-25 14:37:26.889275
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump('pgen_test.ab')



# Generated at 2022-06-25 14:37:29.240947
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.states.append([])
    grammar.dump('test_case_0.pkl')
    grammar_0 = Grammar()
    grammar_0.load('test_case_0.pkl')
    assert grammar == grammar_0


# Generated at 2022-06-25 14:37:41.056668
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.start = 2
    grammar.symbol2number = {"s2n_key": "s2n_value"}
    grammar.number2symbol = {"n2s_key": "n2s_value"}
    grammar.states = ["state_0"]
    grammar.dfas = {"dfas_key": ("dfa_1", "dfa_2")}
    grammar.labels = ["label_0"]
    grammar.keywords = {"keywords_key": "keywords_value"}
    grammar.tokens = {"tokens_key": "tokens_value"}
    grammar.symbol2label = {"symbol2label_key": "symbol2label_value"}
    temp_file_name = tempfile.NamedTemporaryFile().name

# Generated at 2022-06-25 14:37:42.539904
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    fd, path = tempfile.mkstemp()
    os.close(fd)
    grammar_0.dump(path)

# Generated at 2022-06-25 14:37:44.475252
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar_0 = test_case_0()
    grammar.load('input')


# Generated at 2022-06-25 14:37:47.117943
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    bytecode = pickle.dumps(grammar_0)
    grammar_0.loads(bytecode)


# Generated at 2022-06-25 14:37:48.708354
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("test_Grammar")


# Generated at 2022-06-25 14:37:51.598276
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load('Grammar')


# Generated at 2022-06-25 14:38:05.378693
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("/home/dane/python/Python-2.7/Grammar/tmp/pickle.load")
    grammar_0.load("/home/dane/python/Python-2.7/Grammar/tmp/pickle.load")
    grammar_0.load("/home/dane/python/Python-2.7/Grammar/tmp/pickle.load")
    grammar_0.load("/home/dane/python/Python-2.7/Grammar/tmp/pickle.load")
    grammar_0.load("/home/dane/python/Python-2.7/Grammar/tmp/pickle.load")

# Generated at 2022-06-25 14:38:06.886982
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_load = Grammar()
    grammar_load.load(r'test\data\Grammar.pickle')
    assert grammar_load.async_keywords == True


# Generated at 2022-06-25 14:38:16.317587
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    if getattr(grammar_1, "symbol2number", None) is None:
        raise AssertionError
    if getattr(grammar_1, "number2symbol", None) is None:
        raise AssertionError
    if getattr(grammar_1, "states", None) is None:
        raise AssertionError
    if getattr(grammar_1, "dfas", None) is None:
        raise AssertionError
    if getattr(grammar_1, "labels", None) is None:
        raise AssertionError
    if getattr(grammar_1, "keywords", None) is None:
        raise AssertionError
    if getattr(grammar_1, "tokens", None) is None:
        raise Assert

# Generated at 2022-06-25 14:38:20.805652
# Unit test for method load of class Grammar
def test_Grammar_load():

    grammar_0 = Grammar()

    grammar_0.load('Grammar.txt')

if __name__ == '__main__':
    test_case_0()  # test Grammar
    test_Grammar_load()

# Generated at 2022-06-25 14:38:23.187600
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('/tmp/grammar_0.pkl')


# Generated at 2022-06-25 14:38:33.417703
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen_parse import pgen

    def test(input, expected, **kwargs):
        g = pgen(input, **kwargs)
        g.dump("/tmp/Grammar")
        g.load("/tmp/Grammar")
        for attr in expected:
            assert getattr(g, attr) == expected[attr]

    # Empty file
    test("", {"states": [], "symbol2number": {}})

    # File with only a start symbol
    test("'a'", {"states": [], "symbol2number": {"a": 257}})

    # Test with rules
    test("'a' 'b'", {"states": [[], [[(257, 1), (258, 1)]]]})

    # Only test the dicts here; this is not a general test of pgen

# Generated at 2022-06-25 14:38:38.105379
# Unit test for method load of class Grammar
def test_Grammar_load():
    table_0 = Grammar()
    f = tempfile.NamedTemporaryFile(mode='wb', delete=False)
    Pickle.dump(table_0, f)
    f.close()
    table_0.load(f.name)

# Generated at 2022-06-25 14:38:41.218665
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    print("# Unit test for method dump of class Grammar")
    print("grammar = Grammar()")
    grammar = Grammar()
    print("grammar.dump('foo.txt')")
    grammar.dump('foo.txt')


# Generated at 2022-06-25 14:38:42.781714
# Unit test for method load of class Grammar
def test_Grammar_load():
    test_grammar_file_name = "test_grammar_file_name"  # type: str
    grammar_0 = Grammar()
    grammar_0.load(test_grammar_file_name)


# Generated at 2022-06-25 14:38:48.772683
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = "test_grammar_dump.pkl"
    test_case_0()
    try:
        grammar_0.dump(filename)
    except Exception:
        assert False
    finally:
        os.remove(filename)


# Generated at 2022-06-25 14:38:57.909002
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.labels = [(256, "foo"), (-1, None), (-2, "bar"), (257, None)]
    grammar.keywords = {'foo': 256, 'bar': -2}
    grammar.start = 257
    grammar.tokens = {}
    grammar.symbol2label = {'foo': 256, 'bar': -2}
    grammar.symbol2number = {'foo': 256, 'bar': 257}
    grammar.number2symbol = {256: 'foo', 257: 'bar'}
    grammar.states = [[(2, 1), (0, 0)], [], [(1, 1), (0, 0)]]

# Generated at 2022-06-25 14:39:02.698241
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    file_0 = "test.pkl"
    try:
        grammar_0.dump(file_0)
    except Exception as inst:
        print(inst)
    with open(file_0, "rb") as f:
        d = pickle.load(f)
        grammar_0._update(d)
    # Test coverage for the last line of the function
    print(grammar_0)



# Generated at 2022-06-25 14:39:03.625774
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump(str())

# Generated at 2022-06-25 14:39:05.526388
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    try:
        grammar_0.dump('grammar_0.pickle')
    except Exception as e:
        print(e)


# Generated at 2022-06-25 14:39:06.594815
# Unit test for method load of class Grammar
def test_Grammar_load():
    # create an instance
    grammar_0 = Grammar()
    # load a grammar pickle
    grammar_0.load("Grammar/Grammar")

# Generated at 2022-06-25 14:39:09.028825
# Unit test for method dump of class Grammar
def test_Grammar_dump():  # noqa: P102
    """
    Test Grammar.dump()
    """
    grammar = Grammar()
    grammar.dump('c:/temp/test.pkl')  # noqa: B104



# Generated at 2022-06-25 14:39:10.944724
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("/tmp/pytest_dump/test.py")


# Generated at 2022-06-25 14:39:13.393000
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    global grammar_0
    grammar_0 = Grammar()
    grammar_0.dump('test_Grammar_dump.pkl')


# Generated at 2022-06-25 14:39:14.971411
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump('test.pickle')
    g2 = Grammar()
    g2.load('test.pickle')

# Generated at 2022-06-25 14:39:17.889492
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = "python_grammar.tab"
    python_grammar_dump = Grammar()
    python_grammar_dump.dump(filename)
