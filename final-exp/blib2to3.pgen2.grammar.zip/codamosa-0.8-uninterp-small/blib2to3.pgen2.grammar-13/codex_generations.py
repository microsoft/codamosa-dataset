

# Generated at 2022-06-25 14:36:45.871689
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("Python/pgen2/Grammar.py")

# Generated at 2022-06-25 14:36:47.535024
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    pass


# Generated at 2022-06-25 14:36:54.830016
# Unit test for method load of class Grammar

# Generated at 2022-06-25 14:36:57.922081
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump(os.path.join(os.path.dirname(__file__), 'test.pkl'))



# Generated at 2022-06-25 14:37:03.087407
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    with tempfile.NamedTemporaryFile(delete=False) as f:
        pass
    test_grammar_0 = Grammar()
    test_grammar_0.dump(f.name)
    d = pickle.load(open(f.name, 'rb'))
    assert isinstance(d, dict)
    #time.sleep(1)
    os.remove(f.name)


# Generated at 2022-06-25 14:37:04.781786
# Unit test for method load of class Grammar
def test_Grammar_load():
    gerbil = Grammar()
    gerbil.load("test0.gr")
    #gerbil.report()



# Generated at 2022-06-25 14:37:05.850721
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    assert grammar_0.dump == Grammar(grammar_0).dump



# Generated at 2022-06-25 14:37:14.164642
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("../../ast/Grammar.txt")

    grammar_1 = Grammar()
    grammar_1.load("../../ast/Grammar.txt")

    grammar_2 = Grammar()
    grammar_2.loads(
        Grammar.__module__ + "\nGrammar\np0\n(dp1\nS'labels'\np2\n(lp3\n(I0\nS'EMPTY'\np4\ntp5\na(I256\nS'stmt'\np6\ntp7\na(I257\nS'comp_op'\np8\ntp9\nb."
    )

    grammar_3 = Grammar()

# Generated at 2022-06-25 14:37:16.614310
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Reads the grammar tables from a pickle file.
    assert True


# Generated at 2022-06-25 14:37:19.809559
# Unit test for method load of class Grammar
def test_Grammar_load():
    G = Grammar()
    G.dump("Grammar.pickle")
    H = Grammar()
    H.load("Grammar.pickle")
    assert G.__dict__ == H.__dict__


# Generated at 2022-06-25 14:37:26.946052
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("./test/test_Grammar/test/test_dump.test")
    assert os.path.isfile("./test/test_Grammar/test/test_dump.test")



# Generated at 2022-06-25 14:37:31.779859
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen

    grammar = pgen.load_grammar()
    grammar.load("./Lib/test/grammar_1")
    assert grammar == pgen.load_grammar("./Lib/test/grammar_1")



# Generated at 2022-06-25 14:37:38.451309
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load(r"C:\Users\DELLPC\PycharmProjects\cpython\test\test_grammar.pyc")
    assert grammar_0.symbol2number == {}
    assert grammar_0.number2symbol == {}
    assert grammar_0.states == []
    assert grammar_0.dfas == {}
    assert grammar_0.labels == [(0, "EMPTY")]
    assert grammar_0.keywords == {}
    assert grammar_0.tokens == {}


# Generated at 2022-06-25 14:37:41.220056
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump(b"grammar/pickle")



# Generated at 2022-06-25 14:37:46.946878
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_1 = Grammar()

    grammar_0.keywords["await"] = 1
    grammar_0.labels[1] = (3, "await")

    grammar_0.dump("test_dump.pickle")
    grammar_1.load("test_dump.pickle")
    assert grammar_0.keywords == grammar_1.keywords
    assert grammar_0.labels == grammar_1.labels

# Generated at 2022-06-25 14:37:52.193068
# Unit test for method load of class Grammar
def test_Grammar_load():
    # See http://bugs.python.org/issue8396
    grammar_1 = Grammar()
    grammar_1.load(grammar_1.__class__.__module__ + ".pickle")
    grammar_1.report()


if __name__ == "__main__":
    test_case_0()
    test_Grammar_load()

# Generated at 2022-06-25 14:37:53.635111
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()

    grammar_0.dump("grammar.grammar")


# Generated at 2022-06-25 14:37:59.266505
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    data_package_directory = os.path.dirname(os.path.abspath(__file__))
    test_data_directory = os.path.join(data_package_directory, 'test_data')
    grammar.load(os.path.join(test_data_directory, 'grammar.pkl'))
    assert grammar.start == 258

# Generated at 2022-06-25 14:38:03.026205
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    grammar_1 = Grammar()

    f = tempfile.NamedTemporaryFile(delete=False)
    #f = open(b'testcase/testcase_Grammar_dump', 'wb')
    try:
        grammar_1.dump(f.name)
    finally:
        f.close()


# Generated at 2022-06-25 14:38:05.179196
# Unit test for method load of class Grammar
def test_Grammar_load():
    test_cases = [test_case_0]

    for i, test_case in enumerate(test_cases):
        test_case()


# Generated at 2022-06-25 14:38:12.352971
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump("./data/Grammar.dump")
    grammar_1.loads(pickle.dumps(grammar_1, -1))


# Generated at 2022-06-25 14:38:13.859456
# Unit test for method load of class Grammar
def test_Grammar_load():
    test_Grammar = Grammar()
    test_Grammar.load("/dev/null")
    assert True


# Generated at 2022-06-25 14:38:20.953025
# Unit test for method dump of class Grammar
def test_Grammar_dump():
  grammar = Grammar()
  grammar.dump('grammar.pkl')
  grammar.update({'start' : 0})
  with open('grammar.pkl', 'rb') as f:
    d = pickle.load(f)
    f.close()
    grammar_new = Grammar()
    grammar_new.load(d)
    assert grammar_new.start == 0

# Generated at 2022-06-25 14:38:23.825166
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))



# Generated at 2022-06-25 14:38:26.766042
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    try:
        Grammar.dump(grammar_0, None)
    except AttributeError as e:
        assert False


# Generated at 2022-06-25 14:38:30.938529
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    temp_file = tempfile.NamedTemporaryFile()
    try:
        grammar_0.dump(temp_file)
    finally:
        temp_file.close()
        temp_file = None


# Generated at 2022-06-25 14:38:33.374403
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("Grammar.pickle")


if __name__ == "__main__":
    test_case_0()
    test_Grammar_load()

# Generated at 2022-06-25 14:38:37.144513
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    assert grammar_0.load("../Lib/test/pickle_grammar.pickle") == None


# Generated at 2022-06-25 14:38:40.149274
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    try:
        grammar_0.dump("/Users/chris/workspace/demos/python/cpython/Lib/test/test_grammar.py")
    except Exception:
        assert False, "Uncaught exception!"


# Generated at 2022-06-25 14:38:41.711393
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    global grammar_0
    grammar_0.dump("./grammar.txt")

# Generated at 2022-06-25 14:38:48.055158
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load('/Users/mike/Documents/github/pgen2/tests/data/grammar.pickle')


# Generated at 2022-06-25 14:38:48.739656
# Unit test for method load of class Grammar
def test_Grammar_load(): pass



# Generated at 2022-06-25 14:38:50.308884
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    pass


# Generated at 2022-06-25 14:38:52.079156
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.load("Grammar_0.pickle")
    grammar_0.dump("Grammar_1.pickle")

# Generated at 2022-06-25 14:38:52.858657
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    test_case_0()


# Generated at 2022-06-25 14:38:54.515059
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load(None)
    grammar_0.load(None)


# Generated at 2022-06-25 14:38:59.300307
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Adding more tests as part of issue #9489
    grammar_1 = Grammar()
    grammar_2 = Grammar()

    #
    # Adding test code to test the dump method of Grammar class
    #
    try:
        grammar_1.load('python3.7.pickle')
        grammar_2.load('python3.7.pickle')
    except IOError:
        # The pickle file was not found. Skip the test.
        return
    assert(grammar_1 == grammar_2)



# Generated at 2022-06-25 14:39:00.886146
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(os.path.join(os.path.dirname(__file__), "Grammar.pickle"))

# Generated at 2022-06-25 14:39:07.380581
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    # First try with a file that does not exist
    g.load("no_such_file")
    # No assert for this case, no exception expected

    # Now try with a file that exists and contains properly formatted data
    g.load("/dev/null")
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256

    # Test with a file that has invalid data (i.e. a string instead of a dict

# Generated at 2022-06-25 14:39:09.503503
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('../test/Grammar_t3.pkl')



# Generated at 2022-06-25 14:39:19.338929
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    filename = "data/grammar3.3.8-py3.3-custom.pickle"
    grammar.load(filename)



# Generated at 2022-06-25 14:39:26.378897
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    f = tempfile.NamedTemporaryFile(delete=False)
    grammar_1.dump(f.name)
    with open(f.name, 'rb') as g:
        grammar_2 = pickle.load(g)
    assert grammar_2.number2symbol == {}
    assert grammar_2.keywords == {}
    assert grammar_2.tokens == {}
    assert grammar_2.symbol2label == {}
    assert grammar_2.labels == [(0, 'EMPTY')]
    assert grammar_2.states == []
    assert grammar_2.dfas == {}
    assert grammar_2.symbol2number == {}
    assert grammar_2.start == 256
    assert grammar_2.async_keywords == False


# Generated at 2022-06-25 14:39:36.210154
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    # State 0
    grammar_0.states.append([])
    grammar_0.states[0].append((1, 1))
    # State 1
    grammar_0.states.append([])
    grammar_0.states[1].append((2, 1))
    grammar_0.states[1].append((3, 2))
    # State 2
    grammar_0.states.append([])
    grammar_0.states[2].append((0, 0))
    # State 3
    grammar_0.states.append([])
    grammar_0.states[3].append((0, 0))
    grammar_0.start = 0
    grammar_0.load('/data/antlr-grammars/grammar.pickle')
    grammar_0.report()

# Generated at 2022-06-25 14:39:38.169709
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    print('Testing Grammar.dump')
    grammar_0 = Grammar()
    grammar_0.dump('test.py')


# Generated at 2022-06-25 14:39:44.663953
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("grammar.pkl")
    grammar_0.load("grammar.pkl")

# Generated at 2022-06-25 14:39:50.781119
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_1 = Grammar()
    with tempfile.NamedTemporaryFile(delete=False) as f:
        pickle.dump(grammar_0, f, pickle.HIGHEST_PROTOCOL)
    grammar_1.load(f.name)
os.unlink(f.name)


# Generated at 2022-06-25 14:39:52.133229
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """test_Grammar_dump()"""
    _test = Grammar()
    _test.dump("test")
    _test.load("test")
    _test.report()


# Generated at 2022-06-25 14:40:00.295898
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    with open('GrammarTables.python35.pickle', 'rb') as fp:
        grammar.loads(fp.read())
    assert grammar.symbol2number['single_input'] == 256
    assert grammar.symbol2number['root'] == 11
    assert grammar.keywords[';'] == 4
    assert grammar.tokens[token.COMMENT] == 5
    assert grammar.labels[4][1] == ';'
    assert grammar.labels[5][1] is None
    assert grammar.states[8][0] == (0, 9)
    assert grammar.dfas[11][1][token.LBRACE] == 1



# Generated at 2022-06-25 14:40:06.532276
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    # Make sure we can load a pgen pickle file and retrieve
    # the same value from an attribute that we had in there.
    grammar.load(os.path.join(os.path.dirname(__file__), "Pickle_Grammar"))
    assert grammar.start == 257
    assert grammar.number2symbol[257] == "file_input"
    assert grammar.symbol2label["atom"] == 2365


# Generated at 2022-06-25 14:40:10.139117
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    print("Unit test for Grammar.dump")
    grammar_0 = Grammar()
    print("Test normal function")
    print("Return: " + str(grammar_0.dump("C:/Users/L33698/Desktop/new_file")))



# Generated at 2022-06-25 14:40:28.084640
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    with tempfile.TemporaryDirectory() as tmpdir:
        file = os.path.join(tmpdir, "tempfile.txt")
        grammar_0.dump(file)


# Generated at 2022-06-25 14:40:29.791870
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(os.devnull)
    grammar.report()

# Generated at 2022-06-25 14:40:30.879932
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump(tokenize.__file__)



# Generated at 2022-06-25 14:40:34.947111
# Unit test for method load of class Grammar
def test_Grammar_load():

    grammar = Grammar()
    test_file_path = "./pgen2/grammar.pkl"

    if os.path.exists(test_file_path):
        grammar.load(test_file_path)
        assert hasattr(grammar, 'symbol2number')

# Generated at 2022-06-25 14:40:36.143025
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """Test Grammar.dump."""
    grammar = Grammar()
    grammar.dump("pickle")


# Generated at 2022-06-25 14:40:43.434941
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_2 = Grammar()
    # This doesn't actually test the contents of the file...
    grammar_1.dump("./test_temp/test.pickle")
    grammar_2.load("./test_temp/test.pickle")
    assert grammar_1.symbol2number == grammar_2.symbol2number
    assert grammar_1.number2symbol == grammar_2.number2symbol
    assert grammar_1.states == grammar_2.states
    assert grammar_1.dfas == grammar_2.dfas
    assert grammar_1.labels == grammar_2.labels
    assert grammar_1.start == grammar_2.start
    assert grammar_1.keywords == grammar_2.keywords
    assert grammar_1.tokens == grammar_2

# Generated at 2022-06-25 14:40:46.965188
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    filename_0 = './test_out/test_case_0/test_Grammar_load_0.pkl'
    grammar_0.load(filename_0)


# Generated at 2022-06-25 14:40:48.415151
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump('temp_grammar_object')
    os.remove('temp_grammar_object')


# Generated at 2022-06-25 14:40:53.031159
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    test_case_0()
    # grammar_0.dump(Path)
    # Check that grammar_0.dump raises NotImplementedError
    test_case_0()
    # grammar_0.dump(Path)
    # Check that grammar_0.dump raises NotImplementedError
    test_case_0()
    # grammar_0.dump(Path)
    # Check that grammar_0.dump raises NotImplementedError
    test_case_0()
    # grammar_0.dump(Path)
    # Check that grammar_0.dump raises NotImplementedError


# Generated at 2022-06-25 14:41:00.672601
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("./resources/pickle_test_grammar")
    assert grammar_0 is not None
    assert grammar_0.symbol2number is not None
    assert grammar_0.number2symbol is not None
    assert grammar_0.states is not None
    assert grammar_0.dfas is not None
    assert grammar_0.labels is not None
    assert grammar_0.keywords is not None
    assert grammar_0.tokens is not None
    assert grammar_0.symbol2label is not None

# Generated at 2022-06-25 14:41:21.479809
# Unit test for method load of class Grammar
def test_Grammar_load():
    tempfile_0 = tempfile.NamedTemporaryFile('w+b', delete=False)
    # It is later deleted by os.unlink(file.name)
    grammar_1 = Grammar()
    try:
        # The tempfile is deleted in the finally block
        # In the mean time, it is accessed by grammar_1.load
        # Important: the tempfile must not be closed before grammar_1.load finishes
        grammar_1.load(tempfile_0.name)
        assert (True)
    except:
        assert (False)
    finally:
        os.unlink(tempfile_0.name)

# Generated at 2022-06-25 14:41:22.279758
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump()

# Generated at 2022-06-25 14:41:26.994898
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    # print('Grammar_dump(): Dumping grammar tables to test_Grammar.pickle')
    grammar_0.dump('test_Grammar.pickle')
    grammar_1 = Grammar()
    # print('Grammar_dump(): Loading grammar tables from test_Grammar.pickle')
    grammar_1.load('test_Grammar.pickle')
    assert grammar_0 == grammar_1



# Generated at 2022-06-25 14:41:28.151622
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("test_data/grammar.pickle")


# Generated at 2022-06-25 14:41:30.549530
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.start = 257
    assert g.start == 257
    g.dump("test_grammar_dump.txt")
    g2 = Grammar()
    g2.load("test_grammar_dump.txt")
    assert g.start == g2.start

# Generated at 2022-06-25 14:41:31.358859
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()


# Generated at 2022-06-25 14:41:32.131890
# Unit test for method load of class Grammar
def test_Grammar_load():
    test_case_0()


# Generated at 2022-06-25 14:41:34.389042
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("./testdata/Python.grammar.pickle")


# Generated at 2022-06-25 14:41:35.902665
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('pytree.pgen2')


# Generated at 2022-06-25 14:41:37.618483
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("../test/input/grammar.pickle")


# Generated at 2022-06-25 14:41:58.282470
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    pkl = g.loads(test_data_0)
    g.load(test_data_0)
    g.load(test_data_0)


# Generated at 2022-06-25 14:42:03.724118
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('test_1.grammar')
    grammar_1 = Grammar()
    grammar_1.loads(open('test_1.grammar', 'rb').read())
    grammar_1.dump('test_2.grammar')
    grammar_2 = Grammar()
    grammar_2.loads(open('test_2.grammar', 'rb').read())



# Generated at 2022-06-25 14:42:06.998335
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    ret_val_1 = grammar_0.load("str_0")
    assert ret_val_1 is None


# Generated at 2022-06-25 14:42:12.812145
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = "test.pkl"
    test_case_0().dump(filename)
    with open(filename, "rb") as f:
        d = pickle.load(f)
    assert d == {
        "symbol2number": {},
        "number2symbol": {},
        "states": [],
        "dfas": {},
        "labels": [(0, "EMPTY")],
        "keywords": {},
        "tokens": {},
        "symbol2label": {},
        "start": 256,
    }
    os.remove(filename)


if __name__ == "__main__":
    import unittest

    if "dump" not in globals():
        unittest.main()

# Generated at 2022-06-25 14:42:16.545099
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("test_file_0")
    assert_equals(grammar_0.symbol2number, {'print': 2, 'name': 1, 'None': 3})
    assert_equals(grammar_0.number2symbol, {1: 'name', 2: 'print', 3: 'None'})
    assert_equals(grammar_0.start, 256)


# Generated at 2022-06-25 14:42:20.308160
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Dump the grammar tables to a pickle file.
    grammar_test = Grammar()
    # This is a bad unit test that should be fixed
    grammar_test.dump('pgen/parser.grammar')



# Generated at 2022-06-25 14:42:23.494846
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    filename_0 = 'apdcpkg.pickle'

    grammar_0.load(filename_0)


# Generated at 2022-06-25 14:42:25.701702
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # test case 1
    grammar_1 = Grammar()
    grammar_1.dump(os.path.join(tempfile.gettempdir(), "test_file"))


# Generated at 2022-06-25 14:42:27.572361
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("/tmp/test_Grammar_dump/test_case_0")


# Generated at 2022-06-25 14:42:37.578923
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.symbol2number = {'single_input': 256}
    grammar.number2symbol = {256: 'single_input'}
    grammar.states = [[[(1, 1)]]]
    grammar.dfas = {256: ([[(0, 1)]], {256: 1})}
    grammar.labels = [(0, "EMPTY")]
    grammar.keywords = {}
    grammar.tokens = {}
    grammar.symbol2label = {}
    grammar.start = 256
    with tempfile.NamedTemporaryFile() as f:
        grammar.dump(f.name)
        with open(f.name, "rb") as g:
            d = pickle.load(g)

# Generated at 2022-06-25 14:42:51.863490
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = test_case_0()
    grammar_1 = pickle.dump(grammar_0, 'a')
    assert grammar_1 == grammar_0



# Generated at 2022-06-25 14:42:53.881802
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar_0 = Grammar()
    grammar.load(grammar_0)

# Unit tests for method dumps of class Grammar

# Generated at 2022-06-25 14:43:02.356107
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    g = Grammar()

    # Do some crazy stuff to test that dump() can cope with it
    import pickle

    class Crazy:
        def __getstate__(self):
            return {"foo": "bar"}

    d = {
        "string": "foo",
        "int": 42,
        "list": [1, 2, 3],
        "crazy": Crazy(),
        "dict": {"foo": "bar"},
        "none": None,
    }
    for name, value in list(d.items()):
        setattr(g, name, value)

    g.dump("/tmp/foo.pkl")

    with open("/tmp/foo.pkl", "rb") as f:
        d1 = pickle.load(f)


# Generated at 2022-06-25 14:43:04.461988
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    obj = tempfile.NamedTemporaryFile()
    grammar_0.dump(obj.name)
    obj.close()


# Generated at 2022-06-25 14:43:06.214110
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump(b'filename')

# Generated at 2022-06-25 14:43:09.660899
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """Test Grammar.dump()."""
    grammar_0 = Grammar()
    grammar_0.dump(os.devnull)  # test dump


# Generated at 2022-06-25 14:43:13.340084
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('/home/benjamin/.pyenv/versions/3.6.7/lib/python3.6/pickle.pkl')
    grammar_0.report()


Grammar.load.__doc__ = Grammar.load.__doc__

# Generated at 2022-06-25 14:43:20.185855
# Unit test for method load of class Grammar
def test_Grammar_load():
    testArgs = Path(os.getcwd())
    grammar_1 = Grammar()
    grammar_1.dump(testArgs)
    grammar_1.load(testArgs)

# Generated at 2022-06-25 14:43:24.697140
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = "test_Grammar_dump.pickle"
    grammar_0 = Grammar()
    grammar_0.dump(filename)

    grammar_1 = Grammar()
    grammar_1.load(filename)


# Generated at 2022-06-25 14:43:27.469698
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    with tempfile.TemporaryDirectory() as tmp_dir_name:
        grammar_0 = Grammar()
        grammar_0.dump(os.path.join(tmp_dir_name, test_Grammar_dump.__name__))


# Generated at 2022-06-25 14:43:50.894426
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    from .pgen2 import tokenize

    # Create a small grammar by parsing a real file
    with open(tokenize.__file__) as f:
        g = tokenize.generate_grammar(f.readline)

    # Dump the grammar to a temporary file
    temp_file_name = tempfile.mktemp()
    try:
        g.dump(temp_file_name)
        # Check the dump
        with open(temp_file_name, "rb") as f:
            dumped = pickle.load(f)
    finally:
        os.remove(temp_file_name)
    assert dumped == g.__dict__



# Generated at 2022-06-25 14:43:54.138616
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()

    try:
        grammar.dump("Grammar1")
    except IOError as e:
        assert False, "could not dump parser tables to Grammar1: " + str(e)


# Generated at 2022-06-25 14:43:55.466402
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    pass

# Generated at 2022-06-25 14:44:01.753978
# Unit test for method load of class Grammar
def test_Grammar_load():
    try:
        #
        # We serialise the grammar to a temporary file and reload it.
        #
        grammar_0 = test_case_0()
        grammar_0.dump(tempfile.mkstemp()[1])
        grammar_1 = Grammar()
        grammar_1.load(tempfile.mkstemp()[1])
    except Exception as exception:
        print(exception)
        raise exception


# Generated at 2022-06-25 14:44:04.072483
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.dump(grammar_pkl)
    grammar.load(grammar_pkl)
    assert grammar.async_keywords


# Generated at 2022-06-25 14:44:11.050042
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    test_case_0()

if __name__ == "__main__":
    import sys, traceback

    try:
        test_case_0()
    except AssertionError as e:
        traceback.print_exc(file=sys.stdout)

        print("\nTest case 0: FAILED")
    else:
        print("Test case 0: OK")

# Generated at 2022-06-25 14:44:15.033345
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    filename = "test_grammar_file.pkl"
    grammar_new = Grammar()
    try:
        grammar.dump(filename)
        grammar_new.load(filename)
    finally:
        if os.path.exists(filename):
            os.remove(filename)


# Generated at 2022-06-25 14:44:20.557627
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("./tests/test_resources/test_case_0.pickle")
    grammar_1 = Grammar()
    grammar_1.load("./tests/test_resources/test_case_0.pickle")


# Generated at 2022-06-25 14:44:30.274645
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("/home/docs/checkouts/readthedocs.org/user_builds/yourproject/checkouts/latest/test_grammar/grammar.pickle")
    grammar_1 = Grammar()
    grammar_1.tokens = {13: 1, 15: 2}
    grammar_1.dfas = {9: ([[(1, 7), (2, 5)]], {7: 3}), 13: ([[(3, 4)]], {4: 3}), 14: ([[(3, 5)]], {5: 3})}
    grammar_1.keywords = {'.': 1, 'class': 2}
    grammar_1.labels = [(0, 'EMPTY'), (1, '.'), (2, 'class')]
    grammar

# Generated at 2022-06-25 14:44:33.298466
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    assert grammar is not None, 'grammar is None'
    fd, filename = tempfile.mkstemp(suffix='.txt')
    grammar.dump(filename)
    with open(filename) as f:
        assert f is not None, 'f is None'


# Generated at 2022-06-25 14:44:54.853348
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()

# Generated at 2022-06-25 14:44:59.014323
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    tmp_file_path = os.path.join(tempfile.gettempdir(), 'tmp_pgen_Grammar.pkl')
    grammar.dump(tmp_file_path)
    # assert os.path.exists(tmp_file_path)
    # os.unlink(tmp_file_path)


# Generated at 2022-06-25 14:45:03.248723
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    # show_store: whether to print dump information
    show_store = False
    if show_store:
        grammar_0.dump(r"U:\nettest\grammar_0_dump.pkl")
    # show_load: whether to print load information
    show_load = False
    if show_load:
        grammar_0.load(r"U:\nettest\grammar_0_dump.pkl")


# Generated at 2022-06-25 14:45:05.827956
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    test_case_0()
    test_case_1()
    try:
        grammar_0.load('/home/benjello/Documents/pyspeed/cpython/Lib/pydoc.py')
    except Exception:
        pass



# Generated at 2022-06-25 14:45:07.107724
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("")


# Generated at 2022-06-25 14:45:08.496825
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('string')


# Generated at 2022-06-25 14:45:17.603710
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.keywords = {'async': 1, 'await': 1}
    grammar_0.tokens = {59: 2, 41: 2, 61: 2}
    grammar_0.labels = [(0, 'EMPTY'), (59, None), (41, None), (61, None)]
    grammar_0.symbol2label = {'test_4': 3}
    grammar_0.symbol2number = {'test_4': 257}
    grammar_0.number2symbol = {257: 'test_4'}
    grammar_0.start = 257

# Generated at 2022-06-25 14:45:19.144397
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = "TEST_FILE"
    grammar = Grammar()
    grammar.dump(filename)


# Generated at 2022-06-25 14:45:24.889266
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os.path
    import os
    import sys
    import tempfile
    import unittest
    import pickle

    class DumpCase(unittest.TestCase):

        def test_dump(self):
            grammar_0 = Grammar()
            grammar_0.symbol2number = {}
            grammar_0.symbol2number[':='] = 4
            grammar_0.symbol2number['|='] = 2
            grammar_0.symbol2number['%='] = 3
            grammar_0.symbol2number['-='] = 1
            grammar_0.symbol2number['*='] = 0
            grammar_0.number2symbol = {}
            grammar_0.number2symbol[0] = '*='
            grammar_0.number2symbol[2] = '|='

# Generated at 2022-06-25 14:45:26.451179
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("grammar1.py")

# def test_case_1():
#     grammar_0 = Grammar()
#     grammar_0.load("grammar1.py")


# Generated at 2022-06-25 14:45:44.104914
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.keywords["async"] == 645
    assert g.keywords["elif"] == 646
    assert g.keywords["yield"] == 647
    assert g.keywords["async"] == 645

    # Test Python 2.7
    g.keywords["yield"] = -1
    g.load(os.path.join(os.path.dirname(__file__), "Grammar2.7.pkl"))
    assert g.keywords["async"] == -1
    assert g.keywords["yield"] == -1

    # Test Python 2.6
    g.keywords["yield"] = -1
   

# Generated at 2022-06-25 14:45:46.335179
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('/my/file/name')


# Generated at 2022-06-25 14:45:50.106850
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    filename = tempfile.NamedTemporaryFile(delete=False).name
    grammar.dump(filename)
    grammar.load(filename)



# Generated at 2022-06-25 14:45:53.477124
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = "test_Grammar_dump.txt"
    if os.path.exists(filename):
        os.remove(filename)
    grammar = Grammar()
    grammar.dump(filename)
    assert os.path.exists(filename), "Grammar dump: file not created"
    assert os.path.getsize(filename) > 0, "Grammar dump: file has zero size"



# Generated at 2022-06-25 14:45:55.293899
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    test_case_0()


# Generated at 2022-06-25 14:45:56.789370
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_dump = Grammar()
    grammar_dump.dump("test_Grammar_dump.pkl")


# Generated at 2022-06-25 14:45:58.889399
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('/tmp/grammar_dump.out')



# Generated at 2022-06-25 14:46:01.392994
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    try:
        grammar_0.dump("+x.pyc")
    except AttributeError:
        pass
# No exception


# Generated at 2022-06-25 14:46:05.267911
# Unit test for method load of class Grammar
def test_Grammar_load():
    s = os.path.join(os.path.dirname(os.__file__), "..", "Lib", "lib2to3", "Grammar.txt")
    grammar_0 = Grammar()
    grammar_0.load(s)



# Generated at 2022-06-25 14:46:07.574498
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('/tmp/grammar_0.txt')


# Generated at 2022-06-25 14:46:24.578345
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load('pgen2/Grammar.pickle')

# Generated at 2022-06-25 14:46:25.695106
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("Grammar.pickle")



# Generated at 2022-06-25 14:46:27.837474
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Create an instance of Grammar.
    grammar_0 = Grammar()
    # Load grammar tables from a pickle file.
    grammar_0.load(
        b'/localhome/fhv274/final-test-data/test_parser/test_grammar.pkl'
    )


# Generated at 2022-06-25 14:46:28.747733
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("../Library/pgen2/Grammar.pickle")

# Generated at 2022-06-25 14:46:30.047655
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump(grammar_0)


# Generated at 2022-06-25 14:46:31.425825
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load("Grammar.pkl")



# Generated at 2022-06-25 14:46:34.305190
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    assert grammar_1.dump("./test.pickle") is None


# Generated at 2022-06-25 14:46:36.027236
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Test case 0
    test_case_0()
    if os.path.isfile("graminit_0.pickle"):
        os.remove("graminit_0.pickle")

# Generated at 2022-06-25 14:46:38.601178
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    try:
        grammar_0.load("./Grammar.pkl")
    except IOError as e:
        pass
