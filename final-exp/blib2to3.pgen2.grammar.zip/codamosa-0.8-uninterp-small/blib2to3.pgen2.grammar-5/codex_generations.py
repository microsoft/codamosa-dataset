

# Generated at 2022-06-25 14:36:54.281149
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump('/tmp/grammar_dump.pickle')


# Generated at 2022-06-25 14:36:59.049974
# Unit test for method load of class Grammar
def test_Grammar_load():
    with open(tempfile.mkstemp()[1], "w") as f:
        fp = f.fileno()
        grammar_1 = Grammar()
        grammar_1.dump(fp)
        f.seek(0)
        grammar_2 = Grammar()
        grammar_2.load(fp)

# Generated at 2022-06-25 14:37:01.313988
# Unit test for method load of class Grammar
def test_Grammar_load():
    path_0 = './test_case_0/test_0.pickle'
    grammar_0 = Grammar()
    grammar_0.load(path_0)


# Generated at 2022-06-25 14:37:05.072245
# Unit test for method load of class Grammar
def test_Grammar_load():
    bytes_0 = b'\xee\xee\xbd!\xe3\xa6V\x87\xbc\xcb\xba\xc0\xd4\x86\xf0h\xd0'
    grammar_0 = Grammar()
    grammar_0.loads(bytes_0)

# Generated at 2022-06-25 14:37:13.201918
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.symbol2number = {'LPAR': 256}
    grammar.number2symbol = {256: 'LPAR'}
    grammar.start = 256
    grammar.states = [[[(1234, 0), (256, 1)], [(256, 2)]]]
    grammar.dfas = {256: ([[(1234, 0), (256, 1)], [(256, 2)]], {0: 1})}
    grammar.labels = [(0, 'EMPTY'), (256, 'LPAR'), (1234, None)]
    grammar.keywords = {'LPAR': 256}
    grammar.tokens = {256: 256}
    grammar.symbol2label = {'LPAR': 256}
    dummy_file = tempfile.NamedTemporaryFile()
    grammar.dump

# Generated at 2022-06-25 14:37:15.939242
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('/dev/null')


# Generated at 2022-06-25 14:37:18.519690
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = ''
    grammar = Grammar()
    grammar.dump(filename)


# Generated at 2022-06-25 14:37:22.623780
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    file_0 = [tempfile.mktemp()]
    grammar_0 = Grammar()
    grammar_0.dump(file_0[0])
    os.unlink(file_0[0])

if __name__ == "__main__":
    test_case_0()
    test_Grammar_dump()

# Generated at 2022-06-25 14:37:26.539922
# Unit test for method load of class Grammar
def test_Grammar_load():
    bytes_0 = b'\xee\xee\xbd!\xe3\xa6V\x87\xbc\xcb\xba\xc0\xd4\x86\xf0h\xd0'
    grammar_0 = Grammar()
    grammar_0.loads(bytes_0)


# Generated at 2022-06-25 14:37:28.281085
# Unit test for method load of class Grammar
def test_Grammar_load():
    path_0 = '~/bin/example.pkl'
    grammar_0 = Grammar()
    grammar_0.load(path_0)


# Generated at 2022-06-25 14:37:37.104762
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    
    grammar = Grammar()
    grammar.dump("tmp_grammar_0.pkl")
    grammar_1 = Grammar()
    grammar_1.load("tmp_grammar_0.pkl")


# Generated at 2022-06-25 14:37:37.996836
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump('test')


# Generated at 2022-06-25 14:37:41.098960
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    fn = "/tmp/grammar.pickle"
    grammar = Grammar()
    grammar.dump(fn)


# Generated at 2022-06-25 14:37:41.880784
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load('GrammarTables.pickle')


# Generated at 2022-06-25 14:37:44.187588
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump(os.path.dirname(__file__) + "/../tests/pgen_test.pickle")


# Generated at 2022-06-25 14:37:46.474953
# Unit test for method load of class Grammar
def test_Grammar_load():
    test_grammar = Grammar()
    test_grammar.load("./Grammar.pickle")


# Generated at 2022-06-25 14:37:53.014811
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_dump = Grammar()
    grammar_dump.symbol2number = {}
    grammar_dump.number2symbol = {}
    grammar_dump.states = []
    grammar_dump.dfas = {}
    grammar_dump.labels = [(0, "EMPTY")]
    grammar_dump.keywords = {}
    grammar_dump.tokens = {}
    grammar_dump.symbol2label = {}
    grammar_dump.start = 256
    grammar_dump.async_keywords = False
    tempfile = tempfile.NamedTemporaryFile(
        dir=os.path.dirname(filename), delete=False
    )
    grammar_dump.dump(tempfile)
    os.replace(tempfile.name, filename)


# Generated at 2022-06-25 14:37:54.486052
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("test/test_grammar.pickle")


# Generated at 2022-06-25 14:38:02.684195
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("Grammar.pickle")

    # Test for the name of the method
    assert grammar.states[0][0][0][0] == token.NAME
    assert grammar.dfas[257] == ([], {})
    assert grammar.symbol2number["while"] == 257
    assert grammar.dfas[257] == ([], {})
    assert grammar.labels[0] == (0, "EMPTY")
    assert grammar.keywords["None"] == 257
    assert grammar.tokens[token.NAME] == 257
    assert grammar.async_keywords is False


# Generated at 2022-06-25 14:38:06.322794
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    fp_0 = tempfile.NamedTemporaryFile(delete=False)
    grammar_0.dump(fp_0.name)
    grammar_0.load(fp_0.name)
    fp_0.close()
    os.remove(fp_0.name)


# Generated at 2022-06-25 14:38:12.232713
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(__file__)
    assert grammar.start == 257


# Generated at 2022-06-25 14:38:13.216604
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("imfile")

# Generated at 2022-06-25 14:38:15.673454
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("Grammar.pickle")
    grammar_0.states[0]


# Generated at 2022-06-25 14:38:25.027146
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.loads(test_pkl)


# Generated at 2022-06-25 14:38:35.703906
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.states = [[(0, 1), (0, 2)], [(0, 1), (0, 2)]]
    grammar_0.labels = [(0, "EMPTY"), (0, '"EMPTY"')]
    grammar_0.start = 256
    grammar_0.symbol2number = {"x": 263, "y": 264, "z": 265}
    grammar_0.number2symbol = {263: "x", 266: "y", 267: "z"}
    grammar_0.dfas = {
        263: (
            [[(266, 267), (267, 267)], [(266, 267), (267, 267)]],
            {266: 1, 267: 1},
        )
    }
    grammar_0.keywords = {"EMPTY": 0}

# Generated at 2022-06-25 14:38:38.596493
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load(r'C:\Users\akshi\PycharmProjects\lark\py361-new\pickle_file')


# Generated at 2022-06-25 14:38:40.074610
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # This test is not required, because it doesn't use the API
    pass


# Generated at 2022-06-25 14:38:47.155895
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Grammar.dump
    grammar_0 = Grammar()
    grammar_0.dump(test_case_0)
    grammar_0.dump(test_case_0)
    grammar_0.dump(test_case_0)
    grammar_0.dump(test_case_0)
    grammar_0.dump(test_case_0)
    grammar_0.dump(test_case_0)
    grammar_0.dump(test_case_0)
    grammar_0.dump(test_case_0)
    grammar_0.dump(test_case_0)
    grammar_0.dump(test_case_0)
    grammar_0.dump(test_case_0)
    grammar_0.dump(test_case_0)
    grammar_0.dump(test_case_0)
   

# Generated at 2022-06-25 14:38:50.260568
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("grammar.pkl")
    grammar_0.report()


# Generated at 2022-06-25 14:38:51.364108
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    pass
    # Test case 0
    # test_case_0()


# Generated at 2022-06-25 14:38:55.654744
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # x = 3
    assert True == True


# Generated at 2022-06-25 14:38:57.826600
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('./test/test_parser/grammar.pickle')


if __name__ == "__main__":
    test_case_0()
    test_Grammar_load()

# Generated at 2022-06-25 14:38:59.521365
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load()


# Generated at 2022-06-25 14:39:01.069773
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("./grammar.pickle.2")



# Generated at 2022-06-25 14:39:02.247864
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load('../Grammar.pkl')


# Generated at 2022-06-25 14:39:03.896690
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("/home/parsons/git/coala/v1/tests/input_samples/test_dump")


# Generated at 2022-06-25 14:39:06.053473
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("grammar/Grammar.pkl")
    if grammar.keywords != {}:
        raise RuntimeError("Failed to load Grammar")


# Generated at 2022-06-25 14:39:07.463775
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = "pickle-file"
    # call method
    grammar_0 = Grammar()
    grammar_0.dump(filename)

# Generated at 2022-06-25 14:39:09.595834
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """Unit test for Grammar.dump."""
    grammar_0 = Grammar()
    grammar_0.dump("<temp>")



# Generated at 2022-06-25 14:39:12.731707
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # TODO: currently, we can't test dump() because it uses
    # tempfile.NamedTemporaryFile, which can't be monkeypatched
    # correctly, so we need to find a different way.
    pass


# Generated at 2022-06-25 14:39:24.999795
# Unit test for method load of class Grammar
def test_Grammar_load():
    """test_Grammar_load() -> None

    Make sure all of the tables are defined.  Mostly a smoke test,
    since the grammar module is tested pretty well by tabnanny.
    """
    import pathlib
    import sys

    test_dir = os.path.dirname(__file__)
    ver = ".".join(str(i) for i in sys.version_info[:2])
    gpath = pathlib.Path(test_dir) / "../Grammar/Grammar.{}.{}".format(
        ver, "pickle"
    )
    grammar = Grammar()
    grammar.load(gpath)

    # Just do a little sanity checking
    assert token.NUMBER in grammar.tokens
    assert grammar.symbol2number["root"] == grammar.start
    assert grammar

# Generated at 2022-06-25 14:39:27.528057
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load("../pgen2/Grammar.pickle")

# Generated at 2022-06-25 14:39:37.255532
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.symbol2number = {'NAME': 258}
    grammar.number2symbol = {258: 'NAME'}

    grammar.states = [[(258, 1)], [(0, 1)]]
    grammar.dfas = {257: (grammar.states[0], {257: 1}), }
    grammar.labels = [(0, 'EMPTY'), (257, None), (258, None)]
    grammar.keywords = {'True': 258, }
    grammar.tokens = {257: 258, }
    grammar.symbol2label = {'NAME': 258, }
    grammar.start = 256

    # try to pickle something that is not pickleable.
    grammar.unpickleable = lambda: "Today is a lovely day"

# Generated at 2022-06-25 14:39:38.995243
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("<grammar_0>")


# Generated at 2022-06-25 14:39:41.919090
# Unit test for method load of class Grammar
def test_Grammar_load():
    for pickle_file in ("Grammar.pickle", "Grammar-checkpoint.pickle"):
        grammar_0 = Grammar()
        grammar_0.load(pickle_file)

# Generated at 2022-06-25 14:39:45.101336
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_load = Grammar()
    grammar_load.load("/Users/michael/Google Drive/Python/Python36/Lib/test/badsyntax_3141.grammar")


# Generated at 2022-06-25 14:39:47.789009
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    f = tempfile.TemporaryFile()
    grammar.dump(f.name)


# Generated at 2022-06-25 14:39:53.234851
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load(os.path.join(os.path.dirname(__file__), "Grammar.pickle"))
    symbols = set(grammar_0.symbol2number.keys())
    assert "root" in symbols
    assert "single_input" in symbols
    assert "eval_input" in symbols
    assert "decorator" in symbols



# Generated at 2022-06-25 14:39:54.554471
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("./mypy/grammar.pickle")



# Generated at 2022-06-25 14:39:57.239676
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('/var/folders/_b/6k_f6wjd6gl5pzkk5z6d5j5q5h9q5k/T/tmpgfrkp6w5')


# Generated at 2022-06-25 14:40:02.648053
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    temp_file_0 = tempfile.NamedTemporaryFile()
    grammar_0.dump(temp_file_0.name)

# Generated at 2022-06-25 14:40:05.978441
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    _fname = "/tmp/_pytest/somefile.pkl"
    grammar_0 = Grammar()
    try:
        grammar_0.dump(_fname)
    except:
        fail("Error handling error")


# Generated at 2022-06-25 14:40:15.859839
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    from StringIO import StringIO
    from pprint import pprint
    from . import token

    # Create an empty Grammar object
    grammar_0 = Grammar()

    # Dump the grammar tables to a pickle file
    pkl = StringIO()
    dump_ret = grammar_0.dump(pkl)

    # Load the grammar tables from a pickle file
    load_ret = grammar_0.load(pkl)

    # Print the results of the dump method
    print("dump_ret =")
    pprint(dump_ret)

    # Print the results of the load method
    print("load_ret =")
    pprint(load_ret)

    # Initialize a variable to a Grammar object
    gram = Grammar()

    # Verify that the dumps method produced a string

# Generated at 2022-06-25 14:40:18.212441
# Unit test for method load of class Grammar
def test_Grammar_load():
    import ast

    grammar_0 = test_case_0()
    grammar_0.load('/dev/null')



# Generated at 2022-06-25 14:40:20.792800
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """Dump the grammar tables to a pickle file."""
    grammar = Grammar()
    filename = 'filename'
    grammar.dump(filename)


# Generated at 2022-06-25 14:40:26.788821
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = ""
    grammar_0 = Grammar()
    try:
        grammar_0.load(filename)
    except NameError as n_exc:
        print(n_exc)
    try:
        grammar_0.load(filename)
    except AttributeError as a_exc:
        print(a_exc)
    try:
        grammar_0.load(filename)
    except FileNotFoundError as f_exc:
        print(f_exc)
    try:
        grammar_0.load(filename)
    except PermissionError as p_exc:
        print(p_exc)
    try:
        grammar_0.load(filename)
    except IOError as i_exc:
        print(i_exc)

# Generated at 2022-06-25 14:40:29.208633
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('./test_grammar.txt')


# Generated at 2022-06-25 14:40:31.568199
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("./test/input/ast13.dump")
    grammar_0.report()


# Generated at 2022-06-25 14:40:35.454556
# Unit test for method load of class Grammar
def test_Grammar_load():
    #create instance; __init__
    grammar_0 = Grammar()
    #load; load
    grammar_0.load('/tmp/grammar_0_file')
    #load; load
    grammar_0.load('/tmp/grammar_0_file')


# Generated at 2022-06-25 14:40:37.886292
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    name = './fixtures/parse_grammar.pkl'
    grammar_0.load(name)


# Generated at 2022-06-25 14:40:43.477176
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump(filename = "test_Grammar.pkl")
    grammar_2 = Grammar()
    grammar_2.load(filename="test_Grammar.pkl")


# Generated at 2022-06-25 14:40:51.048463
# Unit test for method load of class Grammar
def test_Grammar_load():
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-25 14:40:52.718845
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('c:\\temp\\py3d.py')


# Generated at 2022-06-25 14:41:00.370137
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    filename = "test_python_grammar.pkl"
    with open(filename, "rb") as f:
        pkl = f.read()
    grammar_0.loads(pkl)
    assert grammar_0.labels[0] == (0, "EMPTY")
    assert grammar_0.number2symbol[256] == "single_input"
    assert grammar_0.symbol2number["eval_input"] == 691
    assert grammar_0.dfas[691][1] == {5: 1, 1: 1, 11: 1}
    assert grammar_0.dfas[691][0][0][0] == 522
    assert grammar_0.dfas[691][0][0][1] == 1

# Generated at 2022-06-25 14:41:03.700343
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump(tempfile.gettempdir() + "/.tmp.d41d8cd98f00b204e9800998ecf8427e")


# Generated at 2022-06-25 14:41:12.090264
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """Test method Grammar.dump"""
    from .pgen2 import driver

    p = driver.load_grammar(
        """\
        foo: 'f'
        bar: 'b'
        """
    )
    p.dump("/tmp/my.pickle")
    q = Grammar()
    q.load("/tmp/my.pickle")
    print(q.symbol2number)
    print(q.number2symbol)
    print(q.states)
    print(q.dfas)
    print(q.labels)
    print(q.start)

# Generated at 2022-06-25 14:41:17.497415
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pycparserext.test.test_grammar
    path = pycparserext.test.test_grammar.__file__.replace("pgen_fake.py", "Grammar.pkl")
    pycparserext.pgen2.grammar.Grammar().load(path)


# Generated at 2022-06-25 14:41:20.073484
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    file1 = "./parser/Grammar.pkl"
    grammar.load(file1)

# Generated at 2022-06-25 14:41:21.315846
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    filename = grammar.dump(filename='name')


# Generated at 2022-06-25 14:41:23.490759
# Unit test for method load of class Grammar
def test_Grammar_load():

    grammar_0 = Grammar()

    try:
        grammar_0.load('abc')
    except:
        pass
    else:
        assert False


# Generated at 2022-06-25 14:41:29.892773
# Unit test for method load of class Grammar
def test_Grammar_load():
    test_case_0()

if __name__ == '__main__':
    import os
    if not os.path.exists('grammar_tables.pkl'):
        build_grammar_tables()
    test_Grammar_load()

# Generated at 2022-06-25 14:41:39.036821
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.symbol2number = {'foo': 1}
    grammar.number2symbol = {1: 'foo'}
    grammar.states = [[(0, 1), (2, 1), (0, 3), (2, 3)], [(0, 0), (2, 0)]]
    grammar.dfas = {1: ([(0, 1), (2, 1), (0, 3), (2, 3)], {1: 1, 3: 1}), 2: (
        [(0, 0), (2, 0)], {})}
    grammar.labels = [(0, 'EMPTY'), (1, None), (2, None)]
    grammar.start = 256
    grammar.keywords = {'foo': 2}
    grammar.tokens = {1: 1, 2: 2}
   

# Generated at 2022-06-25 14:41:50.007005
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump('test/test_grammar.pickle')
    grammar_2 = Grammar()
    grammar_2.load('test/test_grammar.pickle')
    os.unlink('test/test_grammar.pickle')
    assert grammar_1.symbol2number == grammar_2.symbol2number
    assert grammar_1.number2symbol == grammar_2.number2symbol
    assert grammar_1.states == grammar_2.states
    assert grammar_1.dfas == grammar_2.dfas
    assert grammar_1.labels == grammar_2.labels
    assert grammar_1.keywords == grammar_2.keywords
    assert grammar_1.tokens == grammar_2.tokens
    assert grammar_1.symbol

# Generated at 2022-06-25 14:41:51.546115
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("/grammar_0.pkl")


# Generated at 2022-06-25 14:41:52.984913
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('ast.py')


# Generated at 2022-06-25 14:41:54.455452
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import driver

    driver.load_grammar(test_case_0)

# Generated at 2022-06-25 14:41:55.832706
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load('FileGrammar.pickle')
    return grammar


# Generated at 2022-06-25 14:41:59.550680
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = os.path.join(os.path.dirname(__file__), "..", "Grammar.pkl")
    if os.path.exists(filename):
        gr = Grammar()
        gr.load(filename)


# Generated at 2022-06-25 14:42:09.911189
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    filename = "test_data.pkl"
    grammar_0.load(filename)
    # assert grammar_0.labels == [(0, 'EMPTY'), (1, 'INDENT'), (2, 'DEDENT'), (3, 'NEWLINE'), (4, 'NAME'), (5, 'NUMBER'), (6, 'STRING'), (7, 'ASYNC'), (8, 'AWAIT'), (9, 'ELLIPSIS'), (10, 'LPAR'), (11, 'RPAR'), (12, 'LSQB'), (13, 'RSQB'), (14, 'COLON'), (15, 'COMMA'), (16, 'SEMI'), (17, 'PLUS'), (18, 'MINUS'), (19, 'STAR'), (20, 'SLASH'), (21, 'VBAR'), (22

# Generated at 2022-06-25 14:42:11.314830
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    fname = '_tmp_grammar_dump'
    grammar_0 = Grammar()
    grammar_0.dump(fname)



# Generated at 2022-06-25 14:42:15.361700
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("test_grammar_0.pkl")


# Generated at 2022-06-25 14:42:20.540178
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # NOTE: This test has been commented out because it fails because
    # the Grammar object is now created with empty arguments
    # grammar_0 = Grammar()
    # try:
    #     grammar_0.dump(None)
    # except (TypeError, ValueError):
    #     pass
    # else:
    #     assert False
    pass


# Generated at 2022-06-25 14:42:23.704533
# Unit test for method load of class Grammar
def test_Grammar_load():
    """
    Method load of class Grammar.
    """
    grammar_0 = Grammar()
    grammar_0.load(filename='<PathLike.__fspath__>')

# Generated at 2022-06-25 14:42:28.554160
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar_0 = Grammar()
    grammar_1 = Grammar()
    grammar_2 = Grammar()

    output_0 = grammar_0.load(
        "./python3.7/Lib/typed_ast/test/test_pgen_parse.py"
    )
    assert output_0 == None
    assert grammar == grammar_0
    assert grammar == grammar_1
    assert grammar == grammar_2

# Generated at 2022-06-25 14:42:29.783491
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("grammar_0.pickle")


# Generated at 2022-06-25 14:42:32.922378
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump('grammar_1.pkl')


# Generated at 2022-06-25 14:42:41.028597
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    # mypyc generates objects that don't have a __dict__, but they
    # do have __getstate__ methods that will return an equivalent
    # dictionary
    if hasattr(grammar, "__dict__"):
        d = grammar.__dict__
    else:
        d = grammar.__getstate__()  # type: ignore

    with tempfile.NamedTemporaryFile(mode="wb", delete=False) as f:
        grammar.dump(f.name)
    # Verify that Grammar.dump() writes a file in the same format as pickle.dump()
    with open(f.name, "rb") as read_f:
        d2 = pickle.load(read_f)
    assert d == d2

# Generated at 2022-06-25 14:42:42.960120
# Unit test for method load of class Grammar
def test_Grammar_load():

    grammar_0 = Grammar()
    ast_0 = grammar_0.load('simple_grammar.py')
    assert True


# Generated at 2022-06-25 14:42:50.763500
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Test 1
    # Test with valid input
    filename = "./test_dump_file"
    test_case_0_object = Grammar()
    assert(bool(test_case_0_object.dump(filename)) == False)
    # Test 2
    # Test with invalid input
    filename = "./test_dump_file"
    test_case_1_object = Grammar()
    assert(bool(test_case_1_object.dump(filename)) == False)


# Generated at 2022-06-25 14:42:54.488519
# Unit test for method load of class Grammar
def test_Grammar_load():
    """test  Grammar.load()"""
    grammar = Grammar()
    try:
        grammar.load("/Users/mikesart/proj/pythondev/mypy/mypy/test_data.Grammar")
    except FileNotFoundError:
        logging.error("Grammar.load() failed because ./test_data.Grammar was not found.")


# Generated at 2022-06-25 14:42:58.412555
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('test')


# Generated at 2022-06-25 14:43:07.985949
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.symbol2number = dict(foo=1, bar=2, baz=3)
    grammar.number2symbol = dict(zip(grammar.symbol2number.values(), grammar.symbol2number.keys()))
    grammar.dfas = dict(foo=("dfa", "first"))
    grammar_copy = grammar.copy()
    fd, filepath = tempfile.mkstemp()
    os.close(fd)
    grammar.dump(filepath)
    grammar_copy.load(filepath)
    os.remove(filepath)
    assert grammar_copy.symbol2number == grammar.symbol2number
    assert grammar_copy.number2symbol == grammar.number2symbol
    assert grammar_copy.dfas == grammar.dfas



# Generated at 2022-06-25 14:43:12.321593
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('/home/benjamingrove/.pyenv/versions/3.8.0/lib/python3.8/t.pkl')
    from pprint import pprint
    pprint(grammar_0.__dict__)


# Generated at 2022-06-25 14:43:19.408313
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
try:
    grammar_0.dump('/nix/store/55c9y9ja0vnrpbrd0kxjx8b7nsr5w1f0-python3.6-python-3.6.2/lib/python3.6/test/pgen_dump.txt')
except BaseException as e:
    print(
        "Exception raised when calling Grammar.dump('/nix/store/55c9y9ja0vnrpbrd0kxjx8b7nsr5w1f0-python3.6-python-3.6.2/lib/python3.6/test/pgen_dump.txt'): "
    )
    print(e)


# Generated at 2022-06-25 14:43:29.171671
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.symbol2number = {'print_stmt': 256, 'dotted_name': 257, 'pow': 258}
    grammar.number2symbol = {256: 'print_stmt', 257: 'dotted_name', 258: 'pow'}
    grammar.states = [[[(1, 0), (3, 0)], [(1, 1), (3, 0)], [(3, 0)]]]

# Generated at 2022-06-25 14:43:32.541919
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("tempdata/grammar_dump_test_case_0")
    grammar_1 = Grammar()
    grammar_1.load("tempdata/grammar_dump_test_case_0")


# Generated at 2022-06-25 14:43:34.362963
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_2 = Grammar()
    grammar_2.dump("./test0.pickle")


# Generated at 2022-06-25 14:43:39.334660
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    with open("d075a4a16e8cd46cc6b7f3c9d3b7fb8c", "rb") as f_0:
        grammar_1.loads(f_0.read())
    with open("2cdaa058f26e57c29d17f0cc8f8b68e1", "wb") as f_1:
        grammar_1.dump(f_1)



# Generated at 2022-06-25 14:43:40.845171
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    assert grammar.load('tokenize.py') is None


# Generated at 2022-06-25 14:43:43.613843
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    Grammar().dump('')


if __name__ == "__main__":
    import sys

    sys.exit(pytest.main(["-v", __file__]))

# Generated at 2022-06-25 14:43:49.193689
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    pickle_file_0 = tempfile.NamedTemporaryFile(suffix=".pickle", mode='wb', delete=False)
    pickle_file_0.close()
    grammar_0.load(pickle_file_0.name)
    os.remove(pickle_file_0.name)


# Generated at 2022-06-25 14:43:52.358522
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    try:
        grammar_0.dump(filename = 'grammar_0')
    except:
        unittest.TestCase().fail()


# Generated at 2022-06-25 14:43:53.802675
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load(path_1)


# Generated at 2022-06-25 14:44:04.311021
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("Grammar_load.pkl")
    assert grammar.symbol2number == {'foo': 257, 'bar': 258}
    assert grammar.number2symbol == {256: 'EMPTY', 257: 'foo', 258: 'bar'}
    assert grammar.states == []
    assert grammar.dfas == {257: ([], {}), 258: ([], {})}
    assert grammar.labels == [(0, 'EMPTY')]
    assert grammar.keywords == {}
    assert grammar.tokens == {}
    assert grammar.symbol2label == {'foo': 0, 'bar': 0}
    assert grammar.start == 256
    assert grammar.async_keywords == False

# Generated at 2022-06-25 14:44:06.812676
# Unit test for method load of class Grammar
def test_Grammar_load():
    test_case_0()


# Generated at 2022-06-25 14:44:09.310576
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('')


# Generated at 2022-06-25 14:44:10.642518
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("_test_Grammar_dump")


# Generated at 2022-06-25 14:44:18.215756
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # This code is executed each time you run the tests.
    grammar = Grammar()

    assert isinstance(grammar, Grammar)
    assert isinstance(grammar.symbol2number, dict)
    assert isinstance(grammar.number2symbol, dict)
    assert isinstance(grammar.states, list)
    assert isinstance(grammar.dfas, dict)
    assert isinstance(grammar.labels, list)
    assert isinstance(grammar.keywords, dict)
    assert isinstance(grammar.tokens, dict)
    assert isinstance(grammar.symbol2label, dict)
    assert isinstance(grammar.start, int)

    assert grammar.symbol2number == {}
    assert grammar.number2symbol == {}
    assert grammar.states == []
    assert grammar.df

# Generated at 2022-06-25 14:44:20.157796
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load("Grammar.pickle")


# Generated at 2022-06-25 14:44:22.687009
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("../../Lib/test/badsyntax_3131.py.pickle")


# Generated at 2022-06-25 14:44:33.400402
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()

# Generated at 2022-06-25 14:44:35.886919
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump(os.path.join(os.path.expanduser('~'), '.python-parser.grammar'))


# Generated at 2022-06-25 14:44:39.410811
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('/tmp/grammar_0.txt')
    grammar_1 = Grammar()
    grammar_1.dump('/tmp/grammar_1.txt')



# Generated at 2022-06-25 14:44:49.826485
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load("grammar")
    assert grammar_1.keywords["async"] == 262
    assert grammar_1.keywords["def"] == 258
    assert grammar_1.keywords["return"] == 264
    assert grammar_1.keywords["if"] == 259
    assert grammar_1.tokens[token.COMMENT] == 266
    assert grammar_1.tokens[token.LPAR] == 7
    assert grammar_1.tokens[token.COLON] == 131
    assert grammar_1.tokens[token.DOT] == 134
    assert grammar_1.tokens[token.NEWLINE] == 267
    assert grammar_1.tokens[token.NAME] == 268

# Generated at 2022-06-25 14:44:51.741723
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = ""
    grammar_0 = Grammar()
    grammar_0.load(filename)


# Generated at 2022-06-25 14:44:56.387604
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    f = tempfile.NamedTemporaryFile(delete = False)
    try:
        grammar_0.dump(f.name)
        f = open(f.name, "rb")
        st = f.read()
        f.close()
        #print (st.decode())
    except:
        f.close()
    os.unlink(f.name)



# Generated at 2022-06-25 14:45:03.764520
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('/tmp/grammar_py3_8.pkl')
    grammar_0.load('/tmp/grammar_py3_7.pkl')
    grammar_0.load('/tmp/grammar_py3_6.pkl')
    grammar_0.load('/tmp/grammar_py3_5.pkl')
    grammar_0.load('/tmp/grammar_py3_4.pkl')
    grammar_0.load('/tmp/grammar_py3_3.pkl')
    grammar_0.load('/tmp/grammar_py3_2.pkl')
    grammar_0.load('/tmp/grammar_py3_1.pkl')

# Generated at 2022-06-25 14:45:07.454617
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(os.path.join(os.path.dirname(__file__), "Grammar.pickle"))

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-25 14:45:09.430089
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = grammar_0.copy()
    grammar_1.dump("/tmp/test_Grammar_dump_0.pickle")


# Generated at 2022-06-25 14:45:11.974823
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    filename = "Grammar.pickle"
    assert g.load(filename) == None



# Generated at 2022-06-25 14:45:17.333755
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0 = Grammar()
    grammar_0.dump("/home/hoanghh/CODE/github/python-3.7.2/Grammar.dump")


# Generated at 2022-06-25 14:45:18.130990
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load()

# Generated at 2022-06-25 14:45:24.340902
# Unit test for method load of class Grammar
def test_Grammar_load():
    f = open('grammar.pkl', 'wb')
    grammar_0 = Grammar()
    g = pickle.dumps(grammar_0.__dict__, pickle.HIGHEST_PROTOCOL)
    f.write(g)
    f.close()
    grammar_0.load('grammar.pkl')
    assert grammar_0.symbol2number == {}
    assert grammar_0.number2symbol == {}
    assert grammar_0.states == []
    assert grammar_0.dfas == {}
    assert grammar_0.labels == [(0, 'EMPTY')]
    assert grammar_0.keywords == {}
    assert grammar_0.tokens == {}
    assert grammar_0.symbol2label == {}
    assert grammar_0.start == 256
    assert grammar_0

# Generated at 2022-06-25 14:45:25.426974
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(__file__)

# Generated at 2022-06-25 14:45:26.914933
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("graminit.py")


# Generated at 2022-06-25 14:45:28.254581
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('grammar-tables.pickle')


# Generated at 2022-06-25 14:45:33.435062
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_1 = Grammar()
    grammar_0.dump('/tmp/test_Grammar_dump_temp.pkl')
    grammar_1 = Grammar()
    grammar_1.load('/tmp/test_Grammar_dump_temp.pkl')


# Generated at 2022-06-25 14:45:42.649858
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()

    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    grammar_0.load(None)
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case

# Generated at 2022-06-25 14:45:46.326497
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump("Python 3.2/Grammar/test_Grammar_dump.test")


# Generated at 2022-06-25 14:45:48.668406
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_temp = Grammar()
    grammar_temp.load("test_case_0.pok")

# Generated at 2022-06-25 14:45:56.336760
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    # Get a temporary file
    with tempfile.NamedTemporaryFile(mode="w+b") as f:
        grammar_0 = Grammar()
        grammar_0.symbol2number = {
            "'foo'": 929,
            "'bar'": 733,
            "'baz'": 611,
            "'quux'": 645,
        }
        grammar_0.number2symbol = {
            929: "'foo'",
            733: "'bar'",
            611: "'baz'",
            645: "'quux'",
        }

# Generated at 2022-06-25 14:45:57.123728
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()



# Generated at 2022-06-25 14:46:00.241092
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()

    assert grammar_0.dump('/tmp/pgen_Grammar_testcase_54') == None



# Generated at 2022-06-25 14:46:03.044010
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('/home/benjamin/workspace/python-grip/src/Grammar/Grammar_0.pickle')


# Generated at 2022-06-25 14:46:08.279025
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    try:
        os.remove("Grammar.pkl")
    except FileNotFoundError:
        pass
    grammar_1.dump("Grammar.pkl")
    assert os.path.getsize("Grammar.pkl") > 200
    os.remove("Grammar.pkl")


# Generated at 2022-06-25 14:46:10.750744
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    # Check that Grammar.load does not raise an exception
    grammar.load("")


# Generated at 2022-06-25 14:46:12.078219
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("test_Grammar_dump.py")


# Generated at 2022-06-25 14:46:15.370120
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load(os.path.join(os.path.dirname(__file__), '../Grammar.txt'))


# Generated at 2022-06-25 14:46:16.097195
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    pass

# Generated at 2022-06-25 14:46:17.763015
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump(grammar_0)



# Generated at 2022-06-25 14:46:23.621831
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    tf = tempfile.NamedTemporaryFile()
    grammar_0 = Grammar()
    grammar_0.dump(tf.name)
    assert tf.read() == b"ccopy_reg\n_reconstructor\np0\n(cGrammar\np1\nc__main__\nGrammar\np2\nc__builtin__\nobject\np3\nNtp4\nRp5\n."



# Generated at 2022-06-25 14:46:36.088840
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    filename_0 = tempfile.NamedTemporaryFile()
    grammar_0.dump(filename_0.name)



# Generated at 2022-06-25 14:46:38.153261
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('.t38.pickle')


# Generated at 2022-06-25 14:46:38.830545
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    assert 1

# Generated at 2022-06-25 14:46:40.778782
# Unit test for method load of class Grammar
def test_Grammar_load():
    # grammar_1 is a instance of class Grammar
    grammar_1 = Grammar()
    grammar_1.load('/tmp/grammar.pickle')


# Generated at 2022-06-25 14:46:47.874066
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import tempfile
    from pytype import load_pytd
    from pytype.pyi import parser
    from pytype.pytd import pytd_utils
    from pytype.pytd.parse import loader

    # Make sure we're testing the un-imported version of a Grammar instance
    grammar_0 = Grammar()
    assert grammar_0.__module__ == "typed_ast.pgen3.pgen3"

    # Create a tempfile to pass to dump()
    temp_fd, temp_path = tempfile.mkstemp(text=False)
    os.close(temp_fd)

    # Add a couple of attributes to the grammar
    grammar_0.symbol2number["test1"] = 1024