

# Generated at 2022-06-25 14:36:53.473519
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("grammar_0.txt")


# Generated at 2022-06-25 14:37:03.254826
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('/home/benjamin/workspace/python-grammar/Grammar.pkl')

# Generated at 2022-06-25 14:37:05.496994
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load("/home/michael/Projects/Python/Python-3.7.4/Grammar/Grammar.pickle")


# Generated at 2022-06-25 14:37:06.946714
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('/tmp/grammar.pickle')


# Generated at 2022-06-25 14:37:08.338781
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("filename")


# Generated at 2022-06-25 14:37:09.913221
# Unit test for method load of class Grammar
def test_Grammar_load():

    grammar_0 = Grammar()
    grammar_0.load('./pgen_pickle.pkl')



# Generated at 2022-06-25 14:37:10.605629
# Unit test for method load of class Grammar
def test_Grammar_load():
    test_case_0()


# Generated at 2022-06-25 14:37:13.938707
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Create an instance of grammar_0
    grammar_0 = Grammar()

    # Call method dump of grammar_0
    grammar_0.dump("test_grammar_0.pkl")

    # Remove the file created
    os.remove("test_grammar_0.pkl")


# Generated at 2022-06-25 14:37:24.454005
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.symbol2number = {}
    g.number2symbol = {}
    g.states = [[(0, 0)]]
    g.dfas = {}
    g.labels = [(1, "label")]
    g.keywords = {}
    g.tokens = {}
    g.symbol2label = {}
    g.start = 2
    g.async_keywords = False

    import pickle
    s = pickle.dumps(g)
    h = Grammar()
    h.loads(s)
    assert h.symbol2number == {}
    assert h.number2symbol == {}
    assert h.states == [[(0, 0)]]
    assert h.dfas == {}
    assert h.labels == [(1, "label")]


# Generated at 2022-06-25 14:37:35.616293
# Unit test for method load of class Grammar
def test_Grammar_load():
    def __init__(self):
        self.symbol2number = {}
        self.number2symbol = {}
        self.states = []
        self.dfas = {}
        self.labels = [(0, "EMPTY")]
        self.keywords = {}
        self.tokens = {}
        self.symbol2label = {}
        self.start = 256
        self.async_keywords = False
    grammar_1 = Grammar()
assert grammar_1.symbol2number == {}
assert grammar_1.number2symbol == {}
assert grammar_1.states == []
assert grammar_1.dfas == {}
assert grammar_1.labels == [(0, "EMPTY")]
assert grammar_1.keywords == {}
assert grammar_1.tokens == {}

# Generated at 2022-06-25 14:37:48.795516
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    temp_path = tempfile.mkdtemp()
    filename_0 = os.path.join(temp_path, 'grammar.pickle')
    grammar_0.dump(filename_0)
    assert os.path.exists(filename_0)
    # Test file written
    assert os.path.getsize(filename_0) > 0
    # Test contents
    with open(filename_0, "rb") as f:
        data = pickle.load(f)

# Generated at 2022-06-25 14:37:51.344936
# Unit test for method load of class Grammar
def test_Grammar_load():

    grammar_1 = Grammar()

    grammar_1.load('graminit.pickle')

# Generated at 2022-06-25 14:38:01.231168
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.start = 256
    grammar_0.dfas = {256: ([[(258, 1), (0, 0)], [(0, 2)], [(0, 1)]], {256: 1})}
    grammar_0.tokens = {257: 258}
    grammar_0.async_keywords = False
    grammar_0.number2symbol = {256: 'SYNC_COMPILER', 257: 'NAME', 258: 'EMPTY'}
    grammar_0.keywords = {}
    grammar_0.labels = [(0, 'EMPTY'), (257, None), (258, 'SYNC_COMPILER')]
    grammar_0.symbol2label = {'SYNC_COMPILER': 258}
    grammar_0.symbol2

# Generated at 2022-06-25 14:38:02.734522
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("test_data")



# Generated at 2022-06-25 14:38:09.869225
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    with tempfile.TemporaryDirectory() as tmpdir:
        filename = os.path.join(tmpdir, "test.pkl")
        grammar_0.dump(filename)
        grammar_1 = Grammar()
        grammar_1.load(filename)
        assert grammar_0.symbol2number == grammar_1.symbol2number
        assert grammar_0.number2symbol == grammar_1.number2symbol
        assert grammar_0.dfas == grammar_1.dfas
        assert grammar_0.labels == grammar_1.labels
        assert grammar_0.states == grammar_1.states
        assert grammar_0.start == grammar_1.start
        assert grammar_0.keywords == grammar_1.keywords
        assert grammar_0.tokens == grammar_

# Generated at 2022-06-25 14:38:12.376599
# Unit test for method load of class Grammar
def test_Grammar_load():
    #
    # Case 0
    #
    grammar_0 = Grammar()
    grammar_0.load('python-grammar.pkl')
    grammar_0.loads(b'')


# Generated at 2022-06-25 14:38:13.642804
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_d = Grammar()
    grammar_d.dump(grammar_d)


# Generated at 2022-06-25 14:38:16.743100
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('/tmp/grammar_0.pickle')

# Generated at 2022-06-25 14:38:19.936253
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    assert grammar.load() == grammar.loads(pickle.dumps())



# Generated at 2022-06-25 14:38:30.974452
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("./Grammar.pickle")

# Generated at 2022-06-25 14:38:37.511308
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("__Grammar_test_file_0")

test_case_0()
test_Grammar_dump()

# Generated at 2022-06-25 14:38:41.218636
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Test file not modified
    grammar_1 = Grammar()
    assert "grammar_1_dumped.pkl" not in os.listdir()
    grammar_1.dump("grammar_1_dumped.pkl")
    os.remove("grammar_1_dumped.pkl")


# Generated at 2022-06-25 14:38:42.626996
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("Grammar.pkl")


# Generated at 2022-06-25 14:38:48.020829
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    file_2 = tempfile.NamedTemporaryFile()
    file_2.close()
    grammar_1.dump(file_2.name)


# Generated at 2022-06-25 14:38:51.576874
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    try:
        grammar_0.dump("grammar-tables.pickle")
        assert False
    except IOError as error:
        errno = error.errno
        assert errno == 2


# Generated at 2022-06-25 14:38:54.901077
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0_old = None
    grammar_0.load('/home/benjamin/workspace/python-future-master/src/python3-future/futurize/tests/grammar_0.pkl')
    assert (grammar_0 == grammar_0_old)


# Generated at 2022-06-25 14:38:55.948138
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump(tempfile.NamedTemporaryFile(delete=False))



# Generated at 2022-06-25 14:39:03.262225
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.start = 257
    grammar_1.symbol2number["chris"] = 257
    grammar_1.number2symbol[257] = "chris"
    grammar_1.dfas[257] = ([[(0, 1)], [(0, 2)], [(1, 2)]], {0: 1})
    grammar_1.keywords["loopy"] = 1
    grammar_1.tokens[1] = 1
    grammar_1.symbol2label["chris"] = 257
    grammar_1.labels = [(0, "EMPTY"), (1, "loopy")]

# Generated at 2022-06-25 14:39:04.439886
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('data/Grammar_dump')

# Generated at 2022-06-25 14:39:05.844609
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    grammar_0 = Grammar()

    grammar_0.dump(__file__)


# Generated at 2022-06-25 14:39:13.952671
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()

    grammar_0.load("./grammar.pickle")


# Generated at 2022-06-25 14:39:23.305706
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = test_case_0()
    grammar_1.load('pickle/Grammar.pickle')
    assert grammar_1.symbol2number == {'endmarker': 258, 'NEWLINE': 257, 'OP': 266}
    assert grammar_1.number2symbol == {258: 'endmarker', 257: 'NEWLINE', 266: 'OP'}

# Generated at 2022-06-25 14:39:24.211516
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump("./test")


# Generated at 2022-06-25 14:39:32.649432
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = os.path.join(os.path.dirname(__file__), "Grammar.pkl")
    g = Grammar()
    g.load(filename)
    assert g.number2symbol[0] == "EMPTY"
    assert g.number2symbol[256] == "start"
    assert g.start == 256
    assert g.dfas[256][1] == {1: 1, 2: 1, 3: 1}
    assert g.token2label[1] == 0

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 14:39:33.983468
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("test/test.pkl")


# Generated at 2022-06-25 14:39:36.140739
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("test")



# Generated at 2022-06-25 14:39:38.994982
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    f_file = os.path.join(os.path.dirname(__file__), "./Grammar.pkl")
    grammar_0.dump(f_file)


# Generated at 2022-06-25 14:39:43.155846
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_file = "grammar.pickle"
    grammar_0.load(grammar_file)
    grammar_0.loads(pickle.dumps(grammar_0.__dict__))
    grammar_0.dump(grammar_file)

if __name__ == "__main__":
    test_case_0()
    test_Grammar_load()

# Generated at 2022-06-25 14:39:46.491242
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load("./test-data/python.pkl")
    grammar_1.report()


# Generated at 2022-06-25 14:39:51.488967
# Unit test for method load of class Grammar
def test_Grammar_load():
    from io import BytesIO

    grammar_0 = Grammar()
    grammar_1 = Grammar()
    grammar_1.load(BytesIO(pickle.dumps(grammar_0.__getstate__(), pickle.HIGHEST_PROTOCOL))) # type: ignore


# Generated at 2022-06-25 14:40:02.997031
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump("test.pickle")

    grammar_1 = Grammar()
    grammar_1.load("test.pickle")

    assert (grammar_0.copy().labels == grammar_1.labels)


# Generated at 2022-06-25 14:40:05.422470
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Test Grammar.load"""
    grammar_0 = Grammar()
    grammar_0.load("Grammar.pickle")


# Generated at 2022-06-25 14:40:07.123370
# Unit test for method load of class Grammar
def test_Grammar_load():
    # This is a unittest stub.
    assert isinstance(Grammar.load, object)


# Generated at 2022-06-25 14:40:11.850611
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load('grammar.txt')
    assert (grammar_0.symbol2number != {})
    assert (grammar_0.number2symbol != {})
    assert (grammar_0.states != [])
    assert (grammar_0.dfas != {})
    assert (grammar_0.labels != [])

# Generated at 2022-06-25 14:40:14.040975
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = "grammar.pkl"
    Grammar().dump(filename)

# Generated at 2022-06-25 14:40:15.620475
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("bu/grammar.pickle")


# Generated at 2022-06-25 14:40:18.250172
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("/home/oliver/PycharmProjects/untitled/pgen2/Grammar.py")


# Generated at 2022-06-25 14:40:21.480555
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    filename = os.path.join(tempfile.gettempdir(), "grammar.pkl")
    grammar_0.dump(filename)
    grammar_0.load(filename)
    os.remove(filename)

# Generated at 2022-06-25 14:40:23.267384
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    # grammar_1.dump(filename)


# Generated at 2022-06-25 14:40:28.044639
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    tempFile = tempfile.NamedTemporaryFile(delete=True)
    # Make sure file is deleted
    grammar_0.dump(tempFile.name)
    # No Exceptions Raised as of 2020.04.12


# Generated at 2022-06-25 14:40:41.487212
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    # testing Grammar()
    grammar_1 = Grammar()
    # testing Grammar.dump
    grammar_1.dump("tests/test_grammar/test_grammar_dump_grammar_0.pickle")

# Generated at 2022-06-25 14:40:43.213316
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("./lib2to3/Grammar.pickle")


# Generated at 2022-06-25 14:40:46.444503
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    from io import BytesIO

    grammar_0.load(BytesIO(b"""\x80\x0c}q\x00."""))


# Generated at 2022-06-25 14:40:48.175183
# Unit test for method load of class Grammar

# Generated at 2022-06-25 14:40:49.826916
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # grammar_0 = Grammar()
    # assert_raises(TypeError, grammar_0.dump, "test_Grammar_dump_0")
    pass



# Generated at 2022-06-25 14:40:51.967363
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_1 = Grammar()

    assert grammar_0 == grammar_1
    # Load the pickle file and compare.
    grammar_0.load("Grammar.pickle")
    assert grammar_0 != grammar_1



# Generated at 2022-06-25 14:40:56.711798
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    try:
        grammar_1.dump((
            "rqr-\x01\xf5\x80\xe1\xbe`\xb8v\x9f\x18\xdeh\x8c\x86["
            "\xbf\xd3\xc8\xeb\xf7\x0b>\x7f\x1e\x7f\x06\\u\x8bW\xb5"
        ))
    except Exception as e:
        assert type(e) == TypeError
        assert str(e) == "unsupported operand type(s) for +: 'PathLike' and 'str'"
        print('test_Grammar dump success')



# Generated at 2022-06-25 14:40:59.703220
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('/tmp/pyc_test_3901/pgen_0.pkl')


# Generated at 2022-06-25 14:41:01.015491
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(b"grammar.pkl")


# Generated at 2022-06-25 14:41:11.927853
# Unit test for method load of class Grammar
def test_Grammar_load():
    assert grammar_0.load("grammars/python2.2.pickle") == None
    assert grammar_0.load("grammars/python2.4.pickle") == None
    assert grammar_0.load("grammars/python3.0.pickle") == None
    assert grammar_0.load("grammars/python3.3.pickle") == None
    assert grammar_0.load("grammars/python3.4.pickle") == None
    assert grammar_0.load("grammars/python3.5.pickle") == None
    assert grammar_0.load("grammars/python3.6.pickle") == None
    assert grammar_0.load("grammars/python3.7.pickle") == None



# Generated at 2022-06-25 14:41:25.765139
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump("/Users/Yingchun/PycharmProjects/py_rule_checker/test_case/test_grammar/out.pygrammar")


# Generated at 2022-06-25 14:41:31.596047
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    # Cleans Up test directories
    import shutil
    import os
    os.mkdir('tests/out')
    try:
        # creates pkl files in tests/out
        grammar.dump('tests/out/test_0')
        # Loads the pkl file
        grammar.load('tests/out/test_0')
    except Exception as e:
        print(e)
        assert False
    shutil.rmtree('tests/out')
    assert True


if __name__ == "__main__":
    import support, sys
    support.run_unittest(__name__)
    support.run_doctest(__name__)
    if sys.argv[-1] == "-t":
        print("Running coverage tests")

# Generated at 2022-06-25 14:41:35.463971
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load("/Users/hazim/Library/Caches/Python-Eggs/Grammar/Grammar_5db6f9d6be8c1d97a1bfeeb6c70d98b8_0.py")


# Generated at 2022-06-25 14:41:37.758955
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("/home/jonathanmorgan/work/django/django/db/models/__init__.py.pgen3")


# Generated at 2022-06-25 14:41:43.760812
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    gram_pickle_path = os.path.join(
        os.path.dirname(__file__), "Python37", "Grammar.pkl"
    )
    grammar.load(gram_pickle_path)
    assert isinstance(grammar.symbol2number, dict)
    assert isinstance(grammar.number2symbol, dict)
    assert isinstance(grammar.dfas, dict)
    assert isinstance(grammar.keywords, dict)
    assert isinstance(grammar.tokens, dict)
    assert isinstance(grammar.symbol2label, dict)
    assert isinstance(grammar.labels, list)
    assert isinstance(grammar.states, list)
    assert isinstance(grammar.start, int)

# Generated at 2022-06-25 14:41:45.179293
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("grammar_0.py")


# Generated at 2022-06-25 14:41:48.264504
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump("C:\\Users\\pandemonium\\Desktop\\Python\\Python37\\python\\Grammar_dump")


# Generated at 2022-06-25 14:41:56.466944
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    p = Grammar()
    p.symbol2number = {'foo': 3, 'bar': 5}
    p.number2symbol = {3: 'foo', 5: 'bar'}
    p.states = [
        [
            ((2, 'and'), 1),
            ((2, None), 3),
            ((1, 'x'), 3),
            ((1, 'y'), 3),
            ((1, 'z'), 3),
            ((4, None), 0),
            ((5, None), 0),
            ((6, None), 0),
            ((3, None), 0),
        ],
        [((4, None), 0)],
        [((4, None), 0)],
        [((0, None), 2), ((4, None), 2)],
    ]

# Generated at 2022-06-25 14:41:58.963883
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()
    grammar_1.load("../src/Grammar.txt")
    grammar_2 = Grammar()
    grammar_2.load("../src/Grammar.txt")
    assert grammar_1 == grammar_2


# Generated at 2022-06-25 14:42:00.963842
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()

    # Call Grammar.dump ( to_pickle_file )
    grammar_0.dump(to_pickle_file)



# Generated at 2022-06-25 14:42:23.832472
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump("./test_grammar.pkl")


# Generated at 2022-06-25 14:42:31.968055
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.tokens = {1: 1}
    grammar_1.dfas = {2: [[(0, 1)], {0: 1}]}
    grammar_1.states = [[[(2, 1)]]]
    grammar_1.symbol2number = {'module': 1}
    grammar_1.start = 1
    grammar_1.symbol2label = {'module': 1}
    grammar_1.keywords = {'def': 1, 'if': 1}
    grammar_1.labels = [(1, 'def'), (1, 'if'), (1, 'module')]
    grammar_1.number2symbol = {1: 'module'}


# Generated at 2022-06-25 14:42:37.706578
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_1 = Grammar()

# Generated at 2022-06-25 14:42:39.245854
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('')


# Generated at 2022-06-25 14:42:42.404133
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load("/home/hayj/dev/python-grammar/Grammar.pickle")

if __name__ == "__main__":
    g = Grammar()
    test_case_0()
    test_Grammar_load()

# Generated at 2022-06-25 14:42:45.198273
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()

    # Assign to __file__
    grammar_0.__file__ = ''

    grammar_0.load('__file__')


# Generated at 2022-06-25 14:42:54.718306
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()

# Generated at 2022-06-25 14:42:55.713925
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    grammar_0.load(__file__)

# Generated at 2022-06-25 14:42:58.098032
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    file_0: Path = "test/test_grammar.g"
    grammar_0.load(file_0)



# Generated at 2022-06-25 14:43:04.741225
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    # Input paramaters.
    grammar_0 = Grammar()
    filename_0 = "grammar.pickle"

    # Expected results.
    expected_filename_0 = "grammar.pickle"

    # Unit test for method dump of class Grammar
    # Case 1.
    # Dump the grammar tables to a pickle file for later use.
    expected_output_0 = None
    actual_output_0 = grammar_0.dump(filename_0)
    assert_output(expected_output_0, actual_output_0)
    assert_file_exists(expected_filename_0)



# Generated at 2022-06-25 14:43:52.358019
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    # Dump the grammar tables to a pickle file.
    grammar_1.dump('test.pkl')


# Generated at 2022-06-25 14:43:53.803564
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump('test_dump.pkl')


# Generated at 2022-06-25 14:43:58.951539
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    path = "grammar_1.pickle"
    try:
        grammar_1.dump(path)
    finally:
        try:
            os.remove(path)
        except OSError:
            pass


# Generated at 2022-06-25 14:44:02.727944
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    temp_file = tempfile.NamedTemporaryFile()
    temp_path = temp_file.name
    t = Grammar()
    t.dump(temp_path)
    actual_value = os.path.isfile(temp_path)
    assert actual_value


# Generated at 2022-06-25 14:44:09.579309
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    assert getattr(grammar_0, "symbol2number") == {}
    assert getattr(grammar_0, "number2symbol") == {}
    assert getattr(grammar_0, "states") == []
    assert getattr(grammar_0, "dfas") == {}
    assert getattr(grammar_0, "labels") == [(0, "EMPTY")]
    assert getattr(grammar_0, "keywords") == {}
    assert getattr(grammar_0, "tokens") == {}
    assert getattr(grammar_0, "symbol2label") == {}
    assert getattr(grammar_0, "start") == 256
    assert getattr(grammar_0, "async_keywords") == False



# Generated at 2022-06-25 14:44:13.196817
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_0 = Grammar()
    filename = os.path.join(os.path.dirname(__file__), "../../../astroid/tests/data/grammar3.7.pkl")
    grammar_0.load(filename)
    assert grammar_0 is not None


# Generated at 2022-06-25 14:44:15.426204
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    try:
        grammar_0.dump('test_grammars.pkl')
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-25 14:44:25.493698
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    # Initialize the grammar
    for line in opmap_raw.splitlines():
        if line:
            op, name = line.split()
            setattr(g, name, 1)
    g.dump(".test_Grammar_pickle")
    # Now read it back
    g = Grammar()
    g.load(".test_Grammar_pickle")
    # Now check the results
    for line in opmap_raw.splitlines():
        if line:
            op, name = line.split()
            assert getattr(g, name) == 1
    os.remove(".test_Grammar_pickle")


# Generated at 2022-06-25 14:44:29.450309
# Unit test for method load of class Grammar
def test_Grammar_load():
    f = tempfile.NamedTemporaryFile(delete=False)
    pkl = pickle.dumps({})
    f.write(pkl)
    f.close()
    gram = Grammar()
    gram.load(f.name)
    os.unlink(f.name)


# Generated at 2022-06-25 14:44:30.285652
# Unit test for method load of class Grammar
def test_Grammar_load():
    pass


# Generated at 2022-06-25 14:46:24.150767
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("./Grammar.pickle")

# Generated at 2022-06-25 14:46:27.113563
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump('./data/Grammar.dump')

if __name__ == "__main__":
    test_case_0()
    test_Grammar_dump()

# Generated at 2022-06-25 14:46:30.541016
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_1 = Grammar()
    grammar_1.dump("test_inputs/dump_out")
    grammar_2 = Grammar()
    grammar_2.load("test_inputs/dump_out")

if __name__ == "__main__":
    test_case_0()
    test_Grammar_dump()

# Generated at 2022-06-25 14:46:31.229046
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load('Grammar.pickle')


# Generated at 2022-06-25 14:46:32.048526
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.dump(tempfile.gettempdir())


# Generated at 2022-06-25 14:46:33.490970
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    grammar_0.load("../test/Grammar/test_grammar.pkl")
    print(grammar_0.dfas)
    grammar_0.dump("test_dump.pkl")

# Generated at 2022-06-25 14:46:35.243108
# Unit test for method load of class Grammar
def test_Grammar_load():
    path_0 = os.path.join(__file__, "test", "unittest_inputs.txt")
    test_case_0(path_0)

# Generated at 2022-06-25 14:46:38.024396
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = tempfile.NamedTemporaryFile().name
    grammar_0 = Grammar()
    grammar_2 = Grammar()
    grammar_2.dump(filename)
    grammar_0.dump(filename)

# Generated at 2022-06-25 14:46:43.595953
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load('Lib/grammar.test_pickle_0')
    assert grammar.number2symbol == {}
    assert grammar.symbol2number == {}
    assert grammar.dfas == {}
    assert grammar.keywords == {}
    assert grammar.labels == [(0, "EMPTY")]
    assert grammar.states == []
    assert grammar.symbol2label == {}
    assert grammar.tokens == {}


# Generated at 2022-06-25 14:46:45.537435
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_0 = Grammar()
    assert grammar_0.dump(0) == (
        None
    ), "Return value from Grammar.dump is None, but should be <class 'NoneType'>"
