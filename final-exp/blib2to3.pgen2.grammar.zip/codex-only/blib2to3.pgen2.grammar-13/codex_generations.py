

# Generated at 2022-06-23 15:30:13.302081
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-23 15:30:20.013309
# Unit test for constructor of class Grammar
def test_Grammar():
    g: Grammar = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256


# Generated at 2022-06-23 15:30:21.832542
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()

if __name__ == "__main__":
    test_Grammar()

# Generated at 2022-06-23 15:30:23.417752
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()



# Generated at 2022-06-23 15:30:24.630018
# Unit test for constructor of class Grammar
def test_Grammar():
    assert Grammar() is not None

# Generated at 2022-06-23 15:30:32.233135
# Unit test for method load of class Grammar
def test_Grammar_load():
    gr = Grammar()
    pkl = pickle.dumps({"async_keywords": False})
    gr.loads(pkl)
    assert gr.async_keywords == False

if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1:
        g = Grammar()
        g.load(sys.argv[1])
        g.report()
    else:
        print("usage: python3", sys.argv[0], "graminit.pkl")
        sys.exit(2)

# Generated at 2022-06-23 15:30:43.548919
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    # Generate a pickle file
    g.dump("grammar.pkl")
    # Read the pickle file and use it to initialize a new grammar
    with open("grammar.pkl", "rb") as f:
        pickl = f.read()
    h = Grammar()
    h.loads(pickl)
    assert g.symbol2number == h.symbol2number
    assert g.number2symbol == h.number2symbol
    assert g.states == h.states
    assert g.dfas == h.dfas
    assert g.labels == h.labels
    assert g.keywords == h.keywords
    assert g.tokens == h.tokens
    assert g.symbol2label == h.symbol2label
    assert g.start

# Generated at 2022-06-23 15:30:51.294598
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-23 15:30:54.212624
# Unit test for method report of class Grammar
def test_Grammar_report():
    from .pgen2 import driver
    from . import tokenize

    file = open('Grammar.py', 'rb')
    g = Grammar()
    g.start = g.symbol2number['file_input']
    setattr(tokenize,'NL',4)
    driver.parse_tokens(tokenize.generate_tokens(file.readline), g)
    g.report()

# Generated at 2022-06-23 15:30:59.021333
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2
    from .parse import Parser

    g = pgen2.driver.load_grammar(
        "Python.asdl", "Python/graminit.c", "Python/parsetok.c", "Python/token.c"
    )
    assert g

    g.dump(tempfile.gettempdir() + "/tmp_grammar")
    g2 = Grammar()
    g2.load(tempfile.gettempdir() + "/tmp_grammar")
    assert g == g2

    p = Parser(g)

# Generated at 2022-06-23 15:31:03.664651
# Unit test for method load of class Grammar
def test_Grammar_load():
    gram = Grammar()
    gram.load('./lib2to3/Grammar.pickle')
    gram.copy()
    gram.loads(b'\x80\x03}q\x00(mcopy\ndload\nq\x01.')
    gram.report()
    assert isinstance(gram, Grammar)

# Generated at 2022-06-23 15:31:16.215872
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-23 15:31:21.273305
# Unit test for method load of class Grammar
def test_Grammar_load():
    import typing
    import tempfile

    tb1 = Grammar()
    tb1.symbol2number['a'] = 1
    tb1.dump(os.path.join(tempfile.gettempdir(), "test_Grammar_load"))
    tb2 = Grammar()
    tb2.load(os.path.join(tempfile.gettempdir(), "test_Grammar_load"))

# Generated at 2022-06-23 15:31:32.903664
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2 import driver

    grammar = Grammar()
    driver.load_grammar(grammar, "Grammar.txt", "Grammar.pickle")

    import os.path
    import os
    import pprint
    import shutil

    filename = "/tmp/Grammar.pickle"

    # Remove file if exists
    if os.path.exists(filename):
        os.remove(filename)

    # Test dump
    grammar.dump(filename)

    # Test that file was created
    assert os.path.exists(filename)

    # Test that file is not empty
    assert os.path.getsize(filename) > 0

    # Test that file was not corrupted
    grammar_copied = Grammar()
    grammar_copied.load(filename)
    assert grammar == grammar_copied



# Generated at 2022-06-23 15:31:44.718938
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {"a": 1}
    g.number2symbol = {1: "a"}
    g.states = [[(1, 2)]]
    g.dfas = {5: ([(1, 2)], {})}
    g.labels = [(1, ""), (2, None)]
    g.keywords = {"b": 3}
    g.tokens = {1: 4}
    g.symbol2label = {"c": 5}
    g.start = 6
    g.async_keywords = True

    g2 = g.copy()

    g.symbol2number = {"x": 1}
    g.number2symbol = {1: "x"}
    g.states = [[(3, 2)]]

# Generated at 2022-06-23 15:31:55.700827
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g1.symbol2number['a'] = 1
    g1.symbol2number['b'] = 2
    g1.number2symbol[3] = 'c'
    g1.number2symbol[4] = 'd'
    g1.dfas[5] = (6, 7)
    g1.keywords['e'] = 8
    g1.tokens[9] = 10
    g1.symbol2label['f'] = 11
    g1.labels = [12, 13, 14]
    g1.states = [[15, 16], [17, 18], [19, 20]]
    g1.start = 21
    g1.async_keywords = True

    g2 = g1.copy()
    assert g1.symbol2number

# Generated at 2022-06-23 15:31:59.073137
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """
    This is a temporary unit test that should be removed when the feature is
    stable.
    """
    g = Grammar()
    g.dump("./pgen_data")
    g.load("./pgen_data")


# Generated at 2022-06-23 15:32:06.147842
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    # copy
    def copy_test():
        g = Grammar()
        g.symbol2number["a"] = 1
        g.number2symbol[2] = "b"
        g.states = [1, 2, 3]
        g.dfas[4] = [(1, 2), (3, 4)]
        g.labels = [1, 2, 3]
        g.start = 4
        g.async_keywords = True

        copy = g.copy()
        assert copy.symbol2number == g.symbol2number
        assert copy.number2symbol == g.number2symbol
        assert copy.states == g.states
        assert copy.dfas == g.dfas
        assert copy.labels == g.labels
        assert copy.start == g.start

# Generated at 2022-06-23 15:32:17.409486
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {"none_symbol_name": 94, "none_symbol_name_2": 96}
    g.number2symbol = {94: "none_symbol_name", 96: "none_symbol_name_2"}
    g.states = [[[(0, 1)], [(0, 1)]]]
    g.dfas = {94: (1, 1), 96: (2, 2)}
    g.labels = [(0, "EMPTY"), (1, "none_symbol_name"), (2, "none_symbol_name_2")]
    g.keywords = {'a' : 1, 'b' : 2}
    g.tokens = {'_COLON_' : 3, '_COMMA_' : 4}


# Generated at 2022-06-23 15:32:19.343962
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    original = Grammar()
    duplicate = original.copy()
    assert original.__dict__ == duplicate.__dict__

# Generated at 2022-06-23 15:32:25.721448
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    print(g)
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert not g.async_keywords

# Generated at 2022-06-23 15:32:33.773835
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import unittest
    import grammar

    class _TestGrammar(unittest.TestCase):
        def _test_Grammar_copy(self, pkg_dir: str):
            filename = os.path.join(pkg_dir, 'Grammar.pickle')
            g = grammar.Grammar()
            g.load(filename)
            g_copy = g.copy()
            for dict_attr in (
                'symbol2number',
                'number2symbol',
                'dfas',
                'keywords',
                'tokens',
                'symbol2label'):
                self.assertEqual(getattr(g, dict_attr), getattr(g_copy, dict_attr))
            self.assertEqual(g.labels, g_copy.labels)
            self

# Generated at 2022-06-23 15:32:41.559464
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2.conv import convert

    # generate and pickle a grammar
    g = Grammar()
    convert(g, "Grammar/Grammar.txt")
    pkl = pickle.dumps(g, pickle.HIGHEST_PROTOCOL)

    # load the pickle and check its contents
    gg = Grammar()
    gg.loads(pkl)
    assert gg.start == g.start
    assert gg.states == g.states
    assert gg.dfas == g.dfas
    assert gg.symbol2number == g.symbol2number

# Generated at 2022-06-23 15:32:50.017436
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {"S": 256}
    g.number2symbol = {256: "S"}
    g.states = [[[(1, 2)], [(3, 4)]]]
    g.dfas = {5: ([[(1, 2)], [(3, 4)]], {1: 1, 2: 1})}
    g.labels = [(0, "EMPTY"), (1, None), (2, None), (3, None), (4, None)]
    g.keywords = {"EMPTY": 1, None: 5}
    g.tokens = {1: 0, 2: 1, 3: 2}
    g.symbol2label = {"EMPTY": 0, None: 5}
    g.start = 256
    g.async_keywords = False

# Generated at 2022-06-23 15:32:56.721620
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.symbol2number = {"foo": 2}
    g.number2symbol = {2: "foo"}
    g.states = [[[(1, 2)], [(3, 4)]]]
    g.dfas = {5: ([[(1, 2)], [(3, 4)]], {})}
    g.labels = [("*", None), ("(", None), (")", None), (1, "else")]
    g.start = 1
    assert g.report() is None


# Generated at 2022-06-23 15:33:00.906265
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("_pgen_test/Python.pgen")
    assert len(grammar.states) == 4460
    assert len(grammar.number2symbol) == 1322


# Generated at 2022-06-23 15:33:08.417457
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(
        os.path.join(
            os.path.dirname(os.path.dirname(__file__)), "Grammar.pkl"
        )
    )
    assert g.keywords["async"] == 269
    assert g.tokens[token.NAME] == 257
    assert g.labels[257] == (1, None)
    assert g.labels[258] == (58, None)
    assert g.labels[258] == (58, None)
    assert g.labels[269] == (1, "async")
    assert g.states[0][8] == (258, 9)

# Generated at 2022-06-23 15:33:09.310909
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    g.report()



# Generated at 2022-06-23 15:33:15.165955
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    with open("Grammar.pickle", "rb") as f:
        pkl = f.read()
    g = Grammar()
    g.loads(pkl)
    for tk in g.tokens:
        assert tk in token.__dict__.values()
    for tp in g.keywords:
        assert tp in token.__dict__.values()

if __name__ == "__main__":
    test_Grammar_loads()

# Generated at 2022-06-23 15:33:26.347463
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {"symbol1":1, "symbol2":2}
    g.number2symbol = {1:"symbol1", 2:"symbol2"}
    g.dfas = {1:(1,{"token1":1}), 2:(2,{"token1":1})}
    g.keywords = {"k1":1, "k2":2}
    g.tokens = {"t1":1, "t2":2}
    g.symbol2label= {"l1":1, "l2":2}
    g.labels = [(0, "e"), (1, 1), (2, "k1")]

# Generated at 2022-06-23 15:33:36.479974
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import tempfile
    import shutil
    from .pgen2 import driver

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-23 15:33:37.282090
# Unit test for method report of class Grammar
def test_Grammar_report():
    gr = Grammar()
    gr.report()

# Generated at 2022-06-23 15:33:46.974309
# Unit test for method load of class Grammar
def test_Grammar_load():
    # save and then reload the pickle
    filename = os.path.dirname(__file__) + "/Grammar.test"
    grammar = Grammar()
    grammar.dump(filename)
    grammar2 = Grammar()
    grammar2.load(filename)
    os.unlink(filename)

    # test the data loaded from pickle
    assert grammar.symbol2number.keys() == grammar2.symbol2number.keys()
    assert grammar.symbol2number == grammar2.symbol2number
    grammar2.symbol2number["TEST"] = 666
    assert grammar.symbol2number != grammar2.symbol2number

    assert grammar.number2symbol == grammar2.number2symbol
    grammar2.number2symbol[666] = "FAIL"

# Generated at 2022-06-23 15:33:57.916076
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1: Grammar
    g2: Grammar
    for a in [1, 2] + list(range(10)):
        g1 = Grammar()
        g1.symbol2number = {"a": a}  # type: ignore
        g1.number2symbol = {a: "a"}
        g1.dfas = {a: (a, {a: 1})}
        g1.keywords = {"a": a}
        g1.tokens = {a: a}
        g1.symbol2label = {"a": a}
        g1.labels = [("a", "b")]
        g1.states = [("a", "b")]
        g1.start = a
        g1.async_keywords = bool(a % 2)
        g2 = g

# Generated at 2022-06-23 15:34:05.158476
# Unit test for constructor of class Grammar
def test_Grammar():
    dummy_grammar = Grammar()
    assert dummy_grammar.symbol2number is not None
    assert dummy_grammar.number2symbol is not None
    assert dummy_grammar.states is not None
    assert dummy_grammar.dfas is not None
    assert dummy_grammar.labels is not None
    assert dummy_grammar.keywords is not None
    assert dummy_grammar.tokens is not None
    assert dummy_grammar.start == 256

# Generated at 2022-06-23 15:34:13.480868
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.number2symbol[0] = 'foo'
    g.symbol2number['foo'] = 0
    g.symbol2label['bar'] = 0
    g.labels.append((0, None))
    g.keywords['baz'] = 0
    g.tokens[0] = 0
    g.states.append(1)
    g.dfas[1] = (2, 3)

    g2 = g.copy()

    assert g2.number2symbol == g.number2symbol
    g2.number2symbol[1] = 'bar'
    assert g2.number2symbol != g.number2symbol

    assert g2.symbol2number == g.symbol2number
    g2.symbol2number['bar'] = 1

# Generated at 2022-06-23 15:34:17.192387
# Unit test for method report of class Grammar
def test_Grammar_report():
    from test.support import captured_stdout
    from test.grammar_test import grammar, example_grammar

    with captured_stdout() as out:
        grammar.report()
        assert out.getvalue() == example_grammar



# Generated at 2022-06-23 15:34:26.197251
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    print("Testing Grammar loads")
    grammar = Grammar()

# Generated at 2022-06-23 15:34:27.653511
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    import tempfile
    with tempfile.NamedTemporaryFile(delete=False) as f:
        g.dump(f.name)



# Generated at 2022-06-23 15:34:32.456411
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import driver

    # Test grammar
    test_grammar_text = """
    s: a | b ;
    a: 'a';
    b: 'b';
    """
    pgen_dir = tempfile.TemporaryDirectory()
    pgen_path = pgen_dir.name

    driver.make_grammar(
        test_grammar_text,
        pgen_path,
        outputdir=pgen_path,
        tokenize=False,
        grammar=True
    )

    grammar = Grammar()

    # Load generated grammar tables to the Grammar instance
    grammar.load(os.path.join(pgen_path, "Grammar.txt"))

    # Check if the Grammar instance has the expected contents
    symbols = sorted(["s", "a", "b"])
   

# Generated at 2022-06-23 15:34:40.929861
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number['foo'] = 256
    g.number2symbol[256] = 'foo'
    g.states = [[[(1, 0)], [(0, 1)]]]
    fd, fn = tempfile.mkstemp(suffix=".pickle")
    os.close(fd)
    try:
        g.dump(fn)
        with open(fn, "rb") as f:
            data = f.read()
        g.loads(data)
        assert 'foo' in g.symbol2number
        assert g.symbol2number['foo'] == 256
    finally:
        os.remove(fn)

# Generated at 2022-06-23 15:34:46.522420
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    pkl_file = tempfile.NamedTemporaryFile(mode="w+b", delete=False)
    file_name = pkl_file.name
    pkl_file.flush()

    # Load the grammar tables 
    pg = pickle.load(open(os.path.join(os.path.dirname(__file__), "Grammar.pkl"), "rb"))
    pg.dump(file_name)

    # Load a copy of the grammar tables
    pg_copy = Grammar()
    pg_copy.load(file_name)

    # Check that the original and the copy are equal
    assert pg == pg_copy

# Generated at 2022-06-23 15:34:54.897429
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-23 15:35:03.238508
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    gr = Grammar()
    assert gr == gr.copy()
    gr.symbol2number = {'x': 10, 'y': 20}
    assert gr == gr.copy()
    gr.number2symbol = {30: 'z'}
    assert gr == gr.copy()
    gr.states = [[], [], []]
    assert gr == gr.copy()
    gr.dfas = {'a': 1, 'b': 2}
    assert gr == gr.copy()
    gr.labels = [(1, 'label'), (2, None), (3, 'label')]
    assert gr == gr.copy()
    gr.keywords = {'w': 1, 'z': 2}
    assert gr == gr.copy()
    gr.tokens = {'m': 1, 'n': 2}
   

# Generated at 2022-06-23 15:35:15.215317
# Unit test for method report of class Grammar
def test_Grammar_report():
    """Test the method report of class Grammar."""
    import textwrap

    g = Grammar()
    g.symbol2number = {"SPAM": 257}
    g.number2symbol = {257: "SPAM"}
    g.states = [[[(1, 0)]]]
    g.dfas = {257: ([[(1, 0)]], {0: 1}), 258: ([[(1, 0)]], {0: 1})}
    g.labels = [(0, "EMPTY"), (1, None)]
    g.keywords = {"REAL": 2}
    g.tokens = {265: 3}
    g.symbol2label = {"SPAM": 4}
    g.start = 257


# Generated at 2022-06-23 15:35:26.060865
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    g2 = Grammar()
    assert g2.start == g.start

    g = Grammar()
    g.symbol2number = {"(": 1, ")": 2, ",": 3, "+": 4}
    g.number2symbol = {1: "(", 2: ")", 3: ",", 4: "+"}

# Generated at 2022-06-23 15:35:33.607983
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import py_grammar

    class TestGrammarLoad(unittest.TestCase):
        def test_load(self):
            # Run the tests only if C pygram exists.
            if not py_grammar:
                raise unittest.SkipTest("Not testing under CPython")
            g = Grammar()
            py_grammar.init_grammar(g)
            g.dump("test-pgen.pkl")
            self.assertTrue(os.path.exists("test-pgen.pkl"))
            g = Grammar()
            g.load("test-pgen.pkl")
            self.assertEqual(g.start, 256)
            self.assertTrue("if" in [k for k, v in g.keywords.items() if v == 257])
            self

# Generated at 2022-06-23 15:35:34.265596
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()

# Generated at 2022-06-23 15:35:40.880598
# Unit test for constructor of class Grammar
def test_Grammar():
    import types

    g = Grammar()
    assert type(g) is Grammar
    for name in g.__dict__:
        assert hasattr(g, name)
        assert type(getattr(g, name)) is types.DictType or type(
            getattr(g, name)
        ) is types.ListType or name == "start" or name == "async_keywords"
    # print 'Grammar test OK'

if __name__ == "__main__":
    test_Grammar()

# Generated at 2022-06-23 15:35:52.908898
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    # check if the copy is identical to the original
    g = Grammar()
    g.states = [[[1,0],[0,2]], [[2,0]]]

# Generated at 2022-06-23 15:36:05.035236
# Unit test for method load of class Grammar

# Generated at 2022-06-23 15:36:15.366972
# Unit test for method load of class Grammar
def test_Grammar_load():
    from tempfile import mktemp
    from os import remove
    from ast_parse.testfile import test_example2, test_example2_ast
    from ast_parse.ast_gen import AstGen
    from ast_parse.parse import Parser

    parser = Parser()
    ast_gen = AstGen(ast_version=3, filename="testfile")
    ast_gen.traverse(test_example2_ast)
    dummy_filename = mktemp(dir=".")
    ast_gen.grammar.dump(dummy_filename)
    ast_gen = AstGen(ast_version=3, filename="testfile")
    ast_gen.grammar.load(dummy_filename)
    ast = parser.parse(ast_gen.grammar, test_example2, debug=False)
    remove(dummy_filename)


# Generated at 2022-06-23 15:36:27.203693
# Unit test for constructor of class Grammar
def test_Grammar():
    gr = Grammar()

    def check(attr: str, expect: Any) -> None:
        assert getattr(gr, attr) == expect, (attr, getattr(gr, attr), expect)

    check("symbol2number", {})
    check("number2symbol", {})
    check("states", [])
    check("dfas", {})
    check("labels", [(0, "EMPTY")])
    check("keywords", {})
    check("tokens", {})
    check("symbol2label", {})
    check("start", 256)
    check("async_keywords", False)


if __name__ == "__main__":
    import sys

    gr = Grammar()
    gr.load(sys.argv[1])
    gr.report()

# Generated at 2022-06-23 15:36:31.017391
# Unit test for constructor of class Grammar
def test_Grammar():
    with tempfile.TemporaryDirectory() as tmpdirname:
        tmpfilename = os.path.join(tmpdirname, "graminit.pk")
        g = Grammar()
        g.dump(tmpfilename)
        g.loads(g.dump(tmpfilename))

# Generated at 2022-06-23 15:36:38.719624
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # todo: make this test less magical by using a mock pickle
    # expect that the dfas member will be loaded into the grammar
    # with a DFA of the form [(0, 1), (1, 2), (2, 0)]
    test_dfa = [
        [(1, 2), (2, 3), (3, 0)],
        [(1, 2), (2, 2), (3, 2)],
        [(2, 3), (3, 0)],
        [(2, 3), (3, 3)],
    ]


# Generated at 2022-06-23 15:36:49.702099
# Unit test for method load of class Grammar
def test_Grammar_load():
    from pgen import generate_grammar

    g = Grammar()
    generate_grammar(g)
    with tempfile.NamedTemporaryFile(delete=False) as f:
        g.dump(f.name)
    g2 = Grammar()
    g2.load(f.name)
    assert g.number2symbol == g2.number2symbol
    assert g.symbol2number == g2.symbol2number
    assert g.dfas == g2.dfas
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label
    assert g.labels == g2.labels
    assert g.states == g2.states

# Generated at 2022-06-23 15:36:55.525290
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest

    g = Grammar()
    filename = './test_grammar.pkl'

    g.dump(filename)
    g.load(filename)

    class TestMethods(unittest.TestCase):
        def test_load(self):
            self.assertTrue(os.path.exists(filename))

    unittest.main()

# Generated at 2022-06-23 15:37:04.333983
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()

    assert repr(g) == "Grammar()"

    g.symbol2number = {"foo": 1, "bar": 2}
    g.number2symbol = {1: "foo", 2: "bar"}
    g.states = [[(1, 2)], [(3, 4)]]
    g.dfas = {3: ([(3, 4)], {1: 1}), 5: ([(1, 2)], {2: 1})}
    g.labels = [(1, "a"), (2, None), (3, "b")]
    g.start = 256
    g.keywords = {"a": 1, "b": 2, "c": 3}
    g.tokens = {4: 1, 5: 2, 6: 3}
    g.symbol2label

# Generated at 2022-06-23 15:37:14.729500
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    grammar = Grammar()
    grammar.symbol2number = {'a': 1}
    grammar.number2symbol = {1: 'a'}
    grammar.states = [[]]
    grammar.dfas = {1: ([], {})}
    grammar.labels = [(0, 'EMPTY')]
    grammar.keywords = {'a': 1}
    grammar.tokens = {1: 1}
    grammar.symbol2label = {'a': 1}
    grammar.start = 256

    copy_grammar = grammar.copy()

    assert grammar.symbol2number == copy_grammar.symbol2number
    assert grammar.number2symbol == copy_grammar.number2symbol
    assert grammar.states == copy_grammar.states
    assert grammar.dfas == copy_grammar.dfas

# Generated at 2022-06-23 15:37:23.376285
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-23 15:37:30.075158
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdir:
        path = os.path.join(tmpdir, "Grammar.dump")
        grammar.dump(path)
        grammar2 = Grammar()
        grammar2.load(path)
        assert grammar2.symbol2number == {}
        assert grammar2.number2symbol == {}
        assert grammar2.states == []
        assert grammar2.dfas == {}
        assert grammar2.labels == [(0, "EMPTY")]
        assert grammar2.keywords == {}
        assert grammar2.tokens == {}
        assert grammar2.symbol2label == {}
        assert grammar2.start == 256

# Generated at 2022-06-23 15:37:35.926813
# Unit test for constructor of class Grammar
def test_Grammar():
    gram = Grammar()
    assert isinstance(gram, Grammar)
    assert isinstance(gram.symbol2number, dict)
    assert isinstance(gram.number2symbol, dict)
    assert isinstance(gram.states, list)
    assert isinstance(gram.dfas, dict)
    assert isinstance(gram.labels, list)
    assert isinstance(gram.keywords, dict)
    assert isinstance(gram.tokens, dict)

# Generated at 2022-06-23 15:37:37.952451
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    pass

if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-23 15:37:41.541422
# Unit test for method report of class Grammar
def test_Grammar_report():
    """
    Test the method report of class Grammar.
    """
    # Set
    gr = Grammar()

    # Call method
    gr.report()

    # Check
    assert True


# Generated at 2022-06-23 15:37:52.414036
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import py_compile
    import sys

    filename = sys.executable
    dir = os.path.dirname(filename)
    out_filename = os.path.join(dir, "python.pkl")
    out_filename2 = os.path.join(dir, "python2.pkl")

    if not os.path.exists(filename):
        py_compile.compile(filename=filename, cfile=filename + "c", dfile=None, doraise=True)
    g = Grammar()
    g.start = 256
    g.symbol2number["foo"] = 257
    g.dump(out_filename)
    g2 = Grammar()
    g2.load(out_filename)
    assert g.start == g2.start

# Generated at 2022-06-23 15:37:57.374361
# Unit test for constructor of class Grammar
def test_Grammar():
    # Create a Grammar instance
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords == False


# Generated at 2022-06-23 15:38:00.587248
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    with open('Grammar_dump.pickle','rb') as f:
        g.loads(pickle.load(f))
    assert len(g.tokens) == 52

# Generated at 2022-06-23 15:38:09.896870
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    class CustomGrammar(Grammar):
        def __init__(self) -> None:
            super().__init__()
            self.x = 42
    g = CustomGrammar()
    g.y = 43
    h = g.copy()
    assert h.x == 42
    assert h.y == 43
    assert isinstance(h, CustomGrammar)
    assert hasattr(h, "__dict__")
    assert not h.__dict__["x"] is g.__dict__["x"]
    assert not h.__dict__["y"] is g.__dict__["y"]

# Generated at 2022-06-23 15:38:21.697359
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2.generate import generate
    from .tokenize import tokenize

    with tempfile.TemporaryDirectory() as t:
        g = generate(t)
        g.load(os.path.join(t, "Grammar.txt"))

        # Make sure that we can use the loaded object.
        g.parse("1")

    #  Issue 5699: load() uses pickle.load() to load the grammar.  Don't
    #  let anyone interfere.
    import pickle
    import io

    class Unloadable(pickle.Unpickler):
        def load(self) -> None:
            raise RuntimeError("Deliberate load failure")


# Generated at 2022-06-23 15:38:24.695702
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import driver
    g = Grammar()
    g.load("Grammar.txt")
    driver.load_grammar("Grammar.txt", g)
    assert vars(g) == vars(driver.grammar)

# Generated at 2022-06-23 15:38:25.366235
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()

# Generated at 2022-06-23 15:38:37.149602
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pytest
    from .tokenize import tokenize

    G1 = Grammar()
    for t in tokenize("print(1)"):
        pass

    G1.dump("dummy")

    G2 = Grammar()
    G2.load("dummy")

    def check_eq(attr1, attr2):
        try:
            assert getattr(G1, attr1) == getattr(G2, attr2)
        except AssertionError:
            pytest.fail(f"Grammar attributes {attr1} and {attr2} are not equal.")

    check_eq("symbol2number", "symbol2number")
    check_eq("number2symbol", "number2symbol")
    check_eq("states", "states")
    check_eq("dfas", "dfas")

# Generated at 2022-06-23 15:38:47.227591
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.symbol2number = {"'foo'": 256, 'bar': 257}
    grammar.number2symbol = {256: "'foo'", 257: 'bar'}
    grammar.start = 256
    tmp = tempfile.NamedTemporaryFile()
    try:
        grammar.dump(tmp.name)
        grammar2 = Grammar()
        grammar2.load(tmp.name)
        assert grammar.symbol2number == grammar2.symbol2number
        assert grammar.number2symbol == grammar2.number2symbol
        assert grammar.start == grammar2.start
    finally:
        tmp.close()

# Generated at 2022-06-23 15:38:53.091413
# Unit test for constructor of class Grammar
def test_Grammar():
    grammar = Grammar()
    assert grammar.symbol2number == {}
    assert grammar.number2symbol == {}
    assert grammar.states == []
    assert grammar.dfas == {}
    assert grammar.labels == [(0, "EMPTY")]
    assert grammar.keywords == {}
    assert grammar.tokens == {}
    assert grammar.symbol2label == {}
    assert grammar.start == 256
    assert grammar.async_keywords is False


# Generated at 2022-06-23 15:39:00.587261
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-23 15:39:00.943094
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()

# Generated at 2022-06-23 15:39:08.836808
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    class FakeGrammar(Grammar):
        def __init__(self):
            super().__init__()
            self.labels = [(0, "EMPTY")]
            self.start = 256

# Generated at 2022-06-23 15:39:17.010309
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io
    import sys
    import unittest
    from . import grammar

    class TestGrammarReport(unittest.TestCase):
        """Tests for the report method of class Grammar"""

        def runTest(self):
            # Capture sys.stdout
            saved = sys.stdout
            sys.stdout = io.StringIO()
            try:
                # Call the report method
                grammar.report()
            finally:
                # Restore sys.stdout
                out = sys.stdout.getvalue()
                sys.stdout.close()
                sys.stdout = saved
                if out:
                    print(out)

    # Run unittests
    unittest.main(TestGrammarReport())

# Generated at 2022-06-23 15:39:27.171930
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    _g = Grammar()

# Generated at 2022-06-23 15:39:36.804471
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.symbol2number = {}
    grammar.number2symbol = {}
    grammar.states = []
    grammar.dfas = {}
    grammar.labels = []
    grammar.keywords = {}
    grammar.tokens = {}
    grammar.symbol2label = {}
    grammar.start = 256
    grammar.async_keywords = False
    filename = "temp/pgen-dump"
    grammar.dump(filename)
    grammar.load(filename)
    assert grammar.symbol2number == {}
    assert grammar.number2symbol == {}
    assert grammar.states == []
    assert grammar.labels == []
    assert grammar.keywords == {}
    assert grammar.tokens == {}
    assert grammar.symbol2label == {}
    assert grammar.start == 256

# Generated at 2022-06-23 15:39:41.864612
# Unit test for method report of class Grammar
def test_Grammar_report():
    from pgen2 import driver
    from io import StringIO

    sio = StringIO()
    g = driver.load_grammar("Python.asdl", "Grammar.txt", "", "", "3.6")

    g.report()
    g.report(file=sio)
    assert sio.getvalue()

# Generated at 2022-06-23 15:39:52.757449
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import random
    import pickle

    def test_dict(n):
        test_dict = {}
        for i in range(n):
            test_dict[i] = random.randint(0, n)
        return test_dict

    def test_list(n):
        test_list = []
        for i in range(n):
            test_list.append(random.randint(0, n))
        return test_list

    def test_bytes(n):
        return pickle.dumps(test_dict(n))

    def assert_list_equal(list1, list2):
        assert list1 == list2

    def assert_dict_equal(dict1, dict2):
        assert dict1 == dict2

    def assert_bytes_equal(bytes1, bytes2):
        assert bytes1 == bytes2



# Generated at 2022-06-23 15:40:05.357838
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    Grammar_Orig = Grammar()
    Grammar_Orig.symbol2number = {1: 1}
    Grammar_Orig.number2symbol = {1: 1}
    Grammar_Orig.dfas = {1: 1}
    Grammar_Orig.keywords = {"a": 1}
    Grammar_Orig.tokens = {1: 1}
    Grammar_Orig.symbol2label = {1: 1}
    Grammar_Orig.labels = [1]
    Grammar_Orig.states = [1]
    Grammar_Orig.start = 1
    Grammar_Orig.async_keywords = False
    
    a = Grammar_Orig.copy()
    assert Grammar_Orig.symbol2number == a.symbol2number
    assert Grammar_Orig.number2symbol