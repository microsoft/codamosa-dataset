

# Generated at 2022-06-23 15:30:12.535669
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    """Test method Grammar.loads()."""
    class A(Grammar):
        def loads(self, pkl: bytes) -> None:
            self._update(pickle.loads(pkl))
    g = A()
    g.loads(b'\x80\x03}q\x00.')

# Generated at 2022-06-23 15:30:14.668528
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    gram = Grammar()
    gram.dump("test_Grammar")
    # TODO

# Generated at 2022-06-23 15:30:25.298802
# Unit test for method report of class Grammar
def test_Grammar_report():
    grammar = Grammar()
    grammar.start = 0
    grammar.symbol2number = {"a": 256}
    grammar.symbol2label = {}
    grammar.number2symbol = {256: "a"}
    grammar.labels = [(0, "EMPTY")]
    grammar.tokens = {}
    grammar.keywords = {}
    grammar.states = [[]]
    grammar.dfas = {256: ([], {"EMPTY": 0})}
    grammar.async_keywords = False

    out = grammar.report()
    assert out is None


if __name__ == "__main__":
    import sys

    g = Grammar()
    g.load(sys.argv[1])
    g.report()

# Generated at 2022-06-23 15:30:32.525205
# Unit test for method report of class Grammar
def test_Grammar_report():
    from . import test_grammar

    G = Grammar()
    G.symbol2number = {"STMT": 256, "NAME": 258}
    G.number2symbol = {256: "STMT", 258: "NAME"}
    G.states = [[[(258, 0), (0, 1)], [], [(256, 0), (0, 1)]]]
    G.dfas = {256: ([[(258, 0), (0, 1)], [], [(256, 0), (0, 1)]], {256: 1, 258: 1})}
    G.labels = [
        (0, None),
        (258, None),
        (256, None),
        (1, None),
        (2, None),
        (3, None),
        (4, None),
    ]

# Generated at 2022-06-23 15:30:42.689127
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    # Create an empty Grammar
    g = Grammar()
    # Add a symbol
    g.symbol2number["test"] = 1
    g.number2symbol[1] = "test"
    # Add a DFA
    g.states = [[[(1, 1)]], [[(2, 2)]]]
    g.dfas[1] = (g.states[0], {})
    g.dfas[2] = (g.states[1], {})
    # Add a label
    g.labels = [(1, "label1"), (2, "label2")]
    # Add a keyword
    g.keywords = {"test1": 1}
    # Add a token
    g.tokens = {1: 1}
    # Add a label

# Generated at 2022-06-23 15:30:52.080887
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.symbol2number = {"foo": 42}
    g.number2symbol = {42: "foo"}
    g.states = [[[(1, 2), (3, 4)]]]
    g.dfas = {1: ([[(1, 2), (3, 4)]], {4: 3}), 2: ([[(1, 2), (3, 4)]], {4: 3})}
    g.tokens = {3: 5, 4: 6}
    g.labels = [(1, "one"), (2, "two"), (3, "three"), (4, "four"), (5, "five"), (6, "six")]
    g.keywords = {"three": 3, "four": 4}
    g.symbol2label = {"foo": 42}
   

# Generated at 2022-06-23 15:30:53.574127
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))

# Generated at 2022-06-23 15:30:57.969517
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()

    # if the pickle is empty, it will fail
    g.dump(tempfile.mktemp())

# Generated at 2022-06-23 15:31:04.428112
# Unit test for method load of class Grammar
def test_Grammar_load():
    token_name = token.tok_name

    def check_grammar(g: Grammar) -> None:
        # check that all symbols in the grammar appear
        # as tokens, with the same token numbers
        symbols = g.number2symbol
        for number in symbols:
            symbol = symbols[number]
            assert g.symbol2number[symbol] == number
            assert token_name[number] == symbol
        for symbol in g.symbol2number:
            number = g.symbol2number[symbol]
            if not symbol in symbols:
                assert number > 256
            assert token_name[number] == symbol
        # check that all symbols in the token list appear
        # as symbols
        for number in range(1, max(g.number2symbol) + 1):
            symbol = token_name[number]

# Generated at 2022-06-23 15:31:11.186239
# Unit test for constructor of class Grammar
def test_Grammar():
    grammar = Grammar()
    assert grammar.symbol2number == {}
    assert grammar.number2symbol == {}
    assert grammar.states == []
    assert grammar.dfas == {}
    assert grammar.labels == [(0, "EMPTY")]
    assert grammar.keywords == {}
    assert grammar.tokens == {}
    assert grammar.symbol2label == {}
    assert grammar.start == 256

# Generated at 2022-06-23 15:31:21.920816
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    grammar = Grammar()

# Generated at 2022-06-23 15:31:28.932302
# Unit test for constructor of class Grammar
def test_Grammar():
    [_, filename] = tempfile.mkstemp()
    try:
        igr = Grammar()
        ogr = Grammar()

        # Check attr. assignment.
        igr.start = 100
        assert igr.start == 100

        # Check pickle/unpickle works.
        igr.dump(filename)
        ogr.load(filename)

        assert igr.start == ogr.start
    finally:
        os.unlink(filename)

# Generated at 2022-06-23 15:31:37.916190
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    # Dummy implementation of a Grammar
    g1 = Grammar()
    g1.symbol2number = {'NT_OFFSET': 256, 'file_input': 257, 'NEWLINE': 5}
    g1.number2symbol = {256: 'NT_OFFSET', 257: 'file_input', 5: 'NEWLINE'}
    g1.dfas = {257: ([[(258, 258)], [(0, -1)]], {}),
               5: ([[(6, 6)], [(0, -1)]], {})}
    g1.keywords = {'and': 241, 'as': 239, 'assert': 238, 'break': 240, 'class': 237}

# Generated at 2022-06-23 15:31:43.908314
# Unit test for constructor of class Grammar
def test_Grammar():
    # Test that Grammar constructor doesn't bomb
    g = Grammar()

    # For now, just make sure the name variables exist
    assert g.symbol2number
    assert g.number2symbol
    assert g.states
    assert g.dfas
    assert g.labels
    assert g.keywords
    assert g.tokens

# Generated at 2022-06-23 15:31:46.412898
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    # Test that dump() can be called without raising any
    # exception.
    grammar.dump("foo.pkl")

# Generated at 2022-06-23 15:31:56.352212
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    g.symbol2number = {'a':1, 'b':2}
    g.number2symbol = {1:'a', 2:'b'}
    g.states = [[[(1,1), (1,2)], [(1,3), (0,3)]]]
    g.dfas = {0:([[(1,1), (1,2)], [(1,3), (0,3)]], {1:1, 2:1}), \
              1:([[(1,1), (1,2)]], {3:1}), \
              2:([[(1,3), (0,3)]], {1:1})}
    g.labels = [(0,None), (1,None), (1,'b'), (1,None)]

# Generated at 2022-06-23 15:32:04.350993
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    a = Grammar()
    b = a.copy()
    lst = [a, b]
    assert lst[0].symbol2number == lst[1].symbol2number
    assert lst[0].number2symbol == lst[1].number2symbol
    assert lst[0].states == lst[1].states
    assert lst[0].dfas == lst[1].dfas
    assert lst[0].labels == lst[1].labels
    assert lst[0].keywords == lst[1].keywords
    assert lst[0].tokens == lst[1].tokens
    assert lst[0].symbol2label == lst[1].symbol2label
    assert lst[0].start == lst[1].start

# Generated at 2022-06-23 15:32:16.224673
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    grammar = Grammar()

# Generated at 2022-06-23 15:32:19.296750
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = "../Grammar.p"
    if os.path.exists(filename):
        g = Grammar()
        g.load(filename)


# Generated at 2022-06-23 15:32:29.452094
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()

# Generated at 2022-06-23 15:32:40.144546
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.symbol2number = {'and': 257, 'not': 258}
    g.number2symbol = {257: 'and', 258: 'not'}
    g.states = [
        [[(1, 1), (2, 2)]],
        [[(3, 3), (4, 4)]],
        [[(5, 5)]],
    ]
    g.dfas = {
        257: ([[[(1, 1), (2, 2)], [(3, 3), (4, 4)]], [[(5, 5)]]], {}),
        258: ([[[(1, 1), (2, 2)], [(3, 3), (4, 4)]], [[(5, 5)]]], {}),
    }

# Generated at 2022-06-23 15:32:44.332233
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {"a": 1, "b": 2}
    g.dump("/tmp/a")
    g2 = Grammar()
    g2.load("/tmp/a")
    assert g.symbol2number == g2.symbol2number

# Generated at 2022-06-23 15:32:50.066632
# Unit test for method report of class Grammar
def test_Grammar_report():
    import pytest
    from io import StringIO
    from logging import INFO, Logger, StreamHandler, getLogger

    f = StringIO()
    h = StreamHandler(f)
    l = Logger(__name__)
    l.setLevel(INFO)
    l.addHandler(h)

    g = Grammar()
    g.report()
    assert f.getvalue() == ""

    g.symbol2number[1] = 'x'
    g.number2symbol[2] = 'y'
    g.states = [[(0,1)], [(0,2)]]
    g.dfas = {1: (g.states[0], set())}
    g.labels = [(0, None), (1, None)]
    g.keywords = {'z': 1}
    g.t

# Generated at 2022-06-23 15:32:55.658150
# Unit test for constructor of class Grammar
def test_Grammar():
  grammar = Grammar()
  assert(grammar.symbol2number == {})
  assert(grammar.number2symbol == {})
  assert(grammar.states == [])
  assert(grammar.dfas == {})
  assert(grammar.labels == [(0, "EMPTY")])
  assert(grammar.keywords == {})
  assert(grammar.tokens == {})


# Generated at 2022-06-23 15:33:05.361111
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # class Grammar:
    #     """Pgen parsing tables conversion class."""
    #     def __init__(self) -> None:
    x = Grammar()
    assert x
    #         self.symbol2number: Dict[str, int] = {}
    assert x.symbol2number == {}
    #         self.number2symbol: Dict[int, str] = {}
    assert x.number2symbol == {}
    #         self.states: List[DFA] = []
    assert x.states == []
    #         self.dfas: Dict[int, DFAS] = {}
    assert x.dfas == {}
    #         self.labels: List[Label] = [(0, "EMPTY")]
    assert x.labels == [(0, "EMPTY")]
    #        

# Generated at 2022-06-23 15:33:16.925861
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import pickle

    g1 = Grammar()
    g1.symbol2number = {'a': 2}
    g1.number2symbol = {1: 'a', 2: 'b'}
    g1.dfas = {1: (1, 1), 2: (2, 3), 3: (3, 4)}
    g1.keywords = {'a': 1, 'b': 2}
    g1.tokens = {1: 3, 2: 4}
    g1.symbol2label = {'a': 1, 'b': 2}
    g1.labels = [(1, 'a'), (2, 'b')]
    g1.states = [[(1, 'a'), (2, 'b')], [(1, 'c'), (2, 'd')]]
    g1.start

# Generated at 2022-06-23 15:33:20.636787
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    p = Grammar()
    with tempfile.NamedTemporaryFile() as f:
        p.dump(f.name)
        p.load(f.name)

# Generated at 2022-06-23 15:33:31.253677
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .test.test_grammar import test_grammar
    from .parse import pgen

    g = test_grammar.copy()
    tmpfile = tempfile.mktemp()
    try:
        g.dump(tmpfile)
    finally:
        os.remove(tmpfile)

    h = pgen.Grammar()
    h.load(tmpfile)

    assert h.symbol2number == g.symbol2number
    assert h.number2symbol == g.number2symbol
    assert h.states == g.states
    assert h.dfas == g.dfas
    assert h.labels == g.labels
    assert h.start == g.start
    assert h.keywords == g.keywords
    assert h.tokens == g.tokens



# Generated at 2022-06-23 15:33:40.703068
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    from .pgen2 import Grammar as PGrammar
    from .pgen2 import tokenize as ptokenize
    from .pgen2 import yacc as pyacc

    g = PGrammar()
    g.parse("Grammar/Grammar.txt")
    parser = pyacc.yacc(module=g, debug=False)
    with open("Grammar/Grammar.txt") as f:
        parser.parse(f.read(), lexer=ptokenize.tokenize)

    c = g.copy()
    assert len(c.symbol2number) == len(g.symbol2number)
    for k, v in g.symbol2number.items():
        assert c.symbol2number.get(k) == v


# Generated at 2022-06-23 15:33:46.065540
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    old = Grammar()
    old.symbol2number = {'A': 123}
    new = old.copy()
    assert new.symbol2number == {'A': 123}
    assert new.symbol2number is not old.symbol2number
    assert not hasattr(new, "start")
    old.start = 123
    new = old.copy()
    assert new.start == 123
    assert new.start is not old.start

# Generated at 2022-06-23 15:33:51.423295
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    f = Grammar()
    with tempfile.NamedTemporaryFile(delete=False) as tmp_file:
        f.dump(tmp_file.name)
        with open(tmp_file.name, "rb") as read_file:
            assert read_file.read() != b''
        os.remove(tmp_file.name)

# Generated at 2022-06-23 15:33:57.802233
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io, sys
    from contextlib import redirect_stdout

    f = io.StringIO()
    with redirect_stdout(f):
        g = Grammar()
        g.report()
    actual = f.getvalue()
    with open(os.path.join(os.path.dirname(__file__), "grammar.out")) as f:
        expected = f.read()
    assert actual == expected


if __name__ == "__main__":
    test_Grammar_report()

# Generated at 2022-06-23 15:34:04.270389
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    g_new = Grammar()
    g_new.loads(g.dumps())
    assert (
        g.symbol2number == g_new.symbol2number
        and g.number2symbol == g_new.number2symbol
        and g.states == g_new.states
        and g.dfas == g_new.dfas
    )

# Generated at 2022-06-23 15:34:06.138105
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()


if __name__ == "__main__":
    test_Grammar()

# Generated at 2022-06-23 15:34:07.277744
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    filename = tempfile.mktemp()
    g = Grammar()
    g.dump(filename)

# Generated at 2022-06-23 15:34:17.960071
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {'a': 1, 'b': 2}
    g.number2symbol = {1: 'a', 2: 'b'}
    g.dfas = {1: ([2, 3], {1: 2}), 2: ([4, 5], {1: 2})}
    g.keywords = {'a': 1, 'b': 2}
    g.tokens = {100: 10, 200: 20}
    g.symbol2label = {'a': 1, 'b': 2}
    g.labels = [(1, None), (2, 'b')]
    g.states = [[('a', 1)], [('b', 2)]]
    g.start = 256

    g2 = g.copy()

    assert g2.symbol

# Generated at 2022-06-23 15:34:21.399810
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    # type: () -> None
    """
    The method copy of class Grammar should create a different object.
    """
    grammar = Grammar()
    new = grammar.copy()
    assert new.__class__ == Grammar
    assert new is not grammar



# Generated at 2022-06-23 15:34:24.766813
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    a = Grammar()
    a.a = "a"
    a.b = "b"
    b = a.copy()
    assert a.a == b.a == "a"
    assert a.b == b.b == "b"

# Generated at 2022-06-23 15:34:35.057810
# Unit test for method report of class Grammar
def test_Grammar_report():
    # Note that this "test" isn't really implemented, but we don't care
    # because it's only a debugging method.
    try:
        import StringIO
    except ImportError:
        from io import StringIO          # type: ignore
    import sys
    import token
    import unittest

    # Now make a fake version of the input for the test
    class FakeGrammar(unittest.TestCase):
        def setUp(self):
            self.start = True

        def test_report(self):
            # This is the actual test
            grammar = Grammar()
            print(grammar.report(), file=sys.stdout)

    output = StringIO.StringIO()
    old_stderr, old_stdout = sys.stderr, sys.stdout
    # Suppress the stderr from unitt

# Generated at 2022-06-23 15:34:42.222608
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g1.symbol2number = { 'LITERAL': 256}
    g1.number2symbol = {256: 'LITERAL'}
    g1.labels = [(0, 'EMPTY')] 
    g1.start = 256
    g2 = g1.copy()
    assert g1.symbol2number == g2.symbol2number
    assert g1.number2symbol == g2.number2symbol
    assert g1.labels == g2.labels
    assert g1.start == g2.start

# Generated at 2022-06-23 15:34:51.520991
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    grammar = Grammar()
    grammar.symbol2number = {"test1": 1, "test2": 2}
    grammar.number2symbol = {1: "test1", 2: "test2"}
    grammar.states = [[(0, 0), (1, 1)], [(1, 0), (2, 1)]]
    grammar.dfas = {1: (grammar.states[0], {1: 1}), 2: (grammar.states[1], {2: 1})}
    grammar.labels = [(0, None), (1, "test1"), (2, "test2")]
    grammar.start = 1
    grammar.keywords = {"test1": 1, "test2": 2}
    grammar.tokens = {1: 1, 2: 2}

# Generated at 2022-06-23 15:34:53.183044
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()

# Generated at 2022-06-23 15:34:59.965055
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Test Python 3:
    from . import pgen3
    from .parse import Parser

    p = Parser()
    p.setup(pgen3.pgen())
    p.setup(pgen3.pgen())  # Test "parser already loaded" check

    # Test Python 2:
    from . import pgen2
    from .parse import Parser

    p = Parser()
    p.setup(pgen2.pgen())


if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-23 15:35:03.097710
# Unit test for method report of class Grammar
def test_Grammar_report():
    from pgen2.grammar import PgenParser
    from pprint import pprint
    grammar = PgenParser("Grammar", "S")
    grammar = Grammar()
    # test path
    grammar.report()

if __name__ == "__main__":
    test_Grammar_report()

# Generated at 2022-06-23 15:35:04.581273
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump('Grammar')


# Generated at 2022-06-23 15:35:16.205831
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-23 15:35:19.064036
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.async_keywords == False


if __name__ == "__main__":
    import sys

    filename = sys.argv[1]
    g = Grammar()
    g.load(filename)
    g.report()

# Generated at 2022-06-23 15:35:28.821224
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-23 15:35:32.270326
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    gr = Grammar()
    name = "a"
    gr.dump(name)
    try:
        assert os.path.exists(name)
    finally:
        os.unlink(name)

# Generated at 2022-06-23 15:35:34.820332
# Unit test for constructor of class Grammar
def test_Grammar():
    gr = Grammar()
    assert gr

if __name__ == "__main__":
    test_Grammar()

# Generated at 2022-06-23 15:35:42.941908
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    g.symbol2number = {'x': 0, 'y': 1}
    g.number2symbol = {0: 'x', 1: 'y'}
    g.states = [[[(0, 1), (0, 2)], [(0, 2), (3, 4)]]]
    g.dfas = {2: (g.states[0], {4: 1, 5: 2})}
    g.labels = [(2, 'z')]
    g.keywords = {'y': 1}
    g.tokens = {3: 2}
    g.symbol2label = {'z': 2}
    g.start = 3
    g.async_keywords = True

    gp = g.copy()

# Generated at 2022-06-23 15:35:54.474590
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = "Grammar.pickle"
    load_Grammar = Grammar()
    load_Grammar.load(filename)

# Generated at 2022-06-23 15:35:57.399525
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # Even though Grammar doesn't subclass object, isinstance still
    # works as expected.
    assert isinstance(Grammar().loads(b"")[0], Grammar)

# Generated at 2022-06-23 15:36:10.078307
# Unit test for constructor of class Grammar
def test_Grammar():
    from pickle import dumps
    from .pgen2 import tokenize

    g = Grammar()
    g.symbol2number = {"foo": 257, "bar": 258}
    g.number2symbol = {257: "foo", 258: "bar"}
    g.start = 257
    dfa0arcs = [(0, 2), (3, 1)]
    dfa1arcs = [(1, 1), (2, 1)]
    dfa2arcs = [(3, 1), (1, 2)]
    g.dfas = {257: ([dfa0arcs, dfa1arcs], {0: 1, 1: 1, 2: 1}), 258: ([dfa2arcs], {1: 1})}

# Generated at 2022-06-23 15:36:14.670363
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g : Grammar = Grammar()
    s : Text = pickle.dumps({'x': 42})
    g.loads(s)
    assert g.x == 42
    g.loads(b'{x:42}')
    assert g.x == 42
    g.loads(b'{x:42')
    assert g.x == 42


# Generated at 2022-06-23 15:36:17.349021
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    d = pickle.dumps(token.tok_name)
    g = Grammar()
    g.loads(d)

# Generated at 2022-06-23 15:36:28.553261
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import pickle

    g = Grammar()
    g.number2symbol = {1: "test"}
    g.symbol2number = {"test": 1}
    g.dfas = {0: ([[(0, 1)]], {1: 1})}
    g.labels = [(5, "label")]
    g.states = [[[(0, 5)]]]
    g.start = 0
    g.async_keywords = False

    new = g.copy()
    assert new.__dict__ == g.__dict__
    assert new.__dict__ is not g.__dict__

    # It's not enough that the values are the same, they need to be the same
    # objects, for example if pickling
    assert new.number2symbol is g.number2symbol

# Generated at 2022-06-23 15:36:37.318721
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    import io

    g = Grammar()
    g.loads(io.BytesIO(b"cos\nsystem\n(S'ls'\ntR.").read())
    assert g.symbol2number == {'print_stmt': 260, 'comp_iter': 258, 'dictorsetmaker': 259}
    assert g.number2symbol == {258: 'comp_iter', 259: 'dictorsetmaker', 260: 'print_stmt'}
    assert g.states == [
        [
            [(258, 1), (259, 2), (260, 2)],
            [],
            [],
        ]
    ]
    assert g.dfas == {258: [[(258, 1), (259, 2), (260, 2)], {}], 259: [[], {}], 260: [[], {}]}
    assert g.lab

# Generated at 2022-06-23 15:36:39.247271
# Unit test for method report of class Grammar
def test_Grammar_report():
    G = Grammar()
    G.report()

test_Grammar_report()

# Generated at 2022-06-23 15:36:49.228450
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g_copy = g.copy()
    assert g.symbol2number == g_copy.symbol2number
    assert g.number2symbol == g_copy.number2symbol
    assert g.dfas == g_copy.dfas
    assert g.keywords == g_copy.keywords
    assert g.tokens == g_copy.tokens
    assert g.symbol2label == g_copy.symbol2label
    assert g.labels == g_copy.labels
    assert g.states == g_copy.states
    assert g.start == g_copy.start
    assert g.async_keywords == g_copy.async_keywords

# Generated at 2022-06-23 15:36:58.068832
# Unit test for method report of class Grammar
def test_Grammar_report():

    def f():
        t = Grammar()
        t.symbol2number = {"a": 1, "b": 2}
        t.number2symbol = {1: "a", 2: "b"}
        t.start = 256
        t.states = [[]]
        t.dfas = {
            1: ([], {}),
            2: ([[(0, 0)]], {0: 0}),
            256: ([], {}),
        }
        t.labels = [(0, "EMPTY")]
        t.keywords = {}
        t.tokens = {}
        t.async_keywords = False

        t.report()

    f()

# Generated at 2022-06-23 15:36:59.572055
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("./test_data/test_grammar.py")

# Generated at 2022-06-23 15:37:10.581308
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g0 = Grammar()
    # symbol2number
    g0.symbol2number["a"] = 1
    g0.symbol2number["b"] = 2
    # number2symbol
    g0.number2symbol[1] = "a"
    g0.number2symbol[2] = "b"
    # dfas
    g0.dfas[1] = ([[(0, 0)], [(2, 2)]], {})
    # keywords
    g0.keywords["c"] = 3
    g0.keywords["d"] = 4
    # tokens
    g0.tokens[1] = 5
    g0.tokens[2] = 6
    # symbol2label
    g0.symbol2label["a"] = 7
    g0.symbol2label

# Generated at 2022-06-23 15:37:17.293396
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number["var1"] = 9
    g.number2symbol[9] = "var2"
    g.dfas[9] = [], {"a": 9}
    g.keywords["var3"] = 9
    g.tokens[9] = 9
    g.symbol2label["var4"] = 9
    g.labels = [(9, "var4")]
    g.states = [[(9, 9)], [(9, 9)]]
    g.start = 9

    cg = g.copy()
    assert g.symbol2number == cg.symbol2number
    assert g.number2symbol == cg.number2symbol
    assert g.dfas == cg.dfas

# Generated at 2022-06-23 15:37:20.557846
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    d = g.__getstate__()  # type: ignore
    g.loads(pickle.dumps(d, pickle.HIGHEST_PROTOCOL))

# Generated at 2022-06-23 15:37:28.019129
# Unit test for constructor of class Grammar
def test_Grammar():
    from . import pgen
    from .pgen2 import driver

    g = Grammar()
    driver.load_grammar(g, __file__)
    p = pgen.Pgen(g)

    # Successful parse
    tree = p.parse("x = 1", "exec")
    assert len(tree) == 1
    tree = p.parse("[*]", "eval")
    assert len(tree) == 2
    tree = p.parse("[*]", "single")
    assert len(tree) == 2

    # Invalid parse
    try:
        tree = p.parse("x = 1", "eval")
    except SyntaxError:
        pass
    else:
        assert 0, "expected SyntaxError"

# Generated at 2022-06-23 15:37:34.715609
# Unit test for method load of class Grammar
def test_Grammar_load():
    """
    This unit test needs a working pgen2 executable
    """
    import subprocess
    import sys

    grammar_pkl = subprocess.check_output([sys.executable, "-m", "pgen2", "-G"])
    grammar = Grammar()
    grammar.loads(grammar_pkl)


if __name__ == "__main__":
    import sys

    g = Grammar()
    g.load(sys.argv[1])
    g.report()

# Generated at 2022-06-23 15:37:46.285594
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import pickle
    from pprint import pprint

    g = Grammar()
    g.symbol2number = {'foo': 0, 'bar': 5}
    g.number2symbol = {0: 'foo', 5: 'bar'}
    g.dfas = {0: ([[(0, 1)]], {1: 1}), 1: ([[(0, 2)]], {2: 1})}
    g.keywords = {'foo': 0, 'bar': 1}
    g.tokens = {0: 0, 1: 1}
    g.symbol2label = {'foo': 0, 'bar': 1}
    g.labels = [(0, None), (1, None)]

# Generated at 2022-06-23 15:37:48.014690
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()


# Generated at 2022-06-23 15:37:56.734614
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    # Type dict is not hashable
    g1.keywords = dict([("True", True), ("False", False)])
    assert hasattr(g1, "__dict__")
    g2 = g1.copy()
    assert hasattr(g2, "__dict__")
    assert g1.keywords == g2.keywords
    # __dict__ for g2 should not be the same one as g1
    assert g1.__dict__ is not g2.__dict__

    # Type dict is not hashable
    g1.dfas = dict([("True", True), ("False", False)])
    g2 = g1.copy()
    assert g1.dfas == g2.dfas
    # __dict__ for g2 should not be the same one as g1

# Generated at 2022-06-23 15:38:04.232387
# Unit test for method report of class Grammar
def test_Grammar_report():
    import sys
    import unittest

    class TestCase(unittest.TestCase):

        def test_report(self):
            grammar = Grammar()
            grammar.report()
            self.assertEqual(1, 1)

    suite = unittest.makeSuite(TestCase)
    runner = unittest.TextTestRunner()
    runner.run(suite)

# End of test_Grammar_report

if __name__ == "__main__":
    test_Grammar_report()

# Generated at 2022-06-23 15:38:10.991163
# Unit test for method report of class Grammar
def test_Grammar_report():
    """This test checks whether Grammar.report() executes.

    It doesn't check whether the text it outputs is correct.
    """
    gram = Grammar()
    gram.report()
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO  # type: ignore

    buf = StringIO()
    gram.report(buf)  # type: ignore
    buf.seek(0)

# Generated at 2022-06-23 15:38:12.855024
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    def test_loads(pkl):
        g = Grammar()
        g.loads(pkl)
        assert g.symbol2number == {"atom": 1, "NAME": 2}
        assert g.start == 256

# Generated at 2022-06-23 15:38:16.314589
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("./Grammar.pkl")
    grammar.report()


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-23 15:38:26.021644
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import libcst.codemod
    import libcst.matchers as m
    from libcst.matchers import _common_matchers as common_matchers
    import libcst.matchers.parse_tree as pt
    from libcst.matchers.combinators import (
        CstHandlerMatcher,
        CstNodeMatcher,
        DeletedNodes,
        InsertedNodes,
        ReplacedNodes,
        WithChildren,
    )
    from libcst.matchers.generic_equality import GenericEqWrapper
    from libcst.metadata.wrapper import MetadataWrapper
    py_grammar = grammar.python_grammar_no_print_statement
    py_grammar.dump("test_grammar")
    # TODO: what about comparing the types of the individual members?


# Generated at 2022-06-23 15:38:38.327431
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    grammar = Grammar()
    source = os.path.join(os.path.dirname(__file__), "Grammar.pkl")
    with open(source, "rb") as f:
        grammar.loads(f.read())

# Generated at 2022-06-23 15:38:43.531229
# Unit test for constructor of class Grammar
def test_Grammar():
    # Just see if it's possible to construct a Grammar.  The details
    # checked here will depend on the particular grammar being used.
    # The grammar file supplied to pgen is hard-coded in
    # Lib/test/test_tokenize.py .
    g = Grammar()

# Generated at 2022-06-23 15:38:53.548949
# Unit test for constructor of class Grammar
def test_Grammar():
    # check init
    grammar = Grammar()
    assert grammar.symbol2number == {}
    assert grammar.number2symbol == {}
    assert grammar.states == []
    assert grammar.dfas == {}
    assert grammar.labels == [(0, "EMPTY")]
    assert grammar.keywords == {}
    assert grammar.tokens == {}
    assert grammar.symbol2label == {}
    assert grammar.start == 256
    assert not grammar.async_keywords

    # check load()
    filename = os.path.join(os.path.dirname(__file__), "Grammar.pickle")
    grammar = Grammar()
    grammar.load(filename)
    assert grammar

    # check copy()

# Generated at 2022-06-23 15:39:03.983107
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    LABELS = [(0, "EMPTY")]
    S2N = {}
    N2S = {}
    STATES = []
    DFAS = {}
    KEYWORDS = {}
    TOKENS = {}
    ATTRS = {
        "symbol2number": S2N,
        "number2symbol": N2S,
        "dfas": DFAS,
        "keywords": KEYWORDS,
        "tokens": TOKENS,
        "labels": LABELS,
        "states": STATES,
        "start": 256
    }
    pkl = pickle.dumps(ATTRS)
    g.loads(pkl)
    assert g == Grammar()

# Generated at 2022-06-23 15:39:14.944897
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-23 15:39:16.932597
# Unit test for method load of class Grammar
def test_Grammar_load():
    # XXX: refactor grammar loading code to make this test not read
    # from disk, and run it
    pass

# Generated at 2022-06-23 15:39:19.020065
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(__file__)

# Generated at 2022-06-23 15:39:28.059560
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.states = [[(1, 1), (2, 2)], [(3, 3), (4, 4)]]
    g.dfas: Dict[int, DFAS] = {1: ([], {}), 2: ([], {})}
    g.labels = [(0, "EMPTY"), (1, "DELETE"), (2, "DELETE"), (3, "DELETE"), (4, "DELETE")]
    g.keywords: Dict[str, int] = {}
    g.tokens: Dict[int, int] = {}
    g.symbol2label: Dict[str, int] = {}
    g.symbol2number: Dict[str, int] = {"DELETE": 1}

# Generated at 2022-06-23 15:39:37.008358
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import sys

    # Create a packer object
    gp = Grammar()

    # Assign attributes
    gp.symbol2number = {'EMPTY': 0, 'STORE': 1}
    gp.number2symbol = {0: 'EMPTY', 1: 'STORE'}
    gp.states = [[(4, 4)], [(4, 4)]]
    gp.dfas = {0: ([(4, 4)], {}), 1: ([(4, 4)], {})}
    gp.labels = [(0, None),
                 (1, 'STORE')]
    gp.keywords = {'STORE': 1}
    gp.tokens = {}
    gp.symbol2label = {'STORE': 1}
    gp.start = 256

    # Write the packed object

# Generated at 2022-06-23 15:39:44.634833
# Unit test for constructor of class Grammar
def test_Grammar():
    """A unit test for the Grammar class.

    This test is far from comprehensive, but it does test to make
    sure that the constructor at least creates the attributes that
    the parser expects to find.

    """

    g = Grammar()
    assert hasattr(g, "symbol2number")
    assert hasattr(g, "number2symbol")
    assert hasattr(g, "states")
    assert hasattr(g, "dfas")
    assert hasattr(g, "labels")
    assert hasattr(g, "keywords")
    assert hasattr(g, "tokens")
    assert hasattr(g, "start")

# Generated at 2022-06-23 15:39:53.820383
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    from . import pgen2
    g1 = pgen2._read_grammar("Grammar.txt", "Grammar.pickle")
    g2 = g1.copy()
    assert g1.symbol2number == g2.symbol2number
    assert g1.number2symbol == g2.number2symbol
    assert g1.dfas == g2.dfas
    assert g1.keywords == g2.keywords
    assert g1.tokens == g2.tokens
    assert g1.symbol2label == g2.symbol2label
    assert g1.labels == g2.labels
    assert g1.states == g2.states
    assert g1.start == g2.start
    assert g1.async_keywords == g2.async_

# Generated at 2022-06-23 15:40:06.583458
# Unit test for constructor of class Grammar
def test_Grammar():
    # test __init__()
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords == False

    # test _update()
    g = Grammar()
    d = {"foo": 3}
    g._update(d)
    assert g.foo == 3

    # test copy()
    g = Grammar()
    gg = g.copy()
    assert gg is not g