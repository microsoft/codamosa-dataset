

# Generated at 2022-06-23 15:30:14.894369
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    attr1 = {"symbol2number": {}}
    attr2 = {"number2symbol": {}}
    attr3 = {"dfas": {}}
    attr4 = {"keywords": {}}
    attr5 = {"tokens": {}}
    attr6 = {"symbol2label": {}}
    attr7 = {"labels": []}
    attr8 = {"states": []}
    attr9 = {"start": 256}
    attr10 = {"async_keywords": False}

# Generated at 2022-06-23 15:30:21.388836
# Unit test for method dump of class Grammar

# Generated at 2022-06-23 15:30:22.560653
# Unit test for constructor of class Grammar
def test_Grammar():
    grammar = Grammar()
    assert isinstance(grammar, Grammar)

# Generated at 2022-06-23 15:30:33.546225
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    # Test for copying a Grammar
    def copy_and_compare(g):
        g2 = g.copy()
        g2.symbol2number = {'abc': 67, 'bcd': 68}
        g2.number2symbol = {67: 'abc', 68: 'bcd'}
        assert g.symbol2number == {'a': 256, 'a2': 257}
        assert g.number2symbol == {256: 'a', 257: 'a2'}
        g2.keywords = {'a': 1, 'b': 2}
        assert g.keywords == {'a': 1, 'a2': 2}
        assert g.keywords != g2.keywords
        g2.tokens = {1: 2, 3: 4}
        assert g.tokens != g

# Generated at 2022-06-23 15:30:36.562704
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.start == 257

# Generated at 2022-06-23 15:30:41.608872
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    g.load("../../Parser/Grammar.pkl")
    g1 = g.copy()
    g2 = Grammar()
    g2.loads(pickle.dumps(g1))
    assert g1 == g2, "should be no change"

# Generated at 2022-06-23 15:30:51.307114
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    # type: () -> None
    class DummyGrammar(Grammar):
        pass

    g1 = DummyGrammar()  # Original grammar
    g1.symbol2number = {'a':1, 'b':2, 'c':3}  # type: Dict[str, int]
    g1.number2symbol = {1:'a', 2:'b', 3:'c'}  # type: Dict[int, str]

# Generated at 2022-06-23 15:30:53.140955
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    g.loads(pickle.dumps({"a": 1}))
    assert g.a == 1

# Generated at 2022-06-23 15:30:59.915699
# Unit test for method load of class Grammar
def test_Grammar_load():
    import grammar
    import pgen2
    import sys

    with tempfile.NamedTemporaryFile(prefix="grammar_test") as tf:
        pgen2.driver.write_grammar(grammar.grammar, tf.name)
        g = Grammar()
        g.load(tf.name)
        assert g.start == g.symbol2number["file_input"]
        assert g.symbol2label[g.number2symbol[g.start]] == 0
        assert g.keywords["False"] == 4
        assert g.tokens[token.NAME] == 2
        assert g.labels[0] == (0, "EMPTY")
        assert len(g.labels) == len(g.symbol2label) == len(g.tokens) + len(g.keywords)



# Generated at 2022-06-23 15:31:02.415010
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    filename = 'test_grammar_dump.pkl'
    grammar.dump(filename)
    grammar.load(filename)
    grammar.reports()

# Generated at 2022-06-23 15:31:14.826554
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    grammar1 = Grammar()
    grammar1.token = 1
    grammar1.tokens = 2
    grammar1.keywords = 3
    grammar1.keyword = 4
    grammar1.start = 5
    grammar1.keywords = {'async': 0}
    grammar1.async_keywords = True

    grammar2 = grammar1.copy()
    grammar2.token = 6
    grammar2.tokens = 7
    grammar2.keywords = 8
    grammar2.keyword = 9
    grammar2.start = 10
    grammar2.keywords = {'def': 0}
    grammar2.async_keywords = False

    assert grammar1.token == 1
    assert grammar1.tokens == 2
    assert grammar1.keywords == 3
    assert grammar1.keyword == 4


# Generated at 2022-06-23 15:31:21.232942
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    copy = g.copy()
    assert copy is not g
    for dict_attr in ("symbol2number", "number2symbol", "dfas", "keywords", "tokens"):
        assert getattr(copy, dict_attr) is not getattr(g, dict_attr)
    assert copy.labels is not g.labels
    assert copy.start == g.start
    assert copy.async_keywords == g.async_keywords


# Generated at 2022-06-23 15:31:32.902242
# Unit test for method report of class Grammar
def test_Grammar_report():
    from . import operator

    g = Grammar()

# Generated at 2022-06-23 15:31:44.720359
# Unit test for method load of class Grammar
def test_Grammar_load():
  # This test function is named so as to not be run by pytest suite
  # by its naming convention.

  test_grammar_text = """
# This is a test grammar file

' # The comment in the first line
'
' this is a test grammar
'

a: 'A' ;
b: 'B' ;
"""

  #
  # Create a test grammar file with the above content
  #
  import tempfile
  test_grammar_file = tempfile.NamedTemporaryFile(delete=False)
  test_grammar_file.write(test_grammar_text.encode())
  test_grammar_file.close()

  #
  # Parse the test grammar file, and obtain the grammer
  #
  from .conv import pgen
  pg = pgen.pgen()
 

# Generated at 2022-06-23 15:31:53.322766
# Unit test for method loads of class Grammar

# Generated at 2022-06-23 15:32:02.058913
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    new = Grammar()
    new.symbol2number = {'key1': 1, 'key2': 2}
    new.number2symbol = {1: 'key1', 2: 'key2'}
    new.dfas = {1: ({1: [({2: 3}, 4)]}, {1: [1, 2]}), 2: ({2: [({4: 5}, 6)]}, {2: [1, 2]})}
    new.keywords = {'key1': 1, 'key2': 2}
    new.tokens = {1: 1, 2: 2}
    new.symbol2label = {'key1': 1, 'key2': 2}
    new.labels = [({1: 1}, 'EMPTY'), ({2: 2}, 'LABELS')]

# Generated at 2022-06-23 15:32:09.382156
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys, os, tempfile
    from .pgen2 import driver
    from . import token, grammar

    # Test driver and pgen2
    g = driver.load_grammar("Grammar/Grammar")
    assert g.restarts == g.restartdfas
    assert g.dfas
    assert len(g.dfas.keys()) == len(g.startdfas)
    assert len(g.dfas) == len(g.startdfas)
    assert len(g.dfas) == len(g.labels) - 1
    assert g.keywords
    assert len(g.keywords) == len(g.keywordlabels)
    assert g.tokens
    assert len(g.tokens) == len(g.tok_name)

    # Test pickling

# Generated at 2022-06-23 15:32:20.597701
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    """
    Unit test for method loads of class Grammar
    """
    # +test+:: test_Grammar_loads
    s2n = {"type_ignore2": 256, "type_ignore": 257, "encoding_decl": 258}
    n2s = {256: "type_ignore2", 257: "type_ignore", 258: "encoding_decl"}
    labels = [(0, "EMPTY"), (token.NAME, None), (token.STRING, None)]
    states = [[(1, 1), (0, 1)]]
    dfas = {258: ([[(1, 1), (0, 1)]], {1: 1})}
    start = 258

# Generated at 2022-06-23 15:32:30.451965
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # We don't want to test all of Grammar, just loads.
    # So we mock out all the methods we aren't testing.
    class MockGrammar(Grammar):
        def dump(self, filename):
            pass
        def load(self, filename):
            pass

    g = MockGrammar()


# Generated at 2022-06-23 15:32:31.982356
# Unit test for method report of class Grammar
def test_Grammar_report():
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 15:32:38.274464
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    import tokenize
    from io import BytesIO
    from .parse import Parser
    p = Parser()
    p.setup()
    s = b'import sys'
    g = Grammar()
    g.loads(p.grammar)
    toks = tokenize.tokenize(BytesIO(s).readline)
    tree = p.parse(toks, g)
    return tree


if __name__ == "__main__":
    test_Grammar_loads()

# Generated at 2022-06-23 15:32:47.666260
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from _ast import Arg, FunctionDef, Num, parse
    from . import pygram

    pygram.init_grammar()
    g = Grammar()
    g.number2symbol = pygram.number2symbol.copy()
    g.symbol2number = pygram.symbol2number.copy()
    g.keywords = pygram.keywords.copy()
    g.tokens = pygram.tokens.copy()
    g.symbol2label = pygram.symbol2label.copy()
    g.labels = pygram.labels[:]
    g.states = pygram.states[:]
    g.dfas = pygram.dfas.copy()
    g.start = pygram.number2symbol["file_input"]

# Generated at 2022-06-23 15:32:51.668598
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, 'EMPTY')]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256


# Generated at 2022-06-23 15:33:01.130366
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {'foo': -1, 'bar': -2}
    g.number2symbol = {-1: 'foo', -2: 'bar'}
    g.dfas = {-1: -1, -2: -2, -3: -3}
    g.keywords = {'foo': -1, 'bar': -2, 'foo1': -3}
    g.tokens = {-1: -1, -2: -2, -3: -3}
    g.labels = [1, 2, 3, 4]
    g.states = [1, 2, 3, 4, 5, 6]
    g.start = -1
    g.async_keywords = True

    c = g.copy()
    assert c.sy

# Generated at 2022-06-23 15:33:06.476494
# Unit test for method report of class Grammar
def test_Grammar_report():
    from pytype.pyc import conv
    from pytype.pyc import loader
    from pytype import load_pytd
    from pytype import vm
    from tests import test_base

    # Note: This test is to make sure report of Grammar class runs.
    #       It is not to make test that the report is correct.
    #       A correct report will be a lot more work.
    path = test_base.get_data_path("data/grammar.pkl")
    pyc = conv.convert_pyc(path, loader.Loader())
    pyc.grammar.report()


test = Grammar()



# Generated at 2022-06-23 15:33:08.991981
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import sys

    os.chdir(sys.path[0])
    g = Grammar()
    g.dump("TESTGrammar.pickle")

# Generated at 2022-06-23 15:33:19.044486
# Unit test for method load of class Grammar
def test_Grammar_load():
    global Grammar
    gram1 = Grammar()
    gram1.number2symbol = {256: 'file_input', 257: 'stmt', 258: 'simple_stmt'}

# Generated at 2022-06-23 15:33:30.118299
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    """
    A Grammar can be created with the dumps() method.
    """
    g = Grammar()

# Generated at 2022-06-23 15:33:40.633776
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = dict(key=1)
    g.number2symbol = dict(key=1)
    g.dfas = dict(key=1)
    g.keywords = dict(key=1)
    g.tokens = dict(key=1)
    g.symbol2label = dict(key=1)
    g.labels = [(0, "EMPTY")]
    g.states = []
    g.start = 256
    g.async_keywords = False

    g2 = g.copy()

    # Check that the instances are not the same
    assert g2 is not g

    # Check that the dictionaries have been copied

# Generated at 2022-06-23 15:33:49.072160
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-23 15:33:49.855880
# Unit test for constructor of class Grammar
def test_Grammar():
    assert Grammar

# Unit tests for class Grammar

# Generated at 2022-06-23 15:33:50.670258
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    assert Grammar().loads(b"") is None

# Generated at 2022-06-23 15:33:57.563885
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("python_grammar")
    assert isinstance(g.start, int)
    assert isinstance(g.symbol2number, dict)
    assert isinstance(g.number2symbol, dict)
    assert isinstance(g.symbol2label, dict)
    assert isinstance(g.labels, list)
    assert isinstance(g.states, list)
    assert isinstance(g.dfas, dict)
    assert isinstance(g.keywords, dict)
    assert isinstance(g.tokens, dict)


# Test for method loads of class Grammar

# Generated at 2022-06-23 15:34:08.712789
# Unit test for method report of class Grammar
def test_Grammar_report():
    from io import StringIO
    import warnings

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=DeprecationWarning)
        g = Grammar()
        oldstdout = sys.stdout
        sys.stdout = f = StringIO()
        try:
            g.report()
        finally:
            sys.stdout = oldstdout
        s = f.getvalue()
        lines = list(filter(bool, s.splitlines()))
        assert lines[2].startswith('  ') and lines[2].endswith('[]'), lines[2]
        assert lines[3].startswith('  ') and lines[3].endswith('{}'), lines[3]
        assert lines[4] == '  256: start'

# Generated at 2022-06-23 15:34:18.797472
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g2 = g1.copy()
    assert g1.states is not g2.states, "Grammar copy failed on states"
    assert g1.dfas is not g2.dfas, "Grammar copy failed on dfas"
    assert g1.keywords is not g2.keywords, "Grammar copy failed on keywords"
    assert g1.labels is not g2.labels, "Grammar copy failed on labels"
    assert g1.tokens is not g2.tokens, "Grammar copy failed on tokens"
    assert g1.symbol2number is not g2.symbol2number, "Grammar copy failed on symbol2number"

# Generated at 2022-06-23 15:34:27.493582
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    grammar: Grammar = Grammar()
    grammar.symbol2number = {"foo":256, "bar":257}
    grammar.number2symbol = {256: "foo", 257: "bar"}
    grammar.states = [[[(0, 0)]]]
    grammar.dfas = {256: ([[(0, 0)]], {0: 0})}
    grammar.labels = [(0, None), (1, "foo")]
    grammar.keywords = {"foo": 1}
    grammar.tokens = {1: 1}
    grammar.symbol2label = {"foo": 1}
    grammar.start = 256
    assert grammar.copy() == grammar

# Generated at 2022-06-23 15:34:32.340803
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    import io
    import unittest.mock as mock
    from types import FunctionType

    class Object(object): pass
    class Class(object): pass

    f = io.BytesIO()

# Generated at 2022-06-23 15:34:42.221895
# Unit test for constructor of class Grammar
def test_Grammar():
    from pickle import loads, dumps, HIGHEST_PROTOCOL

    g1 = Grammar()
    g1.symbol2number["foo"] = 2
    g1.number2symbol[42] = "bar"
    g1.states = [[("a", "b")], [("c", "d")]]
    g1.dfas[42] = (1, {})
    g1.labels.append((43, "baz"))
    g1.start = 2
    g1.keywords["quux"] = 42
    g1.keywords["quuux"] = 43
    g1.tokens["token"] = 44
    assert g1.symbol2number["foo"] == 2
    assert g1.number2symbol[42] == "bar"

# Generated at 2022-06-23 15:34:45.253283
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    grammar = Grammar()
    grammar.start = 256
    grammar_str = pickle.dumps(grammar, pickle.HIGHEST_PROTOCOL)
    loaded_grammar = Grammar()
    loaded_grammar.loads(grammar_str)
    assert loaded_grammar.start == 256

# Generated at 2022-06-23 15:34:54.298821
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # Build temporary Grammar object and create pickle object
    g = Grammar()
    g.symbol2number = {
        "and": 256,
        "not": 257,
        "or": 258,
        "testlist_star_expr": 259,
        "testlist_star_expr_comp": 260,
        "testlist_comp": 261,
        "testlist": 262,
    }
    g.number2symbol = {
        256: "and",
        257: "not",
        258: "or",
        259: "testlist_star_expr",
        260: "testlist_star_expr_comp",
        261: "testlist_comp",
        262: "testlist",
    }

# Generated at 2022-06-23 15:35:03.139531
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.add_dfa(1, "foo")
    g.add_dfa(2, "bar")
    g.add_dfa(3, "baz")
    g.add_dfa(4, "qux")
    assert g.number2symbol[1] == "foo"
    assert g.number2symbol[3] == "baz"
    new = g.copy()
    g.add_dfa(1, "xxx")
    g.add_dfa(3, "yyy")
    assert g.number2symbol[1] == "xxx"
    assert g.number2symbol[3] == "yyy"
    assert new.number2symbol[1] == "foo"

# Generated at 2022-06-23 15:35:05.436169
# Unit test for constructor of class Grammar
def test_Grammar():
    grammar = Grammar()
    assert grammar.symbol2number == {}
    assert grammar.number2symbol == {}
    assert grammar.states == []
    assert grammar.dfas == {}
    assert grammar.labels == [(0, 'EMPTY')]
    assert grammar.keywords == {}
    assert grammar.tokens == {}
    assert grammar.symbol2label == {}
    assert grammar.start == 256


# Generated at 2022-06-23 15:35:09.969475
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    class GrammarSubclass(Grammar):
        pass
    g = GrammarSubclass()
    g.loads(pickle.dumps({'symbol2number': {}}))

if __name__ == "__main__":
    test_Grammar_loads()

# Generated at 2022-06-23 15:35:19.779417
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """Unit test for Grammar.dump.

    Modify the test values below and check that the output value
    changes as expected. This is not a complete test for Grammar.  Use
    the report() method for more thorough testing.

    """

    # setup test data
    g = Grammar()
    g.symbol2number = {')': 258, '*': 259, '+': 260, ',': 261, '-': 262, '.': 263}
    g.number2symbol = {
        258: ')',
        259: '*',
        260: '+',
        261: ',',
        262: '-',
        263: '.'
    }

# Generated at 2022-06-23 15:35:30.483036
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    grammar = Grammar()
    grammar.symbol2number["symbol"] = 1
    grammar.number2symbol[1] = "symbol"
    grammar.symbol2label["symbol"] = 2
    grammar.labels = [(0, "EMPTY"), (1, "LABEL_1")]
    grammar.start = 3
    grammar.keywords = {"keyword": 4}
    grammar.tokens = {5: 6}

# Generated at 2022-06-23 15:35:31.568749
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    print(g.start)

# Generated at 2022-06-23 15:35:32.824565
# Unit test for constructor of class Grammar
def test_Grammar():
    assert Grammar().symbol2number == {}

# Generated at 2022-06-23 15:35:42.992252
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    class SubclassGrammar(Grammar):
        def __init__(self):
            Grammar.__init__(self)

    g = SubclassGrammar()
    g.symbol2number = {"a": 1, "b": 2}
    g.number2symbol = {1: "a", 2: "b"}
    g.states = [[(1, 2)]]
    g.dfas = {256: ([[(1, 2)]], {1: 1})}
    g.labels = [(0, "EMPTY"), (1, None)]
    g.keywords = {"a": 1}
    g.tokens = {256: 1}
    g.symbol2label = {"a": 1}
    g.start = 256
    g.async_keywords = False
    bytes = pick

# Generated at 2022-06-23 15:35:49.429565
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """
    Make sure Grammar.dump() works as expected.

    """
    temp_dir = tempfile.TemporaryDirectory()
    try:
        f = os.path.join(temp_dir.name, "test_grammar.pkl")
        grammar = Grammar()

        grammar.dump(f)
    finally:
        temp_dir.cleanup()

# Generated at 2022-06-23 15:36:00.730982
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    grammar = Grammar()

# Generated at 2022-06-23 15:36:08.001895
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # type: () -> None
    """
    Unit test for method loads of class Grammar.
    """
    # Test a simple grammar
    g = Grammar()
    g.symbol2number = {"file_input": 256, "single_input": 257}
    g.number2symbol = {256: "file_input", 257: "single_input"}
    g.states = [[[[257, 1], [0, 1]]], [[[257, 1], [0, 1]]]]
    g.dfas = {
        256: [[[0, 1]], {}],
        257: [[[257, 1], [0, 1]], {}],
    }
    g.labels = [[257, None], [0, None], [257, None]]
    g.start = 256
    g.keywords = {}

# Generated at 2022-06-23 15:36:16.822064
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    # Test 1
    grm = Grammar()
    grm_cp = grm.copy()

    if not grm == grm_cp:
        print("Grammar copy test failed")
        return


    # Test 2
    grm.symbol2number["a"] = 1234
    grm.symbol2number["b"] = 666
    grm.number2symbol[1234] = "a"
    grm.number2symbol[666] = "b"

    grm1 = grm.copy()
    if not grm.symbol2number == grm1.symbol2number:
        print("Grammar copy test failed")
        return
    if not grm.number2symbol == grm1.number2symbol:
        print("Grammar copy test failed")
        return

# Generated at 2022-06-23 15:36:28.196958
# Unit test for method load of class Grammar
def test_Grammar_load():
    def _check_Grammar(g: Grammar) -> bool:
        return (
            g.symbol2number == {"a": 257, "b": 258}
            and g.number2symbol == {257: "a", 258: "b"}
            and g.states == [[(258, 0)]]
            and g.labels == [(0, "EMPTY"), (258, None)]
            and g.dfas == {257: ([[(0, 1), (258, 1)]], {258: 1}), 258: ([[(0, 0)]], {})}
            and g.start == 257
        )

    # Build the grammar tables.
    g = Grammar()
    g.symbol2number = {"a": 257, "b": 258}

# Generated at 2022-06-23 15:36:37.000575
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import unittest

    filename = "Python.tables"

    class GrammarCopyTest(unittest.TestCase):
        def setUp(self):
            self.g1 = Grammar()
            self.g1.load(filename)

        def test_copy(self):
            self.g2 = self.g1.copy()
            self.assertEqual(self.g1.symbol2number, self.g2.symbol2number)
            self.assertEqual(self.g1.number2symbol, self.g2.number2symbol)
            self.assertEqual(self.g1.dfas, self.g2.dfas)
            self.assertEqual(self.g1.keywords, self.g2.keywords)

# Generated at 2022-06-23 15:36:48.810427
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()

# Generated at 2022-06-23 15:36:59.139821
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g1.symbol2number = {'a': 1}
    g1.number2symbol = {1: 'a'}
    g1.dfas = {1: [(1, 2)], 2: [(3, 4), (4, 5)]}
    g1.keywords = {'b': 1}
    g1.tokens = {2: 1}
    g1.symbol2label = {'c': 3}
    g1.labels = [('b', 'c')]
    g1.states = [[], [], [('a', 'b')]]
    g1.start = 1

    g2 = g1.copy()

    # test g1 and g2 are different objects
    g2.symbol2number["a"] = 2

# Generated at 2022-06-23 15:37:10.093257
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    """Unit test for method loads of class Grammar"""
    grammar = Grammar()

# Generated at 2022-06-23 15:37:19.859716
# Unit test for method report of class Grammar
def test_Grammar_report():
    def _do_test_Grammar(self):
        self.symbol2number = {'foo': 0, 'bar': 1}
        self.number2symbol = {0: 'foo', 1: 'bar'}
        self.dfas = {0: ([1, 2], {3: 4})}
        self.keywords = {'and': 5}
        self.tokens = {6: 7}
        self.symbol2label = {'False': 8}
        self.labels = [
            (0, 'EMPTY'),
            (1, None),
            (2, None),
            (3, None),
            (4, None),
            (5, None),
            (6, None),
            (7, None),
            (8, None),
        ]

# Generated at 2022-06-23 15:37:26.438048
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import pickle

    grammar = Grammar()

    # before the bug fix this would fail with the message:
    # Traceback (most recent call last):
    #   File "/Users/michael/dev/python/cpython/Lib/test/test_grammar.py", line 37, in test_Grammar_copy
    #     grammar2.loads(pickle.dumps(grammar1))
    # AttributeError: 'Grammar' object has no attribute 'async_keywords'
    grammar1 = grammar.copy()
    grammar2 = grammar.copy()
    grammar2.loads(pickle.dumps(grammar1))

# Generated at 2022-06-23 15:37:37.333606
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Workaround for mypy issues:
    # https://github.com/python/mypy/issues/6420
    # https://github.com/python/mypy/issues/6456
    # If a conditional branch can propagate a late-bound type to a
    # generic type, then mypy will sometimes not consider that branch as
    # safe.
    from .pgen2 import driver

    filepath = os.path.join(os.path.dirname(__file__), "Grammar.dump.test")
    if os.path.exists(filepath):
        os.remove(filepath)
    g = driver.load_grammar(filepath)
    g.dump(filepath)


# Generated at 2022-06-23 15:37:49.533069
# Unit test for constructor of class Grammar
def test_Grammar():
    import filecmp
    import sys

    g = Grammar()
    g.dump("Grammar.pickle")
    g1 = Grammar()
    g1.load("Grammar.pickle")
    g2 = Grammar()
    g2.loads(open("Grammar.pickle", "rb").read())

    # Files should be the same
    assert filecmp.cmp("Grammar.pickle", "Grammar.pickle.test")

    # Objects should be equal
    assert g == g1
    assert g1 == g2
    assert sys.getrefcount(g) == sys.getrefcount(g1)
    assert sys.getrefcount(g1) == sys.getrefcount(g2)

    # Copy should be equal
    g3 = g.copy()
    assert g == g

# Generated at 2022-06-23 15:38:01.054823
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2 import driver
    filename = "test-data/simple.pickle"
    grammar = driver.load_grammar("python")
    grammar.dump(filename)
    new = Grammar()
    new.load(filename)
    assert grammar.symbol2number == new.symbol2number
    assert grammar.number2symbol == new.number2symbol
    assert grammar.states == new.states
    assert grammar.dfas == new.dfas
    assert grammar.labels == new.labels
    assert grammar.start == new.start
    assert grammar.keywords == new.keywords
    assert grammar.tokens == new.tokens
    assert grammar.async_keywords == new.async_keywords

# Generated at 2022-06-23 15:38:13.679263
# Unit test for method load of class Grammar
def test_Grammar_load():
    import os
    import pickle
    import tempfile
    import unittest

    class TestGrammar(Grammar):
        def __init__(self):
            super().__init__()
            self.test_data = [['test']]

    g = TestGrammar()
    with tempfile.NamedTemporaryFile() as f:
        g.dump(f.name)
        f.seek(0)
        g2 = TestGrammar()
        g2.load(f)
        g2.test_data[0][0] = "new test"

        with open(f.name, 'rb') as f1:
            pickle.load(f1)
            g3 = TestGrammar()
            g3.loads(f1.read())

    assert g.start == g2.start

# Generated at 2022-06-23 15:38:19.650363
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()

    # check that dump produces something that looks like a pickle file
    tfname = tempfile.NamedTemporaryFile(mode='wb').name
    grammar.dump(tfname)
    f = open(tfname, 'rb')
    data = f.read()
    f.close()
    assert data.startswith(b'\x80\x03cpickle.\n')

# Generated at 2022-06-23 15:38:27.841937
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import sys
    from pgen2.conv import conv
    import tempfile

    # Get the file names out of the way
    os.environ['TMPDIR'] = tempfile.gettempdir()
    path_in = os.path.join(tempfile.gettempdir(), 'grammar.in')
    path_out = os.path.join(tempfile.gettempdir(), 'grammar.out')
    path_in_py37 = os.path.join(tempfile.gettempdir(), 'grammar.py37.in')
    path_out_py37 = os.path.join(tempfile.gettempdir(), 'grammar.py37.out')

    # Generate a grammar and dump it to a file
    g = conv.gen_grammar()

# Generated at 2022-06-23 15:38:39.820795
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    from .conv import grammar2tables

    # Generate a grammar which could be compiled to a pickle file.
    import sys
    from .pgen2 import driver
    g = driver.load_grammar(sys.modules[__name__].__file__)
    tables = grammar2tables(g)

    # Generate the expected pickle file
    class TestCase(unittest.TestCase):
        def test(self):
            tables.dump("TestGrammar.pickle")
    TestCase("test").run()

    # Call the method under test
    g2 = Grammar()
    g2.load("TestGrammar.pickle")

    # Generate the expected values for the test

# Generated at 2022-06-23 15:38:45.254422
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Create an instance of Grammar
    grammar = Grammar()
    # Create a temporary file
    with tempfile.NamedTemporaryFile() as f:
        grammar.dump(f.name)
        grammar.load(f.name)


if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-23 15:38:54.573276
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from typing import Any, Dict, List
    from . import pgen2

    path = "Grammar.dump.pkl"
    g = pgen2.driver.load_grammar(str(path))

    def test_loads_dumps_equal(g: Grammar, assert_equal: Any) -> None:
        d = g.__dict__
        with tempfile.NamedTemporaryFile(
            dir=os.path.dirname(path), delete=False
        ) as f:
            pickle.dump(d, f, pickle.HIGHEST_PROTOCOL)
        with open(f.name, "rb") as f:
            d2 = pickle.load(f)
        os.remove(f.name)
        assert_equal(type(d), type(d2))

# Generated at 2022-06-23 15:39:02.565033
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    g.loads(b"cn\np1\n(dp2\nS'attr'\np3\nI1\nsS'words'\np4\n(lp5\nS'foo'\np6\naS'bar'\np7\naasS'symbols'\np8\n(lp9\nS'symbol1'\np10\nI123\nsS'symbol2'\np11\nI456\nsbasS'__version__'\np12\nL2L\ns.")  # noqa:E501

# Generated at 2022-06-23 15:39:09.837294
# Unit test for method report of class Grammar
def test_Grammar_report():
    s2n = {"A": 257, "B": 258, "C": 259}
    n2s = {257: "A", 258: "B", 259: "C"}
    labels = [(0, None), (1, "A")]
    state_list = [
        [
            [(0, 0), (1, 1), (1, 2)],
            [(0, 0), (1, 2)],
            [(0, 0)],
        ],
        [
            [(0, 0), (1, 1), (1, 2)],
            [(0, 0), (1, 2)],
            [(0, 0)],
        ],
    ]
    dfas = {257: (state_list[0], {}), 258: (state_list[1], {})}
    g = Grammar()
    g.symbol

# Generated at 2022-06-23 15:39:10.798797
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    assert hasattr(Grammar(), "dump")

# Generated at 2022-06-23 15:39:16.141804
# Unit test for method report of class Grammar
def test_Grammar_report():
    """Verify that Grammar report is callable."""
    class TestGrammar(Grammar):
        pass

    g = TestGrammar()
    g.report()


if __name__ == "__main__":
    test_Grammar_report()

# Generated at 2022-06-23 15:39:26.566086
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys, os
    from . import pgen2

    # Test with a grammar that has been compiled to pgen using the
    # command "python -m pgen2 -t expr sample-grammar.txt".

# Generated at 2022-06-23 15:39:33.128310
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import unittest

    class GrammarTestCase(unittest.TestCase):
        def setUp(self):
            self.g = Grammar()
            self.file = sys.argv[1]

        def test_load(self):
            self.g.load(self.file)
            self.assertTrue(self.g.start > 0)

    test_case = GrammarTestCase()
    test_case.setUp()
    test_case.test_load()

# Generated at 2022-06-23 15:39:38.382387
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .tokenizer import get_tokenizer
    from .grammar import generate_grammar

    g = generate_grammar(get_tokenizer(), 'Emacs')
    g.dump('Python.tokens')
    h = Grammar()
    h.load('Python.tokens')
    assert g == h

# Generated at 2022-06-23 15:39:47.314163
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen2
    from .parse import configured_grammar

    gfname = tempfile.mktemp()
    pgen2.driver.write_grammar(gfname, configured_grammar)

# Generated at 2022-06-23 15:39:48.233427
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    gr = Grammar()
    gr.copy()

# Generated at 2022-06-23 15:39:55.660003
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    def test_reload(pkl):
        grammar = Grammar()
        grammar.loads(pkl)
        g = grammar.copy()
        assert g.symbol2number == {'async': 269}
        assert g.number2symbol == {256: 'single_input', 269: 'async', 270: 'varargslist'}
        assert g.states == [[[(0, 1)], [(0, 2)], [(0, 3)]]]
        assert g.dfas == {256: ([[(0, 1)]], {1: 1}),
                          269: ([[(0, 2)]], {2: 1}),
                          270: ([[(0, 3)]], {3: 1})}

# Generated at 2022-06-23 15:40:07.129547
# Unit test for method report of class Grammar
def test_Grammar_report():
    class TestGrammar(Grammar):
        def __init__(self):
            Grammar.__init__(self)
            self.symbol2number = {'foo':1}
            self.number2symbol = {1:'foo'}
            self.states = [[]]
            self.dfas = {1: (1,{'a': 1})}
            self.labels = [(1, (1, 2))]
            self.keywords = {'bar': 1}
            self.tokens = {1 : 1}
            self.symbol2label = {'foo': 1}
            self.start = 100
            self.async_keywords = False
    tg = TestGrammar()
    tg.report()