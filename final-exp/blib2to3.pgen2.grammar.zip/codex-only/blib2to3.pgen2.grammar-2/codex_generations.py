

# Generated at 2022-06-23 15:30:10.058328
# Unit test for method load of class Grammar
def test_Grammar_load():
    class A(Grammar):
        pass
    a = A()
    a.symbol2number = {'foo': 100}
    a.dump('/tmp/foo')
    b = A()
    b.load('/tmp/foo')
    assert b.symbol2number['foo'] == 100


# Generated at 2022-06-23 15:30:20.170199
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest.mock as mock
    from pickle import HIGHEST_PROTOCOL
    from importlib import import_module

    pgen = import_module("astroid.pgen2.pgen")
    gram = pgen.load_grammar(
        str(pgen.__file__.parent / "Grammar.txt"), "Grammar", "grammar"
    )

    with mock.patch("pickle.dump") as mock_dump:
        gram.dump(mock.sentinel.fname)
        mock_dump.assert_called_once_with(
            mock.sentinel.fname, gram.__getstate__(), HIGHEST_PROTOCOL
        )


if __name__ == "__main__":
    import sys

    g = Grammar()

# Generated at 2022-06-23 15:30:28.282985
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g2 = g1.copy()
    assert g1 is not g2
    assert g1.__dict__ is not g2.__dict__
    assert g1.__dict__ == g2.__dict__

    for k, v in g1.__dict__.items():
        if isinstance(v, dict):
            assert v is not g2.__dict__[k]
            assert v == g2.__dict__[k]
        elif isinstance(v, list):
            assert v is not g2.__dict__[k]
            assert v == g2.__dict__[k]

# Generated at 2022-06-23 15:30:38.892153
# Unit test for constructor of class Grammar
def test_Grammar():
    # instantiate the class.
    grammar = Grammar()
    # test start symbol.
    assert grammar.start == 256
    # test tokens.
    assert grammar.tokens == {}
    # test keywords.
    assert grammar.keywords == {}
    # test symbol2label.
    assert grammar.symbol2label == {}
    # test labels.
    assert grammar.labels == [(0, "EMPTY")]
    # test states.
    assert grammar.states == []
    # test dfas.
    assert grammar.dfas == {}
    # test number2symbol.
    assert grammar.number2symbol == {}
    # test symbol2number.
    assert grammar.symbol2number == {}



# Generated at 2022-06-23 15:30:48.912352
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import py
    from .parse import ParserError
    from .pgen2 import conv, pgen

    grammar = Grammar()

    # Test dumping an empty Grammar object
    for path in ("grammar.dat", py.path.local("grammar.dat")):
        grammar.dump(path)
        assert path.check()
        path.remove()

    # Test writing a sample Grammar object with a file-like object
    tok_pkl = b"\x80\x03ctokenize\nTokenInfo\nq\x00(K\x03K\x03K\x04K\x05K\x06eubX\x06\x00\x00\x00ENCODINGq\x01X\x04\x00\x00\x00asciiq\x02ub."
    grammar_p

# Generated at 2022-06-23 15:30:56.827967
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    grammar = Grammar()

# Generated at 2022-06-23 15:31:08.015788
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()

# Generated at 2022-06-23 15:31:12.961188
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    import sys
    import unittest

    class TestGrammar(unittest.TestCase):
        def test_Grammar_loads(self):
            g = Grammar()
            g.load(sys.executable)

    unittest.main()

# Generated at 2022-06-23 15:31:13.532763
# Unit test for constructor of class Grammar
def test_Grammar():
    assert Grammar() is not None

# Generated at 2022-06-23 15:31:23.128515
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {'name1': 1, 'name2': 2}
    g.number2symbol = {1: 'name1', 2: 'name2'}
    g.dfas = {1: ([], {}), 2: ([], {})}
    g.keywords = {'keyword1': 3, 'keyword2': 4}
    g.tokens = {4: 5, 5: 6}
    g.symbol2label = {'label1': 7, 'label2': 8}
    g.labels = [[0, 'EMPTY'], [1, 'ONE'], [2, 'TWO'], [3, 'THREE']]

# Generated at 2022-06-23 15:31:33.737602
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import types
    import pickle

    d = pickle.dumps(Grammar())

    assert Grammar().copy() == Grammar()
    assert Grammar().copy().__class__ == Grammar()
    assert Grammar().copy().__class__.__name__ == "Grammar"

    d2 = pickle.dumps(Grammar().copy())
    assert d2 == d

    assert Grammar().__getstate__() == Grammar().__getstate__()

    for k in dir(Grammar):
        if k not in ("__dict__", "__getstate__"):
            assert k in Grammar().__getstate__()


# Generated at 2022-06-23 15:31:46.277852
# Unit test for method report of class Grammar
def test_Grammar_report():
    try:
        import io
        import sys
    except:
        return
    sys.stdout = io.StringIO()

# Generated at 2022-06-23 15:31:47.972489
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    g.report()



# Generated at 2022-06-23 15:31:51.774985
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen, conv

    pgen.parse_grammar("test.grammar", "test.out")
    conv.convert_grammar("test.out", "test.pickle")

    g = Grammar()
    g.load("test.pickle")

# Generated at 2022-06-23 15:31:59.637596
# Unit test for method report of class Grammar
def test_Grammar_report():
    from .parser import Grammar
    from .pgen2 import driver
    from .pgen2 import pgen

    print("\n" + "*" * 72)
    print(" Unit test for method test_Grammar_report of class Grammar")
    print("*" * 72)

    file_input = driver.load_grammar(pgen.grammar)
    g = Grammar()
    g.start = pgen.start
    g.symbol2number = pgen.symbol2number
    g.number2symbol = pgen.number2symbol
    g.states = pgen.states
    g.dfas = pgen.dfas
    g.labels = pgen.labels
    g.keywords = pgen.keywords
    g.tokens = pgen.tokens
   

# Generated at 2022-06-23 15:32:07.229689
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import operator
    import tokenize

    g = Grammar()

    with open(__file__, "rb") as f:
        tokens = list(tokenize.tokenize(f.readline))

    for t in tokens:
        if t[0] in (token.OP, token.NAME):
            tok = g.number2symbol.get(t[1])
            if tok is None:
                tok = t[1]
            else:
                tok = "'" + tok + "'"
        else:
            tok = repr(t[1])
        print("%-20s %-15r %s" % (
            token.tok_name.get(t[0], t[0]),
            t[1],
            tok,
        ))

# Generated at 2022-06-23 15:32:08.648762
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("grammar1.txt")

# Generated at 2022-06-23 15:32:10.801554
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    class G(Grammar):
        pass

    G().dump(__file__)


if __name__ == "__main__":
    t = Grammar()
    t.dump("Grammar.test")

# Generated at 2022-06-23 15:32:11.901643
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    assert Grammar().copy()

# Generated at 2022-06-23 15:32:17.160807
# Unit test for method report of class Grammar
def test_Grammar_report():
    import unittest

    class TestGrammar(unittest.TestCase):
        def test_report(self):
            grammar = Grammar()
            grammar.report()

    unittest.main(TestGrammar, verbosity=2, exit=False)


__all__ = ["Grammar", "opmap"]

if __name__ == "__main__":
    test_Grammar_report()

# Generated at 2022-06-23 15:32:23.098029
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.keywords = {"class": -1}
    dump_file = "Grammar_dump.pickle"
    g.dump(dump_file)
    with open(dump_file, "rb") as f:
        check = pickle.load(f)
    assert g.keywords == check["keywords"]
    os.remove(dump_file)


# Generated at 2022-06-23 15:32:26.177672
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    gr = Grammar()
    gr.number2symbol = {1: 'a'}
    gr2 = gr.copy()
    assert gr.number2symbol == gr2.number2symbol

# Generated at 2022-06-23 15:32:33.979260
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # type: () -> None
    d = {'a': 2,
         'b': 'test',
         'c': ['test'],
         'd': {'test': 2}}
    g = Grammar()
    g._update(d)

    fn = os.path.join(os.path.dirname(__file__), "tests", "test_grammar.pk1")
    try:
        os.remove(fn)
    except OSError:
        pass
    g.dump(fn)

    assert os.path.isfile(fn)

    g2 = Grammar()
    g2.load(fn)

    for key, value in d.items():
        assert getattr(g, key) == value
        assert getattr(g2, key) == value

# Generated at 2022-06-23 15:32:39.413544
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.load(__file__[:-1])
    g2 = g.copy()
    for key, value in g.symbol2number.items():
        assert g2.symbol2number[key] == value
    for key, value in g.number2symbol.items():
        assert g2.number2symbol[key] == value
    for key, value in g.dfas.items():
        assert g2.dfas[key] == value
    for key, value in g.keywords.items():
        assert g2.keywords[key] == value
    for key, value in g.tokens.items():
        assert g2.tokens[key] == value
    for key, value in g.symbol2label.items():
        assert g2.symbol2label

# Generated at 2022-06-23 15:32:48.480575
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    p = Grammar()
    p.number2symbol[1] = "ONE"
    p.symbol2number["TWO"] = 2
    p.labels = [None, "HELLO"]
    p.states = ["BAD", ["STATE"]]
    p.dfas = {1: ("DFA", "FIRST")}
    p.tokens = {3: "TOKEN"}
    p.keywords = {"FOUR": "KEYWORD"}
    p.symbol2label["SIX"] = 6
    p.start = 7
    p2 = p.copy()
    p2.number2symbol[1] = "ONE CHANGED"
    assert p.number2symbol[1] == "ONE"
    p2.symbol2number["TWO"] = 1

# Generated at 2022-06-23 15:32:51.849563
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2label == {}
    assert isinstance(g.dfas, dict)
    assert g.start == 256

test_Grammar()

if __name__ == "__main__":
    import sys
    from .pgen2 import driver

    driver.Driver(Grammar, sys.argv[1]).run()

# Generated at 2022-06-23 15:32:54.583607
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    assert hasattr(Grammar, 'dump')
    assert callable(Grammar.dump)

# Generated at 2022-06-23 15:32:56.676354
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g2 = g.copy()
    assert g is not g2
    assert g.labels is not g2.labels

# Generated at 2022-06-23 15:33:01.253566
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    class SubGrammar(Grammar):
        def __init__(self):
            super().__init__()
            self.a = 42

    g1 = SubGrammar()
    g2 = g1.copy()
    assert g2.a == 42

# Generated at 2022-06-23 15:33:06.587379
# Unit test for method load of class Grammar
def test_Grammar_load():
    class DummyGrammar(Grammar):
        def __init__(self):
            Grammar.__init__(self)
            self.foo = 42
            self.bar = "hello"
            self.foo_bar = {"spam": 23}

    dg = DummyGrammar()
    dg.dump("Dummy.pickle")
    new = Grammar()
    new.load("Dummy.pickle")
    assert new.foo == 42
    assert new.bar == "hello"
    assert new.foo_bar == {"spam": 23}
    os.unlink("Dummy.pickle")

# Generated at 2022-06-23 15:33:17.219233
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pgen2
    import os
    import tempfile
    import sys
    import pickle
    #Create grammar object and dump to pickle
    #grammar = pgen2.driver.load_grammar("Grammar/Python.gram")
    #with open("Grammar/Python.gram") as file:
    #    grammar = pgen2.parse(file)
    grammar = pgen2.convert_grammar("Grammar/Python.gram")
    tmpdir = tempfile.gettempdir()
    newdir = os.path.join(tmpdir, "env")
    os.mkdir(newdir)
    grammar.dump(os.path.join(newdir, "python_grammar.pickle"))
    #Read pickle back and verify

# Generated at 2022-06-23 15:33:23.375504
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    from .pgen2 import tokenize
    from .pgen2 import driver
    from . import parse

    def parse_string(string: Text) -> None:
        tokens = tokenize.generate_tokens(string)
        g = driver.load_grammar("Grammar/Grammar")
        parser = parse.Parser(g)
        parser.parse(tokens)

    parse_string("a = 1")  # parse a file with a known grammar


if __name__ == "__main__":
    import sys

    test_Grammar_copy()

    g = Grammar()
    g.load(sys.argv[1])
    g.report()

# Generated at 2022-06-23 15:33:34.410454
# Unit test for method load of class Grammar
def test_Grammar_load():
    import re
    import sys
    import unittest
    from parsing.pgen2 import tokenize
    from parsing.pgen2 import driver
    from parsing.pgen2 import parse
    from parsing.pgen2.convert import conv, driver

    class SampleGrammarTestCase(unittest.TestCase):
        def setUp(self) -> None:
            g = conv.parse_grammar()
            driver.save_grammar(g, "Grammar.txt", debug=True)
            self.g = conv.load_grammar("Grammar.txt", debug=True)

        def tearDown(self) -> None:
            #  If we want to keep the grammar, comment out this line
            os.remove("Grammar.txt")


# Generated at 2022-06-23 15:33:44.481209
# Unit test for method report of class Grammar
def test_Grammar_report():
    gram = Grammar()
    gram.states = [[1, 2], [3], [4]]
    gram.labels = [5, 6, 7, 8]
    gram.keywords = {'foo': 'bar'}
    gram.number2symbol = {1: 'a_string'}
    gram.start = 'start_symbol'
    gram.symbol2number = {'a_string': 1}
    gram.symbol2label = {'a_string': 8}
    gram.async_keywords = False
    gram.tokens = {1: 2, 3: 4}
    gram.dfas = {1: (1, {1: 1, 2: 1}), 3: (2, {1: 1, 2: 1})}
    gram.report()

test_Grammar_report

# Generated at 2022-06-23 15:33:51.514782
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert not g.symbol2number
    assert not g.number2symbol
    assert not g.states
    assert not g.dfas
    assert len(g.labels) == 1
    assert g.labels[0][0] == 0
    assert g.labels[0][1] == "EMPTY"
    assert not g.keywords
    assert not g.tokens
    assert not g.symbol2label
    assert g.start == 256


# Generated at 2022-06-23 15:33:57.563174
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    import pickle
    pkl = b"\x80\x03cdecimal\nDecimal\nq\x00)\x81q\x01."
    try:
        pickle.loads(pkl, encoding="ascii")
    except UnicodeDecodeError as err:
        # _codecs.charmap_decode() raises UnicodeDecodeError on invalid bytes
        assert str(err) == "'charmap' codec can't decode byte 0x9d in position 11: character maps to <undefined>"
        pass
    pickle.loads(pkl)

# Generated at 2022-06-23 15:34:08.714812
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    test_grammar = Grammar()
    test_grammar.symbol2number = {"a": 1, "b": 2, "c": 3}
    test_grammar.number2symbol = {1: "a", 2: "b", 3: "c"}
    test_grammar.states = [[[(1, 2)], [(3, 4)]], [[(5, 6), (7, 8)]]]
    test_grammar.dfas = {1: ([[(1, 2)], [(3, 4)]], {1: 100, 2: 200, 3: 300}), 2: ([[(5, 6), (7, 8)]], {4: 400})}
    test_grammar.labels = [(1, "a"), (2, "b"), (3, "c")]
    test_grammar.key

# Generated at 2022-06-23 15:34:15.364711
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    gram = Grammar()
    old_start = gram.start
    old_keywords = gram.keywords

# Generated at 2022-06-23 15:34:23.628323
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io
    from pprint import pprint
    from unittest.mock import patch

    symbol2number = {"'a'": 257, "'b'": 258, "'c'": 259}
    number2symbol = {257: "'a'", 258: "'b'", 259: "'c'"}
    states = [[], []]
    dfas = {257: ([[(0, 0), (1, 1)]], {1: 1}), 258: ([[(0, 0), (1, 1)]], {1: 1})}
    labels = [(0, "EMPTY"), (257, "'a'"), (258, "'b'")]
    keywords = {"'a'": 257, "'b'": 258}
    tokens = {257: 257, 258: 258}

# Generated at 2022-06-23 15:34:24.670195
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g is not None

# Generated at 2022-06-23 15:34:34.976418
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-23 15:34:43.184685
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number['symbol1'] = 1
    g.symbol2number['symbol2'] = 2
    g.number2symbol[1] = "symbol 1"
    g.number2symbol[2] = "symbol 2"
    g.dfas[1] = ([], {})
    g.dfas[2] = ([], {})
    g.keywords['keyword 1'] = 1
    g.keywords['keyword 2'] = 2
    g.tokens[1] = "token 1"
    g.tokens[2] = "token 2"
    g.symbol2label['symbol 1'] = 1
    g.symbol2label['symbol 2'] = 2

# Generated at 2022-06-23 15:34:51.911056
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    grammar_class = Grammar()

# Generated at 2022-06-23 15:35:02.117905
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {'a' : 100}
    g.number2symbol = {100 : 'a'}
    g.dfas = {100 : ([0], {100:1})}
    g.keywords = {'a': 1}
    g.tokens = {100: 1}
    g.symbol2label = {'a': 1}
    g.labels = [(0, 'EMPTY')]
    g.states = [[(0, 0)]]
    g.start = 256
    g.async_keywords = True

    g2 = g.copy()
    assert g.number2symbol == g2.number2symbol
    assert g.symbol2number == g2.symbol2number
    assert g.dfas == g2.df

# Generated at 2022-06-23 15:35:04.071851
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    pass
    # grammar = Grammar()
    # filename = None
    # grammar.dump(filename)


# Generated at 2022-06-23 15:35:05.098704
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()

# Generated at 2022-06-23 15:35:15.338177
# Unit test for method load of class Grammar
def test_Grammar_load():
    assert hasattr(Grammar(), "load")
    assert hasattr(Grammar(), "loads")
    assert hasattr(Grammar(), "symbol2number")
    assert hasattr(Grammar(), "symbol2label")
    assert hasattr(Grammar(), "number2symbol")
    assert hasattr(Grammar(), "states")
    assert hasattr(Grammar(), "dfas")
    assert hasattr(Grammar(), "labels")
    assert hasattr(Grammar(), "start")
    assert hasattr(Grammar(), "keywords")
    assert hasattr(Grammar(), "tokens")



# Generated at 2022-06-23 15:35:26.210781
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import tokenize

    g = Grammar()
    g.load(tokenize.__file__)
    assert g.start == 256
    assert g.symbol2number["file_input"] == 258
    assert g.number2symbol[258] == "file_input"
    assert isinstance(g.dfas, dict)
    assert isinstance(g.dfas[258], tuple)
    assert len(g.dfas[258]) == 2
    assert len(g.dfas[258][0]) == 2
    assert len(g.dfas[258][0][0]) == 2
    assert len(g.dfas[258][0][1]) == 2
    assert isinstance(g.dfas[258][0][0][0], tuple)

# Generated at 2022-06-23 15:35:33.633153
# Unit test for method report of class Grammar
def test_Grammar_report():
    from .pgen2 import driver
    from io import StringIO
    from . import tokenize
    import unittest

    import sys
    # Get stdout to be a text stream to make the test work on Python 3 on Windows.
    sys.stdout = sys.stdout.detach()

    class GrammarTestCase(unittest.TestCase):

        def test_method_report(self):
            with tempfile.NamedTemporaryFile() as grammar_file:
                driver.generate_grammar(grammar_file)
                grammar_file.flush()
                grammar = Grammar()
                grammar.load(grammar_file)

            test_stream = StringIO()
            old_stdout = sys.stdout
            sys.stdout = test_stream
            grammar.report()
            sys.stdout = old_std

# Generated at 2022-06-23 15:35:35.290557
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    assert g.report() is None

# Generated at 2022-06-23 15:35:39.680398
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords == False


# Generated at 2022-06-23 15:35:43.028870
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert [] == g.states
    assert {} == g.dfas
    assert [] == g.labels
    assert {} == g.keywords
    assert {} == g.tokens
    assert {} == g.symbol2label
    assert 256 == g.start

# Generated at 2022-06-23 15:35:54.523508
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Unit test for Grammar.load()."""

    G = Grammar()
    G.number2symbol = {256: "single_input", 257: "file_input"}
    G.symbol2number = {"single_input": 256, "file_input": 257}
    G.tokens = {256: 1, 257: 2, 258: 3, 259: 4, 260: 5}
    G.start = 256
    G.keywords = {}
    G.labels = [(1, "ENCODING"), (2, "NEWLINE"), (3, "INDENT"), (4, "DEDENT"), (5, "ENDMARKER")]
    G.states = [[(2, 1), (1, 2)], [(4, 3), (5, 4), (0, 5)]]


# Generated at 2022-06-23 15:36:03.850764
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g1.states.append(1)
    g1.dfas[0] = ((1, 2), {1: 1})
    g1.labels.append(1)
    g2 = g1.copy()
    assert g2.states == [(1, 2)]
    assert g2.dfas == {0: ((1, 2), {1: 1})}
    assert g2.labels == [1]

if __name__ == "__main__":
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-23 15:36:04.919809
# Unit test for constructor of class Grammar
def test_Grammar():
    assert Grammar()



# Generated at 2022-06-23 15:36:11.552646
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import driver as pgen
    from .pgen2 import graminit

    grammar_lines = pgen.parse_grammar(graminit.grammar)
    g = Grammar()
    g.start = 512
    g.symbol2number = {
        "foo": 1024,
        "bar": 1025,
    }
    g.number2symbol = {
        1024: "foo",
        1025: "bar",
    }
    g.states = [
        [],
        [(0, 1)],
    ]
    g.dfas = {
        1024: (g.states[0], {}),
        1025: (g.states[1], {}),
    }

# Generated at 2022-06-23 15:36:16.507344
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    test_fname = "test_grammar.pickle"
    try:
        os.remove(test_fname)
    except FileNotFoundError:
        pass

    g.dumpex(test_fname)
    assert os.path.isfile(test_fname), "expected pickle file"
    os.remove(test_fname)

if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-23 15:36:27.994773
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    from importlib.util import spec_from_loader, module_from_spec
    from .conv import convert_grammar

    class Loader:
        def get_code(self, name: str) -> bytes:
            g = convert_grammar(name)
            g.dump(name + ".test")
            filename = name + ".test"
            with open(filename, "rb") as f:
                return f.read()

    spec = spec_from_loader(None, Loader(), origin="test_Grammar_loads")
    mod = module_from_spec(spec)
    spec.loader.exec_module(mod)

    filename = "test_Grammar_loads_grammar.test"

    with open(filename, "rb") as f:
        test_bytes = f.read()
    os.remove(filename)

# Generated at 2022-06-23 15:36:34.124997
# Unit test for method report of class Grammar
def test_Grammar_report():
    grammar = Grammar()
    grammar.symbol2number = {'foo': 0}
    grammar.number2symbol = {0: 'foo'}
    grammar.states = []
    grammar.dfas = {}
    grammar.labels = [(0, 'EMPTY')]
    grammar.keywords = {'foo': 1}
    grammar.tokens = {0: 1}
    grammar.symbol2label = {'foo': 1}
    grammar.start = 256
    grammar.report()

# Generated at 2022-06-23 15:36:36.533960
# Unit test for method report of class Grammar
def test_Grammar_report():
    file = os.path.join(os.path.dirname(__file__), "Grammar.dump")
    g = Grammar()
    g.load(file)
    g.report()

# Generated at 2022-06-23 15:36:48.726280
# Unit test for method report of class Grammar
def test_Grammar_report():
    """This test checks whether the report method of class Grammar works
    properly.
    """
    g = Grammar()
    with tempfile.TemporaryDirectory() as tmpdirname:
        # write a pickle file
        dump_file = tmpdirname + "/" + "dummy" + ".pickle"
        g.dump(dump_file)
        # check whether report produces the same output as the dumped
        # data
        import pickle
        g2 = Grammar()
        with open(dump_file, "rb") as f:
            d = pickle.load(f)
        g2._update(d)
        assert g2.symbol2number == g.symbol2number
        assert g2.number2symbol == g.number2symbol
        assert g2.states == g.states
        assert g.df

# Generated at 2022-06-23 15:36:59.065852
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    grammar = Grammar()
    grammar.symbol2number.update({"1": 1, "2": 2})
    grammar.number2symbol.update({1: "1", 2: "2"})
    grammar.symbol2label.update({"1": 1, "2": 2})
    grammar.dfas.update({1: 1, 2: 2})
    grammar.labels.extend([(1, "1"), (2, "2")])
    grammar.states.extend([[(1, 1)], [(2, 2)]])
    grammar.keywords.update({"1": 1, "2": 2})
    grammar.tokens.update({1: 1, 2: 2})
    grammar.start = 1
    grammar.async_keywords = True
    grammar_back = grammar.copy()


# Generated at 2022-06-23 15:37:09.951118
# Unit test for method load of class Grammar
def test_Grammar_load():
    import io
    import pickle

    class MyGrammar(Grammar): pass

    f = io.StringIO('''\
    .             .
    .             .
    .             .
    ''')

    f.name = 'testfile'
    g = MyGrammar()
    g.load(f)
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.start == 256
    assert g.symbol2label == {}


# Generated at 2022-06-23 15:37:12.742473
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    g.dump(tempfile.mktemp())
    g.dump(tempfile.mktemp())
    g.dump(tempfile.mktemp())
    g.dump(tempfile.mktemp())

# Generated at 2022-06-23 15:37:22.295294
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    def check(tbl):
        '''
        tbl must be int or list or tuple
        '''
        if isinstance(tbl, int):
            return

        '''
        tbl is list or tuple
        '''
        assert len(tbl) >= 1, "tbl is empty"
        assert isinstance(tbl[0], int), "tbl[0] must be int"

        for i in tbl[1:]:
            if isinstance(i, tuple) or isinstance(i, list):
                assert len(i) == 2, "%s must have 2 elements" % str(i)
            elif isinstance(i, int):
                pass
            else:
                raise AssertionError("%s must be int or tuple" % str(i))
            check(i)

    g = Grammar()

# Generated at 2022-06-23 15:37:30.362713
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-23 15:37:36.235868
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.number2symbol = {257: 'pair2', 258: 'expr'}

# Generated at 2022-06-23 15:37:39.702833
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("tests/dump.pkl")


if __name__ == "__main__":
    import sys
    from .pgen import driver

    driver.main(sys.argv)

# Generated at 2022-06-23 15:37:51.320263
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-23 15:38:02.008308
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """
    def dump(self, filename: Path) -> None
    """
    from .pgen2 import tokenize

    num2name = token.tok_name
    gram = Grammar()

    def get_symbol(name: str) -> int:
        return gram.symbol2number.setdefault(name, len(gram.symbol2number) + 256)

    def get_label(label: Label) -> int:
        return gram.labels.index(label)

    def get_symbol_label(name: Text) -> int:
        key = (name,)
        return gram.symbol2label.setdefault(key, len(gram.labels))

    def get_keyword_label(kwd: Text) -> int:
        key = (kwd,)
        return gram.symbol2label.setdefault

# Generated at 2022-06-23 15:38:14.474128
# Unit test for method load of class Grammar
def test_Grammar_load():
    import io
    g = Grammar()
    g.start = 2
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.labels = [(0, 'EMPTY'), (1, 'foo'), (2, 'bar')]
    g.keywords = {'foo': 1, 'bar': 2}
    g.tokens = {1: 1, 2: 2}
    g.symbol2label = {'foo': 1, 'bar': 2}
    g.states = [[(0, 0)]]

# Generated at 2022-06-23 15:38:16.233410
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    gram = Grammar()
    gram.dump(os.path.join(os.path.dirname(__file__), "Grammar.pickle"))


if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-23 15:38:20.525127
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle

    p = pickle.dumps({
        "a": "b",
        "c": "d",
    })
    grammar = Grammar()
    grammar.loads(p)
    assert grammar.a == "b"
    assert grammar.c == "d"

# Generated at 2022-06-23 15:38:28.251248
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import json
    import subprocess
    import sys
    import _ast

    # Note that Grammar.dump() and Grammar.load() are two methods
    # for serializing and deserializing grammar tables.
    #
    # Grammar.dump() generates a pickle file, and Grammar.load()
    # reads it.  The pickle format is specific to Python's version
    # and platform.  In contrast, Grammar.dumps() and Grammar.loads()
    # generate and read JSON files, which are more portable.

    # Python's version and platform information
    version = sys.version
    platform = sys.platform
    # Use the latest version of Python3 to run tests,
    # because a pickle file written by an older version of Python3
    # cannot be read by a newer version of Python3.
    # E.g.,

# Generated at 2022-06-23 15:38:29.253636
# Unit test for constructor of class Grammar
def test_Grammar():
    grammar = Grammar()
    assert grammar is not None

# Generated at 2022-06-23 15:38:41.518676
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()

# Generated at 2022-06-23 15:38:51.144185
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    grammar = Grammar()
    grammar.symbol2number = {"a": 1}
    grammar.number2symbol = {"a": 1}
    grammar.dfas = {2: [3, 4]}
    grammar.keywords = {"a": 5}
    grammar.tokens = {6: 7}
    grammar.symbol2label = {"b": 8}
    grammar.labels = [(9, "EMPTY")]
    grammar.states = [10]
    grammar.start = 11
    grammar.async_keywords = True
    grammar_copy = grammar.copy()
    assert grammar_copy.symbol2number == grammar.symbol2number
    assert grammar_copy.number2symbol == grammar.number2symbol
    assert grammar_copy.dfas == grammar.dfas
    assert grammar_copy.keywords

# Generated at 2022-06-23 15:38:59.345284
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g1.symbol2number = {"a": 1, "b": 2}
    g1.number2symbol = {1: "a", 2: "b"}
    g1.dfas = {1: ([[(2, 1), (3, 2)]], {"b": 1}), 2: ([[(3, 2)]], {"c": 1})}
    g1.keywords = {"a": 1, "b": 2}
    g1.tokens = {1: 1, 2: 2}
    g1.symbol2label = {"a": 1, "b": 2}
    g1.labels = [(1, "a"), (2, "b")]
    g1.states = [[[(1, 0), (3, 1)]], [[(1, 1)]]]

# Generated at 2022-06-23 15:39:05.003885
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys


# Generated at 2022-06-23 15:39:09.750744
# Unit test for method load of class Grammar
def test_Grammar_load():
    with open("Grammar/Grammar.pickle", "rb") as f:
        g = Grammar()
        g.load(f)
        assert isinstance(g.states, list)
    return g

# Generated at 2022-06-23 15:39:10.757850
# Unit test for method report of class Grammar
def test_Grammar_report():
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 15:39:18.508929
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    g.symbol2number = {'start': 256}
    g.number2symbol = {256: 'start'}
    g.states = []
    g.dfas = {}
    g.labels = [(0, 'EMPTY')]
    g.keywords = {}
    g.tokens = {}
    g.symbol2label = {}
    g.start = 256
    assert g is not None

# Generated at 2022-06-23 15:39:20.040690
# Unit test for constructor of class Grammar
def test_Grammar():
    assert opmap["+"] == token.PLUS
    assert opmap["="] == token.EQUAL


if __name__ == "__main__":
    test_Grammar()

# Generated at 2022-06-23 15:39:29.634685
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    g.loads(b"\x80\x03cn_spacy\nGrammar\nq\x00)\x81q\x01}q\x02(U\nsymbol2numbq\x03h\x01U\nnumber2symbq\x04h\x02U\x06statesq\x05]."
              b"U\x04dfasq\x06}U\x06labelsq\x07]q\x08(U\x05startq\tU\x07keywordq\n}U\x06tokensq\x0bh\x03u.",)

# Generated at 2022-06-23 15:39:41.737311
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-23 15:39:52.761930
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")
    assert g.symbol2number['atom'] == 261
    assert g.symbol2number['return_stmt'] == 392
    assert g.symbol2number['atom_expr'] == 262
    assert g.symbol2number['simple_stmt'] == 390
    assert g.symbol2number['del_stmt'] == 386
    assert g.symbol2number['testlist'] == 267
    assert g.symbol2number['decorators'] == 271
    assert g.symbol2number['single_input'] == 384
    assert g.symbol2number['eval_input'] == 383
    assert g.symbol2number['file_input'] == 382
    assert g.symbol2number['pass_stmt'] == 391
   

# Generated at 2022-06-23 15:40:05.357632
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .conv import convert

    g = Grammar()
    convert(g, "Python.asdl", "Python/Python-ast.txt")
    g.dump("Grammar.pickle")
    g2 = Grammar()
    g2.load("Grammar.pickle")
    os.remove("Grammar.pickle")
    assert g.number2symbol == g2.number2symbol
    assert g.symbol2number == g2.symbol2number
    assert g.states == g2.states
    assert g.dfas == g2.dfas


if __name__ == "__main__":
    import sys

    if len(sys.argv) == 2:
        g = Grammar()
        g.load(sys.argv[1])
        g.report()