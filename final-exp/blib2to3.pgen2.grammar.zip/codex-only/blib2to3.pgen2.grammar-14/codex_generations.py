

# Generated at 2022-06-23 15:30:15.221839
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-23 15:30:26.525970
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    s2n = {"a":1}
    n2s = {1:"a"}
    dfas = {1: (1, 1)}
    keywords = {"b": 1}
    token = {2: 1}
    label = [(1, 1)]
    state = [(1, 1)]
    symbol2label = {"a": 1}
    g = Grammar()
    g.symbol2number = s2n
    g.number2symbol = n2s
    g.dfas = dfas
    g.keywords = keywords
    g.tokens = token
    g.labels = label
    g.states = state
    g.symbol2label = symbol2label
    assert g.start == 256
    g.start = 10
    assert g.start == 10

# Generated at 2022-06-23 15:30:32.941108
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256


# Generated at 2022-06-23 15:30:33.738674
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()

# Generated at 2022-06-23 15:30:41.456856
# Unit test for constructor of class Grammar
def test_Grammar():
    nt = Grammar()
    assert nt.symbol2number == {}
    assert nt.number2symbol == {}
    assert nt.states == []
    assert nt.dfas == {}
    assert nt.labels == [(0, "EMPTY")]
    assert nt.keywords == {}
    assert nt.tokens == {}
    assert nt.symbol2label == {}
    assert nt.start == 256
    assert nt.async_keywords is False

# Generated at 2022-06-23 15:30:51.264402
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-23 15:30:55.300464
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    from . import pgen

    file = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "../Lib/random.txt"
    )

    g = pgen.generate_grammar(file, "Grammar")
    b = pickle.dumps(g.__getstate__(), protocol=-1)
    g.loads(b)
    b = pickle.dumps(g.__getstate__(), protocol=-1)
    assert b == g.dumps(), "serialization of grammar seems to be broken"
    assert g is not None

# Generated at 2022-06-23 15:31:01.978061
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    test_grammar = Grammar()

# Generated at 2022-06-23 15:31:14.150111
# Unit test for method report of class Grammar
def test_Grammar_report():
    grammar = Grammar()
    # class Grammar's __init__ method is called
    grammar.symbol2number = {'if': 1, 'else': 2}
    grammar.number2symbol = {1: 'if', 2: 'else'}
    grammar.states = [
        [
            [(1, 2), (2, 3), (3, 0)],
            [(1, 4), (3, 0)]
        ]
    ]
    grammar.dfas = {1: ([0, 1], {1: 1, 2: 1, 3: 1}),
                    2: ([0], {2: 1})}
    grammar.labels = [(1, 'if'),
                      (2, 'else'),
                      (3, None)]
    grammar.keywords = {'if': 1, 'else': 2}
    grammar.t

# Generated at 2022-06-23 15:31:23.500092
# Unit test for method report of class Grammar

# Generated at 2022-06-23 15:31:34.040548
# Unit test for method load of class Grammar
def test_Grammar_load():
    #from .pgen2 import tokenize

    # Create an empty file
    with tempfile.NamedTemporaryFile() as f:
        filename = f.name
    assert os.stat(filename).st_size == 0

    # Create grammar tables and dump them to a file
    g = Grammar()
    g.dump(filename)

    # Load grammar tables from the file
    h = Grammar()
    h.load(filename)

    # Tokenize something
    #f = open('/tmp/foo.py', 'rb')
    #t = tokenize.generate_tokens(f.readline)
    #list(t)

    # Tokenize something
    #f = open('/tmp/foo.py', 'rb')
    #t = tokenize.generate_tokens(f.readline)
   

# Generated at 2022-06-23 15:31:46.414183
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.start = 256
    g.symbol2number = {'test_number': 256}
    g.number2symbol = {256: 'test_number'}
    g.states = []
    g.dfas = {256: ([[(1, 2), (3, 3), (2, 4)], [(1, 5), (2, 5), (3, 5)], [(0, 3)],
               [(0, 4)], [(0, 5)]],
              {1: 1, 2: 1, 3: 1})}
    g.keywords = {'test_keyword': 3}
    g.tokens = {256: 1}

# Generated at 2022-06-23 15:31:55.014403
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    assert g.number2symbol == {}

    # make sure this doesn't fail
    g.loads(b"\x80\x04\x95\x0b\x00\x00\x00number2symbolq\x00}\x94."),

    assert g.number2symbol == {}
    g.loads(b"\x80\x04\x95\x0b\x00\x00\x00number2symbolq\x00}q\x01(U\x04testq\x02K\x00K\x01\x86e.")
    assert g.number2symbol == {"test": 1}


# Generated at 2022-06-23 15:31:57.086920
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("./data/Grammar.txt")

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-23 15:32:01.367947
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g2 = g1.copy()
    # Both should be instances of Grammar
    assert isinstance(g1, Grammar)
    assert isinstance(g2, Grammar)
    # Original and copy should be different
    assert g1 is not g2
    # Original should be unchanged
    assert g1.states == []
    g1.states = ["something", "else"]
    assert g1.states == ["something", "else"]
    assert g2.states == []

# Generated at 2022-06-23 15:32:06.259679
# Unit test for method report of class Grammar
def test_Grammar_report():
    # The following code is an adaption of the method Grammar.report() of the
    # grammar.py module. We use this function to implicitly also test that
    # method.
    grammar = Grammar()
    table = ("symbol2number", "number2symbol", "labels", "keywords", "tokens")
    for t in table:
        print(t)
        print(getattr(grammar, t))
    print("start", grammar.start)

# Generated at 2022-06-23 15:32:17.488643
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    class TestGrammar(Grammar):
        def __init__(self):
            super().__init__()
            self.symbol2number = {'test': 1, 'symbol2number': 2}
            self.number2symbol = {1: 'one', 2: 'two'}
            self.states = [DFA]
            self.dfas = {1: DFAS}
            self.labels = [Label]
            self.keywords = {'keyword': 1}
            self.tokens = {1: 1}
            self.symbol2label = {'symbol': 1}
            self.start = 256

    test_grammar = TestGrammar()

# Generated at 2022-06-23 15:32:27.897005
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    class TestGrammar(Grammar):
        pass

    g = TestGrammar()
    g.symbol2number = {'test': 0}
    g.number2symbol = {0: 'test'}
    g.states = [1]
    g.dfas = {0: (1, 2)}
    g.labels = [(0, 'test')]
    g.keywords = {'test': 0}
    g.tokens = {0: 0}
    g.symbol2label = {'test': 0}
    g.start = 256
    g.async_keywords = False

    with tempfile.NamedTemporaryFile() as f:
        g.dump(f.name)

# Generated at 2022-06-23 15:32:29.477131
# Unit test for method report of class Grammar
def test_Grammar_report():
    G = Grammar()
    assert "symbol2number" in G.report()

# Generated at 2022-06-23 15:32:36.532073
# Unit test for constructor of class Grammar
def test_Grammar():
    x = Grammar()
    x.symbol2number = {"(": 256, "x": 257, ")": 258}
    x.number2symbol = {256: "(", 257: "x", 258: ")"}
    x.states = [[(257, 258)], [(0, 1)]]
    x.dfas = {256: (x.states[0], {40: 1}), 257: (x.states[1], {41: 1})}
    x.labels = [Label(0, "EMPTY"), Label(257, None), Label(258, None)]
    x.keywords = {}
    x.tokens = {}
    x.symbol2label = {}
    x.start = 256
    x.async_keywords = False
    y = x.copy()
    assert x.symbol

# Generated at 2022-06-23 15:32:41.443384
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import driver
    from . import util

    def _make_grammar():
        filename = util.grammar_path
        driver.generate_grammar(filename)

    def _check_grammar():
        g = Grammar()
        g.load(util.pickle_path)

    _make_grammar()
    _check_grammar()
    _check_grammar()

# Generated at 2022-06-23 15:32:49.919302
# Unit test for method load of class Grammar
def test_Grammar_load():
    def test_loads_py37_3rd_party():
        from . import py37_grammar as py37

        grammar = Grammar()
        pkl = py37.pickle_grammar_cache_py37()
        grammar.loads(pkl)
        # it should fail on an older Python
        grammar.dump("./pickle_grammar_cache_py37_3rd_party")

    def test_load_py37_3rd_party():
        grammar = Grammar()
        grammar.load("./pickle_grammar_cache_py37_3rd_party")
        grammar.report()

    test_loads_py37_3rd_party()
    test_load_py37_3rd_party()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-23 15:32:55.964397
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.dfas = {'s': ({0: [1, 2], 1: [3, 4], 2: [5, 6]}, {0: 7}), 't': ({0: [7, 8], 1: [9, 10], 2: [11, 12]}, {0: 7})}
    g.states = [[(1, 2)], [(3, 4)], [(5, 6)], [(7, 8)], [(9, 10)], [(11, 12)]]
    g.start = 456
    g.symbol2label = {'func': 13, 'p': 24, 'c': 35, 'b': 46, 'a': 57}
    g.symbol2number = {'y': 8, 'x': 9, 'z': 10}

# Generated at 2022-06-23 15:33:03.198587
# Unit test for constructor of class Grammar
def test_Grammar():
    """Test for constructor of class Grammar."""
    gr = Grammar()
    assert gr.symbol2number == {}
    assert gr.number2symbol == {}
    assert gr.states == []
    assert gr.dfas == {}
    assert gr.labels == [(0, "EMPTY")]
    assert gr.keywords == {}
    assert gr.tokens == {}
    assert gr.symbol2label == {}
    assert gr.start == 256
    assert gr.async_keywords == False


# Generated at 2022-06-23 15:33:09.980878
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # pylint: disable=missing-module-docstring
    # pylint: disable=missing-class-docstring
    # pylint: disable=missing-function-docstring
    class _Grammar(Grammar):
        def __init__(self) -> None:
            Grammar.__init__(self)  # type: ignore
            self.symbol2number = {
                "name": 1,
                "expr": 2,
            }
            self.number2symbol = {
                1: "name",
                2: "expr",
            }
            self.states = [[(1, 2), (2, 3)]]

# Generated at 2022-06-23 15:33:12.159516
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    assert Grammar.dump.__code__.co_argcount == 2

# Generated at 2022-06-23 15:33:23.236284
# Unit test for method load of class Grammar
def test_Grammar_load():

    grammar = Grammar()

    # On-disk parsetab
    dst = os.path.join(os.path.dirname(__file__), "parsetab")
    if os.path.exists(dst):
        grammar.load(dst)
    else:
        # Embedded parsetab
        from . import parsetab

        grammar.loads(parsetab.pkl)


# Generated at 2022-06-23 15:33:33.997689
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-23 15:33:44.214794
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle

    g = Grammar()
    g.symbol2number = {"foo": 257}
    g.number2symbol = {257: "foo"}
    g.states = [None]
    g.dfas = {257: ([[(0, 1)]], {1: 257})}
    g.labels = [(0, "foo")]
    g.keywords = {"foo": 1}
    g.symbol2label = {"foo": 1}
    g.start = 257

    g.dump(__file__ + ".dump")
    with open(__file__ + ".dump", "rb") as f:
        d = pickle.load(f)
    assert d["symbol2number"] == {"foo": 257}
    assert d["number2symbol"] == {257: "foo"}
    assert d

# Generated at 2022-06-23 15:33:50.392910
# Unit test for method report of class Grammar
def test_Grammar_report():
    from unittest import mock
    from . import parse_pickle

    with mock.patch.object(parse_pickle, "parse_grammar") as mock_parse_grammar:
        mock_parse_grammar.return_value = Grammar()

        pkl = parse_pickle.load_grammar(3, "path/to/blah.pkl")
        pkl.dump()

# Generated at 2022-06-23 15:33:52.126054
# Unit test for method report of class Grammar
def test_Grammar_report():
    # Test case checks if there are no crashing or exceptions in the report
    g = Grammar()
    g.report()

# Generated at 2022-06-23 15:33:58.059428
# Unit test for method load of class Grammar
def test_Grammar_load():
    a = Grammar()
    assert a.symbol2number == {}
    assert a.number2symbol == {}
    assert a.states == []
    assert a.dfas == {}
    assert a.labels == [(0, "EMPTY")]
    assert a.keywords == {}
    assert a.tokens == {}
    assert a.symbol2label == {}
    assert a.start == 256
    assert a.async_keywords == False



# Generated at 2022-06-23 15:33:59.578704
# Unit test for constructor of class Grammar
def test_Grammar():
    gr = Grammar()

# Generated at 2022-06-23 15:34:09.703399
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    gram = Grammar()
    gram.symbol2number = {"a": 1, "b": 2, "c": 3}
    gram.number2symbol = {"1": "a", "2": "b", "3": "c"}
    gram.dfas = {1: ([[(1, 2), (2, 2)], [(3, 4), (4, 4)]], {"5": 5}), 2: ([[(1, 2)]], {"5": 5})}
    gram.keywords = {"a": 1, "b": 2}
    gram.tokens = {1: 2, 3: 4}
    gram.symbol2label = {"a": 1, "b": 2}
    gram.labels = [(1, 2), (3, 4)]

# Generated at 2022-06-23 15:34:19.639926
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import grammar
    from . import symbol

    g = grammar.Grammar()
    g.symbol2number = {"foo": 1}
    g.number2symbol = {0: "start"}
    g.keywords = {"blah": 2}
    g.tokens = {1: 3}
    g.symbol2label = {"bar": 1}
    g.states = [[[(1, 2)], [(0, 1)]]]
    g.dfas = {1: ([[(0, 1), (1, 2)]], {3: 4})}
    g.labels = [(1, None), (2, "blah")]
    g.start = 0
    g.async_keywords = False
    g.dump(__file__ + ".dump")


# Generated at 2022-06-23 15:34:29.993945
# Unit test for method loads of class Grammar

# Generated at 2022-06-23 15:34:39.371103
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io
    import unittest

    from . import pgen2

    class Grammar_reportTestCase(unittest.TestCase):
        def test_reported(self):
            grammar = pgen2.driver.load_grammar("Grammar/Grammar")
            out = io.StringIO()
            grammar.report(file=out)
            out.seek(0)
            lines = out.readlines()

# Generated at 2022-06-23 15:34:41.549201
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    class DummyGrammar(Grammar): pass

    assert DummyGrammar().copy().__class__ == DummyGrammar

# Generated at 2022-06-23 15:34:42.484877
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    g.report()

# Generated at 2022-06-23 15:34:51.043171
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-23 15:34:58.282613
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2

    g = Grammar()
    g.keywords = {"LOR": 1, "LOR2": 2, "LOR3": 3}
    g.tokens = {"LOR": 1, "LOR2": 2, "LOR3": 3}
    g.symbol2label = {"LOR": 1, "LOR2": 2, "LOR3": 3}
    g.symbol2number = {"LOR": 1, "LOR2": 2, "LOR3": 3}
    g.number2symbol = {1: "LOR", 2: "LOR2", 3: "LOR3"}
    g.start = 4
    g.async_keywords = True
    # mypyc generates objects that don't have a __dict__, but they
    # do have

# Generated at 2022-06-23 15:35:04.482760
# Unit test for method load of class Grammar
def test_Grammar_load():
    import os
    import pickle
    import unittest
    here = os.path.dirname(os.path.abspath(__file__))
    g = Grammar()
    g.load(os.path.join(here,"Grammar.pkl"))
    # test that pickling still works
    pickle.dumps(g,0)

# Generated at 2022-06-23 15:35:16.168715
# Unit test for method report of class Grammar

# Generated at 2022-06-23 15:35:17.767659
# Unit test for constructor of class Grammar
def test_Grammar():
    x = Grammar()
    assert x is not None


# Generated at 2022-06-23 15:35:22.963155
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(pandas._libs.tslibs.test.test_base.__path__[0], '..', 'parser', 'Grammar.pickle'))
    assert len(g.dfas) == 47
    assert len(g.states) == 442


# Generated at 2022-06-23 15:35:34.521184
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2.driver import Driver
    from .tokenize import tokenize
    from io import StringIO

    # mypyc generates objects that don't have a __dict__,
    # but they do have __getstate__ methods that will return
    # an equivalent dictionary.
    def _dict(obj: Any) -> Dict[str, Any]:
        if hasattr(obj, "__dict__"):
            return obj.__dict__
        return obj.__getstate__()  # type: ignore

    # test grammar object
    def test_grammar_object(obj: Grammar) -> None:
        with tempfile.NamedTemporaryFile(delete=False) as fobj:
            obj.dump(fobj.name)
        with open(fobj.name, "rb") as fobj:
            obj1: Grammar