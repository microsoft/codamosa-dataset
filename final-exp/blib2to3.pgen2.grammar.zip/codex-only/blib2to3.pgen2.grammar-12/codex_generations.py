

# Generated at 2022-06-23 15:30:11.912883
# Unit test for constructor of class Grammar
def test_Grammar():
    G = Grammar()
    assert isinstance(G, Grammar)
    assert G.symbol2number == {}
    assert G.number2symbol == {}
    assert G.states == []
    assert G.dfas == {}
    assert G.labels == [(0, 'EMPTY')]
    assert G.keywords == {}
    assert G.tokens == {}
    assert G.symbol2label == {}
    assert G.start == 256
    assert G.async_keywords == False

# Generated at 2022-06-23 15:30:19.590706
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Set up a grammar from a pickle file (created in pgen2/driver.py)
    import glob
    import py_compile
    import importlib
    import tempfile
    import os

    g = Grammar()
    py_compile.compile('Grammar.py')
    g.loads(py_compile.MAGIC)

    tfn = tempfile.NamedTemporaryFile(delete=False).name
    g.dump(tfn)
    assert os.path.exists(tfn)
    os.remove(tfn)

# Generated at 2022-06-23 15:30:29.374674
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()

    # Testing deepcopy of dicts
    g.symbol2number = {'a': 1}
    g.number2symbol = {'b': 2}
    g.dfas = {1: 1, 2: 2}
    g.keywords = {1: 1, 2: 2}
    g.tokens = {1: 1, 2: 2}
    g.symbol2label = {1: 1, 2: 2}

    # Testing copy of lists
    g.labels = [1]
    g.states = [1]

    new = g.copy()


# Generated at 2022-06-23 15:30:40.043300
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    grammar1 = Grammar()
    grammar2 = grammar1.copy()

    assert grammar1.symbol2number == grammar2.symbol2number
    assert grammar1.number2symbol == grammar2.number2symbol
    assert grammar1.states == grammar2.states
    assert grammar1.dfas == grammar2.dfas
    assert grammar1.labels == grammar2.labels
    assert grammar1.keywords == grammar2.keywords
    assert grammar1.tokens == grammar2.tokens
    assert grammar1.symbol2label == grammar2.symbol2label
    assert grammar1.start == grammar2.start
    assert grammar1.async_keywords == grammar2.async_keywords

# Generated at 2022-06-23 15:30:44.882024
# Unit test for constructor of class Grammar
def test_Grammar():

    grammar = Grammar()
    assert grammar.symbol2number == {}
    assert grammar.number2symbol == {}
    assert grammar.states == []
    assert grammar.dfas == {}
    assert grammar.labels == [(0, "EMPTY")]
    assert grammar.keywords == {}
    assert grammar.tokens == {}
    assert grammar.start == 256

# Generated at 2022-06-23 15:30:54.107074
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    grammar = Grammar()

# Generated at 2022-06-23 15:30:56.597479
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()  # Don't crash

# Generated at 2022-06-23 15:31:01.132124
# Unit test for method report of class Grammar
def test_Grammar_report():
    """Unit test for Grammar.report()."""
    from pgen2.pgen import driver

    g = Grammar()
    driver.load_grammar("Grammar/Grammar", g)
    g.report()

if __name__ == "__main__":
    test_Grammar_report()

# Generated at 2022-06-23 15:31:02.513024
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")

# Generated at 2022-06-23 15:31:15.078510
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """Test method dump of class Grammar."""
    filen = "test2.pickle"
    # Create a temporary grammar
    g = Grammar()
    g.symbol2number["test_symbol1"] = 257
    g.symbol2number["test_symbol2"] = 258
    g.number2symbol[257] = "test_symbol1"
    g.number2symbol[258] = "test_symbol2"
    st = [[[(257, 2)], [(258, 3)]]]
    g.states = st
    g.dfas[258] = (st, {257: 257, 258: 258})
    g.labels = [(257, 257), (258, 258)]
    g.keywords["test_keyword1"] = 257

# Generated at 2022-06-23 15:31:23.815255
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    g2 = Grammar()
    g2.loads(g.dumps())
    if g.symbol2number != g2.symbol2number:
        from pprint import pprint

        print("symbol2number differs")
        pprint(g.symbol2number)
        pprint(g2.symbol2number)
    if g.number2symbol != g2.number2symbol:
        from pprint import pprint

        print("number2symbol differs")
        pprint(g.number2symbol)
        pprint(g2.number2symbol)
    if g.states != g2.states:
        from pprint import pprint

# Generated at 2022-06-23 15:31:34.338208
# Unit test for constructor of class Grammar
def test_Grammar():
    import unittest
    from .pgen2 import tokenize

    # Unit test for Grammar constructor
    class GrammarTestCase(unittest.TestCase):
        def runTest(self):
            g = Grammar()
            g.start = 257
            g.symbol2number = {"file_input": 257, "foo": 258, "bar": 259, "baz": 260}
            g.number2symbol = dict(
                (v, k) for k, v in g.symbol2number.items()
            )  # type: ignore
            g.labels = [(257, None), (258, None), (259, None), (260, None)]
            g.keywords = {}

# Generated at 2022-06-23 15:31:46.550875
# Unit test for method report of class Grammar
def test_Grammar_report():
    from io import StringIO
    import sys

    x = StringIO()
    sys.stdout = x

    g = Grammar()
    g.start = 257
    g.symbol2number = {"REST": 257}
    g.number2symbol = {257: "REST"}
    g.states = [[[(256, 0)]]]
    g.dfas = {257: (g.states[0], {256: 1})}
    g.labels = [(0, "EMPTY"), (256, None)]
    g.keywords = {}
    g.tokens = {}
    g.symbol2label = {}
    g.report()

    sys.stdout = sys.__stdout__
    print(x.getvalue())

# Generated at 2022-06-23 15:31:56.468539
# Unit test for method report of class Grammar
def test_Grammar_report():
    from StringIO import StringIO
    import sys

    # Method report doesn't output anything on stdout
    # so capture the output and check that it is what we expect
    saved_stdout = sys.stdout
    try:
        out = StringIO()
        sys.stdout = out
        g = Grammar()
        g.report()
        output = out.getvalue().strip()
    finally:
        sys.stdout = saved_stdout

    s2n = "{\n    \n}"
    n2s = "{\n    \n}"
    states = "[]"
    dfas = "{\n    \n}"
    labels = "[(0, 'EMPTY')]"
    start = "256"


# Generated at 2022-06-23 15:32:03.433856
# Unit test for method load of class Grammar
def test_Grammar_load():
    gr = Grammar()
    gr.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert gr.symbol2number["expr_stmt"] == 258
    assert gr.number2symbol[258] == "expr_stmt"
    assert gr.symbol2number["comp_op"] == 279
    assert gr.number2symbol[279] == "comp_op"
    assert gr.states[0][0][0][1] == 1
    assert gr.dfas[258][0][0][0][1] == 3
    assert gr.dfas[279][1][">"] == 1
    assert gr.labels[0] == (0, "EMPTY")
    assert gr.labels[2] == (5, None)

# Generated at 2022-06-23 15:32:15.559579
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    gram = Grammar()

# Generated at 2022-06-23 15:32:26.267167
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import pickle
    from textwrap import dedent

    mg = Grammar()
    mg.symbol2number = {"a": 12}
    mg.number2symbol = {12: "a"}
    mg.dfas = {1: [[[1, 2]], [0, 0]]}
    mg.keywords = {"a": 13}
    mg.tokens = {1: 2}
    mg.symbol2label = {"a": 1}
    mg.labels = [[1, "a"]]
    mg.states = [[[[1, 2]]]]
    mg.start = 256

    cg = mg.copy()
    mg.symbol2number["b"] = 13
    mg.number2symbol[13] = "b"

# Generated at 2022-06-23 15:32:29.655683
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2 import driver

    g = driver.load_grammar("Grammar/Grammar")
    g.dump("Grammar/Grammar.pkl")
    h = Grammar()
    h.load("Grammar/Grammar.pkl")

# Generated at 2022-06-23 15:32:36.632746
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    from . import pgen2
    from . import checker


    class GrammarDumpTestCase(unittest.TestCase):
        """Tests Grammar.dump().
        """

        def __init__(self, *args, **kwds):
            unittest.TestCase.__init__(self, *args, **kwds)
            self.filename = tempfile.mktemp()
            self.grammar = pgen2.driver.load_grammar(checker.__file__)
            self.grammar.dump(self.filename)

        def tearDown(self):
            os.unlink(self.filename)

        def runTest(self):
            """Test Grammar.dump().
            """
            loaded_grammar = Grammar()

# Generated at 2022-06-23 15:32:37.783666
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump(None)

if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-23 15:32:42.668426
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()


if __name__ == "__main__":
    import _ast  # noqa

    x = Grammar()
    x.dump("Grammar.pickle")
    x.report()

    y = Grammar()
    y.load("Grammar.pickle")
    y.report()

# Generated at 2022-06-23 15:32:48.469586
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .conv import convert_grammar
    from .pgen2 import tokenize

    with open(tokenize.__file__) as f:
        gr = convert_grammar(f.read(), "tokenize", "Grammar")

    gr2 = Grammar()
    gr2.loads(gr.dumps())
    assert gr.symbol2number == gr2.symbol2number
    assert gr.number2symbol == gr2.number2symbol
    assert gr.dfas[gr.start][0] == gr2.dfas[gr.start][0]

# Generated at 2022-06-23 15:32:58.240232
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    grammar = """cos\nsystem\n(S'ls -l'\ntR."""
    expected = {'start': 256, 'states': [[(257, 1)]], 'symbol2label': {}, 'symbol2number': {'file_input': 256}, 'keywords': {}, 'async_keywords': False, 'labels': [(257, 'NAME'), (0, 'EMPTY')], 'tokens': {}, 'dfas': {256: ([(257, 1)], {'cos': 257, 'system': 257})}, 'number2symbol': {256: 'file_input'}}
    g = Grammar()
    g.loads(grammar.encode('utf-8'))
    assert g.__dict__ == expected

# Generated at 2022-06-23 15:33:05.920804
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    def assert_copy(grammar: Grammar) -> None:
        # This test is written as a function to avoid a __doc__ check
        # in the mypyc stdlib (issue #79).
        # https://github.com/python/mypyc/issues/79
        g = grammar.copy()
        assert g.async_keywords == grammar.async_keywords
        assert g.dfas == grammar.dfas
        assert g.labels == grammar.labels
        assert g.keywords == grammar.keywords
        assert g.number2symbol == grammar.number2symbol
        assert g.start == grammar.start
        assert g.states == grammar.states
        assert g.symbol2label == grammar.symbol2label
        assert g.symbol2number == grammar.symbol2number
        assert g

# Generated at 2022-06-23 15:33:17.011060
# Unit test for method report of class Grammar
def test_Grammar_report():
    from io import StringIO
    from unittest.mock import mock_open
    import unittest.mock

    g = Grammar()
    g.symbol2number = {
        "a": 2,
        "b": 3,
        "c": 4,
        "d": 5,
        "e": 6,
        "f": 7,
    }
    g.number2symbol = {
        v: k for k, v in g.symbol2number.items()
    }

# Generated at 2022-06-23 15:33:28.756985
# Unit test for constructor of class Grammar
def test_Grammar():
    # needs to be defined here so that it can access Grammar
    def checkgrammar(g):
        assert g
        assert g.symbol2number == {"foo": 256, "bar": 257}
        assert g.number2symbol == {256: "foo", 257: "bar"}
        assert g.states == [[(257, 0), (256, 1)], [(0, 1)]]
        assert g.dfas == {256: ([[(257, 0), (256, 1)]], {"EMPTY": 1}), 257: ([[(0, 1)]], {"EMPTY": 1})}
        assert g.labels == [(0, "EMPTY"), (257, None), (256, None)]
        assert g.keywords == {}
        assert g.tokens == {}

# Generated at 2022-06-23 15:33:38.956232
# Unit test for method report of class Grammar
def test_Grammar_report():
    """
    This unit test verifies that the method report of class Grammar returns the
    expected output.
    """

    # Create a grammar object and initialize the instance variables
    grammar = Grammar()
    grammar.symbol2number = { "symbol1": 1, "symbol2": 2, "symbol3": 3 }
    grammar.number2symbol = { 1: "symbol1", 2: "symbol2", 3: "symbol3" }
    grammar.states = [ [ (1, 2), (3, 4), (5, 6) ], [ (7, 8), (9, 10), (11, 12) ] ]

# Generated at 2022-06-23 15:33:48.477289
# Unit test for method report of class Grammar
def test_Grammar_report():
    from io import StringIO
    from pprint import pformat

    class MyGrammar(Grammar):
        def __init__(self, answer: int) -> None:
            Grammar.__init__(self)
            self.answer = answer

        def report(self) -> None:
            print("42 is", self.answer)

    for x in (1, 2, 3):
        g = MyGrammar(x)
        out = StringIO()
        g.report()  # pylint: disable=no-value-for-parameter
        assert out.getvalue() == "42 is %s\n" % x

    g = MyGrammar(42)
    out = StringIO()
    g.report()  # pylint: disable=no-value-for-parameter
    assert out.getvalue

# Generated at 2022-06-23 15:33:55.376484
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import conv

    g = Grammar()
    conv.initialize_grammar(g)

    with tempfile.TemporaryDirectory() as dirname:
        filename = os.path.join(dirname, "test_grammar.pickle")
        g.dump(filename)
        g2 = Grammar()
        g2.load(filename)

    assert g.__dict__ == g2.__dict__



# Generated at 2022-06-23 15:34:07.311185
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    f = tempfile.NamedTemporaryFile(delete=False)
    try:
        g.dump(f.name)
    finally:
        os.remove(f.name)
    g1 = Grammar()
    g1.load(f.name)
    assert g.start == g1.start
    assert g.labels == g1.labels
    assert g.states == g1.states
    assert g.dfas == g1.dfas
    assert g.symbol2number == g1.symbol2number
    assert g.number2symbol == g1.number2symbol
    assert g.keywords == g1.keywords
    assert g.tokens == g1.tokens
    assert g.symbol2label == g1.symbol2label




# Generated at 2022-06-23 15:34:13.800069
# Unit test for constructor of class Grammar
def test_Grammar():
    # This code is called as a unit test from file test/test_pgen.py
    g = Grammar()
    ##  all is ok if the following statements do not raise exceptions
    g.symbol2number = g.number2symbol = g.states = g.dfas = g.labels = None  # type: ignore
    g.keywords = g.tokens = g.symbol2label = None  # type: ignore
    g.start = None
    g.report()

# Generated at 2022-06-23 15:34:19.141819
# Unit test for method report of class Grammar
def test_Grammar_report():
    # Test Grammar.report.  Test it indirectly by loading a saved
    # Grammar and then dumping it.
    from .pgen2 import driver

    g = driver.load_grammar("Grammar.txt")
    g.report()


if __name__ == "__main__":
    import unittest

    unittest.main("grammar.test_grammar", verbosity=2)

# Generated at 2022-06-23 15:34:29.582453
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pytest
    from tokenize import tokenize, TokenInfo
    import io
    sample_code = '''\
        a = b + c
        d[e] = f
    '''

# Generated at 2022-06-23 15:34:32.955721
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # make sure the temp file is removed after the test
    g = Grammar()
    g.dump("test.pkl")
    os.remove("test.pkl")
    assert True

# Generated at 2022-06-23 15:34:42.857111
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    new_grammar = Grammar()
    new_grammar.number2symbol = {1: "a"}
    new_grammar.symbol2number = {"a": 1}
    new_grammar.symbol2label = {"a": 1}
    new_grammar.dfas = {1: ([[(1, 0)], [(2, 1), (3, 2)], [(1, 2)], [(1, 3)]], {0: 0, 1: 2, 2: 3})}
    new_grammar.labels = [(1, "a"), (2, "b"), (3, "c")]
    new_grammar.states = [[(1, 0), (2, 1), (3, 2)], [(1, 0), (3, 1), (3, 2)]]
    new_grammar.keywords

# Generated at 2022-06-23 15:34:52.099131
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g1.symbol2label = {"KEYWORD": 1}
    g1.labels = [(0, "EMPTY")]
    g1.dfas = {256: ([[None, None]], {1: 1})}
    g1.tokens = {1: 1}
    g1.keywords = {"KEYWORD": 1}
    g1.symbol2number = {"KEYWORD": 1}
    g1.number2symbol = {1: "KEYWORD"}
    g1.states = [([[None, None]], {1: 1})]
    g1.start = 256

    g2 = g1.copy()

    # Modify g1
    g1.start = 1

    # Check that g2 was not modified
    assert g2.start

# Generated at 2022-06-23 15:34:54.371296
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    from . import test_grammar

    assert isinstance(test_grammar.grammar.copy(), Grammar)

# Generated at 2022-06-23 15:35:03.139925
# Unit test for method report of class Grammar
def test_Grammar_report():
    from . import grammar
    from . import symbol
    from .pythonparser import Config, PythonParser
    from .pgen2 import tokenize

    # Test grammar reporting with an empty grammar
    g = grammar.Grammar()
    g.report()

    # Test grammar reporting with a normal grammar
    g = PythonParser(Config()).pgen()
    g.report()

    # Test with the tokenize function
    g = symbol.sym_name.copy()
    g.update(symbol.tok_name)
    print("s2n")
    print(g)
    print("n2s")
    g = {y: x for x, y in g.items()}
    print(g)
    print("tokens")
    pprint(tokenize.tok_name)



# Generated at 2022-06-23 15:35:08.033380
# Unit test for method load of class Grammar
def test_Grammar_load():
    try:
        import conv
        import pgen2
    except ImportError:
        return
    print("running Grammar.load() test...")

    # Load grammar.
    g = pgen2.load_pgen("Grammar/Grammar", "Grammar/graminit.c")
    # Make a copy.
    g2 = g.copy()
    # Save the copy to a file.
    pgen2.dump_pgen("Grammar/Grammar.copy", g2)
    # Load the copy from the file.
    g3 = Grammar()
    g3.load("Grammar/Grammar.copy")
    # Compare the original to the loaded copy.

# Generated at 2022-06-23 15:35:14.609836
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys, parse
    grammar_path = "../Parser/Python.grammar"

    if sys.version_info[:2] >= (3, 8):
        grammar_path = "../Parser/Python38.grammar"

    g = parse.Grammar()
    with open(grammar_path, "rb") as f:
        g.loads(f.read())

# Generated at 2022-06-23 15:35:19.316586
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-23 15:35:27.767592
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.symbol2number = {"name": 2}
    g.number2symbol = {1: "number"}
    g.states = [["a", "b", "c"]]
    g.dfas = {1: 2}
    g.labels = [(1, 2)]
    g.start = 256
    assert g.symbol2number is not None
    assert g.number2symbol is not None
    assert g.states is not None
    assert g.dfas is not None
    assert g.labels is not None
    assert g.start is not None
    g.report()


# Generated at 2022-06-23 15:35:35.290902
# Unit test for method load of class Grammar
def test_Grammar_load():
    source = b"\x80\x03}q\x00."
    g = Grammar()
    g.loads(source)
    assert g.keywords == {}

if __name__ == "__main__":
    import sys

    test_Grammar_load()
    if "report" in sys.argv:
        g = Grammar()
        getattr(g, sys.argv[1])(sys.argv[2])
        g.report()

# Generated at 2022-06-23 15:35:44.334288
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import copy
    import pickle

    g = Grammar()
    g.symbol2number = {'a': 1, 'b': 2, 'c': 3}
    g.number2symbol = {1: 'a', 2: 'b', 3: 'c'}
    g.dfas = {1: ([2], {3: 1}), 2: ([3], {4: 1}), 3: ([4], {5: 1})}
    g.keywords = {'d': 6, 'e': 7, 'f': 8}
    g.tokens = {6: 'd', 7: 'e', 8: 'f'}
    g.symbol2label = {'g': 9, 'h': 10, 'i': 11}

# Generated at 2022-06-23 15:35:47.482236
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()

assert token.DOUBLESLASHEQUAL == (getattr(token, "OP", 0) + 11)

# Generated at 2022-06-23 15:35:58.562568
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import io
    import unittest

    class TestGrammarLoad(unittest.TestCase):
        def setUp(self):
            self.fd1, self.fn1 = tempfile.mkstemp()
            self.fd2, self.fn2 = tempfile.mkstemp()
            self.backup_stdout = sys.stdout
            self.out = io.StringIO()
            sys.stdout = self.out

        def tearDown(self):
            os.close(self.fd1)
            os.close(self.fd2)
            os.remove(self.fn1)
            os.remove(self.fn2)
            sys.stdout = self.backup_stdout

        def test_load_reflexive(self):
            g1 = Grammar()
           

# Generated at 2022-06-23 15:36:11.106427
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # This is a unit test for method loads of class Grammar, covering
    # the unusual and error-prone case that the dict of loaded data
    # is empty. See issue #13808.
    g = Grammar()
    g.loads(b"\x80\x03}q.")
    assert g.labels == [(0, "EMPTY")]
    assert g.tokens == {}
    assert g.keywords == {}
    assert g.number2symbol == {}
    assert g.symbol2number == {}
    assert g.symbol2label == {}
    assert g.dfas == {}
    assert g.states == []
    assert g.start == 256
    assert g.async_keywords is False

if __name__ == "__main__":
    g = Grammar()

# Generated at 2022-06-23 15:36:12.881068
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    filename = "tmp.py"
    grammar.dump(filename)
    grammar.loads(open(filename).read())



# Generated at 2022-06-23 15:36:18.311439
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os.path
    from pgen2.pgen import tokenizer
    filename = 'test_Grammar_dump.grammar.pkl'
    g = tokenizer.generate_grammar()
    g.dump(filename)
    assert os.path.exists(filename)
    os.remove(filename)

# Generated at 2022-06-23 15:36:21.636046
# Unit test for constructor of class Grammar
def test_Grammar():
    t = token
    assert t.NAME == 1
    assert t.COMMENT == 55
    assert t.ERRORTOKEN == 59

if __name__ == "__main__":
    test_Grammar()

# Generated at 2022-06-23 15:36:25.597092
# Unit test for method report of class Grammar
def test_Grammar_report():
    from .conv import Convertor
    from .dump import dump_grammar

    c = Convertor()
    g = c.parse_grammar(dump_grammar)
    g.report()
    print("+++++++++++++++++++++++++++++++")
    g.report()
    return g

# Generated at 2022-06-23 15:36:34.991948
# Unit test for method report of class Grammar
def test_Grammar_report():
    """This function tests the method report of class Grammar.

    Method report is part of the development support code and is used
    to print the contents of the tables in the grammar to stdout.



    """
    from . import pgen2
    from . import driver

    pg = pgen2.driver.load_grammar(debug=0)
    pg.report()
    pg = pgen2.driver.load_grammar(debug=1)
    pg.report()
    pg = pgen2.driver.load_grammar(optimize=0, debug=0)
    pg.report()
    pg = pgen2.driver.load_grammar(optimize=0, debug=1)
    pg.report()
    pg = pgen2.driver.load_grammar(start="file_input", debug=0)
    pg

# Generated at 2022-06-23 15:36:37.499175
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()


# Generated at 2022-06-23 15:36:49.153785
# Unit test for constructor of class Grammar
def test_Grammar():
    import unittest
    import pickle

    # a test DFA
    dfa = [
        [((1, ""), 2)],  # state 0
        [((1, ""), 1)],  # state 1
        [((1, ""), 3), ((2, ""), 4), ((0, None), 5)],  # state 2
        [((1, ""), 1)],  # state 3
        [((1, ""), 1)],  # state 4
        [((1, ""), 1)],  # state 5
    ]

# Generated at 2022-06-23 15:36:56.817927
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert(g.symbol2number == {})
    assert(g.number2symbol == {})
    assert(g.states == [])
    assert(g.dfas == {})
    assert(g.labels == [(0, "EMPTY")])
    assert(g.keywords == {})
    assert(g.tokens == {})
    assert(g.symbol2label == {})
    assert(g.start == 256)
    assert(g.async_keywords is False)

# Generated at 2022-06-23 15:36:59.408532
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g2 = g.copy()
    assert g.labels == g2.labels
    g3 = g.copy()
    assert g3 is not g2



# Generated at 2022-06-23 15:37:07.354653
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    g.symbol2number = {
        "async_funcdef": 257,
        "async_stmt": 258,
        "decorated": 259,
        "f_arguments": 260,
        "funcdef": 261,
        "parameters": 262,
        "varargslist": 263,
    }
    pkl = pickle.dumps(g)
    h = Grammar()
    h.loads(pkl)
    assert h.symbol2number == g.symbol2number

# Generated at 2022-06-23 15:37:17.705106
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """
    In order to test Grammar.dump, we create a simple grammar, dump
    it to a file, and then load the file back in again.  We then test
    that the loaded grammar contains the expected values.
    """
    g = Grammar()
    g.symbol2number = {
        "None": 257,
        "False": 258,
        "True": 259,
        "ellipsis": 260,
    }
    g.number2symbol = {
        257: "None",
        258: "False",
        259: "True",
        260: "ellipsis",
    }

# Generated at 2022-06-23 15:37:22.020380
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump('test-Grammar-dump.pickle')
    g2 = Grammar()
    g2.load('test-Grammar-dump.pickle')
    assert g.number2symbol == g2.number2symbol

test_Grammar_dump()

# Generated at 2022-06-23 15:37:30.160903
# Unit test for method report of class Grammar
def test_Grammar_report():
  # Create an instance of Grammar
  data = Grammar()

  # Create a dict with three elements
  dict_A = { "a": 1, "b": 2, "c": 3 }

  # Assign the dict to the instance variable symbol2number
  data.symbol2number = dict_A

  # Create a dict with three elements
  dict_B = { 1: "a", 2: "b", 3: "c" }

  # Assign the dict to the instance variable number2symbol
  data.number2symbol = dict_B

  # Create a list of three lists
  list_A = [ [ (0, 1), (0, 2) ], [ (2, 3) ], [ (4, 5) ] ]

  # Assign the list to the instance variable states
  data.states = list_A

  # Create

# Generated at 2022-06-23 15:37:36.050366
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    from .token import INDENT, DEDENT, token_constructor

    # Symbol numbers.
    file_input = 257
    single_input = 258
    eval_input = 259
    stmt = 260
    simple_stmt = 261
    compound_stmt = 262
    if_stmt = 263
    while_stmt = 264
    for_stmt = 265
    try_stmt = 266
    with_stmt = 267
    funcdef = 268
    classdef = 269
    suite = 270
    test = 271
    and_test = 272
    not_test = 273
    comparison = 274
    comp_op = 275
    expr = 276
    xor_expr = 277
    and_expr = 278
    shift_expr = 279
    arith_expr = 280
    term = 281
    factor = 282


# Generated at 2022-06-23 15:37:38.090361
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    g.start = 1
    assert g.start == 1


# Generated at 2022-06-23 15:37:50.218961
# Unit test for method report of class Grammar
def test_Grammar_report():
    gram = Grammar()
    # init symbol2number
    gram.symbol2number = {"foo": 1}
    assert gram.symbol2number == {"foo": 1}
    # init number2symbol
    gram.number2symbol = {1: "foo"}
    assert gram.number2symbol == {1: "foo"}
    # init states
    gram.states = [["bar"]]
    assert gram.states == [["bar"]]
    # init dfas
    gram.dfas = {1: ("bar", "baz")}
    assert gram.dfas == {1: ("bar", "baz")}
    # init labels
    gram.labels = [("bar", "baz")]
    assert gram.labels == [("bar", "baz")]
    # init keywords

# Generated at 2022-06-23 15:38:01.906441
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    gr = Grammar()

# Generated at 2022-06-23 15:38:08.687071
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    """
    Unit test for method copy of class Grammar.
    """
    import pickle
    from .pgen2 import driver
    import io

    pkl_data = io.BytesIO()
    with open("data/Grammar.pickle", "rb") as f:
        data = f.read()
    pkl_data.write(data)
    pkl_data.seek(0)
    grammar = driver.load_grammar("data/Grammar.txt")
    assert grammar.loads(pkl_data.read()) is None

    grammar_copy = grammar.copy()
    assert grammar_copy is not grammar
    assert grammar_copy.async_keywords == grammar.async_keywords
    assert grammar_copy.start == grammar.start
    assert grammar_copy.symbol2number == grammar.symbol

# Generated at 2022-06-23 15:38:19.263113
# Unit test for constructor of class Grammar
def test_Grammar():
    """
    >>> g = Grammar()
    >>> g.symbol2number == dict()
    True
    >>> g.number2symbol == dict()
    True
    >>> g.states == list()
    True
    >>> g.dfas == dict()
    True
    >>> g.labels == [(0, "EMPTY")]
    True
    >>> g.keywords == dict()
    True
    >>> g.tokens == dict()
    True
    >>> g.symbol2label == dict()
    True
    >>> g.start == 256
    True
    >>> g.async_keywords == False
    True
    """


# Generated at 2022-06-23 15:38:21.600457
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Coverage: need to be able to run this via invoke coverage
    g = Grammar()
    g.load("Grammar.pickle")

# Generated at 2022-06-23 15:38:29.943669
# Unit test for method report of class Grammar
def test_Grammar_report():

    # Test the report method of class Grammar

    # Setup
    temp_name = "pytree_temp.pkl"
    g = Grammar()

    g.symbol2number = {'single_input': 256, 'file_input': 257}
    g.number2symbol = {256: 'single_input', 257: 'file_input'}

# Generated at 2022-06-23 15:38:42.558634
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    source_symbol2number = {"a": 1}
    source_number2symbol = {"1": "a"}
    source_dfas = {1: ([[(1, 1)]], {1: 1})}
    source_keywords = {"a": 1}
    source_tokens = {1: 1}
    source_symbol2label = {"a": 1}
    source_labels = [(1, "a")]
    source_states = [[[(1, 1)]]]
    source_start = "a"
    source = Grammar()
    source.symbol2number = source_symbol2number
    source.number2symbol = source_number2symbol
    source.dfas = source_dfas
    source.keywords = source_keywords
    source.tokens = source_t

# Generated at 2022-06-23 15:38:48.099088
# Unit test for constructor of class Grammar
def test_Grammar():
    # Verify that test_Grammar's caller is test.test_grammar
    assert __name__ == 'test.test_grammar'
    # Verify that test_Grammar's caller is test.test_grammar
    assert __name__ == 'test.test_grammar'
    # Verify that test_Grammar's caller is test.test_grammar
    assert __name__ == 'test.test_grammar'

# Generated at 2022-06-23 15:38:57.301706
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io
    from pprint import pprint


# Generated at 2022-06-23 15:39:03.370291
# Unit test for method load of class Grammar
def test_Grammar_load():
    # This test doesn't really test anything, but it might catch
    # changes that would cause Grammar.load() to fail.

    g = Grammar()
    g.symbol2number = {"foo": 257, "bar": 258}
    g.number2symbol = {257: "foo", 258: "bar"}
    g.start = 257
    g.states = [
        [
            [(259, 1), (260, 0)],
            [(261, 0)],
            [(262, 1), (263, 0)],
        ]
    ]

# Generated at 2022-06-23 15:39:14.731150
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("/Users/michael.sofaer/git/parso/tests/test_grammar/Grammar.pickle")
    assert grammar.symbol2number["comp_op"] == 308
    assert grammar.symbol2number["term"] == 342
    assert grammar.symbol2number["test"] == 346
    assert grammar.symbol2number["test_nocond"] == 347
    assert grammar.symbol2number["dotname"] == 356
    assert grammar.symbol2number["at_stmt"] == 357
    assert grammar.symbol2number["compound_stmt"] == 359
    assert grammar.symbol2number["import_name"] == 370
    assert grammar.symbol2number["import_from"] == 371

# Generated at 2022-06-23 15:39:19.064871
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {"sym2num": 2}
    g.number2symbol = {2: "num2sym"}
    g.dfas = {3: DFAS([[(1, 2)]], {1: 1})}
    g.keywords = {"keyword": 4}
    g.tokens = {1: 1}
    g.symbol2label = {"sym2lbl": 5}
    g.labels = [(1, None), (2, None)]
    g.states = [[(1, 2)]]
    g.start = 2
    g.async_keywords = True

    g_copy = g.copy()

    assert g.symbol2number == g_copy.symbol2number
    assert g.number2symbol == g_copy.number

# Generated at 2022-06-23 15:39:22.830097
# Unit test for method report of class Grammar
def test_Grammar_report():
    from mypy.pgen2 import pgen
    g = pgen.parse(grammar, 'Grammar')
    assert g is not None
    isinstance(g, Grammar)
    # Exception is not raised
    g.report()


# Generated at 2022-06-23 15:39:25.610226
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    from io import StringIO
    from unittest import TestCase

    capture = StringIO()
    g.report()
    TestCase().assertEqual(capture.getvalue(), str(g))

# Generated at 2022-06-23 15:39:30.985828
# Unit test for method copy of class Grammar
def test_Grammar_copy():

    def _get_name(g: Grammar) -> str:
        """Returns the class name of the given object."""
        return str(g.__class__).split(".")[-1][:-2]

    def _get_repr(g: Grammar) -> str:
        """Returns a string representation of the given object."""

# Generated at 2022-06-23 15:39:36.652035
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Test that the dump method accepts a file object as a parameter
    # It previously gave a TypeError for file objects
    class FileLike(object):
        def write(self, s: bytes) -> int:
            print(s)
            return 1

    my_file = FileLike()
    g = Grammar()
    g.dump(my_file)

# Generated at 2022-06-23 15:39:44.152464
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    import unittest

    class TestGrammarLoads(unittest.TestCase):
        def test_loads(self) -> None:
            g = Grammar()
            g.loads(b"\x80\x03}q\x00X\x12\x00\x00\x00symbol2numberq\x01}q\x02(X\x02\x00\x00\x00idq\x03K\x01su."
            )

    unittest.main()


if __name__ == "__main__":
    test_Grammar_loads()

# Generated at 2022-06-23 15:39:46.440306
# Unit test for method report of class Grammar
def test_Grammar_report():
    grammar = Grammar()
    out = str(grammar.report())
    assert out != None

# Generated at 2022-06-23 15:39:54.814100
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    # mypyc doesn't like isinstance(x, cls), so we set these up
    # otherwise
    g1: Grammar = Grammar()
    g2: Grammar = Grammar()

    g1.states = [[(0, 0), (1, 1)], [(2, 2), (3, 3)]]
    g1.start = 0
    g1.symbol2label["a"] = 0
    g1.keywords["b"] = 0
    g1.tokens["c"] = 0

    assert not isinstance(g1.states, dict)
    assert not isinstance(g1.symbol2label, dict)
    assert not isinstance(g1.keywords, dict)
    assert not isinstance(g1.tokens, dict)

    g2.copy(g1)

# Generated at 2022-06-23 15:40:01.494842
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    class MyGrammar(Grammar):
        pass

    g1 = MyGrammar()
    g2 = g1.copy()
    assert g1.__class__ == g2.__class__

    g1 = Grammar()
    g2 = g1.copy()
    assert g1.__class__ == g2.__class__



# Generated at 2022-06-23 15:40:07.233947
# Unit test for constructor of class Grammar
def test_Grammar():
    grammar = Grammar()
    assert grammar.symbol2label == {}
    assert grammar.tokens == {}
    assert grammar.keywords == {}
    assert grammar.labels == [(0, "EMPTY")]
    assert grammar.dfas == {}
    assert grammar.states == []
    assert grammar.number2symbol == {}
    assert grammar.symbol2number == {}
    assert grammar.start == 256