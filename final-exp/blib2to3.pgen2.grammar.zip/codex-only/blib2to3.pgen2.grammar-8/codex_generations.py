

# Generated at 2022-06-23 15:30:10.576012
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.tokens == {}
    assert g.keywords == {}
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.start == 256



# Generated at 2022-06-23 15:30:20.964382
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    class TestGrammar(Grammar):
        def __init__(self):
            self.initialize()

        def initialize(self):
            self.symbol2number = {"foo": 777}
            self.number2symbol = {777: "foo"}
            self.labels = [(1, "bar"), (2, "baz")]
            self.start = 1
    grammar = TestGrammar()
    with tempfile.TemporaryDirectory() as tmpdir:
        test_file = os.path.join(tmpdir, "test_Grammar_dump.pkl")
        grammar.dump(test_file)
        new_grammar = TestGrammar()
        new_grammar.load(test_file)
        assert new_grammar.symbol2number == {"foo": 777}
        assert new_

# Generated at 2022-06-23 15:30:31.489057
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.start = 1
    g.symbol2number = {'None': 2}
    g.dfas = {1: [0, {}], 2: [1, {}]}
    g.number2symbol = {1: 'one', 2: 'two'}
    g.states = [[[1, 1], [2, 1]], [[3, 1]]]
    g.symbol2label = {'one': 2, 'two': 3}
    g.tokens = {1: 2, 2: 3}
    g.keywords = {'one': 2, 'two': 3}
    g.labels = [[1, 'one'], [2, 'two']]
    g.async_keywords = True

    h = g.copy()

# Generated at 2022-06-23 15:30:42.998547
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    gp = Grammar()

# Generated at 2022-06-23 15:30:50.940644
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    # Test adding of an attribute
    gr = Grammar()
    gr.new_attr = "test"
    gr2 = gr.copy()
    assert gr2 is not gr
    assert gr2.new_attr == "test"
    assert gr2.__class__.__name__ == gr.__class__.__name__

    # Test copying of a dictionary attribute
    gr.new_attr = {}
    gr2 = gr.copy()
    assert gr2 is not gr
    assert gr2.new_attr is not gr.new_attr
    gr2.new_attr["test"] = 1
    assert "test" not in gr.new_attr
    assert gr2.new_attr["test"] == 1

    # Test copying of a list attribute
    gr.new_attr2 = []
    gr2 = gr.copy()
   

# Generated at 2022-06-23 15:30:52.376819
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    g.dump(os.path.join(os.path.dirname(__file__), "Grammar.pickle"))
    g.report()


# Generated at 2022-06-23 15:30:54.020808
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()

if __name__ == "__main__":
    test_Grammar()
    print("Grammar class ok")

# Generated at 2022-06-23 15:30:56.597034
# Unit test for constructor of class Grammar
def test_Grammar():
    grammar = Grammar()


# Generated at 2022-06-23 15:31:02.659418
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Make sure that loading a pickle string with a bad value for
    # async_keywords doesn't reset async_keywords to False.
    g = Grammar()
    g.async_keywords = True
    # We use loads instead of load so that the test doesn't depend on
    # the tempfile module or user-writeable directories.
    g.loads(b"cos\n")
    assert g.async_keywords

# Generated at 2022-06-23 15:31:15.238214
# Unit test for method load of class Grammar
def test_Grammar_load():
    from pickle import dumps
    from . import pgen2

    g = pgen2.generate_grammar("grammar_test.txt")
    pkl = dumps(g)
    g2 = Grammar()
    g2.loads(pkl)
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.dfas == g2.dfas
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label
    assert g.labels == g2.labels
    assert g.states == g2.states
    assert g.start == g2.start



# Generated at 2022-06-23 15:31:17.711182
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()

if __name__ == "__main__":
    test_Grammar_report()

# Generated at 2022-06-23 15:31:24.600635
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle

    g = Grammar()
    g.states = [0, 1]
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.dump('Grammar.pkl')
    g.load('Grammar.pkl')

    # g.report()
    assert len(g.states) == 2
    assert g.symbol2number == {'foo': 1, 'bar': 2}


# Generated at 2022-06-23 15:31:34.913103
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[[(1, 1)]]]
    g.dfas = {1: ([[(1, 1)]], {0: 1}), 2: ([[(1, 1)]], {0: 1})}
    g.labels = [(1, 'foo')]
    g.labels = [(1, 'baz')]
    g.keywords = {'baz': 1}
    g.tokens = {2: 1, 3: 1}
    g.symbol2label = {'baz': 1}
    g.start = 256


# Generated at 2022-06-23 15:31:44.118325
# Unit test for constructor of class Grammar
def test_Grammar():
    assert token.DOUBLESLASHEQUAL == 85
    g = Grammar()
    assert len(g.labels) == 1
    assert (0, "EMPTY") in g.labels
    assert g.start == 256
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.async_keywords is False

# Generated at 2022-06-23 15:31:52.631368
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    # an empty grammar cannot be dumped
    try:
        grammar.dump("_dontcare")
    except (AttributeError, pickle.PicklingError):
        pass
    else:
        raise AssertionError("Grammar.dump should have failed on empty grammar")
    # fill in the symbols
    grammar.symbol2number = {"foo": 0, "bar": 1, "baz": 2}
    grammar.number2symbol = {0: "foo", 1: "bar", 2: "baz"}
    # fill in the states
    state = [(0, 1), (1, 2), (0, 0)]
    grammar.states.append(state)
    # fill in the dfas
    grammar.dfas = {0: (0, {2: 1})}
    # fill in the labels

# Generated at 2022-06-23 15:32:01.584578
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    # Test that the symbol2number dict is empty
    assert(g.symbol2number == {})
    # Test that the number2symbol dict is empty
    assert(g.number2symbol == {})
    # Test that the states list is empty
    assert(g.states == [])
    # Test that the dfas dict is empty
    assert(g.dfas == {})
    # Test that the labels list is not empty
    assert(len(g.labels) > 0)
    # Test that the keywords dict is empty
    assert(g.keywords == {})
    # Test that the tokens dict is empty
    assert(g.tokens == {})
    # Test that the symbol2label dict is empty
    assert(g.symbol2label == {})
    # Test that the start

# Generated at 2022-06-23 15:32:09.034907
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io
    import sys
    import unittest

    # Test the three cases, no error (first), an error (second) and
    # an exception (third).
    for i in range(3):
        text = io.StringIO()
        # A bit hackish: we replace sys.stdout by a StringIO and we
        # restore it at the end of the test.
        tmp = sys.stdout
        sys.stdout = text
        try:
            if i == 0:
                Grammar().report()
            elif i == 1:
                Grammar().symbol2number["Error"] = 0
                Grammar().report()
            else:
                raise ValueError("test exception")
        except Exception:
            pass
        sys.stdout = tmp

# Generated at 2022-06-23 15:32:15.368679
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import os.path
    from . import conv
    from . import pgen
    from . import token

    # Grammar file not exist, no need to test
    path = os.path.join(os.path.dirname(sys.executable), "Lib", "lib2to3", "Grammar.txt")
    if not os.path.exists(path):
        return

    # The Python grammar file is called Grammar/Grammar, so we have to
    # chdir to the directory containing the Grammar directory.
    # XXX Perhaps use imp.find_module to find the Grammar directory
    dirname = os.path.dirname
    grammar_dir = os.path.dirname(os.path.dirname(dirname(path)))

# Generated at 2022-06-23 15:32:26.033150
# Unit test for method report of class Grammar
def test_Grammar_report():
    for name in dir(token):
        if not name.startswith("_") and name != "tok_name":
            globals()[name] = name
    class NullGrammar(Grammar):
        states = [[[(1, 2)], [(2, 3), (3, 3)], [(1, 2), (2, 3), (3, 3)]]]
        symbols = {}
        dfas = {1: ([0, 1, 2], {1: 1}), 2: ([0, 1, 2], {1: 1, 2: 1})}
        labels = [(1, None), (2, "foo"), (3, "bar")]
        start = 1
    NullGrammar().report()
    del globals()["LPAR"]
    del globals()["COMMA"]


# Generated at 2022-06-23 15:32:30.249489
# Unit test for method report of class Grammar
def test_Grammar_report():
    from .pgen2 import driver, grammar

    driver.main(["-o", os.devnull, "-g", "-p", "Grammar", grammar])


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-23 15:32:41.049935
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-23 15:32:49.652854
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()

# Generated at 2022-06-23 15:32:55.744200
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """
    Run the test to verify the dump method of Grammar class.
    """

    def _copy_grammar() -> Grammar:
        """
        Copy the grammar tables and return it.
        """
        g = Grammar()
        for dict_attr in (
            "symbol2number",
            "number2symbol",
            "dfas",
            "keywords",
            "tokens",
            "symbol2label",
        ):
            setattr(g, dict_attr, getattr(grammar, dict_attr).copy())
        g.labels = grammar.labels[:]
        g.states = grammar.states[:]
        g.start = grammar.start
        g.async_keywords = False
        return g

    grammar = Grammar()

# Generated at 2022-06-23 15:33:05.432078
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """Test Grammar.dump

    Test that dump + load == Grammar
    """
    g = Grammar()
    g.symbol2number = {"A": 1, "B": 2}
    g.number2symbol = {1: "A", 2: "B"}
    g.states = [[[(1, 0)]]]
    g.dfas = {
        1: (
            [[(1, 0)], [(2, 1)]],
            {0: 0, 1: 1, 2: 1, 3: 1, 4: 1, 5: 1},
        )
    }
    g.labels = [(1, "A"), (2, "B")]
    g.start = 2
    g.keywords = {"A": 1}
    g.tokens = {1: 2}


# Generated at 2022-06-23 15:33:16.930822
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # pylint: disable=import-outside-toplevel
    from . import python_grammar
    # pylint: enable=import-outside-toplevel

    g = python_grammar.pgen_grammar

    class CustomGrammar(Grammar):
        pass  # type: ignore

    g2 = CustomGrammar()
    g2.loads(g.dumps())
    assert g2.keywords == g.keywords

if __name__ == "__main__":
    from . import pgen

    p = pgen.generate_grammar()
    assert isinstance(p, Grammar)

    # mypyc generates objects that don't have a __dict__, but they
    # do have __getstate__ methods that will return an equivalent
    # dictionary

# Generated at 2022-06-23 15:33:21.049195
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()

if __name__ == "__main__":
    from . import main, pgen2

    main(pgen2.generate_grammar_tables)

# Generated at 2022-06-23 15:33:30.676709
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    g.loads(b'\x80\x02cbuiltins\n_collections_abc\n_frozendict\nq\x00)Rq\x01.')


if __name__ == "__main__":
    import unittest

    class TestGrammar(unittest.TestCase):
        def test_Grammar_loads_io_error(self):
            g = Grammar()
            self.assertRaises(OSError, g.load, "/")
            # Tests the try/except block for missing files, although that
            # is probably covered by built-in unit tests, so this may be
            # redundant.

    unittest.main()

# Generated at 2022-06-23 15:33:33.314902
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("Grammar.pickle")
    import pprint
    pprint.pprint(grammar.__dict__)

# Generated at 2022-06-23 15:33:43.530741
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.states = [(1, 2), (3, 4), (5, 6)]
    g.start = "3"
    g.dfas = {"23": ([(1, 2)], {12: 23}), "56": ([(3, 4)], {45: 56})}
    g.number2symbol = {"2": "symbol2", "5": "symbol5"}
    g.symbol2number = {"symbol2": 2, "symbol5": 5}
    g.labels = [(1, "label1"), (2, "label2"), (3, "label3"), (4, "label4")]
    g.tokens = {1: "tokens1", 2: "tokens2"}

# Generated at 2022-06-23 15:33:50.537745
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import pytest
    from typing import cast
    a1 = Grammar()
    a1.test = [1,2,3]
    a2 = Grammar()
    a2.test = [4,5,6]
    a1.labels = a2.labels
    a1.states = a2.states

    # modification of a2 should not modify a1
    for k in a1.__dict__:
        assert a1.__dict__[k] is not a2.__dict__[k], \
            f"a1[{k}] === a2[{k}] a1: {a1.__dict__[k]} a2: {a2.__dict__[k]}"
    a2.test.append(7)
    assert a1.test == [1,2,3]


# Generated at 2022-06-23 15:33:54.614950
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # Just run Grammar.loads method with empty input
    g = Grammar()
    g.loads(b"")


if __name__ == "__main__":
    import sys

    g = Grammar()
    g.load(sys.argv[1])
    g.report()

# Generated at 2022-06-23 15:33:56.242546
# Unit test for method report of class Grammar
def test_Grammar_report():
    from . import parsetok

    g = parsetok.tokenizer()
    g.report()

# Generated at 2022-06-23 15:34:03.483730
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2 import gram1, gram2, gram3

    with tempfile.NamedTemporaryFile() as f:
        gram1.dump(f.name)

        gram2 = Grammar()
        gram2.loads(f.read())
        assert gram1 == gram2

        gram3 = Grammar()
        gram3.load(f.name)
        assert gram1 == gram3

# Generated at 2022-06-23 15:34:08.107052
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Load the builtin grammar
    g = Grammar()
    grammar_pkl = os.path.join(os.path.dirname(__file__), 'Grammar.pkl')
    g.load(grammar_pkl)


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-23 15:34:16.091457
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    d = {
        "symbol2number": {},
        "number2symbol": {},
        "dfas": {},
        "keywords": {},
        "tokens": {},
        "symbol2label": {},
    }
    g1 = Grammar()
    g2 = Grammar()
    g1._update(d)
    g2._update(d)
    assert g1.copy() is not g2
    g3 = g2.copy()
    g3.symbol2number = {}
    assert g2.symbol2number is not {}  # pragma: no cover

# Generated at 2022-06-23 15:34:25.111756
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    g.loads(b'\x80\x03cgrammar\nGrammar\nq\x00)\x81q\x01}q\x02(X\x04\x00\x00\x00dfasq\x03}q\x04(\x88.')
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords == False


# Generated at 2022-06-23 15:34:30.575398
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {'!': 1,  'write': 2, '4': 3, 'a': 4}
    g.number2symbol = {1: '!', 2: 'write', 3: '4', 4: 'a'}
    g.dfas = {1: ({(1, ((1, 1), (2, 1))), (2, ((0, 2), (1, 2)))}, {}), 2: ({(1, ((1, 1), (2, 1))), (2, ((0, 2), (1, 2)))}, {})}
    g.keywords = {'!': 1, 'write': 2}
    g.tokens = {}
    g.symbol2label = {'!': 1, 'write': 2, '4': 3, 'a': 4}

# Generated at 2022-06-23 15:34:33.741295
# Unit test for method load of class Grammar
def test_Grammar_load():
    gp = Grammar()
    gp.load('Grammar.pkl')
    with tempfile.TemporaryFile() as t:
        pickle.dump(gp, t)
        t.seek(0)
        gp2 = pickle.load(t)
    assert gp == gp2

# Generated at 2022-06-23 15:34:35.703075
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()

if __name__ == "__main__":
    test_Grammar()

# Generated at 2022-06-23 15:34:40.747699
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'foo': 10}
    with tempfile.TemporaryDirectory() as tmpdirname:
        g.dump(os.path.join(tmpdirname, "foo"))
        g.load(os.path.join(tmpdirname, "foo"))
        assert g.symbol2number == {'foo': 10}

# Generated at 2022-06-23 15:34:47.770800
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    g1 = Grammar()
    g.loads(g1.dumps())
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords == False


# Generated at 2022-06-23 15:34:52.285824
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle

    tables = Grammar()
    tables.dump("test_Grammar_dump_temp.dat")
    tables2 = pickle.load(open("test_Grammar_dump_temp.dat", "rb"))
    os.remove("test_Grammar_dump_temp.dat")
    assert tables2 == tables
    tables2 = Grammar().copy()
    assert tables2 == tables

# Generated at 2022-06-23 15:34:53.376850
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()

# Generated at 2022-06-23 15:35:02.576488
# Unit test for method load of class Grammar
def test_Grammar_load():
    def t(pkl):
        g = Grammar()
        g.loads(pkl)
        assert g.number2symbol == {256: "file_input"}
        assert g.symbol2number == {"file_input": 256}
        assert g.start == 256


# Generated at 2022-06-23 15:35:12.987704
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen2
    from . import pgen2_convert
    from .driver import Driver

    # test pgen file
    AP = pgen2_convert.PgenConverter(pgen2.tokenize, pgen2.parse)
    driver = Driver(pgen2, pgen2_convert)
    driver.parse_grammar(AP)
    grammar = AP.grammar

    # test Grammar.dump
    with tempfile.TemporaryDirectory() as tmpdir:
        filename = os.path.join(tmpdir, "grammar")
        grammar.dump(filename)

        grammar2 = Grammar()
        grammar2.load(filename)
        assert grammar == grammar2

# Generated at 2022-06-23 15:35:18.306186
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number is not None
    assert g.number2symbol is not None
    assert g.states is not None
    assert g.dfas is not None
    assert g.labels is not None
    assert g.keywords is not None
    assert g.tokens is not None
    assert g.symbol2label is not None
    assert g.start == 256

# Generated at 2022-06-23 15:35:29.505872
# Unit test for method loads of class Grammar

# Generated at 2022-06-23 15:35:39.113294
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    g.symbol2number = {'a': 1, 'b': 2}
    g.number2symbol = {1: 'a', 2: 'b'}
    g.states = [1,2]
    g.dfas = { "a" : (1,1) }
    g.labels = [(0, 1)]
    g.keywords = {'a': 1}
    g.tokens = {1: 1}
    g.symbol2label = {'a': 1}
    g.start = 1
    g.async_keywords = False
    g.copy()
    g.report()

# Generated at 2022-06-23 15:35:50.816747
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    def assert_copy_ok(gram):
        # Assert that gram is a valid Grammar and test copy method
        assert isinstance(gram, Grammar)
        gram_copy = gram.copy()

        # Check shallow copies
        for dict_attr in (
            "symbol2number",
            "number2symbol",
            "dfas",
            "keywords",
            "tokens",
            "symbol2label",
        ):
            dict_orig = getattr(gram, dict_attr)
            dict_copy = getattr(gram_copy, dict_attr)
            assert dict_orig is not dict_copy
            assert dict_orig == dict_copy  # type: ignore

        # Check deep copies
        assert gram.labels is not gram_copy.labels
        assert gram.labels == gram_copy.lab

# Generated at 2022-06-23 15:35:51.886889
# Unit test for method report of class Grammar
def test_Grammar_report():
    """
    Check if Grammar.report can be called without raising exceptions.
    """
    Grammar().report()


# Generated at 2022-06-23 15:35:52.559788
# Unit test for method report of class Grammar
def test_Grammar_report():
    par = Grammar()
    par.report()

# Generated at 2022-06-23 15:35:59.418595
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    class BasicGrammar(Grammar):
        def __init__(self):
            super().__init__()
            self.a = 1
            self.b = "b"
            self.c = True

    g = BasicGrammar()
    g2 = g.copy()
    assert g2.a == 1
    assert g2.b == "b"
    assert g2.c is True  # pylint: disable=g-bool-id-comparison

# Generated at 2022-06-23 15:36:11.610101
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    # Create a grammar, and make a copy.
    gr = Grammar()
    other_gr = gr.copy()
    assert gr.symbol2number == other_gr.symbol2number
    assert gr.number2symbol == other_gr.number2symbol
    assert gr.dfas == other_gr.dfas
    assert gr.keywords == other_gr.keywords
    assert gr.tokens == other_gr.tokens
    assert gr.symbol2label == other_gr.symbol2label
    assert gr.labels == other_gr.labels
    assert gr.states == other_gr.states
    assert gr.start == other_gr.start
    assert gr.async_keywords == other_gr.async_keywords
    # Modify a value, and verify that it only changed in

# Generated at 2022-06-23 15:36:15.542379
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    g.start = "start"
    g.keywords = "keywords"
    g.symbol2number = "symbol2number"
    assert g.start == "start"
    assert g.keywords == "keywords"
    assert g.symbol2number == "symbol2number"

# Generated at 2022-06-23 15:36:27.343546
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.number2symbol = {
        1: "foo",
        2: "bar",
    }
    g.symbol2number = {
        "foo": 1,
        "bar": 2,
    }
    g.states = [
        [
            [
                (1, 2),
                (2, 3),
            ],
            [
                (3, 2),
                (4, 3),
            ],
            [(0, 4)],
        ]
    ]
    g.dfas = {
        1: (g.states[0], {1: 1, 2: 1}),
        2: (g.states[0], {3: 1, 4: 1}),
    }

# Generated at 2022-06-23 15:36:36.270973
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # Initialize grammar
    grammar = Grammar()
    
    # Check that grammar's instance variables are set to expected values
    assert grammar.symbol2number == {}
    assert grammar.number2symbol == {}
    assert grammar.states == []
    assert grammar.dfas == {}
    assert grammar.labels == [(0, "EMPTY")]
    assert grammar.keywords == {}
    assert grammar.tokens == {}
    assert grammar.symbol2label == {}
    assert grammar.start == 256
    assert grammar.async_keywords == False

    # Initialize pkl

# Generated at 2022-06-23 15:36:42.906893
# Unit test for method load of class Grammar
def test_Grammar_load():
    import doctest
    from . import pgen2
    from . import conv
    from . import pgen

    doctest.testmod()
    g = Grammar()
    g.load(pgen.picklefile)
    assert g.start == 256
    assert g.dfas[257][1] == {token.NAME: 1, token.LAMBDA: 1}
    assert g.symbol2number["expr_stmt"] == 261
    assert g.symbol2number["power"] == 275
    assert g.number2symbol[261] == "expr_stmt"
    assert g.number2symbol[275] == "power"
    assert g.labels[257][1] == "python"
    assert g.labels[258][1] == "python2"

# Generated at 2022-06-23 15:36:46.337150
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io
    import sys

    output = io.StringIO()
    try:
        sys.stdout = output
        g = Grammar()
        g.report()
    finally:
        sys.stdout = sys.__stdout__

    assert output.getvalue().startswith("s2n\n{'error'")

if __name__ == "__main__":
    test_Grammar_report()

# Generated at 2022-06-23 15:36:57.051811
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    """Test Grammar.loads"""

    grammar = Grammar()

# Generated at 2022-06-23 15:37:01.469172
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    grammar_bytes = pickle.dumps({'tokens': {}, 'symbol2label': {}, 'labels': [(0, 'EMPTY')], 'start': 256, 'states': [], 'number2symbol': {}, 'dfas': {}, 'keywords': {}, 'symbol2number': {}})
    g.loads(grammar_bytes)

# Generated at 2022-06-23 15:37:10.071746
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import unittest.mock
    # pylint: disable=protected-access
    import pymeta.grammar
    import pymeta.parsing

    # If a pickle file is present (e.g. by having generated it using
    # the 'make' script), then Grammar._read_pgen_grammar will return
    # a copy of it. Otherwise, it will generate it using the pymeta
    # toolchain and save it in the file 'Grammar.pickle.

    with unittest.mock.patch('pymeta.parsing.Grammar._read_pgen_grammar') as mock_read:
        with unittest.mock.patch('pymeta.grammar.Grammar.dump') as mock_dump:
            mock_read.return_value = pymeta.grammar.Gram

# Generated at 2022-06-23 15:37:17.924022
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    h = g.copy()
    assert h.symbol2number == g.symbol2number
    assert h.number2symbol == g.number2symbol
    assert h.dfas == g.dfas
    assert h.keywords == g.keywords
    assert h.tokens == g.tokens
    assert h.symbol2label == g.symbol2label
    assert h.labels == g.labels
    assert h.states == g.states
    assert h.start == g.start
    assert h.async_keywords == g.async_keywords

# Generated at 2022-06-23 15:37:27.734939
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    from pprint import pprint

    g = Grammar()

    def _test(**kwargs: Any) -> None:
        for k, v in kwargs.items():
            setattr(g, k, v)
        with tempfile.NamedTemporaryFile(mode="rb") as f:
            g.dump(f.name)
            g.load(f.name)
            print(k, end=" ")
            pprint(v)
            print(k, end=" ")
            pprint(getattr(g, k))

    _test(symbol2number={"foo": 256, "bar": 257})
    _test(number2symbol={256: "foo", 257: "bar"})
    _test(states=[])

# Generated at 2022-06-23 15:37:37.709990
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g1.symbol2number = {'asap': 1}
    g1.number2symbol = {1: "asap"}
    g1.dfas = {1: ([(1, 2), (1, 3)], {1: 1})}
    g1.keywords = {'asap': 1}
    g1.tokens = {1: 2}
    g1.symbol2label = {'asap': 1}
    g1.labels = [(1, 'asap')]
    g1.states = [[(1, 2), (1, 3)]]
    g1.start = 256
    g1.async_keywords = False

    g2 = g1.copy()

    assert g2.symbol2number == g1.symbol2number

# Generated at 2022-06-23 15:37:49.906810
# Unit test for method report of class Grammar
def test_Grammar_report():
    from io import StringIO
    from pprint import pprint

    # Note:  An empty set isn't valid JSON, so use a list instead
    g = Grammar()
    g.symbol2number = {"foo": 10, "bar": 20}
    g.number2symbol = {10: "foo", 20: "bar"}
    g.start = 10

# Generated at 2022-06-23 15:38:01.906515
# Unit test for constructor of class Grammar
def test_Grammar():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    from io import StringIO
    from unittest.mock import patch
    from .pgen2 import tokenize

    class DummyTokenizer:

        def __init__(self, readline):
            self.readline = readline
            self.fd = StringIO()

        def __iter__(self):
            return self

        def __next__(self):
            return next(tokenize(self.readline))
    g = Grammar()
    with patch("io.StringIO", StringIO), patch("io.StringIO"):
        tokenizer = DummyTokenizer(g.readline)
        g.__init__(tokenizer)

# Generated at 2022-06-23 15:38:07.975774
# Unit test for method report of class Grammar
def test_Grammar_report():
    from .pgen2 import driver
    from .tokenize import generate_tokens, untokenize

    source = """
if 0: pass
elif 1: pass
else: pass
"""

    g = driver.load_grammar("Grammar/Grammar", "Grammar/Tokens", debug=False)
    tokens = list(generate_tokens(source.splitlines))
    tokens.append((token.ENDMARKER, ""))
    tokens.append((token.ERRORTOKEN, ""))

    # fixup python 3.x _tokenize_lines behaviour
    if tokens[-1][:2] == (token.ENDMARKER, ""):
        del tokens[-1]

    driver.parse_tokens(tokens, g, debug=False)
    root = driver.ast_parse

# Generated at 2022-06-23 15:38:13.775400
# Unit test for method load of class Grammar
def test_Grammar_load():
    g1 = Grammar()
    g1.symbol2number["a"] = 1
    g1.dump("test.pkl")
    g2 = Grammar()
    g2.load("test.pkl")
    assert g1.symbol2number == g2.symbol2number
    assert g1.number2symbol == g2.number2symbol
    assert g1.states == g2.states
    assert g1.dfas == g2.dfas
    assert g1.labels == g2.labels
    assert g1.keywords == g2.keywords
    assert g1.tokens == g2.tokens
    assert g1.symbol2label == g2.symbol2label
    assert g1.start == g2.start
    assert g1.async_key

# Generated at 2022-06-23 15:38:20.632664
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    for i in range(1, 6):
        print("Load grammar tables version: ", i)
        path = os.path.join(os.path.dirname(__file__), f"Grammar.pkl{i}")
        with open(path, "rb") as f:
            pkl = f.read()
        g = Grammar()
        g.loads(pkl)
        assert g.number2symbol[257] == "single_input"



# Generated at 2022-06-23 15:38:28.333277
# Unit test for method report of class Grammar
def test_Grammar_report():
    import sys
    import monty.utilities
    import pytest
    import textwrap
    from unittest.mock import MagicMock
    import io

    g = Grammar()
    # We use mock_stdout_open to capture the output printed by the
    # report method.  See comment in monty_stdout_open in
    # monty.utilities for more information.
    with monty.utilities.mock_stdout_open() as stdout_mock:
        g.report()
        out = stdout_mock.getvalue()

    # Build the expected output and check it against the actual.

# Generated at 2022-06-23 15:38:40.544348
# Unit test for method report of class Grammar
def test_Grammar_report():
    # Create a "source grammar" with a single non-terminal symbol:
    # start -> a | b
    symbol2number = {"start": 256}
    number2symbol = {256: "start"}
    start = 256
    tokens = {1: 0, 2: 1}
    labels = [(0, "EMPTY"), (1, None), (2, None)]
    dfas = {
        256: (
            [
                [(2, 1), (2, 2)],
                [(0, 1)],
                [(0, 2)],
            ],
            {1: 1, 2: 1},
        )
    }
    states = [
        [
            [(2, 1), (2, 2)],
            [(0, 1)],
            [(0, 2)],
        ]
    ]

# Generated at 2022-06-23 15:38:45.900692
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2 import driver

    g = driver.load_grammar(os.path.join(os.path.dirname(__file__), "Grammar.txt"))
    g.dump("/tmp/Grammar.pickle")


if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-23 15:38:52.294188
# Unit test for method load of class Grammar
def test_Grammar_load():
    import io

    sys = io.StringIO()
    sys.close = lambda: 0
    sys.encoding = 'utf8'
    old_stdout = sys.stdout
    sys.stdout = sys
    try:
        grammar = Grammar()
        grammar.load(os.path.join(os.path.dirname(__file__),
                                  'Grammar.pkl'))
        grammar.report()
    finally:
        sys.stdout = old_stdout
        print(sys.getvalue())


# Generated at 2022-06-23 15:39:00.086850
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()
    g.symbol2number = {'foo': 256, 'bar': 257}
    g.number2symbol = {'256': 'foo', '257': 'bar'}
    g.states = [[[(0, 0), (0, 1)]], [[(0, 0), (0, 1)]]]
    g.dfas = {256: ([[(0, 0), (1, 1)]], {0: 1}), 257: ([[(0, 0), (0, 1)]], {1: 1})}
    g.labels = [(1, 'foo'), (2, None)]
    g.keywords = {'foo': 0, 'bar': 1}
    g.tokens = {1: 0, 2: 1}

# Generated at 2022-06-23 15:39:05.536116
# Unit test for method report of class Grammar

# Generated at 2022-06-23 15:39:16.044616
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {'a': 1}
    g.number2symbol = {2: 'b'}
    g.dfas = {3: 'a'}
    g.keywords = {'c': 4}
    g.tokens = {5: 'd'}
    g.symbol2label = {'e': 6}
    g.labels = [('f', 'g')]
    g.states = [('h', 'i')]
    g.start = 'j'
    g.async_keywords = 'k'

    h = g.copy()

    for dict_attr in ('symbol2number', 'number2symbol', 'dfas', 'keywords',
                      'tokens', 'symbol2label'):
        assert getattr

# Generated at 2022-06-23 15:39:22.966146
# Unit test for method report of class Grammar
def test_Grammar_report():
    import pytest
    from io import StringIO
    from contextlib import redirect_stdout

    g = Grammar()
    f = StringIO()
    with redirect_stdout(f):
        g.report()
    s = f.getvalue()
    assert 's2n' in s
    assert 'n2s' in s
    assert 'states' in s
    assert 'dfas' in s
    assert 'labels' in s
    assert 'start' in s

# Generated at 2022-06-23 15:39:24.137881
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load('./graminit.pickle')
    assert len(g.symbol2number) > 0

# Generated at 2022-06-23 15:39:25.596722
# Unit test for method report of class Grammar
def test_Grammar_report():
    """Test Grammar.report method."""
    # XXX Need to test this properly
    g = Grammar()
    g.report()

del _P, opmap_raw

# Generated at 2022-06-23 15:39:30.245783
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.symbols = {}
    grammar.keywords = {}
    grammar.tokens = {}
    grammar.start = 8
    grammar.states = []
    grammar.dfas = {}
    grammar.labels = []
    grammar.symbol2label = {}
    grammar.add_nonterminal('foo')
    grammar.add_terminal(257, 'bar')
    with open('temp.pickle', 'wb') as f:
        grammar.dump(f)
    grammar2 = Grammar()
    with open('temp.pickle', 'rb') as f:
        grammar2.load(f)
    assert grammar.symbols == grammar2.symbols
    assert grammar.keywords == grammar2.keywords
    assert grammar.tokens == grammar2.tokens


# Generated at 2022-06-23 15:39:42.412542
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g1.symbol2number = {"01" : 1}
    g1.number2symbol = {1 : "01"}
    g1.labels = [(1, "test")]
    g1.states = [1]
    g1.dfas = {1 : 1}
    g1.keywords = {"01" : 1}
    g1.tokens = {1 : 1}
    g1.symbol2label = {"01" : 1}
    g1.start = 1
    g1.async_keywords = True

    g2 = g1.copy()
    assert g1.symbol2number == g2.symbol2number
    assert g1.number2symbol == g2.number2symbol

# Generated at 2022-06-23 15:39:50.621145
# Unit test for constructor of class Grammar
def test_Grammar():
    obj = Grammar()
    assert hasattr(obj, "symbol2number")
    assert hasattr(obj, "number2symbol")
    assert hasattr(obj, "states")
    assert hasattr(obj, "dfas")
    assert hasattr(obj, "labels")
    assert hasattr(obj, "keywords")
    assert hasattr(obj, "tokens")
    assert hasattr(obj, "symbol2label")
    assert hasattr(obj, "start")
    assert hasattr(obj, "async_keywords")



# Generated at 2022-06-23 15:40:03.200675
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    mypy = Grammar()
    mypy.symbol2number = {'ARROW' : 256}
    mypy.number2symbol = {256 : 'ARROW'}
    mypy.dfas = {256 : ([], {})}
    mypy.keywords = {'ARROW' : 1}
    mypy.tokens = {256 : 1}
    mypy.symbol2label = {'ARROW' : 1}
    mypy.labels = [(256, 'ARROW')]
    mypy.states = [([], {})]
    mypy.start = 256
    mypy.async_keywords = False
    new = mypy.copy()
    assert new.symbol2number == {'ARROW' : 256}
    assert new.number2symbol == {256 : 'ARROW'}

# Generated at 2022-06-23 15:40:05.311219
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()
