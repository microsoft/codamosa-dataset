

# Generated at 2022-06-23 15:30:15.732191
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    from .pgen2 import driver
    g = driver.load_grammar("../Modules/_ast.txt")
    g2 = g.copy()
    import pickle
    data = pickle.dumps(g)
    g3 = pickle.loads(data)
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.symbol2label == g2.symbol2label
    assert g.dfas == g2.dfas
    assert g.states == g2.states
    assert g.labels == g2.labels
    assert g.start == g2.start
    assert g2.start == g3.start
    assert g.async_keywords == g2.async_keywords
    assert g

# Generated at 2022-06-23 15:30:20.808178
# Unit test for constructor of class Grammar
def test_Grammar():
    assert Grammar()
    # assert Grammar(1)
    # assert Grammar(1, 2)
    # assert Grammar(1, 2, 3)
    # assert Grammar(1, 2, 3, 4)


if __name__ == "__main__":
    g = Grammar()
    g.report()

# Generated at 2022-06-23 15:30:30.956996
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import pgen2.grammar as grammar
    import pgen2.tokenize as tokenize
    filename = "Grammar.txt"
    g = grammar.Grammar(grammar.grammar)
    g.dump(filename)

    g2 = grammar.Grammar()
    g2.load(filename)
    g3 = g2.copy()
    f = open("Grammar.txt", "rb")
    bytes_g = f.read()
    f.close()
    g3.loads(bytes_g)

    # Add a key 'add' to symbol2number of g
    dict_symbol2number = g.symbol2number
    dict_symbol2number["add"] = 34
    # Add a key '34' to number2symbol of g

# Generated at 2022-06-23 15:30:35.522295
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump(filename="test")
    grammar.loads(pkl=b"")
    grammar.load(filename="test")
    grammar.report()


if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-23 15:30:38.892204
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io
    import sys

    output = io.StringIO()
    g = Grammar()
    g.report()
    value = output.getvalue()
    assert len(value) > 0

# Generated at 2022-06-23 15:30:48.324651
# Unit test for method loads of class Grammar

# Generated at 2022-06-23 15:30:56.371047
# Unit test for method report of class Grammar
def test_Grammar_report():
    def _get_globals() -> Dict[str, Any]:
        # The code written by Grammar.report() is a bit fragile due to
        # the name mangling it uses
        g = globals()
        g.update(grammar.__dict__)
        del g["_test_Grammar_report"]
        return g

    # Create an instance of Grammar, and add some entries
    grammar = Grammar()
    grammar.symbol2number = {"foo": 42}
    grammar.number2symbol = {42: "foo"}
    grammar.states = [[]]
    grammar.dfas = {1: (grammar.states[0], {})}
    grammar.labels = [(0, "EMPTY")]
    grammar.start = 256
    grammar.async_keywords = False

    # Print the tables

# Generated at 2022-06-23 15:31:00.182356
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io
    import unittest
    import contextlib
    buff = io.StringIO()
    with contextlib.redirect_stdout(buff):
        g = Grammar()
        s = g.report()
    assert s == None

# Generated at 2022-06-23 15:31:04.366808
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    from io import BytesIO

    s = BytesIO()
    data = {"a": "asdf"}
    pickle.dump(data, s)
    s.seek(0)
    g = Grammar()
    g.loads(s.read())
    assert g.a == "asdf"

# Generated at 2022-06-23 15:31:17.104513
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    from . import pgen2
    from . import conv
    parser_gen = pgen2.Driver()
    grammar = conv.convert_grammar(parser_gen.grammar)
    grammar.lines = 2
    copied_grammar = grammar.copy()
    assert copied_grammar == grammar
    assert copied_grammar.start == grammar.start
    assert copied_grammar.symbol2label == grammar.symbol2label
    assert copied_grammar.tokens == grammar.tokens
    assert grammar.keywords is not copied_grammar.keywords
    assert grammar.keywords == copied_grammar.keywords
    assert grammar.dfas is not copied_grammar.dfas
    assert grammar.dfas == copied_grammar.dfas
    assert grammar.labels is not copied_grammar.labels


# Generated at 2022-06-23 15:31:28.611680
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    s = Grammar()
    a = {'symbol2number': {'some_symbol': 1},
         'number2symbol': {1: 'some_symbol'},
         'states': [],
         'dfas': {1: ([], {})},
         'labels': [],
         'keywords': {},
         'tokens': {},
         'symbol2label': {},
         'start': 1,
         'async_keywords': False
         }
    s.loads(pickle.dumps(a))
    assert s.symbol2number == a['symbol2number']
    assert s.number2symbol == a['number2symbol']
    assert s.states == a['states']
    assert s.dfas == a['dfas']
    assert s.labels

# Generated at 2022-06-23 15:31:36.747535
# Unit test for method load of class Grammar
def test_Grammar_load():
    # test method load of class Grammar
    # pickle loads
    _path = os.path.dirname(__file__)
    _test_base = "Python"
    _test_pyversion = sys.version_info[:2]
    if sys.version_info[0] == 2:
        _test_pyversion = repr(_test_pyversion).strip("()").replace(", ", ".")
    _test_name = "%s.%s.%s.pkl" % (_test_base, _test_pyversion, os.name)
    _test_path = os.path.join(_path, _test_name)
    Grammar().load(_test_path)


# Generated at 2022-06-23 15:31:40.663425
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.start = "spam"
    s = pickle.dumps(g)
    h = Grammar()
    h.load(io.BytesIO(s))
    assert g.start == h.start

# Generated at 2022-06-23 15:31:49.596619
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    from . import conv
    from . import pgen

    # Load the grammar from the .asdl file
    c = conv.Converter("Python.asdl")
    c.gen()

    # Write the grammar to a pickle file
    pkl_file = "Python.pkl"
    g = pgen.Pgen(c.grammar, "Python.asdl")
    g.init()
    g.dump(pkl_file)

    # Read the pickle file back into a new grammar
    with open(pkl_file, "rb") as f:
        pkl = f.read()
    g2 = Grammar()
    g2.loads(pkl)

# Generated at 2022-06-23 15:31:52.530809
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("Grammar.pkl")

if __name__ == "__main__":
    grammar = Grammar()
    grammar.load("Grammar.pkl")

# Generated at 2022-06-23 15:31:55.321327
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickletools

    g = Grammar()
    g.loads(pickletools.optimize(pickle.dumps(g.__dict__, pickle.HIGHEST_PROTOCOL)))

# Generated at 2022-06-23 15:31:59.447625
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    class TestGrammar:
        symbol2number = {}
        number2symbol = {}
        states = []
        dfas = {}
        labels = []
        keywords = {}
        tokens = {}
        symbol2label = {}
        start = 0

    g = Grammar()
    g.symbol2number = {"SYMBOL2NUMBER": 1234}
    g.number2symbol = {1234: "NUMBER2SYMBOL"}
    g.states = [["STATE1"], ["STATE2"]]
    g.dfas = {"DFA": ("DFA", {"DFA_FIRST": 1})}
    g.labels = [("LABEL1", None), ("LABEL2", "LABEL2_TEXT")]
    g.keywords = {"KEYWORD1": "KEYWORD1_VALUE"}


# Generated at 2022-06-23 15:32:07.030386
# Unit test for constructor of class Grammar
def test_Grammar():
    import pickle
    import io
    g = Grammar()
    g.symbol2number = {
        "foo": 42,
    }
    g.number2symbol = {
        84: "bar",
    }
    g.states = [
        [
            [(0, 1), (1, 2)],
            [],
            [(0, 0)],
        ],
    ]
    g.dfas = {
        256: ([], {}),
    }
    g.labels = [(0, "foo"), (1, "bar"), (2, "baz")]
    g.tokens = {
        0: 0,
    }
    g.keywords = {
        "foo": 1,
    }
    g.symbol2label = {
        "foo": 0,
    }


# Generated at 2022-06-23 15:32:17.953391
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    class MyGrammar(Grammar):
        def __init__(self) -> None:
            self.a = "abc"
            self.b = ["abc", "def"]
            self.c = {"a": "abc", "b": "def"}

    mg = MyGrammar()
    mg.a = "123"
    mg.b.append("ghi")
    mg.c.update(c="ghi")

    mg_copy = mg.copy()

    assert mg_copy.a == "123"
    assert mg_copy.b == ["abc", "def", "ghi"]
    assert mg_copy.c == {"a": "abc", "b": "def", "c": "ghi"}

    mg_copy.a = "000"
    assert mg_copy.a == "000"

# Generated at 2022-06-23 15:32:25.782661
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest

    class FauxPickle(object):
        def __init__(self, *args, **kwargs):
            pass

        def load(self):
            return {"a": 1}

    class TestCase(unittest.TestCase):
        def test_Grammar_load(self):
            g = Grammar()
            g.load = FauxPickle
            g.load('')
            self.assertEqual(g.a, 1)

    unittest.main()


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-23 15:32:28.429552
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    testgrammar = r"""cos\nsystem\n(S'ls'\ntRp3\n."""
    grammar = Grammar()
    grammar.loads(testgrammar.encode("latin1"))
    assert grammar.symbol2number == {"system": 257}
    assert grammar.number2symbol == {257: "system"}
    assert grammar.start == 256

# Generated at 2022-06-23 15:32:37.292204
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    a = Grammar()
    b = a.copy()
    assert a is not b
    for name, value in a.__dict__.items():
        if name not in ("states", "labels"):
            assert value is getattr(b, name)
    assert a.states is not b.states
    assert a.labels is not b.labels
    for a_value, b_value in zip(a.states, b.states):
        assert a_value is not b_value
    for a_value, b_value in zip(a.labels, b.labels):
        assert a_value is not b_value

# Generated at 2022-06-23 15:32:43.915614
# Unit test for method report of class Grammar
def test_Grammar_report():
    # This is not a real unit test, but an example of how to use the
    # method Grammar.report() for debugging the grammar tables
    for version in ["2.4", "2.5", "2.6", "2.7"]:
        print('=' * 70)
        print(version)
        from .pgen2 import driver

        g = driver.load_grammar(version)
        g.report()


__all__ = ["Grammar", "test_Grammar_report"]

# Generated at 2022-06-23 15:32:49.924494
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    def t():
        grammar = Grammar()
        assert grammar.symbol2number == {}
        assert grammar.number2symbol == {}
        assert grammar.states == []
        assert grammar.dfas == {}
        assert grammar.labels == [(0, "EMPTY")]
        assert grammar.keywords == {}
        assert grammar.tokens == {}
        assert grammar.symbol2label == {}
        assert grammar.start == 256
        assert grammar.async_keywords == False
    t()
    orig = Grammar()
    orig.keywords = {"foo": 1}
    orig.symbol2number["bar"] = 1
    orig.symbol2label["bar"] = 2
    orig.tokens = {"foo": 3}
    orig.number2symbol = {"foo": "bar"}
    orig.dfas

# Generated at 2022-06-23 15:32:55.518537
# Unit test for constructor of class Grammar
def test_Grammar():
    grammar = Grammar()
    assert grammar.symbol2number == {}
    assert grammar.number2symbol == {}
    assert grammar.states == []
    assert grammar.dfas == {}
    assert grammar.labels == [(0, "EMPTY")]
    assert grammar.keywords == {}
    assert grammar.tokens == {}
    assert grammar.symbol2label == {}
    assert grammar.start == 256


# Generated at 2022-06-23 15:32:58.843294
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    class MyGrammar(Grammar):
        pass

    # use a different encoding so that the test works on Windows
    grammar = MyGrammar()
    grammar.load(__file__.encode("mbcs"))

# Generated at 2022-06-23 15:33:01.688243
# Unit test for method load of class Grammar
def test_Grammar_load():
    class C(Grammar):
        pass

    filename = "/tmp/Grammar_load"
    C().dump(filename)
    x = C()
    x.load(filename)
    x.loads(open(filename, "rb").read())

# Generated at 2022-06-23 15:33:08.470293
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g1.symbol2number = {
        "STORE_NAME": 258,
    }
    g1.number2symbol = {
        258: "STORE_NAME",
    }

# Generated at 2022-06-23 15:33:18.128138
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    grammar = Grammar()
    new_grammar = grammar.copy()
    for dict_attr in (
        "symbol2number",
        "number2symbol",
        "dfas",
        "keywords",
        "tokens",
        "symbol2label",
    ):
        # pylint: disable=unidiomatic-typecheck
        assert type(getattr(grammar, dict_attr)) is type(getattr(new_grammar, dict_attr))
    assert grammar.labels == new_grammar.labels
    assert grammar.states == new_grammar.states
    assert grammar.start == new_grammar.start
    assert grammar.async_keywords == new_grammar.async_keywords

# Generated at 2022-06-23 15:33:29.084881
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io
    import unittest.mock

    g = Grammar()
    g.labels = [('a','a'), ('b','b')]
    g.symbol2number = {'a': 1, 'b': 2}
    g.number2symbol = {1: 'a', 2: 'b'}
    g.states = [[('a', 'b')], [('b', 'a')]]
    g.dfas = {1: ([('a', 'b')], {'a': 1}), 2: ([('b', 'a')], {'b': 1})}
    g.keywords = {'a': 1, 'b': 2}
    g.tokens = {1: 'a', 2: 'b'}

# Generated at 2022-06-23 15:33:39.311280
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-23 15:33:45.715420
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number is None
    assert g.number2symbol is None
    assert g.states is None
    assert g.dfas is None
    assert g.labels is None
    assert g.keywords is None
    assert g.tokens is None
    assert g.symbol2label is None
    assert g.start is None
    assert not g.async_keywords

# Generated at 2022-06-23 15:33:51.658396
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .conv import CoverParseTable

    gr = Grammar()
    gr.load("Grammar.pkl")
    assert gr.start == 257
    assert gr.number2symbol[258] == "funcdef"
    gr = Grammar()
    gr.load("Grammar3.pkl")
    assert gr.start == 257
    assert gr.number2symbol[258] == "funcdef"

# Generated at 2022-06-23 15:33:56.368749
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.start = 256
    g.number2symbol = {256: "sometestthing"}
    g.dump("test_Grammar.dump")
    g.load("test_Grammar.dump")
    assert g.start == 256
    assert g.number2symbol == {256: "sometestthing"}

# Generated at 2022-06-23 15:33:57.812094
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("filename")

# Generated at 2022-06-23 15:34:08.970307
# Unit test for method load of class Grammar
def test_Grammar_load():

    def assert_all_files_exist(
        filenames: List[Path], *, cwd: str = os.path.dirname(__file__)
    ) -> None:
        for filename in filenames:
            assert os.path.isfile(os.path.join(cwd, filename)), filename

    # check if old pickle files still exist
    assert_all_files_exist(
        [
            "Grammar.pickle",
            "Grammar3.pickle",
            "Grammar38.pickle",
            "Grammar39.pickle",
            "Grammar2_7.pickle",
        ]
    )

    grammars = []

    # load pickle files and check if they are readable

# Generated at 2022-06-23 15:34:10.075300
# Unit test for method load of class Grammar
def test_Grammar_load():
    gr = Grammar()
    gr.number2symbol = {0: "test"}
    assert gr.number2symbol == {0: "test"}

# Generated at 2022-06-23 15:34:19.353792
# Unit test for constructor of class Grammar
def test_Grammar():
    # Test all the variables in Grammar
    grammar = Grammar()
    assert isinstance(grammar, Grammar)
    assert isinstance(grammar.symbol2number, dict)
    assert isinstance(grammar.number2symbol, dict)
    assert isinstance(grammar.states, list)
    assert isinstance(grammar.dfas, dict)
    assert isinstance(grammar.labels, list)
    assert isinstance(grammar.keywords, dict)
    assert isinstance(grammar.tokens, dict)
    assert isinstance(grammar.symbol2label, dict)
    assert isinstance(grammar.start, int)
    assert isinstance(grammar.async_keywords, bool)

# Generated at 2022-06-23 15:34:24.718262
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}



# Generated at 2022-06-23 15:34:32.139771
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    d = g.__getstate__()
    d2 = {
        'symbol2number': {},
        'number2symbol': {},
        'states': [],
        'dfas': {},
        'labels': [],
        'keywords': {},
        'tokens': {},
        'symbol2label': {},
        'start': 256
    }
    assert d == d2

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-23 15:34:33.847966
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump('/tmp/python-grammar.pickle')

# Generated at 2022-06-23 15:34:37.435004
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import conv

    path = conv.generate_grammar_pickle("2.7")
    g = Grammar()
    g.load(path)

    assert g.number2symbol[0] == "EMPTY"

# Generated at 2022-06-23 15:34:44.833616
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    filename = 'a.pickle'
    g.dump(filename)
    g2 = Grammar()
    g2.load(filename)
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label
    assert g.start == g2.start
    assert g.async_keywords == g2.async_keywords

# Generated at 2022-06-23 15:34:52.971900
# Unit test for method load of class Grammar
def test_Grammar_load():
    from types import SimpleNamespace
    from io import BytesIO
    from .tokenize import generate_tokens
    from .parse import Parser
    # Generate a grammar
    def f(g: Grammar) -> None:
        g.symbol2number = {"a": 256, "b": 257}
        g.number2symbol = {256: "a", 257: "b"}
        g.states = [
            [("EMPTY", -1)],
            [("a", 1), ("EMPTY", -1)],
            [("b", 2), ("EMPTY", -1)],
            [("EMPTY", -1)],
            [("EMPTY", -1)],
        ]

# Generated at 2022-06-23 15:34:53.925710
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()

# Generated at 2022-06-23 15:34:58.770500
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    input = [(0, 1), (1, 0)]
    g = Grammar()
    g.states = [input]
    f = tempfile.NamedTemporaryFile(delete=False)
    g.dump(f.name)
    f.close()
    with open(f.name, "rb") as f:
        output = pickle.load(f)
    try:
        os.remove(f.name)
    except OSError:
        pass
    assert output["states"] == [(0, 1), (1, 0)]

# Generated at 2022-06-23 15:35:02.664651
# Unit test for constructor of class Grammar
def test_Grammar():
    _grammar = Grammar()
    assert isinstance(_grammar, Grammar)


# Generated at 2022-06-23 15:35:14.803544
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import io
    import unittest
    import pickle

    if sys.version_info < (3, 4):
        import unittest.mock as mock
    else:
        import unittest.mock as mock

    class FakeSyntaxError(object):
        def __init__(self, msg):
            self.args = (msg,)

    class Test_Grammar(unittest.TestCase):
        def test_load(self):
            with mock.patch('builtins.open', return_value=io.BytesIO()):
                with mock.patch(
                    'pickle.load',
                    side_effect = FakeSyntaxError(
                        'Invalid pickle data for grammar tables'
                    )
                ):
                    g = Grammar()

# Generated at 2022-06-23 15:35:25.594524
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g1.symbol2number = {"or": 256}
    g1.number2symbol = {256: "or"}
    g1.dfas = {256: (1, 2)}
    g1.keywords = {"or": 0}
    g1.tokens = {1: 2}
    g1.symbol2label = {"or": 1}
    g1.labels = [("1", "2")]
    g1.states = [1]
    g1.start = 256
    g1.async_keywords = True
    g2 = g1.copy()
    assert g1.symbol2number["or"] is 256
    assert g1.number2symbol[256] is "or"

# Generated at 2022-06-23 15:35:27.969547
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()


if __name__ == "__main__":
    test_Grammar_report()

# Generated at 2022-06-23 15:35:39.375794
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'STMT': 1}
    g.number2symbol = {1: 'STMT'}
    g.states = [[(0, 0), (1, 1), (2, 2)]]
    g.dfas = {1: ([[(0, 0), (1, 1), (2, 2)]], {1: 1, 2: 2})}
    g.labels = [(0, 'EMPTY'), (1, 'STMT'), (2, 'COLON')]
    g.keywords = {'STMT': 1}
    g.tokens = {2: 2}
    g.symbol2label = {'STMT': 1}
    g.start = 1
    g.async_keywords = False

# Generated at 2022-06-23 15:35:40.646012
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("foo")
    g.dump("bar")

# Generated at 2022-06-23 15:35:47.225371
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Unit test for method load of class Grammar."""
    from .pgen2 import driver

    grammar = Grammar()
    driver.generate_grammar("Grammar.test_load")
    grammar.loads(driver.pickle_grammar("Grammar.test_load"))
    grammar.report()


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-23 15:35:58.272724
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    """This unit test checks that the method 'loads' of class Grammar
    works correctly.
    """
    g = Grammar()
    DFA = [[(256, 257), (-1, -1)], [(258, 258), (-1, -1)]]
    labels = [(0, "EMPTY"), (256, "SYM"), (258, "SYM")]
    d = {
        "symbol2number": {"SYM": 256, "SYM2": 258},
        "number2symbol": {256: "SYM", 258: "SYM2"},
        "states": [DFA],
        "dfas": {256: (DFA, {258: 1})},
        "labels": labels,
        "start": 256,
    }
    g.loads(pickle.dumps(d))
    assert g

# Generated at 2022-06-23 15:36:10.884739
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    state = [
        [
            (1, 1),
            (2, 2),
        ],
        [
            (3, 1),
            (4, 2),
        ],
    ]
    g = Grammar()
    g.states = [state]
    g.dfas = {"foo": (state, {1: 1, 2: 1, 3: 1, 4: 1})}
    g.symbol2number["foo"] = 1
    g.number2symbol[1] = "foo"
    g.keywords = {"async": 1, "foo": 2}
    g.labels = [(1, "foo"), (1, "async"), (2, "foo")]
    g.tokens = {"NAME": 1, "LPAR": 2}
    g.async_keywords = True
   

# Generated at 2022-06-23 15:36:19.806135
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    from .pgen2 import tokenize

    p = tokenize.generate_grammar()
    q = p.copy()
    assert p.labels == q.labels
    assert p.labels is not q.labels
    assert p.states == q.states
    assert p.states is not q.states
    assert p.keywords == q.keywords
    assert p.keywords is not q.keywords
    assert p.tokens == q.tokens
    assert p.tokens is not q.tokens
    assert p.symbol2label == q.symbol2label
    assert p.symbol2label is not q.symbol2label

# Generated at 2022-06-23 15:36:30.531152
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g1.symbol2number["foo"] = 1
    g1.number2symbol[2] = "bar"
    g1.keywords["k1"] = 1
    g1.keywords["k2"] = 2
    g1.tokens[3] = 3
    g1.tokens[4] = 4
    g1.tokens[5] = 5
    g1.labels[:0] = [('foo', 'bar')]
    g1.states[:0] = [1, 2, 3, 4]
    g1.dfas[1] = (1, {2:1})
    g1.dfas[2] = (2, {3:1})
    g1.start = 3

# Generated at 2022-06-23 15:36:38.669747
# Unit test for method loads of class Grammar

# Generated at 2022-06-23 15:36:49.669465
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    try:
        import rpython.rlib.rpickle as rpickle
    except ImportError:
        import pickle as rpickle


# Generated at 2022-06-23 15:36:59.567514
# Unit test for method report of class Grammar
def test_Grammar_report():
    import unittest

    g = Grammar()
    g.symbol2number = {'symbol': 1}
    g.number2symbol = {1: 'symbol'}
    g.states = [[1, 2], [3, 4], [5, 6]]
    g.dfas = {'dfa': (g.states[0], {1:1, 2:1})}
    g.labels = [(0, "EMPTY"), (1, None), (2, None), (3, "id"), (4, "id")]
    g.keywords = {'def': 3, 'id': 4}
    g.tokens = {token.NEWLINE:1}
    g.start = 256
    g.async_keywords = False


# Generated at 2022-06-23 15:37:10.581801
# Unit test for method load of class Grammar
def test_Grammar_load():
    import io, unittest
    class LoadTests(unittest.TestCase):
        def test_load(self):
            global Grammar
            if Grammar.__module__ == '__main__':
                import grammar
                Grammar = grammar.Grammar
            g = Grammar()

# Generated at 2022-06-23 15:37:12.256586
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()

if __name__ == "__main__":
    test_Grammar()

# Generated at 2022-06-23 15:37:21.717007
# Unit test for method report of class Grammar
def test_Grammar_report():
    """This is a test for the method report() of class Grammar."""
    from StringIO import StringIO as StringIO2
    from sys import stdout
    from token import NAME, NUMBER

    g = Grammar()
    g.symbol2number = {
        "<name>": 256,
        "<epsilon>": 257,
        "<number>": 258,
        "<expr>": 259,
        "<term>": 260,
        "<factor>": 261,
        "<unit>": 262,
    }
    g.number2symbol = {
        256: "<name>",
        257: "<epsilon>",
        258: "<number>",
        259: "<expr>",
        260: "<term>",
        261: "<factor>",
        262: "<unit>",
    }
    g.states

# Generated at 2022-06-23 15:37:29.482537
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-23 15:37:31.786726
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump('')


if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-23 15:37:32.412478
# Unit test for method report of class Grammar
def test_Grammar_report():
    pass

# Generated at 2022-06-23 15:37:35.156833
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    pkl = b'\x80\x03cpychecker.checker\nGrammar\nq\x00)\x81q\x01.'
    g = Grammar()
    g.loads(pkl)

# Generated at 2022-06-23 15:37:39.822762
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    g.start = 257
    assert g.start == 257


# Generated at 2022-06-23 15:37:51.397578
# Unit test for method loads of class Grammar
def test_Grammar_loads():

    class MyGrammar(Grammar):
        def __init__(self) -> None:
            super().__init__()

    my_grammar = MyGrammar()
    # This is not a complete grammar, but it's all we need for the unit test.
    # flake8: noqa

# Generated at 2022-06-23 15:38:02.071577
# Unit test for method load of class Grammar
def test_Grammar_load():
    # pylint: disable=produces-namespace-packages
    import unittest
    import pickle

    class TestGrammar(unittest.TestCase):
        def test_str(self):
            filename = "test_str.pkl"
            self.g.dump(filename)
            g2 = Grammar()
            g2.load(filename)
            s = str(g2)
            self.assertIsInstance(s, str)
            self.assertEqual(s, str(self.g))

        def test_bytes(self):
            self.g.dump("test_bytes.pkl")
            g2 = Grammar()
            g2.load("test_bytes.pkl")
            b = bytes(g2)
            self.assertIsInstance(b, bytes)
            self.assertE

# Generated at 2022-06-23 15:38:05.717272
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()

    try:
        grammar.load(__file__)
    except FileNotFoundError:
        assert False
    except pickle.UnpicklingError:
        assert True
    else:
        assert False

# Generated at 2022-06-23 15:38:15.126567
# Unit test for method report of class Grammar
def test_Grammar_report():
    from io import StringIO
    import sys

    saved_stdout = sys.stdout
    try:
        out = StringIO()
        sys.stdout = out

        g = Grammar()
        g.report()

        output = out.getvalue().strip()
    finally:
        sys.stdout = saved_stdout

    # find the returned output's last two lines and compare
    lines = output.split("\n")
    assert lines[-2] == "n2s {256: 'start'}"
    assert lines[-1] == "start 256"

# Generated at 2022-06-23 15:38:20.252036
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import shutil
    import importlib
    m = importlib.import_module(__package__ + '.conv')
    m = getattr(m, 'Grammar')
    m = m()
    filename = "test"
    m.dump(filename)
    m.load(filename)
    shutil.rmtree(filename)

# Generated at 2022-06-23 15:38:25.063073
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256

# Generated at 2022-06-23 15:38:36.728936
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest.mock
    # Supports Python2 where mock is in unittest2
    try:
        from unittest import mock
    except ImportError:
        import mock
    g = Grammar()
    g.number2symbol = {1: "Grammar", 2: "dump"}
    g.keywords = {"a": 2, "b": 3}
    with unittest.mock.patch("pickle.dump") as mock_dump:
        with unittest.mock.patch("os.replace") as mock_replace:
            fd = unittest.mock.mock_open("w")
            with unittest.mock.patch("tempfile.NamedTemporaryFile") as mock_open:
                mock_open.return_value = fd

# Generated at 2022-06-23 15:38:47.930443
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import better_exceptions;better_exceptions.hook()
    import pytree
    #python2
    #path = os.path.dirname(sys.executable)
    #pkl_path = os.path.join(path, '../pgen_old/Grammar.pkl')
    #python3
    path = os.path.dirname(sys.executable)
    pkl_path = os.path.join(path, '../pgen/Grammar.pkl')
    gr = Grammar()
    g = gr.load(pkl_path)
    gr.report()
    #pytree.test()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-23 15:38:55.931074
# Unit test for method report of class Grammar
def test_Grammar_report():
    """
    This function is created for unit testing.
    """
    from . import pgen2

    module = pgen2.driver.load_grammar('Grammar/Grammar')

    # The following code is a workaround for Python 2.7
    if hasattr(module, "__file__"):
        filename = module.__file__.replace('.py', '.pgen2')
        if not os.path.exists(filename):
            raise SystemExit(
                "No grammar tables found "
                "(use 'make pgen' in {!r})".format(os.path.dirname(filename))
            )
    else:
        return

    module.report()

# Generated at 2022-06-23 15:39:04.431125
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    from inspect import isclass
    from typing import Type

    class Test(unittest.TestCase):
        def test_load(self) -> None:
            grammar_path = os.path.join(os.path.dirname(__file__), "Grammar.pickle")
            with open(grammar_path, "rb") as f:
                grammar = Grammar()
                grammar.loads(f.read())

            self.assertEqual(grammar.start, 257)
            self.assertIsInstance(grammar, Grammar)

    Test().test_load() # type: ignore

    return Test

Grammar.test_load = test_Grammar_load

# Generated at 2022-06-23 15:39:13.821341
# Unit test for constructor of class Grammar
def test_Grammar():
    from .pgen2 import driver

    # Test whether Grammar constructor's class invariants hold.
    g = driver.load_grammar(os.path.expanduser("~/cpython/Grammar.txt"))
    assert len(g.symbol2number) == len(g.number2symbol)
    s2n = g.symbol2number
    n2s = g.number2symbol
    assert set(s2n) == set(n2s.values())
    assert set(n2s) == set(s2n.values())


if __name__ == "__main__":
    test_Grammar()

# Generated at 2022-06-23 15:39:15.072073
# Unit test for method load of class Grammar
def test_Grammar_load():
    assert Grammar.load() == None


# Generated at 2022-06-23 15:39:19.346598
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbols == {}
    assert g.states == []
    assert g.labels == [(0, 'EMPTY')]
    assert g.keywords == {}
    assert g.tokens == {}

# Generated at 2022-06-23 15:39:19.769445
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()

# Generated at 2022-06-23 15:39:20.533297
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()

# Generated at 2022-06-23 15:39:23.421062
# Unit test for method load of class Grammar
def test_Grammar_load():
    c = Grammar()
    assert c.load(
        os.path.join(os.path.dirname(os.path.realpath(__file__)), "Grammar.pkl")
    ) == None

# Generated at 2022-06-23 15:39:27.168443
# Unit test for constructor of class Grammar
def test_Grammar():
    gr = Grammar()

    # Check that the instance variables are all initialized to appropriate values
    assert gr.symbol2number == {}
    assert gr.number2symbol == {}
    assert gr.states == []
    assert gr.dfas == {}
    assert gr.labels == [(0, "EMPTY")]
    assert gr.keywords == {}
    assert gr.tokens == {}
    assert gr.symbol2label == {}
    assert gr.start == 256

    gr = Grammar()
    gr.start = 257
    assert gr.start == 257



# Generated at 2022-06-23 15:39:29.444717
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import python_grammar

    print("Dumping Python grammar tables to python_grammar.pickle ...")
    python_grammar.dump(os.path.join(os.path.dirname(__file__), "python_grammar.pickle"))
    print("Done.")



# Generated at 2022-06-23 15:39:31.553557
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()


# Generated at 2022-06-23 15:39:42.725205
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    import sys
    from . import pgen2

    # Make and populate a new Grammar object
    g = Grammar()
    g.symbol2number = {'test': 256}
    g.number2symbol = {256: 'test'}
    g.states = [[((0, None), 0)]]
    g.dfas = {256: ([((0, None), 0)], {0: 0})}
    g.labels = [(0, None)]
    g.keywords = {}
    g.tokens = {token.ENDMARKER: 0}
    g.symbol2label = {}
    g.start = 256
    g.async_keywords = False

    # Generate a pickle
    s = pickle.dumps(g, pickle.HIGHEST_PROTOCOL)



# Generated at 2022-06-23 15:39:46.121711
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    assert g.tokens == {}
    assert g.keywords == {}
    g.loads(b"\x80\x03c__builtin__\nset\nq\x00)\x81q\x01}q\x02(X\x03\x00\x00\x00fooq\x03K\x01s.")
    assert g.tokens == {}
    assert g.keywords == {'foo': 1}

# Generated at 2022-06-23 15:39:54.444981
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    grammars = []
    for i in range(10):
        grammars.append(Grammar())
        grammars[i].symbol2number = grammars[i].number2symbol = {'+':'+'}
        grammars[i].dfas = {1:([(0, 0), (1, 0)], {0:0})}
        grammars[i].keywords = {'and':0}
        grammars[i].tokens = {'*':0}
        grammars[i].symbol2label = {'and':0}
        grammars[i].labels = [(0, 'and'),(1, '*')]

# Generated at 2022-06-23 15:40:06.931507
# Unit test for method copy of class Grammar
def test_Grammar_copy():  # Change test name: test_grammar_copy()
    import pickle

    g = Grammar()
    g.symbol2label = dict(foo='bar')
    g.labels = ['label1', 'label2']
    g.states = ['state1', 'state2']
    g.dfas = dict(foo='bar')
    g.keywords = dict(foo='bar')
    g.tokens = dict(foo='bar')
    g.symbol2number = dict(foo='bar')
    g.number2symbol = dict(foo='bar')
    g.start = 0
    g.async_keywords = True

    g2 = g.copy()
    assert g2.symbol2label == dict(foo='bar')
    assert g2.labels == ['label1', 'label2']