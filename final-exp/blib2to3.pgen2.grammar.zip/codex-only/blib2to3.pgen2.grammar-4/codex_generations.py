

# Generated at 2022-06-23 15:30:15.764549
# Unit test for method report of class Grammar
def test_Grammar_report():
    # Dummy class to avoid pickling issues
    class Dummy:
        pass

    new = Dummy()
    new.symbol2number = {
        "foo": 1,
        "bar": 2,
        "baz": 3,
    }
    new.number2symbol = {
        1: "foo",
        2: "bar",
        3: "baz",
    }
    new.states = [
        [
            [(1, 1), (2, 2)],
            [(3, 3), (4, 2)],
            [(1, 2), (5, 1)],
        ],
        [
            [(3, 3), (4, 2)],
            [(1, 1), (2, 2)],
            [(3, 3), (4, 2)],
        ],
    ]
    new

# Generated at 2022-06-23 15:30:26.990354
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    gr = Grammar()


# Generated at 2022-06-23 15:30:38.639555
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-23 15:30:40.445353
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()



# Generated at 2022-06-23 15:30:43.772975
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    from .pgen2 import driver

    g = driver.load_grammar()
    g2 = g.copy()
    assert g.start == g2.start
    assert g.states == g2.states

test_Grammar_copy()

# Generated at 2022-06-23 15:30:51.441389
# Unit test for method report of class Grammar
def test_Grammar_report():
    from io import StringIO
    from unittest import TestCase
    from pgen2 import parse_grammar
    from pgen2.parser import PgenParser

    class DummyOpts:
        debug = 0

    class Dummy:
        opts = DummyOpts()
        g = Grammar()

    with open(os.path.join(os.path.dirname(__file__), "Grammar.txt")) as f:
        input = f.read() + "\n"

    s = StringIO(input)
    pgen = PgenParser(Dummy, "Grammar.txt")
    pgen.parse(s, "exec")
    slr1 = parse_grammar(Dummy.g, "Grammar.txt")
    slr1.report()



# Generated at 2022-06-23 15:30:57.601205
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    from .conv import Token, convert
    from .pgen2 import tokenize

    g = convert(tokenize("Grammar.py"))
    copy_g = g.copy()
    g.symbol2number['foo'] = 1
    assert copy_g.symbol2number.get('foo') != 1
    assert g.symbol2number['foo'] == 1

    g.number2symbol[1] = 'foo'
    assert copy_g.number2symbol.get(1) != 'foo'
    assert g.number2symbol[1] == 'foo'

    g.dfas[1] = (DFAS(([(0, 1)], {}), {}))
    assert copy_g.dfas.get(1) != [(0, 1)]

# Generated at 2022-06-23 15:31:03.217755
# Unit test for method report of class Grammar
def test_Grammar_report():
    from io import StringIO
    from contextlib import redirect_stdout

    f = StringIO()
    with redirect_stdout(f):
        Grammar().report()
    assert f.getvalue() == "\ns2n\n{}\nn2s\n{}\nstates\n[]\ndfas\n{}\nlabels\n[(0, 'EMPTY')]\nstart 256\n"



# Generated at 2022-06-23 15:31:06.025443
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("./test_Grammar_dump-pkl")

if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-23 15:31:13.652563
# Unit test for method load of class Grammar
def test_Grammar_load():
    class GrammarSubClass(Grammar):
        def __init__(self):
            super().__init__()
            self.foo = 1
    gs = GrammarSubClass()
    gs.dump("/tmp/pgen_Grammar_load_1")
    del gs
    gs = GrammarSubClass()
    gs.load("/tmp/pgen_Grammar_load_1")
    assert gs.foo == 1


# Generated at 2022-06-23 15:31:23.235958
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .tokenizer import _PseudoTokenMeetBytes

    grammar = Grammar()
    grammar.async_keywords = True
    temp = tempfile.NamedTemporaryFile(delete=False)
    grammar.dump(temp.name)
    grammar2 = Grammar()
    grammar2.load(temp.name)
    assert grammar.async_keywords == grammar2.async_keywords
    os.remove(temp.name)
    temp = tempfile.NamedTemporaryFile()
    grammar.dump(temp.name)
    with open(temp.name, "rb") as f:
        pkl = f.read()
    grammar2 = Grammar()
    grammar2.loads(pkl)
    assert grammar.async_keywords == grammar2.async_keywords
    temp = tempfile.Named

# Generated at 2022-06-23 15:31:28.044668
# Unit test for method report of class Grammar
def test_Grammar_report():
    # The method report of class Grammar prints the dicts
    # symbol2number, number2symbol, states, dfas, labels of the
    # Grammar instance to sys.stdout.
    # This function runs the method report, checks that the result
    # is a correct printed representation of the dicts symbol2number,
    # number2symbol, states, dfas, labels and returns the result.
    from io import StringIO
    from unittest import mock

    out_str = StringIO()
    with mock.patch("sys.stdout", out_str):
        g = Grammar()
        g.symbol2number = {"a": 5, "b": 10}
        g.number2symbol = {5: "a", 10: "b"}

# Generated at 2022-06-23 15:31:37.408248
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Issue 5301: should pickle and unpickle successfully
    g = Grammar()
    fd, fn = tempfile.mkstemp()
    os.close(fd)
    try:
        g.dump(fn)
        g2 = Grammar()
        g2.load(fn)
        assert g2.symbol2number == g2.symbol2number
        assert g2.number2symbol == g2.number2symbol
        assert g2.states == g2.states
        assert g2.dfas == g2.dfas
        assert g2.labels == g2.labels
        assert g2.symbol2label == g2.symbol2label
        assert g2.start == g2.start
    finally:
        os.unlink(fn)


# Generated at 2022-06-23 15:31:46.833452
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io
    import sys
    from unittest import mock

    g = Grammar()

    buf = io.StringIO()
    with mock.patch.object(sys, "stdout", buf):
        g.report()
        expected = """\
s2n
{}
n2s
{}
states
[]
dfas
{}
labels
[(0, 'EMPTY')]
start 256
"""
        assert buf.getvalue() == expected


if __name__ == "__main__":
    # Run the unit test(s)
    test_Grammar_report()

# Generated at 2022-06-23 15:31:55.014703
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    from .pgen2 import driver
    from . import tokenize

    gram = driver.load_grammar()
    copied_gram = gram.copy()

    original_gram_pickle = driver.dump_grammar(gram)
    copied_gram_pickle = driver.dump_grammar(copied_gram)

    assert original_gram_pickle == copied_gram_pickle

    # Check if the same operators are recognized by each grammar
    # (the tokenize module uses pycparser to generate its grammar)
    # The two grammars should recognize the same operators
    assert opmap.keys() == tokenize.opmap.keys()


# Generated at 2022-06-23 15:31:59.286496
# Unit test for constructor of class Grammar
def test_Grammar():
    gram = Grammar()
    assert gram.keywords == {}
    assert gram.labels == [(0, 'EMPTY')]
    assert gram.start == 256
    assert gram.states == []
    assert gram.symbol2label == {}
    assert gram.symbol2number == {}
    assert gram.number2symbol == {}

# Generated at 2022-06-23 15:32:02.698517
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2.pgen import driver

    g = Grammar()
    driver.load_grammar("Grammar/Grammar", g)
    g.dump("./test_grammar.pickle")

    grammar = Grammar()
    grammar.load("./test_grammar.pickle")

# Generated at 2022-06-23 15:32:04.868368
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    assert Grammar().loads(b"cd(1,2)")

# Generated at 2022-06-23 15:32:16.310991
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g1.symbol2number = {"A": 1, "B": 2}
    g1.number2symbol = {1: "A", 2: "B"}
    g1.dfas = {"A": 1, "B": 2}
    g1.keywords = {"C": 1, "D": 2}
    g1.tokens = {"E": 1, "F": 2}
    g1.symbol2label = {"G": 1, "H": 2}
    g1.labels = ["X", "Y"]
    g1.states = ["Z"]
    g1.start = 1

    g2 = g1.copy()

    # verify that each attribute is copied properly
    #
    # This is a bit ugly, but we need to test more than the value
    #

# Generated at 2022-06-23 15:32:26.440025
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    from .pgen2 import driver
    from . import token

    # Test importing a grammar
    g = driver.load_grammar(token.__file__)

    g_copy = g.copy()

    # The grammar should be equal
    assert g == g_copy

    # The grammar should not be the same object in memory
    assert g is not g_copy

    # Test that the grammar works
    from .parse import Parser
    p = Parser(g, "1 + 1")
    p.parse_toplevel()
    assert p.error_count == 0

    # Test mutating the grammar object
    g_copy.start = -1
    p = Parser(g_copy, "1 + 1")
    assert p.error_count == 1

# Generated at 2022-06-23 15:32:34.537312
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import driver
    from . import tokenize
    from .token import ENDMARKER

    g = Grammar()
    g.load(driver.parse_tokens)

    assert token.DEDENT == g.tokens[tokenize.DEDENT]
    assert token.ENDMARKER == g.tokens[ENDMARKER]

    # Ensure that the pickle contains all relevant attributes.
    # NOTE: This test is sensitive to the implementation details of
    # the Grammar class.
    for attr in (
        "states",
        "keywords",
        "tokens",
        "labels",
        "dfas",
        "symbol2number",
        "number2symbol",
        "start",
    ):
        assert hasattr(g, attr)

# Generated at 2022-06-23 15:32:41.749874
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import sys
    import unittest

    class TestGrammar(unittest.TestCase):
        def test_method_copy(self):
            tm = sys.version_info[:2]
            new = g2.copy()
            for dict_attr in (
                "symbol2number",
                "number2symbol",
                "dfas",
                "keywords",
                "tokens",
                "symbol2label",
            ):
                self.assertEqual(getattr(new, dict_attr), getattr(g2, dict_attr))
            self.assertEqual(new.labels, g2.labels)
            self.assertEqual(new.states, g2.states)
            self.assertEqual(new.start, g2.start)
            self.assertEqual

# Generated at 2022-06-23 15:32:49.301668
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    import io
    import os
    import tempfile
    from . import token

    # Load a known grammar
    fd, filename = tempfile.mkstemp()

# Generated at 2022-06-23 15:32:49.952279
# Unit test for method report of class Grammar
def test_Grammar_report():
    assert Grammar.report

# Generated at 2022-06-23 15:32:50.594242
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()

# Generated at 2022-06-23 15:32:51.306637
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()


# Generated at 2022-06-23 15:32:53.630268
# Unit test for method report of class Grammar
def test_Grammar_report():
    import pgen
    from io import StringIO
    from typing import cast

    g = Grammar()
    g.load(pgen.grammar)
    output = StringIO()
    cast(Any, g).report(file=output)
    assert len(output.getvalue()) > 0

# Generated at 2022-06-23 15:33:03.697295
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle

    class CustomGrammar(Grammar):
        def __init__(self):
            self.custom_attr = 42
            self.symbol2number = {"__main__": 42}
            self.number2symbol = {42: "__main__"}
            self.states = [[]]
            self.dfas = {}
            self.labels = [(0, "EMPTY")]
            self.keywords = {}
            self.tokens = {}
            self.symbol2label = {"__main__": 42}
            self.start = 256
            self.async_keywords = False

    g = CustomGrammar()
    g.dump("test_Grammar_dump")

# Generated at 2022-06-23 15:33:04.695777
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g2 = g1.copy()
    assert g1 == g2

# Generated at 2022-06-23 15:33:16.620127
# Unit test for method load of class Grammar
def test_Grammar_load():
    """
    Test load() method of Grammar.

    Note that this test assumes that the class Grammar
    works as expected.
    """
    import io
    import pickle

    grammar = Grammar()
    s = io.BytesIO()
    pickle.dump(grammar.__dict__, s)
    s.seek(0)
    grammar.loads(s.read())

    assert 'symbol2number' in grammar.__dict__
    assert grammar.symbol2number == {}

    assert 'number2symbol' in grammar.__dict__
    assert grammar.number2symbol == {}

    assert 'states' in grammar.__dict__
    assert grammar.states == []

    assert 'dfas' in grammar.__dict__
    assert grammar.dfas == {}

    assert 'labels' in grammar.__dict__

# Generated at 2022-06-23 15:33:24.743271
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # Create a grammar object
    grammar = Grammar()
    # Create a parse table
    parse_table = set(range(0, 256))
    # Create a dumps obj from the parse table
    dumps_obj = pickle.dumps((grammar.__class__.__name__, parse_table), protocol=4)
    # Load the dumps obj on to the grammar object
    grammar.loads(dumps_obj)
    # Check that the updated grammar object works
    grammar.labels
    grammar.symbol2label

# Generated at 2022-06-23 15:33:32.830305
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number['foo'] = 1
    g.number2symbol[1] = 'foo'
    g.start = 10

    h = g.copy()

    assert g.symbol2number == h.symbol2number
    assert g.number2symbol == h.number2symbol
    assert g.start == h.start

    assert g.symbol2number.pop('foo') == 1
    assert g.start == 10

    assert h.symbol2number['foo'] == 1
    assert h.start == 10

# Generated at 2022-06-23 15:33:38.120567
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    with tempfile.TemporaryDirectory() as dirname:
        # First dump the grammar with a real file
        g.dump(os.path.join(dirname, "test_Grammar_dump"))

        # Now dump the grammar to a file that is deleted right after,
        # and we shouldn't crash here.
        g.dump(tempfile.mkstemp(dir=dirname)[1])

# Generated at 2022-06-23 15:33:47.622885
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # Construct the pickle
    a = Grammar()
    a.symbol2number["foo"] = 1
    a.number2symbol[1] = "foo"
    a.states = [[(0,0)]]
    a.dfas = {1: (a.states[0], None)}
    a.labels = [(0, None), (1, "foo")]
    a.keywords = {"foo": 1}
    a.tokens = {1: 1}
    a.start = 256

    # Pickle and unpickle and check it
    pkl = pickle.dumps(a.__getstate__())
    b = Grammar()
    b.loads(pkl)
    assert b.symbol2number == {'foo': 1}

# Generated at 2022-06-23 15:33:58.396001
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    f = tempfile.NamedTemporaryFile(mode="wb", delete=False)
    f.close()
    g.dump(f.name)
    with open(f.name, "rb") as f:
        d = pickle.load(f)
    assert {'symbol2number', 'number2symbol', 'states', 'dfas', 'labels',
            'keywords', 'tokens', 'symbol2label', 'start', 'async_keywords'} == set(d)
    os.remove(f.name)
    g2 = Grammar()
    g2.loads(pickle.dumps(d))
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol

# Generated at 2022-06-23 15:34:04.606766
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys, pprint
    class DummyGrammar(Grammar):
        def __init__(self):
            super().__init__()
            self.symbol2number['symbol1'] = 0
            self.symbol2number['symbol2'] = 1
            self.number2symbol[0] = 'symbol1'
            self.number2symbol[1] = 'symbol2'
            self.states.append([(0, 0), (1, 1)])
            self.states.append([(0, 2), (1, 3)])
            self.dfas[0] = (self.states[0],
                            {256: 1, 257: 1, 258: 1})

# Generated at 2022-06-23 15:34:08.596163
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.number2symbol = {"a": 1}
    g.symbol2number = {"b": 2}
    g.states = [1, 2]
    g.dfas = {"asdf": ("asdf", "asdf")}
    g.labels = None
    g.keywords = {"asdf": "asdf"}
    g.tokens = {1: 2}
    g.symbol2label = {"asdf": "asdf"}
    g.start = 256
    g.async_keywords = False
    assert g.copy() == g

# Generated at 2022-06-23 15:34:10.686702
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()

if __name__ == "__main__":
    test_Grammar_report()

# Generated at 2022-06-23 15:34:16.793643
# Unit test for constructor of class Grammar
def test_Grammar():
    grammar = Grammar()
    assert grammar.symbol2number == {}
    assert grammar.number2symbol == {}
    assert grammar.states == []
    assert grammar.dfas == {}
    assert grammar.labels == [(0, "EMPTY")]
    assert grammar.keywords == {}
    assert grammar.tokens == {}
    assert grammar.symbol2label == {}
    assert grammar.start == 256


# Generated at 2022-06-23 15:34:25.847176
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    gr = Grammar()
    state0 = [[(1, 5)], [(1, 6)], [], [(1, 5)], [(1, 9)], [(2, 7)], [(2, 6)], [(2, 5)],
            [], [], [(2, 9)], [(3, 5)], [(3, 6)], [(3, 9)], [(3, 5)], [(3, 6)], [(3, 5)]]
    state1 = [[(2, 2)], [(2, 3)], [(2, 2)], [(2, 4)], [(2, 2)], [], [], [],
            [(2, 3)], [(2, 4)], [], [(2, 2)], [(2, 3)], [(2, 4)], [(2, 2)], [(2, 3)]]

# Generated at 2022-06-23 15:34:35.405442
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    grammar = Grammar()

# Generated at 2022-06-23 15:34:37.164586
# Unit test for method load of class Grammar
def test_Grammar_load():
    gr = Grammar()
    gr.load("Grammar.pickle")


# Generated at 2022-06-23 15:34:47.085305
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    sub_Grammar_loads = Grammar()

# Generated at 2022-06-23 15:34:49.777201
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    class G(Grammar):
        pass

    g = G()
    g.foo = 1
    g.dump("/tmp/test_Grammar_dump.pkl")



# Generated at 2022-06-23 15:34:56.702325
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # test with valid input
    g = Grammar()

# Generated at 2022-06-23 15:35:01.795795
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256


# Generated at 2022-06-23 15:35:03.809501
# Unit test for method load of class Grammar
def test_Grammar_load():
    table = Grammar()
    table.load(__file__.replace(".py", ".pkl"))

# Generated at 2022-06-23 15:35:15.626048
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import tempfile
    TEMP_FILE_NAME = "temp.bin"
    TEST_DATA_PATH = os.path.join(os.path.dirname(__file__), '..', "testdata")
    GRAMMAR_FILE_PATH = os.path.join(TEST_DATA_PATH, 'grammar.pkl')

    with open(GRAMMAR_FILE_PATH, "rb") as f:
        test_grammar_data = pickle.load(f)

    g = Grammar()

    # This is required for correct function of method dump
    # from Grammar class
    for dict_attr in (
        "symbol2number",
        "number2symbol",
        "dfas",
        "keywords",
        "tokens",
        "symbol2label",
    ):
        setattr

# Generated at 2022-06-23 15:35:16.197682
# Unit test for constructor of class Grammar
def test_Grammar():
    gr = Grammar()

# Generated at 2022-06-23 15:35:27.312521
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    grammar = Grammar()

# Generated at 2022-06-23 15:35:31.882298
# Unit test for constructor of class Grammar
def test_Grammar():
    x = Grammar()
    for attr in (
        "symbol2number", "number2symbol", "states", "dfas", "labels",
        "keywords", "tokens", "symbol2label", "start"
    ):
        assert hasattr(x, attr)


# Generated at 2022-06-23 15:35:36.151230
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    d = {'a': 1, 'b': 2}
    g.symbol2number = d
    new = g.copy()
    assert d is not new.symbol2number
    assert d == new.symbol2number

# Generated at 2022-06-23 15:35:38.673123
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    pkl = _example()
    g.loads(pkl)
    assert pkl == pickle.dumps(g, pickle.HIGHEST_PROTOCOL)


# Generated at 2022-06-23 15:35:50.106851
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Load the Python 2 version of the grammar.
    gram_py2 = Grammar()
    gram_py2.load(
        os.path.join(os.path.dirname(__file__), "Grammar-2.7.6.pkl")
    )

    # Load the Python 3 version of the grammar.
    gram_py3 = Grammar()
    gram_py3.load(
        os.path.join(os.path.dirname(__file__), "Grammar-3.5.0.pkl")
    )

    # Check the number of tokens and labels is the same.
    assert len(gram_py2.labels) == len(gram_py3.labels)
    assert len(gram_py2.tokens) == len(gram_py3.tokens)

   

# Generated at 2022-06-23 15:35:56.923053
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2
    from pgen2.parse import ParseError
    # Test if a grammar can be loaded from a pickle
    # Test if an error is raised when unpickling fails
    try:
        pgen2.driver.load_grammar(
            pgen2.PgenDictionary.from_grammar_source('''
        '''), picklefile=':')
    except ParseError:
        pass
    else:
        assert False


test_Grammar_load()

# Generated at 2022-06-23 15:36:09.572413
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    # access instance variable directly to keep test simple
    g.symbol2number = {"foo": 256}
    g.number2symbol = {256: "foo"}
    g.states = [[[(0, 1)], [(1, 2), (2, 0)], [(2, 3)]]]
    g.dfas = {256: ([[(0, 1), (1, 2)], [(1, 2), (1, 3)]], {0: 1, 1: 1})}
    g.labels = [(0, "EMPTY"), (0, "foo"), (1, None), (2, "bar")]
    g.start = 256

# Generated at 2022-06-23 15:36:17.500663
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    with open('Grammar.pickle', 'rb') as f:
        pkl = f.read()
    g = Grammar()
    g.loads(pkl)
    assert g.symbol2number['and'] == 1024
    assert g.number2symbol[1024] == 'and'
    assert g.states[0][0][0] == (258, 0)
    assert g.dfas[1024][0][0][0] == (0, 7)
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords['def'] == 5
    assert g.tokens[1] == 1
    assert g.symbol2label['stmt'] == 1002
    assert g.start == 256
    assert g.async_keywords == False


# Generated at 2022-06-23 15:36:22.629834
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    filename = 'grammar'
    if os.path.exists(filename):
        g = Grammar()
        with open(filename, "rb") as f:
            g.loads(f.read())
        assert g.start == 256
    else:
        # Enable this test when we can reproduce the pickle files
        assert False

# Generated at 2022-06-23 15:36:23.188278
# Unit test for constructor of class Grammar
def test_Grammar():
    assert Grammar()

# Generated at 2022-06-23 15:36:29.971623
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    class DummyGrammar(Grammar):
        def __init__(self):
            super(DummyGrammar, self).__init__()
            self.some_variable = "abc"

    g1 = DummyGrammar()
    g2 = g1.copy()
    assert g1.some_variable == g2.some_variable == "abc"
    g2.some_variable = "xyz"
    assert g1.some_variable == "abc"
    assert g2.some_variable == "xyz"

# Generated at 2022-06-23 15:36:33.873680
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    f = tempfile.NamedTemporaryFile(delete=False)
    f.close()
    try:
        g.dump(f.name)
        g2 = Grammar()
        g2.load(f.name)
    finally:
        os.remove(f.name)
    assert g == g2

# Generated at 2022-06-23 15:36:38.450840
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords == False



# Generated at 2022-06-23 15:36:49.606014
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import textwrap
    import unittest

    class GrammarTestCase(unittest.TestCase):
        def setUp(self):
            # Copy the mapping opmap in a temporary one
            self.temp_opmap = opmap.copy()
            # Create a Grammar object
            self.grammar = Grammar()
            self.grammar.symbol2number = {
                "and_tok": 257,
                "and_expr": 258,
                "assert_stmt": 259,
            }
            self.grammar.number2symbol = {
                257: "and_tok",
                258: "and_expr",
                259: "assert_stmt",
            }

# Generated at 2022-06-23 15:36:59.567314
# Unit test for method report of class Grammar
def test_Grammar_report():
    # This is a meaningless grammar, but it should exercise
    # all the tables.
    gram = Grammar()
    gram.symbol2number = {"a" : 257, "b" : 258}
    gram.number2symbol = {257 : "a", 258 : "b"}
    gram.states = [[[("<256>", 1)],
                    [(257, 2), (0, 3), ("<end>", 3)],
                    [(258, 4)],
                    [(1, 1)]],
                   [[("<256>", 5)],
                    [(0, 6), ("<end>", 6)],
                    [(257, 6), (258, 7)],
                    [(257, 8)],
                    [(258, 9)],
                    [(257, 10)]]]

# Generated at 2022-06-23 15:37:10.581542
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .conv import Convert, LiteralConverter
    from .pgen2 import tokenize
    from .parse import ParseError
    from .tokenize import generate_tokens
    from .token import untokenize

    path_to_grammar = os.path.join(os.path.dirname(__file__), "Grammar.txt")

    c = Convert(LiteralConverter)
    c.convert(path_to_grammar)

    # Save the grammar
    path_to_grammar_pickle = os.path.join(os.path.dirname(__file__), "Grammar.pickle")
    c.grammar.dump(path_to_grammar_pickle)

    # Check the pickle file
    # Load the grammar again

# Generated at 2022-06-23 15:37:14.435505
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.test_attr_copy = "copy_test"
    g.test_attr_not_copy = "not_copy_test"
    new_g = g.copy()
    new_g.test_attr_copy = "copy_test_new"
    new_g.test_attr_not_copy = "not_copy_test_new"
    assert g.test_attr_copy == "copy_test"
    assert g.test_attr_not_copy == "not_copy_test_new"

# Generated at 2022-06-23 15:37:23.147331
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io
    import unittest

    class FakeStream(io.StringIO):
        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            pass

    class TestGrammar(unittest.TestCase):
        def test_report(self):
            grammar = Grammar()
            with FakeStream() as stream:
                grammar.report(file=stream)

# Generated at 2022-06-23 15:37:29.224660
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys

    # Test with a simple Grammar object
    gr = Grammar()
    gr.symbol2number = {'foo': 0}
    gr.number2symbol = {0: 'foo'}
    gr.states = [None]
    gr.dfas = {0: (None, None)}
    gr.labels = []
    gr.keywords = {}
    gr.tokens = {}
    gr.start = 0

    gr.dump(sys.executable)


if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-23 15:37:34.262347
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # get the current working directory
    cwd = os.getcwd()
    # test the Grammar.dump method
    g = Grammar()
    g.dump(cwd + "/test.pkl")
    for k, v in g.__dict__.items():
        assert k in g.__dict__
        assert g.__dict__[k] == v


# Generated at 2022-06-23 15:37:39.678181
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.number2symbol = {1: "test"}
    g.symbol2number = {"test": 1}
    g.dfas = {1: ([], {})}
    g.keywords = {"test": 1}
    g.tokens = {1: 2}
    g.symbol2label = {"test": 3}
    g.labels = [(1, "test1"), (2, "test2")]
    g.states = [[(1, 2)]]
    g.start = 6
    g.async_keywords = True

    h = g.copy()
    assert h.number2symbol == {1: "test"}
    assert h.symbol2number == {"test": 1}
    assert h.dfas == {1: ([], {})}
    assert h

# Generated at 2022-06-23 15:37:49.580790
# Unit test for method load of class Grammar
def test_Grammar_load():
    # NB: Each Grammar._update() call will set the attrs value to an object
    # of type 'dict' so that it will fail the hasattr check above
    # and fall into the `else` block.
    g = Grammar()
    # check using hasattr
    g._update({'test': 'test_value'})
    assert hasattr(g, 'test')
    # check if test_value is set
    assert g.test == 'test_value'
    # check using getattr
    assert getattr(g, 'test') == 'test_value'

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-23 15:38:01.716726
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import pickle
    from .. import token
    from . import pickle as pickle_

    class Grammar1(Grammar):
        """Test grammar for Grammar.copy()."""

        def __init__(self) -> None:
            super().__init__()
            self.symbol2number = {'foo': 14}
            self.number2symbol = {2: 'bar'}
            self.dfas = {27: ([[(1, 2)]], {0: 3})}
            self.keywords = {'elif': 34}
            self.tokens = {token.RPAR: 37}
            self.symbol2label = {'spam': 41}
            self.labels = [(0, "EMPTY"), (1, "spam"), (2, None)]

# Generated at 2022-06-23 15:38:10.608596
# Unit test for constructor of class Grammar
def test_Grammar():
    grammar = Grammar()
    assert type(grammar) == Grammar
    assert isinstance(grammar.symbol2number, dict)
    assert isinstance(grammar.number2symbol, dict)
    assert isinstance(grammar.states, list)
    assert isinstance(grammar.dfas, dict)
    assert isinstance(grammar.labels, list)
    assert isinstance(grammar.keywords, dict)
    assert isinstance(grammar.tokens, dict)
    assert type(grammar.start) == int
    assert grammar.start == 256

# Generated at 2022-06-23 15:38:12.390187
# Unit test for constructor of class Grammar
def test_Grammar():
    # Issue 9573: Make sure that Grammar doesn't crash on creation.
    Grammar()

# Generated at 2022-06-23 15:38:23.556100
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {"hello": 42}
    g.states = [[(1, 2), (3, 4)]]
    g.dfas = {5: ([[(6, 7), (8, 9)]], {10: 11}), 12: ([[(13, 14), (15, 16)]], {17: 18})}
    g.labels = [(19, "world"), (20, "!")]
    g.number2symbol = {21: "are", 22: "you", 23: "doing"}
    g.keywords = {"ok": 24, "yes": 25, "no": 26}
    g.tokens = {27: 28, 29: 30, 31: 32}
    g.symbol2label = {"first": 33, "second": 34, "third": 35}

# Generated at 2022-06-23 15:38:24.747671
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()


# Generated at 2022-06-23 15:38:31.427030
# Unit test for constructor of class Grammar
def test_Grammar():
    import pickle
    import sys

    # Since this is a test, we ignore type hints here to avoid having to get
    # os.PathLike[str] right.
    g = Grammar()
    g.dump(sys.executable + ".pgen_grammar")
    h = Grammar()
    h.load(sys.executable + ".pgen_grammar")
    i = pickle.loads(pickle.dumps(h))
    j = i.copy()
    assert i.symbol2number == j.symbol2number
    assert i.number2symbol == j.number2symbol
    assert i.states == j.states
    assert i.dfas == j.dfas
    assert i.labels == j.labels
    assert i.keywords == j.keywords
    assert i.tok

# Generated at 2022-06-23 15:38:34.777958
# Unit test for method report of class Grammar
def test_Grammar_report():
    print("testing Grammar.report")

    import areallylongnameasavariable  # noqa
    g = Grammar()
    g.report()

    print("done testing Grammar.report")


# Generated at 2022-06-23 15:38:47.049313
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()

    g.symbol2number = {'a': 1, 'b': 2, 'c': 3}
    g.number2symbol = {1: 'a', 2: 'b', 3: 'c'}
    g.dfas = {10: ([[(10, 20)], [(21, 30)]], {20: 1, 30: 1}),
              20: ([[(10, 20)], [(10, 30)]], {20: 1, 30: 1})}
    g.keywords = {'async': 1}
    g.tokens = {10: 2}
    g.symbol2label = {'d': 3}
    g.labels = [(0, 'EMPTY'), (3, 'd'), (2, 'async')]

# Generated at 2022-06-23 15:38:51.375616
# Unit test for method report of class Grammar
def test_Grammar_report():
    """
    Since the Grammar.report() method directly writes to stdout, we
    simply make sure that it can be called without error.
    """
    g = Grammar()
    # report() is pickle safe, so no need to set up a grammar
    g.report()

__all__ = ["Grammar"]

# Generated at 2022-06-23 15:38:56.205318
# Unit test for method report of class Grammar
def test_Grammar_report():
    import pgen.pgen
    import pgen.pgen2
    import pgen.pgen3
    import pgen.pgen4

    def check(g):
        g.report()

    check(pgen.pgen.grammar)
    check(pgen.pgen2.grammar)
    check(pgen.pgen3.grammar)
    check(pgen.pgen4.grammar)

# Generated at 2022-06-23 15:39:04.693768
# Unit test for method load of class Grammar
def test_Grammar_load():
    # This test is missing in Python 3.7+ because we just import the pickle files
    # directly.
    import pkgutil
    import pygram.grammar
    g = Grammar()
    data = pkgutil.get_data(pygram.grammar.__name__, "Grammar.pickle")
    g.loads(data)
    assert g.start == 256
    assert g.number2symbol[256] == 'file_input'
    assert g.keywords['async'] == 153
    assert g.tokens[token.NAME] == 1
    assert g.states[0][4][1] == 5
    assert g.dfas[258][0][0][0] == 153

# Generated at 2022-06-23 15:39:13.084259
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io
    import sys
    from .parser import Parser

    grammar = Grammar()
    sys.stdout = io.StringIO()
    try:
        start = grammar.symbol2number["single_input"]
        p = Parser(grammar)
        p.setup([])
        p.set_state()
        p.parse_start_symbol(start)
    finally:
        sys.stdout = sys.__stdout__
    output = sys.stdout.getvalue()
    assert len(output) > 0, "Output empty"

# Generated at 2022-06-23 15:39:14.412122
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    grammar = Grammar()
    assert id(grammar) != id(grammar.copy())

# Generated at 2022-06-23 15:39:16.363324
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g1 = Grammar()
    g1.loads(g1.dumps())



# Generated at 2022-06-23 15:39:26.765308
# Unit test for method report of class Grammar
def test_Grammar_report():
    class TestGrammar(Grammar):
        def __init__(self):
            super().__init__()
            self.async_keywords = True
            self.symbol2number = {'a': 257, 'b': 258}
            self.number2symbol = {257: 'a', 258: 'b'}
            self.states = [[[(258, 258)], [(257, 1), (0, 1)]], [[(0, 1)]]]
            self.dfas = {258: ([[(258, 258)], [(257, 1), (0, 1)]], {1: 1}), 257: ([[(0, 1)]], {1: 1})}
            self.labels = [(0, 'EMPTY'), (257, None), (258, None)]

# Generated at 2022-06-23 15:39:31.678561
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number["foo"] = 42
    g.dfas[42] = [[], {}]
    g.symbol2label["foo"] = 0
    g.keywords["bar"] = 10
    g.tokens[10] = 10
    g.labels[0] = 0, None
    g.states = [[[(0, 1), (1, 2)], [(0, 3)]]]
    g2 = g.copy()
    assert g2 is not g
    assert g2.symbol2number is not g.symbol2number
    assert g2.symbol2number["foo"] == 42
    assert g2.dfas is not g.dfas
    assert g2.dfas[42]
    assert g2.symbol2label is not g.symbol

# Generated at 2022-06-23 15:39:39.545156
# Unit test for method load of class Grammar

# Generated at 2022-06-23 15:39:47.259107
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """Tests for Grammar.dump()"""
    filename = "Grammar.pickle"
    g = Grammar()
    g.tokens = {1: 1, 2: 2, 3: 3}
    g.dump(filename)
    g2 = Grammar()
    g2.load(filename)
    assert g.tokens == g2.tokens
    os.remove(filename)

# Generated at 2022-06-23 15:39:52.615098
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # Verify that Grammar.loads raises an exception on a bogus grammar
    with open(__file__) as f:
        source = f.read()
    g = Grammar()
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_filename = os.path.join(tmp_dir, "tmp_grammar.pkl")
        with open(tmp_filename, 'wb') as f:
            f.write(source.encode("utf-8"))
        g.load(tmp_filename)

# Generated at 2022-06-23 15:39:53.740782
# Unit test for constructor of class Grammar
def test_Grammar():
    s = Grammar()
    assert isinstance(s, Grammar)

# Generated at 2022-06-23 15:40:06.501146
# Unit test for method load of class Grammar
def test_Grammar_load():
    # FIXME: put this in a unittest

    import pprint
