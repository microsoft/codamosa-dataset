

# Generated at 2022-06-23 15:30:15.763951
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    # Load a pickle file created by running the following code:
    # import pickle
    # pickle.dump(g.__getstate__(), open("test_Grammar_loads.pkl", "wb"))

# Generated at 2022-06-23 15:30:19.961806
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io
    import contextlib
    with contextlib.redirect_stdout(io.StringIO()) as string_buffer:
        Grammar().report()
    assert "s2n" in string_buffer.getvalue()


# Generated at 2022-06-23 15:30:30.324893
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # This test was added to ensure that mypyc can handle pickled
    # function objects.
    g = Grammar()

# Generated at 2022-06-23 15:30:42.155090
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # type: () -> None
    def unwrap(s):
        # type: (str) -> Tuple[Dict[str, Any], List[Dict[str, Any]]]
        x = eval(s)
        return x['symbol2number'], x['dfas']


# Generated at 2022-06-23 15:30:49.760544
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .conv import gen_convert

    t = gen_convert.make_table(gen_convert.grammar_nts)
    g = Grammar()
    g.tokens = t.tokens
    g.keywords = t.keywords
    g.states = t.states
    g.start = t.start
    assert not hasattr(g, 'start')
    assert not hasattr(g, 'empty')
    assert not hasattr(g, 'error')
    g.dump("/tmp/test.pkl")
    g.load("/tmp/test.pkl")
    assert hasattr(g, 'start')
    assert hasattr(g, 'empty')
    assert hasattr(g, 'error')

# Generated at 2022-06-23 15:30:55.451444
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    with tempfile.TemporaryDirectory() as tmp:
        fname = os.path.join(tmp, "Grammar.pkl")
        g.start = 10
        g.number2symbol = {"a": 1}
        g.dump(fname)
        g2 = Grammar()
        g2.load(fname)
        assert g2.start == 10
        assert g2.number2symbol == {"a": 1}


if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-23 15:31:06.881806
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    # pylint: disable=missing-class-docstring,missing-function-docstring,invalid-name

    g = Grammar()
    g.symbol2number = {'a': 1, 'b': 2}
    g.number2symbol = {1: 'a', 2: 'b'}
    g.dfas = {
        1: ([[(1, 2), (1, 3)], [(2, 4)], [(3, 4)]], {4: 1}),
        2: ([[(1, 2), (2, 3)], [(2, 4), (3, 5)]], {4: 1, 5: 1}),
    }
    g.keywords = {'a': 1, 'c': 3}
    g.tokens = {3: 1, 4: 2}
    g.symbol

# Generated at 2022-06-23 15:31:15.237454
# Unit test for method load of class Grammar
def test_Grammar_load():
    import types

    g = Grammar()
    g.load('./Grammar.pkl')
    assert isinstance(g.symbol2number, dict)
    assert isinstance(g.number2symbol, dict)
    assert isinstance(g.states, list)
    assert isinstance(g.dfas, dict)
    assert isinstance(g.labels, list)
    assert isinstance(g.keywords, dict)
    assert isinstance(g.tokens, dict)

# Generated at 2022-06-23 15:31:23.897151
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g1.symbol2number = {"x":1, "y":2}
    g1.number2symbol = {1:"x", 2:"y"}
    g1.dfas = {"x":([], {"a":1})}
    g1.keywords = {"a":1, "b":2}
    g1.tokens = {"x":3, "y":4}
    g1.symbol2label = {"a":5, "b":6}
    g1.labels = ["a", "b", "c"]
    g1.states = [[("a",1), ("b",2)], [("c",3)]]
    g1.start = 8
    g1.async_keywords = False
    g2 = g1.copy()
    assert g

# Generated at 2022-06-23 15:31:29.310206
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    class GrammarSubclass(Grammar):
        pass
    g = GrammarSubclass()
    g.loads(pickle.dumps({"symbol2number": {"hello": 17}, "number2symbol": {17: "hello"}}))
    assert g.symbol2number["hello"] == 17
    assert g.number2symbol[17] == "hello"

# Generated at 2022-06-23 15:31:38.133459
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {"for": 2, "y": 1, "x": 0}
    g.number2symbol = {0: "x", 1: "y", 2: "for"}
    g.states = [[[(1, 2)], [(2, 3)], [(3, 3)], []]]
    g.dfas = {1: (g.states[0], {0: 1})}
    g.labels = [(0, "EMPTY"), (256, "x"), (257, "y"), (258, "for")]
    g.keywords = {}
    g.tokens = {}
    g.symbol2label = {"x": 256, "y": 257, "for": 258}
    g.start = 258

# Generated at 2022-06-23 15:31:49.329782
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.start = 2
    g.labels = [
        (2, "Test"),
        (1, "Test2")
    ]
    g.states = [
        [
            [(2, 1)],
            [
                (1, 2),
                (1, 3)
            ],
            [(2, 1)],
            [(2, 1)],
        ],
        [[(1, 2), (1, 3)]],
    ]
    g.number2symbol = {
        2: "Test",
        1: "Test2"
    }
    g.keywords = {
        "Test": 2,
        "Test2": 1
    }
    g.tokens = {
        2: 2,
        1: 1
    }
    g.symbol2label

# Generated at 2022-06-23 15:31:50.833667
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("test_Grammar.pickle")

# Generated at 2022-06-23 15:31:54.055825
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    g.loads(pickle.dumps(g.__getstate__()))

if __name__ == "__main__":
    # Run the unit test
    test_Grammar_loads()

# Generated at 2022-06-23 15:32:01.265822
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # pylint: disable=no-self-use,protected-access
    # Dummy grammar
    g = Grammar()
    g.symbol2number = {}
    g.number2symbol = {}
    g.states = [
        [
            [(1, 2), (2, 4), (5, 6), (6, 8)],
            [(1, 1), (1, 1), (1, 2), (1, 4), (1, 6)],
            [(1, 3), (1, 3)],
            [(1, 2), (1, 2)],
            [(1, 5), (1, 5)],
            [(1, 7), (1, 7)],
            [(1, 6), (1, 8)],
        ]
    ]

# Generated at 2022-06-23 15:32:08.775295
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    g.symbol2number["test"] = 0
    g.number2symbol[1] = "test"
    g.states.append([])
    g.states.append([])
    g.dfas[1] = (g.states[1], {})
    g.labels.append((2, "test"))
    g.keywords["test"] = 5
    g.tokens[6] = 7
    g.symbol2label["test"] = 8
    g.start = 8
    g.async_keywords = True

    h = g.copy()

    assert h is not g
    assert h.symbol2number == g.symbol2number
    assert h.number2symbol == g.number2symbol
    assert h.states == g.states

# Generated at 2022-06-23 15:32:18.839935
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io
    import unittest.mock

    # Create an empty grammar object
    g = Grammar()
    g.symbol2number = {'ANDAND': 1, 'AND': 2, 'AS': 3}
    g.number2symbol = {1: 'ANDAND', 2: 'AND', 3: 'AS'}
    g.states = [[(0, 0)], [(0, 0)]]
    g.dfas = {
        1: (
            [(0, 0)],
            {0: 2},
        ),
        2: (
            [(0, 0)],
            {0: 2},
        ),
        3: (
            [(0, 0)],
            {0: 2},
        ),
    }

# Generated at 2022-06-23 15:32:20.673871
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()


if __name__ == "__main__":
    test_Grammar()

# Generated at 2022-06-23 15:32:22.381136
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()

    # assert grammar.load() == 'foo'
    assert True

# Generated at 2022-06-23 15:32:31.536105
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    gram = Grammar()
    gram.dfas = {1: [], 2: []}
    gram.symbol2number = {"a": 256, "b": 257}
    gram.number2symbol = {256: "a", 257: "b"}
    gram.states = [[[(0, 257)]]]
    gram.tokens = {1: 2}
    gram.keywords = {"async": 3}
    gram.labels = [(3, "async")]
    gram.symbol2label = {"b": 257}
    gram.start = 256
    gram.async_keywords = False

    with tempfile.TemporaryDirectory() as dirname:
        filename = os.path.join(dirname, "grammar.pkl")
        gram.dump(filename)
        gramm = Grammar()

# Generated at 2022-06-23 15:32:37.882019
# Unit test for method load of class Grammar
def test_Grammar_load():
    input = {'symbol2number': {'foo': 256, 'bar': 257},
             'number2symbol': {256: 'foo', 257: 'bar'},
             'states': [[[(257, 2), (256, 1)], [(0, 2)], [(1, 3), (0, 3)]]],
             'dfas': {},
             'labels': [(0, 'EMPTY'), (257, None), (256, None), (1, None)],
             'keywords': {},
             'tokens': {},
             'start': 256}

    gram = Grammar()
    gram.load(input)

    assert gram.symbol2number == {'foo': 256, 'bar': 257}
    assert gram.number2symbol == {256: 'foo', 257: 'bar'}

# Generated at 2022-06-23 15:32:46.786993
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    from . import python_grammar

    grammar = Grammar()
    pkl = python_grammar.pkl
    grammar.loads(pkl)
    assert grammar.number2symbol == python_grammar.number2symbol
    assert grammar.symbol2number == python_grammar.symbol2number
    assert grammar.states == python_grammar.states
    assert grammar.dfas == python_grammar.dfas
    assert grammar.labels == python_grammar.labels
    assert grammar.start == python_grammar.start
    assert grammar.keywords == python_grammar.keywords
    assert grammar.tokens == python_grammar.tokens

# Generated at 2022-06-23 15:32:56.493773
# Unit test for constructor of class Grammar
def test_Grammar():
    from . import token

    gr = Grammar()

    assert gr.symbol2number == {}
    assert gr.number2symbol == {}
    assert gr.states == []
    assert gr.dfas == {}
    assert gr.labels == [(0, "EMPTY")]
    assert gr.keywords == {}
    assert gr.tokens == {}
    assert gr.symbol2label == {}
    assert gr.start == 256

    # None of these should raise any exception
    gr.copy()
    gr.report()

    # None of these should raise any exception
    gr.load(b"")
    gr.loads(b"")

# Generated at 2022-06-23 15:33:02.449750
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen

    # Test loading of grammars
    rule_grammar = Grammar()
    pgen.pgen(rule_grammar)
    loaded_grammar = Grammar()
    loaded_grammar.load("Grammar.pickle")
    # Compare the loaded and pgen created grammars
    assert loaded_grammar.__dict__ == rule_grammar.__dict__

# Generated at 2022-06-23 15:33:07.513263
# Unit test for method report of class Grammar
def test_Grammar_report():
    from . import pgen
    from io import StringIO
    from contextlib import redirect_stdout

    f = StringIO()
    with redirect_stdout(f):
        pgen.main()
    s = f.getvalue()

    assert "keywords" in s
    assert "s2n" in s
    assert "n2s" in s
    assert "states" in s
    assert "dfas" in s
    assert "labels" in s
    assert "start 256" in s

# Generated at 2022-06-23 15:33:18.015509
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    import sys
    import io

    new_stdout, new_stderr = io.StringIO(), io.StringIO()
    old_stdout, old_stderr = sys.stdout, sys.stderr
    try:
        sys.stdout, sys.stderr = new_stdout, new_stderr
        grammar.report()
        grammar.dump("test_Grammar_dump")
    finally:
        sys.stdout, sys.stderr = old_stdout, old_stderr
    output = new_stdout.getvalue().strip()
    assert output == ""
    output = new_stderr.getvalue().strip()

# Generated at 2022-06-23 15:33:28.994114
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    grammar = Grammar()
    grammar.symbol2number = {
        'stmt': 1,
    }
    grammar.number2symbol = {
        1: 'stmt',
    }
    grammar.states = [
        [[(0, 1)]]
    ]
    grammar.dfas = {
        1: ([[(0, 1)]], {1: 1})
    }
    grammar.labels = [(0, 'EMPTY'), (1, 'stmt')]
    grammar.keywords = {
        'stmt': 1,
    }
    grammar.tokens = {
        1: 1,
    }
    grammar.symbol2label = {
        'stmt': 1,
    }
    grammar.start = 1

    new_grammar = grammar.copy()
    assert new_gram

# Generated at 2022-06-23 15:33:39.223460
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    gr = Grammar()
    gr.symbol2number = {'method 1': 1}
    gr.number2symbol = {1: 'method 1'}
    gr.labels = [('labels 1', 1)]
    gr.states = [('states 1', 1)]
    gr.start = 1
    gr.async_keywords = False
    gr.tokens = {1: ('tokens 1', 1)}
    gr.symbol2label = {'symbol_label 1': 1}
    gr.dfas = {1: ('dfas 1', 1)}
    gr.keywords = {'keywords 1': 1}
    gr2 = gr.copy()
    for attr, val in gr.__dict__.items():
        assert val == getattr(gr2, attr)


# Generated at 2022-06-23 15:33:48.632040
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g
    g.add_symbol("foo", "s")
    g.add_symbol("bar", "s")
    g.add_state({0:[(1, 2)], 1:[(3, 2)]})
    g.add_state({4:[(5, 2)], 1:[(6, 2)]})
    assert list(g.states[0]) == [(1, 2)]
    assert list(g.states[1]) == [(3, 2)]
    g.add_dfa(0, 1, 3)
    assert list(g.dfas[0][0]) == [(1, 2)]
    assert list(g.dfas[0][1].keys()) == [1, 3]
    assert list(g.dfas[1][0]) == [(4, 2)]
   

# Generated at 2022-06-23 15:33:51.704949
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    from .pgen2 import driver

    g = driver.load_grammar("Grammar/Grammar")
    assert g.copy() is not g

# Generated at 2022-06-23 15:33:52.313202
# Unit test for method report of class Grammar
def test_Grammar_report():
    Grammar().report()

# Generated at 2022-06-23 15:33:55.185892
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()

    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert not g.async_keywords

# Generated at 2022-06-23 15:34:07.070773
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g1.symbol2number = {"a": 1}
    g1.number2symbol = {1: "a"}
    g1.dfas = {1: ([(1,1)]*100, {1: 1}*100)}
    g1.keywords = {"a": "a"}
    g1.tokens = {1: 1}
    g1.symbol2label = {"a": 1}
    g1.labels = [(1, "1")]*100
    g1.states = [([(1,1)]*100, {1: 1}*100)]*100
    g1.start = 1
    g1.async_keywords = True
    g2 = g1.copy()
    assert g2 is not g1
    assert g2.sy

# Generated at 2022-06-23 15:34:10.349321
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    pkl = pickle.dumps({"a": 1}, pickle.HIGHEST_PROTOCOL)
    grammar = Grammar()
    grammar.loads(pkl)
    assert grammar.a == 1

# Generated at 2022-06-23 15:34:20.223973
# Unit test for constructor of class Grammar
def test_Grammar():
    import unittest
    import sys
    from typing import List

    class GrammarTestCase(unittest.TestCase):
        def setUp(self) -> None:
            self.g = Grammar()

        def test_initial_attributes(self) -> None:
            self.assertEqual(self.g.symbol2number, {})
            self.assertEqual(self.g.number2symbol, {})
            self.assertEqual(self.g.states, [])
            self.assertEqual(self.g.dfas, {})
            self.assertEqual(self.g.labels, [(0, "EMPTY")])
            self.assertEqual(self.g.keywords, {})
            self.assertEqual(self.g.tokens, {})

# Generated at 2022-06-23 15:34:31.052501
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    import unittest
    import hashlib
    from parser.pgen2.parser import parse, tokenize, Grammar

    g = Grammar()

# Generated at 2022-06-23 15:34:40.137732
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[(1, 2)], [(2, 3)]]
    g.dfas = {1: ([(2, 3)], {1: 1, 2: 2}), 2: ([(3, 4)], {3: 1, 4: 2})}
    g.labels = [(1, '1st'), (2, None), (3, '3rd'), (4, None)]
    g.start = 1
    g.keywords = {'a': 1, 'b': 2}
    g.tokens = {1: 3, 2: 4}

# Generated at 2022-06-23 15:34:41.450969
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    g.report()
    # test that constructor doesn't result in errors
    pass

# Generated at 2022-06-23 15:34:47.428900
# Unit test for constructor of class Grammar
def test_Grammar():
    grammar = Grammar()
    assert grammar.symbol2number == {}
    assert grammar.number2symbol == {}
    assert grammar.states == []
    assert grammar.dfas == {}
    assert grammar.labels == [(0, "EMPTY")]
    assert grammar.keywords == {}
    assert grammar.tokens == {}
    assert grammar.symbol2label == {}
    assert grammar.start == 256
    assert grammar.async_keywords == False

# Generated at 2022-06-23 15:34:52.728732
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2 import driver

    d = driver.Driver()
    d.parse_grammar('Grammar/Grammar', "a : b c d ")
    pkl_file = '/tmp/python_grammar_pickle'
    d.grammar.dump(pkl_file)
    d.grammar.load(pkl_file)
    os.remove(pkl_file)


# Generated at 2022-06-23 15:35:02.304403
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Not really testing anything, but just making sure dump()
    # works and produces the same content as Grammar().load()
    def check():
        g1 = Grammar()
        g2 = Grammar()
        g1.dump("graminit.tmp")
        g2.load("graminit.tmp")
        assert g1.__dict__ == g2.__dict__
        os.unlink("graminit.tmp")
    check()
    # Also test the case where the module is imported from
    # a different directory.
    # In this case, the filename is either __main__.py or __main__.pyc
    oldpwd = os.getcwd()
    os.chdir(os.path.dirname(__file__))
    check()
    os.chdir(oldpwd)

# Generated at 2022-06-23 15:35:14.296242
# Unit test for method report of class Grammar
def test_Grammar_report():
    from io import StringIO
    from contextlib import redirect_stdout

    g = Grammar()
    g.symbol2number = {
        "a": 0,
        "b": 1,
        "c": 2,
        "d": 3,
        "e": 4,
        "f": 5,
        "g": 6,
    }

    g.number2symbol = {
        0: "a",
        1: "b",
        2: "c",
        3: "d",
        4: "e",
        5: "f",
        6: "g",
    }

    g.labels = [(0, "EMPTY"), (1, "a"), (2, "b"), (3, "c")]


# Generated at 2022-06-23 15:35:25.284171
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    # prepare fake data
    s2n = {'A': 257}
    n2s = {257: 'A'}
    dfas = {257: ([[(128, 0)]], {0: 0})}
    keywords = {'class': 128}
    tokens = {10: 128}
    symbol2label = {'class': 128}
    labels = [(0, 'EMPTY'), (10, 'CLASS')]
    states = [[[(128, 0)]]]
    start = 256
    async_keywords = False

    # put fake data into the Grammar
    grammar = Grammar()
    grammar.symbol2number = s2n
    grammar.number2symbol = n2s
    grammar.dfas = dfas
    grammar.keywords = keywords
    grammar.tokens = tokens
    grammar.sy

# Generated at 2022-06-23 15:35:27.390494
# Unit test for method report of class Grammar
def test_Grammar_report():
    from .pgen2 import driver
    g = driver.load_grammar(test_grammar)
    g.report()


# Generated at 2022-06-23 15:35:33.520502
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Make a brand new grammar and save it
    g = Grammar()
    g.symbol2number["foo"] = 42
    g.dump("Foo.pickle")

    # Reload it, and compare
    g2 = Grammar()
    g2.load("Foo.pickle")
    assert g2.symbol2number == g.symbol2number

# Generated at 2022-06-23 15:35:39.016520
# Unit test for method load of class Grammar
def test_Grammar_load():
    import io
    import pgen_test
    import parse

    g = pgen_test.GetGrammar()
    for gfile, gpickle in pgen_test.gen_gfiles_gpickles():
        g.load(gfile)
        g.dump(gpickle)

    # make sure that load can order the keys; this matters because
    # the pickle order differs on different platforms
    s = io.BytesIO()
    g.dump(s)
    s.seek(0)
    g = Grammar()
    g.loads(s.read())

    # make sure the parsing engine sees the right thing
    p = parse.Parser(g)
    p.setup()

    # make sure the parser engine can handle strings as input
    p = parse.Parser(g)
    p.setup()



# Generated at 2022-06-23 15:35:50.669178
# Unit test for constructor of class Grammar
def test_Grammar():
    s = Grammar()

    s.symbol2number = {'DEDENT': 257, 'a': 258}
    assert s.symbol2number == {'DEDENT': 257, 'a': 258}

    s.number2symbol = {257: 'DEDENT', 258: 'a'}
    assert s.number2symbol == {257: 'DEDENT', 258: 'a'}

    s.states = [
        [(1, 1), (2, 1), (3, 1), (4, 2), (5, 3), (6, 4)],
        [],
        [],
        [],
        [],
        [],
        []
    ]

# Generated at 2022-06-23 15:36:02.213093
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    g.start = 5
    g.labels.append((1, "foo"))
    g.keywords["def"] = 1
    g.states.append([(1, 1), (1, 1)])
    g.tokens[1] = 2
    g.symbol2number["foo"] = 3
    g.number2symbol[3] = "foo"
    g.dfas[5] = ([[1]], {1: 1},)
    g.async_keywords = True

    import pickle

    g_copy = Grammar()
    g_copy.loads(pickle.dumps(g))
    assert g_copy.start == g.start
    assert g_copy.labels == g.labels
    assert g_copy.keywords == g.keywords

# Generated at 2022-06-23 15:36:04.866822
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    f = "test"
    g.dump(f)
    g.load(f)
    os.remove(f)

# Generated at 2022-06-23 15:36:15.258102
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    assert grammar.states == []
    assert grammar.dfas == {}
    assert grammar.labels == [(0, "EMPTY")]
    assert grammar.keywords == {}
    assert grammar.tokens == {}
    assert grammar.start == 256
    assert grammar.async_keywords == False

    grammar.states = [[]]
    grammar.dfas = {"test": ([], {})}
    grammar.labels = [("test1", "test2")]
    grammar.keywords = {"test3": "test4"}
    grammar.tokens = {"test5": "test6"}
    grammar.start = 1024

    # Try to dump pickle file
    filename = "./testfile.pkl"

# Generated at 2022-06-23 15:36:22.733573
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import unittest
    from .tokenize import generate_tokens
    from .pgen2 import tokenize

    # This is sort of a hack to test Grammar.copy().  We use tokenize()
    # to produce the grammar we want to copy, and we use the copy to
    # produce a second parser.
    g = Grammar()
    g2 = g.copy()
    tokenize(generate_tokens(iter("").__next__), g2)
    assert g2.start == 256

# Generated at 2022-06-23 15:36:25.029450
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    gram = Grammar()
    gram.dump('dummy.pickle')
    assert os.path.exists('dummy.pickle')
    os.remove('dummy.pickle')

# Generated at 2022-06-23 15:36:28.954028
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    class DummyGrammar(Grammar):
        pass
    dummy_grammar = DummyGrammar()
    dummy_file = 'dummy_file'
    try:
        dummy_grammar.dump(dummy_file)
    except Exception:
        assert False
    else:
        assert True

# Generated at 2022-06-23 15:36:34.710923
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords == False


# Generated at 2022-06-23 15:36:36.671552
# Unit test for method load of class Grammar
def test_Grammar_load():
    gr = Grammar()
    gr.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    gr.report()

# Generated at 2022-06-23 15:36:37.830740
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    pass

# Generated at 2022-06-23 15:36:49.253863
# Unit test for method report of class Grammar
def test_Grammar_report():
    from io import StringIO
    from pprint import pprint

    g = Grammar()

    # initialize
    g.symbol2number = {
        "single_input": 257,
        "eval_input": 258,
        "file_input": 259,
        "decorator": 260,
    }
    g.number2symbol = {
        257: "single_input",
        258: "eval_input",
        259: "file_input",
        260: "decorator",
    }

# Generated at 2022-06-23 15:36:58.423990
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import unittest
    import unittest.mock

    class GrammarTestCase(unittest.TestCase):
        def setUp(self) -> None:

            self.grammar = Grammar()
            self.grammar.symbol2number = {"a":1}
            self.grammar.number2symbol = {1:"a"}
            self.grammar.states = [[[(1,2)], [(1,3)]]]
            self.grammar.dfas = {1: ([[(1,2)], [(1,3)]], {2:3})}
            self.grammar.labels = [(256, "a"), (257, "b")]
            self.grammar.keywords = {'a':256}

# Generated at 2022-06-23 15:37:02.801634
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import parser
    g = parser.Grammar()

    with tempfile.NamedTemporaryFile() as f:
        filename = f.name
        g.dump(filename)
        with open(filename, 'rb') as pkl:
            table = pickle.load(pkl)

    assert filename.endswith('.pickle')

    assert table == g.__dict__


# Generated at 2022-06-23 15:37:12.436756
# Unit test for method report of class Grammar
def test_Grammar_report():
    import StringIO
    import sys
    output = StringIO.StringIO()
    old_stdout = sys.stdout

# Generated at 2022-06-23 15:37:16.230118
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.start == 257
    assert g.number2symbol[257] == 'file_input'
    assert g.symbol2label['atom'] == 258
    assert g.tokens[token.NAME] == 259
    assert g.tokens[token.NUMBER] == 260

# Generated at 2022-06-23 15:37:26.031288
# Unit test for method load of class Grammar
def test_Grammar_load():
    # pytype: disable=module-attr
    from . import conv

# Generated at 2022-06-23 15:37:37.297042
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number["a"] = 1
    g.number2symbol[1] = "a"
    g.dfas[1] = 1
    g.keywords["a"] = 1
    g.tokens[1] = 1
    g.symbol2label["a"] = 1
    g.labels = [(1, "a")]
    g.states = [1]
    g.start = 1
    g.async_keywords = True

    h = g.copy()
    assert h.symbol2number == g.symbol2number
    assert h.number2symbol == g.number2symbol
    assert h.dfas == g.dfas
    assert h.keywords == g.keywords
    assert h.tokens == g.tok

# Generated at 2022-06-23 15:37:38.313845
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()

# Generated at 2022-06-23 15:37:41.965535
# Unit test for method report of class Grammar
def test_Grammar_report():
    # This test makes no real assertions besides checking that
    # the method doesn't crash, and that it prints certain
    # substrings to stdout.
    grammar = Grammar()
    grammar.report()

# Generated at 2022-06-23 15:37:52.461581
# Unit test for method report of class Grammar
def test_Grammar_report():
    grammar = Grammar()
    grammar.symbol2number = {"symbol": 25}
    grammar.number2symbol = {25: "number"}
    grammar.states = [
        [
            [(1, 1), (2, 2)],
            [(3, 3), (4, 4)],
            [(5, 5), (6, 6)],
        ]
    ]
    grammar.dfas = {1: ([[(1, 2)]], {1: 1, 2: 2})}
    grammar.labels = [(10, "label"), (20, None)]
    grammar.keywords = {"key1": 10, "key2": 10}
    grammar.tokens = {1: 10, 2: 20}
    grammar.start = 10
    grammar.report()

# Generated at 2022-06-23 15:37:54.573796
# Unit test for constructor of class Grammar
def test_Grammar():
    #First test the constructor
    g=Grammar()
    assert g
    

# Generated at 2022-06-23 15:38:03.586553
# Unit test for method load of class Grammar
def test_Grammar_load():
    class GrammarForTest(Grammar):
        def __init__(self) -> None:
            super().__init__()

# Generated at 2022-06-23 15:38:16.108998
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    class Fake:
        pass
    g = Fake()
    g.symbol2number = {'a': 1, 'b': 2}
    g.number2symbol = {1: 'a', 2: 'b'}
    g.dfas = {3: (4, 5)}
    g.keywords = {'foo': 6, 'bar': 7}
    g.tokens = {8: 9, 10: 11, 12: 13}
    g.symbol2label = {'c': 14, 'd': 15}
    g.labels = [(16, 'y'), (17, 'z')]
    g.states = [18, 19]
    g.start = 20
    g.async_keywords = True
    h = g.copy()
    # dicts don't have __eq__ methods, so

# Generated at 2022-06-23 15:38:25.889786
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    # pylint: disable=invalid-name
    # pylint: disable=no-member
    # pylint: disable=protected-access
    from . import alphabet
    from .conv import conv_table
    from .pgen import grammar, driver
    from .tokenizer import Tokenizer

    Grammar.async_keywords = False
    g = Grammar()
    conv_table.convert(g)
    g2 = g.copy()
    # g2 is not g
    assert g2 is not g
    # g2.symbol2number is not g.symbol2number
    assert g2.symbol2number is not g.symbol2number
    # g2.symbol2number == g.symbol2number
    assert g2.symbol2number == g.symbol2number
    # g

# Generated at 2022-06-23 15:38:28.168462
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    assert(Grammar().loads(pickle.dumps(dict())) == None)

# Generated at 2022-06-23 15:38:40.332296
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-23 15:38:50.402317
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    import os
    import tempfile

    def grammar_pkl(g):
        return pickle.dumps(g.__getstate__())

    def grammar_tmp_pkl(g):
        f = tempfile.NamedTemporaryFile(delete=False)
        try:
            pickle.dump(g.__getstate__(), f, pickle.HIGHEST_PROTOCOL)
        finally:
            f.close()
        return f.name

    def grammar_tmp_load_pkl(f):
        g = Grammar()
        with open(f, "rb") as f:
            g.loads(f.read())
        return g


# Generated at 2022-06-23 15:38:51.767147
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump('/tmp/foo')

# Generated at 2022-06-23 15:39:00.578213
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.symbol2number = {'foo': 1}
    g.number2symbol = {1: 'foo'}
    g.states = [[(0,1)]]
    g.dfas = {1: ([[(0,1)]], {})}
    g.labels = [(0, 'foo')]
    g.start = 1
    with open("/dev/null", "w") as f:
        save_stdout = sys.stdout
        sys.stdout = f
        g.report()
        sys.stdout = save_stdout

# Generated at 2022-06-23 15:39:01.519703
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()



# Generated at 2022-06-23 15:39:09.217066
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import conv

    g = Grammar()
    conv.pgen_grammar_to_grammar(g, "Python.asdl", "Python/Grammar.h")
    filename = "test.pickle"
    g.dump(filename)
    g2 = Grammar()
    g2.load(filename)
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label
    assert g

# Generated at 2022-06-23 15:39:11.166125
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("/src/python/Lib/pyparsing.py")
    grammar.states[0]

# Generated at 2022-06-23 15:39:15.224933
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("test_dump.pkl")
    g.load("test_dump.pkl")
    assert g.start == 256


# Generated at 2022-06-23 15:39:25.908566
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import pickle
    from . import pgen
    from .pgen2 import driver
    from . import token

    with open("Grammar.pickle", "rb") as f:
        g = pickle.load(f)

    def _check_Grammar(g: Grammar) -> None:
        assert len(g.symbol2number) == len(g.number2symbol)
        assert len(g.states) == len(g.dfas)
        assert len(g.labels) == len(g.labels)
        assert g.start >= token.NT_OFFSET
        assert all(key in g.dfas for key in g.symbol2number.values())

    g2 = Grammar()
    g2.loads(pickle.dumps(g))

# Generated at 2022-06-23 15:39:29.462438
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = os.path.join(os.path.dirname(__file__), "Grammar.pickle")
    g = Grammar()
    g.dump(filename)

# Generated at 2022-06-23 15:39:41.521018
# Unit test for method dump of class Grammar

# Generated at 2022-06-23 15:39:52.327681
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g2 = g1.copy()
    assert g1 is not g2
    assert g1.symbol2number is not g2.symbol2number
    assert g1.number2symbol is not g2.number2symbol
    assert g1.dfas is not g2.dfas
    assert g1.keywords is not g2.keywords
    assert g1.tokens is not g2.tokens
    assert g1.symbol2label is not g2.symbol2label
    assert g1.labels is not g2.labels
    assert g1.states is not g2.states
    assert g1.start is g2.start
    assert g1.async_keywords == g2.async_keywords

# Generated at 2022-06-23 15:40:04.339381
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Test the method load of class Grammar"""
    g = Grammar()
    g.load("Grammar.pickle")
    assert g.symbol2number['_STMT'] == 258
    assert g.number2symbol[258] == '_STMT'
    assert g.states[0][0][0][0] == 0
    assert g.states[0][0][0][1] == 1
    assert g.dfas[258][0][0][0][0] == 0
    assert g.dfas[258][0][0][0][1] == 1
    assert g.labels[0] == (0, "EMPTY")
    assert g.labels[1] == (1, None)
    assert g.keywords[','] == 2
    assert g.tokens[41] == 3


# Generated at 2022-06-23 15:40:08.324449
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    filename = r'C:\Users\Jonas\Code\Python\Python\Lib\importlib\_bootstrap_external.py'
    with open(filename, 'rb') as file:
        grammar_pkl = file.read()
    g = Grammar()
    g.loads(grammar_pkl)
    print(g.symbol2number)