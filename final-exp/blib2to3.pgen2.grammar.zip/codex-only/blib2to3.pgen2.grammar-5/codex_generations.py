

# Generated at 2022-06-23 15:30:09.252207
# Unit test for constructor of class Grammar
def test_Grammar():
    from .pgen2 import driver  # type: ignore

    """
    def setUp(self):
        self.gr = gr = Grammar()
        f = StringIO(SAMPLE)
        driver.parse_grammar(f, "sample.txt", gr)
    """
    gr = Grammar()
    f = open("Grammar.txt", "r")
    driver.parse_grammar(f, "sample.txt", gr)
    print("end")



# Generated at 2022-06-23 15:30:17.785477
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    from .pgen2 import driver

    grammar = Grammar()
    driver.load_grammar("Grammar.txt", "Grammar.pickle", "Grammar.py", grammar)
    grammar2 = Grammar()
    grammar2.loads(grammar.dumps())
    assert grammar.symbol2number == grammar2.symbol2number
    assert grammar.number2symbol == grammar2.number2symbol
    assert grammar.states == grammar2.states
    assert grammar.dfas == grammar2.dfas
    assert grammar.labels == grammar2.labels
    assert grammar.keywords == grammar2.keywords
    assert grammar.tokens == grammar2.tokens
    assert grammar.symbol2label == grammar2.symbol2label
    assert grammar.start == grammar2.start
    assert grammar

# Generated at 2022-06-23 15:30:23.584396
# Unit test for method report of class Grammar
def test_Grammar_report():
    # The Grammar class is not intended to be constructed directly.
    # This test only calls the method report, because this is the only
    # class method actually needed, while the rest of the class
    # accesses the instance variables directly.
    grammar = Grammar()
    grammar.report()

del opmap_raw, test_Grammar_report

# Generated at 2022-06-23 15:30:25.342655
# Unit test for constructor of class Grammar
def test_Grammar():
    gram = Grammar()
    assert len(gram.states) == 0
    assert len(gram.start) == 256

# Generated at 2022-06-23 15:30:28.836827
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    A = Grammar()
    A.start = 1234
    B = A.copy()
    assert id(A) != id(B)
    assert A.start == B.start
    A.states = "foo"
    assert A.states != B.states
    assert B.states == []

# Generated at 2022-06-23 15:30:40.676137
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    gram = Grammar()
    # set up some dummy data
    gram.symbol2number = {"foo": 5, "bar": 6}
    gram.number2symbol = {5: "foo", 6: "bar"}
    gram.states = []
    gram.dfas = {"whiz": (1, 2)}
    gram.labels = [("wibble", None), ("bang", "foo")]
    gram.keywords = {"baz": ("brazen", "frobnitz")}
    gram.tokens = {"xyzzy": 42}
    gram.symbol2label = {"roger": 42}
    gram.start = 256
    gram.async_keywords = False

    filename = "gram_dump_test"

    # clear file if exists

# Generated at 2022-06-23 15:30:49.317300
# Unit test for method report of class Grammar
def test_Grammar_report():
    grammar = Grammar()

    grammar.symbol2number["Symbol1"] = 1
    grammar.symbol2number["Symbol2"] = 2
    grammar.number2symbol[1] = "Number1"
    grammar.number2symbol[2] = "Number2"
    grammar.states = [
        [
            [[1, 1], [2, 2]],
            [[1, 1], [2, 2]],
            [[1, 1], [2, 2]],
            [[0, 3]],
        ],
        [
            [[3, 3], [4, 4]],
            [[3, 3], [4, 4]],
            [[3, 3], [4, 4]],
            [[0, 5]],
        ],
    ]

# Generated at 2022-06-23 15:30:57.017363
# Unit test for method load of class Grammar
def test_Grammar_load():
    from textwrap import dedent
    import os
    import pickle
    from . import token

    def get_token(name):
        return getattr(token, name)

    # Arrange

    # Act

    # Assert


# Generated at 2022-06-23 15:31:08.218045
# Unit test for method report of class Grammar
def test_Grammar_report():
    from .conv import parse_grammar
    from .parse import ParserGenerator
    from .pgen2 import driver
    pgen = driver.main()
    parser = ParserGenerator(pgen.pgen_grammar)
    parser.st2tok = pgen.st2tok
    driver.grammar_file = driver.grammar_file.replace(driver.grammar_name, 'test_grammar')
    driver.grammar_name = 'test_grammar'
    driver.output_dir = os.path.join(driver.output_dir, 'test')
    os.makedirs(driver.output_dir, exist_ok=True)
    gram = parse_grammar(parser.grammar, "", "", "", "")
    gram.report()

# Generated at 2022-06-23 15:31:20.016684
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    grammar = Grammar()
    pkl = b"\x80\x03}q\x00]q\x01}q\x02(X\x04\x00\x00\x00tokensq\x03}q\x04(K\x04\x00\x00\x00\x00K\x11\x00\x00\x00\x00}q\x05(h\x04K\x11h\x04K\x11\x87q\x06(h\x04K\x11h\x04K\x11X\x05\x00\x00\x00EMPTYq\x07eub."
    grammar.loads(pkl)
    assert grammar.tokens == {4: 17}

# Generated at 2022-06-23 15:31:31.468067
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {"foo": 10}
    g.number2symbol = {10: "foo"}
    g.states = [[(1, 2), (3, 4)]]
    g.dfas = {10: (0, 1)}
    g.labels = [(0, None), (1, "foo"), (2, "bar"), (3, "baz")]
    g.keywords = {"foo": 1}
    g.tokens = {1: 1}
    g.symbol2label = {"baz": 3}
    g.start = 10
    g.async_keywords = False
    g2 = g.copy()
    # Dictionary attributes are copied (as mutable objects)
    assert g.symbol2number is not g2.symbol2number


# Generated at 2022-06-23 15:31:39.345593
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    import pickle
    from . import pickletools

    # Create a grammar object
    g = Grammar()

    # Load the grammar tables from a pickle file; this is the slowest
    # way to initialize the tables because it involves parsing Python
    # source files.
    g.load(pickletools._PickleTools__file_path)

    # Pickle the grammar tables
    pkl = pickle.dumps(g, pickle.HIGHEST_PROTOCOL)

    # Reset the grammar tables
    g = Grammar()

    # Load the grammar tables from a pickle bytes object; this is the
    # fastest way to initialize the tables
    g.loads(pkl)

    # Reset the grammar tables
    g = Grammar()

    # Load the grammar tables from a pickle file; this is the slowest
    # way

# Generated at 2022-06-23 15:31:49.955240
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    import io
    import pickle

    # The grammar tables compiled from Grammar/Grammar
    from . import pgen2_grammar as pgen2_grammar_mod

    data = io.BytesIO()
    pgen2_grammar_mod.pgen2_grammar.dump(data)
    data.seek(0)
    pickle_grammar = Grammar()
    pickle_grammar.loads(data.read())

    pgen2_grammar = pgen2_grammar_mod.pgen2_grammar
    assert pgen2_grammar.symbol2number == pickle_grammar.symbol2number
    assert pgen2_grammar.number2symbol == pickle_grammar.number2symbol
    assert pgen2_grammar.states == pickle_grammar.states

# Generated at 2022-06-23 15:31:58.573026
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {"a": 1}
    g.number2symbol = {1: "a"}
    g.states = [(1,2)]
    g.dfas = {1: ((1,2), {3: 4})}
    g.labels = [(1, 2)]
    g.keywords = {"a": 1}
    g.tokens = {1: 1}
    g.symbol2label = {"a": 1}
    g.start = 1
    g.async_keywords = False
    h = g.copy()
    assert h is not g
    assert h.symbol2number == g.symbol2number
    assert h.number2symbol == g.number2symbol
    assert h.states == g.states
    assert h.df

# Generated at 2022-06-23 15:31:59.785303
# Unit test for method load of class Grammar
def test_Grammar_load():
    print("Testing Grammar.load")
    assert False



# Generated at 2022-06-23 15:32:06.567239
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    from itertools import count

    class testGrammar(Grammar):

        def __init__(self):
            super().__init__()

# Generated at 2022-06-23 15:32:10.032246
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    # Test that the report method does not crash on a new object with
    # no attributes
    assert g.report() is None

# Generated at 2022-06-23 15:32:20.929570
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    g.symbol2number['TEST'] = 256
    g.number2symbol[256] = 'TEST'
    g.states = [[0]]
    g.dfas = {256: ([0], {1: 1})}
    g.labels = [(1, None)]
    g.keywords = {'NAME': 0}
    g.tokens = {1: 0}
    g.symbol2label['NAME'] = 0
    g.start = 256
    g.async_keywords = False
    # This block is to create a GS
    with open("grammar.pkl", "wb") as f:
        pickle.dump(vars(g), f, pickle.HIGHEST_PROTOCOL)
    # This block is to test load()
    s

# Generated at 2022-06-23 15:32:30.683351
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    def assert_file_exists_and_contains_data(filename):
        assert os.path.isfile(filename)
        assert os.path.getsize(filename) > 0

    def assert_files_are_equal(filename1, filename2):
        with open(filename1, "rb") as fp1:
            data1 = fp1.read()
        with open(filename2, "rb") as fp2:
            data2 = fp2.read()
        assert data1 == data2

    def assert_file_has_been_deleted(filename):
        assert os.path.isfile(filename) == False

    def setup_file(filename, data):
        with open(filename, "wb") as fp:
            fp.write(data)

    # Create a file with some data inside
   

# Generated at 2022-06-23 15:32:37.275023
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import copy
    old = Grammar()
    old.symbol2number = {'a': 1, 'b': 2, 'c': 3}
    old.number2symbol = {1: 'a', 2: 'b', 3: 'c'}
    old.dfas = {1: 'a', 2: 'b', 3: 'c'}
    old.keywords = {1: 'a', 2: 'b', 3: 'c'}
    old.tokens = {1: 'a', 2: 'b', 3: 'c'}
    old.symbol2label = {1: 'a', 2: 'b', 3: 'c'}
    old.labels = ['a', 'b', 'c']
    old.states = ['a', 'b', 'c']
    old.start = 1


# Generated at 2022-06-23 15:32:46.946696
# Unit test for method load of class Grammar
def test_Grammar_load():
    import datetime
    with tempfile.NamedTemporaryFile() as f:
        filename = f.name
        grammar = Grammar()
        grammar.dump(filename)
        grammar2 = Grammar()
        grammar2.load(filename)
        assert grammar.__dict__ == grammar2.__dict__
        grammar.async_keywords = datetime.datetime.utcnow()
        grammar.dump(filename)
        grammar2.load(filename)
        assert grammar.__dict__ == grammar2.__dict__
        assert grammar.async_keywords == grammar2.async_keywords

if __name__ == "__main__":
    import sys

    if len(sys.argv) == 2:
        g = Grammar()
        g.load(sys.argv[1])
        g.report()

# Generated at 2022-06-23 15:32:58.544749
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    grammar = Grammar()
    grammar.symbol2number = {"name": 1}
    grammar.number2symbol = {1: "name"}
    grammar.states = [1, 2, 3]
    grammar.dfas = {1: (1, 2), 2: (3, 4)}
    grammar.labels = [(1, "name"), (2, "name2")]
    grammar.keywords = {1: "kw1", 2: "kw2"}
    grammar.tokens = {1: "tok1", 2: "tok2"}
    grammar.symbol2label = {1: "l1", 2: "l2"}
    grammar.start = 257
    grammar.async_keywords = True

    new = grammar.copy()
    assert new.symbol2number == grammar.symbol2number


# Generated at 2022-06-23 15:33:06.150726
# Unit test for method report of class Grammar
def test_Grammar_report():
    import sys
    from io import StringIO

    out = StringIO()
    prev, sys.stdout = sys.stdout, out

    g = Grammar()
    g.symbol2number = dict(a=1)
    g.number2symbol = dict(b=2)
    g.states = [3]
    g.dfas = dict(c=4)
    g.labels = [5]
    g.keywords = dict(e=6)
    g.tokens = dict(f=7)
    g.symbol2label = dict(g=8)
    g.start = 9
    g.async_keywords = False
    x = g.report()

    sys.stdout = prev

# Generated at 2022-06-23 15:33:17.010613
# Unit test for method load of class Grammar
def test_Grammar_load():
    s = """\
    symbol2number = {'and': 257, 'or': 258}
    number2symbol = {257: 'and', 258: 'or'}
    states = [[(258, 0), (257, 1)], [(0, 0)]]
    dfas = {257: ([[(257, 1), (0, 1)]], {1: 1}), 258: ([[(258, 1), (0, 1)]], {1: 1})}
    labels = [(0, 'EMPTY'), (257, None), (258, None)]
    keywords = {}
    tokens = {}
    symbol2label = {'and': 257, 'or': 258}
    start = 256
    """
    import io
    import os.path
    import tempfile
    from unittest import mock

    _path = tempfile.mk

# Generated at 2022-06-23 15:33:24.455773
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords is False


# Generated at 2022-06-23 15:33:25.408499
# Unit test for method report of class Grammar
def test_Grammar_report():
    grammar = Grammar()
    grammar.report()

# Generated at 2022-06-23 15:33:31.157417
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    g.loads(b'\x80\x03}q\x00(U\x06tokensq\x01}q\x02U\n\xe9\xdcu\xc2\xe0\x00\x00\x00\x00\x00\x00u.')
    assert g.tokens[token.NAME] == 257

# Generated at 2022-06-23 15:33:37.274691
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    filename = "non_existing_file"
    with open(filename, "w") as f:
        f.write("pickled_grammar")
    try:
        with open(filename, "rb") as f:
            pickled_grammar = f.read()
        g = Grammar()
        g.loads(pickled_grammar)
        assert "pickled_grammar" == g.pickled_grammar
    finally:
        os.remove(filename)

# Generated at 2022-06-23 15:33:43.198063
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    # all the attributes should be initialized properly
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256

# Generated at 2022-06-23 15:33:47.157861
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    print(g.states)
    print(g.symbol2number)
    print(g.number2symbol)
    print(g.dfas)
    print(g.labels)
    print(g.keywords)
    print(g.tokens)
    print(g.start)

# Generated at 2022-06-23 15:33:58.420789
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {"a": 1, "b": 2}
    g.number2symbol = {1: "a", 2: "b"}
    g.dfas = {1: ([[(1, 1)], [(0, 0)]], {2: 3}), 3: ([[(2, 4), (3, 5)]], {4: 4})}
    g.keywords = {"c": 1, "d": 2}
    g.tokens = {1: 1, 2: 3}
    g.symbol2label = {"e": 1, "f": 2}
    g.labels = [(0, "EMPTY"), (1, "c"), (2, None), (3, "d")]

# Generated at 2022-06-23 15:34:04.606495
# Unit test for constructor of class Grammar
def test_Grammar():
    from .parse import pgen

    g = pgen()
    assert "grammar" in g.symbol2number
    assert "Grammar" in g.symbol2number
    assert "Grammar" in g.symbol2label
    assert g.number2symbol[256] == "Grammar"
    assert g.symbol2number["Grammar"] == 256
    assert g.symbol2label["Grammar"] == 256
    assert g.start == 256
    assert g.async_keywords == False
    assert g.keywords == {}
    assert g.tokens == {}
    assert len(g.labels) >= 2
    assert g.labels[1] == (0, "EMPTY")
    assert g.labels[(1, 0)] == 0
    assert g.number2

# Generated at 2022-06-23 15:34:06.084982
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    assert g.copy() is not g

# Generated at 2022-06-23 15:34:14.004894
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    import pgen2.tokenize
    from pgen2.pgen import Grammar
    from pgen2 import driver
    import io
    import unittest

    class TestGrammarFunctions(unittest.TestCase):

        def test_loads(self):
            g = Grammar()
            # test with a non-existent python file
            self.assertRaises(FileNotFoundError, driver.load_grammar, g, "junk.txt")
            # test with a python file that contains a syntax error
            self.assertRaises(pgen2.tokenize.TokenError, driver.load_grammar, g, "junk.py")
            # test with a valid python file
            driver.load_grammar(g, "pgen2/grammar.txt")
            # test with a python file that contains a syntax error

# Generated at 2022-06-23 15:34:18.926436
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g2 = g.copy()
    assert g2 is not g
    for d in g.__dict__:
        assert getattr(g2, d) == getattr(g, d)
    g2.async_keywords = True
    assert g2.async_keywords == True
    assert g.async_keywords == False

# Generated at 2022-06-23 15:34:29.317080
# Unit test for method loads of class Grammar

# Generated at 2022-06-23 15:34:31.603989
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    g.loads(type(g).__module__.encode())

# Generated at 2022-06-23 15:34:32.505668
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()
    pass

# Generated at 2022-06-23 15:34:42.394068
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    def create_dfas():
        dfa = []
        dfa.append([(1, 0), (2, 1)])
        dfa.append([(3, 2)])
        dfa.append([(4, 3)])
        dfa.append([(5, 4), (6, 5)])
        dfa.append([(7, 6)])
        dfa.append([(8, 7)])
        dfa.append([(9, 8)])
        dfa.append([(10, 9)])
        dfa.append([(11, 10)])
        dfa.append([(12, 11)])
        dfa.append([(13, 12)])
        dfa.append([(14, 13)])
        dfa.append([(15, 14)])

# Generated at 2022-06-23 15:34:48.949308
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # create a dummy grammar data
    states = [[(258, 1), (0, 2), (0, 1)], [(259, 1)]]
    symbol2number = {"foo": 257, "bar": 258, "fob": 259}
    number2symbol = {257: "foo", 258: "bar", 259: "fob"}
    dfas = {258: ([[(0, 1)], [(259, 2)]], {})}
    labels = [(0, "EMPTY"), (258, None), (259, None)]
    keywords = {"fob": 259}
    tokens = {}
    symbol2label = {"bar": 258, "fob": 259}
    start = 257
    async_keywords = False
    # pickle the data

# Generated at 2022-06-23 15:34:49.982120
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    from . import pickle as pickle
    g = Grammar()
    g.loads(pickle.grammar)

# Generated at 2022-06-23 15:34:56.839860
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g1.symbol2number = {"one": 1, "two": 2}
    g1.number2symbol = {1: "one", 2: "two"}
    g1.dfas = {1: (1, 1)}
    g1.keywords = {"one": 1}
    g1.tokens = {1: "one"}
    g1.labels = ["one", "two"]
    g1.states = ["one", "two"]
    g1.start = "one"
    g1.async_keywords = True

    g2 = g1.copy()

    # check that all attributes were copied
    for attr in vars(g1):
        assert getattr(g1, attr) == getattr(g2, attr)

# Generated at 2022-06-23 15:35:03.700657
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .conv import convert
    from .pgen2 import driver

    def test_grammar(grammar_str, g=None):
        driver.parse_grammar(grammar_str, create_tables=True, g=g)

    test_grammar("""
    a: b
    b: '!'
    """)
    for g in (Grammar(), convert("Grammar", test_grammar.g)):
        g.load(g.fp.name)
        delattr(test_grammar, "g")
    try:
        g.load("nonexistent.pickle")
    except IOError:
        pass
    else:
        raise Exception("expected IOError")

# Generated at 2022-06-23 15:35:05.148011
# Unit test for method report of class Grammar
def test_Grammar_report():
    gr = Grammar()
    gr.report()
    assert True

# Generated at 2022-06-23 15:35:10.478846
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    import pickle
    from .conv import conv
    from . import pgen2

    g = Grammar()
    g.load(pgen2.parse(conv, "Grammar_loads"))
    g2 = Grammar()
    g2.loads(pickle.dumps(g))

__all__ = ["Grammar", "Label", "test_Grammar_loads"]

# Generated at 2022-06-23 15:35:20.026782
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import sys
    import unittest

    class GrammarCopyTests(unittest.TestCase):
        def test_copy(self):
            for ver in sys.version_info[:2]:
                g = Grammar()
                g.loads(LOADED_GRAMMAR_PICKLE[ver])
                h = g.copy()
                self.assertEqual(g.symbol2number, h.symbol2number)
                self.assertEqual(g.number2symbol, h.number2symbol)
                self.assertEqual(g.dfas, h.dfas)
                self.assertEqual(g.keywords, h.keywords)
                self.assertEqual(g.tokens, h.tokens)

# Generated at 2022-06-23 15:35:22.012162
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    print(id(g))
    print(id(g.copy()))

# Generated at 2022-06-23 15:35:33.573240
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g1.symbol2number = {'!': 259}
    g1.number2symbol = {259: '!'}
    g1.labels = [(0, 'EMPTY'),
                 (40, 'NOTHING'),
                 (259, '!'),
                 (260, 'NOTHING'),
                 (261, 'NOTHING'),
                 (262, 'NOTHING')]
    g1.states = [[(259, 1)],
                 [(260, 2), (261, 1), (262, 1)],
                 [(259, 3)],
                 [(262, 3), (0, 3)]]

# Generated at 2022-06-23 15:35:43.256039
# Unit test for method report of class Grammar
def test_Grammar_report():
    from . import conv
    from . import pgen
    from . import pickle
    from . import token

    g = Grammar()
    g.report()

    g2 = Grammar()
    pickle.dump(g2, open("Grammar.pickle", "wb"))
    g2 = pickle.load(open("Grammar.pickle", "rb"))
    try:
        g2.report()
    except AttributeError:
        pass

    g3 = Grammar()
    p = pgen.PgenParser()
    s = conv.Symtable()
    g3.start = g3.symbol2number["file_input"]
    for prod in p.parse(token.tok_name):
        lhs, rhs, prec, func = prod

# Generated at 2022-06-23 15:35:54.705035
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    grammar = Grammar()

# Generated at 2022-06-23 15:36:06.921885
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {'x': 1}
    g.number2symbol = {2: 'y'}
    g.dfas = {3: (4, 5)}
    g.keywords = {'a': 6}
    g.tokens = {7: 8}
    g.symbol2label = {'b': 9}
    g.labels = [10, 11]
    g.states = [12, 13]
    g.start = 14
    g.async_keywords = 15
    g2 = g.copy()
    assert g2.symbol2number == {'x': 1}
    assert g2.number2symbol == {2: 'y'}
    assert g2.dfas == {3: (4, 5)}
    assert g

# Generated at 2022-06-23 15:36:16.537595
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    gr = Grammar()
    gr.symbol2number = {'a': 1, 'b': 2, 'c': 3}
    gr.number2symbol = {1: 'a', 2: 'b', 3: 'c'}
    gr.dfas = {4: ([[(1, 5), (2, 6), (3, 7)]], {8: 9}),
                10: ([[(1, 11), (2, 12)]], {13: 14})}
    gr.keywords = {'e': 1, 'f': 2}
    gr.tokens = {5: 1, 6: 2}
    gr.symbol2label = {'g': 1, 'h': 2}
    gr.labels = [(1, 'a'), (2, None), (3, 'b')]
    gr.states

# Generated at 2022-06-23 15:36:19.290005
# Unit test for method report of class Grammar
def test_Grammar_report():
    grammar = Grammar()
    grammar.report()


if __name__ == "__main__":
    test_Grammar_report()

# Generated at 2022-06-23 15:36:30.343905
# Unit test for method load of class Grammar
def test_Grammar_load():
    class MyGrammar(Grammar):
        def __init__(self) -> None:
            super(MyGrammar, self).__init__()
            self.symbol2number = {'foo': 1, 'bar': 2}
            self.number2symbol = {1: 'foo', 2: 'bar'}
            self.states = [
                [(0, 1), (2, 3)],
                [],
                [(3, 4)],
            ]
            self.dfas = {1: (self.states[0], {1: 1}), 2: (self.states[2], {1: 1})}
            self.labels = [(1, None), (2, None), (3, None)]
            self.keywords = {'qux': 2}

# Generated at 2022-06-23 15:36:38.319575
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {"aaa": 1}
    g.number2symbol = {2: "bbb"}
    g.dfas = {3: ([4], {"5": 6})}
    g.keywords = {"aaa": 7}
    g.tokens = {8: 9}
    g.symbol2label = {"aaa": 10}
    g.labels = [(11, "bbb")]
    g.states = [[(12, 13)]]
    g.start = 14
    g.async_keywords = False

    new_g = g.copy()

    assert new_g.symbol2number == g.symbol2number
    assert new_g.number2symbol == g.number2symbol
    assert new_g.dfas == g.df

# Generated at 2022-06-23 15:36:49.605809
# Unit test for method report of class Grammar
def test_Grammar_report():
    from lib2to3.pgen2 import tokenizer, driver
    from lib2to3.pgen2.conv import pygram, pytree
    from lib2to3.pygram import python_symbols as syms

    tokenize = tokenizer.generate_tokens
    d = driver.Driver(pygram, pytree)
    d.grammar = pygram
    d.grammar.async_keywords = True

    d.grammar.report()

    # Ensure that async is in "keywords" dict
    assert d.grammar.keywords["async"]
    assert not d.grammar.keywords.get("await")

    from io import BytesIO
    from lib2to3.pgen2.pgen import dump_grammar

    f = BytesIO()

# Generated at 2022-06-23 15:36:59.569422
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import tokenize
    g = Grammar()
    g.symbol2number = {"a": 13, "b": 42}
    g.number2symbol = {13: "a", 42: "b"}
    g.states = [[[(1, 2)], [(3, 4)]]]
    g.dfas = {4: ([[(2, 3)], [(4, 5)]], {1: 2})}
    g.labels = [(3, None), (4, "b")]
    g.keywords = {"def": 1}
    g.tokens = {token.ENDMARKER: 2}
    g.start = 42
    fd, path = tempfile.mkstemp()

# Generated at 2022-06-23 15:37:10.581437
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.number2symbol[1] = 'test'
    g.tokens[1] = 2
    g.labels = [(1,"test")]
    g.keywords["test"] = 2
    g.states = [ [(1,1)] ]
    g.dfas[1] = g.states, {"test":1}
    g.symbol2label["test"] = 3
    with tempfile.NamedTemporaryFile() as f:
        g.dump(f.name)
        g.load(f.name)
    g.report()
    g.labels = []
    g.report()
    with tempfile.NamedTemporaryFile() as f:
        g.dump(f.name)
        g.load(f.name)
    g.report()



# Generated at 2022-06-23 15:37:16.072764
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {'name': 1}
    g.number2symbol = {1: 'name'}
    g.states = [ [[(256, 0)]] ]
    g.dfas = { 256: ( g.states[0], {} ) }
    g.labels = [(256, None)]
    g.keywords = { "async": 0 }
    g.tokens = { 1: 0 }
    g.symbol2label = { "async": 0 }
    g.start = 256
    g.async_keywords = False

    new = g.copy()

# Generated at 2022-06-23 15:37:25.827832
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    import unittest
    from . import Grammar, token


# Generated at 2022-06-23 15:37:36.176189
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.symbol2number = {"root": 1}
    g.number2symbol = {1: "root"}
    g.states = [[(0, 0)]]
    g.dfas = {1: ([[(0, 0)]], {0: 1}), 2: ([[(1, 0), (0, 0)]], {1: 1})}
    g.labels = [(0, "EMPTY"), (1, "EOF")]
    g.keywords = {"eof": 1}
    g.tokens = {1: 1}
    g.symbol2label = {"$end": 1}
    g.start = 1
    g.report()

# Generated at 2022-06-23 15:37:48.227461
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-23 15:37:56.804177
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()

    g.symbol2number["a"] = 1
    g.number2symbol[2] = "b"
    g.states = [1, 2, 3]
    g.dfas[1] = 2, 3
    g.labels = [(1, None), (2, "b")]
    g.keywords = {"c": 3}
    g.tokens = {1: 2}
    g.symbol2label["a"] = 1
    g.start = 256
    g.async_keywords = False

    g2 = g.copy()

    assert(g.symbol2number["a"] == 1)
    assert(g.number2symbol[2] == "b")
    assert(g.states == [1, 2, 3])

# Generated at 2022-06-23 15:38:00.415678
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    gram = Grammar()
    gram.dump("C:/Users/Ashley/Documents/Projects/Python/py3k/Lib/test/pgen.pkl")
    assert True


# Generated at 2022-06-23 15:38:12.760753
# Unit test for method load of class Grammar
def test_Grammar_load():
    gram = Grammar()

# Generated at 2022-06-23 15:38:18.540341
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    s = "abcd"
    s_len = len(s)
    with tempfile.NamedTemporaryFile(mode='wb') as tmp:
        filename = tmp.name
        g = Grammar()
        g.dump(filename)
        with open(filename, "rb") as f:
            d = f.read()
            assert s_len == len(d)


# Generated at 2022-06-23 15:38:21.743130
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    filename = "Grammar.pickle"
    g.dump(filename)
    del g
    g = Grammar()
    g.load(filename)
    os.remove(filename)

# Generated at 2022-06-23 15:38:30.091029
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import pickle
    from .pgen2 import driver
    from .python import PythonParser

    # The tests
    _ = """
    # This is a comment
    def f():
        return 3
    """

    g = driver.load_grammar("Grammar/Grammar")

    p1 = PythonParser(g)
    p1.parse(_, "test.py")
    k = g.keywords

    # Save the original grammar to a pickle file
    s = pickle.dumps(g, protocol=pickle.HIGHEST_PROTOCOL)

    # Copy the grammar
    g2 = g.copy()
    assert g2.symbol2number == g.symbol2number
    assert g2.number2symbol == g.number2symbol
    assert g2.dfas == g.df

# Generated at 2022-06-23 15:38:42.756550
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert isinstance(g, Grammar)

    g.symbol2number = {}
    assert g.symbol2number == {}

    g.number2symbol = {}
    assert g.number2symbol == {}

    g.states = []
    assert g.states == []

    g.dfas = {}
    assert g.dfas == {}

    g.labels = [(0, "EMPTY")]
    assert g.labels == [(0, "EMPTY")]

    g.keywords = {}
    assert g.keywords == {}

    g.tokens = {}
    assert g.tokens == {}

    g.symbol2label = {}
    assert g.symbol2label == {}

    g.start = 256
    assert g.start == 256


# Generated at 2022-06-23 15:38:44.414968
# Unit test for method report of class Grammar
def test_Grammar_report():
    grammar = Grammar()
    grammar.report()


# Generated at 2022-06-23 15:38:47.485133
# Unit test for method report of class Grammar
def test_Grammar_report():
    from sys import stdout
    from .tok_name import tok_name

    g = Grammar()

    for op, name in opmap.items():
        print(op, tok_name[name], file=stdout)

    g.report()

# Generated at 2022-06-23 15:38:56.712302
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    path = os.path.join(
        os.path.dirname(__file__), "..", "data", "Grammar.pkl"
    )
    with open(path, "rb") as f:
        g = pickle.load(f)
    data = pickle.dumps(g, pickle.HIGHEST_PROTOCOL)
    g2 = Grammar()
    g2.loads(data)
    if g is not g2:
        print(bool(g.symbol2number) == g2.symbol2number)
        print(bool(g.number2symbol) == g2.number2symbol)
        print(bool(g.states) == g2.states)
        print(bool(g.dfas) == g2.dfas)

# Generated at 2022-06-23 15:39:02.418611
# Unit test for method report of class Grammar
def test_Grammar_report():
    if not sys.flags.optimize:
        # Replace print statement in the tested function with a call to a mock.
        # (This is a no-op when the module has been compiled by mypyc.)
        import unittest.mock
        Grammar.report = unittest.mock.MagicMock()

        g = Grammar()
        g.report()

        # Restore print statement in the tested function.
        Grammar.report = Grammar.report.__wrapped__

# Generated at 2022-06-23 15:39:09.756564
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import sys

    class Grammar(object):
        def __init__(self):
            self._symbol2number = {}
            self._number2symbol = {}
            self._states = []
            self._dfas = {}
            self._labels = [(0, "EMPTY")]
            self._keywords = {}
            self._tokens = {}
            self._symbol2label = {}
            self._start = 256

        @property
        def symbol2number(self):
            return self._symbol2number

        @property
        def number2symbol(self):
            return self._number2symbol

        @property
        def states(self):
            return self._states

        @property
        def dfas(self):
            return self._dfas

        @property
        def labels(self):
            return

# Generated at 2022-06-23 15:39:18.853464
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    from .conv import parse_grammar
    from .pgen import make_pgen

    pgen = make_pgen(parse_grammar(opmap_raw))
    g = pgen.load()
    if hasattr(g, '__dict__'):
        assert id(g.__dict__) != id(g.copy().__dict__)
    else:
        # mypyc-generated objects doesn't have __dict__
        assert id(g.__getstate__()) != id(g.copy().__getstate__())

# Generated at 2022-06-23 15:39:24.293769
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")
    assert g.number2symbol[257] == 'encoding_decl'
    assert g.number2symbol[89] == 'if_stmt'
    assert g.symbol2number['if_stmt'] == 89
    assert g.states[9] == [
        [(17, 4), (18, 5), (0, 9)],
        [(1, 10)],
        [(0, 12)],
        [(19, 6), (20, 7), (21, 8), (2, 11)],
        [],
        [],
        [],
        [],
        [],
        [],
        [(16, 1), (2, 3)],
        [],
        [(0, 12)],
    ]
    assert g.df

# Generated at 2022-06-23 15:39:26.881216
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pkl"))
    g.report()


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-23 15:39:36.195364
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import io, pprint
    from typing import Any

    def test_lists(list_attr: str) -> None:
        def hash_list(l: List[Any]) -> int:
            return hash(tuple(l))

        old_items = getattr(old_grammar, list_attr)
        new_items = getattr(new_grammar, list_attr)
        print('Testing', list_attr)
        assert hash_list(old_items) == hash_list(new_items)
        assert len(old_items) == len(new_items)
        assert len(set(old_items)) == len(set(new_items))

    old_grammar = Grammar()

# Generated at 2022-06-23 15:39:46.942641
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = "tmp_test_Grammar_dump.pkl"
    g = Grammar()
    g.dump(filename)
    g1 = Grammar()
    g1.load(filename)
    assert g.symbol2number == g1.symbol2number, "Grammar dump/load failed"
    assert g.number2symbol == g1.number2symbol, "Grammar dump/load failed"
    assert g.states == g1.states, "Grammar dump/load failed"
    assert g.dfas == g1.dfas, "Grammar dump/load failed"
    assert g.labels == g1.labels, "Grammar dump/load failed"
    assert g.start == g1.start, "Grammar dump/load failed"

# Generated at 2022-06-23 15:39:53.465972
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = "Grammar.pickle"
    grammar = Grammar()
    grammar.dump(filename)
    grammar.load(filename)
    assert grammar.symbol2number == {}
    assert grammar.number2symbol == {}
    assert grammar.states == []
    assert grammar.dfas == {}
    assert grammar.labels == [(0, "EMPTY")]
    assert grammar.keywords == {}
    assert grammar.tokens == {}
    assert grammar.symbol2label == {}
    assert grammar.start == 256
    assert not grammar.async_keywords
    os.remove(filename)

# Generated at 2022-06-23 15:40:06.169440
# Unit test for method report of class Grammar
def test_Grammar_report():
    class TestGrammar(Grammar):
        def __init__(self):
            super().__init__()
            self.start = 0
            self.symbol2number = {"sym": 0}
            self.number2symbol = {0: "sym"}
            self.states = [[[(0, 1), (1, 2), (0, 3)], [(0, 4)]]]
            self.dfas = {0: (self.states[0], {1: 1, 3: 2, 4: 2})}
            self.labels = [(0, None), (2, "tok")]
            self.tokens = {2: 1}
            self.keywords = {"tok": 1}
    g = TestGrammar()
    g.report()
