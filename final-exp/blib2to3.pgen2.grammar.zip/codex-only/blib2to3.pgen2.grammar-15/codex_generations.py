

# Generated at 2022-06-23 15:30:13.217372
# Unit test for method loads of class Grammar
def test_Grammar_loads():

    class C(Grammar):
        def __init__(self):
            super().__init__()
            self.symbol2number = {'foo':1}
            self.number2symbol = {1:'foo'}
            self.states = [[[(1,1)]]]
            self.labels = [(1, 1)]
            self.dfas = {1: (1, {1:1})}

    pkl = pickle.dumps(C(), pickle.HIGHEST_PROTOCOL)
    g = Grammar()
    g.loads(pkl)
    assert g.symbol2number == {'foo': 1}
    assert g.number2symbol == {1: 'foo'}
    assert g.states == [[[(1, 1)]]]

# Generated at 2022-06-23 15:30:24.846973
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Test the Grammar.load method.

    Tests a Grammar initialized from the tables in the pickle file
    "Grammar.pickle" (see the test_grammar.py file in the Tools/
    directory for how the file is produced).
    """
    import sys
    import unittest

    from typing import TextIO

    from . import pgen

    class GrammarTest(unittest.TestCase):
        def setUp(self) -> None:
            self.g = pgen.pgen(sys.version)
            self.g.load("Grammar.pickle")
        def test_symbol2number(self) -> None:
            self.assertEqual(self.g.symbol2number["single_input"], 256)

# Generated at 2022-06-23 15:30:25.447222
# Unit test for constructor of class Grammar
def test_Grammar():
    assert Grammar()

# Generated at 2022-06-23 15:30:31.352401
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    g.loads(b'\x80\x03crnumpy.core._multiarray_umath\n_reconstruct\nq\x00cnumpy\ndtype\nq\x01U\x02f8q\x02K\x00K\x01\x87q\x03Rq\x04(K\x03U\x01<q\x05NNNJ\xff\xff\xff\xffJ\xff\xff\xff\xffK\x00tb\x89C\x04\x07\x00\x00tb.')

# Generated at 2022-06-23 15:30:42.497851
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    if type(pickle.Unpickler) is type:
        # Python 2 of course doesn't have forward references...
        class Unpickler(pickle.Unpickler):

            def find_class(self, module, name):
                # Allow for the case where name is a constant in module
                if name in module.__dict__:
                    return module.__dict__[name]
                else:
                    return getattr(module, name)

    else:
        Unpickler = pickle.Unpickler

    # mypyc does not support find_class
    unp = cast(Any, Unpickler)

    g = Grammar()
    g.loads(open("Grammar/Grammar", "rb").read())
    assert g.start == g.symbol2number["file_input"]

# Generated at 2022-06-23 15:30:43.816018
# Unit test for method report of class Grammar
def test_Grammar_report():
    """Test Grammar.report()"""
    g = Grammar()
    g.report()

# Generated at 2022-06-23 15:30:51.468044
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import os
    import shutil
    import pytest
    import pickle
    import io

    test_grammar = Grammar()
    test_grammar.symbol2number = {"foo": 1}
    test_grammar.states = [[[(1, 2)]]]
    test_grammar.dfas = {1: ([[(1, 2)]], {2: 1})}
    test_grammar.labels = [(1, None)]
    test_grammar.start = 256
    test_grammar.keywords = {"bar": 1}
    test_grammar.tokens = {1: 1}
    test_grammar.symbol2label = {"baz": 1}


# Generated at 2022-06-23 15:30:57.629521
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g1.number2symbol["number2symbol"] = "number2symbol"
    g1.symbol2number["symbol2number"] = 123
    g1.labels.append((1, 2))
    g1.labels.append((3, 4))
    g1.keywords["keywords"] = "keywords"
    g1.tokens["tokens"] = "tokens"
    g1.symbol2label["symbol2label"] = "symbol2label"
    g1.start = "start"

    # The copied object g2 should be equal to g1
    g2 = g1.copy()
    assert g2.number2symbol == g1.number2symbol
    assert g2.symbol2number == g1.symbol

# Generated at 2022-06-23 15:31:01.985608
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    grammar = Grammar()

# Generated at 2022-06-23 15:31:03.065759
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()

# Generated at 2022-06-23 15:31:05.470986
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    h = g.copy()
    assert g.__dict__ == h.__dict__

# Generated at 2022-06-23 15:31:13.546880
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    grammar = Grammar()
    cgrammar = grammar.copy()
    assert grammar.symbol2number == cgrammar.symbol2number
    assert grammar.keywords == cgrammar.keywords
    assert grammar.symbol2label == cgrammar.symbol2label
    assert grammar.labels == cgrammar.labels
    assert grammar.states == cgrammar.states
    assert grammar.start == cgrammar.start
    assert grammar.async_keywords == cgrammar.async_keywords

# Generated at 2022-06-23 15:31:20.474481
# Unit test for method loads of class Grammar

# Generated at 2022-06-23 15:31:32.107336
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {'a':1, 'b':2}
    g.number2symbol = {1: 'a', 2: 'b'}
    g.dfas = {1: ([[(1, 1), (2, 2)]], {1: 2}), 2: ([[(1, 1), (2, 2)]], {1: 2})}
    g.keywords = {'if': 1}
    g.tokens = {1: 2}
    g.symbol2label = {'if': 1}
    g.labels = [(1, 'a'), (2, 'b')]
    g.states = [[(1, 1), (2, 2)], [(1, 1), (2, 2)]]
    g.start = 1

# Generated at 2022-06-23 15:31:33.431761
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()


grammar_version = "3.7"

# Generated at 2022-06-23 15:31:45.859324
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    class _TestGrammar(Grammar):
        def __init__(self):
            super().__init__()
            self.order = 1

        def __getstate__(self):
            return {"symbol2number": self.symbol2number,
                    "number2symbol": self.number2symbol,
                    "states": self.states,
                    "dfas": self.dfas,
                    "labels": self.labels,
                    "keywords": self.keywords,
                    "tokens": self.tokens,
                    "symbol2label": self.symbol2label,
                    "start": self.start,
                    "async_keywords": self.async_keywords}
    test = _TestGrammar()
    old_id = id(test)

# Generated at 2022-06-23 15:31:56.192879
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # Test key part of Grammar.loads, to exercise
    # the code in all versions of Python.
    g = Grammar()

# Generated at 2022-06-23 15:32:03.233017
# Unit test for method report of class Grammar
def test_Grammar_report():
    """This function tests the method report of class Grammar with a simple grammar."""
    grammar = Grammar()
    grammar.symbol2number = {'symbol': 1, 'start': 0}
    grammar.number2symbol = {1: 'symbol', 0: 'start'}
    grammar.states = [[[(1, 1)]], [[(1, 2)]]]
    grammar.dfas = {1: (1, {1: 1})}
    grammar.labels = [(1, None)]
    grammar.keywords = {}
    grammar.tokens = {}
    grammar.symbol2label = {}
    grammar.start = 0

    grammar.report()


# Generated at 2022-06-23 15:32:15.327408
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    class DummyGrammar(Grammar):
        def __init__(self):
            self.symbol2number = {
                "a": 1,
                "b": 2,
            }
            self.number2symbol = {
                1: "a",
                2: "b",
            }
            self.states = [[(1, 1), (2, 2)], []]
            self.dfas = {1: ([(1, 1), (2, 2)], {}), 2: ([], {})}
            self.labels = [(1, "a"), (2, "b")]
            self.keywords = {"a": 1}
            self.tokens = {1: 1}
            self.symbol2label = {"a": 1}
            self.start = 1
            self.async_key

# Generated at 2022-06-23 15:32:18.121634
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    return grammar

# Generated at 2022-06-23 15:32:28.340462
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    grammar = Grammar()

# Generated at 2022-06-23 15:32:28.871145
# Unit test for constructor of class Grammar
def test_Grammar():
    p = Grammar()

# Generated at 2022-06-23 15:32:36.157993
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    g = Grammar()
    g.start = 3
    g.symbol2number = {'a': 1, 'b': 2, 'c': 3}
    g.number2symbol = {1: 'a', 2: 'b', 3: 'c'}
    g.labels = [(0, None), (1, None), (2, None), (3, None)]
    g.states = [[[(0, 1), (2, 2)], [(0, 3)]]]
    g.dfas = {1: ([[(0, 1), (2, 2)], [(0, 3)]], {0: 1}), 3: ([[(0, 3)]], {0: 1})}
    g.keywords = {'b': 2}
    g.tokens = {1: 1}
    g.sy

# Generated at 2022-06-23 15:32:46.000494
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    grammar = Grammar()

# Generated at 2022-06-23 15:32:47.969972
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/dev/null")

if __name__ == "__main__":
    # Test dump with an empty Grammar
    test_Grammar_dump()

# Generated at 2022-06-23 15:32:56.676166
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert not g.async_keywords

# Local variables:
# tab-width: 4
# indent-tabs-mode: nil
# End:
# vim: set expandtab tabstop=4 shiftwidth=4:

# Generated at 2022-06-23 15:32:57.835814
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()

# Generated at 2022-06-23 15:33:01.726175
# Unit test for method load of class Grammar
def test_Grammar_load():
    """
    This function tests the loading of the grammar tables.
    """
    grammar = Grammar()

    from .conv import convert

    convert(grammar)

    # load() is not implemented
    #grammar.dump('Grammar.txt')
    #grammar.report()
    #grammar.load('Grammar.txt')

# Generated at 2022-06-23 15:33:08.039773
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.dfas = {1: ([2], {1: 1}), 3: ([4], {1: 1})}
    g.symbol2number = {"a": 1, "b": 3}
    g.number2symbol = {1: "a", 3: "b"}
    g.labels = [(1, "a"), (3, "b"), (4, "c")]
    g.states = [[(1, 3)], [(3, 4)]]
    g.keywords = {"a": 1}
    g.tokens = {1: 1, 2: 2}
    g.symbol2label = {"a": 1, "b": 3}
    g.start = 256
    g.async_keywords = False

    g2 = g.copy()

    assert g

# Generated at 2022-06-23 15:33:18.406981
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    g.keywords["None"] = 1
    g.keywords["True"] = 2
    g.keywords["False"] = 3
    g.tokens[g.keywords["None"]] = 1
    g.tokens[g.keywords["True"]] = 2
    g.tokens[g.keywords["False"]] = 3
    g.symbol2number["a"] = 1
    g.symbol2number["b"] = 2
    g.number2symbol[1] = "a"
    g.number2symbol[2] = "b"
    g.start = 256
    g.labels = [[0, "EMPTY"]]

# Generated at 2022-06-23 15:33:29.552710
# Unit test for method report of class Grammar
def test_Grammar_report():
    """
    It must print the correct information.
    """
    g = Grammar()
    g.symbol2number = {}
    g.number2symbol = {}
    g.states = []
    g.dfas = {}
    g.labels = []
    g.keywords = {}
    g.tokens = {}
    g.symbol2label = {}
    g.start = 256
    g.async_keywords = False
    import sys
    import io

    output = io.StringIO()
    sys.stdout = output
    g.report()
    sys.stdout = sys.__stdout__

# Generated at 2022-06-23 15:33:40.203434
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    def assertion(G1: Grammar, G2: Grammar) -> None:
        assert G1.symbol2number == G2.symbol2number
        assert G1.number2symbol == G2.number2symbol
        assert G1.dfas == G2.dfas
        assert G1.keywords == G2.keywords
        assert G1.tokens == G2.tokens
        assert G1.symbol2label == G2.symbol2label
        assert G1.labels == G2.labels
        assert G1.states == G2.states
        assert G1.start == G2.start

    G = Grammar()
    G_copy = G.copy()
    assertion(G, G_copy)
    G.symbol2number["1"] = 1

# Generated at 2022-06-23 15:33:44.304302
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    if g.start != 256:
        raise AssertionError
    if not g.tokens:
        raise AssertionError
    if not g.keywords:
        raise AssertionError

# Generated at 2022-06-23 15:33:55.336890
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.symbol2number = {'NAME': 257, 'NUMBER': 258}
    g.number2symbol = {257: 'NAME', 258: 'NUMBER'}
    g.states = [[[(258, 0), (257, 1)], [(0, 0)]]]
    g.dfas = {257: ([[(258, 0), (257, 1)], [(0, 0)]], {}),
              258: ([[(0, 0)]], {})}
    g.labels = [(0, 'EMPTY'), (258, None), (257, None)]
    g.keywords = {}
    g.tokens = {258: 1, 257: 2}
    g.symbol2label = {'NAME': 2, 'NUMBER': 1}
    g.start = 257
   

# Generated at 2022-06-23 15:33:58.159991
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.opmap == opmap

# Local variables:
# tab-width: 4
# indent-tabs-mode: nil
# End:
# vim: set expandtab tabstop=4 shiftwidth=4:

# Generated at 2022-06-23 15:34:02.555678
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()

# Faster alternative to .get() with a default value of 1
try:
    from _collections import defaultdict
except ImportError:
    # Py2 fallback
    class defaultdict(dict):
        def __init__(self, default_factory=None):
            self.default_factory = default_factory

        def __missing__(self, key):
            if self.default_factory is None:
                raise KeyError(key)
            self[key] = default_factory()
            return self[key]

# Generated at 2022-06-23 15:34:12.019618
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    g.report()
    g.symbol2number["a"] = 1
    g.symbol2number["b"] = 2
    g.symbol2number[None] = 3
    g.states.append( [(0, 1), (1, 2)])
    g.states.append( [(0, 2), (1, 1)])
    g.labels.append( (1, "a"))
    g.labels.append( (2, "b"))
    g.labels.append( (3, None))
    g.dfas[1] = (g.states[0], {"a" : 1})
    g.dfas[2] = (g.states[1], {"b" : 1})

    tempname = tempfile.mktemp()
    g.dump(tempname)

# Generated at 2022-06-23 15:34:16.135689
# Unit test for method load of class Grammar
def test_Grammar_load():
    s2n = {'A': 257, 'B': 258, 'C': 259, 'D': 260}
    n2s = {257: 'A', 258: 'B', 259: 'C', 260: 'D'}
    states = [[(0, 1)]]
    dfas = {257: ([[(0, 1)]], {1: 1})}
    labels = [(0, 'EMPTY'), (258, None), (259, None)]
    keywords = {}
    tokens = {}
    symbol2label = {'A': 257}
    start = 257

# Generated at 2022-06-23 15:34:25.744221
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load('/home/paulbe/python/grammar-3.4/Grammar.pkl')
    assert g.start == 256, "bad"
    assert g.keywords['else'] == 258, "bad"
    assert g.keywords['except'] == 259, "bad"
    assert g.keywords['print'] == 260, "bad"
    assert g.keywords['class'] == 261, "bad"
    assert g.keywords['finally'] == 262, "bad"
    assert g.keywords['is'] == 263, "bad"
    assert g.keywords['return'] == 264, "bad"
    assert g.keywords['None'] == 265, "bad"
    assert g.keywords['continue'] == 266, "bad"
    assert g.keywords

# Generated at 2022-06-23 15:34:32.287069
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Verify that dump() doesn't clobber file
    g = Grammar()
    g.dump("/tmp/not-here")  # No error
    file = open("/tmp/not-here", "w")
    file.write("In case dump() would clobber\n")
    file.close()
    g.dump("/tmp/not-here")
    file = open("/tmp/not-here")
    assert file.read() == "In case dump() would clobber\n"
    file.close()

# Generated at 2022-06-23 15:34:33.632263
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()  # NOQA


# Unit test

# Generated at 2022-06-23 15:34:41.824748
# Unit test for method report of class Grammar
def test_Grammar_report():
    grammar = Grammar()
    grammar.symbol2number = {"bad": 256}
    grammar.number2symbol = {256: "bad"}
    grammar.labels = [(1, "bad")]
    grammar.states = [[[(1, 1)]]]
    grammar.dfas = {256: ([[(1, 1)]], {"bad": 1})}
    grammar.start = 265
    grammar.keywords = {"bad": 1}
    grammar.tokens = {"bad": 1}
    grammar.symbol2label = {"bad": 1}
    grammar.async_keywords = True
    grammar.report()

# Generated at 2022-06-23 15:34:50.268767
# Unit test for method load of class Grammar
def test_Grammar_load():
    ofile = "/tmp/Grammar.test"

    g = Grammar()
    g.load(ofile)
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords == False

    g.start = -1
    g.dump(ofile)

    g = Grammar()
    g.load(ofile)
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
   

# Generated at 2022-06-23 15:35:00.867494
# Unit test for method load of class Grammar

# Generated at 2022-06-23 15:35:02.792057
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("test.txt")

# Generated at 2022-06-23 15:35:14.880673
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    def assertFields(orig, copy):
        assert orig.symbol2number == copy.symbol2number
        assert orig.number2symbol == copy.number2symbol
        assert orig.dfas == copy.dfas
        assert orig.keywords == copy.keywords
        assert orig.tokens == copy.tokens
        assert orig.symbol2label == copy.symbol2label
        assert orig.labels == copy.labels
        assert orig.states == copy.states
        assert orig.start == copy.start
        assert orig.async_keywords == copy.async_keywords
    grammar = Grammar()
    grammar.symbol2number = {"first": 1}
    grammar.number2symbol = {1: "first"}
    grammar.dfas = {1: ([], {})}
    grammar

# Generated at 2022-06-23 15:35:21.222757
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    assert grammar.symbol2number is not None
    assert grammar.number2symbol is not None
    assert grammar.states is not None
    assert grammar.dfas is not None
    assert grammar.labels is not None
    assert grammar.start is not None
    assert grammar.keywords is not None
    assert grammar.tokens is not None
    assert grammar.symbol2label is not None


# Generated at 2022-06-23 15:35:32.255084
# Unit test for method load of class Grammar
def test_Grammar_load():
    """
    This test creates a Grammar object, then loads it with the
    pickle file created by Grammar.dump().  The test finally compares
    the object with the loaded object and they should be the same.
    """
    # Create a Grammar object
    grammar = Grammar()
    # Create a pickle file and write the test object in
    pkl_file = tempfile.NamedTemporaryFile(mode='wb', delete=False)
    pickle.dump(grammar, pkl_file, pickle.HIGHEST_PROTOCOL)
    pkl_file.close()
    # Load the pickle file into loaded_grammar
    loaded_grammar = Grammar()
    loaded_grammar.load(pkl_file.name)
    # Compare the two Grammar objects
    assert loaded_grammar.__dict

# Generated at 2022-06-23 15:35:42.680597
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Implicitly tests method loads too.
    class BadlyPickledGrammar(Grammar):
        def __getstate__(self) -> Dict[str, Any]:
            return {"no": "way"}

    class UnpicklableGrammar(Grammar):
        def __getstate__(self) -> Dict[str, Any]:
            return {"no": []}

        def __setstate__(self, state):
            # Trigger an exception
            self.no[0]

    g = Grammar()
    g.states = [[[(0, 1)]]]
    g.symbol2number["foo"] = 257
    g.number2symbol[257] = "foo"
    g.start = 257
    g.labels = [(257, None)]
    _, filename = tempfile.mkstem

# Generated at 2022-06-23 15:35:54.293636
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {"+": 1, "-": 2}
    g.number2symbol = {1: "+", 2: "-"}
    g.dfas = {1: ([[(1, 1)], [(2, 2)]], {1: 1, 2: 2}), 2: ([[(1, 1)]], {1: 1})}
    g.keywords = {"+": 1, "-": 2}
    g.tokens = {1: 3, 2: 4}
    g.symbol2label = {"+": 1, "-": 2}
    g.labels = [(1, "+"), (2, "-")]
    g.states = [[(1, 1)], [(2, 2)]]
    g.start = 100
    g.async_keywords = True



# Generated at 2022-06-23 15:36:03.573322
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.start == 256
    assert not hasattr(g, 's2n')
    assert not hasattr(g, 'n2s')
    assert not hasattr(g, 'states')
    assert not hasattr(g, 'dfas')
    assert not hasattr(g, 'labels')
    assert not hasattr(g, 'keywords')
    assert not hasattr(g, 'tokens')
    assert not hasattr(g, 'symbol2label')

if __name__ == "__main__":
    test_Grammar()

# Generated at 2022-06-23 15:36:14.304973
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.start = 256
    g.dfas = {
        256: (
            [[(0, 256), (1, 257)]],
            {0: 8},
        ),
        257: (
            [[(0, 257), (2, 256)]],
            {0: 1, 1: 4},
        ),
    }
    g.keywords = {
        "if": 257,
        "then": 256,
    }
    g.labels = [
        (0, None),
        (257, "if"),
        (256, "then")
    ]
    g.number2symbol = {
        256: "if",
        257: "then"
    }
    g.symbol2label = {
        "if": 257,
        "then": 256
    }


# Generated at 2022-06-23 15:36:25.630400
# Unit test for constructor of class Grammar
def test_Grammar():
    grammar = Grammar()
    try:
        grammar.report()
    except Exception:
        assert False, "report() failed"

    grammar.dump("grammar.pickle")
    copy = Grammar()
    copy.load("grammar.pickle")

    assert copy.symbol2number == grammar.symbol2number
    assert copy.number2symbol == grammar.number2symbol
    assert copy.dfas == grammar.dfas
    assert copy.labels == grammar.labels
    assert copy.states == grammar.states
    assert copy.keywords == grammar.keywords
    assert copy.tokens == grammar.tokens
    assert copy.symbol2label == grammar.symbol2label
    assert copy.start == grammar.start

# Generated at 2022-06-23 15:36:35.024177
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    assert not g.symbol2number

# Generated at 2022-06-23 15:36:43.949549
# Unit test for method load of class Grammar
def test_Grammar_load():
    # This used to raise an error because the labeldict was not loaded.
    # See issue #2415.
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))


if __name__ == "__main__":
    g = Grammar()
    g.load(sys.argv[1])
    g.report()

# Generated at 2022-06-23 15:36:45.072242
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()


# Generated at 2022-06-23 15:36:49.900397
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number["foo"] = 1
    g.number2symbol[2] = "bar"
    g.dfas[3] = (4, {"a":1})
    g.keywords = {"b": 5}
    g.tokens = {6: 7}
    g.symbol2label["c"] = 8
    g.labels = [1,2,3,4]
    g.start = 9
    g_copy = g.copy()
    assert g.symbol2number == g_copy.symbol2number
    assert g.number2symbol == g_copy.number2symbol
    assert g.dfas == g_copy.dfas
    assert g.keywords == g_copy.keywords
    assert g.tokens == g_copy

# Generated at 2022-06-23 15:36:52.937775
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # The actual unit test is too much work. Just test we don't crash
    g = Grammar()
    g.dump(tempfile.mktemp())

# Generated at 2022-06-23 15:37:00.802637
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import unittest

    class Test_Grammar(unittest.TestCase):
        def test_copy(self):
            g1 = Grammar()
            g1.symbol2number["a"] = 1
            g1.symbol2number["b"] = 2
            g1.states = [[1], [], []]
            g1.dfas = {"a": (1, 1), "b": (2, 1)}
            g2 = g1.copy()
            self.assertEqual(g1.symbol2number, g2.symbol2number)
            self.assertEqual(g1.number2symbol, g2.number2symbol)
            self.assertEqual(g1.states, g2.states)

# Generated at 2022-06-23 15:37:08.007109
# Unit test for constructor of class Grammar
def test_Grammar():
    import os
    from . import conv, pgen

    s = Grammar()
    assert s.symbol2number == {}
    assert s.number2symbol == {}
    assert s.states == []
    assert s.dfas == {}
    assert s.labels == [(0, "")]
    assert s.keywords == {}
    assert s.tokens == {}
    assert s.symbol2label == {}
    assert s.start == 256

    # Issue #30737
    s.async_keywords = True
    assert s.async_keywords



# Generated at 2022-06-23 15:37:18.252614
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g_before = Grammar()
    g_before = g_before.copy()
    g_before.symbol2number["foo"] = 2
    g_before.number2symbol[2] = "foo"
    g_before.dfas[2] = {2: 1}
    g_before.keywords["foo"] = 2
    g_before.tokens[2] = 2
    g_before.symbol2label["foo"] = 2
    g_before.labels.append((1, "foo"))
    g_before.states.append([(1, 2)])
    g_before.start = 3

    g_after = g_before.copy()
    assert g_after.symbol2number == g_before.symbol2number
    assert g_after.number2symbol == g_before

# Generated at 2022-06-23 15:37:20.779258
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    from .conv import convert

    g = convert()
    g.loads(pickle.dumps(g.__getstate__()))

# Generated at 2022-06-23 15:37:28.750711
# Unit test for method loads of class Grammar

# Generated at 2022-06-23 15:37:34.984699
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.start == 256
    assert g.async_keywords is False
    assert g.keywords == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.tokens == {}
    assert g.symbol2label == {}

# Generated at 2022-06-23 15:37:46.676828
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    class TestGrammar(Grammar):
        pass

    tg = TestGrammar()
    tg.test_1 = 1
    tg.test_2 = 2
    tg.test_3 = 3
    tg.test_4 = 4
    tg.test_5 = 5
    tg.test_6 = 6
    tg.test_7 = 7
    tg.test_8 = 8
    tg.test_9 = 9

    tg_copy = tg.copy()

    assert tg_copy.test_1 == 1
    assert tg_copy.test_2 == 2
    assert tg_copy.test_3 == 3
    assert tg_copy.test_4 == 4
    assert tg_copy.test_5 == 5

# Generated at 2022-06-23 15:37:50.650182
# Unit test for constructor of class Grammar
def test_Grammar():
    import io
    import pickle

    with io.BytesIO() as f:
        pickle.dump(Grammar(), f)
        test_pkl = f.getvalue()

    g = Grammar()
    g.loads(test_pkl)

# Generated at 2022-06-23 15:37:58.409633
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    from .pgen2 import driver
    g = driver.load_grammar("/usr/lib/python2.7/lib2to3/Grammar.txt")
    g2 = g.copy()
    assert g.symbol2number == g2.symbol2number

if __name__ == "__main__":
    import sys

    g = Grammar()
    g.load(sys.argv[1])
    g.report()

# Generated at 2022-06-23 15:38:10.499690
# Unit test for method report of class Grammar
def test_Grammar_report():
    import pytest  # type: ignore

    g = Grammar()
    g.symbol2number = {"A": 0, "B": 1}
    g.number2symbol = {"C": 0, "D": 1}
    g.states = [[[(0, 1)], [(2, 3)]]]
    g.dfas = {"E": (1, {"F": 1}), "G": (0, {"H": 1})}
    g.labels = [(0, None), (1, "A"), (2, None)]
    g.keywords = {"I": 3, "J": 4}
    g.tokens = {"K": 5, "L": 6}
    g.symbol2label = {"M": 7, "N": 8}
    g.start = 9
    g.async_keywords

# Generated at 2022-06-23 15:38:21.058575
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    fname = "Grammar.dump.test"
    g = Grammar()
    g.dump(fname)
    h = Grammar()
    h.load(fname)
    assert g.number2symbol == h.number2symbol
    assert g.symbol2number == h.symbol2number
    assert g.dfas == h.dfas
    assert g.keywords == h.keywords
    assert g.tokens == h.tokens
    assert g.symbol2label == h.symbol2label
    assert g.labels == h.labels
    assert g.states == h.states
    assert g.start == h.start
    os.remove(fname)

# Generated at 2022-06-23 15:38:27.209699
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    class GrammarSub(Grammar):
        def __init__(self):
            super().__init__()
            self.test = ""
    g1 = GrammarSub()
    g2 = GrammarSub()
    g1.test = "a"
    g2.test = "b"
    g1.loads(pickle.dumps(g1.__dict__))
    assert g1.test == "a"
    g1.loads(pickle.dumps(g2.__dict__))
    assert g1.test == "b"

# Generated at 2022-06-23 15:38:38.326179
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import io
    from .pgen2 import driver

    def _save_stdout():
        return sys.stdout

    def _read_stdout():
        output = sys.stdout.getvalue()
        sys.stdout = _save_stdout()
        return output

    def _write_stdout():
        sys.stdout = io.StringIO()

    _write_stdout()
    d = driver.Driver()
    _read_stdout()
    _write_stdout()
    d.dump_grammar('Grammar.txt')
    _read_stdout()
    _write_stdout()
    d.load_grammar('Grammar.txt')
    _read_stdout()

# Generated at 2022-06-23 15:38:49.486693
# Unit test for method load of class Grammar
def test_Grammar_load():
    import ast
    import inspect

    class ExampleGrammar(Grammar):
        pass

    # ast.parse() requires that the source be a multi-line string, so
    # here we pass a function with a blank docstring.
    source = inspect.getsource(ExampleGrammar)
    tree = ast.parse(source)
    # This is a bit fragile, but until we have better AST support, it
    # will have to do.
    g = ExampleGrammar()
    g.loads(tree.body[1].body[0].value.s)
    assert len(g.symbol2number) == 2
    assert len(g.number2symbol) == 2
    assert len(g.states) == 1
    assert len(g.states[0]) == 2
    assert len(g.states[0][0])

# Generated at 2022-06-23 15:38:58.152480
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    import pprint
    g.tokens = {256: 0, 257: 1}
    g.states = [
        [
            [0, 1],
            [1, 0],
        ],
        [
            [0, 2],
            [1, 0],
        ],
    ]
    g.labels = [
        [None, "EMPTY"],
        [257, None],
        [256, "NAME"],
    ]

# Generated at 2022-06-23 15:39:03.744091
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    def get_parser():
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                               'Grammar.pickle'), 'rb') as f:
            return f.read()

    grammar = Grammar()
    grammar.loads(get_parser())
    grammar.dump(os.path.join(tempfile.gettempdir(), 'Grammar.pickle'))


tok_name = {getattr(token, x): x for x in dir(token) if x.isupper()}

__all__ = [
    "Grammar",
    "Label",
    "DFA",
    "DFAS",
    "tok_name",
    "opmap",
    "opmap_raw",
]

# Generated at 2022-06-23 15:39:14.730737
# Unit test for method report of class Grammar
def test_Grammar_report():
    class Dummy(Grammar):
        pass
    d = Dummy()
    d.symbol2number = {"symbol2number": "symbol2number"}
    assert d.symbol2number == {"symbol2number": "symbol2number"}
    d.number2symbol = {"number2symbol": "number2symbol"}
    assert d.number2symbol == {"number2symbol": "number2symbol"}
    d.states = ["states"]
    assert d.states == ["states"]
    d.dfas = {"dfas": "dfas"}
    assert d.dfas == {"dfas": "dfas"}
    d.labels = ["labels"]
    assert d.labels == ["labels"]
    d.keywords = {"keywords": "keywords"}
    assert d.key

# Generated at 2022-06-23 15:39:25.524065
# Unit test for method load of class Grammar
def test_Grammar_load():
    class TestGrammar(Grammar):
        def __init__(self):
            Grammar.__init__(self)
            self.states = list(range(11))
    g = TestGrammar()
    g.dump(__file__+".tmp")
    h = TestGrammar()
    h.load(__file__+".tmp")
    assert g.states == h.states
    assert g.start == h.start
    assert g.tokens == h.tokens
    assert g.keywords == h.keywords
    assert g.labels == h.labels
    assert g.dfas == h.dfas
    assert g.number2symbol == h.number2symbol
    assert g.symbol2number == h.symbol2number

# Generated at 2022-06-23 15:39:29.746570
# Unit test for method load of class Grammar
def test_Grammar_load():
    class MyGrammar(Grammar): pass
    g = MyGrammar()
    g.load(os.path.join(os.path.dirname(__file__), 'Grammar.pickle'))

# Generated at 2022-06-23 15:39:41.169590
# Unit test for method load of class Grammar
def test_Grammar_load():
    # simple test
    pkl = b"cn\x01\x00\x00\x00q\x00(K\x01K\x02cta"
    g = Grammar()
    g.loads(pkl)
    assert g.symbol2number == {'a': 1, 'b': 2}
    assert g.number2symbol == {1: 'a', 2: 'b'}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, 'EMPTY')]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert not g.async_keywords

# Generated at 2022-06-23 15:39:52.410086
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import tempfile
    import os

    dir = tempfile.TemporaryDirectory()
    filename = os.path.join(dir.name, 'test.pkl')
    with open(filename, 'w') as f:
        pickle.dump(dir.name, f)
    g = Grammar()
    g.dump(dir.name)
    dir.cleanup()


if __name__ == "__main__":
    import sys
    import py_grammar_dump  # noqa: F401

    if sys.argv[1:]:
        g = Grammar()

        for filename in sys.argv[1:]:
            print(filename)
            g.load(filename)
            g.report()

# Generated at 2022-06-23 15:39:58.316825
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # We should not be able to pickle a Grammar object at this level
    import pickle
    g = Grammar()
    with tempfile.NamedTemporaryFile(delete=False) as f:
        try:
            g.dump(f.name)
            raise AssertionError("should not have been able to pickle a Grammar object at this level")
        except pickle.PicklingError:
            pass

# Generated at 2022-06-23 15:40:07.391973
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io
    import unittest
    from unittest import mock
    with mock.patch('sys.stdout', new_callable=io.StringIO) as mock_stdout:
        g = Grammar()
        g.report()
        actual = mock_stdout.getvalue()
    expected = """s2n
{}
n2s
{}
states
[]
dfas
{}
labels
[(0, 'EMPTY')]
start 256
"""
    assert expected == actual

if __name__ == "__main__":
    import doctest

    doctest.testmod()