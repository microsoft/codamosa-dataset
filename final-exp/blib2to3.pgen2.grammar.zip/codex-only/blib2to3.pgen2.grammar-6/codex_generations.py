

# Generated at 2022-06-23 15:30:13.967945
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    from .pgen2 import driver

    g = Grammar()
    g.loads(driver.grammar)

# Generated at 2022-06-23 15:30:25.255929
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g1.symbol2number = {'a': 1}
    g1.number2symbol = {2: 'b'}
    g1.dfas = {3: ({4}, {5: 6})}
    g1.keywords = {'a': 7}
    g1.tokens = {8: 9}
    g1.symbol2label = {'a': 10}
    g1.labels = [(11, 'a')]
    g1.states = [[(12, 13)]]
    g1.start = 14
    g1.async_keywords = True

    g2 = g1.copy()
    assert g1.symbol2number == g2.symbol2number
    assert g1.number2symbol == g2.number2symbol

# Generated at 2022-06-23 15:30:34.556399
# Unit test for method report of class Grammar
def test_Grammar_report():
    class TestGrammar(Grammar):
        def __init__(self):
            Grammar.__init__(self)
            self.symbol2number = {"SYM": 0}
            self.number2symbol = {0: "SYM"}
            self.states = [0]
            self.dfas = {0: ([], {0: ("START",)})}
            self.labels = [(0, "EMPTY")]
            self.keywords = {None: 0}
            self.tokens = {0: 0}
            self.symbol2label = {None: 0}
            self.start = 0

    TestGrammar().report()

# Generated at 2022-06-23 15:30:45.225831
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    grammar = Grammar()
    grammar.symbol2number = {"foo": 10}
    grammar.number2symbol = {10: "foo"}
    grammar.states = ["state"]
    grammar.dfas = {"dfa": ("state", {})}
    grammar.labels = [(10, "foo")]
    grammar.keywords = {"foo": 10}
    grammar.tokens = {10: 10}
    grammar.symbol2label = {"foo": 10}
    grammar.start = 256
    grammar.async_keywords = False

    grammar01 = grammar.copy()
    grammar01.states = ["state01"]

    assert grammar01.states == ["state01"]
    assert grammar01.symbol2number == {"foo": 10}
    assert grammar01.number2symbol == {10: "foo"}

# Generated at 2022-06-23 15:30:47.214183
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .repair import RepairGrammar
    r = RepairGrammar()
    r.load()

# Generated at 2022-06-23 15:30:56.207078
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import builtins
    import io
    import os
    import tempfile
    import unittest
    import sys

    class Grammar_dump_TestCase(unittest.TestCase):
        def setUp(self):
            self.tf = tempfile.NamedTemporaryFile()
            self.tfname = self.tf.name
            self.tf.close()
            self.orig_stdout = sys.stdout
            self.stdout = io.StringIO()
            sys.stdout = self.stdout
            self.orig_stderr = sys.stderr
            self.stderr = io.StringIO()
            sys.stderr = self.stderr

        def tearDown(self):
            self.tfname = None
            self.tf = None
            sys.stdout = self.orig_

# Generated at 2022-06-23 15:31:07.419064
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    G = Grammar()

# Generated at 2022-06-23 15:31:19.511579
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    from grammar_parser.pgen2.token import Token
    from grammar_parser.pgen2.pgen import Grammar as pgen_Grammar

    g = pgen_Grammar(
        """
        expr: 'x'
        """
    )

    g_pickled = g.dumps()
    g_loaded = Grammar()
    g_loaded.loads(g_pickled)
    assert g_loaded.symbol2number == g.symbol2number
    assert g_loaded.number2symbol == g.number2symbol
    assert g_loaded.states == g.states
    assert g_loaded.dfas == g.dfas
    assert g_loaded.labels == g.labels
    assert g_loaded.keywords == g.keywords
    assert g_loaded.tokens == g

# Generated at 2022-06-23 15:31:30.694580
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """Test Grammar.dump()."""
    import io
    import os
    import pickle
    import py_compile
    import shutil
    import sys
    import tempfile
    import unittest
    import unittest.mock

    from . import pgen2

    # Save the PYTHONPATH to restore it later
    pythonpath = os.environ.get("PYTHONPATH")

    # Create a temporary directory to store the Python grammar files and the
    # pickle file
    tempdir = tempfile.mkdtemp()
    os.environ["PYTHONPATH"] = tempdir

    def _write_python_grammar(filename: str, content: str) -> None:
        """Write the given content in a file."""

# Generated at 2022-06-23 15:31:38.949100
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    f = tempfile.NamedTemporaryFile(delete=False)
    f.close()
    # create a simple grammar object
    g = Grammar()
    g.symbol2number['file_input'] = 0
    g.symbol2number['stmt'] = 1
    g.number2symbol[0] = 'file_input'
    g.number2symbol[1] = 'stmt'
    g.dfas[0] = ([[(177, 0), (1, 1), (0, 1)], []], {0: 1})
    g.keywords['False'] = 34
    g.tokens[1] = 1
    g.start = 0
    g.labels = [(0, 'EMPTY'), (1, None), (34, 'False'), (177, 'NEWLINE')]
   

# Generated at 2022-06-23 15:31:49.721766
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    from .conv import parse_grammar
    from .pgen2 import driver
    # Tests that the method copy of class Grammar works when a grammar
    # is loaded via the conv module (parse_grammar).
    grammar = parse_grammar(driver.grammar, "Grammar", "grammar")
    copy_grammar = grammar.copy()
    assert copy_grammar.start == grammar.start
    assert copy_grammar.tokens == grammar.tokens
    assert copy_grammar.labels == grammar.labels
    assert copy_grammar.symbol2label == grammar.symbol2label
    assert copy_grammar.keywords == grammar.keywords
    assert copy_grammar.start == grammar.start
    assert copy_grammar.async_keywords == grammar.async_keywords
    #

# Generated at 2022-06-23 15:31:54.833565
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    fname = "./nonexistent.pickle"
    try:
        g.load(fname)
    except FileNotFoundError:
        pass
    else:
        assert False, "expected FileNotFoundError"

if __name__ == "__main__":
    g = Grammar()
    g.load("./pgen_testgrammar.pickle")

# Generated at 2022-06-23 15:32:03.475914
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    from .conv import grammar, convert, make_pgen
    from . import pgen2
    from . import pgen2_convert  # type: ignore

    pgen2_convert.make_pgen = make_pgen
    convert(grammar, pgen2)
    for ver, pth in ((3, "3.6"), (3.7, "3.7")):
        with open(f"Lib/{pth}/grammar{ver}.6.pickle", "rb") as f:
            p = Grammar()
            p.loads(f.read())
            assert p.async_keywords == (ver >= 3.7)



# Generated at 2022-06-23 15:32:15.230904
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.start = 256
    g.dfas[256] = []
    g.dfas[257] = []
    try:
        g.dump("/tmp/")
        raise Exception("expected OSError")
    except OSError:
        pass
    fd, fn = tempfile.mkstemp()
    os.close(fd)
    g.dump(fn)
    g2 = Grammar()
    g2.load(fn)
    assert g2.start == 256
    assert g2.dfas[256] == g.dfas[256]
    assert g2.dfas[257] == g.dfas[257]


if __name__ == "__main__":
    import driver

    driver.driver()

# Generated at 2022-06-23 15:32:21.503217
# Unit test for constructor of class Grammar
def test_Grammar():
    G = Grammar()
    assert G.symbol2number is not None
    assert G.number2symbol is not None
    assert G.states is not None
    assert G.dfas is not None
    assert G.labels is not None
    assert G.keywords is not None
    assert G.tokens is not None
    assert G.symbol2label is not None
    assert G.start == 256
    assert G.async_keywords == False

# Generated at 2022-06-23 15:32:26.032856
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.load("Grammar.txt")
    g2 = g.copy()
    assert g.tokens == g2.tokens
    g.tokens[token.EQUAL] += 1
    assert g.tokens != g2.tokens

# Generated at 2022-06-23 15:32:28.770622
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    assert Grammar.loads is Grammar.load

if __name__ == "__main__":
    import sys

    parser = Grammar()
    parser.load(sys.argv[1])
    parser.report()

# Generated at 2022-06-23 15:32:30.644246
# Unit test for method report of class Grammar
def test_Grammar_report():
    class DummyGrammar(Grammar):
        pass

    gram = DummyGrammar()
    gram.report()

# Generated at 2022-06-23 15:32:41.377365
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .conv import parse_grammar as _parse_grammar

    fn = 'Grammar.py'

    # write a pickle file
    with tempfile.NamedTemporaryFile(suffix='.pkl', delete=False) as f:
        g2 = _parse_grammar(fn, "exec")
        g2.dump(f.name)

    # read the pickle file
    with open(f.name, "rb") as f:
        g1 = Grammar()
        g1.loads(f.read())

    # convert it back to a pickle file
    with tempfile.NamedTemporaryFile(suffix='.pkl', delete=False) as f:
        g1.dump(f.name)

    # read the pickle file

# Generated at 2022-06-23 15:32:43.290346
# Unit test for constructor of class Grammar
def test_Grammar():
    gr = Grammar()
    assert gr.async_keywords == False

# Test the copy method

# Generated at 2022-06-23 15:32:47.474527
# Unit test for constructor of class Grammar
def test_Grammar():
    grammar = Grammar()
    assert grammar.symbol2number == {}
    assert grammar.number2symbol == {}
    assert grammar.states == []
    assert grammar.dfas == {}
    assert grammar.labels == [(0, "EMPTY")]
    assert grammar.keywords == {}
    assert grammar.tokens == {}
    assert grammar.symbol2label == {}
    assert grammar.start == 256



# Generated at 2022-06-23 15:32:57.565881
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()

    tmp_dir = tempfile.gettempdir()
    fname = os.path.join(tmp_dir, "unittest_parser_grammar.pickle")
    g.dump(fname)
    with open(fname, "rb") as f:
        pickle_data = pickle.load(f)
    assert pickle_data == {"async_keywords": False, "dfas": None, "keywords": None, "labels": [], "number2symbol": None, "start": 256, "states": None, "symbol2label": None, "symbol2number": None, "tokens": None}
    os.remove(fname)

# Generated at 2022-06-23 15:33:03.818881
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import pickle
    g = Grammar()

    # mypyc generates objects that don't have a __dict__, but they
    # do have __getstate__ methods that will return an equivalent
    # dictionary
    if hasattr(g, "__dict__"):
        d = g.__dict__
    else:
        d = g.__getstate__()  # type: ignore
    g.dump(io.BytesIO())
    g.loads(pickle.dumps(d, -1))

# Generated at 2022-06-23 15:33:15.022388
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    from . import pgen
    import io

    grammar = Grammar()
    pgen.generate_grammar(grammar)
    with io.BytesIO() as f:
        grammar.dump(f)
        f.seek(0)
        grammar2 = Grammar()
        grammar2.loads(f.read())
    assert grammar2.symbol2number == grammar.symbol2number
    assert grammar2.number2symbol == grammar.number2symbol
    assert grammar2.dfas == grammar.dfas
    assert grammar2.keywords == grammar.keywords
    assert grammar2.tokens == grammar.tokens
    assert grammar2.symbol2label == grammar.symbol2label
    assert grammar2.labels == grammar.labels
    assert grammar2.states == grammar.states

# Generated at 2022-06-23 15:33:26.081173
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    gr = Grammar()

# Generated at 2022-06-23 15:33:36.434395
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    g.loads(b"\x80\x04\x95\xbe\x00\x00\x00\x00\x00\x00\x00(\x8c\x11symbol2number\x94\x8c\x17number2symbol\x94\x8c\x06states\x94\x93\x94\x8c\x04dfas\x94\x8c\x07labels\x94]q\x00(K\x00\x85q\x01N\x8c\x04stop\x88\x8c\x10async_keywords\x88u.")

# Generated at 2022-06-23 15:33:46.206633
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g1.symbol2number = {"foo": 42}
    g1.number2symbol = {42: "foo"}
    g1.dfas = {256: ([[(257, 1)]] , {1: 1})}
    g1.keywords = {"foo1": 42}
    g1.tokens = {"foo2": 42}
    g1.symbol2label = {"foo3": 42}
    g1.labels = [(1, 1)]
    g1.states = [([(1, 1)], {1: 1})]
    g1.start = 256
    g1.async_keywords = False

    g2 = g1.copy()
    assert(g2.symbol2number == g1.symbol2number)

# Generated at 2022-06-23 15:33:51.190063
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    with tempfile.NamedTemporaryFile() as f:
        grammar.dump(f.name)
        grammar2 = Grammar()
        grammar2.load(f.name)
    assert grammar.states == grammar2.states
    assert grammar.dfas == grammar2.dfas

# Generated at 2022-06-23 15:33:59.921998
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    class MockGrammar(Grammar):
        __getstate__ = Grammar.__dict__['__getstate__']

    # check that the pickled data describes this Python file
    # and add an assertion that it refers to a valid token
    # (since MockToken doesn't exist at runtime)
    g = MockGrammar()

# Generated at 2022-06-23 15:34:00.954036
# Unit test for method report of class Grammar
def test_Grammar_report():
    import doctest
    doctest.run_docstring_examples(Grammar.report, globals(), True, Grammar())


# Generated at 2022-06-23 15:34:10.753530
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g1.symbol2number = dict(a=1, b=2, c=3)
    g1.number2symbol = dict(d=1, e=2, f=3)
    g1.dfas = dict(g=4, h=5, i=6)
    g1.keywords = dict(j=7, k=8, l=9)
    g1.tokens = dict(m=10, n=11, o=12)
    g1.symbol2label = dict(p=13, q=14, r=15)
    g1.labels = [('s', 't'), ('u', 'v'), ('w', 'x')]
    g1.states = ['y', 'z']
    g1.start = 1488

    g

# Generated at 2022-06-23 15:34:16.464922
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import grammar
    from .conv import parse_grammar, pickle_grammar
    from .pgen import driver

    pickle_grammar(grammar, 'Grammar.pickle')
    gram = driver.load_grammar('Grammar.pickle')
    pdict = parse_grammar(gram, 'Grammar.pickle', 'empty_file')
    assert not pdict

# Generated at 2022-06-23 15:34:25.792189
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()

    g.symbol2number = {
        "A": 256,
        "B": 257,
        "C": 258,
        "D": 259,
        "E": 260,
        "F": 261,
        "G": 262,
        "H": 263,
        "I": 264,
    }
    g.number2symbol = {
        256: "A",
        257: "B",
        258: "C",
        259: "D",
        260: "E",
        261: "F",
        262: "G",
        263: "H",
        264: "I",
    }

# Generated at 2022-06-23 15:34:35.405817
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.symbol2number = {'a': 1, 'b': 2}
    grammar.number2symbol = {1: 'a', 2: 'b'}
    grammar.states = [[[(1, 1), (3, 2)], [(1, 2), (3, 1)]], [[(2, 3), (2, 3)]]]
    grammar.dfas = {1: ([[(1, 1), (3, 2)]], {1: 1, 3: 1}), 2: ([[(2, 3), (2, 3)]], {2: 1})}
    grammar.labels = [(0, 'EMPTY'), (1, None), (2, 'x'), (3, None)]
    grammar.keywords = {'x': 2}

# Generated at 2022-06-23 15:34:36.487138
# Unit test for method load of class Grammar
def test_Grammar_load():
    _test_Grammar_load()



# Generated at 2022-06-23 15:34:44.338247
# Unit test for constructor of class Grammar
def test_Grammar():
    """
    >>> x = Grammar()
    >>> x.symbol2number is not None
    True
    >>> x.number2symbol is not None
    True
    >>> x.states is not None
    True
    >>> x.dfas is not None
    True
    >>> x.labels is not None
    True
    >>> x.keywords is not None
    True
    >>> x.tokens is not None
    True
    >>> x.symbol2label is not None
    True
    >>> x.start
    256
    """
    pass


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-23 15:34:48.233727
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    orig = Grammar()
    orig.symbol2number = {'a': 1}
    orig.number2symbol = {1: 'a'}
    d1 = DFA()
    d2 = DFA()
    orig.states = [d1, d2]
    orig.dfas = {1: ([], {})}
    orig.labels = [(0, 'a')]
    orig.keywords = {'b': 1}
    orig.tokens = {2: 3}
    orig.symbol2label = {'c': 4}
    orig.start = 5
    orig.async_keywords = True
    copy = orig.copy()
    assert copy is not orig
    assert copy.symbol2number is not orig.symbol2number
    assert copy.number2symbol is not orig.number

# Generated at 2022-06-23 15:34:53.904039
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Create a Grammar object
    g = Grammar()
    g.symbol2number = {
        "if": 256,
        "else": 257,
        "elif": 258,
    }
    g.number2symbol = {256: "if", 257: "else", 258: "elif"}
    g.states = [[[(257, 1), (258, 2)], [], [(0, 3)], [], []], []]
    g.dfas = {256: ([[(257, 1), (258, 2)], [], [(0, 3)], [], []], {257: 1, 258: 1})}
    g.labels = [(257, "else"), (258, "elif"), (0, "EMPTY")]
    g.keywords = {"else": 257, "elif": 258}

# Generated at 2022-06-23 15:35:01.312501
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    g.loads(pickle.dumps({'symbol2number': {'__all__': 1}}))
    assert g.symbol2number == {'__all__': 1}
    assert g.number2symbol == {1: '__all__'}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, 'EMPTY')]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256


# Generated at 2022-06-23 15:35:13.180974
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    a = Grammar()
    a.symbol2number = {"hi": 1}
    a.number2symbol = {1: "hi"}
    a.dfas = {1: ({},{})}
    a.keywords = {"keywords": 1}
    a.tokens = {1: 1}
    a.symbol2label = {"symbol2label": 1}
    a.labels = [({}, {}, {}, {}, {}, {}, {}, {})]
    a.states = [([], [], [], [], [], [], [], [])]
    a.start = 1
    a.async_keywords = True
    b = a.copy()
    assert a is not b
    assert a.symbol2number is not b.symbol2number
    assert a.symbol2

# Generated at 2022-06-23 15:35:15.047731
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    g.loads(g.dump(__file__))

# Generated at 2022-06-23 15:35:20.621839
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2.pgen import driver

    grammar = Grammar()
    driver.load_grammar("Python.asdl", "Python.txt", grammar)

    try:
        grammar.dump("Grammar.pickle")
    except Exception as e:
        print(repr(e))


if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-23 15:35:31.415334
# Unit test for method report of class Grammar
def test_Grammar_report():
    from StringIO import StringIO
    from contextlib import redirect_stdout

    def check_out(data: str) -> None:
        assert out.getvalue() == data

    g = Grammar()
    g.symbol2number = {"abc": 1, "def": 2}
    g.number2symbol = {1: "abc", 2: "def"}
    g.states = [[[(0, 0)]]]
    g.dfas = {1: ([[(0, 0)]], {}), 2: ([[(0, 0)]], {})}
    g.labels = [(0, None), (1, "abc"), (2, "def")]
    g.keywords = {"abc": 1}
    g.tokens = {1: 1}

# Generated at 2022-06-23 15:35:42.199188
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    g.symbol2number = {"(": 59, ")": 60}
    g.number2symbol = {59: "(", 60: ")"}
    g.states = [[[(59, 1), (60, 2)], [(0, 2)], []]]
    g.dfas = {59: ([[(59, 1), (60, 2)], [(0, 2)], []], {59: 1, 60: 1}), 60: ([[(0, 0)], []], {})}
    g.labels = [(0, "EMPTY"), (59, None), (60, None)]
    g.keywords = {}
    g.tokens = {}
    g.symbol2label = {"(": 59, ")": 60}
    g.start = 59

# Generated at 2022-06-23 15:35:50.516718
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.symbol2number = {'START': 258}
    g.number2symbol = {258: 'START'}
    g.states = [[[(1, 'START'), (3, 1)], [(0, 1)]]]
    g.dfas = {258: (0, {1: 1})}
    g.labels = [(1, None), (3, 'START')]
    g.start = 258
    g.report()

# Generated at 2022-06-23 15:36:02.018229
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [
        [
            [(0, 1), (0, 2)],
            [(0, 3)],
            [(0, 4)],
            [(0, 5)],
            [(0, 6)],
            [(0, 7)],
            [(0, 8)],
        ]
    ]
    g.dfas = {1: ([], {1: 1}), 2: ([], {2: 1}), 3: ([], {3: 1})}
    g.labels = [(0, "EMPTY"), ('foo', 'foo'), ('bar', 'bar'), ('zot', 'zot')]
   

# Generated at 2022-06-23 15:36:13.428303
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {"s1": 1, "s2": 2}
    g.number2symbol = {1: "s1", 2: "s2"}
    g.dfas = {"d1": ([], {})}
    g.keywords = {"k1": 1}
    g.tokens = {"t1": 1}
    g.symbol2label = {"l1": 1}
    g.labels = [(0, "EMPTY")]
    g.states = [([("s1", "s2")], {})]
    g.start = 256

    gc = g.copy()

    # compare symbol2number
    if gc.symbol2number == g.symbol2number:
        print("Grammar.copy: symbol2number: OK")
   

# Generated at 2022-06-23 15:36:20.341436
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    assert not g.tokens
    assert not g.labels
    g.dump(b"tmp.pickle")
    g1 = Grammar()
    with open(b"tmp.pickle", b"rb") as fp:
        g1.loads(fp.read())
    assert not g1.tokens
    assert not g1.labels



# Generated at 2022-06-23 15:36:30.756401
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import conv, tokenize

    g = conv.pgen(tokenize.generate_tokens, "Grammar")
    g_text = str(g)
    with tempfile.NamedTemporaryFile(dir="/tmp/", delete=False) as f:
        g.dump(f.name)
        g_file = str(g)
    with open(f.name, "rb") as f:
        g_load = Grammar()
        g_load.loads(f.read())
        g_load = str(g_load)
        g_load2 = Grammar()
        g_load2.load(f.name)
        g_load2 = str(g_load2)
    os.remove(f.name)
    assert g_text == g_file
    assert g_file == g

# Generated at 2022-06-23 15:36:38.624714
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    assert g.symbol2label == {}
    assert g.tokens == {}
    assert g.keywords == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.states == []
    assert g.start == 256

    # Test loading from a string
    from . import pgen2
    t = pgen2.driver.make_grammar_pickle(
        grammar_name="Grammar",
        start="file_input",
        debug=False,
        optimize=False,
        tabfile="Grammar.tab",
        picklefile="Grammar.pickle",
    )
    g.loads(t)


# Generated at 2022-06-23 15:36:49.669639
# Unit test for method report of class Grammar
def test_Grammar_report():
    grammar = Grammar()
    grammar.symbol2number = {'var': 257}
    grammar.number2symbol = {257: 'var'}
    grammar.states = [[(0, 1), (1, 2), (1, 4), (1, 5)], [(0, 1), (1, 3), (2, 4), (2, 6)]]
    grammar.dfas = {257: ([(0, 1), (1, 2), (1, 4), (1, 5)], {1: 1})}
    grammar.labels = [(0, 'EMPTY'), (258, None), (1, '='), (259, None), (2, None), (260, 'None'), (261, 'None')]
    grammar.keywords = {}
    grammar.tokens = {}

# Generated at 2022-06-23 15:36:51.581212
# Unit test for method dump of class Grammar
def test_Grammar_dump():  # noqa (unused function)
    grammar = Grammar()
    with tempfile.NamedTemporaryFile() as f:
        grammar.dump(f.name)
        grammar.load(f.name)

# Generated at 2022-06-23 15:36:55.429579
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    def loads(d: Any) -> None:
        def m(*a, **v) -> None:
            pass

        Grammar.loads(m, d)

    b"".loads(0)


__all__ = ["Grammar", "test_Grammar_loads"]

# Generated at 2022-06-23 15:37:04.210339
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    def test(g1, g2):
        def dicts(d1, d2):
            if len(d1) != len(d2):
                return False
            for k in d1:
                if d1[k] != d2[k]:
                    return False
            return True

        if g1.symbol2number != g2.symbol2number:
            return False
        if g1.number2symbol != g2.number2symbol:
            return False
        if g1.dfas != g2.dfas:
            return False
        if g1.keywords != g2.keywords:
            return False
        if g1.tokens != g2.tokens:
            return False
        if g1.symbol2label != g2.symbol2label:
            return False


# Generated at 2022-06-23 15:37:10.188252
# Unit test for constructor of class Grammar
def test_Grammar():
    # Create a new instance of Grammar
    gram = Grammar()
    # Check instance variables
    assert gram.symbol2number == {}
    assert gram.number2symbol == {}
    assert gram.states == []
    assert gram.dfas == {}
    assert gram.labels == [(0, "EMPTY")]
    assert gram.keywords == {}
    assert gram.tokens == {}
    assert gram.symbol2label == {}
    assert gram.start == 256

# Generated at 2022-06-23 15:37:19.935986
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g1.start = 2
    g1.symbol2number["test"] = 3
    g1.number2symbol[3] = "test"
    g1.dfas[0] = 1
    g1.keywords["test"] = 4
    g1.tokens[5] = 6
    g1.symbol2label["test"] = 7
    g1.labels.append("test")
    g1.states.append("test")
    g2 = g1.copy()
    assert g1.start == g2.start
    assert g1.symbol2number == g2.symbol2number
    assert g1.number2symbol == g2.number2symbol
    assert g1.dfas == g2.dfas
    assert g1.keywords

# Generated at 2022-06-23 15:37:27.983077
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    from .conv import parse_grammar
    from .pgen2 import run_pgen

    def test_loads(pkl: bytes) -> None:
        g = Grammar()
        g.loads(pkl)


# Generated at 2022-06-23 15:37:37.879098
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    def f():
        pass

    gram = Grammar()
    method_loads_bytes = pickle.dumps(f)
    gram.loads(method_loads_bytes)
    # Assert that following lines are not executed:
    # - methods equal types without problems
    # - wrong types are understood by mypy
    # - method is a pickleable object
    # - method can be assigned to an attribute
    # - an attribute exists
    # - a string can be assigned to an attribute
    gram.loads = None # type: ignore
    gram.loads = "string" # type: ignore
    gram.loads = f # type: ignore
    assert gram.loads is None # type: ignore
    try:
        gram.loads = 1.1
    except TypeError:
        pass

# Generated at 2022-06-23 15:37:44.682157
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    class C(Grammar):
        def __init__(self, d):
            Grammar.__init__(self)
            self._update(d)

    d = {'a': 1}
    c = C(d)
    c.dump('/tmp/c.pkl')
    with open('/tmp/c.pkl', 'rb') as f:
        r = pickle.load(f)
        assert r == d

# Generated at 2022-06-23 15:37:49.381998
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    class MyGrammar(Grammar):
        pass

    my_grammar = MyGrammar()
    my_grammar.loads(b'\x80\x03c__builtin__\nobject\nq\x01\x85Rq\x02.')

# Generated at 2022-06-23 15:37:53.541962
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    g.report()
    g.dump("/tmp/Grammar.pickle")

# Generated at 2022-06-23 15:37:57.508131
# Unit test for method report of class Grammar
def test_Grammar_report():
    from .pgen2 import driver, tokens

    g = driver.load_grammar("./Grammar.txt")
    g.report()
    print(tokens.tok_name)


if __name__ == "__main__":
    test_Grammar_report()

# Generated at 2022-06-23 15:38:09.117954
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io
    import sys
    from tokenize import tokenize, untokenize, TokenInfo

    # fake a module object
    class Module:

        def __init__(self, name):
            self.__name__ = name

    # fake a token
    class Token:

        def __init__(self, type, string, *args):
            self.type = type
            self.string = string

        def __repr__(self):
            return f"Token({self.type}, {self.string!r})"

    # fake a token list
    class FakeTokenList:

        def __init__(self, tokens):
            self.tokens = tokens
            self.cursor = 0

        def __getitem__(self, index):
            return self.tokens[self.cursor + index]


# Generated at 2022-06-23 15:38:21.257316
# Unit test for method loads of class Grammar

# Generated at 2022-06-23 15:38:23.626854
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Test the method load of class Grammar"""
    g = Grammar()
    g.load('Grammar.pickle')



# Generated at 2022-06-23 15:38:30.861567
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .conv import convert
    from . import token

    def assert_pickle_equal(source: Grammar, pickle_path: str) -> None:
        # Test the original Grammar against the pickled Grammar
        new = Grammar()
        new.load(pickle_path)
        # Test the serialized Grammar against the original Grammar
        for attr in (
            "symbol2number",
            "number2symbol",
            "dfas",
            "keywords",
            "tokens",
            "symbol2label",
            "labels",
            "states",
            "start",
            "async_keywords",
        ):
            assert getattr(source, attr) == getattr(new, attr)

    g = Grammar()
    convert([token], g)
    #

# Generated at 2022-06-23 15:38:36.357474
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    code = b"""ccopy_reg
_reconstructor
p0
(c__main__
Grammar
p1
c__builtin__
object
p2
Ntp3
Rp4
(dp5
S'states'
lp6
(lp7
(lp8
"""
    g = Grammar()
    g.loads(code)
    assert g.states[0][0][1] == 0



# Generated at 2022-06-23 15:38:48.267448
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()

    g.symbol2number = {"a": 256, "b": 257, "c": 258}
    g.number2symbol = {256: "a", 257: "b", 258: "c"}
    g.states = [[[], [[(0, 0), (1, 0)]]]]
    g.dfas = {256: ([[(0, 0), (1, 0)]], {1: 1}), 257: ([[(0, 0), (1, 0)]], {1: 1})}
    g.labels = [(0, None), (1, None), (2, None)]
    g.keywords = {"a": (1, None), "b": (2, None)}
    g.tokens = {256: (1, None), 257: (2, None)}

# Generated at 2022-06-23 15:38:52.811415
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest

    class TestCase(unittest.TestCase):
        def test(self):
            grammar = Grammar()
            grammar.load(__file__[:-3] + "-tokens.pkl")

    unittest.main()


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-23 15:39:00.410203
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {'a': 1, 'b': 2}
    g.symbol2label = {'a': 3, 'b': 4}
    g.number2symbol = {1: 'a', 2: 'b'}
    g.dfas = {1: ([[(1, 1), (2, 2)]], {1: 2}), 2: ([[(3, 3), (4, 4)]], {1: 2})}
    g.keywords = {'a': 1, 'b': 2}
    g.tokens = {1: 1, 2: 2}
    g.start = 3
    g.labels = [(1, 'a'), (2, 'b')]

# Generated at 2022-06-23 15:39:02.823114
# Unit test for method report of class Grammar
def test_Grammar_report():
    p = Grammar()
    assert 'print("s2n")' in Grammar.report.__doc__
    assert 'print("states")' in Grammar.report.__doc__

if __name__ == "__main__":
    test_Grammar_report()
    print("unit test for Grammar class")

# Generated at 2022-06-23 15:39:03.419832
# Unit test for method report of class Grammar
def test_Grammar_report():
    g=Grammar()
    g.report()

# Generated at 2022-06-23 15:39:14.730546
# Unit test for method report of class Grammar
def test_Grammar_report():
    from io import StringIO
    from unittest import mock

    def _fake_pprint(*args, **kwargs):
        pass

    gram = Grammar()
    gram.symbol2number = {"symbol1": 1, "symbol2": 2}
    gram.number2symbol = {1: "symbol1", 2: "symbol2"}
    gram.states = [
        [
            [(1, 0), (2, 1), (3, 2)],
            [(1, 1)],
            [(1, 0), (2, 1), (3, 2)],
        ]
    ]
    gram.dfas = {1: (0, {"symbol2": 1})}
    gram.labels = [(0, "EMPTY"), (1, "LABEL1")]
    gram.start = 0
   

# Generated at 2022-06-23 15:39:15.606182
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    assert g


# Generated at 2022-06-23 15:39:26.240711
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import copy

    g = Grammar()

    g.symbol2number = {'aa': 1}
    g.number2symbol = {1: 'aa'}
    g.dfas = {1: ([], {})}
    g.keywords = {'aa': 1}
    g.tokens = {1: 1}
    g.symbol2label = {'aa': 1}
    g.labels = [(1, 'aa')]
    g.states = [[(1, 1)]]
    g.start = 2
    g.async_keywords = True

    g1 = g.copy()
    assert g.symbol2number == g1.symbol2number
    assert g.number2symbol == g1.number2symbol
    assert g.dfas == g1.dfas
   

# Generated at 2022-06-23 15:39:35.622065
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import grammar, pickle as pickle_module

    g = grammar.Grammar()
    g.symbol2number["a"] = 1
    g.number2symbol[2] = "b"
    g.states.append("c")
    g.dfas["d"] = "e"
    g.labels.append("f")
    g.keywords["g"] = "h"
    g.tokens["i"] = "j"
    g.symbol2label["k"] = "l"
    g.start = "m"
    g.async_keywords = True

    with tempfile.NamedTemporaryFile("w+b") as f:
        g.dump(f.name)
        f.seek(0)
        h = grammar.Grammar()
        h.loads

# Generated at 2022-06-23 15:39:38.226031
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g
    with pytest.raises(AttributeError, match='"FakeGrammar" has no attribute "symbol2number"'):
        g.symbol2number


# Generated at 2022-06-23 15:39:46.561202
# Unit test for method loads of class Grammar

# Generated at 2022-06-23 15:39:51.670337
# Unit test for constructor of class Grammar
def test_Grammar():
    gr = Grammar()
    assert gr.symbol2number == {}
    assert gr.number2symbol == {}
    assert gr.states == []
    assert gr.dfas == {}
    assert gr.labels == [(0, "EMPTY")]
    assert gr.keywords == {}
    assert gr.tokens == {}
    assert gr.symbol2label == {}
    assert gr.start == 256


# Generated at 2022-06-23 15:40:03.716701
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {}
    g.number2symbol = None
    old_dfas = g.dfas = {}
    old_keywords = g.keywords = []
    old_tokens = g.tokens = []
    old_symbol2label = g.symbol2label = []
    old_labels = g.labels = []
    old_states = g.states = []
    g.start = None
    g.async_keywords = False

    g2 = g.copy()
    assert g2.symbol2number is not g.symbol2number
    assert g2.number2symbol is g.number2symbol
    assert g2.dfas is not old_dfas
    assert g2.keywords is not old_keywords
