

# Generated at 2022-06-23 15:30:14.485295
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pytest
    from . import driver

    # For 'if __name__ == "__main__"' in grammar.dump
    old_main = getattr(driver, "__main__", None)
    if old_main is None:
        driver.__main__ = lambda: None
    else:
        driver.__main__ = lambda: pytest.skip("handle multi-grammar __main__")

    try:
        # Use a temporary directory, rather than delete the file after
        # the unit test.
        with tempfile.TemporaryDirectory() as tmpdir:
            filename = os.path.join(tmpdir, "Python.gram")
            py = Grammar()
            py.load(filename)
    finally:
        driver.__main__ = old_main

# Generated at 2022-06-23 15:30:25.824869
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    class Dummy:
        def __init__(self):
            self.x = 5
    gr = Grammar()
    gr.symbol2number = {"hi": 1, "bye": 2}
    gr.number2symbol = {1: "hi", 2: "bye"}
    gr.dfas = {1: ([], {}), 2: ([], {})}
    gr.keywords = {"hi": 1, "bye": 2}
    gr.tokens = {1: "hi", 2: "bye"}
    gr.symbol2label = {"hi": 1, "bye": 2}
    gr.labels = ["hi", "bye"]
    gr.states = [[["hi", "bye"]]]
    gr.start = "start"
    gr.async_keywords = True
    # Test with literal string
    gr

# Generated at 2022-06-23 15:30:27.814307
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    gr = Grammar()
    gr.dump('test.pickle')

if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-23 15:30:29.270023
# Unit test for method report of class Grammar
def test_Grammar_report():
    # Crashes
    g = Grammar()
    g.report()


# Generated at 2022-06-23 15:30:41.158992
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    from .pgen2 import driver

    g = driver.load_grammar("Grammar.txt")
    h = g.copy()
    assert g is not h
    assert g.symbol2number == h.symbol2number
    assert g.number2symbol == h.number2symbol
    assert g.dfas == h.dfas
    assert g.keywords == h.keywords
    assert g.tokens == h.tokens
    assert g.symbol2label == h.symbol2label
    assert g.labels == h.labels
    assert g.states == h.states
    assert g.start == h.start
    assert g.async_keywords == h.async_keywords


if __name__ == "__main__":
    test_Grammar_copy()

# Generated at 2022-06-23 15:30:42.150959
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()

# Generated at 2022-06-23 15:30:46.072310
# Unit test for method report of class Grammar
def test_Grammar_report():
    from io import StringIO
    from contextlib import redirect_stdout

    s = StringIO()
    g = Grammar()
    with redirect_stdout(s):
        g.report()
    assert s.getvalue().count("\n") == 8


__all__ = ["Grammar"]

# Generated at 2022-06-23 15:30:52.709793
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io
    import unittest.mock as mock
    from .grammar_pickle import grammar

    save_stdout = sys.stdout
    try:
        sys.stdout = io.StringIO()

        grammar.report()
        captured = sys.stdout.getvalue()

        assert 's2n' in captured
        assert 'n2s' in captured
        assert 'states' in captured
        assert 'dfas' in captured
        assert 'labels' in captured
        assert 'start' in captured
    finally:
        sys.stdout = save_stdout

# Generated at 2022-06-23 15:30:56.976884
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert not g.async_keywords


# Generated at 2022-06-23 15:31:08.169464
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    from . import pgen2
    from io import StringIO
    from typing import List, Optional, IO
    from tokenize import tokenize, untokenize, NAME
    file = StringIO(
        r"""# Grammar
    grammar = (
        (r'<root>', '<root>', (
            (r'\', "<root>", "name"),
            (r'\', "<root>", "name"),
            (r'\', "<root>", "name"),
            (r'\', "<root>", "name"),
            (r'\', "<root>", "name"),
        )),
    )
    """
    )
    g = pgen2.load_grammar(file)
    del file
    assert isinstance(g, Grammar)

# Generated at 2022-06-23 15:31:13.544934
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """
    Unit test for method dump of class Grammar
    """
    gram = Grammar()
    with open("Grammar.pickle", "wb") as f:
        gram.dump(f)

if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-23 15:31:20.474988
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    from pygram import python_grammar

    class DumpTests(unittest.TestCase):
        def test_dump(self):
            filename = "dumptest.py"
            python_grammar.dump(filename)
            try:
                new_grammar = Grammar()
                new_grammar.load(filename)
                new_dict = new_grammar.__dict__
                self.assertEqual(len(python_grammar.__dict__), len(new_dict))
                for k, v in python_grammar.__dict__.items():
                    self.assertEqual(v, new_dict[k])
            finally:
                os.remove(filename)

    suite = unittest.TestLoader().loadTestsFromTestCase(DumpTests)
    unitt

# Generated at 2022-06-23 15:31:26.993924
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256

# Generated at 2022-06-23 15:31:28.076626
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    assert False, 'Test not implemented.'


# Generated at 2022-06-23 15:31:32.853864
# Unit test for method report of class Grammar
def test_Grammar_report():
    import StringIO
    import sys

    test_grammar = Grammar()
    test_grammar.symbol2number = {"foo": 1}
    test_grammar.number2symbol = {1: "foo"}
    test_grammar.states = [0]
    test_grammar.dfas = {1: {(0, None), (1, None)}}
    test_grammar.labels = [(0, "EMPTY"), (1, None)]
    test_grammar.keywords = {"foo": 2}
    test_grammar.tokens = {3: 2}
    test_grammar.symbol2label = {"foo": 2}
    test_grammar.start = 256

    old_stdout = sys.stdout
    sys.stdout = StringIO.StringIO()
    test_gram

# Generated at 2022-06-23 15:31:44.721051
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-23 15:31:47.597280
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import driver

    gram = Grammar()
    for file in sys.argv[1:]:
        driver.load_grammar(file, gram)

# Generated at 2022-06-23 15:31:56.110901
# Unit test for method load of class Grammar
def test_Grammar_load():
    # issue8577: test load method, which calls load_grammar method.
    g = Grammar()
    # Check that grammar is loaded correctly
    result = os.path.join('Lib', 'test', 'parser-grammar')
    g.load(result)
    assert g.symbol2number['listmaker'] == 309
    assert g.symbol2number['trailer'] == 310

    # Check that grammar is loaded correctly with a relative path
    here = os.path.dirname(result)
    g.load(os.path.join(here, 'parser-grammar'))
    assert g.symbol2number['listmaker'] == 309
    assert g.symbol2number['trailer'] == 310

# Generated at 2022-06-23 15:32:04.201307
# Unit test for method report of class Grammar
def test_Grammar_report():
    from .pgen2 import driver
    from . import parse
    from . import token

    import io

    tokenize_src = io.StringIO("from io import StringIO")
    tokens = tokenize_src.readline

    driver.tokenize = lambda x, y: (t for t in tokens())
    grammar = driver.load_grammar('Grammar.report.test')
    # this is what a Grammar looks like

# Generated at 2022-06-23 15:32:06.935511
# Unit test for method load of class Grammar
def test_Grammar_load():
    _G = Grammar()
    _G.load(os.path.join(os.path.dirname(__file__), "Grammar.txt"))

# Generated at 2022-06-23 15:32:10.948267
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    from .pgen2 import driver
    from .parse import parse

    data = driver.generate_grammar_data()
    grammar = Grammar()
    grammar.loads(data)

    parse(grammar, [])

# Generated at 2022-06-23 15:32:21.324640
# Unit test for method report of class Grammar
def test_Grammar_report():
    from . import parsetok

    def check(input, expected):
        from io import StringIO
        from contextlib import redirect_stdout
        f = StringIO()
        with redirect_stdout(f):
            g = Grammar()
            g.start = "file_input"
            g.states = [[(1, 1), (1, 2), (0, 0), (1, 4)]]
            g.labels = [(1, "INTEGER"), (1, "NAME")]
            g.dfas = {"file_input": g.states[0]}
            g.report()
        output = f.getvalue()
        # Verify some key features
        assert "file_input" in output
        assert "1, NAME" in output
        assert "states" in output
        assert "1" in output

# Generated at 2022-06-23 15:32:30.990050
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import warnings

    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords == False

    # regression test for issue #14647
    # The .pickle file contains the dfas keys in a different order
    # depending on the python version, so we have different files for
    # each version.
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", DeprecationWarning)
        version = ".".join

# Generated at 2022-06-23 15:32:37.437262
# Unit test for method load of class Grammar
def test_Grammar_load():
    def f():
        # This function body is never executed, but mypy complains
        # if it isn't present.
        return

    g = Grammar()
    g.start = 3

    with tempfile.NamedTemporaryFile(mode="wb") as f:
        g.dump(f.name)
        f.seek(0)
        g2 = Grammar()
        g2.load(f.name)

    assert g.start == g2.start

# Generated at 2022-06-23 15:32:42.031845
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    from cobra.pgen2 import pgen
    filename = pgen(os.path.join(os.path.dirname(__file__), 'Python.asdl'))
    with open(filename, "rb") as f:
        pkl = f.read()
    gram = Grammar()
    gram.loads(pkl)
    gram.report()

# Generated at 2022-06-23 15:32:46.678166
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, 'EMPTY')]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.start == 256


# Generated at 2022-06-23 15:32:53.853466
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256

# Generated at 2022-06-23 15:32:54.858648
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()
    assert True

# Generated at 2022-06-23 15:33:04.409148
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle

    grammar = Grammar()
    grammar.dfas = {"first": "test"}
    grammar.labels = ["test"]
    grammar.symbol2number = {"first": 1}
    grammar.start = "start"
    grammar.keywords = {"first": "test"}
    grammar.tokens = {"first": "test"}
    grammar.symbol2label = {"first": "test"}
    grammar.number2symbol = {"first": 1}
    grammar.states = ["test"]
    with tempfile.NamedTemporaryFile(mode="wb", delete=False) as f:
        grammar.dump(f)
    with open(f.name, "rb") as f:
        assert pickle.load(f) == grammar.__dict__



# Generated at 2022-06-23 15:33:16.168347
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    # Original Grammar object
    g1 = Grammar()
    g1.symbol2number["g1_dict"] = 1
    g1.number2symbol[1] = "g1_dict"
    g1.dfas[1] = (DFAS([[(0, 1)], [(0, 0)]], {}), "g1_dfas")
    g1.keywords["g1_keywords"] = 1
    g1.tokens[1] = 1
    g1.symbol2label["g1_symbol"] = 1
    g1.labels = [(0, "g1_labels")]
    g1.states = DFA([[(0, 0)]], {})
    g1.start = 1
    g1.async_keywords = True

    # Copied Grammar

# Generated at 2022-06-23 15:33:27.902599
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # Create a Grammar instance
    g = Grammar()

    # Store the __dict__ in a BytesIO instance
    import io
    pkl = io.BytesIO(pickle.dumps(g.__dict__))

    # Restore the __dict__ via method loads of class Grammar
    g.loads(pkl.getvalue())

    # Check that the __dict__ has been restored correctly
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.dfas == {}
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.states == []
    assert g.labels == [(0, "EMPTY")]
    assert g.start == 256
    assert g.async_keywords is False

# Generated at 2022-06-23 15:33:37.946941
# Unit test for constructor of class Grammar
def test_Grammar():
    x = Grammar()
    assert x.symbol2number == {}
    assert x.number2symbol == {}
    assert x.states == []
    assert x.dfas == {}
    assert x.labels == [(0, "EMPTY")]
    assert x.keywords == {}
    assert x.tokens == {}
    assert x.symbol2label == {}
    assert x.start == 256
    assert not x.async_keywords
    # test dump() and load()
    x.dump("/tmp/Grammar")
    x.load("/tmp/Grammar")
    assert x.symbol2number == {}
    assert x.number2symbol == {}
    assert x.states == []
    assert x.dfas == {}

# Generated at 2022-06-23 15:33:47.485062
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()


# Generated at 2022-06-23 15:33:53.121328
# Unit test for method report of class Grammar
def test_Grammar_report():
    from io import StringIO
    from unittest import mock

    f = StringIO()
    grammar = Grammar()
    grammar.report()
    with mock.patch("builtins.print", return_value=None) as mocked_print:
        f = StringIO()
        grammar.report()
        assert mocked_print.call_count == 8

# Generated at 2022-06-23 15:33:55.644110
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.start = 257
    g_copy = g.copy()
    assert g_copy.start == 257

# Generated at 2022-06-23 15:34:07.602295
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    e = Grammar()
    e.number2symbol[0] = None
    e.number2symbol[1] = "a"
    e.symbol2number["a"] = 1
    e.symbol2number["b"] = 2
    e.states = [1]
    e.dfas = {1: ([0], {0: 1})}
    e.labels = [(1, "a")]
    e.keywords = {"async": 1}
    e.tokens = {1: 1}
    e.symbol2label["a"] = 1
    e.start = 1
    a = e.copy()

# Generated at 2022-06-23 15:34:13.262750
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    import io
    g = Grammar()
    assert g.symbol2number == {}
    g.loads(b'\x80\x03}q\x00.')
    assert g.symbol2number == {}

if __name__ == "__main__":
    import sys

    g = Grammar()
    g.load(sys.argv[1])
    g.report()

# Generated at 2022-06-23 15:34:19.798233
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    class test_Grammar(Grammar):
        def __init__(self):
            self._dict = {"a": "object", "b": 2, "c": ["a", "b"], "d": {"a": "c"}}

        def __getstate__(self) -> Any:
            return self._dict

    test = test_Grammar()
    test.loads(pickle.dumps((test.__getstate__())))
    assert test._dict == test.__getstate__()

# Generated at 2022-06-23 15:34:29.994208
# Unit test for constructor of class Grammar
def test_Grammar():
    import unittest
    import pgen2.grammar

    class TestGrammar(unittest.TestCase):
        def test_init(self):
            grammar = pgen2.grammar.Grammar()
            self.assertIsInstance(grammar.symbol2number, dict)
            self.assertIsInstance(grammar.number2symbol, dict)
            self.assertIsInstance(grammar.states, list)
            self.assertIsInstance(grammar.dfas, dict)
            self.assertIsInstance(grammar.labels, list)
            self.assertIsInstance(grammar.keywords, dict)
            self.assertIsInstance(grammar.tokens, dict)
            self.assertIsInstance(grammar.symbol2label, dict)

    unittest.main()

# Generated at 2022-06-23 15:34:31.602496
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()


# Generated at 2022-06-23 15:34:40.575947
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # Construct the grammar tables.
    g = Grammar()
    g.symbol2number["foo"] = 4
    g.number2symbol[4] = "foo"
    g.labels[258] = (259, "keyword")
    g.states.append([[(258, 1), (259, 1)]])
    g.dfas[4] = ([[(258, 1), (259, 1)]], {1: 1})
    g.keywords["keyword"] = 259
    g.tokens[259] = 259
    g.symbol2label["foo"] = 258
    g.start = 256

    # Dump the grammar tables and load them again.
    with tempfile.TemporaryFile() as f:
        g.dump(f)
        f.seek(0)

# Generated at 2022-06-23 15:34:42.355423
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g2 = g.copy()
    assert g.__dict__ == g2.__dict__
    assert g.__dict__ is not g2.__dict__

# Generated at 2022-06-23 15:34:48.920733
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {"a": 1, "b": 2}
    g.number2symbol = {1: "a", 2: "b"}
    g.dfas = {1: ([[(0, 2)], [(0, 3)]], {0: 0, 1: 1}), 2: ([[(5, 4)], [(6, 5)]], {0: 0, 1: 1})}
    g.keywords = {"c": 3}
    g.tokens = {4: 6}
    g.symbol2label = {"d": 7}
    g.labels = [(0, "Empty"), (1, "abc"), (2, None)]
    g.states = [[[(8, 9)], [(0, 10)]]]
    g.start = 11

    g

# Generated at 2022-06-23 15:34:49.776713
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert isinstance(g, Grammar)


# Generated at 2022-06-23 15:34:57.278707
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    gram = Grammar()

# Generated at 2022-06-23 15:35:01.352690
# Unit test for method report of class Grammar
def test_Grammar_report():
    gr = Grammar()
    import io
    import sys
    gr.report()
    try:
        sys.stdout = io.StringIO()
        gr.report()
    finally:
        sys.stdout = sys.__stdout__


if __name__ == "__main__":
    test_Grammar_report()

# Generated at 2022-06-23 15:35:08.979765
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    with tempfile.NamedTemporaryFile(delete=False) as f:
        filename = f.name
        grammar.dump(filename)
    try:
        with open(filename, "rb") as f:
            data = f.read(1024)
    finally:
        os.remove(filename)
    assert data == b'\x80\x04\x95E\x00\x00\x00\x00\x00\x00\x00\x8c\x08pgen.grammar\x94.'

# Generated at 2022-06-23 15:35:19.009074
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Dummy pickle file
    pkl = b"]q\x81q\x02}q\x03(K\x0cK\x06X\x03\x00\x00\x00oneq\x04K\x01X\x03\x00\x00\x00twoq\x05K\x02ub."
    import io
    data = io.BytesIO(pkl)
    # Dummy Grammar instance
    g = Grammar()
    # Call load
    g.loads(pkl)
    # Assert that the result of load is what we expect
    assert g.symbol2number == {'one': 12, 'two': 6}
    assert g.number2symbol == {12: 'one', 6: 'two'}

# Generated at 2022-06-23 15:35:29.914657
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    from .conv import gen_pgen
    from .pgen2 import tokenize_pgen
    from .parse import Parser

    g = gen_pgen()
    g2 = g.copy()
    p = Parser(g, 'single')
    p = Parser(g, 'file')
    p = Parser(g, 'eval')
    p = Parser(g, 'exec')
    p = Parser(g, 'single', 'async')
    p = Parser(g, 'file', 'async')
    p2 = Parser(g2, 'single')
    p2 = Parser(g2, 'file')
    p2 = Parser(g2, 'eval')
    p2 = Parser(g2, 'exec')

# Generated at 2022-06-23 15:35:36.409789
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256

# Generated at 2022-06-23 15:35:37.861246
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert isinstance(g, Grammar)

# Generated at 2022-06-23 15:35:49.170853
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-23 15:35:52.617568
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import driver as PGEN
    from .parse import ParseError
    from .tokenize import tokenize, untokenize
    from io import BytesIO

    grammar = PGEN.parse_grammar(open(PGEN.grammar).read())
    g = Grammar()
    g.load(filename=PGEN.pgen)
    driver = PGEN.Driver(g, PGEN.pgen)
    driver.parse_grammar(grammar)



# Generated at 2022-06-23 15:36:02.806961
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    G = Grammar()
    G.test = 10
    # Need to pickle to a writable file and then replace the original file to
    # ensure an atomic operation
    temp_file_name = os.path.join(os.path.dirname(__file__), 'temp_file.pkl')
    try:
        G.dump(temp_file_name)
        with open(temp_file_name, 'rb') as pickle_file:
            attrs = pickle.load(pickle_file)
        assert attrs['test'] == 10
    finally:
        try:
            os.remove(temp_file_name)
        except FileNotFoundError:
            pass

# Generated at 2022-06-23 15:36:05.337303
# Unit test for constructor of class Grammar
def test_Grammar():
    from . import pgen2

    g = pgen2.driver.load_grammar(pgen2.grammar)
    print(id(g))

# Generated at 2022-06-23 15:36:15.542266
# Unit test for constructor of class Grammar
def test_Grammar():
    import unittest


# Generated at 2022-06-23 15:36:27.333695
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.number2symbol = {"number": "symbol"}
    g.symbol2number = {1: "a", 2: "b"}
    g.dfas = {3: ("state", "first")}
    g.states = [["states"]]
    g.keywords = {"keyword": 1}
    g.tokens = {3: "label"}
    g.symbol2label = {"symbol": "label"}
    g.labels = [("label", "x")]
    g.start = 1
    with tempfile.NamedTemporaryFile(delete=True) as f:
        g.dump(f.name)
        g.load(f.name)
        assert g.number2symbol == {"number": "symbol"}
        assert g.symbol2

# Generated at 2022-06-23 15:36:30.442061
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    for d in [{'this': 'that'}, {'testing': 123}]:
        g = Grammar()
        g.loads(pickle.dumps(d))
        assert g._load_dict == d

# Generated at 2022-06-23 15:36:31.022400
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()

# Generated at 2022-06-23 15:36:38.800338
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Make a new grammar object
    grammar = Grammar()

    # Dump grammar tables to a pickle file
    # pylint: disable=no-member
    grammar.dump('g1.pickle')

    # Make another new grammar object
    grammar = Grammar()
    assert grammar.dfas == {}

    # Load grammar tables from a pickle file
    grammar.load('g1.pickle')

    # Check that all attributes were loaded
    assert grammar.symbol2number != {}
    assert grammar.number2symbol != {}
    assert grammar.states != []
    assert grammar.dfas != {}
    assert grammar.labels != []
    assert grammar.keywords != {}
    assert grammar.tokens != {}
    assert grammar.symbol2label != {}
    assert grammar.start == 256

# Generated at 2022-06-23 15:36:41.360189
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()

if __name__ == "__main__":
    test_Grammar()

# Generated at 2022-06-23 15:36:49.067992
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()

    try:
        g.load("foo.pickle")
    except OSError:
        pass
    else:
        assert False, "expected OSError"

    g.loads(b"cposix\nExpressions\np0\n.")
    assert g.start == 256, "expected start state 256"

    g.dump("foo.pickle")
    g.load("foo.pickle")
    assert g.start == 256, "expected start state 256"
    os.unlink("foo.pickle")



# Generated at 2022-06-23 15:36:59.289372
# Unit test for method report of class Grammar
def test_Grammar_report():
    import sys
    g = Grammar()
    g.report()

# Generated at 2022-06-23 15:37:10.387974
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    test_grammar = Grammar()
    test_grammar.symbol2number = {"test" : 1}
    test_grammar.number2symbol = {2 : "test"}
    test_grammar.states = [["test"]]
    test_grammar.dfas = {1 : (["test"], {"test" : 1})}
    test_grammar.labels = [(1, None)]
    test_grammar.keywords = {"test" : 1}
    test_grammar.tokens = {1 : 1}
    test_grammar.symbol2label = {"test" : 1}
    test_grammar.start = 256
    test_grammar.async_keywords = False


# Generated at 2022-06-23 15:37:15.774278
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    d = (
        (+1, 2),
        (3, 4),
    )
    g = Grammar()
    g.states = [d]
    g2 = g.copy()
    assert g2.states[0] == d
    assert g2.states[0] is not d

if __name__ == "__main__":
    test_Grammar_copy()

# Generated at 2022-06-23 15:37:25.488648
# Unit test for constructor of class Grammar
def test_Grammar():
    import dis
    g = Grammar()
    g.start
    g.symbol2number
    g.number2symbol
    g.states
    g.dfas
    g.labels
    g.keywords
    g.tokens
    g.symbol2label
    foo = g.copy()
    g.dump("foo")
    g.load("foo")
    g.report()
    assert g.start == foo.start
    assert g.symbol2number == foo.symbol2number
    assert g.number2symbol == foo.number2symbol
    assert g.states == foo.states
    assert g.dfas == foo.dfas
    assert g.labels == foo.labels
    assert g.keywords == foo.keywords
    assert g.tokens == foo.t

# Generated at 2022-06-23 15:37:36.704789
# Unit test for method loads of class Grammar
def test_Grammar_loads():

    d = {'dfas': {256: (
        [[(1, 1)],
         [(1, 2)]],
        {0: 1}
    ), 257: (
        [[(1, 2)],
         [(1, 2)]],
        {0: 2}
    )},
     'keywords': {},
     'labels': [(0, 'EMPTY'), (1, None), (1, None)],
     'number2symbol': {256: 'start', 257: 'alt'},
     'states': [[[(0, 1)], [(0, 2)]]],
     'start': 256,
     'symbol2label': {'start': 1, 'alt': 2},
     'symbol2number': {'start': 256, 'alt': 257},
     'tokens': {}}

    g

# Generated at 2022-06-23 15:37:43.115815
# Unit test for method report of class Grammar
def test_Grammar_report():
    def test():
        try:
            test.g.report()
        except Exception as err:
            test.success = False
            print(err)
        else:
            test.success = True

        print("test_Grammar.test_Grammar_report:", "success" if test.success else "fail")

    test.success = True
    test.g = Grammar()
    test()

# Generated at 2022-06-23 15:37:51.839824
# Unit test for method report of class Grammar
def test_Grammar_report():
    grammar_obj = Grammar()
    grammar_obj.symbol2number = {'A': 258}
    grammar_obj.number2symbol = {258: 'A'}
    grammar_obj.states = [[[(257, 2)], [(256, 1)]]]
    grammar_obj.dfas = {258: ([[(257, 2)], [(256, 1)]], {1: 0})}
    grammar_obj.labels = [(0, 'EMPTY'), (257, None), (256, None)]
    grammar_obj.start = 256

    assert grammar_obj.report() == None

# Generated at 2022-06-23 15:38:02.326154
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    from .pgen2 import driver
    from .pgen2 import tokenize

    def parse_grammar(path):
        input = open(path).read()
        tokenize.tokenize(input, "exec", grammar=driver.Grammar())
    
    glr_path = os.path.realpath(__file__)
    glr_path = os.path.join(os.path.dirname(glr_path), "Python.asdl")
    glr_path = os.path.abspath(glr_path)
    assert os.path.exists(glr_path)
    parse_grammar(glr_path)
    
    py_path = os.path.realpath(__file__)

# Generated at 2022-06-23 15:38:14.803298
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Create a dummy grammar to test with.
    g = Grammar()
    g.symbol2number = {"a": 1, "b": 2}
    g.number2symbol = {1: "a", 2: "b"}
    g.states = [[[(0, 1)]], [[(1, 2)]]]
    g.dfas = {"a": g.states[0], "b": g.states[1]}
    g.labels = [(0, ""), (1, "")]
    g.keywords = {"b": 1}
    g.tokens = {"a": 0}
    g.symbol2label = {}
    g.start = 1

    # Dump it to a temporary file and load it back again.

# Generated at 2022-06-23 15:38:19.040805
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("./test.pickle")
    g1 = Grammar()
    g1.load("./test.pickle")
    assert g.states[0] == g1.states[0]


# Generated at 2022-06-23 15:38:21.409837
# Unit test for method report of class Grammar
def test_Grammar_report():
    global opmap
    g = Grammar()
    g.report()


__all__ = ["Grammar", "opmap"]

# Generated at 2022-06-23 15:38:28.721367
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-23 15:38:32.116162
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("../../Grammar/Grammar.pkl")

if __name__ == '__main__':
    test_Grammar_load()

# Generated at 2022-06-23 15:38:35.545520
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    test_file = "/tmp/parse_test"
    grammar.dump(test_file)


if __name__ == "__main__":
    grammar = Grammar()
    grammar.report()

# Generated at 2022-06-23 15:38:47.629066
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    assert Grammar().loads(b"\x80\x03}q\x00(X\x0c\x00\x00\x00number2symbolq\x01}q\x02X\x04\x00\x00\x00Noneq\x03K\x04sX\x06\x00\x00\x00symbolq\x04K\x02s."
                            b"X\x07\x00\x00\x00symbol2numberq\x05}q\x06X\x04\x00\x00\x00Noneq\x07K\x04sX\x06\x00\x00\x00symbolq\x08K\x02s.")

# Generated at 2022-06-23 15:38:53.549818
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-23 15:39:04.344960
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen

    grammar = pgen.pgen("Python.asdl.txt").grammar
    grammar.dump('Grammar.dump')

    grammar2 = Grammar()
    grammar2.load('Grammar.dump')
    assert grammar.symbol2number == grammar2.symbol2number
    assert grammar.number2symbol == grammar2.number2symbol
    assert grammar.states == grammar2.states
    assert grammar.dfas == grammar2.dfas
    assert grammar.labels == grammar2.labels
    assert grammar.keywords == grammar2.keywords
    assert grammar.tokens == grammar2.tokens
    assert grammar.symbol2label == grammar2.symbol2label
    assert grammar.start == grammar2.start

# Generated at 2022-06-23 15:39:10.828716
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    grammar = Grammar()

# Generated at 2022-06-23 15:39:16.195790
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2label = {"abc": 1}
    g2 = g.copy()
    assert g.symbol2label is not g2.symbol2label
    assert g.symbol2label == g2.symbol2label

# Generated at 2022-06-23 15:39:26.607289
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {'A':1, 'B':2}
    g.number2symbol = {1:'C', 2:'D'}
    g.dfas = {1:(((1,2),(3,4)),{5:6}), 2:(((7,8),(9,10)),{11:12})}
    g.keywords = {'key1':1, 'key2':2}
    g.tokens = {1:1, 2:2}
    g.symbol2label = {'E':1, 'F':2}
    g.labels = [((1,2),'G'), ((3,4),'H')]
    g.states = [((5, 5), (6, 6))]
    g.start = 7



# Generated at 2022-06-23 15:39:31.580827
# Unit test for method loads of class Grammar

# Generated at 2022-06-23 15:39:42.761956
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    import json
    import pickle
    import io

    # Example from load() method
    # Create a temporary file for reading
    with tempfile.NamedTemporaryFile(mode='wb', delete=False) as f:
        # mypyc generates objects that don't have a __dict__, but they
        # do have __getstate__ methods that will return an equivalent
        # dictionary
        if hasattr(f, "__dict__"):
            d = f.__dict__
        else:
            d = f.__getstate__()  # type: ignore
        d['name'] = 'foo'
        d['mode'] = 'rb'
        d['encoding'] = None
        d['newline'] = None
        d['errors'] = None
        d['closefd'] = True
        d['opener'] = None
       

# Generated at 2022-06-23 15:39:44.915021
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    fn = os.path.join(tempfile.mkdtemp(), "test.pickle")
    try:
        g.dump(fn)
        s2n2 = g.symbol2number
    finally:
        os.unlink(fn)

# Generated at 2022-06-23 15:39:53.975361
# Unit test for method load of class Grammar
def test_Grammar_load():
    import re, symbol, token
    g = Grammar()
    g.load('Grammar.gram')
    assert g.symbol2number['atom'] == 256
    assert g.number2symbol[256] == 'atom'
    assert g.states[0] == [(5, 256), (0, 1), (1, 1), (2, 1), (3, 1), (4, 1)]
    dfa, first = g.dfas[256]
    assert dfa == [(0, 256), (5, 257), (6, 258), (7, 258), (8, 259), (9, 259)]
    assert first == {3:1, 4:1, 6:1, 7:1}

# Generated at 2022-06-23 15:40:06.664928
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    grammar1 = Grammar()
    grammar1.symbol2number = {'a': 1}
    grammar1.number2symbol = {1: 'a'}
    grammar1.dfas = {1: (2, 3)}
    grammar1.keywords = {'a': 1}
    grammar1.tokens = {1: 2}
    grammar1.symbol2label = {'a': 1}
    grammar1.labels = ['a']
    grammar1.states = [1]
    grammar1.start = 1
    grammar1.async_keywords = True

    grammar2 = grammar1.copy()
