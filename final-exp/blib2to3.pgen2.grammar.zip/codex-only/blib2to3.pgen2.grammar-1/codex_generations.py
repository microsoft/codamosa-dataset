

# Generated at 2022-06-23 15:30:15.502278
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # Create a test grammar, and ensure the correct data structure.
    grammar = Grammar()
    grammar.symbol2number["a"] = 1
    grammar.symbol2number["b"] = 2
    grammar.symbol2number["c"] = 3
    grammar.symbol2number["d"] = 4
    grammar.number2symbol[1] = "a"
    grammar.number2symbol[2] = "b"
    grammar.number2symbol[3] = "c"
    grammar.number2symbol[4] = "d"
    grammar.states = [(1, 2, 3, 4), (5, 6, 7, 8)]
    grammar.dfas[1] = [(1, 2, 3, 4), {1, 2, 3, 4}]

# Generated at 2022-06-23 15:30:26.782006
# Unit test for constructor of class Grammar

# Generated at 2022-06-23 15:30:30.440459
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import sys
    from .pgen2 import driver

    g = driver.load_grammar(sys.argv[1])
    g2 = g.copy()
    assert g is not g2
    assert g.__dict__ == g2.__dict__

# Generated at 2022-06-23 15:30:42.304966
# Unit test for method report of class Grammar
def test_Grammar_report():
    # Provide a dummy grammar object, populate some of its fields,
    # and verify that report() produces expected output
    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2, 'baz': 3}
    g.number2symbol = {1: 'foo', 2: 'bar', 3: 'baz'}
    g.labels = [(0, ''), (1, 'one'), (2, 'two')]
    g.states = [[(1, 2)], [(2, 2)]]
    g.dfas = {1: (g.states[0], {1: 1, 2: 1}),
              2: (g.states[1], {2: 1})}
    g.keywords = {'one': 1, 'two': 2}

# Generated at 2022-06-23 15:30:51.702190
# Unit test for method report of class Grammar
def test_Grammar_report():
    t = Grammar()
    t.symbol2number["single"] = 1
    t.symbol2number["double"] = 2
    t.symbol2number["list"] = 3
    t.symbol2number["triple"] = 4
    t.symbol2number["quad"] = 5
    t.number2symbol = dict(
        (v, k) for k, v in t.symbol2number.items()
    )
    t.labels = [(0, "EMPTY"), (1, None), (2, None), (3, "foo"), (4, "bar")]
    t.tokens = {"foo": 3, "bar": 4}
    t.keywords = {"baz": 3, "qux": 5}

# Generated at 2022-06-23 15:30:58.920068
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    class GrammarTest(Grammar):
        def __init__(self) -> None:
            super().__init__()
            self.dict_a = {"key1":1, "key2":2}
            self.dict_b = {"key3":3, "key4":4}
            self.dict_c = {"key5":5, "key6":6}
            self.list_a = [1,2,3]
            self.list_b = [4,5,6]
            self.list_c = [7,8,9]


# Generated at 2022-06-23 15:31:00.245703
# Unit test for constructor of class Grammar
def test_Grammar():
    """
    Unit test for Grammar constructor.
    """
    g = Grammar()


if __name__ == "__main__":
    test_Grammar()

# Generated at 2022-06-23 15:31:12.089302
# Unit test for method load of class Grammar

# Generated at 2022-06-23 15:31:22.255872
# Unit test for method load of class Grammar
def test_Grammar_load():
    p = Grammar()
    p.async_keywords = False

# Generated at 2022-06-23 15:31:24.811963
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    # This test is not optimal, because the output from report is
    # indented by 2 spaces.
    g.report()

# Generated at 2022-06-23 15:31:29.705840
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io
    import sys
    import unittest

    class Test_Grammar_report(unittest.TestCase):
        def test_Grammar_report(self):
            output = io.StringIO()
            def get_output() -> str:
                return output.getvalue()
            savestdout = sys.stdout
            sys.stdout = output
            try:
                g = Grammar()
                g.report()
            finally:
                sys.stdout = savestdout
            self.assertEqual(get_output(), """\
s2n
{}
n2s
{}
states
[[]]
dfas
{}
labels
[(0, 'EMPTY')]
start 256
""")

    unittest.main()



# Generated at 2022-06-23 15:31:38.376488
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.start = 257
    g.symbol2number = {'times': 258, 'expr': 259, 'factor': 260}
    g.number2symbol = {258: 'times', 259: 'expr', 260: 'factor'}
    g.states = [[(0, 0), (1, 1)], [(2, 2), (3, 3), (0, 4)]]
    g.dfas = {258: ([(1, 2), (0, 0)], {1: 1}),
              259: ([(0, 1), (2, 2), (3, 2), (0, 3)], {1: 1}),
              260: ([(2, 0), (0, 0)], {2: 1})}

# Generated at 2022-06-23 15:31:43.672342
# Unit test for method report of class Grammar
def test_Grammar_report():
    import pytest

    class G(Grammar):
        def __init__(self):
            Grammar.__init__(self)
            self.symbol2number = {'a': 'b', 'c': 'd'}
            self.number2symbol = {'b': 'a', 'd': 'c'}
            self.states = [[(0, 1)], [(0, 2)]]
            self.dfas = {'e': [[(0, 3)], [(0, 4)]], 'f': [[(0, 5)], [(0, 6)]]}
            self.labels = [(1, None), (2, 'hi')]
            self.keywords = {'a': 7, 'b': 8}
            self.tokens = {'i': 9, 'j': 10}

# Generated at 2022-06-23 15:31:45.103329
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump(tempfile.mktemp())

# Generated at 2022-06-23 15:31:55.783624
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    # Create temp dir
    tempdir = tempfile.TemporaryDirectory()
    pathname = os.path.join(tempdir.name, "grammar.pickle")

    # Create grammar
    g = Grammar()

    # Populate grammar with some data
    g.symbol2number = {"symbol2number" : 1}
    g.number2symbol = {"number2symbol" : 2}
    g.dfas = {"dfas" : 3}
    g.keywords = {"keywords" : 4}
    g.tokens = {"tokens" : 5}
    g.symbol2label = {"symbol2label" : 6}
    g.labels = ["labels0", "labels1", "labels2", "labels3", "labels4"]

# Generated at 2022-06-23 15:32:02.665641
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # The pgen2 module is used to generate a fresh pickle of the grammar
    # data, in case the grammar definition changes.
    # The grammar pickle is imported as a string in test_grammar.py.
    # Note: this is not used when using the extension module.
    #
    # To regenerate the pickle, run this script in the top-level directory:
    # python -m test.test_pickletest
    from .pgen2 import driver

    pkl = driver.generate_grammar_pickle()
    g = Grammar()
    g.loads(pkl)
    assert isinstance(g, Grammar)

# Generated at 2022-06-23 15:32:15.088622
# Unit test for method dump of class Grammar

# Generated at 2022-06-23 15:32:25.448353
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import ast
    import tempfile
    import os
    import pathlib
    with tempfile.TemporaryDirectory() as tmp_dir:
        test_grammar_pkl_path = os.path.join(tmp_dir, 'test_grammar.pkl')
        test_grammar = Grammar()
        test_grammar.dump(test_grammar_pkl_path)
        with open(test_grammar_pkl_path, 'rb') as test_grammar_pkl_file:
            test_grammar_pkl_file_content = test_grammar_pkl_file.read()
            test_grammar_pkl_file_content_str = test_grammar_pkl_file_content.decode("utf-8") 

# Generated at 2022-06-23 15:32:26.631830
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    new = Grammar()
    assert new is not None

# Generated at 2022-06-23 15:32:31.718631
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert not g.async_keywords


# Generated at 2022-06-23 15:32:36.449456
# Unit test for constructor of class Grammar
def test_Grammar():
    try:
        g = Grammar()
        assert not g.symbol2number
        assert not g.number2symbol
        assert not g.states
        assert not g.dfas
        assert g.labels == [(0, "EMPTY")]
        assert not g.keywords
        assert not g.tokens
        assert not g.symbol2label
        assert g.start == 256
    except:
        print("Grammar constructor failed")
        raise

# Constructor should not fail
test_Grammar()

# Generated at 2022-06-23 15:32:45.949436
# Unit test for method load of class Grammar
def test_Grammar_load():
    import io
    import pickle
    import tempfile
    import unittest

    class TestGrammar(unittest.TestCase):
        @classmethod
        def setUpClass(cls):
            cls.pkl = io.BytesIO()
            g = Grammar()
            g.symbol2number = {"a": 1, "b": 2}
            g.number2symbol = {"3": "c", "4": "d"}
            g.start = 3
            g.labels = ["e", "f"]
            pickle.dump(g, cls.pkl, pickle.HIGHEST_PROTOCOL)
            cls.pkl.seek(0)

        @classmethod
        def tearDownClass(cls):
            cls.pkl.close()


# Generated at 2022-06-23 15:32:47.940129
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # This test is only used to force mypyc to compile the __getstate__
    # and __setstate__ methods.
    g = Grammar()
    g.loads(g.dumps())

# Generated at 2022-06-23 15:32:55.564890
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen2
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as temp_dir:
        fn = Path(temp_dir, "Grammar.pkl")
        grammar = pgen2.driver.load_grammar("3.7")
        grammar.dump(str(fn))
        loaded_grammar = Grammar()
        loaded_grammar.load(str(fn))
        assert loaded_grammar.dfas[grammar.start] == grammar.dfas[grammar.start]

# Generated at 2022-06-23 15:33:04.096305
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import ast
    import io
    import pickle
    source = io.StringIO('x = "test_str"')
    mod = ast.parse(source.read())
    pickled_mod_copy = pickle.dumps(mod)
    pickled_mod_copy = pickle.loads(pickled_mod_copy)
    g = Grammar()
    g.tokens = {1: 2, 2: 1}
    g.labels = [(1, None)]
    g.dfas = {3: ([[(2, 1)]], {1: 1})}
    g.states = [g.dfas[3][0]]
    g.number2symbol = {1: 'number', 2: 'symbol'}
    g.symbol2number = {'number': 1, 'symbol': 2}


# Generated at 2022-06-23 15:33:10.139871
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    gram = Grammar()
    gram.dfas.clear()
    gram.dump("test.pickle")
    gram = Grammar()
    gram.load("test.pickle")
    gram.dfas.clear()
    gram.dump("test2.pickle")
    assert open("test.pickle", "rb").read() == open("test2.pickle", "rb").read(), "pickle files are not equal"

# Generated at 2022-06-23 15:33:21.203257
# Unit test for method report of class Grammar
def test_Grammar_report():
    """Test for method report of class Grammar.

    Write out the tokens and expected characters.
    We only can do this in Python 3.
    """
    from pprint import pprint

    import token

    tt = token.tok_name
    to = {}
    for k, v in tt.items():
        to[v] = k
    print('\n# This table is generated using:'
          '\n#     test/lib2to3/fixes/fix_tokens.py')
    print()
    print('token_chars = {')
    pprint(to)
    print('}\n')
    print('# This table is generated using:'
          '\n#     test/lib2to3/fixes/fix_tokens.py')
    print()
    print('token_triples = [')

# Generated at 2022-06-23 15:33:31.693943
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import pickle
    g = Grammar()
    g.symbol2number = { 'a': 2, 'b': 3 }
    g.number2symbol = { 2: 'a', 3: 'b' }
    g.dfas = { 2: (1,1), 3: (2,2) }
    g.keywords = { 'a': 4, 'b': 5 }
    g.tokens = { 6: 7, 8: 9 }
    g.symbol2label = { 'a': 10, 'b': 11 }
    g.labels = [ (0, "EMPTY"), (1, None), (2, None) ]
    g.states = [ [ (1, 2) ], [ (0, 1) ] ]
    g.start = 256
    g.async_keywords = False
    h

# Generated at 2022-06-23 15:33:37.496862
# Unit test for method report of class Grammar
def test_Grammar_report():
    from io import StringIO
    import sys

    sys_stdout_save = sys.stdout
    sys.stdout = StringIO()

    g = Grammar()
    g.report()
    g.symbol2number = {'foo': 1}
    g.report()
    assert str(g.symbol2number) in sys.stdout.getvalue()
    sys.stdout.close()
    sys.stdout = sys_stdout_save

# Generated at 2022-06-23 15:33:47.159223
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import unittest
    import types
    f = tempfile.NamedTemporaryFile()
    f.close()

# Generated at 2022-06-23 15:33:58.059957
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    from .pgen2 import driver
    from . import token

    filename = "Grammar.pickle"
    driver.generate_grammar("Grammar.txt")
    pgen_grammar = driver.load_grammar("Grammar.txt")
    pgen_grammar.dump("Grammar.pickle")
    pgen_copy_grammar = Grammar()
    pgen_copy_grammar.load("Grammar.pickle")
    assert pgen_grammar == pgen_copy_grammar
    assert pgen_grammar.symbol2number == pgen_copy_grammar.symbol2number
    assert pgen_grammar.number2symbol == pgen_copy_grammar.number2symbol

# Generated at 2022-06-23 15:34:09.177407
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    import unittest
    from pprint import pprint


# Generated at 2022-06-23 15:34:15.818432
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """Unit test for method Grammar.dump."""

    # Original file
    filename = os.path.join(os.path.dirname(__file__), "Grammar.py")

    # Test table
    g = Grammar()
    with open(filename, "r") as f:
        g.parse(f.readline)
    g.dump("Grammar.pickle")

    # Test table
    g = Grammar()
    g.load("Grammar.pickle")

# Generated at 2022-06-23 15:34:21.656031
# Unit test for method load of class Grammar
def test_Grammar_load():
    import os
    import py_compile
    filename = os.path.abspath(__file__)
    py_compile.compile(filename)
    basename, ext = os.path.splitext(filename)
    assert ext == ".py"
    file_pkl = basename + ".pkl"
    g = Grammar()
    g.load(file_pkl)
    assert g.symbol2number["grammar"] == 258

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-23 15:34:25.044988
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2 import driver

    g = Grammar()
    filename = "rule.pkl"
    driver.load_grammar(g, filename)
    g.dump(filename)
    g2 = Grammar()
    g2.load(filename)
    assert g == g2

# Generated at 2022-06-23 15:34:30.534998
# Unit test for method copy of class Grammar

# Generated at 2022-06-23 15:34:36.778284
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords == False

# Unit tests for methods of class Grammar

# Generated at 2022-06-23 15:34:44.297517
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g2 = g1.copy()
    assert g2 is not g1
    assert g1.symbol2number is not g2.symbol2number
    assert g1.number2symbol is not g2.number2symbol
    assert g1.dfas is not g2.dfas
    assert g1.keywords is not g2.keywords
    assert g1.tokens is not g2.tokens
    assert g1.symbol2label is not g2.symbol2label
    assert g1.labels is not g2.labels
    assert g1.states is not g2.states

# Generated at 2022-06-23 15:34:45.659365
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(__file__)
    grammar.load(__file__ + "pickle")
    grammar.loads(b"\x80\x03]q\x00.")

# Generated at 2022-06-23 15:34:47.126881
# Unit test for method report of class Grammar
def test_Grammar_report():
    grammar = Grammar()
    grammar.report()

# Generated at 2022-06-23 15:34:50.826954
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g1.number2symbol = {1: 'b', 2: 'a'}
    g1.start = 3

    g2 = g1.copy()

    assert g1.number2symbol == g2.number2symbol
    assert g1.start == g2.start

    g1.number2symbol[4] = 'd'
    assert g1.number2symbol != g2.number2symbol

# Generated at 2022-06-23 15:34:52.621094
# Unit test for method report of class Grammar
def test_Grammar_report():
    import sys
    from . import pickle as _pickle
    gr = _pickle.load(sys.stdin)
    gr.report()

# Generated at 2022-06-23 15:35:02.240978
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {'a': 1, 'b': 2, 'c': 3}
    g.number2symbol = {1: 'a', 2: 'b', 3: 'c'}
    g.dfas = {2: ([[(1, 2)], [(0, 3)]], {3: 4}), 3: ([[(1, 2)], [(0, 3)]], {3: 4})}
    g.keywords = {'a': 1, 'b': 2}
    g.tokens = {2: 1, 3: 1}
    g.symbol2label = {'a': 1, 'b': 1}
    g.labels = [(0, 'EMPTY')]

# Generated at 2022-06-23 15:35:14.251041
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    copy = grammar.copy()
    assert copy is not grammar
    for dict_attr in ("symbol2number", "number2symbol", "dfas",
                      "keywords", "tokens", "symbol2label"):
        assert getattr(copy, dict_attr) is not getattr(grammar, dict_attr)
        assert getattr(copy, dict_attr) == getattr(grammar, dict_attr)
    assert copy.labels is not grammar.labels
    assert copy.labels == grammar.labels
    assert copy.states is not grammar.states
    assert copy.states is grammar.states
    assert copy.start is grammar.start
    assert copy.async_keywords is grammar.async_keywords

if __name__ == "__main__":
    grammar = Grammar()

# Generated at 2022-06-23 15:35:25.233078
# Unit test for constructor of class Grammar
def test_Grammar():
    from pickle import dumps
    from pickle import HIGHEST_PROTOCOL
    from pickle import loads
    from types import ModuleType
    s = dumps(Grammar(), HIGHEST_PROTOCOL)
    t = type(loads(s))
    assert issubclass(t, Grammar)
    assert isinstance(t, type)
    assert isinstance(t, type)
    assert isinstance(t.__base__, tuple)
    assert isinstance(t.__base__, tuple)
    assert isinstance(t.__base__[0], type)
    assert isinstance(t.__base__[0], type)
    assert isinstance(t.__base__[0].__base__, tuple)
    assert isinstance(t.__base__[0].__base__, tuple)

# Generated at 2022-06-23 15:35:37.026735
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import sys
    def render_DFA(DFA):
        return "(" + str(DFA[0]) + ", " + str(DFA[1]) + ")"
    def render_DFAS(DFAS):
        return "[" + render_DFA(DFAS[0]) + ", " + str(DFAS[1]) + "]"
    def render_Grammar(g):
        return str((g.symbol2number, g.number2symbol, g.states, g.dfas, g.keywords, g.tokens, g.symbol2label))
    g1 = Grammar()
    g1.symbol2number = {"a": 1, "b": 2}
    g1.number2symbol = {1: "a", 2: "b"}

# Generated at 2022-06-23 15:35:41.366368
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import pickle
    from .pgen2 import driver
    grammar = driver.load_grammar(sys.argv[1])
    grammar.dump(sys.argv[2])
    with open(sys.argv[2], "rb") as f:
        pickle.load(f)


# Generated at 2022-06-23 15:35:47.432603
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    gr = Grammar()
    gr_copy = gr.copy()
    assert gr.__dict__ == gr_copy.__dict__
    # Test with a Grammar instance that has been initialized
    gr.symbol2number = {'a': 1}
    gr_copy = gr.copy()
    assert gr.__dict__ == gr_copy.__dict__

# Generated at 2022-06-23 15:35:56.023515
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen

    g = Grammar()
    pgen.pgen(g, "Grammar.pickle", "Python.asdl")
    g.dump("test/test_Grammar.output")
    g2 = Grammar()
    g2.load("test/test_Grammar.output")
    assert g.start == g2.start
    assert g.labels == g2.labels
    assert g.dfas == g2.dfas
    assert g.keywords == g2.keywords


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-23 15:36:00.731499
# Unit test for method report of class Grammar
def test_Grammar_report():
  import unittest
  from . import pgen2

  class TestGrammar(unittest.TestCase):
    def test_report(self):
      g = pgen2.pgen.generate_grammar()
      g.report()

  unittest.main()

# Generated at 2022-06-23 15:36:12.525904
# Unit test for method load of class Grammar
def test_Grammar_load():
    print("Test loading a pickle byte string")
    from . import pgen

    g = pgen.generate_grammar()
    fname = "./pickle_test_Grammar_load.pkl"
    g.dump(fname)
    print("Saved grammar to", fname)

    h = Grammar()
    with open(fname, "rb") as gfile:
        pkl = gfile.read()
    h.loads(pkl)
    if h == g:
        print("Successfully loaded a pickle byte string")
    else:
        print("Failed to load a pickle byte string")

    print("Test loading a pickle file")
    g = pgen.generate_grammar()
    fname = "./pickle_test_Grammar_load.pkl"
   

# Generated at 2022-06-23 15:36:23.916223
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-23 15:36:31.429121
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    def _test(s: str, g: Grammar) -> None:
        g1 = Grammar()
        g1.loads(s)
        assert g == g1

    g = Grammar()
    g.symbol2number = {"a": 256}
    s = pickle.dumps(g, pickle.HIGHEST_PROTOCOL)
    _test(s, g)

    g1 = Grammar()
    g1.symbol2number = {"a": 256}
    g2 = Grammar()
    g2.loads(s)
    assert g1 == g2

# Generated at 2022-06-23 15:36:36.635974
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256



# Generated at 2022-06-23 15:36:38.482970
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("./pgen_pickle_files/Grammar.pickle")
    g.report()


# Generated at 2022-06-23 15:36:49.327837
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle

    g = Grammar()
    g.symbol2number["foo"] = 123
    g.states.append([(1, 2), (3, 4)])
    g.dfas[5] = (g.states[0], {1: 1, 3: 1})
    g.labels.append((6, "bar"))
    g.tokens[7] = 8
    g.async_keywords = True
    g.dump("foo")

    h = Grammar()
    h.load("foo")
    assert h == g

    pkl = pickle.dumps(g, pickle.HIGHEST_PROTOCOL)
    g.loads(pkl)

    n = g.copy()
    assert n == g

# Generated at 2022-06-23 15:36:59.349772
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """
    This method tests the Grammar.dump() method.
    """
    gram = Grammar()

    gram.symbol2number = {'t_COMMA': 258, 't_SEMI': 259}
    gram.number2symbol = {258: 't_COMMA', 259: 't_SEMI'}
    gram.states = [[[(1, 1)], [(2, 2)]]]
    gram.dfas = {258: ([[(1, 1)]], {1: 1})}
    gram.labels = [('EMPTY', None), ('COMMA', None), ('SEMI', None)]
    gram.keywords = {'COMMA': 1, 'SEMI': 2}
    gram.tokens = {59: 1, 59: 2}

# Generated at 2022-06-23 15:37:05.478199
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    filename = None
    try:
        with tempfile.NamedTemporaryFile(delete=False) as f:
            filename = f.name
        g.dump(filename)
        g2 = Grammar()
        g2.load(filename)
    finally:
        if filename is not None:
            os.remove(filename)


# Generated at 2022-06-23 15:37:15.903227
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import pickle

    g = Grammar()
    g.states = [[[(0, 0)], [(1, 1)], [(2, 0)]]]
    g.symbol2number = {'symb2': 2, 'symb1': 1, 'symb0': 0}
    g.number2symbol = {0: 'symb0', 1: 'symb1', 2: 'symb2'}

# Generated at 2022-06-23 15:37:19.175477
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load('/Users/mabharath/Documents/GitHub/sicp-py/sicp/grammar.pkl')
    grammar.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-23 15:37:27.256563
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-23 15:37:32.360805
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import tokenize
    g = Grammar()
    p = "../Grammar.txt"
    with open(p, "rb") as f:
        g.loads(tokenize.detect_encoding(f.readline)[0].encode("utf-8"))


# Generated at 2022-06-23 15:37:40.110808
# Unit test for method loads of class Grammar

# Generated at 2022-06-23 15:37:51.583463
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    from . import grammar
    from . import python_grammar

    original_grammar = python_grammar
    new_grammar = original_grammar.copy()

    # Check that each attribute of new_grammar is the same as in original_grammar
    for attr in ["symbol2number", "number2symbol", "dfas", "keywords", "tokens", "symbol2label"]:
        assert getattr(new_grammar, attr) == getattr(original_grammar, attr)
    assert new_grammar.labels == original_grammar.labels
    assert new_grammar.states == original_grammar.states
    assert new_grammar.start == original_grammar.start
    assert new_grammar.async_keywords == original_grammar.async_keywords

# Generated at 2022-06-23 15:37:53.282254
# Unit test for constructor of class Grammar
def test_Grammar():
    pass # leave this line empty



# Generated at 2022-06-23 15:38:02.697303
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Verify that Grammar.load() and Grammar.loads() work as expected."""
    grammar = Grammar()
    grammar.start = 17
    grammar.dfas = {1: ("abc", frozenset({"def"}))}
    grammar.labels = [("ghi", "jkl")]
    grammar.tokens = {3: 27, 17: -1}
    grammar.symbol2label = {"mno": 42}
    grammar.symbol2number = {"pqr": -123}
    grammar.number2symbol = {-123: "pqr"}
    grammar.keywords = {"stu": 0, "vwx": 1}
    grammar.states = [["abc", "def", "ghi"]]
    grammar.async_keywords = True
    assert grammar.start == 17


# Generated at 2022-06-23 15:38:06.945499
# Unit test for method report of class Grammar
def test_Grammar_report():
    """Check whether Grammar.report() runs without errors.
    """
    import unittest
    import test.test_grammar
    from . import conv, pgen

    class TestGrammar(unittest.TestCase):

        def test_report(self):
            g = pgen.generate_grammar()
            c = conv.Converter(g)
            c.convert()
            g.report()

    test.test_grammar.run_unittest(TestGrammar)

# Generated at 2022-06-23 15:38:19.374448
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()

# Generated at 2022-06-23 15:38:22.442706
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    from . import pgen2

    gram = pgen2.tokenize("grammar.txt")
    gram.loads(gram.dumps())
    assert gram.symbol2number["file_input"] == 256

# Generated at 2022-06-23 15:38:30.390123
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    grammar = Grammar()

# Generated at 2022-06-23 15:38:42.917108
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'SYMBOL': 256}
    g.number2symbol = {256:'SYMBOL'}
    g.states = [[[(1,1)],[(1,1)]]]
    g.dfas = {256: ([[(1,1)]], {1: 1})}
    g.labels = [(0, "EMPTY"), (1, "LABEL")]
    g.keywords = {'KEYWORD': 1}
    g.tokens = {1: 1}
    g.symbol2label = {'SYMBOL': 1}
    g.start = 256

    g.dump("example_pgen_dump.pkl")

    f = open("example_pgen_dump.pkl", "rb")

# Generated at 2022-06-23 15:38:49.179509
# Unit test for constructor of class Grammar
def test_Grammar():
    gram = Grammar()
    # empty tables
    assert gram.symbol2number == {}
    assert gram.number2symbol == {}
    assert gram.states == []
    assert gram.dfas == {}
    assert gram.labels == [(0, "EMPTY")]
    assert gram.keywords == {}
    assert gram.tokens == {}
    assert gram.symbol2label == {}
    assert gram.start == 256
    assert not gram.async_keywords

# Generated at 2022-06-23 15:38:50.587503
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()


del opmap_raw



# Generated at 2022-06-23 15:38:58.966724
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {'a': 10, 'b': 20}
    g.number2symbol = {10: 'a', 20: 'b'}
    g.dfas = {1: ([0, 1], {0: 0}), 2: ([0, 1], {0: 0})}
    g.keywords = {'a': 1, 'b': 2}
    g.tokens = {1: 0, 2: 1}
    g.symbol2label = {'c': 3, 'd': 4}
    g.labels = [(0, 'a'), (1, 'b')]
    g.states = [[(0, 1)], [(0, 2)]]
    g.start = 3
    g.async_keywords = False
    g_cpy

# Generated at 2022-06-23 15:39:07.141398
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    import pickle
    from . import grammar

    s = pickle.dumps(grammar.grammar)
    g = Grammar()
    g.loads(s)

    # Add in Python's 'backquote' token type
    g.number2symbol[token.BACKQUOTE] = "`"
    g.symbol2number["`"] = token.BACKQUOTE

    # 3.7+: async and await are keywords, not identifiers
    g.symbol2number["async"] = token.ASYNC
    g.symbol2number["await"] = token.AWAIT
    g.async_keywords = True

    # Ensure that we have all the expected names.

# Generated at 2022-06-23 15:39:16.433997
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import sys

    # Test the method copy of class Grammar
    # The internal constructor of Grammar is too complicated to test, so
    # we import the module 'python.pgen2.pgen2' to get the class Grammar,
    # and try to restore the internal states by using the method 'setstate'
    if sys.version_info < (3, 5):
        # The module 'python.pgen2.pgen2' was renamed to 'python.pgen2'
        # in Python 3.5, we need test both
        from . import python_pgen2
    else:
        from . import python_pgen2
        from . import python_pgen25


# Generated at 2022-06-23 15:39:26.804807
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.report()
    g.symbol2number = {'a':1, 'b':2}
    g.number2symbol = {1:'a', 2:'b'}
    g.dfas = {1:{'a':2, 'b':3}, 2:{'a':1, 'b':2}, 3:{'a':3, 'b':1}}
    g.keywords = {'a':1, 'b':2}
    g.tokens = {1:2, 2:1}
    g.symbol2label = {'a':1, 'b':2}
    g.labels = [(1, 'a'), (2, 'b')]

# Generated at 2022-06-23 15:39:29.566762
# Unit test for method report of class Grammar
def test_Grammar_report():
    from . import tokenizer
    from . import pgen2

    def check_report(version):
        pgen = pgen2.Pgen2(tokenizer.__file__, version)
        g = pgen.load_grammar()
        g.report()

    check_report(2)
    check_report(3)
    check_report(4)
    check_report(5)

# Generated at 2022-06-23 15:39:30.381697
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()



# Generated at 2022-06-23 15:39:38.695691
# Unit test for constructor of class Grammar
def test_Grammar():
    start = 256
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == start
    assert g.async_keywords == False

# Generated at 2022-06-23 15:39:47.580429
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    class myGrammar(Grammar):
        def __init__(self):
            super(myGrammar, self).__init__()
            self.symbol2number: Dict[str, int] = {}
            self.number2symbol: Dict[int, str] = {}
            self.states: List[DFA] = []
            self.dfas: Dict[int, DFAS] = {}
            self.labels: List[Label] = [(0, "EMPTY")]
            self.keywords: Dict[str, int] = {}
            self.tokens: Dict[int, int] = {}
            self.symbol2label: Dict[str, int] = {}
            self.start = 256
            # Python 3.7+ parses async as a keyword, not an identifier
           

# Generated at 2022-06-23 15:39:48.845314
# Unit test for constructor of class Grammar
def test_Grammar():
    assert Grammar.__doc__
    assert Grammar().__class__ == Grammar

# Generated at 2022-06-23 15:39:55.606514
# Unit test for method report of class Grammar
def test_Grammar_report():
    def sa(s: Text, v: Any) -> None:
        globals()[s] = v

    g = Grammar()

    sa("symbol2number", {"if": 1})
    sa("number2symbol", {1: "if"})
    sa("states", [[[], [], []]])
    sa("dfas", {1: ([], {})})
    sa("labels", [(0, "EMPTY"), (1, None)])
    sa("keywords", {"if": 1})
    sa("tokens", {1: 1})
    sa("symbol2label", {"if": 1})
    sa("start", 256)
    sa("async_keywords", False)

    g.report()

# Generated at 2022-06-23 15:39:57.576965
# Unit test for constructor of class Grammar
def test_Grammar():
    test = Grammar()
    assert test


# Generated at 2022-06-23 15:40:08.409711
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g2 = Grammar()
    g1.symbol2number = {'a': 1, 'b':2}
    g1.number2symbol = {1: 'a', 2: 'b'}
    g1.dfas = {1: [1, 2], 2: [3, 4]}
    g1.keywords = {'c': 1, 'd': 2}
    g1.tokens = {5: 1, 6: 2}
    g1.symbol2label = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    g1.labels = [(1, 'a'), (2, 'b'), (3, 'c'), (4, 'd')]