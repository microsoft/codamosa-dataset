

# Generated at 2022-06-21 09:58:42.694760
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    new = Grammar()
    new.symbol2number = {'symbol': 1}
    new.number2symbol = {1: 'number'}
    new.states = [[(1,2)]]
    new.dfas = {5:{5:[3,4], 6:[5,6]}}
    new.keywords = {'k1':1, 'k2':2}
    new.tokens = {51:100, 52:200}
    new.symbol2label = {'s1':1, 's2':2}
    new.labels = [(1,'l1'), (2,'l2')]

    new2 = Grammar()
    new2 = new.copy()
    assert new2.symbol2number == {'symbol': 1}

# Generated at 2022-06-21 09:58:46.532796
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    a = Grammar()
    b = Grammar()
    a.load('Grammar.txt')
    b.loads(pickle.dumps(a.__getstate__()))
    assert(a.__getstate__() == b.__getstate__())

# Generated at 2022-06-21 09:58:59.582664
# Unit test for method report of class Grammar
def test_Grammar_report():
    import unittest
    import io
    import sys

    from . import pgen, conv

    class TestGrammar(unittest.TestCase):

        def setUp(self):
            self.real_stdout = sys.stdout
            sys.stdout = io.StringIO()

        def tearDown(self):
            sys.stdout = self.real_stdout

        def test_python27_report(self):
            gr = conv.convert_grammar(pgen.grammar, "27")
            gr.report()
            output = sys.stdout.getvalue()
            self.assertTrue(output != "")
            self.assertTrue("symbol2number" in output)
            self.assertTrue("states" in output)
            self.assertTrue("dfas" in output)
            self.assertTrue

# Generated at 2022-06-21 09:59:09.522861
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g2 = g1.copy()
    assert g1.labels == g2.labels
    assert g1.symbol2label == g2.symbol2label
    assert g1.symbol2number == g2.symbol2number
    assert g1.number2symbol == g2.number2symbol
    assert g1.dfas == g2.dfas
    assert g1.keywords == g2.keywords
    assert g1.tokens == g2.tokens
    assert g1.start == g2.start
    g1.labels.append((1, "label"))
    g1.symbol2label["symb"] = 1
    g1.symbol2number["symb"] = "number"

# Generated at 2022-06-21 09:59:11.818697
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load('Grammar.pkl')

# Generated at 2022-06-21 09:59:19.408973
# Unit test for method load of class Grammar
def test_Grammar_load():
    """This unit test checks the Grammar.load method."""
    from .pgen2 import tokenize

    # Load the Python grammar
    gr = Grammar()
    gr.load(tokenize._grammar_file)
    assert gr.start == gr.symbol2number["file_input"]


if __name__ == "__main__":
    # Run unit test for Grammar.load
    test_Grammar_load()
    print("unit test for Grammar.load: ok")

# Generated at 2022-06-21 09:59:21.601903
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256

# Generated at 2022-06-21 09:59:22.561688
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()

# Generated at 2022-06-21 09:59:34.085992
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    grammar = Grammar()

# Generated at 2022-06-21 09:59:43.327957
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import datetime
    import os

    def test_dump_load(g: Grammar, tmp_path: Path) -> None:
        filename = tmp_path / "graminit.cache"
        g.dump(filename)
        g2 = g.copy()
        g2.load(filename)
        assert g == g2

    class MyGrammar(Grammar):
        def __init__(self) -> None:
            Grammar.__init__(self)
            self.symbol2number = {'foo': 2}
            self.number2symbol = {2: 'foo'}
            self.states = [[[(0, 0)]]]
            self.dfas = {
                2: (self.states[0], {-1: -1, 0: 0}),
            }
            self.labels

# Generated at 2022-06-21 09:59:57.846498
# Unit test for method report of class Grammar

# Generated at 2022-06-21 10:00:00.875182
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    assert g1 is not g1.copy()
    g2 = Grammar()
    assert g1 is not g2
    assert g1.copy() is not g2.copy()

# Generated at 2022-06-21 10:00:05.219579
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    g._update({'keywords': {'async': 257, 'await': 258}})
    s = pickle.dumps(g.__getstate__())
    g2 = Grammar()
    g2.loads(s)
    assert g2.keywords == {'async': 257, 'await': 258}

# Generated at 2022-06-21 10:00:11.349008
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Test the method Grammar.load

    Test that the data loaded by a call to Grammar.load are correct.
    """
    # Create a Grammar object
    g = Grammar()

    # Check the attributes of the Grammar object
    # before the load
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords == False

    # Create a path for the pickle file

# Generated at 2022-06-21 10:00:22.389324
# Unit test for method report of class Grammar

# Generated at 2022-06-21 10:00:29.360983
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g2 = g1.copy()
    assert g1.symbol2number is not g2.symbol2number
    assert g1.number2symbol is not g2.number2symbol
    assert g1.dfas is not g2.dfas
    assert g1.keywords is not g2.keywords
    assert g1.tokens is not g2.tokens
    assert g1.symbol2label is not g2.symbol2label
    assert g1.labels is not g2.labels
    assert g1.states is not g2.states
    assert g1.start == g2.start
    assert g1.async_keywords is g2.async_keywords

# Generated at 2022-06-21 10:00:38.212815
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {'a': 1, 'b': 2}
    g.number2symbol = {1: 'a', 2: 'b'}
    g.dfas = {3: ([[1, 2]], {1: 1})}
    g.keywords = {'a': 2}
    g.tokens = {1: 2}
    g.symbol2label = {'a': 2}
    g.labels = [([2, 3], 'a')]
    g.states = [[2, 3], [4, 5]]
    g.start = 256
    g.async_keywords = True

    g2 = g.copy()


# Generated at 2022-06-21 10:00:47.462951
# Unit test for method report of class Grammar
def test_Grammar_report():
    from _ast import Pass, If, Name, Store, Load, Add, Sub, BinOp, NameConstant, Constant, Str
    g = Grammar()
    g.report()
    g.symbol2number = {'test': 256}
    g.number2symbol = {256: 'test'}
    g.states = [[[(0, 1)]], [[(1, 2)]]]
    g.labels = [(0, "EMPTY"), (1, "test")]
    g.keywords = {'test': 1}
    g.tokens = {256: 1}
    g.start = 256
    g.async_keywords = False
    g.report()

# Generated at 2022-06-21 10:00:51.187577
# Unit test for method report of class Grammar
def test_Grammar_report():
    from .parser import get_grammar

    grammar = Grammar()
    grammar.load(get_grammar())
    # Just in case we're running in parallel for coverage.
    print()
    grammar.report()



# Generated at 2022-06-21 10:01:02.079890
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.symbol2number = {'foo': 0}
    g.number2symbol = {0: 'bar'}
    g.states = [[1, 2], [3, 4]]
    g.dfas = {0: ((5, 6), {7: 8})}
    g.labels = [(9, 'x'), (0, 'y')]
    g.start = 42
    f = tempfile.NamedTemporaryFile()

# Generated at 2022-06-21 10:01:21.058157
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import os
    import tokenize

    pickle_file = "./Grammar.pkl"
    grammar = Grammar()

    if os.path.exists(pickle_file):
        grammar.load(pickle_file)
        assert(len(grammar.symbol2number) == 0)
        assert(len(grammar.number2symbol) == 0)
        assert(len(grammar.dfas) == 0)
        assert(len(grammar.symbol2label) == 0)
        assert(len(grammar.keywords) == 0)
        assert(len(grammar.tokens) == 0)
        assert(len(grammar.labels) == 0)
        assert(grammar.start == 0)


# Generated at 2022-06-21 10:01:23.215816
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()

# Unit test:  Create a grammar object, populate it, pickle it,
# unpickle it.

# Generated at 2022-06-21 10:01:31.203036
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-21 10:01:31.793468
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()

# Generated at 2022-06-21 10:01:34.166134
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    assert grammar.dump(os.devnull) == None, "Bad return value"

# Generated at 2022-06-21 10:01:37.474934
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    import pickle
    grammar = Grammar()
    #import pdb; pdb.set_trace()
    grammar.loads(pickle.dumps(grammar.__dict__))


# Generated at 2022-06-21 10:01:48.640804
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io
    import pprint
    import sys

    g = Grammar()
    g.symbol2number = {'a': 1}
    g.number2symbol = {2: 'b'}
    g.states = [[[(0, 0)]]]
    g.dfas = {3: ([[(0, 0)]], {0: 0}), 4: ([[(0, 0)]], {0: 0})}
    g.labels = [(0, ''), (1, 'a'), (2, 'b')]
    g.keywords = {'c': 1, '': 2}
    g.tokens = {0: 1}
    g.symbol2label = {'d': 1}
    g.start = 10
    saved_stdout = sys.stdout

# Generated at 2022-06-21 10:01:50.813475
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    from .pgen2 import driver

    g = driver.load_grammar("Grammar.txt")
    g.copy()

# Generated at 2022-06-21 10:02:02.859395
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    tables = Grammar()

# Generated at 2022-06-21 10:02:04.306393
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()


# Generated at 2022-06-21 10:02:31.012529
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    def assertEqual(x, y):
        assert x == y
    def assertNotEqual(x, y):
        assert x != y
    def assertIs(x, y):
        assert x is y
    EmptyGrammar = b(
        '\x80\x03cfoo.bar\n'
        'Grammar\n'
        'q\x00)\x81q\x01.'
    )
    empty_g = Grammar()
    empty_g.loads(EmptyGrammar)
    assertEqual(empty_g.symbol2number, {})
    assertEqual(empty_g.number2symbol, {})
    assertEqual(empty_g.states, [])
    assertEqual(empty_g.dfas, {})

# Generated at 2022-06-21 10:02:40.275497
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Test with a grammar object with a __dict__, which is what we normally have
    g = Grammar()
    g.start = 42
    assert g.start == 42

    # Test that dump works with a grammar with a __dict__
    filename = tempfile.mktemp()
    g.dump(filename)

    # Test that the pickle file actually has the right stuff in it
    newg = Grammar()
    newg.load(filename)
    assert newg.start == 42

    # Test with a mock Grammar that doesn't have a __dict__, but does have a __getstate__
    class MockGrammar:
        def __getstate__(self) -> Dict[str, Any]:
            return {"start": 42}

    # Test that dump works with a __getstate__ Grammar
    filename = tempfile.mk

# Generated at 2022-06-21 10:02:52.459333
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # Create a grammar object with some known attributes
    gr = Grammar()
    gr.symbol2number = {"A": 1, "B": 2, "C": 3}
    gr.number2symbol = {1: "A", 2: "B", 3: "C"}
    gr.states = [[[(1, 2)], [(3, 2)]]]
    gr.dfas = {1: ([[(1, 2)], [(3, 2)]], {1: None}), 2: ([[(1, 2)], [(3, 2)]], {1: 1})}
    gr.labels = [(1, None), (2, None), (3, None)]
    gr.keywords = {"A": 1, "B": 2}
    gr.tokens = {1: 1, 2: 2}

# Generated at 2022-06-21 10:02:53.297083
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()

# Generated at 2022-06-21 10:02:55.949063
# Unit test for method report of class Grammar
def test_Grammar_report():
    # This test is specifically for inspect.signature in
    # Grammar.report().
    grammar = Grammar()
    with open(os.devnull, 'w') as f:
        # This used to raise ValueError:
        grammar.report()

# Generated at 2022-06-21 10:02:57.114069
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()


# Generated at 2022-06-21 10:02:58.842242
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    def f() -> None:
        g = Grammar()
        g.loads(b"cos\nsystem\n(S'ls'\ntR.")

    f()



# Generated at 2022-06-21 10:03:00.948653
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(token.__file__.rstrip("co"))

# Generated at 2022-06-21 10:03:12.363261
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    grammar = Grammar()
    # since Grammar does not implement __getstate__, this will use __dict__
    state = grammar.__dict__
    pkl = pickle.dumps(state, pickle.HIGHEST_PROTOCOL)
    grammar.loads(pkl)
    assert grammar.symbol2number == {}
    assert grammar.number2symbol == {}
    assert grammar.states == []
    assert grammar.dfas == {}
    assert grammar.labels == [(0, "EMPTY")]
    assert grammar.keywords == {}
    assert grammar.tokens == {}
    assert grammar.symbol2label == {}
    assert grammar.start == 256
    assert grammar.async_keywords == False
    assert grammar.start == 256
    assert grammar.async_keywords == False

# Generated at 2022-06-21 10:03:19.848222
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2
    from . import pgen

    g = Grammar()
    g.load("Python.grammar")
    gp = pgen.GenerateGrammar()
    gp.generate("Grammar.out", g)
    g2 = Grammar()
    g2.load("Grammar.out")
    assert g == g2
    if pgen2:
        g3 = pgen2.pickle_grammar("Python.grammar", "Grammar.out2")
        assert g == g3

# Generated at 2022-06-21 10:03:38.552570
# Unit test for method load of class Grammar
def test_Grammar_load():
    """
    In the Python grammar, there are 7840 states, 1453 labels and 449 dfas.
    """
    from . import grammar
    from .pgen2 import driver
    g = grammar.Grammar()
    driver.load_grammar("Grammar.txt", g)
    assert len(g.states) == 7840
    assert len(g.labels) == 1453
    assert len(g.dfas) == 449

# Generated at 2022-06-21 10:03:48.358335
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test load() for empty file
    gr = Grammar()
    with tempfile.NamedTemporaryFile() as f:
        gr.load(f.name)

    # Test load() for file containing something else than a pickle
    with tempfile.NamedTemporaryFile("w") as f:
        f.write("test")
        f.flush()
        try:
            gr.load(f.name)
        except EOFError:
            pass
        except IOError:
            # Python 2
            pass
        else:
            assert(False)

    # Test load() for unpickleable content
    def bad_load():
        raise ValueError("test")


# Generated at 2022-06-21 10:04:00.693109
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import sys
    import unittest.mock

    def mock_NamedTemporaryFile(dir: str, delete: bool = False) -> io.BytesIO:
        return io.BytesIO()

    class mock_pickle(unittest.mock.MagicMock):
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            super().__init__(*args, **kwargs)
            self.HIGHEST_PROTOCOL = 4

    class mock_os(unittest.mock.MagicMock):
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            super().__init__(*args, **kwargs)
            self.replace = unittest.mock.MagicMock

    g = Grammar()

# Generated at 2022-06-21 10:04:08.884688
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))

    assert g.dfas == {256: ([[(38, 3), (25, 2)], [(0, 1)], [(0, 1)], [(0, 1)]], {
        1: 1,
        2: 1,
        3: 1
    })}

    assert g.labels == [(0, 'EMPTY'), (25, None), (38, None)]

    assert g.number2symbol == {256: 's_stmt'}

    assert g.states == [[[(38, 3), (25, 2)], [(0, 1)], [(0, 1)], [(0, 1)]]]

    assert g.start == 256

    assert g.sy

# Generated at 2022-06-21 10:04:11.339202
# Unit test for constructor of class Grammar
def test_Grammar():
    print(Grammar.__doc__)

if __name__ == "__main__":
    test_Grammar()

# Generated at 2022-06-21 10:04:24.104739
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import parser
    import token
    p = parser.Parser()
    g = Grammar()
    p.parsetokens(g)
    g.dump(os.path.join(os.path.dirname(__file__), "Grammar.txt"))
    assert g.number2symbol[256] == 'file_input'
    assert g.number2symbol[259] == 'suite'
    assert g.number2symbol[271] == 'simple_stmt'
    assert g.symbol2number['testlist_star_expr'] == 269
    assert g.symbol2number['small_stmt'] == 270
    assert g.keywords['True'] == 5
    assert g.tokens[token.NUMBER] == 1
    assert g.symbol2label['atom_expr'] == 268


# Generated at 2022-06-21 10:04:34.246533
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.symbol2number["foo"] = 1
    assert g.symbol2number["foo"] == 1
    g.dump("/tmp/t")
    g2 = Grammar()
    assert "foo" not in g2.symbol2number
    g2.load("/tmp/t")
    assert g2.symbol2number["foo"] == 1
    os.remove("/tmp/t")
    # loading bogus file should raise exception that includes filename
    try:
        g2.load("/hopefully/this/path/does/not/exist")
    except IOError as e:
        assert e.filename == "/hopefully/this/path/does/not/exist", e.filename

# Generated at 2022-06-21 10:04:46.549965
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import traceback
    import unittest

    class Grammar_dump_TestCase(unittest.TestCase):

        def test_dump(self):

            # A simple set of grammar tables

            class MyGrammar(Grammar):

                def __init__(self):
                    super().__init__()
                    self.symbol2number = {
                        "foo": 257,
                        "bar": 258,
                        "baz": 259,
                        "quux": 260,
                    }
                    self.number2symbol = {
                        v: k for k, v in self.symbol2number.items()
                    }

# Generated at 2022-06-21 10:04:48.942429
# Unit test for method load of class Grammar
def test_Grammar_load():
    gram = Grammar()
    gram.load('Grammar')
    assert gram == gram

# Testcase for method copy of class Grammar

# Generated at 2022-06-21 10:04:59.101959
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-21 10:05:22.050004
# Unit test for method report of class Grammar

# Generated at 2022-06-21 10:05:32.220561
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    from .tokenize import tokenize, untokenize, NUMBER, STRING
    from io import BytesIO
    from .parse import Parser
    p = Parser(Grammar())
    f = BytesIO("x = 2\n")
    p.set_file_input(f)
    p.input("2")
    assert p.next_token() == (NUMBER, "2", None)
    p.input("'foo'")
    assert p.next_token() == (STRING, "'foo'", None)
    # Any grammar should do
    f = BytesIO("import os\n")
    g = Grammar()
    g.loads(f.getbuffer())

# Generated at 2022-06-21 10:05:36.759118
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Test that Grammar can be loaded from a pickle file."""
    import tempfile
    from .grammar import grammar

    f = tempfile.NamedTemporaryFile()
    try:
        filename = f.name
        grammar.dump(filename)
        parser = Grammar()
        parser.load(filename)
    finally:
        f.close()

# Generated at 2022-06-21 10:05:46.639793
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io
    import sys

    # Capture stdout
    orig_stdout = sys.stdout
    sys.stdout = my_stdout = io.StringIO()

    # Construct a Grammar and call report
    g = Grammar()
    g.report()

    # Get printed output
    output = my_stdout.getvalue()

    # Restore stdout
    sys.stdout = orig_stdout

    # Verify that everything is as expected
    assert output.startswith("s2n\n{'error': 258}\n"), "missing s2n dict"
    assert output.startswith("n2s\n{258: 'error'}\n"), "missing n2s dict"
    assert output.startswith("states\n[[(512, 259), (513, 260)]]\n"), "missing states list"

# Generated at 2022-06-21 10:05:52.038116
# Unit test for constructor of class Grammar
def test_Grammar():
    gr = Grammar()
    assert gr.symbol2number == {}
    assert gr.number2symbol == {}
    assert gr.states == []
    assert gr.dfas == {}
    assert gr.labels == [(0, "EMPTY")]
    assert gr.keywords == {}
    assert gr.tokens == {}
    assert gr.symbol2label == {}
    assert gr.start == 256
    assert gr.async_keywords == False


# Generated at 2022-06-21 10:05:57.531516
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g1.symbol2number["foo"] = 2
    g1.symbol2number["bar"] = 5
    g1.async_keywords = True
    g2 = g1.copy()
    assert g2.symbol2number["foo"] == 2
    assert g2.symbol2number["bar"] == 5
    assert g2.async_keywords is True
    g1.symbol2number["foo"] = 3

    g1.async_keywords = False
    assert g2.symbol2number["foo"] == 2
    assert g2.symbol2number["bar"] == 5
    assert g2.async_keywords is True



# Generated at 2022-06-21 10:06:05.350711
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io
    out = io.StringIO()
    g = Grammar()
    g.report(file=out)
    out.seek(0)
    expected = (
        "s2n\n"
        "{}\n"
        "n2s\n"
        "{}\n"
        "states\n"
        "[]\n"
        "dfas\n"
        "{}\n"
        "labels\n"
        "[(0, 'EMPTY')]\n"
        "start 256\n"
    )
    assert out.read() == expected

# Generated at 2022-06-21 10:06:08.325839
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    test_Grammar_instance_attributes(g)
    test_Grammar_instance_methods(g)


# Generated at 2022-06-21 10:06:12.403458
# Unit test for constructor of class Grammar
def test_Grammar():
    grammar = Grammar()
    assert grammar.symbol2number == {}
    assert grammar.number2symbol == {}
    assert grammar.states == []
    assert grammar.dfas == {}
    assert grammar.labels == [(0, "EMPTY")]
    assert grammar.keywords == {}
    assert grammar.tokens == {}
    assert grammar.symbol2label == {}
    assert grammar.start == 256
    assert grammar.async_keywords is False


# Generated at 2022-06-21 10:06:24.316245
# Unit test for method loads of class Grammar

# Generated at 2022-06-21 10:06:38.933001
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from io import BytesIO
    g = Grammar()
    g.symbol2number["foo"] = 42
    g.number2symbol[42] = "foo"
    g.labels.append((0, "bar"))
    g.start = 42
    f = BytesIO()
    g.dump(f)
    assert f.getvalue() == pickle.dumps(g.__dict__, pickle.HIGHEST_PROTOCOL)
    f = TextIOWrapper(BytesIO(), encoding="utf-8")
    g.dump(f)

# Generated at 2022-06-21 10:06:51.534799
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2
    from . import token
    from . import parser

    co_grammar = Grammar()

# Generated at 2022-06-21 10:07:02.134185
# Unit test for constructor of class Grammar
def test_Grammar():
    # Dummy symbols.
    symbols = ['a', 'b']
    # Make grammar from symbols.
    g = Grammar()
    # Test against list of symbols.
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, 'EMPTY')]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords == False


# Generated at 2022-06-21 10:07:10.031565
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = os.path.join(
        os.path.dirname(__file__), "../../external/uncompyle6/python3.8_grammar.pkl"
    )
    pkl = ""
    with open(filename, "rb") as f:
        pkl = f.read()
    g = Grammar()
    g.loads(pkl)
    assert g
    assert (
        len(g.symbol2number) > 100
    ), "symbol2number should contain > 100 keys: {0}".format(g.symbol2number)
    assert (
        len(g.number2symbol) > 100
    ), "number2symbol should contain > 100 keys: {0}".format(g.number2symbol)

# Generated at 2022-06-21 10:07:16.641633
# Unit test for method load of class Grammar
def test_Grammar_load(): # Turns out there is not yet an automated unit test.
    from . import pgen2

    g = Grammar()

    g.copy()

    gp = pgen2.driver.load_grammar("Grammar/Grammar")
    g.loads(gp)

    g.report()
    g.dump("./dump.pkl")


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-21 10:07:17.831086
# Unit test for method report of class Grammar
def test_Grammar_report():
    x = Grammar()
    x.report()

# Generated at 2022-06-21 10:07:27.545443
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g2 = g.copy()

    assert g is not g2
    assert g.symbol2number is not g2.symbol2number
    assert g.number2symbol is not g2.number2symbol
    assert g.dfas is not g2.dfas
    assert g.keywords is not g2.keywords
    assert g.tokens is not g2.tokens
    assert g.symbol2label is not g2.symbol2label
    assert g.labels is not g2.labels
    assert g.states is not g2.states

    assert g.start == g2.start
    assert g.async_keywords == g2.async_keywords

# Generated at 2022-06-21 10:07:35.473690
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    original = Grammar()
    copied = original.copy()
    assert original.symbol2number == copied.symbol2number
    assert original.number2symbol == copied.number2symbol
    assert original.dfas == copied.dfas
    assert original.keywords == copied.keywords
    assert original.tokens == copied.tokens
    assert original.symbol2label == copied.symbol2label
    assert original.labels == copied.labels
    assert original.states == copied.states
    assert original.start == copied.start
    assert original.async_keywords == copied.async_keywords
    assert type(original) is type(copied)


if __name__ == "__main__":
    import sys

    g = Grammar()
    g.load(sys.argv[1])

# Generated at 2022-06-21 10:07:37.818625
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    g.loads(g.dump(None))

# Generated at 2022-06-21 10:07:40.365467
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    from . import pgen2

    g = pgen2.grammar.Grammar()
    g.copy()

# Generated at 2022-06-21 10:08:10.044570
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io
    import sys
    import types

    g = Grammar()
    g.symbol2number = dict(a=1,b=2,c=3)
    g.number2symbol = dict(zip(g.symbol2number.values(),g.symbol2number.keys()))
    g.states = ["s1","s2","s3"]
    g.dfas = dict(a=("dfa1",{1}))
    g.labels = [(x,None) for x in range(3)]
    g.start = g.symbol2number['c']

    orig = sys.stdout
    sys.stdout = io.StringIO()

# Generated at 2022-06-21 10:08:13.839237
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.start == 256

# Generated at 2022-06-21 10:08:23.575802
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Effect:
    # Creates a temporary directory and a grammar with 2 rule. Then
    # creates a pickle file containing the grammar and finally dumps
    # the grammar. Example of temp dirs picked up from the standard
    # library test_tempfile.py
    def make_pickle_file() -> None:
        # Create a temporary directory and a grammar with 2 rule. Then
        # create a pickle file containing the grammar and finally dump
        # the grammar.
        grammar = Grammar()
        grammar.number2symbol = {0: "S", 1: "A", 2: "B", 3: "C", 4: "D"}
        grammar.symbol2number = {"S": 0, "A": 1, "B": 2, "C": 3, "D": 4}

# Generated at 2022-06-21 10:08:32.960468
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {"A": 1, "B": 2}  # type: ignore
    g.number2symbol = {1: "A", 2: "B"}  # type: ignore
    g.states = [[(0, 13)], [(0, 3), (0, 5)], [(0, 4)], [(0, 14), (0, 6)], [(0, 15)]]  # type: ignore
    g.dfas = {1: ([[(0, 1)], [(0, 3), (0, 5)], [(0, 4)], [(0, 6)]], {0: 1}), 2: ([[(0, 1)], [(0, 2)]], {2: 3})}  # type: ignore
    g.labels = [(0, "EMPTY")]  # type