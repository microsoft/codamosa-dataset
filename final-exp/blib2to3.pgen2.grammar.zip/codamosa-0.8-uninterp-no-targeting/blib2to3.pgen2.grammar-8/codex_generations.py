

# Generated at 2022-06-21 09:58:50.347329
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import re

    # pylint: disable=import-outside-toplevel
    from .conv import parse_grammar

    parse_grammar("Grammar.test_Grammar_copy", re, token, False, False).copy()

# Generated at 2022-06-21 09:58:51.389800
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    assert False


# Generated at 2022-06-21 09:58:52.419594
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()


test_Grammar()

# Generated at 2022-06-21 09:58:57.923138
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    g.report()
    g.dump("grammar.pkl")
    g = Grammar()
    g.load("grammar.pkl")
    g.report()


if __name__ == "__main__":
    test_Grammar()

# Generated at 2022-06-21 09:59:08.290151
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    filename = "test_Grammar_load"
    grammar.dump(filename)
    grammar.load(filename)
    os.remove(filename)

# Generated at 2022-06-21 09:59:12.974915
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-21 09:59:24.210869
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .python.graminit import grammar
    from .pygram import python_symbols as syms

    # Python 3.7+ parses async as a keyword, not an identifier
    grammar.async_keywords = True

    d = {}
    d["start"] = syms.file_input
    d["s2n"] = grammar.symbol2number
    d["n2s"] = grammar.number2symbol
    d["states"] = grammar.states
    d["dfas"] = grammar.dfas
    d["labels"] = grammar.labels
    d["keywords"] = grammar.keywords
    d["tokens"] = grammar.tokens
    d["symbol2label"] = grammar.symbol2label
    d["_async_keywords"] = grammar.async_keywords


# Generated at 2022-06-21 09:59:35.929890
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    gr = Grammar()
    gr.symbol2number = {'var': 1}
    gr.number2symbol = {1: 'var'}
    gr.states = [[(0, 1)]]
    gr.dfas = {1: (gr.states[0], {0: 1})}
    gr.labels = [(1, 'var'), (1, 'var')]
    gr.keywords = {'var': 1}
    gr.tokens = {1: 2}
    gr.symbol2label = {'var': 1}
    gr.start = 256

    new = gr.copy()
    assert new.symbol2number == gr.symbol2number
    assert new.number2symbol == gr.number2symbol
    assert new.states == gr.states

# Generated at 2022-06-21 09:59:38.202943
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Use Grammar.load to load a grammar file
    filename = os.path.join(os.path.dirname(__file__), "../Python/Grammar/Grammar")
    g = Grammar()
    g.load(filename)
    # Check that the symbol to number mapping is of the expected length
    assert len(g.symbol2number) == 277

# Generated at 2022-06-21 09:59:43.678424
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pygram import python_grammar
    from . import pyparse
    from .pgen2.pgen import driver
    from .pgen2.pgen import tokenize

    gram = Grammar()
    d = driver.Driver(gram, pyparse.python_grammar_nts)
    d.parse_tokens(tokenize.generate_tokens("1 + 1"))
    gram.dump("/tmp/test.gram")
    gram.load("/tmp/test.gram")
    assert gram.start == 256

# Generated at 2022-06-21 09:59:53.353653
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import driver

    g = Grammar()
    g.number2symbol[256] = "<grammar>"
    g.symbol2number["<grammar>"] = 256
    g.start = 256
    driver.save_grammar(g, tempfile.mktemp())

# Generated at 2022-06-21 10:00:04.053803
# Unit test for constructor of class Grammar
def test_Grammar():
    from .pgen2 import driver
    import os
    import tempfile
    from .pytokenize import generate_tokens

    # Generate the grammar file
    with tempfile.NamedTemporaryFile(delete=False) as input:
        grammar = driver.generate_grammar("Grammar/Grammar", input.name)
    try:
        os.unlink(input.name)
    except OSError:
        pass

    # Load the grammar
    g = Grammar()
    g.loads(grammar)

    # Check that the grammar don't contain errors
    assert isinstance(g.start, int)
    assert isinstance(g.states, list)
    assert isinstance(g.dfas, dict)
    assert isinstance(g.symbol2number, dict)

# Generated at 2022-06-21 10:00:05.688518
# Unit test for method report of class Grammar
def test_Grammar_report():
    # Make sure Grammar.report does not raise any exception
    g = Grammar()
    g.report()

# Generated at 2022-06-21 10:00:07.135129
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()

if __name__ == "__main__":
    print("Module not executable")

# Generated at 2022-06-21 10:00:08.363261
# Unit test for method report of class Grammar
def test_Grammar_report():
    # Simple smoke test.
    g = Grammar()
    g.report()

# Generated at 2022-06-21 10:00:13.033411
# Unit test for constructor of class Grammar
def test_Grammar():
    grammar = Grammar()
    assert grammar.symbol2number == {}
    assert grammar.number2symbol == {}
    assert grammar.states == []
    assert grammar.dfas == {}
    assert grammar.labels == [(0, "EMPTY")]
    assert grammar.keywords == {}
    assert grammar.tokens == {}
    assert grammar.start == 256

# Generated at 2022-06-21 10:00:20.621475
# Unit test for method report of class Grammar
def test_Grammar_report():
    grammar = Grammar()
    grammar.report()


if __name__ == "__main__":
    import sys

    if len(sys.argv) == 1:
        from . import pgen2

        pgen2.main(sys.argv)
    else:
        filename = sys.argv[1]
        if filename.endswith(".pickle"):
            g = Grammar()
            g.load(filename)
            g.report()
        else:
            exec(open(filename).read())

# Generated at 2022-06-21 10:00:28.513489
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = dict(foo=1, bar=2)
    g.number2symbol = dict(a=3, b=4)
    g.dfas = dict(first=5, second=6)
    g.keywords = dict(third=7, fourth=8)
    g.tokens = dict(fifth=9, sixth=10)
    g.symbol2label = dict(seventh=11, eighth=12)
    g.labels = [1, 2, 3, 4]
    g.states = ["a", "b", "c", "d"]
    g.start = 10

    c = g.copy()

    assert c.symbol2number == g.symbol2number
    assert c.number2symbol == g.number2symbol
   

# Generated at 2022-06-21 10:00:35.850968
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-21 10:00:44.250809
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import tempfile
    import os
    import os.path
    import sys
    # Store current dir and go to temp dir
    cwd = os.getcwd()
    temp_dir = tempfile.TemporaryDirectory()
    os.chdir(temp_dir.name)

    filename = 'pyt_grammar.pickle'
    grammar = Grammar()
    grammar.dump(filename)
    # Test pickle file was created
    assert os.path.isfile(filename)
    os.remove(filename)

    # Go back to original directory
    os.chdir(cwd)



# Generated at 2022-06-21 10:00:59.355325
# Unit test for constructor of class Grammar
def test_Grammar():
    assert Grammar().symbol2number == {}
    assert Grammar().number2symbol == {}
    assert Grammar().states == []
    assert Grammar().dfas == {}
    assert Grammar().labels == [(0, "EMPTY")]
    assert Grammar().keywords == {}
    assert Grammar().tokens == {}
    assert Grammar().symbol2label == {}
    assert Grammar().start == 256

# Generated at 2022-06-21 10:01:05.618626
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert not g.async_keywords

    g.start = 0
    assert g.start == 0


# Generated at 2022-06-21 10:01:17.041494
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(os.path.join(os.path.dirname(__file__), 'Grammar.pkl'))
    assert grammar.async_keywords is False
    assert grammar.start == 256
    assert grammar.labels[0] == (0, "EMPTY")
    assert grammar.tokens[token.NAME] == 1
    assert grammar.tokens[token.PLUS] == 2
    assert grammar.tokens[token.STAR] == 3
    assert grammar.keywords["and"] == 4
    assert grammar.keywords["class"] == 5
    assert grammar.symbol2label["decorator"] == 6
    assert grammar.symbol2label["file_input"] == 7
    assert grammar.symbol2label["single_input"] == 10

# Generated at 2022-06-21 10:01:27.098540
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    g.symbol2number = {'A': 257, 'B': 258, 'empty': 256}
    g.number2symbol = {256: 'empty', 257: 'A', 258: 'B'}

# Generated at 2022-06-21 10:01:38.634130
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import typing
    from .pgen2 import tokenize
    from .pgen2.driver import Driver
    from . import grammar

    # set a new grammar variable
    grammar_file = os.path.join(
        os.path.dirname(grammar.__file__), "Grammar.txt"
    )
    driver = Driver(grammar_file, "Grammar.pickle")
    driver.generate_grammar()
    # use Grammar class to read the pickle file and test if the instance variables are
    # equal to the new grammar.
    with open(driver.pickle_file, "rb") as f:
        new_g = Grammar()
        new_g.loads(f.read())
        tokenize._generate_grammar_pickle = None
        g = tokenize._generate_gram

# Generated at 2022-06-21 10:01:42.286558
# Unit test for method load of class Grammar
def test_Grammar_load():
    try:
        grammar = Grammar()
        grammar.load(__file__)
        assert False
    except (pickle.UnpicklingError, AttributeError, EOFError, ImportError, IndexError):
        pass

# Generated at 2022-06-21 10:01:52.554680
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    from . import pytree
    from .pgen2.parse import ParseError
    from .pgen2.tokenize import generate_tokens, untokenize

    def parse(string: str, expect: Any) -> None:
        """
        Parse the string, and test whether its grammar matches the
        expected result.  If they don't match, it's a test failure.
        """
        x = Grammar()
        x.loads(serialize(string))
        try:
            tree = pytree.PythonGrammar(x).parse("\n".join(string.splitlines()))
        except ParseError as p:
            raise AssertionError(p)
        tree = untokenize(tree)
        if tree.strip() != expect.strip():
            raise AssertionError("Serialization failed for", string)



# Generated at 2022-06-21 10:02:02.040009
# Unit test for method report of class Grammar
def test_Grammar_report():
    """Test for Coverage"""
    from .conv import convert

    g = Grammar()
    convert(grammar=g, grfile="Grammar.txt")
    f, filename = tempfile.mkstemp()
    g.dump(filename=filename)
    g2 = Grammar()
    g2.load(filename=filename)

    assert g.start == g2.start
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords

# Generated at 2022-06-21 10:02:12.462708
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.copy()
    # This is a compile-time test that Grammar.copy is implemented
    # correctly for mypyc-compiled versions of Python.  The copy()
    # method of the base class mypyc.common.primitives.object_class is
    # hard-coded to return an Any object.  This test ensures that the
    # copy() method of the Grammar class returns the same (subclassed)
    # type that it was called on.
    c = g.copy()
    c2 = c.copy()
    assert isinstance(c, Grammar)
    assert isinstance(c2, Grammar)
    assert type(c) == type(c2)

# Generated at 2022-06-21 10:02:18.170632
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    fname = os.path.join(os.path.dirname(__file__), "Grammar.txt")
    with open(fname, "rb") as f:
        g = Grammar()
        g.loads(f.read())
    # The first test is to see if the file loads.
    assert g.states == [[(1, 1)], [(0, 2)]]
    # This test is to see whether async is treated as a keyword.
    assert g.async_keywords

# Generated at 2022-06-21 10:02:35.432863
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import py._test.assertion
    g = Grammar()
    g.symbol2number = dict(abc=1)

# Generated at 2022-06-21 10:02:43.045725
# Unit test for method copy of class Grammar

# Generated at 2022-06-21 10:02:45.339464
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()


# Generated at 2022-06-21 10:02:50.904749
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = "test_parser_grammar_dump.pickle"
    try:
        g = Grammar()
        g.dump(filename)
        g2 = Grammar()
        g2.load(filename)
    finally:
        if os.path.exists(filename):
            os.unlink(filename)

if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-21 10:02:52.399499
# Unit test for constructor of class Grammar
def test_Grammar():
    grammar = Grammar()
    assert grammar is not None

# Generated at 2022-06-21 10:02:59.372592
# Unit test for method report of class Grammar
def test_Grammar_report():
    gr = Grammar()


# Generated at 2022-06-21 10:03:05.670554
# Unit test for method loads of class Grammar
def test_Grammar_loads():

    def _check(g: Grammar) -> None:
        g.load(str(tmpdir.joinpath(".pyre_temp/grammar")))

    tmpdir = Path(tempfile.gettempdir())
    tmpdir.joinpath(".pyre_temp").mkdir(exist_ok=True)
    g = Grammar()
    g.dump(str(tmpdir.joinpath(".pyre_temp/grammar")))
    _check(g)

# Generated at 2022-06-21 10:03:17.791874
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .parse import ParserGenerator
    from .cst import PythonBaseParser

    gen = ParserGenerator(
        [
            "start",
            "expr",
            "exprlist",
            "testlist_comp",
            "exprlist_comp",
            "testlist_star_expr",
            "test_comp",
            "dictorsetmaker",
            "classdef",
            "arglist",
        ],
        PythonBaseParser,
        rule_args=dict(
            asdl_file="Python/Python.asdl",
            output="Python/Python-ast.txt",
            gendir="Grammar",
        ),
        token_map=PythonBaseParser.tokens,
    )
    gen.init_grammar()
    tmpfile = tempfile.mktemp(dir=".")

# Generated at 2022-06-21 10:03:30.290828
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    grammar1 = Grammar()
    grammar1.symbol2number = {'symbol': 1}
    grammar1.number2symbol = {1: 'symbol'}
    grammar1.dfas = {1: ([[], [], []], {1: 1})}
    grammar1.keywords = {'kw': 2}
    grammar1.tokens = {1: 2}
    grammar1.symbol2label = {'sl': 2}
    grammar1.labels = [(1, '1'), (2, '2')]
    grammar1.states = [[(1, 1), (2, 2)], [(3, 1), (4, 2)], [(3, 1), (4, 2)]]
    grammar1.start = 3
    grammar1.async_keywords = True
    grammar2 = grammar1

# Generated at 2022-06-21 10:03:40.949516
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    gram = Grammar()
    # note that the pickle is pickled with protocol 3

# Generated at 2022-06-21 10:03:50.798912
# Unit test for method report of class Grammar
def test_Grammar_report():
    # No test yet
    assert True

# Generated at 2022-06-21 10:03:57.859797
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-21 10:04:07.213092
# Unit test for method loads of class Grammar

# Generated at 2022-06-21 10:04:19.847567
# Unit test for method report of class Grammar
def test_Grammar_report():
    from io import StringIO
    import unittest
    from unittest.mock import patch

    class TestReport(unittest.TestCase):
        @patch('sys.stdout', new_callable=StringIO)
        def test(self, mock_stdout):
            gram = Grammar()
            gram.number2symbol = {1: 'test'}
            gram.symbol2number = {'test': 1}
            gram.states = [[[(1, 1)]]]
            gram.dfas = {1: ([[(1, 1)]], {})}
            gram.labels = [(1, None)]
            gram.start = 256
            gram.report()

# Generated at 2022-06-21 10:04:29.036703
# Unit test for method loads of class Grammar

# Generated at 2022-06-21 10:04:40.643983
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    def dump(self, filename):
        return
    def load(self, filename):
        return
    def dump_to_string(self):
        return pickle.dumps({"symbol2number": {'whatevs': '1'}})
    Grammar.dump = dump
    Grammar.load = load
    grammar = Grammar()
    grammar.dump_to_string = dump_to_string
    grammar.loads(b'\x80\x03}q\x00(X\x0bymbol2numberq\x01}q\x02X\x08whatevsq\x03X\x01q\x04ss.')
    assert grammar.symbol2number == {'whatevs': '1'},"Method loads in class Grammar does not work as expected"

# Generated at 2022-06-21 10:04:51.056267
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from tokenize import NAME
    from ast import PyCF_ONLY_AST
    from . import parse, pgen
    import unparse
    import io

    p = parse.Parser(Grammar(), PyCF_ONLY_AST)
    parser_pgen = pgen.ParserGenerator(io.TextIOWrapper(io.BytesIO()))
    symbol2number = parser_pgen.symbol2number
    number2symbol = parser_pgen.number2symbol
    dfa_codes = parser_pgen.dfa_codes
    dfas = parser_pgen.dfas
    labels = parser_pgen.labels
    keywords = parser_pgen.keywords
    tokens = parser_pgen.tokens

    source = "foo = 'bar'"
    st = p.parse_string(source)

# Generated at 2022-06-21 10:05:00.815499
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g2 = g.copy()
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.dfas == g2.dfas
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label
    assert g.labels == g2.labels
    assert g.states == g2.states
    assert g.start == g2.start
    assert g.async_keywords == g2.async_keywords


if __name__ == "__main__":
    test_Grammar_copy()

# Generated at 2022-06-21 10:05:12.671199
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import types
    from os.path import join, dirname
    pickle_path = join(dirname(__file__), "Grammar.pkl")

    g = Grammar()
    g.load(pickle_path)
    g2 = g.copy()
    assert g2 is not g
    assert g2.__dict__ is not g.__dict__
    assert g2.symbol2number is not g.symbol2number
    assert g2.number2symbol is not g.number2symbol
    assert g2.states is not g.states
    assert g2.dfas is not g.dfas
    assert g2.labels is not g.labels
    assert g2.keywords is not g.keywords
    assert g2.tokens is not g.tokens
    assert g

# Generated at 2022-06-21 10:05:23.646567
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {'alpha': 1}
    g.number2symbol = {1: 'alpha'}
    g.dfas = {1: [(1, 2)], 2: [(0, 2)]}
    g.keywords = {'break': 1}
    g.tokens = {1: 1}
    g.symbol2label = {'alpha': 1}
    g.labels = [(1, 'alpha'), (1, 'beta')]
    g.states = [(1, 2), (2, 0, 2)]
    g.start = 4
    g.async_keywords = False

    g1 = g.copy()
    # These object copy methods don't copy object references but
    # instead copy the values at those references
    assert g1.symbol2

# Generated at 2022-06-21 10:05:52.928954
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    # The symbol2number attribute of a grammar object is a dictionary.  It maps
    # symbols to numbers.  If we want to copy a grammar, we would also like to
    # copy the dictionary, so that the copy is independent of the original.
    g = Grammar()
    g.symbol2number["abc"] = 3
    h = g.copy()
    assert h.symbol2number["abc"] == 3
    # If the copy does not create a new dictionary, then modifying the
    # dictionary for the copy will also affect the original.
    h.symbol2number["abc"] = 5
    assert g.symbol2number["abc"] == 5
    # The copy of a dictionary is independent of the original.  Modifying
    # the copy will not affect the original.
    h.symbol2number["abc"] = 7
    assert g

# Generated at 2022-06-21 10:06:04.581441
# Unit test for method report of class Grammar
def test_Grammar_report():
    import sys
    from importlib import util
    from io import StringIO
    from unittest.mock import patch

    path = util.find_spec("test.grammar_string").origin
    with open(path, "rb") as f:
        g = pickle.load(f)

    with patch("builtins.print") as mock_print, patch(
        "test.test_grammar.pprint.pprint"
    ) as mock_pprint:
        g.report()
        expected = [
            "s2n",
            "n2s",
            "states",
            "dfas",
            "labels",
            "start 256",
        ]

# Generated at 2022-06-21 10:06:13.007897
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.start = 256
    g.symbol2number = {'a': 257, 'b': 258}
    g.number2symbol = {257: 'a', 258: 'b'}
    g.dfas = {257: ([[1, 2], [2, 3, 4], [3], [4], [5]], {2: 1})}
    g.states = [[(1, 1), (2, 2)], [(3, 1), (4, 3), (5, 4)]]
    g.labels = [(0, 'EMPTY'), (1, 'a'), (2, 'b'), (3, 'c'), (4, 'd'), (5, 'e')]

    tf = tempfile.NamedTemporaryFile(delete=False)
    g.dump(tf.name)

# Generated at 2022-06-21 10:06:24.855229
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import tokenize
    from .pgen2 import tokenize as tokenize2
    from .parse import Parser

    try:
        g2 = tokenize2.generate_grammar()
    except IOError:
        # don't fail if the tokenize2 module is not present
        return
    g = Grammar()
    g._update(g2.__dict__)
    p = Parser(g)

    # parser creation succeeds
    g2 = g.copy()
    try:
        p2 = Parser(g2)
    except Exception as e:
        assert False, "parser creation should succeed, got {}".format(e)

    # class should be the same
    assert g.__class__ is g2.__class__

    # all __dict__ attributes should be equal

# Generated at 2022-06-21 10:06:28.254635
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()

    f = tempfile.NamedTemporaryFile(delete=False)
    try:
        g.dump(f)
    finally:
        os.remove(f.name)

# Generated at 2022-06-21 10:06:31.135346
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    from .test_grammar_pickle import grammar_pickle

    g = Grammar()
    g.loads(grammar_pickle)

# Generated at 2022-06-21 10:06:32.202828
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()

# Generated at 2022-06-21 10:06:41.446912
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    class TestGrammar(Grammar):
        pass
    testgr = TestGrammar()
    testgr.states.append(1)
    testgr.dfas[1] = (1,2)
    testgr.labels.append(3)
    testgr.start = 1
    testgr.symbol2number[1] = 2
    testgr.number2symbol[1] = 2
    testgr.keywords[1] = 2
    testgr.tokens[1] = 2
    testgr.symbol2label[1] = 2
    g = testgr.copy()
    assert id(g) != id(testgr)
    assert g.states == testgr.states
    assert g.dfas == testgr.dfas
    assert g.labels == testgr.labels
   

# Generated at 2022-06-21 10:06:50.248957
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # This test method is for mypyc. For mypyc to pick up this
    # method, the class Grammar() needs to be instantiated.
    # We cannot instantiate the Grammar class directly since
    # the class is abstract, so we need to create a subclass if
    # we want to manually instantiate Grammar().
    class Foo(Grammar):
        pass
    x = Foo()
    x.dump("foo.pkl")
    assert os.path.exists("foo.pkl")
    x.load("foo.pkl")
    assert os.path.exists("foo.pkl")

# Generated at 2022-06-21 10:06:54.102506
# Unit test for method load of class Grammar
def test_Grammar_load():
    class Dummy(Grammar):
        def loads(self, bytes_):
            pass
    d = Dummy()
    for name in ("symbol2number", "number2symbol", "states", "dfas", "labels"):
        assert name not in d.__dict__
    d.load("")
    # The test is not very satisfying. If a test would check that all
    # members of the dict were properly initialized, it would be
    # ensured that the dicts are shallow copies.
    for name in ("symbol2number", "number2symbol", "states", "dfas", "labels"):
        assert name in d.__dict__

# Generated at 2022-06-21 10:07:57.466202
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert not g.symbol2number
    assert not g.number2symbol
    assert not g.states
    assert not g.dfas
    assert len(g.labels) == 1
    assert (0, "EMPTY") in g.labels
    assert not g.keywords
    assert not g.tokens
    assert not g.symbol2label
    assert g.start == 256
    assert not g.async_keywords

# Generated at 2022-06-21 10:08:00.970140
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    import pgen2.pgen

    gram = pgen2.pgen.Grammar()
    gram.loads(b"cn\nps\n-\ns")

if __name__ == "__main__":
    test_Grammar_loads()

# Generated at 2022-06-21 10:08:08.512447
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.symbol2number["foo"] = 1
    g.number2symbol[1] = "foo"
    g.states = [[[(1, 2)], [(2, 3)], [(0, 3)], [(0, 3)]]]
    g.dfas = {1: (g.states[0], {1: 1})}
    g.labels = [
        (0, "EMPTY"),
        (1, None),
        (2, None),
        (0, None),
    ]
    g.keywords = {}
    g.tokens = {}
    g.symbol2label = {}
    g.start = 256
    pkl = pickle.dumps(g, pickle.HIGHEST_PROTOCOL)
    new = Grammar()
   

# Generated at 2022-06-21 10:08:19.484379
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Construct a dummy Grammar
    g = Grammar()
    g.symbol2number = {"one": 1, "two": 2, "three": 3}
    g.symbol2label = {"a" : 1, "b" : 2, "c" : 3}
    g.number2symbol = {"1": "one", "2": "two", "3": "three"}
    g.states = [[(1, 2), (2, 3)], [(3, 4), (4, 5)]]
    g.dfas = {"1": [g.states[0], {2: 1}], "2": [g.states[1], {4: 1}]}
    g.labels = [(1, "one"), (2, "two"), (3, "three")]

# Generated at 2022-06-21 10:08:27.628880
# Unit test for constructor of class Grammar
def test_Grammar():
    """Test for constructor of class Grammar"""
    gr = Grammar()
    gr.symbol2number['test'] = 1
    gr.number2symbol[1] = 'test'
    gr.states = [[]]
    gr.dfas = {0: ([[]],{})}
    gr.labels = [(0,'EMPTY')]
    gr.keywords = {'test':1}
    gr.tokens = {0:1}
    gr.symbol2label = {'test':1}
    gr.start = 0
    gr.async_keywords = True
    new_gr = gr.copy()
    assert new_gr.symbol2number == gr.symbol2number
    assert new_gr.number2symbol == gr.number2symbol

# Generated at 2022-06-21 10:08:34.083669
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert not g.async_keywords

# Generated at 2022-06-21 10:08:43.793765
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Verify that the Grammar.load method can load a file that was
    # dumped using pytest-benchmark and the benchmarked_load fixture.
    import os
    import pytest
    import sys
    import datetime

    os.environ['PYTHONPATH'] = os.path.abspath('..')
    os.environ['PYTHONSTARTUP'] = os.path.abspath('..')
    del sys.modules['astropy.io']
    del sys.modules['astropy.io.fits']
    del sys.modules['astropy.utils']
    del sys.modules['astropy.utils.data']
    del sys.modules['astropy.utils.compat']
    del sys.modules['astropy.utils.compat.contextlib']