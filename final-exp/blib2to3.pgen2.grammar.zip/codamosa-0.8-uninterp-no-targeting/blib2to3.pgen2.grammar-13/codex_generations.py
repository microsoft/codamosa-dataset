

# Generated at 2022-06-21 09:58:42.310701
# Unit test for method report of class Grammar
def test_Grammar_report():
    from . import pgen2

    grammar = Grammar()
    pgen = pgen2.load_grammar(grammar)

    with open("Grammar/__init__.py", "w") as f:
        f.write("from .pgen2 import load_grammar\n")
        f.write("from .conv import graminit\n")
        f.write("from ._pickle import loads\n")
        f.write("from . import parsetok\n")

    grammar = Grammar()
    pgen = pgen2.load_grammar(grammar)
    grammar.report()

if __name__ == "__main__":
    test_Grammar_report()

# Generated at 2022-06-21 09:58:48.146969
# Unit test for method load of class Grammar
def test_Grammar_load():
    with tempfile.NamedTemporaryFile(delete=False) as f:
        pickle.dump({"hello": 42}, f, pickle.HIGHEST_PROTOCOL)
    g = Grammar()
    g.load(f.name)
    assert g.hello == 42
    os.unlink(f.name)

# Generated at 2022-06-21 09:58:59.950961
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    assert g.start != 257
    g.start = 257  # type: ignore
    g2 = g.copy()
    assert g.start == 257
    assert g2.start == 257

    assert g.symbol2number != g2.symbol2number
    assert g.number2symbol != g2.number2symbol
    assert g.dfas != g2.dfas
    assert g.keywords != g2.keywords
    assert g.tokens != g2.tokens
    assert g.labels != g2.labels
    assert g.states != g2.states
    assert g.symbol2label != g2.symbol2label
    assert g.async_keywords == g2.async_keywords

# Generated at 2022-06-21 09:59:02.127872
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g_copy = g.copy()
    assert g is not g_copy

# Generated at 2022-06-21 09:59:06.127304
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g2 = g1.copy()
    g1.symbol2number["testing"] = 12345
    assert g2
    assert g2.symbol2number["testing"] != 12345
    assert g1.symbol2number["testing"] == 12345

# Generated at 2022-06-21 09:59:12.751062
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import pickle
    a = Grammar()
    a.symbol2number = {"foo": 1}
    a.number2symbol = {1: "foo"}
    a.dfas = {1: ([0], {})}
    a.keywords = {1: "foo"}
    a.tokens = {1: "foo"}
    a.symbol2label = {1: "foo"}
    a.states = [[(1, 1)], [(1, 1)]]
    a.labels = [1, 2]
    a.start = 1

    b = a.copy()
    assert b.symbol2number == {"foo": 1}
    assert b.number2symbol == {1: "foo"}
    assert b.dfas == {1: ([0], {})}

# Generated at 2022-06-21 09:59:24.033646
# Unit test for method loads of class Grammar

# Generated at 2022-06-21 09:59:25.793167
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = "tests/input/Grammar.pickle"
    # TODO: Test dump


# Generated at 2022-06-21 09:59:30.719579
# Unit test for constructor of class Grammar
def test_Grammar():
    from . import pgen2

    g = pgen2.generate_grammar()
    g.report()
    g.dump("Grammar.gen.pkl")
    g.load("Grammar.gen.pkl")
    g.report()

# Generated at 2022-06-21 09:59:41.139634
# Unit test for method load of class Grammar
def test_Grammar_load():
    def _test(s, expected_result):
        g = Grammar()
        g.loads(s)
        assert g.labels == expected_result
    # test cases for bad data
    for s in ("", ".", "abc", 123, 1.2, b"abc", object(), (1, 2), [1, 2]):
        try:
            _test(s, "")
            raise RuntimeError("bad input wasn't detected")
        except:
            pass
    # good data

# Generated at 2022-06-21 09:59:50.604928
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    grammar = Grammar()
    sample = pickle.dumps(grammar, pickle.HIGHEST_PROTOCOL)
    grammar.loads(sample)
    sample2 = pickle.dumps(grammar, pickle.HIGHEST_PROTOCOL)
    assert sample == sample2

# Generated at 2022-06-21 10:00:01.128872
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    g.symbol2number = {'A': 260, 'B': 261}
    g.number2symbol = {260: 'A', 261: 'B'}
    g.states = [[[(1, 2), (3, 4)], [(5, 6), (7, 8)]], [[(9, 10), (11, 12)], [(13, 14), (15, 16)]]]
    g.dfas = {260: (0, {1: 1, 3: 1}), 261: (1, {5: 1, 7: 1})}
    g.labels = [(0, "EMPTY"), (1, None), (3, None), (5, None), (7, None), (9, None), (11, None), (13, None), (15, None)]
    g.keywords

# Generated at 2022-06-21 10:00:03.845335
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load('Grammar.txt')
    return grammar

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-21 10:00:09.730634
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    grammar = Grammar()
    copied = grammar.copy()
    assert id(copied) != id(grammar)
    assert id(copied.symbol2number) != id(grammar.symbol2number)
    assert id(copied.dfas) != id(grammar.dfas)
    assert id(copied.keywords) != id(grammar.keywords)
    assert id(copied.tokens) != id(grammar.tokens)
    assert id(copied.labels) != id(grammar.labels)
    assert id(copied.states) != id(grammar.states)

# Generated at 2022-06-21 10:00:13.241140
# Unit test for method load of class Grammar
def test_Grammar_load():

    class A(Grammar):
        pass

    a = A()
    d = {"foo": "bar"}
    a.load(d)
    assert a.foo == "bar"

    a = A()
    a.load(d)
    assert a.foo == "bar"

# Generated at 2022-06-21 10:00:24.138314
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    import unittest
    
    class GrammarLoaderTestCase(unittest.TestCase):
        def setUp(self):
            self.loader = Grammar
            # Grammar.loads is ignored by mypy and TypedDict.
            # So this test case can not run on mypy.
            

# Generated at 2022-06-21 10:00:31.137435
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-21 10:00:39.904946
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number["A"] = 1
    g.number2symbol[2] = "B"
    g.states = [[(0, 1)]]
    g.dfas[3] = ([[(0, 4)], [(0, 4), (2, 4)]], {4: 5})
    g.labels[0] = (0, "EMPTY")
    g.keywords["C"] = 1
    g.tokens[4] = 2
    g.symbol2label["A"] = 3
    test_file = tempfile.NamedTemporaryFile(delete=False)
    g.dump(test_file.name)
    g_new = Grammar()
    g_new.load(test_file.name)

# Generated at 2022-06-21 10:00:46.318296
# Unit test for constructor of class Grammar
def test_Grammar():
    gr = Grammar()
    assert not gr.symbol2number
    assert not gr.number2symbol
    assert not gr.states
    assert not gr.dfas
    assert gr.labels == [(0, 'EMPTY')]
    assert not gr.keywords
    assert not gr.tokens
    assert not gr.symbol2label
    assert gr.start == 256
    assert not gr.async_keywords

# Generated at 2022-06-21 10:00:57.232033
# Unit test for method load of class Grammar

# Generated at 2022-06-21 10:01:07.051903
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.keywords == {}
    assert g.symbol2label == {}
    assert g.symbol2number == {}
    assert g.tokens == {}
    assert g.start == 256
    assert g.keywords == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.states == []
    assert g.dfas == {}
    assert g.number2symbol == {}


# Generated at 2022-06-21 10:01:09.521819
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    class MyGrammar(Grammar):
        pass
    g1 = MyGrammar()
    assert type(g1.copy()) == MyGrammar

# Generated at 2022-06-21 10:01:20.154313
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    g.start = token.NAME
    g.symbol2number = {'NAME': 256}
    g.symbol2label = {'NAME': 258}
    g.number2symbol = {256: 'NAME'}
    g.keywords = {"False": 258, "None": 258, "True": 258}
    g.tokens = {token.NAME: 258}
    g.dfas = {token.NAME: ([[(258, 1), (258, 2)]], {1: 2, 2: 1})}
    g.labels = [(0, "EMPTY"), (258, "NAME")]
    g.states = [[[(258, 1), (258, 2)], [(258, 1)]]]

# Generated at 2022-06-21 10:01:29.193513
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # Test Grammar.loads(bytes)
    # Create a Grammar with a non-default constructor
    # (which is what mypyc generates)
    class MyGrammar(Grammar):
        def __init__(self, a: int) -> None:
            super().__init__()
            self.a = a

    g = MyGrammar(10)

    # Save the Grammar to a pickle
    g_pkl = pickle.dumps(g, pickle.HIGHEST_PROTOCOL)

    # Make a new Grammar object
    g2 = MyGrammar(0)

    # Load the pickle into g2
    g2.loads(g_pkl)

    # Check that the new Grammar has the same attributes
    # as the old one.
    assert g2.__dict

# Generated at 2022-06-21 10:01:33.272692
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    import pickle

    pkl = pickle.dumps({"a": 1, "b": 2})
    g = Grammar()
    g.loads(pkl)
    assert g.a == 1
    assert g.b == 2

# Generated at 2022-06-21 10:01:38.356028
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    class Cls(Grammar):
        ...
    g = Cls()
    s = pickle.dumps({'symbol2number': {'foo': 42}, 'number2symbol': {42: 'foo'}, 'start': 42})
    g.loads(s)
    assert g.number2symbol[42] == 'foo'

# Generated at 2022-06-21 10:01:39.824103
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.start == 256

# Generated at 2022-06-21 10:01:50.467794
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    emptygrammar = Grammar().loads(pickle.dumps({}))
    assert emptygrammar.states == []


# Generated at 2022-06-21 10:01:52.140916
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("grammar.pickle")


test_Grammar_dump()

# Generated at 2022-06-21 10:01:58.523983
# Unit test for method loads of class Grammar

# Generated at 2022-06-21 10:02:08.936214
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    assert g.report() is None

# Generated at 2022-06-21 10:02:17.370444
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g2 = g1.copy()
    assert g1.symbol2number == g2.symbol2number
    assert g1.number2symbol == g2.number2symbol
    assert g1.dfas == g2.dfas
    assert g1.keywords == g2.keywords
    assert g1.tokens == g2.tokens
    assert g1.symbol2label == g2.symbol2label
    assert g1.labels == g2.labels
    assert g1.states == g2.states
    assert g1.start == g2.start
    assert g1.async_keywords == g2.async_keywords

# Generated at 2022-06-21 10:02:20.041741
# Unit test for method report of class Grammar
def test_Grammar_report():
    import sys
    import test.support

    sys.stderr = sys.stdout = test.support.captured_stdout("utf-8")
    g = Grammar()
    g.report()

# Generated at 2022-06-21 10:02:26.173139
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    class E(Grammar):
        def __init__(self):
            super(E, self).__init__()
            self.symbol2number = {'foo': 1}
    e = E()
    e.loads(b'\x80\x03}q\x00X\x03\x00\x00\x00fooq\x01K\x01ub.')
    assert e.symbol2number['foo'] == 1

# Generated at 2022-06-21 10:02:37.383551
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.symbol2number = {"a": 256, "b": 257}
    grammar.number2symbol = {256: "a", 257: "b"}
    grammar.states = [[[(1, 1)], [(2, 0)]]]
    grammar.dfas = {256: (0, {}), 257: (1, {1: 1})}
    grammar.labels = [(1, None), (2, None)]
    grammar.start = 256
    grammar.keywords = {"c": 3, "d": 4}
    grammar.tokens = {5: 5, 6: 6}
    grammar.symbol2label = {257: 2}
    grammar.async_keywords = False

    filename = "test.pkl"

# Generated at 2022-06-21 10:02:39.561104
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("dump_file")
    assert os.path.isfile('dump_file')
    os.remove('dump_file')


# Generated at 2022-06-21 10:02:40.713861
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    # g.dump(BytesIO())


# Generated at 2022-06-21 10:02:49.789146
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io
    import sys

    saved_stdout = sys.stdout
    try:
        out = io.StringIO()
        sys.stdout = out
        g = Grammar()
        g.report()
        output = out.getvalue().strip()
    finally:
        sys.stdout = saved_stdout

    assert output == """s2n
{}
n2s
{}
states
[]
dfas
{}
labels
[(0, 'EMPTY')]
start 256""".strip()

# Generated at 2022-06-21 10:02:57.681256
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    basic_tokens = {
        token.INDENT: "INDENT",
        token.DEDENT: "DEDENT",
        token.NEWLINE: "NEWLINE",
        token.NAME: "NAME",
        token.NUMBER: "NUMBER",
        token.STRING: "STRING",
        token.ENDMARKER: "ENDMARKER",
    }

    def check_Grammar(g: Grammar) -> None:
        for i in range(256):
            if i in g.tokens and i not in basic_tokens:
                assert g.tokens[i] == (i, "OP")
            if i not in g.tokens and i in basic_tokens:
                assert (i, basic_tokens[i]) in g

# Generated at 2022-06-21 10:03:09.404681
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    from types import MethodType
    from . import pgen
    g = pgen.Generator()
    g.build()
    g2 = g.grammar.copy()
    assert g2.number2symbol == g.grammar.number2symbol
    assert g2.symbol2number == g.grammar.symbol2number
    assert g2.dfas == g.grammar.dfas
    assert g2.keywords == g.grammar.keywords
    assert g2.tokens == g.grammar.tokens
    assert g2.symbol2label == g.grammar.symbol2label
    assert g2.labels == g.grammar.labels
    assert g2.states == g.grammar.states
    assert g2.start == g.grammar.start
    assert g

# Generated at 2022-06-21 10:03:18.363205
# Unit test for constructor of class Grammar
def test_Grammar():
    grammar = Grammar()
    assert isinstance(grammar, Grammar)

# Generated at 2022-06-21 10:03:20.476838
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("Grammar.pickle")
    assert opmap == grammar.tokens


# Generated at 2022-06-21 10:03:33.293402
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # These are the attributes of the Grammar class, as defined in the
    # implementation above.
    assert set(Grammar.__dict__) == {
        "__module__",
        "__init__",
        "dump",
        "load",
        "loads",
        "report",
    }

    # Nothing works until the grammar has been initialized.
    g = Grammar()
    with pytest.raises(RuntimeError):
        g.dump("foobar")
    with pytest.raises(RuntimeError):
        g.loads(b"foobar")
    with pytest.raises(RuntimeError):
        g.report()

    # Test methods dump and report by dumping the current grammar to
    # a temporary file and reading it back.

    # The grammar will eventually be initialized in parse.py, but it
    #

# Generated at 2022-06-21 10:03:33.948352
# Unit test for method report of class Grammar
def test_Grammar_report():
    gr = Grammar()

# Generated at 2022-06-21 10:03:44.924802
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import pytest

    pytest.importorskip("astroid")

    from astroid import builder

    builder._module_cache.clear()
    builder._builtin_lookup.clear()

    from .pgen2 import driver

    grammar = driver.load_grammar("testdata/Grammar.txt", "Grammar.txt")
    new_grammar = grammar.copy()

    assert not (new_grammar is grammar)
    for dict_attr in ("symbol2number", "number2symbol", "dfas", "keywords", "tokens"):
        assert not (getattr(new_grammar, dict_attr) is getattr(grammar, dict_attr))

    assert new_grammar.labels is not grammar.labels
    assert new_grammar.states is not grammar.states

# Generated at 2022-06-21 10:03:48.367827
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import tempfile

    with tempfile.NamedTemporaryFile() as f:
        g = Grammar()
        g.dump(f.name)
        g.loads(f.read())


if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-21 10:03:58.458406
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test that load() can handle a path with a non-ascii character
    # in its name. This is important to catch on Windows, as Python
    # might crash when trying to access one of these paths.
    with tempfile.TemporaryDirectory() as dir:
        filename = os.path.join(dir, "tes{0}t".format(chr(0xFFFD)))
        assert filename.isascii() is False
        with open(filename, "wb") as f:
            pickle.dump({"x": 1}, f, pickle.HIGHEST_PROTOCOL)
        g = Grammar()
        g.load(filename)

# Generated at 2022-06-21 10:04:04.551897
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Test that Grammar.load works"""
    try:
        import StringIO
    except ImportError:
        from io import StringIO
    g = Grammar()
    sio = StringIO.StringIO()
    g.start = 42
    pickle.dump(g, sio, pickle.HIGHEST_PROTOCOL)
    sio.seek(0)
    g2 = Grammar()
    g2.load(sio)
    assert g2.start == 42

# Generated at 2022-06-21 10:04:16.177751
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    try:
        from test import support
    except ImportError:
        from test import test_support as support

    class TestGrammarDump(unittest.TestCase):

        def check_Grammar_dump(self) -> None:
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2, 'c': 3}
            g.number2symbol = {1: 'a', 2: 'b', 3: 'c'}
            g.states = [[[(1, 0)]]]
            g.dfas = {1: ([[(0, 0)]], {0: 1}), 2: ([[(0, 0)]], {0: 1})}
            g.labels = [(2, 'b')]
            g

# Generated at 2022-06-21 10:04:27.074063
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import pickle

    g1 = pickle.loads(b"\x80\x03cpyger._pgen\nGrammar\nq\x00)\x81q\x01}q\x02(X\x06\x00\x00\x00statesq\x03]q\x04X\x04\x00\x00\x00dfasq\x05}q\x06(K\x00uX\x06\x00\x00\x00labelsq\x07]q\x08(K\x00Nq\teX\x05\x00\x00\x00startq\nK\xa8ub.")  # noqa: E501
    g2 = g1.copy()
    assert g1.states == g2.states

# Generated at 2022-06-21 10:04:48.537913
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {'aa': 1, 'bb': 2}
    g.number2symbol = {1: 'aa', 2: 'bb'}
    dfas = {}
    dfas[1] = ([[], []], {0: 1})
    dfas[2] = ([[], []], {0: 1})
    g.dfas = dfas
    g.keywords = {1: 'a', 2: 'b'}
    g.tokens = {1: 'a', 2: 'b'}
    g.symbol2label = {'a': 1, 'b': 2}
    g.labels = [('a', 'b')]
    g.states = [1, 2]
    g.start = 3
    g2 = g.copy()

# Generated at 2022-06-21 10:04:58.733275
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io
    import sys
    from pprint import pprint

    g = Grammar()
    g.symbol2number = {'and': 257, 'or': 259, 'not': 258}
    g.number2symbol = {257: 'and', 258: 'not', 259: 'or'}
    g.states = [[[(3, 1)], [(3, 2)]], [[(0, 2)]]]
    g.dfas = {257: (0, {1: 1}), 258: (1, {1: 1}), 259: (0, {1: 1})}
    g.labels = [(0, 'EMPTY'), (3, None), (4, None), (3, 'and')]
    g.start = 256
    # Redirect sys.stdout to capture output of method report

# Generated at 2022-06-21 10:05:10.107014
# Unit test for method load of class Grammar
def test_Grammar_load():
    class GrammarSub(Grammar):
        def __init__(self) -> None:
            super().__init__()
            self.symbol2number["key"] = "value"
            self.number2symbol[3] = "three"
            self.states = [
                [],
                [[(1, 2), (3, 4)]],
                [[(5, 6), (7, 8)]],
                [[(9, 10)]],
                [[(11, 12)]],
            ]
            self.dfas = {1: (self.states[2], {2: 1, 3: 1}), 2: (self.states[1], {4: 1})}

# Generated at 2022-06-21 10:05:22.009598
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    GRAMMAR_1 = Grammar()
    GRAMMAR_1.symbol2number = {"a": 100, "b": 101}
    GRAMMAR_1.number2symbol = {100: "a"}
    GRAMMAR_1.dfas = {1: DFA, 2: DFA}
    GRAMMAR_1.keywords = {"c": 102}
    GRAMMAR_1.tokens = {103: 104}
    GRAMMAR_1.symbol2label = {"aa": 105}
    GRAMMAR_1.labels = [106]
    GRAMMAR_1.states = [DFA, DFA]
    GRAMMAR_1.start = 107
    GRAMMAR_1.async_keywords = False

    GRAMMAR_2 = GRAMMAR_1.copy()



# Generated at 2022-06-21 10:05:25.815578
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    import pickle

    g = Grammar()
    g.loads(pickle.dumps({"symbol2number": {"None": 10}}))

    assert g.symbol2number == {"None": 10}

# Generated at 2022-06-21 10:05:36.285997
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2 import driver
    from . import token

    g = driver.load_grammar(os.path.join(os.path.dirname(__file__), "Grammar.txt"))
    g.start = g.symbol2number["file_input"]
    g.dump(os.path.join(os.path.dirname(__file__), "Grammar.pickle"))
    del g

    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pickle"))
    # Just check a few attributes
    assert g.start == g.symbol2number["file_input"]
    assert g.labels[131][0] == token.COMMENT



# Generated at 2022-06-21 10:05:44.599294
# Unit test for method report of class Grammar
def test_Grammar_report():
    grammar = Grammar()
    grammar.symbol2number = {'foo':257}
    grammar.number2symbol = {257:'foo'}
    grammar.states = [[[(0,0)]]]
    grammar.dfas = {257: ([[(0,0)]], {0:0})}
    grammar.labels = [(0, 'EMPTY'), (1, None)]
    grammar.keywords = {'bar':1}
    grammar.tokens = {257:1}
    grammar.symbol2label = {'foo':1}
    grammar.start = 257
    grammar.async_keywords = False
    grammar.report()



# Generated at 2022-06-21 10:05:48.375347
# Unit test for constructor of class Grammar
def test_Grammar():
    """Test the constructor of class Grammar.

    This function is not called by the unit test in test_parser, but
    only when this module is run as a script.
    """
    gr = Grammar()
    # Constructor must create the instance variables symbol2number,
    # number2symbol, states, dfas, labels, keywords, tokens, and
    # symbol2label.
    assert len(gr.symbol2number) == 0
    assert len(gr.number2symbol) == 0
    assert len(gr.states) == 0
    assert len(gr.dfas) == 0
    assert len(gr.labels) == 1
    assert len(gr.labels[0]) == 2
    assert len(gr.keywords) == 0
    assert len(gr.tokens) == 0

# Generated at 2022-06-21 10:05:55.913447
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    gram = Grammar()
    gram.states = [
        [[(0, 1), (1, 2), (2, 3), (0, 3)], [(1, 2), (2, 3), (0, 3)], [(0, 3)]]
    ]
    gram.dfas = {257: ([[0, 1, 2, 2]], {0: 1, 1: 1})}
    gram.async_keywords = True
    gram2 = gram.copy()
    assert gram2.states == [
        [[(0, 1), (1, 2), (2, 3), (0, 3)], [(1, 2), (2, 3), (0, 3)], [(0, 3)]]
    ]

# Generated at 2022-06-21 10:05:59.611723
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()  # does not raise an exception

# Generated at 2022-06-21 10:06:09.540952
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()

# Generated at 2022-06-21 10:06:20.150951
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    p = Grammar()
    q = p.copy()
    assert type(p) is type(q)
    assert p is not q
    assert p.__dict__ is not q.__dict__

    # The following test fails because mypyc generates Grama objects
    # that don't have __dict__ attributes.
    # assert p.__dict__.keys() == q.__dict__.keys()
    assert p.start == q.start
    assert p.async_keywords == q.async_keywords
    for key in p.__dict__.keys():
        if key in {"start", "async_keywords"}:
            continue
        assert p.__dict__[key] == q.__dict__[key]

# Generated at 2022-06-21 10:06:28.513634
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {'x': 100}
    g.number2symbol = {100: 'x'}
    g.dfas = {'a': 'b'}
    g.keywords = {'c': 100}
    g.tokens = {200: 100}
    g.symbol2label = {'e': 100}
    g.labels = [('f', 100)]
    g.states = [('g', 100)]
    g.start = 300

    g2 = g.copy()

    assert g.symbol2number is not g2.symbol2number
    assert g.number2symbol is not g2.number2symbol
    assert g.dfas is not g2.dfas
    assert g.keywords is not g2.keywords


# Generated at 2022-06-21 10:06:39.779226
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Create a simple grammar and use dump method to store it in a pickle file
    g = Grammar()
    g.symbol2number = { "symbol_one": 256 }
    g.number2symbol = { 256: "symbol_one" }
    g.states = [ [((0, None), 1)] ]
    g.dfas = { 256: (g.states[0], {"token_one": 1}) }
    g.labels = [ (0, None), (1, "token_one") ]
    g.tokens = { 1: 1 }
    g.keywords = { "token_one" : 1 }
    g.symbol2label = { "symbol_one" : 256 }
    g.start = 256

    # Call the dump method

# Generated at 2022-06-21 10:06:51.815668
# Unit test for constructor of class Grammar
def test_Grammar():
    grammar = Grammar()
    if not isinstance(grammar, Grammar):
        raise TypeError("test_Grammar: Grammar()")
    if grammar.symbol2number != {}:
        raise AssertionError("test_Grammar: Grammar().symbol2number")
    if grammar.number2symbol != {}:
        raise AssertionError("test_Grammar: Grammar().number2symbol")
    if grammar.states != []:
        raise AssertionError("test_Grammar: Grammar().states")
    if grammar.dfas != {}:
        raise AssertionError("test_Grammar: Grammar().dfas")
    if grammar.labels != [(0, "EMPTY")]:
        raise AssertionError("test_Grammar: Grammar().labels")
   

# Generated at 2022-06-21 10:07:02.800359
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import conv, dfa, pgen2

    test_grammar_path = os.path.join(os.path.split(__file__)[0], "_test_grammar.pkl")
    g = Grammar()
    g.load(test_grammar_path)
    assert g.start == 256
    assert g.number2symbol[256] == "file_input"
    conv.convert_dfas(dfa.parse_grammar("_test_grammar.txt", g), g)
    g2 = pgen2.Driver("_test_grammar.txt", g).grammar

    assert g == g2

# Generated at 2022-06-21 10:07:10.770950
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    grammar = Grammar()

    grammar.symbol2number = {'a': 1}
    grammar.number2symbol = {1: 'a'}
    grammar.dfas = {1: [[(1,2)], {}]}
    grammar.keywords = {'a': 1}
    grammar.tokens = {1: 1}
    grammar.symbol2label = {'a': 1}
    grammar.labels = [(1, 'a')]
    grammar.states = [[(1,2)]]
    grammar.start = 256

    new = grammar.copy()

    assert new.symbol2number == grammar.symbol2number
    assert new.number2symbol == grammar.number2symbol
    assert new.dfas == grammar.dfas
    assert new.keywords == grammar.keywords
    assert new

# Generated at 2022-06-21 10:07:21.631702
# Unit test for method loads of class Grammar

# Generated at 2022-06-21 10:07:22.309950
# Unit test for method report of class Grammar
def test_Grammar_report():
    pass

# Generated at 2022-06-21 10:07:32.474969
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    def _test(async_keywords):
        g = Grammar()
        g.async_keywords = async_keywords
        g.labels = (1, 2, 3)
        g.start = 8
        g.states = (1, 2, 3)
        g.dfas = {1: 2, 3: 4}
        g.keywords = {1: 2, 3: 4}
        g.tokens = {1: 2, 3: 4}
        g.symbol2label = {1: 2, 3: 4}
        g.number2symbol = {1: 2, 3: 4}
        g.symbol2number = {1: 2, 3: 4}
        h = g.copy()
        assert g == h
        assert g.async_keywords == async_keywords


# Generated at 2022-06-21 10:07:46.499735
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.keywords = {"async": 276}
    g.dump("/tmp/test")
    h = Grammar()
    h.load("/tmp/test")
    assert h.keywords == {"async": 276}

# Generated at 2022-06-21 10:07:53.315317
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import builtins
    # pickle supports several backends, and this lets the test run
    # with the pure Python implementation even on Python 3
    if isinstance(pickle.dump, builtins.builtin_function_or_method):
        pytest.skip("pickle.dump is builtin method")
    g = Grammar()
    g.symbol2number = {"a": 1, "b": 2}
    g.number2symbol = {1: "a", 2: "b"}
    g.states = [[], [], [[(0, 0)]], [[(0, 0), (1, 3)], [(1, 3)], []]]
    g.dfas = {1: ([[(0, 0), (1, 3)], [(1, 3)], []], {" ": 1}), 2: ([[]], {})}

# Generated at 2022-06-21 10:07:54.685021
# Unit test for method report of class Grammar
def test_Grammar_report():
    assert hasattr(Grammar,"report"), "Class Grammar should have method report"

# Generated at 2022-06-21 10:08:00.747691
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    gr = Grammar()
    gr.symbol2number = {'Hello': 42, 'World': 19}
    new_gr = gr.copy()
    assert gr is not new_gr
    assert gr.start == new_gr.start
    assert gr.symbol2number == new_gr.symbol2number
    assert gr.symbol2number is not new_gr.symbol2number
    assert gr.labels == new_gr.labels
    assert gr.labels is not new_gr.labels

# Generated at 2022-06-21 10:08:08.370997
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import sys
    import lib2to3.pgen2.convert
    import lib2to3.pgen2.parse

    gparser = lib2to3.pgen2.parse.Parser(lib2to3.pgen2.convert.Converter("Grammar.pickle").grammar)
    g = gparser.parse_grammar(sys.stdin)

    tparser = lib2to3.pgen2.parse.Parser(g)
    t = tparser.parse_grammar("4")
    assert t.number2symbol[t.symbol2number["number"]] == "number"
    assert t.number2symbol[t.symbol2number["funcdef"]] == "funcdef"

# Generated at 2022-06-21 10:08:13.095571
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g2 = g1.copy()
    assert g1 is not g2
    assert g1.__dict__ == g2.__dict__
    g1.symbol2number['a']=10
    assert 'a' not in g2.symbol2number

# Generated at 2022-06-21 10:08:23.048559
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import sys
    import unittest

    # Create a test grammar
    class TestGrammar(Grammar):
        def __init__(self):
            super(TestGrammar, self).__init__()
            self.symbol2number = {
                "a": 257,
                "b": 258,
                "c": 259,
                "d": 260,
                "e": 261,
                "f": 262,
                "g": 263,
                "h": 264,
                "i": 265,
                "j": 266,
            }

# Generated at 2022-06-21 10:08:32.402733
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    t = tempfile.TemporaryFile()