

# Generated at 2022-06-21 09:58:55.130027
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    from .pgen2 import driver

    g1 = driver.load_grammar("Grammar.txt")
    g2 = g1.copy()
    assert g1.labels == g2.labels
    assert g1.states == g2.states
    assert g1.dfas == g2.dfas
    assert g1.symbol2label == g2.symbol2label
    assert g1.symbol2number == g2.symbol2number
    assert g1.number2symbol == g2.number2symbol
    assert g1.keywords == g2.keywords
    assert g1.tokens == g2.tokens
    assert g1.start == g2.start

# Generated at 2022-06-21 09:59:06.887757
# Unit test for method report of class Grammar
def test_Grammar_report():
    class Test_Grammar(Grammar):
        def __init__(self):
            super().__init__()
            self.symbol2number = {'dummy': 123}
            self.number2symbol = {'123': 'dummy'}
            self.states = ['state']
            self.dfas = {'dfa': 'dfa_state'}
            self.labels = ['labels']
            self.keywords = {'keyword': 'keyword_labels'}
            self.tokens = {'token': 'token_labels'}
            self.start = 'start'

    tg = Test_Grammar()
    try:
        tg.report()
    except SystemExit:
        pass


test_Grammar_report()

# Generated at 2022-06-21 09:59:08.340311
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    try:
        g.report()
    except TypeError:
        pass

# Generated at 2022-06-21 09:59:15.065632
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import conv, pgen2

    fname = "./3.6/Grammar.txt"
    _g = Grammar()
    _g.load(fname)
    g = conv.convert(pgen2.parse(fname), _g.start)

# Generated at 2022-06-21 09:59:21.855432
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords == False


# Generated at 2022-06-21 09:59:30.540484
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [
        [[(1, 1), (1, 2)], [(1, 3)]],
        [[(1, 3)]],
    ]
    g.dfas = {1: [[[2, 3]]], 2: [[[1, 2]]]}
    g.labels = [(1, None), (2, None), (3, None)]
    g.start = 1
    g.report()

# Generated at 2022-06-21 09:59:36.071355
# Unit test for constructor of class Grammar
def test_Grammar():
    assert Grammar.__doc__ is not None


if __name__ == "__main__":
    import sys

    if len(sys.argv) == 2:
        filename = sys.argv[1]
    else:
        filename = "Grammar.pickle"
    g = Grammar()
    g.load(filename)
    g.report()

# Generated at 2022-06-21 09:59:39.083852
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # type: () -> None
    """Test Grammar.loads"""
    grammar = Grammar()
    grammar.loads(b'\x80\x03cbuiltins\ncollections\nOrderedDict\nq\x00)\x81q\x01}'
                 b'(X\x03\x00\x00\x00keyq\x02X\x05\x00\x00\x00valueq\x03a')
    assert grammar.symbol2number == {b"key": 2, b"value": 3}

# Generated at 2022-06-21 09:59:46.024740
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    import math
    import pickle
    import random
    import tempfile


# Generated at 2022-06-21 09:59:51.746749
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-21 10:00:06.061101
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g1.symbol2number = {'A': 1, 'B': 2}
    g1.number2symbol = {1: 'A', 2: 'B'}
    g1.dfas = {1: ([1, 2, 3], {1: 0}), 2: ([], {2: 0})}
    g1.keywords = {'a': 1, 'b': 2}
    g1.tokens = {1: 1, 2: 2}
    g1.labels = [('TURNON', None), ('TURNOFF', None)]
    g1.states = [[(1, 2)], [(2, 3)], []]
    g1.start = 256
    g1.async_keywords = False

    g2 = g1.copy()

   

# Generated at 2022-06-21 10:00:10.226688
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g1 = g.copy()
    assert g.keywords == g1.keywords
    assert g.number2symbol == g1.number2symbol
    assert g.tokens == g1.tokens
    assert g.symbol2label == g1.symbol2label
    assert g.labels[0] == g1.labels[0]
    assert g.states[0] == g1.states[0]
    assert g.start == g1.start

# Generated at 2022-06-21 10:00:17.010106
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-21 10:00:24.319473
# Unit test for constructor of class Grammar
def test_Grammar():
    global Grammar
    import pgen2.grammar

    Grammar = pgen2.grammar.Grammar

    parse1 = Grammar()
    parse1.dump("parse1.pkl")
    parse2 = Grammar()
    parse2.load("parse1.pkl")
    del parse1.symbol2number["EMPTY"]
    del parse2.symbol2number["EMPTY"]
    assert parse1.symbol2number == parse2.symbol2number


# Cleanup symbols imported by side effect
del os, pickle, tempfile, Text

# Generated at 2022-06-21 10:00:27.883533
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    class Mock_File(object):
        def __init__(self):
            self.name = "Test"
            self.count = 0
        def write(self, bytes):
            self.count += len(bytes)
    mock_file = Mock_File()
    g = Grammar()
    g.dump(mock_file)
    assert mock_file.count > 0

# Generated at 2022-06-21 10:00:37.478300
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = os.path.join("Parser", "Grammar.py")
    grammar = Grammar()
    grammar.load(filename)
    assert grammar.start == 1084

# Generated at 2022-06-21 10:00:48.273740
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    from .pgen2 import driver

    gr = driver.load_grammar("Grammar.txt", convert=False)
    pickle_file_path = "Grammar.pickle"
    gr.dump(pickle_file_path)

    # check pickle file exist
    assert os.path.exists(pickle_file_path) == True

    # check pickle file is not empty
    assert os.stat(pickle_file_path).st_size != 0

    # check pickle file is not a text file
    ifile = open(pickle_file_path, "r")
    with open(pickle_file_path, "rb") as ifile:
        try:
            pickle.load(ifile)
            assert False
        except UnicodeDecodeError:
            assert True



# Generated at 2022-06-21 10:00:59.484466
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    assert not g.number2symbol
    assert not g.symbol2number
    assert not g.dfas
    assert not g.keywords
    assert not g.tokens
    assert not g.symbol2label
    assert [] == g.labels
    assert [] == g.states
    assert 256 == g.start
    assert not g.async_keywords
    g.load("Grammar.txt")
    assert g.number2symbol
    assert g.symbol2number
    assert g.dfas
    assert g.keywords
    assert g.tokens
    assert g.symbol2label
    assert g.labels
    assert g.states
    assert 256 == g.start
    assert not g.async_keywords



# Generated at 2022-06-21 10:01:05.770220
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    tempdir = tempfile.mkdtemp()
    filename = os.path.join(tempdir, "test.pkl")
    state_table = Grammar()
    state_table.dump(filename)
    with open(filename, "rb") as f:
        pickled = pickle.load(f)
    assert pickled["states"] == state_table.states
    assert pickled["tokens"] == state_table.tokens


if __name__ == "__main__":
    import unittest

    unittest.main()

# Generated at 2022-06-21 10:01:17.218920
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    g = Grammar()
    g.symbol2number = {"foo": 1, "bar": 2, "baz": 3}
    g.number2symbol = {1: "foo", 2: "bar", 3: "baz"}
    g.states = [[["a",1],["b",2]], [["baz",3]]]
    g.dfas = {1: (1, 1), 2: (2, 2)}
    g.labels = [["G", "g"], ["F", "f"], ["E", "e"]]
    g.keywords = {"g": 1, "f": 2, "e": 3}
    g.tokens = {1: 4, 2: 5, 3: 6}

# Generated at 2022-06-21 10:01:27.459063
# Unit test for method load of class Grammar
def test_Grammar_load():
    d = Grammar()
    d.loads(b"\x80\x03}q\x00(X\x05\x00\x00\x00asdfq\x01K\x01s.".replace(b'\n', b''))
    assert d.asdf == 1

# Generated at 2022-06-21 10:01:31.678977
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    class G(Grammar):
        def __init__(*args): pass
    g = G()
    with open("Grammar.pickle", "rb") as f:
        pkl = f.read()
    g.loads(pkl)
    g.report()

# Generated at 2022-06-21 10:01:33.774677
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()

# Generated at 2022-06-21 10:01:36.531886
# Unit test for method report of class Grammar
def test_Grammar_report():
    # This method generates output for the user, so it makes no
    # assertions about what it writes.
    x = Grammar()
    x.report()


# Generated at 2022-06-21 10:01:47.555571
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = dict(foo=1)
    g.number2symbol = dict(bar=1)
    g.dfas = dict(baz=1)
    g.keywords = dict(qux=1)
    g.tokens = dict(quux=1)
    g.symbol2label = dict(quuz=1)
    g.labels = list(range(10))
    g.states = list(range(10))
    g.start = 10
    g.async_keywords = True

    n = g.copy()
    assert n.symbol2number == g.symbol2number
    assert n.number2symbol == g.number2symbol
    assert n.dfas == g.dfas
    assert n.keywords == g

# Generated at 2022-06-21 10:01:49.273982
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    assert g.report() == None


# Generated at 2022-06-21 10:01:57.285244
# Unit test for method load of class Grammar
def test_Grammar_load():

    def new_grammar() -> Grammar:
        g = Grammar()
        g.symbol2number = {'single_input': 256, 'file_input': 257, 'eval_input': 258}
        g.number2symbol = {256: 'single_input', 257: 'file_input', 258: 'eval_input'}

# Generated at 2022-06-21 10:02:09.707502
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {0: 1}
    g.number2symbol = {0: 1}
    g.dfas = {0: 1}
    g.keywords = {0: 1}
    g.tokens = {0: 1}
    g.symbol2label = {0: 1}
    g.start = 2
    g.labels = [1]
    g.states = [1]
    h = g.copy()
    assert h.symbol2number == g.symbol2number
    assert h.number2symbol == g.number2symbol
    assert h.dfas == g.dfas
    assert h.keywords == g.keywords
    assert h.tokens == g.tokens

# Generated at 2022-06-21 10:02:18.598505
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io

    # Capture output of method to string
    f = io.StringIO()
    old_stdout = sys.stdout
    sys.stdout = f

    # Call method
    Grammar().report()

    # Restore output to previous value
    sys.stdout = old_stdout
    output = f.getvalue()

    # Verify output is of the expected form
    assert output.startswith(
        's2n\n{}\nn2s\n{}\nstates\n[]\ndfas\n{}\nlabels\n[(0, \'EMPTY\')]\nstart 256\n'
    )


if __name__ == "__main__":
    import sys
    import unittest

    from . import pgen2


# Generated at 2022-06-21 10:02:26.010806
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number["test"] = 1
    h = g.copy()
    assert g.symbol2number is not h.symbol2number


# Create temporary files needed for test case in test_parser
testdir = tempfile.mkdtemp()
token_data = os.path.join(testdir, "token-data")
grammar_data = os.path.join(testdir, "grammar-data")
symbol_data = os.path.join(testdir, "symbol-data")

# Generated at 2022-06-21 10:02:36.982702
# Unit test for method load of class Grammar
def test_Grammar_load():
    pass


# Generated at 2022-06-21 10:02:39.639186
# Unit test for method load of class Grammar
def test_Grammar_load():
    assert Grammar().load('not-a-valid-file') is None


if __name__ == "__main__":
    # Run the unit tests
    g = Grammar()
    test_Grammar_load()

# Generated at 2022-06-21 10:02:40.462326
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()

# Generated at 2022-06-21 10:02:52.459622
# Unit test for method report of class Grammar
def test_Grammar_report():
    from unittest import TestCase
    from io import StringIO
    import sys
    import contextlib
    
    @contextlib.contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err
    
    class TestGrammar(TestCase):
        def test_report(self):
            g = Grammar()
            g.symbol2number["x"] = 1
            g.symbol2number["y"] = 2
            g.symbol

# Generated at 2022-06-21 10:03:02.709642
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    test_grammar1 = Grammar()
    test_grammar1.symbol2number = {"a": 1, "b": 2}
    test_grammar1.number2symbol = {1: "a", 2: "b"}
    test_grammar1.dfas = {1: ({}, {}), 2: ({}, {})}
    test_grammar1.keywords = {"a": 1, "b": 1}
    test_grammar1.tokens = {1: 1, 2: 2}
    test_grammar1.symbol2label = {"a": 1, "b": 2}
    test_grammar1.labels = [(0, "EMPTY"), (1, "a"), (2, "b")]

# Generated at 2022-06-21 10:03:10.865127
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert len(g.symbol2number) == 0
    assert len(g.number2symbol) == 0
    assert len(g.states) == 0
    assert len(g.dfas) == 0
    assert len(g.labels) == 1
    assert len(g.keywords) == 0
    assert len(g.tokens) == 0
    assert len(g.symbol2label) == 0
    assert g.start == 256

if __name__ == "__main__":
    test_Grammar()

# Generated at 2022-06-21 10:03:21.018239
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    class _Grammar(Grammar):
        def loads(self, _: bytes) -> None:
            """Load the grammar tables from a pickle bytes object."""

    grammar = _Grammar()

# Generated at 2022-06-21 10:03:33.461639
# Unit test for constructor of class Grammar
def test_Grammar():
    grammar = Grammar()
    assert grammar
    assert hasattr(grammar, "symbol2number")
    grammar.number2symbol["foo"] = "bar"
    assert "foo" in grammar.number2symbol
    assert grammar.number2symbol["foo"] == "bar"
    grammar.symbol2number["bar"] = "foo"
    assert "bar" in grammar.symbol2number
    assert grammar.symbol2number["bar"] == "foo"
    grammar.states.append("baz")
    assert "baz" in grammar.states
    assert grammar.states[0] == "baz"
    grammar.dfas["buz"] = "fuz"
    assert "buz" in grammar.dfas
    assert grammar.dfas["buz"] == "fuz"

# Generated at 2022-06-21 10:03:40.443101
# Unit test for method load of class Grammar
def test_Grammar_load():
    from tokenize import generate_tokens

    grammar = Grammar()
    grammar.load("../Parser/Grammar.pkl")

    # Test method _read_table of class Grammar
    def read_table(table: bytes) -> List[Tuple[int, int]]:
        # Build a DFA from a table
        i = 0
        dfa = []
        for j in range(256):
            c = table[i]
            i = i + 1
            if c == 0xFF:
                target = 0
            elif c == 0xFE:
                target = table[i]
                i = i + 1
            else:
                target = c
            dfa.append([(j, target)])
        return dfa

    # Test method _read_dfas of class Grammar

# Generated at 2022-06-21 10:03:43.000792
# Unit test for method load of class Grammar
def test_Grammar_load():
    # If we get to Summer 2015 without adding new grammar tables, just delete this
    # and the test code below.
    assert_load()


# Generated at 2022-06-21 10:04:08.305906
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2

    filename = os.path.join(
        os.path.dirname(os.path.realpath(__file__)), "Grammar.pickle"
    )
    gr = Grammar()
    gr.load(filename)

    # The pickle file was generated by the following code:
    #
    #    gr = pgen2.driver.load_grammar("Grammar.txt")
    #    gr.dump("Grammar.pickle")
    #
    # The following assertions all succeed on Python 3.3
    #
    # https://bitbucket.org/ned/coveragepy/issue/113/self-symbol2number-is-empty

# Generated at 2022-06-21 10:04:20.697282
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # Check if the Grammar initialization still works with Python 3.8.
    # We only need Python 3 to check this as Python 2 doesn't support
    # from __future__ import annotations.
    from typing import TYPE_CHECKING
    if TYPE_CHECKING:
        from . import pgen2
        g = pgen2.generate_grammar("Grammar.test_Grammar_loads", [])
    else:
        g = Grammar()
    g.loads(g.dump(""))


if __name__ == "__main__":
    import sys

    # When this module is run as a script, it dumps the grammar tables
    # as a pickle to standard output.  This requires that the
    # Python-grammar file has been created.
    g = Grammar()
    exec("from pgen2 import grammar as g")

# Generated at 2022-06-21 10:04:23.317338
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.a = "a"
    g.b = "b"
    g.c = "c"

    gcopy = g.copy()

    assert gcopy.a == "a"
    assert gcopy.b == "b"
    assert gcopy.c == "c"

    assert gcopy.__dict__ is not g.__dict__

# Generated at 2022-06-21 10:04:24.224091
# Unit test for method report of class Grammar
def test_Grammar_report():
    grammar = Grammar()
    grammar.report()

# Generated at 2022-06-21 10:04:31.367888
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    gr = Grammar()
    gr.loads(b'\x80\x03}q\x00(X\x16\x00\x00\x00symbol2numberq\x01}q\x02X\x05\x00\x00\x00asyncq\x03K\x01uX\x02\x00\x00\x00ifq\x04K\x04uX\x03\x00\x00\x00intq\x05K\x06uX\x06\x00\x00\x00numberq\x06K\x07uX\x11\x00\x00\x00nonlocal_stmtq\x07K\x05uX\t\x00\x00\x00not_testq\x08K\x0fuu.')

# Generated at 2022-06-21 10:04:43.633216
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import conv, pgen
    from .parse import Parser

    g = Grammar()
    g.start = 256
    g.labels = [(0, "EMPTY")]


# Generated at 2022-06-21 10:04:52.416068
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    gram = Grammar()
    gram.symbol2number = {"toto": 2}
    gram.number2symbol = {2: "toto"}
    gram.dfas = {2: [2, "toto"]}
    gram.keywords = {"toto": 2}
    gram.tokens = {2: "toto"}
    gram.symbol2label = {"toto": 2}
    gram.labels = ["toto"]
    gram.states = [["toto"]]
    gram.start = 2
    gram_copy = gram.copy()
    assert gram_copy.symbol2number == {"toto": 2}
    assert gram_copy.number2symbol == {2: "toto"}
    assert gram_copy.dfas == {2: [2, "toto"]}

# Generated at 2022-06-21 10:05:01.491768
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    print("start symbol:", g.start)
    d = {
        "a": 1,
        "b": 2,
        "c": "test string",
        "d": [1, 2, 3],
        "e": [1, 2, 4, 4],
    }
    fd, fn = tempfile.mkstemp()
    os.close(fd)

# Generated at 2022-06-21 10:05:08.033607
# Unit test for constructor of class Grammar
def test_Grammar():
    grammar = Grammar()
    assert grammar.symbol2number == {}
    assert grammar.number2symbol == {}
    assert grammar.states == []
    assert grammar.dfas == {}
    assert grammar.labels == [(0, "EMPTY")]
    assert grammar.keywords == {}
    assert grammar.tokens == {}
    assert grammar.symbol2label == {}
    assert grammar.start == 256
    assert not grammar.async_keywords

# Generated at 2022-06-21 10:05:16.431692
# Unit test for constructor of class Grammar
def test_Grammar():
    """ Constructor test of class Grammar """
    grammar = Grammar()
    assert grammar.symbol2number == {}
    assert grammar.number2symbol == {}
    assert grammar.states == []
    assert grammar.dfas == {}
    assert grammar.labels == [(0, "EMPTY")]
    assert grammar.keywords == {}
    assert grammar.tokens == {}
    assert grammar.symbol2label == {}
    assert grammar.start == 256
    assert grammar.async_keywords == False

# Generated at 2022-06-21 10:06:08.325464
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    # Test Python 2.7
    if sys.version_info.major == 2:
        exec(
            """
        class MyGrammar_2(Grammar):
            def __init__(self):
                super(MyGrammar_2, self).__init__()
            def __repr__(self):
                return "MyGrammar_2"
    """
        )  # type: Union[None, Type[Grammar]]
        MyGrammar = MyGrammar_2
    # Test Python 3.7+
    else:
        exec(
            """
        class MyGrammar_3(Grammar):
            def __init__(self):
                super().__init__()
            def __repr__(self):
                return "MyGrammar_3"
    """
        )

# Generated at 2022-06-21 10:06:09.716699
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    g.loads(pickle.dumps({"keywords": {"foo": 1}}))
    assert g.keywords == {"foo": 1}

# Generated at 2022-06-21 10:06:14.416348
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    print("Testing method dump of class Grammar")
    import tempfile
    from . import conv

    data = "".join(open("Grammar.txt", "rb").readlines())
    g = conv.parse(data)
    f = tempfile.NamedTemporaryFile()
    g.dump(f.name)
    g2 = Grammar()
    g2.load(f.name)


# Generated at 2022-06-21 10:06:25.930930
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-21 10:06:38.289268
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    grammar = Grammar()
    new_grammar = grammar.copy()
    try:
        assert new_grammar.symbol2number == grammar.symbol2number
        assert new_grammar.number2symbol == grammar.number2symbol
        assert new_grammar.dfas == grammar.dfas
        assert new_grammar.keywords == grammar.keywords
        assert new_grammar.tokens == grammar.tokens
        assert new_grammar.symbol2label == grammar.symbol2label
        assert new_grammar.labels == grammar.labels
        assert new_grammar.states == grammar.states
        assert new_grammar.start == grammar.start
        assert new_grammar.async_keywords == grammar.async_keywords
    except AssertionError:
       raise Ass

# Generated at 2022-06-21 10:06:50.762285
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    grammar = Grammar()
    grammar.symbol2number = {"A": 1, "B": 2}
    grammar.number2symbol = {1: "A", 2: "B"}
    grammar.dfas = {1: ([[(1, 1), (2, 1)]], {}), 2: ([[(3, 1)]], {})}
    grammar.keywords = {"A": 1, "B": 2}
    grammar.tokens = {1: 3, 2: 4}
    grammar.symbol2label = {"A": 5, "B": 6}
    grammar.labels = [(1, "A"), (2, "B")]
    grammar.states = [[(1, 1), (2, 1)], [(1, 2)]]
    grammar.start = 1
    grammar.async_keywords = False

   

# Generated at 2022-06-21 10:06:58.154890
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    fd, fn = tempfile.mkstemp()
    try:
        with os.fdopen(fd, "wb") as f:
            g.dump(f)
        g2 = Grammar()
        g2.load(fn)
    finally:
        os.remove(fn)
    assert g.__dict__ == g2.__dict__

# Generated at 2022-06-21 10:07:08.246782
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    import io

    m = Grammar()

# Generated at 2022-06-21 10:07:19.251862
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    class MyGrammar(Grammar):
        def __init__(self):
            Grammar.__init__(self)
            self.symbol2number = {"A":1,"B":2,"C":3}
            self.number2symbol = {1:"A",2:"B",3:"C"}
            self.states = [[[(0,0)],[]]]
            self.dfas = {1:([],{}), 2:([[(0,0)],[]])}
            self.labels = [(1,"A"),(2,"B"),(3,"C")]
            self.keywords = {"A":1,"B":2}
            self.tokens = {1:1,2:2}
            self.symbol2label = {"A":1,"B":2}
            self.start = 256

# Generated at 2022-06-21 10:07:20.983559
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar: Grammar = Grammar()
    grammar.dump(tempfile.NamedTemporaryFile().name)

# Generated at 2022-06-21 10:08:21.962773
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # Create a class which represents a dummy grammar
    class DummyGrammar(Grammar):
        def __init__(self) -> None:
            super().__init__()
            self.symbol2number = {"method_name": 100, "other_method_name": 200}
            self.number2symbol = {100: "method_name", 200: "other_method_name"}
            self.states = [ [ (1, 2), (2, 3), (3, 4) ] ]
            self.dfas = { 100: ([], {}) }
            self.labels = [ (), (), (), () ]
            self.keywords = {"keyword_name": 1, "other_keyword_name": 2}

# Generated at 2022-06-21 10:08:26.041645
# Unit test for method load of class Grammar
def test_Grammar_load():
    from types import CodeType
    from tokenize import tokenize
    from io import BytesIO
    from . import parse

    code = CodeType(0, 0, 0, 0, bytes(), (), (), (), "", "", 1, b"")
    parser = parse.Parser()
    parser.setup(code)
    parser.grammar = Grammar()

# Generated at 2022-06-21 10:08:35.682558
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    g.start = 256

# Generated at 2022-06-21 10:08:42.555310
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert not g.async_keywords


if __name__ == "__main__":
    test_Grammar()