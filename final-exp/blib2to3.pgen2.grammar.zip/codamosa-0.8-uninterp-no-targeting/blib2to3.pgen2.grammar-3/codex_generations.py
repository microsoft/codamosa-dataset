

# Generated at 2022-06-21 09:58:51.856006
# Unit test for constructor of class Grammar
def test_Grammar():
    gr = Grammar()
    assert gr.symbol2number == {}
    assert gr.number2symbol == {}
    assert gr.states == []
    assert gr.dfas == {}
    assert gr.labels == [(0, "EMPTY")]
    assert gr.keywords == {}
    assert gr.tokens == {}
    assert gr.symbol2label == {}
    assert gr.start == 256
    assert gr.async_keywords == False


# Generated at 2022-06-21 09:59:04.440690
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    from .conv import convert
    from .pgen2 import driver
    from . import token

    import io

    # Create the grammar object
    g = convert(driver.parse_grammar(driver.grammar))
    # Dump grammar tables to bytes object
    pkl = pickle.dumps(g, pickle.HIGHEST_PROTOCOL)

    # Create new Grammar object
    newG = Grammar()
    # Load grammar tables from bytes object
    newG.loads(pkl)

    # Test all Grammar attributes
    assert newG.symbol2number == g.symbol2number
    assert newG.number2symbol == g.number2symbol
    assert newG.states == g.states
    assert newG.dfas == g.dfas
    assert newG.labels == g.labels

# Generated at 2022-06-21 09:59:11.287192
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import sys
    from .pgen2 import driver

    g = driver.load_grammar(sys.argv[1])
    gr = g.copy()
    assert g.symbol2number == gr.symbol2number
    assert g.number2symbol == gr.number2symbol
    assert g.dfas == gr.dfas
    assert g.keywords == gr.keywords
    assert g.tokens == gr.tokens
    assert g.symbol2label == gr.symbol2label
    assert g.labels == gr.labels
    assert g.states == gr.states
    assert g.start == gr.start
    assert g.async_keywords == gr.async_keywords

# Generated at 2022-06-21 09:59:13.593317
# Unit test for method loads of class Grammar
def test_Grammar_loads():

    assert Grammar().loads(b"cos\nsystem\n(S'echo hello world'\ntR.") is None

# Generated at 2022-06-21 09:59:19.857726
# Unit test for constructor of class Grammar
def test_Grammar():
    grammar = Grammar()
    assert grammar
    assert grammar.symbol2number is not None
    assert grammar.number2symbol is not None
    assert grammar.states is not None
    assert grammar.dfas is not None
    assert grammar.labels is not None
    assert grammar.keywords is not None
    assert grammar.tokens is not None
    assert grammar.symbol2label is not None

# Generated at 2022-06-21 09:59:24.063728
# Unit test for constructor of class Grammar
def test_Grammar():
    try:
        from parser import grammar
        from parser import pgen
    except ImportError:
        return
    g = Grammar()
    g.start = 255
    g.symbol2number["foo"] = 42
    g.number2symbol[42] = "foo"
    g.keywords["if"] = 1
    g.tokens[1] = 1
    dfa = []
    g.states.append(dfa)
    dfa.append([(1, 2), (0, 1)])
    dfa.append([(1, 1)])
    g.dfas[42] = (dfa, {})
    g.labels.append((1, None))
    g.symbol2label["foo"] = 2
    g.async_keywords = True
    g.start = pgen

# Generated at 2022-06-21 09:59:31.212468
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-21 09:59:41.558448
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    class MockGrammar(Grammar):
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            Grammar.__init__(self)

    mg = MockGrammar()
    assert mg.start == 256

    # Construct a pickle of the mock grammar
    test_dict = {
        "symbol2number": mg.symbol2number,
        "number2symbol": mg.number2symbol,
        "states": mg.states,
        "dfas": mg.dfas,
        "labels": mg.labels,
        "keywords": mg.keywords,
        "tokens": mg.tokens,
        "symbol2label": mg.symbol2label,
        "start": mg.start,
    }

# Generated at 2022-06-21 09:59:53.093481
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    from . import pgen2
    import pytest

    def check(g_old: Grammar, g_new: Grammar) -> None:
        for attr in ("symbol2number", "number2symbol", "dfas", "keywords", "tokens"):
            assert getattr(g_old, attr) == getattr(g_new, attr)

        for attr in ("labels", "states", "symbol2label"):
            assert getattr(g_old, attr) is not getattr(g_new, attr)

        assert g_old.start == g_new.start
        assert g_old.async_keywords == g_new.async_keywords

    g = pgen2.load_grammar(pytest.grammar, "Python", 3.7)
   

# Generated at 2022-06-21 09:59:59.673184
# Unit test for constructor of class Grammar
def test_Grammar():
    gr = Grammar()

    assert not gr.symbol2number
    assert not gr.number2symbol
    assert not gr.states
    assert not gr.dfas
    assert gr.labels == [(0, "EMPTY")]
    assert not gr.keywords
    assert not gr.tokens
    assert not gr.symbol2label
    assert gr.start == 256
    assert not gr.async_keywords

# Generated at 2022-06-21 10:00:10.392426
# Unit test for constructor of class Grammar
def test_Grammar():
    final_states = [(0,1), (0,2), (0,3), (0,4), (0,5)]
    states = [[(1,1), (2,2), (3,3), (4,4), (5,5)], final_states]
    dfas = {256: (states, {0: 1})}
    labels = [("EMPTY", None), ("A", None), ("B", None), ("C", None), ("D", None),
              ("E", None)]
    symbol2label = {'EMPTY': 0, 'B': 2, 'C': 3, 'D': 4, 'E': 5, 'A': 1}
    symbol2number = {'A': 256, 'B': 257}
    number2symbol = {256: 'A', 257: 'B'}
    start = 256

# Generated at 2022-06-21 10:00:21.280933
# Unit test for method report of class Grammar
def test_Grammar_report():
    def check(expected: str) -> None:
        assert temp.getvalue() == expected

    from io import StringIO
    from pprint import pformat

    gr = Grammar()

    temp = StringIO()
    gr.report()
    check(
        "s2n\n{}\nn2s\n{}\nstates\n[]\ndfas\n{}\nlabels\n[(0, 'EMPTY')]\nstart 256\n"
    )

    gr.symbol2number["abc"] = 123
    gr.number2symbol[123] = "abc"
    gr.symbol2number[2] = "def"  # noqa: E231
    gr.start = 42
    gr.keywords = {"abc": 1}
    gr.tokens = {2: 3}
    gr

# Generated at 2022-06-21 10:00:29.164024
# Unit test for constructor of class Grammar
def test_Grammar():
    # Check the order of the docstring in class Grammar
    def record_order(line: str, order: List[str]) -> None:
        word = line.split(' ')[0]
        if word and word[0].isalpha():
            order.append(word)

    lines = Grammar.__init__.__doc__.splitlines()
    order = []
    list(map(record_order, lines, [order] * len(lines)))

    # Find the order of the instance variables in the class by using
    # the inspect module.
    import inspect

    instance_vars = [var for var in sorted(inspect.getmembers(Grammar))
                     if var[0] in order]
    assert order == [var[0] for var in instance_vars]
test_Grammar()

# Generated at 2022-06-21 10:00:38.094552
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # test that Grammar.loads() successfully loads the grammar data
    # when the data is in bytes-like format, just as Grammar.load()
    # does when the data is in a file
    grammar = Grammar()
    grammar.number2symbol = {256: "root", 257: "file_input"}
    grammar.start = 256

# Generated at 2022-06-21 10:00:48.832402
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {1: 1}
    g.number2symbol = {0: 0}
    g.states = [0]
    g.labels = [1]
    g.start = 2

    g2 = g.copy()

    assert g.symbol2number != g2.symbol2number
    assert g.number2symbol != g2.number2symbol
    assert g.states != g2.states
    assert g.labels != g2.labels
    assert g.start == g2.start

    g2.symbol2number[0] = 'a'
    g2.number2symbol[1] = 'b'
    g2.states.append(1)
    g2.labels.append(2)
    g2.start

# Generated at 2022-06-21 10:01:00.055324
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    assert g.__class__ == Grammar
    g.symbol2number = {'a':1, 'b':2}
    g.number2symbol = {2: 'b'}
    g.states = [[(1, 2)], [(1, 2)]]
    g.dfas = {256: ([[(1, 2)]], {1: 1})}
    g.labels = [(1, 'b'), (2, 'a')]
    g.keywords = {'a': 1, 'b': 2}
    g.tokens = {1: 1, 2: 2}
    g.symbol2label = {'a': 1, 'b': 2}
    g.start = 256
    g.async_keywords = True

    g1 = g.copy()



# Generated at 2022-06-21 10:01:05.903044
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    with open('tests/data/Grammar.pickle', 'rb') as f:
        data = f.read()
    grammar = Grammar()
    grammar.loads(data)
    for attr in ('symbol2number', 'number2symbol', 'states',
                 'dfas', 'labels', 'start', 'keywords',
                 'tokens', 'symbol2label', 'async_keywords'):
        assert hasattr(grammar, attr)


# Generated at 2022-06-21 10:01:08.429521
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump('/tmp/grammar.pickle')
    grammar.load('/tmp/grammar.pickle')

# Generated at 2022-06-21 10:01:19.943089
# Unit test for method report of class Grammar
def test_Grammar_report():
    # Create a test Grammar instance
    grammar = Grammar()
    grammar.symbol2number = {'a': 1, 'b': 2, 'c': 3}
    grammar.number2symbol = {1: 'a', 2: 'b', 3: 'c'}
    grammar.states = [
        [],
        [
            [0, 1],
            [1, 2],
            [1, 1],
        ],
        [],
    ]
    grammar.dfas = {
        0: ([], {}),
        1: ([
            [0, 1],
            [1, 2],
            [1, 1],
        ], {0: 1, 1: 1}),
        2: ([], {}),
        3: ([], {})
    }

# Generated at 2022-06-21 10:01:29.090157
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .conv import convert
    import pickle, io
    from .pgen2 import tokenize

    with open('/tmp/Python.grammar', 'w') as f, open('/tmp/Python.tokens', 'w') as g:
        convert("Grammar.txt", f, g)

    with open('/tmp/Python.tokens', 'r') as f:
        t = tokenize(f.readline, f.readline)
        t = list(t)

    gram = Grammar()
    gram.load("/tmp/Python.grammar")
    out = io.BytesIO()
    gram.dump(out)
    out.seek(0, 0)
    gram2 = Grammar()
    gram2.load(out)


# Generated at 2022-06-21 10:01:46.838606
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    def check_Grammar(g: Grammar):
        gc = g.copy()
        assert gc.symbol2number == g.symbol2number
        assert gc.number2symbol == g.number2symbol
        assert gc.dfas == g.dfas
        assert gc.keywords == g.keywords
        assert gc.tokens == g.tokens
        assert gc.symbol2label == g.symbol2label
        assert gc.labels == g.labels
        assert gc.states == g.states
        assert gc.start == g.start
        assert gc.async_keywords == g.async_keywords

    grammar = Grammar()
    check_Grammar(grammar)
    grammar.start = 1
    grammar.symbol

# Generated at 2022-06-21 10:01:48.857454
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    tmp = tempfile.NamedTemporaryFile()
    g = Grammar()
    g.loads(tmp.read())

# Generated at 2022-06-21 10:01:57.074650
# Unit test for method report of class Grammar
def test_Grammar_report():
    import unittest.mock as mock

    g = Grammar()
    g.symbol2number = {'A': 1}
    g.number2symbol = {2: 'B'}
    g.states = [[1, 2], [3, 4]]
    g.dfas = {5: ([6, 7], {8: 8})}
    g.labels = ['label1', 'label2']
    g.start = 9
    with mock.patch('sys.stdout') as stdout:
        g.report()

# Generated at 2022-06-21 10:02:06.671613
# Unit test for constructor of class Grammar
def test_Grammar():
    """Test the constructor of Grammar."""
    x = Grammar()
    assert type(x.symbol2number) == dict
    assert type(x.number2symbol) == dict
    assert type(x.states) == list
    assert type(x.dfas) == dict
    assert type(x.labels) == list
    assert type(x.keywords) == dict
    assert type(x.tokens) == dict
    assert type(x.start) == int
    assert type(x.async_keywords) == bool


# Generated at 2022-06-21 10:02:16.814868
# Unit test for method loads of class Grammar

# Generated at 2022-06-21 10:02:22.096641
# Unit test for method load of class Grammar
def test_Grammar_load():
    class Foo:
        pass
    foo = Foo()
    foo.x = 42
    foo.bar = "hello"
    foo.baz = [1, 2, 3]
    data = pickle.dumps(foo.__dict__)
    g = Grammar()
    g.loads(data)
    assert g.x == 42
    assert g.bar == "hello"
    assert g.baz == [1, 2, 3]

# Generated at 2022-06-21 10:02:34.000387
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    with tempfile.TemporaryDirectory() as tmpdirname:
        filename = os.path.join(tmpdirname, "py3grammar.pickle")
        grammar.dump(filename)
        d: dict
        with open(filename, "rb") as f:
            d = pickle.load(f)
    # Assert instance variables are as expected
    assert d == {
        "symbol2number": {},
        "number2symbol": {},
        "states": [],
        "dfas": {},
        "labels": [(0, "EMPTY")],
        "keywords": {},
        "tokens": {},
        "symbol2label": {},
        "start": 256,
        "async_keywords": False,
    }

# Generated at 2022-06-21 10:02:41.261877
# Unit test for method load of class Grammar
def test_Grammar_load():
    from pprint import pprint
    
    _abspath = os.path.abspath(__file__)
    g = Grammar()
    g.load(os.path.join(os.path.dirname(_abspath),"..","..","Grammar.txt"))
    pprint (g.states)
    pprint (g.labels)
    pprint (g.dfas)
    pprint (g.symbol2number)
    pprint (g.number2symbol)
    print (g.start)
    print (g.async_keywords)

if __name__ == '__main__':
    test_Grammar_load()

# Generated at 2022-06-21 10:02:45.744933
# Unit test for method load of class Grammar
def test_Grammar_load():
    assert Grammar().load(None) is None

if __name__ == "__main__":
    # Run the unit tests
    test_Grammar_load()

# Generated at 2022-06-21 10:02:55.177167
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    gr = Grammar()

# Generated at 2022-06-21 10:03:17.974064
# Unit test for method loads of class Grammar

# Generated at 2022-06-21 10:03:30.564868
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Verify the load of Grammar.
    f = "test_Grammar_load.pkl"

    # Create a grammar instance.
    g = Grammar()
    g.symbol2number = {"expr": 256, "expr_or_star": 257}
    g.number2symbol = {256: "expr", 257: "expr_or_star"}
    g.dfas = {
        256: ([[(None, 257)], []], {}),
        257: ([[(None, 257)], [(256, 257), (0, 257)]], {257: 257}),
    }
    g.states = [[[(None, 257)], [(256, 257), (0, 257)]]]
    g.labels = [(0, "EMPTY"), (None, None), (257, None)]

# Generated at 2022-06-21 10:03:32.651311
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    assert hasattr(g, "report") == True  # should pass
    g.report()  # should pass

# Generated at 2022-06-21 10:03:43.745243
# Unit test for method loads of class Grammar

# Generated at 2022-06-21 10:03:48.367027
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    # We use tempfile to get a unique name to avoid problems when run
    # in parallel
    with tempfile.NamedTemporaryFile(dir=".", delete=False) as f:
        g.dump(f.name)
    os.remove(f.name)


del opmap_raw

# Generated at 2022-06-21 10:03:52.116143
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")
    g.report()


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-21 10:04:03.228452
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-21 10:04:14.794434
# Unit test for method load of class Grammar
def test_Grammar_load():
    # test that loads() works correctly
    gram = Grammar()
    f = tempfile.TemporaryFile()

    # test that the grammar can be pickled
    try:
        pickle.dump(gram, f, pickle.HIGHEST_PROTOCOL)
    except pickle.PicklingError:
        # cannot be pickled
        pass
    else:
        f.seek(0)
        gram2 = Grammar()
        gram2.loads(f.read())

    # test that the grammar can be written to a file
    f = tempfile.NamedTemporaryFile()
    gram.dump(f.name)
    gram2 = Grammar()
    gram2.load(f.name)

    # test that the grammar can be read from a file
    f = tempfile.NamedTemporaryFile()
    gram

# Generated at 2022-06-21 10:04:19.770008
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {'foo': 0, 'bar': 1, 'baz': 2}
    g.number2symbol = {0: 'foo', 1: 'bar', 2: 'baz'}
    g.dfas = {1: ([0], {0: 1, 1: 1}), 4: ([0], {0: 1, 4: 1})}
    g.keywords = {'x': 0, 'y': 1}
    g.tokens = {2: 3, 3: 4}
    g.symbol2label = {'x': 0, 'y': 1}
    g.labels = [(0, 'foo'), (1, 'bar')]

# Generated at 2022-06-21 10:04:21.709779
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    assert g1.copy() is not g1



# Generated at 2022-06-21 10:04:47.724177
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords == False


if __name__ == "__main__":
    test_Grammar()
    print("Grammar class unit test done")

# Generated at 2022-06-21 10:04:53.749345
# Unit test for method load of class Grammar
def test_Grammar_load():
    from pgen2 import pgen

    grammar = pgen.load_grammar(token._Encoding)
    assert grammar
    assert len(grammar.symbol2number) > 0
    assert len(grammar.number2symbol) > 0
    assert len(grammar.states) > 0
    assert len(grammar.dfas) > 0
    assert len(grammar.labels) > 0

# Generated at 2022-06-21 10:04:55.105176
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("./foo.pkl")

# Generated at 2022-06-21 10:05:02.881660
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g1.symbol2number["A"] = 1
    g1.number2symbol[1] = "A"
    g1.symbol2number["b"] = 2
    g1.number2symbol[2] = "b"
    g1.dfas = {1: ([], {}), 2: ([], {})}
    g1.keywords["A"] = 1
    g1.tokens[1] = 2
    g1.symbol2label["A"] = 4
    g1.labels = [(1, "A"), (2, "b"), (2, "B"), (3, "c"), (4, "D")]
    g1.states = [([(1, 1)], [(2, 2)])]
    g1.start = 1

    g

# Generated at 2022-06-21 10:05:15.008277
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    import sys
    import unittest
    from . import python_grammar, symtable

    class MockSymtable(symtable.SymbolTable):
        def __init__(self, filename: str) -> None:
            super().__init__(filename)
            self.symtabs = {}  # type: Dict[str, symtable.SymbolTable]

        def get_symbol(self, name: str) -> symtable.Symbol:
            if name not in self.symtabs:
                self.symtabs[name] = MockSymtable(name)
            return self.symtabs[name]

        def get_name(self) -> str:
            return "MockSymTable"


# Generated at 2022-06-21 10:05:24.792496
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    def check(
        grammar: Grammar,
        symbol2number: Dict[str, int],
        number2symbol: Dict[int, str],
        states: List[DFA],
        dfas: Dict[int, DFAS],
        labels: List[Label],
        keywords: Dict[str, int],
        tokens: Dict[int, int],
        symbol2label: Dict[str, int],
        start: int,
    ):
        assert grammar.symbol2number == symbol2number
        assert grammar.number2symbol == number2symbol
        assert grammar.states == states
        assert grammar.dfas == dfas
        assert grammar.labels == labels
        assert grammar.keywords == keywords
        assert grammar.tokens == tokens
        assert grammar.symbol2label == symbol2label


# Generated at 2022-06-21 10:05:35.684301
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import ast

    class GrammarDumpTC(unittest.TestCase):
        def setUp(self):
            self.ast_grammar = ast.parse("x = 1")
            self.ast_Grammar = Grammar()
            self.filename_str = "ast_grammar.pickle"

        def tearDown(self):
            if os.path.isfile(self.filename_str):
                os.remove(self.filename_str)

        def test_Grammar_dump_pickle(self):
            self.ast_Grammar.dump(self.filename_str)
            self.assertTrue(os.path.isfile(self.filename_str))

    unittest.main(exit=False, verbosity=2)

# Generated at 2022-06-21 10:05:45.552241
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    import pickle

    class V3Grammar(Grammar):
        def _update(self, attrs: Dict[str, Any]) -> None:
            for k, v in attrs.items():
                setattr(self, k, v)

    def test(d: dict) -> None:
        g = V3Grammar()
        g.loads(pickle.dumps(d, pickle.HIGHEST_PROTOCOL))
        assert g.symbol2number == {"key": 1}
        assert g.number2symbol == {1: "key"}
        assert g.states == [[[(0, 1), (-1, 1)]]]
        assert g.dfas == {1: ([[(0, 1), (-1, 1)]], {1: 1})}

# Generated at 2022-06-21 10:05:46.466052
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    global opmap
    Grammar().loads(opmap)

# Generated at 2022-06-21 10:05:51.883201
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()

    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords == False


# Generated at 2022-06-21 10:06:17.041253
# Unit test for method load of class Grammar
def test_Grammar_load():
    import os
    import warnings
    import pickle
    from pickle import _Pickler
    grammar = Grammar()
    pickle_tmp = pickle.dumps(grammar)
    grammar_dump = Grammar()
    grammar_load = Grammar()
    grammar_dump.loads(pickle_tmp)
    grammar_load.load(grammar_dump)
    assert grammar_load == grammar_dump


# Generated at 2022-06-21 10:06:23.713632
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-21 10:06:25.262478
# Unit test for constructor of class Grammar
def test_Grammar():
    gr = Grammar()
    assert gr.labels[0] == (0, "EMPTY")

# Generated at 2022-06-21 10:06:29.351045
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    from io import BytesIO

    class A:
        def __init__(self):
            self.thing = "thing"

    g = Grammar()
    g.load(BytesIO(pickle.dumps(A())))

# Generated at 2022-06-21 10:06:30.983268
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    assert g.report()

# Generated at 2022-06-21 10:06:40.800384
# Unit test for method report of class Grammar
def test_Grammar_report():

    grammar = Grammar()

    def check_str(grammar, attr, expected):
        '''
        Helper function to test class Grammar's attributes
        '''
        obj = getattr(grammar, attr)
        g = grammar.__class__.__dict__.get(attr)
        if g and (g.__class__ is not property):
            obj = obj.copy()
        assert expected == str(obj)

    grammar.symbol2number = {'a': 0}
    grammar.number2symbol = {0: 'a'}
    grammar.states = [[(0, [0], 0.001)]]
    grammar.dfas = {0: ([(0, [0], 0.001)], {0: 0})}

# Generated at 2022-06-21 10:06:41.643032
# Unit test for constructor of class Grammar
def test_Grammar():
    gr = Grammar()

# Generated at 2022-06-21 10:06:52.755722
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    grammar1 = Grammar()
    grammar1.symbol2number = {'A': 10}
    grammar1.number2symbol = {10: 'A'}
    grammar1.dfas = {1: (((1, 1), (0, 1)), {1: 2})}
    grammar1.keywords = {'A': 1}
    grammar1.tokens = {1: 1}
    grammar1.symbol2label = {'A': 1}
    grammar1.labels = [(1, 'A'), (0, 'EMPTY')]
    grammar1.states = [[((1, 1), (0, 1))]]
    grammar1.start = 256
    grammar1.async_keywords = False
    grammar2 = grammar1.copy()
    assert grammar1.symbol2number == grammar2.symbol

# Generated at 2022-06-21 10:06:55.749526
# Unit test for constructor of class Grammar
def test_Grammar():
    gr = Grammar()
    print(gr)

if __name__ == "__main__":
    test_Grammar()

# Generated at 2022-06-21 10:07:07.413126
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {"lhs": 10}
    g.number2symbol = {10: "lhs"}
    g.keywords = {"and": 257}

# Generated at 2022-06-21 10:07:48.208463
# Unit test for method report of class Grammar
def test_Grammar_report():
    class TestGrammar(Grammar):
        def __init__(self):
            Grammar.__init__(self)
            self.symbol2number = {'stmt': 256, 'small_stmt': 257}
            self.number2symbol = {256: 'stmt', 257: 'small_stmt'}
            self.states = [[[(258, 1)], [(258, 2)], [], [(0, 2)]]]
            self.dfas = {256: (self.states[0], {258: 1, 0: 1}), 257: (self.states[0], {258: 1, 0: 1})}
            self.labels = [(0, 'EMPTY'), (258, None)]
            self.keywords = {}
            self.tokens = {}
            self.symbol2label

# Generated at 2022-06-21 10:07:58.590570
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os, sys
    from . import pgen2

    if sys.executable.endswith("pypy3"):
        pytest.skip("pypy3 doesn't support pegen")

    path = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        *([".."] * 3 + ["Lib", "grammar.txt"])
    ))
    parser = pgen2.driver.load_grammar(path)
    fd, path = tempfile.mkstemp()
    os.close(fd)

    try:
        parser.dump(path)
        parser.loads(open(path, "rb").read())
    finally:
        os.unlink(path)

# Generated at 2022-06-21 10:08:01.941834
# Unit test for method report of class Grammar
def test_Grammar_report():
    from pgen2 import driver
    import sys
    file_name = sys.argv[1]
    g = driver.load_grammar(file_name)
    g.report()

if __name__ == "__main__":
    test_Grammar_report()

# Generated at 2022-06-21 10:08:03.449494
# Unit test for constructor of class Grammar
def test_Grammar():
    token.sym_name[1] = "A"
    Grammar()


if __name__ == "__main__":
    test_Grammar()

# Generated at 2022-06-21 10:08:13.933724
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'a': 1}
    g.number2symbol = {1: 'a'}
    g.states = [1, 2]
    g.dfas = {1: (1, 2)}
    g.labels = [(1, 'a'), (2, 'b')]
    g.keywords = {'a': 1}
    g.tokens = {1: 2}
    g.symbol2label = {'a': 1}
    g.start = 3
    g.async_keywords = True
    with tempfile.NamedTemporaryFile(delete=False) as f:
        filename = f.name
        g.dump(filename)
    assert os.path.isfile(filename)

# Generated at 2022-06-21 10:08:15.611344
# Unit test for method report of class Grammar
def test_Grammar_report():
    grammar = Grammar()
    grammar.report()

# Generated at 2022-06-21 10:08:25.028825
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256


# Generated at 2022-06-21 10:08:34.654800
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    x = Grammar()
    y = x.copy()
    assert x.start == y.start == 256
    assert x.symbol2number == y.symbol2number == {}
    assert x.number2symbol == y.number2symbol == {}
    assert x.states == y.states == []
    assert x.dfas == y.dfas == {}
    assert x.labels == y.labels == [(0, "EMPTY")]
    assert x.keywords == y.keywords == {}
    assert x.tokens == y.tokens == {}
    assert x.symbol2label == y.symbol2label == {}
    assert x.async_keywords == y.async_keywords == False

    x.symbol2number["test"] = 5

# Generated at 2022-06-21 10:08:42.411819
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    a = Grammar()
    a.start = 1
    a.dfas = {1:([[(2, 3)], [(2, 4), (5, 5)]], {4:0, 5:1})}
    a.symbol2number = {"a":1, "b":2}
    a.number2symbol = {1:"a", 2:"b"}
    b = a.copy()
    assert a.start == b.start
    assert a.dfas == b.dfas
    assert a.symbol2number == b.symbol2number
    assert a.number2symbol == b.number2symbol