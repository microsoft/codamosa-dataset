

# Generated at 2022-06-21 09:58:39.023268
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    from . import pgen2
    gen = pgen2.GenerateGrammarTables()
    gen.dump('Grammar.pickle')

    with open('Grammar.pickle','rb') as f:
        pkl = f.read()

    grammar1 = Grammar()
    grammar1.load('Grammar.pickle')

    grammar2 = Grammar()
    grammar2.loads(pkl)

    assert(grammar1==grammar2)

# Generated at 2022-06-21 09:58:40.142978
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/tmp/grammar.pkl")

# Generated at 2022-06-21 09:58:46.478742
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    _grammar = Grammar()

# Generated at 2022-06-21 09:58:53.337285
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .grammar import pgen

    def parse(gram: Grammar, x: str) -> None:
        from . import parse

        parse.driver(gram, x)

    g1 = pgen.makeGrammar()
    g2 = Grammar()
    g2.loads(g1.dumps())
    parse(g1, "3")
    parse(g2, "3")



# Generated at 2022-06-21 09:59:05.524061
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    gt = Grammar()
    gt.symbol2number["SYMBOL"] = 256
    gt.number2symbol[256] = "SYMBOL"
    gt.states = [[[]]]
    gt.dfas = {256: (0, set())}
    gt.labels = [(0, "EMPTY")]
    gt.keywords = {256: "SYMBOL"}
    gt.tokens = {256: "SYMBOL"}
    gt.symbol2label = {256: "SYMBOL"}
    gt.start = 256
    gt.async_keywords = True
    gc = gt.copy()

# Generated at 2022-06-21 09:59:08.496816
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()

    assert grammar.symbol2number == {}
    assert grammar.number2symbol == {}
    assert grammar.states == []
    assert grammar.dfas == {}
    assert grammar.labels == [(0, "EMPTY")]
    assert grammar.keywords == {}
    assert grammar.tokens == {}
    assert grammar.symbol2label == {}
    assert grammar.start == 256
    assert not grammar.async_keywords

# Generated at 2022-06-21 09:59:12.590104
# Unit test for method load of class Grammar
def test_Grammar_load():
    # just make sure that nothing crashes.
    g = Grammar()
    g.loads(g.dump(os.path.devnull))

# Generated at 2022-06-21 09:59:24.032325
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'None': 65, 'False': 66, 'True': 67, 'await': 68}
    g.number2symbol = {65: 'None', 66: 'False', 67: 'True', 68: 'await'}
    g.states = [[[(0, 1)], [(0, 2)], [(0, 3)], [(0, 0)]]]

# Generated at 2022-06-21 09:59:35.800830
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    from copy import copy

    g = Grammar()
    g.symbol2number["testkey"] = 123
    g.number2symbol[123] = "testkey"
    g.labels.append((1, "name1"))
    g.labels.append((2, "name2"))
    g.keywords["name1"] = 1
    g.tokens[2] = 2

    serialized = pickle.dumps(g)
    loaded_g = Grammar()
    loaded_g.loads(serialized)

    assert loaded_g.symbol2number == g.symbol2number
    assert loaded_g.number2symbol == g.number2symbol
    assert loaded_g.labels == g.labels
    assert loaded_g.keywords == g.keywords
    assert loaded_g

# Generated at 2022-06-21 09:59:43.377010
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    gr = Grammar()
    gr2 = gr.copy()
    assert gr2.symbol2number == gr.symbol2number
    assert gr2.number2symbol == gr.number2symbol
    assert gr2.dfas == gr.dfas
    assert gr2.keywords == gr.keywords
    assert gr2.tokens == gr.tokens
    assert gr2.symbol2label == gr.symbol2label
    assert gr2.labels == gr.labels
    assert gr2.states == gr.states
    assert gr2.start == gr.start
    assert gr2.async_keywords == gr.async_keywords

# Generated at 2022-06-21 09:59:52.535270
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256

# Generated at 2022-06-21 10:00:02.713665
# Unit test for method report of class Grammar
def test_Grammar_report():
    grammar = Grammar()
    grammar.symbol2number = {'foo': 257}
    grammar.number2symbol = {257: 'foo'}
    grammar.labels = [(0, 'EMPTY'), (258, 'bar')]
    grammar.states = [
        [(258, 1), (0, 2)],
        [(258, 1), (0, 3)],
        [],
        [],
    ]
    grammar.dfas = {257: ([[(258, 1), (0, 2)], [(258, 1), (0, 3)], [], []], {258: 1})}
    grammar.keywords = {'EMPTY': 0}
    grammar.tokens = {258: 258}
    grammar.start = 257
    grammar.report()


# Generated at 2022-06-21 10:00:06.576482
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.tokens[1] = 2
    pkl = pickle.dumps(g, pickle.HIGHEST_PROTOCOL)
    ng = Grammar()
    ng.loads(pkl)
    assert ng.tokens[1] == 2

# Generated at 2022-06-21 10:00:11.919510
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    grammar1 = Grammar()
    grammar2 = Grammar()
    grammar2.symbol2number["a"] = "1"
    grammar2.number2symbol[1] = "a"
    grammar2.dfas[1] = (([], {}), {})
    grammar2.keywords["b"] = 1
    grammar2.tokens[2] = 1
    grammar2.symbol2label["c"] = 1
    grammar2.labels = [(1, "a")]
    grammar2.states = [[(1, 2)]]
    grammar2.start = 256
    grammar2.async_keywords = False

    grammar3 = grammar2.copy()
    grammar3.symbol2number["a"] = "2"
    grammar3.number2symbol[2] = "b"
    grammar3

# Generated at 2022-06-21 10:00:12.525352
# Unit test for method load of class Grammar
def test_Grammar_load():
    pass

# Generated at 2022-06-21 10:00:23.416943
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # type: () -> None
    """
    Test Grammar.loads
    """
    g = Grammar()

# Generated at 2022-06-21 10:00:24.369707
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()


# Generated at 2022-06-21 10:00:36.431429
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2
    from .parser import PythonParser
    path = os.path.dirname(__file__)
    # Load the grammar of Python 3.4
    g34 = pgen2.pgen(os.path.join(path, "Grammar.txt"), "3.4")
    g34.dump(os.path.join(path, "Grammar34.pickle"))
    # Load the grammar of Python 3.6
    g36 = pgen2.pgen(os.path.join(path, "Grammar.txt"), "3.6")
    g36.dump(os.path.join(path, "Grammar36.pickle"))
    parser34 = PythonParser(g34)
    parser36 = PythonParser(g36)

# Generated at 2022-06-21 10:00:46.268777
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import os
    import io
    import pickle
    # XXX: The code below causes mypyc to crash with a segfault, so
    # we have to disable it
    if sys.implementation.name != "mypyc":
        f1, f2 = tempfile.mkstemp()
        try:
            os.close(f1)
            g1 = Grammar()
            g1.symbol2number['foo'] = 1
            g1.dump(f2)
            g2 = Grammar()
            g2.load(f2)
            assert g2.symbol2number.keys() == ['foo']
        finally:
            os.remove(f2)


# Generated at 2022-06-21 10:00:50.126168
# Unit test for method report of class Grammar
def test_Grammar_report():
    for line in opmap_raw.splitlines():
        if line:
            op, name = line.split()
            opmap[op] = getattr(token, name)
# End of test_Grammar_report()



# Generated at 2022-06-21 10:01:03.858089
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .conv import graminit
    from .pgen import driver

    dirname = os.path.join(os.path.dirname(__file__), "..", "Grammar")
    grammar = graminit.Grammar()
    driver.load_grammar(grammar, dirname)
    fname = os.path.join(dirname, "Grammar.pickle")
    grammar.dump(fname)
    new_grammar = graminit.Grammar()
    new_grammar.load(fname)
    assert grammar.symbol2number == new_grammar.symbol2number
    assert grammar.number2symbol == new_grammar.number2symbol
    assert grammar.states == new_grammar.states
    assert grammar.dfas == new_grammar.dfas

# Generated at 2022-06-21 10:01:05.393473
# Unit test for method report of class Grammar
def test_Grammar_report():
    """
    Check Grammar.report().
    """
    grammar = Grammar()
    grammar.report()

# Generated at 2022-06-21 10:01:16.439445
# Unit test for method load of class Grammar
def test_Grammar_load():
    g1 = Grammar()
    g1.number2symbol = {}
    g1.symbol2number = {}
    g1.dfas = {}
    g1.start = 0
    g1.labels = [(0, None)]
    g1.keywords = {}
    g1.async_keywords = False
    g1.tokens = {}
    g1.symbol2label = {}
    filename = tempfile.mktemp("gram")
    try:
        # This call should succeed
        g1.dump(filename)
        g2 = Grammar()
        g2.load(filename)
        assert g1.number2symbol == g2.number2symbol
    finally:
        os.remove(filename)


# Generated at 2022-06-21 10:01:26.521515
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    g.number2symbol[1] = "a"
    g.symbol2number["a"] = 1
    g.dfas[1] = ([], {"a": 1})
    g.tokens[1] = 2
    g.keywords["a"] = 3
    g.labels = [(1, "a"), (2, None)]
    g.states = [([(1, 1)]), []]
    g.start = 1

    copy = g.copy()
    assert copy.copy() is not copy
    assert copy.number2symbol == g.number2symbol
    assert copy.symbol2number == g.symbol2number
    assert copy.dfas == g.dfas
    assert copy.tokens == g.tokens

# Generated at 2022-06-21 10:01:29.188016
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("Grammar.txt")

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-21 10:01:41.007580
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = os.path.abspath(os.path.split(__file__)[0]) + '/../test/test.pickle'
    with open(filename, 'rb') as f:
        d = pickle.load(f)
        g = Grammar()
        g._update(d)
    for dict_attr in (
        'symbol2number', 'number2symbol', 'dfas', 'keywords', 'tokens', 'symbol2label'
    ):
        if getattr(g, dict_attr) != d[dict_attr]:
            print(getattr(g, dict_attr), d[dict_attr])
            assert False
    if g.labels != d['labels']:
        print(g.labels, d['labels'])
        assert False

# Generated at 2022-06-21 10:01:51.554034
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test for method load of class Grammar
    import sys

    g = Grammar()
    f = sys._getframe()
    pkl = f.f_code.co_consts[0]
    g.loads(pkl)

# Generated at 2022-06-21 10:01:54.034009
# Unit test for constructor of class Grammar
def test_Grammar():
    class DummyGrammar(Grammar):
        pass
    assert DummyGrammar.__doc__ is not None
    assert "Pgen parsing tables conversion class." in DummyGrammar.__doc__

# Generated at 2022-06-21 10:02:01.709875
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    import io, pickle

    g = Grammar()
    g.number2symbol = {257: 'if_stmt', 258: 'test', 259: 'suite'}
    s = pickle.dumps(g.__dict__, pickle.HIGHEST_PROTOCOL)
    gg = Grammar()
    gg.loads(s)
    assert gg.__dict__ == g.__dict__

# Generated at 2022-06-21 10:02:08.841882
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test if load() does not raise any exceptions and sets at least
    # some of the attributes
    filename = os.path.join(os.path.dirname(__file__), "Grammar.pkl")
    g = Grammar()
    g.load(filename)
    assert g.symbol2number
    assert g.number2symbol
    assert g.states
    assert g.dfas
    assert g.labels
    assert g.start == 256

# Generated at 2022-06-21 10:02:21.110159
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2 import python_grammar
    from .parse import ParserError

    g = python_grammar

    # Dump the grammar tables to a pickle file.
    filename = os.path.join(os.path.dirname(__file__), "Grammar.pickle")
    g.dump(filename)

    # Load the grammar tables from a pickle file.
    h = Grammar()
    h.load(filename)

    # Compare the dumped/loaded grammar tables with the original ones.
    assert str(g) == str(h)
    assert g.__dict__ == h.__dict__

    # Compare the dumped/loaded grammar tables with an object pickled
    # from the original ones.
    import pickle
    o = pickle.dumps(g)
    hh = Grammar()
    h

# Generated at 2022-06-21 10:02:28.685700
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    import io
    import pickle

    path = 'src/Grammar.pkl'
    with open(path, "rb") as f:
        pkl = f.read()

    g = Grammar()
    g.loads(pkl)

    f = io.BytesIO(pkl)
    g1 = Grammar()
    g1.loads(pickle.load(f))

    # python3.7+
    assert g1.async_keywords

# Generated at 2022-06-21 10:02:36.191128
# Unit test for constructor of class Grammar
def test_Grammar():
    """Grammar constructor should add some attributes."""
    g = Grammar()
    assert hasattr(g, "symbol2number")
    assert hasattr(g, "number2symbol")
    assert hasattr(g, "states")
    assert hasattr(g, "dfas")
    assert hasattr(g, "labels")
    assert hasattr(g, "keywords")
    assert hasattr(g, "tokens")
    assert hasattr(g, "symbol2label")
    assert hasattr(g, "start")


del opmap_raw



# Generated at 2022-06-21 10:02:43.511369
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    from .pgen2 import tokenize

    g = Grammar()

    for version in range(pickle.HIGHEST_PROTOCOL + 1):
        s = pickle.dumps(g, protocol=version)
        g2 = Grammar()
        g2.loads(s)
        assert g == g2
        assert g.async_keywords == g2.async_keywords
        assert g.states == g2.states
        assert g.tokens == g2.tokens
        assert g.number2symbol == g2.number2symbol
        assert g.symbol2number == g2.symbol2number
        assert g.dfas == g2.dfas
        assert g.labels == g2.labels
        assert g.keywords == g2.keywords
        assert g

# Generated at 2022-06-21 10:02:46.301662
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    import pprint
    pprint.pprint(g.states)

# Generated at 2022-06-21 10:02:55.577807
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    def check_Grammar_loads(s: str) -> Grammar:
        g = Grammar()
        g.loads(s)
        return g

    # mypy does not like this construct
    # assert check_Grammar_loads(b"\x80\x02c_ast\nNode\n")
    exc = None
    try:
        check_Grammar_loads(b"\x80\x02c_ast\nNode\n")
    except Exception as e:
        exc = e
    assert type(exc) is Exception
    assert str(exc) == "START symbol not defined"

    # assert check_Grammar_loads(b"\x80\x02c_ast\nNode\n.(")
    exc = None

# Generated at 2022-06-21 10:03:07.079305
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    for dict_attr in (
        "symbol2number",
        "number2symbol",
        "dfas",
        "keywords",
        "tokens",
        "symbol2label",
    ):
        d = getattr(g, dict_attr)
        d[1] = 2
        assert d is getattr(g, dict_attr)
    g.labels = [1, 2, 3, 4]
    g.states = [[1, 2]]
    g.start = 1
    g.async_keywords = True
    g2 = g.copy()

# Generated at 2022-06-21 10:03:18.321254
# Unit test for method report of class Grammar
def test_Grammar_report():
    from io import StringIO
    from unittest import mock
    from . import pgen
    out = StringIO()
    with mock.patch("sys.stdout", new=out):
        g = pgen.expr("0")
        g.report()

# Generated at 2022-06-21 10:03:20.103609
# Unit test for method report of class Grammar
def test_Grammar_report():
    from pgen2.grammar import Grammar
    from pprint import pprint

    g = Grammar()

# Generated at 2022-06-21 10:03:30.060989
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    grammar = Grammar()
    # With bpo-34473.a
    with open("Lib/pgen2/pgen2/pgen.pickle", "rb") as f:
        grammar.loads(f.read())


# Create a mapping from keywords to tokens
keyword2tok = {}
token2keyword: Dict[int, str] = {}
for kw, t in token.__dict__.items():
    if isinstance(t, int):
        keyword2tok[kw] = t
        token2keyword[t] = kw

# Generated at 2022-06-21 10:03:48.273568
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    from .conv import Conv
    from .pgen import Pgen

    conv = Conv()
    pgen = Pgen(conv)

# Generated at 2022-06-21 10:04:00.649752
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io
    import pprint
    import unittest

    from .parser import Parser

    class Grammar_reportTests(unittest.TestCase):
        def test_report(self):
            s = io.StringIO()
            p = Parser()
            p.grammar.report(file=s)
            s.seek(0)
            self.assertEqual(s.readline(), 's2n\n')

# Generated at 2022-06-21 10:04:08.819724
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest

    class MockGrammar (Grammar):
        def __init__(self):
            super().__init__()
            self.a = set()
            self.b = {}

    g = MockGrammar()
    g.load(os.path.join("Lib", "test", "pickle_data", "grammar.pkl"))
    assert g.a == {'EMPTY'}
    assert g.b == {}
    assert g.start == 256

    assert g.symbol2number == {
        'STORE': 258,
        'NAME': 260,
        'TUPLE': 259,
        'LIST': 257,
    }

# Generated at 2022-06-21 10:04:16.633900
# Unit test for constructor of class Grammar
def test_Grammar():
    gr = Grammar()
    assert gr.symbol2number == {}
    assert gr.number2symbol == {}
    assert gr.states == []
    assert gr.dfas == {}
    assert gr.labels == [(0, "EMPTY")]
    assert gr.keywords == {}
    assert gr.tokens == {}
    assert gr.symbol2label == {}
    assert gr.start == 256
    assert gr.async_keywords == False

# Generated at 2022-06-21 10:04:27.261974
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-21 10:04:39.648915
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    from copy import copy
    from pgen2.grammar import Grammar, terminal

    class Terminal(terminal):
        def __init__(self, terminator, value=None):
            self.terminator = terminator
            self.value = value

    # Create a simple grammar
    g1 = Grammar()
    g1.symbol2number["foo"] = 16
    g1.number2symbol[16] = "foo"
    g1.start = 1
    g1.labels = [(1, "UNKNOWN")]

    g1.dfas = {1: ([[(1, 1)]], {"UNKNOWN": 1}), 2: ([[(2, 2)]], {"EOF": 2})}

# Generated at 2022-06-21 10:04:48.237979
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    class TestGrammar(Grammar):
        pass

    t = TestGrammar()
    s = pickle.dumps(t.__dict__, pickle.HIGHEST_PROTOCOL)
    u = TestGrammar()
    u.loads(s)


if __name__ == "__main__":
    import sys

    if len(sys.argv) == 1:
        print("give me a pgen.pickle file")
    else:
        g = Grammar()
        g.load(sys.argv[1])
        g.report()

# Generated at 2022-06-21 10:04:49.112492
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()


# Generated at 2022-06-21 10:04:57.293056
# Unit test for method load of class Grammar
def test_Grammar_load():
    try:
        os.remove('c:\\users\\public\\grammars\\grammar.py')
    except:
        pass
    try:
        os.remove('c:\\users\\public\\grammars\\grammar37.py')
    except:
        pass
    try:
        os.remove('c:\\users\\public\\grammars\\grammar3x.py')
    except:
        pass
    os.remove('c:\\users\\public\\grammars\\grammar2x.py')


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-21 10:05:08.343626
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.report()
    g2 = g.copy()
    g.report()

    assert g == g2
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.start == g2.start
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label
    assert g.async_keywords == g2.async_keywords

if __name__ == "__main__":
    test_Grammar

# Generated at 2022-06-21 10:05:35.850864
# Unit test for method report of class Grammar
def test_Grammar_report():
    """Ensure that Grammar.report does not raise exception."""
    Grammar().report()

# Generated at 2022-06-21 10:05:45.718686
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")
    assert(g.async_keywords == False)
    assert(g.number2symbol[258] == "stmt")
    assert(g.number2symbol[259] == "simple_stmt")
    assert(g.symbol2label["simple_stmt"] == 2)
    assert(g.number2symbol[260] == "small_stmt")
    assert(g.number2symbol[272] == "compound_stmt")
    assert(g.states[19][1][1][0] == (261, 53))
    assert(g.tokens[token.NAME] == 1)
    assert(g.tokens[token.EQUAL] == 31)

# Generated at 2022-06-21 10:05:46.304452
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()

# Generated at 2022-06-21 10:05:54.478471
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    filename = "my-grammar.p"
    g.dump(filename)
    file = open(filename, "rb")
    pickle_g = pickle.load(file)
    file.close()
    assert g.symbol2number == pickle_g.symbol2number
    assert g.number2symbol == pickle_g.number2symbol
    assert g.states == pickle_g.states
    assert g.dfas == pickle_g.dfas
    assert g.labels == pickle_g.labels
    assert g.keywords == pickle_g.keywords
    assert g.tokens == pickle_g.tokens
    assert g.symbol2label == pickle_g.symbol2label
    assert g.start == pickle_

# Generated at 2022-06-21 10:06:07.086252
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-21 10:06:13.941372
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {'a': 1}
    g.number2symbol = {1: 'a'}
    g.states = [0]
    g.dfas = {1: (1, 2)}
    g.labels = [(0, "EMPTY")]
    g.keywords = {'EMPTY': 1}
    g.tokens = {1: 1}
    g.symbol2label = {'EMPTY': 1}
    g.start = 256
    g.async_keywords = False
    c = g.copy()
    assert c.symbol2number == g.symbol2number
    assert c.number2symbol == g.number2symbol
    assert c.states == g.states
    assert c.dfas == g.dfas

# Generated at 2022-06-21 10:06:14.570428
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()

# Generated at 2022-06-21 10:06:26.027431
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    def loads(expected, *args, **kwargs):
        grammar = Grammar()
        grammar.loads(*args, **kwargs)
        assert grammar.symbol2number == expected.symbol2number
        assert grammar.number2symbol == expected.number2symbol
        assert grammar.states == expected.states
        assert grammar.dfas == expected.dfas
        assert grammar.labels == expected.labels
        assert grammar.keywords == expected.keywords
        assert grammar.tokens == expected.tokens
        assert grammar.start == expected.start

    from pickle import dumps

    expected = Grammar()
    expected.symbol2number = {'foo': 257}
    expected.number2symbol = {257: 'foo'}
    expected.states = []

# Generated at 2022-06-21 10:06:38.359276
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    class MyGrammar(Grammar):
        def __init__(self):
            super().__init__()
            self.x = 1
    g = MyGrammar()
    assert g is g.copy()
    assert g.copy().x == 1


if __name__ == "__main__":
    import pprint
    from .conv import convert
    from .pgen import dump

    g = Grammar()
    g.symbol2number = {
        "term": 258,
        "term_op": 259,
        "factor": 260,
        "factor_op": 261,
        "power": 262,
        "atom": 263,
    }
    g.number2symbol = dict((v, k) for k, v in g.symbol2number.items())

# Generated at 2022-06-21 10:06:50.814123
# Unit test for method load of class Grammar
def test_Grammar_load():
    # type: () -> None
    import unittest
    import tempfile
    import os

    from .pgen2 import driver

    # A grammar file is passed to the constructor to make
    # a Grammar instance that has load method called on it later.
    class TestGrammar(unittest.TestCase):
        def test_load(self):
            temp_dir = tempfile.TemporaryDirectory()

# Generated at 2022-06-21 10:07:58.541858
# Unit test for constructor of class Grammar
def test_Grammar():
    import unittest
    import sys

    class TestGrammar(unittest.TestCase):
        def test_map(self):
            for op, tok in opmap.items():
                self.assertEqual(token.tok_name[tok], op)

        def test_grammar(self):
            g = Grammar()
            self.assertEqual(g.symbol2number, {})
            self.assertEqual(g.number2symbol, {})
            self.assertEqual(g.states, [])
            self.assertEqual(g.dfas, {})
            self.assertEqual(g.labels, [(0, "EMPTY")])
            self.assertEqual(g.keywords, {})
            self.assertEqual(g.tokens, {})


# Generated at 2022-06-21 10:08:06.890907
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import py
    import sys
    import pickle
    import shutil
    import os
    import tempfile
    tname = py.test.ensuretemp("pygram").join("test_Grammar_dump.pickle")
    tname2 = tname.new(basename="test_Grammar_dump.2.pickle")
    if tname.check(): tname.remove()
    if tname2.check(): tname2.remove()
    g = Grammar()
    g.dump(tname)
    h = Grammar()
    h.dump(tname2)
    file1 = open(str(tname), "rb")
    file2 = open(str(tname2), "rb")
    data1 = pickle.load(file1)

# Generated at 2022-06-21 10:08:15.024347
# Unit test for constructor of class Grammar
def test_Grammar():
    assert Grammar().symbol2number == {}
    assert Grammar().number2symbol == {}
    assert Grammar().states == []
    assert Grammar().dfas == {}
    assert Grammar().labels == [(0, "EMPTY")]
    assert Grammar().keywords == {}
    assert Grammar().tokens == {}
    assert Grammar().symbol2label == {}
    assert Grammar().start == 256
    assert Grammar().async_keywords == False


# Generated at 2022-06-21 10:08:22.934534
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import json
    import pkgutil

    # Critical: make sure pickle data written by dump() is readable
    # by Python 2.x.  This test is intended to detect when the
    # HIGHEST_PROTOCOL value in dump() needs to be changed.
    result = io.BytesIO()
    data = json.loads(
        pkgutil.get_data("lib2to3", "Grammar.txt").decode('utf-8')
    )
    for item in data:
        g = Grammar()
        g.loads(item)
        g.dump(result)
    pickle.loads(result.getvalue())

# Generated at 2022-06-21 10:08:25.645682
# Unit test for method report of class Grammar
def test_Grammar_report():
    from io import StringIO
    from .pgen2 import driver

    g = driver.load_grammar()
    out = StringIO()
    g.report(file=out)
    out.seek(0)
    assert out.read() != ""

# Generated at 2022-06-21 10:08:35.313306
# Unit test for method loads of class Grammar