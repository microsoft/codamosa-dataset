

# Generated at 2022-06-21 09:58:54.553616
# Unit test for method report of class Grammar
def test_Grammar_report():
    from . import pgen2

    g = Grammar()
    g.states = [[(1, 1), (2, 2)], [(2, 3), (4, 4)]]
    g.start = 2
    g.dfas = {
        256: (0, {1: 1}),
        257: (1, {2: 1}),
    }
    g.symbol2number = {
        "<def>": 256,
        "<expr>": 257,
    }
    g.number2symbol = {256: "<def>", 257: "<expr>"}
    g.labels = [
        (0, None),
        (257, "<expr>"),
        (1, "x"),
        (2, None),
        (258, "y"),
    ]

# Generated at 2022-06-21 09:59:06.518020
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.symbol2number = {'A': 0, 'B': 1, 'C': 2}
    g.number2symbol = {0: 'A', 1: 'B', 2: 'C'}
    g.states = [[[(0, 0), (0, 2)],
                 [(0, 0), (1, 3)],
                 [(0, 1), (1, 3)],
                 [(0, 4)]]]

# Generated at 2022-06-21 09:59:16.045580
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # Grammar.loads() is used by frozen grammars, and so must be
    # preserved as a staticmethod.
    g = Grammar()

# Generated at 2022-06-21 09:59:26.573720
# Unit test for method load of class Grammar
def test_Grammar_load():
    import ast
    import sys
    # import pytest
    # pytest.skip("tests are not yet implemented")

    _filename = sys.executable  # type: ignore
    grammar = Grammar()
    grammar.loads(b"")
    value = grammar.load(_filename)
    assert isinstance(value, type(None)), repr(value)
    assert value is None, repr(value)
    assert isinstance(grammar.symbol2number, dict), repr(grammar.symbol2number)
    assert isinstance(grammar.number2symbol, dict), repr(grammar.number2symbol)
    assert isinstance(grammar.states, list), repr(grammar.states)
    assert all(isinstance(x, list) for x in grammar.states)

# Generated at 2022-06-21 09:59:34.418737
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert not g.async_keywords


# Generated at 2022-06-21 09:59:43.493921
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-21 09:59:53.302539
# Unit test for method report of class Grammar
def test_Grammar_report():
    import StringIO
    import sys
    import token
    import tokenize
    from typing import BinaryIO

    def readGrammar(file_or_filename: Union[Path, BinaryIO]) -> Grammar:
        if isinstance(file_or_filename,str):
            g = Grammar()
            g.load(file_or_filename)
            return g
        else:
            return Grammar().loads(file_or_filename.read())

    def tokenCount(g: Grammar) -> int:
        k = len(g.keywords)
        return k + len(g.tokens) - len(set(g.keywords.keys()) &
                                       set(g.tokens.keys()))


# Generated at 2022-06-21 09:59:59.173083
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    class MyGrammar(Grammar):
        pass

    grammar = MyGrammar()  # type: ignore
    grammar.loads(b'\x80\x03c__main__\nMyGrammar\nq\x00)\x81q\x01.')


if __name__ == "__main__":
    test_Grammar_loads()

# Generated at 2022-06-21 10:00:08.050715
# Unit test for constructor of class Grammar
def test_Grammar():
    # 	print "Testing constructor of class Grammar"

    g = Grammar()

    g.symbol2number = {"s1": 257, "s2": 258, "s3": 259}
    g.number2symbol = {257: "s1", 258: "s2", 259: "s3"}
    g.states = [[(258, 1)], [(0, 2)]]
    g.dfas = {257: (g.states[0], {258: 1}), 258: (g.states[1], {0: 1})}
    g.labels = [(0, None), (258, None), (0, None)]
    g.keywords = {}
    g.tokens = {}
    g.symbol2label = {}

    g.start = 256

    g.report()
    g.dump

# Generated at 2022-06-21 10:00:18.662137
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    g.symbol2number["abc"] = 256
    g.number2symbol[256] = "abc"
    g.states = [[(1, 2)], []]
    g.start = 256
    g.dfas = {256: ([(1, 2)], {1: 1})}
    g.labels = [(3, "def"), (4, None)]
    g.keywords = {"def": 1}
    g.tokens = {3: 1}
    g.symbol2label["abc"] = 0
    tables = pickle.dumps(g.__getstate__(), pickle.HIGHEST_PROTOCOL)
    g2 = Grammar()
    g2.loads(tables)
    assert g.__getstate__() == g2.__getstate

# Generated at 2022-06-21 10:00:30.120181
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()

    # mypyc generates objects that don't have a __dict__, but they
    # do have __getstate__ methods that will return an equivalent
    # dictionary
    if hasattr(g, "__dict__"):
        d = g.__dict__
    else:
        d = g.__getstate__()  # type: ignore

    import pickle
    import tempfile

    with tempfile.NamedTemporaryFile(mode='wb') as f:
        g.dump(f.name)
        dnew = pickle.load(f)

    for k, v in d.items():
        if k not in ("symbol2number", "number2symbol", "keywords"):
            assert v == dnew[k]

    dsyms = d["symbol2number"]
    dsy

# Generated at 2022-06-21 10:00:38.666856
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'1': 1, '2': 2}
    g.number2symbol = {1: '1', 2: '2'}
    g.states = [1, '1', '2']
    g.dfas = {1: '1', 2: '2'}
    g.labels = [(1, '1'), (2, '2')]
    g.keywords = {'1': 1, '2': 2}
    g.tokens = {1: 1, 2: 2}
    g.start = 1
    g.async_keywords = True

    f = tempfile.NamedTemporaryFile(delete=False)
    g.dump(f.name)


# Generated at 2022-06-21 10:00:50.000403
# Unit test for method loads of class Grammar

# Generated at 2022-06-21 10:00:51.313925
# Unit test for method report of class Grammar
def test_Grammar_report():
    grammar = Grammar()
    grammar.report()


# Generated at 2022-06-21 10:00:56.810889
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    class MyGrammar(Grammar):
        pass

    g = MyGrammar()
    g.loads(b"\x80\x03}q\x00(X\t\x00\x00\x00startq\x01K\x100s.".replace(b"\r\n", b""))
    assert g.start == 256

# Generated at 2022-06-21 10:01:00.011130
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")
    print("loaded")
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-21 10:01:02.987797
# Unit test for method load of class Grammar
def test_Grammar_load():
    import test.test_parser
    filename = test.test_parser.__file__.replace('.pyc', '.pkl')
    g = Grammar()
    g.load(filename)
    g.report()

# Generated at 2022-06-21 10:01:07.315269
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .conv import init_by_grammar
    from .grammar import Grammar
    from .pgen import parse_grammar
    from .tokenize import tokenize

    g = Grammar()
    init_by_grammar(g, parse_grammar(tokenize("grammar.txt")))
    g.dump("grammar.txt.pickle")

    h = Grammar()
    h.load("grammar.txt.pickle")



# Generated at 2022-06-21 10:01:08.267886
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()



# Generated at 2022-06-21 10:01:19.816704
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-21 10:01:28.894503
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    class _DummyGrammar(Grammar):
        """A dummy class to test the method loads."""

    grammar: Grammar = _DummyGrammar()
    d = {"a": 1, "b": 2, "c": 3}
    assert grammar.a == 0 and grammar.b == 0 and grammar.c == 0
    grammar.loads(pickle.dumps(d))
    assert grammar.a == 1 and grammar.b == 2 and grammar.c == 3

# Generated at 2022-06-21 10:01:40.767823
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-21 10:01:45.508566
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    import pgen2.grammar

    def loads(s: str) -> BytesIO:
        return BytesIO(pickle.dumps(s, pickle.HIGHEST_PROTOCOL))

    g = pgen2.grammar.Grammar()
    g.loads(loads("abc"))
    g.loads(loads(b"abc"))

# Generated at 2022-06-21 10:01:53.880652
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    g.loads(pickle.dumps({
        'symbol2number': {'root': '####'},
        'states': [[[0, 0]]]
    }))
    assert g.symbol2number['root'] == '####'
    assert g.states == [[[0, 0]]]


if __name__ == "__main__":
    g = Grammar()
    g.loads(pickle.dumps({
        'symbol2number': {'root': '####'},
        'states': [[[0, 0]]]
    }))
    print(g.symbol2number['root'], g.states)

# Generated at 2022-06-21 10:01:58.054864
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import ast

    class GrammarWithDumpsTestCase(unittest.TestCase):
        def test_dump(self):
            assert Grammar().dump(None) is None

    unittest.main(module=__name__)

# Generated at 2022-06-21 10:02:09.004546
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g
    assert g.symbol2number is not None
    assert g.number2symbol is not None
    assert g.states is not None
    assert g.dfas is not None
    assert g.labels is not None
    assert g.keywords is not None
    assert g.tokens is not None


if __name__ == "__main__":
    import sys
    import pprint

    if len(sys.argv) != 2:
        raise SystemExit("usage: %s %s" % (sys.executable, sys.argv[0]))

    gram = Grammar()
    gram.load(sys.argv[1])
    gram.report()

# Generated at 2022-06-21 10:02:14.085245
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.symbol2number = {'foo': 42}
    g.number2symbol = {42: 'foo'}
    g.states = [[]]
    g.dfas = {42: ([], {})}
    g.labels = [(1, 'one'), (2, None)]
    g.keywords = {'one': 1}
    g.tokens = {2: 2}
    g.start = 42
    import io
    import sys
    temp = io.StringIO()
    sys.stdout = temp
    try:
        g.report()
    finally:
        sys.stdout = sys.__stdout__
    output = temp.getvalue()
    assert output.startswith('s2n\n{\'foo\': 42}')
    assert output.end

# Generated at 2022-06-21 10:02:18.824382
# Unit test for constructor of class Grammar
def test_Grammar():
    grammar = Grammar()

    assert grammar.symbol2number is not None
    assert grammar.number2symbol is not None
    assert grammar.states is not None
    assert grammar.dfas is not None
    assert grammar.labels is not None
    assert grammar.keywords is not None
    assert grammar.tokens is not None
    assert grammar.symbol2label is not None
    assert grammar.start is not None


if __name__ == "__main__":
    test_Grammar()

# Generated at 2022-06-21 10:02:30.231038
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle

    g = Grammar()
    g.foo = 5
    g.bar = "abc"
    g.baz = [1, 2]
    g.dump("pgen.out")
    g1 = Grammar()
    with open("pgen.out", "rb") as f:
        g1.loads(f.read())
    assert g.foo == g1.foo
    assert g.bar == g1.bar
    # TODO: assert g.baz == g1.baz  # fails in Python 2.6
    for name in ["foo", "bar", "baz"]:
        assert g.__dict__[name] == g1.__dict__[name]


if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-21 10:02:33.784452
# Unit test for method loads of class Grammar
def test_Grammar_loads():

    def helper(mstr):
        mstr = mstr.replace(' ', '').replace('\\n', '\n')
        mb = bytes(mstr, 'utf-8')
        g = Grammar()
        g.loads(mb)
        return g

    assert helper('{}') == helper('{}')

    g1 = helper('{}')
    g2 = helper('{"states": [[[[0, 1]]]]}')
    assert g1 != g2

# Generated at 2022-06-21 10:02:51.876614
# Unit test for method load of class Grammar
def test_Grammar_load():
    import io
    import os
    import ast
    import pickle


# Generated at 2022-06-21 10:02:59.020529
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import dataclasses
    import pathlib
    import tempfile
    import unittest
    import pickle

    class ExampleGrammar(Grammar):
        def __init__(self):
            Grammar.__init__(self)
            self.symbol2number = {"Hello": 1, "World": 2}
            self.number2symbol = {1: "Hello", 2: "World"}

    class Test_Grammar_dump(unittest.TestCase):
        def test_dump(self):
            example = ExampleGrammar()
            temp_fd, temp_path = tempfile.mkstemp(suffix=".pickle")
            os.close(temp_fd)
            example.dump(temp_path)

            with open(temp_path, "rb") as fh:
                d = pickle

# Generated at 2022-06-21 10:03:04.756034
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle

    g = Grammar()
    def f(s: str) -> None:
        g.labels = [tuple(int(i) for i in s.split(","))]
        g.dump(".grammar")

    f("0,a")
    f("1,b")
    f("0,c")
    f("1,d")


del token, opmap_raw

# Generated at 2022-06-21 10:03:16.835135
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number['key1'] = 1
    g.symbol2number['key2'] = 2
    g.symbol2number['key3'] = 3
    g.number2symbol[1] = 'value1'
    g.number2symbol[2] = 'value2'
    g.number2symbol[3] = 'value3'
    g.start = 1
    g.states = [[(2, 3), (4, 5)], [(6, 7), (8, 9)]]
    g.dfas[1] = ((10, 11), {12: 13})
    g.dfas[2] = ((14, 15), {16: 17})

# Generated at 2022-06-21 10:03:23.835592
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    g.symbol2number['foo'] = 1
    g.number2symbol[2] = 'bar'
    g.states = [[(1, 1), (2, 2)]]
    g.dfas = {2: (g.states[0], {1: 1})}
    g.labels = [(3, 'baz'), (4, 'quux')]
    g.keywords = {'spam': 1, 'eggs': 2}
    g.tokens = {17: 3, 32: 4}
    g.symbol2label = {'foo': 2, 'bar': 4}
    g.start = 42
    g.async_keywords = True

    expected = Grammar()
    expected._update(g.__getstate__())

    h = Grammar()

# Generated at 2022-06-21 10:03:34.735135
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()

# Generated at 2022-06-21 10:03:41.202602
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    import marshal

    # The following is Python 3.5.2's grammar

# Generated at 2022-06-21 10:03:49.719425
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    """
    Test the method loads of class Grammar.

    The method loads() may only work if the class Grammar, or one of its
    subclasses, is already loaded. So, we execute the call by means of exec().
    """

    g = Grammar()

# Generated at 2022-06-21 10:04:01.432127
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2 import driver
    from .parse import ParseError
    from .tokenize import generate_tokens, untokenize
    from . import pgen

    g = driver.load_grammar(pgen.GRAMMAR_FILE)
    g.dump('Grammar.pickle')
    with open('Grammar.pickle', 'rb') as f:
        attrs = pickle.load(f)
    g2 = Grammar()
    g2._update(attrs)

    def check(s: Text) -> None:
        try:
            tokens = list(generate_tokens(s.encode().__next__))
        except ParseError:
            return
        g2.parsesuite(tokens)
        code = untokenize(tokens).decode()

# Generated at 2022-06-21 10:04:07.034785
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import copy

    g = Grammar()
    g.dfas[0] = (1, 2)
    assert id(g.dfas) != id(g.copy().dfas)
    assert id(g.dfas[0]) != id(g.copy().dfas[0])
    assert id(g.dfas[0][0]) != id(g.copy().dfas[0][0])
    assert id(g.dfas[0][1]) != id(g.copy().dfas[0][1])

# Generated at 2022-06-21 10:04:24.063976
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    from .pgen2 import driver
    from . import parse
    from . import tokenize
    from . import token

    g = driver.load_grammar("graminit.txt")
    parse.initialize_globals(g)
    g2 = g.copy()
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.symbol2label == g2.symbol2label
    assert parse.make_grammar(g) == parse.make_grammar(g2)

# Generated at 2022-06-21 10:04:31.304250
# Unit test for method copy of class Grammar
def test_Grammar_copy():


    class MyGrammar(Grammar):
        pass

    g1 = MyGrammar()
    g1.dfas[0] = 0
    g2 = g1.copy()
    assert g1.dfas is not g2.dfas
    assert g1.dfas == g2.dfas
    g1.labels.append(1)
    g1.labels.append(1)
    g2 = g1.copy()
    assert g1.labels is not g2.labels
    assert g1.labels == g2.labels
    g1.states.append(1)
    g2 = g1.copy()
    assert g1.states is not g2.states
    assert g1.states == g2.states
    g1.symbol2label[0] = 0

# Generated at 2022-06-21 10:04:43.519679
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-21 10:04:52.362149
# Unit test for method loads of class Grammar

# Generated at 2022-06-21 10:05:01.490616
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    grammar = Grammar()
    bytestring = pickle.dumps(
        {
            "symbol2number": {"_add": 256, "atom": 258, "trailer": 257},
            "number2symbol": {256: "_add", 257: "trailer", 258: "atom"},
            "states": [[[(1, 1), (0, 1)]]],
            "dfas": {256: ([[(1, 1), (0, 1)]], {0: 1})},
            "labels": [(0, None), (256, None), (257, None), (258, None)],
            "start": 256,
            "keywords": {},
            "tokens": {},
            "symbol2label": {},
            "async_keywords": False,
        }
    )
    grammar

# Generated at 2022-06-21 10:05:04.199232
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()

if __name__ == "__main__":
    test_Grammar_report()

# Generated at 2022-06-21 10:05:16.430080
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    import sys
    import traceback
    import io
    import tokenize
    import typing
    text = r"""
        def foo(x: ???):
            y: ???
    """
    if sys.version_info < (3, 8):
        stderr = io.StringIO()
        with tokenize.tokenize(io.StringIO(text).readline) as gen:
            for typ, val, *_ in gen:
                print("{!a} {!r}".format(token.tok_name[typ], val), file=stderr)

# Generated at 2022-06-21 10:05:25.462752
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import token
    # del token.__dict__['DOUBLESLASHEQUAL']
    # del token.__dict__['ASYNC_KEYWORD']

    def check_token(key: Text) -> bool:
        return key in token.__dict__ and key.isupper() and len(key) == len(
            "DOUBLESLASHEQUAL"
        )

    as_keys = [key for key in token.__dict__ if check_token(key)]
    g = Grammar()
    g.sym = 'sym'
    g.tokens = {getattr(token, key): i for i, key in enumerate(as_keys)}
    f = open(tempfile.mktemp('.pickle'), 'wb')

# Generated at 2022-06-21 10:05:26.238303
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()

# Generated at 2022-06-21 10:05:36.966893
# Unit test for method report of class Grammar
def test_Grammar_report():
    from . import pgen2
    from tempfile import NamedTemporaryFile
    from subprocess import check_output

    headers = ['#! /usr/bin/env python3', '# -*- coding: utf-8 -*-', '']
    grammar = pgen2.driver.load_grammar(None)
    grammar.async_keywords = True
    with NamedTemporaryFile('w') as f:
        grammar.dump(f.name)
        pyc = check_output(['python3', '-m', 'py_compile', f.name])
    gut = Grammar()
    gut.loads(pyc)
    with NamedTemporaryFile('w', encoding='utf-8') as f:
        f.write('\n'.join(headers))
        gut.report()

# Generated at 2022-06-21 10:05:48.087962
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.copy()

# Generated at 2022-06-21 10:05:55.714734
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    grammar = Grammar()

# Generated at 2022-06-21 10:06:08.238763
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    """
    Ensure that the Grammar.loads() method works.
    """

    def check(g):
        assert g.tokens[token.NAME] == 1
        assert g.labels[1] == (token.NAME, None)
        # check that we don't have keys
        assert not hasattr(g, "__dict__")
        # check that we have a __getstate__ method
        assert hasattr(g, "__getstate__")

        # this is the same as the code in loads, so we know that it works
        d = g.__getstate__()  # type: ignore
        assert d["tokens"] == {token.NAME: 1}
        assert d["labels"] == [(0, "EMPTY"), (token.NAME, None)]

    # create a dummy grammar
    g = Grammar()


# Generated at 2022-06-21 10:06:10.092337
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    import io
    g = Grammar()
    g.loads(io.BytesIO(b"cnopy\n."))


# Generated at 2022-06-21 10:06:11.635189
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    s = pickle.dumps(g)
    g.loads(s)
    assert bool(g)


# Generated at 2022-06-21 10:06:23.588352
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import _pickle as pickle
    from io import BytesIO

    class NewGrammar(Grammar):
        pass

    example_grammar = NewGrammar()
    example_grammar.symbol2number["foo"] = 1
    example_grammar.number2symbol[1] = "bar"
    example_grammar.dfas[2] = 3, 4
    example_grammar.keywords["spam"] = 5
    example_grammar.tokens[6] = 7
    example_grammar.symbol2label["eggs"] = 8
    example_grammar.labels = [(7, "ONION")]
    example_grammar.states = [(1, 2)]
    example_grammar.start = 9
    example_grammar.async_keywords = True
    example

# Generated at 2022-06-21 10:06:25.449874
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    gram = Grammar()
    gram.load('Grammar.pickle')
    gram.dump('Grammar.dump')


# Generated at 2022-06-21 10:06:36.233285
# Unit test for constructor of class Grammar
def test_Grammar():
    test_grammar = Grammar()
    assert test_grammar.symbol2number == {}
    assert test_grammar.number2symbol == {}
    assert test_grammar.states == []
    assert test_grammar.dfas == {}
    assert test_grammar.labels == [(0, "EMPTY")]
    assert test_grammar.keywords == {}
    assert test_grammar.tokens == {}
    assert test_grammar.symbol2label == {}
    assert test_grammar.start == 256
    assert test_grammar.async_keywords is False
    return None


# Generated at 2022-06-21 10:06:42.899463
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    gr = Grammar()
    gr.number2symbol = {0: '1', 1: '2', 2: '3', 3: '4', 4: '5', 11: '6'}
    gr.symbol2number = {'1': 0, '2': 1, '3': 2, '4': 3, '5': 4, '6': 11}
    gr.states = [[[(0, 1)],
                  [(1, 2)],
                  [(1, 5), (2, 3)],
                  [(0, 4)],
                  [(2, 6)],
                  [(1, 7)],
                  [(0, 8)],
                  [(2, 9)]],
                 [[(1, 10)],
                  [(1, 6)],
                  [(0, 11)]]]

# Generated at 2022-06-21 10:06:47.983814
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(os.path.join(os.path.dirname(__file__), 'Grammar.pkl'))

    print("symbol2number:")
    keys = grammar.symbol2number.keys()
    print(list(keys))

    print("number2symbol:")
    keys = grammar.number2symbol.keys()
    print(list(keys))

    print("states:")
    print(grammar.states)

    print("dfas:")
    print(grammar.dfas)

    print("labels:")
    print(grammar.labels)

    print("keywords:")
    print(grammar.keywords)

    print("tokens:")
    print(grammar.tokens)


# Generated at 2022-06-21 10:07:19.735427
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """
    Test that Grammar.dump() results in a readable file.

    This test can be used for debugging changes to the pickle file.
    """

    grammar = Grammar()
    grammar.dump("Grammar.dump")
    grammar.load("Grammar.dump")
    grammar.report()

# Generated at 2022-06-21 10:07:21.790694
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("./Grammar.pickle")
    g.report()


# Generated at 2022-06-21 10:07:24.470110
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()

    g.dump("dump_test.pickle")
    os.remove("dump_test.pickle")

# Generated at 2022-06-21 10:07:33.697149
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()

    g.symbol2number = {"a": 1, "b": 2}
    g.number2symbol = {1: "a", 2: "b"}
    g.keywords = {"a": 22, "b": 23}
    g.tokens = {22: 22, 23: 23}
    g.symbol2label = {"a": 2, "b": 3}
    g.labels = [(0, "EMPTY"), (1, None), (2, "a"), (3, "b")]
    g.states = [[(1, 1), (1, 2)], [(2, 3)]]
    g.dfas = {1: (g.states[0], {1: 1, 2: 1}), 2: (g.states[1], {3: 1})}
    g

# Generated at 2022-06-21 10:07:45.954582
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    def check(g: Grammar, fn):
        g.dump(fn)
        h = Grammar()
        h.load(fn)
        assert g.symbol2number == h.symbol2number
        assert g.number2symbol == h.number2symbol
        assert g.states == h.states
        assert g.dfas == h.dfas
        assert g.labels == h.labels
        assert g.start == h.start

    fn = "test.pkl"

# Generated at 2022-06-21 10:07:49.596660
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Trivial test of Grammar.dump
    from . import conv, pgen

    g = Grammar()
    conv.parse_grammar(g, pgen.pgen(pgen.graminit.graminit_v3_7, "3.7"))
    g.dump("/dev/null")


test_Grammar_dump()

# Generated at 2022-06-21 10:08:00.542168
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    print("testing method dump of class Grammar")

    import subprocess
    import sys

    ffile = os.path.join(
        os.path.dirname(__file__), os.path.pardir, "Grammar.txt"
    )
    pname = subprocess.check_output(["which", "python3.7"]).decode()
    pfile = os.path.join(
        os.path.dirname(os.path.dirname(pname)), "Grammar/Grammar.txt"
    )

    if sys.version_info[:2] == (3, 7):
        ffile = pfile
    else:
        assert False, "${python3.7} must available for this test"

    with open(ffile) as f:
        txt = f.read()

   

# Generated at 2022-06-21 10:08:05.647935
# Unit test for constructor of class Grammar
def test_Grammar():
    grammar = Grammar()
    assert grammar.symbol2number == {}
    assert grammar.number2symbol == {}
    assert grammar.states == []
    assert grammar.dfas == {}
    assert grammar.labels == [(0, "EMPTY")]
    assert grammar.keywords == {}
    assert grammar.tokens == {}
    assert grammar.symbol2label == {}
    assert grammar.start == 256
    assert not grammar.async_keywords



# Generated at 2022-06-21 10:08:17.917033
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    filename = "test_grammar_loads.pickle"
    grammar = Grammar()
    grammar.loads(b"(dp0\nS'number2symbol'\np1\n(dp2\nS'256'\np3\nsS'257'\np4\nsS'258'\np5\nsS'260'\np6\nsS'265'\np7\nsS'258'\np8\nsS'259'\np9\nsS'264'\np10\nsS'262'\np11\nsS'263'\np12\nsS'261'\np13\nsS'266'\np14\nsS'267'\np15\nsb.")

# Generated at 2022-06-21 10:08:18.850045
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    g.start = 256