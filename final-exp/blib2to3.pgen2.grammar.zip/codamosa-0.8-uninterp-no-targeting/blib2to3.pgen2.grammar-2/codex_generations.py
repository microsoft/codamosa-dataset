

# Generated at 2022-06-21 09:58:42.785832
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-21 09:58:48.126993
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {'x': 1, 'y': 2}
    g.number2symbol = {1: 'x', 2: 'y'}
    g.dfas = {3: ([4], {4: 5}), 6: ([7], {7: 8})}
    g.keywords = {'key': 1, 'word': 2}
    g.tokens = {3: 1, 4: 2}
    g.symbol2label = {'s1': 1, 's2': 2}
    g.labels = [(1, 'x'), (2, 'y')]
    g.states = [[(1, 1)], [(2, 2)]]
    g.start = 3
    g.async_keywords = True
    g1 = g.copy

# Generated at 2022-06-21 09:59:00.413911
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import sys
    import types
    import unittest

    class GrammarTest(unittest.TestCase):
        def setUp(self):
            self.g_copy_attrs = [
                "symbol2number",
                "number2symbol",
                "dfas",
                "keywords",
                "tokens",
                "symbol2label",
                "labels",
                "states",
                "start",
            ]
            self.original = Grammar()
            for d in self.g_copy_attrs:
                if d not in ["labels", "states"]:
                    setattr(self.original, d, {d: d})
                elif d == "labels":
                    setattr(self.original, d, [d])
                elif d == "states":
                    setattr

# Generated at 2022-06-21 09:59:09.964699
# Unit test for method loads of class Grammar

# Generated at 2022-06-21 09:59:22.202086
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from tempfile import TemporaryFile
    from io import BytesIO

    def test_dump(g, f):
        g.dump(f)
        f.seek(0)
        d = pickle.load(f)
        assert d['symbol2number'] == g.symbol2number
        assert d['number2symbol'] == g.number2symbol
        assert d['states'] == g.states
        assert d['dfas'] == g.dfas
        assert d['labels'] == g.labels
        assert d['keywords'] == g.keywords
        assert d['tokens'] == g.tokens
        assert d['symbol2label'] == g.symbol2label
        assert d['start'] == g.start

# Generated at 2022-06-21 09:59:33.469770
# Unit test for method load of class Grammar
def test_Grammar_load():

    def _make_grammar():
        grammar = Grammar()
        # Simulate the results of the conv and pgen modules, so we
        # can save the results and check them again later.
        grammar.start = grammar.symbol2number["file_input"] = 256
        grammar.number2symbol[256] = "file_input"
        grammar.start = 256
        grammar.keywords["foo"] = 257
        grammar.tokens[1] = 258
        grammar.symbol2label["bar"] = 259
        grammar.labels = [(257, "foo"), (258, 1), (259, "bar")]
        grammar.states = [[(257, 1), (258, 1)], [(259, 2)], []]

# Generated at 2022-06-21 09:59:43.081955
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords == False
    d = dict(a=1, b=2)
    g._update(d)
    assert g.a == 1
    assert g.b == 2
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}

# Generated at 2022-06-21 09:59:45.352894
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    g.report()


# Generated at 2022-06-21 09:59:50.985539
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # Grammar.loads()
    g = Grammar()
    g.loads(b'\x80\x04\x95\rP\x95\rX\x01\x00\x00\x00j\x95\x02]q\x00K\x00e\x81\x01\x00q\x01\x85q\x02Rq\x03.')
    assert isinstance(g, Grammar)



# Generated at 2022-06-21 09:59:56.459216
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.number2symbol == {}
    assert g.symbol2number == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256

# Generated at 2022-06-21 10:00:08.982405
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    grammar1 = Grammar()
    grammar2 = grammar1.copy()
    assert grammar1.symbol2number == grammar2.symbol2number
    assert grammar1.number2symbol == grammar2.number2symbol
    assert grammar1.dfas == grammar2.dfas
    assert grammar1.keywords == grammar2.keywords
    assert grammar1.tokens == grammar2.tokens
    assert grammar1.symbol2label == grammar2.symbol2label
    assert grammar1.labels == grammar2.labels
    assert grammar1.states == grammar2.states
    assert grammar1.start == grammar2.start
    assert grammar1.async_keywords == grammar2.async_keywords


# Generated at 2022-06-21 10:00:19.566942
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-21 10:00:25.233396
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()

    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256


# Generated at 2022-06-21 10:00:37.092731
# Unit test for method report of class Grammar
def test_Grammar_report():
    """Create a dummy Grammar and print its attributes to stdout"""

    from pprint import pprint
    from . import token

    # Create a dummy Grammar
    pdict = Grammar()

# Generated at 2022-06-21 10:00:47.849137
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    import io
    import unittest

    import lib2to3.pgen2.grammar as mygrammar

    # Pupulate a Grammar object
    G = mygrammar.Grammar()


# Generated at 2022-06-21 10:00:51.186618
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("graminit.txt")
    g2 = Grammar()
    g2.load("graminit.txt")

    assert(g.__dict__ == g2.__dict__)

# Generated at 2022-06-21 10:00:54.476567
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    gr = Grammar()
    gr.dump("/tmp/graminit.tmp")
    gr2 = Grammar()
    gr2.load("/tmp/graminit.tmp")

# Generated at 2022-06-21 10:01:00.220776
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256


# Generated at 2022-06-21 10:01:04.847508
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test writing and then reading a Grammar object
    grammar = Grammar()
    if hasattr(grammar, "__dict__"):
        grammar.__dict__["test"] = 42
    else:
        grammar.test = 42  # type: ignore
    _, path = tempfile.mkstemp(text=False)

# Generated at 2022-06-21 10:01:15.803853
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g1.symbol2number = kwargs = {"k": "v"}
    g1.number2symbol = {i: f"k{i}" for i in range(100)}
    g1.dfas = {
        i: ([[(0, i)]], {i: i})
        for i in range(100)
    }  # type: ignore
    g1.keywords = {f"s{i}": i for i in range(100)}
    g1.tokens = dict(opmap)
    g1.symbol2label = {f"s{i}": i for i in range(100)}
    g1.labels = [(i, f"s{i}") for i in range(100)]

# Generated at 2022-06-21 10:01:24.097702
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()

# Generated at 2022-06-21 10:01:30.354486
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = os.path.join(os.getcwd(), "tmp_foobar")

    def cleanup() -> None:
        try:
            os.remove(filename)
        except OSError:
            pass

    cleanup()
    g = Grammar()
    g.symbol2number["foo"] = 42
    g.number2symbol[42] = "foo"
    g.dump(filename)
    g.loads(open(filename, "rb").read())
    assert g.symbol2number["foo"] == 42
    assert g.number2symbol[42] == "foo"
    cleanup()

# Generated at 2022-06-21 10:01:31.277143
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()

# Generated at 2022-06-21 10:01:39.676007
# Unit test for constructor of class Grammar
def test_Grammar():
    grammar = Grammar()
    assert grammar.symbol2number == {}
    assert grammar.number2symbol == {}
    assert grammar.states == []
    assert grammar.dfas == {}
    assert grammar.labels == [(0, "EMPTY")]
    assert grammar.keywords == {}
    assert grammar.tokens == {}
    assert grammar.symbol2label == {}
    assert grammar.start == 256
    assert not grammar.async_keywords
    assert repr(grammar) == "<Grammar object>"


# Generated at 2022-06-21 10:01:50.382780
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g1.keywords = {'try' : 1, 'finally' : 2, 'except' : 3, 'lambda' : 4, 'or' : 5}
    g1.tokens = {258 : 6, 259 : 7, 260 : 8, 261 : 9, 262 : 10}
    g1.symbol2label = {'comp_op' : 11, 'expr' : 12, 'xor_expr' : 13, 'test' : 14, 'small_stmt' : 15}
    g1.labels = [(258, 'break'), (259, 'continue'), (260, None), (261, 'async'), (262, 'del')]
    g1.symbol2number = {'Arith_expr' : 256, 'Expr' : 257}
    g1.number2

# Generated at 2022-06-21 10:01:53.684011
# Unit test for method load of class Grammar
def test_Grammar_load():
    os.remove(".PythonGrammar.pickle")
    from .pgen2 import driver

    driver.GenerateGrammar()
    g = Grammar()
    g.load(".PythonGrammar.pickle")
    g.report()



# Generated at 2022-06-21 10:02:05.555148
# Unit test for method load of class Grammar
def test_Grammar_load():
    # This function is called by the unit tests

    # If we can import pickle, test the load() / dump() methods
    pickle_available = False
    try:
        import pickle

        pickle_available = True
    except ImportError:
        pass

    if pickle_available:
        try:
            with tempfile.TemporaryDirectory() as dirname:
                g = Grammar()
                g.load(os.path.join(dirname, "nonexistant"))
        except IOError:
            pass
        else:
            raise RuntimeError("Failed to detect missing pickle file")
        g = Grammar()
        fname = os.path.join(dirname, "grammar.pickle")
        g.dump(fname)
        g.load(fname)

# Generated at 2022-06-21 10:02:10.304752
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    grammar = Grammar()
    # check that dfas entry is not present after initialization
    assert not grammar.dfas

# Generated at 2022-06-21 10:02:17.918696
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    class FakeGrammar(Grammar):
        def __getstate__(self):
            return {"foo": "bar"}

    g = FakeGrammar()
    assert g.foo is None, "__init__ did not set attribute foo"
    g.loads(b"c__builtin__\nFakeGrammar\np0\n((dp1\n.".replace(b"FakeGrammar", g.__class__.__name__.encode("latin-1")))
    assert g.foo == b"bar", "loads did not load the attribute foo"

if __name__ == "__main__":
    test_Grammar_loads()

# Generated at 2022-06-21 10:02:23.720254
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    pickle_filename = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        "data",
        "grammar.pickle",
    )
    g = Grammar()
    g.dump(pickle_filename)
    del g
    g2 = Grammar()
    g2.load(pickle_filename)
    os.unlink(pickle_filename)

# Generated at 2022-06-21 10:02:42.857632
# Unit test for method report of class Grammar
def test_Grammar_report():
    from StringIO import StringIO
    from pprint import pprint
    from unittest import TestCase

    class CaptureDict(dict):
        def __init__(self, *args, **kwds):
            super(CaptureDict, self).__init__(*args, **kwds)
            self.capture = []
        def __getitem__(self, key):
            self.capture.append(key)
            return super(CaptureDict, self).__getitem__(key)

    class GrammarTester(TestCase):
        def setUp(self):
            self.output = StringIO()
            self.original = pprint.pprint
            pprint.pprint = self.output.write

        def tearDown(self):
            pprint.pprint = self.original


# Generated at 2022-06-21 10:02:53.520599
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    initial_values = dict(
        symbol2number={"a": 1, "b": 2},
        number2symbol={1: "a", 2: "b"},
        dfas={1: ([[(0, 1)]], {1: 2})},
        keywords={"a": 1, "b": 2},
        tokens={1: 1, 2: 2},
        symbol2label={"a": 1, "b": 2},
        labels=[(0, "EMPTY")],
        states=[[[(0, 1)]]],
        start=1,
        async_keywords=True,
    )
    grammar = Grammar()
    for name, value in initial_values.items():
        setattr(grammar, name, value)
    copy = grammar.copy()
    assert copy == grammar
    # check that all dict

# Generated at 2022-06-21 10:02:57.669721
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """
    def dump(self, filename: str) -> None:
    """
    k = Grammar()
    with tempfile.NamedTemporaryFile(mode="w+b", delete=False) as f:
        k.dump(f.name)
    os.remove(f.name)

# Generated at 2022-06-21 10:03:02.749158
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    class GrammarSub(Grammar):
        pass
    s = GrammarSub()
    s.async_keywords = True
    s.start = 1
    s.dfas[1] = (None, None)
    s.keywords["foo"] = 2
    s.tokens[3] = 4
    s.labels[5] = (None, "bar")
    s.number2symbol[6] = "Baz"
    s.symbol2number["Baz"] = 6
    p = s.loads(s.dumps())
    assert p.async_keywords == True
    assert p.start == 1
    assert p.dfas[1] == (None, None)
    assert p.keywords["foo"] == 2
    assert p.tokens[3] == 4
   

# Generated at 2022-06-21 10:03:14.102446
# Unit test for method load of class Grammar
def test_Grammar_load():
    """
    Test if it is possible to load any pickle file (containing a string in pickle format)
    """
    from types import ModuleType

    g = Grammar()

    # check if it is possible to load a pickle file containing a string
    test_str = "this is a test string"
    pickle_file_str = tempfile.NamedTemporaryFile(delete=False)
    with pickle_file_str as pf:
        pickle.dump(test_str, pf)
    g.load(pickle_file_str.name)

    # check if it is possible to load a pickle file containing a dict
    test_dict = {"a": 1, "b": 2, "c": 3}
    pickle_file_dict = tempfile.NamedTemporaryFile(delete=False)

# Generated at 2022-06-21 10:03:20.556533
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    data = g.__dict__
    assert data['symbol2number'] == {}
    assert data['number2symbol'] == {}
    assert data['states'] == []
    assert data['dfas'] == {}
    assert data['labels'] == [(0, "EMPTY")]
    assert data['keywords'] == {}
    assert data['tokens'] == {}
    assert data['symbol2label'] == {}
    assert data['start'] == 256

# Generated at 2022-06-21 10:03:33.293145
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import unittest.mock

    class GrammarDumpTests(unittest.TestCase):
        def test_dump(self):
            path = "path"
            g = Grammar()
            with unittest.mock.patch.object(
                g, "dump", autospec=True
            ) as mock_dump, unittest.mock.patch(
                "pickle.dump", autospec=True
            ) as mock_pickle_dump, unittest.mock.patch(
                "os.replace", autospec=True
            ) as mock_replace:
                # Exercise
                g.dump(path)
                # Verify
                self.assertEqual(mock_dump.call_count, 1)

# Generated at 2022-06-21 10:03:38.284118
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    # Test data
    g1 = Grammar()
    g1.symbol2number = {"a": 1, "b": 2, "c": 3}
    g1.number2symbol = {1: "a", 2: "b", 3: "c"}
    g1.states = [[(0, 1)], [(0, 2)], [(0, 3)]]
    g1.dfas = {1: (1, {"E": 1}), 2: (2, {"E": 1}), 3: (3, {"E": 1})}
    g1.labels = [(0, "EMPTY"), (1, "a"), (2, "b"), (3, "c")]
    g1.keywords = {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-21 10:03:44.208077
# Unit test for method load of class Grammar
def test_Grammar_load():
    class TestGrammar(Grammar):
        """Test subclass of Grammar."""

        def __init__(self) -> None:
            Grammar.__init__(self)
            self.symbol2number["A"] = 1
            self.number2symbol[1] = "A"
            self.symbol2number["B"] = 2
            self.number2symbol[2] = "B"
            self.states.append([[(1, 2)], [(2, 1)]])
            self.dfas[1] = self.states[0], {1: 2}
            self.dfas[2] = self.states[1], {1: 2}
            self.labels.append((1, "a"))
            self.labels.append((2, "b"))
            self.start = 1

# Generated at 2022-06-21 10:03:56.305991
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-21 10:04:15.760911
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import tempfile
    import sys

    assert sys.implementation.name == "cpython", "Not a cpython implementation"

    class TestGrammarMethods(unittest.TestCase):
        """
        Test the Grammar class method dump
        """

        def test_Grammar_dump(self):
            """
            Test Grammar dump.
            """

            tfn = tempfile.mktemp(".pickle")
            os.unlink(tfn)

            i = Grammar()
            i.dump(tfn)

            j = Grammar()
            j.load(tfn)

            os.unlink(tfn)

    unittest.main()


if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-21 10:04:17.061361
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load()

# Generated at 2022-06-21 10:04:27.554232
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar(
        symbol2number={"A": 1, "B": 2},
        number2symbol={1: "A", 2: "B"},
        states=[["S0", "S1"], ["S2", "S3"]],
        dfas={1: ("DFA1", {"a": 1}), 2: ("DFA2", {"b": 1})},
        labels=[(1, "A"), (2, "B"), (3, None), (4, "C")],
        keywords={"a": 1, "b": 2},
        tokens={"a": 1, "b": 2},
        start=3,
    )

    assert g.symbol2number == {"A": 1, "B": 2}
    assert g.number2symbol == {1: "A", 2: "B"}
   

# Generated at 2022-06-21 10:04:39.835675
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    import io
    from . import conv, pgen
    from .parse import ParserGenerator

    grammar = Grammar()
    with io.StringIO() as stream:
        pgen.pgen("Grammar.g", stream, optimize=False)
        assert stream.getvalue().startswith("""# Parser grammar for
# Python 2.1.2
# Parser grammar for
# Python 2.1.2
""")
        conv.parse_grammar(stream, grammar)
    grammar.dump("/tmp/Grammar.pickle")
    grammar.load("/tmp/Grammar.pickle")

    pg = ParserGenerator(grammar)

    def test_parse(s):
        print(s, pg.parse(s))
        print()


# Generated at 2022-06-21 10:04:50.481216
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {'foo': 1}
    g.number2symbol = {2: 'bar'}
    g.dfas = {1: {'foo': 1, 'bar': 2}}
    g.keywords = {'foo': 1, 'bar': 2}
    g.tokens = {1: 1, 2: 2}
    g.labels = [3, 4]
    g.states = [[(5, 6), (7, 8)]]
    g.start = 9
    g.async_keywords = False


    # mypyc generates objects that don't have a __dict__, but they
    # do have __getstate__ methods that will return an equivalent
    # dictionary
    if hasattr(g, "__dict__"):
        d = g

# Generated at 2022-06-21 10:04:51.331598
# Unit test for method report of class Grammar
def test_Grammar_report():
    f = Grammar()
    f.report()

# Generated at 2022-06-21 10:05:01.274331
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    grammar = Grammar()
    # Ensure attributes with dict value are the same
    for dict_attr in (
        "symbol2number",
        "number2symbol",
        "dfas",
        "keywords",
        "tokens",
        "symbol2label",
    ):
        setattr(grammar, dict_attr, {1: 1, 2: 2})
    # Ensure attributes with list value are the same
    grammar.labels = [1, 2]
    grammar.states = [1, 2]
    # Ensure other attributes are the same
    grammar.start = 3
    grammar.async_keywords = True

    new = grammar.copy()

    # Check attributes with dict value are the same

# Generated at 2022-06-21 10:05:13.681655
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pytest

    skip_on_py37 = pytest.mark.skipif(
        token.N_TOKENS != len(opmap) + 1,
        reason="Remaining tokens are not statically determined on Python 3.7+",
    )

    g = Grammar()
    g.symbol2number = {"s1": 1, "s2": 2}
    g.number2symbol = {1: "s1", 2: "s2"}
    g.states = [[[(1, 2), (2, 3)], [(0, 1), (1, 1)]]]
    g.dfas = {1: (0, {"x": 1, "y": 1}), 2: (1, {"z": 1})}

# Generated at 2022-06-21 10:05:20.348544
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords == False


# Generated at 2022-06-21 10:05:24.406095
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    try:
        import _pickle as p
    except ImportError:
        import pickle as p
    with open("Grammar.pickle", "rb") as f:
        pkl = p.load(f)
    g = Grammar()
    g.loads(pkl)
    g.dump("/tmp/testGrammar.pkl")

# Generated at 2022-06-21 10:05:38.364026
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .conv import parse_grammar
    gram = Grammar()
    parse_grammar(gram, 'Grammar')
    gram.dump('Grammar.pkl')

    gram = Grammar()
    gram.load('Grammar.pkl')
    gram.report()


# Generated at 2022-06-21 10:05:44.389907
# Unit test for method report of class Grammar
def test_Grammar_report():
    gr = Grammar()
    save_stdout = sys.stdout
    try:
        out = io.StringIO()
        sys.stdout = out
        gr.report()
        out.seek(0)
        print(out.read())
    finally:
        sys.stdout = save_stdout

if __name__ == "__main__":
    import sys
    import io

    test_Grammar_report()

# Generated at 2022-06-21 10:05:51.803841
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    g.symbol2number["foo"] = 5
    g.number2symbol[10] = "bar"

    assert g.symbol2number == {"foo": 5}
    assert g.number2symbol == {10: "bar"}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256


if __name__ == "__main__":
    test_Grammar()

# Generated at 2022-06-21 10:05:57.969569
# Unit test for method copy of class Grammar
def test_Grammar_copy():
  grammar = Grammar()
  grammar.symbol2number = {"name1":1, "name2":2, "name3":3}
  grammar.number2symbol = {1:"name1", 2:"name2", 3:"name3"}
  grammar.dfas = {1:[1,2,3], 2:[4,5,6], 3:[7,8,9]}
  grammar.keywords = {'key1':1, 'key2':2, 'key3':3}
  grammar.tokens = {1:1, 2:2, 3:3}
  grammar.symbol2label = {"name1":1, "name2":2, "name3":3}
  grammar.labels = [1,2,3]

# Generated at 2022-06-21 10:06:03.524920
# Unit test for method report of class Grammar
def test_Grammar_report():
    from pprint import pformat
    import sys
    import unittest
    from unittest import mock


# Generated at 2022-06-21 10:06:05.596627
# Unit test for method load of class Grammar
def test_Grammar_load():
    gr = Grammar()
    gr.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))

# Generated at 2022-06-21 10:06:13.524552
# Unit test for constructor of class Grammar
def test_Grammar():
    # Test the first four methods of class Grammar
    g = Grammar()
    filename = os.path.splitext(__file__)[0] + ".pickle"

    try:
        g.dump(filename)
        g2 = Grammar()
        g2.load(filename)
        assert g2.symbol2number == {}

        pkl = pickle.dumps(g, pickle.HIGHEST_PROTOCOL)
        g3 = Grammar()
        g3.loads(pkl)
        assert g3.symbol2number == {}
    finally:
        try:
            os.remove(filename)
        except FileNotFoundError:
            pass

    # Test copy method of class Grammar
    g.symbol2number = {"a": 1, "b": 2}
    g.number2

# Generated at 2022-06-21 10:06:21.403908
# Unit test for constructor of class Grammar
def test_Grammar():
    assert hasattr(Grammar, "symbol2number")
    assert hasattr(Grammar, "number2symbol")
    assert hasattr(Grammar, "states")
    assert hasattr(Grammar, "dfas")
    assert hasattr(Grammar, "labels")
    assert hasattr(Grammar, "start")
    assert hasattr(Grammar, "keywords")
    assert hasattr(Grammar, "tokens")

# Generated at 2022-06-21 10:06:28.998605
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Test Grammar.dump with a minimal object
    g = Grammar()
    g.start = 5
    g.states = [[[(1, 2), (3, 4)]]]
    g.async_keywords = True
    with tempfile.TemporaryDirectory() as tmpdir:
        fn = os.path.join(tmpdir, "grammar.pickle")
        g.dump(fn)

        with open(fn, "rb") as f:
            unpickled_dict = pickle.load(f)
        assert unpickled_dict["start"] == 5
        assert unpickled_dict["states"] == [[[(1, 2), (3, 4)]]]
        assert unpickled_dict["async_keywords"] == True

if __name__ == "__main__":
    import sys


# Generated at 2022-06-21 10:06:31.439618
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()

if __name__ == "__main__":
    test_Grammar()

# Generated at 2022-06-21 10:07:02.562990
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'NAME': 257}
    g.number2symbol = {257: 'NAME'}
    g.states = []
    g.dfas = {257: ([[(257, -1)]], {})}
    g.labels = [(0, 'EMPTY'), (257, None)]
    g.keywords = {}
    g.tokens = {}
    g.symbol2label = {'NAME': 257}
    g.start = 256
    g.async_keywords = False
    g.dump('/tmp/es-tmp-refl0snsk-1.py')
    '''
    assert False # todo: implement your test here
    '''


# Generated at 2022-06-21 10:07:06.775267
# Unit test for method load of class Grammar
def test_Grammar_load():
    if hasattr(Grammar, "load") and callable(Grammar.load):
        Grammar().load("testdata/Grammar.load.data")
        Grammar().load("testdata/Grammar.load.data")

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-21 10:07:12.940313
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Issue 7233: test dump and loads
    #
    # Make a Grammar object with a fake table.  The fake table has
    # a START symbol, whose rule has all the possible tokens over three
    # different RHS.  Make sure that the dumped and loaded dicts have the
    # same contents.

    class FakeGrammar(Grammar):
        def __init__(self) -> None:
            super().__init__()
            self.symbol2number = {"START": 256}
            self.number2symbol = {256: "START"}
            self.states = [[[(0, 1), (257, 2)], [(0, 1), (258, 3)], [(0, 1)]],]
            self.keywords = {"hi": 259, "ho": 260}

# Generated at 2022-06-21 10:07:19.344301
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    assert grammar.dump(__file__) is None
    with open(__file__, "rb") as f:
        assert grammar.loads(f.read()) is None


if __name__ == "__main__":
    test_Grammar_dump()
    print("*" * 50)
    print("All tests passed")
    print("*" * 50)

# Generated at 2022-06-21 10:07:20.395532
# Unit test for constructor of class Grammar
def test_Grammar():
    grammar = Grammar()


# Generated at 2022-06-21 10:07:30.447440
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    from .pgen2 import tokenize as tokenize2

    g = Grammar()
    tokenize2.untokenize(g)
    g2 = g.copy()
    assert g2.symbol2number == g.symbol2number
    assert g2.number2symbol == g.number2symbol
    assert g2.dfas == g.dfas
    assert g2.keywords == g.keywords
    assert g2.tokens == g.tokens
    assert g2.symbol2label == g.symbol2label
    assert g2.labels == g.labels
    assert g2.states == g.states
    assert g2.start == g.start
    assert g2.async_keywords == g.async_keywords

# Generated at 2022-06-21 10:07:36.837044
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Issue 9170
    # Test that the load method of class Grammar loads the
    # keywords attribute as a dict.
    #
    # Finished testing

    # pylint: disable=W0603,C0103
    class GrammarWithSetAttribute(Grammar):
        def __init__(self, filenames: List[Path]) -> None:
            Grammar.__init__(self)
            self.filename = filenames

        def set_attributes(self):
            self.keywords = {}

    temp = tempfile.NamedTemporaryFile(mode="w+b")
    gram1 = GrammarWithSetAttribute(temp.name)
    gram1.set_attributes()
    gram1.dump(temp.name)
    gram2 = Grammar()
    gram2.load(temp.name)
   

# Generated at 2022-06-21 10:07:47.737926
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g2 = g1.copy()
    assert g1 == g2
    assert g1.symbol2number == g2.symbol2number
    assert g1.number2symbol == g2.number2symbol
    assert g1.dfas == g2.dfas
    assert g1.keywords == g2.keywords
    assert g1.tokens == g2.tokens
    assert g1.symbol2label == g2.symbol2label
    assert g1.labels == g2.labels
    assert g1.states == g2.states
    assert g1.start == g2.start
    assert g1.async_keywords == g2.async_keywords

# Generated at 2022-06-21 10:07:58.863271
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    grammar = Grammar()
    assert grammar.symbol2number == {}
    assert grammar.number2symbol == {}
    assert grammar.states == []
    assert grammar.dfas == {}
    assert grammar.labels == [(0, "EMPTY")]
    assert grammar.keywords == {}
    assert grammar.tokens == {}
    assert grammar.symbol2label == {}
    assert grammar.start == 256
    assert not grammar.async_keywords

    grammar1 = grammar.copy()

    assert grammar1.symbol2number == {}
    assert grammar1.number2symbol == {}
    assert grammar1.states == []
    assert grammar1.dfas == {}
    assert grammar1.labels == [(0, "EMPTY")]
    assert grammar1.keywords == {}

# Generated at 2022-06-21 10:08:07.112146
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()