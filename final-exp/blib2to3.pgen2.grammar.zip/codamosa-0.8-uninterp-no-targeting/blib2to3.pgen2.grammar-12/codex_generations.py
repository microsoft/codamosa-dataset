

# Generated at 2022-06-21 09:58:54.415529
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    if g.start is not 256:
        print("error: g.start is not 256")
    g.start = 0
    if g.start is not 0:
        print("error: g.start is not 0")
    h = g.copy()
    if h.start is not 0:
        print("error: h.start is not 256")
    h.start = 1
    if g.start is not 0:
        print("error: g.start is not 0")
    if h.start is not 1:
        print("error: h.start is not 1")

# Generated at 2022-06-21 09:59:06.434343
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g2 = g1.copy()
    assert g1.tokens == g2.tokens
    assert g1.symbol2number == g2.symbol2number
    assert g1.number2symbol == g2.number2symbol
    assert g1.symbol2label  == g2.symbol2label
    assert g1.dfas          == g2.dfas
    assert g1.keywords      == g2.keywords
    assert g1.tokens        == g2.tokens
    assert g1.labels        == g2.labels
    assert g1.states        == g2.states
    assert g1.start         == g2.start
    assert g1.opmap         == g2.opmap

# Generated at 2022-06-21 09:59:12.909494
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {'a':1, 'b':2}
    g.number2symbol = {1:'a', 2:'b'}
    g.dfas = {1:('a', 'b'), 2:('c', 'd')}
    g.keywords = {'a':1, 'b':2}
    g.tokens = {1:'a', 2:'b'}
    g.symbol2label = {'a':1, 'b':2}
    g.labels = ['a', 'b']
    g.states = ['c', 'd']
    g.start = 1
    g.async_keywords = True
    g_copy = g.copy()
    assert g_copy.symbol2number == g.symbol2number
   

# Generated at 2022-06-21 09:59:24.152599
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io
    from unittest import mock

    s2n = {'single_input': 256, 'file_input': 258, 'eval_input': 259}
    n2s = {256: 'single_input', 258: 'file_input', 259: 'eval_input'}
    states = [
        [(256, 260), (257, 259), (258, 262)]
    ]
    dfas = {
        256: ([[(0, 260), (1, 261), (0, 259)]], {256: 1, 257: 1, 258: 1})
    }
    labels = [
        (0, 'EMPTY'),
        (257, 'NEWLINE'),
        (256, 'single_input'),
        (258, 'file_input'),
        (259, 'eval_input'),
    ]

# Generated at 2022-06-21 09:59:35.883228
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.symbol2number = {'a': 1, 'b': 2}
    grammar.number2symbol = {1: 'a', 2: 'b'}
    grammar.states = [[(1, 2), (2, 3)], [(1, 4), (2, 5)]]
    grammar.dfas = {1: (grammar.states[0], {1: 1, 2: 1}),
                    2: (grammar.states[1], {1: 1, 2: 1})}
    grammar.labels = [(1, 'a'), (2, 'b')]
    grammar.start = 1
    grammar.keywords = {'a': 1, 'b': 2}
    grammar.tokens = {1: 1, 2: 2}


# Generated at 2022-06-21 09:59:39.053546
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    filename = tempfile.mktemp()
    g.dump(filename)
    g1 = Grammar()
    g1.load(filename)
    assert g == g1


# Generated at 2022-06-21 09:59:45.996373
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    assert token.NAME == 2
    assert token.RARROW == 85

    g = Grammar()

    g.symbol2number = {"test1": 1, "test2": 2, "test3": 3, "test4": 4}
    g.number2symbol = {1: "test1", 2: "test2", 3: "test3", 4: "test4"}
    g.states = [
        [
            [(1, 1), (2, 3), (3, 3)],
            [(2, 2), (3, 4)],
            [(1, 1), (2, 2), (3, 3), (4, 5)],
            [(1, 1), (2, 1), (3, 3)],
        ]
    ]

# Generated at 2022-06-21 09:59:49.915177
# Unit test for method load of class Grammar
def test_Grammar_load():

    try:
        os.remove('Grammar.pickle')
    except FileNotFoundError:
        pass

    from . import conv, pgen
    g = Grammar()
    g.load('Grammar.pickle')
    assert g.start == 256
    g.dump('Grammar.pickle')

# Generated at 2022-06-21 10:00:00.489095
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io
    import unittest

    # This class is used to capture the output of the report method
    # of the Grammar class
    class CaughtIO(io.StringIO):
        def __init__(self) -> None:
            io.StringIO.__init__(self)
            self.with_prefix = False

        def write(self, s: Text) -> int:
            if self.with_prefix:
                s = "    %s" % s
            else:
                self.with_prefix = True
            return io.StringIO.write(self, s)

    class GrammarTestCase(unittest.TestCase):

        def caught_output(self, f: Any, *args: Any, **kwds: Any) -> Text:
            stdout = sys.stdout

# Generated at 2022-06-21 10:00:08.925918
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    filename = os.path.join(os.path.dirname(__file__), "Grammar.pkl")
    with open(filename, "rb") as f:
        grammar_pkl = f.read()
    g = Grammar()
    g = g.loads(grammar_pkl)

# Generated at 2022-06-21 10:00:24.139716
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import copy

    g1 = Grammar()
    assert g1.name == 'Grammar'
    g2 = g1.copy()
    assert g1.name == 'Grammar'
    assert g2.name == 'Grammar'
    assert g1 == g2
    assert not (g1 is g2)
    g2.name = 'Grammar2'
    assert g1.name == 'Grammar'
    assert g2.name == 'Grammar2'
    assert g1 != g2
    g2 = copy.copy(g1)
    assert g1.name == 'Grammar'
    assert g2.name == 'Grammar'
    assert g1 == g2
    assert not (g1 is g2)
    g2.name = 'Grammar2'
   

# Generated at 2022-06-21 10:00:36.264570
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    gram = Grammar()
    gram.start = 257
    gram.symbol2number = {'a': 257, 'b': 258, 'c': 259}
    gram.number2symbol = {257: 'a', 258: 'b', 259: 'c'}
    gram.states = [[(0, 0)]]


# Generated at 2022-06-21 10:00:47.287604
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen2
    from . import parse

    g = pgen2.driver.load_grammar("Python.asdl")
    
    # we don't want to write to Python.asdl.pickle
    tmpdir = tempfile.TemporaryDirectory()
    tmpfile = os.path.join(tmpdir.name, "Grammar.pickle")
    
    g.dump(tmpfile)
    g2 = Grammar()
    g2.load(tmpfile)
    assert g2.number2symbol == g.number2symbol
    assert g2.symbol2number == g.symbol2number
    assert g2.dfas == g.dfas
    assert g2.keywords == g.keywords
    assert g2.tokens == g.tokens
    assert g2.sy

# Generated at 2022-06-21 10:00:48.620628
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    assert Grammar().__class__.__module__ == __name__

# Generated at 2022-06-21 10:00:59.880658
# Unit test for method report of class Grammar
def test_Grammar_report():
    # It's not nice to put data in the doctest
    g = Grammar()

# Generated at 2022-06-21 10:01:07.681754
# Unit test for method load of class Grammar
def test_Grammar_load():
    """
    Unit test for the method load of class Grammar.
    """
    import doctest
    import typing
    from .pgen2 import dump_grammar
    from .pgen2 import tokenize
    from .pgen2 import driver
    from .pgen2 import parse
    import os

    # Create temporary directory
    temp_dir: Text = tempfile.mkdtemp()
    print("Unit test for method load of class Grammar")
    print("  Temporary directory: {}".format(temp_dir))

    # Create string "hello world" in file "foo.py"
    file_path = os.path.join(temp_dir, "foo.py")
    file_handler = open(file_path, "w")
    file_handler.write("print('hello world')\n")
    file_handler.close()



# Generated at 2022-06-21 10:01:19.090564
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    grammar = Grammar()

# Generated at 2022-06-21 10:01:23.906514
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import tempfile
    import os

    # Pickle file is written by calling dump()
    g = Grammar()
    bfile = tempfile.NamedTemporaryFile()
    g.dump(bfile.name)
    assert os.path.isfile(bfile.name)
    bfile.close()
    # delete file
    os.remove(bfile.name)

# Generated at 2022-06-21 10:01:31.666582
# Unit test for method report of class Grammar
def test_Grammar_report():
    import os
    import tempfile
    import unittest
    from pgen2.pgen import tokenize
    from pgen2.pgen import driver

    class MockStdout(object):
        def __init__(self, lines: List[str]) -> None:
            self.lines = lines

        def write(self, s: Text) -> int:
            self.lines.append(s)
            return len(s)

        def __enter__(self) -> Any:
            return self

        def __exit__(self, type, value, traceback) -> None:
            pass

    class Test_Grammar_report(unittest.TestCase):
        def setUp(self) -> None:
            dirname = os.path.dirname(__file__)

# Generated at 2022-06-21 10:01:41.889552
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    pkl = b'\x80\x03cskylark_parsing.pgen_grammar\nGrammar\nq\x00)Rq\x01.'
    g.loads(pkl)
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-21 10:01:56.085692
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """
    Test Grammar.dump()
    """
    import sys

    filename = os.path.join(tempfile.gettempdir(), "grammar_dump.pickle")
    grammar = Grammar()
    grammar.dump(filename)

    from pickle import PickleError

    try:
        grammar.load(filename)
    except PickleError as err:
        # Python 3.2+ will raise an error for python_version < (3, 5)
        if sys.version_info < (3, 5):
            if sys.version_info < (3, 2):
                raise err
            else:
                # ignore error on python_version == (3, 2/3/4)
                pass
        else:
            raise err

# Generated at 2022-06-21 10:02:01.383383
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    with open('../Parser/rd_grammar.pkl', 'rb') as f:
        pkl = f.read()
    # Ensure that Grammar.loads works without a Grammar instance
    Grammar.loads(pkl)


# Generated at 2022-06-21 10:02:04.257689
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    g.number2symbol[1] = "a1"
    assert g.symbol2number["a1"] == 1



# Generated at 2022-06-21 10:02:08.794009
# Unit test for constructor of class Grammar
def test_Grammar():
    '''
    >>> Grammar()
    <Grammar object at 0x7f6c584a6e90>
    '''
    Grammar()

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 10:02:18.053702
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    def test(data: Any, filename: Path = "test.pkl") -> None:
        g = Grammar()
        g._update(data)
        g.dump(filename)
        g2 = Grammar()
        g2.load(filename)
        assert g2.__dict__ == g.__dict__

    # test a simple grammar

# Generated at 2022-06-21 10:02:29.472131
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = dict(a=1, b=2)

# Generated at 2022-06-21 10:02:32.649407
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("./Grammar.pickle")
    grammar.load("./Grammar-with-async.pickle")

# Generated at 2022-06-21 10:02:41.327611
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    original = Grammar()
    original.symbol2number = {"a": 1, "b": 2}
    original.number2symbol = {1: "a", 2: "b"}
    original.dfas = {1: None, 2: None}
    original.keywords = {"x": 1}
    original.tokens = {1: 1}
    original.symbol2label = {"y": 2}
    original.labels = [(1, "one"), (2, "two")]
    original.states = [(None, None), (None, None)]
    original.start = 3
    original.async_keywords = True

    copy = original.copy()


# Generated at 2022-06-21 10:02:53.060661
# Unit test for method report of class Grammar
def test_Grammar_report():
    class TestGrammar(Grammar):
        def __init__(self):
            self.symbol2number = {
                "&": 257,
                "*": 258,
                "[1]": 259,
                "**": 260,
                "+": 261,
                ",": 262,
                ":": 263,
                "-": 264,
                ".": 265,
                "/": 266,
                "<": 267,
                "=": 268,
            }

# Generated at 2022-06-21 10:02:59.784111
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    import marshal
    from .tokenize import generate_tokens

    def test_loads_helper(tokens):
        p = Grammar()
        p.loads(tokens)

    def test_loads_helper2():
        with open("Grammar.pickle", "rb") as f:
            tokens = f.read()
        test_loads_helper(tokens)

    # Generates bytecode in byteorder=little and byteorder=big
    def generate_tokens():
        g = Grammar()
        tokens = marshal.dumps(g.__getstate__())
        tokens_swapped = bytearray(tokens)
        for i in range(len(tokens_swapped) - 1, -1, -1):
            tokens_swapped[i] = tokens

# Generated at 2022-06-21 10:03:07.239898
# Unit test for constructor of class Grammar
def test_Grammar():
    assert Grammar()

# Generated at 2022-06-21 10:03:18.447844
# Unit test for constructor of class Grammar
def test_Grammar():
    def check(cond, msg):
        if not cond:
            print(msg)

    G = Grammar()

    assert G.symbol2number == {}
    assert G.number2symbol == {}
    assert G.states == []
    assert G.dfas == {}
    assert G.labels == [(0, "EMPTY")]
    assert G.keywords == {}
    assert G.tokens == {}
    assert G.symbol2label == {}
    assert G.start == 256

    G.symbol2number = {'foo': 1}
    G.number2symbol = {1: 'foo'}
    G.states = [1, 2, 3]
    G.dfas = {1: [1, 2, 3]}
    G.labels = [('foo', 1)]
    G.key

# Generated at 2022-06-21 10:03:19.950162
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump(tempfile.mktemp())

# Generated at 2022-06-21 10:03:32.529051
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    from .parser import Parser
    from .pgen2 import driver
    from .pgen2.pgen import generate_grammar

    modname = "test.grammar_copy"
    driver.make_grammar(modname, generate_grammar(), False, False)
    p = Parser(modname)
    assert p.grammar.symbol2number == p.grammar.copy().symbol2number
    assert p.grammar.number2symbol == p.grammar.copy().number2symbol
    assert p.grammar.dfas == p.grammar.copy().dfas
    assert p.grammar.keywords == p.grammar.copy().keywords
    assert p.grammar.tokens == p.grammar.copy().tokens
    assert p.grammar.symbol2label == p

# Generated at 2022-06-21 10:03:36.951190
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    f = tempfile.NamedTemporaryFile()
    g = Grammar()
    assert g.tokens == {}
    g.dump(f.name)
    g.load(f.name)
    # Reloading the grammar should not clear g.tokens
    assert g.tokens == {}


# Generated at 2022-06-21 10:03:37.855890
# Unit test for method report of class Grammar
def test_Grammar_report():
    grammar = Grammar()
    grammar.report()

# Generated at 2022-06-21 10:03:47.611974
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """
    Case:   dump grammar
    Expect: dump success
    """
    file_path = "./lib/tokenize_grammar.py"

    if not os.path.isfile(file_path):
        print("Unable to locate file %s\n" % file_path)
        return

    with open(file_path, "rb") as f:
        d = pickle.load(f)

    pkl = pickle.dumps(d, pickle.HIGHEST_PROTOCOL)

    with open("./tokenize_grammar.pkl", "wb") as f:
        f.write(pkl)

if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-21 10:03:52.771949
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    g.loads(b'ccopy_reg\n_reconstructor\np1\n(c_ast\nAST\np2\nc__builtin__\nobject\np3\nNtRp4\n.')

# Generated at 2022-06-21 10:04:03.492415
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io
    import sys

    # Test the method report of the class Grammar
    # This requires that pprint is present
    # Create a dummy Grammar
    _g = Grammar()
    _g.symbol2number = {
        "one": 1,
        "two": 2,
        "three": 3,
    }  # type: ignore
    _g.number2symbol = {
        1: "one",
        2: "two",
        3: "three",
    }  # type: ignore
    _g.dfas = {
        1: ([[(2, 1), (0, 2)]], {1: 2}),
        2: ([[(2, 3)], [(0, 4)]], {3: 2}),
    }

# Generated at 2022-06-21 10:04:15.018950
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # type: () -> None
    G = Grammar()

# Generated at 2022-06-21 10:04:28.565123
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.symbol2number = {'SYM1': 260, 'SYM2': 261}
    g.number2symbol = {260: 'SYM1', 261: 'SYM2'}
    g.states = [[[(1, 2)], [(3, 4)], [(5, 6)], [(7, 8)]]]
    g.dfas = {260: ([[(1, 2)], [(3, 4)], [(5, 6)], [(7, 8)]], {260: 1}), 261: ([[(9, 10)], [(11, 12)], [(13, 14)], [(15, 16), (17, 16)]] , {261: 1})}

# Generated at 2022-06-21 10:04:40.599940
# Unit test for method report of class Grammar
def test_Grammar_report():
    '''Unit test for method report of class Grammar.'''
    import io
    from . import pgen2
    from .conv import convert
    from . import pgen
    from .pgen2 import grammar
    from .pgen2 import token
    from .pgen2 import driver

    # Create a parse tree for the expression: '2 + 3' and verify that
    # its structure is as expected.
    test_expr = "1 + 2"
    tree = driver.parse_string(test_expr)
    assert tree
    assert len(tree.children) == 3
    assert tree.type == grammar.symbol2number['sum']
    assert tree.children[0].value == '1'
    assert tree.children[1].type == token.PLUS
    assert tree.children[2].value == '2'

    # Create a

# Generated at 2022-06-21 10:04:47.245853
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    # Check that a Grammar instance can dump() itself properly
    g.dump("/tmp/test.pickle")
    os.remove("/tmp/test.pickle")


if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1:
        for fn in sys.argv[1:]:
            Grammar().load(fn).report()

# Generated at 2022-06-21 10:04:57.937778
# Unit test for constructor of class Grammar
def test_Grammar():
    # Test class constructor Grammar
    import sys
    import os
    import tempfile
    from typing import Dict
    from pprint import pprint

    # Create a Grammar from load() method
    fd, fn = tempfile.mkstemp()
    os.close(fd)
    s2n: Dict[str, int] = {'i': 258, 'j': 259}
    n2s: Dict[int, str] = {258: 'i', 259: 'j'}
    states: List[DFA] = []
    dfa = [(256, 'EMPTY'), (1, 0)]
    states.append(dfa)

# Generated at 2022-06-21 10:05:01.215476
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2.pgen import driver

    driver.load_grammar('python2', 'Grammar.pickle')
    driver.load_grammar('python3', 'Grammar.pickle')


test_Grammar_load()

# Generated at 2022-06-21 10:05:13.381939
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    class Sub(Grammar):
        pass
    s = Sub()

# Generated at 2022-06-21 10:05:20.525299
# Unit test for constructor of class Grammar
def test_Grammar():
    a = lambda: None
    a.attr2 = 3
    b = lambda: None
    b.attr1 = 2
    b.attr3 = "hello"
    c = lambda: None
    c.attr1 = 1
    c.attr2 = "world"
    l = [a, b, c]
    l.sort(key=lambda x: (getattr(x, "attr1", None), getattr(x, "attr2", None)))
    assert l == [c, a, b]

# Generated at 2022-06-21 10:05:21.969897
# Unit test for constructor of class Grammar
def test_Grammar():
    assert Grammar().keywords == {}

# Generated at 2022-06-21 10:05:33.963021
# Unit test for method load of class Grammar
def test_Grammar_load():
    import os
    import sys
    import unittest

    from typing import Dict, List, Tuple

    from . import conv, pgen
    from .pgen2 import tokenize

    from . import token

    from .parse import ParseError

    class GrammarTest(unittest.TestCase):
        def test_load(self):
            # Check that grammar loading works

            # Set up paths to grammar definition files
            srcdir = os.path.dirname(__file__) or os.curdir
            if sys.version_info[:2] == (3, 6):
                grammar_name = "grammar36.txt"
            else:
                grammar_name = "grammar37.txt"
            grammar_path = os.path.join(srcdir, grammar_name)
            pickle_path = os.path

# Generated at 2022-06-21 10:05:36.758676
# Unit test for method load of class Grammar
def test_Grammar_load():
    """
    Check for grammar with async keyword.
    """
    gram = Grammar()
    gram.load('Grammar.pickle')
    assert gram.async_keywords, "Failure in load of Grammar"

# Generated at 2022-06-21 10:05:54.501548
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.symbol2number = {
        "foo": 256,
        "bar": 257,
        "baz": 258,
    }
    g.number2symbol = {
        256: "foo",
        257: "bar",
        258: "baz",
    }
    g.states = [
        [
            ((4, 256), 1),
            ((1, 257), 2),
            ((0, 2), 2),
            ((1, 257), 3),
            ((1, 258), 3),
            ((0, 3), 3),
        ],
        [((1, 257), 2), ((1, 258), 2), ((0, 2), 2)],
        [((1, 257), 3), ((1, 258), 3), ((0, 3), 3)],
    ]
    g

# Generated at 2022-06-21 10:05:59.071527
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    grammar = Grammar()
    grammar.loads(b'\x80\x03}q\x00.')


# Generated at 2022-06-21 10:06:02.319890
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    class DerivedGrammar(Grammar):
        pass

    g = Grammar()
    assert isinstance(g.copy(), Grammar)
    d = DerivedGrammar()
    assert isinstance(d.copy(), DerivedGrammar)

# Generated at 2022-06-21 10:06:05.127192
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    for pickle_protocol in range(1, pickle.HIGHEST_PROTOCOL + 1):
        m = Grammar()
        m.dump("Grammar_dump.pickle", pickle_protocol)

# Generated at 2022-06-21 10:06:13.306056
# Unit test for method load of class Grammar
def test_Grammar_load():
    path = "${TESTDIR}/Grammar/Grammar_load"
    grammar = Grammar()
    grammar.load(path)
    assert grammar.symbol2number == {'test': 258}
    assert grammar.number2symbol == {258: 'test'}
    assert grammar.states == [[[(1,1),(65,2)],[(0,2)]]]

# Generated at 2022-06-21 10:06:25.143703
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2.parser import Driver
    from .pgen2 import tokenize
    import io

    # Driver creates empty Grammar instance.
    driver = Driver()
    assert driver.grammar.symbol2number == {}

    # Test dumping and loading Grammar instance.
    driver.grammar.symbol2number = {"AAP": 1, "Noot": 2}
    with io.BytesIO() as f:
        driver.grammar.dump(f)
        g = Grammar()
        g.loads(f.getvalue())
    assert g.symbol2number == {"AAP": 1, "Noot": 2}

    # Test comparing Grammar instances created by Driver.
    assert driver.grammar.symbol2number == g.symbol2number

    # Test parsing simple source file.
    driver.parse_tok

# Generated at 2022-06-21 10:06:31.771888
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Create a Grammar instance and set its attribute 'start' to 256
    g = Grammar()
    g.start = 256
    # Call the dump method of class Grammar with a temporary file
    with tempfile.NamedTemporaryFile() as f:
        g.dump(f.name)
        g2 = Grammar()
        g2.load(f.name)
        assert g2.start == 256

# Generated at 2022-06-21 10:06:37.874994
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256


# Generated at 2022-06-21 10:06:50.548644
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    s = "Grammar copy"
    g = Grammar()
    g.symbol2number = {"A": 1}
    g.number2symbol = {1: "A"}
    g.states = ["A"]
    g.dfas = {1: (["A"], {"A": 1})}
    g.labels = [(1, "A")]
    g.keywords = {"A": 1}
    g.tokens = {"A": 1}
    g.symbol2label = {"A": 1}
    g.start = "A"
    g.async_keywords = True

    g_copy = g.copy()
    assert g_copy is not g
    assert g_copy.symbol2number == g.symbol2number
    assert g_copy.number2symbol == g.number

# Generated at 2022-06-21 10:07:03.428866
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    from . import parsetok, tokenizer

    def _tokens():
        test_tokens = [token.NAME, token.NAME, token.NAME,
                       token.NEWLINE, token.NEWLINE, token.NEWLINE]
        for i, _ in enumerate(test_tokens):
            yield i, test_tokens[i]

    g = Grammar()
    g.number2symbol = parsetok.token_to_symbol

# Generated at 2022-06-21 10:07:33.082440
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    cwd = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(cwd, 'test', 'input', 'Grammar_test.pickle')
    g = Grammar()
    g.load(path)
    h = g.copy()
    assert(g.keywords == h.keywords)
    assert(g.labels == h.labels)
    assert(g.number2symbol == h.number2symbol)
    assert(g.symbol2label == h.symbol2label)
    assert(g.symbol2number == h.symbol2number)
    assert(g.tokens == h.tokens)

if __name__ == "__main__":
    import sys


# Generated at 2022-06-21 10:07:45.145839
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io
    from contextlib import redirect_stdout

    from . import pgen2

    def capture_Grammar_report(grammar):
        f = io.StringIO()
        with redirect_stdout(f):
            grammar.report()
        return f.getvalue()

    grammar = pgen2.driver.load_grammar("Grammar/Grammar")

# Generated at 2022-06-21 10:07:46.660773
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    test_Logging_Grammar_loads(Grammar)



# Generated at 2022-06-21 10:07:51.857284
# Unit test for method report of class Grammar
def test_Grammar_report():
    """Unit test for method report of class Grammar."""
    import unittest
    import sys

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self._out_ = sys.stdout
            sys.stdout = self._output = []  # type: ignore

        def tearDown(self):
            sys.stdout = self._out_

        def test_report(self):
            g = Grammar()
            g.report()
            self.assertGreater(len(self._output), 0)  # type: ignore

    unittest.main()

# Generated at 2022-06-21 10:08:01.525951
# Unit test for constructor of class Grammar
def test_Grammar():
    # Make sure that the table of operator-to-token-code mappings is
    # complete
    assert len(opmap) == token.NUM_OPERATORS

    # Make sure that the inverse mappings are correct
    assert token.NUM_TOKENS == len(set(token.tok_name.values()))
    for x in range(token.NUM_TOKENS + token.NUM_OPERATORS):
        op = token.tok_name[x]
        if op.endswith("EQUAL"):
            assert op[:-len("EQUAL")] == token.tok_name[opmap[op[:-len("EQUAL")]]]

# Generated at 2022-06-21 10:08:10.883248
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # ensure method dump of class Grammar does not modify the grammar object
    from . import grammar
    from .pgen2 import tokenize

    # load test grammar
    _test_grammar = grammar.Grammar()
    _test_grammar.load(tokenize.__file__.rstrip("c"))
    # save test grammar
    _test_grammar.dump(tokenize.__file__.rstrip("c") + "2")
    # reload test grammar
    _test_grammar_2 = grammar.Grammar()
    _test_grammar_2.load(tokenize.__file__.rstrip("c") + "2")

    # check test grammar and reloaded test grammar are equal
    assert _test_grammar.symbol2number == _test_grammar_2.symbol2number
    assert _test

# Generated at 2022-06-21 10:08:21.290153
# Unit test for method loads of class Grammar

# Generated at 2022-06-21 10:08:30.330172
# Unit test for method load of class Grammar
def test_Grammar_load():
    def _check(s, name, value):
        if s.__dict__[name] != value:
            raise AssertionError(name)

    s = Grammar()
    data = Grammar()
    data.keywords = {b'a': 1, b'b': 2, b'c': 3}
    data.labels = [(0, "EMPTY"), (1, None), (2, "as"), (3, "def")]
    data.start = 256
    data.states = [[(0, 6), (3, 2), (2, 3), (3, 1)], [(0, 3), (3, 4), (3, 5)]]
    data.symbol2number = {b'a': 258, b'b': 259}

# Generated at 2022-06-21 10:08:33.958260
# Unit test for constructor of class Grammar
def test_Grammar():
    grammar = Grammar()
    assert grammar.symbol2number == {}
    assert grammar.number2symbol == {}
    assert grammar.states == []
    assert grammar.dfas == {}
    assert grammar.start == 256
    assert grammar.async_keywords == False

# Generated at 2022-06-21 10:08:41.003632
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # Test loads
    g = Grammar()