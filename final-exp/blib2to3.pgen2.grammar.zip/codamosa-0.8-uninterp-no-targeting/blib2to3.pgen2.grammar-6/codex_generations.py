

# Generated at 2022-06-21 09:58:35.321073
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()

    # check all instance variable

# Generated at 2022-06-21 09:58:43.303556
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    this = Grammar()
    this.a = 1
    this.b = 2
    this.c = [1, 2, 3]
    this.d = (1, 2, 3)
    that = this.copy()
    assert this.a == 1
    assert this.b == 2
    assert this.c == [1, 2, 3]
    assert this.d == (1, 2, 3)
    assert that.a == 1
    assert that.b == 2
    assert that.c == [1, 2, 3]
    assert that.d == (1, 2, 3)
    this.a = 10
    this.b = 20
    this.c.append(4)
    this.d += (4,)
    assert this.a == 10
    assert this.b == 20

# Generated at 2022-06-21 09:58:54.878065
# Unit test for method loads of class Grammar

# Generated at 2022-06-21 09:59:06.723179
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-21 09:59:13.058395
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import pickle
    import tokenize

    class MyGrammar(Grammar):
        def __init__(self):
            super().__init__()
            self.symbol2number = {"my_symbol": 1, "your_symbol": 2}
            self.number2symbol = {"1": "my_symbol", "2": "your_symbol"}
            self.states = [[[0,"2"]],[]]
            self.dfas = {"1":[[0,"2"]], "2":[[0,"2"]]}
            self.labels = [(0,"EMPTY"), (1,"my_symbol"), (2,"your_symbol")]
            self.keywords = {"my_keyword": 1, "your_keyword": 2}

# Generated at 2022-06-21 09:59:24.245015
# Unit test for method report of class Grammar
def test_Grammar_report():
    dfa1 = [
        [(1, 1), (2, 2)],
        [(3, 3)],
        [(4, 4)],
        [(5, 5)],
        [(6, 6)],
        [],
    ]
    labels1 = [
        (256, "symbol"),
        (257, "symbol"),
        (258, "symbol"),
        (259, "symbol"),
        (260, "symbol"),
        (261, "symbol"),
    ]
    dfas1 = {256: (dfa1, {257: 1, 258: 1, 259: 1, 260: 1, 261: 1})}
    s2n1 = {
        "symbol": 256,
    }
    n2s1 = {
        256: "symbol",
    }
    states1

# Generated at 2022-06-21 09:59:35.974456
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.number2symbol = {
        0: "EMPTY",
        1: "test",
        2: "test2",
        3: "test3",
        4: "test4",
        5: "test5",
        6: "test6",
        7: "test7",
        256: "START",
    }
    g.symbol2number = {symbol: number for number, symbol in g.number2symbol.items()}

# Generated at 2022-06-21 09:59:40.187241
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    def get_symbol2number(g: Grammar) -> Dict[str, int]:
        return g.symbol2number

    grammar = Grammar()
    grammar.symbol2number = {"alpha": 4, "beta": 3}
    new_grammar = grammar.copy()

    assert new_grammar.symbol2number == {"alpha": 4, "beta": 3}
    assert get_symbol2number(grammar) == {"alpha": 4, "beta": 3}

    grammar.symbol2number["alpha"] = 5
    assert grammar.symbol2number == {"alpha": 5, "beta": 3}
    assert get_symbol2number(grammar) == {"alpha": 5, "beta": 3}
    assert new_grammar.symbol2number == {"alpha": 4, "beta": 3}
    assert get

# Generated at 2022-06-21 09:59:43.080700
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert isinstance(g.symbol2number, dict)
    assert isinstance(g.number2symbol, dict)
    assert isinstance(g.states, list)
    assert isinstance(g.dfas, dict)
    assert isinstance(g.labels, list)
    assert isinstance(g.keywords, dict)
    assert isinstance(g.tokens, dict)
    assert isinstance(g.symbol2label, dict)
    assert isinstance(g.start, int)

# Generated at 2022-06-21 09:59:51.414739
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    import marshal

    # The setuptools console_scripts entry point "2to3" uses 2to3.main.main
    # which uses lib2to3.pgen2.parse() which will call
    # lib2to3.pgen2.driver.load_grammar() which will call Grammar.loads()
    # That function calls marshal.loads() on the bytes loaded from a file.
    # If marshal.loads() is called with an empty list, it will segfault.
    # This test ensures that this bug is not reintroduced.
    g = Grammar()
    g.loads(marshal.dumps([]))

# Generated at 2022-06-21 10:00:05.017488
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    """Exercise method Grammar.loads."""
    import io, zlib

    # A string holding the pickled dictionary that __getstate__ would make.

# Generated at 2022-06-21 10:00:10.597589
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    gram = Grammar()
    newgram = gram.copy()
    assert gram.symbol2number == newgram.symbol2number
    assert gram.number2symbol == newgram.number2symbol
    assert gram.dfas == newgram.dfas
    assert gram.keywords == newgram.keywords
    assert gram.tokens == newgram.tokens
    assert gram.symbol2label == newgram.symbol2label
    assert gram.labels == newgram.labels
    assert gram.states == newgram.states
    assert gram.start == newgram.start
    assert gram.async_keywords == newgram.async_keywords

# Generated at 2022-06-21 10:00:15.637357
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    import io
    grammar = Grammar()
    grammar.loads(io.BytesIO(b"""cos
system
1
2
""").read())
    assert grammar.symbol2number == {'cos': 257, 'system': 258}
    assert grammar.number2symbol == {258: 'system', 257: 'cos'}

# Generated at 2022-06-21 10:00:25.440527
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    g.symbol2number = {'exprlist': 261, 'subscript': 274, 'suite': 288}
    g.number2symbol = {261: 'exprlist', 274: 'subscript', 288: 'suite'}

# Generated at 2022-06-21 10:00:28.328402
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()

# Generated at 2022-06-21 10:00:37.763244
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {"A": 10}
    g.number2symbol = {"B": 20}
    g.dfas = {"C": (DFA(), {"D": 30})}
    g.keywords = {"E": 40}
    g.tokens = {"F": 50}
    g.symbol2label = {"G": 60}
    g.labels = [(70,"H")]
    g.states = [DFA()]
    g.start = 80
    g.async_keywords = True

    h = g.copy()
    assert g.symbol2number is not h.symbol2number
    assert g.number2symbol is not h.number2symbol
    assert g.dfas is not h.dfas

# Generated at 2022-06-21 10:00:48.582640
# Unit test for method loads of class Grammar
def test_Grammar_loads():  # type: ignore
    G = Grammar()

# Generated at 2022-06-21 10:00:59.781625
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import unittest

    class TestGrammarTestCase(unittest.TestCase):
        def test_full(self):
            grammar = Grammar()

# Generated at 2022-06-21 10:01:07.638241
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number["a"] = 1
    g.symbol2number["b"] = 2
    g.symbol2number["c"] = 3
    g.number2symbol[1] = "a"
    g.number2symbol[2] = "b"
    g.number2symbol[3] = "c"
    g.dfas[1] = ([1, 2, 3], {1: 1, 2: 2, 3: 3})
    g.keywords["abc"] = 1
    g.tokens[1] = 2
    g.symbol2label["d"] = 3
    g.labels.append("a")
    g.labels.append("b")
    g.labels.append("c")

# Generated at 2022-06-21 10:01:09.395237
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    f = Grammar()
    f.dump(tempfile.NamedTemporaryFile().name)

# Generated at 2022-06-21 10:01:23.949336
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    gr = Grammar()
    new_gr = gr.copy()
    assert new_gr is not gr
    for dict_attr in ('symbol2number', 'number2symbol', 'dfas', 'keywords',
                      'tokens', 'symbol2label'):
        nd = getattr(new_gr, dict_attr)
        assert nd.copy() == getattr(gr, dict_attr)
    assert new_gr.labels == gr.labels
    assert new_gr.states == gr.states


if __name__ == "__main__":
    gr = Grammar()
    gr.load("Grammar.pkl")
    gr.report()

# Generated at 2022-06-21 10:01:31.694282
# Unit test for constructor of class Grammar
def test_Grammar():
    g1 = Grammar()
    g1.symbol2number = {'foo': 1, 'bar': 2}
    g1.number2symbol = {1: 'foo', 2: 'bar'}
    g1.states = [[[(1, 0)]]]
    g1.dfas = {0: ([[(1, 0)]], {0: 1}), 1: ([[(1, 0)]], {0: 1})}
    g1.labels = [(0, 'EMPTY'), (1, None)]
    g1.start = 256
    g1.keywords = {'y': 1}
    g1.tokens = {1: 1}
    g1.symbol2label = {'x': 1}
    g2 = g1.copy()
    assert g1.symbol2number

# Generated at 2022-06-21 10:01:33.786419
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    #The method is tested by parsing_test
    assert True


# Generated at 2022-06-21 10:01:44.749090
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    gr: Grammar = Grammar()
    gr.dfas = {0: ([[], [(259, 1), (260, 2)]], {0: 0, 1: 1, 2: 2})}
    gr.keywords = {"if": 259, "for": 260}
    gr.labels = [(1, None), (2, None)]
    gr.number2symbol = {0: "Nonterminal"}
    gr.start = 0
    gr.states = [[[(1, 2), (0, 0)]]]
    gr.symbol2label = {None: 0, "Nonterminal": 0}
    gr.symbol2number = {"Nonterminal": 0}
    gr.tokens = {0: 0, 259: 1, 260: 2}
    filename = "test/support/parse_grammar/test"

# Generated at 2022-06-21 10:01:49.305017
# Unit test for method load of class Grammar
def test_Grammar_load():
    # The load method should accept bytes object
    g = Grammar()
    d = g.__dict__
    pickled_d = pickle.dumps(d, pickle.HIGHEST_PROTOCOL)
    g.loads(pickled_d)


test_Grammar_load()

# Generated at 2022-06-21 10:01:57.306994
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import types
    import pickle

    dirname = os.path.dirname(__file__)
    filename = os.path.join(dirname, "Grammar.dump")

    if os.path.exists(filename):
        f = open(filename, "rb")
        data = f.read()
        f.close()
        G = Grammar()
        G.loads(data)
        G1 = Grammar()
        G1.load(filename)
    else:
        G = Grammar()
        G.dump(filename)
        G1 = Grammar()
        G1.load(filename)

    assert isinstance(G, types.ModuleType)
    assert isinstance(G1, types.ModuleType)
    assert G == G1

# Generated at 2022-06-21 10:02:00.859941
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()

if __name__ == "__main__":
    test_Grammar_report()

# Generated at 2022-06-21 10:02:12.554582
# Unit test for method report of class Grammar
def test_Grammar_report():
    # a toy grammar.
    g = Grammar()
    g.symbol2number = {"'a'": 257, "'b'": 258, "S": 259}
    g.number2symbol = {v: k for k, v in g.symbol2number.items()}
    g.dfas = {
        257: ([[(1, 1)]], {"EMPTY": 1}),
        258: ([[(2, 1)]], {"EMPTY": 1}),
        259: ([[(0, 1), (3, 2)], [(0, 2)]], {"EMPTY": 1}),
    }
    g.states = g.dfas.values()
    g.labels = [(0, "EMPTY"), (257, None), (258, None), (259, None)]
    g.start = 259
    g

# Generated at 2022-06-21 10:02:17.074459
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.tokens = {"a": "Z"}

    # test with a temporary file
    with tempfile.NamedTemporaryFile() as f:
        g.dump(f.name)
        with open(f.name, "rb") as file2:
            d = pickle.load(file2)
        assert d == g.__dict__

# Generated at 2022-06-21 10:02:28.214517
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert isinstance(g.symbol2number, dict)
    # assert isinstance(g.number2symbol, dict)
    assert isinstance(g.states, list)
    assert isinstance(g.dfas, dict)
    assert isinstance(g.labels, list)
    assert g.labels == [(0, "EMPTY")]
    assert isinstance(g.keywords, dict)
    assert g.keywords == {}
    assert isinstance(g.tokens, dict)
    assert g.tokens == {}
    assert isinstance(g.symbol2label, dict)
    assert g.symbol2label == {}
    assert isinstance(g.start, int)
    assert isinstance(g.async_keywords, bool)

# Generated at 2022-06-21 10:02:41.419414
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    from .conv import pgen

    g = Grammar()

# Generated at 2022-06-21 10:02:51.411321
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()
    g.start = 'start'
    g.states = ['state']
    g.symbol2number = {'key': 'value'}
    g.number2symbol = {'1': 'one'}
    g.dfas = {'key': 'value'}
    g.labels = [('key', 'value')]
    g.keywords = {'key': 'value'}
    g.tokens = {'key': 'value'}
    g.report()


if __name__ == "__main__":
    test_Grammar_report()

# Generated at 2022-06-21 10:02:56.011494
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()

    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert not g.async_keywords

# Generated at 2022-06-21 10:03:05.954248
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    h = g.copy()
    assert g.symbol2number == h.symbol2number
    assert g.number2symbol == h.number2symbol
    assert g.dfas == h.dfas
    assert g.keywords == h.keywords
    assert g.tokens == h.tokens
    assert g.symbol2label == h.symbol2label
    assert g.labels is not h.labels
    assert g.states is not h.states
    assert g.start == h.start
    assert g.async_keywords is h.async_keywords


if __name__ == "__main__":
    # Run a unit test
    test_Grammar_copy()

# Generated at 2022-06-21 10:03:15.670992
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    from . import pgen2

    p = pgen2.pgen(pgen2.grammar)
    q = p.copy()
    assert q.number2symbol == p.number2symbol
    assert q.symbol2number == p.symbol2number
    assert q.dfas == p.dfas
    assert q.keywords == p.keywords
    assert q.tokens == p.tokens
    assert q.symbol2label == p.symbol2label
    assert q.labels == p.labels
    assert q.states == p.states
    assert q.start == p.start

# Generated at 2022-06-21 10:03:18.204004
# Unit test for constructor of class Grammar
def test_Grammar():
    gr = Grammar()
    gr.report()

if __name__ == "__main__":
    test_Grammar()

# Generated at 2022-06-21 10:03:30.836634
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()

# Generated at 2022-06-21 10:03:41.511954
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()

# Generated at 2022-06-21 10:03:44.068368
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("./Grammar.txt")
    grammar.report()


# Generated at 2022-06-21 10:03:48.340251
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()

    # Test pkl loading from a file
    file_path = os.path.join(os.path.dirname(__file__), "grammar.pkl")
    grammar.load(file_path)

    # Test pkl loading from a bytes object
    with open(file_path, "rb") as f:
        pkl = f.read()
    grammar.loads(pkl)

# Generated at 2022-06-21 10:04:00.951130
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    from pygram.python import PythonGrammar

    class TestGrammar_load(unittest.TestCase):
        def test_load(self):
            g = PythonGrammar()
            g.load()

# Generated at 2022-06-21 10:04:02.059188
# Unit test for constructor of class Grammar
def test_Grammar():
    assert Grammar()



# Generated at 2022-06-21 10:04:07.647997
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    from pickle import dumps

    g = Grammar()
    assert g.dfas == {}
    g.loads(dumps({'dfas': {1: ([[(1, 2), (3, 1)]], {2: 1, 3: 2}), 2: ([[(3, 1)]], {3: 1})}}))
    assert g.dfas == {1: ([[(1, 2), (3, 1)]], {2: 1, 3: 2}), 2: ([[(3, 1)]], {3: 1})}

# Generated at 2022-06-21 10:04:10.467459
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    file_name = "test"
    grammar.dump(file_name)
    assert os.path.isfile(file_name)
    os.remove(file_name)

# Generated at 2022-06-21 10:04:15.496832
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    path = "urllib/parser/__dump.pickle"
    try:
        g.dump(path)
    except OSError:
        pass
    else:
        os.remove(path)

# Generated at 2022-06-21 10:04:23.209972
# Unit test for method load of class Grammar
def test_Grammar_load():
    gr = Grammar()
    assert gr.symbol2number == {}
    assert gr.number2symbol == {}
    assert gr.states == []
    assert gr.dfas == {}
    assert gr.labels == [(0, "EMPTY")]
    assert gr.keywords == {}
    assert gr.tokens == {}
    assert gr.symbol2label == {}
    assert gr.start == 256
    assert gr.async_keywords is False


# Generated at 2022-06-21 10:04:29.721667
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    gr: Grammar = Grammar()
    file = "test"
    def func(self, filename: Path) -> None:
        f = open(filename, "w")
        f.write("test")
        f.close()

    try:
        Grammar.dump = func
        gr.dump(file)
        f = open(file, "r")
        assert f.read() == "test"
        f.close()
    finally:
        os.remove(file)


# Generated at 2022-06-21 10:04:41.461580
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest.mock
    for mode in ("wb", "rb"):
        with unittest.mock.patch("pickle.dump") as mock_dump:
            with unittest.mock.patch("pickle.load") as mock_load:
                mock_load.return_value = {'a': 1}
                grammar = Grammar()
                grammar.load("a-filename")
                mock_load.assert_called_once()
                assert grammar.a == 1

        with unittest.mock.patch("tempfile.NamedTemporaryFile") as mock_tempfile:
            mock_tempfile.return_value.__enter__.return_value = unittest.mock.Mock(
                delete=False, name="a-tempname"
            )

# Generated at 2022-06-21 10:04:51.536848
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest.mock as mock

    gram = Grammar()
    gram.symbol2number = {"x": 1, "y": 2}
    gram.number2symbol = {1: "x", 2: "y"}
    gram.states = [
        [
            [(0, 1), (1, 2)],
            [(0, 3)],
            [(0, 4)],
            [],
            [],
        ]
    ]
    gram.dfas = {1: (gram.states[0], {"a": 1}), 2: ([[(0, 4)]], {"a": 1})}
    gram.labels = [(0, "EMPTY"), (1, None), (2, "a")]
    gram.keywords = {"a": 2}
    gram.tokens = {1: 1}

# Generated at 2022-06-21 10:04:56.682962
# Unit test for method report of class Grammar
def test_Grammar_report():
    import unittest

    class GrammarReportTest(unittest.TestCase):
        def test_report(self):
            g = Grammar()
            g.report()

    unittest.main()


if __name__ == "__main__":
    test_Grammar_report()

# Generated at 2022-06-21 10:05:18.058869
# Unit test for method report of class Grammar
def test_Grammar_report():
    from . import token as token_

    g = Grammar()
    assert g.report() is None
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords == False
    assert g.dump() is None
    assert g.load() is None
    assert g.loads(bytes()) is None
    assert isinstance(g.copy(), Grammar)

    assert token_.ISNONTERMINAL <= 255
    assert token_.ISEOF == 256

# Generated at 2022-06-21 10:05:23.613657
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert isinstance(g, Grammar)
    assert 'symbol2number' in dir(g)
    assert 'number2symbol' in dir(g)
    assert 'states' in dir(g)
    assert 'dfas' in dir(g)
    assert 'labels' in dir(g)
    assert 'keywords' in dir(g)
    assert 'tokens' in dir(g)

# Generated at 2022-06-21 10:05:35.250380
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import pickle
    import tempfile
    import py_compile
    import doctest  # For example of Grammar.dump() usage.

    def _remove(filename):
        try:
            os.remove(filename)
        except OSError:
            pass

    def get_pickle_name(filename):
        name, ext = os.path.splitext(filename)
        return name + ".pickle"

    # Grammar.dump (and pickle) are misleading when used on
    # class instances.  This test doesn't correctly demonstrate
    # the problem.
    class A:
        def __init__(self):
            self.data = 12

    with tempfile.NamedTemporaryFile(suffix=".py") as f:
        f.write(b"data = 42\n")
       

# Generated at 2022-06-21 10:05:37.838056
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.a = []
    g.b = Grammar()
    g.b.c = []
    gg = g.copy()
    assert gg is not g
    assert gg.a is not g.a
    assert gg.b is not g.b
    assert gg.b.c is not g.b.c

# Generated at 2022-06-21 10:05:41.762928
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from ..pgen2 import driver

    g = Grammar()
    driver.load_grammar("Grammar.txt", g)
    tmp_pickle_file = tempfile.NamedTemporaryFile()
    g.dump(tmp_pickle_file.name)
    tmp_pickle_file.file.close()

# Generated at 2022-06-21 10:05:50.905366
# Unit test for method report of class Grammar
def test_Grammar_report():
    from . import pgen2 as pgen2
    from . import pgen2_gen as pgen2_gen

    f = tempfile.NamedTemporaryFile()
    gen = pgen2_gen.Generator("./Grammar.txt", f.name, None)
    pgen = pgen2.Pgen(f.name)

    # pgen.states, pgen.dfas, pgen.labels, pgen.keywords, pgen.symbol2label, pgen.symbol2number, pgen.number2symbol, pgen.start = gen.generate_tables()
    pgen.load()
    pgen.report()

if __name__ == "__main__":
    test_Grammar_report()

# Generated at 2022-06-21 10:05:51.446212
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()

# Generated at 2022-06-21 10:05:53.751273
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    g.loads(b"cnumpy\n")
    assert g == Grammar()

if __name__ == "__main__":
    test_Grammar_loads()

# Generated at 2022-06-21 10:06:00.556187
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import grammar

    g = grammar.Grammar()
    g.load(g._grammar_file)
    assert g.start == 257
    assert g.keywords["and"] == 258
    assert g.symbol2number["and_expr"] == 258
    assert g.number2symbol[258] == "and_expr"

# Generated at 2022-06-21 10:06:07.507628
# Unit test for method report of class Grammar
def test_Grammar_report():
    grammar = Grammar()
    grammar.states = [[{}]]
    old_stdout = sys.stdout
    try:
        out = StringIO()
        sys.stdout = out
        grammar.report()
        assert out.getvalue() == "s2n\n{}\nn2s\n{}\nstates\n[[{{}}]]\ndfas\n{}\nlabels\n[(0, 'EMPTY')]\nstart 256\n"
    finally:
        sys.stdout = old_stdout

# Generated at 2022-06-21 10:06:38.425512
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    def removeINDENT(lst):
        """Return a list with INDENT tokens removed.

        This list is a minimal representation of an identical parse tree to
        make testing easier.

        """
        return [
            x for x in lst if not isinstance(x, token.INDENT) and not isinstance(x, str)
        ]

    g = Grammar()

# Generated at 2022-06-21 10:06:50.909553
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Test Grammar.load() with a minimal grammar.
    """

    from .pgen2 import tokenize, driver

    g0 = driver.load_grammar()

    g1 = Grammar()
    g1.loads(pickle.dumps(g0))

    class MyParser(object):
        def __init__(self, grammar=None) -> None:
            if grammar is None:
                grammar = Grammar()

            self.grammar = grammar
            self.reset()

        def reset(self) -> None:
            self.type = None  # type: token.Token
            self.value = None  # type: object
            self.lineno = 0
            self.level = 0  # Nesting level (access to nested scopes)
            self.num_tokens = 0  # Token number of this token
           

# Generated at 2022-06-21 10:07:03.810881
# Unit test for method load of class Grammar
def test_Grammar_load():
    import tempfile
    import pickle
    import os
    import shutil

    g = Grammar()
    g.symbol2number = {"a":1,"b":2}
    g.number2symbol = {1:"a",2:"b"}
    g.states = [[[(1,1),(2,1)],[(3,1)]]]
    g.dfas = {1:([[(1,1),(2,1)],[(3,1)]],{1:1}),2:([[(1,2),(2,2)],[(3,2)]],{1:1})}
    g.labels = [(0,"EMPTY")]
    g.keywords = {"if":1,"for":2,"break":3}

# Generated at 2022-06-21 10:07:08.097848
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    parser_pickle_path = os.path.join(
        os.path.dirname(__file__), os.pardir, "bin", "parser.pkl"
    )
    with open(parser_pickle_path, "rb") as f:
        pkl = f.read()

    parser = Grammar()
    parser.loads(pkl)

# Generated at 2022-06-21 10:07:19.040980
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io
    from pprint import pprint
    from .conv import parse_grammar
    from .pgen2 import tokenize

    def _compare_output(s1: str, s2: str) -> None:
        lines1 = [i.rstrip(" ") for i in s1.split("\n")]
        lines2 = [i.rstrip(" ") for i in s2.split("\n")]
        if lines1 != lines2:
            print("\n".join(["[%d]\n%s\n%s" % (i, s1, s2) for (i, (s1, s2)) in enumerate(zip(lines1, lines2)) if s1 != s2]))
        assert lines1 == lines2


# Generated at 2022-06-21 10:07:21.460141
# Unit test for method load of class Grammar
def test_Grammar_load():
    gram = Grammar()
    gram.load("python.gram")
    assert len(gram.symbol2number) == 259
    assert gram.start == 261



# Generated at 2022-06-21 10:07:23.851148
# Unit test for method load of class Grammar
def test_Grammar_load():
    g0 = Grammar()
    s = "".encode("utf-8")
    g0.load(s)

# Generated at 2022-06-21 10:07:25.695129
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()


del opmap_raw

# Generated at 2022-06-21 10:07:34.383728
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import sys
    from . import pgen2

    p = pgen2.driver.load_grammar()
    # Override 'async' if not present
    if sys.version_info < (3, 5):
        p.async_keywords = True
    new = p.copy()

    assert new.async_keywords == p.async_keywords

    for dict_attr in (
        "symbol2number",
        "number2symbol",
        "dfas",
        "keywords",
        "tokens",
        "symbol2label",
    ):
        assert getattr(new, dict_attr) == getattr(p, dict_attr)
    assert new.labels == p.labels
    assert new.states == p.states
    assert new.start == p.start

# Generated at 2022-06-21 10:07:46.824446
# Unit test for method report of class Grammar
def test_Grammar_report():
    class M(object):
        def __init__(self):
            self.foo = "bar"

    g = Grammar()
    g.symbol2number = dict(a = 1, b = 2)
    g.number2symbol = dict(a = 2, b = 2)
    g.states = [[dict(a = 1), dict(b = 1)], [dict(a = 1), dict(b = 1)]]
    g.dfas = dict(a = (1, 1), b = (2, 2))
    g.labels = [(1, "a"), (2, "b")]
    g.start = 3
    g.keywords = dict(foo = 1, bar = 2)
    g.tokens = dict(foo = 1, bar = 2)