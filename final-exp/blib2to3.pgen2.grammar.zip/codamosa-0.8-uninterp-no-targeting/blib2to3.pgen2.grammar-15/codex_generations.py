

# Generated at 2022-06-21 09:58:49.976364
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    # test that two grammars returned by Grammar.copy()
    # contain the same data
    g1 = Grammar()
    g2 = g1.copy()
    assert vars(g1) == vars(g2)

# Generated at 2022-06-21 09:59:02.258954
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.start = 1
    g.dfas = {1: (
        [(1, 2)],
        {2: 3}
    )}
    g.symbol2number = {'a': 1}
    g.number2symbol = {1: 'a'}
    g.keywords = {'True': 1}
    g.tokens = {1: 2}
    g.labels = [(1, 'True'), (2, None)]

    actual = "\n".join(g.report().split("\n")[4:9])  # Ignore frame info
    expect = """dfas
{1: ([(1, 2)], {2: 3})}
labels
[(1, 'True'), (2, None)]
start 1
"""

# Generated at 2022-06-21 09:59:10.874462
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    class Dummy:
        def __init__(self):
            self.symbol2number = {"number_1": 1, "number_2": 2}
            self.number2symbol = {"1": "symbol_1", "2": "symbol_2"}
            self.states = [[[(0, 1)], [(0, 2)]], [[(0, 3)], [(0, 4)]]]
            self.dfas = {1: (1, {}), 2: (0, {})}
            self.labels = [(0, "EMPTY"), (256, None), (258, None), (256, None), (258, None)]
            self.keywords = {}
            self.tokens = {1: 0, 2: 1}
            self.symbol2label = {}
            self.start = 256

    d

# Generated at 2022-06-21 09:59:15.248034
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("pgen.pkl")
    with open("pgen.pkl", "rb") as f:
        assert len(f.read()) > 0
    os.remove("pgen.pkl")

# Generated at 2022-06-21 09:59:16.518886
# Unit test for constructor of class Grammar
def test_Grammar():
    assert Grammar().symbol2number == {}  # type: ignore

# Generated at 2022-06-21 09:59:27.485260
# Unit test for method load of class Grammar
def test_Grammar_load():
    t = Grammar()
    t.symbol2number = {"foo": 1, "bar": 2}
    t.number2symbol = {1: "foo", 2: "bar"}
    t.states = [[(1, 4)], [(1, 5), (1, 7)], [(1, 6)], [(1, 7)], [], [], [], []]
    t.dfas = {3: (t.states[0], {}), 5: (t.states[1], {}), 7: (t.states[3], {})}
    t.labels = [(0, "EMPTY"), (1, "foo")]
    t.keywords = {}
    t.tokens = {}
    t.symbol2label = {1: "foo"}
    t.start = 3


# Generated at 2022-06-21 09:59:39.217011
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import tempfile
    import unittest

    from . import grammar, parse
    from .pgen2 import driver

    test_grammar_str = """
module: moduledef
moduledef: "module" NAME ["(" argslist ")"] NEWLINE
argslist: arg
        | arg "," argslist
arg: NAME
"""

    class TestGrammarLoad(unittest.TestCase):
        def test_simple(self):
            with tempfile.NamedTemporaryFile(suffix=".py") as test_file:
                with tempfile.NamedTemporaryFile(suffix=".py") as grammar_file:
                    test_file.write(test_grammar_str.encode("utf-8"))
                    test_file.seek(0)

# Generated at 2022-06-21 09:59:43.427328
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256

# Generated at 2022-06-21 09:59:53.301581
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Construct parser
    import pgen2.pgen
    g = Grammar()
    # Load tables
    g.loads(pgen2.pgen.pickle_grammar(pickle.HIGHEST_PROTOCOL))
    # Check tables
    symbol2number = g.symbol2number
    number2symbol = g.number2symbol
    states = g.states
    dfas = g.dfas
    labels = g.labels
    keywords = g.keywords
    tokens = g.tokens
    # Check consistency of symbol/number translations
    for symbol, number in symbol2number.items():
        assert number2symbol[number] == symbol
    # Check consistency of states, labels and dfas

# Generated at 2022-06-21 09:59:54.502248
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    pass
    # Changed with mypy's plugin system

# Generated at 2022-06-21 10:00:04.171002
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords == False


# Generated at 2022-06-21 10:00:08.133000
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    grammar = Grammar()
    grammar.loads(b"cos\nsystem\n(S'ls'\ntR.")


if __name__ == "__main__":
    import sys

    g = Grammar()
    g.load(sys.argv[1])
    g.report()

# Hack for mypy
if False:
    Grammar.copy()

# Generated at 2022-06-21 10:00:08.680713
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()

# Generated at 2022-06-21 10:00:19.379885
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.start = 0
    g.number2symbol = {0: "start", 1: "S", 2: "S'"}
    g.symbol2number = {"start": 0, "S": 1, "S'": 2}
    g.states = [
        [[(0, 1), (4, 3)], [(0, 2), (4, 3)], [], [(0, 1)]],
        [],
        [],
    ]

# Generated at 2022-06-21 10:00:24.369325
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g2 = Grammar()
    g.symbol2number = {'hi': 1}
    fname = tempfile.NamedTemporaryFile()
    g.dump(fname.name)
    g2.load(fname.name)
    assert g.symbol2number['hi'] == g2.symbol2number['hi']

# Generated at 2022-06-21 10:00:25.275916
# Unit test for method report of class Grammar
def test_Grammar_report():
    # This should not fail.
    Grammar().report()

# Generated at 2022-06-21 10:00:34.680139
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    # Check for presence of instance variables
    assert hasattr(g, "symbol2number")
    assert hasattr(g, "number2symbol")
    assert hasattr(g, "states")
    assert hasattr(g, "dfas")
    assert hasattr(g, "labels")
    assert hasattr(g, "keywords")
    assert hasattr(g, "tokens")
    assert hasattr(g, "symbol2label")
    assert hasattr(g, "start")

# Generated at 2022-06-21 10:00:41.872388
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    def f1():
        g = Grammar()
        g.test = 1
        f = g.copy()
        return f.test

    assert f1() == 1
    assert f1.__code__.co_freevars == ("g",)

    def f2():
        g = Grammar()
        f = g.copy()
        g.test = 1
        return f.test

    assert f2() == 1
    assert f2.__code__.co_freevars == ("g",)

# Generated at 2022-06-21 10:00:46.991866
# Unit test for method load of class Grammar
def test_Grammar_load():
    import tokenize
    from io import BytesIO

    data = b"\n0\n(\x88\x01\x01K\x00h\x01\x00\x00."
    f = BytesIO(data)
    g = Grammar()
    g.load(f)
    assert g.tokens == tokenize.tokenmap

# Generated at 2022-06-21 10:00:57.845010
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    import os

    def _test_one(pickle_text):
        grammar = Grammar()
        grammar.loads(pickle_text)
        assert grammar.symbol2number == {
            "accept": 2,
            "accept_tokens": 1,
        }
        assert grammar.number2symbol == {
            1: "accept_tokens",
            2: "accept",
        }

# Generated at 2022-06-21 10:01:15.167425
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # Check that Grammar.loads can successfully recreate this Grammar object.
    f = tokenize.StringIO(file_input)

    import nltk.parser
    g = nltk.parser.load_parser('grammars/book_grammars/feat1.fcfg', trace=2)
    h = nltk.parser.load_parser('grammars/book_grammars/feat1.fcfg', trace=2)
    h.load_Grammar_pkl(g.dump_Grammar_pkl())

if __name__ == "__main__":
    import sys
    import tokenize
    from nltk.compat import input

    # Get grammar file name from command line argument

# Generated at 2022-06-21 10:01:16.076660
# Unit test for constructor of class Grammar
def test_Grammar():
    assert Grammar().symbol2number == {}

# Generated at 2022-06-21 10:01:26.188888
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import shutil

    filename = "Grammar.pickle"
    if os.path.exists(filename):
        os.remove(filename)
    g = Grammar()
    g.dump(filename)
    shutil.copyfile(filename, filename + ".copy")
    assert os.path.exists(filename)
    assert os.path.exists(filename + ".copy")
    assert os.path.getsize(filename) == os.path.getsize(filename + ".copy")
    g2 = Grammar()
    g2.load(filename)
    assert os.path.getsize(filename) == os.path.getsize(filename + ".copy")
    assert g.number2symbol == g2.number2symbol
    assert g.symbol2number == g2.symbol2number

# Generated at 2022-06-21 10:01:32.928952
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pickle"))
    assert g.symbol2number == {
        "comp_op": 261,
        "testlist_comp": 259,
        "comp_if": 262,
        "test": 256,
        "testlist": 257,
        "testlist1": 258,
        "dictorsetmaker": 260,
        "yield_expr": 263,
        "lambda_form": 264,
        "argument": 265,
        "arglist": 266,
        "arglist_comp": 270,
        "argument_comp": 267,
        "arglist_star_expr": 271,
        "testlist_star_expr": 269,
        "test_nocond": 272,
        "dictorsetmaker_comp": 273,
    }

# Generated at 2022-06-21 10:01:44.022502
# Unit test for method report of class Grammar
def test_Grammar_report():
    # Construct a grammar from various test data
    g = Grammar()
    g.symbol2number = {
        "": 12,
        "NAME": 15,
        "NUMBER": 16,
        "STRING": 17,
        "NEWLINE": 18,
        "INDENT": 19,
        "DEDENT": 20,
        "LPAR": 21,
        "RPAR": 22,
    }
    g.number2symbol = {
        12: "",
        15: "NAME",
        16: "NUMBER",
        17: "STRING",
        18: "NEWLINE",
        19: "INDENT",
        20: "DEDENT",
        21: "LPAR",
        22: "RPAR",
    }

# Generated at 2022-06-21 10:01:48.356344
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    grammar = Grammar()
    filename = os.path.join(os.path.dirname(__file__), "../Grammar.pkl")
    with open(filename, mode="rb") as pkl_file:
        grammar.loads(pkl_file.read())

# Generated at 2022-06-21 10:01:53.957769
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords == False


# Generated at 2022-06-21 10:01:55.089902
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()

# Generated at 2022-06-21 10:01:55.937841
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()


# Generated at 2022-06-21 10:02:09.004541
# Unit test for method loads of class Grammar

# Generated at 2022-06-21 10:02:30.180197
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # Verify that the 'loads' method of class Grammar loads all the
    # instance variables that 'dump' saves.

    # Create instances of Grammar
    grammar1 = Grammar()
    grammar2 = Grammar()

    # Set some instance variables to something interesting
    # mypy doesn't understand c.update(b)
    grammar1.symbol2number.update({"a": 1, "b": 2, "c": 3})
    grammar1.number2symbol.update({1: "a", 2: "b", 3: "c"})
    grammar1.states = [["a", "b", "c"]]
    grammar1.dfas = {}
    grammar1.dfas[1] = [["d", "e", "f"], {}]
    grammar1.labels = ["1", "2", "3"]
   

# Generated at 2022-06-21 10:02:34.706171
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import driver

    grammar = driver.load_grammar("Grammar/Grammar.txt")
    grammar.load("Grammar/Grammar.pkl")


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-21 10:02:39.794945
# Unit test for method report of class Grammar
def test_Grammar_report():
    import sys
    import unittest

    class GrammarTest(unittest.TestCase):
        def test_Grammar_report(self):
            orig_stdout = sys.stdout
            try:
                sys.stdout = None
                # _Grammar_report()
                # self.assertEqual(sys.stdout, 'write me!')
            finally:
                sys.stdout = orig_stdout

# Generated at 2022-06-21 10:02:51.876755
# Unit test for method report of class Grammar
def test_Grammar_report():
    """This function is used to test that Grammar.report() works correctly."""
    # Create a new Grammar object
    grammar = Grammar()
    # Create pprint-friendly dicts
    s2n = {"'*'": 258, "'+'": 259, "'-'": 260}
    n2s = {258: "'*'", 259: "'+'", 260: "'-'"}
    dfas = {258: ([[(259, 2), (260, 3)], [(0, 1)], [(0, 4)], [(260, 5)]], {}), 259: ([[(259, 6)], [(0, 7)]], {}), 260: ([[(260, 8)], [(0, 9)]], {})}

# Generated at 2022-06-21 10:03:01.829765
# Unit test for method load of class Grammar
def test_Grammar_load():
    def test_helper(load_func):
        class GrammarSubclass(Grammar):
            def __init__(self, filename: Path) -> None:
                Grammar.__init__(self)
                self.file = open(filename, "rb")
                load_func(self)
            def copy(self: _P) -> _P:
                return object.__new__(_P)
        g = GrammarSubclass(os.path.join(os.path.dirname(__file__), "Grammar.pickle"))
        return g

    # Should be able to run the load method on both a Grammar
    # instance and a GrammarSubclass instance.
    g = test_helper(Grammar.load)
    assert g.start == 256

# Generated at 2022-06-21 10:03:13.077998
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle

    g = Grammar()

# Generated at 2022-06-21 10:03:22.314748
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g_a = Grammar()
    g_a.start = 0
    g_a.symbol2number = {"foo": 1, "bar": 2}
    g_a.number2symbol = {1: "foo", 2: "bar"}
    g_a.states = []
    g_a.dfas = {"foo": {}, "bar": {}}
    g_a.labels = [0, 1, 2]
    g_a.keywords = {0: "xyz"}
    g_a.tokens = {1: 0, 2: 1}
    g_a.symbol2label = {0: "foo", 1: "bar"}
    g_b = g_a.copy()
    assert g_a.start == g_b.start

# Generated at 2022-06-21 10:03:34.165936
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test with an empty temporary file
    with tempfile.NamedTemporaryFile() as f:
        g = Grammar()
        g.load(f.name)
        assert g.symbol2number == {}
        assert g.number2symbol == {}
        assert g.states == []
        assert g.dfas == {}
        assert g.labels == [(0, "EMPTY")]
        assert g.keywords == {}
        assert g.tokens == {}
        assert g.start == 256
    # Test with an empty temporary file
    from .tokenize import generate_tokens, untokenize
    with tempfile.NamedTemporaryFile() as f:
        g = Grammar()
        f.write(b"import")
        f.flush()

# Generated at 2022-06-21 10:03:37.235157
# Unit test for constructor of class Grammar
def test_Grammar():
    grammar = Grammar()
    assert len(grammar.states) == 0
    assert grammar.dfas == {}
    assert len(grammar.labels) == 1
    assert grammar.keywords == {}
    assert grammar.tokens == {}
    assert grammar.symbol2label == {}
    assert grammar.start == 256

# Generated at 2022-06-21 10:03:46.497250
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    from . import conv, pgen

    path = sys.executable
    fn = path + (
        ".pkl"
        if sys.platform == "win32" and not path.endswith(".exe")
        else "c.pkl"
    )
    g1 = conv.Converter().parse(path)
    g1.dump(fn)
    g2 = pgen.Generator().parse(path)
    g2.dump(fn)
    f = open(fn, "rb")
    s1 = f.read()
    f.seek(0)
    s2 = f.read()
    f.close()
    assert s1 == s2

# Generated at 2022-06-21 10:04:03.661628
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()

# Generated at 2022-06-21 10:04:15.245282
# Unit test for method report of class Grammar
def test_Grammar_report():
    import os
    import sys
    import time

    print()

# Generated at 2022-06-21 10:04:23.344345
# Unit test for constructor of class Grammar
def test_Grammar():
    gr = Grammar()
    assert gr.number2symbol.__class__ == dict
    assert gr.symbol2number.__class__ == dict
    assert gr.states.__class__ == list
    assert gr.dfas.__class__ == dict
    assert gr.labels.__class__ == list
    assert gr.keywords.__class__ == dict
    assert gr.tokens.__class__ == dict
    assert gr.symbol2label.__class__ == dict
    assert gr.start == 256

# Generated at 2022-06-21 10:04:30.869633
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()

# Generated at 2022-06-21 10:04:34.102539
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import sys
    import io
    import io

    class DummyGrammar(Grammar):
        def __init__(self):
            super().__init__()
            self.symbol2number = {'a': 'a', 'b': 'b'}
            self.number2symbol = {'a': 'a', 'b': 'b'}
            self.dfas = {'a': 'a', 'b': 'b'}
            self.keywords = {'a': 'a', 'b': 'b'}
            sel

# Generated at 2022-06-21 10:04:46.501660
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {'SEMI': 5}
    g.number2symbol = {4: 'EQUAL'}
    g.dfas = {1: ([[(0, 1)], [(0, 2), (0, 3)]], {1:2}), 3: ([[(0, 4)], [(0, 5), (0, 6)]], {4:5})}
    g.keywords = {'lambda': 7, 'finally': 8}
    g.tokens = {0: 9, 1: 10}
    g.symbol2label = {'DOT': 11, 'LESS': 12}
    g.labels = [(13, 'D')]

# Generated at 2022-06-21 10:04:57.206522
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    def test_loads(pkl: bytes) -> None:
        g = Grammar()  # type: Grammar
        g.loads(pkl)
        assert g.symbol2number == {"foo": 256, "bar": 257}
        assert g.number2symbol == {256: "foo", 257: "bar"}
        assert g.states == [[[(0, 257), (1, 258)], [(0, 259), (2, 257)], [(1, 260)]]]
        assert g.dfas == {
            256: (
                [[(0, 257), (1, 258)], [(0, 259), (2, 257)], [(1, 260)]],
                {1: 1, 2: 1},
            )
        }

# Generated at 2022-06-21 10:04:59.819319
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump('/tmp/bla.pkl')
    g.load('/tmp/bla.pkl')

# Generated at 2022-06-21 10:05:02.871439
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    grammar = Grammar()
    grammar.loads(pickle.dumps(grammar.__dict__, pickle.HIGHEST_PROTOCOL))

# vim:ts=4:sw=4:et

# Generated at 2022-06-21 10:05:11.030504
# Unit test for method report of class Grammar
def test_Grammar_report():
    from io import StringIO

    save_stdout = sys.stdout
    try:
        out = StringIO()
        sys.stdout = out
        g = Grammar()
        g.report()
        output = out.getvalue()
    finally:
        sys.stdout = save_stdout
    assert output == """s2n
{}
n2s
{}
states
[]
dfas
{}
labels
[(0, 'EMPTY')]
start 256
"""


#
# Supporting functions
#


# Generated at 2022-06-21 10:05:35.250816
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import driver
    from .parse import Parser

    grammar = Grammar()
    grammar.load(driver.pickle)
    p = Parser(grammar, token.tok_name)
    p.parse()


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-21 10:05:40.787158
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    grammar = Grammar()

# Generated at 2022-06-21 10:05:45.272381
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    pass
    #g = Grammar()
    #g.number2symbol[1] = 2
    #g1 = g.copy()
    #assert g.number2symbol == g1.number2symbol
    #assert g.number2symbol is not g1.number2symbol

# Generated at 2022-06-21 10:05:53.819530
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import unittest
    import pprint
    from .pygram import python_symbols as syms
    from .pygram import python_grammar as gram
    from .pygram import python_operators as ops
    from .pgen2 import tokenize

    class FakeToken(object):
        def __init__(self, type, string, start, end, line):
            self.type = type
            self.string = string
            self.start = start
            self.end = end
            self.line = line


# Generated at 2022-06-21 10:05:54.600345
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()

# Generated at 2022-06-21 10:06:01.221518
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    # Check that Grammar.report doesn't break
    import io
    try:
        out = io.StringIO()
        g.report(out)
    finally:
        out.close()


test_Grammar_report()
del test_Grammar_report

# Generated at 2022-06-21 10:06:02.143590
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()

# Generated at 2022-06-21 10:06:03.462335
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("ast.pkl")

# Generated at 2022-06-21 10:06:12.325728
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    def check(g: Grammar, attrs: Dict[str, Any]) -> None:
        for k, v in attrs.items():
            assert getattr(g, k) == v

    # pickle of a Grammar:

# Generated at 2022-06-21 10:06:18.390853
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """
    Test Grammar.dump() method.
    """
    filename = "data/Grammar.dump"
    gram = Grammar()
    gram.report()
    gram.dump(filename)
    gram2 = Grammar()
    gram2.load(filename)
    gram2.report()

if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-21 10:06:50.645254
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    def create_test_grammar() -> Grammar:
        g = Grammar()
        # invert symbol2number
        for k, v in g.symbol2number.items():
            g.number2symbol[v] = k
        # fill states, labels and dfas
        g.states.append([(1, 2), (3, 4), (0, 5)])
        g.states.append([(1, 2), (3, 4), (0, 5)])
        g.labels.append((3, "test"))
        g.labels.append((4, "test2"))
        g.dfas[5] = (g.states[0], {0: 1})
        # these attributes are required by GrammarLoader
        g._name2number = {}
        g._name2labels = {}
        g

# Generated at 2022-06-21 10:07:03.534500
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    from . import grammar
    g = grammar.Grammar()
    g.start = 654321
    g.tokens[12345] = 54321
    g.dump("tmp.pkl")
    g2 = grammar.Grammar()
    g2.load("tmp.pkl")
    assert g.start == g2.start
    assert g.tokens[12345] == g2.tokens[12345]
    os.remove("tmp.pkl")

# Generated at 2022-06-21 10:07:11.206771
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import shutil
    import pickle
    import sys

    # mypyc generates objects that don't have a __dict__, but they
    # do have __getstate__ methods that will return an equivalent
    # dictionary
    if hasattr(sys.modules["_ast"], "__dict__"):
        d = sys.modules["_ast"].__dict__
    else:
        d = sys.modules["_ast"].__getstate__()  # type: ignore

    pickle_name = "test_grammar.pickle"
    with open(pickle_name, "wb") as f:
        pickle.dump(d, f, pickle.HIGHEST_PROTOCOL)

    grammar = Grammar()
    grammar.load(pickle_name)
    grammar_copy = grammar.copy()

# Generated at 2022-06-21 10:07:22.207690
# Unit test for method report of class Grammar
def test_Grammar_report():
    import unittest.mock as mock
    import unittest
    import io

    # First, get a tokenize.TokenInfo object
    # We use a mocked out 'open' function to pass in a string as a file object
    # This lets us get the tokenize.tokenize function to accept a string as input
    #
    # the following is a simple python program
    program = "program_name = 'test program'\nprint(program_name)\n# test comment"
    with mock.patch("tokenize.open", return_value = io.StringIO(program)):
        tokgen = tokenize.tokenize(io.StringIO(program).readline)
        token1 = next(tokgen)
        assert(token1.type == tokenize.NAME)
        assert(token1.string == "program_name")


# Generated at 2022-06-21 10:07:32.401163
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {'foo': 1}
    g.number2symbol = {2: 'bar'}
    g.dfas = {3: None}
    g.keywords = {'baz': 4}
    g.tokens = {5: 6}
    g.symbol2label = {'spam': 7}
    g.labels = [('ham', 8)]
    g.states = [None, ('eggs', 9)]
    g.start = 10
    g.async_keywords = True
    h = g.copy()
    assert g is not h
    assert g.symbol2number is not h.symbol2number
    assert g.symbol2number == h.symbol2number

# Generated at 2022-06-21 10:07:35.472555
# Unit test for method report of class Grammar
def test_Grammar_report():
    try:
        import StringIO
        import sys
        sys.stdout = StringIO.StringIO()
        g = Grammar()
        g.report()
        assert False, "Didn't raise exception"
    except AttributeError:
        pass

# Generated at 2022-06-21 10:07:47.861369
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {"test": 1}
    g.number2symbol = {2: "test2"}
    g.dfas = {5: ([], {}), 6: ([], {})}
    g.keywords = {"key": 1}
    g.tokens = {2: 3}
    g.symbol2label = {"symb": 4}
    g.labels = [(1, 1)]
    g.states = [[(1, 1)], [(1, 1)]]
    g.start = 4
    g.async_keywords = False

    g_copy = g.copy()
    assert g_copy.symbol2number == g.symbol2number and g_copy.symbol2number is not g.symbol2number
    assert g_copy.number2

# Generated at 2022-06-21 10:07:57.050915
# Unit test for method load of class Grammar
def test_Grammar_load():
    class DummyGrammar(Grammar):

        def __init__(self) -> None:
            super().__init__()
            self.tmpdir = None

        def __getstate__(self) -> None:
            return {}

        def load(self, filename: Path) -> None:
            super().load(filename)

    try:
        grammar = DummyGrammar()
        grammar.load(".")
    except (IOError, OSError):
        pass
    else:
        raise AssertionError("should have raised IOError")


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-21 10:08:05.800234
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import pickle
    from .pgen2 import driver
    from . import token
    from .tokenize import untokenize

    grammar = driver.load_grammar("Python.asdl")

    """We use the grammar file to initialize a Grammar object

    This tests that the grammar was loaded correctly.
    """
    _grammar_pkl_name = "Grammar.pkl"
    grammar_tf = tempfile.NamedTemporaryFile(dir=".", mode="w")
    try:
        grammar.dump(_grammar_pkl_name)
    finally:
        grammar_tf.close()

    _grammar_pkl_name = tempfile.mktemp(dir=".")
    grammar.dump(_grammar_pkl_name)

# Generated at 2022-06-21 10:08:15.302545
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.start = 0
    g.keywords = {"if": "a", "else": "b"}
    g.tokens = {"c": 1, "d": 2}

    fn = "grammar_temp.pkl"
    try:
        g.dump(fn)
        f = open(fn, "rb")
    finally:
        try:
            os.unlink(fn)
        except OSError:
            pass

    with f:
        d = pickle.load(f)
    assert d == g.__dict__

