

# Generated at 2022-06-21 09:58:39.098643
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert not g.async_keywords


# Generated at 2022-06-21 09:58:43.001266
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from pgen2.grammar import Grammar

    test_filename = "grammar_test.pk"
    g = Grammar()
    g.dump(test_filename)

    with open(test_filename, "rb") as f:
        g_dict = pickle.load(f)
    for k, v in g_dict.items():
        assert getattr(g, k) == v

# Generated at 2022-06-21 09:58:54.554220
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    def test_dfas():
        assert grammar.dfas == {}
    def test_states():
        assert grammar.states == []
    def test_keywords():
        assert grammar.keywords == {}
    def test_labels():
        assert grammar.labels == [(0, "EMPTY")]
    def test_symbol2label():
        assert grammar.symbol2label == {}
    def test_symbol2number():
        assert grammar.symbol2number == {}
    def test_tokens():
        assert grammar.tokens == {}
    def test_number2symbol():
        assert grammar.number2symbol == {}

    filename = "./test_Grammar_dump.pickle"

# Generated at 2022-06-21 09:59:06.517634
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    from .pgen2 import tokenize

    g = Grammar()
    g.start = 1
    g.number2symbol = {1: "name"}
    g.symbol2number = {"name": 1}
    g.keywords = {"name": 2}
    g.tokens = {1: 2}
    g.states = [[[(2, 3), (2, 4)], [(2, 5)], []]]
    g.dfas = {1: (0, {})}
    g.symbol2label = {"name": 2}
    g.labels = [(0, "EMPTY"), (1, "name")]
    g.async_keywords = True

    g_copy = g.copy()

    assert g.start == g_copy.start
    assert g.number2symbol == g

# Generated at 2022-06-21 09:59:10.128693
# Unit test for constructor of class Grammar
def test_Grammar():
    try:
        Grammar()
    except:
        assert 1, 'could not construct Grammar()'

if __name__ == "__main__":
    import unittest

    class GrammarTest(unittest.TestCase):
        def test_constructor(self) -> None:
            Grammar()

    unittest.main()

# Generated at 2022-06-21 09:59:11.469369
# Unit test for method load of class Grammar
def test_Grammar_load():
    pass

# Generated at 2022-06-21 09:59:14.208293
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pgen2.conv
    g = pgen2.conv.Grammar()
    g.load("Grammar.txt")

# Generated at 2022-06-21 09:59:25.159122
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    """
    Test that the Grammar.loads method works.
    """
    grammar = Grammar()
    grammar.loads(grammar_file)
    assert grammar.symbol2number == {"single_input": 256, "file_input": 257}
    assert grammar.number2symbol == {256: "single_input", 257: "file_input"}
    assert len(grammar.states) == 2

# Generated at 2022-06-21 09:59:25.745922
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()

# Generated at 2022-06-21 09:59:37.903228
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g1.symbol2number["a"] = 1
    g1.number2symbol[1] = "a"
    g1.dfas[1] = ([[(1, 2)]], {2: 3})
    g1.keywords["b"] = 3
    g1.tokens[3] = 4
    g1.symbol2label["c"] = 5
    g1.labels = [(1, None), (2, "d")]
    g1.states = [[[(3, 4), (5, 6)], [(7, 8)]]]
    g1.start = 9
    g1.async_keywords = True
    g2 = g1.copy()
    assert g1 is not g2
    assert g1.symbol2number is not g

# Generated at 2022-06-21 09:59:46.470980
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()
    return g

if __name__ == "__main__":
    # Run the unit test
    _g = test_Grammar_report()

# Generated at 2022-06-21 09:59:47.495613
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()


# Generated at 2022-06-21 09:59:57.780382
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number['name'] = 2
    g.number2symbol[3] = 'symbol'
    g.dfas['some key'] = 3
    g.keywords['some keyword'] = 'a'
    g.tokens['some token'] = 'b'
    g.symbol2label['some symbol'] = 'c'
    # Map from operator to number (since tokenize doesn't do this)
    for line in opmap_raw.splitlines():
        if line:
            op, name = line.split()
            opmap[op] = getattr(token, name)
    g.labels = opmap.items()

# Generated at 2022-06-21 10:00:04.290471
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords == False
    assert not hasattr(g, "__dict__")

# Generated at 2022-06-21 10:00:08.489684
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import sys

# Generated at 2022-06-21 10:00:15.727493
# Unit test for constructor of class Grammar
def test_Grammar():
    g_object = Grammar()
    assert g_object.symbol2number == {}
    assert g_object.number2symbol == {}
    assert g_object.states == []
    assert g_object.dfas == {}
    assert g_object.labels == [(0, "EMPTY")]
    assert g_object.keywords == {}
    assert g_object.tokens == {}
    assert g_object.symbol2label == {}
    assert g_object.start == 256


# Generated at 2022-06-21 10:00:25.519134
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    # Initializing the grammar tables
    g = Grammar()
    g.symbol2number = {"A": 1, "B": 2}
    g.number2symbol = {1: "A", 2: "B"}
    g.dfas = {1: 2, 2: 3}
    g.keywords = {"a": 1, "b": 2}
    g.tokens = {1: 2, 2: 3}
    g.symbol2label = {"A": 1, "B": 2}
    g.labels = [(0, "EMPTY"), (1, "A"), (2, "B")]
    g.states = [(1,2), (3,4), (5,6)]
    g.start = 1
    g.async_keywords = True
    h = g.copy()

# Generated at 2022-06-21 10:00:37.125742
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    grammar = Grammar()

# Generated at 2022-06-21 10:00:37.718558
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()

# Generated at 2022-06-21 10:00:43.335811
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Ensure first stable position for locals
    g = Grammar()
    g.load(__file__)
    g.load(__file__)

    # Ensure both branches are covered
    g = Grammar()
    g.load(__file__)
    g.load(__file__)

    # Ensure both branches are covered
    g = Grammar()
    g.load(__file__)
    g.load(__file__)


# Generated at 2022-06-21 10:00:54.775751
# Unit test for constructor of class Grammar
def test_Grammar():
    d = Grammar()
    assert d.symbol2number == {}
    assert d.number2symbol == {}
    assert d.states == []
    assert d.dfas == {}
    assert d.labels == [(0, "EMPTY")]
    assert d.keywords == {}
    assert d.tokens == {}

# Generated at 2022-06-21 10:01:04.565859
# Unit test for method load of class Grammar

# Generated at 2022-06-21 10:01:06.852106
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pickle"))


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-21 10:01:18.247965
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    gr = Grammar()
    gr.symbol2number = dict(a=0, b=1)
    gr.number2symbol = dict(x=1, y=2)
    gr.dfas = dict(a=0, b=1)
    gr.keywords = dict(a=0, b=1)
    gr.tokens = dict(a=0, b=1)
    gr.symbol2label = dict(a=0, b=1)
    gr.labels = [(0, 1), (3, 2)]
    gr.states = [[(1, 0), (2, 1)], [(3, 2)]]
    gr.start = 10
    gr.async_keywords = True

    gr1 = gr.copy()
    assert gr.symbol2number == gr1.symbol2

# Generated at 2022-06-21 10:01:21.256858
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    grammar = Grammar()
    d = {"key": "value"}
    pickled_d = pickle.dumps(d)
    grammar.loads(pickled_d)
    assert grammar.key == "value"

# Generated at 2022-06-21 10:01:29.388591
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g1.start = 1
    g1.states = [1, 2]
    g1.symbol2number["foo"] = 3
    g2 = g1.copy()
    assert g1.start == g2.start
    assert g1.states == g2.states
    g1.start = 2
    g1.states.append(3)
    assert g1.start == 2
    assert g2.start == 1
    assert g1.states[-1] == 3
    assert g2.states[-1] != 3
    g2.symbol2number["bar"] = 4
    assert "bar" not in g1.symbol2number
    assert "bar" in g2.symbol2number

# Generated at 2022-06-21 10:01:41.104955
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    class TestGrammar(Grammar):
        symbol2number = {"Test": 258}
        number2symbol = {258: "Test"}
        states = [[]]
        dfas = {258: ([], {})}
        labels = [(0, "EMPTY"), (258, None)]
        keywords = {}
        tokens = {}
        symbol2label = {}

    g = TestGrammar()
    g.start = 258
    pkl = pickle.dumps(g, pickle.HIGHEST_PROTOCOL)
    g2 = Grammar()
    g2.loads(pkl)

    assert g2.symbol2number == g.symbol2number
    assert g2.number2symbol == g.number2symbol
    assert g2.states == g.states

# Generated at 2022-06-21 10:01:42.584715
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # issue: #53
    g = Grammar()
    filename = "/tmp/compiled_grammar"
    g.dump(filename)
    g.load(filename)

# Generated at 2022-06-21 10:01:52.800113
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.symbol2number['STMT'] = 256
    g.symbol2number['expr'] = 257
    g.number2symbol[256] = 'STMT'
    g.number2symbol[257] = 'expr'
    g.states = [[[(257, 2), (0, 1)],
                  [(256, 0), (0, 0)]],
                 [[(257, 4), (0, 3)],
                  [(0, 2), (256, 0), (0, 0)]]]

# Generated at 2022-06-21 10:01:56.980068
# Unit test for method report of class Grammar
def test_Grammar_report():
    import unittest.mock
    with unittest.mock.patch("sys.stdout") as mock_stdout:
        grammar = Grammar()
        grammar.report()
        assert mock_stdout.mock_calls != []

if __name__ == "__main__":
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)
    # test_Grammar_report()

# Generated at 2022-06-21 10:02:04.209435
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g2 = g.copy()
    assert g2 is not g
    assert g2.__dict__ == g.__dict__, "copy should copy attributes"

# Generated at 2022-06-21 10:02:15.357295
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import pickle
    grammar = Grammar()
    grammar.symbol2number = {'EMPTY': 301, 'empty': 300}
    grammar.number2symbol = {300: 'empty', 301: 'EMPTY'}
    grammar.states = [
        [],
        [
            (0, 1),
            (301, 2)
        ],
        [
            (0, 1)
        ]
    ]
    grammar.start = 300

# Generated at 2022-06-21 10:02:24.490577
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    # create two Grammars g1 and g2 which look identical
    g1 = Grammar()
    g2 = Grammar()

    # test that the two Grammars are identical
    assert g1.labels == g2.labels
    assert g1.keywords == g2.keywords
    assert g1.number2symbol == g2.number2symbol
    assert g1.symbol2number == g2.symbol2number
    assert g1.symbol2label == g2.symbol2label
    assert g1.tokens == g2.tokens
    assert g1.dfas == g2.dfas
    assert g1.states == g2.states
    assert g1.start == g2.start
    assert g1.async_keywords == g2.async_keywords

# Generated at 2022-06-21 10:02:36.110934
# Unit test for method copy of class Grammar
def test_Grammar_copy():

    g = Grammar()
    assert g.copy() is not g
    assert g.copy().__class__ is g.__class__
    g.symbol2number = {42: 42}
    assert g.copy().symbol2number == {42: 42}
    g.number2symbol = {42: 42}
    assert g.copy().number2symbol == {42: 42}
    g.dfas = {42: 42}
    assert g.copy().dfas == {42: 42}
    g.keywords = {42: 42}
    assert g.copy().keywords == {42: 42}
    g.tokens = {42: 42}
    assert g.copy().tokens == {42: 42}
    g.symbol2label = {42: 42}
    assert g.copy().sy

# Generated at 2022-06-21 10:02:42.634064
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    import pickle

    class MyGrammar(object):
        def __init__(self, tokenizer: Any, start: int) -> None:
            self.tokenizer = tokenizer
            self.start = start

    tokenizer = token.Tokenizer()
    start = 256
    d = {"tokenizer": tokenizer, "start": start}
    g1 = MyGrammar(tokenizer, start)
    pkl = pickle.dumps(g1, pickle.HIGHEST_PROTOCOL)
    g2 = Grammar()
    g2.loads(pkl)
    assert g2.tokenizer == tokenizer
    assert g2.start == start

# Generated at 2022-06-21 10:02:52.980507
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g1.symbol2number["a"] = 1
    g1.labels = [2, 3]
    print(g1.symbol2number) # {'a': 1}
    print(g1.labels) # [2, 3]

    g2 = g1.copy()
    g1.symbol2number["b"] = 2
    g2.labels = [4, 5]
    print(g2.symbol2number) # {'a': 1, 'b': 2}
    print(g2.labels) # [4, 5]

if __name__ == "__main__":
    print(opmap)
    print(Grammar.mro())
    test_Grammar_copy()

# Generated at 2022-06-21 10:02:59.757709
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    G = Grammar()
    G.symbol2number = {'a': 1}
    G.number2symbol = {1: 'a'}
    G.dfas = {2: ([0], {3: 1})}
    G.keywords = {'b': 4}
    G.tokens = {5: 6}
    G.symbol2label = {'c': 7}
    G.states = [[(8, 9)]]
    G.labels = [(10, 11), (12, 13)]
    G.start = 14
    G.async_keywords = True
    G1 = G.copy()
    assert G.symbol2number == G1.symbol2number
    assert G.number2symbol == G1.number2symbol

# Generated at 2022-06-21 10:03:04.457868
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.states == []
    assert g.dfas == {}
    assert g.start == 256

# Generated at 2022-06-21 10:03:16.482443
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import py
    import pickle
    import sys

    g = Grammar()
    g.symbol2number = {"a": 2, "b": 3}
    g.number2symbol = {2: "a", 3: "b"}
    g.dfas = {4: ([[(1, 2)], [(0, 2)]], {2: 3}), 5: ([[(3, 2)], [(0, 2)]], {2: 3})}
    g.keywords = {"a": 1, "c": 3}
    g.tokens = {4: 5, 6: 7}
    g.symbol2label = {"a": 0, "b": 1}
    g.labels = [(0, "EMPTY"), (1, None)]

# Generated at 2022-06-21 10:03:19.592070
# Unit test for method report of class Grammar
def test_Grammar_report():
    from io import StringIO
    import sys

    sys_stdout = sys.stdout
    sys.stdout = StringIO()
    try:
        Grammar().report()
    finally:
        sys.stdout = sys_stdout

# Generated at 2022-06-21 10:03:40.995218
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    filename = "test.pkl"
    try:
        g.dump(filename)
        g1 = Grammar()
        g1.load(filename)
    finally:
        os.remove(filename)

    assert g1.symbol2number == {}
    assert g1.number2symbol == {}
    assert g1.states == []
    assert g1.dfas == {}
    assert g1.labels == [(0, "EMPTY")]
    assert g1.keywords == {}
    assert g1.tokens == {}
    assert g1.symbol2label == {}
    assert g1.start == 256
    assert g1.async_keywords == False


# Generated at 2022-06-21 10:03:47.218183
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import tempfile
    path = tempfile.mkdtemp()
    g = Grammar()
    g.async_keywords = True
    g.dump(path + "test")
    g.load(path + "test")
    assert g.async_keywords
    sys.path.append(path)
    try:
        import test
        assert test.async_keywords
    finally:
        del sys.path[-1]

# Generated at 2022-06-21 10:03:59.884450
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    old_grammar = Grammar()
    old_grammar.symbol2number["test_symbol"] = 123
    old_grammar.number2symbol[123] = "test_symbol"
    old_grammar.dfas[123] = [
        [
            (0, 1),
            (0, 2),
        ],
        [
            (1, 1),
            (1, 2),
        ],
    ],
    old_grammar.keywords["test_keyword"] = 1
    old_grammar.tokens[123] = 1
    old_grammar.symbol2label["test_label"] = 1
    old_grammar.labels = [
        (2, "test_label"),
        (123, None),
    ]

# Generated at 2022-06-21 10:04:05.803030
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    with open("Grammar.pkl", "rb") as f:
        pkl = f.read()
    g.loads(pkl)
    # FIXME: should test that g has the same values as g2, but testing
    # __eq__ magically causes g to be an instance of Grammar2, instead
    # of Grammar.
    # g2 = Grammar()
    # g2.load("Grammar.pkl")
    # assert g == g2

# Generated at 2022-06-21 10:04:09.653466
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert not g.symbol2number
    assert not g.number2symbol
    assert not g.states
    assert not g.dfas
    assert g.labels == [(0, "EMPTY")]
    assert not g.keywords
    assert not g.tokens
    assert not g.symbol2label
    assert g.start == 256
    assert not g.async_keywords



# Generated at 2022-06-21 10:04:16.176575
# Unit test for method report of class Grammar
def test_Grammar_report():
    from io import StringIO
    from .pgen2 import driver

    g = Grammar()
    d = driver.Driver(g, "Grammar", False)
    d.parse_tokens(StringIO("pass"))
    buf = StringIO()
    g.report(buf)
    assert buf.getvalue().startswith("s2n\n")

# Generated at 2022-06-21 10:04:27.073504
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    G = Grammar()
    G.symbol2number["foo"] = 1
    G.number2symbol[1] = "foo"
    G.states = [
        [
            [(1, 4)],
            [(0, 3)],
            [(1, 4)],
            [(0, 3)],
            [(1, 4)],
            [(0, 3)],
        ]
    ]
    G.dfas[1] = ([[(1, 3), (2, 4)]], {4: 5})
    G.labels = [(0, None), ("...", "NAME"), ("...", "NAME"), ("...", "NAME")]
    G.keywords = {"foo": 1}
    G.tokens = {"foo": 1}
    G.symbol2label["foo"] = 1

# Generated at 2022-06-21 10:04:28.183718
# Unit test for constructor of class Grammar
def test_Grammar():
    gram = Grammar()

# Generated at 2022-06-21 10:04:40.263689
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Unit test for method load of class Grammar"""
    import pickle, sys
    import token as pytoken
    import pgen2
    # Generate a grammar
    g = pgen2.driver.load_grammar("Grammar/Grammar")
    # Dump it to a pickle file
    dumppath = sys.argv[0] + ".dump"
    g.dump(dumppath)
    # Load it from the pickle file
    got = Grammar()
    try:
        got.load(dumppath)
    finally:
        os.unlink(dumppath)
    # Compare it to the original
    def compare(a, b):
        try:
            if a != b: return 0
        except:
            return 0
        else:
            return 1

# Generated at 2022-06-21 10:04:50.792355
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.symbol2number = {"a": 1, "b": 2}
    g.number2symbol = {1: "a", 2: "b"}
    g.states = [[(1, 1)]]
    g.dfas = {1: ([[(1, 1), (2, 2)]], {1: 2}), 2: ([[(3, 3)]], {1: 2})}
    g.labels = [("a", None), ("b", "b"), ("c", None)]
    g.start = 1
    g.keywords = {"a": 1, "b": 2}
    g.tokens = {1: 2, 2: 3}
    g.symbol2label = {"a": 1, "b": 2, "c": 3}
    g.report()


# Generated at 2022-06-21 10:05:20.349164
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    def test_func1(x: int, y: int) -> int:
        return x + y

    def test_func2(x: int, y: int) -> int:
        return x - y

    # Test normal case
    grammar1 = Grammar()
    grammar1.symbol2number = {"k1": 1, "k2": 2}
    grammar1.number2symbol = {1: "v1", 2: "v2"}
    grammar1.dfas = {"k3": (1, 1, 1), "k4": (2, 2, 2)}
    grammar1.keywords = {"k1": 1, "k2": 2}
    grammar1.tokens = {"k3": 3, "k4": 4}

# Generated at 2022-06-21 10:05:27.416328
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """
    Test Grammar.dump().  We can't verify the exact contents of the pickle file
    (it depends on dictionary ordering, among other things), but we can at least
    verify that the file can be successfully unpickled.
    """
    from . import conv, pgen
    from .tokenize import generate_tokens
    from .token import INDENT, DEDENT, ENCODING

    g = Grammar()
    conv.initialize_grammar(g)

    # Dump the grammar tables to a pickle file.
    with tempfile.NamedTemporaryFile() as f:
        g.dump(f.name)
        f.flush()

        # Create a ParserGenerator instance using the tables.
        with open(f.name, "rb") as f2:
            pg = pgen.ParserGenerator

# Generated at 2022-06-21 10:05:33.510923
# Unit test for constructor of class Grammar
def test_Grammar():
    p = Grammar()
    assert p.symbol2number == {}
    assert p.number2symbol == {}
    assert p.states == []
    assert p.dfas == {}
    assert p.labels == [(0, "EMPTY")]
    assert p.keywords == {}
    assert p.tokens == {}
    assert p.symbol2label == {}
    assert p.start == 256

# Generated at 2022-06-21 10:05:42.615338
# Unit test for method report of class Grammar

# Generated at 2022-06-21 10:05:52.381955
# Unit test for method report of class Grammar
def test_Grammar_report():
    import pgen2.grammar
    import os
    import sys
    import tempfile
    from pgen2.parse import parse_grammar
    from pprint import pprint
    from io import StringIO

    fd, fn = tempfile.mkstemp()
    os.close(fd)

# Generated at 2022-06-21 10:05:53.665394
# Unit test for method load of class Grammar
def test_Grammar_load():
    a = Grammar()
    a.load('../../Grammar/Grammar')
    a.report()


# Generated at 2022-06-21 10:06:05.505893
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    def same_dict(d1: dict, d2: dict) -> bool:
        return all(d2[k] == v for k, v in d1.items())

    def same_list(l1: list, l2: list) -> bool:
        return all(l2[i] is v for i, v in enumerate(l1))

    g1 = Grammar()
    g1.symbol2number = {'a': 1, 'b': 2, 'c': 3}
    g1.number2symbol = {1: 'a', 2: 'b', 3: 'c'}
    g1.dfas = {1: ([], {}), 2: ([], {}), 3: ([], {})}
    g1.keywords = {'a': 1, 'b': 2, 'c': 3}
    g

# Generated at 2022-06-21 10:06:13.482863
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import pickle

    source = Grammar()

    g = Grammar()
    g.symbol2number = {1:2}
    g.number2symbol = {2:1}
    g.dfas = {1:1}
    g.keywords = {'1':1}
    g.tokens = {1:1}
    g.symbol2label = {1:1}
    g.labels = [1,2]
    g.states = [1,2]
    g.start = 256
    g.async_keywords = False

    g.symbol2number[1] = 2
    g.number2symbol[2] = 1
    g.dfas[1] = 1
    g.keywords['1'] = 1
    g.tokens[1] = 1

# Generated at 2022-06-21 10:06:25.302490
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    assert g1.start == 256
    g1.start = 257
    g2 = g1.copy()
    assert g2.start == 257
    g2.start = 258
    assert g1.start == 257


if __name__ == "__main__":
    import sys

    if len(sys.argv) == 1:
        print("Usage: %s graminit_tab.py [pickle-file]" % sys.argv[0])
        print("   or: %s pickle-file" % sys.argv[0])
        sys.exit(1)

    if len(sys.argv) == 3:
        from .conv import convert

        convert(sys.argv[1], sys.argv[2])
    else:
        g = Grammar()
        g

# Generated at 2022-06-21 10:06:37.639543
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import types

    class TestGrammar:
        def __init__(self) -> None:
            self.symbol2number: Dict[str, int] = {}
            self.number2symbol: Dict[int, str] = {}
            self.states: List[DFA] = []
            self.dfas: Dict[int, DFAS] = {}
            self.labels: List[Label] = [(0, "EMPTY")]
            self.keywords: Dict[str, int] = {}
            self.tokens: Dict[int, int] = {}
            self.symbol2label: Dict[str, int] = {}
            self.start = 256
            # Python 3.7+ parses async as a keyword, not an identifier
            self.async_key

# Generated at 2022-06-21 10:06:59.190949
# Unit test for method report of class Grammar
def test_Grammar_report():
    p = Grammar()
    p.report()

# Generated at 2022-06-21 10:07:08.587810
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    oldGrammar = Grammar()
    oldGrammar.symbol2number = {'foo': 1, 'bar': 2}
    oldGrammar.number2symbol = {1: 'foo', 2: 'bar'}
    oldGrammar.states = [[[(1, 3), (2, 4)], [(3, 0)], [(4, 0)]],
                         [[(1, 3), (2, 4)], [(3, 0)], [(4, 0)]]]
    oldGrammar.dfas = {2: (oldGrammar.states[0], {1: 1, 2: 1}),
                       3: (oldGrammar.states[1], {1: 1, 2: 1})}
    oldGrammar.labels = [(1, 'foo'), (2, 'bar')]
   

# Generated at 2022-06-21 10:07:11.619570
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import grammar
    from .pgen2 import driver

    assert isinstance(grammar, Grammar)
    g = driver.load_grammar()
    assert isinstance(g, Grammar)

# Generated at 2022-06-21 10:07:13.808113
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    grammar = Grammar()
    grammar_copy = grammar.copy()
    assert grammar == grammar_copy
    assert grammar.copy() != grammar

# Generated at 2022-06-21 10:07:25.465487
# Unit test for method report of class Grammar
def test_Grammar_report():

    class Dummy(object):
        def __init__(self):
            self.s2n = {'s1': 1, 's2': 2}
            self.n2s = {1: 'n1', 2: 'n2'}
            self.states = [[[(1, 2)], [(1, 4)], [(1, 2)], [(1, 3)]]]
            self.dfas = {1: ([[(1, 2)], [(1, 4)], [(1, 2)], [(1, 3)]],
                             {0: 5, 1: 0, 2: 5, 3: 5, 4: 5}),
                         2: ([[(1, 1)], [(1, 3)]] , {0: 4, 1: 0, 2: 4, 3: 4})}

# Generated at 2022-06-21 10:07:26.080998
# Unit test for constructor of class Grammar
def test_Grammar():
    assert Grammar()

# Generated at 2022-06-21 10:07:31.230776
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert not g.symbol2number
    assert not g.number2symbol
    assert not g.states
    assert not g.dfas
    assert g.labels == [(0, "EMPTY")]
    assert not g.keywords
    assert not g.tokens
    assert not g.symbol2label
    assert g.start == 256
    assert not g.async_keywords

# Generated at 2022-06-21 10:07:38.348806
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.test_attr = 'blah'
    g.test_attr2 = 'blah2'
    g1 = g.copy()
    assert g.test_attr == g1.test_attr
    assert g.test_attr2 == g1.test_attr2
    g1.test_attr = 'blah'
    g1.test_attr2 = 'blah2'
    assert g.test_attr != g1.test_attr
    assert g.test_attr2 != g1.test_attr2

# Generated at 2022-06-21 10:07:40.365427
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump('./grammar.pickle')


# Generated at 2022-06-21 10:07:41.414185
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()



# Generated at 2022-06-21 10:08:20.326432
# Unit test for method load of class Grammar

# Generated at 2022-06-21 10:08:28.774512
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import os
    import unittest

    class MyGrammarTest(unittest.TestCase):
        grammar_path = os.path.join(os.path.dirname(__file__), "../Grammar.txt")

        def test_copy(self):
            import io
            import io
            import pickle
            import pickletools

            from . import pgen2

            g_org = pgen2.driver.load_grammar(self.grammar_path)
            g_new = g_org.copy()
            assert g_org is not g_new
            assert g_org.symbol2number == g_new.symbol2number
            assert g_org.number2symbol == g_new.number2symbol
            assert g_org.states == g_new.states
            assert g_org