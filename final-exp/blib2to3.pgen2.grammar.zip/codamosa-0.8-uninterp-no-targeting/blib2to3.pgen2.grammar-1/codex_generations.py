

# Generated at 2022-06-21 09:58:56.176491
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen
    from .parse import ParserError

    tmpdir = tempfile.gettempdir()
    filename = os.path.join(tmpdir, "test_grammar")

# Generated at 2022-06-21 09:58:59.131111
# Unit test for method load of class Grammar
def test_Grammar_load():
  from Python.test.test_grammar import pgen_data

  g = Grammar()
  g.load(pgen_data)

# Generated at 2022-06-21 09:59:04.905514
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    if not hasattr(token, "START_LEXEME"):
        return
    from .pgen2 import driver

    g = Grammar()
    g.loads(driver.grammar)


__all__ = [
    "Grammar",
    "Label",
    "DFA",
    "DFAS",
    "opmap",
]

# Generated at 2022-06-21 09:59:09.996573
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-21 09:59:22.201369
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-21 09:59:33.471177
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    class MyGrammar(Grammar):
        def __init__(self, x: int) -> None:
            super().__init__()
            self.x = x

    g1 = MyGrammar(1)
    g2 = g1.copy()
    assert g1 is not g2
    assert g1.x == g2.x
    g1.y = 1
    assert not hasattr(g2, "y")
    g1.x = 2
    assert g1.x == 2
    assert g2.x == 1
    # In Python 2.7, the builtins don't have a __dict__
    g1.states.append(1)  # type: ignore
    assert len(g1.states) == len(g2.states) + 1

# Generated at 2022-06-21 09:59:43.080764
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-21 09:59:53.303775
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-21 09:59:55.601147
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io

    out = io.StringIO()
    grammar = Grammar()
    grammar.report()
    assert out.getvalue() == ""

# Generated at 2022-06-21 10:00:03.226406
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    import py
    import pgen2.conv

    OUTPUT = py.path.local.sysfind("python3.6")
    if OUTPUT is None:
        py.test.skip("need python3.6")

    print(OUTPUT.dirname)
    gram = pgen2.conv.generate_grammar(OUTPUT.dirname)
    gram_copy = Grammar()
    gram_copy.loads(pickle.dumps(gram))
    assert gram.async_keywords == gram_copy.async_keywords

# Generated at 2022-06-21 10:00:23.926850
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2 import driver
    from . import token

    grammar = driver.load_grammar(token)
    tmp_file = "/tmp/grammar.test.pickle"
    grammar.dump(tmp_file)
    grammar1 = Grammar()
    grammar1.load(tmp_file)

    assert grammar.symbol2number == grammar1.symbol2number
    assert grammar.number2symbol == grammar1.number2symbol
    assert grammar.states == grammar1.states
    assert grammar.dfas == grammar1.dfas
    assert grammar.labels == grammar1.labels
    assert grammar.keywords == grammar1.keywords
    assert grammar.tokens == grammar1.tokens
    assert grammar.symbol2label == grammar1.symbol2label

# Generated at 2022-06-21 10:00:30.960529
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import ast
    import io
    import sys
    import unittest
    from unittest import mock
    from importlib import reload
    import pickle
    import tokenize
    import token
    import io
    import os.path
    import importlib
    import pgen2.conv

    # Helper functions that allow us to reload the parser module after
    # adding it to the path.
    def reload_grammar():
        """
        Reload the grammar module.
        """
        importlib.reload(pgen2.conv)
        reload(pgen2.pgen2)

    def load_grammar(filename, debug=False):
        """
        Load a grammar from the given filename.
        """
        if debug:
            print("Loading grammar from", filename)

# Generated at 2022-06-21 10:00:38.960654
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    grammar = Grammar()

# Generated at 2022-06-21 10:00:48.965734
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g2 = g1.copy()
    assert g1 != g2
    assert g1.symbol2number == g2.symbol2number
    assert g1.number2symbol == g2.number2symbol
    assert g1.dfas == g2.dfas
    assert g1.keywords == g2.keywords
    assert g1.tokens == g2.tokens
    assert g1.symbol2label == g2.symbol2label
    assert g1.labels == g2.labels
    assert g1.states == g2.states
    assert g1.start == g2.start
    assert g1.async_keywords == g2.async_keywords

# Generated at 2022-06-21 10:00:51.672742
# Unit test for constructor of class Grammar
def test_Grammar():
    try:
        import builtins
    except ImportError:
        import __builtin__ as builtins
    assert builtins.Grammar

# Generated at 2022-06-21 10:01:01.631518
# Unit test for method load of class Grammar
def test_Grammar_load():
    gr = Grammar()
    gr.start = 1
    gr.symbol2number = {'foo': 1, 'bar': 2}
    gr.number2symbol = {1: 'foo', 2: 'bar'}
    gr.dfas = {1: (4, 8), 2: (15, 19)}
    gr.states = [[(2, 3)], [(4, 5), (6, 7)], [], [(8, 9), (10, 11)]]
    # only states and symbol table are checked
    assert gr.states == [[(2, 3)], [(4, 5), (6, 7)], [], [(8, 9), (10, 11)]]
    assert gr.symbol2number == {'foo': 1, 'bar': 2}

# Generated at 2022-06-21 10:01:07.192862
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    a = Grammar()
    a.symbol2number = { "if": 1, "else": 2 }
    a.async_keywords = True
    b = a.copy()
    b.symbol2number["while"] = 3
    b.async_keywords = False
    assert a.symbol2number == { "if": 1, "else": 2 }
    assert b.symbol2number == { "if": 1, "else": 2, "while": 3 }
    assert a.async_keywords == True
    assert b.async_keywords == False

# Generated at 2022-06-21 10:01:12.906850
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pytest
    from .conv import convert
    from . import pgen2

    with pytest.raises(ValueError):
        # Grammar doesn't have 'dump' method
        grammar = Grammar()
        grammar.dump(tempfile.mktemp(dir="/tmp"))

    grammar = convert(pgen2.tokenize(pgen2.grammar))
    grammar.dump(tempfile.mktemp(dir="/tmp"))

# Generated at 2022-06-21 10:01:14.606677
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()

# Generated at 2022-06-21 10:01:24.720899
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    g.symbol2number = { 'var': 257, 'mystery': 258 }
    g.number2symbol = { 257: 'var', 258: 'mystery' }
    g.states = [ [ (0, 2) ], [ (0, 3) ] ]
    g.dfas = { 257: ( [ (0, 2) ], 8 ), 258: ( [ (0, 3) ], 9 ) }
    g.labels = [ (0, 'EMPTY'), (257, None), (258, None) ]
    g.start = 257
    g.keywords = { 'keyword': 257 }
    g.tokens = { 257: 257 }
    g.symbol2label = { 'var': 257, 'mystery': 258 }
    g.async_keywords = False
    p

# Generated at 2022-06-21 10:01:43.937177
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {}
    g.number2symbol = {}
    g.dfas = {}
    g.keywords = {}
    g.tokens = {}
    g.symbol2label = {}
    g.labels = []
    g.states = []
    g.start = 256
    g.async_keywords = False
    g1 = g.copy()
    assert g1.symbol2number == g.symbol2number
    assert g1.number2symbol == g.number2symbol
    assert g1.dfas == g.dfas
    assert g1.keywords == g.keywords
    assert g1.tokens == g.tokens
    assert g1.symbol2label == g.symbol2label
    assert g

# Generated at 2022-06-21 10:01:49.969133
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2 import driver

    grammar = driver.load_grammar("Grammar.txt")
    outfile = tempfile.NamedTemporaryFile(delete=False)
    try:
        grammar.dump(outfile.name)
        assert os.path.exists(outfile.name)
    finally:
        outfile.close()
        os.unlink(outfile.name)

# Generated at 2022-06-21 10:01:57.556362
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.symbol2number = {"A": 1, "B": 2}
    g.number2symbol = {1: "A", 2: "B"}
    g.states = [
        [
            [(11, 1)],
            [(22, 2)],
            [(11, 1), (22, 2)],
            [(-30, 1), (22, 3)],
        ]
    ]
    g.labels = [(0, "EMPTY"), (11, None), (22, "ID"), (-30, "STRING")]
    g.dfas = {
        1: (g.states[0], {"ID": 1, "STRING": 1}),
        2: (g.states[0], {"ID": 1, "STRING": 1}),
    }
    g.key

# Generated at 2022-06-21 10:01:59.322333
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    assert g.copy() is not g



# Generated at 2022-06-21 10:02:02.537985
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    from . import grammar

    with pytest.raises(EOFError):
        grammar.Grammar().loads(b"")

# Generated at 2022-06-21 10:02:03.628842
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Disabled due to dependency on the token module
    assert 0

# Generated at 2022-06-21 10:02:14.817079
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io
    import sys
    import unittest

    from .pgen2 import driver

    class GrammarReportTest(unittest.TestCase):
        def test_Grammar_report(self) -> None:
            graminit = driver.load_grammar("Grammar.txt")
            io_obj = io.StringIO()  # type: ignore
            sys.stdout = io_obj
            graminit.dump("Grammar.pickle")
            gram = Grammar()
            gram.load("Grammar.pickle")
            gram.report()
            sys.stdout = sys.__stdout__
            output = io_obj.getvalue()

# Generated at 2022-06-21 10:02:21.093135
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import sys
    import py_compile
    from test.support import captured_stdout
    from test.test_grammar import test_pickle, _test_weakref

    grammar = test_pickle()
    tmpdir = tempfile.mkdtemp(prefix='test_grammar_')

# Generated at 2022-06-21 10:02:31.376356
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("test_Grammar_dump.pickle")


if __name__ == "__main__":
    import sys
    import pickle

    grammar = Grammar()
    # mypyc generates objects that don't have a __dict__, but they
    # do have __getstate__ methods that will return an equivalent
    # dictionary
    if hasattr(grammar, "__dict__"):
        d = grammar.__dict__
    else:
        d = grammar.__getstate__()  # type: ignore
    pickle.dump(d, sys.stdout, pickle.HIGHEST_PROTOCOL)

# Generated at 2022-06-21 10:02:40.610301
# Unit test for method loads of class Grammar

# Generated at 2022-06-21 10:02:55.289506
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io
    import sys
    import unittest

    class GrammarTestCase(unittest.TestCase):
        def setUp(self):
            self.grammar = Grammar()
            self.grammar.symbol2number = {'symbol2number': 1}
            self.grammar.number2symbol = {'number2symbol': 2}
            self.grammar.states = {'states': 3}
            self.grammar.dfas = {'dfas': 4}
            self.grammar.labels = {'labels': 5}
            self.grammar.keywords = {'keywords': 6}
            self.grammar.tokens = {'tokens': 7}
            self.grammar.symbol2label = {'symbol2label': 8}
            self.gram

# Generated at 2022-06-21 10:03:06.848993
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io, pprint, re
    from . import conv, pgen

    # Create a grammar instance from a file, if the first argument is a file
    if len(sys.argv) > 1:
        filename = sys.argv[1]
        if re.search(".tar$", filename) or re.search(".tgz$", filename):
            g = conv.Converter(filename)
        else:
            g = pgen.Driver(filename)
    else:
        # or just create an empty instance
        g = Grammar()

    # Redirect stdout to an io.StringIO instance, so we can compare
    # the dump output with a fixed reference
    f = io.StringIO()
    sys.stdout=f

    # Call the report() method
    g.report()

    # Get the dumped output


# Generated at 2022-06-21 10:03:12.429110
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .conv import gen_py_grammar
    from .pgen2 import driver
    from . import parse

    g = gen_py_grammar("Python", "/tmp")
    driver.make_grammar_tables(g, "data")
    t = parse.PyParser("2.6", input="")
    t.grammar = g
    t.grammar.dump("/tmp")



# Generated at 2022-06-21 10:03:20.472708
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g2 = g.copy()
    for attr in vars(g):
        if attr != "dfas":
            assert getattr(g, attr) == getattr(g2, attr)
        elif "dfas" == attr:
            dfas1 = getattr(g, attr)
            dfas2 = getattr(g2, attr)
            for key in dfas1:
                assert dfas1[key] == dfas2[key]
            for key in dfas2:
                assert dfas1[key] == dfas2[key]

# Generated at 2022-06-21 10:03:33.292009
# Unit test for method load of class Grammar
def test_Grammar_load():
    def _DummyGrammar(self):
        self.state = "Dummy"

    test_symbol2number = {"test": 0}
    test_number2symbol = {0: "test"}
    test_states = [[(0, 1)], [(1, 2)]]
    test_dfas = {0: (test_states[0], {0: 1})}
    test_labels = [(0, None)]
    test_keywords = {}
    test_tokens = {0: 0}
    test_symbol2label = {}
    test_start = 256

    t = Grammar()
    t.symbol2number = test_symbol2number
    t.number2symbol = test_number2symbol
    t.states = test_states
    t.dfas = test_dfas

# Generated at 2022-06-21 10:03:44.191320
# Unit test for method report of class Grammar
def test_Grammar_report():
    grammar = Grammar()
    grammar.report()
    grammar.symbol2number, grammar.number2symbol = { 'symbol1':1 }, { 1:'symbol1' }
    grammar.keywords, grammar.tokens = { 1:0, 2:1 }, { 3:2 }
    grammar.states, grammar.dfas = [[[0,1]],{1:(1,{1:1})}], { 1:2, 2:3 }
    grammar.labels = [(1, 'key1'), (2, 'key2'), (3, 'tok3')]
    grammar.start = 4
    grammar.report()


if __name__ == "__main__":
    import unittest

    from . import conv


# Generated at 2022-06-21 10:03:56.304313
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    from .pgen2 import tokenize

    class Grammar_dump_TestCase(unittest.TestCase):
        def setUp(self):
            self.g = tokenize.generate_grammar()
            self.dir = tempfile.mkdtemp()

        def tearDown(self):
            import shutil

            shutil.rmtree(self.dir)

        def test_dump(self):
            filename = os.path.join(self.dir, "Grammar.pkl")
            self.g.dump(filename)
            g2 = Grammar()
            g2.load(filename)
            self.assertEqual(self.g.symbol2number, g2.symbol2number)

# Generated at 2022-06-21 10:04:02.384948
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-21 10:04:07.116025
# Unit test for constructor of class Grammar
def test_Grammar():
    assert Grammar().symbol2number == {}
    assert Grammar().number2symbol == {}
    assert Grammar().states == []
    assert Grammar().dfas == {}
    assert Grammar().labels == [(0, "EMPTY")]
    assert Grammar().keywords == {}
    assert Grammar().tokens == {}

# Generated at 2022-06-21 10:04:09.120925
# Unit test for method report of class Grammar
def test_Grammar_report():
    # Should print a bunch of stuff to stdout.
    g = Grammar()
    g.report()

# Generated at 2022-06-21 10:04:25.372324
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    grammar = Grammar()
    assert grammar.keywords == {}

    # Test pickle with empty dict
    pkl = b'\x80\x03celemental.parser.Grammar\nGrammar\nq\x00)\x81q\x01}q\x02sb.'
    grammar.loads(pkl)
    assert grammar.keywords == {}

    # Test pickle with dict containing a single key
    pkl = b'\x80\x03celemental.parser.Grammar\nGrammar\nq\x00)\x81q\x01}q\x02(X\x06\x00\x00\x00keywordq\x03X\x01\x00\x00\x00xq\x04K\x01sbu.'

# Generated at 2022-06-21 10:04:29.625373
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    class A: pass
    a = A()
    g.dump(a)
    g.dump(None)
    g.dump(a)

# Generated at 2022-06-21 10:04:34.691890
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    for str in [
        "s2n",
        "n2s",
        "states",
        "dfas",
        "labels",
        "keywords",
        "tokens",
        "symbol2label",
    ]:
        assert hasattr(g, str)

# Generated at 2022-06-21 10:04:46.970527
# Unit test for method load of class Grammar
def test_Grammar_load():
    def check(s, t):
        grammar = Grammar()
        grammar.loads(s.encode("utf-8"))
        assert grammar.number2symbol == t.number2symbol
        assert grammar.states == t.states
        assert grammar.dfas == t.dfas
        assert grammar.labels == t.labels
        assert grammar.symbol2number == t.symbol2number
        assert grammar.symbol2label == t.symbol2label


# Generated at 2022-06-21 10:04:57.641333
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    from pickletools import dis
    from . import token
    from .pgen2 import driver

    path = driver.get_grammar()
    # On Windows, Python 3.6+ doesn't like opening a file in binary
    # mode while a different process (Python) has it open.
    if os.name == "nt" and sys.version_info[:2] >= (3, 6):
        g = Grammar()
        with open(path, "rb") as f:
            g.loads(f.read())
    else:
        with open(path, "rb") as f:
            g = pickle.load(f)
    assert hasattr(g, "LABELS")
    assert hasattr(g, "NONTERMINALS")
    assert hasattr(g, "terminals")

# Generated at 2022-06-21 10:05:02.665149
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    class Foo(Grammar):
        def __init__(self):
            self.foo = {'bar': 'baz'}
    f = Foo()
    f.dump('/tmp/foo.pkl')
    assert os.path.exists('/tmp/foo.pkl')
    os.remove('/tmp/foo.pkl')

# Generated at 2022-06-21 10:05:09.677746
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords == False


# Generated at 2022-06-21 10:05:21.790755
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    grammar = Grammar()

# Generated at 2022-06-21 10:05:33.786948
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {"a": 1}
    g.number2symbol = {1: "a"}
    g.dfas = {"a": (1, 2)}
    g.keywords = {"a": 1}
    g.tokens = {"a": 1}
    g.symbol2label = {"a": 1}
    g.labels = [("a", "b")]
    g.states = ["a"]
    g.start = 256
    g.async_keywords = False
    g2 = g.copy()
    assert g is not g2
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.dfas == g2.dfas
    assert g

# Generated at 2022-06-21 10:05:43.027583
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # pylint: disable=missing-docstring,too-many-branches,too-many-statements
    # pylint: disable=too-many-nested-blocks,too-many-locals,too-many-lines
    import pickle
    import tempfile
    from typing import Dict

    from grako.ast import AST
    from grako.parsing import Parser
    from grako.tool import compile
    from grako.codegen import cpp

    class ModelParser(Parser):
        def __init__(self, **kwargs):
            kwargs['optimize'] = 'LALR'
            kwargs['keep_all_tokens'] = True
            super(ModelParser, self).__init__(**kwargs)
            self._last_model = None
            self._last_module

# Generated at 2022-06-21 10:05:51.156714
# Unit test for method report of class Grammar
def test_Grammar_report():
    gr = Grammar()
    gr.report()

# Local Variables:
# tab-width:4
# indent-tabs-mode:nil
# End:
# vim: set expandtab tabstop=4 shiftwidth=4:

# Generated at 2022-06-21 10:05:57.584795
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {'None': 1, 'Foo': 2}
    g.number2symbol = {1: 'None', 2: 'Foo'}
    g.dfas = {1: [[[0, 1], [1, 1]], {1: 1}]}
    g.keywords = {'key': 1, 'words': 2}
    g.tokens = {58: 1, 17: 2}
    g.symbol2label = {'Foo': 1}
    g.labels = [(1, 2), (0, 1)]
    g.states = [[[1, 1], [2, 2]]]
    g.start = 2
    g.async_keywords = False
    g2 = g.copy()

# Generated at 2022-06-21 10:06:08.452592
# Unit test for method report of class Grammar
def test_Grammar_report():
    from textwrap import dedent

    g = Grammar()
    g.number2symbol = {}
    g.start = 256
    g.states = [(0, 1), (2, 3)]
    g.labels = [(4, 5), (6, 7)]
    g.dfas = {8: (9, {10: 1}), 11: (12, {13: 1})}
    g.symbol2number = {14: 15, 16: 17}
    g.keywords = {18: 19, 20: 21}
    g.tokens = {22: 23, 24: 25}


# Generated at 2022-06-21 10:06:14.316519
# Unit test for constructor of class Grammar
def test_Grammar():
    from . import yacc
    from . import pgen2

    fname = os.path.join(os.path.dirname(__file__), "python3.5.g")
    g = yacc.yacc(debug=0, write_tables=False, debugfile=fname, tabmodule="foo")

    g2 = Grammar()
    g2.load(fname)
    assert g is not g2

    g3 = Grammar()
    pgen2.load_grammar(g3, "python3.5")
    assert g is not g3
    assert g2 is not g3

# Generated at 2022-06-21 10:06:25.866971
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar_dict = {
        "async_keywords": False,
        "dfas": {},
        "keywords": {},
        "labels": [(0, "EMPTY")],
        "number2symbol": {},
        "start": 256,
        "states": [],
        "symbol2label": {},
        "symbol2number": {},
        "tokens": {},
    }
    grammar_bytes = pickle.dumps(grammar_dict, pickle.HIGHEST_PROTOCOL)
    grammar.loads(grammar_bytes)
    assert grammar.async_keywords == grammar_dict["async_keywords"]
    assert grammar.dfas == grammar_dict["dfas"]

# Generated at 2022-06-21 10:06:38.215013
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.number2symbol = {1: 'x', 2: 'y'}
    g.labels = [(i, i) for i in range(10)]
    g.dfas = {i: [0,1,2,3] for i in range(10)}
    g.states = [g.dfas[i] for i in range(10)]
    g.symbol2label = {chr(ord('a') + i): i for i in range(10)}
    g.symbol2number = {chr(ord('A') + i): i for i in range(10)}
    g.keywords = {chr(ord('k') + i): i for i in range(10)}
    g.tokens = {i: i + 100 for i in range(10)}
    g

# Generated at 2022-06-21 10:06:41.768973
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    gs = Grammar()
    copy_gs = gs.copy()
    assert id(gs) != id(copy_gs)

# Generated at 2022-06-21 10:06:52.850386
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    a = Grammar()
    b = a.copy()
    assert a == b
    assert a is not b
    assert a.symbol2number == b.symbol2number
    assert a.symbol2number is not b.symbol2number
    assert a.number2symbol == b.number2symbol
    assert a.number2symbol is not b.number2symbol
    assert a.dfas == b.dfas
    assert a.dfas is not b.dfas
    assert a.keywords == b.keywords
    assert a.keywords is not b.keywords
    assert a.tokens == b.tokens
    assert a.tokens is not b.tokens
    assert a.symbol2label == b.symbol2label

# Generated at 2022-06-21 10:07:05.668523
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """Test dump method of Grammar class"""
    d = {}
    d["symbol2number"] = {"a": 1, "b": 2}
    d["number2symbol"] = {1: "a", 2: "b"}
    d["states"] = [[(1, 2)]]
    d["dfas"] = {2: ([(1, 2)], {1: 1})}
    d["labels"] = [(0, "EMPTY"), (1, None), (2, "a")]
    d["keywords"] = {"b": "b"}
    d["tokens"] = {"a": "a"}
    d["symbol2label"] = {"a": "a"}
    d["start"] = 256
    d["async_keywords"] = False
    g = Grammar()

# Generated at 2022-06-21 10:07:10.763132
# Unit test for method report of class Grammar
def test_Grammar_report():
    """
    >>> g = Grammar()
    >>> g.report()
    s2n
    {}
    n2s
    {}
    states
    []
    dfas
    {}
    labels
    [(0, 'EMPTY')]
    start 256
    """

if __name__ == "__main__":
    import doctest

    doctest.testmod(verbose=True)

# Generated at 2022-06-21 10:07:23.895821
# Unit test for method report of class Grammar
def test_Grammar_report():
    # Test for the method report of class Grammar.
    # We do not test the exact output, but simply call the method.
    Grammar().report()

del opmap_raw
del opmap

# Generated at 2022-06-21 10:07:28.740763
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    gram = Grammar()
    gram.loads(b'\x80\x03cexecfile\nreload\nq\x00.')
    assert gram.symbol2number == {'execfile': 131, 'reload': 132}
    assert gram.number2symbol == {131: 'execfile', 132: 'reload'}
    assert gram.states == [[], []]
    assert gram.dfas == {131: ([], {257: 1}), 132: ([], {257: 1})}
    assert gram.labels == [(0, 'EMPTY')]
    assert gram.keywords == {}
    assert gram.tokens == {}
    assert gram.symbol2label == {}
    assert gram.start == 257

# Generated at 2022-06-21 10:07:31.791779
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import pgen2.pgen
    grammar = pgen2.pgen.Grammar()
    new_grammar = grammar.copy()
    assert new_grammar.__class__ is pgen2.pgen.Grammar

# Generated at 2022-06-21 10:07:40.577243
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.states = [[(0, 1), (0, 2), (0, 3)], [(0, 4)]]
    g.labels = []
    g2 = g.copy()
    assert g is not g2
    assert g.states is not g2.states
    assert g.states[0] is not g2.states[0]
    assert g.states[0][0] is not g2.states[0][0]
    assert g.states[0][0][0] is g2.states[0][0][0]
    assert g.states == g2.states


# Generated at 2022-06-21 10:07:50.407011
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {'A': 1, 'B': 2}
    g.number2symbol = {1: 'A', 2: 'B'}
    g.states = [[(1, 2), (2, 3)], [(3, 4), (4, 5)]]
    g.dfas = {1: ([(1, 2), (2, 3)], {1: 2, 2: 3}),
              2: ([(3, 4), (4, 5)], {3: 4, 4: 5})}
    g.labels = [(0, 'EMPTY'), (1, None), (2, None), (3, None), (4, None), (5, None)]
    g.keywords = {'A': 1, 'B': 2}

# Generated at 2022-06-21 10:07:52.603306
# Unit test for constructor of class Grammar
def test_Grammar():
  g = Grammar()



# Generated at 2022-06-21 10:07:59.573773
# Unit test for method load of class Grammar
def test_Grammar_load():
    # These tests locate the test_data directory in the same folder as where this
    # test file is located, so it needs to be run from within the astroid root
    # directory.
    dir_path = os.path.dirname(os.path.realpath(__file__))
    g = Grammar()
    g.load(os.path.join(dir_path, "test_data", "Grammar.pickle"))
    assert g.symbol2number["and"] == 259
    assert g.symbol2number["not"] == 263
    assert g.start == 256


# Generated at 2022-06-21 10:08:04.134010
# Unit test for method report of class Grammar
def test_Grammar_report():
    import sys
    import types
    anonymousG = Grammar()
    result = anonymousG.report()
    assert result is None
    try:
        module = types.ModuleType("test_Grammar_report")
        sys.modules["test_Grammar_report"] = module
        importlib.reload(module)
    finally:
        del sys.modules["test_Grammar_report"]

# Generated at 2022-06-21 10:08:09.185667
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.report()
    g.dump("test_Grammar_dump.pk")
    g2 = Grammar()
    g2.load("test_Grammar_dump.pk")
    g2.report()
    os.remove("test_Grammar_dump.pk")

# Generated at 2022-06-21 10:08:19.894033
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    grammar = Grammar()