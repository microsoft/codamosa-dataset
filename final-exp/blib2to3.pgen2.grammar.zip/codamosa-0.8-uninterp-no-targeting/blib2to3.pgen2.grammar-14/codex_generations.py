

# Generated at 2022-06-21 09:58:34.950767
# Unit test for constructor of class Grammar
def test_Grammar():
    grammar = Grammar()
    grammar.report()


test_Grammar()

# Generated at 2022-06-21 09:58:43.049044
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io
    import sys
    import unittest
    import sys

    class GrammarTestCase(unittest.TestCase):
        def setUp(self):
            self.grammar = Grammar()

# Generated at 2022-06-21 09:58:45.506630
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()
    assert True # did not crash

if __name__ == "__main__":
    test_Grammar_report()

# Generated at 2022-06-21 09:58:58.457763
# Unit test for method dump of class Grammar

# Generated at 2022-06-21 09:59:07.439739
# Unit test for constructor of class Grammar
def test_Grammar():
    grammar = Grammar()
    assert isinstance(grammar.symbol2number, dict)
    assert isinstance(grammar.number2symbol, dict)
    assert isinstance(grammar.states, list)
    assert isinstance(grammar.dfas, dict)
    assert isinstance(grammar.labels, list)
    assert isinstance(grammar.keywords, dict)
    assert isinstance(grammar.tokens, dict)
    assert isinstance(grammar.symbol2label, dict)
    assert isinstance(grammar.start, int)
    assert isinstance(grammar.async_keywords, bool)


# Generated at 2022-06-21 09:59:08.470140
# Unit test for constructor of class Grammar
def test_Grammar():
    x = Grammar()
    # just make sure we can get here ...


# Generated at 2022-06-21 09:59:10.601351
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()

# Generated at 2022-06-21 09:59:13.701537
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    pkl = g.dump("./Grammar.pickle")
    g.loads(pkl)

# Generated at 2022-06-21 09:59:15.395592
# Unit test for constructor of class Grammar
def test_Grammar():
    p = Grammar()
    p.report()



# Generated at 2022-06-21 09:59:20.236463
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # test for no module
    grammar = Grammar()
    with open(os.path.join(os.path.dirname(__file__), "Grammar.pkl"), "rb") as f:
        pkl = f.read()
    grammar.loads(pkl)



# Generated at 2022-06-21 09:59:35.450933
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    # Test more than just shallow copy.
    symbol2number = {'foo': 1, 'bar': 2}
    number2symbol = {1: 'foo', 2: 'bar'}
    labels = [(1, 'foo'), (2, 'bar')]
    states = [0]
    states[0] = [(0, 0), (0, 1)]
    dfas = {1: (0, {1: 1}), 2: (0, {2: 1})}
    g = Grammar()
    g.symbol2number = symbol2number
    g.number2symbol = number2symbol
    g.labels = labels
    g.states = states
    g.dfas = dfas
    g1 = g.copy()
    assert g1.symbol2number == symbol2number

# Generated at 2022-06-21 09:59:38.685443
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    s = pickle.dumps(g, pickle.HIGHEST_PROTOCOL)
    g = Grammar()
    g.loads(s)
    # g.report()

# Generated at 2022-06-21 09:59:45.767493
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    assert hasattr(Grammar, "loads")

    # Attributes set by loads (used by pickle)
    assert hasattr(Grammar, "symbol2number")
    assert hasattr(Grammar, "number2symbol")
    assert hasattr(Grammar, "states")
    assert hasattr(Grammar, "dfas")
    assert hasattr(Grammar, "labels")
    assert hasattr(Grammar, "start")
    assert hasattr(Grammar, "keywords")
    assert hasattr(Grammar, "tokens")

    # Attributes set by loads (used only by test)
    assert hasattr(Grammar, "symbol2label")
    assert hasattr(Grammar, "async_keywords")

    # load(), dump() not used by test
   

# Generated at 2022-06-21 09:59:46.940962
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    g.dump('pgen_table.pickle')

# Generated at 2022-06-21 09:59:57.213033
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """Check the dump method of Grammar"""

    gr = Grammar()
    gr.symbol2number["A"] = 10
    gr.symbol2number["B"] = 20
    gr.symbol2number["C"] = 30
    gr.number2symbol[10] = "A"
    gr.number2symbol[20] = "B"
    gr.number2symbol[30] = "C"

    gr.states.append([(0, 5)])
    gr.states.append([(0, 6)])
    gr.states.append([(0, 7)])
    gr.states.append([(0, 8)])
    gr.states.append([(0, 9)])
    gr.states.append([(10, 6)])
    gr.states.append([(11, 7)])

# Generated at 2022-06-21 10:00:05.220342
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import os
    import tempfile
    import importlib
    from . import pickle as pickle

    g = Grammar()
    fd, filename = tempfile.mkstemp()
    os.close(fd)
    g.dump(filename)
    assert os.path.exists(filename)
    assert importlib.util.find_spec("_pickle")
    assert pickle.HIGHEST_PROTOCOL >= 4
    with open(filename, "rb") as f:
        d = pickle.load(f)
    os.remove(filename)
    sys.path.append('./')


# Generated at 2022-06-21 10:00:08.206404
# Unit test for method load of class Grammar
def test_Grammar_load():
    from parser import Parser
    from pytree import Leaf
    # test loading of grammar tables from pickle file
    p = Parser()
    p.grammar = Grammar()
    p.grammar.load("Examples/Grammar.pickle")
    l = Leaf(1, "def")
    p.add_lookahead(l)
    assert p.add_lookaheads.lookahead == {'def': 1}

# Generated at 2022-06-21 10:00:17.723454
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import copy
    import unittest

    class GrammarCopyTest(unittest.TestCase):
        def test_copy(self):
            g1 = Grammar()
            g2 = copy.copy(g1)
            self.assertEqual(g1, g2)
            g1.symbol2number = g1.symbol2number.copy()
            self.assertNotEqual(g1, g2)
            g2 = g1.copy()
            self.assertEqual(g1, g2)

    unittest.TextTestRunner().run(unittest.TestLoader().loadTestsFromTestCase(GrammarCopyTest))

test_Grammar_copy()

# Generated at 2022-06-21 10:00:19.053331
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Util/graminit.pkl")

# Generated at 2022-06-21 10:00:27.787466
# Unit test for method load of class Grammar
def test_Grammar_load():
  # Test the Grammar class.
  from . import test_grammar, test_grammar_pgen
  filename = test_grammar.__file__
  if filename.endswith(".pyc"):
    filename = filename[:-1]
  g = test_grammar_pgen.grammar
  g1 = Grammar()
  g1.load(filename)
  assert g1.symbol2number == g.symbol2number
  assert g1.number2symbol == g.number2symbol
  assert g1.states == g.states
  assert g1.dfas == g.dfas
  assert g1.labels == g.labels
  assert g1.keywords == g.keywords
  assert g1.tokens == g.tokens
  assert g1.start == g

# Generated at 2022-06-21 10:00:38.827235
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from hashlib import md5
    from itertools import chain
    import pgen2.grammar

    for gram in chain(pgen2.grammar.iter_grammars(), pgen2.grammar.iter_grammars(3)):
        try:
            # The pickle has a hash of the grammar version.
            m = md5()
            m.update(gram.version.encode("utf8"))
            pkl = pickle.dumps(gram.__getstate__(), pickle.HIGHEST_PROTOCOL)
            if pkl.startswith(m.digest()):
                raise AssertionError(f"Grammar {gram} is pickled with an outdated pickle protocol")
        except AttributeError:
            pass


# Generated at 2022-06-21 10:00:50.127413
# Unit test for constructor of class Grammar
def test_Grammar():
    assert issubclass(Grammar, object)
    assert Grammar.__name__ == "Grammar"
    assert Grammar.__doc__  # do not crash
    assert repr(Grammar)   # do not crash
    g = Grammar()
    assert isinstance(g, Grammar)
    assert isinstance(g, object)
    #
    for attr in "symbol2number", "number2symbol", "states", "dfas", \
                "labels", "keywords", "tokens", "symbol2label", "start", \
                "async_keywords":
        assert hasattr(g, attr)

# Generated at 2022-06-21 10:00:54.908151
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """
    Unit test for method dump of class Grammar.
    """
    g = Grammar()
    f = tempfile.NamedTemporaryFile(delete=False)
    f.close()
    g.dump(f.name)
    os.unlink(f.name)


# Generated at 2022-06-21 10:01:04.686584
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest.mock

    def assert_method_invoked(expected_filename):
        def check_args(actual_filename, actual_protocol):
            assert (
                actual_filename == expected_filename
                and actual_protocol == pickle.HIGHEST_PROTOCOL
            )

        return unittest.mock.call(check_args)

    class MyGrammar(Grammar):
        """Grammar subclass for testing."""

        __getstate__ = Grammar.dump.__get__(None, Grammar)
        my_attr = "myattr"

    grammar = MyGrammar()
    grammar.my_attr = "myattr"

# Generated at 2022-06-21 10:01:15.502243
# Unit test for method load of class Grammar
def test_Grammar_load():
    try:
        from .grammar_pickle import pickle_file
    except ImportError:
        # Don't fail if the pickle file was not created yet
        return
    # Create Grammar instance
    grammar = Grammar()

    # Call method
    grammar.load(pickle_file)

    # Check results
    assert grammar.start == 256
    assert grammar.symbol2number["comment"] == 282
    assert grammar.number2symbol[282] == "comment"
    assert grammar.dfas[258] == (
        [[(13, 0), (0, 0)], [(6, 2), (12, 1), (0, 0)], [(6, 2), (0, 0)]],
        {258: 0, 260: 1, 259: 2},
    )

# Generated at 2022-06-21 10:01:25.763730
# Unit test for method load of class Grammar
def test_Grammar_load():
    import tempfile
    g = Grammar()
    # Need to init symbol dict
    g.symbol2number["foo"] = 42
    # Need to init dfas dict
    g.dfas[43] = ([], {})
    # Need to init keywords dict
    g.keywords["bar"] = 44
    # Need to init tokens dict
    g.tokens[45] = 46

    with tempfile.TemporaryFile("wb+") as fp:
        pickle.dump(dict(g.__dict__), fp, pickle.HIGHEST_PROTOCOL)
        fp.seek(0)
        d = pickle.load(fp)
        g.loads(pickle.dumps(d, pickle.HIGHEST_PROTOCOL))
        assert g.symbol2number["foo"]

# Generated at 2022-06-21 10:01:32.672347
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    class MyGrammar(Grammar):
        def __init__(self, pickle_data: bytes) -> None:
            if pickle_data:
                self.loads(pickle_data)

    pickle_data = b"\x80\x04\x95\x0c\x00\x00\x00symbol2numberq\x00}q\x01(U\x01sq\x02K\x02U\x03cosq\x03K\x05U\x03sqrtsq\x04K\x07U\x02spq\x05K\x08u."
    g = MyGrammar(pickle_data)
    assert g.symbol2number["s"] == 2
    assert g.symbol2number["cos"] == 5
    assert g.symbol

# Generated at 2022-06-21 10:01:43.767593
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g1.symbol2number = {"abc": 123}
    g1.number2symbol = {"abc": 123}
    g1.dfas = {0: [(0, 0), (1, 1)], 1: [(2, 2), (3, 3)]}
    g1.keywords = {"a": 1, "b": 2}
    g1.tokens = {"a": 1, "b": 2}
    g1.symbol2label = {"a": 1, "b": 2}
    g1.labels = [(0, "EMPTY")]
    g1.states = [[(0, 0), (1, 1)], [(2, 2), (3, 3)]]
    g1.start = 256
    g1.async_keywords = False

    g2

# Generated at 2022-06-21 10:01:51.234117
# Unit test for method load of class Grammar
def test_Grammar_load():
    class TestGrammar(Grammar):
        def __init__(self):
            self.a = 256
            self.b = 257
            self.c = 258

    g = TestGrammar()

    with open("tmp/grammar1_8.pkl", "rb") as f:
        d = pickle.load(f)
        g.loads(pickle.dumps(d, pickle.HIGHEST_PROTOCOL))

    assert g.a == 256
    assert g.b == 257
    assert g.c == 258

# Generated at 2022-06-21 10:01:52.800742
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Issue #20054
    a = Grammar()
    a.dump(os.devnull)

# Generated at 2022-06-21 10:02:02.364319
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import gen_parser

    class TestGrammar(Grammar):
        pass

    tg = TestGrammar()
    tg.load(gen_parser.FUTURE_GRAMMAR_FILE)
    assert tg.start == tg.symbol2number["file_input"]


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-21 10:02:05.555813
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    filename = "test.pickle"
    open(filename, "w").close()
    try:
        g.dump(filename)
    finally:
        os.unlink(filename)

# Generated at 2022-06-21 10:02:09.800660
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.dump(os.path.join(os.path.dirname(__file__), "Grammar.pickle"))
    grammar.load(os.path.join(os.path.dirname(__file__), "Grammar.pickle"))

# Generated at 2022-06-21 10:02:18.597532
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.start = 257
    g.states = [[[(1, 1)]]]
    g.labels = [(257, "expr"), (1, None)]
    g.dfas = {257: ([[(1, 1)]], {})}
    g.symbol2number = {"expr": 257}
    g.number2symbol = {257: "expr"}
    g.keywords = {}
    g.tokens = {1: 1}

    # Dump the grammar tables to the pickle file
    g.dump("Grammar_dump_test.pkl")

    # Load the grammar tables from the pickle file
    g1 = Grammar()
    g1.load("Grammar_dump_test.pkl")

    # Compare the dumped and loaded grammar if it is equal
   

# Generated at 2022-06-21 10:02:24.054049
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256

# Generated at 2022-06-21 10:02:35.691743
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    def testit(self, cls, test_args: Dict[str, Any]):
        for i, attr in enumerate(test_args):
            test_args[attr] = [1] * i
        s = pickle.dumps({attr: getattr(self, attr) for attr in test_args})
        g = cls()
        g.loads(s)
        for attr, value in test_args.items():
            assert getattr(self, attr) == value, "%s" % (attr, )

    g = Grammar()
    g.symbol2number = {'a': 1}
    g.number2symbol = {1: 'a'}
    g.states = [[]]
    g.dfas = {1: ([], {})}
    g.start = 1
   

# Generated at 2022-06-21 10:02:41.163049
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    import io
    # Create a dummy grammar
    class dummy_grammar(Grammar):
        pass

    # Write a dummy grammar table to a bytes buffer
    with io.BytesIO() as f:
        pkl.dump(dummy_grammar(), f)
        pkl_bytes = f.getvalue()

    # Load a grammar table from a bytes buffer
    dummy_grammar_loads = dummy_grammar()
    dummy_grammar_loads.loads(pkl_bytes)

# Generated at 2022-06-21 10:02:46.541800
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    def dump_test():
        g = Grammar()
        g.start = 1
        return g.dumps()

    def check(obj):
        assert obj.start == 1

    check(Grammar().loads(dump_test()))

# Generated at 2022-06-21 10:02:55.756645
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """This tests that we can write a pickle file and read it back."""
    g_filename = os.path.join(
        os.path.dirname(__file__), "Grammar.test.pkl"
    )
    # Create the grammar file
    with open(g_filename, "wb"):
        pass

    g = Grammar()
    g.symbol2number = {
        "foo": 0,
        "bar": 1,
        "baz": 2,
        "qux": 3,
    }
    g.number2symbol = {
        4: "foo",
        5: "bar",
        6: "baz",
        7: "qux",
    }

# Generated at 2022-06-21 10:03:07.238451
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    """Unit test for method 'loads' of class 'Grammar'
    
    Issue #24971:  A bug in mypyc generated a correct method 'Grammar.loads',
    but the type signature of this method was wrong.
    """
    gram = Grammar()

# Generated at 2022-06-21 10:03:21.666906
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    from io import BytesIO

    # Set up a test grammar
    g = Grammar()
    g.symbol2number = {"test": 1}
    g.number2symbol = {1: "test"}
    g.states = [[[]]]
    g.dfas = {1: ([[]] * 2, {1: 0})}
    g.labels = [(0, "EMPTY"), (1, None)]
    g.keywords = {"test": 1}
    g.tokens = {1: 1}
    g.symbol2label = {"test": 1}
    g.start = 2
    g.async_keywords = True

    # Dump the grammar tables to a pickle file
    pkl = BytesIO()
    g.dump(pkl)

    # Load grammar tables from pickle

# Generated at 2022-06-21 10:03:33.754100
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Create an instance of class Grammar
    grammar = Grammar()

    # Assign some values to the attributes
    grammar.symbol2number = {'a': 1, 'b': 2}
    grammar.number2symbol = {1: 'a', 2: 'b'}
    grammar.states = [1, 2]
    grammar.dfas = {'a': [1, 2], 'b': [3, 4]}
    grammar.labels = [1, 2]
    grammar.keywords = {'a': 1, 'b': 2}
    grammar.tokens = {1: 1, 2: 2}
    grammar.symbol2label = {'a': 1, 'b': 2}
    grammar.start = 3

    # Save the grammar to a file

# Generated at 2022-06-21 10:03:38.169371
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    try:
        os.remove("Grammar.pkl")
    except FileNotFoundError:
        pass
    del sys.modules["lib2to3.pgen2.conv"]
    importlib.import_module("lib2to3.pgen2.conv")
    from ..pgen2 import conv
    c = conv.PgenConverter("Grammar")
    c.convert()
    g = Grammar()
    g.load("Grammar.pkl")

# Generated at 2022-06-21 10:03:43.093731
# Unit test for constructor of class Grammar
def test_Grammar():  # defined here so it can access the classes
    g = Grammar()
    try:
        g.symbol2number
    except AttributeError as e:
        print(e)


if __name__ == "__main__":
    test_Grammar()

# Generated at 2022-06-21 10:03:50.614260
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-21 10:03:56.740214
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    assert not g.number2symbol
    g.loads(b'\x80\x03}q\x00.)\x81q\x01X\x04\x00\x00\x00testq\x02K\x04e.')
    assert g.number2symbol == {4: 'test'}



# Generated at 2022-06-21 10:04:00.633190
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .conv import convert
    import tempfile

    f = tempfile.NamedTemporaryFile(prefix="grammar", suffix=".txt", delete=False)
    g = convert(f.name)
    f.close()

    f = tempfile.NamedTemporaryFile(prefix="grammar", delete=False)
    g.dump(f.name)
    f.close()

    g2 = Grammar()
    g2.load(f.name)
    assert g == g2

# Generated at 2022-06-21 10:04:08.816048
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    start_sym = "single_input"
    dfa_index = 256
    assert dfa_index == len(token.tok_name)
    token_index = dfa_index + 1
    dfa_dict = {dfa_index: ([
        [ (0, 256+1) ]
    ], {dfa_index: token_index})}

    # Grammar for Python 2
    g = Grammar()
    g.dfas = dfa_dict
    g.symbol2number = { start_sym: dfa_index }
    g.number2symbol = { dfa_index: start_sym }
    g.keywords = {"True": 256+1, "False": 256+1}

# Generated at 2022-06-21 10:04:21.754391
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    from .pgen2 import driver
    g = driver.load_grammar('Python.asdl', 'Grammar_nt')
    init_keywords = g.symbol2number.keys()
    g.symbol2number['BLAH'] = 999
    new_g = g.copy()
    # Verify that new instance is a copy of the original
    assert g is not new_g
    assert g.symbol2number is not new_g.symbol2number
    assert g.number2symbol is not new_g.number2symbol
    assert g.dfas is not new_g.dfas
    assert g.keywords is not new_g.keywords
    assert g.tokens is not new_g.tokens
    assert g.symbol2label is not new_g.symbol2label
   

# Generated at 2022-06-21 10:04:26.493043
# Unit test for method loads of class Grammar

# Generated at 2022-06-21 10:04:40.297322
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    """
    The following function tests if Grammar.loads(pkl) corresponds to Grammar.load(file)
    where file is a pickled version of Grammar.
    """
    test_grammar = Grammar()
    with tempfile.TemporaryDirectory() as tmpdirname:
        test_file = os.path.join(tmpdirname, "test.pickle")
        test_grammar.dump(test_file)
        test_grammar_loaded = Grammar()
        with open(test_file, "rb") as f:
            test_bytes = f.read()
        test_grammar_loaded.loads(test_bytes)
        assert test_grammar.symbol2number == test_grammar_loaded.symbol2number
        assert test_grammar.number2symbol == test_grammar_loaded.number

# Generated at 2022-06-21 10:04:50.826471
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    for method in [Grammar.dump, Grammar.loads, Grammar._update]:
        g = Grammar()
        g.states = [
            [(0, 0), (1, 1), (2, 2, "foo")],
            [(3, 4, "bar"), (0, 5), (5, 0)],
            [(0, 1), (1, 0)],
            [(5, 1, "baz")],
            [(5, 0, "qux"), (0, 1, "quux")],
        ]
        g.labels = [
            (0, None),
            (257, "one"),
            (258, "two"),
            (259, "three"),
            (260, None),
            (261, "five"),
            (262, "six"),
        ]

# Generated at 2022-06-21 10:04:53.701810
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__[:-1])


# Generated at 2022-06-21 10:04:57.979182
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """
    Grammar.dump shouldn't raise an exception.
    """
    import sys

    g = Grammar()
    filename = "temp_parse_tables.pickle"
    try:
        g.dump(filename)
    finally:
        try:
            os.unlink(filename)
        except OSError:
            pass



# Generated at 2022-06-21 10:05:04.562622
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # TODO: Use real pytest? Or ensure test runs when running setup.py
    g = Grammar()

# Generated at 2022-06-21 10:05:06.918116
# Unit test for method report of class Grammar
def test_Grammar_report():
    from . import pgen

    g = pgen.load_grammar("Grammar.txt")
    g.report()



# Generated at 2022-06-21 10:05:19.299552
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-21 10:05:20.261627
# Unit test for constructor of class Grammar
def test_Grammar():
    assert Grammar()


# Generated at 2022-06-21 10:05:23.000023
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # Regression test for http://bugs.python.org/issue14288
    grammar = Grammar()
    grammar.loads(b"\x80\x03}q\x00.")

# Generated at 2022-06-21 10:05:24.851922
# Unit test for method load of class Grammar
def test_Grammar_load():
    gr = Grammar()
    gr.load('./Grammar.pkl')

# Generated at 2022-06-21 10:05:49.449160
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen2
    from . import token

    i = tempfile.NamedTemporaryFile()
    j = tempfile.NamedTemporaryFile()
    pgen2.driver.run_pgen(i.name, j.name)
    g = Grammar()
    g.load(j.name)

# Generated at 2022-06-21 10:05:56.543743
# Unit test for method report of class Grammar
def test_Grammar_report():
    import unittest
    from unittest.mock import Mock

    class MockGrammar(Grammar):
        def __init__(self):
            self.symbol2number = {'KEYWORD': 1}
            self.number2symbol = {1: 'KEYWORD'}
            self.states = [[[(1, 1)], []]]
            self.dfas = {1: ([[], []], {1: 1, 2: 2})}
            self.labels = [(1, 'KEYWORD')]
            self.keywords = {'KEYWORD': 1}
            self.tokens = {1: 2}
            self.symbol2label = {'symbol': 2}
            self.start = 256
            self.async_keywords = False


# Generated at 2022-06-21 10:06:08.410980
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.symbol2number['foo'] = 37
    g.number2symbol[37] = 'foo'
    g.states = [[[(1, 2), (3, 4)], [(5, 6), (7, 8)]]]
    g.dfas[37] = [
        [[(1, 2), (3, 4)], [(5, 6), (7, 8)]], {1: 1, 3: 1, 5: 1}]
    g.labels = [(1, "NUMBER"), (3, "NAME"), (5, "STRING")]
    g.keywords['async'] = 5
    g.tokens[1] = 3
    g.symbol2label['spam'] = 23
    g.start = 0
    g.report()

# Generated at 2022-06-21 10:06:17.262496
# Unit test for method load of class Grammar
def test_Grammar_load():
    """
    Create a pickle file and ensure it can be loaded.
    """
    from . import graminit
    from .pgen2 import driver

    tmpfile = tempfile.NamedTemporaryFile(delete=False)
    driver.main(verbose=1, generate=True, outputdir=tmpfile.dirname, write_bytes=True)
    with open(tmpfile.name, "r") as f:
        g = pickle.load(f)
    assert g.start == 257
    assert g.symbol2number["root"] == 257
    assert g.number2symbol[257] == "root"
    assert g.dfas[257]
    assert g.states
    assert g.keywords == graminit.keywords
    assert g.tokens == graminit.tokens


# TODO: move

# Generated at 2022-06-21 10:06:21.697028
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    g.loads(b'\x80\x03cpygments.pyparsing\nGrammar\nq\x00)\x81q\x01.')
    assert g.start == 256

# Generated at 2022-06-21 10:06:29.101247
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    def test_dict_copy(a_dict: Dict[Any, Any], b_dict: Dict[Any, Any]) -> None:
        assert len(a_dict) == len(b_dict)
        for k in a_dict:
            assert b_dict[k] == a_dict[k]

    g = Grammar()
    g.symbol2number['foo'] = 1
    g.number2symbol[1] = 'foo'
    g.dfas[1] = ([[(1, 1)], [(0, 1)]], {1: 1})
    g.keywords['bar'] = 1
    g.tokens[1] = 1
    g.symbol2label['bar'] = 1
    g.labels.append((1, 1))

# Generated at 2022-06-21 10:06:40.137274
# Unit test for method loads of class Grammar

# Generated at 2022-06-21 10:06:43.446538
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    gs = g.copy()
    assert gs is not None
    assert gs.__class__ is g.__class__

# Generated at 2022-06-21 10:06:54.503110
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g1.symbol2number = {"one": 1, "two": 2}
    g1.number2symbol = {1: "one", 2: "two"}
    g1.labels = [(0, "EMPTY"), (1, "ONE")]
    g1.states = [[(1, 1), (2, 2)], [(2, 3), (3, 4)]]
    g1.dfas = {1: (g1.states[0], {}), 2: (g1.states[1], {})}
    g1.keywords = {"one": 1}
    g1.tokens = {1: 1}
    g1.symbol2label = {"one": 1}
    g1.start = 256
    g1.async_keywords = True

    g2

# Generated at 2022-06-21 10:07:06.737289
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    g.symbol2number = {'a': 1, 'b': 2}
    g.number2symbol = {1: 'a', 2: 'b'}
    g.start = 256
    g.async_keywords = False
    g.states = [[[(0, 4), (1, 5)], [(0, 6), (1, 7)]]]
    g.dfas = {256: ([[(0, 4), (1, 5)], [(0, 6), (1, 7)]], {5: 1}), 257: ([[(0, 8), (2, 9)]], {9: 1})}
    g.labels = [(0, 'EMPTY'), (1, None), (2, 'kw')]
    g.keywords = {'kw': 2}
    g

# Generated at 2022-06-21 10:07:30.529328
# Unit test for constructor of class Grammar
def test_Grammar():
    # See also test_conv.py, test_pgen.py.
    from .pgen2 import driver, pgen


# Generated at 2022-06-21 10:07:33.792760
# Unit test for method report of class Grammar
def test_Grammar_report():
    # Test the Grammar.report method
    # This test is added because the method Grammar.report is called from
    # test_pickle_dump of test_grammar.py.
    # pylint: disable=W0201
    gr = Grammar()
    gr.report()



# Generated at 2022-06-21 10:07:41.053818
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number is not None
    assert g.number2symbol is not None
    assert g.states is not None
    assert g.dfas is not None
    assert g.labels is not None
    assert g.keywords is not None
    assert g.tokens is not None
    assert g.symbol2label is not None
    assert g.start is not None
    assert g.async_keywords is not None


# Generated at 2022-06-21 10:07:43.407884
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    test_grammar = Grammar()
    test_grammar.loads(test_grammar.dump)
    assert True

# Generated at 2022-06-21 10:07:44.351412
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()

# Generated at 2022-06-21 10:07:52.045936
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import os

    g = Grammar()
    g.start = 1
    g.ignore = 2
    g.tokens = {1: 2, 3: 4}
    g.dfas = {1: 2, 3: 4}
    g.labels = [[1, 2], [3, 4]]
    g.keywords = {"key": 1, "word": 3}
    g.states = [
        [[[1, 2]], [[3, 4]]],
        [[[1, 2]], [[3, 4]]],
    ]
    g.symbol2number = {"name": 1, "number": 3}
    g.number2symbol = {1: "name", 3: "number"}
    g.async_keywords = True


# Generated at 2022-06-21 10:07:53.335397
# Unit test for method report of class Grammar
def test_Grammar_report():
    import py
    import sys
    g = Grammar()
    g.report()



# Generated at 2022-06-21 10:07:56.919726
# Unit test for method report of class Grammar
def test_Grammar_report():
    import sys
    import io

    grammar = Grammar()

    saved_stdout = sys.stdout
    try:
        out = io.StringIO()
        sys.stdout = out
        grammar.report()
        output = out.getvalue().strip()
    finally:
        sys.stdout = saved_stdout

    assert len(output) > 0

# Generated at 2022-06-21 10:08:01.482706
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2 import driver

    g = driver.load_grammar("Grammar/Grammar")
    g.dump("Grammar.pickle")
    g2 = Grammar()
    g2.load("Grammar.pickle")
    assert g2.__dict__ == g.__dict__
    os.remove("Grammar.pickle")

# Generated at 2022-06-21 10:08:10.781757
# Unit test for method load of class Grammar
def test_Grammar_load():
    def make_grammar():
        g = Grammar()
        g.symbol2number = {
            "test": 1,
            "test2": 2,
        }
        g.symbol2label = {
            "test": 1,
            "test2": 2,
        }
        g.number2symbol = {
            1: "test",
            2: "test2",
        }
        g.dfas = {
            1: ([[(1, 2)], [(2, 2)]], {"test2": 1}),
            2: ([[(2, 2)]], {"test": 1}),
        }
        g.labels = [
            (0, None),
            (1, "test"),
            (2, "test2"),
        ]