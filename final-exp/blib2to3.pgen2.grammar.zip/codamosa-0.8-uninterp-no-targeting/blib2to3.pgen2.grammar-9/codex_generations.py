

# Generated at 2022-06-21 09:58:58.186100
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    g.symbol2number = {'A': 1, 'B': 2, 'C': 3}
    g.number2symbol = {1: 'A', 2: 'B', 3: 'C'}
    g.states = [
        [
            [(1, 2), (3, 4)],
            [(3, 5)],
            [(3, 6)],
            [(1, 7), (3, 8)]
        ]
    ]

# Generated at 2022-06-21 09:59:08.424932
# Unit test for method load of class Grammar
def test_Grammar_load():
    """This is for testing the grammar table load error,
    where a token is not available in token.py.

    """
    grammar = Grammar()
    grammar.keywords = {
        "False": token.NAME,
        "None": token.NAME,
        "True": token.NAME,
        "async": token.NAME,
        "await": token.NAME,
        "class": token.NAME,
        "global": token.NAME,
        "import": token.NAME,
        "lambda": token.NAME,
        "nonlocal": token.NAME,
        "pass": token.NAME,
        "raise": token.NAME,
        "try": token.NAME,
        "while": token.NAME,
        "yield": token.NAME,
    }

# Generated at 2022-06-21 09:59:22.021532
# Unit test for method load of class Grammar
def test_Grammar_load():
    """
    Test method load
    """

# Generated at 2022-06-21 09:59:33.184520
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    def get_random_grammar(g: Grammar) -> Grammar:
        from random import randint
        from itertools import chain

        def get_random_arc(labels: List[Label]) -> Tuple[int, int]:
            return randint(0, len(labels) - 1), randint(0, len(g.states) - 1)

        def get_random_state(labels: List[Label]) -> List[Tuple[int, int]]:
            return [get_random_arc(labels) for i in chain(g.tokens, g.dfas)]

        def get_random_dfa(labels: List[Label]) -> List[int]:
            return [get_random_state(labels) for i in range(randint(1, 10))]


# Generated at 2022-06-21 09:59:42.863492
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    grammar1 = Grammar()
    grammar1.symbol2number = {"A": 1, "B": 2}
    grammar1.number2symbol = {1: "A", 2: "B"}
    grammar1.dfas = {1: "A", 2: "B"}
    grammar1.keywords = {"C": 3, "D": 4}
    grammar1.tokens = {3: 3, 4: 4}
    grammar1.symbol2label = {"E": 5, "F": 6}
    grammar1.labels = [(7, "G"), (8, "H")]
    grammar1.states = [1, 2, 3]
    grammar1.start = 9
    grammar1.async_keywords = False
    grammar2 = grammar1.copy()

# Generated at 2022-06-21 09:59:49.504462
# Unit test for method load of class Grammar
def test_Grammar_load():
    g1 = Grammar()
    g1.symbol2number['one'] = 1
    g1.symbol2number['two'] = 2
    g1.dump("grammar.pkl")
    g1.symbol2number['one'] = 3
    g2 = Grammar()
    g2.load("grammar.pkl")
    assert g1.symbol2number == g2.symbol2number
    os.remove("grammar.pkl")



# Generated at 2022-06-21 10:00:00.103355
# Unit test for constructor of class Grammar
def test_Grammar():
    from .grammar import Grammar

    # Issue 7451: Test default constructor
    g = Grammar()
    if g.symbol2number != {}:
        raise ValueError("wrong symbol2number default")
    if g.number2symbol != {}:
        raise ValueError("wrong number2symbol default")
    if g.states != []:
        raise ValueError("wrong states default")
    if g.dfas != {}:
        raise ValueError("wrong dfas default")
    if g.labels != [(0, "EMPTY")]:
        raise ValueError("wrong labels default")
    if g.keywords != {}:
        raise ValueError("wrong keywords default")
    if g.tokens != {}:
        raise ValueError("wrong tokens default")

# Generated at 2022-06-21 10:00:03.804547
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # One instance of Grammar must exist for this to work
    instance = Grammar()
    result = instance.dump('/tmp')
    assert result is None
    instance2 = Grammar()
    result2 = instance2.dump('/tmp')
    assert result2 is None

# Generated at 2022-06-21 10:00:10.664739
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import tempfile
    import unittest
    import pickle
    import os

    loader = unittest.TestLoader()
    testcase_classes = [test_Tokeneater.GrammarTest]
    suite = loader.loadTestsFromTestCase(testcase_classes[0])

    runner = unittest.TextTestRunner()
    result = runner.run(suite)
    if result.errors:
        print(result.errors)
        raise SystemExit(1)

    class Grammar_for_memory(Grammar):
        def load(self, filename: Path) -> None:
            pass
        def _update(self, attrs: Dict[str, Any]) -> None:
            pass

    g = Grammar_for_memory()
    f = tempfile.NamedTemporaryFile()
    g.sy

# Generated at 2022-06-21 10:00:13.240910
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    from .pygram import python_grammar
    pygram = Grammar()
    pygram.loads(python_grammar)
    assert len(pygram.dfas) > 10

# Generated at 2022-06-21 10:00:24.093565
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert type(g.symbol2number) == dict
    assert type(g.number2symbol) == dict
    assert type(g.states) == list
    assert type(g.dfas) == dict
    assert type(g.labels) == list
    assert type(g.keywords) == dict
    assert type(g.tokens) == dict
    assert type(g.symbol2label) == dict
    assert type(g.start) == int

# Generated at 2022-06-21 10:00:31.118495
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()

# Generated at 2022-06-21 10:00:34.433096
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pytest
    with pytest.raises(AttributeError):
        grammar = Grammar()
        grammar.load("nonexistent_file")

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-21 10:00:43.377531
# Unit test for method load of class Grammar
def test_Grammar_load():
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    grammar = Grammar()
    grammar.symbol2number = {'a': 100, 'b': 200}
    grammar.states = [1, 2]
    grammar.tokens = {'a': 1, 'b':2}
    s = StringIO()
    grammar.dump(s)
    newgrammar = Grammar()
    newgrammar.load(s)
    assert newgrammar.symbol2number == grammar.symbol2number
    assert newgrammar.states == grammar.states
    assert newgrammar.tokens == grammar.tokens

# Generated at 2022-06-21 10:00:55.311029
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import conv, pgen2
    import os
    import sys
    import tempfile

    grammar = Grammar()

    # Build dummy grammar tables
    pgen = pgen2.pgen(grammar)

    # Write tables to a pickle file
    _, dfas = tempfile.mkstemp(prefix="test_Grammar_load", suffix="_dfas.pkl")

# Generated at 2022-06-21 10:01:05.046569
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    class MyGrammar(Grammar):
        def __init__(self) -> None:
            Grammar.__init__(self)
            self.symbol2number = {'a': 1}
            self.number2symbol = {1: 'a'}
            self.states = [[(0, 0)]]
            self.dfas = {1: ([[(0, 0)]], {0: 1})}
            self.labels = [(0, 0)]
            self.keywords = {'a': 1}
            self.tokens = {1: 1}
            self.symbol2label = {'a': 1}
            self.start = 258
            self.async_keywords = True

    g = MyGrammar()


# Generated at 2022-06-21 10:01:16.306245
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import pickle
    from test.support import captured_stdout

    symbol_name = "test_symbol"
    kw_test = "test_kw"
    op_test = "+"
    op_label_name = "test_op"

    def setattr_test(value, *args, **kwargs):
        assert value == 1

    def getattr_test(*args, **kwargs):
        return 1

    def test_dictionary_input(symbol_name, symbol_value):
        g = Grammar()
        g.symbol2number[symbol_name] = symbol_value
        g.number2symbol[symbol_value] = symbol_name

# Generated at 2022-06-21 10:01:26.394853
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """ Unit test for method dump of class Grammar """
    import os
    import tempfile
    import warnings
    import io
    import pickle
    from pickle import HIGHEST_PROTOCOL
    from pickletools import dis
    from typing import Any, Dict

    symbol2number = {'A': 256, 'B': 257, 'C': 258}
    number2symbol = {256: 'A', 257: 'B', 258: 'C'}
    states = [[[(0, 0)], [(257, 3), (258, 4)], [(0, 1)], [(0, 2)]], [[(0, 5)]]]

# Generated at 2022-06-21 10:01:29.124644
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("graminit.bin")
    g2 = Grammar()
    g2.load("graminit.bin")
    assert g.async_keywords == g2.async_keywords

# Generated at 2022-06-21 10:01:41.013610
# Unit test for constructor of class Grammar
def test_Grammar():
    # test initialization of Grammar instance
    g = Grammar()
    for d in (g.symbol2number, g.number2symbol, g.dfas, g.keywords, g.tokens):
        assert isinstance(d, dict)
    assert len(g.symbol2number) == 0
    assert len(g.number2symbol) == 0
    assert len(g.dfas) == 0
    assert len(g.keywords) == 0
    assert len(g.tokens) == 0

    assert isinstance(g.states, list)
    assert len(g.states) == 0

    assert isinstance(g.labels, list)
    assert len(g.labels) == 1
    assert g.labels[0] == (0, "EMPTY")


# Generated at 2022-06-21 10:01:56.378973
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g1.symbol2number = {'A': 2}
    g1.number2symbol = {3: 'B'}
    g1.dfas = {4:([(5,6)],{6:7})}
    g1.keywords = {'C':8}
    g1.tokens = {9:10}
    g1.symbol2label = {'D':11}
    g1.labels = [12, 13]
    g1.states = [[(14,15)]]
    g1.start = 16
    g1.async_keywords = True

    g2 = g1.copy()
    assert g2.symbol2number == {'A': 2}

# Generated at 2022-06-21 10:02:09.531806
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    sym1 = "test1"
    sym2 = "test2"
    sym3 = "test3"
    g.symbol2number = {sym1: 4, sym2: 5, sym3: 6}
    g.number2symbol = {4: sym1, 5: sym2, 6: sym3}
    g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
    g.dfas = {4: (g.states[0], {4: 1}),
              5: (g.states[1], {5: 2})}

# Generated at 2022-06-21 10:02:14.872970
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import importlib.util
    import pytest

    try:
        g = Grammar()
        g.dump('Grammar.pickle')
    finally:
        os.remove('Grammar.pickle')

    assert os.path.exists('Grammar.pickle')
    assert importlib.util.find_spec('Grammar.pickle') is not None

# Generated at 2022-06-21 10:02:24.095806
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    grammar = Grammar()
    grammar.symbol2number["dummy"] = 0
    grammar.number2symbol[0] = "dummy"
    grammar.dfas[0] = (DFA([]), {})
    grammar.keywords["dummy"] = 0
    grammar.tokens[0] = 0
    grammar.symbol2label["dummy"] = 0
    grammar.labels[0] = (0, "dummy")
    grammar.states[0] = [((0, "dummy"), 0)]
    grammar.start = 256
    grammar.async_keywords = False
    
    new = grammar.copy()
    assert new.symbol2number["dummy"] == 0
    assert new.number2symbol[0] == "dummy"

# Generated at 2022-06-21 10:02:33.560010
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pathlib
    from .conv import parse_grammar

    g = parse_grammar("Grammar/Grammar")
    # No dump for Python < 3.8,
    # because os.PathLike is *not* supported by pickle there
    if hasattr(os.PathLike, "__fspath__"):
        f = pathlib.Path(tempfile.mktemp())
        g.dump(f)
        g_ = Grammar()
        g_.load(f)
        f.unlink()


if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-21 10:02:39.129887
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import os
    import pickle

    with tempfile.TemporaryDirectory() as tmpdir:
        file_path = os.path.join(tmpdir, 'test.pickle')
        grammar = Grammar()
        grammar.dump(file_path)
        with open(file_path, 'rb') as f:
            unpickler = pickle.Unpickler(f)
            grammar_copy = unpickler.load()
        assert grammar == grammar_copy

# Generated at 2022-06-21 10:02:45.190148
# Unit test for method report of class Grammar
def test_Grammar_report():
    import sys, tempfile, token

    g = Grammar()
    s = """
    def: NAME '(' ')'
        | NAME '(' arglist ')'

    arglist: NAME '=' NAME
            | NAME '=' NAME ',' arglist
    """
    # Build the grammar from a string
    from .pgen2 import driver

    driver.parse_string(s, "dummy_filename.py", "exec")
    g.update([], driver.grammar)

    # Dump the grammar to a temp file
    filenames = driver.write_tables(g, None)

# Generated at 2022-06-21 10:02:54.753826
# Unit test for method report of class Grammar
def test_Grammar_report():
    fname = os.path.join(os.path.dirname(__file__), "Grammar.txt")
    f = open(fname, "w")
    try:
        g = Grammar()
        g.report(file=f)
    finally:
        f.close()
        with open(fname) as f:
            lines = f.readlines()
    assert lines == [
        's2n\n',
        '{}\n',
        'n2s\n',
        '{}\n',
        'states\n',
        '[\n',
        ']\n',
        'dfas\n',
        '{}\n',
        'labels\n',
        "[(0, 'EMPTY')]\n",
        'start 256\n',
    ]

# Generated at 2022-06-21 10:02:57.033924
# Unit test for method report of class Grammar
def test_Grammar_report():
    from pgen2.dump import dump_grammar
    dump_grammar('Grammar.test', 'Grammar.test')
    g = Grammar()
    g.load('Grammar.test')
    g.report()

# Generated at 2022-06-21 10:02:58.185533
# Unit test for method report of class Grammar
def test_Grammar_report():
    """Test the method Grammar.report"""
    g = Grammar()
    g.report()

# Generated at 2022-06-21 10:03:20.211598
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    """
    Test that we can shallow copy Grammar objects.
    """
    g = Grammar()
    g.symbol2number = dict(foo=1)
    g.number2symbol = dict(bar=2)
    g.dfas = dict(baz=3)
    g.keywords = dict(qux=4)
    g.tokens = dict(quux=5)
    g.symbol2label = dict(baz=6)
    g.labels = [1, 2, 3]
    g.states = [4, 5, 6]
    g.start = 7
    h = g.copy()
    assert h.symbol2number == dict(foo=1)
    assert h.number2symbol == dict(bar=2)

# Generated at 2022-06-21 10:03:32.877897
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    from .pgen2 import driver
    from .parse import ParserError
    from io import StringIO
    from .tokenize import StringIterator

    try:
        g = driver.load_grammar("/")
        return
    except FileNotFoundError:
        pass
    except ParserError as e:
        assert e.msg == 'Unable to locate file "<string>"'


# Generated at 2022-06-21 10:03:37.679786
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert isinstance(g.symbol2number, dict)
    assert isinstance(g.number2symbol, dict)
    assert isinstance(g.states, list)
    assert isinstance(g.dfas, dict)
    assert isinstance(g.labels, list)
    assert isinstance(g.keywords, dict)
    assert isinstance(g.tokens, dict)
    assert isinstance(g.symbol2label, dict)

# Generated at 2022-06-21 10:03:48.035527
# Unit test for method report of class Grammar
def test_Grammar_report():
    def load_pickle(self, filename: Path) -> None:
        with open(filename, "rb") as f:
            d = pickle.load(f)
        self._update(d)

    def check():
        path_ = os.path.join(os.path.dirname(__file__), "graminit.pickle")
        with open(path_, "rb") as f:
            Grammar.dump(pickle.load(f), "nodeps.pickle")
        g = Grammar()
        g.load("nodeps.pickle")
        g.report()

    def check_out(filename: Path) -> None:
        path_ = os.path.join(os.path.dirname(__file__), "graminit.pickle")

# Generated at 2022-06-21 10:04:00.277947
# Unit test for method load of class Grammar

# Generated at 2022-06-21 10:04:08.598496
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    def _test(pkl: bytes, filename: Path) -> None:
        grammar = Grammar()
        grammar.loads(pkl)
        grammar.load(filename)
        assert grammar.start == 256

    _test(b"\x80\x04\x95\x11\x00\x00\x00\x00\x00\x00\x00\x8c\x06tokensq\x00}q\x01(X\x03\x00\x00\x00ASSq\x02h\x01K\xc3X\x01\x00\x00\x00Dq\x03K\x02u.",
          'tests/data/asdl_c.grammar')


# Generated at 2022-06-21 10:04:09.172493
# Unit test for constructor of class Grammar
def test_Grammar():
    pass

# Generated at 2022-06-21 10:04:10.077445
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()

# Generated at 2022-06-21 10:04:23.303476
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g1.symbol2number = {'ONE': 1, 'TWO': 2}
    g1.number2symbol = {1: 'ONE', 2: 'TWO'}
    g1.dfas = {3: ([], {}), 5: ([], {})}
    g1.keywords = {'ONE': 1, 'TWO': 2}
    g1.tokens = {1: 3, 2: 5}
    g1.symbol2label = {'ONE': 6, 'TWO': 7}
    g1.labels = [(0, 'EMPTY'), (1, None), (2, None), (3, None), (4, None), (5, None)]

# Generated at 2022-06-21 10:04:30.800067
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords == False
    #
    g.load(__file__[:-1]+"pickle")

# Generated at 2022-06-21 10:04:50.552190
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    gr = Grammar()
    gr.symbol2number = {'foo': 257, 'bar': 258}
    gr.number2symbol = {258: 'bar', 257: 'foo'}
    gr.states = [[[(9, 0)]]]
    gr.dfas = {257: ([[(9, 1)]], {1: 1}), 258: ([[(9, 6)]], {6: 1})}
    gr.labels = [(0, 'EMPTY'), (257, None), (258, None), (9, 'foo'), (258, 'bar')]
    gr.start = 257
    gr.keywords = {'bar': 4}
    gr.tokens = {9: 3}
    gr.symbol2label = {'foo': 3, 'bar': 4}

# Generated at 2022-06-21 10:04:55.991715
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .conv import convert
    from .pgen import driver

    g = Grammar()
    driver.generate_grammar("Grammar/Grammar.txt")
    convert("Grammar/Grammar.txt", "Grammar/Grammar.pickle", True)
    g.load("Grammar/Grammar.pickle")

# Generated at 2022-06-21 10:04:59.336634
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    original = Grammar()
    original.symbol2number["foo"] = 1
    original.keywords["bar"] = 1
    new = original.copy()
    assert original.symbol2number is not new.symbol2number
    assert original.keywords is not new.keywords

# Generated at 2022-06-21 10:05:10.629496
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io
    import unittest
    import sys

    class GrammarTest(unittest.TestCase):
        def test_Grammar_report(self):
            g = Grammar()
            g.symbol2number = {"A": 1, "B": 2, "C": 3}
            g.number2symbol = {1: "A", 2: "B", 3: "C"}

# Generated at 2022-06-21 10:05:22.335453
# Unit test for method report of class Grammar
def test_Grammar_report():
    from io import StringIO
    import pprint
    import unittest
    from test import support
    from . import pgen2

    support.import_module("tokenize", deprecated=True)
    support.import_module("typing")

    with open(pgen2.find_grammar(), "rb") as f:
        gram = pickle.load(f)

    output = StringIO()
    def _print(*args):
        print(*args, file=output)

    gram.report = lambda: _print(pprint.pformat(gram.__dict__))
    gram.report()

    # We can't check the real output because it varies depending on
    # the python version and by platform. So just make sure that the
    # report actually outputs something
    self = unittest.TestCase()

# Generated at 2022-06-21 10:05:34.099718
# Unit test for method report of class Grammar
def test_Grammar_report():
    from io import StringIO
    import textwrap
    from unittest import mock
    import pgen2
    import pgen2.pgen
    with mock.patch("sys.stdout", new_callable=StringIO) as fake_out:
        pgen2.dump_grammar("python3.7")
        out = fake_out.getvalue()
        assert "pgen2 version" in out
        for i in pgen2.pgen_main.PY_MAJOR_VERSIONS:
            if i == 3:
                i_str = "3.7"
            else:
                i_str = str(i)
            assert i_str in out
        if pgen2.Main.verbose:
            assert "s2n" in out
            assert "n2s" in out
            assert "states"

# Generated at 2022-06-21 10:05:43.187465
# Unit test for method report of class Grammar
def test_Grammar_report():
    # Issue #1793: Crashes on various grammars
    import io
    import contextlib

    @contextlib.contextmanager
    def capture_stdout() -> Any:
        buf = io.StringIO()
        oldout = sys.stdout
        sys.stdout = buf
        try:
            yield buf
        finally:
            sys.stdout = oldout

    # Issue #2062: Crash in Grammar.report() when using Python 2.3
    with captured_stdout() as buf:
        # Grammars for Python < 2.8
        grammar23 = Grammar()
        grammar24 = Grammar()
        grammar25 = Grammar()
        grammar26 = Grammar()
        grammar27 = Grammar()
        grammar30 = Grammar()
        grammar33 = Grammar()

        grammar23.report()
        grammar

# Generated at 2022-06-21 10:05:51.596363
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import tokenize
    from .parse import Parser

    for version in (2, 3):
        # Load pickled tables and make an instance of the grammar
        pgen = Grammar()
        pgen.load(f"Grammar.pgen{version}")
        # Make a parser using the loaded tables
        parser = Parser(pgen)
        # Make a tokenizer using the loaded tables
        lines = ["x = 3\n", "def f():\n  return x\n"]
        tokens = tokenize.generate_tokens(lines)
        # Parse the simple input
        ast = parser.parse(tokens, "<test>")

# Generated at 2022-06-21 10:05:57.854159
# Unit test for method report of class Grammar
def test_Grammar_report():
    # Arrange
    grammar = Grammar()
    grammar.symbol2number = {'SYMBOL2NUMBER': 'VALUE'}
    grammar.number2symbol = {'NUMBER2SYMBOL': 'VALUE'}
    grammar.states = ['STATE1', 'STATE2']
    grammar.dfas = {'DFA1': 'DFA1_VALUE', 'DFA2': 'DFA2_VALUE'}
    grammar.labels = ['LABEL1', 'LABEL2']
    grammar.start = 'START'
    grammar.keywords = {}
    grammar.tokens = {}
    grammar.symbol2label = {}
    grammar.async_keywords = True


# Generated at 2022-06-21 10:06:08.498743
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    with tempfile.NamedTemporaryFile() as f:
        g.dump(f.name)
        g2 = Grammar()
        g2.load(f.name)
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.start == g2.start
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label


if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-21 10:06:38.933360
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Test method dump of class Grammar (grammar.py)
    import pickle
    import sys

    path = sys.argv[1]
    with open(path, "rb") as f:
        pickled = f.read()

    # Test load from pickled
    g = Grammar()
    g.loads(pickled)

    # Test load from dump into a file
    g2 = Grammar()
    filename = sys.argv[2]
    g.dump(filename)
    g2.load(filename)
    assert g.labels == g2.labels
    assert g.tokens == g2.tokens
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.dfas == g2

# Generated at 2022-06-21 10:06:45.999797
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.start == 256

# Generated at 2022-06-21 10:06:51.354536
# Unit test for constructor of class Grammar
def test_Grammar():
    # Accessing the instance variables before construction raises an exception
    grammar = Grammar()
    for attr in (
        "symbol2number",
        "number2symbol",
        "states",
        "dfas",
        "labels",
        "keywords",
        "tokens",
        "symbol2label",
    ):
        getattr(grammar, attr)

# Generated at 2022-06-21 10:07:01.447411
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g1.labels = [10, 20]
    g2 = g1.copy()
    assert g2.labels == [10, 20]
    assert g2.labels is not g1.labels

if __name__ == "__main__":
    import sys
    g = Grammar()
    try:
        g.load(sys.argv[1])
    except IndexError:
        print("Usage: %s grammar_file" % sys.argv[0])
    else:
        g.report()

# Generated at 2022-06-21 10:07:02.859839
# Unit test for constructor of class Grammar
def test_Grammar():
    p = Grammar()

# Generated at 2022-06-21 10:07:10.801802
# Unit test for method report of class Grammar
def test_Grammar_report():
    # Test at beginning of file
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    def compare_output_with_file(res, filename):
        with open(filename) as f:
            expected = f.read().strip()
            assert res.getvalue().strip() == expected

    g = Grammar()

# Generated at 2022-06-21 10:07:13.658306
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    test_grammar = Grammar()
    with tempfile.TemporaryDirectory() as tmp_dir_name:
        test_grammar.dump(os.path.join(tmp_dir_name, "test_grammar"))

# Generated at 2022-06-21 10:07:25.310991
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g1.symbol2number = {'foo': 1}
    g1.number2symbol = {1: 'foo'}
    g1.dfas = {1: ([1], {2: 3})}
    g1.keywords = {'bar': 4}
    g1.tokens = {5: 6}
    g1.symbol2label = {'baz': 7}
    g1.labels = [(1, 'foo'), (2, 'bar')]
    g1.states = [(1, 2), (3, 4)]
    g1.start = 8
    g1.async_keywords = True
    g2 = g1.copy()
    assert g1.symbol2number is not g2.symbol2number
    assert g1.number

# Generated at 2022-06-21 10:07:31.170955
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.start == 256
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.async_keywords == False

# Generated at 2022-06-21 10:07:41.792904
# Unit test for method loads of class Grammar