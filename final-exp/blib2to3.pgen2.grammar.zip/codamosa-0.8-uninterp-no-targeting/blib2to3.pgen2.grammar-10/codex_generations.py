

# Generated at 2022-06-21 09:58:47.857932
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.start = 42
    g.dfas = 3                                               # type: ignore
    g.states = 4                                             # type: ignore

# Generated at 2022-06-21 09:59:00.142305
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.a = 1
    g.b = 2
    g.symbol2number['foo'] = 1
    g.number2symbol[1] = 'foo'

    gg = g.copy()

    # test that g and gg are not the same object
    assert g is not gg

    # test that g and gg have the same values
    assert g.__dict__ == gg.__dict__

    # test that changes in g does not affect gg
    g.a = 10
    g.symbol2number['foo'] = 2
    assert gg.a == 1
    assert gg.symbol2number['foo'] == 1

    # test that changes in gg does not affect g
    gg.b = 20

# Generated at 2022-06-21 09:59:03.092911
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))

# Generated at 2022-06-21 09:59:05.914326
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    import pytest

    g = Grammar()
    with pytest.raises(AttributeError, match="'Grammar' object has no attribute '__dict__'"):
        g.loads(b"pickle")

# Generated at 2022-06-21 09:59:08.101056
# Unit test for method report of class Grammar
def test_Grammar_report():

    grammar = Grammar()
    # Check for lack of output.
    # Don't know how to check stdout return value.
    grammar.report()



# Generated at 2022-06-21 09:59:22.021241
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # type: () -> None
    g = Grammar()

# Generated at 2022-06-21 09:59:33.182807
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Tests the dump method of class Grammar
    from .pgen2 import driver

    drv = driver.Driver()
    gr = drv.load_grammar(tokenize.detect_encoding(__file__)[0])
    with tempfile.NamedTemporaryFile(delete=False) as f:
        gr.dump(f.name)

    with open(f.name, "rb") as f:
        d = pickle.load(f)

    assert d["symbol2number"] == gr.symbol2number
    assert d["number2symbol"] == gr.number2symbol
    assert d["states"] == gr.states
    assert d["dfas"] == gr.dfas
    assert d["labels"] == gr.labels
    assert d["keywords"] == gr.keywords

# Generated at 2022-06-21 09:59:35.358541
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(__file__[:-3] + '_grammar')

# Generated at 2022-06-21 09:59:44.034763
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    # Test preconditions
    assert g.async_keywords == False
    assert len(g.dfas) == 0
    assert len(g.keywords) == 0
    assert len(g.labels) == 1
    assert len(g.number2symbol) == 0
    assert len(g.states) == 0
    assert len(g.symbol2label) == 0
    assert len(g.symbol2number) == 0

    # Mutate these instance variables
    g.async_keywords = True
    g.dfas = {1: ([1], {}), 2: ([], {})}
    g.keywords = {'async': 1, 'nonlocal': 2}
    g.labels = [(1, None), (2, None)]
    g.number2symbol

# Generated at 2022-06-21 09:59:49.660823
# Unit test for constructor of class Grammar
def test_Grammar():
    grammar = Grammar()
    assert grammar.symbol2number == {}
    assert grammar.number2symbol == {}
    assert grammar.states == []
    assert grammar.dfas == {}
    assert grammar.labels == [(0, "EMPTY")]
    assert grammar.keywords == {}
    assert grammar.tokens == {}
    assert grammar.symbol2label == {}
    assert grammar.start == 256
    assert not grammar.async_keywords


# Generated at 2022-06-21 09:59:57.211544
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()

# Generated at 2022-06-21 10:00:06.878054
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {'x': 1}
    g.number2symbol = {1: 'x'}
    g.states = [[[(0, 1)]]]
    g.dfas = {1: ([[(0, 1)]], {1: 1})}
    g.labels = [(0, 'EMPTY'), (1, None)]
    g.keywords = {}
    g.tokens = {}
    g.symbol2label = {'x': 1}
    g.start = 1
    g.async_keywords = False

    h = g.copy()
    assert g == h
    assert isinstance(h, Grammar)

    assert g.symbol2number == h.symbol2number
    assert g.number2symbol == h.number

# Generated at 2022-06-21 10:00:17.511347
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.symbol2number = {
        "foo": 256,
        "bar": 257,
        "baz": 258
    }
    g.number2symbol = {
        256: "foo",
        257: "bar",
        258: "baz"
    }

# Generated at 2022-06-21 10:00:23.651809
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-21 10:00:35.847860
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    text = """
        (dp0
        S'keywords'
        p1
        (lp2
        S'bar'
        p3
        I0
        sS'async'
        p4
        I0
        sS'await'
        p5
        I0
        sS'baz'
        p6
        I0
        sS'foo'
        p7
        I0
        sS'quux'
        p8
        I0
        sS'grault'
        p9
        I0
        sS'corge'
        p10
        I0
        sS'garply'
        p11
        I0
        sS'waldo'
        p12
        I0
        s.
        """

# Generated at 2022-06-21 10:00:47.143551
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import sys
    import unittest

    class Checker(object):
        def __init__(self, obj):
            self.obj = obj

        def __eq__(self, other):
            if self.obj is not other:
                raise AssertionError("%s is not %s" % (self.obj, other))
            return True

    if sys.version_info >= (3, 8):
        class TestGrammarCopy(unittest.TestCase):

            def test_copy(self):
                test_grammar = Grammar()
                test_grammar.start = Checker(256)
                test_grammar_copy = test_grammar.copy()
                self.assertEqual(test_grammar.start, test_grammar_copy.start)

        unittest.main()  # pragma:

# Generated at 2022-06-21 10:00:52.125165
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import pytest
    g = Grammar()
    g.load(sys.executable)
    g.loads(g.dumps())
    pytest.raises(TypeError, g.loads, b"0")
    pytest.raises(ValueError, g.loads, b"a")


# Generated at 2022-06-21 10:00:58.746654
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, 'EMPTY')]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256



# Generated at 2022-06-21 10:01:07.067119
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-21 10:01:18.478174
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    from .conv import parse_grammar

    # test that the method loads of class Grammar doesn't segfault if
    # the garbage collector doesn't know about the object.
    #
    # This means the grammar tables have to be frozen, in that they
    # don't contain Python objects as values, only ints, strings,
    # tuples, lists, and dicts.  This was asserted in
    # test_conv_freeze.

    g = Grammar()

    # Much to my surprise, even with 2.7's pgen, Python 2's code pickle
    # (that implicitly uses HIGHEST_PROTOCOL) is shorter.
    #
    # Python 3.8: 873 bytes
    # Python 2.7: 863 bytes
    parse_grammar(g, "Python", 2.7)

# Generated at 2022-06-21 10:01:33.176292
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g_ = g.copy()
    assert g_ is not g
    assert g_.symbol2number is not g.symbol2number
    assert g_.number2symbol is not g.number2symbol
    assert g_.dfas is not g.dfas
    assert g_.keywords is not g.keywords
    assert g_.tokens is not g.tokens
    assert g_.symbol2label is not g.symbol2label
    assert g_.labels is not g.labels
    assert g_.states is not g.states
    assert g_.start == g.start
    assert g_.async_keywords == g.async_keywords

# Generated at 2022-06-21 10:01:43.165057
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io
    from unittest.mock import patch
    import pgen2.parser

    table_provider = pgen2.parser.GrammarC(["empty_string"])

    # Redirect output to a string
    f = io.StringIO()
    with patch.object(pgen2.parser, "sys", autospec=True) as mock_sys:
        mock_sys.stdout = f
        table_provider.report()
        output = f.getvalue()

    assert "s2n" in output
    assert "n2s" in output
    assert "states" in output
    assert "dfas" in output
    assert "labels" in output
    assert "start" in output

# Generated at 2022-06-21 10:01:45.120241
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("Grammar.pickle")



# Generated at 2022-06-21 10:01:53.204185
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io
    from contextlib import redirect_stdout
    from .conv import grammar
    g = grammar()
    f = io.StringIO()
    with redirect_stdout(f):
        g.report()
        out = f.getvalue()
        lines = out.splitlines()
    for i in range(0, 10):
        assert lines[i].startswith('s2n') or lines[i].startswith('n2s') or lines[i].startswith('states') or lines[i].startswith('dfas') or lines[i].startswith('labels') or lines[i].startswith('start')

# Generated at 2022-06-21 10:02:05.900671
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .conv import gen
    from .pgen2 import tokenize

    g = Grammar()
    g.load(gen.__file__.replace(".pyc", ".pkl"))
    # Hack to avoid comparing one large circular data structure.
    g2 = Grammar()
    g2.load(gen.__file__.replace(".pyc", ".pkl"))
    gen._grammar = g2
    g.start = g2.start
    assert g.start == g2.start
    assert g.states == g2.states
    assert g.tokens == g2.tokens
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    

# Generated at 2022-06-21 10:02:16.411281
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    import pickle

    def _dict_copy(d: Dict[str, Any]) -> Dict[str, Any]:

        def _is_pickleable(v: Any) -> bool:
            try:
                pickle.dumps(v)
                return True
            except pickle.PicklingError:
                return False

        copied = {}
        for k, v in d.items():
            assert _is_pickleable(v)
            copied[k] = v
        return copied

    def _list_copy(l: List[Any]) -> List[Any]:
        copied = []
        for v in l:
            assert _is_pickleable(v)
        copied = l[:]
        return copied

    _is_pickleable = lambda v: True
    g.symbol2

# Generated at 2022-06-21 10:02:18.129056
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = '~/Grammar.pickle'
    g = Grammar()
    g.dump(filename)


# Generated at 2022-06-21 10:02:29.561478
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g.symbol2number = {'a': 2}
    g.number2symbol = {1: 'a'}
    g.dfas = {'a': 2}
    g.keywords = {'a': 2}
    g.tokens = {1: 2}
    g.symbol2label = {'a': 2}
    g.labels = [(1, 'a'), (2, 'b')]
    g.states = [(1, 2), (3, 4)]
    g.start = 1
    g.async_keywords = True

    copy_g = g.copy()
    assert copy_g.symbol2number == {'a': 2}
    assert copy_g.number2symbol == {1: 'a'}

# Generated at 2022-06-21 10:02:39.406347
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    gr = Grammar()

# Generated at 2022-06-21 10:02:39.897894
# Unit test for method report of class Grammar
def test_Grammar_report():
    _g = Grammar()
    _g.report()

# Generated at 2022-06-21 10:02:54.523821
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-21 10:03:00.643381
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    var = [1,2,3,4]
    g1.symbol2number = {1:1, 2:2, 3:3, 4:4}
    g1.number2symbol = {1:1, 2:2, 3:3, 4:4}
    g1.dfas = {1: 1, 2:2, 3:3, 4:4}
    g1.keywords = {5:5, 6:6, 7:7, 8:8}
    g1.tokens = {9:9, 10:10, 11:11, 12:12}
    g1.labels = [var[i] for i in range(4)]
    g1.states = [var for i in range(4)]
    g1.start = var[0]
   

# Generated at 2022-06-21 10:03:12.053527
# Unit test for method report of class Grammar
def test_Grammar_report():
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def stdoutIO(stdout=None):
        old = sys.stdout
        if stdout is None:
            stdout = StringIO()
        sys.stdout = stdout
        yield stdout
        sys.stdout = old

    import sys
    import unittest

    # The standard library mock module can be used to replace parts of Grammar,
    # but this using this would make the unit test itself dependent on a
    # non-standard library module.
    # Instead, the grammar attributes are replaced with a combination of
    # hard-coded lists and mocks (using unittest.mock.MagicMock) for the
    # purpose of the unit test only.
    # The grammar attributes of Grammar.report that are tested by this unit
    #

# Generated at 2022-06-21 10:03:18.989590
# Unit test for method report of class Grammar
def test_Grammar_report():
    from . import pgen
    from . import token

    token.LPAR = 1
    token.LSQB = 2
    token.LBRACE = 3

    g = pgen.parsetok("expr : x")
    g.report()

    # Cleanup
    del token.LPAR
    del token.LSQB
    del token.LBRACE


__all__ = [
    "Grammar",
    "Label",
    "opmap",
]

# Generated at 2022-06-21 10:03:21.050195
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(b"_parser.pkl")
    assert grammar.symbol2number

# Generated at 2022-06-21 10:03:33.462970
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-21 10:03:34.402803
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g != None

# Generated at 2022-06-21 10:03:39.172115
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    grammar = Grammar()
    s = "cdgAJ+NwV26QAAAAAAAAAAAABAAAAAAAAAADlAAAAAA=\n"
    grammar.loads(s.encode())

# Generated at 2022-06-21 10:03:47.108226
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    f = tempfile.NamedTemporaryFile(delete=False)
    try:
        g.dump(f.name)
        g.load(f.name)
        assert g.symbol2number == {}
        assert g.number2symbol == {}
        assert g.states == []
        assert g.dfas == {}
        assert g.labels == [(0, "EMPTY")]
        assert g.keywords == {}
        assert g.tokens == {}
        assert g.symbol2label == {}
        assert g.start == 256
    finally:
        os.remove(f.name)

# Generated at 2022-06-21 10:03:49.394545
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert isinstance(g, Grammar)

# Generated at 2022-06-21 10:04:04.353776
# Unit test for method loads of class Grammar
def test_Grammar_loads():
  g = Grammar()
  s = g.symbol2number
  n = g.number2symbol
  a = g.dfas
  b = g.keywords
  c = g.tokens
  d = g.labels
  e = g.states
  f = g.symbol2label
  g_string = pickle.dumps(g)
  h = Grammar()
  h.loads(g_string)
  s_ = h.symbol2number
  n_ = h.number2symbol
  a_ = h.dfas
  b_ = h.keywords
  c_ = h.tokens
  d_ = h.labels
  e_ = h.states
  f_ = h.symbol2label
  assert s == s_
  assert n == n_

# Generated at 2022-06-21 10:04:15.964573
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    class GrammarSubclass(Grammar):
        pass
    s = GrammarSubclass()
    p = pickle.dumps(s)
    s1 = GrammarSubclass()
    s1.loads(p)
    assert s.symbol2number == s1.symbol2number
    assert s.number2symbol == s1.number2symbol
    assert s.states == s1.states
    assert s.dfas == s1.dfas
    assert s.labels == s1.labels
    assert s.keywords == s1.keywords
    assert s.tokens == s1.tokens
    assert s.symbol2label == s1.symbol2label
    assert s.start == s1.start
    assert s.async_keywords == s1.async_key

# Generated at 2022-06-21 10:04:23.211037
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256


# Generated at 2022-06-21 10:04:30.772450
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    g = Grammar()

# Generated at 2022-06-21 10:04:31.821265
# Unit test for constructor of class Grammar
def test_Grammar():
    Grammar()



# Generated at 2022-06-21 10:04:40.118166
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g = Grammar()
    g2 = g.copy()
    assert g2.symbol2number == {}
    assert g2.number2symbol == {}
    assert g2.dfas == {}
    assert g2.keywords == {}
    assert g2.tokens == {}
    assert g2.symbol2label == {}
    assert g2.labels == [(0, "EMPTY")]
    assert g2.states == []
    assert g2.start == 256
    assert g2.async_keywords == False

# Generated at 2022-06-21 10:04:47.153254
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    # Initialize grammar
    gram = Grammar()

    # Dump the grammar to a pickle file
    gram.dump('../../_test/data/Grammar.pickle')

    # Load the grammar from a pickle bytes object
    with open('../../_test/data/Grammar.pickle', 'rb') as byteFile:
        byte_data = byteFile.read()
    gram.loads(byte_data)

    gram.report()

# Generated at 2022-06-21 10:04:57.853047
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    import pickle
    import unittest.mock

    g1 = Grammar()
    g1.symbol2number = {"a": 1}
    g1.number2symbol = {2: "b"}
    g1.dfas = {3: pickle.dumps(42)}
    g1.keywords = {"c": 4}
    g1.tokens = {5: 6}
    g1.symbol2label = {"d": 7}
    g1.labels = [8, "e"]
    g1.states = [9]
    g1.start = 10

    with unittest.mock.patch.object(Grammar, '__init__', return_value=None):
        g2 = g1.copy()

        # Subclasses of Grammar may set other instance variables, just

# Generated at 2022-06-21 10:05:04.496999
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.symbol2number = {
        'a': 1,
        'b': 2,
    }
    g.number2symbol = {
        1: 'a',
        2: 'b',
    }
    g.states = [
        [
            [(4, 0), (5, 1)],
            [(6, 2)],
        ],
        [
            [(4, 1), (4, 2)],
            [(4, 1), (4, 2)]
        ],
    ]
    g.dfas = {
        3: ([[(0, 2)], [(3, 1)]], {2: 1, 3: 1}),
        4: ([[(0, 2)], [(5, 1)]], {2: 1, 5: 1}),
    }

# Generated at 2022-06-21 10:05:14.506133
# Unit test for method report of class Grammar
def test_Grammar_report():
    from io import StringIO
    from pprint import pprint

    e = StringIO()
    g = Grammar()
    g.number2symbol[0] = "assign"
    g.symbol2number["assign"] = 0
    g.report(file=e)
    e.seek(0)
    s = e.read()
    assert s == """s2n
{'assign': 0}
n2s
{0: 'assign'}
states
[]
dfas
{}
start
256
""".replace(
        " ", ""
    ).replace(
        "\n", ""
    )


# Generated at 2022-06-21 10:05:35.561213
# Unit test for method load of class Grammar
def test_Grammar_load():
    def test_roundtrip(g: Grammar) -> bool:
        g2 = Grammar()
        g2.load(f.name)
        return g == g2

    g = Grammar()
    fd, f.name = tempfile.mkstemp()

# Generated at 2022-06-21 10:05:45.488089
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    from .conv import text_to_grammar
    g = text_to_grammar("")
    pkl = g.dumps()
    g2 = Grammar()
    g2.loads(pkl)

# Generated at 2022-06-21 10:05:50.988844
# Unit test for method report of class Grammar
def test_Grammar_report():
    import io
    import sys

    g = Grammar()
    out = io.StringIO()
    save_stdout = sys.stdout
    sys.stdout = out
    try:
        g.report()
    finally:
        sys.stdout = save_stdout
    assert out.getvalue() == """s2n
{}
n2s
{}
states
[]
dfas
{}
labels
[(0, 'EMPTY')]
start 256
"""

# Generated at 2022-06-21 10:05:54.119466
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert grammar.number2symbol[257] == "file_input"
    assert grammar.number2symbol[262] == "funcdef"
    assert grammar.symbol2number["file_input"] == 257
    assert grammar.symbol2number["funcdef"] == 262

# Generated at 2022-06-21 10:06:06.065774
# Unit test for method report of class Grammar
def test_Grammar_report():
    from io import StringIO
    from . import pgen2
    from .tokenize_rt import tokenize_rt
    from .pygram_rt import pygram_rt
    from .pgen2_rt import find_module_and_grammar

    grammar = pgen2.load_grammar(
        pygram_rt.identifier, find_module_and_grammar(tokenize_rt)
    )

    with StringIO() as buf:
        save_stdout = sys.stdout
        sys.stdout = buf
        try:
            grammar.report()
        finally:
            sys.stdout = save_stdout

        result = buf.getvalue()

    result_lines = result.splitlines()

    # Verify that some of the report output looks approximately correct.
    assert "s2n" in result_lines
   

# Generated at 2022-06-21 10:06:08.902411
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    def do(self):
        self.dump(filename)
    filename = "./test/builtins.pickle"
    do(Grammar())


del opmap_raw

# Generated at 2022-06-21 10:06:14.660576
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import io

    class DummyGrammar(Grammar):
        pass

    pkl = io.BytesIO(b"\x80\x03}q\x00.".replace(b".", b"*"))
    grammar = DummyGrammar()
    grammar.load(pkl)
    assert grammar.symbol2number == {}
    assert grammar.number2symbol == {}
    assert grammar.states == []
    assert grammar.dfas == {}
    assert grammar.labels == [(0, "EMPTY")]
    assert grammar.keywords == {}
    assert grammar.tokens == {}
    assert grammar.symbol2label == {}
    assert grammar.start == 256


# Generated at 2022-06-21 10:06:26.091392
# Unit test for method report of class Grammar
def test_Grammar_report():
    import sys
    import io
    import unittest

    class DummyDisplay(object):
        """Capture output of method report of class Grammar to test it."""

        def __init__(self) -> None:
            self.got = io.StringIO()

# Generated at 2022-06-21 10:06:28.451477
# Unit test for method report of class Grammar
def test_Grammar_report():
    grammar = Grammar()
    grammar.report()



# Generated at 2022-06-21 10:06:30.089514
# Unit test for method report of class Grammar
def test_Grammar_report():
    g = Grammar()
    g.report()


# Generated at 2022-06-21 10:06:51.308292
# Unit test for constructor of class Grammar
def test_Grammar():
    # Check that the constructor does not crash
    g = Grammar()
    g.dump(tempfile.TemporaryFile())

# Generated at 2022-06-21 10:07:04.232431
# Unit test for method loads of class Grammar
def test_Grammar_loads():
    from .tokenize import generate_tokens, untokenize

    g = Grammar()
    g.async_keywords = True

# Generated at 2022-06-21 10:07:11.563879
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle

    # Test file generated in test_Grammar_dump()
    original = Grammar()
    original.load("Grammar.pkl")
    with open("Grammar.pkl", "rb") as f:
        pkl = f.read()
    clone = Grammar()
    clone.loads(pkl)
    # comparison of the first states of the two DFAs
    assert original.states[0][1:4] == clone.states[0][1:4]
    print("original.states[0][1:4] =", original.states[0][1:4])
    print("clone.states[0][1:4] =", clone.states[0][1:4])


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-21 10:07:15.457412
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    # Ensure that trying to dump an empty Grammar is silent.
    g.dump("/tmp/g.tmp")


if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-21 10:07:26.533208
# Unit test for method copy of class Grammar
def test_Grammar_copy():
    g1 = Grammar()
    g1.symbol2number = {"a": 1, "b": 2}
    g1.number2symbol = {1: "a", 2: "b"}
    g1.dfas = {1: ([[(1, 1), (2, 3)]], {1: 1, 3: 2}), 2: ([[(1, 1)]], {1: 1})}
    g1.keywords = {"a": 1, "b": 2}
    g1.tokens = {1: 1, 2: 2}
    g1.symbol2label = {"a": 1, "b": 2}
    g1.labels = [(1, "a"), (2, "b")]

# Generated at 2022-06-21 10:07:35.332917
# Unit test for method report of class Grammar
def test_Grammar_report():
    gram = Grammar()
    gram.start = 1
    gram.labels = [(1, None), (2, "foo"), (3, "bar")]
    gram.keywords = {"foo": 2, "bar": 3}
    gram.tokens = {3: 3, 4: 4}
    gram.symbol2number = {"A": 42, "B": 144}
    gram.number2symbol = {42: "A", 144: "B"}
    states = [[(1, 1), (2, 2)], [(3, 2)], [(4, 3)]]
    gram.states = states
    gram.dfas = {42: (states[0], {3: 1}), 144: (states[1], {4: 1})}

# Generated at 2022-06-21 10:07:47.738373
# Unit test for method loads of class Grammar

# Generated at 2022-06-21 10:07:58.819111
# Unit test for constructor of class Grammar
def test_Grammar():
    import pickle

    g = Grammar()

    def check(**kwds):
        for k, v in kwds.items():
            assert getattr(g, k) == v

    # Test initialization
    check(symbol2number={}, number2symbol={}, states=[], dfas={}, labels=[(0, "EMPTY")])
    check(keywords={}, tokens={}, symbol2label={}, start=256)

    # Test symbol addition
    g.add_symbol("foo", 256)
    check(symbol2number={"foo": 256}, number2symbol={256: "foo"})
    g.add_symbol("bar", 257)
    check(symbol2number={"foo": 256, "bar": 257}, number2symbol={256: "foo", 257: "bar"})

    # Test

# Generated at 2022-06-21 10:08:07.081173
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    from io import BytesIO

# Generated at 2022-06-21 10:08:13.407206
# Unit test for constructor of class Grammar
def test_Grammar():
    g = Grammar()
    g.start = 'file_input'
    g.labels = [('dedent', 'DEDENT'), ('indent', 'INDENT'), ('newline', 'NEWLINE'), ('endmarker', 'ENDMARKER')]
    g.keywords = {'False': 3, 'None': 2, 'True': 4}
    g.tokens = {59: 0, 60: 1, 57: 2, 61: 3, 24: 4}
    assert g.start == 'file_input'
    assert g.labels[0] == ('dedent', 'DEDENT')
    assert g.labels[1] == ('indent', 'INDENT')
    assert g.labels[2] == ('newline', 'NEWLINE')