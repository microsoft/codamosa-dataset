

# Generated at 2022-06-17 16:38:10.202791
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import os
    import tempfile
    import shutil
    import sys

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.filename = os.path.join(self.tempdir, "grammar.pickle")
            self.grammar = Grammar()
            self.grammar.symbol2number = {'a': 1, 'b': 2}
            self.grammar.number2symbol = {1: 'a', 2: 'b'}
            self.grammar.states = [[[(1, 1), (2, 2)], [(3, 3)]]]

# Generated at 2022-06-17 16:38:21.648471
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import os
    import tempfile
    import shutil
    import sys
    from . import token

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.filename = os.path.join(self.tempdir, "test.pickle")
            self.g = Grammar()
            self.g.symbol2number = {"a": 1, "b": 2}
            self.g.number2symbol = {1: "a", 2: "b"}
            self.g.states = [[[(1, 1), (2, 2)], [(3, 3), (4, 4)]]]

# Generated at 2022-06-17 16:38:31.838081
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2
    from . import conv

    g = Grammar()
    g.load("Grammar.pickle")

# Generated at 2022-06-17 16:38:42.434068
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import pickle
    from io import BytesIO

    g = Grammar()
    g.symbol2number = {'foo': 1}
    g.number2symbol = {1: 'foo'}
    g.states = [1, 2, 3]
    g.dfas = {1: (1, 2), 2: (3, 4)}
    g.labels = [(1, 'foo'), (2, 'bar')]
    g.keywords = {'foo': 1, 'bar': 2}
    g.tokens = {1: 1, 2: 2}
    g.symbol2label = {'foo': 1, 'bar': 2}
    g.start = 3
    g.async_keywords = True

    f = BytesIO()
    g.dump(f)


# Generated at 2022-06-17 16:38:51.322451
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    from . import pgen2
    from . import tokenize

    # Create a grammar object
    g = pgen2.driver.load_grammar(sys.executable)

    # Dump the grammar tables to a pickle file
    g.dump("Grammar.pickle")

    # Load the grammar tables from the pickle file
    g2 = Grammar()
    g2.load("Grammar.pickle")

    # Create a tokenize object
    t = tokenize.generate_tokens(open(__file__).readline)

    # Tokenize the file
    for tok in t:
        print(tok)


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:38:55.003934
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pickle"))
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:39:05.513244
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == 0
    assert g.dfas[257][0][0][0][0] == 0
    assert g.labels[0][1] == "EMPTY"
    assert g.keywords["and"] == 0
    assert g.tokens[token.NAME] == 0
    assert g.symbol2label["and"] == 0
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:39:11.147546
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.pickle")
    assert g.symbol2number["and"] == 258
    assert g.number2symbol[258] == "and"
    assert g.states[0][0][0][0] == 1
    assert g.dfas[258][0][0][0][0] == 1
    assert g.labels[1] == (1, None)
    assert g.keywords["False"] == 1
    assert g.tokens[1] == 1
    assert g.start == 256


# Generated at 2022-06-17 16:39:21.789394
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2
    from .pgen2 import tokenize

    g = Grammar()
    g.load(pgen2.grammar_file)
    assert g.start == g.symbol2number["file_input"]
    assert g.start == g.symbol2number["eval_input"]
    assert g.start == g.symbol2number["single_input"]
    assert g.start == g.symbol2number["decorator"]
    assert g.start == g.symbol2number["decorators"]
    assert g.start == g.symbol2number["decorated"]
    assert g.start == g.symbol2number["async_funcdef"]
    assert g.start == g.symbol2number["funcdef"]

# Generated at 2022-06-17 16:39:32.004134
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import os
    import tempfile
    from . import pgen2

    # Create a grammar object
    g = pgen2.driver.load_grammar("Grammar/Grammar")

    # Dump the grammar object to a pickle file
    with tempfile.NamedTemporaryFile(delete=False) as f:
        g.dump(f.name)

    # Load the grammar object from the pickle file
    with open(f.name, "rb") as f:
        g2 = pickle.load(f)

    # Compare the loaded grammar object with the original one
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2

# Generated at 2022-06-17 16:39:43.333881
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["single_input"] == 256
    assert g.number2symbol[256] == "single_input"
    assert g.states[0][0][0][0] == token.NEWLINE
    assert g.dfas[258][1][token.NAME] == 1
    assert g.labels[1][0] == token.NAME
    assert g.keywords["False"] == 5
    assert g.tokens[token.NAME] == 1
    assert g.symbol2label["expr_stmt"] == 261
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:39:44.465885
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pkl"))
    g.report()

# Generated at 2022-06-17 16:39:54.023350
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import pickle
    import unittest

    class GrammarSubclass(Grammar):
        def __init__(self):
            super().__init__()
            self.symbol2number = {'symbol': 1}
            self.number2symbol = {1: 'symbol'}
            self.states = [[(1, 2)], [(1, 2)]]
            self.dfas = {1: ([(1, 2)], {1: 1})}
            self.labels = [(1, 'label')]
            self.keywords = {'keyword': 1}
            self.tokens = {1: 1}
            self.symbol2label = {'symbol': 1}
            self.start = 256
            self.async_keywords = False


# Generated at 2022-06-17 16:40:01.546021
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2
    from . import conv

    g = Grammar()
    g.load("Grammar.pickle")
    g2 = Grammar()
    g2.loads(g.dumps())
    g3 = Grammar()
    g3.loads(g.dumps())
    g4 = Grammar()
    g4.loads(g.dumps())
    g5 = Grammar()
    g5.loads(g.dumps())
    g6 = Grammar()
    g6.loads(g.dumps())
    g7 = Grammar()
    g7.loads(g.dumps())
    g8 = Grammar()
    g8.loads(g.dumps())
    g9 = Grammar()
    g9.loads(g.dumps())
    g10 = Gram

# Generated at 2022-06-17 16:40:09.462065
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import conv
    from . import pgen2

    g = Grammar()
    g.load("Grammar.txt")
    g2 = Grammar()
    g2.loads(g.dumps())
    g3 = Grammar()
    g3.loads(g2.dumps())
    assert g.dumps() == g2.dumps() == g3.dumps()

    g4 = Grammar()
    g4.loads(g3.dumps())
    g5 = Grammar()
    g5.loads(g4.dumps())
    assert g4.dumps() == g5.dumps()

    g6 = Grammar()
    g6.loads(g5.dumps())
    g7 = Grammar()
    g7.loads(g6.dumps())
    assert g

# Generated at 2022-06-17 16:40:14.070879
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/tmp/test_Grammar_dump")
    g.load("/tmp/test_Grammar_dump")
    g.loads(g.dumps())
    g.copy()
    g.report()

# Generated at 2022-06-17 16:40:18.805456
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[257][0][0][0][0] == token.NAME
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["and"] == 257
    assert g.tokens[token.NAME] == 258
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:40:22.924938
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test that Grammar.load() works
    g = Grammar()
    g.load(__file__.replace(".py", ".pkl"))
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:40:26.179808
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/tmp/Grammar.dump")
    g.load("/tmp/Grammar.dump")
    g.report()

if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-17 16:40:35.337037
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[257][0][0][0][0] == token.NAME
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["and"] == 257
    assert g.tokens[token.NAME] == 1
    assert g.symbol2label["and"] == 257
    assert g.start == 256

# Generated at 2022-06-17 16:40:43.683393
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.dump("test.pkl")

    unittest.main()

# Generated at 2022-06-17 16:40:46.572136
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    from . import pgen2
    from . import pgen2_grammar

    class TestGrammarLoad(unittest.TestCase):
        def test_load(self):
            grammar = pgen2.driver.load_grammar(pgen2_grammar.grammar)
            self.assertIsInstance(grammar, Grammar)

    unittest.main()

# Generated at 2022-06-17 16:40:53.147823
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import tempfile
    import shutil
    import os

    class TestGrammarLoad(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.filename = os.path.join(self.tempdir, "grammar.pickle")

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_load(self):
            # Test that the load method of class Grammar works
            # as expected.
            g = Grammar()
            g.dump(self.filename)
            g2 = Grammar()
            g2.load(self.filename)
            self.assertEqual(g.symbol2number, g2.symbol2number)

# Generated at 2022-06-17 16:41:02.942633
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    from . import pgen2

    g = Grammar()
    g.load(pgen2.pickle_file)
    assert g.start == g.symbol2number["file_input"]
    assert g.start == g.symbol2number["eval_input"]
    assert g.start == g.symbol2number["single_input"]
    assert g.start == g.symbol2number["decorator"]
    assert g.start == g.symbol2number["decorators"]
    assert g.start == g.symbol2number["decorated"]
    assert g.start == g.symbol2number["async_funcdef"]
    assert g.start == g.symbol2number["funcdef"]
    assert g.start == g.symbol2number["parameters"]

# Generated at 2022-06-17 16:41:11.348502
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert grammar.symbol2number["and_expr"] == 258
    assert grammar.number2symbol[258] == "and_expr"
    assert grammar.states[0][0][0][0] == 0
    assert grammar.dfas[258][0][0][0][0] == 0
    assert grammar.labels[0] == (0, "EMPTY")
    assert grammar.keywords["False"] == 1
    assert grammar.tokens[1] == 1
    assert grammar.symbol2label["and_expr"] == 258
    assert grammar.start == 256
    assert grammar.async_keywords == False

# Generated at 2022-06-17 16:41:21.759218
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test that Grammar.load() can load a pickle file
    # that was generated by Grammar.dump()
    g = Grammar()
    g.symbol2number = {'foo': 1}
    g.number2symbol = {1: 'foo'}
    g.states = [[[(0, 0)]]]
    g.dfas = {1: ([[(0, 0)]], {0: 0})}
    g.labels = [(0, 'EMPTY'), (1, None)]
    g.keywords = {'foo': 1}
    g.tokens = {1: 1}
    g.symbol2label = {'foo': 1}
    g.start = 256
    g.async_keywords = False

# Generated at 2022-06-17 16:41:24.191728
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:41:33.780297
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.g = Grammar()
            self.g.symbol2number = {'a': 1, 'b': 2}
            self.g.number2symbol = {1: 'a', 2: 'b'}
            self.g.states = [[(1, 1), (2, 2)], [(3, 3), (4, 4)]]
            self.g.dfas = {1: ([(1, 1), (2, 2)], {1: 1, 2: 2}),
                           2: ([(3, 3), (4, 4)], {3: 3, 4: 4})}

# Generated at 2022-06-17 16:41:44.040942
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    from typing import Any, Dict, List, Optional, Text, Tuple, TypeVar, Union

    # Local imports
    from . import token

    _P = TypeVar("_P", bound="Grammar")
    Label = Tuple[int, Optional[Text]]
    DFA = List[List[Tuple[int, int]]]
    DFAS = Tuple[DFA, Dict[int, int]]
    Path = Union[str, "os.PathLike[str]"]


# Generated at 2022-06-17 16:41:54.697505
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'foo': 1}
    g.number2symbol = {1: 'foo'}
    g.states = [[(1, 2)]]
    g.dfas = {1: ([(1, 2)], {1: 1})}
    g.labels = [(1, 'foo')]
    g.keywords = {'foo': 1}
    g.tokens = {1: 1}
    g.symbol2label = {'foo': 1}
    g.start = 256
    g.async_keywords = False
    g.dump('/tmp/foo')
    g2 = Grammar()
    g2.load('/tmp/foo')
    assert g.symbol2number == g2.symbol2number

# Generated at 2022-06-17 16:42:11.371316
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen2
    from .pgen2 import tokenize

    g = pgen2.driver.load_grammar("Grammar.txt")
    g.dump("Grammar.pickle")
    g2 = Grammar()
    g2.load("Grammar.pickle")
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label

# Generated at 2022-06-17 16:42:23.216863
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import driver
    from . import token

    g = Grammar()
    g.load(driver.grammar)

    assert g.symbol2number["single_input"] == 256
    assert g.number2symbol[256] == "single_input"
    assert g.symbol2number["file_input"] == 257
    assert g.number2symbol[257] == "file_input"
    assert g.symbol2number["eval_input"] == 258
    assert g.number2symbol[258] == "eval_input"
    assert g.symbol2number["decorator"] == 259
    assert g.number2symbol[259] == "decorator"
    assert g.symbol2number["decorators"] == 260

# Generated at 2022-06-17 16:42:30.929614
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == 1
    assert g.dfas[257][0][0][0][0] == 1
    assert g.labels[1][0] == token.NAME
    assert g.keywords["False"] == 1
    assert g.tokens[token.NAME] == 1
    assert g.start == 257
    assert g.async_keywords == False

# Generated at 2022-06-17 16:42:38.461875
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import tempfile
    import os
    from .pgen2 import driver
    from . import token

    # Create a grammar object
    g = driver.load_grammar("Grammar/Grammar")

    # Dump the grammar object to a pickle file
    with tempfile.NamedTemporaryFile(delete=False) as f:
        g.dump(f.name)

    # Load the grammar object from the pickle file
    with open(f.name, "rb") as f:
        g2 = pickle.load(f)

    # Compare the grammar objects
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.df

# Generated at 2022-06-17 16:42:46.988990
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    import io
    from . import pgen2
    from . import token

    # Create a grammar
    g = pgen2.driver.load_grammar("Grammar/Grammar")

    # Dump the grammar tables to a pickle file
    f = io.BytesIO()
    g.dump(f)
    f.seek(0)

    # Load the grammar tables from the pickle file
    g2 = Grammar()
    g2.loads(f.read())

    # Check that the loaded grammar tables are the same as the dumped ones
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas

# Generated at 2022-06-17 16:42:54.296017
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    import io
    import sys

    # Test for Python 3.x
    if sys.version_info[0] == 3:
        # Test for Python 3.7+
        if sys.version_info[1] >= 7:
            async_keywords = True
        else:
            async_keywords = False
    # Test for Python 2.x
    else:
        async_keywords = False

    # Create a Grammar object
    g = Grammar()
    # Create a dictionary of attributes

# Generated at 2022-06-17 16:43:05.228594
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import os
    import pickle
    import tempfile
    from . import token

    class TestGrammar(unittest.TestCase):

        def setUp(self):
            self.g = Grammar()
            self.g.symbol2number = {'foo': 1, 'bar': 2}
            self.g.number2symbol = {1: 'foo', 2: 'bar'}
            self.g.states = [[(1, 2), (3, 4)], [(5, 6)]]
            self.g.dfas = {1: (self.g.states[0], {1: 1, 2: 1}),
                           2: (self.g.states[1], {3: 1})}

# Generated at 2022-06-17 16:43:13.366624
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    from . import token

    # mypyc generates objects that don't have a __dict__, but they
    # do have __getstate__ methods that will return an equivalent
    # dictionary
    if hasattr(token, "__dict__"):
        d = token.__dict__
    else:
        d = token.__getstate__()  # type: ignore

    with tempfile.NamedTemporaryFile(delete=False) as f:
        pickle.dump(d, f, pickle.HIGHEST_PROTOCOL)
    os.remove(f.name)

# Generated at 2022-06-17 16:43:17.843611
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("test_Grammar_dump.pkl")
    g.load("test_Grammar_dump.pkl")
    g.report()
    os.remove("test_Grammar_dump.pkl")

# Generated at 2022-06-17 16:43:27.534602
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert grammar.symbol2number["and_expr"] == 258
    assert grammar.number2symbol[258] == "and_expr"
    assert grammar.states[0][0][0][0] == 0
    assert grammar.dfas[258][0][0][0][0] == 0
    assert grammar.labels[0][0] == 0
    assert grammar.keywords["False"] == 0
    assert grammar.tokens[0] == 0
    assert grammar.symbol2label["and_expr"] == 258
    assert grammar.start == 256
    assert grammar.async_keywords == False

if __name__ == "__main__":
    test_

# Generated at 2022-06-17 16:43:41.427936
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[258] == "as"
    assert g.states[0][0][0][1] == 1
    assert g.dfas[258][0][0][0][1] == 1
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["and"] == 257
    assert g.tokens[token.NAME] == 1
    assert g.start == 256

# Generated at 2022-06-17 16:43:49.570579
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import sys
    import unittest
    from . import pgen2

    class Grammar_dump_TestCase(unittest.TestCase):
        def test_dump(self):
            grammar = pgen2.driver.load_grammar(sys.version_info)
            grammar.dump("Grammar.dump")
            self.assertTrue(os.path.exists("Grammar.dump"))
            os.remove("Grammar.dump")

    unittest.main()

# Generated at 2022-06-17 16:43:59.202371
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import os
    import pickle
    import tempfile
    from . import pgen2
    from . import token

    # Create a temporary file
    fd, filename = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary grammar
    g = pgen2.driver.load_grammar(sys.executable)
    g.dump(filename)

    # Load the temporary grammar
    g2 = Grammar()
    g2.load(filename)

    # Check the loaded grammar
    assert g2.symbol2number == g.symbol2number
    assert g2.number2symbol == g.number2symbol
    assert g2.states == g.states
    assert g2.dfas == g.dfas
    assert g2.labels == g.labels
   

# Generated at 2022-06-17 16:44:06.021778
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import io
    import os
    import tempfile
    from . import token

    # Create a grammar object
    g = Grammar()
    g.symbol2number = {'foo': 256, 'bar': 257}
    g.number2symbol = {256: 'foo', 257: 'bar'}
    g.states = [[[(0, 1)], [(0, 2)]]]
    g.dfas = {256: ([[(0, 1)], [(0, 2)]], {1: 1, 2: 1}), 257: ([[(0, 1)], [(0, 2)]], {1: 1, 2: 1})}
    g.labels = [(0, 'EMPTY'), (token.NAME, None), (token.NAME, None)]

# Generated at 2022-06-17 16:44:17.310750
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io
    import sys
    import os
    import tempfile
    import shutil
    import importlib
    import importlib.util
    import importlib.machinery
    import importlib.abc
    import importlib.util
    import importlib.machinery
    import importlib.abc
    import importlib.util
    import importlib.machinery
    import importlib.abc
    import importlib.util
    import importlib.machinery
    import importlib.abc
    import importlib.util
    import importlib.machinery
    import importlib.abc
    import importlib.util
    import importlib.machinery
    import importlib.abc
    import importlib.util
    import importlib.machinery
    import importlib.abc


# Generated at 2022-06-17 16:44:21.177682
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import unittest
    import unittest.mock

    class GrammarTestCase(unittest.TestCase):
        def test_dump(self):
            with unittest.mock.patch.object(sys, "argv", ["grammar.py", "test.pkl"]):
                g = Grammar()
                g.dump("test.pkl")

    unittest.main()

# Generated at 2022-06-17 16:44:33.367773
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[257][0][0][0][0] == token.NAME
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["and"] == 257
    assert g.tokens[token.NAME] == 257
    assert g.symbol2label["and"] == 257
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:44:37.417676
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("test_Grammar_dump.pkl")
    assert os.path.exists("test_Grammar_dump.pkl")
    os.remove("test_Grammar_dump.pkl")

# Generated at 2022-06-17 16:44:50.679566
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import io
    import pickle

    class GrammarTest(Grammar):
        def __init__(self):
            Grammar.__init__(self)
            self.symbol2number = {'foo': 1, 'bar': 2}
            self.number2symbol = {1: 'foo', 2: 'bar'}
            self.states = [[[(1, 1), (2, 2)], [(3, 3), (4, 4)]]]
            self.dfas = {1: ([[(1, 1), (2, 2)], [(3, 3), (4, 4)]], {1: 1}), 2: ([[(1, 1), (2, 2)], [(3, 3), (4, 4)]], {1: 1})}

# Generated at 2022-06-17 16:44:57.956772
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import unittest
    from io import BytesIO

    class GrammarTestCase(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            g.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 2}),
                      2: ([(5, 6), (7, 8)], {3: 3, 4: 4})}

# Generated at 2022-06-17 16:45:10.590268
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2

    g = Grammar()
    g.load(pgen2.__file__.rstrip("c"))
    g.report()


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:45:19.949597
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import tempfile
    import os
    from . import token

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.g = Grammar()
            self.g.symbol2number = {'foo': 256, 'bar': 257}
            self.g.number2symbol = {256: 'foo', 257: 'bar'}
            self.g.states = [[[(0, 1)], [(0, 2)]]]
            self.g.dfas = {256: ([[(0, 1)], [(0, 2)]], {1: 1}), 257: ([[(0, 1)], [(0, 2)]], {1: 1})}

# Generated at 2022-06-17 16:45:21.998886
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pkl"))
    g.report()

# Generated at 2022-06-17 16:45:29.588005
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.load(pgen2.grammar_file)
            self.assertTrue(g.symbol2number)
            self.assertTrue(g.number2symbol)
            self.assertTrue(g.states)
            self.assertTrue(g.dfas)
            self.assertTrue(g.labels)
            self.assertTrue(g.keywords)
            self.assertTrue(g.tokens)
            self.assertTrue(g.symbol2label)
            self.assertTrue(g.start)

    unittest.main()

# Generated at 2022-06-17 16:45:38.622881
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import unittest
    import pickle
    import io
    from . import pgen2
    from . import token

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = pgen2.driver.load_grammar(
                "Grammar/Grammar", picklefile=io.BytesIO(pickle.dumps(sys.grammar))
            )
            self.assertEqual(g.symbol2number["single_input"], 257)
            self.assertEqual(g.number2symbol[257], "single_input")
            self.assertEqual(g.states[0][0][0][0], token.NEWLINE)

# Generated at 2022-06-17 16:45:48.193295
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[257][0][0][0][0] == token.NAME
    assert g.labels[1] == (token.NAME, None)
    assert g.keywords["False"] == 2
    assert g.tokens[token.NAME] == 1
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:45:54.986350
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import io
    import unittest
    from unittest import mock

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            with mock.patch.object(sys, "stdout", new_callable=io.StringIO) as mock_stdout:
                g = Grammar()
                g.dump("test.pkl")
                self.assertEqual(mock_stdout.getvalue(), "")

    unittest.main()


# Generated at 2022-06-17 16:46:01.734499
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[(1, 2)], [(3, 4)]]
            g.dfas = {1: ([(1, 2)], {1: 1}), 2: ([(3, 4)], {3: 1})}
            g.labels = [(1, None), (2, None), (3, None), (4, None)]
            g.keywords = {'a': 1, 'b': 2}

# Generated at 2022-06-17 16:46:11.372356
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import sys
    import unittest
    import pickle
    from . import grammar, token
    from .pgen2 import driver

    class GrammarDumpTests(unittest.TestCase):

        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.pickle = os.path.join(self.tmpdir, "Grammar.pickle")
            self.pickle_b = os.path.join(self.tmpdir, "Grammar_b.pickle")
            self.pickle_py3 = os.path.join(self.tmpdir, "Grammar_py3.pickle")
            self.pickle_py3_b = os.path.join(self.tmpdir, "Grammar_py3_b.pickle")


# Generated at 2022-06-17 16:46:23.209844
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    from . import pgen2
    from . import driver

    class TestGrammarDump(unittest.TestCase):
        def test_dump(self):
            g = pgen2.generate_grammar("Grammar/Grammar")
            g.dump("Grammar/Grammar.pickle")
            g2 = Grammar()
            g2.load("Grammar/Grammar.pickle")
            self.assertEqual(g.symbol2number, g2.symbol2number)
            self.assertEqual(g.number2symbol, g2.number2symbol)
            self.assertEqual(g.states, g2.states)
            self.assertEqual(g.dfas, g2.dfas)
            self.assertEqual

# Generated at 2022-06-17 16:46:59.764180
# Unit test for method load of class Grammar
def test_Grammar_load():
    """
    Test method load of class Grammar.
    """
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    g.report()

# Generated at 2022-06-17 16:47:10.514048
# Unit test for method load of class Grammar
def test_Grammar_load():
    """
    Test that Grammar.load() works.
    """
    import io
    import pickle
    import unittest

    from . import pgen2

    class GrammarLoadTests(unittest.TestCase):
        def test_load(self):
            gr = pgen2.driver.load_grammar("Grammar/Grammar")
            self.assertIsInstance(gr, Grammar)
            self.assertEqual(len(gr.states), 1)
            self.assertEqual(len(gr.states[0]), 1)
            self.assertEqual(len(gr.states[0][0]), 1)
            self.assertEqual(gr.states[0][0][0][0], 0)
            self.assertEqual(gr.states[0][0][0][1], 0)


# Generated at 2022-06-17 16:47:13.604443
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.load(io.BytesIO(pickle.dumps(g)))

    unittest.main()


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:47:23.255007
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == 257
    assert g.dfas[257][0][0][0][0] == 257
    assert g.labels[257][0] == 257
    assert g.keywords["and"] == 257
    assert g.tokens[token.NAME] == 258
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:47:32.499758
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import os
    import tempfile
    from . import token

    # Test that Grammar.dump() writes a pickle file that can be read
    # by Grammar.load()
    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
    g.dfas = {1: (g.states[0], {1: 1, 2: 1}), 2: (g.states[1], {3: 1, 4: 1})}
    g.labels = [(token.NAME, 'foo'), (token.NAME, 'bar')]
    g.key

# Generated at 2022-06-17 16:47:38.398579
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    from . import pgen2
    from . import tokenize

    # Create a grammar object
    grammar = pgen2.driver.load_grammar(sys.version_info[0])

    # Dump the grammar tables to a pickle file
    grammar.dump("Grammar.pickle")

    # Load the grammar tables from the pickle file
    grammar2 = Grammar()
    grammar2.load("Grammar.pickle")

    # Compare the two grammar objects
    assert grammar.symbol2number == grammar2.symbol2number
    assert grammar.number2symbol == grammar2.number2symbol
    assert grammar.states == grammar2.states
    assert grammar.dfas == grammar2.dfas
    assert grammar.labels == grammar2.labels
    assert grammar.keywords == grammar2.key

# Generated at 2022-06-17 16:47:50.604997
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import os
    import io
    import pickle
    import unittest
    import tempfile
    import shutil
    import importlib.util
    import importlib.machinery
    import importlib.abc

    class Loader(importlib.abc.Loader):
        def __init__(self, data):
            self.data = data

        def get_filename(self, fullname):
            return "<test>"

        def get_data(self, path):
            return self.data

    class Finder(importlib.abc.MetaPathFinder):
        def __init__(self, data):
            self.data = data
