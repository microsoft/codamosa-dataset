

# Generated at 2022-06-17 16:38:20.289346
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["single_input"] == 256
    assert g.number2symbol[256] == "single_input"
    assert g.states[0][0][0][0] == token.NEWLINE
    assert g.dfas[258][0][0][0][0] == token.NAME
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["False"] == 1
    assert g.tokens[token.NAME] == 2
    assert g.symbol2label["single_input"] == 256
    assert g.start == 256
    assert g.async_keywords == False

# Unit test

# Generated at 2022-06-17 16:38:27.524531
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("test_Grammar_dump.pkl")
    g2 = Grammar()
    g2.load("test_Grammar_dump.pkl")
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label
    assert g.start == g2.start
    assert g.async_keywords == g2.async_keywords

# Generated at 2022-06-17 16:38:39.157144
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.symbol2number["assert"] == 258
    assert g.symbol2number["break"] == 259
    assert g.symbol2number["class"] == 260
    assert g.symbol2number["continue"] == 261
    assert g.symbol2number["def"] == 262
    assert g.symbol2number["del"] == 263
    assert g.symbol2number["elif"] == 264
    assert g.symbol2number["else"] == 265
    assert g.symbol2number["except"] == 266
    assert g.symbol2number["exec"] == 267
    assert g.symbol

# Generated at 2022-06-17 16:38:44.746110
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import io
    import unittest
    from unittest.mock import patch

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            with patch.object(sys, "stdout", new=io.StringIO()) as fake_out:
                g = Grammar()
                g.dump("test")
                self.assertEqual(fake_out.getvalue(), "")

    unittest.main()

# Generated at 2022-06-17 16:38:50.605924
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import os
    import pickle
    import tempfile
    import shutil
    from . import token

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.filename = os.path.join(self.tempdir, "grammar.pickle")
            self.g = Grammar()
            self.g.symbol2number = {"foo": 1, "bar": 2}
            self.g.number2symbol = {1: "foo", 2: "bar"}
            self.g.states = [[(1, 1), (2, 2)], [(3, 3), (4, 4)]]

# Generated at 2022-06-17 16:39:02.785118
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Test that Grammar.dump() works correctly
    g = Grammar()
    g.dump("test_Grammar_dump.pkl")
    g2 = Grammar()
    g2.load("test_Grammar_dump.pkl")
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label
    assert g.start == g2.start

# Generated at 2022-06-17 16:39:11.999493
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pytest
    from . import pgen2

    g = pgen2.driver.load_grammar("Grammar.txt")
    g.dump("Grammar.pickle")

    g2 = Grammar()
    g2.load("Grammar.pickle")
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label
    assert g.start == g2.start
    assert g

# Generated at 2022-06-17 16:39:22.162601
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import tempfile
    import os
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = pgen2.grammar.Grammar()
            g.start = 1
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[(1, 1), (2, 2)], [(3, 3), (4, 4)]]

# Generated at 2022-06-17 16:39:28.756343
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import io
    import os
    import tempfile
    import shutil

    class TestGrammar(unittest.TestCase):

        def setUp(self):
            self.dir = tempfile.mkdtemp()
            self.filename = os.path.join(self.dir, "test.pkl")

        def tearDown(self):
            shutil.rmtree(self.dir)

        def test_dump(self):
            g = Grammar()
            g.dump(self.filename)
            with open(self.filename, "rb") as f:
                d = pickle.load(f)
            self.assertEqual(d, g.__dict__)

        def test_load(self):
            g = Grammar()

# Generated at 2022-06-17 16:39:35.415931
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Test that Grammar.dump() works.
    #
    # This is a bit tricky because we want to test that the pickle
    # file is correct, but we don't want to depend on the exact
    # contents of the pickle file.  So we create a temporary grammar
    # object, pickle it, unpickle it, and compare the two objects.
    # They won't be equal (the unpickled one has a __reduce__ method
    # which the temporary one doesn't), but they should compare equal
    # after we strip the unpickled one's __reduce__ method.

    # Create a temporary grammar object
    g = Grammar()
    g.symbol2number = {"foo": 1, "bar": 2}
    g.number2symbol = {1: "foo", 2: "bar"}

# Generated at 2022-06-17 16:39:50.837747
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == 1
    assert g.dfas[257][0][0][0][0] == 1
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["and"] == 1
    assert g.tokens[token.NAME] == 1
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:39:58.848831
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import sys
    import unittest

    class GrammarTestCase(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            g.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 2}),
                      2: ([(5, 6), (7, 8)], {3: 3, 4: 4})}
            g.labels = [(1, None), (2, None), (3, None), (4, None)]

# Generated at 2022-06-17 16:40:08.298611
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen2
    from . import pgen2_grammar
    from . import pgen2_parse

    g = pgen2.load_grammar(pgen2_grammar.grammar, pgen2_parse.driver)
    g.dump("Grammar.dump")
    g2 = Grammar()
    g2.load("Grammar.dump")
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2

# Generated at 2022-06-17 16:40:20.844102
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    from . import token

    class Grammar(object):
        def __init__(self) -> None:
            self.symbol2number = {}
            self.number2symbol = {}
            self.states = []
            self.dfas = {}
            self.labels = [(0, "EMPTY")]
            self.keywords = {}
            self.tokens = {}
            self.symbol2label = {}
            self.start = 256
            # Python 3.7+ parses async as a keyword, not an identifier
            self.async_keywords = False

    g = Grammar()
    g.symbol2number["a"] = 1
    g.number2symbol[1] = "a"

# Generated at 2022-06-17 16:40:25.732374
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import os
    import sys
    from . import pgen2
    from . import token

    if sys.version_info < (3, 7):
        # Python 3.7+ parses async as a keyword, not an identifier
        assert "async" in token.N_TOKENS

    # Create a grammar object
    g = pgen2.driver.load_grammar("Grammar/Grammar")

    # Dump the grammar object to a pickle file
    g.dump("Grammar/Grammar.pickle")

    # Load the grammar object from the pickle file
    g2 = Grammar()
    g2.load("Grammar/Grammar.pickle")

    # Check that the grammar objects are equal
    assert g.symbol2number == g2.symbol2number


# Generated at 2022-06-17 16:40:32.468795
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import os
    import tempfile
    import shutil
    from . import pgen2

    class TestGrammarDump(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.grammar = pgen2.driver.load_grammar(self.tmpdir)

        def tearDown(self):
            shutil.rmtree(self.tmpdir)

        def test_dump(self):
            grammar = self.grammar
            grammar.dump(os.path.join(self.tmpdir, "grammar.pickle"))
            with open(os.path.join(self.tmpdir, "grammar.pickle"), "rb") as f:
                d = pickle.load(f)
           

# Generated at 2022-06-17 16:40:43.023788
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import driver

    g = Grammar()
    driver.load_grammar(g)
    g.dump("Grammar.pickle")
    g2 = Grammar()
    g2.load("Grammar.pickle")
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label
    assert g.start == g2.start

# Generated at 2022-06-17 16:40:50.384666
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert grammar.symbol2number["and"] == 258
    assert grammar.number2symbol[258] == "and"
    assert grammar.states[0][0][0][0] == 0
    assert grammar.dfas[258][0][0][0][0] == 0
    assert grammar.labels[0][0] == 0
    assert grammar.keywords["and"] == 0
    assert grammar.tokens[0] == 0
    assert grammar.start == 256

# Generated at 2022-06-17 16:40:59.163588
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import io
    import unittest
    import unittest.mock

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            with unittest.mock.patch.object(sys, "stdout", new=io.StringIO()) as mock_stdout:
                g = Grammar()
                g.dump("test_dump")
                self.assertEqual(mock_stdout.getvalue(), "")

    unittest.main()

# Generated at 2022-06-17 16:41:01.420173
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")
    g.report()


# Generated at 2022-06-17 16:41:19.737697
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import io

    g = Grammar()
    g.symbol2number = {'foo': 1}
    g.number2symbol = {1: 'foo'}
    g.states = [[(1, 2)]]
    g.dfas = {1: ([(1, 2)], {1: 2})}
    g.labels = [(1, 'foo')]
    g.keywords = {'foo': 1}
    g.tokens = {1: 1}
    g.symbol2label = {'foo': 1}
    g.start = 1
    g.async_keywords = False

    f = io.BytesIO()
    g.dump(f)
    f.seek(0)
    g2 = Grammar()
    g2.load(f)

   

# Generated at 2022-06-17 16:41:27.336925
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 258
    assert g.number2symbol[258] == "and"
    assert g.states[0][0][0][0] == 1
    assert g.dfas[258][0][0][0][0] == 1
    assert g.labels[1] == (1, None)
    assert g.keywords["and"] == 1
    assert g.tokens[token.NAME] == 1
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:41:35.149510
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    import io
    import unittest

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            g.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 2}), 2: ([(5, 6), (7, 8)], {3: 3, 4: 4})}

# Generated at 2022-06-17 16:41:40.428677
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("test_Grammar_dump.pkl")
    g.load("test_Grammar_dump.pkl")
    g.report()
    os.remove("test_Grammar_dump.pkl")

if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-17 16:41:52.067068
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[(1, 1), (2, 2)], [(3, 3), (4, 4)]]
            g.dfas = {1: ([(1, 1), (2, 2)], {1: 1, 2: 2}), 2: ([(3, 3), (4, 4)], {3: 3, 4: 4})}

# Generated at 2022-06-17 16:42:02.171508
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import os
    import tempfile
    import unittest
    import sys
    import io

    class GrammarTestCase(unittest.TestCase):
        def setUp(self):
            self.g = Grammar()
            self.g.symbol2number = {'a': 1, 'b': 2}
            self.g.number2symbol = {1: 'a', 2: 'b'}
            self.g.states = [[[(1, 1), (2, 2)], [(3, 3), (4, 4)]]]

# Generated at 2022-06-17 16:42:12.804451
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    from . import pgen2

    g = Grammar()
    g.load(pgen2.__file__.replace(".py", ".pkl"))
    assert g.symbol2number["term"] == 258
    assert g.number2symbol[258] == "term"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[258][0][0][0][0] == token.NAME
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["False"] == 257
    assert g.tokens[token.NAME] == 257
    assert g.symbol2label["term"] == 258
    assert g.start == 256
    assert g.async_keywords == False

    # Test pickle protocol

# Generated at 2022-06-17 16:42:24.711295
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    from . import pgen2
    from . import token

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.grammar = pgen2.driver.load_grammar(
                "Grammar.txt", "Grammar.pickle"
            )


# Generated at 2022-06-17 16:42:27.220964
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    g.report()

# Generated at 2022-06-17 16:42:37.379736
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import io

    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
    g.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 2}), 2: ([(5, 6), (7, 8)], {5: 5, 6: 6})}
    g.labels = [(1, 'foo'), (2, 'bar'), (3, 'baz')]
    g.keywords = {'foo': 1, 'bar': 2}

# Generated at 2022-06-17 16:42:46.080675
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import unittest
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = pgen2.Grammar()
            g.load(sys.executable)
            self.assertTrue(g.start > 256)

    unittest.main()

# Generated at 2022-06-17 16:42:53.842911
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pytest
    from . import pgen2

    # Create a grammar
    g = pgen2.driver.load_grammar("Grammar/Grammar")

    # Dump the grammar to a pickle file
    g.dump("Grammar/Grammar.pickle")

    # Load the grammar from the pickle file
    g2 = Grammar()
    g2.load("Grammar/Grammar.pickle")

    # Check that the grammar is the same
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels

# Generated at 2022-06-17 16:43:04.648700
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[[(1, 2), (3, 4)], [(5, 6), (7, 8)]]]
    g.dfas = {1: ([[(1, 2), (3, 4)], [(5, 6), (7, 8)]], {1: 1, 2: 1}), 2: ([[(1, 2), (3, 4)], [(5, 6), (7, 8)]], {1: 1, 2: 1})}

# Generated at 2022-06-17 16:43:14.485588
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import conv
    from . import pgen2

    g = Grammar()
    g.load("Grammar.txt")
    g.report()

    g = Grammar()
    g.load("Grammar.txt")
    g.report()

    g = Grammar()
    g.load("Grammar.txt")
    g.report()

    g = Grammar()
    g.load("Grammar.txt")
    g.report()

    g = Grammar()
    g.load("Grammar.txt")
    g.report()

    g = Grammar()
    g.load("Grammar.txt")
    g.report()

    g = Grammar()
    g.load("Grammar.txt")
    g.report()

    g = Grammar()

# Generated at 2022-06-17 16:43:26.364044
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import tempfile
    import os
    import pickle
    import shutil
    import sys
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.filename = os.path.join(self.tempdir, "Grammar.pickle")

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_dump_load(self):
            grammar = pgen2.driver.load_grammar(
                "Grammar.txt",
                convert=pgen2.pgen2.convert_grammar,
                logging_level=0,
            )
            grammar.dump(self.filename)

# Generated at 2022-06-17 16:43:36.768679
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[258] == "as"
    assert g.states[0][0][0][0] == 1
    assert g.dfas[258][1][token.NAME] == 1
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["False"] == 1
    assert g.tokens[token.NAME] == 1
    assert g.symbol2label["and"] == 257
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:43:40.933475
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("test.pickle")
    g.load("test.pickle")
    g.report()
    os.remove("test.pickle")

# Generated at 2022-06-17 16:43:44.353086
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pkl"))
    g.report()

# Generated at 2022-06-17 16:43:48.644540
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    g.report()

# Generated at 2022-06-17 16:43:58.602059
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[(1, 1), (2, 2)], [(3, 3), (4, 4)]]
            g.dfas = {1: ([(1, 1), (2, 2)], {1: 1, 2: 2}),
                      2: ([(3, 3), (4, 4)], {3: 3, 4: 4})}

# Generated at 2022-06-17 16:44:17.352465
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[258] == "as"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[258][0][0][0][0] == token.NAME
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["False"] == 1
    assert g.tokens[token.NAME] == 2
    assert g.symbol2label["and"] == 257
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:44:24.426052
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import io

    class TestGrammarLoad(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'foo': 1, 'bar': 2}
            g.number2symbol = {1: 'foo', 2: 'bar'}
            g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            g.dfas = {1: ([(1, 2), (3, 4)], {1: 2, 3: 4}),
                      2: ([(5, 6), (7, 8)], {5: 6, 7: 8})}
            g.labels = [(1, 'foo'), (2, 'bar')]

# Generated at 2022-06-17 16:44:35.044003
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import pickle
    import unittest

    class GrammarTestCase(unittest.TestCase):
        def test_dump(self):
            grammar = Grammar()
            grammar.symbol2number = {"a": 1, "b": 2}
            grammar.number2symbol = {1: "a", 2: "b"}
            grammar.states = [[(1, 2)], [(3, 4)]]
            grammar.dfas = {1: ([(1, 2)], {1: 1}), 2: ([(3, 4)], {3: 1})}
            grammar.labels = [(1, None), (2, None), (3, None), (4, None)]
            grammar.keywords = {"a": 1, "b": 2}

# Generated at 2022-06-17 16:44:37.417675
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pkl"))
    g.report()

# Generated at 2022-06-17 16:44:50.438799
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[257][0][0][0][0] == token.NAME
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["False"] == 1
    assert g.tokens[token.NAME] == 2
    assert g.symbol2label["and"] == 257
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:45:02.883038
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    from . import token

    # Create a grammar object
    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[(1, 1), (2, 2)], [(3, 3), (4, 4)]]
    g.dfas = {1: (g.states[0], {1: 1, 2: 1}), 2: (g.states[1], {3: 1, 4: 1})}
    g.labels = [(1, 'foo'), (2, 'bar'), (3, 'baz'), (4, 'qux')]

# Generated at 2022-06-17 16:45:13.351287
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import unittest
    import pickle
    from io import BytesIO

    class GrammarTestCase(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[(1, 2)], [(3, 4)]]
            g.dfas = {1: (1, {1: 1})}
            g.labels = [(1, 'foo'), (2, 'bar')]
            g.keywords = {'foo': 1}
            g.tokens = {1: 2}
            g.symbol2label = {'foo': 1}
            g.start = 3
            g.async_keywords

# Generated at 2022-06-17 16:45:17.032394
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2
    from . import tokenize

    g = Grammar()
    g.load("Grammar.txt")
    p = pgen2.PgenParser(g)
    p.parse(tokenize.generate_tokens(lambda: "1"))

# Generated at 2022-06-17 16:45:24.713554
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import io
    import unittest

    class GrammarTest(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            g.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 2}), 2: ([(5, 6), (7, 8)], {3: 3, 4: 4})}

# Generated at 2022-06-17 16:45:28.423580
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("test_Grammar_dump.pkl")
    g.load("test_Grammar_dump.pkl")
    g.report()
    os.remove("test_Grammar_dump.pkl")

if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-17 16:45:55.927383
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.pickle")
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == 257
    assert g.dfas[257][0][0][0][0] == 257
    assert g.labels[257][0] == 257
    assert g.keywords["and"] == 257
    assert g.tokens[token.AND] == 257
    assert g.symbol2label["and"] == 257
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:45:58.322285
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pkl"))
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:46:03.413451
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/tmp/test_Grammar_dump.pkl")
    g.load("/tmp/test_Grammar_dump.pkl")
    g.report()

if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-17 16:46:05.013454
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/tmp/test_Grammar_dump")


# Generated at 2022-06-17 16:46:17.141087
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import tempfile
    import os
    import sys
    import io
    import contextlib
    from . import token

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.grammar = Grammar()
            self.grammar.symbol2number = {'foo': 1, 'bar': 2}
            self.grammar.number2symbol = {1: 'foo', 2: 'bar'}
            self.grammar.states = [[[(1, 1), (2, 2)], [(3, 3), (4, 4)]]]

# Generated at 2022-06-17 16:46:24.215216
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))

# Generated at 2022-06-17 16:46:35.799868
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import driver

    g = Grammar()
    driver.load_grammar(g)

    # Test that the grammar is loaded properly
    assert g.symbol2number["single_input"] == 256
    assert g.number2symbol[256] == "single_input"
    assert g.dfas[256][0][0][0] == 257
    assert g.labels[257] == (token.NEWLINE, None)
    assert g.keywords["False"] == 258
    assert g.tokens[token.NAME] == 259
    assert g.symbol2label["single_input"] == 256
    assert g.start == 256
    assert g.async_keywords == False

    # Test that the grammar is dumped properly
    g.dump("Grammar.pickle")
    g2 = Gram

# Generated at 2022-06-17 16:46:49.999665
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[257][0][0][0][0] == token.NAME
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["and"] == 257
    assert g.tokens[token.NAME] == 1
    assert g.symbol2label["and"] == 257
    assert g.start == 256
    assert g.async_keywords == False


# Generated at 2022-06-17 16:46:52.481694
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pickle"))
    g.report()

# Generated at 2022-06-17 16:47:02.178293
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import io
    import sys
    import os
    import tempfile
    from . import pgen2
    from . import token

    class GrammarTestCase(unittest.TestCase):
        def setUp(self):
            self.g = pgen2.driver.load_grammar(
                os.path.join(os.path.dirname(__file__), "Grammar.txt")
            )
            self.g.dump(os.path.join(tempfile.gettempdir(), "Grammar.pickle"))

        def test_dump(self):
            with open(os.path.join(tempfile.gettempdir(), "Grammar.pickle"), "rb") as f:
                d = pickle.load(f)

# Generated at 2022-06-17 16:47:27.350904
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    from io import BytesIO

    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[[(0, 1)]]]
    g.dfas = {1: ([[(0, 1)]], {1: 1})}
    g.labels = [(0, 'EMPTY'), (1, None)]
    g.keywords = {'foo': 1}
    g.tokens = {1: 1}
    g.symbol2label = {'foo': 1}
    g.start = 256

    f = BytesIO()
    g.dump(f)
    f.seek(0)
    g2 = Grammar()


# Generated at 2022-06-17 16:47:34.951794
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    import unittest

    class TestGrammar(Grammar):
        def __init__(self):
            super().__init__()
            self.symbol2number = {'a': 1, 'b': 2}
            self.number2symbol = {1: 'a', 2: 'b'}
            self.states = [[(1, 2), (2, 3)], [(3, 4), (4, 5)]]
            self.dfas = {1: ([(1, 2), (2, 3)], {1: 1, 2: 1}),
                         2: ([(3, 4), (4, 5)], {3: 1, 4: 1})}

# Generated at 2022-06-17 16:47:42.119971
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == 1
    assert g.dfas[257][0][0][0][0] == 1
    assert g.labels[1] == (1, None)
    assert g.keywords["and"] == 1
    assert g.tokens[1] == 1
    assert g.start == 257

# Generated at 2022-06-17 16:47:51.891020
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import tempfile
    import os
    import shutil

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.g = Grammar()
            self.g.symbol2number = {'foo': 1, 'bar': 2}
            self.g.number2symbol = {1: 'foo', 2: 'bar'}
            self.g.states = [[(1, 1), (2, 2)], [(3, 3), (4, 4)]]
            self.g.dfas = {1: ([(1, 1), (2, 2)], {1: 1, 2: 2}),
                           2: ([(3, 3), (4, 4)], {3: 3, 4: 4})}

# Generated at 2022-06-17 16:47:56.988244
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == 1
    assert g.dfas[257][0][0][0][0] == 1
    assert g.labels[1][0] == token.NAME
    assert g.keywords["and"] == 1
    assert g.tokens[token.NAME] == 1
    assert g.start == 257
    assert g.async_keywords == False

# Generated at 2022-06-17 16:48:03.391236
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    import io
    import unittest

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            g.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 1}), 2: ([(5, 6), (7, 8)], {3: 1, 4: 1})}

# Generated at 2022-06-17 16:48:11.786710
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import io
    import os
    import sys
    import tempfile

    class GrammarTestCase(unittest.TestCase):
        def test_dump(self):
            grammar = Grammar()
            grammar.symbol2number = {'a': 1, 'b': 2}
            grammar.number2symbol = {1: 'a', 2: 'b'}
            grammar.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            grammar.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 1}), 2: ([(5, 6), (7, 8)], {1: 1, 2: 1})}