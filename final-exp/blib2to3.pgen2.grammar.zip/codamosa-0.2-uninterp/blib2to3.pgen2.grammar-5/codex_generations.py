

# Generated at 2022-06-17 16:38:10.166806
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))

# Generated at 2022-06-17 16:38:21.647634
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            grammar = Grammar()
            grammar.symbol2number = {'a': 1, 'b': 2}
            grammar.number2symbol = {1: 'a', 2: 'b'}
            grammar.states = [[(1, 1), (2, 2)], [(3, 3), (4, 4)]]
            grammar.dfas = {1: ([(1, 1), (2, 2)], {1: 1, 2: 2}), 2: ([(3, 3), (4, 4)], {3: 3, 4: 4})}

# Generated at 2022-06-17 16:38:24.633337
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = pgen2.grammar.Grammar()
            g.load(pgen2.grammar.DEFAULT_GRAMMAR_FILE)

    unittest.main()

# Generated at 2022-06-17 16:38:27.662890
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    g.report()

# Generated at 2022-06-17 16:38:39.156979
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))

# Generated at 2022-06-17 16:38:47.388167
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    import unittest

    class GrammarTestCase(unittest.TestCase):
        def setUp(self):
            self.g = Grammar()
            self.g.symbol2number = {'a': 1, 'b': 2}
            self.g.number2symbol = {1: 'a', 2: 'b'}
            self.g.states = [[[(1, 2), (3, 4)], [(5, 6), (7, 8)]]]

# Generated at 2022-06-17 16:38:50.272789
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:39:02.446534
# Unit test for method load of class Grammar
def test_Grammar_load():
    # pylint: disable=missing-docstring,too-few-public-methods
    class TestGrammar(Grammar):
        def __init__(self):
            super().__init__()
            self.symbol2number = {"foo": 1}
            self.number2symbol = {1: "foo"}
            self.states = [[[(1, 2)], [(2, 3)]]]
            self.dfas = {1: (self.states[0], {2: 1})}
            self.labels = [(0, "EMPTY"), (1, None), (2, None)]
            self.keywords = {"bar": 3}
            self.tokens = {4: 5}
            self.symbol2label = {"baz": 6}
            self.start = 7

# Generated at 2022-06-17 16:39:10.848868
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test that Grammar.load() works correctly
    import pickle
    from io import BytesIO

    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[[(1, 2)], [(3, 4)]]]
    g.dfas = {1: ([[(1, 2)], [(3, 4)]], {1: 1, 2: 1}), 2: ([[(5, 6)], [(7, 8)]], {3: 1, 4: 1})}

# Generated at 2022-06-17 16:39:21.758656
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import unittest
    import warnings
    from io import BytesIO

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {"a": 1, "b": 2}
            g.number2symbol = {1: "a", 2: "b"}
            g.states = [[(1, 2)], [(3, 4)]]
            g.dfas = {1: (g.states[0], {1: 1}), 2: (g.states[1], {3: 1})}
            g.labels = [(1, "a"), (2, "b"), (3, "c"), (4, "d")]
            g.keywords = {"a": 1, "b": 2}


# Generated at 2022-06-17 16:39:33.333720
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import os
    import tempfile
    import shutil
    import sys

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.temp_file = os.path.join(self.temp_dir, "test_Grammar_dump.pkl")

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_dump(self):
            g = Grammar()
            g.dump(self.temp_file)
            with open(self.temp_file, "rb") as f:
                d = pickle.load(f)
            self.assertEqual(d, g.__dict__)


# Generated at 2022-06-17 16:39:42.810032
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    from typing import Any, Dict, List, Optional, Text, Tuple, TypeVar, Union

    # Local imports
    from . import token

    _P = TypeVar("_P", bound="Grammar")
    Label = Tuple[int, Optional[Text]]
    DFA = List[List[Tuple[int, int]]]
    DFAS = Tuple[DFA, Dict[int, int]]
    Path = Union[str, "os.PathLike[str]"]


# Generated at 2022-06-17 16:39:50.802090
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'a': 1, 'b': 2}
    g.number2symbol = {1: 'a', 2: 'b'}
    g.states = [[(1, 2)], [(3, 4)]]
    g.dfas = {1: ([(1, 2)], {1: 1}), 2: ([(3, 4)], {3: 1})}
    g.labels = [(1, 'a'), (2, None), (3, 'b')]
    g.keywords = {'a': 1, 'b': 3}
    g.tokens = {1: 1, 2: 2, 3: 3}
    g.symbol2label = {'a': 1, 'b': 3}
    g.start = 256

# Generated at 2022-06-17 16:39:53.634822
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pkl"))
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:40:05.569166
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
    g.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 1}), 2: ([(5, 6), (7, 8)], {3: 1, 4: 1})}
    g.labels = [(1, 'foo'), (2, 'bar')]
    g.keywords = {'foo': 1, 'bar': 2}
    g.tokens = {1: 1, 2: 2}

# Generated at 2022-06-17 16:40:18.287072
# Unit test for method load of class Grammar
def test_Grammar_load():
    import io
    import pickle
    from . import pgen2
    from .pgen2 import tokenize

    # Create a grammar object
    g = pgen2.driver.load_grammar("Grammar/Grammar")

    # Dump the grammar object to a pickle file
    f = io.BytesIO()
    pickle.dump(g, f, pickle.HIGHEST_PROTOCOL)
    f.seek(0)

    # Load the grammar object from the pickle file
    g2 = Grammar()
    g2.loads(f.read())

    # Check that the grammar object is the same as the original
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states

# Generated at 2022-06-17 16:40:20.302183
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """
    Test Grammar.dump()
    """
    g = Grammar()
    g.dump("/tmp/test_Grammar_dump")
    g.load("/tmp/test_Grammar_dump")
    g.report()


if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-17 16:40:29.167581
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import os
    import tempfile
    import shutil
    import sys

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.dir = tempfile.mkdtemp()
            self.filename = os.path.join(self.dir, "test_grammar.pkl")

        def tearDown(self):
            shutil.rmtree(self.dir)

        def test_dump(self):
            g = Grammar()
            g.dump(self.filename)
            with open(self.filename, "rb") as f:
                d = pickle.load(f)
            self.assertEqual(d["symbol2number"], g.symbol2number)

# Generated at 2022-06-17 16:40:34.434408
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("Grammar.pickle")
    grammar.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:40:42.264429
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == 1
    assert g.dfas[257][0][0][0][0] == 1
    assert g.labels[1] == (1, None)
    assert g.keywords["and"] == 1
    assert g.tokens[1] == 1
    assert g.start == 256

# Generated at 2022-06-17 16:40:59.351925
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import sys

    g = Grammar()
    g.start = 1
    g.symbol2number = {'a': 1, 'b': 2}
    g.number2symbol = {1: 'a', 2: 'b'}
    g.states = [[[(1, 1)], [(2, 2)]]]
    g.dfas = {1: ([[(1, 1)], [(2, 2)]], {1: 1, 2: 1}), 2: ([[(1, 1)], [(2, 2)]], {1: 1, 2: 1})}
    g.labels = [(1, 'a'), (2, 'b')]
    g.keywords = {'a': 1, 'b': 2}
    g.tokens = {1: 1, 2: 2}

# Generated at 2022-06-17 16:41:09.354293
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io
    import os
    import sys
    import tempfile
    from typing import Any, Dict, List, Optional, Text, Tuple, TypeVar, Union
    from . import token
    from . import parse
    from . import pgen2

# Generated at 2022-06-17 16:41:20.346493
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import io
    import unittest
    from unittest import mock

    class TestGrammar(unittest.TestCase):
        def test_Grammar_dump(self):
            # Test that Grammar.dump() writes the expected data to the file
            # object.
            grammar = Grammar()
            grammar.symbol2number = {'foo': 1, 'bar': 2}
            grammar.number2symbol = {1: 'foo', 2: 'bar'}
            grammar.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]

# Generated at 2022-06-17 16:41:31.285712
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import tempfile
    import os
    from . import token

    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
    g.dfas = {1: (g.states[0], {1: 1, 2: 1}), 2: (g.states[1], {3: 1, 4: 1})}
    g.labels = [(token.NAME, 'foo'), (token.NAME, 'bar')]
    g.keywords = {'foo': 1, 'bar': 2}

# Generated at 2022-06-17 16:41:35.565531
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))

# Generated at 2022-06-17 16:41:38.988319
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/tmp/test_Grammar_dump")
    g.load("/tmp/test_Grammar_dump")
    g.report()

# Generated at 2022-06-17 16:41:50.054696
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert grammar.symbol2number["single_input"] == 256
    assert grammar.number2symbol[256] == "single_input"
    assert grammar.states[0][0][0][0] == token.NEWLINE
    assert grammar.dfas[257][0][0][0][0] == token.NEWLINE
    assert grammar.labels[0] == (0, "EMPTY")
    assert grammar.keywords["False"] == 257
    assert grammar.tokens[token.NAME] == 258
    assert grammar.symbol2label["expr_stmt"] == 259
    assert grammar.start == 256
    assert grammar.async_keywords == False


# Generated at 2022-06-17 16:41:56.745615
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["single_input"] == 256
    assert g.number2symbol[256] == "single_input"
    assert g.states[0][0][0][0] == token.NEWLINE
    assert g.dfas[258][0][0][0][0] == token.NEWLINE
    assert g.labels[1] == (token.NEWLINE, None)
    assert g.keywords["False"] == 2
    assert g.tokens[token.NAME] == 3
    assert g.symbol2label["expr_stmt"] == 259
    assert g.start == 256

# Generated at 2022-06-17 16:42:05.937737
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'foo': 1}
    g.number2symbol = {1: 'foo'}
    g.states = [[(1, 2), (3, 4)]]
    g.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 1})}
    g.labels = [(1, 'foo'), (2, None)]
    g.keywords = {'foo': 1}
    g.tokens = {1: 1}
    g.symbol2label = {'foo': 1}
    g.start = 256
    g.async_keywords = False

    g.dump('/tmp/test_Grammar_dump.pkl')

    g2 = Grammar()

# Generated at 2022-06-17 16:42:13.234688
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    from . import pgen2
    from . import token

    # Create a grammar object
    g = pgen2.driver.load_grammar("Grammar/Grammar")

    # Dump the grammar object to a pickle file
    g.dump("Grammar/Grammar.pickle")

    # Load the grammar object from the pickle file
    g2 = Grammar()
    g2.load("Grammar/Grammar.pickle")

    # Check that the loaded grammar object is the same as the original
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2

# Generated at 2022-06-17 16:42:25.182940
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.load(__file__.replace(".py", ".pkl"))

    unittest.main()

# Generated at 2022-06-17 16:42:33.231819
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import pytest
    from . import pgen2

    # Test that loading a pickle file works
    g = pgen2.generate_grammar()
    g.dump(sys.executable + ".pickle")
    g2 = Grammar()
    g2.load(sys.executable + ".pickle")
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label

# Generated at 2022-06-17 16:42:43.248256
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import tempfile
    import os
    import pickle
    from . import token

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'foo': 1, 'bar': 2}
            g.number2symbol = {1: 'foo', 2: 'bar'}
            g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            g.dfas = {1: (g.states[0], {1: 1, 2: 1}), 2: (g.states[1], {3: 1, 4: 1})}
            g.labels = [(token.NAME, 'foo'), (token.NAME, 'bar')]
            g

# Generated at 2022-06-17 16:42:52.030857
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    from . import pgen2
    from . import tokenize
    from . import parse

    class TestGrammarDump(unittest.TestCase):
        def test_dump(self):
            g = pgen2.driver.load_grammar("Grammar.txt")
            g.dump("Grammar.pickle")
            g2 = Grammar()
            g2.load("Grammar.pickle")
            self.assertEqual(g.symbol2number, g2.symbol2number)
            self.assertEqual(g.number2symbol, g2.number2symbol)
            self.assertEqual(g.states, g2.states)
            self.assertEqual(g.dfas, g2.dfas)

# Generated at 2022-06-17 16:43:03.238822
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'foo': 1}
    g.number2symbol = {1: 'foo'}
    g.states = [[(1, 2)], [(1, 2)]]
    g.dfas = {1: ([(1, 2)], {1: 1})}
    g.labels = [(1, 'foo')]
    g.keywords = {'foo': 1}
    g.tokens = {1: 1}
    g.symbol2label = {'foo': 1}
    g.start = 1
    g.async_keywords = False
    g.dump('/tmp/foo')
    g2 = Grammar()
    g2.load('/tmp/foo')
    assert g.symbol2number == g2.symbol2

# Generated at 2022-06-17 16:43:13.550572
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import tempfile
    import os
    import pickle
    import shutil
    import sys

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[[(1, 2), (2, 3)], [(3, 4), (4, 5)]]]

# Generated at 2022-06-17 16:43:25.491623
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    from . import pgen2
    from . import tokenize

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = pgen2.driver.load_grammar("Grammar/Grammar")
            g.report()
            g.dump("Grammar/Grammar.pickle")
            g2 = Grammar()
            g2.load("Grammar/Grammar.pickle")
            g2.report()
            self.assertEqual(g.symbol2number, g2.symbol2number)
            self.assertEqual(g.number2symbol, g2.number2symbol)
            self.assertEqual(g.states, g2.states)

# Generated at 2022-06-17 16:43:36.684757
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2
    from . import tokenize

    # Create a grammar object
    g = pgen2.driver.load_grammar("Grammar/Grammar")

    # Dump the grammar tables to a pickle file
    g.dump("Grammar/Grammar.pickle")

    # Load the grammar tables from the pickle file
    g2 = Grammar()
    g2.load("Grammar/Grammar.pickle")

    # Verify that the tables are the same
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.key

# Generated at 2022-06-17 16:43:50.069319
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    from io import BytesIO

    g = Grammar()
    g.symbol2number = {'foo': 1}
    g.number2symbol = {1: 'foo'}
    g.states = [[[(1, 2)], [(2, 3)]]]
    g.dfas = {1: ([[(1, 2)], [(2, 3)]], {2: 1})}
    g.labels = [(1, 'foo'), (2, 'bar')]
    g.keywords = {'foo': 1}
    g.tokens = {1: 2}
    g.symbol2label = {'foo': 1}
    g.start = 3
    g.async_keywords = True


# Generated at 2022-06-17 16:43:58.718147
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import os
    import tempfile
    import shutil
    from . import pgen2

    class TestGrammarDump(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.filename = os.path.join(self.tempdir, "grammar.pickle")

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_dump(self):
            g = pgen2.driver.load_grammar("Grammar/Grammar")
            g.dump(self.filename)
            with open(self.filename, "rb") as f:
                d = pickle.load(f)

# Generated at 2022-06-17 16:44:17.815947
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[[(1, 2), (2, 3)], [(1, 4), (2, 5)]]]
            g.dfas = {1: ([[(1, 2), (2, 3)], [(1, 4), (2, 5)]], {1: 1, 2: 1}), 2: ([[(1, 2), (2, 3)], [(1, 4), (2, 5)]], {1: 1, 2: 1})}
           

# Generated at 2022-06-17 16:44:23.270647
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    from typing import Any, Dict, List, Optional, Text, Tuple, TypeVar, Union
    from . import token
    _P = TypeVar("_P", bound="Grammar")
    Label = Tuple[int, Optional[Text]]
    DFA = List[List[Tuple[int, int]]]
    DFAS = Tuple[DFA, Dict[int, int]]
    Path = Union[str, "os.PathLike[str]"]


# Generated at 2022-06-17 16:44:34.346598
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import io
    import sys
    from . import pgen2
    from . import token

    g = pgen2.driver.load_grammar("Grammar.txt")
    g.dump(sys.argv[1])
    with open(sys.argv[1], "rb") as f:
        d = pickle.load(f)
    g2 = Grammar()
    g2._update(d)
    assert g2.symbol2number == g.symbol2number
    assert g2.number2symbol == g.number2symbol
    assert g2.states == g.states
    assert g2.dfas == g.dfas
    assert g2.labels == g.labels
    assert g2.keywords == g.keywords
    assert g2.tokens

# Generated at 2022-06-17 16:44:42.711193
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))

# Generated at 2022-06-17 16:44:46.399798
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("test_Grammar_dump.pickle")
    os.remove("test_Grammar_dump.pickle")

# Generated at 2022-06-17 16:44:53.066470
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    from io import BytesIO

    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[[(1, 2), (3, 4)], [(5, 6), (7, 8)]]]
    g.dfas = {1: ([[(1, 2), (3, 4)], [(5, 6), (7, 8)]], {1: 1, 2: 1}), 2: ([[(9, 10)], [(11, 12)]], {3: 1, 4: 1})}

# Generated at 2022-06-17 16:45:04.504384
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import sys
    import unittest
    from . import pgen2

    class Grammar_dump_TestCase(unittest.TestCase):
        def test_dump(self):
            # Create a temporary file
            fd, filename = tempfile.mkstemp()
            os.close(fd)
            # Create a Grammar instance
            g = pgen2.driver.load_grammar(sys.version_info)
            # Dump the grammar tables to the temporary file
            g.dump(filename)
            # Load the grammar tables from the temporary file
            g2 = Grammar()
            g2.load(filename)
            # Remove the temporary file
            os.remove(filename)
            # Check that the grammar tables are the same

# Generated at 2022-06-17 16:45:08.795588
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2

    g = Grammar()
    g.load(pgen2.grammar_file)
    g.report()


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:45:14.510591
# Unit test for method load of class Grammar
def test_Grammar_load():
    import io
    import pickle
    import unittest
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = pgen2.Grammar()
            g.load(io.BytesIO(pickle.dumps(g)))

    unittest.main()


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:45:23.071965
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[(1, 2)], [(3, 4)]]
            g.dfas = {1: ([(1, 2)], {1: 1}), 2: ([(3, 4)], {3: 1})}
            g.labels = [(1, 'foo'), (2, 'bar')]
            g.keywords = {'foo': 1, 'bar': 2}
            g.tokens = {1: 1, 2: 2}

# Generated at 2022-06-17 16:45:48.179972
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == 1
    assert g.dfas[257][0][0][0][0] == 1
    assert g.labels[1][0] == 1
    assert g.keywords["and"] == 1
    assert g.tokens[1] == 1
    assert g.start == 256

# Generated at 2022-06-17 16:45:57.894909
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io
    import sys

    class TestGrammarLoad(unittest.TestCase):
        def test_load(self):
            # Test that Grammar.load() works correctly
            # This test is a bit tricky because we need to create a
            # pickle file that contains a valid Grammar object.  We
            # can't just use pickle.dump() because the Grammar class
            # is defined in this module, so the pickle file would
            # contain a reference to this module, which won't exist
            # when we try to unpickle the file.  So we create a
            # subclass of Grammar that doesn't contain a reference to
            # this module, and we pickle an instance of that.
            class GrammarSubclass(Grammar):
                pass

            g = Grammar

# Generated at 2022-06-17 16:46:01.913183
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:46:11.924766
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import conv, pgen
    from .parse import Parser

    g = Grammar()
    g.load("Grammar.txt")
    p = Parser(g)
    p.parse("1 + 2")

    g = Grammar()
    g.load("Grammar.txt")
    p = Parser(g)
    p.parse("1 + 2")

    g = Grammar()
    g.load("Grammar.txt")
    p = Parser(g)
    p.parse("1 + 2")

    g = Grammar()
    g.load("Grammar.txt")
    p = Parser(g)
    p.parse("1 + 2")

    g = Grammar()
    g.load("Grammar.txt")
    p = Parser(g)
    p

# Generated at 2022-06-17 16:46:23.432239
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import io
    import os
    import sys
    import tempfile
    import shutil
    import py_compile
    import importlib.util
    import importlib.machinery
    import importlib.abc

    class NullLoader(importlib.abc.Loader):
        def create_module(self, spec):
            return None

        def exec_module(self, module):
            pass

    class NullFinder(importlib.abc.MetaPathFinder):
        def find_module(self, fullname, path=None):
            if fullname == "test_grammar":
                return NullLoader()

    class GrammarTestCase(unittest.TestCase):
        def setUp(self):
            self.directory = tempfile.mkdtemp()

# Generated at 2022-06-17 16:46:25.650439
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/tmp/foo")
    g.load("/tmp/foo")
    g.report()

# Generated at 2022-06-17 16:46:37.673492
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2
    from . import tokenize
    from . import token

    # Create a grammar object
    g = pgen2.driver.load_grammar("Grammar/Grammar")
    g.dump("Grammar/Grammar.pickle")

    # Load the grammar object
    h = Grammar()
    h.load("Grammar/Grammar.pickle")

    # Check that the two objects are equal
    assert g.symbol2number == h.symbol2number
    assert g.number2symbol == h.number2symbol
    assert g.states == h.states
    assert g.dfas == h.dfas
    assert g.labels == h.labels
    assert g.keywords == h.keywords
    assert g.tokens == h.tok

# Generated at 2022-06-17 16:46:50.647288
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    import io
    import sys
    import tokenize
    from . import token
    from . import parse
    from . import pgen2
    from . import pgen

    # Create a grammar object
    grammar = pgen2.pgen(pgen.grammar)

    # Dump the grammar object to a pickle file
    grammar.dump("Grammar.pickle")

    # Load the grammar object from the pickle file
    grammar2 = Grammar()
    grammar2.load("Grammar.pickle")

    # Create a parser object
    parser = parse.Parser(grammar2)

    # Parse a simple expression
    with open("simple_expr.py", "rb") as f:
        tokens = tokenize.tokenize(f.readline)

# Generated at 2022-06-17 16:47:01.412618
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.g = Grammar()
            self.g.symbol2number = {"foo": 1, "bar": 2}
            self.g.number2symbol = {1: "foo", 2: "bar"}
            self.g.states = [[[(1, 2)], [(2, 3)]]]
            self.g.dfas = {1: ([[(1, 2)], [(2, 3)]], {1: 1}), 2: ([[(1, 2)], [(2, 3)]], {1: 1})}
            self.g.labels = [(1, "foo"), (2, "bar")]
            self.g.keywords = {"foo": 1, "bar": 2}


# Generated at 2022-06-17 16:47:10.987790
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    from . import pgen2

    class GrammarTestCase(unittest.TestCase):
        def test_load(self):
            g = pgen2.Grammar()
            g.load(pgen2.grammar_file)
            self.assertTrue(g.symbol2number)
            self.assertTrue(g.number2symbol)
            self.assertTrue(g.states)
            self.assertTrue(g.dfas)
            self.assertTrue(g.labels)
            self.assertTrue(g.keywords)
            self.assertTrue(g.tokens)
            self.assertTrue(g.symbol2label)
            self.assertTrue(g.start)

    unittest.main()