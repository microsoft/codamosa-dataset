

# Generated at 2022-06-17 16:38:10.050107
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import os
    import tempfile
    import pickle
    import shutil
    import sys
    import io

    class GrammarTestCase(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.filename = os.path.join(self.tempdir, "test_grammar.pickle")
            self.grammar = Grammar()
            self.grammar.symbol2number = {"a": 1, "b": 2}
            self.grammar.number2symbol = {1: "a", 2: "b"}
            self.grammar.states = [[[(1, 2)], [(3, 4)]]]

# Generated at 2022-06-17 16:38:21.482000
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[(1, 2)], [(3, 4)]]
            g.dfas = {1: ([(1, 2)], {1: 1}), 2: ([(3, 4)], {3: 1})}
            g.labels = [(1, None), (2, None), (3, None), (4, None)]
            g.keywords = {'a': 1, 'b': 2}

# Generated at 2022-06-17 16:38:28.109887
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2 import driver
    from . import token

    g = driver.load_grammar("Grammar/Grammar")
    g.dump("Grammar/Grammar.pickle")

    # Check that the pickle file can be loaded
    g2 = Grammar()
    g2.load("Grammar/Grammar.pickle")

    # Check that the pickle file is the same as the original
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords

# Generated at 2022-06-17 16:38:38.256676
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 261
    assert g.number2symbol[261] == "and"
    assert g.states[0][0][0][0] == 1
    assert g.dfas[261][0][0][0][0] == 1
    assert g.labels[1][0] == 1
    assert g.keywords["and"] == 1
    assert g.tokens[1] == 1
    assert g.symbol2label["and"] == 1
    assert g.start == 256


# Generated at 2022-06-17 16:38:46.977134
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import os
    import tempfile
    from . import token

    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[[(1, 2), (3, 4)], [(5, 6), (7, 8)]]]
    g.dfas = {1: ([[(1, 2), (3, 4)], [(5, 6), (7, 8)]], {1: 1, 2: 1}), 2: ([[(9, 10)], [(11, 12)]], {3: 1, 4: 1})}

# Generated at 2022-06-17 16:38:48.481521
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("test.pkl")
    assert os.path.exists("test.pkl")
    os.remove("test.pkl")

# Generated at 2022-06-17 16:38:59.789807
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import tempfile
    import os
    import shutil

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.filename = os.path.join(self.tempdir, 'test.pkl')

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_dump(self):
            g = Grammar()
            g.dump(self.filename)
            with open(self.filename, 'rb') as f:
                d = pickle.load(f)
            self.assertEqual(d, g.__dict__)

    unittest.main()

if __name__ == "__main__":
    test_G

# Generated at 2022-06-17 16:39:08.084452
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[257][0][0][0][0] == token.NAME
    assert g.labels[1][0] == token.NAME
    assert g.keywords["and"] == 1
    assert g.tokens[token.NAME] == 1
    assert g.start == 257

# Generated at 2022-06-17 16:39:19.938830
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen2
    from . import conv

    g = Grammar()
    g.start = 256
    g.symbol2number = {'foo': 257, 'bar': 258}
    g.number2symbol = {257: 'foo', 258: 'bar'}
    g.states = [[[(0, 1)], [(0, 2)]]]
    g.dfas = {257: ([[(0, 1)], [(0, 2)]], {0: 1}), 258: ([[(0, 1)], [(0, 2)]], {0: 1})}
    g.labels = [(0, 'EMPTY'), (1, None), (2, None)]
    g.keywords = {}
    g.tokens = {}
    g.symbol2label = {}

    # Test dump
   

# Generated at 2022-06-17 16:39:23.665262
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:39:34.020322
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pytest
    import os
    import pickle
    import tempfile
    from . import token
    from . import pgen2
    from . import parse

    # Create a Grammar object
    g = pgen2.driver.load_grammar("Grammar/Grammar")

    # Dump the Grammar object to a pickle file
    with tempfile.NamedTemporaryFile(delete=False) as f:
        g.dump(f.name)

    # Load the pickle file into a new Grammar object
    g2 = Grammar()
    g2.load(f.name)

    # Check that the two Grammar objects are the same
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol

# Generated at 2022-06-17 16:39:42.938282
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import os
    import sys
    import tempfile

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.g = Grammar()
            self.g.symbol2number = {'foo': 1, 'bar': 2}
            self.g.number2symbol = {1: 'foo', 2: 'bar'}
            self.g.states = [[[(1, 2), (3, 4)], [(5, 6), (7, 8)]]]

# Generated at 2022-06-17 16:39:46.423256
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pkl"))
    g.report()

# Generated at 2022-06-17 16:39:56.149038
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[257][0][0][0][0] == token.NAME
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["if"] == 1
    assert g.tokens[token.NAME] == 1
    assert g.symbol2label["and"] == 257
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:39:59.339685
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.pickle")
    g.report()


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:40:07.848481
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == 1
    assert g.dfas[257][0][0][0][0] == 1
    assert g.labels[1][0] == 1
    assert g.keywords["and"] == 1
    assert g.tokens[token.NAME] == 1
    assert g.symbol2label["and"] == 1
    assert g.start == 256

# Generated at 2022-06-17 16:40:20.260317
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    from . import pgen2

    g = pgen2.driver.load_grammar("Grammar/Grammar")
    g.dump("Grammar/Grammar.pickle")
    g2 = Grammar()
    g2.load("Grammar/Grammar.pickle")
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label

# Generated at 2022-06-17 16:40:24.629490
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2
    from . import conv

    g = Grammar()
    g.load(conv.__file__.replace(".pyc", ".pkl"))
    g2 = pgen2.driver.load_grammar(conv.__file__.replace(".pyc", ".txt"))
    assert g == g2

# Generated at 2022-06-17 16:40:31.849030
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io
    import sys

    class TestGrammarLoad(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'foo': 1, 'bar': 2}
            g.number2symbol = {1: 'foo', 2: 'bar'}
            g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            g.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 1}), 2: ([(5, 6), (7, 8)], {3: 1, 4: 1})}

# Generated at 2022-06-17 16:40:43.181154
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test that Grammar.load() works
    import pickle
    import io
    import unittest

    class GrammarTestCase(unittest.TestCase):
        def test_load(self):
            # Test that Grammar.load() works
            g = Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {2: 'bar'}
            g.states = [[[(1, 2)], [(3, 4)]]]
            g.dfas = {5: ([[(6, 7)]], {8: 9})}
            g.labels = [(10, 'baz'), (11, 'qux')]
            g.keywords = {'spam': 12}
            g.tokens = {13: 14}
            g.symbol2

# Generated at 2022-06-17 16:40:59.232723
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    from . import pgen2
    from . import tokenize

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = pgen2.driver.load_grammar("Grammar.txt")
            g.dump("Grammar.pickle")
            g2 = Grammar()
            g2.load("Grammar.pickle")
            self.assertEqual(g.symbol2number, g2.symbol2number)
            self.assertEqual(g.number2symbol, g2.number2symbol)
            self.assertEqual(g.states, g2.states)
            self.assertEqual(g.dfas, g2.dfas)

# Generated at 2022-06-17 16:41:09.315860
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import io
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            grammar = pgen2.driver.load_grammar("Grammar.txt")
            with io.BytesIO() as f:
                grammar.dump(f)
                f.seek(0)
                grammar2 = Grammar()
                grammar2.loads(f.read())
                self.assertEqual(grammar.symbol2number, grammar2.symbol2number)
                self.assertEqual(grammar.number2symbol, grammar2.number2symbol)
                self.assertEqual(grammar.states, grammar2.states)
                self.assertEqual(grammar.dfas, grammar2.dfas)

# Generated at 2022-06-17 16:41:20.349122
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = pgen2.driver.load_grammar("Grammar.txt")
            g.dump("Grammar.pickle")
            g2 = Grammar()
            g2.load("Grammar.pickle")
            self.assertEqual(g.symbol2number, g2.symbol2number)
            self.assertEqual(g.number2symbol, g2.number2symbol)
            self.assertEqual(g.states, g2.states)
            self.assertEqual(g.dfas, g2.dfas)
            self.assertEqual(g.labels, g2.labels)

# Generated at 2022-06-17 16:41:22.542986
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("test.pkl")
    g.load("test.pkl")
    g.report()


# Generated at 2022-06-17 16:41:24.598789
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pkl"))
    g.report()

# Generated at 2022-06-17 16:41:33.779478
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import os
    import sys
    import tempfile
    import shutil
    import importlib

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.filename = os.path.join(self.tempdir, "grammar.pickle")
            self.grammar = Grammar()
            self.grammar.symbol2number = {'foo': 1, 'bar': 2}
            self.grammar.number2symbol = {1: 'foo', 2: 'bar'}
            self.grammar.states = [[[(1, 1), (2, 2)], [(3, 3), (4, 4)]]]

# Generated at 2022-06-17 16:41:39.301743
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/tmp/test_Grammar_dump.pkl")
    g.load("/tmp/test_Grammar_dump.pkl")
    g.report()

if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-17 16:41:49.699090
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == 0
    assert g.dfas[257][0][0][0][0] == 0
    assert g.labels[0][0] == 0
    assert g.keywords["False"] == 0
    assert g.tokens[0] == 0
    assert g.symbol2label["and"] == 0
    assert g.start == 256
    assert g.async_keywords is False

# Generated at 2022-06-17 16:41:55.268645
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import unittest
    from test.support import captured_stdout, run_unittest

    class GrammarTestCase(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.load(sys.executable)
            with captured_stdout() as stdout:
                g.report()
            self.assertTrue(stdout.getvalue())

    run_unittest(GrammarTestCase)


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:42:05.426487
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io
    import os
    import tempfile
    import shutil

    class TestGrammarLoad(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.grammar = Grammar()
            self.grammar.symbol2number = {'foo': 1, 'bar': 2}
            self.grammar.number2symbol = {1: 'foo', 2: 'bar'}
            self.grammar.states = [[[(1, 1), (2, 2)], [(3, 3), (4, 4)]]]

# Generated at 2022-06-17 16:42:14.033188
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import unittest
    from . import pgen2

    class GrammarTestCase(unittest.TestCase):
        def test_load(self):
            grammar = pgen2.driver.load_grammar(sys.version_info)
            self.assertIsInstance(grammar, Grammar)

    unittest.main()

# Generated at 2022-06-17 16:42:26.160550
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen2
    from . import conv

    # Create a grammar object
    grammar = Grammar()
    # Load the grammar tables from a pickle file
    grammar.load(conv.DEFAULT_TABLE)
    # Dump the grammar tables to a pickle file
    grammar.dump(conv.DEFAULT_TABLE)

    # Create a grammar object
    grammar = Grammar()
    # Load the grammar tables from a pickle file
    grammar.load(conv.DEFAULT_TABLE)
    # Dump the grammar tables to a pickle file
    grammar.dump(conv.DEFAULT_TABLE)

    # Create a grammar object
    grammar = Grammar()
    # Load the grammar tables from a pickle file
    grammar.load(conv.DEFAULT_TABLE)
    # Dump the grammar tables to a pickle file

# Generated at 2022-06-17 16:42:37.261730
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import sys
    import unittest
    from . import pgen2

    class GrammarDumpTests(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.addCleanup(lambda: shutil.rmtree(self.tmpdir))
            self.filename = os.path.join(self.tmpdir, "Grammar.pickle")

        def test_dump_and_load(self):
            g = pgen2.grammar.Grammar()
            g.dump(self.filename)
            g2 = pgen2.grammar.Grammar()
            g2.load(self.filename)
            self.assertEqual(g.__dict__, g2.__dict__)


# Generated at 2022-06-17 16:42:50.315909
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.g = Grammar()
            self.g.symbol2number = {'foo': 1, 'bar': 2}
            self.g.number2symbol = {1: 'foo', 2: 'bar'}
            self.g.states = [[(1, 1), (2, 2)], [(3, 3), (4, 4)]]
            self.g.dfas = {1: ([(1, 1), (2, 2)], {1: 1, 2: 1}),
                           2: ([(3, 3), (4, 4)], {3: 1, 4: 1})}

# Generated at 2022-06-17 16:43:02.621851
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import os
    import pickle
    import tempfile
    import shutil
    import sys

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.filename = os.path.join(self.tempdir, "test.pickle")
            self.g = Grammar()
            self.g.symbol2number = {"a": 1, "b": 2}
            self.g.number2symbol = {1: "a", 2: "b"}
            self.g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]

# Generated at 2022-06-17 16:43:12.992223
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test that the method load of class Grammar works correctly
    # Create a Grammar object
    g = Grammar()
    # Load the grammar tables from a pickle file
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    # Check that the grammar tables have been loaded correctly

# Generated at 2022-06-17 16:43:24.783961
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    from . import pgen2

    g = Grammar()
    g.load(pgen2.__file__.replace(".pyc", ".pkl"))
    assert g.symbol2number["stmt"] == 256
    assert g.number2symbol[256] == "stmt"
    assert g.states[0][0][0][1] == 1
    assert g.dfas[256][0][0][0][1] == 1
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["False"] == 1
    assert g.tokens[token.NAME] == 2
    assert g.symbol2label["stmt"] == 256
    assert g.start == 256
    assert g.async_keywords == False

    # Test that the pick

# Generated at 2022-06-17 16:43:26.461510
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.pickle")
    g.report()


# Generated at 2022-06-17 16:43:37.537971
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    from . import pgen2
    from . import token

    g = pgen2.driver.load_grammar("Grammar/Grammar")
    g.dump("Grammar/Grammar.pickle")
    g2 = Grammar()
    g2.load("Grammar/Grammar.pickle")
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2

# Generated at 2022-06-17 16:43:50.423050
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import os
    import tempfile
    import shutil

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.grammar = Grammar()
            self.grammar.symbol2number = {'a': 1, 'b': 2}
            self.grammar.number2symbol = {1: 'a', 2: 'b'}
            self.grammar.states = [[(1, 1), (2, 2)], [(3, 3), (4, 4)]]

# Generated at 2022-06-17 16:43:56.510990
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/tmp/test_Grammar_dump.pkl")


# Generated at 2022-06-17 16:44:02.483001
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import pytest
    from . import pgen2

    # Test that Grammar.load() raises an exception if the pickle file
    # is not found
    with pytest.raises(FileNotFoundError):
        Grammar().load("not_a_file")

    # Test that Grammar.load() raises an exception if the pickle file
    # is not a valid pickle file
    with tempfile.NamedTemporaryFile() as f:
        f.write(b"not a valid pickle file")
        f.flush()
        with pytest.raises(pickle.UnpicklingError):
            Grammar().load(f.name)

    # Test that Grammar.load() raises an exception if the pickle file
    # does not contain a valid grammar

# Generated at 2022-06-17 16:44:13.431776
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    from . import pgen2
    from . import tokenize

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.load(pgen2.grammar_file)
            self.assertEqual(g.start, g.symbol2number["file_input"])
            self.assertEqual(g.start, g.symbol2number["eval_input"])
            self.assertEqual(g.start, g.symbol2number["single_input"])
            self.assertEqual(g.start, g.symbol2number["decorator"])
            self.assertEqual(g.start, g.symbol2number["decorators"])

# Generated at 2022-06-17 16:44:22.582123
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 258
    assert g.number2symbol[258] == "and"
    assert g.symbol2number["atom"] == 261
    assert g.number2symbol[261] == "atom"
    assert g.symbol2number["listmaker"] == 267
    assert g.number2symbol[267] == "listmaker"
    assert g.symbol2number["testlist_comp"] == 270
    assert g.number2symbol[270] == "testlist_comp"
    assert g.symbol2number["argument"] == 272
    assert g.number2symbol[272] == "argument"
    assert g

# Generated at 2022-06-17 16:44:34.079984
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[(1, 2)], [(2, 3)]]
            g.dfas = {1: ([(1, 2)], {1: 1}), 2: ([(2, 3)], {2: 1})}
            g.labels = [(1, 'foo'), (2, 'bar')]
            g.keywords = {'foo': 1, 'bar': 2}
            g.tokens = {1: 1, 2: 2}

# Generated at 2022-06-17 16:44:42.595390
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import tempfile
    import os
    import shutil

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.dir = tempfile.mkdtemp()
            self.filename = os.path.join(self.dir, "grammar.pickle")

        def tearDown(self):
            shutil.rmtree(self.dir)

        def test_dump(self):
            g = Grammar()
            g.dump(self.filename)
            with open(self.filename, "rb") as f:
                d = pickle.load(f)
            self.assertEqual(d["symbol2number"], g.symbol2number)

# Generated at 2022-06-17 16:44:54.798243
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import tempfile
    import os

    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
    g.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 1}), 2: ([(5, 6), (7, 8)], {3: 1, 4: 1})}
    g.labels = [(0, 'EMPTY'), (1, 'foo'), (2, 'bar'), (3, 'baz'), (4, 'qux')]

# Generated at 2022-06-17 16:45:05.502687
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    from io import BytesIO
    from .pgen2 import driver

    g = driver.load_grammar("Grammar.txt")
    g.dump("Grammar.pickle")
    with open("Grammar.pickle", "rb") as f:
        d = pickle.load(f)
    g2 = Grammar()
    g2._update(d)
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens

# Generated at 2022-06-17 16:45:16.494867
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test that Grammar.load() can load a pickle file
    # that was created by Grammar.dump()
    g = Grammar()
    g.symbol2number = {'foo': 1}
    g.number2symbol = {1: 'foo'}
    g.states = [[(1, 2)], [(2, 3)]]
    g.dfas = {1: ([(1, 2)], {1: 1}), 2: ([(2, 3)], {2: 1})}
    g.labels = [(0, 'EMPTY'), (1, None), (2, None)]
    g.keywords = {'foo': 1}
    g.tokens = {1: 1}
    g.symbol2label = {'foo': 1}
    g.start = 256

# Generated at 2022-06-17 16:45:17.369588
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/tmp/test.pkl")


# Generated at 2022-06-17 16:45:29.898617
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io
    import sys


# Generated at 2022-06-17 16:45:33.314979
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.pickle")
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:45:35.373149
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pkl"))
    g.report()

# Generated at 2022-06-17 16:45:40.752505
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2
    from . import conv

    g = Grammar()
    g.load("Grammar.txt")
    g2 = Grammar()
    g2.load("Grammar.txt")
    assert g == g2
    g3 = Grammar()
    g3.loads(g.dumps())
    assert g == g3
    g4 = Grammar()
    g4.loads(g.dumps())
    assert g == g4

    # Test that the grammar is valid
    pgen2.driver.load_grammar(g)
    conv.convert_grammar(g)

# Generated at 2022-06-17 16:45:46.282469
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    import io
    import sys
    import unittest

    class Grammar_load_TestCase(unittest.TestCase):
        def test_load(self):
            # Test that Grammar.load() can load a pickle file
            # written by Grammar.dump()
            g = Grammar()
            g.symbol2number = {'foo': 1, 'bar': 2}
            g.number2symbol = {1: 'foo', 2: 'bar'}
            g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]

# Generated at 2022-06-17 16:45:49.857905
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pkl"))
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:45:58.939135
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import tempfile
    import os
    import shutil

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.dir = tempfile.mkdtemp()
            self.filename = os.path.join(self.dir, "test.pkl")
            self.g = Grammar()
            self.g.symbol2number = {"a": 1, "b": 2}
            self.g.number2symbol = {1: "a", 2: "b"}
            self.g.states = [[(1, 2)], [(3, 4)]]
            self.g.dfas = {1: ([(1, 2)], {1: 1}), 2: ([(3, 4)], {3: 1})}

# Generated at 2022-06-17 16:46:09.500900
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    from . import token

    class DummyGrammar(Grammar):
        def __init__(self):
            super().__init__()
            self.symbol2number = {"a": 1, "b": 2}
            self.number2symbol = {1: "a", 2: "b"}
            self.states = [[[(1, 2)], [(2, 3)]]]
            self.dfas = {1: ([[(1, 2)], [(2, 3)]], {1: 1, 2: 1}), 2: ([[(1, 2)], [(2, 3)]], {1: 1, 2: 1})}
            self.labels = [(1, "a"), (2, "b")]

# Generated at 2022-06-17 16:46:12.570007
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.pickle")
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:46:23.889181
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import io
    import unittest
    from . import pgen2

    class Grammar_dump_TestCase(unittest.TestCase):
        def test_Grammar_dump(self):
            # Test Grammar.dump()
            # Create a grammar object and dump it to a pickle file
            g = pgen2.driver.load_grammar(sys.version_info)
            f = io.BytesIO()
            g.dump(f)
            f.seek(0)
            # Load the pickle file and compare the loaded object to the
            # original
            g2 = pgen2.driver.load_grammar(sys.version_info)
            g2.loads(f.read())
            self.assertEqual(g.symbol2number, g2.symbol2number)
           

# Generated at 2022-06-17 16:46:40.901667
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io
    import os
    import sys
    import tempfile
    from . import token

    class TestGrammarLoad(unittest.TestCase):
        def setUp(self):
            self.g = Grammar()
            self.g.symbol2number = {'foo': 1}
            self.g.number2symbol = {1: 'foo'}
            self.g.states = [[[(1, 2)], [(2, 3)]]]
            self.g.dfas = {1: ([[(1, 2)], [(2, 3)]], {1: 1, 2: 1})}
            self.g.labels = [(1, 'foo'), (2, 'bar')]
            self.g.keywords = {'foo': 1}
           

# Generated at 2022-06-17 16:46:51.813473
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen2
    from . import tokenize
    from . import parse

    p = pgen2.driver.load_grammar("Grammar.txt")
    p.dump("Grammar.pickle")
    p2 = Grammar()
    p2.load("Grammar.pickle")
    assert p2.symbol2number == p.symbol2number
    assert p2.number2symbol == p.number2symbol
    assert p2.states == p.states
    assert p2.dfas == p.dfas
    assert p2.labels == p.labels
    assert p2.keywords == p.keywords
    assert p2.tokens == p.tokens
    assert p2.symbol2label == p.symbol2label
    assert p2.start

# Generated at 2022-06-17 16:47:01.823193
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import tempfile
    import os
    from . import conv
    from . import pgen2

    def _test_Grammar_dump(grammar_file: str, pickle_file: str) -> None:
        g = conv.parse_grammar(grammar_file)
        g.dump(pickle_file)
        g2 = pgen2.load_grammar(pickle_file)
        assert g.symbol2number == g2.symbol2number
        assert g.number2symbol == g2.number2symbol
        assert g.states == g2.states
        assert g.dfas == g2.dfas
        assert g.labels == g2.labels
        assert g.keywords == g2.keywords
        assert g.tokens == g2.t

# Generated at 2022-06-17 16:47:11.282434
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import io
    import unittest
    from unittest.mock import patch
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.grammar = pgen2.driver.load_grammar(
                "Grammar/Grammar", "Grammar/Grammar", "Grammar/Grammar"
            )
            self.grammar.dump("Grammar/Grammar")

        def test_dump(self):
            self.assertTrue(os.path.isfile("Grammar/Grammar"))

        def tearDown(self):
            os.remove("Grammar/Grammar")

    suite = unittest.TestLoader().loadTestsFromTestCase(TestGrammar)


# Generated at 2022-06-17 16:47:22.176945
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            g.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 1}),
                      2: ([(5, 6), (7, 8)], {3: 1, 4: 1})}

# Generated at 2022-06-17 16:47:31.424442
# Unit test for method load of class Grammar
def test_Grammar_load():
    import io
    import pickle
    import unittest

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[(0, 1), (1, 2)], [(0, 3), (2, 4)]]
            g.dfas = {1: ([[(0, 1), (1, 2)]], {1: 1}), 2: ([[(0, 3), (2, 4)]], {2: 1})}
            g.labels = [(0, 'EMPTY'), (1, None), (2, None)]

# Generated at 2022-06-17 16:47:41.717976
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test that Grammar.load() works
    import pickle
    from io import BytesIO
    from . import pgen2

    g = pgen2.driver.load_grammar(BytesIO(pickle.dumps(pgen2.driver.grammar)))
    assert g.symbol2number == pgen2.driver.grammar.symbol2number
    assert g.number2symbol == pgen2.driver.grammar.number2symbol
    assert g.states == pgen2.driver.grammar.states
    assert g.dfas == pgen2.driver.grammar.dfas
    assert g.labels == pgen2.driver.grammar.labels
    assert g.keywords == pgen2.driver.grammar.keywords

# Generated at 2022-06-17 16:47:51.774761
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import pickle
    import unittest

    class TestGrammar(Grammar):
        def __init__(self):
            super().__init__()
            self.symbol2number = {'a': 1, 'b': 2}
            self.number2symbol = {1: 'a', 2: 'b'}
            self.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            self.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 2}),
                         2: ([(5, 6), (7, 8)], {3: 3, 4: 4})}