

# Generated at 2022-06-17 16:38:21.356319
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    from . import pgen2

    class TestGrammarDump(unittest.TestCase):
        def test_dump(self):
            grammar = pgen2.driver.load_grammar("Grammar.txt")
            grammar.dump("Grammar.pickle")
            grammar2 = Grammar()
            grammar2.load("Grammar.pickle")
            self.assertEqual(grammar.symbol2number, grammar2.symbol2number)
            self.assertEqual(grammar.number2symbol, grammar2.number2symbol)
            self.assertEqual(grammar.states, grammar2.states)
            self.assertEqual(grammar.dfas, grammar2.dfas)

# Generated at 2022-06-17 16:38:28.066465
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import os
    import sys
    import tempfile
    import shutil
    import io

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.filename = os.path.join(self.tempdir, "test.pkl")

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_dump(self):
            g = Grammar()
            g.dump(self.filename)
            with open(self.filename, "rb") as f:
                d = pickle.load(f)
            self.assertEqual(d, g.__dict__)

        def test_load(self):
            g = Grammar()


# Generated at 2022-06-17 16:38:31.234761
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pkl"))
    g.report()

# Generated at 2022-06-17 16:38:41.900332
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.start == 256
    assert g.symbol2number["single_input"] == 256
    assert g.number2symbol[256] == "single_input"
    assert g.symbol2number["file_input"] == 257
    assert g.number2symbol[257] == "file_input"
    assert g.symbol2number["eval_input"] == 258
    assert g.number2symbol[258] == "eval_input"
    assert g.symbol2number["decorator"] == 259
    assert g.number2symbol[259] == "decorator"
    assert g.symbol2number["decorators"] == 260
   

# Generated at 2022-06-17 16:38:48.684164
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.symbol2number["as"] == 258
    assert g.symbol2number["assert"] == 259
    assert g.symbol2number["break"] == 260
    assert g.symbol2number["class"] == 261
    assert g.symbol2number["continue"] == 262
    assert g.symbol2number["def"] == 263
    assert g.symbol2number["del"] == 264
    assert g.symbol2number["elif"] == 265
    assert g.symbol2number["else"] == 266
    assert g.symbol2number["except"] == 267
    assert g.symbol

# Generated at 2022-06-17 16:39:00.261153
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen2
    from . import tokenize
    from . import token
    import io
    import sys
    import unittest

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.TemporaryDirectory()
            self.temp_file = os.path.join(self.temp_dir.name, "grammar.pickle")
            self.grammar = pgen2.driver.load_grammar(self.temp_file)

        def tearDown(self):
            self.temp_dir.cleanup()

        def test_dump(self):
            self.grammar.dump(self.temp_file)

# Generated at 2022-06-17 16:39:09.574538
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import os
    import shutil
    import tempfile
    import sys
    import io

    class GrammarTestCase(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.filename = os.path.join(self.tempdir, "grammar.pickle")
            self.grammar = Grammar()
            self.grammar.symbol2number = {'foo': 1, 'bar': 2}
            self.grammar.number2symbol = {1: 'foo', 2: 'bar'}
            self.grammar.states = [[[(1, 1)], [(2, 2)]]]

# Generated at 2022-06-17 16:39:14.243509
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.pickle")
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:39:25.290105
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io
    import sys

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'foo': 1, 'bar': 2}
            g.number2symbol = {1: 'foo', 2: 'bar'}
            g.states = [[[(0, 1)], [(0, 2)]]]
            g.dfas = {1: ([[(0, 1)], [(0, 2)]], {1: 1, 2: 1}), 2: ([[(0, 1)], [(0, 2)]], {1: 1, 2: 1})}
            g.labels = [(0, 'EMPTY'), (1, None), (2, None)]

# Generated at 2022-06-17 16:39:33.650706
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            # Test that Grammar.load() can load a pickle file
            # written by Grammar.dump()
            g = Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[[(0, 1)]]]
            g.dfas = {1: ([[(0, 1)]], {1: 1}), 2: ([[(0, 2)]], {2: 1})}
            g.labels = [(0, 'EMPTY'), (1, None), (2, None)]
            g.keywords = {'foo': 1}
            g.t

# Generated at 2022-06-17 16:39:51.404756
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import unittest
    from . import pgen2
    from . import tokenize
    from . import token

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = pgen2.driver.load_grammar(sys.version_info)
            self.assertIsInstance(g, Grammar)
            self.assertIsInstance(g.symbol2number, dict)
            self.assertIsInstance(g.number2symbol, dict)
            self.assertIsInstance(g.states, list)
            self.assertIsInstance(g.dfas, dict)
            self.assertIsInstance(g.labels, list)
            self.assertIsInstance(g.keywords, dict)
            self.assertIsInstance(g.tokens, dict)
           

# Generated at 2022-06-17 16:39:59.298059
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import tempfile
    import os
    import sys

    class GrammarTest(Grammar):
        def __init__(self):
            super().__init__()
            self.symbol2number = {'a': 1, 'b': 2}
            self.number2symbol = {1: 'a', 2: 'b'}
            self.states = [[[(1, 1), (2, 2)], [(3, 3), (4, 4)]]]
            self.dfas = {1: ([[(1, 1), (2, 2)], [(3, 3), (4, 4)]], {1: 1, 2: 1}),
                         2: ([[(1, 1), (2, 2)], [(3, 3), (4, 4)]], {1: 1, 2: 1})}

# Generated at 2022-06-17 16:40:08.630717
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[(1, 2)]]
            g.dfas = {1: ([(1, 2)], {2: 3})}
            g.labels = [(1, 'foo')]
            g.keywords = {'foo': 1}
            g.tokens = {1: 1}
            g.symbol2label = {'foo': 1}
            g.start = 1
            g.async_keywords = False


# Generated at 2022-06-17 16:40:11.298177
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pkl"))
    g.report()

# Generated at 2022-06-17 16:40:23.218799
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import pickle
    import unittest

    class GrammarTestCase(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[(1, 2)], [(1, 3)]]
            g.dfas = {1: ([(1, 2)], {1: 1}), 2: ([(1, 3)], {1: 1})}
            g.labels = [(1, 'foo'), (1, 'bar')]
            g.keywords = {'foo': 1, 'bar': 2}
            g.tokens = {1: 1, 2: 2}

# Generated at 2022-06-17 16:40:30.959345
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import pickle
    import unittest

    class TestGrammar(Grammar):
        def __init__(self):
            super().__init__()
            self.symbol2number = {'a': 1, 'b': 2}
            self.number2symbol = {1: 'a', 2: 'b'}
            self.states = [[[(1, 1)], [(2, 2)]]]
            self.dfas = {1: ([[(1, 1)], [(2, 2)]], {1: 1, 2: 1}), 2: ([[(1, 1)], [(2, 2)]], {1: 1, 2: 1})}
            self.labels = [(0, 'EMPTY'), (1, None), (2, None)]

# Generated at 2022-06-17 16:40:43.064608
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test that Grammar.load() works
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0] == [(1, 1), (2, 2)]
    assert g.dfas[257] == (g.states[0], {1: 1, 2: 1})
    assert g.labels[1] == (1, None)
    assert g.labels[2] == (2, None)
    assert g.keywords["and"] == 1
    assert g.tokens[1] == 1
    assert g.symbol2label["and"] == 257


# Generated at 2022-06-17 16:40:51.497747
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import driver
    from . import token

    g = Grammar()
    g.load("Grammar.txt")
    assert g.symbol2number["single_input"] == 256
    assert g.number2symbol[256] == "single_input"
    assert g.symbol2number["file_input"] == 257
    assert g.number2symbol[257] == "file_input"
    assert g.symbol2number["eval_input"] == 258
    assert g.number2symbol[258] == "eval_input"
    assert g.symbol2number["decorator"] == 259
    assert g.number2symbol[259] == "decorator"
    assert g.symbol2number["decorators"] == 260

# Generated at 2022-06-17 16:41:01.307344
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == 1
    assert g.dfas[257][0][0][0][0] == 1
    assert g.labels[1] == (1, None)
    assert g.keywords["and"] == 1
    assert g.tokens[1] == 1
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:41:10.567839
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    import unittest

    from . import pgen2

    class Grammar_dump_TestCase(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.filename = os.path.join(self.tempdir, "grammar.pickle")
            self.grammar = pgen2.grammar.Grammar()

        def tearDown(self):
            os.remove(self.filename)
            os.rmdir(self.tempdir)

        def test_dump(self):
            self.grammar.dump(self.filename)
            with open(self.filename, "rb") as f:
                d = pickle.load(f)

# Generated at 2022-06-17 16:41:25.454078
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    import io
    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[[(0, 1)], [(0, 2)]]]
    g.dfas = {1: ([[(0, 1)], [(0, 2)]], {1: 1, 2: 1}), 2: ([[(0, 1)], [(0, 2)]], {1: 1, 2: 1})}
    g.labels = [(0, 'EMPTY'), (1, None), (2, None)]
    g.keywords = {'foo': 1, 'bar': 2}
    g.tokens = {1: 1, 2: 2}
    g

# Generated at 2022-06-17 16:41:28.176492
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.pickle")
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:41:32.349185
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import unittest
    from . import pgen2

    class GrammarTestCase(unittest.TestCase):
        def test_dump(self):
            g = pgen2.driver.load_grammar(sys.version_info)
            g.dump("Grammar.pickle")

    unittest.main()

# Generated at 2022-06-17 16:41:43.658476
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[(1, 2)], [(3, 4)]]
            g.dfas = {1: ([(1, 2)], {1: 1}), 2: ([(3, 4)], {3: 1})}
            g.labels = [(1, 'a'), (2, 'b'), (3, 'c'), (4, 'd')]
            g.keywords = {'a': 1, 'b': 2}
            g.tok

# Generated at 2022-06-17 16:41:54.460359
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'foo': 1}
    g.number2symbol = {1: 'foo'}
    g.states = [[[(1, 2)], [(1, 3)]]]
    g.dfas = {1: ([[(1, 2)], [(1, 3)]], {1: 1})}
    g.labels = [(1, 'foo')]
    g.keywords = {'foo': 1}
    g.tokens = {1: 1}
    g.symbol2label = {'foo': 1}
    g.start = 256
    g.async_keywords = False
    g.dump('/tmp/test_Grammar_dump.pickle')
    g2 = Grammar()

# Generated at 2022-06-17 16:42:04.367296
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    import unittest

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
            self.assertEqual(g.symbol2number["and"], 257)
            self.assertEqual(g.number2symbol[257], "and")
            self.assertEqual(g.states[0][0][0][0], token.NAME)
            self.assertEqual(g.dfas[257][0][0][0][0], token.NAME)
            self.assertEqual(g.labels[0], (0, "EMPTY"))

# Generated at 2022-06-17 16:42:14.667525
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    from . import pgen2

    g = pgen2.driver.load_grammar("Grammar.txt")
    g.dump("Grammar.pickle")
    with open("Grammar.pickle", "rb") as f:
        d = pickle.load(f)
    assert d["symbol2number"] == g.symbol2number
    assert d["number2symbol"] == g.number2symbol
    assert d["states"] == g.states
    assert d["dfas"] == g.dfas
    assert d["labels"] == g.labels
    assert d["keywords"] == g.keywords
    assert d["tokens"] == g.tokens
    assert d["symbol2label"] == g.symbol2label

# Generated at 2022-06-17 16:42:19.235699
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pkl"))
    g.report()


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:42:23.260263
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/tmp/test_Grammar_dump")
    g.load("/tmp/test_Grammar_dump")
    g.report()

if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-17 16:42:29.725931
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test that Grammar.load() works
    from . import pgen2
    from . import tokenize

    g = Grammar()
    g.load(pgen2.__file__.replace(".pyc", ".pkl"))
    t = tokenize.generate_tokens(iter([]).__next__)
    try:
        next(t)
    except StopIteration:
        pass
    else:
        assert False, "tokenize did not raise StopIteration"


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:42:50.288692
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import tempfile
    import os
    import os.path
    import sys
    import unittest

    class GrammarTestCase(unittest.TestCase):
        def setUp(self):
            self.g = Grammar()
            self.g.symbol2number = {'foo': 1, 'bar': 2}
            self.g.number2symbol = {1: 'foo', 2: 'bar'}
            self.g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            self.g.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 1}),
                           2: ([(5, 6), (7, 8)], {3: 1, 4: 1})}


# Generated at 2022-06-17 16:43:02.621380
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Create a Grammar object
    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[[(1, 1), (2, 2)], [(3, 3), (4, 4)]]]
    g.dfas = {1: ([[(1, 1), (2, 2)], [(3, 3), (4, 4)]], {1: 1, 2: 1}), 2: ([[(5, 5), (6, 6)], [(7, 7), (8, 8)]], {5: 1, 6: 1})}

# Generated at 2022-06-17 16:43:04.314141
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:43:14.176142
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test that Grammar.load() works
    g = Grammar()
    g.start = "start"
    g.symbol2number = {"start": 1}
    g.number2symbol = {1: "start"}
    g.states = [[[(1, 2)], [(1, 3)]]]
    g.dfas = {1: ([[(1, 2)], [(1, 3)]], {1: 1})}
    g.labels = [(1, "start")]
    g.keywords = {"start": 1}
    g.tokens = {1: 1}
    g.symbol2label = {"start": 1}
    with tempfile.NamedTemporaryFile(mode="wb") as f:
        g.dump(f.name)
        f.flush()

# Generated at 2022-06-17 16:43:22.631112
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import io
    import unittest

    class Grammar_dump_TestCase(unittest.TestCase):
        def test_dump(self):
            # Create a grammar object
            g = Grammar()
            # Create a dummy file
            f = io.StringIO()
            # Call the method
            g.dump(f)
            # Check the result
            self.assertEqual(f.getvalue(), "")

    unittest.main()


# Generated at 2022-06-17 16:43:26.550367
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    import io
    import sys
    import unittest

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.loads(pickle.dumps(g))

    unittest.main(argv=sys.argv[:1], exit=False)

# Generated at 2022-06-17 16:43:37.618057
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import os
    import tempfile
    import shutil
    import sys
    import io

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.filename = os.path.join(self.tempdir, 'grammar.pickle')

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_dump(self):
            g = Grammar()
            g.dump(self.filename)
            with open(self.filename, 'rb') as f:
                d = pickle.load(f)
            self.assertEqual(d['symbol2number'], g.symbol2number)

# Generated at 2022-06-17 16:43:49.117974
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    from . import token

    # mypyc generates objects that don't have a __dict__, but they
    # do have __getstate__ methods that will return an equivalent
    # dictionary
    if hasattr(token, "__dict__"):
        d = token.__dict__
    else:
        d = token.__getstate__()  # type: ignore

    with tempfile.NamedTemporaryFile(delete=False) as f:
        pickle.dump(d, f, pickle.HIGHEST_PROTOCOL)
    os.remove(f.name)

# Generated at 2022-06-17 16:43:58.891858
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import io
    import pickle
    import sys

    class Grammar_dumpTests(unittest.TestCase):
        """Test dump() of class Grammar."""

        def test_dump(self):
            """Test dump()."""
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[[(1, 1), (2, 2)], [(3, 3), (4, 4)]],
                        [[(5, 5), (6, 6)], [(7, 7), (8, 8)]]]

# Generated at 2022-06-17 16:44:05.860265
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    from typing import Any, Dict, List, Optional, Text, Tuple, TypeVar, Union

    # Local imports
    from . import token

    _P = TypeVar("_P", bound="Grammar")
    Label = Tuple[int, Optional[Text]]
    DFA = List[List[Tuple[int, int]]]
    DFAS = Tuple[DFA, Dict[int, int]]
    Path = Union[str, "os.PathLike[str]"]


# Generated at 2022-06-17 16:44:24.943437
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import os
    import sys
    import tempfile
    import shutil
    import io
    import tokenize
    from . import token
    from . import parse
    from . import pgen2

# Generated at 2022-06-17 16:44:35.296254
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import unittest
    import unittest.mock

    class TestGrammar(Grammar):
        def __init__(self):
            super().__init__()
            self.symbol2number = {'foo': 1, 'bar': 2}
            self.number2symbol = {1: 'foo', 2: 'bar'}
            self.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            self.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 2}),
                         2: ([(5, 6), (7, 8)], {5: 5, 6: 6})}
            self.labels = [(1, 'foo'), (2, 'bar')]

# Generated at 2022-06-17 16:44:38.385800
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("test_Grammar_dump.pickle")
    assert os.path.exists("test_Grammar_dump.pickle")
    os.remove("test_Grammar_dump.pickle")

# Generated at 2022-06-17 16:44:50.880249
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    from io import BytesIO

    g = Grammar()
    g.symbol2number = {'foo': 1}
    g.number2symbol = {1: 'foo'}
    g.states = [[[(1, 2)], [(1, 3)]]]
    g.dfas = {1: ([[(1, 2)], [(1, 3)]], {1: 1})}
    g.labels = [(1, 'foo'), (2, None)]
    g.keywords = {'foo': 1}
    g.tokens = {1: 1}
    g.symbol2label = {'foo': 1}
    g.start = 256

    f = BytesIO()
    g.dump(f)
    f.seek(0)
    g2 = Grammar()

# Generated at 2022-06-17 16:44:58.025356
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2

    g = Grammar()
    g.load(pgen2.__file__.replace(".pyc", ".pkl"))
    assert g.start == 256
    assert g.symbol2number["single_input"] == 256
    assert g.number2symbol[256] == "single_input"
    assert g.states[0][0][0][0] == token.NEWLINE
    assert g.states[0][0][0][1] == 1
    assert g.states[0][1][0][0] == token.ENDMARKER
    assert g.states[0][1][0][1] == 1
    assert g.states[0][1][1][0] == 256
    assert g.states[0][1][1][1] == 2

# Generated at 2022-06-17 16:45:06.935779
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import os
    import pickle
    import tempfile
    from . import token

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'foo': 1, 'bar': 2}
            g.number2symbol = {1: 'foo', 2: 'bar'}
            g.states = [[[(1, 2), (3, 4)], [(5, 6), (7, 8)]]]
            g.dfas = {1: ([[(1, 2), (3, 4)], [(5, 6), (7, 8)]], {1: 1}), 2: ([[(9, 10)]], {2: 1})}

# Generated at 2022-06-17 16:45:17.031920
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import io
    import os
    import sys
    from . import pgen2
    from . import token

    class TestGrammarDump(unittest.TestCase):
        def setUp(self):
            self.pkl = io.BytesIO()
            self.grammar = pgen2.grammar.Grammar()
            self.grammar.symbol2number = {'foo': 1, 'bar': 2}
            self.grammar.number2symbol = {1: 'foo', 2: 'bar'}
            self.grammar.states = [[[(1, 1), (2, 2)], [(3, 3), (4, 4)]]]

# Generated at 2022-06-17 16:45:19.600443
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("Grammar.pickle")
    grammar.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:45:28.253551
# Unit test for method load of class Grammar
def test_Grammar_load():
    import io
    import pickle
    import unittest

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            g.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 1}), 2: ([(5, 6), (7, 8)], {3: 1, 4: 1})}

# Generated at 2022-06-17 16:45:29.621837
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")
    g.report()


# Generated at 2022-06-17 16:45:44.709897
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import unittest
    from . import pgen2

    class GrammarLoadTests(unittest.TestCase):
        def test_load(self):
            g = pgen2.Grammar()
            g.load(sys.executable)

    unittest.main()

# Generated at 2022-06-17 16:45:53.606543
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import sys
    import unittest

    class Grammar_dumpTests(unittest.TestCase):
        def test_it(self):
            # Issue #18078: Grammar.dump() should not crash on Windows
            # when the file already exists.
            if sys.platform == "win32":
                filename = "test_grammar.pkl"
                if os.path.exists(filename):
                    os.unlink(filename)
                g = Grammar()
                g.dump(filename)
                g.dump(filename)
                os.unlink(filename)

    unittest.main()

# Generated at 2022-06-17 16:46:03.871744
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import os
    import tempfile

    # Create a Grammar object
    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[(1, 2)], [(3, 4)]]
    g.dfas = {1: ([(1, 2)], {1: 1}), 2: ([(3, 4)], {3: 1})}
    g.labels = [(1, 'foo'), (2, 'bar')]
    g.keywords = {'foo': 1, 'bar': 2}
    g.tokens = {1: 1, 2: 2}

# Generated at 2022-06-17 16:46:12.617811
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import tempfile
    import os

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.filename = os.path.join(self.tempdir, "test.pickle")

        def tearDown(self):
            os.remove(self.filename)
            os.rmdir(self.tempdir)

        def test_dump(self):
            g = Grammar()
            g.dump(self.filename)
            self.assertTrue(os.path.exists(self.filename))

    unittest.main()

# Generated at 2022-06-17 16:46:23.889397
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {"a": 1, "b": 2}
            g.number2symbol = {1: "a", 2: "b"}
            g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            g.dfas = {1: (g.states[0], {1: 1, 2: 1}), 2: (g.states[1], {3: 1, 4: 1})}
            g.labels = [(1, "a"), (2, "b"), (3, "c"), (4, "d")]

# Generated at 2022-06-17 16:46:35.597968
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import tempfile
    import os
    import sys

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.g = Grammar()
            self.g.symbol2number = {'foo': 1, 'bar': 2}
            self.g.number2symbol = {1: 'foo', 2: 'bar'}
            self.g.states = [[(0, 1), (1, 2)], [(0, 3)]]
            self.g.dfas = {1: (self.g.states[0], {1: 1}), 2: (self.g.states[1], {2: 1})}
            self.g.labels = [(0, None), (1, None), (2, None), (3, None)]

# Generated at 2022-06-17 16:46:42.274002
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pytest
    import os
    import pickle
    from . import token

    # Create a Grammar object
    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[[(1, 2), (3, 4)], [(5, 6)]]]
    g.dfas = {1: ([[(1, 2), (3, 4)], [(5, 6)]], {1: 1, 2: 1}), 2: ([[(7, 8)]], {3: 1})}

# Generated at 2022-06-17 16:46:51.488292
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import sys
    import unittest
    from . import pgen2

    class Grammar_dump_TestCase(unittest.TestCase):
        def setUp(self):
            self.temp_file = tempfile.mkstemp()[1]
            self.grammar = pgen2.driver.load_grammar(sys.version_info)

        def tearDown(self):
            os.remove(self.temp_file)

        def test_dump(self):
            self.grammar.dump(self.temp_file)
            self.assertTrue(os.path.exists(self.temp_file))

    unittest.main()

# Generated at 2022-06-17 16:47:01.047936
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.pickle")
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[258] == "as"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[258][0][0][0][0] == token.NAME
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["False"] == 257
    assert g.tokens[token.NAME] == 257
    assert g.symbol2label["and"] == 257
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:47:11.222524
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import os
    import tempfile
    from . import pgen2

    # Create a temporary file
    fd, filename = tempfile.mkstemp()
    os.close(fd)

    # Create a grammar object
    g = pgen2.driver.load_grammar(filename)

    # Dump the grammar object
    g.dump(filename)

    # Load the grammar object
    g2 = Grammar()
    g2.load(filename)

    # Compare the two grammar objects
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.key

# Generated at 2022-06-17 16:47:38.314248
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[(0, 1)]]
            g.dfas = {1: ([(0, 1)], {1: 1})}
            g.labels = [(0, 'foo')]
            g.keywords = {'foo': 1}
            g.tokens = {1: 1}
            g.symbol2label = {'foo': 1}
            g.start = 1
            g.async_keywords = False

            f = io.BytesIO()
            g.dump

# Generated at 2022-06-17 16:47:50.573274
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import io
    import os
    import tempfile

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.g = Grammar()
            self.g.symbol2number = {'foo': 1, 'bar': 2}
            self.g.number2symbol = {1: 'foo', 2: 'bar'}
            self.g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            self.g.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 2}),
                           2: ([(5, 6), (7, 8)], {3: 3, 4: 4})}
            self.g.lab

# Generated at 2022-06-17 16:47:56.538670
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import os
    import tempfile
    import shutil

    class TestGrammar(unittest.TestCase):

        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.filename = os.path.join(self.tmpdir, "grammar.pkl")
            self.g = Grammar()
            self.g.symbol2number = {"a": 1, "b": 2}
            self.g.number2symbol = {1: "a", 2: "b"}
            self.g.states = [[[(1, 2)], [(2, 3)]]]

# Generated at 2022-06-17 16:48:03.031881
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import os
    import pickle
    import tempfile
    import shutil

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.filename = os.path.join(self.tempdir, "test.pkl")
            self.g = Grammar()
            self.g.symbol2number = {"a": 1, "b": 2}
            self.g.number2symbol = {1: "a", 2: "b"}
            self.g.states = [[[(1, 1), (2, 2)], [(3, 3), (4, 4)]]]

# Generated at 2022-06-17 16:48:11.289074
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[(0, 0)]]
            g.dfas = {1: ([[(0, 0)]], {0: 0})}
            g.labels = [(0, 'EMPTY')]
            g.keywords = {'foo': 1}
            g.tokens = {1: 1}
            g.symbol2label = {'foo': 1}
            g.start = 256
            g.async_keywords = False

            f = io.BytesIO()
            pick