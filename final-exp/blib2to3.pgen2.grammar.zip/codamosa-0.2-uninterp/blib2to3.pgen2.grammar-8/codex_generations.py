

# Generated at 2022-06-17 16:38:15.235906
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'a': 1, 'b': 2}
    g.number2symbol = {1: 'a', 2: 'b'}
    g.states = [[[(1, 1)], [(2, 2)]]]
    g.dfas = {1: ([[(1, 1)], [(2, 2)]], {1: 1, 2: 1}), 2: ([[(1, 1)], [(2, 2)]], {1: 1, 2: 1})}
    g.labels = [(1, None), (2, None)]
    g.keywords = {'a': 1, 'b': 2}
    g.tokens = {1: 1, 2: 2}

# Generated at 2022-06-17 16:38:18.531673
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    g.report()

# Generated at 2022-06-17 16:38:26.545523
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Test that Grammar.dump() works as expected.
    import unittest
    import os
    import pickle
    import tempfile
    from . import token

    class TestGrammarDump(unittest.TestCase):
        def setUp(self):
            self.g = Grammar()
            self.g.symbol2number = {'a': 1, 'b': 2}
            self.g.number2symbol = {1: 'a', 2: 'b'}
            self.g.states = [[(1, 1), (2, 2)], [(3, 3), (4, 4)]]
            self.g.dfas = {1: (1, {1: 1}), 2: (2, {2: 1})}

# Generated at 2022-06-17 16:38:38.662991
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    from . import pgen2

    class Grammar_load_TestCase(unittest.TestCase):
        def test_load(self):
            g = pgen2.Grammar()
            g.load(pgen2.grammar_file)
            self.assertTrue(g.symbol2number)
            self.assertTrue(g.number2symbol)
            self.assertTrue(g.states)
            self.assertTrue(g.dfas)
            self.assertTrue(g.labels)
            self.assertTrue(g.keywords)
            self.assertTrue(g.tokens)
            self.assertTrue(g.symbol2label)
            self.assertTrue(g.start)
            self.assertTrue(g.async_keywords)

    unitt

# Generated at 2022-06-17 16:38:47.073341
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'foo': 1}
    g.number2symbol = {1: 'foo'}
    g.states = [[[(1, 2)], [(2, 3)], [(3, 4)]]]
    g.dfas = {1: ([[(1, 2)], [(2, 3)], [(3, 4)]], {1: 1})}
    g.labels = [(1, 'foo'), (2, 'bar'), (3, 'baz')]
    g.keywords = {'foo': 1, 'bar': 2, 'baz': 3}
    g.tokens = {1: 1, 2: 2, 3: 3}
    g.symbol2label = {'foo': 1, 'bar': 2, 'baz': 3}


# Generated at 2022-06-17 16:38:51.938712
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import tempfile
    import os
    import sys
    from . import pgen2

    class TestGrammarDump(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.filename = os.path.join(self.tempdir, "Grammar.pickle")
            self.grammar = pgen2.driver.load_grammar(self.tempdir)

        def tearDown(self):
            os.unlink(self.filename)
            os.rmdir(self.tempdir)

        def test_dump(self):
            self.grammar.dump(self.filename)
            with open(self.filename, "rb") as f:
                d = pickle.load(f)


# Generated at 2022-06-17 16:39:04.062877
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import tempfile
    from . import conv
    from . import token

    # Create a grammar object
    g = conv.Converter()
    g.convert(token)

    # Dump the grammar object to a pickle file
    with tempfile.TemporaryDirectory() as tmpdirname:
        filename = os.path.join(tmpdirname, "test_Grammar_dump.pickle")
        g.dump(filename)

        # Load the grammar object from the pickle file
        g2 = Grammar()
        g2.load(filename)

        # Check that the grammar objects are equal
        assert g.symbol2number == g2.symbol2number
        assert g.number2symbol == g2.number2symbol
        assert g.states == g2.states
        assert g.dfas

# Generated at 2022-06-17 16:39:11.857031
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    import io
    import sys
    from . import token

    # Create a Grammar object
    g = Grammar()

    # Set its instance variables
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[[(1, 2), (3, 4)], [(5, 6), (7, 8)]]]
    g.dfas = {1: (g.states[0], {1: 1, 2: 1}), 2: (g.states[0], {3: 1, 4: 1})}
    g.labels = [(1, 'foo'), (2, 'bar'), (3, 'baz'), (4, 'quux')]

# Generated at 2022-06-17 16:39:22.089816
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    from typing import Any, Dict, List, Optional, Text, Tuple, TypeVar, Union

    # Local imports
    from . import token

    _P = TypeVar("_P", bound="Grammar")
    Label = Tuple[int, Optional[Text]]
    DFA = List[List[Tuple[int, int]]]
    DFAS = Tuple[DFA, Dict[int, int]]
    Path = Union[str, "os.PathLike[str]"]


# Generated at 2022-06-17 16:39:32.325186
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    from typing import Any, Dict, List, Optional, Text, Tuple, TypeVar, Union

    # Local imports
    from . import token

    _P = TypeVar("_P", bound="Grammar")
    Label = Tuple[int, Optional[Text]]
    DFA = List[List[Tuple[int, int]]]
    DFAS = Tuple[DFA, Dict[int, int]]
    Path = Union[str, "os.PathLike[str]"]


# Generated at 2022-06-17 16:39:50.462026
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'foo': 1}
    g.number2symbol = {1: 'foo'}
    g.states = [[(1, 2)], [(2, 3)]]
    g.dfas = {1: (g.states[0], {1: 1})}
    g.labels = [(1, 'foo'), (2, 'bar')]
    g.keywords = {'foo': 1}
    g.tokens = {1: 1}
    g.symbol2label = {'foo': 1}
    g.start = 1
    g.async_keywords = False
    g.dump('/tmp/foo.pickle')
    g2 = Grammar()
    g2.load('/tmp/foo.pickle')
    assert g

# Generated at 2022-06-17 16:39:58.548848
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import sys
    import io
    from . import pgen2

    class TestGrammarDump(unittest.TestCase):
        def test_dump(self):
            g = pgen2.grammar.Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[[(0, 0)]]]
            g.dfas = {1: ([[(0, 0)]], {0: 0})}
            g.labels = [(0, None)]
            g.keywords = {'foo': 1}
            g.tokens = {1: 1}
            g.symbol2label = {'foo': 1}
            g.start = 256
            g.async_

# Generated at 2022-06-17 16:40:08.058501
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import sys
    import unittest

    # Create a Grammar object
    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[[(1, 1), (2, 2)], [(3, 3), (4, 4)]]]
    g.dfas = {1: ([[(1, 1), (2, 2)], [(3, 3), (4, 4)]], {1: 1, 2: 1}), 2: ([[(1, 1), (2, 2)], [(3, 3), (4, 4)]], {1: 1, 2: 1})}

# Generated at 2022-06-17 16:40:20.414369
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[257][0][0][0][0] == token.NAME
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["and"] == 257
    assert g.tokens[token.NAME] == 258
    assert g.symbol2label["and"] == 257
    assert g.start == 256
    assert g.async_keywords == False


# Generated at 2022-06-17 16:40:29.237909
# Unit test for method load of class Grammar
def test_Grammar_load():
    import os
    import tempfile
    import pickle
    from . import token

    # Create a temporary file
    fd, filename = tempfile.mkstemp()
    os.close(fd)

    # Create a Grammar object
    g = Grammar()
    g.symbol2number = {'foo': 1}
    g.number2symbol = {1: 'foo'}
    g.states = [[[(1, 1)], [(2, 2)]]]
    g.dfas = {1: ([[(1, 1)], [(2, 2)]], {1: 1, 2: 1}), 2: ([[(1, 1)], [(2, 2)]], {1: 1, 2: 1})}
    g.labels = [(1, 'foo'), (2, 'bar')]

# Generated at 2022-06-17 16:40:38.045953
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.start == 256
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.dfas[257][0][0][0] == 258
    assert g.labels[258][1] == "and"
    assert g.keywords["and"] == 258
    assert g.tokens[token.AND] == 258
    assert g.symbol2label["and"] == 258
    assert g.states[0][0][0][0] == 258
    assert g.states[0][0][0][1] == 1
    assert g.states[0][1][0][0]

# Generated at 2022-06-17 16:40:49.575984
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pytest
    from .pgen2 import driver
    from . import token

    # Test the load method of class Grammar
    #
    # Create a grammar object
    g = driver.load_grammar("Grammar/Grammar")
    #
    # Create a temporary file
    with tempfile.NamedTemporaryFile(mode="wb", delete=False) as f:
        #
        # Dump the grammar object to the temporary file
        g.dump(f.name)
        #
        # Load the grammar object from the temporary file
        g2 = Grammar()
        g2.load(f.name)
        #
        # Check that the grammar objects are equal
        assert g.symbol2number == g2.symbol2number
        assert g.number2symbol == g2.number2symbol
       

# Generated at 2022-06-17 16:41:01.227938
# Unit test for method load of class Grammar
def test_Grammar_load():
    """
    Test Grammar.load()
    """
    g = Grammar()
    g.load(__file__.replace(".py", ".pkl"))
    assert g.symbol2number["and"] == 258
    assert g.number2symbol[258] == "and"
    assert g.start == 256
    assert g.symbol2label["and"] == 258
    assert g.keywords["and"] == 258
    assert g.tokens[token.NAME] == 259
    assert g.labels[259] == (token.NAME, None)
    assert g.dfas[258][0][0] == (258, 1)
    assert g.dfas[258][1][0] == (0, 1)
    assert g.dfas[258][1][1] == (259, 2)

# Generated at 2022-06-17 16:41:10.531591
# Unit test for method load of class Grammar
def test_Grammar_load():
    import io
    import pickle

    g = Grammar()
    g.symbol2number = {'foo': 1}
    g.number2symbol = {1: 'foo'}
    g.states = [[[(1, 1)]]]
    g.dfas = {1: ([[(1, 1)]], {1: 1})}
    g.labels = [(1, 'foo')]
    g.keywords = {'foo': 1}
    g.tokens = {1: 1}
    g.symbol2label = {'foo': 1}
    g.start = 256

    f = io.BytesIO()
    pickle.dump(g, f, pickle.HIGHEST_PROTOCOL)
    f.seek(0)
    g2 = Grammar()
    g2

# Generated at 2022-06-17 16:41:21.521613
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import io
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            grammar = pgen2.driver.load_grammar("Grammar.txt")
            with io.BytesIO() as f:
                grammar.dump(f)
                f.seek(0)
                grammar2 = Grammar()
                grammar2.loads(f.read())
            self.assertEqual(grammar.symbol2number, grammar2.symbol2number)
            self.assertEqual(grammar.number2symbol, grammar2.number2symbol)
            self.assertEqual(grammar.states, grammar2.states)
            self.assertEqual(grammar.dfas, grammar2.dfas)

# Generated at 2022-06-17 16:41:27.406929
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = pgen2.grammar.Grammar()
            g.load("Grammar.pickle")

    unittest.main()

# Generated at 2022-06-17 16:41:35.197673
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    from . import token

    class Grammar(object):
        def __init__(self) -> None:
            self.symbol2number: Dict[str, int] = {}
            self.number2symbol: Dict[int, str] = {}
            self.states: List[DFA] = []
            self.dfas: Dict[int, DFAS] = {}
            self.labels: List[Label] = [(0, "EMPTY")]
            self.keywords: Dict[str, int] = {}
            self.tokens: Dict[int, int] = {}
            self.symbol2label: Dict[str, int] = {}
            self.start = 256
            # Python 3.7+ parses async as a keyword, not

# Generated at 2022-06-17 16:41:43.928784
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == 1
    assert g.dfas[257][0][0][0][0] == 1
    assert g.labels[1][0] == token.NAME
    assert g.keywords["and"] == 1
    assert g.tokens[token.NAME] == 1
    assert g.start == 257
    assert g.async_keywords == False

# Generated at 2022-06-17 16:41:54.628786
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import tempfile
    import os
    import io
    import sys
    import unittest

    class GrammarTestCase(unittest.TestCase):
        def setUp(self):
            self.g = Grammar()
            self.g.symbol2number = {'a': 1, 'b': 2}
            self.g.number2symbol = {1: 'a', 2: 'b'}
            self.g.states = [[[(1, 1), (2, 2)], [(3, 3), (4, 4)]]]

# Generated at 2022-06-17 16:41:58.061559
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    g.report()

# Generated at 2022-06-17 16:42:07.257745
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):

        def test_load(self):
            g = Grammar()
            g.symbol2number = {'foo': 1, 'bar': 2}
            g.number2symbol = {1: 'foo', 2: 'bar'}
            g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            g.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 1}),
                      2: ([(5, 6), (7, 8)], {3: 1, 4: 1})}

# Generated at 2022-06-17 16:42:17.314440
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[257][1][token.NAME] == 1
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["False"] == 1
    assert g.tokens[token.NAME] == 1
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:42:27.919350
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen2
    from . import tokenize

    g = pgen2.driver.load_grammar("Grammar.txt")
    g.dump("Grammar.pickle")
    g2 = Grammar()
    g2.load("Grammar.pickle")
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label
    assert g.start == g2.start
   

# Generated at 2022-06-17 16:42:37.130980
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[257][0][0][0][0] == token.NAME
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["and"] == 257
    assert g.tokens[token.NAME] == 1
    assert g.symbol2label["and"] == 257
    assert g.start == 256

# Generated at 2022-06-17 16:42:50.260285
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import os
    import pickle
    import tempfile
    from typing import Any, Dict, List, Optional, Text, Tuple, TypeVar, Union
    from . import token
    _P = TypeVar("_P", bound="Grammar")
    Label = Tuple[int, Optional[Text]]
    DFA = List[List[Tuple[int, int]]]
    DFAS = Tuple[DFA, Dict[int, int]]
    Path = Union[str, "os.PathLike[str]"]


# Generated at 2022-06-17 16:43:05.662761
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import conv
    from . import pgen2

    g = Grammar()
    g.load("Grammar.pickle")
    g2 = Grammar()
    pgen2.driver.load_grammar(g2)
    assert g == g2

    g3 = Grammar()
    conv.convert_grammar(g3)
    assert g == g3

    g4 = Grammar()
    pgen2.driver.load_grammar(g4, "Grammar.txt")
    assert g == g4

    g5 = Grammar()
    pgen2.driver.load_grammar(g5, "Grammar.txt", optimize=False)
    assert g == g5

    g6 = Grammar()

# Generated at 2022-06-17 16:43:15.982664
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[(1, 2)], [(3, 4)]]
            g.dfas = {1: ([(1, 2)], {1: 1}), 2: ([(3, 4)], {3: 1})}
            g.labels = [(1, None), (2, None), (3, None), (4, None)]
            g.keywords = {'a': 1, 'b': 2}

# Generated at 2022-06-17 16:43:27.265924
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    from typing import Any, Dict, List, Optional, Text, Tuple, TypeVar, Union

    # Local imports
    from . import token

    _P = TypeVar("_P", bound="Grammar")
    Label = Tuple[int, Optional[Text]]
    DFA = List[List[Tuple[int, int]]]
    DFAS = Tuple[DFA, Dict[int, int]]
    Path = Union[str, "os.PathLike[str]"]


# Generated at 2022-06-17 16:43:38.176519
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0] == [(1, 1), (2, 2), (3, 3), (4, 4), (5, 5), (6, 6)]
    assert g.dfas[257] == ([[(1, 1), (2, 2), (3, 3), (4, 4), (5, 5), (6, 6)]], {0: 0})
    assert g.labels[1] == (1, None)
    assert g.keywords["and"] == 1
    assert g.tokens[token.NAME]

# Generated at 2022-06-17 16:43:41.873606
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/tmp/test_Grammar_dump.pickle")


# Generated at 2022-06-17 16:43:52.121019
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import pickle
    import unittest

    class GrammarTestCase(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {"foo": 1}
            g.number2symbol = {1: "foo"}
            g.states = [[(1, 2)]]
            g.dfas = {1: ([(1, 2)], {2: 1})}
            g.labels = [(1, "foo")]
            g.keywords = {"foo": 1}
            g.tokens = {1: 1}
            g.symbol2label = {"foo": 1}
            g.start = 1
            g.async_keywords = False

            f = io.BytesIO()
            g.dump(f)


# Generated at 2022-06-17 16:43:59.712089
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    import io
    import os
    import tempfile
    import unittest

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.g = Grammar()
            self.g.symbol2number = {'foo': 1, 'bar': 2}
            self.g.number2symbol = {1: 'foo', 2: 'bar'}
            self.g.states = [[[(0, 1)], [(0, 2)]]]
            self.g.dfas = {1: ([[(0, 1)], [(0, 2)]], {1: 1, 2: 1}),
                           2: ([[(0, 1)], [(0, 2)]], {1: 1, 2: 1})}

# Generated at 2022-06-17 16:44:06.356549
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import io
    import unittest
    from unittest.mock import patch

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.grammar = Grammar()
            self.grammar.symbol2number = {'a': 1, 'b': 2}
            self.grammar.number2symbol = {1: 'a', 2: 'b'}
            self.grammar.states = [[(1, 2), (2, 3)], [(3, 4), (4, 5)]]
            self.grammar.dfas = {1: ([(1, 2), (2, 3)], {1: 1, 2: 1}),
                                 2: ([(3, 4), (4, 5)], {3: 1, 4: 1})}


# Generated at 2022-06-17 16:44:17.578061
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import sys
    import unittest
    from . import pgen2

    class Grammar_dump_TestCase(unittest.TestCase):
        def test_dump(self):
            # Test dumping the grammar tables to a pickle file.
            #
            # This test is not very thorough, but it does exercise
            # the code.
            g = pgen2.driver.load_grammar(sys.version_info)
            g.dump("Grammar.pickle")
            g2 = Grammar()
            g2.load("Grammar.pickle")
            self.assertEqual(g.start, g2.start)
            self.assertEqual(g.symbol2number, g2.symbol2number)

# Generated at 2022-06-17 16:44:28.802951
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[(1, 2)], [(3, 4)]]
            g.dfas = {1: ([(1, 2)], {1: 1}), 2: ([(3, 4)], {1: 1})}
            g.labels = [(1, 'a'), (2, 'b')]
            g.keywords = {'a': 1, 'b': 2}
            g.tokens = {1: 1, 2: 2}


# Generated at 2022-06-17 16:44:42.440923
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import os
    import tempfile
    from . import token

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'foo': 1, 'bar': 2}
            g.number2symbol = {1: 'foo', 2: 'bar'}
            g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            g.dfas = {1: (g.states[0], {1: 1, 2: 1}), 2: (g.states[1], {3: 1, 4: 1})}
            g.labels = [(token.NAME, 'foo'), (token.NAME, 'bar')]
            g

# Generated at 2022-06-17 16:44:54.797717
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'foo': 1, 'bar': 2}
            g.number2symbol = {1: 'foo', 2: 'bar'}
            g.states = [[(1, 1), (2, 2)], [(3, 3), (4, 4)]]
            g.dfas = {1: ([(1, 1), (2, 2)], {1: 1, 2: 2}), 2: ([(3, 3), (4, 4)], {3: 3, 4: 4})}

# Generated at 2022-06-17 16:45:05.535296
# Unit test for method load of class Grammar
def test_Grammar_load():
    import os
    import pickle
    import tempfile
    from typing import Any, Dict, List, Optional, Text, Tuple, TypeVar, Union

    # Local imports
    from . import token

    _P = TypeVar("_P", bound="Grammar")
    Label = Tuple[int, Optional[Text]]
    DFA = List[List[Tuple[int, int]]]
    DFAS = Tuple[DFA, Dict[int, int]]
    Path = Union[str, "os.PathLike[str]"]


# Generated at 2022-06-17 16:45:16.494215
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {"a": 1, "b": 2}
            g.number2symbol = {1: "a", 2: "b"}
            g.states = [[(1, 2)], [(3, 4)]]
            g.dfas = {1: ([(1, 2)], {1: 1}), 2: ([(3, 4)], {1: 1})}
            g.labels = [(1, "a"), (2, "b")]
            g.keywords = {"a": 1, "b": 2}
            g.tokens = {1: 1, 2: 2}

# Generated at 2022-06-17 16:45:18.830808
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/tmp/test_Grammar_dump")
    g.load("/tmp/test_Grammar_dump")

# Generated at 2022-06-17 16:45:28.108082
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    from typing import Any, Dict, List, Optional, Text, Tuple, TypeVar, Union

    # Local imports
    from . import token

    _P = TypeVar("_P", bound="Grammar")
    Label = Tuple[int, Optional[Text]]
    DFA = List[List[Tuple[int, int]]]
    DFAS = Tuple[DFA, Dict[int, int]]
    Path = Union[str, "os.PathLike[str]"]


# Generated at 2022-06-17 16:45:35.065366
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import io
    import sys
    import os
    import tempfile
    import contextlib

    class GrammarTestCase(unittest.TestCase):
        def setUp(self):
            self.g = Grammar()
            self.g.symbol2number = {'foo': 1, 'bar': 2}
            self.g.number2symbol = {1: 'foo', 2: 'bar'}
            self.g.states = [
                [
                    [(1, 2), (3, 4)],
                    [(5, 6), (7, 8)],
                ],
                [
                    [(9, 10), (11, 12)],
                    [(13, 14), (15, 16)],
                ],
            ]

# Generated at 2022-06-17 16:45:41.901197
# Unit test for method load of class Grammar
def test_Grammar_load():
    import io
    import pickle
    import unittest

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            # Test that Grammar.load() loads pickle data
            # correctly.
            g = Grammar()
            g.symbol2number = {'foo': 1, 'bar': 2}
            g.number2symbol = {1: 'foo', 2: 'bar'}
            g.states = [[(1, 2)], [(3, 4)]]
            g.dfas = {1: ([(1, 2)], {1: 1}), 2: ([(3, 4)], {3: 1})}
            g.labels = [(1, 'foo'), (2, 'bar'), (3, 'baz'), (4, 'quux')]
            g

# Generated at 2022-06-17 16:45:52.502972
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen2
    from . import tokenize

    g = pgen2.driver.load_grammar("Grammar.txt")
    g.dump("Grammar.pickle")
    g2 = Grammar()
    g2.load("Grammar.pickle")
    assert g2.start == g.start
    assert g2.symbol2number == g.symbol2number
    assert g2.number2symbol == g.number2symbol
    assert g2.keywords == g.keywords
    assert g2.tokens == g.tokens
    assert g2.symbol2label == g.symbol2label
    assert g2.labels == g.labels
    assert g2.states == g.states
    assert g2.dfas == g.dfas
   

# Generated at 2022-06-17 16:46:03.759993
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import os
    import pickle
    import tempfile
    from . import token

    class GrammarTestCase(unittest.TestCase):
        def setUp(self):
            self.g = Grammar()
            self.g.symbol2number = {'a': 1, 'b': 2}
            self.g.number2symbol = {1: 'a', 2: 'b'}
            self.g.states = [[[(1, 1), (2, 2)], [(3, 3), (4, 4)]]]

# Generated at 2022-06-17 16:46:23.922641
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")
    assert g.symbol2number == {'expr': 258, 'xor_expr': 259, 'and_expr': 260, 'shift_expr': 261, 'arith_expr': 262, 'term': 263, 'factor': 264, 'power': 265, 'atom': 266}
    assert g.number2symbol == {258: 'expr', 259: 'xor_expr', 260: 'and_expr', 261: 'shift_expr', 262: 'arith_expr', 263: 'term', 264: 'factor', 265: 'power', 266: 'atom'}

# Generated at 2022-06-17 16:46:35.596106
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):

        def test_load(self):
            g = Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[(1, 2)], [(2, 3)]]
            g.dfas = {1: ([(1, 2)], {2: 3}), 2: ([(2, 3)], {3: 4})}
            g.labels = [(1, 'foo'), (2, 'bar')]
            g.keywords = {'foo': 1, 'bar': 2}
            g.tokens = {1: 1, 2: 2}

# Generated at 2022-06-17 16:46:49.861115
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    from . import pgen2
    from . import tokenize

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            # Test that the grammar can be loaded from a pickle file
            # and that it produces the same results as the original
            # grammar.
            g = pgen2.driver.load_grammar("Grammar.txt")
            g.dump("Grammar.pickle")
            g2 = Grammar()
            g2.load("Grammar.pickle")
            self.assertEqual(g.symbol2number, g2.symbol2number)
            self.assertEqual(g.number2symbol, g2.number2symbol)
            self.assertEqual(g.states, g2.states)
            self

# Generated at 2022-06-17 16:47:00.983094
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import os
    import tempfile

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.grammar = Grammar()
            self.grammar.symbol2number = {'foo': 1, 'bar': 2}
            self.grammar.number2symbol = {1: 'foo', 2: 'bar'}
            self.grammar.states = [[(1, 2)], [(2, 3)]]
            self.grammar.dfas = {1: ([(1, 2)], {1: 1}), 2: ([(2, 3)], {2: 1})}
            self.grammar.labels = [(1, 'foo'), (2, 'bar')]

# Generated at 2022-06-17 16:47:04.800029
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))

# Generated at 2022-06-17 16:47:12.562686
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2
    from . import pgen2_grammar

    g = pgen2.load_grammar(pgen2_grammar.__file__)
    g.dump("/tmp/test_Grammar_load.pickle")
    g2 = Grammar()
    g2.load("/tmp/test_Grammar_load.pickle")
    assert g.start == g2.start
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.dfas == g2.dfas
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label

# Generated at 2022-06-17 16:47:23.486614
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io
    import os
    import sys
    import tempfile
    from . import pgen2
    from . import token


# Generated at 2022-06-17 16:47:28.799320
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen2
    from . import tokenize
    import io
    import os
    import sys
    import unittest

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.test_dir = os.path.dirname(__file__)
            self.test_file = os.path.join(self.test_dir, "Grammar.py")
            self.test_file_pkl = os.path.join(self.test_dir, "Grammar.py.pkl")
            self.test_file_pkl_bak = os.path.join(self.test_dir, "Grammar.py.pkl.bak")

# Generated at 2022-06-17 16:47:35.690536
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[258] == "as"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[258][0][0][0][0] == token.NAME
    assert g.labels[1] == (token.NAME, None)
    assert g.keywords["False"] == 2
    assert g.tokens[token.NAME] == 1
    assert g.symbol2label["comp_op"] == 258
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:47:43.409767
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            g.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 1}), 2: ([(5, 6), (7, 8)], {5: 1, 6: 1})}