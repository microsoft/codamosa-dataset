

# Generated at 2022-06-17 16:38:21.772839
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import os
    import pickle
    from . import token
    from . import pgen2

    class TestGrammarDump(unittest.TestCase):
        def setUp(self):
            self.g = pgen2.grammar.Grammar()
            self.g.symbol2number = {'foo': 256, 'bar': 257}
            self.g.number2symbol = {256: 'foo', 257: 'bar'}
            self.g.states = [[[(1, 2), (3, 4)], [(5, 6), (7, 8)]]]
            self.g.dfas = {256: ([[(1, 2), (3, 4)], [(5, 6), (7, 8)]], {1: 1})}

# Generated at 2022-06-17 16:38:23.972133
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/tmp/test_Grammar_dump")
    g.load("/tmp/test_Grammar_dump")

# Generated at 2022-06-17 16:38:35.879967
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    from io import BytesIO

    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
    g.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 1}), 2: ([(5, 6), (7, 8)], {3: 1, 4: 1})}
    g.labels = [(0, 'EMPTY'), (1, None), (2, None), (3, None), (4, None), (5, None), (6, None), (7, None), (8, None)]

# Generated at 2022-06-17 16:38:49.679216
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import io
    import os
    import sys

    class Grammar_dump_TestCase(unittest.TestCase):
        def test_dump(self):
            # Create a Grammar instance
            grammar = Grammar()
            # Create a file-like object to hold the pickle
            f = io.BytesIO()
            # Call the method to test
            grammar.dump(f)
            # Check the pickle
            f.seek(0)
            unpickler = pickle.Unpickler(f)
            if sys.version_info[0] >= 3:
                unpickler.encoding = "bytes"
            d = unpickler.load()
            self.assertEqual(d, grammar.__dict__)

    unittest.main()


# Generated at 2022-06-17 16:39:01.844962
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import io
    from . import pgen2
    from . import token

    g = pgen2.driver.load_grammar("Grammar/Grammar")
    f = io.BytesIO()
    g.dump(f)
    f.seek(0)
    g2 = Grammar()
    g2.loads(f.read())
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g

# Generated at 2022-06-17 16:39:08.257328
# Unit test for method load of class Grammar

# Generated at 2022-06-17 16:39:20.059502
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import tempfile
    import pickle
    from . import token

    # Create a temporary file
    fd, filename = tempfile.mkstemp()
    os.close(fd)

    # Create a Grammar object
    g = Grammar()
    g.symbol2number = {'foo': 256, 'bar': 257}
    g.number2symbol = {256: 'foo', 257: 'bar'}
    g.states = [
        [
            [(257, 1), (0, 2)],
            [(0, 2)],
            [],
        ],
        [
            [(257, 3), (0, 4)],
            [(0, 4)],
            [],
        ],
    ]

# Generated at 2022-06-17 16:39:28.366578
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[[(1, 2)], [(2, 3)]]]
            g.dfas = {1: ([[(1, 2)], [(2, 3)]], {1: 1}), 2: ([[(1, 2)], [(2, 3)]], {1: 1})}
            g.labels = [(1, 'foo'), (2, 'bar')]
            g.keywords = {'foo': 1, 'bar': 2}

# Generated at 2022-06-17 16:39:35.300292
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    from io import BytesIO
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = pgen2.driver.load_grammar("Grammar.txt")
            g.dump("Grammar.pickle")
            with open("Grammar.pickle", "rb") as f:
                pkl = f.read()
            g2 = Grammar()
            g2.loads(pkl)
            self.assertEqual(g.symbol2number, g2.symbol2number)
            self.assertEqual(g.number2symbol, g2.number2symbol)
            self.assertEqual(g.states, g2.states)
            self.assertEqual

# Generated at 2022-06-17 16:39:43.702971
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2
    from . import tokenize

    g = Grammar()
    g.load(pgen2.grammar_file)
    assert g.start == g.symbol2number["file_input"]
    assert g.start == g.symbol2number["eval_input"]
    assert g.start == g.symbol2number["single_input"]
    assert g.start == g.symbol2number["decorator"]
    assert g.start == g.symbol2number["decorators"]
    assert g.start == g.symbol2number["decorated"]
    assert g.start == g.symbol2number["async_funcdef"]
    assert g.start == g.symbol2number["funcdef"]
    assert g.start == g.symbol2number["parameters"]


# Generated at 2022-06-17 16:39:55.013151
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import driver
    from . import token

    g = Grammar()
    g.load(driver.grammar)
    assert g.symbol2number["file_input"] == 256
    assert g.number2symbol[256] == "file_input"
    assert g.symbol2number["funcdef"] == 261
    assert g.number2symbol[261] == "funcdef"
    assert g.symbol2number["parameters"] == 262
    assert g.number2symbol[262] == "parameters"
    assert g.symbol2number["typedargslist"] == 263
    assert g.number2symbol[263] == "typedargslist"
    assert g.symbol2number["tfpdef"] == 264

# Generated at 2022-06-17 16:40:06.130123
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import os
    import tempfile
    from . import token

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.g = Grammar()
            self.g.symbol2number = {'foo': 256, 'bar': 257}
            self.g.number2symbol = {256: 'foo', 257: 'bar'}
            self.g.states = [[[(0, 1)], [(0, 2)]]]
            self.g.dfas = {256: ([[(0, 1)], [(0, 2)]], {1: 1, 2: 1}), 257: ([[(0, 1)], [(0, 2)]], {1: 1, 2: 1})}

# Generated at 2022-06-17 16:40:18.610237
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import conv
    from . import pgen2

    g = Grammar()
    g.load("Grammar.txt")

    g2 = Grammar()
    g2.loads(g.dumps())

    g3 = Grammar()
    g3.loads(g2.dumps())

    g4 = Grammar()
    g4.loads(g3.dumps())

    g5 = Grammar()
    g5.loads(g4.dumps())

    g6 = Grammar()
    g6.loads(g5.dumps())

    g7 = Grammar()
    g7.loads(g6.dumps())

    g8 = Grammar()
    g8.loads(g7.dumps())

    g9 = Grammar()
    g9.loads(g8.dumps())

# Generated at 2022-06-17 16:40:26.470456
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    from . import token

    # mypyc generates objects that don't have a __dict__, but they
    # do have __getstate__ methods that will return an equivalent
    # dictionary
    if hasattr(token, "__dict__"):
        d = token.__dict__
    else:
        d = token.__getstate__()  # type: ignore

    with tempfile.NamedTemporaryFile(delete=False) as f:
        pickle.dump(d, f, pickle.HIGHEST_PROTOCOL)
    os.remove(f.name)

# Generated at 2022-06-17 16:40:35.377156
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 256
    assert g.number2symbol[256] == "and"
    assert g.states[0][0][0][0] == 1
    assert g.dfas[257][0][0][0][0] == 1
    assert g.labels[1][0] == 1
    assert g.keywords["and"] == 1
    assert g.tokens[1] == 1
    assert g.symbol2label["and"] == 1
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:40:43.531442
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test that Grammar.load() works
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[257][0][0][0][0] == token.NAME
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["and"] == 257
    assert g.tokens[token.NAME] == 1
    assert g.symbol2label["and"] == 257
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:40:51.779109
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import shutil
    import tempfile
    import unittest

    from . import pgen2

    class GrammarDumpTests(unittest.TestCase):
        def setUp(self):
            self.dir = tempfile.mkdtemp()
            self.filename = os.path.join(self.dir, "Grammar.pickle")

        def tearDown(self):
            shutil.rmtree(self.dir)

        def test_dump(self):
            g = pgen2.driver.load_grammar("Grammar.txt")
            g.dump(self.filename)
            g2 = Grammar()
            g2.load(self.filename)
            self.assertEqual(g.symbol2number, g2.symbol2number)
            self.assertEqual

# Generated at 2022-06-17 16:41:02.706015
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[(1, 2), (3, 4)]]
            g.dfas = {1: ([[(1, 2), (3, 4)]], {1: 2})}
            g.labels = [(1, 'foo'), (2, 'bar')]
            g.keywords = {'foo': 1}
            g.tokens = {1: 2}
            g.symbol2label = {'foo': 1}
            g.start = 1
            g.async_keywords = True



# Generated at 2022-06-17 16:41:10.702650
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == 1
    assert g.dfas[257][0][0][0][0] == 1
    assert g.labels[1] == (1, None)
    assert g.keywords["and"] == 1
    assert g.tokens[token.NAME] == 1
    assert g.start == 257
    assert g.async_keywords == False

# Generated at 2022-06-17 16:41:17.838350
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/tmp/test_Grammar_dump.pkl")
    g2 = Grammar()
    g2.load("/tmp/test_Grammar_dump.pkl")
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label
    assert g.start == g2.start
    assert g.async_keywords == g2.async_

# Generated at 2022-06-17 16:41:33.778936
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pkl"))
    assert g.symbol2number["and_expr"] == 258
    assert g.number2symbol[258] == "and_expr"
    assert g.states[0][0][0][0] == 0
    assert g.states[0][0][0][1] == 1
    assert g.dfas[258][0][0][0][0] == 0
    assert g.dfas[258][0][0][0][1] == 1
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["False"] == 1
    assert g.tokens[token.NAME] == 2
    assert g.symbol2label["and_expr"] == 258

# Generated at 2022-06-17 16:41:44.040666
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io
    import sys

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            # Test that Grammar.load() works
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            g.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 1}),
                      2: ([(5, 6), (7, 8)], {3: 1, 4: 1})}

# Generated at 2022-06-17 16:41:54.696896
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    import unittest

    class GrammarTest(unittest.TestCase):
        def setUp(self):
            self.g = Grammar()
            self.g.symbol2number = {'a': 1, 'b': 2}
            self.g.number2symbol = {1: 'a', 2: 'b'}
            self.g.states = [[[(1, 1), (2, 2)], [(3, 3)]]]
            self.g.dfas = {1: ([[(1, 1), (2, 2)], [(3, 3)]], {1: 1, 2: 1}),
                           2: ([[(4, 4), (5, 5)], [(6, 6)]], {4: 1, 5: 1})}


# Generated at 2022-06-17 16:41:57.345223
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/tmp/test_Grammar_dump")


# Generated at 2022-06-17 16:42:05.380653
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pickle"))
    assert g.symbol2number["stmt"] == 258
    assert g.number2symbol[258] == "stmt"
    assert g.states[0][0][0][0] == 0
    assert g.dfas[258][1][token.NAME] == 1
    assert g.labels[0][1] == "EMPTY"
    assert g.keywords["if"] == 1
    assert g.tokens[token.NAME] == 1
    assert g.symbol2label["stmt"] == 258
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:42:08.863844
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import unittest
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = pgen2.grammar.Grammar()
            g.dump(sys.stdout)

    unittest.main()

# Generated at 2022-06-17 16:42:21.009994
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[258] == "as"
    assert g.states[0][0] == [(0, 1), (257, 2)]
    assert g.dfas[258][0][0] == [(0, 1), (258, 2)]
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["and"] == 257
    assert g.tokens[token.NAME] == 1
    assert g.symbol2label["and"] == 257
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:42:30.241146
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import os
    import pickle
    import tempfile
    from . import token
    from . import grammar
    from . import parse
    from . import pgen2

    # Create a temporary file
    fd, filename = tempfile.mkstemp()
    os.close(fd)

    # Create a grammar object
    g = grammar.Grammar()

    # Create a parser object
    p = parse.Parser(g, parse.DefaultWhitespace)

    # Create a pgen2 object
    p2 = pgen2.pgen2(filename)

    # Write the grammar tables to a pickle file
    p2.write_grammar(g)

    # Load the grammar tables from the pickle file
    g2 = grammar.Grammar()
    g2.load(filename)

    # Remove the temporary

# Generated at 2022-06-17 16:42:33.503383
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.pickle")
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:42:38.581438
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("test_Grammar_dump.pkl")
    grammar.load("test_Grammar_dump.pkl")
    grammar.report()
    os.remove("test_Grammar_dump.pkl")

# Generated at 2022-06-17 16:42:48.144456
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    from . import pgen2

    class GrammarTest(unittest.TestCase):
        def test_load(self):
            g = pgen2.Grammar()
            g.load("Grammar.pickle")

    unittest.main()

# Generated at 2022-06-17 16:42:50.409749
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    g.report()

# Generated at 2022-06-17 16:42:59.960720
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import shutil
    import tempfile
    import os
    from . import pgen2

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a grammar object
    grammar = pgen2.driver.load_grammar(os.path.join(temp_dir, "Grammar.txt"))

    # Dump the grammar object
    grammar.dump(os.path.join(temp_dir, "Grammar.pickle"))

    # Remove the temporary directory
    shutil.rmtree(temp_dir)

# Generated at 2022-06-17 16:43:10.040263
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io
    import sys

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            # Test Grammar.load
            g = Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[[(1, 2)], [(2, 3)], [(3, 4)]]]
            g.dfas = {1: ([[(1, 2)], [(2, 3)], [(3, 4)]], {1: 1})}
            g.labels = [(1, 'foo'), (2, 'bar'), (3, 'baz')]
            g.keywords = {'foo': 1, 'bar': 2}
            g

# Generated at 2022-06-17 16:43:15.880016
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == 1
    assert g.dfas[257][0][0][0][0] == 1
    assert g.labels[1] == (1, None)
    assert g.keywords["and"] == 1
    assert g.tokens[token.NAME] == 1
    assert g.start == 257

# Generated at 2022-06-17 16:43:27.208222
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    from . import token

    # Create a temporary directory
    temp_dir = tempfile.TemporaryDirectory()

    # Create a temporary file
    temp_file = os.path.join(temp_dir.name, "temp_file")

    # Create a Grammar object
    g = Grammar()

    # Dump the grammar tables to a pickle file
    g.dump(temp_file)

    # Load the grammar tables from a pickle file
    g.load(temp_file)

    # Remove the temporary directory
    temp_dir.cleanup()

    # Test the instance variables
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}

# Generated at 2022-06-17 16:43:37.498417
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            # Create a temporary file
            with tempfile.NamedTemporaryFile(delete=False) as f:
                filename = f.name
            # Create a grammar object
            g = pgen2.driver.load_grammar("Grammar.txt")
            # Dump the grammar object to the temporary file
            g.dump(filename)
            # Load the grammar object from the temporary file
            g2 = pgen2.driver.load_grammar(filename)
            # Check that the two grammar objects are equal
            self.assertEqual(g, g2)

    unittest.main()

# Generated at 2022-06-17 16:43:50.412897
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == 1
    assert g.dfas[257][0][0][0][0] == 1
    assert g.labels[1] == (token.NAME, None)
    assert g.keywords["and"] == 1
    assert g.tokens[token.NAME] == 1
    assert g.start == 257
    assert g.async_keywords == False

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:43:58.717405
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    import io
    g = Grammar()
    g.symbol2number = {'a': 1, 'b': 2}
    g.number2symbol = {1: 'a', 2: 'b'}
    g.states = [
        [
            [(0, 1), (1, 2)],
            [(0, 3)],
            [(0, 4)],
            [(0, 5)],
            [(0, 6)],
            [(0, 7)],
            [(0, 8)],
        ]
    ]

# Generated at 2022-06-17 16:44:05.712930
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import pickle
    import unittest

    class GrammarTest(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[[(1, 1)]]]
            g.dfas = {1: ([[(1, 1)]], {1: 1})}
            g.labels = [(1, 'foo')]
            g.keywords = {'foo': 1}
            g.tokens = {1: 1}
            g.symbol2label = {'foo': 1}
            g.start = 1
            g.async_keywords = False

            f = io.BytesIO()
            g

# Generated at 2022-06-17 16:44:23.471684
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.load(pgen2.__file__.replace(".pyc", ".pkl"))
            self.assertEqual(g.symbol2number["and"], 257)
            self.assertEqual(g.number2symbol[257], "and")
            self.assertEqual(g.states[0][0][0][0], token.NAME)
            self.assertEqual(g.dfas[257][0][0][0][0], token.NAME)
            self.assertEqual(g.labels[0], (0, "EMPTY"))
            self.assertEqual(g.keywords["False"], 1)
           

# Generated at 2022-06-17 16:44:34.487153
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    import io
    import os
    import sys
    import tempfile
    import unittest

    from . import pgen2

    class GrammarTestCase(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.tempfile = os.path.join(self.tempdir, "grammar.pickle")
            self.grammar = pgen2.driver.load_grammar(self.tempfile)

        def tearDown(self):
            import shutil

            shutil.rmtree(self.tempdir)


# Generated at 2022-06-17 16:44:38.453853
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import unittest
    from . import pgen2

    class TestGrammarLoad(unittest.TestCase):
        def test_load(self):
            g = pgen2.grammar.Grammar()
            g.load(sys.executable)

    unittest.main()

# Generated at 2022-06-17 16:44:44.686275
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {"a": 1, "b": 2}
            g.number2symbol = {1: "a", 2: "b"}
            g.states = [[[(1, 1), (2, 2)], [(3, 3), (4, 4)]]]
            g.dfas = {1: ([[(1, 1), (2, 2)], [(3, 3), (4, 4)]], {1: 1, 2: 1}), 2: ([[(5, 5), (6, 6)], [(7, 7), (8, 8)]], {5: 1, 6: 1})}

# Generated at 2022-06-17 16:44:54.868349
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == 1
    assert g.dfas[257][0][0][0][0] == 1
    assert g.labels[1][0] == 1
    assert g.labels[1][1] == "and"
    assert g.keywords["and"] == 1
    assert g.tokens[1] == 1
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:45:04.504767
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == 1
    assert g.dfas[257][0][0][0][0] == 1
    assert g.labels[1] == (1, None)
    assert g.keywords["and"] == 1
    assert g.tokens[1] == 1
    assert g.start == 257
    assert g.async_keywords == False

# Generated at 2022-06-17 16:45:08.022489
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:45:16.539063
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert grammar.symbol2number["and"] == 257
    assert grammar.number2symbol[257] == "and"
    assert grammar.states[0][0][1] == 1
    assert grammar.dfas[257][0][0][1] == 1
    assert grammar.labels[0] == (0, "EMPTY")
    assert grammar.keywords["and"] == 1
    assert grammar.tokens[token.NAME] == 2
    assert grammar.start == 256
    assert grammar.async_keywords == False

# Generated at 2022-06-17 16:45:24.415780
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import io
    import unittest
    from unittest import mock

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.grammar = Grammar()
            self.grammar.symbol2number = {'foo': 1, 'bar': 2}
            self.grammar.number2symbol = {1: 'foo', 2: 'bar'}
            self.grammar.states = [[(1, 2), (2, 3)], [(3, 4), (4, 5)]]
            self.grammar.dfas = {1: ([(1, 2), (2, 3)], {1: 1, 2: 1}), 2: ([(3, 4), (4, 5)], {3: 1, 4: 1})}

# Generated at 2022-06-17 16:45:29.587329
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.load(pgen2.__file__.replace(".pyc", ".pkl"))

    unittest.main("idlelib.pgen2.test_Grammar", verbosity=2, exit=False)

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:45:57.493305
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import io
    import unittest
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.grammar = pgen2.driver.load_grammar(
                "Grammar.txt", "Grammar.pickle"
            )

        def test_load(self):
            self.assertEqual(self.grammar.symbol2number["single_input"], 256)
            self.assertEqual(self.grammar.number2symbol[256], "single_input")
            self.assertEqual(self.grammar.symbol2number["file_input"], 257)
            self.assertEqual(self.grammar.number2symbol[257], "file_input")

# Generated at 2022-06-17 16:46:08.977830
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pytest
    import os
    import sys
    import tempfile
    from . import pgen2
    from . import tokenize

    # Create a grammar
    g = pgen2.driver.load_grammar(tokenize.__file__)

    # Dump the grammar
    with tempfile.NamedTemporaryFile(delete=False) as f:
        g.dump(f.name)

    # Load the grammar
    g2 = Grammar()
    g2.load(f.name)

    # Check that the two grammars are the same
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels

# Generated at 2022-06-17 16:46:10.806937
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pkl"))
    g.report()

# Generated at 2022-06-17 16:46:22.669832
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[258] == "as"
    assert g.states[0][0][0][0] == 1
    assert g.dfas[258][0][0][0][0] == 1
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["False"] == 1
    assert g.tokens[token.NAME] == 1
    assert g.start == 256
    assert g.async_keywords == False


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:46:24.710685
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/tmp/foo.pkl")
    g.load("/tmp/foo.pkl")
    g.report()

# Generated at 2022-06-17 16:46:27.067219
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.pickle")
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:46:38.860910
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import tempfile
    import os
    import pickle
    import shutil
    import sys
    import io

    class GrammarTestCase(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.tempfile = os.path.join(self.tempdir, "test_Grammar_dump.pkl")
            self.g = Grammar()
            self.g.symbol2number = {'foo': 1, 'bar': 2}
            self.g.number2symbol = {1: 'foo', 2: 'bar'}
            self.g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]

# Generated at 2022-06-17 16:46:41.254832
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pkl"))
    g.report()

# Generated at 2022-06-17 16:46:51.921480
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import sys
    import io
    import pickle
    import os
    import tempfile

    class Grammar_dump_TestCase(unittest.TestCase):
        def test_dump(self):
            # Test that Grammar.dump() writes a pickle file
            # that can be read by Grammar.load()
            g = Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[[(1, 1)]]]
            g.dfas = {1: ([[(1, 1)]], {1: 1})}
            g.labels = [(1, 'foo')]
            g.keywords = {'foo': 1}
            g.tokens = {1: 1}

# Generated at 2022-06-17 16:46:56.875045
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.dump("test_dump.pkl")

    unittest.main()

# Generated at 2022-06-17 16:47:29.661950
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[[(1, 2)], [(2, 3)]]]
            g.dfas = {1: ([[(1, 2)], [(2, 3)]], {1: 1})}
            g.labels = [(1, 'foo'), (2, 'bar')]
            g.keywords = {'foo': 1}
            g.tokens = {1: 1}
            g.symbol2label = {'foo': 1}
            g.start = 256


# Generated at 2022-06-17 16:47:36.346992
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {"a": 1, "b": 2}
            g.number2symbol = {1: "a", 2: "b"}
            g.states = [[(1, 2), (2, 3)], [(3, 4)]]
            g.dfas = {1: (g.states[0], {1: 1, 2: 1}), 2: (g.states[1], {3: 1})}
            g.labels = [(1, "a"), (2, "b"), (3, None)]
            g.keywords = {"a": 1, "b": 2}

# Generated at 2022-06-17 16:47:49.727272
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            g.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 2}), 2: ([(5, 6), (7, 8)], {3: 3, 4: 4})}

# Generated at 2022-06-17 16:47:55.829328
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/tmp/test_Grammar_dump.pkl")
    g2 = Grammar()
    g2.load("/tmp/test_Grammar_dump.pkl")
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label
    assert g.start == g2.start
    assert g.async_keywords == g2.async_

# Generated at 2022-06-17 16:47:58.640614
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import unittest
    from . import pgen2

    class GrammarTestCase(unittest.TestCase):
        def test_load(self):
            g = pgen2.Grammar()
            g.load(sys.executable)

    unittest.main()

# Generated at 2022-06-17 16:48:04.983623
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    import unittest
    from typing import Any, Dict, List, Optional, Text, Tuple, TypeVar, Union

    # Local imports
    from . import token

    _P = TypeVar("_P", bound="Grammar")
    Label = Tuple[int, Optional[Text]]
    DFA = List[List[Tuple[int, int]]]
    DFAS = Tuple[DFA, Dict[int, int]]
    Path = Union[str, "os.PathLike[str]"]


# Generated at 2022-06-17 16:48:14.279003
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    import unittest

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            g.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 2}), 2: ([(5, 6), (7, 8)], {3: 3, 4: 4})}
            g.labels = [(1, 'a'), (2, 'b')]
            g