

# Generated at 2022-06-17 16:38:05.423810
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("test.pkl")
    g.load("test.pkl")
    g.report()

# Generated at 2022-06-17 16:38:15.427519
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import pickle
    import unittest

    class GrammarTestCase(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'foo': 1, 'bar': 2}
            g.number2symbol = {1: 'foo', 2: 'bar'}
            g.states = [[(1, 2)], [(3, 4)]]
            g.dfas = {1: ([(1, 2)], {1: 1}), 2: ([(3, 4)], {3: 1})}
            g.labels = [(1, 'foo'), (2, 'bar'), (3, 'baz')]
            g.keywords = {'foo': 1, 'bar': 2}

# Generated at 2022-06-17 16:38:25.045618
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import unittest
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = pgen2.grammar.Grammar()
            g.symbol2number = {"a": 1, "b": 2}
            g.number2symbol = {1: "a", 2: "b"}
            g.states = [[[(1, 2)], [(2, 3)]]]
            g.dfas = {1: ([[(1, 2)], [(2, 3)]], {1: 1, 2: 1}), 2: ([[(1, 2)], [(2, 3)]], {1: 1, 2: 1})}
            g.labels = [(1, "a"), (2, "b")]
            g

# Generated at 2022-06-17 16:38:37.035082
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'foo': 1}
    g.number2symbol = {1: 'foo'}
    g.states = [[(1, 2)], [(1, 3)]]
    g.dfas = {1: ([(1, 2)], {1: 1}), 2: ([(1, 3)], {1: 1})}
    g.labels = [(1, 'foo')]
    g.keywords = {'foo': 1}
    g.tokens = {1: 1}
    g.symbol2label = {'foo': 1}
    g.start = 1
    g.async_keywords = False
    g.dump('/tmp/foo')
    g2 = Grammar()
    g2.load('/tmp/foo')


# Generated at 2022-06-17 16:38:41.883487
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pkl"))
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:38:51.555426
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    from . import pgen2
    from . import tokenize

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            # Test that Grammar.load() works
            g = pgen2.driver.load_grammar("Grammar/Grammar")
            self.assertTrue(g)
            self.assertTrue(g.symbol2number)
            self.assertTrue(g.number2symbol)
            self.assertTrue(g.states)
            self.assertTrue(g.dfas)
            self.assertTrue(g.labels)
            self.assertTrue(g.keywords)
            self.assertTrue(g.tokens)
            self.assertTrue(g.symbol2label)

# Generated at 2022-06-17 16:38:55.645315
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import unittest

    class GrammarTestCase(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.load(sys.executable)

    unittest.main()

# Generated at 2022-06-17 16:39:06.791706
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert grammar.symbol2number["and_expr"] == 258
    assert grammar.number2symbol[258] == "and_expr"
    assert grammar.states[0][0][0][0] == 0
    assert grammar.states[0][0][0][1] == 1
    assert grammar.dfas[258][0][0][0][0] == 0
    assert grammar.dfas[258][0][0][0][1] == 1
    assert grammar.labels[0][0] == 0
    assert grammar.labels[0][1] == "EMPTY"
    assert grammar.keywords["async"] == 1

# Generated at 2022-06-17 16:39:18.696371
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [1, 2, 3]
            g.dfas = {1: (1, 2), 2: (3, 4)}
            g.labels = [(1, 'foo'), (2, 'bar')]
            g.keywords = {'foo': 1, 'bar': 2}
            g.tokens = {1: 1, 2: 2}
            g.symbol2label = {'foo': 1, 'bar': 2}
            g.start = 1

# Generated at 2022-06-17 16:39:28.020665
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io
    import os
    import sys
    import tempfile
    import tokenize
    import token
    import ast
    import inspect
    import textwrap
    import importlib
    import importlib.util
    import importlib.machinery

    # Test the load method of class Grammar
    class Test_Grammar_load(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None
            self.test_dir = tempfile.TemporaryDirectory()
            self.test_file = os.path.join(self.test_dir.name, "test.pkl")

# Generated at 2022-06-17 16:39:38.502633
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[257][0][0][0][0] == token.NAME
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["and"] == 257
    assert g.tokens[token.NAME] == 258
    assert g.symbol2label["and"] == 257
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:39:47.076338
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    import sys
    import unittest

    class Grammar_load_TestCase(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.load(sys.executable)
            self.assertRaises(pickle.UnpicklingError, g.loads, b"")

    unittest.main()

# Generated at 2022-06-17 16:39:54.024194
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pkl"))
    assert g.symbol2number["and_expr"] == 258
    assert g.number2symbol[258] == "and_expr"
    assert g.states[0][0][0][0] == 1
    assert g.dfas[258][0][0][0][0] == 1
    assert g.labels[1] == (1, None)
    assert g.keywords["False"] == 1
    assert g.tokens[token.NAME] == 1
    assert g.symbol2label["and_expr"] == 258
    assert g.start == 256

# Generated at 2022-06-17 16:40:05.811843
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io

    class TestGrammarLoad(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[(1, 2)]]
            g.dfas = {1: ([(1, 2)], {1: 1})}
            g.labels = [(1, 'foo')]
            g.keywords = {'foo': 1}
            g.tokens = {1: 1}
            g.symbol2label = {'foo': 1}
            g.start = 1
            g.async_keywords = False

            f = io.BytesIO()

# Generated at 2022-06-17 16:40:18.287991
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import tempfile
    import os

    class TestGrammar(unittest.TestCase):

        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            g.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 1}),
                      2: ([(5, 6), (7, 8)], {3: 1, 4: 1})}

# Generated at 2022-06-17 16:40:21.743017
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen2
    from . import tokenize
    from .parse import Parser

    g = pgen2.driver.load_grammar("Grammar.txt")
    g.dump("Grammar.pickle")
    g = Grammar()
    g.load("Grammar.pickle")
    p = Parser(g)
    p.parse(tokenize.generate_tokens(iter(["pass"]).__next__))

# Generated at 2022-06-17 16:40:24.342605
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pkl"))
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:40:31.673300
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    from . import grammar
    from . import token

    class GrammarDumpTests(unittest.TestCase):
        def test_dump(self):
            g = grammar.Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[[(1, 2), (3, 4)], [(5, 6)]]]
            g.dfas = {1: ([[(1, 2), (3, 4)], [(5, 6)]], {1: 1, 2: 1})}
            g.labels = [(1, None), (2, None), (3, None), (4, None), (5, None), (6, None)]
            g.keywords = {'bar': 1}

# Generated at 2022-06-17 16:40:43.142414
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")

# Generated at 2022-06-17 16:40:50.449179
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == 1
    assert g.dfas[257][0][0][0][0] == 1
    assert g.labels[1][0] == token.NAME
    assert g.keywords["and"] == 1
    assert g.tokens[token.NAME] == 1
    assert g.start == 256

# Generated at 2022-06-17 16:41:09.143255
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import pickle
    import pytest

    # Test with a pickle file that doesn't exist
    with pytest.raises(FileNotFoundError):
        Grammar().load("does_not_exist.pickle")

    # Test with a pickle file that is not a valid pickle file
    with tempfile.NamedTemporaryFile(delete=False) as f:
        f.write(b"not a pickle file")
    with pytest.raises(pickle.UnpicklingError):
        Grammar().load(f.name)
    os.remove(f.name)

    # Test with a valid pickle file

# Generated at 2022-06-17 16:41:20.348456
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[(1, 2)], [(3, 4)]]
            g.dfas = {1: (g.states[0], {1: 1}), 2: (g.states[1], {2: 1})}
            g.labels = [(1, 'bar'), (2, 'baz')]
            g.keywords = {'bar': 1}
            g.tokens = {1: 1}
            g.symbol2label = {'foo': 1}

# Generated at 2022-06-17 16:41:21.928255
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/tmp/test_Grammar_dump")


# Generated at 2022-06-17 16:41:29.653556
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io
    import os
    import tempfile

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.g = Grammar()
            self.g.symbol2number = {'a': 1, 'b': 2}
            self.g.number2symbol = {1: 'a', 2: 'b'}
            self.g.states = [[(1, 1), (2, 2)], [(3, 3), (4, 4)]]
            self.g.dfas = {1: ([(1, 1), (2, 2)], {1: 1, 2: 2}),
                           2: ([(3, 3), (4, 4)], {3: 3, 4: 4})}
            self.g.lab

# Generated at 2022-06-17 16:41:34.410986
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen2
    from .pgen2 import tokenize

    g = pgen2.driver.load_grammar("Grammar.txt")
    g.dump("Grammar.pickle")
    g2 = Grammar()
    g2.load("Grammar.pickle")
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label

# Generated at 2022-06-17 16:41:36.705740
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/tmp/test_Grammar_dump")


# Generated at 2022-06-17 16:41:49.648250
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {"a": 1, "b": 2}
            g.number2symbol = {1: "a", 2: "b"}
            g.states = [[(1, 2)], [(3, 4)]]
            g.dfas = {1: ([(1, 2)], {1: 1}), 2: ([(3, 4)], {3: 1})}
            g.labels = [(1, "a"), (2, "b"), (3, "c"), (4, "d")]
            g.keywords = {"a": 1, "b": 2}

# Generated at 2022-06-17 16:42:01.246032
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = pgen2.Grammar()
            g.load(pgen2.grammar_file)
            self.assertTrue(g.symbol2number)
            self.assertTrue(g.number2symbol)
            self.assertTrue(g.states)
            self.assertTrue(g.dfas)
            self.assertTrue(g.labels)
            self.assertTrue(g.keywords)
            self.assertTrue(g.tokens)
            self.assertTrue(g.symbol2label)
            self.assertTrue(g.start)

# Generated at 2022-06-17 16:42:12.641422
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import os
    from . import pgen2
    from . import token

    # Create a grammar object
    g = pgen2.driver.load_grammar("Grammar/Grammar")

    # Dump the grammar object to a pickle file
    g.dump("Grammar/Grammar.pickle")

    # Load the grammar object from the pickle file
    g2 = Grammar()
    g2.load("Grammar/Grammar.pickle")

    # Compare the two grammar objects
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels

# Generated at 2022-06-17 16:42:24.536100
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import os
    import shutil
    import tempfile
    import pickle
    import sys
    import io

    class Grammar_dump_TestCase(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.temp_file = os.path.join(self.temp_dir, "temp_file")
            self.grammar = Grammar()
            self.grammar.symbol2number = {"a": 1, "b": 2}
            self.grammar.number2symbol = {1: "a", 2: "b"}
            self.grammar.states = [[(1, 1), (2, 2)], [(3, 3), (4, 4)]]

# Generated at 2022-06-17 16:42:34.675983
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import io
    from . import pgen2

    class TestGrammarDump(unittest.TestCase):
        def test_dump(self):
            g = pgen2.grammar.Grammar()
            g.dump(io.BytesIO())

    unittest.main()

# Generated at 2022-06-17 16:42:44.108350
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import io
    import unittest
    import pickle

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[(1, 1)]]
            g.dfas = {1: ([[(1, 1)]], {1: 1})}
            g.labels = [(1, 'foo')]
            g.keywords = {'foo': 1}
            g.tokens = {1: 1}
            g.symbol2label = {'foo': 1}
            g.start = 1
            g.async_keywords = False

            # mypyc generates objects that

# Generated at 2022-06-17 16:42:52.727052
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    import unittest
    from typing import Any, Dict, List, Optional, Text, Tuple, TypeVar, Union

    from . import token

    _P = TypeVar("_P", bound="Grammar")
    Label = Tuple[int, Optional[Text]]
    DFA = List[List[Tuple[int, int]]]
    DFAS = Tuple[DFA, Dict[int, int]]
    Path = Union[str, "os.PathLike[str]"]


# Generated at 2022-06-17 16:43:03.701752
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import os
    import tempfile
    from . import token

    # Create a temporary file
    fd, filename = tempfile.mkstemp()
    os.close(fd)

    # Create a Grammar object
    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
    g.dfas = {1: (g.states[0], {1: 1}), 2: (g.states[1], {1: 1})}
    g.labels = [(token.NAME, 'foo'), (token.NAME, 'bar')]

# Generated at 2022-06-17 16:43:13.883005
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test that Grammar.load() works
    #
    # The test is a bit tricky because we can't just compare the
    # loaded grammar to the original one, since the order of the
    # states list is undefined.  So we compare the two grammars'
    # dumps.
    import pickle
    import io

    g = Grammar()
    g.symbol2number = {"foo": 1, "bar": 2}
    g.number2symbol = {1: "foo", 2: "bar"}
    g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
    g.dfas = {1: (0, {1: 1}), 2: (1, {3: 1})}

# Generated at 2022-06-17 16:43:25.837538
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2
    from . import conv

    g = Grammar()
    g.load("Grammar.txt")

# Generated at 2022-06-17 16:43:35.110918
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == 257
    assert g.dfas[257][0][0][0][0] == 257
    assert g.labels[257] == (257, None)
    assert g.keywords["and"] == 257
    assert g.tokens[token.AND] == 257
    assert g.symbol2label["and"] == 257
    assert g.start == 256


# Generated at 2022-06-17 16:43:39.355669
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            grammar = pgen2.driver.load_grammar("Grammar/Grammar")
            self.assertIsInstance(grammar, Grammar)

    unittest.main("Grammar", verbosity=2, exit=False)

# Generated at 2022-06-17 16:43:50.815480
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[257][0][0][0][0] == token.NAME
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["and"] == 1
    assert g.tokens[token.NAME] == 1
    assert g.symbol2label["and"] == 1
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:43:58.749871
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import io
    import unittest
    import unittest.mock

    class TestGrammar(Grammar):
        def __init__(self):
            super().__init__()
            self.symbol2number = {'a': 1, 'b': 2}
            self.number2symbol = {1: 'a', 2: 'b'}
            self.states = [[(1, 1), (2, 2)], [(3, 3), (4, 4)]]
            self.dfas = {1: ([(1, 1), (2, 2)], {1: 1, 2: 2}), 2: ([(3, 3), (4, 4)], {3: 3, 4: 4})}

# Generated at 2022-06-17 16:44:18.073472
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[257][0][0][0][0] == token.NAME
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["False"] == 1
    assert g.tokens[token.NAME] == 2
    assert g.symbol2label["and"] == 257
    assert g.start == 256

# Generated at 2022-06-17 16:44:19.826903
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("test.pkl")
    g.load("test.pkl")
    g.report()

# Generated at 2022-06-17 16:44:25.583829
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    import unittest

    class GrammarTestCase(unittest.TestCase):
        def setUp(self):
            self.grammar = Grammar()
            self.grammar.symbol2number = {'foo': 1, 'bar': 2}
            self.grammar.number2symbol = {1: 'foo', 2: 'bar'}
            self.grammar.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            self.grammar.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 2}),
                                 2: ([(5, 6), (7, 8)], {3: 3, 4: 4})}
            self.grammar

# Generated at 2022-06-17 16:44:35.477650
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")

# Generated at 2022-06-17 16:44:43.290901
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("test_Grammar_dump.pkl")
    g2 = Grammar()
    g2.load("test_Grammar_dump.pkl")
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label
    assert g.start == g2.start
    assert g.async_keywords == g2.async_keywords

# Generated at 2022-06-17 16:44:52.300231
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import pickle
    import unittest
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = pgen2.generate_grammar(sys.version_info)
            g.dump("Grammar.pickle")
            g2 = Grammar()
            g2.load("Grammar.pickle")
            self.assertEqual(g.symbol2number, g2.symbol2number)
            self.assertEqual(g.number2symbol, g2.number2symbol)
            self.assertEqual(g.states, g2.states)
            self.assertEqual(g.dfas, g2.dfas)

# Generated at 2022-06-17 16:44:58.569325
# Unit test for method load of class Grammar
def test_Grammar_load():
    import io
    import pickle
    from . import pgen2

    # Create a grammar object
    g = pgen2.driver.load_grammar("Grammar/Grammar")

    # Dump the grammar object to a pickle file
    (fd, filename) = tempfile.mkstemp()
    os.close(fd)
    g.dump(filename)

    # Load the grammar object from the pickle file
    h = Grammar()
    h.load(filename)

    # Dump the grammar object to a pickle bytes object
    with open(filename, "rb") as f:
        pkl = f.read()
    i = Grammar()
    i.loads(pkl)

    # Compare the grammar objects
    assert g.symbol2number == h.symbol2number
    assert g.number2

# Generated at 2022-06-17 16:45:07.205851
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")
    assert g.symbol2number["and_expr"] == 258
    assert g.number2symbol[258] == "and_expr"
    assert g.states[0][0][0][0] == token.NAME
    assert g.states[0][0][0][1] == 1
    assert g.dfas[258][0][0][0][0] == token.NAME
    assert g.dfas[258][0][0][0][1] == 1
    assert g.labels[0][0] == 0
    assert g.labels[0][1] == "EMPTY"
    assert g.keywords["False"] == 1
    assert g.tokens[token.NAME] == 2

# Generated at 2022-06-17 16:45:17.292533
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import pickle
    import unittest

    class TestGrammar(Grammar):
        def __init__(self):
            super().__init__()
            self.symbol2number = {"a": 1, "b": 2}
            self.number2symbol = {1: "a", 2: "b"}
            self.states = [[[(1, 1), (2, 2)], [(3, 3), (4, 4)]]]
            self.dfas = {1: ([[(1, 1), (2, 2)], [(3, 3), (4, 4)]], {1: 1, 2: 1}), 2: ([[(1, 1), (2, 2)], [(3, 3), (4, 4)]], {1: 1, 2: 1})}
            self.labels

# Generated at 2022-06-17 16:45:23.688035
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][1] == 1
    assert g.dfas[257][0][0][1] == 1
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["and"] == 257
    assert g.tokens[token.NAME] == 258
    assert g.start == 256

# Generated at 2022-06-17 16:45:51.377101
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pkl"))
    assert g.symbol2number["and_expr"] == 258
    assert g.number2symbol[258] == "and_expr"
    assert g.states[0][0][0][0] == 257
    assert g.dfas[258][0][0][0][0] == 257
    assert g.labels[257][0] == token.NAME
    assert g.keywords["False"] == 259
    assert g.tokens[token.NAME] == 257
    assert g.symbol2label["and_expr"] == 258
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:45:59.409280
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    import unittest

    class GrammarTestCase(unittest.TestCase):
        def setUp(self):
            self.g = Grammar()
            self.g.symbol2number = {'foo': 1, 'bar': 2}
            self.g.number2symbol = {1: 'foo', 2: 'bar'}
            self.g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            self.g.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 1}),
                           2: ([(5, 6), (7, 8)], {3: 1, 4: 1})}

# Generated at 2022-06-17 16:46:09.614204
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("test_Grammar_dump.pickle")
    g2 = Grammar()
    g2.load("test_Grammar_dump.pickle")
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label
    assert g.start == g2.start
    assert g.async_keywords == g2.async_keywords

# Generated at 2022-06-17 16:46:12.710654
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pkl"))
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:46:21.126632
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import io
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            grammar = pgen2.driver.load_grammar("Grammar.txt")
            f = io.BytesIO()
            grammar.dump(f)
            f.seek(0)
            unpickled = pickle.load(f)
            self.assertEqual(unpickled["start"], 256)

    unittest.main()

# Generated at 2022-06-17 16:46:27.933091
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[257][0][0][0][0] == token.NAME
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["False"] == 1
    assert g.tokens[token.NAME] == 2
    assert g.symbol2label["and"] == 257
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:46:39.343126
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[(1, 2)], [(3, 4)]]
            g.dfas = {1: ([(1, 2)], {1: 1}), 2: ([(3, 4)], {3: 1})}
            g.labels = [(1, 'a'), (2, 'b'), (3, 'c'), (4, 'd')]
            g.keywords = {'a': 1, 'b': 2}
            g.tok

# Generated at 2022-06-17 16:46:48.546307
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert grammar.symbol2number["and_expr"] == 258
    assert grammar.number2symbol[258] == "and_expr"
    assert grammar.states[0][0][0][0] == 1
    assert grammar.dfas[258][0][0][0][0] == 1
    assert grammar.labels[1] == (1, None)
    assert grammar.keywords["False"] == 1
    assert grammar.tokens[1] == 1
    assert grammar.symbol2label["and_expr"] == 258
    assert grammar.start == 256
    assert grammar.async_keywords == False

# Generated at 2022-06-17 16:46:59.726984
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'a': 1, 'b': 2}
    g.number2symbol = {1: 'a', 2: 'b'}
    g.states = [[(1, 2)], [(3, 4)]]
    g.dfas = {1: ([(1, 2)], {1: 1}), 2: ([(3, 4)], {3: 1})}
    g.labels = [(1, 'a'), (2, 'b'), (3, 'c')]
    g.keywords = {'a': 1, 'b': 2}
    g.tokens = {1: 1, 2: 2}
    g.symbol2label = {'a': 1, 'b': 2}
    g.start = 256
    g.async_

# Generated at 2022-06-17 16:47:10.513895
# Unit test for method load of class Grammar
def test_Grammar_load():
    import os
    import sys
    from . import pgen2
    from . import tokenize

    # Create a temporary file
    fd, filename = tempfile.mkstemp()
    os.close(fd)

    # Generate a pickle file
    g = pgen2.driver.load_grammar(sys.version_info[0])
    g.dump(filename)

    # Load the pickle file
    g2 = Grammar()
    g2.load(filename)

    # Remove the temporary file
    os.remove(filename)

    # Compare the two grammars
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
