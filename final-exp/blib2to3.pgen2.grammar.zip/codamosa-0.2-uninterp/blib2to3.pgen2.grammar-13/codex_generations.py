

# Generated at 2022-06-17 16:38:10.165780
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import tempfile
    import os

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            g.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 1}),
                      2: ([(5, 6), (7, 8)], {1: 1, 2: 1})}
            g.labels = [(1, 'a'), (2, 'b')]


# Generated at 2022-06-17 16:38:21.606452
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import unittest
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = pgen2.driver.load_grammar("Grammar.txt")
            f = io.BytesIO()
            g.dump(f)
            f.seek(0)
            g2 = Grammar()
            g2.loads(f.read())
            self.assertEqual(g.symbol2number, g2.symbol2number)
            self.assertEqual(g.number2symbol, g2.number2symbol)
            self.assertEqual(g.states, g2.states)
            self.assertEqual(g.dfas, g2.dfas)

# Generated at 2022-06-17 16:38:23.859121
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:38:35.363144
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = pgen2.Grammar()
            g.load(pgen2.grammar_file)
            self.assertTrue(g.symbol2number)
            self.assertTrue(g.number2symbol)
            self.assertTrue(g.states)
            self.assertTrue(g.dfas)
            self.assertTrue(g.labels)
            self.assertTrue(g.keywords)
            self.assertTrue(g.tokens)
            self.assertTrue(g.symbol2label)
            self.assertTrue(g.start)

    unittest.main()

# Generated at 2022-06-17 16:38:44.849345
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import unittest
    import tempfile
    import os

    class TestGrammar(Grammar):
        def __init__(self):
            super().__init__()
            self.symbol2number = {"foo": 1, "bar": 2}
            self.number2symbol = {1: "foo", 2: "bar"}
            self.states = [[(0, 1), (1, 2)], [(0, 3), (2, 4)]]
            self.dfas = {1: ([(0, 1), (1, 2)], {1: 1}), 2: ([(0, 3), (2, 4)], {2: 1})}
            self.labels = [(0, "EMPTY"), (1, None), (2, None)]

# Generated at 2022-06-17 16:38:48.878633
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            grammar = pgen2.driver.load_grammar("Grammar.txt")
            grammar.dump("Grammar.pickle")

    unittest.main("idlelib.pgen2.conv", verbosity=2, exit=False)

if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-17 16:39:00.530447
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    import unittest

    class GrammarTestCase(unittest.TestCase):
        def setUp(self):
            self.grammar = Grammar()
            self.grammar.symbol2number = {'foo': 1, 'bar': 2}
            self.grammar.number2symbol = {1: 'foo', 2: 'bar'}
            self.grammar.states = [[(1, 1), (2, 2)], [(1, 3), (2, 4)]]
            self.grammar.dfas = {1: ([(1, 1), (2, 2)], {1: 1, 2: 2}),
                                 2: ([(1, 3), (2, 4)], {1: 1, 2: 2})}
            self.grammar

# Generated at 2022-06-17 16:39:09.754618
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0] == [(0, 1), (1, 2)]
    assert g.dfas[258][0][0] == [(0, 1), (1, 2)]
    assert g.labels[1] == (1, None)
    assert g.keywords["and"] == 1
    assert g.tokens[token.NAME] == 2
    assert g.symbol2label["and"] == 1
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:39:20.451483
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[257][0][0][0][0] == token.NAME
    assert g.labels[1] == (token.NAME, None)
    assert g.keywords["and"] == 1
    assert g.tokens[token.NAME] == 1
    assert g.start == 257
    assert g.async_keywords == False

# Generated at 2022-06-17 16:39:30.919530
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io
    import sys
    import os
    import os.path
    import tempfile
    import shutil
    import importlib
    import importlib.util
    import importlib.machinery
    import importlib.abc
    import importlib._bootstrap
    import importlib._bootstrap_external
    import importlib._bootstrap_external.FileLoader
    import importlib._bootstrap_external.SourceFileLoader
    import importlib._bootstrap_external.SourcelessFileLoader
    import importlib._bootstrap_external.ExtensionFileLoader
    import importlib._bootstrap_external.ExecutableFinder
    import importlib._bootstrap_external.PathFinder
    import importlib._bootstrap_external.FileFinder
    import importlib._bootstrap_external.FileLoader

# Generated at 2022-06-17 16:39:42.806292
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    import io
    import sys
    import tempfile
    import os
    import shutil
    from . import pgen2
    from . import token

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 16:39:50.801732
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import tempfile
    from . import pgen2
    from . import tokenize
    from . import token

    # Create a temporary directory
    temp_dir = tempfile.TemporaryDirectory()
    temp_dir_name = temp_dir.name

    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir_name, delete=False)
    temp_file_name = temp_file.name

    # Create a temporary grammar
    temp_grammar = Grammar()
    temp_grammar.symbol2number = {"a": 1, "b": 2}
    temp_grammar.number2symbol = {1: "a", 2: "b"}

# Generated at 2022-06-17 16:39:58.817750
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[(1, 1), (2, 2)], [(3, 3), (4, 4)]]
            g.dfas = {1: ([(1, 1), (2, 2)], {1: 1, 2: 2}), 2: ([(3, 3), (4, 4)], {3: 3, 4: 4})}
            g.labels = [(1, None), (2, None), (3, None), (4, None)]


# Generated at 2022-06-17 16:40:07.732568
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert grammar.symbol2number["and"] == 258
    assert grammar.number2symbol[258] == "and"
    assert grammar.states[0][0][0][0] == 1
    assert grammar.dfas[258][0][0][0][0] == 1
    assert grammar.labels[1] == (1, None)
    assert grammar.keywords["False"] == 1
    assert grammar.tokens[1] == 1
    assert grammar.symbol2label["and"] == 258
    assert grammar.start == 256
    assert grammar.async_keywords == False

# Generated at 2022-06-17 16:40:20.114401
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[[(1, 1)]]]
            g.dfas = {1: ([[(1, 1)]], {1: 1})}
            g.labels = [(1, 'foo')]
            g.keywords = {'foo': 1}
            g.tokens = {1: 1}
            g.symbol2label = {'foo': 1}
            g.start = 1
            g.async_keywords = False

            f = io.BytesIO()
           

# Generated at 2022-06-17 16:40:27.510667
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == 1
    assert g.dfas[257][0][0][0][0] == 1
    assert g.labels[1][0] == 1
    assert g.keywords["and"] == 1
    assert g.tokens[1] == 1
    assert g.start == 256

# Generated at 2022-06-17 16:40:36.744798
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    from io import BytesIO
    from . import pgen2

    # Create a grammar object
    grammar = pgen2.driver.load_grammar("Grammar/Grammar")

    # Dump the grammar object to a pickle file
    grammar.dump("Grammar/Grammar.pickle")

    # Load the grammar object from the pickle file
    grammar2 = Grammar()
    grammar2.load("Grammar/Grammar.pickle")

    # Dump the grammar object to a pickle bytes object
    with BytesIO() as f:
        pickle.dump(grammar, f, pickle.HIGHEST_PROTOCOL)
        pkl = f.getvalue()

    # Load the grammar object from the pickle bytes object
    grammar3 = Grammar()
   

# Generated at 2022-06-17 16:40:41.437575
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/tmp/test_Grammar_dump")
    g.load("/tmp/test_Grammar_dump")

# Generated at 2022-06-17 16:40:50.793773
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import tempfile
    import pickle
    from . import pgen2
    from . import token

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.g = pgen2.driver.load_grammar("Grammar/Grammar")
            self.g.async_keywords = True
            self.g.dump(tempfile.mktemp())

        def test_dump(self):
            g = Grammar()
            g.load(tempfile.mktemp())
            self.assertEqual(g.async_keywords, True)
            self.assertEqual(g.symbol2number, self.g.symbol2number)
            self.assertEqual(g.number2symbol, self.g.number2symbol)


# Generated at 2022-06-17 16:41:02.484561
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import tempfile
    import pickle
    from . import token

    # Create a Grammar instance
    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[[(1, 2), (2, 3)], [(3, 4)]]]
    g.dfas = {1: ([[(1, 2), (2, 3)], [(3, 4)]], {1: 1, 2: 1, 3: 1, 4: 1}), 2: ([[(1, 2), (2, 3)], [(3, 4)]], {1: 1, 2: 1, 3: 1, 4: 1})}

# Generated at 2022-06-17 16:41:09.510436
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.pickle")
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:41:14.202758
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import unittest

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.load(sys.executable)

    unittest.main()

# Generated at 2022-06-17 16:41:23.773340
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import os
    import pickle
    import tempfile
    import shutil
    from . import token

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.filename = os.path.join(self.tempdir, "grammar.pickle")
            self.g = Grammar()
            self.g.symbol2number = {"foo": 1, "bar": 2}
            self.g.number2symbol = {1: "foo", 2: "bar"}
            self.g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]

# Generated at 2022-06-17 16:41:30.980780
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {"foo": 1}
            g.number2symbol = {1: "foo"}
            g.states = [[(1, 2)]]
            g.dfas = {1: ([(1, 2)], {1: 1})}
            g.labels = [(1, "foo")]
            g.keywords = {"foo": 1}
            g.tokens = {1: 1}
            g.symbol2label = {"foo": 1}
            g.start = 1
            g.async_keywords = True

            f = io.BytesIO()

# Generated at 2022-06-17 16:41:43.378175
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pytest
    import os
    import pickle
    from . import token
    from .pgen2 import tokenize

    g = Grammar()
    g.symbol2number = {'foo': 257, 'bar': 258}
    g.number2symbol = {257: 'foo', 258: 'bar'}
    g.states = [[[(0, 1)], [(0, 2)]]]
    g.dfas = {257: ([[(0, 1)], [(0, 2)]], {257: 1}), 258: ([[(0, 1)], [(0, 2)]], {258: 1})}
    g.labels = [(0, 'EMPTY'), (257, None), (258, None)]
    g.keywords = {}
    g.tokens = {}
    g.symbol2label

# Generated at 2022-06-17 16:41:49.606627
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    from . import pgen2
    from . import tokenize

    # Create a grammar object
    g = pgen2.driver.load_grammar(tokenize.__file__)

    # Dump the grammar object to a pickle file
    g.dump(sys.argv[1])

# Generated at 2022-06-17 16:41:56.654760
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[(1, 2)], [(3, 4)]]
    g.dfas = {1: (g.states[0], {1: 1}), 2: (g.states[1], {3: 1})}
    g.labels = [(1, None), (2, None), (3, None), (4, None)]
    g.keywords = {'foo': 1, 'bar': 3}
    g.tokens = {1: 1, 2: 2, 3: 3, 4: 4}
    g.symbol2label = {'foo': 1, 'bar': 3}
    g.start

# Generated at 2022-06-17 16:42:05.861945
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import unittest
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = pgen2.Grammar()
            g.load(sys.executable)
            self.assertTrue(g.symbol2number)
            self.assertTrue(g.number2symbol)
            self.assertTrue(g.states)
            self.assertTrue(g.dfas)
            self.assertTrue(g.labels)
            self.assertTrue(g.keywords)
            self.assertTrue(g.tokens)
            self.assertTrue(g.symbol2label)
            self.assertTrue(g.start)
            self.assertTrue(g.async_keywords)

    unittest.main

# Generated at 2022-06-17 16:42:13.185024
# Unit test for method load of class Grammar
def test_Grammar_load():
    """
    Test method load of class Grammar.
    """
    import pytest
    from . import conv, pgen

    # Create a grammar object
    g = Grammar()

    # Create a pickle file
    with tempfile.NamedTemporaryFile(delete=False) as f:
        pickle.dump(g.__dict__, f, pickle.HIGHEST_PROTOCOL)
        pickle_file = f.name

    # Load the pickle file
    g.load(pickle_file)

    # Delete the pickle file
    os.remove(pickle_file)

    # Create a pickle file
    with tempfile.NamedTemporaryFile(delete=False) as f:
        pickle.dump(g.__dict__, f, pickle.HIGHEST_PROTOCOL)

# Generated at 2022-06-17 16:42:23.966749
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == 1
    assert g.dfas[257][0][0][0][0] == 1
    assert g.labels[1][0] == token.NAME
    assert g.keywords["and"] == 1
    assert g.tokens[token.NAME] == 1
    assert g.start == 257
    assert g.async_keywords == False

# Generated at 2022-06-17 16:42:36.805701
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import io
    from . import pgen2
    from . import token

    # Create a grammar object
    g = pgen2.driver.load_grammar("Grammar/Grammar")

    # Dump the grammar object to a pickle file
    f = io.BytesIO()
    g.dump(f)

    # Load the grammar object from the pickle file
    f.seek(0)
    g2 = Grammar()
    g2.loads(f.read())

    # Check that the grammar objects are equal
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2

# Generated at 2022-06-17 16:42:50.173407
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[(1, 1), (2, 2)], [(3, 3), (4, 4)]]
            g.dfas = {1: ([(1, 1), (2, 2)], {1: 1}), 2: ([(3, 3), (4, 4)], {3: 1})}
            g.labels = [(1, 'a'), (2, 'b'), (3, 'c'), (4, 'd')]

# Generated at 2022-06-17 16:42:54.687940
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pkl"))
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:43:03.702801
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import io
    import unittest

    class GrammarDumpTests(unittest.TestCase):
        def test_dump(self):
            # Issue #28963: Grammar.dump() should not write to stdout
            # when called with a filename.
            g = Grammar()
            g.dump('/dev/null')
            self.assertEqual(sys.stdout.getvalue(), '')

    # Create a StringIO object for stdout
    sys.stdout = io.StringIO()
    try:
        unittest.main(verbosity=0, exit=False)
    finally:
        sys.stdout = sys.__stdout__

# Generated at 2022-06-17 16:43:13.027526
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    from . import token

    # mypyc generates objects that don't have a __dict__, but they
    # do have __getstate__ methods that will return an equivalent
    # dictionary
    if hasattr(token, "__dict__"):
        d = token.__dict__
    else:
        d = token.__getstate__()  # type: ignore

    with tempfile.NamedTemporaryFile(
        dir=os.path.dirname(__file__), delete=False
    ) as f:
        pickle.dump(d, f, pickle.HIGHEST_PROTOCOL)
    os.replace(f.name, __file__)

# Generated at 2022-06-17 16:43:24.111609
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import os
    import tempfile
    import shutil

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.filename = os.path.join(self.tmpdir, 'test.pickle')

        def tearDown(self):
            shutil.rmtree(self.tmpdir)

        def test_dump(self):
            g = Grammar()
            g.dump(self.filename)
            with open(self.filename, 'rb') as f:
                d = pickle.load(f)
            self.assertEqual(d, g.__dict__)

    unittest.main()

# Generated at 2022-06-17 16:43:28.229167
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import unittest
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = pgen2.Grammar()
            g.load(sys.executable)

    unittest.main()

# Generated at 2022-06-17 16:43:35.332729
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import unittest.mock

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            grammar = Grammar()
            grammar.dump("test_dump")
            with unittest.mock.patch("pickle.dump") as mock_dump:
                grammar.dump("test_dump")
                mock_dump.assert_called_once()

    unittest.main()

# Generated at 2022-06-17 16:43:42.495367
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
            self.assertEqual(g.symbol2number["and"], 257)
            self.assertEqual(g.number2symbol[257], "and")
            self.assertEqual(g.states[0][0][0][0], token.NAME)
            self.assertEqual(g.dfas[257][0][0][0][0], token.NAME)
            self.assertEqual(g.labels[0], (0, "EMPTY"))

# Generated at 2022-06-17 16:43:47.480120
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import io
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            grammar = pgen2.driver.load_grammar("Grammar.txt")
            f = io.BytesIO()
            grammar.dump(f)
            f.seek(0)
            grammar2 = Grammar()
            grammar2.loads(f.read())
            self.assertEqual(grammar.symbol2number, grammar2.symbol2number)
            self.assertEqual(grammar.number2symbol, grammar2.number2symbol)
            self.assertEqual(grammar.states, grammar2.states)
            self.assertEqual(grammar.dfas, grammar2.dfas)
           

# Generated at 2022-06-17 16:44:15.702326
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import sys
    import os
    import pickle
    import tempfile
    import shutil
    import io

    class Grammar_dump_TestCase(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.filename = os.path.join(self.tempdir, "test.pkl")

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_dump_and_load(self):
            g = Grammar()
            g.dump(self.filename)
            g2 = Grammar()
            g2.load(self.filename)
            self.assertEqual(g.symbol2number, g2.symbol2number)

# Generated at 2022-06-17 16:44:23.552909
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import sys
    import unittest

    class GrammarTestCase(unittest.TestCase):
        def test_dump(self):
            # Test dumping a grammar
            g = Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[(1, 2)], [(1, 3)]]
            g.dfas = {1: ([(1, 2)], {1: 1}), 2: ([(1, 3)], {1: 1})}
            g.labels = [(1, 'bar')]
            g.keywords = {'bar': 1}
            g.tokens = {1: 1}
            g.symbol2label = {'foo': 1}

# Generated at 2022-06-17 16:44:26.857469
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:44:30.471486
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.pickle")
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:44:32.996316
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    g.report()

# Generated at 2022-06-17 16:44:42.441722
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import pickle
    from . import pgen2
    from . import token

    g = pgen2.driver.load_grammar("Grammar.txt")
    f = io.BytesIO()
    g.dump(f)
    f.seek(0)
    g2 = Grammar()
    g2.loads(f.read())
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens

# Generated at 2022-06-17 16:44:54.797838
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import sys
    import os
    import pickle
    import tempfile
    from . import pgen2

    class Grammar_dump_TestCase(unittest.TestCase):
        def test_dump(self):
            g = pgen2.grammar.Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[(1, 2)], [(1, 3)]]
            g.dfas = {1: (g.states[0], {1: 1}), 2: (g.states[1], {1: 1})}
            g.labels = [(1, 'foo'), (2, 'bar')]
            g.keywords = {'foo': 1}
            g.t

# Generated at 2022-06-17 16:45:05.536264
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    from io import BytesIO

    g = Grammar()
    g.symbol2number = {'foo': 1}
    g.number2symbol = {1: 'foo'}
    g.states = [[[(1, 2)], [(2, 3)]]]
    g.dfas = {1: ([[(1, 2)], [(2, 3)]], {1: 1, 2: 1})}
    g.labels = [(1, 'foo'), (2, 'bar')]
    g.keywords = {'foo': 1, 'bar': 2}
    g.tokens = {1: 1, 2: 2}
    g.symbol2label = {'foo': 1, 'bar': 2}
    g.start = 256

    f = BytesIO()

# Generated at 2022-06-17 16:45:16.494233
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {"a": 1, "b": 2}
    g.number2symbol = {1: "a", 2: "b"}
    g.states = [[(1, 2)], [(3, 4)]]
    g.dfas = {1: (g.states[0], {1: 1}), 2: (g.states[1], {3: 1})}
    g.labels = [(1, "a"), (2, "b"), (3, "c")]
    g.keywords = {"a": 1, "b": 2}
    g.tokens = {1: 1, 2: 2}
    g.symbol2label = {"a": 1, "b": 2}
    g.start = 256
    g.async_keywords = False

# Generated at 2022-06-17 16:45:24.388084
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    from typing import Any, Dict, List, Optional, Text, Tuple, TypeVar, Union

    # Local imports
    from . import token

    _P = TypeVar("_P", bound="Grammar")
    Label = Tuple[int, Optional[Text]]
    DFA = List[List[Tuple[int, int]]]
    DFAS = Tuple[DFA, Dict[int, int]]
    Path = Union[str, "os.PathLike[str]"]


# Generated at 2022-06-17 16:46:05.109588
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import sys
    import os
    import tempfile
    import shutil
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.pickle_file = os.path.join(self.tmpdir, "grammar.pickle")

        def tearDown(self):
            shutil.rmtree(self.tmpdir)

        def test_dump(self):
            pgen2.driver.load_grammar(self.pickle_file)
            with open(self.pickle_file, "rb") as f:
                d = pickle.load(f)
            self.assertEqual(d["start"], 256)

    unittest

# Generated at 2022-06-17 16:46:17.225605
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import sys
    import os
    import pickle
    from . import pgen2
    from . import token

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.filename = os.path.join(self.tmpdir, "Grammar.pickle")
            self.grammar = pgen2.driver.load_grammar(self.filename)

        def tearDown(self):
            os.remove(self.filename)
            os.rmdir(self.tmpdir)

        def test_dump(self):
            self.grammar.dump(self.filename)
            with open(self.filename, "rb") as f:
                d = pickle.load(f)

# Generated at 2022-06-17 16:46:19.709898
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    g.report()

# Generated at 2022-06-17 16:46:27.377659
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen2
    from . import conv

    # Create a grammar object
    g = Grammar()

    # Load the grammar tables
    pgen2.driver.load_grammar("Grammar/Grammar", g)

    # Dump the grammar tables
    g.dump("Grammar/Grammar.pickle")

    # Load the grammar tables
    g2 = Grammar()
    g2.load("Grammar/Grammar.pickle")

    # Convert the grammar tables
    conv.convert_grammar(g2)

    # Dump the grammar tables
    g2.dump("Grammar/Grammar.pickle")

    # Load the grammar tables
    g3 = Grammar()
    g3.load("Grammar/Grammar.pickle")

    # Convert the

# Generated at 2022-06-17 16:46:34.968716
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = pgen2.driver.load_grammar("Grammar/Grammar")
            g.dump("Grammar/Grammar.pickle")

    unittest.main("test_Grammar_dump", verbosity=2, exit=False)

# Generated at 2022-06-17 16:46:41.958449
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'foo': 1}
    g.number2symbol = {1: 'foo'}
    g.states = [[[(1, 1)]]]
    g.dfas = {1: ([[(1, 1)]], {1: 1})}
    g.labels = [(1, None)]
    g.keywords = {'foo': 1}
    g.tokens = {1: 1}
    g.symbol2label = {'foo': 1}
    g.start = 1
    g.async_keywords = False
    with tempfile.NamedTemporaryFile() as f:
        g.dump(f.name)

# Generated at 2022-06-17 16:46:50.318988
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[258] == "as"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[258][0][0][0][0] == token.NAME
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["False"] == 1
    assert g.tokens[token.NAME] == 2
    assert g.symbol2label["and"] == 257
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:47:01.360211
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    from . import token

    # Create a Grammar object
    g = Grammar()
    g.symbol2number = {'foo': 257, 'bar': 258}
    g.number2symbol = {257: 'foo', 258: 'bar'}
    g.states = [[[(0, 0)], [(1, 1)], [(2, 2)], [(3, 3)], [(4, 4)]]]

# Generated at 2022-06-17 16:47:11.260550
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    from io import BytesIO

    class TestGrammarLoad(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.loads(b"\x80\x03}q\x00.")
            self.assertEqual(g.symbol2number, {})
            self.assertEqual(g.number2symbol, {})
            self.assertEqual(g.states, [])
            self.assertEqual(g.dfas, {})
            self.assertEqual(g.labels, [(0, "EMPTY")])
            self.assertEqual(g.keywords, {})
            self.assertEqual(g.tokens, {})
            self.assertEqual(g.symbol2label, {})
           

# Generated at 2022-06-17 16:47:17.077303
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    import unittest

    class GrammarTestCase(unittest.TestCase):
        def setUp(self):
            self.grammar = Grammar()
            self.grammar.symbol2number = {'foo': 1, 'bar': 2}
            self.grammar.number2symbol = {1: 'foo', 2: 'bar'}
            self.grammar.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            self.grammar.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 1}),
                                 2: ([(5, 6), (7, 8)], {3: 1, 4: 1})}
            self.grammar