

# Generated at 2022-06-17 16:38:22.611716
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen2

    g = pgen2.driver.load_grammar("Grammar.txt")
    g.dump("Grammar.pickle")
    g2 = Grammar()
    g2.load("Grammar.pickle")
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label
    assert g.start == g2.start

# Generated at 2022-06-17 16:38:32.228710
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == 0
    assert g.dfas[257][0][0][0][0] == 0
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["and"] == 0
    assert g.tokens[token.NAME] == 0
    assert g.start == 256


# Generated at 2022-06-17 16:38:42.707992
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Test that Grammar.dump() works
    g = Grammar()
    g.start = 1
    g.symbol2number = {'a': 1, 'b': 2}
    g.number2symbol = {1: 'a', 2: 'b'}
    g.states = [[(1, 2), (2, 3)], [(3, 4), (4, 5)]]
    g.dfas = {1: (g.states[0], {1: 1, 2: 1}), 2: (g.states[1], {3: 1, 4: 1})}
    g.labels = [(0, 'EMPTY'), (1, None), (2, None), (3, None), (4, None)]
    g.keywords = {}
    g.tokens = {}
    g.symbol2label

# Generated at 2022-06-17 16:38:51.803811
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    from typing import Any, Dict, List, Optional, Text, Tuple, TypeVar, Union

    # Local imports
    from . import token

    _P = TypeVar("_P", bound="Grammar")
    Label = Tuple[int, Optional[Text]]
    DFA = List[List[Tuple[int, int]]]
    DFAS = Tuple[DFA, Dict[int, int]]
    Path = Union[str, "os.PathLike[str]"]


# Generated at 2022-06-17 16:38:57.740382
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import unittest

    class GrammarTest(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.load(sys.executable)

    unittest.main()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:39:07.964107
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2
    from . import conv
    from . import driver
    from . import tokenize
    from . import token

    # Create a grammar object
    g = Grammar()

    # Create a pickle file
    g.dump("Grammar.pickle")

    # Load the grammar object from the pickle file
    g.load("Grammar.pickle")

    # Create a driver object
    d = driver.Driver(g, "test", "test")

    # Create a tokenize object
    t = tokenize.generate_tokens(d.grammar)

    # Create a conv object
    c = conv.Converter(t, d.grammar)

    # Create a pgen2 object
    p = pgen2.Pgen2(c, d.grammar)

    # Test the

# Generated at 2022-06-17 16:39:10.192989
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/tmp/test_Grammar_dump.pkl")


# Generated at 2022-06-17 16:39:21.678290
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    from io import BytesIO

    class GrammarDumpTest(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'foo': 1, 'bar': 2}
            g.number2symbol = {1: 'foo', 2: 'bar'}
            g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            g.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 1}),
                      2: ([(5, 6), (7, 8)], {3: 1, 4: 1})}

# Generated at 2022-06-17 16:39:31.577248
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[257][0][0][0][0] == token.NAME
    assert g.labels[257][0] == token.NAME
    assert g.keywords["and"] == 257
    assert g.tokens[token.NAME] == 257
    assert g.symbol2label["and"] == 257
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:39:33.300930
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/tmp/grammar.pickle")
    g.load("/tmp/grammar.pickle")
    g.report()

# Generated at 2022-06-17 16:39:51.436068
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import io
    from . import pgen2

    g = pgen2.driver.load_grammar("Grammar.txt")
    f = io.BytesIO()
    g.dump(f)
    f.seek(0)
    g2 = Grammar()
    g2.loads(f.read())
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label
   

# Generated at 2022-06-17 16:39:58.305334
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == 1
    assert g.dfas[257][0][0][0][0] == 1
    assert g.labels[1][0] == 1
    assert g.keywords["and"] == 1
    assert g.tokens[1] == 1
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:40:07.882948
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen
    from . import conv
    from . import tokenize

    # Create a grammar object
    g = Grammar()

    # Create a parser generator object
    pg = pgen.ParserGenerator("Grammar.test_Grammar_load", g)

    # Create a converter object
    c = conv.Converter("Grammar.test_Grammar_load", g)

    # Create a tokenizer object
    t = tokenize.Tokenizer()

    # Create a temporary file
    fd, filename = tempfile.mkstemp()
    os.close(fd)

    # Dump the grammar tables to the temporary file
    g.dump(filename)

    # Load the grammar tables from the temporary file
    g.load(filename)

    # Remove the temporary file
    os.remove(filename)



# Generated at 2022-06-17 16:40:20.261520
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen2
    from . import tokenize

    g = pgen2.driver.load_grammar("Grammar.txt")
    g.dump("Grammar.pickle")
    g2 = Grammar()
    g2.load("Grammar.pickle")
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label
    assert g.start == g2.start
   

# Generated at 2022-06-17 16:40:25.353266
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[257][0][0][0][0] == token.NAME
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["False"] == 1
    assert g.tokens[token.NAME] == 2
    assert g.symbol2label["and"] == 257
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:40:32.276564
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    import io
    import unittest
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            # Create a grammar object
            g = pgen2.grammar.Grammar()
            # Create a pickle file
            g.dump("test.pkl")
            # Load the pickle file
            g2 = pgen2.grammar.Grammar()
            g2.load("test.pkl")
            # Check that the two grammar objects are the same
            self.assertEqual(g.symbol2number, g2.symbol2number)
            self.assertEqual(g.number2symbol, g2.number2symbol)
            self.assertEqual(g.states, g2.states)


# Generated at 2022-06-17 16:40:37.352436
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import unittest
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = pgen2.Grammar()
            g.load(sys.executable)

    unittest.main()

# Generated at 2022-06-17 16:40:45.109314
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 258
    assert g.number2symbol[258] == "and"
    assert g.states[0][0][0][0] == 1
    assert g.dfas[258][0][0][0][0] == 1
    assert g.labels[1] == (1, None)
    assert g.keywords["and"] == 1
    assert g.tokens[token.NAME] == 1
    assert g.start == 256

# Generated at 2022-06-17 16:40:52.537171
# Unit test for method load of class Grammar
def test_Grammar_load():
    import io
    import pickle
    import unittest

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[(1, 2)]]
            g.dfas = {1: ([(1, 2)], {2: 1})}
            g.labels = [(1, None)]
            g.keywords = {'foo': 1}
            g.tokens = {1: 1}
            g.symbol2label = {'foo': 1}
            g.start = 1
            g.async_keywords = False

            f = io.BytesIO()

# Generated at 2022-06-17 16:41:02.733941
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pytest
    from . import pgen2
    from . import tokenize

    # Create a Grammar instance
    g = pgen2.driver.load_grammar("Grammar/Grammar")

    # Dump the Grammar instance to a pickle file
    g.dump("Grammar/Grammar.pickle")

    # Load the Grammar instance from the pickle file
    g2 = Grammar()
    g2.load("Grammar/Grammar.pickle")

    # Compare the two Grammar instances
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.lab

# Generated at 2022-06-17 16:41:22.144879
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'foo': 1}
    g.number2symbol = {1: 'foo'}
    g.states = [[(1, 2)]]
    g.dfas = {1: ([(1, 2)], {1: 1})}
    g.labels = [(1, 'foo')]
    g.keywords = {'foo': 1}
    g.tokens = {1: 1}
    g.symbol2label = {'foo': 1}
    g.start = 1
    g.async_keywords = False

    # mypyc generates objects that don't have a __dict__, but they
    # do have __getstate__ methods that will return an equivalent
    # dictionary

# Generated at 2022-06-17 16:41:30.064341
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("test.pkl")
    g2 = Grammar()
    g2.load("test.pkl")
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.start == g2.start
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label
    assert g.async_keywords == g2.async_keywords
    os.remove("test.pkl")

# Generated at 2022-06-17 16:41:31.691412
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pkl"))
    g.report()


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:41:43.658433
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen2
    from . import tokenize
    from . import token

    g = pgen2.driver.load_grammar("Grammar.txt")
    g.dump("Grammar.pickle")
    g2 = Grammar()
    g2.load("Grammar.pickle")
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.start == g2.start
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens

# Generated at 2022-06-17 16:41:54.425134
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import unittest
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = pgen2.driver.load_grammar("Grammar.txt")
            f = io.BytesIO()
            g.dump(f)
            f.seek(0)
            g2 = Grammar()
            g2.loads(f.read())
            self.assertEqual(g.symbol2number, g2.symbol2number)
            self.assertEqual(g.number2symbol, g2.number2symbol)
            self.assertEqual(g.states, g2.states)
            self.assertEqual(g.dfas, g2.dfas)

# Generated at 2022-06-17 16:41:59.733197
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import unittest
    from . import pgen2

    class GrammarTest(unittest.TestCase):
        def test_load(self):
            g = pgen2.Grammar()
            g.load(sys.executable)

    unittest.main()

# Generated at 2022-06-17 16:42:11.498825
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    import io
    import sys

    # Create a grammar
    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[[(1, 2), (3, 4)], [(5, 6), (7, 8)]]]
    g.dfas = {1: ([[(1, 2), (3, 4)], [(5, 6), (7, 8)]], {1: 1, 2: 1}), 2: ([[(9, 10)]], {3: 1})}

# Generated at 2022-06-17 16:42:20.710652
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import io
    import sys
    import unittest

    class GrammarDumpTests(unittest.TestCase):
        def test_dump(self):
            # Issue #17096: Grammar.dump() should not crash when
            # sys.stdout is None
            g = Grammar()
            g.dump(io.BytesIO())
            saved_stdout = sys.stdout
            try:
                sys.stdout = None
                g.dump(io.BytesIO())
            finally:
                sys.stdout = saved_stdout

    unittest.main()

# Generated at 2022-06-17 16:42:22.700356
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/tmp/foo.pickle")


# Generated at 2022-06-17 16:42:31.387051
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))

# Generated at 2022-06-17 16:42:50.366531
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import os
    import tempfile
    import shutil
    import sys
    import io

    class GrammarTestCase(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.filename = os.path.join(self.temp_dir, "grammar.pickle")
            self.grammar = Grammar()
            self.grammar.symbol2number = {"a": 1, "b": 2}
            self.grammar.number2symbol = {1: "a", 2: "b"}
            self.grammar.states = [[[(1, 1)], [(2, 2)]], [[(3, 3)], [(4, 4)]]]

# Generated at 2022-06-17 16:43:02.703263
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2 import driver
    from . import token

    g = driver.load_grammar("Grammar.txt")
    g.dump("Grammar.pickle")
    g2 = Grammar()
    g2.load("Grammar.pickle")
    assert g2.symbol2number == g.symbol2number
    assert g2.number2symbol == g.number2symbol
    assert g2.states == g.states
    assert g2.dfas == g.dfas
    assert g2.labels == g.labels
    assert g2.keywords == g.keywords
    assert g2.tokens == g.tokens
    assert g2.symbol2label == g.symbol2label
    assert g2.start == g.start

# Generated at 2022-06-17 16:43:12.617576
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert grammar.symbol2number["and_expr"] == 258
    assert grammar.number2symbol[258] == "and_expr"
    assert grammar.states[0][0][0][0] == 1
    assert grammar.dfas[258][0][0][0][0] == 1
    assert grammar.labels[0] == (0, "EMPTY")
    assert grammar.keywords["False"] == 1
    assert grammar.tokens[token.NAME] == 2
    assert grammar.symbol2label["and_expr"] == 258
    assert grammar.start == 256
    assert grammar.async_keywords == False

# Generated at 2022-06-17 16:43:24.205465
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    import unittest
    import shutil

    class GrammarTestCase(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.grammar = Grammar()
            self.grammar.symbol2number = {'symbol': 1}
            self.grammar.number2symbol = {1: 'symbol'}
            self.grammar.states = [[(0, 1)]]
            self.grammar.dfas = {1: ([(0, 1)], {1: 1})}
            self.grammar.labels = [(0, 'EMPTY')]
            self.grammar.keywords = {'keyword': 1}

# Generated at 2022-06-17 16:43:29.622612
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    import io

    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[[(0, 1)], [(1, 2)]]]
    g.dfas = {1: ([[(0, 1)], [(1, 2)]], {1: 1}), 2: ([[(0, 1)], [(1, 2)]], {1: 1})}
    g.labels = [(0, 'EMPTY'), (1, None), (2, None)]
    g.keywords = {'foo': 1, 'bar': 2}
    g.tokens = {1: 1, 2: 2}

# Generated at 2022-06-17 16:43:39.141432
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import io
    import unittest
    import unittest.mock

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[(1, 2)]]
            g.dfas = {1: ([(1, 2)], {1: 1})}
            g.labels = [(1, 'foo')]
            g.keywords = {'foo': 1}
            g.tokens = {1: 1}
            g.symbol2label = {'foo': 1}
            g.start = 1
            g.async_keywords = False


# Generated at 2022-06-17 16:43:44.342245
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import unittest

    class GrammarTest(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.dump(sys.stdout)

    unittest.main()

# Generated at 2022-06-17 16:43:54.316734
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import unittest
    from . import pgen2

    class Grammar_load_TestCase(unittest.TestCase):
        def test_load(self):
            # Test loading of pickle file
            g = pgen2.driver.load_grammar(sys.version_info)
            g.dump("Grammar.pickle")
            h = Grammar()
            h.load("Grammar.pickle")
            self.assertEqual(g.symbol2number, h.symbol2number)
            self.assertEqual(g.number2symbol, h.number2symbol)
            self.assertEqual(g.states, h.states)
            self.assertEqual(g.dfas, h.dfas)

# Generated at 2022-06-17 16:43:58.673716
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    g.report()

# Generated at 2022-06-17 16:44:05.693699
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle

    class TestGrammarLoad(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[[(1, 1)]]]
            g.dfas = {1: ([[(1, 1)]], {1: 1})}
            g.labels = [(1, 'foo')]
            g.keywords = {'foo': 1}
            g.tokens = {1: 1}
            g.symbol2label = {'foo': 1}
            g.start = 1
            g.async_keywords = False


# Generated at 2022-06-17 16:44:21.418480
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    import unittest

    from . import pgen2

    class Grammar_dump_TestCase(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.filename = os.path.join(self.tempdir, "grammar.pickle")

        def tearDown(self):
            import shutil

            shutil.rmtree(self.tempdir)

        def test_dump(self):
            grammar = pgen2.grammar.Grammar()
            grammar.dump(self.filename)
            with open(self.filename, "rb") as f:
                d = pickle.load(f)
            self.assertEqual(d["symbol2number"], {})

# Generated at 2022-06-17 16:44:28.526213
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2
    from . import conv

    # Create a grammar object
    g = Grammar()

    # Load the grammar tables
    g.load(conv.__file__.replace(".pyc", ".pkl"))

    # Create a parser object
    p = pgen2.Parser(g)

    # Parse a string
    p.parse("print(1)")

# Generated at 2022-06-17 16:44:36.714536
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2
    from . import tokenize
    from . import token

    # Create a grammar object
    g = pgen2.driver.load_grammar("Grammar/Grammar")
    assert g.start == g.symbol2number["file_input"]

    # Dump the grammar tables to a pickle file
    g.dump("Grammar/Grammar.pickle")

    # Create a new grammar object
    g2 = Grammar()
    g2.load("Grammar/Grammar.pickle")

    # Verify that the new grammar object is the same as the old one
    assert g2.start == g2.symbol2number["file_input"]
    assert g2.start == g.start
    assert g2.symbol2number == g.symbol2number

# Generated at 2022-06-17 16:44:50.345033
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'a': 1}
            g.number2symbol = {1: 'a'}
            g.states = [[[(0, 1)]]]
            g.dfas = {1: ([[(0, 1)]], {1: 1}), 2: ([[(0, 1)]], {1: 1})}
            g.labels = [(0, 'EMPTY'), (1, None), (2, None)]
            g.keywords = {'a': 1, 'b': 2}
            g.tokens = {1: 1, 2: 2}

# Generated at 2022-06-17 16:44:58.907482
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2
    from .pgen2 import tokenize

    g = Grammar()
    g.load(pgen2.grammar_file)

    # Test that the grammar can be used to parse itself.
    pdict = g.pgen()
    t = tokenize.generate_tokens(open(pgen2.grammar_file).readline)
    try:
        pdict["file_input"].parse(t, g)
    except tokenize.TokenError:
        pass


# Generated at 2022-06-17 16:45:07.349266
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {"a": 1, "b": 2}
    g.number2symbol = {1: "a", 2: "b"}
    g.states = [[(0, 0)], [(0, 1)]]
    g.dfas = {1: (g.states[0], {}), 2: (g.states[1], {})}
    g.labels = [(0, "EMPTY"), (1, None), (2, None)]
    g.keywords = {}
    g.tokens = {}
    g.symbol2label = {}
    g.start = 256
    g.async_keywords = False
    g.dump("/tmp/test_Grammar_dump")
    g2 = Grammar()

# Generated at 2022-06-17 16:45:17.372196
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import os
    import shutil

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.grammar = Grammar()
            self.grammar.symbol2number = {'a': 1, 'b': 2}
            self.grammar.number2symbol = {1: 'a', 2: 'b'}
            self.grammar.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]

# Generated at 2022-06-17 16:45:24.863922
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.start == 256
    assert g.number2symbol[256] == "file_input"
    assert g.symbol2number["file_input"] == 256
    assert g.number2symbol[257] == "stmt"
    assert g.symbol2number["stmt"] == 257
    assert g.number2symbol[258] == "simple_stmt"
    assert g.symbol2number["simple_stmt"] == 258
    assert g.number2symbol[259] == "small_stmt"
    assert g.symbol2number["small_stmt"] == 259

# Generated at 2022-06-17 16:45:31.316913
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2
    from . import conv
    from . import tokenize

    # Create a grammar object
    grammar = Grammar()

    # Load the grammar tables
    pgen2.driver.load_grammar("Grammar/Grammar", grammar)

    # Create a parser object
    parser = conv.Parser(grammar)

    # Create a tokenizer object
    tokenizer = tokenize.tokenize(b"x = 1 + 2")

    # Parse the input
    tree = parser.parse(tokenizer)

    # Dump the parse tree
    tree.dump()


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:45:40.273926
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2
    from . import tokenize
    from . import parse

    g = pgen2.driver.load_grammar("Grammar.txt")
    g.dump("Grammar.pickle")
    g2 = Grammar()
    g2.load("Grammar.pickle")
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label

# Generated at 2022-06-17 16:45:58.588907
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import io
    import os
    import tempfile
    import sys

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'foo': 1, 'bar': 2}
            g.number2symbol = {1: 'foo', 2: 'bar'}
            g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            g.dfas = {1: (g.states[0], {1: 1, 2: 1}), 2: (g.states[1], {3: 1, 4: 1})}

# Generated at 2022-06-17 16:46:09.456591
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import os
    import sys
    import unittest

    class GrammarTestCase(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'foo': 1, 'bar': 2}
            g.number2symbol = {1: 'foo', 2: 'bar'}
            g.states = [[(0, 1)], [(0, 2)]]
            g.dfas = {1: (g.states[0], {1: 1}), 2: (g.states[1], {2: 1})}
            g.labels = [(0, 'EMPTY'), (1, None), (2, None)]
            g.keywords = {'foo': 1, 'bar': 2}

# Generated at 2022-06-17 16:46:21.213664
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    from . import token

    # Create a Grammar object
    g = Grammar()
    g.symbol2number = {'foo': 256, 'bar': 257}
    g.number2symbol = {256: 'foo', 257: 'bar'}
    g.states = [[[(0, 0)], [(1, 1)]]]
    g.dfas = {256: ([[(0, 0)], [(1, 1)]], {1: 1}), 257: ([[(0, 0)], [(1, 1)]], {1: 1})}
    g.labels = [(0, 'EMPTY'), (1, None)]
    g.keywords = {'foo': 1}
    g.tokens = {token.NAME: 1}

# Generated at 2022-06-17 16:46:23.853213
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.pickle")
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:46:35.596204
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen2
    from . import tokenize
    from . import token

    # Create a grammar object
    g = pgen2.driver.load_grammar("Grammar/Grammar")

    # Create a temporary file
    with tempfile.NamedTemporaryFile(delete=False) as f:
        filename = f.name

    # Dump the grammar object to the temporary file
    g.dump(filename)

    # Load the grammar object from the temporary file
    g2 = Grammar()
    g2.load(filename)

    # Remove the temporary file
    os.remove(filename)

    # Create a tokenize object
    t = tokenize.generate_tokens(open(__file__).readline)

    # Create a parse object

# Generated at 2022-06-17 16:46:49.896100
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import io
    import unittest
    from test.support import captured_stdout, captured_stderr

    class GrammarTestCase(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[(1, 2), (2, 3)], [(3, 4), (4, 5)]]
            g.dfas = {1: ([(1, 2), (2, 3)], {1: 1, 2: 1}),
                      2: ([(3, 4), (4, 5)], {3: 1, 4: 1})}

# Generated at 2022-06-17 16:47:01.021099
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    from io import BytesIO
    from . import pgen2
    from . import token

    # Create a grammar object
    g = pgen2.driver.load_grammar("Grammar/Grammar")

    # Dump the grammar object to a pickle file
    fd, filename = tempfile.mkstemp()
    os.close(fd)
    g.dump(filename)

    # Load the grammar object from the pickle file
    g2 = Grammar()
    g2.load(filename)
    os.remove(filename)

    # Check that the grammar objects are equal
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states

# Generated at 2022-06-17 16:47:11.221917
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import io
    import os
    import tempfile
    import shutil

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.filename = os.path.join(self.tempdir, "grammar.pickle")
            self.grammar = Grammar()
            self.grammar.symbol2number = {'foo': 1, 'bar': 2}
            self.grammar.number2symbol = {1: 'foo', 2: 'bar'}
            self.grammar.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]

# Generated at 2022-06-17 16:47:17.028756
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.symbol2number["and_expr"] == 258
    assert g.number2symbol[258] == "and_expr"
    assert g.symbol2number["arglist"] == 259
    assert g.number2symbol[259] == "arglist"
    assert g.symbol2number["argument"] == 260
    assert g.number2symbol[260] == "argument"
    assert g.symbol2number["arith_expr"] == 261
    assert g.number2symbol[261] == "arith_expr"

# Generated at 2022-06-17 16:47:27.448749
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen2
    from . import tokenize

    g = pgen2.driver.load_grammar("Grammar.txt")
    g.dump("Grammar.pickle")
    g2 = Grammar()
    g2.load("Grammar.pickle")
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label
    assert g.start == g2.start
   