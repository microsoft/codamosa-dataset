

# Generated at 2022-06-17 16:38:13.085444
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == 0
    assert g.states[0][0][0][1] == 1
    assert g.dfas[257][0][0][0][0] == 0
    assert g.dfas[257][0][0][0][1] == 1
    assert g.labels[0][0] == 0
    assert g.labels[0][1] == "EMPTY"
    assert g.keywords["and"] == 0
    assert g.tokens[token.NAME] == 0

# Generated at 2022-06-17 16:38:23.348940
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("test_Grammar_dump.pickle")
    g2 = Grammar()
    g2.load("test_Grammar_dump.pickle")
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label
    assert g.start == g2.start
    assert g.async_keywords == g2.async_keywords

# Generated at 2022-06-17 16:38:35.367698
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'foo': 1}
    g.number2symbol = {1: 'foo'}
    g.states = [[(1, 2)]]
    g.dfas = {1: ([(1, 2)], {2: 1})}
    g.labels = [(1, 'foo')]
    g.keywords = {'foo': 1}
    g.tokens = {1: 1}
    g.symbol2label = {'foo': 1}
    g.start = 256
    g.async_keywords = False

    with tempfile.TemporaryDirectory() as tmpdir:
        filename = os.path.join(tmpdir, 'grammar.pickle')
        g.dump(filename)
        g2 = Grammar()
        g

# Generated at 2022-06-17 16:38:39.225625
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            # Create a grammar object
            g = Grammar()
            # Create a pickle string
            pkl = pickle.dumps(g, pickle.HIGHEST_PROTOCOL)
            # Load the grammar from the pickle string
            g.loads(pkl)
            # Create a pickle file
            with io.BytesIO() as f:
                pickle.dump(g, f, pickle.HIGHEST_PROTOCOL)
                f.seek(0)
                # Load the grammar from the pickle file
                g.load(f)

    unittest.main()

# Generated at 2022-06-17 16:38:47.448171
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import sys
    import unittest
    from . import pgen2

    class Grammar_dump_TestCase(unittest.TestCase):
        def test_Grammar_dump(self):
            # Create a Grammar object
            grammar = pgen2.driver.load_grammar(sys.version_info)
            # Dump the grammar tables to a pickle file
            filename = "Grammar_dump.pickle"
            grammar.dump(filename)
            # Load the grammar tables from the pickle file
            grammar2 = Grammar()
            grammar2.load(filename)
            # Remove the pickle file
            os.remove(filename)
            # Assert that the two Grammar objects are equal
            self.assertEqual(grammar, grammar2)

    unittest.main()

#

# Generated at 2022-06-17 16:38:59.460647
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    from io import BytesIO

    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[[(1, 2), (3, 4)], [(5, 6), (7, 8)]]]
    g.dfas = {1: ([[(1, 2), (3, 4)], [(5, 6), (7, 8)]], {1: 1, 2: 1}), 2: ([[(1, 2), (3, 4)], [(5, 6), (7, 8)]], {1: 1, 2: 1})}
    g.labels = [(1, 'foo'), (2, 'bar')]

# Generated at 2022-06-17 16:39:02.928834
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.pickle")
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:39:09.016748
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.pickle")
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == 0
    assert g.dfas[257][0][0][0][0] == 0
    assert g.labels[0][0] == 0
    assert g.keywords["and"] == 0
    assert g.tokens[0] == 0
    assert g.start == 256

# Generated at 2022-06-17 16:39:13.110374
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:39:23.914357
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import os
    import tempfile
    import shutil
    import sys

    class GrammarTestCase(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.filename = os.path.join(self.tempdir, "grammar.pickle")

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_dump(self):
            grammar = Grammar()
            grammar.dump(self.filename)
            with open(self.filename, "rb") as f:
                d = pickle.load(f)
            self.assertEqual(d["symbol2number"], {})
            self.assertEqual(d["number2symbol"], {})
           

# Generated at 2022-06-17 16:39:34.172215
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[[(0, 1)]]]
            g.dfas = {1: ([[(0, 1)]], {1: 1})}
            g.labels = [(0, 'EMPTY'), (1, None)]
            g.keywords = {'foo': 1}
            g.tokens = {1: 1}
            g.symbol2label = {'foo': 1}
            g.start = 256
            g.async_keywords = False


# Generated at 2022-06-17 16:39:37.659531
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test that Grammar.load() works
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    g.report()

# Generated at 2022-06-17 16:39:50.169505
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == 0
    assert g.dfas[257][0][0][0][0] == 0
    assert g.labels[0][0] == 0
    assert g.keywords["and"] == 0
    assert g.tokens[0] == 0
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:39:58.482197
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import sys
    import os
    import pickle
    import tempfile
    from . import pgen2

    class TestGrammarDump(unittest.TestCase):
        def test_dump(self):
            g = pgen2.grammar.Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[[(1, 2)]]]
            g.dfas = {1: ([[(1, 2)]], {2: 1})}
            g.labels = [(1, 'foo')]
            g.keywords = {'foo': 1}
            g.tokens = {1: 1}
            g.symbol2label = {'foo': 1}
           

# Generated at 2022-06-17 16:40:01.717853
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.txt"))
    g.report()

# Generated at 2022-06-17 16:40:04.038601
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/tmp/grammar.pkl")
    g.load("/tmp/grammar.pkl")
    g.report()

# Generated at 2022-06-17 16:40:11.097597
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import tempfile
    import os
    import pickle
    import shutil
    import sys

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.temp_file = os.path.join(self.temp_dir, "test_grammar.pickle")
            self.grammar = Grammar()
            self.grammar.symbol2number = {"a": 1, "b": 2}
            self.grammar.number2symbol = {1: "a", 2: "b"}
            self.grammar.states = [[(1, 1), (2, 2)], [(3, 3), (4, 4)]]

# Generated at 2022-06-17 16:40:15.478004
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.pickle")
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:40:25.531494
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            g.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 2}), 2: ([(5, 6), (7, 8)], {3: 3, 4: 4})}
            g.labels = [(1, 'a'), (2, 'b')]

# Generated at 2022-06-17 16:40:32.324622
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import unittest
    import pickle

    class GrammarTest(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.load(sys.executable)
            self.assertRaises(pickle.UnpicklingError, g.loads, b"")

    unittest.main()


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:40:44.549912
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.start == 256
    assert g.symbol2number["and"] == 258
    assert g.number2symbol[258] == "and"
    assert g.keywords["and"] == 258
    assert g.tokens[token.NAME] == 257
    assert g.labels[257] == (token.NAME, None)
    assert g.labels[258] == (token.NAME, "and")
    assert g.symbol2label["and"] == 258
    assert g.states[0][0] == [(257, 1), (258, 2)]
    assert g.states[0][1] == [(0, 1)]

# Generated at 2022-06-17 16:40:48.152910
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pkl"))
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:40:59.798355
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import sys
    import os
    import tempfile
    from io import BytesIO

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.g = Grammar()
            self.g.symbol2number = {'foo': 1, 'bar': 2}
            self.g.number2symbol = {1: 'foo', 2: 'bar'}
            self.g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]

# Generated at 2022-06-17 16:41:01.923135
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pkl"))
    g.report()

# Generated at 2022-06-17 16:41:07.194078
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.load(pgen2.__file__.rstrip("c"))
            self.assertEqual(g.start, g.symbol2number["file_input"])

    unittest.main()

# Generated at 2022-06-17 16:41:20.023171
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import unittest
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            # Create a grammar object
            g = pgen2.driver.load_grammar(sys.executable)
            # Dump the grammar tables to a pickle file
            g.dump("Grammar.pickle")
            # Load the grammar tables from the pickle file
            g2 = Grammar()
            g2.load("Grammar.pickle")
            # Compare the two grammar objects
            self.assertEqual(g.symbol2number, g2.symbol2number)
            self.assertEqual(g.number2symbol, g2.number2symbol)
            self.assertEqual(g.states, g2.states)

# Generated at 2022-06-17 16:41:28.411698
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import io
    import os
    import sys
    import tempfile
    import unittest

    class GrammarTestCase(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[[(1, 2)], [(1, 3)]]]
            g.dfas = {1: ([[(1, 2)], [(1, 3)]], {1: 1})}
            g.labels = [(1, 'foo')]
            g.keywords = {'foo': 1}
            g.tokens = {1: 1}
            g.symbol2label = {'foo': 1}

# Generated at 2022-06-17 16:41:33.074683
# Unit test for method load of class Grammar
def test_Grammar_load():
    import io
    import pickle
    import unittest

    from . import pgen2

    class Grammar_load_TestCase(unittest.TestCase):
        def test_load(self):
            g = pgen2.Grammar()
            g.load(io.BytesIO(pickle.dumps(g, pickle.HIGHEST_PROTOCOL)))

    unittest.main()

# Generated at 2022-06-17 16:41:43.717883
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import pickle
    import unittest

    class GrammarTestCase(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[(0, 1)]]
            g.dfas = {1: ([[(0, 1)]], {1: 1})}
            g.labels = [(0, 'EMPTY')]
            g.keywords = {'foo': 1}
            g.tokens = {1: 1}
            g.symbol2label = {'foo': 1}
            g.start = 256
            g.async_keywords = False

            f = io.BytesIO()
            g

# Generated at 2022-06-17 16:41:54.494604
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            grammar = Grammar()
            grammar.symbol2number = {"a": 1}
            grammar.number2symbol = {1: "a"}
            grammar.states = [[[(1, 2)], [(2, 3)]]]
            grammar.dfas = {1: ([[(1, 2)], [(2, 3)]], {1: 1})}
            grammar.labels = [(1, "a"), (2, "b")]
            grammar.keywords = {"a": 1}
            grammar.tokens = {1: 1}
            grammar.symbol2label = {"a": 1}
            grammar.start = 1
            grammar.async_key

# Generated at 2022-06-17 16:42:12.844850
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2
    from . import tokenize
    from . import token

    # Test the load() method of the Grammar class.
    #
    # This test is a bit tricky because we want to test load() without
    # actually having a pickle file to load.  So we create a temporary
    # pickle file, and then we monkey-patch the load() method to read
    # from that file.  The monkey-patching is done by replacing the
    # load() method with a function that does the monkey-patching and
    # then calls the original load().

    # Create a temporary pickle file.
    with tempfile.NamedTemporaryFile() as f:
        pickle_file = f.name

    # Create a Grammar instance and load the pickle file.
    grammar = pgen2.driver.load_grammar

# Generated at 2022-06-17 16:42:15.004780
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/tmp/Grammar.test")
    g.load("/tmp/Grammar.test")

# Generated at 2022-06-17 16:42:18.971754
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:42:22.794391
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("foo.pkl")
    g.load("foo.pkl")
    g.report()

if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-17 16:42:25.212906
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("test.pkl")
    g.load("test.pkl")
    g.report()


# Generated at 2022-06-17 16:42:33.259159
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import shutil
    import tempfile
    from . import pgen2

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-17 16:42:42.971080
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["single_input"] == 257
    assert g.number2symbol[257] == "single_input"
    assert g.states[0][0][0][0] == token.NEWLINE
    assert g.dfas[257][0][0][0][0] == token.NEWLINE
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["False"] == 1
    assert g.tokens[token.NEWLINE] == 0
    assert g.symbol2label["single_input"] == 257
    assert g.start == 257

# Generated at 2022-06-17 16:42:51.583625
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[257][0][0][0][0] == token.NAME
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["if"] == 1
    assert g.tokens[token.NAME] == 1
    assert g.symbol2label["and"] == 257
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:43:01.532397
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io
    import sys

    class Grammar_load_TestCase(unittest.TestCase):
        def test_load(self):
            # Test the method load of class Grammar
            # This test is not complete, because the pickle file is not
            # available.
            g = Grammar()
            g.load(io.BytesIO(pickle.dumps({"a": 1})))
            self.assertEqual(g.a, 1)

    unittest.main()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:43:11.630904
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import os
    import pickle
    import tempfile
    from . import token
    from . import pgen2

    # Create a temporary file
    fd, filename = tempfile.mkstemp()
    os.close(fd)

    # Create a Grammar object
    g = pgen2.driver.load_grammar(sys.version_info)

    # Dump the Grammar object to a pickle file
    g.dump(filename)

    # Load the Grammar object from the pickle file
    g2 = Grammar()
    g2.load(filename)

    # Check that the Grammar objects are equal
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
   

# Generated at 2022-06-17 16:43:31.579879
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pkl"))
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:43:40.172544
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """
    Test that Grammar.dump() writes a pickle file that can be loaded
    by Grammar.load().
    """
    g = Grammar()
    g.symbol2number = {"foo": 1, "bar": 2}
    g.number2symbol = {1: "foo", 2: "bar"}
    g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
    g.dfas = {1: (g.states[0], {1: 1, 2: 1}), 2: (g.states[1], {3: 1, 4: 1})}
    g.labels = [(1, "foo"), (2, "bar"), (3, "baz"), (4, "qux")]

# Generated at 2022-06-17 16:43:43.671923
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pkl"))
    g.report()

# Generated at 2022-06-17 16:43:52.629823
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import tempfile
    import os
    import pickle
    import shutil
    import sys
    import io
    import contextlib

    class Grammar_dump_TestCase(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.temp_file = os.path.join(self.temp_dir, "temp.pickle")

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_dump(self):
            g = Grammar()
            g.dump(self.temp_file)
            with open(self.temp_file, "rb") as f:
                d = pickle.load(f)

# Generated at 2022-06-17 16:44:00.072025
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import io
    import os

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[(1, 1), (2, 2)], [(3, 3), (4, 4)]]
            g.dfas = {1: ([(1, 1), (2, 2)], {1: 1, 2: 2}), 2: ([(3, 3), (4, 4)], {3: 3, 4: 4})}

# Generated at 2022-06-17 16:44:04.038821
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    from . import pgen2
    from . import tokenize

    # Create a grammar object
    g = pgen2.driver.load_grammar("Grammar/Grammar")

    # Dump the grammar object to a pickle file
    g.dump("Grammar/Grammar.pickle")

    # Load the grammar object from the pickle file
    with open("Grammar/Grammar.pickle", "rb") as f:
        g2 = pickle.load(f)

    # Compare the two grammar objects
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas

# Generated at 2022-06-17 16:44:14.442149
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pkl"))
    assert g.symbol2number["and_expr"] == 258
    assert g.number2symbol[258] == "and_expr"
    assert g.states[0][0][0][0] == 1
    assert g.dfas[258][0][0][0][0] == 1
    assert g.labels[1][0] == token.NAME
    assert g.keywords["False"] == 3
    assert g.tokens[token.NAME] == 1
    assert g.symbol2label["and_expr"] == 258
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:44:18.198724
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("test.pkl")
    g.load("test.pkl")
    g.report()

if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-17 16:44:24.858545
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    import unittest

    class GrammarTestCase(unittest.TestCase):
        def setUp(self):
            self.g = Grammar()
            self.g.symbol2number = {'a': 1, 'b': 2}
            self.g.number2symbol = {1: 'a', 2: 'b'}
            self.g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            self.g.dfas = {1: ([(1, 2), (3, 4)], {1: 1}),
                           2: ([(5, 6), (7, 8)], {1: 1})}

# Generated at 2022-06-17 16:44:34.232180
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[257][0][0][0][0] == token.NAME
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["and"] == 1
    assert g.tokens[token.NAME] == 1
    assert g.start == 256

# Generated at 2022-06-17 16:45:16.445902
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 256
    assert g.number2symbol[257] == "as"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[258][0][0][0][0] == token.NAME
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["False"] == 1
    assert g.tokens[token.NAME] == 2
    assert g.symbol2label["and"] == 3
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:45:24.361784
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import sys
    import unittest
    from . import pgen2

    class Grammar_dump_TestCase(unittest.TestCase):
        def setUp(self):
            self.dir = os.path.dirname(__file__)
            self.file = os.path.join(self.dir, "Grammar.dump")
            self.g = pgen2.driver.load_grammar(os.path.join(self.dir, "Grammar.txt"))
            self.g.dump(self.file)

        def tearDown(self):
            try:
                os.unlink(self.file)
            except OSError:
                pass

        def test_load(self):
            g = Grammar()
            g.load(self.file)
            self.assertE

# Generated at 2022-06-17 16:45:33.267981
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import pickle
    from . import pgen2

    p = pgen2.driver.load_grammar("Grammar.txt")
    f = io.BytesIO()
    p.dump(f)
    f.seek(0)
    p2 = Grammar()
    p2.loads(f.read())
    assert p2.symbol2number == p.symbol2number
    assert p2.number2symbol == p.number2symbol
    assert p2.states == p.states
    assert p2.dfas == p.dfas
    assert p2.labels == p.labels
    assert p2.keywords == p.keywords
    assert p2.tokens == p.tokens
    assert p2.symbol2label == p.symbol2label
   

# Generated at 2022-06-17 16:45:40.810986
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'foo': 1, 'bar': 2}
            g.number2symbol = {1: 'foo', 2: 'bar'}
            g.states = [[(1, 2)], [(3, 4)]]
            g.dfas = {1: ([(1, 2)], {1: 1}), 2: ([(3, 4)], {3: 1})}
            g.labels = [(1, None), (2, None), (3, None), (4, None)]
            g.keywords = {'foo': 1, 'bar': 2}

# Generated at 2022-06-17 16:45:46.326307
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import unittest
    from io import BytesIO
    from . import pgen2

    class GrammarTestCase(unittest.TestCase):
        def test_dump(self):
            g = pgen2.grammar.Grammar()
            g.load(pgen2.pgen.__file__)
            f = BytesIO()
            g.dump(f)
            f.seek(0)
            g2 = pgen2.grammar.Grammar()
            g2.loads(f.read())
            self.assertEqual(g.symbol2number, g2.symbol2number)
            self.assertEqual(g.number2symbol, g2.number2symbol)
            self.assertEqual(g.states, g2.states)

# Generated at 2022-06-17 16:45:56.912655
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = pgen2.driver.load_grammar("Grammar.txt")
            g.dump("Grammar.pickle")
            g2 = Grammar()
            g2.load("Grammar.pickle")
            self.assertEqual(g.symbol2number, g2.symbol2number)
            self.assertEqual(g.number2symbol, g2.number2symbol)
            self.assertEqual(g.states, g2.states)
            self.assertEqual(g.dfas, g2.dfas)
            self.assertEqual(g.labels, g2.labels)

# Generated at 2022-06-17 16:46:08.160261
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][1] == 1
    assert g.dfas[257][0][0][0][1] == 1
    assert g.labels[0][1] == "EMPTY"
    assert g.keywords["and"] == 257
    assert g.tokens[token.NAME] == 258
    assert g.symbol2label["and"] == 257
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:46:11.482297
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2
    from . import conv

    g = Grammar()
    g.load(pgen2.grammar_file)
    g.report()
    g = Grammar()
    g.loads(conv.grammar_pickle)
    g.report()

# Generated at 2022-06-17 16:46:23.303949
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2
    from . import pgen2_grammar

    g = Grammar()
    g.load(pgen2.pickle_file)
    assert g.symbol2number == pgen2_grammar.symbol2number
    assert g.number2symbol == pgen2_grammar.number2symbol
    assert g.states == pgen2_grammar.states
    assert g.dfas == pgen2_grammar.dfas
    assert g.labels == pgen2_grammar.labels
    assert g.keywords == pgen2_grammar.keywords
    assert g.tokens == pgen2_grammar.tokens
    assert g.symbol2label == pgen2_grammar.symbol2label
    assert g.start == pgen2_

# Generated at 2022-06-17 16:46:25.914823
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")
    g.report()


if __name__ == "__main__":
    test_Grammar_load()