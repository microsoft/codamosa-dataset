

# Generated at 2022-06-17 16:38:22.905902
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import os
    import tempfile

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.g = Grammar()
            self.g.symbol2number = {'foo': 1, 'bar': 2}
            self.g.number2symbol = {1: 'foo', 2: 'bar'}
            self.g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            self.g.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 1}),
                           2: ([(5, 6), (7, 8)], {3: 1, 4: 1})}

# Generated at 2022-06-17 16:38:32.327182
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == 1
    assert g.dfas[257][0][0][0][0] == 1
    assert g.labels[1] == (1, None)
    assert g.keywords["and"] == 1
    assert g.tokens[1] == 1
    assert g.start == 256

# Generated at 2022-06-17 16:38:42.820939
# Unit test for method load of class Grammar
def test_Grammar_load():
    import io
    import pickle
    import unittest

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'foo': 1, 'bar': 2}
            g.number2symbol = {1: 'foo', 2: 'bar'}
            g.states = [[[(1, 2)], [(3, 4)]]]
            g.dfas = {1: ([[(1, 2)], [(3, 4)]], {1: 1, 2: 2}), 2: ([[(5, 6)]], {3: 3})}
            g.labels = [(1, 'foo'), (2, 'bar'), (3, 'baz')]

# Generated at 2022-06-17 16:38:51.480074
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[258] == "assert"
    assert g.states[0][0][0][0] == 1
    assert g.dfas[258][0][0][0][0] == 1
    assert g.labels[1][0] == 1
    assert g.keywords["False"] == 1
    assert g.tokens[token.NAME] == 1
    assert g.symbol2label["and"] == 257
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:38:55.597683
# Unit test for method load of class Grammar
def test_Grammar_load():
    """
    >>> g = Grammar()
    >>> g.load(__file__.replace('.py', '.pkl'))
    """


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-17 16:39:06.709571
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[(1, 2)], [(3, 4)]]
            g.dfas = {1: ([(1, 2)], {1: 1}), 2: ([(3, 4)], {3: 1})}
            g.labels = [(1, 'foo'), (2, None), (3, 'bar'), (4, None)]
            g.keywords = {'foo': 1, 'bar': 3}
            g.tokens = {1: 1, 2: 3}
            g.symbol

# Generated at 2022-06-17 16:39:18.696144
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2
    from . import pgen


# Generated at 2022-06-17 16:39:28.020544
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import tempfile
    import unittest

    from . import grammar

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.filename = os.path.join(self.tempdir, "grammar.pickle")
            self.g = grammar.Grammar()
            self.g.dump(self.filename)

        def tearDown(self):
            import shutil

            shutil.rmtree(self.tempdir)

        def test_load(self):
            g = grammar.Grammar()
            g.load(self.filename)
            self.assertEqual(g.symbol2number, self.g.symbol2number)

# Generated at 2022-06-17 16:39:33.007189
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import tempfile
    import os
    import shutil

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.filename = os.path.join(self.temp_dir, "grammar.pickle")

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_dump(self):
            g = Grammar()
            g.dump(self.filename)
            with open(self.filename, "rb") as f:
                d = pickle.load(f)
            self.assertEqual(d, g.__dict__)

    unittest.main()

# Generated at 2022-06-17 16:39:38.149050
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import unittest.mock

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.dump("test_dump")
            g.dump("test_dump")

    unittest.main()

# Generated at 2022-06-17 16:39:51.076918
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    from . import token

    # mypyc generates objects that don't have a __dict__, but they
    # do have __getstate__ methods that will return an equivalent
    # dictionary
    if hasattr(token, "__dict__"):
        d = token.__dict__
    else:
        d = token.__getstate__()  # type: ignore

    with tempfile.NamedTemporaryFile(delete=False) as f:
        pickle.dump(d, f, pickle.HIGHEST_PROTOCOL)
    os.remove(f.name)

# Generated at 2022-06-17 16:39:59.003602
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io
    import os

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.g = Grammar()
            self.g.symbol2number = {'foo': 1}
            self.g.number2symbol = {1: 'foo'}
            self.g.states = [[(1, 2)]]
            self.g.dfas = {1: (1, {1: 1})}
            self.g.labels = [(1, 'foo')]
            self.g.start = 1
            self.g.keywords = {'foo': 1}
            self.g.tokens = {1: 1}
            self.g.symbol2label = {'foo': 1}


# Generated at 2022-06-17 16:40:05.362034
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    from . import pgen2
    from . import pgen2_grammar

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = pgen2_grammar.Grammar()
            g.load(pgen2.grammar_file)
            g.dump(pgen2.grammar_file)

    unittest.main(module=__name__, exit=False)

# Generated at 2022-06-17 16:40:16.224423
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == 1
    assert g.dfas[257][0][0][0][0] == 1
    assert g.labels[1] == (1, None)
    assert g.keywords["and"] == 1
    assert g.tokens[1] == 1
    assert g.start == 257

# Generated at 2022-06-17 16:40:26.183593
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[[(1, 1), (2, 2)], [(3, 3), (4, 4)]]]
    g.dfas = {1: ([[(1, 1), (2, 2)], [(3, 3), (4, 4)]], {1: 1, 2: 1, 3: 1, 4: 1}),
              2: ([[(1, 1), (2, 2)], [(3, 3), (4, 4)]], {1: 1, 2: 1, 3: 1, 4: 1})}

# Generated at 2022-06-17 16:40:32.646243
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.g = Grammar()
            self.g.symbol2number = {'foo': 1, 'bar': 2}
            self.g.number2symbol = {1: 'foo', 2: 'bar'}
            self.g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            self.g.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 2}),
                           2: ([(5, 6), (7, 8)], {3: 3, 4: 4})}

# Generated at 2022-06-17 16:40:43.399132
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    from . import pgen2
    from . import tokenizer

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = pgen2.driver.load_grammar("Grammar.txt")
            g.dump("Grammar.pickle")
            g2 = Grammar()
            g2.load("Grammar.pickle")
            self.assertEqual(g.symbol2number, g2.symbol2number)
            self.assertEqual(g.number2symbol, g2.number2symbol)
            self.assertEqual(g.states, g2.states)
            self.assertEqual(g.dfas, g2.dfas)

# Generated at 2022-06-17 16:40:51.687432
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import tempfile
    import os
    import shutil
    import sys
    import io
    import pgen2.pgen
    import pgen2.parse
    import pgen2.driver

    class TestGrammarDump(unittest.TestCase):
        def setUp(self):
            self.dir = tempfile.mkdtemp()
            self.filename = os.path.join(self.dir, "grammar.pickle")
            self.pgen = pgen2.pgen.Pgen(pgen2.parse.grammar)
            self.pgen.dump(self.filename)
            self.pgen2 = pgen2.pgen.Pgen(pgen2.parse.grammar)
            self.pgen2.load(self.filename)



# Generated at 2022-06-17 16:41:02.448022
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[257][0][0][0][0] == token.NAME
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["False"] == 1
    assert g.tokens[token.NAME] == 2
    assert g.symbol2label["and"] == 257
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:41:11.396947
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import tempfile
    import os
    import shutil
    import sys

    class GrammarTestCase(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.filename = os.path.join(self.tempdir, "grammar.pickle")
            self.grammar = Grammar()
            self.grammar.symbol2number = {'a': 1, 'b': 2}
            self.grammar.number2symbol = {1: 'a', 2: 'b'}
            self.grammar.states = [[[(1, 1), (2, 2)], [(1, 3), (2, 4)]]]

# Generated at 2022-06-17 16:41:23.889391
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import unittest
    from unittest import mock

    class TestGrammar(Grammar):
        def __init__(self):
            super().__init__()
            self.symbol2number = {"a": 1}
            self.number2symbol = {1: "a"}
            self.states = [[[(1, 1)]]]
            self.dfas = {1: ([[(1, 1)]], {1: 1})}
            self.labels = [(1, "a")]
            self.keywords = {"a": 1}
            self.tokens = {1: 1}
            self.symbol2label = {"a": 1}
            self.start = 1
            self.async_keywords = False


# Generated at 2022-06-17 16:41:33.778989
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import tempfile
    import pickle
    from . import token

    # Create a temporary directory
    temp_dir = tempfile.TemporaryDirectory()
    temp_dir_name = temp_dir.name

    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir_name, delete=False)
    temp_file_name = temp_file.name

    # Create a Grammar object
    g = Grammar()

    # Populate the Grammar object
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[[(0, 1)], [(0, 2)]]]

# Generated at 2022-06-17 16:41:36.706358
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("test.pickle")
    g.load("test.pickle")
    g.report()

# Generated at 2022-06-17 16:41:49.647336
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import io
    import pickle

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[(1, 2)]]
            g.dfas = {1: ([(1, 2)], {1: 1})}
            g.labels = [(1, 'foo')]
            g.keywords = {'foo': 1}
            g.tokens = {1: 1}
            g.symbol2label = {'foo': 1}
            g.start = 256
            g.async_keywords = False

            f = io.BytesIO()
            g.dump

# Generated at 2022-06-17 16:41:56.512748
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[257][0][0][0][0] == token.NAME
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["False"] == 1
    assert g.tokens[token.NAME] == 2
    assert g.symbol2label["and"] == 257
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:42:05.782335
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    from . import pgen2
    from . import tokenize

    def test(grammar: Grammar, filename: str) -> None:
        grammar.dump(filename)
        grammar2 = Grammar()
        grammar2.load(filename)
        assert grammar.symbol2number == grammar2.symbol2number
        assert grammar.number2symbol == grammar2.number2symbol
        assert grammar.states == grammar2.states
        assert grammar.dfas == grammar2.dfas
        assert grammar.labels == grammar2.labels
        assert grammar.start == grammar2.start
        assert grammar.keywords == grammar2.keywords
        assert grammar.tokens == grammar2.tokens
        assert grammar.symbol2label == grammar2.symbol2label

# Generated at 2022-06-17 16:42:12.882881
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[257][0][0][0][0] == token.NAME
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["False"] == 1
    assert g.tokens[token.NAME] == 2
    assert g.symbol2label["and"] == 257
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:42:25.261831
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    import unittest

    class TestGrammar(Grammar):
        def __init__(self):
            super().__init__()
            self.symbol2number = {'a': 1, 'b': 2}
            self.number2symbol = {1: 'a', 2: 'b'}
            self.states = [[(1, 1), (2, 2)], [(3, 3), (4, 4)]]
            self.dfas = {1: ([(1, 1), (2, 2)], {1: 1, 2: 1}),
                         2: ([(3, 3), (4, 4)], {3: 1, 4: 1})}

# Generated at 2022-06-17 16:42:36.896764
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    from . import pgen2
    from . import tokenize
    from . import parse

    class TestGrammarDump(unittest.TestCase):
        def test_dump(self):
            grammar = pgen2.driver.load_grammar("Grammar.txt")
            # mypyc generates objects that don't have a __dict__, but they
            # do have __getstate__ methods that will return an equivalent
            # dictionary
            if hasattr(grammar, "__dict__"):
                d = grammar.__dict__
            else:
                d = grammar.__getstate__()  # type: ignore

            with tempfile.NamedTemporaryFile(delete=False) as f:
                grammar.dump(f.name)

# Generated at 2022-06-17 16:42:50.171928
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.g = Grammar()
            self.g.symbol2number = {'foo': 1, 'bar': 2}
            self.g.number2symbol = {1: 'foo', 2: 'bar'}
            self.g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            self.g.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 2}),
                           2: ([(5, 6), (7, 8)], {3: 3, 4: 4})}

# Generated at 2022-06-17 16:43:05.661678
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    from . import pgen2

    # Create a grammar object
    g = pgen2.driver.load_grammar("Grammar/Grammar")

    # Dump the grammar object to a pickle file
    fname = "Grammar/Grammar.pickle"
    g.dump(fname)

    # Load the grammar object from the pickle file
    with open(fname, "rb") as f:
        d = pickle.load(f)

    # Remove the pickle file
    os.remove(fname)

    # Check that the grammar object has the expected attributes
    assert "symbol2number" in d
    assert "number2symbol" in d
    assert "states" in d
    assert "dfas" in d
    assert "labels" in d

# Generated at 2022-06-17 16:43:14.793028
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    from . import grammar
    from . import token

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = grammar.Grammar()
            g.load(grammar.grammar_file)
            self.assertEqual(g.symbol2number["and"], 257)
            self.assertEqual(g.number2symbol[257], "and")
            self.assertEqual(g.states[0][0], [(token.NAME, 1), (token.NEWLINE, 2)])
            self.assertEqual(g.dfas[257], (g.states[0], {token.NAME: 1}))
            self.assertEqual(g.labels[0], (0, "EMPTY"))
            self.assertE

# Generated at 2022-06-17 16:43:26.522534
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
    g.dfas = {1: (1, {1: 1, 2: 1}), 2: (2, {3: 1, 4: 1})}
    g.labels = [(1, 'foo'), (2, 'bar'), (3, 'baz'), (4, 'qux')]
    g.keywords = {'foo': 1, 'bar': 2}
    g.tokens = {1: 3, 2: 4}

# Generated at 2022-06-17 16:43:37.617981
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    import io

    g = Grammar()
    g.symbol2number = {'foo': 1}
    g.number2symbol = {1: 'foo'}
    g.states = [[(1, 2)], [(1, 3)]]
    g.dfas = {1: ([(1, 2)], {1: 1}), 2: ([(1, 3)], {1: 1})}
    g.labels = [(1, 'foo'), (2, 'bar')]
    g.keywords = {'foo': 1}
    g.tokens = {1: 2}
    g.symbol2label = {'foo': 1}
    g.start = 3

    f = io.BytesIO()
    g.dump(f)
    f.seek(0)
    g

# Generated at 2022-06-17 16:43:50.442704
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import tempfile
    import pickle
    from . import token

    # Create a temporary file
    fd, fname = tempfile.mkstemp()
    os.close(fd)

    # Create a Grammar object
    g = Grammar()
    g.symbol2number = {'foo': 256, 'bar': 257}
    g.number2symbol = {256: 'foo', 257: 'bar'}
    g.states = [[[(0, 1), (1, 2)], [(0, 2)]]]
    g.dfas = {256: (g.states[0], {1: 1}), 257: (g.states[0], {1: 1})}
    g.labels = [(0, None), (token.NAME, 'foo'), (token.NAME, 'bar')]


# Generated at 2022-06-17 16:43:58.749871
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import io
    import pickle
    from . import pgen2
    from . import tokenize

    # Create a grammar object
    g = pgen2.driver.load_grammar(
        "Grammar/Grammar",
        "Grammar/Grammar.txt",
        "Grammar/Grammar.pickle",
        "Grammar/Grammar.pgen",
    )

    # Dump the grammar object to a pickle file
    g.dump("Grammar/Grammar.pickle")

    # Load the grammar object from the pickle file
    g2 = Grammar()
    g2.load("Grammar/Grammar.pickle")

    # Dump the grammar object to a pickle file

# Generated at 2022-06-17 16:44:05.764699
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/tmp/test_Grammar_dump.pkl")
    g2 = Grammar()
    g2.load("/tmp/test_Grammar_dump.pkl")
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label
    assert g.start == g2.start
    assert g.async_keywords == g2.async_

# Generated at 2022-06-17 16:44:16.983254
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import os
    import pickle
    import tempfile
    import shutil

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.g = Grammar()
            self.g.symbol2number = {'foo': 1, 'bar': 2}
            self.g.number2symbol = {1: 'foo', 2: 'bar'}
            self.g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            self.g.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 2}),
                           2: ([(5, 6), (7, 8)], {3: 3, 4: 4})}

# Generated at 2022-06-17 16:44:24.258773
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    import io
    import os
    import tempfile

    g = Grammar()
    g.symbol2number = {'foo': 1}
    g.number2symbol = {1: 'foo'}
    g.states = [[[(1, 2)], [(2, 3)]]]
    g.dfas = {1: ([[(1, 2)], [(2, 3)]], {1: 1})}
    g.labels = [(1, 'foo'), (2, 'bar')]
    g.keywords = {'foo': 1}
    g.tokens = {1: 1}
    g.symbol2label = {'foo': 1}
    g.start = 256

    with tempfile.NamedTemporaryFile(delete=False) as f:
        pickle.dump

# Generated at 2022-06-17 16:44:34.925803
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[[(1, 2), (3, 4)], [(5, 6), (7, 8)]]]
            g.dfas = {1: ([[(1, 2), (3, 4)], [(5, 6), (7, 8)]], {1: 1, 2: 2}), 2: ([[(1, 2), (3, 4)], [(5, 6), (7, 8)]], {1: 1, 2: 2})}
           

# Generated at 2022-06-17 16:44:54.869546
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import io

    g = Grammar()
    g.symbol2number = {'foo': 1}
    g.number2symbol = {1: 'foo'}
    g.states = [[[(1, 2)], [(2, 3)]]]
    g.dfas = {1: ([[(1, 2)], [(2, 3)]], {1: 1, 2: 1, 3: 1})}
    g.labels = [(1, 'foo'), (2, 'bar')]
    g.keywords = {'foo': 1}
    g.tokens = {1: 1}
    g.symbol2label = {'foo': 1}
    g.start = 256

    f = io.BytesIO()
    g.dump(f)
    f.seek(0)


# Generated at 2022-06-17 16:44:58.275001
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/tmp/test.pkl")
    g.load("/tmp/test.pkl")
    g.report()

# Generated at 2022-06-17 16:45:07.064887
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    from io import BytesIO
    from typing import Any, Dict, List, Optional, Text, Tuple, TypeVar, Union

    # Local imports
    from . import token

    _P = TypeVar("_P", bound="Grammar")
    Label = Tuple[int, Optional[Text]]
    DFA = List[List[Tuple[int, int]]]
    DFAS = Tuple[DFA, Dict[int, int]]
    Path = Union[str, "os.PathLike[str]"]


# Generated at 2022-06-17 16:45:17.168012
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import unittest
    import warnings
    import io
    import pickle
    import os
    import tempfile
    from . import pgen2
    from . import token

    class GrammarDumpTestCase(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.TemporaryDirectory()
            self.filename = os.path.join(self.tempdir.name, "Grammar.pickle")
            self.grammar = pgen2.driver.load_grammar(
                pgen2.pgen.__file__, "Grammar.txt"
            )

        def tearDown(self):
            self.tempdir.cleanup()

        def test_dump(self):
            self.grammar.dump(self.filename)

# Generated at 2022-06-17 16:45:24.783134
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import io
    import os
    import tempfile
    from . import token

    # Create a grammar object
    g = Grammar()
    g.symbol2number = {'foo': 256, 'bar': 257}
    g.number2symbol = {256: 'foo', 257: 'bar'}
    g.states = [[[(0, 0), (1, 1)], [(2, 2), (3, 3)]]]
    g.dfas = {256: ([[(0, 0), (1, 1)], [(2, 2), (3, 3)]], {1: 1}), 257: ([[(0, 0), (1, 1)], [(2, 2), (3, 3)]], {1: 1})}

# Generated at 2022-06-17 16:45:26.898460
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:45:36.148082
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[(1, 2)], [(3, 4)]]
            g.dfas = {1: ([(1, 2)], {1: 1}), 2: ([(3, 4)], {1: 1})}
            g.labels = [(1, 'a'), (2, 'b')]
            g.keywords = {'a': 1, 'b': 2}
            g.tokens = {1: 1, 2: 2}


# Generated at 2022-06-17 16:45:47.020021
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][1] == 1
    assert g.dfas[257][0][0][1] == 1
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["and"] == 257
    assert g.tokens[token.NAME] == 258
    assert g.start == 256

# Generated at 2022-06-17 16:45:55.730218
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == 1
    assert g.dfas[257][0][0][0][0] == 1
    assert g.labels[1] == (1, None)
    assert g.keywords["and"] == 1
    assert g.tokens[1] == 1
    assert g.start == 256

# Generated at 2022-06-17 16:46:02.172764
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and_expr"] == 258
    assert g.number2symbol[258] == "and_expr"
    assert g.states[0][0][0][0] == 0
    assert g.states[0][0][0][1] == 1
    assert g.dfas[258][0][0][0][0] == 0
    assert g.dfas[258][0][0][0][1] == 1
    assert g.labels[0][0] == 0
    assert g.labels[0][1] == "EMPTY"
    assert g.keywords["False"] == 1
    assert g.tokens[1]

# Generated at 2022-06-17 16:46:27.044847
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    import unittest
    from . import pgen2

    class Grammar_load_TestCase(unittest.TestCase):
        def test_load(self):
            g = pgen2.driver.load_grammar("Grammar/Grammar.pickle")
            self.assertIsInstance(g, Grammar)
            self.assertEqual(g.symbol2number["file_input"], 257)
            self.assertEqual(g.number2symbol[257], "file_input")
            self.assertEqual(len(g.states), 5)
            self.assertEqual(len(g.states[0]), 3)
            self.assertEqual(len(g.states[0][0]), 2)

# Generated at 2022-06-17 16:46:38.859362
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io
    import os
    import tempfile
    from typing import Dict, List, Tuple, Union
    from . import token
    from .pgen2 import tokenize

    class TestGrammar(unittest.TestCase):
        def setUp(self) -> None:
            self.grammar = Grammar()

# Generated at 2022-06-17 16:46:48.590218
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import unittest.mock

    class TestGrammar(Grammar):
        def __init__(self):
            super().__init__()
            self.symbol2number = {'a': 1, 'b': 2}
            self.number2symbol = {1: 'a', 2: 'b'}
            self.states = [[(1, 1), (2, 2)], [(3, 3), (4, 4)]]
            self.dfas = {1: ([(1, 1), (2, 2)], {1: 1, 2: 2}),
                         2: ([(3, 3), (4, 4)], {3: 3, 4: 4})}

# Generated at 2022-06-17 16:46:59.801564
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.start == 256
    assert g.symbol2number["single_input"] == 256
    assert g.number2symbol[256] == "single_input"
    assert g.symbol2number["file_input"] == 257
    assert g.number2symbol[257] == "file_input"
    assert g.symbol2number["eval_input"] == 258
    assert g.number2symbol[258] == "eval_input"
    assert g.symbol2number["decorator"] == 259
    assert g.number2symbol[259] == "decorator"
    assert g.symbol2number["decorators"] == 260
   

# Generated at 2022-06-17 16:47:09.673611
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import shutil
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    try:
        # Create a temporary file
        fd, filename = tempfile.mkstemp(dir=tmpdir)
        os.close(fd)

        # Create a Grammar object
        g = Grammar()

        # Call the method to test
        g.dump(filename)

        # Check that the file exists
        assert os.path.exists(filename)

        # Check that the file is not empty
        assert os.path.getsize(filename) > 0
    finally:
        # Remove the temporary directory
        shutil.rmtree(tmpdir)

# Generated at 2022-06-17 16:47:21.138237
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen2
    from . import tokenize
    from . import token

    # Create a grammar
    g = pgen2.driver.load_grammar("Grammar/Grammar")

    # Dump it to a file
    g.dump("Grammar/Grammar.pickle")

    # Load it from the file
    g2 = Grammar()
    g2.load("Grammar/Grammar.pickle")

    # Compare the two
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.start == g2.start

   

# Generated at 2022-06-17 16:47:23.000265
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("test.pickle")
    grammar.load("test.pickle")
    grammar.report()


# Generated at 2022-06-17 16:47:24.187704
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/tmp/test_Grammar_dump")


# Generated at 2022-06-17 16:47:29.183222
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[257][0][0][0][0] == token.NAME
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["and"] == 1
    assert g.tokens[token.NAME] == 1
    assert g.symbol2label["and"] == 1
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:47:36.030341
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[(1, 2)], [(3, 4)]]
            g.dfas = {1: ([(1, 2)], {1: 1}), 2: ([(3, 4)], {3: 1})}
            g.labels = [(1, 'foo'), (2, 'bar'), (3, 'baz')]
            g.keywords = {'foo': 1, 'bar': 2}
            g.tokens = {1: 1, 2: 2}
            g.symbol2label

# Generated at 2022-06-17 16:48:07.510131
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import os
    import tempfile
    from . import pgen2
    grammar = pgen2.driver.load_grammar("Grammar.txt")
    with tempfile.NamedTemporaryFile(delete=False) as f:
        grammar.dump(f.name)
    with open(f.name, "rb") as f:
        d = pickle.load(f)
    os.remove(f.name)
    assert d == grammar.__dict__

# Generated at 2022-06-17 16:48:16.085150
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    from io import BytesIO
    from . import token
    from .pgen2 import tokenize

    g = Grammar()
    g.symbol2number = {'foo': 256, 'bar': 257}
    g.number2symbol = {256: 'foo', 257: 'bar'}
    g.states = [[[(257, 1)], [(0, 2)], [(0, 2)], [(0, 2)]]]
    g.dfas = {256: ([[(257, 1)], [(0, 2)], [(0, 2)], [(0, 2)]], {257: 1}), 257: ([[(0, 1)]], {token.NAME: 1})}