

# Generated at 2022-06-17 16:38:02.409250
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/tmp/test_Grammar_dump")


# Generated at 2022-06-17 16:38:06.404410
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import unittest

    class TestGrammar_load(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.load(sys.executable)

    unittest.main()

# Generated at 2022-06-17 16:38:16.649653
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    from typing import Any, Dict, List, Optional, Text, Tuple, TypeVar, Union

    # Local imports
    from . import token

    _P = TypeVar("_P", bound="Grammar")
    Label = Tuple[int, Optional[Text]]
    DFA = List[List[Tuple[int, int]]]
    DFAS = Tuple[DFA, Dict[int, int]]
    Path = Union[str, "os.PathLike[str]"]


# Generated at 2022-06-17 16:38:24.842859
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0] == [(257, 1), (258, 2)]
    assert g.dfas[257] == ([[(0, 1)]], {0: 1})
    assert g.labels[257] == (257, None)
    assert g.keywords["and"] == 257
    assert g.tokens[token.NAME] == 258
    assert g.start == 256

# Generated at 2022-06-17 16:38:36.791889
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Test that Grammar.dump() works
    g = Grammar()
    g.symbol2number = {"foo": 1, "bar": 2}
    g.number2symbol = {1: "foo", 2: "bar"}
    g.states = [[[(1, 2), (3, 4)], [(5, 6), (7, 8)]]]
    g.dfas = {1: ([[(1, 2), (3, 4)], [(5, 6), (7, 8)]], {1: 1, 2: 1}), 2: ([[(9, 10)]], {3: 1})}

# Generated at 2022-06-17 16:38:49.896747
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    from typing import Dict, List, Tuple
    from . import token

    class Grammar(object):
        def __init__(self) -> None:
            self.symbol2number: Dict[str, int] = {}
            self.number2symbol: Dict[int, str] = {}
            self.states: List[List[Tuple[int, int]]] = []
            self.dfas: Dict[int, Tuple[List[List[Tuple[int, int]]], Dict[int, int]]] = {}
            self.labels: List[Tuple[int, Optional[str]]] = [(0, "EMPTY")]
            self.keywords: Dict[str, int] = {}

# Generated at 2022-06-17 16:39:02.099751
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import os
    import sys
    import tempfile
    import shutil
    import io
    import tokenize
    import token
    import io
    import ast
    import asttokens
    import astunparse
    import astpretty
    import astor
    import astpretty
    import astunparse
    import astor
    import asttokens
    import ast
    import tokenize
    import token
    import io
    import tempfile
    import shutil
    import sys
    import os
    import pickle
    import unittest

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            # Test Grammar.dump
            g = Grammar()

# Generated at 2022-06-17 16:39:08.753884
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import io
    import pickle

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            g.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 2}), 2: ([(5, 6), (7, 8)], {5: 5, 6: 6})}
            g.labels = [(1, 'a'), (2, 'b')]

# Generated at 2022-06-17 16:39:20.578208
# Unit test for method load of class Grammar
def test_Grammar_load():
    import io
    import pickle
    import unittest
    from . import grammar

    class GrammarTest(unittest.TestCase):
        def test_load(self):
            g = grammar.Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[(1, 2), (3, 4)]]
            g.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 1})}
            g.labels = [(1, 'foo'), (2, 'bar')]
            g.keywords = {'foo': 1}
            g.tokens = {1: 1}
            g.symbol2label = {'foo': 1}

# Generated at 2022-06-17 16:39:27.348645
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[257][0][0][0][0] == token.NAME
    assert g.labels[1] == (token.NAME, None)
    assert g.keywords["False"] == 2
    assert g.tokens[token.NAME] == 1
    assert g.start == 257
    assert g.async_keywords == False

# Generated at 2022-06-17 16:39:34.585258
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import io
    from . import token

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.g = Grammar()
            self.g.symbol2number = {'foo': 256, 'bar': 257}
            self.g.number2symbol = {256: 'foo', 257: 'bar'}
            self.g.states = [[[(257, 0)], [(256, 1), (0, 1)], [(0, 2)]]]

# Generated at 2022-06-17 16:39:43.305507
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen2
    from . import parse

    g = pgen2.driver.load_grammar("Grammar.txt")
    g.dump("Grammar.pickle")
    g2 = Grammar()
    g2.load("Grammar.pickle")
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label
    assert g.start == g2.start

# Generated at 2022-06-17 16:39:53.306746
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import os
    import pickle
    import tempfile
    import shutil
    import sys

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.filename = os.path.join(self.temp_dir, "grammar.pickle")

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_dump(self):
            g = Grammar()
            g.dump(self.filename)
            with open(self.filename, "rb") as f:
                d = pickle.load(f)
            self.assertEqual(d["symbol2number"], {})

# Generated at 2022-06-17 16:40:05.070365
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[258] == "as"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[258][0][0][0][0] == token.NAME
    assert g.labels[1] == (token.NAME, None)
    assert g.keywords["False"] == 2
    assert g.tokens[token.NAME] == 1
    assert g.symbol2label["and"] == 257
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:40:18.239790
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen2
    from . import tokenize

    g = pgen2.driver.load_grammar("Grammar.txt")
    g.dump("Grammar.pickle")
    g2 = Grammar()
    g2.load("Grammar.pickle")
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label
    assert g.start == g2.start
   

# Generated at 2022-06-17 16:40:21.420498
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:40:29.739578
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import io

    class TestGrammarDump(unittest.TestCase):
        def test_dump(self):
            grammar = Grammar()
            grammar.symbol2number = {'foo': 1}
            grammar.number2symbol = {1: 'foo'}
            grammar.states = [1, 2, 3]
            grammar.dfas = {1: (1, 2)}
            grammar.labels = [(1, 'foo'), (2, 'bar')]
            grammar.keywords = {'foo': 1}
            grammar.tokens = {1: 2}
            grammar.symbol2label = {'foo': 1}
            grammar.start = 3
            grammar.async_keywords = False

            f = io.BytesIO()
            grammar.dump

# Generated at 2022-06-17 16:40:41.770730
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import io
    import unittest

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[(1, 1)], [(2, 2)]]
            g.dfas = {1: ([(1, 1)], {1: 1}), 2: ([(2, 2)], {2: 1})}
            g.labels = [(1, 'a'), (2, 'b')]
            g.keywords = {'a': 1, 'b': 2}
            g.tokens = {1: 1, 2: 2}


# Generated at 2022-06-17 16:40:50.902814
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pytest
    import os
    import pickle
    import tempfile
    from . import token

    # Create a Grammar object
    g = Grammar()
    g.symbol2number = {'foo': 256, 'bar': 257}
    g.number2symbol = {256: 'foo', 257: 'bar'}
    g.states = [[[(0, 1)], [(0, 2)]]]
    g.dfas = {256: ([[(0, 1)], [(0, 2)]], {0: 1}), 257: ([[(0, 1)], [(0, 2)]], {0: 1})}
    g.labels = [(0, 'EMPTY'), (0, None), (0, None)]
    g.keywords = {'foo': 1, 'bar': 2}

# Generated at 2022-06-17 16:41:02.554507
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["single_input"] == 256
    assert g.number2symbol[256] == "single_input"
    assert g.symbol2number["file_input"] == 257
    assert g.number2symbol[257] == "file_input"
    assert g.symbol2number["eval_input"] == 258
    assert g.number2symbol[258] == "eval_input"
    assert g.symbol2number["decorator"] == 259
    assert g.number2symbol[259] == "decorator"
    assert g.symbol2number["decorators"] == 260

# Generated at 2022-06-17 16:41:08.266741
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/tmp/test_Grammar_dump")


# Generated at 2022-06-17 16:41:20.226590
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import io
    import unittest
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = pgen2.grammar.Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            g.dfas = {1: (1, {1: 1, 2: 1}), 2: (2, {3: 1, 4: 1})}

# Generated at 2022-06-17 16:41:28.516611
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import unittest
    from io import StringIO

    class GrammarTestCase(unittest.TestCase):
        def test_dump(self):
            # Test that dump() writes the pickle to a file
            # and that load() reads it back.
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[(0, 1), (1, 2)], [(0, 3), (2, 4)]]
            g.dfas = {1: (g.states[0], {1: 1, 2: 1}),
                      2: (g.states[1], {1: 1, 2: 1})}

# Generated at 2022-06-17 16:41:34.575812
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.pickle")
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[257][0][0][0][0] == token.NAME
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["and"] == 257
    assert g.tokens[token.NAME] == 258
    assert g.start == 256


# Generated at 2022-06-17 16:41:44.271838
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen2
    from . import tokenize

    g = pgen2.driver.load_grammar("Grammar.txt")
    g.dump("Grammar.pickle")
    g2 = Grammar()
    g2.load("Grammar.pickle")
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label
    assert g.start == g2.start
   

# Generated at 2022-06-17 16:41:53.139117
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[257][0][0][0][0] == token.NAME
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["and"] == 257
    assert g.tokens[token.NAME] == 258
    assert g.start == 256

# Generated at 2022-06-17 16:41:56.892432
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.pkl")
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:41:59.775559
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:42:11.498533
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import io
    import unittest
    from unittest import mock

    class TestGrammar(unittest.TestCase):
        def test_Grammar_dump(self):
            with mock.patch("builtins.open", mock.mock_open()) as mock_file:
                g = Grammar()
                g.dump("test_file")
                mock_file.assert_called_once_with("test_file", "wb")
                handle = mock_file()
                handle.write.assert_called_once()

    suite = unittest.TestLoader().loadTestsFromTestCase(TestGrammar)
    result = unittest.TextTestRunner(stream=io.StringIO(), verbosity=2).run(suite)
    assert result.wasSuccessful()


# Generated at 2022-06-17 16:42:23.260757
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
    g.dfas = {1: (1, {1: 1, 2: 1}), 2: (2, {3: 1, 4: 1})}
    g.labels = [(1, None), (2, None), (3, None), (4, None),
                (5, None), (6, None), (7, None), (8, None)]
    g.keywords = {'foo': 1, 'bar': 2}
    g.tokens = {1: 3, 2: 4}


# Generated at 2022-06-17 16:42:38.397662
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    from typing import Any, Dict, List, Optional, Text, Tuple, TypeVar, Union

    # Local imports
    from . import token

    _P = TypeVar("_P", bound="Grammar")
    Label = Tuple[int, Optional[Text]]
    DFA = List[List[Tuple[int, int]]]
    DFAS = Tuple[DFA, Dict[int, int]]
    Path = Union[str, "os.PathLike[str]"]


# Generated at 2022-06-17 16:42:42.425500
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:42:51.647243
# Unit test for method load of class Grammar
def test_Grammar_load():
    import io
    import pickle
    import unittest
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.load(pgen2.grammar_file)
            self.assertEqual(g.start, 256)
            self.assertEqual(g.symbol2number["single_input"], 256)
            self.assertEqual(g.number2symbol[256], "single_input")
            self.assertEqual(g.states[0][0][0][0], token.NEWLINE)
            self.assertEqual(g.dfas[256][0][0][0][0][0], token.NEWLINE)
            self.assertEqual(g.labels[0][0], 0)

# Generated at 2022-06-17 16:43:03.201792
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import driver

    g = Grammar()
    driver.load_grammar(g)
    assert g.start == g.symbol2number["file_input"]
    assert g.start == g.symbol2number["eval_input"]
    assert g.start == g.symbol2number["single_input"]
    assert g.start == g.symbol2number["decorator"]
    assert g.start == g.symbol2number["decorators"]
    assert g.start == g.symbol2number["decorated"]
    assert g.start == g.symbol2number["async_funcdef"]
    assert g.start == g.symbol2number["funcdef"]
    assert g.start == g.symbol2number["parameters"]
    assert g.start == g.symbol

# Generated at 2022-06-17 16:43:13.515961
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import tempfile
    import os
    import shutil
    import sys

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmp_file = tempfile.mkstemp(dir=tmp_dir)

    # Create a Grammar object
    g = Grammar()

    # Dump the object to the temporary file
    g.dump(tmp_file)

    # Open the temporary file
    with open(tmp_file, "rb") as f:
        # Load the object from the temporary file
        g2 = pickle.load(f)

    # Compare the two objects
    assert g.__dict__ == g2.__dict__

    # Remove the temporary directory
    shutil.rmtree(tmp_dir)

    # Test for issue

# Generated at 2022-06-17 16:43:25.454838
# Unit test for method load of class Grammar

# Generated at 2022-06-17 16:43:35.200764
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import tempfile
    import os
    import os.path
    import sys

    # Create a temporary file
    fd, filename = tempfile.mkstemp(text=False)
    os.close(fd)

    # Create a Grammar object
    g = Grammar()

    # Dump the object to the temporary file
    g.dump(filename)

    # Load the object from the temporary file
    with open(filename, "rb") as f:
        d = pickle.load(f)

    # Check that the object is the same as the original
    assert d == g.__dict__

    # Clean up
    os.remove(filename)

# Generated at 2022-06-17 16:43:42.443089
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'foo': 1}
    g.number2symbol = {1: 'foo'}
    g.states = [[(1, 1)]]
    g.dfas = {1: (1, {1: 1})}
    g.labels = [(1, 'foo')]
    g.keywords = {'foo': 1}
    g.tokens = {1: 1}
    g.symbol2label = {'foo': 1}
    g.start = 1
    g.async_keywords = False
    g.dump('/tmp/foo.pkl')
    g2 = Grammar()
    g2.load('/tmp/foo.pkl')
    assert g.symbol2number == g2.symbol2number

# Generated at 2022-06-17 16:43:47.408845
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    import io

    g = Grammar()
    g.symbol2number = {'foo': 1}
    g.number2symbol = {1: 'foo'}
    g.states = [[(1, 2)], [(3, 4)]]
    g.dfas = {1: ([(1, 2)], {1: 1}), 2: ([(3, 4)], {3: 1})}
    g.labels = [(1, 'foo'), (2, 'bar')]
    g.keywords = {'foo': 1, 'bar': 2}
    g.tokens = {1: 1, 2: 2}
    g.symbol2label = {'foo': 1, 'bar': 2}
    g.start = 256

    f = io.BytesIO()
    g.dump

# Generated at 2022-06-17 16:43:57.469669
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2
    from . import conv

    g = Grammar()
    g.load("Grammar.pickle")
    assert g.start == 256
    assert g.number2symbol[256] == "file_input"
    assert g.symbol2number["file_input"] == 256
    assert g.number2symbol[257] == "stmt"
    assert g.symbol2number["stmt"] == 257
    assert g.number2symbol[258] == "simple_stmt"
    assert g.symbol2number["simple_stmt"] == 258
    assert g.number2symbol[259] == "small_stmt"
    assert g.symbol2number["small_stmt"] == 259
    assert g.number2symbol[260] == "expr_stmt"


# Generated at 2022-06-17 16:44:23.334160
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.load(pgen2.__file__)
            self.assertEqual(g.symbol2number["and"], 257)
            self.assertEqual(g.number2symbol[257], "and")
            self.assertEqual(g.states[0][0][0][0], token.NAME)
            self.assertEqual(g.dfas[257][0][0][0][0], token.NAME)
            self.assertEqual(g.labels[0][0], 0)
            self.assertEqual(g.keywords["False"], 1)

# Generated at 2022-06-17 16:44:34.381463
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    import io

    g = Grammar()
    g.symbol2number = {"a": 1, "b": 2}
    g.number2symbol = {1: "a", 2: "b"}
    g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
    g.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 2}), 2: ([(5, 6), (7, 8)], {5: 1, 6: 2})}
    g.labels = [(1, "a"), (2, "b"), (3, "c"), (4, "d"), (5, "e"), (6, "f"), (7, "g"), (8, "h")]

# Generated at 2022-06-17 16:44:37.459104
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.pickle")
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:44:50.707592
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == 1
    assert g.states[0][0][0][1] == 1
    assert g.dfas[257][0][0][0][0] == 1
    assert g.dfas[257][0][0][0][1] == 2
    assert g.labels[1] == (1, None)
    assert g.keywords["and"] == 1
    assert g.tokens[1] == 1
    assert g.start == 257
    assert g.async_key

# Generated at 2022-06-17 16:45:03.124459
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import io

    class GrammarTest(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            g.dfas = {1: (1, {1: 1}), 2: (2, {2: 1})}
            g.labels = [(1, 'a'), (2, 'b')]
            g.keywords = {'a': 1, 'b': 2}
            g.tokens = {1: 1, 2: 2}

# Generated at 2022-06-17 16:45:13.836694
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    from . import token

    # Create a Grammar object
    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[[(1, 2), (3, 4)], [(5, 6), (7, 8)]]]
    g.dfas = {1: ([[(1, 2), (3, 4)], [(5, 6), (7, 8)]], {1: 1, 2: 1}), 2: ([[(9, 10)]], {3: 1, 4: 1})}

# Generated at 2022-06-17 16:45:21.055796
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import os
    import tempfile

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.g = Grammar()
            self.g.symbol2number = {'a': 1, 'b': 2}
            self.g.number2symbol = {1: 'a', 2: 'b'}
            self.g.states = [[(1, 1), (2, 2)], [(3, 3), (4, 4)]]
            self.g.dfas = {1: ([(1, 1), (2, 2)], {1: 1, 2: 2}),
                           2: ([(3, 3), (4, 4)], {3: 3, 4: 4})}

# Generated at 2022-06-17 16:45:29.657652
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.symbol2number["as"] == 258
    assert g.symbol2number["assert"] == 259
    assert g.symbol2number["break"] == 260
    assert g.symbol2number["class"] == 261
    assert g.symbol2number["continue"] == 262
    assert g.symbol2number["def"] == 263
    assert g.symbol2number["del"] == 264
    assert g.symbol2number["elif"] == 265
    assert g.symbol2number["else"] == 266
    assert g.symbol2number["except"] == 267
    assert g.symbol

# Generated at 2022-06-17 16:45:38.683999
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import os
    import pickle
    import unittest
    from io import BytesIO
    from . import token

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.g = Grammar()
            self.g.symbol2number = {
                "foo": 256,
                "bar": 257,
                "baz": 258,
            }
            self.g.number2symbol = {
                256: "foo",
                257: "bar",
                258: "baz",
            }
            self.g.states = [
                [
                    [(257, 1), (258, 2)],
                    [(0, 1)],
                    [(0, 2)],
                ]
            ]

# Generated at 2022-06-17 16:45:44.698589
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    from . import token

    g = Grammar()
    g.symbol2number = {'foo': 256, 'bar': 257}
    g.number2symbol = {256: 'foo', 257: 'bar'}
    g.states = [[[(0, 1)], [(0, 2)]]]
    g.dfas = {256: ([[(0, 1)], [(0, 2)]], {1: 1, 2: 1}), 257: ([[(0, 1)], [(0, 2)]], {1: 1, 2: 1})}
    g.labels = [(0, 'EMPTY'), (0, None), (0, None)]
    g.keywords = {}
    g.tokens = {}
    g.symbol2label = {}

# Generated at 2022-06-17 16:46:28.307484
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")
    g.report()

# Generated at 2022-06-17 16:46:39.468605
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'foo': 1, 'bar': 2}
            g.number2symbol = {1: 'foo', 2: 'bar'}
            g.states = [[(1, 2)], [(3, 4)]]
            g.dfas = {1: ([(1, 2)], {1: 1}), 2: ([(3, 4)], {1: 1})}
            g.labels = [(1, 'foo'), (2, 'bar')]
            g.keywords = {'foo': 1, 'bar': 2}
            g.tokens = {1: 1, 2: 2}


# Generated at 2022-06-17 16:46:50.134104
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import io
    import unittest
    from unittest import mock
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            grammar = pgen2.driver.load_grammar("Grammar.txt")
            with mock.patch("sys.stdout", new=io.StringIO()) as fake_out:
                grammar.dump("Grammar.pkl")
                self.assertEqual(fake_out.getvalue(), "")

    unittest.main(argv=[sys.argv[0]], exit=False)

# Generated at 2022-06-17 16:47:01.250490
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen2
    from . import tokenize

    g = pgen2.driver.load_grammar("Grammar.txt")
    g.dump("Grammar.pickle")
    g2 = Grammar()
    g2.load("Grammar.pickle")
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label
    assert g.start == g2.start
   

# Generated at 2022-06-17 16:47:11.225346
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import sys
    import tempfile
    import unittest

    from . import pgen2

    class GrammarDumpTests(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.grammar = pgen2.driver.load_grammar(
                os.path.join(os.path.dirname(__file__), "Grammar.txt")
            )

        def tearDown(self):
            import shutil

            shutil.rmtree(self.tempdir)

        def test_dump(self):
            filename = os.path.join(self.tempdir, "Grammar.pickle")
            self.grammar.dump(filename)
            self.assertTrue(os.path.exists(filename))



# Generated at 2022-06-17 16:47:17.053161
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    from . import token

    # Create a grammar object
    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[[(1, 2)], [(2, 3)]]]
    g.dfas = {1: ([[(1, 2)], [(2, 3)]], {1: 1, 2: 1}), 2: ([[(1, 2)], [(2, 3)]], {1: 1, 2: 1})}
    g.labels = [(0, 'EMPTY'), (1, None), (2, None)]
    g.keywords = {'foo': 1, 'bar': 2}
   

# Generated at 2022-06-17 16:47:26.809481
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[257][0][0][0][0] == token.NAME
    assert g.labels[0][0] == 0
    assert g.labels[0][1] == "EMPTY"
    assert g.keywords["False"] == 1
    assert g.tokens[token.NAME] == 1
    assert g.symbol2label["and"] == 257
    assert g.start == 256

# Generated at 2022-06-17 16:47:34.749466
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2
    from . import tokenize
    from . import parse

    # Create a grammar object
    g = pgen2.driver.load_grammar("Grammar/Grammar")

    # Dump the grammar tables to a pickle file
    g.dump("Grammar/Grammar.pickle")

    # Create a new grammar object
    h = Grammar()

    # Load the grammar tables from the pickle file
    h.load("Grammar/Grammar.pickle")

    # Create a parser object
    p = parse.Parser(h, tokenize.generate_tokens)

    # Parse a string
    p.parse("1 + 2")

    # Parse a file
    p.parse(open("Grammar/Grammar"))



# Generated at 2022-06-17 16:47:42.156444
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == 1
    assert g.dfas[257][0][0][0][0] == 1
    assert g.labels[1][0] == 1
    assert g.keywords["False"] == 1
    assert g.tokens[1] == 1
    assert g.start == 257
    assert g.async_keywords == False

# Generated at 2022-06-17 16:47:51.688053
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 256
    assert g.number2symbol[256] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[256][0][0][0][0] == token.NAME
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["False"] == 1
    assert g.tokens[token.NAME] == 2
    assert g.symbol2label["and"] == 256
    assert g.start == 256
    assert g.async_keywords == False