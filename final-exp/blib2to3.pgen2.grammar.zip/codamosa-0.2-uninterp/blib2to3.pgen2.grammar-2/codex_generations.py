

# Generated at 2022-06-17 16:38:10.090437
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import io
    import unittest

    class GrammarDumpTest(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'a': 1}
            g.number2symbol = {1: 'a'}
            g.states = [[(1, 2)], [(1, 3)]]
            g.dfas = {1: ([(1, 2)], {1: 1}), 2: ([(1, 3)], {1: 1})}
            g.labels = [(1, 'a'), (2, 'b')]
            g.keywords = {'a': 1}
            g.tokens = {1: 1}
            g.symbol2label = {'a': 1}

# Generated at 2022-06-17 16:38:21.566151
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import pickle
    from . import pgen2
    from . import tokenize

    # Create a grammar object
    g = pgen2.driver.load_grammar(tokenize.detect_encoding(sys.stdin.buffer)[0])

    # Dump the grammar object to a pickle file
    g.dump("Grammar.pickle")

    # Load the grammar object from the pickle file
    g2 = Grammar()
    g2.load("Grammar.pickle")

    # Compare the two grammar objects
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2

# Generated at 2022-06-17 16:38:23.819013
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    g.report()

# Generated at 2022-06-17 16:38:35.694479
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    from typing import Any, Dict, List, Optional, Text, Tuple, TypeVar, Union
    from . import token

    _P = TypeVar("_P", bound="Grammar")
    Label = Tuple[int, Optional[Text]]
    DFA = List[List[Tuple[int, int]]]
    DFAS = Tuple[DFA, Dict[int, int]]
    Path = Union[str, "os.PathLike[str]"]


# Generated at 2022-06-17 16:38:49.644620
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test that Grammar.load() works as expected
    g = Grammar()
    g.symbol2number = {'a': 1}
    g.number2symbol = {1: 'a'}
    g.states = [[[(1, 1)]]]
    g.dfas = {1: ([[(1, 1)]], {1: 1}), 2: ([[(1, 1)]], {1: 1})}
    g.labels = [(1, 'a')]
    g.keywords = {'a': 1}
    g.tokens = {1: 1}
    g.symbol2label = {'a': 1}
    g.start = 1
    g.async_keywords = False

# Generated at 2022-06-17 16:39:01.795930
# Unit test for method load of class Grammar
def test_Grammar_load():
    import io
    import pickle
    import unittest

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {"a": 1, "b": 2}
            g.number2symbol = {1: "a", 2: "b"}
            g.states = [[[(1, 1), (2, 2)], [(3, 3), (4, 4)]]]
            g.dfas = {1: ([[(1, 1), (2, 2)], [(3, 3), (4, 4)]], {1: 1, 2: 1}), 2: ([], {})}
            g.labels = [(1, "a"), (2, "b"), (3, "c"), (4, "d")]
           

# Generated at 2022-06-17 16:39:10.202434
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0] == [(1, 1), (2, 2), (3, 3), (4, 4)]
    assert g.dfas[257] == ([[(1, 1), (2, 2), (3, 3), (4, 4)]], {0: 1})
    assert g.labels[1] == (1, None)
    assert g.keywords["and"] == 1
    assert g.tokens[token.NAME] == 1
    assert g.start == 257

# Generated at 2022-06-17 16:39:21.678626
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0] == [(1, 1), (2, 2)]
    assert g.dfas[257] == (g.states[0], {1: 1, 2: 1})
    assert g.labels[1] == (1, None)
    assert g.labels[2] == (2, None)
    assert g.keywords["and"] == 1
    assert g.tokens[1] == 1
    assert g.symbol2label["and"] == 1
    assert g.start == 256
    assert g

# Generated at 2022-06-17 16:39:30.153869
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 258
    assert g.number2symbol[258] == "and"
    assert g.states[0][0][0][0] == 1
    assert g.dfas[258][0][0][0][0] == 1
    assert g.labels[1] == (1, None)
    assert g.keywords["and"] == 1
    assert g.tokens[1] == 1
    assert g.start == 256

# Generated at 2022-06-17 16:39:32.111172
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("test.pkl")
    g.load("test.pkl")
    g.report()

# Generated at 2022-06-17 16:39:51.372589
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[257][0][0][0][0] == token.NAME
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["False"] == 1
    assert g.tokens[token.NAME] == 2
    assert g.symbol2label["and"] == 257
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:39:59.268655
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import io
    import os
    import tempfile

    class GrammarTestCase(unittest.TestCase):
        def setUp(self):
            self.g = Grammar()
            self.g.symbol2number = {"a": 1, "b": 2}
            self.g.number2symbol = {1: "a", 2: "b"}
            self.g.states = [[(1, 2)], [(3, 4)]]
            self.g.dfas = {1: ([(1, 2)], {1: 1}), 2: ([(3, 4)], {3: 1})}
            self.g.labels = [(1, "a"), (2, "b"), (3, "c"), (4, "d")]

# Generated at 2022-06-17 16:40:08.598577
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    from typing import Any, Dict, List, Optional, Text, Tuple, TypeVar, Union

    # Local imports
    from . import token

    _P = TypeVar("_P", bound="Grammar")
    Label = Tuple[int, Optional[Text]]
    DFA = List[List[Tuple[int, int]]]
    DFAS = Tuple[DFA, Dict[int, int]]
    Path = Union[str, "os.PathLike[str]"]


# Generated at 2022-06-17 16:40:12.206428
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pkl"))
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:40:18.951614
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = pgen2.driver.load_grammar("Grammar.txt")
            g.dump("Grammar.pickle")

    unittest.main("pgen2.pgen2", verbosity=2, exit=False)

# Generated at 2022-06-17 16:40:28.291548
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import os
    import tempfile
    from . import token

    # Create a temporary file
    fd, filename = tempfile.mkstemp()
    os.close(fd)

    # Create a Grammar object
    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[(1, 1), (2, 2)], [(3, 3), (4, 4)]]
    g.dfas = {1: (g.states[0], {1: 1, 2: 1}), 2: (g.states[1], {3: 1, 4: 1})}

# Generated at 2022-06-17 16:40:37.388417
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import sys
    import io
    import pickle
    import os
    import tempfile
    from typing import Any, Dict, List, Optional, Text, Tuple, TypeVar, Union


# Generated at 2022-06-17 16:40:39.742265
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:40:46.807851
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'foo': 256, 'bar': 257}
    g.number2symbol = {256: 'foo', 257: 'bar'}
    g.states = [[[(0, 0)], [(1, 1)], [(2, 2)]]]
    g.dfas = {256: ([[(0, 0)], [(1, 1)], [(2, 2)]], {0: 1}), 257: ([[(0, 0)], [(1, 1)], [(2, 2)]], {0: 1})}
    g.labels = [(0, 'EMPTY'), (1, None), (2, None)]
    g.keywords = {'foo': 1, 'bar': 2}
    g.tokens = {1: 1, 2: 2}
   

# Generated at 2022-06-17 16:40:57.728360
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pytest
    import os
    from . import pgen2
    from . import token
    from . import parse

    # Create a grammar object
    g = pgen2.driver.load_grammar("Grammar/Grammar")

    # Dump the grammar object to a pickle file
    g.dump("Grammar/Grammar.pickle")

    # Load the grammar object from the pickle file
    g2 = Grammar()
    g2.load("Grammar/Grammar.pickle")

    # Create a parser object
    p = parse.Parser(g2)

    # Parse a string
    p.parse("1 + 2", "exec")

    # Clean up
    os.remove("Grammar/Grammar.pickle")

# Generated at 2022-06-17 16:41:11.278656
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'foo': 1}
    g.number2symbol = {1: 'foo'}
    g.states = [1, 2, 3]
    g.dfas = {1: (1, 2)}
    g.labels = [(1, 'foo'), (2, 'bar')]
    g.keywords = {'foo': 1, 'bar': 2}
    g.tokens = {1: 1, 2: 2}
    g.symbol2label = {'foo': 1, 'bar': 2}
    g.start = 256
    g.async_keywords = False

    with tempfile.TemporaryDirectory() as tmpdir:
        filename = os.path.join(tmpdir, 'test.pkl')
        g.dump(filename)

# Generated at 2022-06-17 16:41:21.720145
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2
    from . import tokenize

    g = Grammar()
    g.load(pgen2.grammar_file)
    assert g.start == g.symbol2number["file_input"]
    assert g.start == g.symbol2number["eval_input"]
    assert g.start == g.symbol2number["single_input"]
    assert g.start == g.symbol2number["decorator"]
    assert g.start == g.symbol2number["decorators"]
    assert g.start == g.symbol2number["decorated"]
    assert g.start == g.symbol2number["async_funcdef"]
    assert g.start == g.symbol2number["async_stmt"]

# Generated at 2022-06-17 16:41:29.540833
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import tempfile
    import os
    import shutil

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.filename = os.path.join(self.temp_dir, "grammar.pickle")

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_dump(self):
            g = Grammar()
            g.dump(self.filename)
            with open(self.filename, "rb") as f:
                d = pickle.load(f)
            self.assertEqual(d["symbol2number"], g.symbol2number)

# Generated at 2022-06-17 16:41:36.171258
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    import io
    from . import pgen2
    from . import token

    g = pgen2.driver.load_grammar("Grammar/Grammar")
    f = io.BytesIO()
    g.dump(f)
    f.seek(0)
    h = Grammar()
    h.load(f)
    assert h.symbol2number == g.symbol2number
    assert h.number2symbol == g.number2symbol
    assert h.states == g.states
    assert h.dfas == g.dfas
    assert h.labels == g.labels
    assert h.keywords == g.keywords
    assert h.tokens == g.tokens
    assert h.symbol2label == g.symbol2label
    assert h.start

# Generated at 2022-06-17 16:41:42.446193
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import unittest

    class GrammarTest(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.load(sys.executable)

    unittest.main()

# Generated at 2022-06-17 16:41:48.979927
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2
    from . import conv

    g = Grammar()
    g.load(pgen2.__file__.replace(".pyc", ".pkl"))
    g.report()
    g2 = conv.convert(g)
    g2.report()

# Generated at 2022-06-17 16:41:56.292407
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    from . import token

    # Create a Grammar object
    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[[(1, 1), (2, 2)], [(3, 3), (4, 4)]]]
    g.dfas = {1: ([[(1, 1), (2, 2)], [(3, 3), (4, 4)]], {1: 1, 2: 1}), 2: ([[(5, 5), (6, 6)], [(7, 7), (8, 8)]], {5: 1, 6: 1})}

# Generated at 2022-06-17 16:42:05.380537
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == 0
    assert g.dfas[257][0][0][0][0] == 0
    assert g.labels[0][0] == 0
    assert g.keywords["and"] == 0
    assert g.tokens[0] == 0
    assert g.start == 256
    assert g.async_keywords == False

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:42:12.825746
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import io
    import pickle
    from . import pgen2

    # Create a parser generator
    pg = pgen2.driver.load_grammar("Grammar/Grammar")

    # Create a grammar object
    g = pg.grammar

    # Create a temporary file
    with tempfile.NamedTemporaryFile(mode="wb", delete=False) as f:
        # Dump the grammar tables to the temporary file
        g.dump(f.name)

        # Read the temporary file
        f.seek(0)
        data = f.read()

    # Load the grammar tables from the temporary file
    g2 = Grammar()
    g2.loads(data)

    # Create a temporary file

# Generated at 2022-06-17 16:42:24.752099
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import tempfile
    import os
    import pickle
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            grammar = pgen2.driver.load_grammar("Grammar/Grammar")
            with tempfile.NamedTemporaryFile(delete=False) as f:
                grammar.dump(f.name)
            with open(f.name, "rb") as f:
                d = pickle.load(f)
            os.remove(f.name)
            self.assertEqual(d["symbol2number"]["file_input"], 257)
            self.assertEqual(d["number2symbol"][257], "file_input")

# Generated at 2022-06-17 16:42:42.562729
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {"a": 1, "b": 2}
            g.number2symbol = {1: "a", 2: "b"}
            g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            g.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 2}),
                      2: ([(5, 6), (7, 8)], {3: 3, 4: 4})}
            g.labels = [(1, "a"), (2, "b"), (3, "c"), (4, "d")]

# Generated at 2022-06-17 16:42:43.970822
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/tmp/test_Grammar_dump")


# Generated at 2022-06-17 16:42:52.092627
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'foo': 1, 'bar': 2}
            g.number2symbol = {1: 'foo', 2: 'bar'}
            g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            g.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 1}),
                      2: ([(5, 6), (7, 8)], {5: 1, 6: 1})}

# Generated at 2022-06-17 16:43:03.295804
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen2
    from . import tokenize

    g = pgen2.driver.load_grammar("Grammar.txt")
    g.dump("Grammar.pickle")
    g2 = Grammar()
    g2.load("Grammar.pickle")
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label
    assert g.start == g2.start
   

# Generated at 2022-06-17 16:43:06.172689
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/tmp/grammar.pickle")
    g.load("/tmp/grammar.pickle")
    g.report()

# Generated at 2022-06-17 16:43:09.346773
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.pkl")
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:43:15.904775
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == 0
    assert g.dfas[257][0][0][0][0] == 0
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["False"] == 1
    assert g.tokens[token.NAME] == 2
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:43:27.232031
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pytest
    from . import pgen2
    from .pgen2 import tokenize

    g = pgen2.driver.load_grammar("Grammar/Grammar")
    g.dump("Grammar/Grammar.pickle")
    g2 = Grammar()
    g2.load("Grammar/Grammar.pickle")
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.dfas == g2.dfas
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label
    assert g.labels == g2.labels
    assert g.states

# Generated at 2022-06-17 16:43:38.096699
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import driver
    from . import token

    g = Grammar()
    g.load(driver.grammar)
    assert g.symbol2number["file_input"] == 256
    assert g.number2symbol[256] == "file_input"
    assert g.start == 256
    assert g.keywords["False"] == 257
    assert g.tokens[token.NAME] == 258
    assert g.labels[258] == (token.NAME, None)
    assert g.labels[259] == (token.NUMBER, None)
    assert g.labels[260] == (token.STRING, None)
    assert g.labels[261] == (token.NEWLINE, None)
    assert g.labels[262] == (token.INDENT, None)
    assert g

# Generated at 2022-06-17 16:43:50.416647
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0] == [(1, 1), (2, 2), (3, 3)]
    assert g.dfas[257] == ([[(1, 1), (2, 2), (3, 3)]], {1: 1, 2: 1, 3: 1})
    assert g.labels[1] == (1, None)
    assert g.keywords["and"] == 1
    assert g.tokens[1] == 1
    assert g.start == 257

# Generated at 2022-06-17 16:44:00.448996
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:44:02.363557
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import unittest
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = pgen2.load_grammar(sys.executable)
            self.assertIsInstance(g, Grammar)

    unittest.main()

# Generated at 2022-06-17 16:44:13.438507
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'a': 1}
            g.number2symbol = {1: 'a'}
            g.states = [[(1, 2), (3, 4)]]
            g.dfas = {1: ([(1, 2), (3, 4)], {1: 1})}
            g.labels = [(1, 'a'), (2, 'b')]
            g.keywords = {'a': 1}
            g.tokens = {1: 2}
            g.symbol2label = {'a': 1}
            g.start = 3
            g.async_keywords

# Generated at 2022-06-17 16:44:22.582463
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import tempfile
    import pickle
    import shutil
    from . import token

    class MyGrammar(Grammar):
        def __init__(self):
            super().__init__()
            self.symbol2number = {'foo': 256}
            self.number2symbol = {256: 'foo'}
            self.states = [[[(0, 1)]]]
            self.dfas = {256: ([[(0, 1)]], {1: 1})}
            self.labels = [(0, 'EMPTY'), (token.NAME, 'foo')]
            self.keywords = {'foo': 1}
            self.tokens = {token.NAME: 1}
            self.symbol2label = {'foo': 1}
            self.start = 256
            self

# Generated at 2022-06-17 16:44:32.787550
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[257][0][0][0][0] == token.NAME
    assert g.labels[1][0] == token.NAME
    assert g.keywords["and"] == 1
    assert g.tokens[token.NAME] == 1
    assert g.start == 257

# Generated at 2022-06-17 16:44:42.408094
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[[(1, 1), (2, 2)], [(3, 3), (4, 4)]]]
    g.dfas = {1: ([[(1, 1), (2, 2)], [(3, 3), (4, 4)]], {1: 1, 2: 1, 3: 1, 4: 1}),
              2: ([[(5, 5), (6, 6)], [(7, 7), (8, 8)]], {5: 1, 6: 1, 7: 1, 8: 1})}

# Generated at 2022-06-17 16:44:52.027227
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2
    from . import tokenize
    from . import parse

    # Create a grammar
    g = pgen2.driver.load_grammar("Grammar/Grammar")

    # Dump the grammar
    g.dump("Grammar/Grammar.pickle")

    # Load the grammar
    h = Grammar()
    h.load("Grammar/Grammar.pickle")

    # Parse a test file
    f = open("Grammar/Grammar", "rb")

# Generated at 2022-06-17 16:45:03.915003
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[257][1][token.NAME] == 1
    assert g.labels[1] == (token.NAME, None)
    assert g.keywords["and"] == 1
    assert g.tokens[token.NAME] == 1
    assert g.symbol2label["and"] == 1
    assert g.start == 257
    assert g.async_keywords == False

# Generated at 2022-06-17 16:45:14.959059
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["single_input"] == 257
    assert g.number2symbol[257] == "single_input"
    assert g.states[0][0][0][0] == token.NEWLINE
    assert g.dfas[257][0][0][0][0] == token.NEWLINE
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["False"] == 1
    assert g.tokens[token.NAME] == 2
    assert g.symbol2label["single_input"] == 257
    assert g.start == 257
    assert g.async_keywords == False

# Generated at 2022-06-17 16:45:23.386631
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.pickle")
    assert g.start == 256
    assert g.symbol2number["and"] == 258
    assert g.number2symbol[258] == "and"
    assert g.keywords["and"] == 258
    assert g.tokens[token.NAME] == 259
    assert g.labels[259] == (token.NAME, None)
    assert g.symbol2label["and"] == 258
    assert g.symbol2label["NAME"] == 259
    assert g.symbol2label["COMMA"] == 44
    assert g.symbol2label["COMMA"] == g.tokens[token.COMMA]
    assert g.symbol2label["PLUS"] == 43

# Generated at 2022-06-17 16:45:43.137880
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("test_Grammar_dump.pkl")
    g.load("test_Grammar_dump.pkl")
    g.report()
    os.remove("test_Grammar_dump.pkl")


# Generated at 2022-06-17 16:45:49.864320
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen2
    from . import tokenize

    g = pgen2.driver.load_grammar("Grammar.txt")
    g.dump("Grammar.pickle")
    g2 = Grammar()
    g2.load("Grammar.pickle")
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label
    assert g.start == g2.start
   

# Generated at 2022-06-17 16:45:53.889799
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/tmp/test_Grammar_dump")
    g2 = Grammar()
    g2.load("/tmp/test_Grammar_dump")
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.start == g2.start
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label
    assert g.async_keywords == g2.async_keywords

# Generated at 2022-06-17 16:46:02.619156
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["atom"] == 258
    assert g.number2symbol[258] == "atom"
    assert g.states[0][0][1] == 1
    assert g.dfas[258][0][0][1] == 1
    assert g.labels[1] == (0, "EMPTY")
    assert g.keywords["False"] == 2
    assert g.tokens[token.NAME] == 3
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:46:07.948744
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[258] == "as"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[258][0][0][0][0] == token.NAME
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["False"] == 1
    assert g.tokens[token.NAME] == 2
    assert g.symbol2label["testlist_star_expr"] == 259
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:46:19.492556
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {"foo": 1, "bar": 2}
    g.number2symbol = {1: "foo", 2: "bar"}
    g.states = [[(1, 2)], [(3, 4)]]
    g.dfas = {1: ([(1, 2)], {1: 1}), 2: ([(3, 4)], {3: 1})}
    g.labels = [(1, "foo"), (2, "bar"), (3, "baz")]
    g.keywords = {"foo": 1, "bar": 2}
    g.tokens = {1: 1, 2: 2}
    g.symbol2label = {"foo": 1, "bar": 2}
    g.start = 3

# Generated at 2022-06-17 16:46:26.779153
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[257][0][0][0][0] == token.NAME
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["False"] == 1
    assert g.tokens[token.NAME] == 2
    assert g.symbol2label["and"] == 257
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:46:38.651584
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.load(pgen2.__file__.replace(".py", ".pickle"))
            self.assertEqual(g.start, 257)
            self.assertEqual(g.symbol2number["file_input"], 257)
            self.assertEqual(g.number2symbol[257], "file_input")
            self.assertEqual(g.dfas[257][0][0][0], (0, 1))
            self.assertEqual(g.dfas[257][0][1][0], (0, 2))

# Generated at 2022-06-17 16:46:48.469358
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    from typing import Dict, List, Tuple

    from . import token

    class Grammar(object):
        def __init__(self) -> None:
            self.symbol2number: Dict[str, int] = {}
            self.number2symbol: Dict[int, str] = {}
            self.states: List[DFA] = []
            self.dfas: Dict[int, DFAS] = {}
            self.labels: List[Label] = [(0, "EMPTY")]
            self.keywords: Dict[str, int] = {}
            self.tokens: Dict[int, int] = {}
            self.symbol2label: Dict[str, int] = {}
            self.start = 256
            # Python

# Generated at 2022-06-17 16:46:59.351732
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import io
    import unittest
    from . import pgen2

    class GrammarDumpTests(unittest.TestCase):
        def setUp(self):
            self.grammar = pgen2.driver.load_grammar(
                "Grammar.txt", "Python.asdl", "Python/graminit.c"
            )
            self.old_stdout = sys.stdout
            sys.stdout = io.StringIO()

        def tearDown(self):
            sys.stdout = self.old_stdout

        def test_dump(self):
            self.grammar.dump("Grammar.pickle")
            self.assertEqual(sys.stdout.getvalue(), "")

    unittest.main()