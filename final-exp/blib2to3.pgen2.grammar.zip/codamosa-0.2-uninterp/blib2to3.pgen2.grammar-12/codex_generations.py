

# Generated at 2022-06-17 16:38:18.204619
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io

    class TestGrammarLoad(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[[(1, 1), (2, 2)], [(3, 3), (4, 4)]]]

# Generated at 2022-06-17 16:38:25.894801
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[257][0][0][0][0] == token.NAME
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["False"] == 1
    assert g.tokens[token.NAME] == 2
    assert g.symbol2label["and"] == 257
    assert g.start == 256

# Generated at 2022-06-17 16:38:37.856820
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.symbol2number["as"] == 258
    assert g.symbol2number["assert"] == 259
    assert g.symbol2number["break"] == 260
    assert g.symbol2number["class"] == 261
    assert g.symbol2number["continue"] == 262
    assert g.symbol2number["def"] == 263
    assert g.symbol2number["del"] == 264
    assert g.symbol2number["elif"] == 265
    assert g.symbol2number["else"] == 266
    assert g.symbol2number["except"] == 267
    assert g.symbol

# Generated at 2022-06-17 16:38:45.589180
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pytest
    from . import pgen2

    # Create a temporary file for the pickle
    with tempfile.NamedTemporaryFile(delete=False) as f:
        filename = f.name
    try:
        # Create a grammar object
        g = pgen2.driver.load_grammar("Grammar.txt")
        # Dump the grammar object to the pickle
        g.dump(filename)
        # Load the grammar object from the pickle
        g2 = Grammar()
        g2.load(filename)
        # Check that the two grammar objects are equal
        assert g == g2
    finally:
        # Delete the temporary file
        os.remove(filename)

# Generated at 2022-06-17 16:38:52.512737
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io
    import os
    import sys
    import tempfile
    from . import token

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.g = Grammar()
            self.g.symbol2number = {'foo': 1, 'bar': 2}
            self.g.number2symbol = {1: 'foo', 2: 'bar'}
            self.g.states = [[[(1, 2), (3, 4)], [(5, 6), (7, 8)]]]

# Generated at 2022-06-17 16:38:55.550280
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:38:59.386504
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.pickle")
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:39:09.094823
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import sys
    import io
    import pickle
    import os
    import tempfile
    import shutil
    import contextlib

    class GrammarTestCase(unittest.TestCase):
        def setUp(self):
            self.g = Grammar()
            self.g.symbol2number = {'a': 1, 'b': 2}
            self.g.number2symbol = {1: 'a', 2: 'b'}
            self.g.states = [[[(1, 1), (2, 2)], [(3, 3), (4, 4)]]]

# Generated at 2022-06-17 16:39:20.798697
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'foo': 1}
    g.number2symbol = {1: 'foo'}
    g.states = [[[(1, 2)], [(2, 3)]]]
    g.dfas = {1: ([[(1, 2)], [(2, 3)]], {1: 1})}
    g.labels = [(1, 'foo'), (2, 'bar')]
    g.start = 1
    g.keywords = {'foo': 1}
    g.tokens = {1: 1}
    g.symbol2label = {'foo': 1}
    g.async_keywords = False
    g.dump('/tmp/grammar.pickle')
    g2 = Grammar()

# Generated at 2022-06-17 16:39:24.080728
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("test.pickle")
    assert os.path.exists("test.pickle")
    os.remove("test.pickle")

# Generated at 2022-06-17 16:39:34.504518
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import io
    import unittest

    class Grammar_dumpTests(unittest.TestCase):
        """Test dump() method of Grammar class."""

        def test_dump(self):
            """Test dump() method of Grammar class."""
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[(0, 0)], [(0, 1)]]
            g.dfas = {1: ([(0, 0)], {0: 1}), 2: ([(0, 1)], {0: 1})}
            g.labels = [(0, None), (1, None)]

# Generated at 2022-06-17 16:39:37.664090
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:39:42.683348
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/tmp/test_Grammar_dump")
    g.load("/tmp/test_Grammar_dump")
    g.report()

# Generated at 2022-06-17 16:39:52.853386
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    from io import BytesIO
    from . import pgen2

    g = Grammar()
    pgen2.driver.load_grammar(g)
    s = BytesIO()
    pickle.dump(g, s, pickle.HIGHEST_PROTOCOL)
    s.seek(0)
    g2 = Grammar()
    g2.loads(s.read())
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens

# Generated at 2022-06-17 16:40:04.721017
# Unit test for method load of class Grammar
def test_Grammar_load():
    """
    Test that Grammar.load() works.
    """
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[257][0][0][0][0] == token.NAME
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["False"] == 1
    assert g.tokens[token.NAME] == 2
    assert g.symbol2label["and"] == 257

# Generated at 2022-06-17 16:40:10.937059
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0] == [(257, 1), (256, 2)]
    assert g.dfas[257] == ([[(257, 1), (256, 2)]], {1: 1})
    assert g.labels[257] == (257, None)
    assert g.keywords["and"] == 257
    assert g.tokens[token.NAME] == 256
    assert g.start == 256

# Generated at 2022-06-17 16:40:14.024778
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    g.report()

# Generated at 2022-06-17 16:40:25.271502
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    from . import pgen2
    from . import tokenize

    # Create a grammar object
    g = pgen2.driver.load_grammar(tokenize.__file__)

    # Dump the grammar object to a pickle file
    g.dump("Grammar.pickle")

    # Load the grammar object from the pickle file
    g2 = Grammar()
    g2.load("Grammar.pickle")

    # Compare the two grammar objects
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords

# Generated at 2022-06-17 16:40:35.573470
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[258] == "as"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[258][0][0][0][0] == token.NAME
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["False"] == 1
    assert g.tokens[token.NAME] == 2
    assert g.symbol2label["and"] == 257
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:40:43.180273
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == 258
    assert g.dfas[257][0][0][0][0] == 258
    assert g.labels[258] == (1, "and")
    assert g.keywords["and"] == 258
    assert g.tokens[1] == 258
    assert g.symbol2label["and"] == 258
    assert g.start == 256

# Generated at 2022-06-17 16:40:49.784689
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pkl"))
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:41:01.464578
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import io
    import os
    import tempfile
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = pgen2.driver.load_grammar("Grammar.txt")
            g.dump("Grammar.pkl")
            with open("Grammar.pkl", "rb") as f:
                d = pickle.load(f)
            self.assertEqual(d["symbol2number"], g.symbol2number)
            self.assertEqual(d["number2symbol"], g.number2symbol)
            self.assertEqual(d["states"], g.states)
            self.assertEqual(d["dfas"], g.dfas)
            self

# Generated at 2022-06-17 16:41:10.636674
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[(1, 1)]]
            g.dfas = {1: ([(1, 1)], {1: 1})}
            g.labels = [(1, 'foo')]
            g.keywords = {'foo': 1}
            g.tokens = {1: 1}
            g.symbol2label = {'foo': 1}
            g.start = 1
            g.async_keywords = True

            f = io.BytesIO()

# Generated at 2022-06-17 16:41:15.566482
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert grammar.symbol2number["and"] == 257
    assert grammar.number2symbol[257] == "and"
    assert grammar.states[0][0][0][0] == token.NAME
    assert grammar.dfas[257][0][0][0][0] == token.NAME
    assert grammar.labels[0] == (0, "EMPTY")
    assert grammar.keywords["False"] == 1
    assert grammar.tokens[token.NAME] == 0
    assert grammar.symbol2label["and"] == 257
    assert grammar.start == 256
    assert grammar.async_keywords == False

# Generated at 2022-06-17 16:41:17.633586
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/tmp/test.pkl")
    g.load("/tmp/test.pkl")

# Generated at 2022-06-17 16:41:26.109551
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Test that dump() works
    g = Grammar()
    g.symbol2number = {"foo": 1}
    g.number2symbol = {1: "foo"}
    g.states = [[[(0, 1)], [(0, 2)]]]
    g.dfas = {1: ([[(0, 1)], [(0, 2)]], {1: 1}), 2: ([[(0, 1)], [(0, 2)]], {1: 1})}
    g.labels = [(0, "EMPTY"), (1, None), (2, None)]
    g.keywords = {"foo": 1}
    g.tokens = {1: 1, 2: 2}
    g.symbol2label = {"foo": 1}
    g.start = 256
    g.async_keywords

# Generated at 2022-06-17 16:41:33.513875
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.txt"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == 257
    assert g.dfas[257][0][0][0][0] == 257
    assert g.labels[257][0] == 257
    assert g.keywords["and"] == 257
    assert g.tokens[token.AND] == 257
    assert g.symbol2label["and"] == 257
    assert g.start == 256

# Generated at 2022-06-17 16:41:43.895533
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import shutil
    import tempfile

    from . import pgen2

    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-17 16:41:49.017773
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.pickle")
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:41:56.113577
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import unittest

    class GrammarTestCase(unittest.TestCase):
        def test_load(self):
            grammar = Grammar()
            grammar.load(sys.executable)
            self.assertTrue(grammar.symbol2number)
            self.assertTrue(grammar.number2symbol)
            self.assertTrue(grammar.states)
            self.assertTrue(grammar.dfas)
            self.assertTrue(grammar.labels)
            self.assertTrue(grammar.keywords)
            self.assertTrue(grammar.tokens)
            self.assertTrue(grammar.symbol2label)
            self.assertTrue(grammar.start)

    unittest.main()

# Generated at 2022-06-17 16:42:14.033691
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test that Grammar.load() can load a pickle file generated by
    # Grammar.dump()
    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[[(1, 1), (2, 2)], [(3, 3), (4, 4)]]]
    g.dfas = {1: ([[(1, 1), (2, 2)], [(3, 3), (4, 4)]], {1: 1, 2: 1}),
              2: ([[(1, 1), (2, 2)], [(3, 3), (4, 4)]], {1: 1, 2: 1})}

# Generated at 2022-06-17 16:42:24.046717
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == 1
    assert g.dfas[257][0][0][0][0] == 1
    assert g.labels[1] == (1, None)
    assert g.keywords["and"] == 1
    assert g.tokens[token.NAME] == 2
    assert g.start == 257

# Generated at 2022-06-17 16:42:32.493336
# Unit test for method load of class Grammar
def test_Grammar_load():
    import io
    import pickle
    import unittest

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'a': 1}
            g.number2symbol = {1: 'a'}
            g.states = [[[(1, 2)], [(2, 3)]]]
            g.dfas = {1: ([[(1, 2)], [(2, 3)]], {1: 1, 2: 1})}
            g.labels = [(1, 'a'), (2, 'b')]
            g.keywords = {'a': 1}
            g.tokens = {1: 1}
            g.symbol2label = {'a': 1}
            g.start = 256

# Generated at 2022-06-17 16:42:42.557585
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))

# Generated at 2022-06-17 16:42:51.443754
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    from . import pgen2

    g = Grammar()
    g.load(pgen2.__file__.replace(".py", ".pkl"))
    assert g.symbol2number["atom"] == 258
    assert g.number2symbol[258] == "atom"
    assert g.states[0][0][0][0] == token.NAME
    assert g.states[0][0][0][1] == 1
    assert g.states[0][1][0][0] == token.LPAR
    assert g.states[0][1][0][1] == 2
    assert g.states[0][1][1][0] == token.LSQB
    assert g.states[0][1][1][1] == 3
    assert g.states[0][1][2][0] == token

# Generated at 2022-06-17 16:43:03.161655
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test that Grammar.load() works
    g = Grammar()
    g.symbol2number = {"foo": 1}
    g.number2symbol = {1: "foo"}
    g.states = [[[(1, 2)], [(3, 4)]]]
    g.dfas = {1: ([[(1, 2)], [(3, 4)]], {1: 1}), 2: ([[(1, 2)], [(3, 4)]], {1: 1})}
    g.labels = [(1, "foo"), (2, "bar")]
    g.keywords = {"foo": 1, "bar": 2}
    g.tokens = {1: 1, 2: 2}
    g.symbol2label = {"foo": 1, "bar": 2}
    g.start = 1

# Generated at 2022-06-17 16:43:12.866022
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pkl"))
    assert g.symbol2number["and_expr"] == 258
    assert g.number2symbol[258] == "and_expr"
    assert g.states[0][0][0][0] == 0
    assert g.dfas[258][0][0][0][0] == 0
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["False"] == 1
    assert g.tokens[token.NAME] == 2
    assert g.symbol2label["and_expr"] == 258
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:43:24.204827
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[257][0][0][0][0] == token.NAME
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["and"] == 1
    assert g.tokens[token.NAME] == 2
    assert g.symbol2label["and"] == 1
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:43:35.515130
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import io
    import sys
    import os
    import tempfile
    import shutil

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.filename = os.path.join(self.tempdir, "test_grammar.pkl")

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_dump(self):
            g = Grammar()
            g.dump(self.filename)
            with open(self.filename, "rb") as f:
                d = pickle.load(f)
            self.assertEqual(d, g.__dict__)

        def test_load(self):
            g = Gram

# Generated at 2022-06-17 16:43:37.769508
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("test.pkl")
    g.load("test.pkl")
    os.remove("test.pkl")

# Generated at 2022-06-17 16:44:00.953993
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    from . import token

    # Create a Grammar object
    g = Grammar()
    g.symbol2number = {'foo': 257, 'bar': 258}
    g.number2symbol = {257: 'foo', 258: 'bar'}
    g.states = [[[(0, 1), (1, 2)], [(0, 2)]]]
    g.dfas = {257: ([[(0, 1), (1, 2)], [(0, 2)]], {1: 1, 2: 1}), 258: ([[(0, 1), (1, 2)], [(0, 2)]], {1: 1, 2: 1})}
    g.labels = [(0, 'EMPTY'), (1, None), (2, None)]

# Generated at 2022-06-17 16:44:13.304655
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2
    from . import pgen2_grammar

    g = Grammar()
    g.load(pgen2.grammar_file)
    assert g.start == pgen2_grammar.start
    assert g.symbol2number == pgen2_grammar.symbol2number
    assert g.number2symbol == pgen2_grammar.number2symbol
    assert g.states == pgen2_grammar.states
    assert g.dfas == pgen2_grammar.dfas
    assert g.labels == pgen2_grammar.labels
    assert g.keywords == pgen2_grammar.keywords
    assert g.tokens == pgen2_grammar.tokens

# Generated at 2022-06-17 16:44:22.582466
# Unit test for method load of class Grammar
def test_Grammar_load():
    import os
    import pickle
    import tempfile
    from typing import Dict, List, Tuple

    from . import token

    # mypyc generates objects that don't have a __dict__, but they
    # do have __getstate__ methods that will return an equivalent
    # dictionary
    def getstate(obj):
        if hasattr(obj, "__dict__"):
            return obj.__dict__
        else:
            return obj.__getstate__()  # type: ignore

    class Grammar(object):
        def __init__(self) -> None:
            self.symbol2number: Dict[str, int] = {}
            self.number2symbol: Dict[int, str] = {}
            self.states: List[DFA] = []

# Generated at 2022-06-17 16:44:34.080405
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    from io import BytesIO

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.loads(b"\x80\x03}q\x00(X\x0b\x00\x00\x00symbol2numberq\x01}q\x02X\x04\x00\x00\x00asyncq\x03K\x01X\x04\x00\x00\x00testq\x04K\x02u.")
            self.assertEqual(g.symbol2number, {"async": 1, "test": 2})

    unittest.main()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:44:42.595004
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pytest
    from . import pgen2

    g = Grammar()
    g.load(pgen2.__file__.replace(".pyc", ".pkl"))
    assert g.start == 256
    assert g.number2symbol[256] == "file_input"
    assert g.symbol2number["file_input"] == 256
    assert g.symbol2number["stmt"] == 257
    assert g.number2symbol[257] == "stmt"
    assert g.symbol2number["simple_stmt"] == 258
    assert g.number2symbol[258] == "simple_stmt"
    assert g.symbol2number["small_stmt"] == 259
    assert g.number2symbol[259] == "small_stmt"

# Generated at 2022-06-17 16:44:51.221639
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test that Grammar.load() works
    g = Grammar()
    g.load(__file__.replace(".py", ".pickle"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == 257
    assert g.dfas[257][0][0][0][0] == 257
    assert g.labels[257][0] == 257
    assert g.keywords["and"] == 257
    assert g.tokens[token.AND] == 257
    assert g.symbol2label["and"] == 257
    assert g.start == 256

# Generated at 2022-06-17 16:45:03.524150
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import unittest
    from io import BytesIO

    class GrammarTest(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[(1, 2)]]
            g.dfas = {1: ([(1, 2)], {1: 1})}
            g.labels = [(1, 'foo')]
            g.keywords = {'foo': 1}
            g.tokens = {1: 1}
            g.symbol2label = {'foo': 1}
            g.start = 1
            g.async_keywords = False

            f = BytesIO()
            g

# Generated at 2022-06-17 16:45:14.257156
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[257][0][0][0][0] == token.NAME
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["and"] == 257
    assert g.tokens[token.NAME] == 1
    assert g.symbol2label["and"] == 257
    assert g.start == 256
    assert g.async_keywords == False


# Generated at 2022-06-17 16:45:17.612939
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import unittest

    class GrammarTest(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.dump(sys.stdout)

    unittest.main()

# Generated at 2022-06-17 16:45:27.957570
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import tempfile
    import os
    import shutil
    import io

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.filename = os.path.join(self.tempdir, 'test.pickle')
            self.g = Grammar()
            self.g.symbol2number = {'a': 1, 'b': 2}
            self.g.number2symbol = {1: 'a', 2: 'b'}
            self.g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]

# Generated at 2022-06-17 16:45:57.150470
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import io
    from . import pgen2

    class TestGrammarDump(unittest.TestCase):
        def test_dump(self):
            g = pgen2.grammar.Grammar()
            g.symbol2number = {'foo': 1, 'bar': 2}
            g.number2symbol = {1: 'foo', 2: 'bar'}
            g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            g.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 2}),
                      2: ([(5, 6), (7, 8)], {3: 3, 4: 4})}

# Generated at 2022-06-17 16:46:08.896560
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import pickle
    import unittest

    class GrammarTestCase(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'foo': 1, 'bar': 2}
            g.number2symbol = {1: 'foo', 2: 'bar'}
            g.states = [[[(1, 2), (3, 4)], [(5, 6), (7, 8)]]]
            g.dfas = {1: ([[(1, 2), (3, 4)], [(5, 6), (7, 8)]], {1: 1, 2: 1}),
                      2: ([[(1, 2), (3, 4)], [(5, 6), (7, 8)]], {1: 1, 2: 1})}

# Generated at 2022-06-17 16:46:20.508754
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    import io
    import sys
    from . import pgen2

    # Create a grammar
    g = pgen2.driver.load_grammar("Grammar/Grammar")

    # Dump the grammar to a pickle file
    fd, filename = tempfile.mkstemp()
    os.close(fd)
    g.dump(filename)

    # Load the grammar from the pickle file
    g2 = Grammar()
    g2.load(filename)

    # Dump the grammar to a pickle bytes object
    f = io.BytesIO()
    g.dump(f)
    f.seek(0)

    # Load the grammar from the pickle bytes object
    g3 = Grammar()
    g3.loads(f.read())

    # Compare the two grammars
   

# Generated at 2022-06-17 16:46:27.856326
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = pgen2.driver.load_grammar("Grammar.txt")
            g.dump("Grammar.pickle")
            g2 = Grammar()
            g2.load("Grammar.pickle")
            self.assertEqual(g.symbol2number, g2.symbol2number)
            self.assertEqual(g.number2symbol, g2.number2symbol)
            self.assertEqual(g.states, g2.states)
            self.assertEqual(g.dfas, g2.dfas)
            self.assertEqual(g.labels, g2.labels)

# Generated at 2022-06-17 16:46:39.343965
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import io
    import sys
    import unittest

    class Grammar_dump_TestCase(unittest.TestCase):
        def test_dump(self):
            # Test that Grammar.dump() writes a pickle file that can be read
            # back in.
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]

# Generated at 2022-06-17 16:46:51.326163
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import tempfile
    import os
    import shutil

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.filename = os.path.join(self.tempdir, "grammar.pickle")
            self.g = Grammar()
            self.g.symbol2number = {"a": 1, "b": 2}
            self.g.number2symbol = {1: "a", 2: "b"}
            self.g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]

# Generated at 2022-06-17 16:46:55.559946
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.pickle")
    g.report()


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:46:58.563546
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    g.report()

# Generated at 2022-06-17 16:47:03.894452
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("test_Grammar_dump.pkl")
    g.load("test_Grammar_dump.pkl")
    g.report()
    os.remove("test_Grammar_dump.pkl")


# Generated at 2022-06-17 16:47:11.918601
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import tempfile
    import pickle
    from typing import Any, Dict, List, Optional, Text, Tuple, TypeVar, Union
    from . import token
    _P = TypeVar("_P", bound="Grammar")
    Label = Tuple[int, Optional[Text]]
    DFA = List[List[Tuple[int, int]]]
    DFAS = Tuple[DFA, Dict[int, int]]
    Path = Union[str, "os.PathLike[str]"]
