

# Generated at 2022-06-17 16:38:09.929930
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[257][0][0][0][0] == token.NAME
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["and"] == 257
    assert g.tokens[token.NAME] == 258
    assert g.symbol2label["and"] == 257
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:38:14.265252
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import tempfile
    from . import pgen2

    # Create a temporary directory
    temp_dir = tempfile.TemporaryDirectory()
    temp_dir_name = temp_dir.name

    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir_name, delete=False)
    temp_file_name = temp_file.name

    # Create a Grammar object
    grammar = pgen2.driver.load_grammar(temp_dir_name)

    # Dump the grammar tables to a pickle file
    grammar.dump(temp_file_name)

    # Check that the file exists
    assert os.path.isfile(temp_file_name)

    # Remove the temporary file
    os.remove(temp_file_name)

    # Remove the temporary

# Generated at 2022-06-17 16:38:24.261073
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import tempfile
    import os

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[(0, 1), (1, 2)], [(0, 3), (2, 4)]]
            g.dfas = {1: ([(0, 1), (1, 2)], {1: 1}), 2: ([(0, 3), (2, 4)], {2: 1})}
            g.labels = [(0, 'EMPTY'), (1, None), (2, None)]

# Generated at 2022-06-17 16:38:36.186309
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen2
    from . import token

    g = pgen2.load_grammar("Grammar.txt")
    g.dump("Grammar.pickle")
    h = Grammar()
    h.load("Grammar.pickle")
    assert g.symbol2number == h.symbol2number
    assert g.number2symbol == h.number2symbol
    assert g.states == h.states
    assert g.dfas == h.dfas
    assert g.labels == h.labels
    assert g.start == h.start
    assert g.keywords == h.keywords
    assert g.tokens == h.tokens
    assert g.symbol2label == h.symbol2label
    assert g.async_keywords == h.async_

# Generated at 2022-06-17 16:38:49.679199
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    import unittest

    class GrammarTestCase(unittest.TestCase):

        def setUp(self):
            self.g = Grammar()
            self.g.symbol2number = {'foo': 1, 'bar': 2}
            self.g.number2symbol = {1: 'foo', 2: 'bar'}
            self.g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            self.g.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 2}),
                           2: ([(5, 6), (7, 8)], {3: 3, 4: 4})}

# Generated at 2022-06-17 16:39:01.845565
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import sys
    from . import pgen2
    from . import tokenize

    if sys.version_info < (3, 7):
        return

    # Create a grammar object
    g = pgen2.driver.load_grammar("Grammar/Grammar")

    # Dump the grammar tables to a pickle file
    filename = "Grammar/Grammar.pickle"
    g.dump(filename)

    # Load the grammar tables from the pickle file
    g2 = Grammar()
    g2.load(filename)

    # Remove the pickle file
    os.remove(filename)

    # Verify that the grammar tables are the same
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol

# Generated at 2022-06-17 16:39:10.473996
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    from typing import Any, Dict, List, Optional, Text, Tuple, TypeVar, Union
    from . import token

    _P = TypeVar("_P", bound="Grammar")
    Label = Tuple[int, Optional[Text]]
    DFA = List[List[Tuple[int, int]]]
    DFAS = Tuple[DFA, Dict[int, int]]
    Path = Union[str, "os.PathLike[str]"]


# Generated at 2022-06-17 16:39:20.217786
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pkl"))
    assert g.symbol2number["and_expr"] == 258
    assert g.number2symbol[258] == "and_expr"
    assert g.states[0][0][0][0] == 258
    assert g.dfas[258][0][0][0][0] == 258
    assert g.labels[258][0] == 258
    assert g.keywords["False"] == 259
    assert g.tokens[token.NAME] == 260
    assert g.symbol2label["and_expr"] == 258
    assert g.start == 256

# Generated at 2022-06-17 16:39:30.675126
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    import io

    class MyGrammar(Grammar):
        def __init__(self):
            super().__init__()
            self.symbol2number = {"foo": 1}
            self.number2symbol = {1: "foo"}
            self.states = [[[(1, 1)]]]
            self.dfas = {1: ([[(1, 1)]], {1: 1})}
            self.labels = [(1, "foo")]
            self.keywords = {"foo": 1}
            self.tokens = {1: 1}
            self.symbol2label = {"foo": 1}
            self.start = 1

    g = MyGrammar()
    f = io.BytesIO()
    g.dump(f)
    f.seek(0)

# Generated at 2022-06-17 16:39:33.941455
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == 0
    assert g.dfas[257][0][0][0][0] == 0
    assert g.labels[0][0] == 0
    assert g.keywords["False"] == 0
    assert g.tokens[token.NAME] == 0
    assert g.symbol2label["and"] == 0
    assert g.start == 256

# Generated at 2022-06-17 16:39:51.106116
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2 import driver
    from . import token

    g = driver.load_grammar("Grammar/Grammar")
    g.dump("Grammar/Grammar.pickle")
    g2 = Grammar()
    g2.load("Grammar/Grammar.pickle")
    assert g2.symbol2number == g.symbol2number
    assert g2.number2symbol == g.number2symbol
    assert g2.states == g.states
    assert g2.dfas == g.dfas
    assert g2.labels == g.labels
    assert g2.keywords == g.keywords
    assert g2.tokens == g.tokens
    assert g2.symbol2label == g.symbol2label
    assert g2.start

# Generated at 2022-06-17 16:39:59.032291
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import io
    import pickle
    import sys
    import os
    import tempfile
    from typing import Any, Dict, List, Optional, Text, Tuple, TypeVar, Union


# Generated at 2022-06-17 16:40:08.432070
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import pickle
    import unittest

    from . import grammar
    from . import token

    class GrammarDumpTests(unittest.TestCase):
        def setUp(self):
            self.g = grammar.Grammar()
            self.g.symbol2number = {"foo": 1, "bar": 2}
            self.g.number2symbol = {1: "foo", 2: "bar"}
            self.g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            self.g.dfas = {1: ([(1, 2), (3, 4)], {1: 1, 2: 2}), 2: ([(5, 6), (7, 8)], {3: 3, 4: 4})}

# Generated at 2022-06-17 16:40:11.506178
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    g.report()

# Generated at 2022-06-17 16:40:23.434051
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[[(1, 1), (2, 2)], [(3, 3), (4, 4)]]]
    g.dfas = {1: ([[(1, 1), (2, 2)], [(3, 3), (4, 4)]], {1: 1, 2: 1, 3: 1, 4: 1}), 2: ([[(1, 1), (2, 2)], [(3, 3), (4, 4)]], {1: 1, 2: 1, 3: 1, 4: 1})}

# Generated at 2022-06-17 16:40:31.097524
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    import unittest

    class TestGrammar(Grammar):
        def __init__(self):
            super().__init__()
            self.symbol2number = {'foo': 1}
            self.number2symbol = {1: 'foo'}
            self.states = [[[(1, 1)]]]
            self.dfas = {1: ([[(1, 1)]], {1: 1})}
            self.labels = [(1, 'foo')]
            self.keywords = {'foo': 1}
            self.tokens = {1: 1}
            self.symbol2label = {'foo': 1}
            self.start = 1
            self.async_keywords = False


# Generated at 2022-06-17 16:40:43.065143
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io
    import sys

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            # Test Grammar.load()
            g = Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[[(1, 2)], [(3, 4)]]]
            g.dfas = {1: ([[(1, 2)], [(3, 4)]], {1: 1, 2: 1})}
            g.labels = [(1, None), (2, None), (3, None), (4, None)]
            g.keywords = {'bar': 3}
            g.tokens = {5: 1}
           

# Generated at 2022-06-17 16:40:51.497421
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["single_input"] == 256
    assert g.number2symbol[256] == "single_input"
    assert g.states[0][0][0][0] == token.NEWLINE
    assert g.dfas[258][0][0][0][0] == token.NEWLINE
    assert g.labels[1] == (token.NEWLINE, None)
    assert g.keywords["False"] == 2
    assert g.tokens[token.NAME] == 3
    assert g.symbol2label["single_input"] == 258
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:41:02.707809
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test that Grammar.load() works as expected
    #
    # Setup
    g = Grammar()
    g.symbol2number = {"foo": 1}
    g.number2symbol = {1: "foo"}
    g.states = [[[(1, 2)]]]
    g.dfas = {1: ([[(1, 2)]], {2: 1}), 2: ([[(1, 2)]], {2: 1})}
    g.labels = [(1, "foo")]
    g.keywords = {"foo": 1}
    g.tokens = {1: 1}
    g.symbol2label = {"foo": 1}
    g.start = 1
    g.async_keywords = False

# Generated at 2022-06-17 16:41:10.755869
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    from . import token

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.symbol2number = {"foo": 1, "bar": 2}
            g.number2symbol = {1: "foo", 2: "bar"}
            g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
            g.dfas = {1: (g.states[0], {1: 1}), 2: (g.states[1], {1: 1})}
            g.labels = [(token.NAME, "foo"), (token.NAME, "bar")]
            g.keywords = {"foo": 1, "bar": 2}
            g.t

# Generated at 2022-06-17 16:41:19.404420
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("test.pkl")
    g.load("test.pkl")
    g.report()

# Generated at 2022-06-17 16:41:26.134081
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import tempfile
    from . import pgen2

    class GrammarDumpTest(unittest.TestCase):
        def test_dump(self):
            grammar = pgen2.driver.load_grammar("Grammar.txt")
            with tempfile.TemporaryDirectory() as tmpdir:
                grammar.dump(os.path.join(tmpdir, "Grammar.pickle"))
                grammar.load(os.path.join(tmpdir, "Grammar.pickle"))
                self.assertEqual(grammar.start, 256)

    unittest.main()

# Generated at 2022-06-17 16:41:34.464021
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    from io import BytesIO
    from . import pgen2

    g = pgen2.generate_grammar("Grammar.test")
    g.dump("Grammar.test")
    g2 = Grammar()
    g2.load("Grammar.test")
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label

# Generated at 2022-06-17 16:41:44.246996
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'foo': 1}
    g.number2symbol = {1: 'foo'}
    g.states = [[(0, 0), (1, 1)]]
    g.dfas = {1: (g.states[0], {0: 1})}
    g.labels = [(0, None), (1, None)]
    g.keywords = {'foo': 1}
    g.tokens = {1: 1}
    g.symbol2label = {'foo': 1}
    g.start = 1
    g.async_keywords = False
    g.dump(os.path.join(tempfile.gettempdir(), 'test_Grammar_dump'))
    g2 = Grammar()

# Generated at 2022-06-17 16:41:54.827583
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2
    from .pgen2 import tokenize

    # Create a grammar object
    g = pgen2.driver.load_grammar("Grammar/Grammar")

    # Dump the grammar tables to a pickle file
    g.dump("Grammar/Grammar.pickle")

    # Load the grammar tables from a pickle file
    g2 = Grammar()
    g2.load("Grammar/Grammar.pickle")

    # Test that the grammar tables are the same
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
   

# Generated at 2022-06-17 16:42:03.113254
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][1] == 1
    assert g.dfas[257][0][0][1] == 1
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["and"] == 257
    assert g.tokens[token.NAME] == 258
    assert g.start == 256

# Generated at 2022-06-17 16:42:09.172460
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import io
    import unittest
    from unittest.mock import patch

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            with patch('sys.stdout', new=io.StringIO()) as fake_out:
                g = Grammar()
                g.dump(sys.stdout)
                self.assertEqual(fake_out.getvalue(), '')

    unittest.main()


# Generated at 2022-06-17 16:42:21.213188
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io
    import os
    import sys
    import tempfile

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.g = Grammar()
            self.g.symbol2number = {'a': 1, 'b': 2}
            self.g.number2symbol = {1: 'a', 2: 'b'}
            self.g.states = [[[(1, 1), (2, 2)], [(3, 3), (4, 4)]]]

# Generated at 2022-06-17 16:42:30.419066
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pytest
    from . import pgen2

    def test_load(pkl: bytes) -> None:
        g = Grammar()
        g.loads(pkl)

# Generated at 2022-06-17 16:42:38.303401
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen2
    from . import tokenize

    g = pgen2.driver.load_grammar("Grammar.txt")
    g.dump("Grammar.pickle")
    g2 = Grammar()
    g2.load("Grammar.pickle")
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label
    assert g.start == g2.start
   

# Generated at 2022-06-17 16:42:55.205999
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import pickle
    from . import pgen2

    g = pgen2.driver.load_grammar("Grammar.txt")
    f = io.BytesIO()
    g.dump(f)
    f.seek(0)
    g2 = Grammar()
    g2.loads(f.read())
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label
   

# Generated at 2022-06-17 16:43:06.064243
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("test_Grammar_dump.pickle")
    g2 = Grammar()
    g2.load("test_Grammar_dump.pickle")
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label
    assert g.start == g2.start
    assert g.async_keywords == g2.async_keywords

# Generated at 2022-06-17 16:43:10.352582
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import unittest
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            grammar = pgen2.grammar.Grammar()
            grammar.dump(sys.stdout)

    unittest.main()

# Generated at 2022-06-17 16:43:14.033401
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = pgen2.grammar.Grammar()
            g.load("Grammar.pickle")

    unittest.main()

# Generated at 2022-06-17 16:43:26.021593
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io
    import os

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[[(0, 1)], [(0, 2)]]]
            g.dfas = {1: ([[(0, 1)], [(0, 2)]], {1: 1}), 2: ([[(0, 1)], [(0, 2)]], {1: 1})}
            g.labels = [(0, 'EMPTY'), (1, 'foo'), (2, 'bar')]
            g.keywords = {'foo': 1, 'bar': 2}


# Generated at 2022-06-17 16:43:35.594808
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == 257
    assert g.dfas[257][0][0][0][0] == 257
    assert g.labels[257][0] == 257
    assert g.keywords["and"] == 257
    assert g.tokens[token.NAME] == 258
    assert g.start == 257
    assert g.async_keywords == False

# Generated at 2022-06-17 16:43:42.653474
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import tempfile
    import pickle
    from . import token

    class TestGrammar(Grammar):
        def __init__(self):
            super().__init__()
            self.symbol2number = {'foo': 257, 'bar': 258}
            self.number2symbol = {257: 'foo', 258: 'bar'}
            self.states = [[[(0, 1)], [(0, 2)]], [[(0, 3)], [(0, 4)]]]
            self.dfas = {257: ([[(0, 1)], [(0, 2)]], {257: 1}), 258: ([[(0, 3)], [(0, 4)]], {258: 1})}

# Generated at 2022-06-17 16:43:47.234223
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[257][0][0][0][0] == token.NAME
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["False"] == 1
    assert g.tokens[token.NAME] == 2
    assert g.symbol2label["and"] == 257
    assert g.start == 256

# Generated at 2022-06-17 16:43:57.157623
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import tempfile
    import pickle
    import os
    import shutil
    import sys

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.filename = os.path.join(self.tempdir, "grammar.pickle")
            self.g = Grammar()
            self.g.symbol2number = {'a': 1, 'b': 2}
            self.g.number2symbol = {1: 'a', 2: 'b'}
            self.g.states = [[(1, 1), (2, 2)], [(3, 3), (4, 4)]]

# Generated at 2022-06-17 16:44:03.901203
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 256
    assert g.number2symbol[256] == "and"
    assert g.states[0][0][0][0] == 1
    assert g.dfas[256][0][0][0][0] == 1
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["and"] == 1
    assert g.tokens[token.NAME] == 2
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:44:25.248986
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pkl"))
    g.report()

# Generated at 2022-06-17 16:44:35.458190
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import sys
    import os
    import pickle
    import tempfile
    import shutil
    import io
    import contextlib
    from . import token

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.filename = os.path.join(self.tempdir, "grammar.pickle")
            self.grammar = Grammar()
            self.grammar.symbol2number = {'foo': 1, 'bar': 2}
            self.grammar.number2symbol = {1: 'foo', 2: 'bar'}
            self.grammar.states = [[[(1, 1), (2, 2)], [(3, 3), (4, 4)]]]

# Generated at 2022-06-17 16:44:43.376420
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pytest
    from . import pgen2
    from .pgen2 import driver

    with pytest.raises(SystemExit):
        driver.main(["-h"])

    with pytest.raises(SystemExit):
        driver.main(["-v"])

    with pytest.raises(SystemExit):
        driver.main(["-vv"])

    with pytest.raises(SystemExit):
        driver.main(["-vvv"])

    with pytest.raises(SystemExit):
        driver.main(["-vvvv"])

    with pytest.raises(SystemExit):
        driver.main(["-vvvvv"])

    with pytest.raises(SystemExit):
        driver.main(["-vvvvvv"])


# Generated at 2022-06-17 16:44:52.319569
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    from . import token
    from .pgen2 import tokenize

    # Create a grammar object
    g = Grammar()
    g.symbol2number = {'foo': 257, 'bar': 258}
    g.number2symbol = {257: 'foo', 258: 'bar'}
    g.states = [[[(0, 1)], [(1, 2)], [(2, 3)], [(3, 4)], [(4, 5)], [(5, 6)]]]

# Generated at 2022-06-17 16:45:04.257259
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[(1, 2)]]
            g.dfas = {1: ([(1, 2)], {1: 2})}
            g.labels = [(1, 'foo')]
            g.keywords = {'foo': 1}
            g.tokens = {1: 1}
            g.symbol2label = {'foo': 1}
            g.start = 1
            g.async_keywords = False

            f = io.BytesIO()

# Generated at 2022-06-17 16:45:08.882492
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest

    class TestGrammarLoad(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.load(__file__.replace(".py", ".pkl"))

    unittest.main()

# Generated at 2022-06-17 16:45:18.751200
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    import io
    import sys
    import unittest

    class TestGrammar(unittest.TestCase):

        def test_load(self):
            # Test that Grammar.load() works
            g = Grammar()
            g.symbol2number = {'foo': 1}
            g.number2symbol = {1: 'foo'}
            g.states = [[[(0, 1)]]]
            g.dfas = {1: ([[(0, 1)]], {1: 1})}
            g.labels = [(0, 'EMPTY'), (1, None)]
            g.keywords = {'foo': 1}
            g.tokens = {1: 1}
            g.symbol2label = {'foo': 1}
            g.start = 256

           

# Generated at 2022-06-17 16:45:22.151955
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pkl"))
    g.report()


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-17 16:45:30.264380
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import tempfile
    from . import token

    # Create a grammar object
    g = Grammar()
    g.symbol2number = {'foo': 256, 'bar': 257}
    g.number2symbol = {256: 'foo', 257: 'bar'}
    g.states = [[[(1, 2)], [(3, 4)]]]
    g.dfas = {256: (g.states[0], {1: 1, 3: 1}), 257: (g.states[0], {1: 1, 3: 1})}
    g.labels = [(0, 'EMPTY'), (1, None), (3, None)]
    g.keywords = {'foo': 1, 'bar': 3}

# Generated at 2022-06-17 16:45:39.377347
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[(1, 1), (2, 2)], [(3, 3), (4, 4)]]
    g.dfas = {1: (1, {1: 1, 2: 1}), 2: (2, {3: 1, 4: 1})}
    g.labels = [(0, 'EMPTY'), (1, None), (2, None), (3, None), (4, None)]
    g.keywords = {'foo': 1, 'bar': 2}
    g.tokens = {1: 1, 2: 2}

# Generated at 2022-06-17 16:46:23.475939
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import os
    import tempfile
    from . import token

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.g = Grammar()
            self.g.symbol2number = {'foo': 257, 'bar': 258}
            self.g.number2symbol = {257: 'foo', 258: 'bar'}
            self.g.states = [[[(1, 2), (3, 4)], [(5, 6), (7, 8)]]]

# Generated at 2022-06-17 16:46:35.553368
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen2
    from . import tokenize

    g = pgen2.driver.load_grammar("Grammar.txt")
    g.dump("Grammar.pickle")
    g2 = Grammar()
    g2.load("Grammar.pickle")
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label
    assert g.start == g2.start
   

# Generated at 2022-06-17 16:46:42.074877
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert g.symbol2number["and"] == 257
    assert g.number2symbol[257] == "and"
    assert g.states[0][0][0][0] == token.NAME
    assert g.dfas[257][0][0][0][0] == token.NAME
    assert g.labels[0] == (0, "EMPTY")
    assert g.keywords["and"] == 257
    assert g.tokens[token.NAME] == 258
    assert g.symbol2label["and"] == 257
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-17 16:46:50.876018
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import os
    import pickle
    import tempfile
    from . import token

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.g = Grammar()
            self.g.symbol2number = {'foo': 1, 'bar': 2}
            self.g.number2symbol = {1: 'foo', 2: 'bar'}
            self.g.states = [[[(1, 1), (2, 2)], [(3, 3), (4, 4)]]]

# Generated at 2022-06-17 16:47:01.589616
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    import os
    import sys
    import io
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.temp_file = tempfile.NamedTemporaryFile(delete=False)
            self.temp_file.close()

        def tearDown(self):
            os.remove(self.temp_file.name)

        def test_dump(self):
            g = pgen2.grammar.Grammar()
            g.dump(self.temp_file.name)
            with open(self.temp_file.name, "rb") as f:
                d = pickle.load(f)
            self.assertEqual(d, g.__dict__)


# Generated at 2022-06-17 16:47:11.258570
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    from . import pgen2

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = pgen2.driver.load_grammar("Grammar.txt")
            g.dump("Grammar.pickle")
            g2 = Grammar()
            g2.load("Grammar.pickle")
            self.assertEqual(g.symbol2number, g2.symbol2number)
            self.assertEqual(g.number2symbol, g2.number2symbol)
            self.assertEqual(g.states, g2.states)
            self.assertEqual(g.dfas, g2.dfas)
            self.assertEqual(g.labels, g2.labels)

# Generated at 2022-06-17 16:47:22.175820
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[(1, 1), (2, 2)], [(3, 3), (4, 4)]]
            g.dfas = {1: ([(1, 1), (2, 2)], {1: 1, 2: 2}), 2: ([(3, 3), (4, 4)], {3: 3, 4: 4})}

# Generated at 2022-06-17 16:47:23.537863
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))

# Generated at 2022-06-17 16:47:28.860269
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import io

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.symbol2number = {'a': 1, 'b': 2}
            g.number2symbol = {1: 'a', 2: 'b'}
            g.states = [[(1, 2)], [(3, 4)]]
            g.dfas = {1: ([(1, 2)], {1: 1}), 2: ([(3, 4)], {3: 1})}
            g.labels = [(1, 'a'), (2, 'b'), (3, 'c'), (4, 'd')]
            g.keywords = {'a': 1, 'b': 2}
            g.tok

# Generated at 2022-06-17 16:47:35.928921
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .conv import convert
    from .pgen import driver

    g = Grammar()
    driver.parse_grammar(convert("Grammar/Grammar", "Grammar"), g)
    g.dump("Grammar/Grammar.pickle")
    g2 = Grammar()
    g2.load("Grammar/Grammar.pickle")
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label