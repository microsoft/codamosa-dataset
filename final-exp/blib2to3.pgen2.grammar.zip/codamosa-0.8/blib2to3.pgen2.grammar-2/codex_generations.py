

# Generated at 2022-06-11 19:34:43.325914
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2
    from . import tokenize
    from .pgen2 import driver
    from .pgen2 import parse
    g = Grammar()
    g.load("pgen2/Grammar.pickle")
    f1 = parse.FileInput("/home/foo")
    f2 = parse.FileInput("/home/foo")
    f3 = parse.FileInput("/home/foo")
    g.start = 256
    new_tokens = (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16)

# Generated at 2022-06-11 19:34:56.550563
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Check that the load and dump methods are inverses."""
    g = Grammar()
    g.symbol2number = {
        "a": 2,
        "c": 3,
    }
    g.number2symbol = {
        2: "a",
        3: "c",
    }

# Generated at 2022-06-11 19:35:08.821968
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import pathlib
    import tempfile
    import unittest

    class GrammarTests(unittest.TestCase):
        def setUp(self) -> None:
            self.temp_dir = tempfile.TemporaryDirectory()
            self.addCleanup(self.temp_dir.cleanup)
            self.old_cwd = os.getcwd()
            os.chdir(self.temp_dir.name)

        def tearDown(self) -> None:
            os.chdir(self.old_cwd)

        def test_Grammar_dump(self):
            g = Grammar()
            g.symbol2number = {"symbol2number": 1}
            g.number2symbol = {"number2symbol": 1}
            g.states = [[], []]
            g

# Generated at 2022-06-11 19:35:12.405325
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.symbol2number = {'foo': 1}
    assert g.symbol2number['foo'] == 1
    s = pickle.dumps(g)
    g = Grammar()
    g.loads(s)
    assert g.symbol2number['foo'] == 1

# Generated at 2022-06-11 19:35:21.131413
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    for attrs in (
        dict(a=1, b=[2, 3], c={'d': 'e'}),
        dict(b=42),
        dict(states=[1,2,3], start=4, symbols={'a': 5, 'b': 6}),
    ):
        g = Grammar()
        g._update(attrs)
        g.dump('foo.pkl')
        g2 = Grammar()
        g2.load('foo.pkl')
        assert g2.__dict__ == attrs
        os.remove('foo.pkl')

# Generated at 2022-06-11 19:35:26.881111
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    f = tempfile.NamedTemporaryFile(delete=False)
    f.close()
    g.dump(f.name)
    g.load(f.name)


if __name__ == "__main__":
    import sys

    g = Grammar()
    g.load(sys.argv[1])
    g.report()

# Generated at 2022-06-11 19:35:28.210518
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {"the_symbol": 1}
    g.dump("test.pickle")


if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-11 19:35:31.259896
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    filename = "test.pkl"
    grammar.dump(filename)
    grammar.load(filename)
    grammar.loads(open(filename, "rb").read())

# Generated at 2022-06-11 19:35:36.749014
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    with tempfile.TemporaryDirectory() as directory:
        path = os.path.join(directory, "grammar.pickle")
        g.dump(path)

        # Check that the file was created
        assert os.path.exists(path)
        with open(path, "rb") as f:
            d = pickle.load(f)
        assert d == g.__dict__



# Generated at 2022-06-11 19:35:46.061740
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2 import driver
    from . import tokenize
    from .tokenize import generate_tokens

    d = driver.Driver()
    p = d.parse_string("val = (1 + 1)", "expr_stmt")
    g: Grammar = p.grammar
    f = tempfile.NamedTemporaryFile(delete=False)

# Generated at 2022-06-11 19:35:53.179229
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import driver

    filename = driver.get_grammar()
    g = Grammar()
    g.load(filename)
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-11 19:35:57.656926
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(os.path.basename(__file__), "Grammar.pkl"))


if __name__ == "__main__":
    import sys
    import pgen2.parse

    filename = sys.argv[1]
    g = Grammar()
    g.load(filename)
    pgen2.parse.Parse(g).parse(sys.stdin)

# Generated at 2022-06-11 19:36:08.770081
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import os
    import pygram_test
    from pickle import dumps, load
    from pygram.conv import convert
    from pygram.pgen import driver

    class TestGrammarLoad(unittest.TestCase):
        def setUp(self) -> None:
            self.dir = os.path.dirname(pygram_test.__file__)
            self.file = os.path.join(self.dir, "Grammar.pickle")
            self.g = Grammar()
            self.g.copy = lambda: self.g
            self.g.load = lambda pkl: load(open(pkl, "rb"))
            self.g.loads = lambda pkl: load(dumps(pkl))
            self.g.dump = lambda pkl: None

# Generated at 2022-06-11 19:36:17.247269
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import pickle
    import sys

    s = io.StringIO()
    g = Grammar()
    g.token2symbol = {0: 'ENDMARKER'}
    g.symbol2token = {'ENDMARKER': 0}
    g.symbol2label = {'ENDMARKER': 10}
    g.labels = [(1, None), (2, None), (3, 'ident'), (4, 'def'), (5, "'+'"), (6, ':='), (7, ';'), (8, '='), (9, 'for'), (10, 'ENDMARKER')]
    g.number2symbol = {0: 'ENDMARKER'}
    g.symbol2number = {'ENDMARKER': 0}

# Generated at 2022-06-11 19:36:20.075577
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Simplest test
    grammar = Grammar()
    grammar.load(os.path.join(os.path.dirname(__file__), "Grammar.txt"))
    assert grammar.keywords == {b"False": 259, b"None": 260, b"True": 258, "return": 261}
    assert grammar.async_keywords == False

# Generated at 2022-06-11 19:36:31.883169
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    from pickle import UnpicklingError

    g = Grammar()
    g.symbol2number = {'root': 259, 'file_input': 260, 'stmt': 261, 'compound_stmt': 262}
    g.number2symbol = {259: 'root', 260: 'file_input', 261: 'stmt', 262: 'compound_stmt'}
    g.states = [[[(0, 1), (2, 2)], [(3, 2), (4, 3), (5, 4)], [(6, 1), (7, 5), (8, 6)]]]

# Generated at 2022-06-11 19:36:40.741293
# Unit test for method load of class Grammar

# Generated at 2022-06-11 19:36:51.987555
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os, pickle
    from genshi.core import Stream
    from genshi.template import Context
    from genshi.template import MarkupTemplate
    from genshi.template.eval import Expression

    mt = MarkupTemplate(Stream('<p py:for="x in expr"/>'))
    g = mt.stream(Context(expr=['a', 'b']), loader=mt.loader, auto_reload=False)
    g.template.parser.dump('test.pgen')

# Generated at 2022-06-11 19:37:04.338480
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Mypy doesn't know about the new load() method yet.
    from . import pgen2

    pgen2.driver.main(["pgen2", "--grammar", "Grammar.test.py"])
    g = pgen2.driver.load_grammar()
    s2n = g.symbol2number
    n2s = g.number2symbol
    labels = g.labels
    tokens = g.tokens
    res = open(os.path.join(os.path.dirname(__file__), "Grammar.test.res")).read()
    assert str(s2n) == res

    # Check inverses
    assert set(s2n) == set(n2s)

# Generated at 2022-06-11 19:37:11.412881
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    def get_dump_file(filename):
        with open(filename, "rb") as f:
            return f.read()
    def get_dump(grammar):
        f = tempfile.NamedTemporaryFile(delete=False)
        grammar.dump(f)
        return get_dump_file(f.name)
    def compare(g1, g2):
        return get_dump(g1) == get_dump(g2)
    g1 = Grammar()
    g1.symbol2number = {"one": 1, "two": 2}
    g1.number2symbol = {1: "one", 2: "two"}
    g1.states.append([])
    g1.states.append([(0,0)])
    g1.states.append([(1,1)])
    g

# Generated at 2022-06-11 19:37:19.653849
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pytest
    from . import pickle as pickle_mod
    from . import pgen2
    from .tokenize import tokenize

    filename = "Grammar.testdump"
    path = os.path.join(os.path.dirname(__file__), filename)

    # Load the grammar
    g = pgen2.driver.load_grammar(path)
    g.dump(filename)

    # Read it back
    g2 = Grammar()
    g2.load(filename)

    # Compare
    assert g2.symbol2number == g.symbol2number
    assert g2.number2symbol == g.number2symbol
    assert g2.keywords == g.keywords
    assert g2.tokens == g.tokens
    assert g2.states == g.states

# Generated at 2022-06-11 19:37:27.659751
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()

    from . import conv
    from . import driver

    conv.Converter(g, "Python", "3.7", "Grammar.txt", driver.Driver())
    assert len(g.states) == 108

    g2 = Grammar()
    g2.load(g.dump("Grammar.pickle"))
    assert len(g2.states) == 108

    g3 = Grammar()
    g3.loads(g.dumps())
    assert len(g3.states) == 108



# Generated at 2022-06-11 19:37:30.327711
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import driver

    driver.load_grammar()


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-11 19:37:35.730244
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2

    g = pgen2.generate_grammar()
    fn = tempfile.mktemp()
    g.dump(fn)
    g2 = Grammar()
    g2.load(fn)
    os.unlink(fn)

# Generated at 2022-06-11 19:37:42.656151
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.dict1 = {"a": 1, "b": 2}
    g.dict2 = {"a": 3, "b": 4}
    g.dump("build/pgen.pkl")
    g2 = Grammar()
    g2.load("build/pgen.pkl")
    assert g2.dict1 == {"a": 1, "b": 2}
    assert g2.dict2 == {"a": 3, "b": 4}



# Generated at 2022-06-11 19:37:53.575048
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pyparse, io

    # write grammar to temporary file
    g = pyparse.Grammar()
    g.dump("Grammar.pickle")

    # read grammar from temporary file
    f = io.open("Grammar.pickle", "rb")
    p = f.read()
    f.close()

    # load grammar from the pickle bytes object
    h = pyparse.Grammar()
    h.loads(p)
    assert g.symbol2number == h.symbol2number
    assert g.number2symbol == h.number2symbol
    assert g.states == h.states
    assert g.dfas == h.dfas
    assert g.labels == h.labels
    assert g.keywords == h.keywords
    assert g.tokens == h.tok

# Generated at 2022-06-11 19:38:01.458393
# Unit test for method load of class Grammar

# Generated at 2022-06-11 19:38:06.612021
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = ".test.pickle"
    try:
        g = Grammar()
        g.dump(filename)
        g1 = Grammar()
        g1.load(filename)
        assert g == g1
    finally:
        try:
            os.unlink(filename)
        except OSError:
            pass

# Generated at 2022-06-11 19:38:12.664248
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import tempfile, os, shutil
    orig = Grammar()
    orig.symbol2number = {"1":1}
    orig.number2symbol = {1:"1"}
    orig.dfas = {1:1}
    orig.keywords = {"2":2}
    orig.tokens = {1:1}
    orig.symbol2label = {"3":3}
    orig.labels = [(1,1),(2,2),(3,3)]
    orig.states = [1,2,3]
    orig.start = 256
    orig.async_keywords = False
    origdump = tempfile.mkdtemp()
    orig.dump(origdump)
    copy = Grammar()
    copy.load(origdump)
    copydump = tempfile.mkdtemp()
   

# Generated at 2022-06-11 19:38:16.456763
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("./Grammar.pickle")
    assert grammar.symbol2label['comprehension'] == 2475


# Generated at 2022-06-11 19:38:25.363710
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = 'lib2to3/Grammar.txt'
    fh = open(filename)
    try:
        text = fh.read()
    finally:
        fh.close()
    grammar = Grammar()
    grammar.loads(text.encode())
    grammar.report()

# Generated at 2022-06-11 19:38:27.059780
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load()

# Generated at 2022-06-11 19:38:33.955972
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import shutil
    import tempfile
    import types

    _save_stdout = sys.stdout  # type: ignore

# Generated at 2022-06-11 19:38:45.138879
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest.mock
    import importlib.util
    import pickle
    module_name = 'mypy.test_Grammar_dump'
    module_spec = importlib.util.spec_from_loader(module_name, None)
    module = importlib.util.module_from_spec(module_spec)
    exec("def test_Grammar_dump(): pass", module.__dict__)
    global_namespace = module.__dict__
    with unittest.mock.patch('builtins.open', new=unittest.mock.mock_open()):
        grammar = Grammar()
        grammar.dump('foo')
        grammar.load('foo')
        grammar.loads(pickle.dumps(grammar, pickle.HIGHEST_PROTOCOL))

# Generated at 2022-06-11 19:38:56.384079
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Test Grammar.dump()
    g = Grammar()
    g.symbol2number['spam'] = 1
    g.symbol2number['ham'] = 2
    g.number2symbol[2] = 'ham'
    g.number2symbol[1] = 'spam'
    g.states = [
        [('NOTHING',0), (1,1), (2,2)],
        [('NOTHING', 0), (1, 1), (2, 2)],
        [('NOTHING', 0), (1, 1), (2, 2)]
    ]
    g.dfas['spam'] = ('NOTHING', [1,2,3])
    g.labels = [('NOTHING', 'NOTHING')]

# Generated at 2022-06-11 19:39:06.504884
# Unit test for method load of class Grammar
def test_Grammar_load():
    import logging
    import sys
    import pytest
    import shutil, tempfile
    from mypy.parser.parser import Parser
    from mypy.parser.pgen2.pgen import generate_grammar

    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)

    try:
        logging.getLogger('pgen2.pgen').setLevel(logging.WARNING)
        logging.getLogger('mypy.parser.pgen2.pgen').setLevel(logging.WARNING)
    except KeyError:
        logger.warning('pgen logger not found')

    test_dir = tempfile.mkdtemp()

# Generated at 2022-06-11 19:39:12.925473
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import io

    class GrammarTestCase(unittest.TestCase):
        def setUp(self) -> None:
            self.grammar = Grammar()

        def test_method_dump(self) -> None:
            expected = (b"cdecimal\n"
                        b"(dp0\n"
                        b".\n")
            output = io.BytesIO()
            self.grammar.dump(output)
            assert output.getvalue().startswith(expected)

    unittest.main()

# Generated at 2022-06-11 19:39:15.307547
# Unit test for method load of class Grammar
def test_Grammar_load():
    # assume Grammar class is loaded
    g = Grammar()
    g.load(__file__)
    assert g.labels[0] == (0, 'EMPTY')

# Generated at 2022-06-11 19:39:26.987637
# Unit test for method load of class Grammar
def test_Grammar_load():
  table_file = os.path.join(os.path.dirname(__file__), 'Grammar.pickle')
  g_test = Grammar()
  g_test.load(table_file)

# Generated at 2022-06-11 19:39:30.131370
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    with tempfile.NamedTemporaryFile(delete=False) as f:
        filename = f.name
    grammar.dump(filename)
    grammar.load(filename)
    os.unlink(filename)

# Generated at 2022-06-11 19:39:43.361826
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    f = tempfile.NamedTemporaryFile(delete=False)
    try:
        o = Grammar()
        pickle.dump(o.__dict__, f, pickle.HIGHEST_PROTOCOL)
        f.close()
        s = Grammar()
        s.load(f.name)
    finally:
        os.unlink(f.name)

# Generated at 2022-06-11 19:39:45.704053
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    assert hasattr(g, 'async_keywords')
    g.dump('foo.pkl')



# Generated at 2022-06-11 19:39:50.013578
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    f = tempfile.NamedTemporaryFile()
    g.dump(f.name)
    g.load(f.name)

# Generated at 2022-06-11 19:39:53.406314
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import parser

    grammar = parser.Grammar()
    grammar.dump(os.path.join(os.path.dirname(__file__), 'Grammar.txt'))



# Generated at 2022-06-11 19:39:59.293731
# Unit test for method load of class Grammar
def test_Grammar_load():
    # test if dump(...) and load(...) works
    grammar = Grammar()
    try:
        grammar.dump('/dev/null')
        grammar.load('/dev/null')
    except:
        raise AssertionError
    # test if loads(...) works
    try:
        grammar.loads(pickle.dumps({}))
    except:
        raise AssertionError

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-11 19:40:10.709008
# Unit test for method load of class Grammar

# Generated at 2022-06-11 19:40:17.268248
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import conv, data, pgen2

    grammar = Grammar()  # Load grammar from .../lib/lib2to3/Grammar.txt
    grammar.load(data.find("Grammar.txt"))
    tables = conv.parse(data.find("Grammar.txt"), data.find("PatternGrammar.txt"))
    grammar.load(pgen2.make_pgen(tables, pickle=False))

# Generated at 2022-06-11 19:40:19.216233
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_filename = 'Grammar_dump.dump'
    g = Grammar()
    g.dump(grammar_filename)

# Generated at 2022-06-11 19:40:21.732461
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    # Test load by loading string
    g.loads(b'\x80\x03}q\x00.')
    assert g.__getstate__() == {}
    # Test load by loading file
    g.load(__file__)

# Generated at 2022-06-11 19:40:27.814146
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.pkl")
    g.report()
    print(g.symbol2number["atom"])
    print(g.number2symbol[258])
    print(g.start)
    print(g.tokens[token.NAME])
    print(g.keywords["def"])


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-11 19:40:47.715538
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.labels = [(1, "test"),
                (5, None),
                (6, "test"),
                (7, "test")]
    g.keywords = {"test": 1, "test2": 2}
    g.tokens = {token.COMMA: 2, token.EQUAL: 3}
    g.start = 6
    g.symbol2number = {"test": 6, "test2": 7}
    g.number2symbol = {6: "test", 7: "test2"}
    g.symbol2label = {"test": 1, "test2": 2}
    g.states = [[(1, 2), (3, 3)], [(3, 3), (2, 1)]]

# Generated at 2022-06-11 19:40:58.861139
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import sys

    from . import pgen
    from . import PythonGrammar
    from . import driver

    parser = pgen.PgenParser()

    # Print the grammar rules
    with open(os.path.dirname(sys.executable) + "/Grammar.txt", "r") as f:
        gstr = f.read()
    gram = PythonGrammar.PythonGrammar(gstr, "3.6")
    gram.parser = parser
    gram.symbol2label = pgen.make_grammar_labels(gram.symbol2number)
    gram.make_dfas()
    gram.add_filters()
    parser.grammar = gram
    driver.hook_grammar_driver(parser)
    driver.initialize_grammar_tables(parser)
   

# Generated at 2022-06-11 19:41:08.348219
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = "Grammarpickle"
    g = Grammar()
    g.dump(filename)
    g2 = Grammar()
    g2.load(filename)
    assert g2.symbol2number == g.symbol2number
    assert g2.number2symbol == g.number2symbol
    assert g2.states == g.states
    assert g2.dfas == g.dfas
    assert g2.labels == g.labels
    assert g2.keywords == g.keywords
    assert g2.tokens == g.tokens
    assert g2.symbol2label == g.symbol2label
    assert g2.start == g.start


# Generated at 2022-06-11 19:41:17.826970
# Unit test for method load of class Grammar
def test_Grammar_load():
    gram = Grammar()

# Generated at 2022-06-11 19:41:26.162057
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle

    class MyGrammar(Grammar):
        def __init__(self) -> None:
            super().__init__()
            self.spam = "eggs"

    g = MyGrammar()  # type: ignore
    dump_filename = tempfile.mktemp()
    try:
        g.dump(dump_filename)
        h = MyGrammar()  # type: ignore
        h.load(dump_filename)
        assert h.spam == "eggs"
    finally:
        os.remove(dump_filename)



# Generated at 2022-06-11 19:41:29.565018
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pygram

    filename = tempfile.mktemp(prefix="pgen_", suffix=".pkl")
    pygram._main(filename)
    if os.path.isfile(filename):
        os.remove(filename)
    else:
        raise AssertionError("%r wasn't created" % (filename,))


# Generated at 2022-06-11 19:41:39.458223
# Unit test for method load of class Grammar
def test_Grammar_load():
    # common part of testing for load of class Grammar
    class SubGrammar(Grammar):
        def __init__(self):
            Grammar.__init__(self)

            self.symbol2number = {"_dummy1": 1}
            self.number2symbol = {1: "_dummy1"}
            self.states = [1]
            self.keywords = {"_dummy3": 3}
            self.tokens = {"_dummy4": 4}
            self.symbol2label = {"_dummy5": 5}

            self.labels = [
                (0, "EMPTY"),
            ]

            self.start = 256
            self.async_keywords = False

    # testing of method load of class Grammar
    # when pkl is a bytes object

# Generated at 2022-06-11 19:41:49.510930
# Unit test for method load of class Grammar
def test_Grammar_load():
    def test(module):
        import sys
        import tokenize
        import pytest

        if module != "__main__":
            return
        sys.path.append("test")
        g = Grammar()
        g.load(tokenize.__file__.rstrip("co"))
        pytest.main(["test_Grammar"])

    test(__name__)


if __name__ == "__main__":
    import unittest

    from . import parse

    class GrammarTest(unittest.TestCase):

        def test_async_keywords(self) -> None:
            async_kw = "async"
            async_for_kw = "async for"
            async_with_kw = "async with"
            # Python 3.6 does not have async as a keyword

# Generated at 2022-06-11 19:41:57.597847
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("Grammar.pkl")

    assert grammar.number2symbol[256] == "root"
    assert grammar.symbol2number["root"] == 256

    assert grammar.labels[1] == (1, None)
    assert grammar.labels[20] == (20, None)
    assert grammar.labels[21] == (20, "and")

    assert grammar.tokens[3] == 3
    assert grammar.tokens[18] == 18
    assert grammar.tokens[opmap["**="]] == 89

    assert grammar.keywords["not"] == 25
    assert grammar.keywords["print"] == 37

    assert grammar.states[0] == [(4, 1), (0, 0)]

# Generated at 2022-06-11 19:42:04.890255
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .conv import PyTreeGrammar
    from .pgen import Driver

    g = PyTreeGrammar()
    d = Driver(g, optimize=0, lextab="lextab", yacctab="yacctab")
    d.dump()

    g2 = Grammar()
    g2.load("grammar.pickle")

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-11 19:42:27.340231
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = os.path.join(os.path.dirname(__file__), "Grammar.test.pkl")
    g = Grammar()
    g.dump(filename)
    g.dump(filename)
    g.dump(filename)
    g.dump(filename)
    g.dump(filename)
    g.dump(filename)


if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-11 19:42:39.033381
# Unit test for method load of class Grammar
def test_Grammar_load():
    def create_grammar():
        grammar = Grammar()
        grammar.symbol2number = {'symbol1': 1, 'symbol2': 2, 'symbol3': 3}
        grammar.number2symbol = {1: 'symbol1', 2: 'symbol2', 3: 'symbol3'}
        grammar.states = [[(1, 2), (3, 4), (5, 6)], [(1, 2), (3, 4)]]
        grammar.dfas = {1: (0, {2: 1}), 2: (1, {3: 1}), 3: (1, {1: 1}), 4: (0, {5: 1})}

# Generated at 2022-06-11 19:42:46.836711
# Unit test for method load of class Grammar
def test_Grammar_load():
    """
    This test ensures that load() properly restores the state of Grammar objects.
    """
    test_grammar = Grammar()
    test_grammar.start = 256
    pkl = pickle.dumps(test_grammar.__getstate__(), pickle.HIGHEST_PROTOCOL)
    assert len(pkl) > 10
    new_grammar = Grammar()
    assert new_grammar.start != test_grammar.start
    new_grammar.loads(pkl)
    assert new_grammar.start == test_grammar.start

# Generated at 2022-06-11 19:42:56.287415
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import marshal
    from .pgen2 import driver

    filename = "/tmp/pgen_grammar.py"
    with open(filename, "wb") as f:
        f.write(marshal.dumps(driver.grammar))
    with open(filename, "rb") as f:
        g = Grammar()
        g.loads(f.read())
        assert g.labels == driver.grammar.labels
        assert g.start == driver.grammar.start
        assert g.keywords == driver.grammar.keywords
        assert g.tokens == driver.grammar.tokens

# Generated at 2022-06-11 19:43:04.074188
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import conv
    from . import pgen

    g1 = Grammar()
    assert g1.start == 256

    g2 = Grammar()
    conv.grammar(g1, "Grammar", "grammar.txt")
    g2.load("Grammar.pickle")

    assert g1.start == g2.start
    assert g1.symbol2number == g2.symbol2number
    assert g1.number2symbol == g2.number2symbol
    assert len(g1.states) == len(g2.states)
    assert g1.dfas == g2.dfas
    assert g1.labels == g2.labels
    assert g1.keywords == g2.keywords
    assert g1.tokens == g2.tokens

# Generated at 2022-06-11 19:43:14.340183
# Unit test for method load of class Grammar
def test_Grammar_load():
    def _test(grammar: Grammar) -> None:
        assert grammar.symbol2number["file_input"] == 257
        assert grammar.symbol2number["atom"] == 311
        assert grammar.symbol2number["testlist_comp"] == 319

        assert grammar.number2symbol[257] == "file_input"
        assert grammar.number2symbol[311] == "atom"
        assert grammar.number2symbol[319] == "testlist_comp"

        assert grammar.labels[0] == (0, "EMPTY")

        assert grammar.keywords[":"] == 1
        assert grammar.keywords["class"] == 8

        assert grammar.tokens[257] == 0
        assert grammar.tokens[token.NAME] == 258  # start=256

        assert grammar.async_keywords

# Generated at 2022-06-11 19:43:22.806349
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import pickle
    filename = sys.modules[__name__].__file__
    filename = os.path.splitext(filename)[0] + "_dump.pkl"
    a = Grammar()
    a.dump(filename)
    b = Grammar()
    b.load(filename)
    os.unlink(filename)
    assert a.__dict__ == b.__dict__
    # verify that Grammar can be pickled even if it doesn't have a __dict__
    pickle.dumps(a)


# Generated at 2022-06-11 19:43:30.687464
# Unit test for method load of class Grammar
def test_Grammar_load():
    import re
    import tempfile
    import unittest

    class TestGrammarLoad(unittest.TestCase):
        def setUp(self) -> None:
            self.grammar = Grammar()
            self.gfile = tempfile.NamedTemporaryFile()

            # Create a grammar file for testing
            self.gfile.write(b"Grammar\n")
            self.gfile.write(b"symbol2number\n")
            self.gfile.write(b'{\'a\': 1}\n')
            self.gfile.write(b"number2symbol\n")
            self.gfile.write(b'{1: \'a\'}\n')
            self.gfile.write(b"states\n")

# Generated at 2022-06-11 19:43:39.474812
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    # test some attributes before load:
    assert not hasattr(grammar, 'symbol2number')
    # the following test should pass (see issue #26865):
    assert grammar.start == 256
    grammar.start = 257
    assert grammar.start == 257
    grammar.load('Grammar/Grammar')
    # test some attributes after load:

# Generated at 2022-06-11 19:43:41.747126
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("xxx.pickle")

_P = TypeVar("_P", bound="Grammar")

# Generated at 2022-06-11 19:44:08.511805
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """
    Unit test for method dump of class Grammar.
    """
    gram = Grammar()

    gram.symbol2number = {"A": 1, "B": 2}
    gram.number2symbol = {1: "A", 2: "B"}
    gram.states = [[]]
    gram.dfas = {}
    gram.labels = [(0, "EMPTY"), (1, None)]
    gram.keywords = {"A": 0}
    gram.tokens = {"B": 0}
    gram.symbol2label = {"A": 1, "B": 2}
    gram.start = 256
    gram.async_keywords = False

    gram.dump("gramdump.pkl")

    newgram = Grammar()
    newgram.load("gramdump.pkl")

    assert gram.sy

# Generated at 2022-06-11 19:44:15.886676
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """Generate a grammar pickle, and run smoke tests.

    After running this function, the resulting pickle file can be
    unpickled and tested with this command:

        python -m pickletools -v < pickle
    """
    # pylint: disable=unused-variable,unused-argument
    def _conv(filename, start, dfas):
        def show(x):
            return x

        class Conv(object):
            def __init__(self, start, dfas, labels):
                self.start = start
                self.dfas = dfas
                self.labels = labels
                self.symbol2label = {}

            def fixlabels(self, labels, symbol2label):
                del labels[:]
                new_labels = []
                labels_append = labels.append
                self.symbol2

# Generated at 2022-06-11 19:44:24.009676
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Test the grammar dump / load methods."""
    filename = "tmp"

    g = Grammar()
    g.symbol2number["foo"] = 1
    g.number2symbol[2] = "bar"
    g.states = [[(1, 2)], [(3, 4), (5, 6)]]
    g.dfas = {1: (g.states[0], {"some": 1}), 2: (g.states[1], {"tokens": 1})}
    g.labels = [(0, "EMPTY"), (1, None), (2, "bar"), (3, "baz")]
    g.keywords = {"abc": 2, "def": 3}
    g.tokens = {4: 2, 5: 3}

# Generated at 2022-06-11 19:44:28.903247
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from parsing.parse import Parser
    p = Parser(file_input=False)
    g = p.grammar
    g.dump('/tmp/grammar1.pkl') # Does not raise exception



# Generated at 2022-06-11 19:44:38.136768
# Unit test for method dump of class Grammar