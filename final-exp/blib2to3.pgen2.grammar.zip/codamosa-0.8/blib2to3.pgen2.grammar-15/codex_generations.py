

# Generated at 2022-06-11 19:34:47.540629
# Unit test for method load of class Grammar
def test_Grammar_load():
    from io import BytesIO
    from _ast import arguments
    byte_object = BytesIO()
    gram = Grammar()
    gram.loads(byte_object.getvalue())



# Generated at 2022-06-11 19:34:58.646505
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import driver
    from .pgen2.parse import ParseError
    import io

    # Test for a non-existing file
    grammar = Grammar()
    try:
        grammar.load("non-existing")
    except ParseError:
        pass             # OK
    else:
        assert False, "Test 1 failed"

    # Test for a pickled grammar file created from Python's grammar
    pickleFile = io.BytesIO()
    pickle.dump("Hello World!", pickleFile)
    try:
        grammar.load(pickleFile)
    except ParseError:
        pass             # OK
    else:
        assert False, "Test 2 failed"

    # Test for a grammar file created from Python's grammar
    grammar = Grammar()
    grammar.start = 256

# Generated at 2022-06-11 19:35:01.971530
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    p = Grammar()
    p.dump(tempfile.mktemp())
    p.loads(b'')
    p.load(tempfile.mktemp())

# Generated at 2022-06-11 19:35:04.091923
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("Grammar.txt")

# Generated at 2022-06-11 19:35:13.994190
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Trivial test, just to make sure dump() doesn't blow up
    s2n = {'a': 3}
    n2s = {3: 'a'}
    states = [[(1, 2)], [(3, 4)]]
    dfas = {3: (states[0], {1: 1})}
    labels = [(1, 'EMPTY'), (2, 'A'), (3, 'B'), (4, 'C')]
    keywords = {'EMPTY': 1, 'A': 2, 'B': 3, 'C': 4}
    tokens = {1: 1, 2: 2, 3: 3, 4: 4}
    symbol2label = {'a': 3}
    g = Grammar()
    g.symbol2number = s2n
    g.number2symbol = n2s


# Generated at 2022-06-11 19:35:18.551110
# Unit test for method load of class Grammar
def test_Grammar_load():
    def test_method(self):
        from .pgen2.grammar import Grammar

        grammar = Grammar()

        # XXX: Don't try to load this file, it doesn't exist
        grammar.load("UNKNOWN_FILE_NAME")

# Generated at 2022-06-11 19:35:30.261587
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import unittest
    import unittest.mock
    import six

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            grammar = Grammar()
            grammar.symbol2number = {'a': 1, 'b': 2}
            with unittest.mock.patch('pyflakes.grammar.Grammar.dump') as mock_dump:
                grammar.dump('test.pkl')
                mock_dump.assert_called_once_with('test.pkl')

    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(TestGrammar))

    result = unittest.TextTestRunner(stream=sys.stdout, verbosity=2).run(suite)

# Generated at 2022-06-11 19:35:35.740067
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    # dirty hack: add a class attribute to Grammar so we can test that it doesn't
    # get blown away by Grammar.load
    g.X = 1
    g.load("Tests/GrammarTables.pickle")
    assert g.X == 1, "class attribute lost by load"
    assert g.__class__ is Grammar, "load produced an instance of wrong class"

# Generated at 2022-06-11 19:35:40.786908
# Unit test for method load of class Grammar
def test_Grammar_load():
    # XXX: This test can't be run without loading the grammar
    # tables, which are usually done by the caller.  Doesn't
    # try very hard to test the method anyway.
    #import sys
    #g = Grammar()
    #g.load(sys.executable)
    pass


# Generated at 2022-06-11 19:35:46.708934
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    class SubGrammar(Grammar):
        def __init__(self) -> None:
            super().__init__()
        def load(self, filename: Path) -> None:
            pass

    g = SubGrammar()
    g.dump('xxx')

if __name__ == "__main__":
    import sys

    g = Grammar()
    g.load(sys.argv[1])
    g.report()

# Generated at 2022-06-11 19:35:56.603677
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Make a temporary file. This could cause errors if the user
    # doesn't have access to the current directory.
    from tempfile import NamedTemporaryFile
    with NamedTemporaryFile() as tmp:
        g = tmp.name

    # First, check that the file doesn't exist
    assert not os.path.exists(g)

    g = Grammar()
    # This should raise an error. If the file exists, it fails on Windows.
    try:
        g.load(g)
    except IOError:
        pass
    else:
        raise AssertionError

# Generated at 2022-06-11 19:36:07.565625
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {"foo":1}
    g.number2symbol = {1:"foo"}
    g.states = [[[(0, 0)]]]
    g.dfas = {1:([[(0, 0)]], {0: 1}), 2:([[(0, 0)]], {0: 1})}
    g.labels = [(0, "EMPTY")]
    g.keywords = {"foo":1}
    g.tokens = {1:1}
    g.symbol2label = {"foo":1}
    g.start = 256
    try:
        os.unlink("Grammar_dump.pickle")
    except OSError:
        pass
    g.dump("Grammar_dump.pickle")
    g

# Generated at 2022-06-11 19:36:16.608873
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import tokenize

    grammar = Grammar()
    grammar.load("Grammar.txt")
    grammar.start = grammar.symbol2number["file_input"]
    assert grammar.start == 256

    try:
        grammar.load("ast.py")
        assert False, "Should have raised IOError"
    except IOError:
        pass

    # Test that the pickle file is still readable by Python 3.0
    f = open("Grammar.txt", "rb")
    try:
        grammar = pickle.load(f)
        assert grammar is not None
    finally:
        f.close()

    # Test that serialized grammar is still readable by Python 3.0
    f = open("Grammar.txt", "rb")

# Generated at 2022-06-11 19:36:27.880769
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from tokenize import generate_tokens
    from .parse import Parser, ParseError, DEFAULT_BLANKS
    import io

    def parse(src: str) -> Parser:
        return Parser(*DEFAULT_BLANKS).parse(src)

    def parse_string(src: str, s: str) -> None:
        assert tokenize_string(s) == parse(src).totuple()

    def tokenize_string(s: str) -> str:
        if s == "":
            return "STRING", "''"
        if s[0] in "'\"":
            return "STRING", s
        return "STRING", repr(s)

    grammar = Grammar()
    grammar.symbol2number["a"] = 256
    grammar.symbol2number["a1"] = 257
    grammar

# Generated at 2022-06-11 19:36:35.748518
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar/Grammar.pkl")
    assert g.tokens[token.INDENT] == 1
    assert g.tokens[token.DEDENT] == 2
    assert g.tokens[token.NEWLINE] == 3
    assert g.tokens[token.NUMBER] == 4
    assert g.tokens[token.STRING] == 5
    assert g.tokens[token.NAME] == 6
    assert g.tokens[token.ASYNC] == 7
    assert g.tokens[token.AWAIT] == 8


# Generated at 2022-06-11 19:36:36.948532
# Unit test for method load of class Grammar
def test_Grammar_load():
    assert Grammar.load is Grammar.loads


# Generated at 2022-06-11 19:36:44.094668
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()

# Generated at 2022-06-11 19:36:54.781493
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.symbol2number = {1: 2, 3: 4}
    grammar.number2symbol = {5: 6, 7: 8}
    grammar.states = [[(9, 10)], [(11, 12)]]
    grammar.dfas = {13: [(14, 15), (16, 17)], 18: [(19, 20), (21, 22)]}
    grammar.labels = [(23, "24"), (25, "26")]
    grammar.keywords = {27: 28, 29: 30}
    grammar.tokens = {31: 32, 33: 34}
    grammar.symbol2label = {35: 36, 37: 38}
    grammar.start = 39
    grammar.async_keywords = True
    grammar.dump('tmp')

# Generated at 2022-06-11 19:37:06.195148
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest


# Generated at 2022-06-11 19:37:15.434297
# Unit test for method load of class Grammar
def test_Grammar_load():
    # This is a smoke test for the load() method.
    g = Grammar()
    assert len(g.symbol2number) == 0
    assert g.start == 256
    g.load(__file__.replace(".py", ".pkl"))
    assert g.start == 256
    assert (
        g.labels[g.symbol2label["old_print_function"]] == (1, "old_print_function")
    )


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-11 19:37:26.866765
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    f = tempfile.NamedTemporaryFile()
    g.dump(f.name)
    f.seek(0)
    g2 = Grammar()
    g2.loads(f.read())
    assert g == g2
    # Run again to ensure that pickle file is not corrupted when loaded twice
    g2 = Grammar()
    g2.loads(f.read())
    assert g == g2

# Generated at 2022-06-11 19:37:38.863508
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.symbol2number = {"symbol2number": "symbol2number"}
    grammar.number2symbol = {"number2symbol": "number2symbol"}
    grammar.states = [[[(1, 2), (3, 4)]]]
    grammar.dfas = {1: [[[(1, 2), (3, 4)], {1: 1}]]}
    grammar.labels = [(1, "test"), (2, "test2")]
    grammar.keywords = {"test": 1}
    grammar.tokens = {1: 2}
    grammar.symbol2label = {"symbol": 1}
    grammar.start = 256

    grammar.dump("example.pkl")

    newgrammar = Grammar()
    newgrammar.load("example.pkl")

# Generated at 2022-06-11 19:37:46.252383
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("./Lib/pytree/Grammar.pkl")

# Generated at 2022-06-11 19:37:48.017175
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = tempfile.mktemp()
    g = Grammar()
    # test that dump does not raise exception
    g.dump(filename)

# Generated at 2022-06-11 19:37:58.088113
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [1, 2]
    g.dfas = {1: 2}
    g.labels = [1, 2]
    g.keywords = {'foo': 1}
    g.tokens = {1: 2}
    g.symbol2label = {'bar': 1}
    g.start = 1
    assert Grammar().dump("test_dump") == None
    g2 = Grammar()
    g2.load("test_dump")
    for i in g.__dict__:
        assert g.__dict__[i] == g2.__dict__[i]
    # g

# Generated at 2022-06-11 19:38:00.324445
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.copy
    g.loads
    g.load("/dev/null")
    g.loads(b"abc")

# Generated at 2022-06-11 19:38:11.602799
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()

# Generated at 2022-06-11 19:38:18.102773
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from pytype import load_pytd

    filename = "grammar_dump_test.py"
    with open(filename, "wb") as f:
        pickle.dump(load_pytd.load_pytd_from_string(""), f, pickle.HIGHEST_PROTOCOL)
    os.unlink(filename)

test_Grammar_dump()

# Generated at 2022-06-11 19:38:21.596947
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle

    g = Grammar()
    d = pickle.dumps(g, pickle.HIGHEST_PROTOCOL)
    gg = Grammar()
    gg.loads(d)

# Generated at 2022-06-11 19:38:25.461572
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = "test_Grammar_dump.txt"
    grammar = Grammar()
    grammar.dump(filename=filename)
    with open(filename, "rb") as f:
        assert f.read()

# Generated at 2022-06-11 19:38:30.167755
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(os.path.join(os.path.dirname(__file__), 'Grammar.pickle'))

# Generated at 2022-06-11 19:38:41.008757
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    # Pickle was created with python 2.7
    # SyntaxError: Non-ASCII character '\xe0' in file /home/david/code/cpython/Lib/test/data/badsyntax_3103.py on line 7, but no encoding declared; see http://python.org/dev/peps/pep-0263/ for details
    with open(os.path.join(os.path.dirname(__file__), "badsyntax_3103.pkl"), "rb") as f:
        g.loads(f.read())

    # pylint: enable=bad-continuation

# Generated at 2022-06-11 19:38:46.951013
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Create a dummy Grammar object
    g = Grammar()
    g.symbol2number = {"foo": 1}  # type: ignore
    # Write out the pickle file
    g.dump("Grammar.dat")
    # Reload the object
    g2 = Grammar()
    g2.load("Grammar.dat")
    os.remove("Grammar.dat")
    # Check the loaded object
    assert g2.symbol2number == g.symbol2number

# Generated at 2022-06-11 19:38:52.348905
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import conv
    from . import token

    token.LPAR, token.RPAR = 1, 2
    g = conv.Grammar()
    g.start = 257
    d = {'dfas': {257: ([[(1, 0), (0, 2)], [(0, 1)]], {0: 0, 1: 1})},
         'labels': [(0, 'EMPTY'), (1, None), (2, None)],
         'number2symbol': {257: 'file_input'},
         'states': [[[(1, 0), (0, 2)], [(0, 1)]]],
         'symbol2number': {'file_input': 257},
         'tokens': {1: 0, 2: 1}}
    g.load(d)

# Generated at 2022-06-11 19:38:54.219126
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump(os.devnull)

# Generated at 2022-06-11 19:38:55.835968
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-11 19:39:06.209078
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import itertools
    import sys

    def compareClassData(self,file1,file2):
        with open(file1, mode='rb') as f:
            d1 = pickle.load(f)

        with open(file2, mode='rb') as f:
            d2 = pickle.load(f)

        assert d1==d2

    gr1 = Grammar()
    gr1.symbol2number = {"a": 10, "b": 100, "c": 5}
    gr1.number2symbol = {10: "a", 100: "b", 5: "c"}

# Generated at 2022-06-11 19:39:14.891478
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Lists the instance variables of the grammar class.
    # These should be the only instance variables in the class.
    attribute_list = [
        'symbol2number',
        'number2symbol',
        'states',
        'dfas',
        'labels',
        'keywords',
        'tokens',
        'symbol2label',
        'start'
    ]
    grammar = Grammar()
    # Test that the pickle written out is the same as the instance
    # variables of the Grammar class.
    for attribute in attribute_list:
        assert(hasattr(grammar, attribute))
    # Test the Grammar.loads class method.
    grammar = Grammar()
    pickle = grammar.dump('grammar.pkl')
    grammar.loads(pickle)

# Generated at 2022-06-11 19:39:26.692499
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2.parse import ParseError
    from .pgen2.driver import pgen

    def do_test(python_version: int) -> None:
        # Test loading a pickle file
        filename = os.path.join(os.path.dirname(__file__), "Grammar.pkl")
        g = pgen(python_version, False)
        g.dump(filename)
        g2 = pgen(python_version, False)
        g2.load(filename)
        os.remove(filename)

        # Test loading a pickle string
        with open(filename, "rb") as f:
            pkl = f.read()
        g3 = pgen(python_version, False)
        g3.loads(pkl)

    # Successes

# Generated at 2022-06-11 19:39:30.841457
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pgen2.pgen # type: ignore
    gram = pgen2.pgen.Grammar("./Grammar.txt") # type: ignore
    gram.dump("./Grammar_dump.pkl")
    gram_test = pgen2.pgen.Grammar("./Grammar.txt") # type: ignore
    gram_test.load("./Grammar_dump.pkl")

# Generated at 2022-06-11 19:39:44.568700
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import tempfile
    import unittest

    from . import tokenize

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.grammar = Grammar()
            self.tmpdir = tempfile.TemporaryDirectory()

        def tearDown(self):
            del self.grammar
            self.tmpdir.cleanup()
            del self.tmpdir

        def _test_dump(self, grammar):
            path = os.path.join(self.tmpdir.name, "test.pickle")
            grammar.dump(path)
            grammar2 = Grammar()
            grammar2.load(path)
            self.assertEqual(grammar.number2symbol, grammar2.number2symbol)

# Generated at 2022-06-11 19:39:56.578301
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Pickle a few small instances of class Grammar
    def test_pickle(g: Grammar) -> None:
        with tempfile.NamedTemporaryFile(delete=False) as f:
            g.dump(f.name)
        g2 = g.copy()
        g2.load(f.name)
        assert g2.number2symbol == g.number2symbol
        assert g2.symbol2number == g.symbol2number
        assert g2.dfas == g.dfas
        assert g2.labels == g.labels
        assert g2.states == g.states
        assert g2.start == g.start
        assert g2.keywords == g.keywords
        assert g2.tokens == g.tokens
        assert g2.symbol2label == g

# Generated at 2022-06-11 19:40:00.874791
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Unit test for method load of class Grammar"""
    g = Grammar()
    g.start = 17
    g.dump("test_ast_dump.pickle")
    g2 = Grammar()
    g2.load("test_ast_dump.pickle")
    assert g.start == g2.start

# Generated at 2022-06-11 19:40:10.743609
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    f = Grammar()
    f.start = 256
    f.symbol2number = {'NAME': 256}
    f.number2symbol = {256: 'NAME'}
    f.keywords = {'name': 256}
    f.tokens = {1: 0}
    f.labels = [(0, 'EMPTY'), (256, None)]
    f.dfas = {256: ([[(256, 0)]], {0: 1}), 2: ([[(2, 0)]], {0: 1})}
    f.symbol2label = {'NAME': 256}
    f.states = [[[(256, 0)]]]
    return f


# Generated at 2022-06-11 19:40:16.949410
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .conv import parse_grammar_file, convert_grammar

    pgen = os.environ["PYTHON_PARSER_PGEN"]
    filename = parse_grammar_file(pgen)
    Grammar.dump(convert_grammar(filename), filename + ".pickle")

    g = Grammar()
    g.load(filename + ".pickle")
    g.report()

# Generated at 2022-06-11 19:40:25.495707
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .conv import make_grammar
    from .stk import stack

    g = make_grammar(open(os.path.join(os.path.dirname(__file__), "Grammar.txt")), "Grammar")
    for closure in g.dfas[g.symbol2number["file_input"]][0]:
        print(stack(closure))
    print(g.labels)
    f = tempfile.NamedTemporaryFile(delete=False)
    f.close()
    print(f.name)
    g.dump(f.name)
    h = Grammar()
    h.load(f.name)
    for closure in h.dfas[h.symbol2number["file_input"]][0]:
        print(stack(closure))

# Generated at 2022-06-11 19:40:34.018585
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import os
    import tempfile
    # This is a loop to create a temporary file name
    file_name = None
    for i in range(1000):
        try:
            file_name = tempfile.mkstemp()[1]
            break
        except FileExistsError:
            pass
    G = Grammar()
    G.symbol2number = {'and_expr': 256, 'expr': 258, 'exprlist': 259, 'testlist': 260}
    G.number2symbol = {256: 'and_expr', 258: 'expr', 259: 'exprlist', 260: 'testlist'}

# Generated at 2022-06-11 19:40:42.252584
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from io import BytesIO

    filename = os.path.join(os.path.dirname(__file__), "Grammar.dump")
    g = Grammar()
    g.dump(filename)
    g2 = Grammar()
    g2.load(filename)

    s = BytesIO()
    g2.dump(s)
    s.seek(0)
    g3 = Grammar()
    g3.loads(s.read())
    assert g == g3, "Grammar.dump() and Grammar.load() failed"

# Generated at 2022-06-11 19:40:48.971258
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import six
    import unittest
    class Grammar_Dump_Test(unittest.TestCase):
        def test_Grammar_dump(self):
            g = Grammar()
            if six.PY2:
                f = sys.stdout
            else:
                f = sys.stdout.buffer
            g.dump(f)
    unittest.main()

if __name__ == '__main__':
    test_Grammar_dump()

# Generated at 2022-06-11 19:40:59.332227
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import tempfile
    import os
    import io

    g = Grammar()
    g.symbol2number = {'symbol': 42}
    g.number2symbol = {42: 'number'}
    g.states = [[]]
    g.dfas = {1: ([[(42, 0)]], {0: 42})}
    g.labels = [(1, 'label')]
    g.keywords = {'keyword': 1}
    g.tokens = {1: 2}
    g.symbol2label = {'symbol': 1}
    g.start = 256
    with tempfile.TemporaryDirectory() as temporary_directory:
        g.dump(os.path.join(temporary_directory, 'pickle'))

# Generated at 2022-06-11 19:41:14.462169
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    name = "test.pkl"
    g.dump(name)
    gg = Grammar()
    gg.load(name)
    os.remove(name)
    assert gg.symbol2number == {}
    assert gg.number2symbol == {}
    assert gg.states == []
    assert gg.dfas == {}
    assert gg.labels == [(0, "EMPTY")]
    assert gg.keywords == {}
    assert gg.tokens == {}
    assert gg.symbol2label == {}
    assert gg.start == 256
    assert gg.async_keywords == False

# Generated at 2022-06-11 19:41:27.036095
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest

    class TestGrammarLoad(unittest.TestCase):
        def test_load_success(self):
            gram = Grammar()
            with open("grammar.pickle", "rb") as f:
                gram.loads(f.read())


# Generated at 2022-06-11 19:41:33.505578
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys, os
    path = os.path.join(os.path.dirname(__file__), "Python.asdl")
    pgen = os.path.join(os.path.dirname(__file__), "pgen")
    try:
        os.remove(pgen)
    except FileNotFoundError:
        pass
    g = Grammar()
    g.start = "file_input"
    g.symbol2number = {"file_input": 256,
                       "error_stmt": 257}
    g.number2symbol = {256: "file_input",
                       257: "error_stmt"}
    g.states = [[[(257, 256)], [(0, 1)]],
                [[(257, 1)], [(257, 1)]]]

# Generated at 2022-06-11 19:41:38.351155
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    class GrammarTestCase(unittest.TestCase):
        def runTest(self):
            pass
    def test_suite():
        return unittest.makeSuite(GrammarTestCase)
    g = Grammar()
    g.dump('/tmp/foo.pkl')


if __name__ == "__main__":
    unittest.main(defaultTest="test_suite")

# Generated at 2022-06-11 19:41:48.667309
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Dummy init
    g = Grammar()
    g.symbol2number = {'example': 256}
    g.number2symbol = {256: 'example'}
    g.states = [0]
    g.dfas = {256: (1, 2)}
    g.labels = [(0, None), (1, None), (2, 'example')]
    g.keywords = {'example': 0}
    g.tokens = {0: 1}
    g.symbol2label = {'example': 2}
    g.start = 256
    g.async_keywords = False

    # Test dump
    f = tempfile.NamedTemporaryFile(delete=False)
    g.dump(f.name)
    f.close()
    os.remove(f.name)

# Generated at 2022-06-11 19:41:54.743832
# Unit test for method load of class Grammar
def test_Grammar_load():
    import py
    import sys
    prog = py.path.local(sys.executable)
    grammar_path = prog.dirpath() / "Lib" / "pygraminit._pgen_local"
    if not grammar_path.check():
        grammar_path = prog.dirpath() / "lib" / "pygraminit._pgen_local"
    assert grammar_path.check()
    gr = Grammar()
    gr.load(grammar_path)

# Generated at 2022-06-11 19:42:03.751804
# Unit test for method load of class Grammar
def test_Grammar_load():
    import io
    import sys
    import unittest

    class GrammarLoadTestCase(unittest.TestCase):

        def setUp(self) -> None:
            self.test_string = io.BytesIO()
            self.grammar = Grammar()

        def test_Grammar_load(self) -> None:
            pickle.dump(self.grammar, self.test_string, pickle.HIGHEST_PROTOCOL)
            self.test_string.seek(0)
            self.grammar.loads(self.test_string.read())

    test_support.run_unittest(GrammarLoadTestCase)
    if hasattr(sys, "last_value") and isinstance(sys.last_value, KeyboardInterrupt):
        raise sys.last_value



# Generated at 2022-06-11 19:42:13.269199
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import warnings
    import os
    import sys

    old_flags = sys.flags
    old_warnoptions = list(warnings.filters)

    # On Python 2, we get a ResourceWarning from close();
    # suppress it, since we don't actually want to close the file.
    # On Windows, we get a FileNotFoundError; suppress that as well.
    warnings.simplefilter("ignore", ResourceWarning)
    warnings.simplefilter("ignore", FileNotFoundError)
    # On Python 3.7+, we get a ResourceWarning about unclosed temporary files;
    # suppress that too.
    warnings.simplefilter("ignore", ResourceWarning)
    # On Python 2.6+, we get a ResourceWarning from pickle.dump();
    # suppress it too
    warnings.simplefilter("ignore", ResourceWarning)


# Generated at 2022-06-11 19:42:24.673958
# Unit test for method load of class Grammar
def test_Grammar_load():
    class TestGrammar(Grammar):
        def __init__(self) -> None:
            self.symbol2number = {"a": 256}
            self.number2symbol = {256: "a"}
            self.states = [123]
            self.dfas = {256: (456, 789)}
            self.labels = [(0, "EMPTY")]
            self.keywords = {"EMPTY": 0}
            self.tokens = {"token": 0}
            self.symbol2label = {"a": 256}
            self.start = 256
            self.async_keywords = False
    tg = TestGrammar()
    _, file = tempfile.mkstemp()

# Generated at 2022-06-11 19:42:31.825167
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.states = [
        [
            (0, 1),
            (256, 2),
            (257, 3),
            (258, 4),
            (259, 5),
            (260, 6),
            (261, 7),
        ]
    ]
    g.start = 258
    g.labels = [(0, "EMPTY"), (256, None), (257, "def"), (258, "stmt"), (259, "sstmt")]
    g.dfas = {258: (g.states[0], {257: 1, 258: 1}), 259: (g.states[0], {261: 1})}
    g.symbol2number = {"stmt": 258, "sstmt": 259}

# Generated at 2022-06-11 19:42:39.080491
# Unit test for method load of class Grammar
def test_Grammar_load():
    if token.DOUBLESTAR:
        pass  # pragma: no cover

# Generated at 2022-06-11 19:42:49.075506
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.states = [[(1, 2), (3, 4)]]
    g.symbol2number = {}
    g.number2symbol = {}
    g.dfas = {1: (1, 3)}
    g.labels = [("a", "b"), ("c", "d"), ("e", "f"), ("g", "h")]
    g.keywords = {}
    g.tokens = {}
    g.symbol2label = {}
    g.start = 256
    f = tempfile.NamedTemporaryFile()
    f.close()
    g.dump(f.name)
    del g
    g = Grammar()
    g.load(f.name)
    assert g.states == [[(1, 2), (3, 4)]]
    assert g

# Generated at 2022-06-11 19:43:00.332637
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test: create a new class, set instance variables and dump it to a pickle
    # file, then load it again.  See if everything is there
    from ._pgen2_parse import PgenGrammar
    g = PgenGrammar()
    g.load_grammar_if_not_loaded()
    g2 = Grammar()
    g.symbol2number["_"] = 256
    g.dump(os.devnull)
    g2.load(os.devnull)
    assert g2.symbol2number["_"] == 256
    # Test: loading a old-style grammar with a dfa table in the pickle file
    g3 = Grammar()
    assert g3.load(__file__.replace(".py", ".pkl"))

# Generated at 2022-06-11 19:43:11.642409
# Unit test for method load of class Grammar
def test_Grammar_load():
    # mypyc generates objects that don't have a __dict__, but they
    # do have __getstate__ methods that will return an equivalent
    # dictionary
    def getstate(self):
        return {
            "symbol2number": self.symbol2number,
            "number2symbol": self.number2symbol,
            "states": self.states,
            "dfas": self.dfas,
            "labels": self.labels,
            "keywords": self.keywords,
            "tokens": self.tokens,
            "symbol2label": self.symbol2label,
            "start": self.start,
            "async_keywords": self.async_keywords,
        }

    grammar = Grammar()
    grammar.__getstate__ = getstate  # type

# Generated at 2022-06-11 19:43:14.526826
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = '/tmp/grammar_test.pickle'
    dump_filename = '/tmp/grammar_test.pickle'
    g = Grammar()
    g.dump(dump_filename)
    g.load(filename)
    g.report()

# Generated at 2022-06-11 19:43:26.239346
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest.mock as mock
    from io import BytesIO

    grammar = Grammar()
    assert len(grammar.keywords) == 0
    assert len(grammar.states) == 0
    assert len(grammar.dfas) == 0
    assert len(grammar.symbol2number) == 0

    grammar.keywords["foo"] = 2
    grammar.states.append([])
    grammar.dfas[2] = ([], {})
    grammar.symbol2number["foo"] = 2

    file = mock.Mock(spec=BytesIO)
    grammar.dump(file)
    file.write.assert_called_once()
    args, kwargs = file.write.call_args_list[0]
    value = pickle.loads(args[0])

# Generated at 2022-06-11 19:43:37.015037
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pytest

    from .conv import convert, pygram
    from .pgen2.parse import ParseError
    from .token import tokenize

    pygram_pkl = os.path.join(
        os.path.dirname(__file__), "Grammar.pygram.pickle"
    )
    if os.path.exists(pygram_pkl):
        g = Grammar()
        g.load(pygram_pkl)
    else:
        g = pygram.python_grammar
    with tempfile.NamedTemporaryFile(delete=False) as tf:
        g.dump(tf.name)
        pytest.raises(ParseError, convert, tokenize(b"1+2"), g)
    os.remove(tf.name)

# Generated at 2022-06-11 19:43:47.645334
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest

    class GrammarLoadTests(unittest.TestCase):
        """Unit testing for method load of class Grammar"""

        def test_load_pickle(self):
            """Testing functionality of method load of class Grammar"""
            expect = Grammar()
            expect.loads(b"c__builtin__\np0\n(dp1\n.".replace(b"__builtin__", b"builtins"))
            grammar = Grammar()
            grammar.load("pgen_pickle")
            self.assertEqual(expect.labels, grammar.labels)
            self.assertEqual(expect.start, grammar.start)
            self.assertEqual(expect.tokens, grammar.tokens)

# Generated at 2022-06-11 19:43:53.159279
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import py_grammar

    f = tempfile.NamedTemporaryFile(suffix='.pickle')
    py_grammar.dump(f.name)
    py_grammar.load(f.name)
    f.delete = False
    f.close()



# Generated at 2022-06-11 19:43:59.745984
# Unit test for method load of class Grammar

# Generated at 2022-06-11 19:44:15.278785
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import conv
    g = conv.generate_grammar("Grammar.test")
    tempfile = os.path.join("testdata", "Grammar.test")
    g.dump(tempfile)


# Generated at 2022-06-11 19:44:18.366980
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import grammar

    def _test(data: bytes):
        gr = Grammar()
        gr.loads(data)
        assert gr.start == 257

    _test(data)

# Generated at 2022-06-11 19:44:23.000775
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump('Grammar.dump.1')
    g.load('Grammar.dump.1')
    g.dump('Grammar.dump.2')
    with open('Grammar.dump.1', 'rb') as file1:
        with open('Grammar.dump.2', 'rb') as file2:
            data1 = file1.read()
            data2 = file2.read()
            assert data1 == data2

# Generated at 2022-06-11 19:44:33.580858
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Lib/test/badsyntax_grammar")
    assert g.symbol2number["badsyntax"] == 257
    assert g.symbol2number["expr"] == 260
    assert g.symbol2number["xor_expr"] == 265
    assert g.symbol2number["term"] == 261
    assert g.symbol2number["factor"] == 263
    assert g.symbol2number["atom"] == 264
    assert g.symbol2number["dictorsetmaker"] == 266
    assert g.symbol2number["import_as_name"] == 273
    assert g.symbol2number["name"] == 271
    assert g.symbol2number["vfpdef"] == 267
    assert g.symbol2number["vfplist"] == 268
    assert g.sy

# Generated at 2022-06-11 19:44:43.947579
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Build up a dummy grammar
    grammar = Grammar()
    grammar.symbol2number = test_symbol2number = {}
    grammar.number2symbol = test_number2symbol = {}
    grammar.states = test_states = []
    grammar.dfas = test_dfas = {}
    grammar.labels = test_labels = []
    grammar.keywords = test_keywords = {}
    grammar.tokens = test_tokens = {}

    grammar.dump(filename = "test.pickle")

    # Check the pickle file contents
    import pickle
    with open("test.pickle", "rb") as pkl_file:
        check_dict = pickle.load(pkl_file)
        check_symbol2number = check_dict["symbol2number"]
        check_number