

# Generated at 2022-06-11 19:34:56.470865
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test that load() works.
    import pickle
    import io

    grammar = Grammar()
    grammar.number2symbol = {256: "start"}
    grammar.symbol2number = {"start": 256}
    grammar.symbol2label = {"start": 1}
    grammar.start = 256
    grammar.dfas = {256: ([[(0, 1), (1, 2)]], {})}
    grammar.labels = [(1, "start")]
    grammar.tokens = {}
    grammar.states = [[[(0, 1)]]]
    grammar.keywords = {}
    output = io.BytesIO()
    pickle.dump(grammar, output)
    grammar_data = output.getvalue()
    grammar1 = Grammar()
    grammar1.loads(grammar_data)
   

# Generated at 2022-06-11 19:35:08.773318
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    gram = Grammar()

    gram.symbol2number = {"'a'": 256, "'b'": 258}
    gram.number2symbol = {256: "'a'", 258: "'b'"}
    gram.states = [[[(1, 2), (3, 4), (4, 4)], [(4, 4)]], [[(4, 4)]]]
    gram.dfas = {256: ([[(1, 2), (3, 4), (4, 4)], [(4, 4)]], {1: 1, 3: 1}), 258: ([[(4, 4)]], {})}
    gram.labels = [(0, "EMPTY"), (1, '"a"'), (3, '"b"')]
    gram.keywords = {'"b"': 3, '"a"': 1}
    gram

# Generated at 2022-06-11 19:35:15.134443
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Unit test for method load of class Grammar."""
    from io import BytesIO

    g = Grammar()
    g.loads(pickle.dumps({"foo": 1, "bar": 42}))
    assert g.foo == 1
    assert g.bar == 42

    g = Grammar()
    fp = BytesIO()
    d = {"foo": 1, "bar": 42}
    pickle.dump(d, fp, pickle.HIGHEST_PROTOCOL)
    fp.seek(0)
    g.load(fp)
    assert g.foo == 1
    assert g.bar == 42

# Generated at 2022-06-11 19:35:17.945503
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    '''Test the dump method of Grammar class'''
    gr = Grammar()
    gr.dump("dump_test.py")

# Generated at 2022-06-11 19:35:27.872344
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    x = 2
    y = 3
    g1 = Grammar()
    g1.test = 4
    g1.test2 = 5
    g1.test3 = 6
    g2 = Grammar()
    g2.test3 = 6
    try:
        g2.dump("dump_test.p")
        g2.load("dump_test.p")
        assert g1.__dict__ == g2.__dict__
    except:
        raise
    finally:
        try:
            os.remove("dump_test.p")
        except:
            pass

# Generated at 2022-06-11 19:35:37.566176
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    class subclass(Grammar):
        def __init__(self):
            self.symbol2number = {"A": 1, "B": 2}
            self.number2symbol = {1: "A", 2: "B"}
            self.states = [[[(1, 1), (2, 2)], [(3, 3), (4, 4)]],
                           [[(5, 5), (6, 6)]]]
            self.dfas = {2: ([[(1, 1), (2, 2)]], {1: 1}),
                         5: ([[(3, 3), (4, 4)]], {2: 1})}

# Generated at 2022-06-11 19:35:40.345195
# Unit test for method load of class Grammar
def test_Grammar_load():
    obj = Grammar()
    obj.load(os.path.join(os.path.dirname(__file__), 'Grammar.txt'))
    print('done')

# Generated at 2022-06-11 19:35:48.227559
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import grammar
    from . import pgen2


    def generate_pickle() -> bytes:
        pkl_dir = os.path.join(os.path.dirname(__file__), "..", "..", "..", "test", "data")
        gp = pgen2.generate_grammar(os.path.join(pkl_dir, "Grammar.txt"))
        g = grammar.Grammar()
        g.__init__()
        g._update(gp.__dict__)
        return pickle.dumps(g.__dict__, pickle.HIGHEST_PROTOCOL)



# Generated at 2022-06-11 19:35:58.169769
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.loads(b'\x80\x03}q\x00X\x0b\x00\x00\x00symbol2numberq\x01}q\x02(X\x02\x00\x00\x00ifq\x03K\x01X\x03\x00\x00\x00defq\x04K\x02u.')
    assert g.symbol2number == {'if': 1, 'def': 2}

# Generated at 2022-06-11 19:36:00.494995
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load('Grammar.pickle')
    g.report()


# Generated at 2022-06-11 19:36:13.879154
# Unit test for method load of class Grammar
def test_Grammar_load():

    g = Grammar()
    filename = "test/fixtures/grammar.pkl"
    g.load(filename)

    assert g.async_keywords == False
    assert g.start == 278
    assert g.symbol2number["_arglist"] == 276
    assert g.symbol2number["_comp_op"] == 447
    assert g.symbol2number["_name"] == 1
    assert g.symbol2number["_mklambda"] == 290
    assert g.symbol2number["_print_stmt"] == 383
    assert g.symbol2number["_atom"] == 11
    assert g.symbol2number["_stmt"] == 8
    assert g.symbol2number["_comp_for"] == 437
    assert g.symbol2number["_comp_if"] == 435

# Generated at 2022-06-11 19:36:20.254828
# Unit test for method load of class Grammar
def test_Grammar_load():
    gr = Grammar()
    gr.load('Grammar.txt')
    assert gr.start == 256
    assert gr.async_keywords == False


if __name__ == '__main__':
    gr = Grammar()
    gr.load('Grammar.txt')
    print(gr.start)
    print(gr.async_keywords)

# Generated at 2022-06-11 19:36:32.003261
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import sys

    _, filename = tempfile.mkstemp()
    temp_file = io.StringIO()

    try:
        saved_stdout = sys.stdout
        sys.stdout = temp_file
        grammar = Grammar()
        grammar.dump(filename)
        grammar.report()
        assert "s2n" in temp_file.getvalue()
        assert "n2s" in temp_file.getvalue()
        assert "states" in temp_file.getvalue()
        assert "dfas" in temp_file.getvalue()
        assert "labels" in temp_file.getvalue()
        assert "start" in temp_file.getvalue()
    finally:
        sys.stdout = saved_stdout
        os.remove(filename)


# Generated at 2022-06-11 19:36:37.156925
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Unit test for method Grammar.load()."""
    class E(Exception):
        pass

    def raiseE():
        raise E()
    class G(Grammar):
        def load(self, *args):
            try:
                raiseE()
            except E:
                self.x = 1
    g = G()
    g.load(None)
    assert g.x == 1


# Generated at 2022-06-11 19:36:38.319356
# Unit test for method dump of class Grammar
def test_Grammar_dump():
  # method dump of class Grammar
  g = Grammar()
  g.dump("foo")

# Generated at 2022-06-11 19:36:47.540894
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Create a Grammar instance and add some attributes
    g = Grammar()
    g.test_attr = 42
    f = tempfile.NamedTemporaryFile(dir=".", delete=False)
    f.close()
    g.dump(f.name)
    # Create another Grammar instance and load the pickle file
    h = Grammar()
    h.load(f.name)
    os.unlink(f.name)
    # The test_attr should be there, but with a different value
    assert hasattr(h, "test_attr")
    assert h.test_attr != g.test_attr

# Generated at 2022-06-11 19:36:56.138327
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = os.path.join(os.path.dirname(__file__), "..", "..", "Grammar.pkl")
    g = Grammar()
    g.symbol2number = {'and': 257, 'testandtest': 258}
    g.number2symbol = {257: 'and', 258: 'testandtest'}
    g.states = [[(0, 1), (0, 2), (0, 3), (0, 4), (0, 5), (0, 6), (0, 7), (0, 8), (0, 9), (1, 10), (0, 11), (0, 12)], [(0, 0)]]
    g.dfas = {258: (g.states[0], {259: 1}), 257: (g.states[1], {260: 1})}


# Generated at 2022-06-11 19:36:59.484775
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(os.path.join(os.path.dirname(__file__), "Grammar.pickle"))
    assert grammar != Grammar()



# Generated at 2022-06-11 19:37:01.554281
# Unit test for method load of class Grammar
def test_Grammar_load():
    for _ in range(5):
        pkl = Grammar().dumps()
        Grammar().loads(pkl)

# Generated at 2022-06-11 19:37:04.246409
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.dump("notarealname")
    h = Grammar()
    h.load("notarealname")

# Generated at 2022-06-11 19:37:11.104509
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle

    data = pickle.dumps(Grammar())

    g = Grammar()
    g.load(data)
    assert data == pickle.dumps(g)

# Generated at 2022-06-11 19:37:19.846481
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[[(1, 2), (3, 4)], [(5, 6)]]]
    g.dfas = {0: ([[(1, 2), (3, 4)], [(5, 6)]], {0: 0, 1: 1, 2: 2})}
    g.labels = [(0, None), (1, 'foo'), (2, 'bar'), (3, 'baz')]
    g.start = 255  # Should be updated to 256.
    assert g.symbol2number == {'foo': 1, 'bar': 2}

# Generated at 2022-06-11 19:37:24.331096
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    filename = "test_Grammar_dump"
    grammar.dump(filename)
    grammar2 = Grammar()
    grammar2.load(filename)
    assert grammar2.symbol2number == grammar.symbol2number

# Generated at 2022-06-11 19:37:32.004310
# Unit test for method load of class Grammar
def test_Grammar_load():
    import io
    import unittest
    import pickle

    from .Grammar import Grammar

    from .pgen import pgen
    from .token import NAME, NEWLINE

    class TestCase(unittest.TestCase):
        def assert_tables_equal(self, g1, g2):
            for attr in ['symbol2number', 'number2symbol', 'dfas',
                         'keywords', 'tokens']:
                self.assertEqual(getattr(g1, attr), getattr(g2, attr))
            self.assertEqual(len(g1.states), len(g2.states))
            for state1, state2 in zip(g1.states, g2.states):
                self.assertEqual(len(state1), len(state2))

# Generated at 2022-06-11 19:37:41.474091
# Unit test for method load of class Grammar
def test_Grammar_load():
    # write a test pickle file
    # The test pickle file is intended to be used only for testing
    # and thus is not included in the distribution.
    f_name = 'Grammar.pkl'

# Generated at 2022-06-11 19:37:52.971270
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Test that the pickle file can be unpickled
    # and contains the same data
    # with the same attribute names
    g = Grammar()
    g.symbol2number = {'bar': 1}
    g.number2symbol = {1: 'bar'}
    g.states = []
    g.dfas = {1: ([], {})}
    g.labels = [(1, 'bar')]
    g.start = 2
    f = tempfile.NamedTemporaryFile(mode='wb', delete=False)
    g.dump(f)
    f.close()
    h = Grammar()
    h.load(f.name)
    os.remove(f.name)
    assert g.symbol2number == h.symbol2number

# Generated at 2022-06-11 19:38:00.751385
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    class MyGrammar(Grammar):
        def __init__(self) -> None:
            super().__init__()
            self.symbol2number = {
                "a": 256,
                "b": 257,
                "c": 258,
            }
            self.number2symbol = {
                256: "a",
                257: "b",
                258: "c",
            }
            self.states = [[(1, 1)]]
            self.dfas = {}
            self.labels = [(0, "EMPTY")]
            self.keywords = {}
            self.tokens = {}
            self.symbol2label = {}
            self.start = 256
            self.async_keywords = False

    filename = "test.py"

# Generated at 2022-06-11 19:38:11.912293
# Unit test for method load of class Grammar
def test_Grammar_load():
    def check_Grammar(g: Grammar):
        assert g.symbol2number == {'foo': 256}
        assert g.number2symbol == {256: 'foo'}
        assert g.states == [[[(921, 1)]]]
        assert g.dfas == {256: ([[(921, 1)]], {1: 1}), 257: ([[(0, 0)]], {0: 1})}
        assert g.labels == [(0, 'EMPTY'), (256, None), (257, None), (258, 'bar')]
        assert g.keywords == {'bar': 258}
        assert g.tokens == {257: 257}
        assert g.symbol2label == {'bar': 258}
        assert g.start == 256
        assert g.async_keywords

# Generated at 2022-06-11 19:38:18.977958
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Test loading from a pickle file."""
    g = Grammar()
    g.symbol2number = {"foo": 42}
    g.dump("test_Grammar_load.pkl")
    g2 = Grammar()
    g2.load("test_Grammar_load.pkl")
    assert g.symbol2number == g2.symbol2number

test_Grammar_load.need_pickle = True

# Generated at 2022-06-11 19:38:21.640087
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")

# __main__
if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-11 19:38:30.500957
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2

    # Initialize the instance.
    g = pgen2.driver.load_grammar("Python.gram")
    g2 = Grammar()
    g2.load("Python.pkl")

    # Compare the instance with a reference.
    assert g.__dict__ == g2.__dict__

# Generated at 2022-06-11 19:38:43.261431
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    def _test(dir_path: str) -> None:
        fname = os.path.join(dir_path, 'test.pkl')
        grammar = Grammar()
        grammar.dump(fname)
        grammar2 = Grammar()
        grammar2.load(fname)
        assert grammar.number2symbol == grammar2.number2symbol
        assert grammar.symbol2number == grammar2.symbol2number
        assert grammar.dfas == grammar2.dfas
        assert grammar.keywords == grammar2.keywords
        assert grammar.tokens == grammar2.tokens
        assert grammar.symbol2label == grammar2.symbol2label
        assert grammar.labels == grammar2.labels
        assert grammar.start == grammar2.start

# Generated at 2022-06-11 19:38:45.138003
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")
    g.report()


# Generated at 2022-06-11 19:38:47.495156
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("/path/to/a/pickle/file")

# Generated at 2022-06-11 19:38:58.753557
# Unit test for method load of class Grammar
def test_Grammar_load():
    import io
    import unittest
    import warnings
    import sys

    class Test_Grammar(unittest.TestCase):

        def setUp(self):
            self.saved_stderr = sys.stderr
            self.saved_stdout = sys.stdout

        def tearDown(self):
            sys.stderr = self.saved_stderr
            sys.stdout = self.saved_stdout

        def _test(self, expected, test):
            stdout = io.StringIO()
            sys.stdout = stdout
            test()
            self.assertEqual(expected, stdout.getvalue())

        def test_load_broken_pickle(self):
            # Issue13771: loading an empty but valid pickle should not crash
            stdout = io.String

# Generated at 2022-06-11 19:38:59.576280
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()  # type: ignore
    g.load("Grammar.pickle")  # type: ignore

# Generated at 2022-06-11 19:39:03.694582
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen2
    filename = "/tmp/Grammar-dump.pickle"
    g = pgen2.driver.load_grammar("Grammar")
    g.dump(filename)
    assert os.path.isfile(filename)

    os.remove(filename)
    assert not os.path.exists(filename)

# Generated at 2022-06-11 19:39:12.696649
# Unit test for method load of class Grammar
def test_Grammar_load():
    """This is a unit test for method load of class Grammar."""
    # pylint: disable=unused-variable
    import pickle
    import sys
    import traceback

    grammar = Grammar()
    data = (512, "NUMBER")
    pickled = pickle.dumps(data, pickle.HIGHEST_PROTOCOL)
    filename = sys.executable.replace("python.exe", "parsetab.pickle")
    with open(filename, "wb") as f:
        f.write(pickled)
    # Load the grammar
    try:
        grammar.load(filename)
    except Exception as e:
        traceback.print_exc()
    os.unlink(filename)

# Generated at 2022-06-11 19:39:17.845447
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("foo")
    g.dump(b"bar")
    # mypyc generates objects that don't have a __dict__, but they
    # do have __getstate__ methods that will return an equivalent
    # dictionary
    # g.dump(g.__getstate__())
    # g.dump(g)

# Generated at 2022-06-11 19:39:27.194242
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from pathlib import Path
    from gensupport.grammar import ParserGenerator
    from gensupport.parser import FileParser
    from gensupport.parse import Parser

    g = ParserGenerator(Path("test_Grammar_dump.grammar"), "start")
    g.generate_tables()
    g.dump("test_Grammar_dump.pkl")
    p = FileParser("test_Grammar_dump.pkl")

    # Test that the dumped tables can be used to parse a file
    assert p.parse("1") == ["1"]

if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-11 19:39:45.373415
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = os.path.join(os.path.dirname(__file__), 'Grammar_dump.pkl')

    class DataGrammar(Grammar):
        def __init__(self):
            super().__init__()
            self.symbol2number = {'SYMBOL_2_NUMBER_TEST': 5}
            self.number2symbol = {1: 'NUMBER_2_SYMBOL_TEST'}
            self.states = [[[(1, 1)], [(1, 1), (1, 1)]]]
            self.dfas = {3: ([[(1, 1), (1, 1)], [(1, 1)]], {2: 3})}
            self.labels = [(1, 'LABEL_TEST')]

# Generated at 2022-06-11 19:39:50.374892
# Unit test for method load of class Grammar
def test_Grammar_load():
    from grammar_parser.pgen2 import pgen

    g = Grammar()
    g.load(pgen.__file__)
    g.report()
    print(g.number2symbol[g.start])



# Generated at 2022-06-11 19:40:00.858940
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pytest
    import importlib
    import sys

    module_name = "parse_grammar"
    del sys.modules[module_name]

    filename = "test_Grammar_dump.pkl"
    g = Grammar()
    try:
        g.dump(filename)
    except (OSError, pickle.PickleError):
        pytest.skip()

    g2 = Grammar()
    g2.load(filename)
    assert g == g2

    m = importlib.import_module(module_name)

    for dict_attr in (
        "symbol2number",
        "number2symbol",
        "dfas",
        "keywords",
        "tokens",
        "symbol2label",
    ):
        assert getattr(g, dict_attr) == get

# Generated at 2022-06-11 19:40:05.307483
# Unit test for method load of class Grammar
def test_Grammar_load():
    src = b"""
import pickle
if __name__ == '__main__':
    g = pickle.load(open("Grammar.pickle", "rb"))
"""
    p = Grammar()
    p.loads(src)

# Generated at 2022-06-11 19:40:13.330179
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pytest

    class GrammarTestCase(unittest.TestCase):
        def test_grammar_dump(self):
            grammar = Grammar()

            with tempfile.NamedTemporaryFile() as temp:
                filename = temp.name

            expected = "s2n\n{}\nn2s\n{}\nstates\n[]\ndfas\n{}\nlabels\n[(0, 'EMPTY')]\nstart 256"  # noqa: E501
            grammar.dump(filename)
            with open(filename, "r") as f:
                actual = f.read()
            self.assertEqual(actual, expected)

    with pytest.raises(Exception):
        GrammarTestCase().test_grammar_dump()

# Generated at 2022-06-11 19:40:24.031801
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    class MyGrammar(Grammar):
        def __init__(self):
            Grammar.__init__(self)

# Generated at 2022-06-11 19:40:32.078685
# Unit test for method load of class Grammar
def test_Grammar_load():
    def helper(filename, exp_start, exp_number2symbol, exp_symbol2number):
        g = Grammar()
        g.load(filename)
        assert g.start == exp_start
        assert g.number2symbol == exp_number2symbol
        assert g.symbol2number == exp_symbol2number
    the_filename = "./test/data/Grammar.test_Grammar_load.pkl"
    # This data is obtained from a dump of the Grammar instance in
    # Lib/test/test_grammar.py.
    exp_start = 256

# Generated at 2022-06-11 19:40:45.536791
# Unit test for method load of class Grammar
def test_Grammar_load():
    def func():
        pass

    g = Grammar()
    f = tempfile.NamedTemporaryFile(delete=False)
    g.dump(f.name)
    f.close()
    g2 = Grammar()
    g2.load(f.name)
    assert g.__dict__ == g2.__dict__
    os.unlink(f.name)

    # pylint: disable=unnecessary-pass
    # the pass is there to show that the code below has no effect
    g.load(func)
    g.loads(pickle.dumps(g.__dict__))
    g2 = Grammar()
    g2.loads(None)

    # pylint: disable=bad-whitespace
    g.load(None)
    # pylint: enable=bad-whites

# Generated at 2022-06-11 19:40:49.584977
# Unit test for method load of class Grammar
def test_Grammar_load():
    class MockGrammar(Grammar):
        pass
    filename = os.path.join(os.path.dirname(os.path.realpath(__file__)), "Grammar.pkl")
    g = MockGrammar()
    g.load(filename)
    return g

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-11 19:40:59.364418
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest.mock as mock
    import ast

    g = ast.Grammar()
    filename = "foo"
    with mock.patch("parser.grammar.ast.pickle") as mock_pickle:
        g.dump(filename)
        assert mock_pickle.dump.called

    # Test that all calls write the file in a secure manner
    for func in ("dump", "loads"):
        for secure in (False, True):
            g = ast.Grammar()
            filename = "foo"

# Generated at 2022-06-11 19:41:27.654262
# Unit test for method load of class Grammar
def test_Grammar_load():
    def check_grammar(g: Grammar) -> None:
        assert g.start == 256
        assert "class" in g.symbol2number
        assert "classdef" in g.symbol2number
        assert "def" in g.symbol2number
        assert "suite" in g.symbol2number
        assert "file_input" in g.symbol2number
        assert 257 in g.number2symbol
        assert 258 in g.number2symbol
        assert 259 in g.number2symbol
        assert 260 in g.number2symbol
        assert 261 in g.number2symbol
        assert "if_stmt" in g.symbol2label
        assert "ifelsestmt" in g.symbol2label
        assert 25 in g.symbol2label["suite"]

# Generated at 2022-06-11 19:41:38.418309
# Unit test for method load of class Grammar
def test_Grammar_load():
    class Foo(Grammar):
        pass

    foo = Foo()
    with tempfile.TemporaryFile("r+b") as f:
        foo.dump(f)
        f.seek(0)
        foo2 = Foo()
        foo2.load(f)

    assert set(foo.symbol2number) == set(foo2.symbol2number)
    assert set(foo.number2symbol) == set(foo2.number2symbol)
    assert set(foo.dfas) == set(foo2.dfas)
    assert set(foo.keywords) == set(foo2.keywords)
    assert set(foo.tokens) == set(foo2.tokens)
    assert set(foo.symbol2label) == set(foo2.symbol2label)

# Generated at 2022-06-11 19:41:43.924206
# Unit test for method load of class Grammar
def test_Grammar_load():
    gr = Grammar()
    g1 = gr.load("Python37/Grammar.pkl")
    # This is to test the type return by load.
    g2 = Grammar().load("Python37/Grammar.pkl")
    assert g1 is None  # type: ignore
    assert g2 is None  # type: ignore

# Generated at 2022-06-11 19:41:51.536111
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pickle"))
    assert g.symbol2number["NUMBER"] == 258
    assert g.number2symbol[258] == "NUMBER"
    assert g.dfas[258][0][255] == [(2, 257)]
    assert g.keywords["False"] == 2
    assert g.tokens[2] == 1
    assert g.symbol2label["expr_stmt"] == 3
    assert g.labels[3] == (257, None)
    assert g.states == [[[(0, 1)], [(4, 2)], [(4, 3)], [(4, 4)], [(4, 5)]]]
    assert g.start == 257

# Generated at 2022-06-11 19:42:01.949786
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import struct

    g = Grammar()

    # mypyc generates objects that don't have a __dict__, but they
    # do have __getstate__ methods that will return an equivalent
    # dictionary
    if hasattr(g, "__dict__"):
        d = g.__dict__
    else:
        d = g.__getstate__()  # type: ignore

    with tempfile.NamedTemporaryFile() as f:
        g.dump(f.name)
        with open(f.name, "rb") as f1:
            header = f1.read(2)
            assert header == b"\x80\x03"
            data = f1.read()
    assert pickle.loads(header + data) == d

    # Verify that load() works

# Generated at 2022-06-11 19:42:05.248661
# Unit test for method load of class Grammar
def test_Grammar_load():
    gr = Grammar()
    gr.load(__file__.replace(".py", ".pickle"))
    assert gr.symbol2number["atom"] == 258


# Generated at 2022-06-11 19:42:13.452892
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()

    # If a file does not exist, load raises FileNotFoundError.
    from pytest import raises

    with raises(FileNotFoundError):
        grammar.load("__file_that_does_not_exist__")

    # In the following test case, a file "foo.pkl" is created with
    # dump, then loaded with load, then the loaded grammar is dumped
    # to "bar.pkl", and finally the contents of the two files are
    # compared.
    import pickle
    import random
    import string

    random.seed(42)
    with open("foo.pkl", "wb") as f:
        d = {}

# Generated at 2022-06-11 19:42:24.905599
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import ast

    g = Grammar()
    g.symbol2number["foo"] = 1
    g.number2symbol[2] = "bar"
    g.states = [[[(1, 2), (3, 4)], [(5, 6), (7, 8)]]]
    g.dfas = {1: ([[(1, 2), (3, 4)], [(5, 6), (7, 8)]], {1: 1, 2: 2}), 2: ([], {})}
    g.labels = [(1, 1), (2, 2)]
    g.keywords = {"foo": 1}
    g.tokens = {"<": 2, ">": 3}
    g.symbol2label = {"foo": "bar", "baz": "qux"}
    g.start = 256


# Generated at 2022-06-11 19:42:30.512135
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    class Foo(Grammar):
        def __init__(self):
            super().__init__()
            self.x = 1
            self.y = 2

    def do_test(filename: Path) -> None:
        f = Foo()
        f.dump(filename)
        f.x = 2
        f.loads(open(filename, "rb").read())
        assert f.x == 1
        assert f.y == 2

    do_test(tempfile.mktemp())
    do_test(os.path.join(tempfile.gettempdir(), "test_Grammar_dump"))


# Generated at 2022-06-11 19:42:32.112716
# Unit test for method load of class Grammar
def test_Grammar_load():
    t = Grammar()
    import io
    t.loads(io.BytesIO(b'\x80\x03}q\x00.'))
    return True

# Generated at 2022-06-11 19:42:59.860577
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    gram = Grammar()
    gram.symbol2number = {'foo': 42}
    gram.number2symbol = {42: 'foo'}
    gram.start = 42
    gram.states = [ [(1,1)], [(0,1)] ]
    gram.labels = [(0, "EMPTY"), (1, None)]
    gram.dfas = {1: ( [], {} )}
    gram.keywords = {"bar": 2}
    gram.tokens = {5: 3}
    gram.symbol2label = {"foo": 4}


# Generated at 2022-06-11 19:43:01.934381
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    test_grammar = Grammar()
    assert test_grammar.dump('/tmp/') == None

# Generated at 2022-06-11 19:43:08.574088
# Unit test for method load of class Grammar
def test_Grammar_load():
    b = Grammar()
    b.loads(b"cposix\nstrop\n_pickle.Unpickler\np0\n(S'python-grammar.pickle'\np1\ntp2\nRp3\n.")
    assert b.tokens[1] == 4300

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-11 19:43:17.535727
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from io import BytesIO

    g = Grammar()
    g.symbol2number["foo"] = 1
    g.number2symbol[1] = "foo"
    g.states = []
    g.dfas = {"foo": ([1, [[2], [3]]], {"foo": 2})}
    g.labels = [
        (token.STRING, "hi there"),
        (token.ENDMARKER, None),
        (token.NAME, "foo"),
        (token.OP, "*"),
    ]
    g.keywords = {"def": 4, "class": 7}
    g.tokens = {token.STAR: 3}
    g.symbol2label["bar"] = 5
    g.start = 23
    g.async_keywords = True

    f = Bytes

# Generated at 2022-06-11 19:43:28.206999
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    class MyGrammar(Grammar):
        def __init__(self) -> None:
            Grammar.__init__(self)
            self.labels = [(0, "EMPTY")]
            self.keywords = {"and": 0}
            self.tokens = {"NAME": 0}
            self.symbol2label = {"LAMBDA": 0}
            self.start = 256
    grammar = MyGrammar()
    grammar.dump("mygrammar.pickle")
    reloaded = MyGrammar()
    reloaded.load("mygrammar.pickle")
    assert grammar.labels == reloaded.labels
    assert grammar.keywords == reloaded.keywords
    assert grammar.tokens == reloaded.tokens
    assert grammar.symbol2label == reloaded.sy

# Generated at 2022-06-11 19:43:38.359748
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()

    # Test 1: empty file
    with tempfile.NamedTemporaryFile(mode="wb", delete=False) as f:
        f.write(b"")
    try:
        g.load(f.name)
    except pickle.UnpicklingError:
        # If the file is empty, we should get an UnpicklingError
        pass
    else:
        raise ValueError("Expected UnpicklingError")
    os.remove(f.name)

    # Test 2: invalid file
    with tempfile.NamedTemporaryFile(mode="wb", delete=False) as f:
        f.write(b"\x8f")

# Generated at 2022-06-11 19:43:44.872118
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest

    class TestGrammar(unittest.TestCase):
        def test_grammar(self) -> None:
            # Construct a Grammar instance with a few known attributes
            g = Grammar()
            g.states = [
                [(257, 2), (258, 1)],
                [(0, 1)],
                [(0, 2), (1, 3), (2, 1)],
                [(0, 3)],
            ]
            g.start = 257

# Generated at 2022-06-11 19:43:51.243846
# Unit test for method load of class Grammar
def test_Grammar_load():
    """This tests the Grammar class."""
    import unittest
    import unittest.mock
    import io
    import pickle
    from typing import Type

    class Mock_Grammar(Grammar):
        def __init__(self) -> None:
            self.tok_name = unittest.mock.Mock(return_value="FAKE NAME")

    # dyn load pickle file
    class Mock_Opener(io.IOBase):
        def __init__(self, data: bytes) -> None:
            self.data = data
            self.pointer = 0

        def read(self, size: int = 0) -> bytes:
            length = len(self.data)
            if size == 0:
                size = length
            if self.pointer >= length:
                return b""

# Generated at 2022-06-11 19:43:59.030319
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = tempfile.mktemp()
    g = Grammar()
    g.dump(filename)
    h = Grammar()
    h.load(filename)
    assert g.symbol2number == h.symbol2number
    assert g.number2symbol == h.number2symbol
    assert g.states == h.states
    assert g.dfas == h.dfas
    assert g.labels == h.labels
    assert g.start == h.start
    assert g.keywords == h.keywords
    assert g.tokens == h.tokens
    assert g.symbol2label == h.symbol2label


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-11 19:44:08.905035
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    # Create test grammar
    g = Grammar()
    g.states = [
        [[(1, 1), (2, 2), (3, 3)], [(4, 4), (5, 5), (3, 3)], [(3, 3), (6, 6)]]
    ]
    g.symbol2number = {"a": 256, "b": 257}
    g.number2symbol = {256: "a", 257: "b"}
    g.dfas = {
        256: ([[(1, 1), (2, 2), (3, 3)], [(4, 4), (5, 5), (3, 3)], [(3, 3), (6, 6)]], {"b": 1})
    }

# Generated at 2022-06-11 19:44:30.045364
# Unit test for method load of class Grammar

# Generated at 2022-06-11 19:44:38.101687
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.start = 1024
    g.symbol2number = {'x': 128}
    g.number2symbol = {128: 'x'}
    g.states = [
        [
            [(256, 1), (257, 2)],
            [(258, 3)],
            [(259, 4)],
            [(260, 5), (261, 6)],
            [(262, 7)],
            [(0, 7)],
            [(263, 7)],
        ]
    ]
    g.dfas = {256: (g.states[0], {256: 1}), 257: (g.states[0], {257: 1})}
    g.labels = [(0, "EMPTY")]
    g.keywords = {}
    g.tokens = {}
    g

# Generated at 2022-06-11 19:44:41.925693
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    try:
        g.dump()
        assert False
    except TypeError:
        pass
    try:
        g.dump(10)
        assert False
    except TypeError:
        pass