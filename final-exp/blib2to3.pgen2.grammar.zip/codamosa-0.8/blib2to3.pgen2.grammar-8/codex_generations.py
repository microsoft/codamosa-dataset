

# Generated at 2022-06-11 19:34:43.139926
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.start = 1
    g.symbol2number = {'NAME': 2}
    g.symbol2label = {'NAME': 0}
    with tempfile.TemporaryDirectory() as td:
        f = os.path.join(td, 'foo.pickle')
        g.dump(f)
        with open(f, 'rb') as f:
            s = f.read()

# Generated at 2022-06-11 19:34:56.472301
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.dfas = {1: ([[(256, 0)]], {})}
    g.labels = [(0, None), (256, None)]
    g.number2symbol = {256: "file_input"}
    g.states = [[(256, 0)]]
    g.symbol2label = {"file_input": 256}
    g.symbol2number = {"file_input": 256}
    g.start = 256
    g.tokens = {}
    g.dump("test.pkl")
    g2 = Grammar()
    g2.load("test.pkl")
    assert g2.dfas == {1: ([[(256, 0)]], {})}
    assert g2.labels == [(0, None), (256, None)]

# Generated at 2022-06-11 19:35:08.379292
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """Test dump method of Grammar class."""

    filename = "Grammar.pkl"
    grammar = Grammar()
    grammar.dump(filename)

    with open(filename, "rb") as f:
        d = pickle.load(f)
    assert d["symbol2number"] == {}
    assert d["number2symbol"] == {}
    assert d["states"] == []
    assert d["dfas"] == {}
    assert d["labels"] == [(0, "EMPTY")]
    assert d["keywords"] == {}
    assert d["tokens"] == {}
    assert d["symbol2label"] == {}
    assert d["start"] == 256
    assert d["async_keywords"] == False

    os.remove(filename)



# Generated at 2022-06-11 19:35:15.988127
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()

    # mypyc generates objects that don't have a __dict__, but they
    # do have __getstate__ methods that will return an equivalent
    # dictionary
    if hasattr(grammar, "__dict__"):
        d = grammar.__dict__
    else:
        d = grammar.__getstate__()  # type: ignore

    with tempfile.NamedTemporaryFile(delete=False) as f:
        pickle.dump(d, f, pickle.HIGHEST_PROTOCOL)
        fname = f.name

    grammar2 = Grammar()
    grammar2.load(fname)

    for attr in ("symbol2number", "number2symbol", "states", "dfas", "labels", "keywords", "tokens"):
        assert get

# Generated at 2022-06-11 19:35:23.598562
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import os
    import tempfile
    import pickle

    pkl = pickle.dumps({"foo": "bar"}, pickle.HIGHEST_PROTOCOL)
    gram = Grammar()
    gram.loads(pkl)
    assert gram.foo == "bar"

    pkl = pickle.dumps({"foo": "bar"}, pickle.HIGHEST_PROTOCOL)
    gram = Grammar()
    with tempfile.NamedTemporaryFile(
        dir=os.path.dirname(sys.executable), delete=False
    ) as f:
        f.write(pkl)
    gram.load(f.name)
    assert gram.foo == "bar"

# Generated at 2022-06-11 19:35:32.722358
# Unit test for method load of class Grammar
def test_Grammar_load():
    import io
    import pickle

    g = Grammar()

    # Try a version that doesn't exist
    py_version = sys.version_info[0:2]
    filename = "Grammar.cpython-%s%s.pickle" % py_version
    try:
        g.load(filename)
    except FileNotFoundError:
        pass
    else:
        assert False, "Grammar.load() returned without raising"

    # Try a version that does exist
    g.symbol2number = {'test': 2}
    s = io.BytesIO()
    pickle.dump(g.__getstate__(), s, 2)
    s.flip()
    g.loads(s.read())
    assert g.symbol2number == {'test': 2}

# Generated at 2022-06-11 19:35:35.109325
# Unit test for method load of class Grammar
def test_Grammar_load():
    gr = Grammar()
    assert not gr.symbol2number

    gr.load("Grammar.pkl")
    assert gr.symbol2number

# Generated at 2022-06-11 19:35:45.299083
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'a': 1, 'b': 2}
    g.number2symbol = {1: 'a', 2: 'b'}
    g.states = [[(1, 2)], [(1, 3)]]
    g.dfas = {2: (g.states[0], {1: 1})}
    g.labels = [(0, 'EMPTY'), (1, 'test')]
    g.start = 10
    g.keywords = {'kw': 1}
    g.tokens = {1: 1}
    dumpfile = tempfile.mktemp()
    g.dump(dumpfile)
    g1 = Grammar()
    g1.load(dumpfile)
    os.remove(dumpfile)
    assert g1.symbol2

# Generated at 2022-06-11 19:35:47.506380
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .util import read_python_grammar

    g = Grammar()
    g.load(read_python_grammar())

# Generated at 2022-06-11 19:35:53.333060
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    (tmpfd, tmpname) = tempfile.mkstemp()
    try:
        os.close(tmpfd)
        g = Grammar()
        g.dump(tmpname)
        g2 = Grammar()
        g2.load(tmpname)
    finally:
        os.remove(tmpname)



# Generated at 2022-06-11 19:36:07.194953
# Unit test for method load of class Grammar

# Generated at 2022-06-11 19:36:11.749268
# Unit test for method load of class Grammar
def test_Grammar_load():
    # issue20668 - Ensure that a pickled file can be read and parsed
    # on any computer regardless of the endianness of the CPU

    # Create a pickle file on an EL big endian machine
    g = Grammar()
    g.dump('tmp')

    # Read the pickle file on an EL little endian machine
    g1 = Grammar()
    g1.load('tmp')
    os.remove('tmp')


# Generated at 2022-06-11 19:36:18.101075
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .conv import Converter
    from .pgen2 import tokenize

    conv = Converter("Grammar.test_Grammar")
    conv.convert([tokenize.generate_tok_py])
    tmp: Path = os.path.join(os.path.dirname(__file__), "tmp_Grammar")
    conv.grammar.dump(tmp)
    new = Grammar()
    new.load(tmp)
    # XXX We should check that new is equal to conv.grammar,
    # but that would require defining equality for these objects first.


if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-11 19:36:29.586714
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import unittest
    import warnings

    grammar = Grammar()
    grammar.number2symbol = {1: "test"}

    with unittest.mock.patch("tempfile.NamedTemporaryFile") as mock_tempfile:
        with unittest.mock.patch("os.replace") as mock_replace:
            mock_tempfile.return_value.__enter__.return_value.name = "test.pickle"

            grammar.dump("test.pickle")

            mock_replace.assert_called_with("test.pickle", "test.pickle")
            mock_tempfile.assert_called_with(dir="", delete=False)
            file_handle = mock_tempfile.return_value.__enter__.return_value
            file_handle.write.assert_called_

# Generated at 2022-06-11 19:36:35.700558
# Unit test for method load of class Grammar
def test_Grammar_load():
    """
    Unit test for method load of class Grammar.
    """
    g = Grammar()
    g.symbol2number["foo"] = 42
    g.dump("/tmp/foo.pkl")
    g2 = Grammar()
    g2.load("/tmp/foo.pkl")
    assert g2.symbol2number == {"foo": 42}
    os.unlink("/tmp/foo.pkl")


if __name__ == "__main__":
    import doctest

    doctest.testmod(
        optionflags=doctest.ELLIPSIS | doctest.NORMALIZE_WHITESPACE,
        verbose=True,
    )

# Generated at 2022-06-11 19:36:43.336540
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    test_grammar = Grammar()
    test_grammar.symbol2number = {'dot': 258, 't_option': 256, 't_value': 257}
    test_grammar.number2symbol = {256: 't_option', 257: 't_value', 258: 'dot'}

# Generated at 2022-06-11 19:36:50.365502
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Make sure that Grammar.load() doesn't crash if a Grammar is not properly initialized.
    # This can happen if a SyntaxError occurs early in Loading the grammar file.
    g = Grammar()
    g.load(__file__)

if __name__ == "__main__":
    import sys

    g = Grammar()
    g.load(sys.argv[1])
    g.report()

# Generated at 2022-06-11 19:37:00.292294
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pytest
    import pickle

    grammar = Grammar()
    grammar.dfas[0] = (
        [[(1, 1), (2, 2)]],
        {0: 1, 1: 2},  # value is DFA #
    )
    grammar.labels = [(0, "EMPTY"), (1, None), (2, "token_string")]

    with tempfile.NamedTemporaryFile() as f:
        grammar.dump(f.name)
        with open(f.name, "rb") as r:
            d = pickle.load(r)

    assert d == grammar.__getstate__()  # type: ignore


# Generated at 2022-06-11 19:37:09.711693
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import os
    import io
    import tempfile

    lib2to3_dir = os.path.dirname(os.path.dirname(__file__))
    Grammar_pickle_file = os.path.join(lib2to3_dir, "Grammar.pickle")
    Grammar_pickle_file_2 = os.path.join(lib2to3_dir, "Grammar_backup.pickle")
    Grammar_pickle_file_3 = os.path.join(os.getcwd(), "Grammar.pickle")

    def get_Grammar_pickle_bytes():
        old_stdout = sys.stdout
        sys.stdout = io.StringIO()

# Generated at 2022-06-11 19:37:14.113860
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen

    p = pgen.PgenParser()
    with tempfile.NamedTemporaryFile(mode="w") as file:
        file.write("Grammar()\n")
    p.parse(file.name)



# Generated at 2022-06-11 19:37:28.234780
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', '2': 'bar'}
    g.states = [
        [  # DFA 0
            [(1, 0), (2, 1)],  # State 0
            [(3, 0)],  # State 1
            [(4, 1)],  # State 2
        ]
    ]
    g.dfas = {
        '1': (0, {'2': 1}),
    }
    g.labels = [
        (0, None),
        (0, '+'),
        (0, '-'),
        (0, '*'),
        (0, '/'),
    ]
    g.start = 256

# Generated at 2022-06-11 19:37:39.691370
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2 import driver

    grammar = Grammar()
    grammar.start = 256
    for i in range(256):
        grammar.symbol2number[str(i)] = i
        grammar.number2symbol[i] = str(i)
    for i in range(7, 10):
        grammar.states.append([[(i, i)]])
    for i in range(7, 10):
        grammar.dfas[i] = (grammar.states[i - 7], {i: 1})
    for i in range(7, 10):
        grammar.labels.append((i, None))
    grammar.keywords = {
        "True": 7,
        "False": 8,
        "None": 9,
    }
    driver.save_grammar(grammar, "test.pkl")

# Generated at 2022-06-11 19:37:44.177597
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Test that the Grammar class is unpicklable when it is
    # not fully initialized, for a case where early release of
    # file handles is important.

    # This is not a comprehensive test of the dump method.
    # That would require a comprehensive test of the initialization process.
    from .pgen2 import driver

    g = driver.load_grammar("Python.asdl", "Python/graminit.c")
    g.dump("tmp.pkl")

# Generated at 2022-06-11 19:37:54.658353
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    grammar = Grammar()
    # Test for malformed input
    with pytest.raises(ValueError):
        grammar.load(b"\0" * 8)
    file_name = str(tmp_path / "test_Grammar_load.pickle")
    with open(file_name, "wb") as f:
        pickle.dump(grammar, f)
    grammar1 = Grammar()
    grammar1.load(file_name)
    assert grammar1.symbol2number == {}
    assert grammar1.number2symbol == {}
    assert grammar1.states == []
    assert grammar1.dfas == {}
    assert grammar1.labels == [(0, "EMPTY")]
    assert grammar1.keywords == {}
    assert grammar1.tokens == {}

# Generated at 2022-06-11 19:37:58.273480
# Unit test for method load of class Grammar
def test_Grammar_load():

    gr = Grammar()

    f = open("Grammar.pickle", "rb")
    gr.loads(f.read())
    f.close()

    f = open("Grammar.pickle", "rb")
    gr.load("Grammar.pickle")
    f.close()

# Generated at 2022-06-11 19:38:09.775928
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import random
    import tempfile

    class DummyGrammar(Grammar):
        def __init__(self) -> None:
            self.symbol2number = {}  # type: Dict[str, int]
            self.number2symbol = {}  # type: Dict[int, str]
            self.states = []  # type: List[DFA]
            self.dfas = {}  # type: Dict[int, DFAS]
            self.labels = []  # type: List[Label]
            self.keywords = {}  # type: Dict[str, int]
            self.tokens = {}  # type: Dict[int, int]
            self.symbol2label = {}  # type: Dict[str, int]
            self.start = random

# Generated at 2022-06-11 19:38:12.906111
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import pytest
    from . import generate_grammar
    s = generate_grammar.main([], ())
    assert () == s


# Generated at 2022-06-11 19:38:16.210579
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__[:-8] + 'Grammar.pickle')
    g.report()

# Generated at 2022-06-11 19:38:24.552417
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[(1, 2)], [(2, 3)]]
    g.dfas = {1: (1, {1: 1}), 2: (2, {2: 1})}
    g.labels = [(0, 'EMPTY'), (1, None), (2, None)]
    g.keywords = {'foo': 1, 'bar': 2}
    g.tokens = {1: 1, 2: 2}
    g.symbol2label = {'foo': 1, 'bar': 2}
    g.start = 256
    g.async_keywords = False

# Generated at 2022-06-11 19:38:27.865723
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2 import tokenize

    p = tokenize.generate_grammar()
    p.dump("Grammar.pickle")



# Generated at 2022-06-11 19:38:36.741010
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.symbols = {'key': 'value'}
    g.dump('grammar.pkl')
    g2 = Grammar()
    g2.load('grammar.pkl')
    assert g.symbols == g2.symbols, "The two grammars should be equal"

# Generated at 2022-06-11 19:38:38.933529
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")
    # Test that verification did not raise any AssertionError.

# Generated at 2022-06-11 19:38:48.773509
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    class G(Grammar):
        def __init__(self, symbol2number, number2symbol, start):
            super(G, self).__init__()
            self.symbol2number = symbol2number
            self.number2symbol = number2symbol
            self.start = start

    def _dump_load_check(g):
        g.dump("/tmp/a")
        g2 = G({}, {}, 0)
        g2.load("/tmp/a")
        g2.dump("/tmp/b")
        g3 = G({}, {}, 0)
        g3.load("/tmp/b")
        assert g == g2
        assert g == g3

    _dump_load_check(G({}, {}, 0))

# Generated at 2022-06-11 19:39:00.854285
# Unit test for method load of class Grammar
def test_Grammar_load():
    print("*** test_Grammar_load starting ***")
    g = Grammar()
    g.symbol2number = {"A": 1, "B": 2, "C": 3}
    if len(g.symbol2number) != 3:
        raise RuntimeError("g.symbol2number = {0}".format(g.symbol2number))
    if g.symbol2number["A"] != 1:
        raise RuntimeError("g.symbol2number[A] = {0}".format(g.symbol2number["A"]))
    if g.symbol2number["B"] != 2:
        raise RuntimeError("g.symbol2number[B] = {0}".format(g.symbol2number["B"]))
    print("*** test_Grammar_load succeeded ***")
# Unit test

# Generated at 2022-06-11 19:39:08.026615
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Pickling produces different output with Python version 3.8+
    if not (3 <= int(os.environ["PYTHON_VERSION_MINOR"]) <= 7):
        return
    g = Grammar()
    g.start = 256
    g.symbol2number = {"start": 256, "foo": 257, "bar": 258, "baz": 259}
    g.number2symbol = dict(
        (v, k) for k, v in g.symbol2number.items()
    )  # {256: 'start', 257: 'foo', 258: 'bar', 259: 'baz'}
    g.keywords = {"for": 1000, "if": 1001}
    g.tokens = {"def": 100, "class": 101}

# Generated at 2022-06-11 19:39:15.872144
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")
    assert g.symbol2number == {'async_comp_for': 261, 'test_nocond': 259}
    assert g.number2symbol == {256: 'file_input', 258: 'test_then', 259: 'test_nocond',
        260: 'test', 261: 'async_comp_for'}
    assert g.states == [[(257, 1), (4, 2), (5, 2)], [(0, 1)]]

# Generated at 2022-06-11 19:39:27.031859
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Test method load of class Grammar

    Checks if the grammar tables are correctly read from a pickle file. This is done by
    creating a small grammar, dumping it to a pickle file, reading it back and checking
    if all instance variables have their expected values.
    """
    from .conv import convert
    from .pgen2 import driver
    from . import pygram

    filename = "Grammar.test_Grammar_load.pickle"

    grammar = pygram.python_grammar_no_print_statement
    convert(grammar, "Grammar", "Grammar.test_Grammar_load")
    with open(filename, "wb") as f:
        f.write(driver.grammar.dump())

    grammar2 = pygram.python_grammar_no_print_statement

# Generated at 2022-06-11 19:39:38.618748
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    gr = Grammar()
    symname = 'TestSymbol'
    symnum = gr.symbol2number.get(symname, None)
    assert symnum is None, 'symname = %r already in symbol2number' % symname
    symnum = 256
    gr.symbol2number[symname] = symnum
    gr.number2symbol[symnum] = symname
    #
    dfas: Dict[int, int] = {}
    gr.dfas[symnum] = (gr.states, dfas)
    #
    dtok_name = 'TestToken'
    dtok = token.NT_OFFSET + 10
    gr.tokens[dtok] = dtok
    assert gr.tokens[dtok] == dtok
    #
    assert gr

# Generated at 2022-06-11 19:39:46.471907
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = 'test.pkl'
    g = Grammar()
    g.dump(filename)
    h = Grammar()
    h.load(filename)
    assert g.symbol2number == h.symbol2number
    assert g.number2symbol == h.number2symbol
    assert g.states == h.states
    assert g.dfas == h.dfas
    assert g.labels == h.labels
    assert g.keywords == h.keywords
    assert g.tokens == h.tokens
    assert g.symbol2label == h.symbol2label
    assert g.start == h.start
    assert g.async_keywords == h.async_keywords

# Generated at 2022-06-11 19:39:57.505185
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Pickle the grammar of JSON to a file
    from json import tool

    pkl = tempfile.mktemp(suffix=".pickle")
    tool.main(["-o", pkl, "-e"])

    # Load the grammar from the file
    g = Grammar()
    g.load(pkl)

    # Add a field to verify the update
    g.new_field = "new_field"

    # Now dump the grammar to another file
    dump = tempfile.mktemp(suffix=".pickle")
    g.dump(dump)

    # Load the grammar from the second file
    g = Grammar()
    g.load(dump)

    # Check the new field
    assert g.new_field == "new_field"

# Generated at 2022-06-11 19:40:06.414796
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = dict(a=256, b=257)
    g.number2symbol = dict(zip(g.symbol2number.values(), g.symbol2number))
    g.states = [
        [
            [(0, 1), (257, 2)],
            [(257, 1)],
            [(0, 2)],
            [],
        ]
    ]
    g.labels = [
        (0, None),
        (257, "name"),
    ]
    with tempfile.TemporaryDirectory() as d:
        g.dump(os.path.join(d, "test_Grammar_dump"))
        g2 = Grammar()
        g2.load(os.path.join(d, "test_Grammar_dump"))

   

# Generated at 2022-06-11 19:40:09.609568
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    with tempfile.NamedTemporaryFile(delete=False) as f:
        grammar.dump(f.name)
    os.unlink(f.name)


# Generated at 2022-06-11 19:40:19.679615
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'key': 1}
    g.number2symbol = {1: 'key'}
    g.states = [0, 1]
    g.dfas = {1: ([0, 1], {0: 0, 1: 1})}
    g.labels = [(0, 'empty')]
    g.keywords = {'key': 1}
    g.tokens = {1: 2}
    g.symbol2label = {'key': 3}
    g.start = 256
    g.dump('/tmp/test_grammar')
    new = Grammar()  # type: ignore
    new.load('/tmp/test_grammar')
    os.unlink('/tmp/test_grammar')
    assert repr(g) == repr

# Generated at 2022-06-11 19:40:25.243637
# Unit test for method load of class Grammar
def test_Grammar_load():
    class C(Grammar):
        pass

    c = C()

# Generated at 2022-06-11 19:40:32.508422
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import driver

    grammar = Grammar()

    # Capture stdout to check for verbose output
    import sys
    import io
    from contextlib import redirect_stdout

    out = io.StringIO()
    with redirect_stdout(out):
        driver.Driver(grammar, optimize=1, verbose=1, outputdir=None).run()

    grammar.dump("default.pgen")
    grammar = Grammar()
    grammar.load("default.pgen")
    out = io.StringIO()
    with redirect_stdout(out):
        grammar.report()
    print(out.getvalue())

# Generated at 2022-06-11 19:40:35.573436
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    fn = tempfile.mktemp()
    g.dump(fn)

# Generated at 2022-06-11 19:40:47.423734
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Create the grammar tables
    gr = Grammar()
    gr.start = gr.symbol2number["file_input"]
    gr.states.append(())
    gr.dfas[1] = (gr.states[0], {1: 1})
    gr.labels.append((1, None))
    gr.keywords["False"] = gr.labels[1]
    gr.tokens[1] = gr.labels[1]

    # Dump the grammar into a pickle file
    with tempfile.NamedTemporaryFile(delete=False) as f:
        gr.dump(f.name)

    # Read the pickle file and verify read data is the same as the original
    gr_cmp = Grammar()
    gr_cmp.load(f.name)
    os.remove(f.name)

# Generated at 2022-06-11 19:40:58.861053
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import tempfile
    import os
    import pickle
    import re

    class FakeGrammar(Grammar):
        """Fake grammar for testing Grammar.dump."""

        def __init__(self):
            Grammar.__init__(self)
            self.grammar_name = "FakeGrammar"
            self.start = 1
            self.symbol2number = {"'string'": 2}
            self.number2symbol = {2: "'string'"}

    grammar = FakeGrammar()

# Generated at 2022-06-11 19:41:09.130194
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .conv import convert

    gram = Grammar()
    convert(gram, "Grammar.txt")
    gram.dump("Grammar.pickle")

    class TestGrammar(Grammar):
        pass

    gram2 = TestGrammar()
    gram2.load("Grammar.pickle")

    assert gram.start == gram2.start
    assert gram.symbol2number == gram2.symbol2number
    assert gram.number2symbol == gram2.number2symbol
    assert gram.keywords == gram2.keywords
    assert gram.tokens == gram2.tokens
    assert gram.symbol2label == gram2.symbol2label
    assert gram.dfas == gram2.dfas
    assert len(gram.states) == len(gram2.states)


# Generated at 2022-06-11 19:41:11.805626
# Unit test for method load of class Grammar
def test_Grammar_load():
    assert Grammar.load('Grammar').states[0][0] == (0, 1)

# Generated at 2022-06-11 19:41:24.430082
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import io

    class LoadTest(unittest.TestCase):
        def test_loads(self):
            gr = Grammar()
            test_data = {"key": "value"}
            gr.loads(pickle.dumps(test_data))
            self.assertEqual(gr._update(test_data), None)

    unittest.main()


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-11 19:41:32.109248
# Unit test for method load of class Grammar
def test_Grammar_load():
    import tempfile
    import pickle
    data = {"key1": "value1"}
    grammar = Grammar()
    # test load()
    with tempfile.NamedTemporaryFile(mode="wb", delete=False) as f:
        pickle.dump(data, f)
        f.flush()
        filename = f.name
    grammar.load(filename)
    assert grammar.key1 == "value1"
    # test loads()
    with tempfile.NamedTemporaryFile(mode="wb", delete=False) as f:
        pickle.dump(data, f)
        f.flush()
        filename = f.name
    with open(filename, "rb") as f:
        data = f.read()
    grammar = Grammar()
    grammar.loads(data)

# Generated at 2022-06-11 19:41:38.249495
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pgen2
    import copy
    import pickle

    # Create Grammar object
    grammar = pgen2.pgen.yacc.load_grammar(None)

    # Make sure it can be pickled
    pkl = pickle.dumps(grammar)
    grammar2: Grammar = pickle.loads(pkl)

    # Make sure it is recursively copied
    grammar3 = copy.deepcopy(grammar)

    # Make sure the copy matches the original
    assert grammar == grammar2 == grammar3



# Generated at 2022-06-11 19:41:45.842624
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.number2symbol = {
        256: "foo",
        257: "bar",
    }

    with tempfile.TemporaryDirectory() as dirname:
        path = os.path.join(dirname, "example.pickle")
        g.dump(path)

        with open(path, "rb") as f:
            data = f.read()
        g = Grammar()
        g.loads(data)
        assert g.number2symbol == {256: "foo", 257: "bar"}

# Generated at 2022-06-11 19:41:52.586497
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """
    Test the Grammar.dump method.

    This test checks that grammar files can be written to disk and then read
    back as expected.
    """
    import sys
    import tester

    # try dumping a grammar file written by the parser generator

# Generated at 2022-06-11 19:42:02.199252
# Unit test for method load of class Grammar
def test_Grammar_load():
    m = Grammar()
    assert m.number2symbol == {}
    assert m.symbol2number == {}
    assert m.states == []
    assert m.dfas == {}
    assert m.labels == [(0, "EMPTY")]
    assert m.keywords == {}
    assert m.tokens == {}
    assert m.symbol2label == {}
    assert m.start == 256

    m.load("bad_file")
    assert m.number2symbol == {}
    assert m.symbol2number == {}
    assert m.states == []
    assert m.dfas == {}
    assert m.labels == [(0, "EMPTY")]
    assert m.keywords == {}
    assert m.tokens == {}
    assert m.symbol2label == {}

# Generated at 2022-06-11 19:42:09.890654
# Unit test for method load of class Grammar
def test_Grammar_load():
    parser_mod = Grammar()
    assert parser_mod.symbol2number == {}
    assert parser_mod.number2symbol == {}
    assert parser_mod.states == []
    assert parser_mod.dfas == {}
    assert parser_mod.labels == [(0, "EMPTY")]
    assert parser_mod.keywords == {}
    assert parser_mod.tokens == {}
    assert parser_mod.symbol2label == {}
    assert parser_mod.start == 256
    assert parser_mod.async_keywords == False

# Generated at 2022-06-11 19:42:16.440701
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Save the grammar to a temporary file
    import os.path
    from . import pgen2
    from .parse import ParseError
    from .driver import Driver
    from .pgen2 import write_grammar
    from .pgen2 import driver as pgen2_driver

    try:
        driver = Driver(pgen_driver=pgen2_driver, grammar=pgen2)
    except ParseError as err:
        print(err.__class__.__name__ + ":", err)
        driver = Driver(pgen_driver=pgen2_driver)

    tmpdir = tempfile.gettempdir()

    def _delete(filename: str) -> None:
        try:
            os.remove(os.path.join(tmpdir, filename))
        except OSError:
            pass


# Generated at 2022-06-11 19:42:27.222795
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import conv
    from . import tokenize
    from . import pgen2

    # Build a grammar from scratch
    g = conv.Converter()
    g.build(os.path.join(os.path.dirname(__file__), "Grammar.txt"), "Grammar")

    # Load it
    h = Grammar()
    h.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))

    # Load it again using pgen2 and compare
    g2 = pgen2.pgen(os.path.join(os.path.dirname(__file__), "Grammar.txt"))
    h2 = Grammar()

# Generated at 2022-06-11 19:42:34.949427
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .conv import convert_grammar

    g = Grammar()
    convert_grammar(g, "Grammar/Grammar")
    assert len(g.states) > 0
    fn = tempfile.mktemp()
    g.dump(fn)
    g2 = Grammar()
    g2.load(fn)
    assert len(g2.states) == len(g.states)
    assert g2.states == g.states
    os.unlink(fn)



# Generated at 2022-06-11 19:42:51.453524
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.number2symbol = {1: 'a', 2: 'b', 3: 'c'}
    g.symbol2number = {'a': 1, 'b': 2, 'c': 3}
    g.dfas = {1: ([1], {1: 1}), 2: ([2], {1: 1}), 3: ([3], {1: 1})}
    g.states = [[(1, 1)], [(1, 2)], [(1, 3)]]
    g.labels = [(0, "EMPTY")]
    g.keywords = {}
    g.tokens = {}
    g.symbol2label = {}
    g.start = 4

# Generated at 2022-06-11 19:42:54.896359
# Unit test for method load of class Grammar
def test_Grammar_load():
    class CGrammar(Grammar):
        def load(self, path):
            pass

    g = CGrammar()
    g.load("")


# Generated at 2022-06-11 19:43:03.437887
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    from pathlib import PurePath
    from .pgen2 import driver
    from .pgen2 import tokenize as _tokenize

    # Test the load method of the class Grammar, which loads the pickle file into
    # the grammar.

    # pylint: disable=redefined-outer-name
    def tokenize(source: str) -> List[str]:
        """
        Given the source code for a Python module, return a list containing the tokens.
        """

        tokens = []
        tokengen = _tokenize.generate_tokens(source.__iter__().__next__)
        for num, value, _, _, _ in tokengen:
            if num == token.NAME and value in ("False", "None", "True"):
                num = token.CONST

# Generated at 2022-06-11 19:43:05.834805
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/tmp/test.pickle")


# Generated at 2022-06-11 19:43:13.401844
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    def dump_same(self, filename, orig_filename):
        self.dump(filename)
        other = self.__class__()
        other.load(filename)
        assert other.__dict__ == self.__dict__
        os.unlink(filename)

    from . import conv, pgen

    for klass, filename in [(conv.Converter, "Grammar.txt"), (pgen.ParserGenerator, "Grammar.txt")]:
        g = klass(filename)
        dump_same(g, "temp.pkl", filename)

# Generated at 2022-06-11 19:43:24.676622
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys, io

    f = io.StringIO()

# Generated at 2022-06-11 19:43:26.360402
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("Grammar.pickle")
    grammar.report()

# Generated at 2022-06-11 19:43:37.395047
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    from . import pgen2
    from .parse import pgen

    parser = pgen.ParserGenerator()
    parser.parse(os.path.join(pgen2.__file__, "Grammar.txt"))
    parser.grammar.dump("Grammar.pickle")
    parser2 = pgen.ParserGenerator()
    parser2.load("Grammar.pickle")
    parser2.dfas.clear()
    parser2.dump("Grammar2.pickle")
    with open("Grammar.pickle", "rb") as f:
        s = f.read()
    with open("Grammar2.pickle", "rb") as f:
        s2 = f.read()
    assert s == s2, "files do not match"

# Generated at 2022-06-11 19:43:45.192937
# Unit test for method load of class Grammar
def test_Grammar_load():
    for method_name in ["load", "loads"]:
        g = Grammar()
        getattr(g, method_name)("./pickle/grammar.pkl")

        # Check that tables have been loaded
        assert g.symbol2number
        assert g.number2symbol
        assert g.states
        assert g.dfas
        assert g.labels
        assert g.keywords
        assert g.tokens
        assert g.symbol2label
        assert g.start == 256
        assert not g.async_keywords

# Generated at 2022-06-11 19:43:51.384197
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2 import driver
    from test.test_grammar import GrammarTestCase

    filename = os.path.join(
        GrammarTestCase.directory,
        'Lib', 'test', 'badsyntax_future3.py',
    )

    def check_grammar(g: Grammar) -> None:
        # Convert g to a Grammar object.
        g.labels = [
            (_f[0], _f[1])
            if len(_f) == 2
            else (_f[0], None)
            for _f in g.labels
        ]
        g.dfas = dict((k, (v[0], {})) for k, v in g.dfas.items())

        assert isinstance(g.start, int)

        # Write the grammar to a pickle file.
        fd

# Generated at 2022-06-11 19:44:11.154063
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("Lib/pytree/pgen2/Grammar.txt")
    assert grammar != None

# Generated at 2022-06-11 19:44:21.797715
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .tokenizer import generate_tokens, TokenInfo, TokenType

    # Test with a simple grammar
    test_grammar = Grammar()
    test_grammar.number2symbol[256] = "expr"
    test_grammar.symbol2number["expr"] = 256
    test_grammar.start = 256
    test_grammar.tokens[1] = (1, None)
    test_grammar.tokens[2] = (2, None)
    test_grammar.tokens[3] = (3, None)
    test_grammar.tokens[4] = (4, None)
    test_grammar.tokens[5] = (5, None)
    test_grammar.keywords["None"] = 5

# Generated at 2022-06-11 19:44:24.993441
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("some_file")

# Generated at 2022-06-11 19:44:29.728328
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = "grammar.pkl"

# Generated at 2022-06-11 19:44:38.077963
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """Check that dump() and load() are inverses."""
    import shutil
    import tempfile

    g = Grammar()

    g.symbol2number = {"A": 1, "B": 2}  # type: ignore
    g.number2symbol = {1: "A", 2: "B"}  # type: ignore
    g.states = [[[(1, 2), (3, 5)], [(0, 2)]]]
    g.dfas = {1: (0, {1: 1}), 2: (1, {2: 1})}  # type: ignore
    g.labels = [(1, "a"), (1, None), (2, "b"), (2, None)]
    g.start = 1  # type: ignore