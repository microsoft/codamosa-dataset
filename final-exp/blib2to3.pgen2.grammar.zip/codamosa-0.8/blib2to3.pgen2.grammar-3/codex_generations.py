

# Generated at 2022-06-11 19:34:42.338871
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    sel = Grammar()
    filename = "test"
    sel.dump(filename)
    sel2 = Grammar()
    sel2.load(filename)
    assert sel == sel2

    sel.symbol2number = sel2.symbol2number.copy()
    sel.number2symbol = sel2.number2symbol.copy()
    sel.dfas = sel2.dfas.copy()
    sel.keywords = sel2.keywords.copy()
    sel.tokens = sel2.tokens.copy()
    sel.symbol2label = sel2.symbol2label.copy()
    sel.labels = sel2.labels
    sel.states = sel2.states
    sel.start

# Generated at 2022-06-11 19:34:55.974709
# Unit test for method load of class Grammar
def test_Grammar_load():
    """test_Grammar_load()"""
    # unknown symbol used for testing
    unknown_symbol = "unknown_symbol"
    # create a test grammar instance
    g = Grammar()
    # add an unknown symbol to instance as a string
    g.states.append(unknown_symbol)
    # dump test grammar instance to file
    with tempfile.TemporaryFile(mode="wb") as f:
        g.dump(f)
        f.seek(0)
        # recreate test grammar instance
        g2 = Grammar()
        # load pickled grammar tables Instance
        g2.load(f)
        # check that contents of test grammar instance was re-loaded correctly
        assert g.symbol2number == g2.symbol2number
        assert g.number2symbol == g2.number2symbol
       

# Generated at 2022-06-11 19:35:08.291422
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    from pickle import HIGHEST_PROTOCOL as H
    from ast import parse

    f = tempfile.NamedTemporaryFile(suffix=".pickle")
    f.close()
    try:
        # Test pickle protocol 0 (ascii)
        pickle.dump(parse("pass"), f.name, 0)
        with open(f.name, "rb") as f:
            p0 = f.read()
        # Test pickle protocol 1 (binary)
        pickle.dump(parse("pass"), f.name, 1)
        with open(f.name, "rb") as f:
            p1 = f.read()
    finally:
        os.remove(f.name)
    # Ensure that the dumped file has different contents than the
    # original file. Otherwise, the test isn

# Generated at 2022-06-11 19:35:11.894252
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import driver

    # If we can't find the pickle file, just skip this test
    try:
        driver.load_grammar("Grammar.pickle")
    except (IOError, OSError):
        pass



# Generated at 2022-06-11 19:35:14.030130
# Unit test for method load of class Grammar
def test_Grammar_load():
    Grammar().load('cpython/Grammar')


# Generated at 2022-06-11 19:35:23.822221
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # NOTE: The actual dumps are tested in lib2to3/pgen2/conv.py.
    import io
    import pickle
    from textwrap import dedent

    s = dedent("""\
            number2symbol = {1: 'foo', 2: 'bar'}
            symbol2number = {'foo': 1, 'bar': 2}
            start = 1
        """)

    f = io.BytesIO()
    exec(s, globals(), locals())
    pickle.dump(locals(), f, pickle.HIGHEST_PROTOCOL)
    f.seek(0)
    d = pickle.load(f)
    g = Grammar()
    g.load(io.BytesIO(pickle.dumps(d, pickle.HIGHEST_PROTOCOL)))

    assert g

# Generated at 2022-06-11 19:35:26.235618
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    gram = Grammar()
    gram.dump("testing.pkl")

# Generated at 2022-06-11 19:35:33.791688
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number["symb"] = 257
    g.number2symbol[257] = "symb"
    g.states = [[[(259, 1), (260, 2)], [(257, 1), (0, 2)]]]
    g.dfas[257] = (g.states[0], {258: 1})

# Generated at 2022-06-11 19:35:44.088908
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import os
    import re
    import unittest

    import pgen2.grammar
    import pgen2.pgen

    class PgenGrammarTest(unittest.TestCase):
        """Test cases for pgen2.grammar.Grammar.dump()."""

        def setUp(self):
            self.g = pgen2.grammar.Grammar()
            self.g.symbol2number = {None: 0, "EMPTY": 1, "first": 2, "second": 3}
            self.g.number2symbol = {0: None, 1: "EMPTY", 2: "first", 3: "second"}
            self.g.keywords = {None: 0, "EMPTY": 1, "first": 2, "second": 3}
            self.g.t

# Generated at 2022-06-11 19:35:55.525192
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()

# Generated at 2022-06-11 19:36:09.454934
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import sys
    import tempfile

    class A:
        def __init__(self, name: Text) -> None:
            self.name = name

        def __getstate__(self) -> Dict[str, Text]:
            return {"name": self.name}

        def __setstate__(self, attrs: Dict[str, Text]) -> None:
            self.name = attrs["name"]

    g = Grammar()
    g.a = A("test")
    with tempfile.NamedTemporaryFile(delete=False) as f:
        g.dump(f.name)
    with open(f.name, "rb") as f:
        data = pickle.load(f)
    os.unlink(f.name)

# Generated at 2022-06-11 19:36:19.375448
# Unit test for method load of class Grammar
def test_Grammar_load():
    import py._path.local
    import pickle
    import pgen.pgen
    import tempfile

    # Make a pickle file containing a pickled Grammar object.
    gram_pkl_path = py._path.local.LocalPath(tempfile.mkdtemp()) / "Grammar.pickle"
    gram = pgen.pgen.Grammar()
    gram.parse_grammar(py._path.local.LocalPath(grammar_path))
    gram.save(str(gram_pkl_path))

    # Load the pickle file into a Grammar object.
    x = Grammar()
    x.load(str(gram_pkl_path))

    # Verify that the Grammar object has expected attributes.
    assert isinstance(x.number2symbol, dict)

# Generated at 2022-06-11 19:36:25.335561
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("testdata/before_dump.txt")
    g.loads(open("testdata/after_dump.txt", "rb").read())
    g.dump("testdata/after_dump.txt")
    a = open("testdata/after_dump.txt", "rb").read()
    b = open("testdata/after_dump.txt", "rb").read()
    assert a == b

# Generated at 2022-06-11 19:36:36.080663
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """Unit test for Grammar.dump()."""

    # The following is based on code from Grammar.report()
    g = Grammar()
    g.dump("Grammar.dump.test")
    with open("Grammar.dump.test", "rb") as f:
        d = pickle.load(f)
    for dict_attr in (
        "symbol2number",
        "number2symbol",
        "dfas",
        "keywords",
        "tokens",
        "symbol2label",
    ):
        if not isinstance(d[dict_attr], dict):
            raise ValueError(f"{dict_attr} is not a dict")
    if not isinstance(d["labels"], list):
        raise ValueError("labels is not a list")

# Generated at 2022-06-11 19:36:45.835674
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import types

    # Check that dump returns the correct type
    gr = Grammar()
    gr.dump("test.pkl")
    assert type(gr.dump("test.pkl")) is NoneType

    # Check that an empty Grammar has no attributes and therefore
    # dump returns None
    gr2 = Grammar()
    assert type(gr.dump("test.pkl")) is NoneType

    # Check that load loads the correct data
    gr = Grammar()
    gr.states = [1, 2, 3]
    gr.dump("test.pkl")
    gr2 = Grammar()
    gr2.load("test.pkl")
    assert gr2.states == [1, 2, 3]

    # Check that loads loads the correct data
    gr = Grammar()

# Generated at 2022-06-11 19:36:55.445936
# Unit test for method load of class Grammar
def test_Grammar_load():
    class TestGrammar(Grammar):
        def __init__(self):
            super(TestGrammar, self).__init__()
            self.symbol2number = {
                "a": 257,
                "b": 258,
                "c": 259,
                "d": 260,
                "e": 261,
                "f": 262,
            }
            self.number2symbol = {
                v: k for k, v in self.symbol2number.items()
            }

# Generated at 2022-06-11 19:37:06.701436
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    assert g.start == 256
    assert g.tokens == {}
    assert g.symbol2number == {}
    assert g.keywords == {}
    assert g.symbol2label == {}
    assert g.number2symbol == {}
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.states == []
    assert g.async_keywords == False

    # mypyc generates objects that don't have a __dict__, but they
    # do have __getstate__ methods that will return an equivalent
    # dictionary
    if hasattr(g, "__dict__"):
        assert g.__dict__ == g.__getstate__()  # type: ignore

    g1 = g.copy()

# Generated at 2022-06-11 19:37:11.917275
# Unit test for method load of class Grammar
def test_Grammar_load():
    # import Parser

    Grammar.load(Grammar, "grammar.pkl")
    if __name__ == "__main__":
        Grammar.report(Grammar)


test_Grammar_load()

# Generated at 2022-06-11 19:37:20.227877
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    def _test():
        #
        # Test with a file in a temporary directory
        #
        filename = tempfile.mktemp()
        # Check the file is not there
        assert not os.path.exists(filename)
        # Create an instance
        g = Grammar()
        # Smoke test the method
        g.dump(filename)
        # Check the file is there
        assert os.path.exists(filename)
        # Remove the file
        os.remove(filename)
        #
        # Test with a file in a non existent directory
        #
        filename = tempfile.mktemp()
        # Check the file is not there
        assert not os.path.exists(filename)
        # Create an instance
        g = Grammar()
        # Smoke test the method
        g.dump(filename)
        # Check

# Generated at 2022-06-11 19:37:24.733523
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    tmpfile = tempfile.NamedTemporaryFile()
    tmpfile_name = tmpfile.name
    g.dump(tmpfile_name)
    tmpfile.close()
    return tmpfile_name

# Generated at 2022-06-11 19:37:39.068831
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    filename = os.path.join(os.path.dirname(__file__), "Grammar.pkl")
    with open(filename, "rb") as f:
        g = pickle.load(f)  # type: ignore
    assert g.symbol2number is not None
    assert g.number2symbol is not None
    assert g.states is not None
    assert g.dfas is not None
    assert g.labels is not None
    assert g.keywords is not None
    assert g.tokens is not None
    assert g.symbol2label is not None
    assert g.start is not None
    assert g.async_keywords is not None
    with open(filename, "rb") as f:
        g = Grammar()
        g.load(f)


# Generated at 2022-06-11 19:37:46.346078
# Unit test for method load of class Grammar
def test_Grammar_load():
    import io
    import pickle
    import unittest


# Generated at 2022-06-11 19:37:52.157691
# Unit test for method load of class Grammar
def test_Grammar_load():
    # pylint: disable=E0602
    import sys

    sys.modules["conv"] = sys.modules["tokenize"]
    try:
        from .conv import convert_grammar

        convert_grammar(
            "./Grammar.txt",
            "./python.asdl",
            "./python.pgen.py",
            start_symbol="file_input",
            target_version=3,
        )
    finally:
        del sys.modules["conv"]

    with open("./python.pgen", "rb") as f:
        g = pickle.load(f)

    assert g.number2symbol[parser.nt_off] == "file_input"

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-11 19:37:55.233891
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = "test.pickle"
    grammar = Grammar()

    # first method - dump
    # no error, so pass the test
    grammar.dump(filename)
    os.remove(filename)



# Generated at 2022-06-11 19:38:02.159132
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test for NotImplemented.
    test_grammar = Grammar()
    with open("test_grammar_load.pkl", "wb") as pkl:
        pickle.dump(test_grammar.__getstate__(), pkl)

    with open("test_grammar_load.pkl", "rb") as pkl:
        d = pickle.load(pkl)
    test_grammar.__setstate__(d)

    assert test_grammar.symbol2number == {}
    assert test_grammar.number2symbol == {}
    assert test_grammar.states == []
    assert test_grammar.dfas == {}
    assert test_grammar.labels == [(0, "EMPTY")]
    assert test_grammar.keywords == {}

# Generated at 2022-06-11 19:38:12.586356
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # test_missing_file
    parser = Grammar()

    try:
        parser.dump("/path/to/missing/file/for_test")
        assert False  # pragma: no cover
    except FileNotFoundError:  # missing directory
        pass

    # test_dump_load
    parser = Grammar()
    parser.symbol2number = {
        "foo": 1,
        "bar": 2,
        "baz": 3,
    }

    with tempfile.NamedTemporaryFile(delete=False) as f:
        parser.dump(f.name)
    parser.load(f.name)
    assert parser.symbol2number == {
        "foo": 1,
        "bar": 2,
        "baz": 3,
    }
    os.remove(f.name)

# Generated at 2022-06-11 19:38:22.471285
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest.mock
    import pickle
    import io
    # The function to be tested
    def f():
        g = Grammar()

        g.symbol2number = {1: 2}
        g.number2symbol = {2: 3}
        g.states        = [4]
        g.dfas          = {5: (6, 7)}
        g.labels        = [8, 9]
        g.keywords      = {10: 11}
        g.tokens        = {12: 13}
        g.symbol2label  = {14: 15}
        g.start         = 16
        # Python 3.7+ parses async as a keyword, not an identifier
        g.async_keywords = 17

        fh = io.BytesIO()


# Generated at 2022-06-11 19:38:26.028700
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Test a case where symbol2number has no unicode symbols
    grammar = Grammar()
    grammar.dump('dump_test')
    # Test a case where symbol2number has unicode symbols, but no bytes
    grammar = Grammar()
    grammar.symbol2number = {"fran\u00e7ais": 12,
                             "unicode": 8}
    grammar.dump('dump_test')

# Generated at 2022-06-11 19:38:31.370774
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from unittest import mock
    from .pgen2.pgen import generate_grammar
    import sys

    sys.argv = ["pgen2", "-q", "parse.py", "gen_grammar.py"]

    with mock.patch("sys.stdout", new_callable=lambda: sys.stdout):
        generate_grammar.main()

if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-11 19:38:37.391155
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pytest
    gr = Grammar()
    temp = tempfile.NamedTemporaryFile(delete=False)
    gr.dump(temp.name)
    temp.close()
    gr.load(temp.name)
    os.remove(temp.name)
    pytest.skip("unimplemented")

# Generated at 2022-06-11 19:38:41.684723
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    def f():
        raise ValueError

    assert Grammar().dump(f) is None

# Generated at 2022-06-11 19:38:43.316876
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # type: () -> None
    testgrammardump()



# Generated at 2022-06-11 19:38:46.292623
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = "grammar.pkl"
    g = Grammar()
    g.dump(filename)
    assert os.path.exists(filename)
    os.unlink(filename)


# Generated at 2022-06-11 19:38:57.953520
# Unit test for method load of class Grammar

# Generated at 2022-06-11 19:39:06.934984
# Unit test for method load of class Grammar
def test_Grammar_load():
    import py
    import sys

    def _prepare_input_file():
        with open("hello.grammar", "w") as outfile:
            outfile.write("hello")
        return py.path.local("hello.grammar")

    def _cleanup(path):
        import os

        os.remove(path)


# Generated at 2022-06-11 19:39:15.368916
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()

# Generated at 2022-06-11 19:39:20.565696
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pytest
    import pickle

    class A(object):
        pass

    a = A()
    a.key = "value"
    g = Grammar()
    x = pickle.dumps(a)
    g.loads(x)
    assert g.key == 'value'

# Generated at 2022-06-11 19:39:29.539702
# Unit test for method load of class Grammar
def test_Grammar_load():
    import tempfile
    import os
    import pickle
    import pytest

    g = Grammar()
    # Write a pickle file
    with tempfile.NamedTemporaryFile(delete=False) as f1:
        pickle.dump(g.__dict__, f1, pickle.HIGHEST_PROTOCOL)
    # Read a pickle file
    g2 = Grammar()
    g2.load(f1.name)
    # Compare the result
    assert g.__dict__ == g2.__dict__
    os.unlink(f1.name)

    g3 = Grammar()
    with pytest.raises(FileNotFoundError):
        g3.load("foo")  # File not found

# Generated at 2022-06-11 19:39:34.434496
# Unit test for method load of class Grammar
def test_Grammar_load():
    def test_load(path):
        with open(path, 'rb') as f:
            data = f.read()

        grammar = Grammar()
        grammar.loads(data)

# Generated at 2022-06-11 19:39:45.119711
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import sys
    import time
    from importlib import import_module
    from pkg_resources import resource_filename
    from .conv import gen_py
    from .pgen2 import driver, write_grammar

    temp_dir = resource_filename("pgen2", "Grammar")
    py_file = os.path.join(temp_dir, "Grammar.py")
    gen_py(py_file)
    module = import_module("pgen2.Grammar")
    module.Grammar.parse(sys.argv[0])
    driver.write_tables(module)
    assert os.path.exists(module.PICKLE)
    write_grammar(module.PICKLE)
    assert os.path.exists(module.PICKLE + ".pickle")

# Generated at 2022-06-11 19:39:58.455812
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()

    # Load should fail on a file that does not exist
    filename = "/this/file/will/not/exist"
    assert not os.path.exists(filename)
    try:
        g.load(filename)
    except FileNotFoundError:
        pass
    else:
        assert 1 == 0

    # Load should fail on an empty file
    with tempfile.NamedTemporaryFile(mode='w+b', delete=False) as f:
        pass
    try:
        g.load(f.name)
    except EOFError:
        pass
    else:
        assert 1 == 0
    os.remove(f.name)

    # Load should fail on a file that isn't a pickle

# Generated at 2022-06-11 19:40:00.582570
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pickle"))
    assert g

# Generated at 2022-06-11 19:40:04.633391
# Unit test for method load of class Grammar
def test_Grammar_load():
    gr = Grammar()
    gr.load('/home/fernando/code/nix-python-3.7.3/Lib/lib2to3/Grammar.txt')


# Generated at 2022-06-11 19:40:13.178842
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pgen2.pgen
    import pgen2.driver
    import pgen2.grammar
    import pgen2.parse

    # Test Grammar.load()
    # Create a grammar using the pgen2. This will create the file
    # Python37/Grammar, which we'll load
    g = pgen2.pgen.generate_grammar("Python37")

    # Load the grammar
    g2 = Grammar()
    g2.load("Python37/Grammar")

    # Create a driver using the original grammar.
    d = pgen2.driver.Driver(g, convert=pgen2.parse.convert)

    # Create a driver using the loaded grammar (g2).
    d2 = pgen2.driver.Driver(g2, convert=pgen2.parse.convert)



# Generated at 2022-06-11 19:40:23.932904
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import pickle
    from typing import Dict
    from . import pgen

    class Grammar(pgen.Grammar):
        def __init__(self) -> None:
            super().__init__()
            self.symbol2number: Dict[str, int] = {}
            self.number2symbol: Dict[int, str] = {}
            self.states: List[DFA] = []
            self.dfas: Dict[int, DFAS] = {}
            self.labels: List[Label] = [(0, "EMPTY")]
            self.keywords: Dict[str, int] = {}
            self.tokens: Dict[int, int] = {}
            self.start = 256

    gram = Grammar()
    tbuf = io.BytesIO()


# Generated at 2022-06-11 19:40:27.477225
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.txt"))
    g.report()


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-11 19:40:32.004092
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    tempfile = os.path.join(os.path.dirname(__file__), "test_grammar.pkl")
    g = Grammar()
    g.dump(tempfile)
    g2 = Grammar()
    g2.loads(open(tempfile, "rb").read())
    # Internal dicts are dumped as pickle dict, not dictproxy.
    assert g.__dict__ == g2.__dict__

# Generated at 2022-06-11 19:40:45.442814
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    filename = "Grammar.pickle"
    def cleanup():
        try: os.remove(filename)
        except FileNotFoundError: pass
    import atexit; atexit.register(cleanup)
    t = (1, None)
    g.symbol2number = {}
    g.number2symbol = {}
    g.states = [[[t, [t, [t]]]]]
    g.dfas = {1: ([[t, [t, [t]]]], {}), 2: ([[t, [t, [t]]]], {})}
    g.labels = [t, (1, None)]
    g.start = 256
    g.keywords = {}
    g.tokens = {}
    g.symbol2label = {}

# Generated at 2022-06-11 19:40:52.386658
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Disable warning lost-function-docstring because save grammar.py
    # docstrings.
    # pylint: disable=missing-function-docstring
    import random

    def check(g1: Grammar, g2: Grammar) -> None:
        attrs1 = g1.__dict__
        attrs2 = g2.__dict__
        assert attrs1.keys() == attrs2.keys()
        for k in attrs1.keys():
            v1 = attrs1[k]
            v2 = attrs2[k]
            if isinstance(v1, dict):
                assert v1.keys() == v2.keys()
                for kk in v1.keys():
                    assert v1[kk] == v2[kk]
            elif isinstance(v1, list):
                assert len

# Generated at 2022-06-11 19:40:58.596286
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_path = os.path.join(os.path.dirname(__file__), '..', 'Grammar.pkl')
    assert os.path.exists(grammar_path)
    g = Grammar()
    g.load(grammar_path)
    assert g.symbol2number
    assert g.number2symbol
    assert g.states
    assert g.dfas
    assert g.labels
    assert g.start == 256


# Generated at 2022-06-11 19:41:09.950302
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    assert grammar
    tempdir = tempfile.mkdtemp()
    filename = os.path.join(tempdir, "Grammar_dump.p")
    grammar.dump(filename)
    oldgrammar = Grammar()
    oldgrammar.load(filename)
    assert grammar.symbol2number == oldgrammar.symbol2number
    assert grammar.number2symbol == oldgrammar.number2symbol
    assert grammar.states == oldgrammar.states
    assert grammar.dfas == oldgrammar.dfas
    assert grammar.labels == oldgrammar.labels
    assert grammar.keywords == oldgrammar.keywords
    assert grammar.tokens == oldgrammar.tokens
    assert grammar.symbol2label == oldgrammar.symbol2label
    assert grammar

# Generated at 2022-06-11 19:41:12.712826
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump('/tmp/test_Grammar_dump')



# Generated at 2022-06-11 19:41:19.993409
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump('grammar.dump')
    filename = 'grammar.dump'
    with open(filename, 'rb') as f:
        data = f.read()
    os.unlink(filename)

# Generated at 2022-06-11 19:41:22.859672
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Grammar.load(a)
    # -- Calls Grammar.loads(bytes(a, 'utf-8'))
    pass

# Generated at 2022-06-11 19:41:24.554260
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump('test-dump.txt')
    os.remove('test-dump.txt')

# Generated at 2022-06-11 19:41:32.155297
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.dfas = {
        256: ([[(0, 1), (257, 2)]], {1: 1}),
        257: ([[(0, 3), (258, 4)]], {2: 1}),
    }
    g.keywords = {"foo": 258}
    g.labels = [
        (0, "EMPTY"),
        (0, None),
        (257, None),
        (256, "test"),
        (258, None),
    ]
    g.start = 256
    g.states = [[[(0, 0)]], [[(1, 1), (2, 2)]]]
    g.symbol2label = {
        "test": 3,
    }
    g.symbol2number = {
        "test": 256
    }
   

# Generated at 2022-06-11 19:41:36.443098
# Unit test for method load of class Grammar
def test_Grammar_load():
    import io
    import pickle
    from . import grammar, conv

    buf = io.BytesIO()

    gr = conv.LRParserGenerator([], {}, {})
    pickle.dump(gr.grammar, buf)

    buf.seek(0)
    g1 = grammar.Grammar()
    g1.load_grammar(buf)

    buf.seek(0)
    g2 = grammar.Grammar()
    g2.loads(buf.read())

    if g1.symbol2number != g2.symbol2number:
        raise ValueError("symbol2number")
    if g1.number2symbol != g2.number2symbol:
        raise ValueError("number2symbol")
    if g1.states != g2.states:
        raise ValueError("states")


# Generated at 2022-06-11 19:41:47.841993
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Create and initialize a Grammar instance
    g = Grammar()
    g.symbol2number["a"] = 1
    g.number2symbol[1] = "a"
    g.states = [[(1, 1)]]
    g.dfas = {1: ([[(1, 1), (0, 1)]], {"a": 1})}
    g.labels = [(0, "EMPTY"), (1, "b")]
    g.keywords = {"b": 1}
    g.tokens = {1: 1}
    g.symbol2label["a"] = 1
    g.start = 2
    # Dump the Grammar instance to a pickle file
    fd, filename = tempfile.mkstemp()
    os.close(fd)
    g.dump(filename)
    #

# Generated at 2022-06-11 19:41:49.986107
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    s = g.load(__file__)
    assert isinstance(s, None)


# Generated at 2022-06-11 19:41:56.162099
# Unit test for method load of class Grammar
def test_Grammar_load():
    """
    Unit test for Grammar_load
    """
    import unittest
    import test.input_subprocess  # type: ignore
    import sys
    import os


# Generated at 2022-06-11 19:42:10.975553
# Unit test for method load of class Grammar
def test_Grammar_load():
    # data is a representation of what dump() writes
    data = {"start": 10000, "keywords": [(1, 2), (3, 4)], "async_keywords": True}

    # Pickle up the data.
    fd, fname = tempfile.mkstemp()
    try:
        os.write(fd, pickle.dumps(data, pickle.HIGHEST_PROTOCOL))
    finally:
        os.close(fd)

    # Now load the pickle back in.
    g = Grammar()
    g.load(fname)
    os.unlink(fname)
    assert g.start == data["start"]
    assert g.keywords == dict(data["keywords"])
    assert g.async_keywords == data["async_keywords"]



# Generated at 2022-06-11 19:42:19.740223
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import shutil
    import sys
    from . import pgen2


    def test_grammar(fn: Path) -> None:
        """
        Tests that the given grammar can be pickled.
        """
        g = pgen2.load_grammar(fn)
        # g.report()
        out_fn = fn + ".pickle"
        g.dump(out_fn)
        g2 = pgen2.Grammar()
        g2.load(out_fn)
        # g.report()
        shutil.rmtree(out_fn)


    for arg in sys.argv[1:]:
        test_grammar(arg)

# Generated at 2022-06-11 19:42:23.342100
# Unit test for method load of class Grammar
def test_Grammar_load():
    gr = Grammar()
    gr.load("Grammar.pickle")
    gr.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-11 19:42:31.491084
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Generate a pickle file containing g
    g = Grammar()
    g.dump('_test.pkl')
    g1 = Grammar()
    g1.load('_test.pkl')
    assert g.symbol2number == g1.symbol2number, 'Cannot load a pickle file containing a Grammar object'
    assert g.number2symbol == g1.number2symbol, 'Cannot load a pickle file containing a Grammar object'
    assert g.states == g1.states, 'Cannot load a pickle file containing a Grammar object'
    assert g.dfas == g1.dfas, 'Cannot load a pickle file containing a Grammar object'
    assert g.labels == g1.labels, 'Cannot load a pickle file containing a Grammar object'

# Generated at 2022-06-11 19:42:42.304405
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    class LocalGrammar(Grammar):
        pass

    g = LocalGrammar()

    g.symbol2number = {'z': 6}
    g.number2symbol = {6: 'z'}
    g.states = [[[(0, 0)]]]
    g.dfas = {0: ([[(0, 0)]], {})}
    g.keywords = {'kw': 1}
    g.tokens = {1: 1}
    g.symbol2label = {'z': 2}
    g.labels = [(0, "EMPTY"), (1, None)]
    g.start = 256


# Generated at 2022-06-11 19:42:47.726555
# Unit test for method load of class Grammar
def test_Grammar_load():
    from io import BytesIO

    f = BytesIO(b"cos\nsystem\n(S'cat /etc/passwd'\ntR.")
    g = Grammar()
    g.load(f)
    assert g.symbol2number == {"cos": 257, "system": 258}
    assert g.symbol2number.get("line") is None



# Generated at 2022-06-11 19:42:59.820651
# Unit test for method load of class Grammar
def test_Grammar_load():
    import io
    import os.path
    import tempfile


# Generated at 2022-06-11 19:43:04.381420
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import pickle

    data = io.BytesIO()

    g = Grammar()
    g.dump(data)

    data.seek(0)
    assert pickle.load(data) == g.__dict__  # type: ignore



# Generated at 2022-06-11 19:43:12.162322
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    grammar = Grammar()

# Generated at 2022-06-11 19:43:15.710424
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    with tempfile.TemporaryDirectory() as temp_dir:
        fname = os.path.join(temp_dir, "grammar.pickle")
        g.dump(fname)
        with open(fname, "rb") as f:
            d = pickle.load(f)
    assert d == g.__dict__

# Generated at 2022-06-11 19:43:30.880447
# Unit test for method load of class Grammar
def test_Grammar_load():
    old = Grammar()
    old.symbol2number = {'bar': 263}
    old.number2symbol = {263: 'bar'}
    old.states = [[(0, 0, "EMPTY")],
            [(0, 0, "EMPTY")]]
    old.dfas = {263: (1, {'baz': 1})}
    old.labels = [(0, 'EMPTY'), (0, 'baz')]
    old.keywords = {'baz': 1}
    old.tokens = {}
    old.symbol2label = {}
    old.start = 263

    f = tempfile.NamedTemporaryFile(delete=False)
    old.dump(f.name)
    os.remove(f.name)

# Generated at 2022-06-11 19:43:34.524831
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("../../Grammar/Grammar.pkl")
    g.report()


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-11 19:43:37.387585
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    with tempfile.TemporaryDirectory() as directory:
        filename = os.path.join(directory, "temp")
        grammar.dump(filename)
        grammar.load(filename)



# Generated at 2022-06-11 19:43:46.215847
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = ...  # type: Path
    g = Grammar()
    g.load(filename)
    assert isinstance(g.symbol2number, dict)
    assert isinstance(g.number2symbol, dict)
    assert isinstance(g.states, list)
    assert isinstance(g.dfas, dict)
    assert isinstance(g.labels, list)
    assert isinstance(g.keywords, dict)
    assert isinstance(g.tokens, dict)
    assert isinstance(g.symbol2label, dict)
    assert isinstance(g.start, int)


# Generated at 2022-06-11 19:43:56.836103
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    s2n = {"a_symbol": 256, "another_symbol": 257}
    n2s = {}
    for k in s2n:
        n = s2n[k]
        n2s[n] = k
    labels = [(0, None), (1, None)]
    states = [[(0, 1), (1, 1)]]
    dfas = {256: (states[0], {0: 1})}
    state_dict = {
        "symbol2number": s2n,
        "number2symbol": n2s,
        "labels": labels,
        "states": states,
        "dfas": dfas,
    }

# Generated at 2022-06-11 19:44:07.179125
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2
    from .parse import ParseError

    import tempfile

    grammar = pgen2.generate_grammar()
    x = tempfile._TemporaryFileWrapper(
        tempfile.mkstemp(dir=tempfile.gettempdir())[0]
    )  # type: ignore
    grammar.dump(x.name)

    g = Grammar()
    g.load(x.name)
    assert g.start == grammar.start
    assert g.symbol2number == grammar.symbol2number
    assert g.number2symbol == grammar.number2symbol
    assert g.states == grammar.states
    assert g.dfas == grammar.dfas
    assert g.labels == grammar.labels
    assert g.keywords == grammar.keywords
    assert g.tok

# Generated at 2022-06-11 19:44:14.255297
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen2

    g = pgen2.tokenize_pgen()
    try:
        for name in ("parser.parsing.Grammar.dump", "Grammar.dump"):
            g.dump(name)
            os.remove(name)
        for name in ("parser.parsing.Grammar.dump", "Grammar.dump"):
            g.dump(name)
            os.remove(name)
    except:
        os.error("Delete file error")
        os.remove(name)

# Generated at 2022-06-11 19:44:23.115006
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {"a": 1}
    g.number2symbol = {1: "a"}
    g.states = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
    g.dfas = {1: ([(1, 0), (2, 1)], {0: 0, 1: 1}), 2: ([(1, 0), (2, 1)], {0: 0, 1: 1})}
    g.labels = [(1, None), (2, "a")]
    g.start = 1

    fd, path = tempfile.mkstemp()
    with os.fdopen(fd, "wb") as f:
        g.dump(f)

    g2 = Grammar()

# Generated at 2022-06-11 19:44:33.637373
# Unit test for method load of class Grammar
def test_Grammar_load():
    gram = Grammar()
    try:
        gram.load("./Grammar/file.pkl")
    except FileNotFoundError as e:
        print(e)
    except:
        raise