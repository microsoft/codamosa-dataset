

# Generated at 2022-06-11 19:34:54.673872
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from os.path import join
    from tempfile import mkdtemp
    from shutil import rmtree
    from .pgen_parsing import PseudoGrammar

    TemporaryDirectory = mkdtemp()

    g = Grammar()
    assert isinstance(g, Grammar)
    g.dump(join(TemporaryDirectory, 'tempfile'))
    psg = PseudoGrammar()
    assert isinstance(psg, PseudoGrammar)
    psg.dump(join(TemporaryDirectory, 'tempfile'))

    rmtree(TemporaryDirectory)


# Generated at 2022-06-11 19:34:56.015606
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    assert isinstance(g, Grammar)



# Generated at 2022-06-11 19:35:08.379639
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import conv, pgen

    grammar = Grammar()
    with tempfile.TemporaryDirectory() as temp_dir:
        filename = os.path.join(temp_dir, "Grammar.dump")

        # The files include an incorrect encoding declaration
        # while the rest of the code expects the latin1 encoding
        conv.parse_grammar(grammar, encoding='latin1')
        grammar.dump(filename)

        grammar2 = Grammar()
        grammar2.load(filename)
        pgen.validate_grammar(grammar2)

        # mypyc generates objects that don't have a __dict__, but they
        # do have __getstate__ methods that will return an equivalent
        # dictionary

# Generated at 2022-06-11 19:35:09.271770
# Unit test for method load of class Grammar
def test_Grammar_load():
    assert Grammar().load

# Generated at 2022-06-11 19:35:18.171401
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    for test_input, expected in (
        (1, pickle.HIGHEST_PROTOCOL),
        (4, 4),
        ("4", 4),
        ("foo", pickle.HIGHEST_PROTOCOL)
    ):
        with tempfile.NamedTemporaryFile(delete=False) as f:
            g = Grammar()
            g.dump(f.name, test_input)
            with open(f.name, "rb") as pkl:
                assert pickle.load(pkl) == expected

# Generated at 2022-06-11 19:35:30.186694
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Verify the Grammar.load() method."""
    import unittest
    import unittest.mock

    class Parser:
        def __init__(self, g: Grammar):
            self.g = g

        def parse(self, buf: Any) -> None:
            self.g.symbol2number
            self.g.number2symbol
            self.g.states
            self.g.dfas
            self.g.labels
            self.g.keywords
            self.g.tokens
            self.g.symbol2label
            self.g.start

    class MockMemFile(unittest.mock.MagicMock):
        def __init__(self) -> None:
            super().__init__()
            self.name = "filename"


# Generated at 2022-06-11 19:35:38.405824
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    '''
    Method dump of class Grammar can correctly write the grammar tables
    to a pickle file and the writing operation can be correctly read.
    '''

    g = Grammar()
    if hasattr(g, "__dict__"):
        d = g.__dict__
    else:
        d = g.__getstate__()  # type: ignore

    with tempfile.NamedTemporaryFile() as f:
        pickle.dump(d, f, pickle.HIGHEST_PROTOCOL)
        f.seek(0)
        g2 = Grammar()
        g2._update(pickle.load(f))

    assert g == g2

# Generated at 2022-06-11 19:35:47.123146
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()

    # Use the first import of a Grammar (above)
    g1 = Grammar()

    def eq(a, b):
        return a.__dict__ == b.__dict__

    assert eq(g1, g1)

    # Set a bunch of attrs
    attrs = dict(
        symbol2number=dict(a=2),
        number2symbol=dict(b=1),
        states=[[(1, 2)]],
        dfas=dict(d=1),
        labels=[[1, 2]],
        keywords=dict(a=2),
        tokens=dict(b=2),
        symbol2label=dict(c=1),
        start=256,
    )


# Generated at 2022-06-11 19:35:49.179766
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump('test.pkl')
    t = Grammar()
    t.load('test.pkl')

if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-11 19:35:58.302065
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pytest
    from pathlib import Path

    test_grammar = Grammar()
    # test 'loads' method
    data1 = pickle.dumps(test_grammar.__dict__)
    test_grammar.loads(data1)
    assert test_grammar.__dict__ == pickle.loads(data1)

    # test 'load' method
    data2 = pickle.dumps(test_grammar.__dict__)
    tmp_path = Path('./test_Grammar_load.tmp')
    with open(tmp_path, 'wb') as f:
        f.write(data2)
    data3 = pickle.loads(data2)
    test_grammar.load(tmp_path)
    assert test_grammar.__dict__ == data3

# Generated at 2022-06-11 19:36:13.099383
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2

    g = Grammar()
    g.load(pgen2.pickle_file_name)

    assert len(g.symbol2number) == 156
    assert len(g.number2symbol) == 156
    assert len(g.keywords) == 35
    assert len(g.tokens) == 30
    assert len(g.symbol2label) == 191
    assert len(g.labels) == 213
    assert len(g.states) == 506
    assert len(g.dfas) == 156

    # XXX Test something more here?

# Generated at 2022-06-11 19:36:24.743012
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar1 = Grammar()
    # Call the method to be tested
    grammar2 = Grammar()
    grammar2.load(grammar1.dump("/tmp/grammar1.pkl"))

# Generated at 2022-06-11 19:36:33.252070
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import conv
    from . import pgen2py

    grammar = conv.Converter(pgen2py.Generator("Grammar")).pgen_grammar()
    grammar.dump("python.gram")
    grammar2 = Grammar()
    grammar2.load("python.gram")
    assert grammar == grammar2

__test__ = {
    "test_Grammar_load": test_Grammar_load,
}

if __name__ == "__main__":
    import sys

    grammar = Grammar()
    grammar.load(sys.argv[1])
    grammar.report()

# Generated at 2022-06-11 19:36:41.654887
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .conv import parse
    from .pgen2 import driver
    import io

    test_file = io.StringIO("""
# A fake grammar file

# This has a syntax error, to test
# error handling (missing colon)
x = a b

# This defines a rule
y = c

# This defines a token
z =
""")
    gr = driver.load_grammar("<test>", test_file)
    assert isinstance(gr, Grammar)

    # Ensure that the pickle format version is at least 2.
    # This test is here because the pickle format is implementation
    # specific; the implementation was changed in revision 58048.
    s = pickle.dumps(gr, 1)
    assert s.startswith(b"\x80\x02")

# Generated at 2022-06-11 19:36:50.723570
# Unit test for method load of class Grammar
def test_Grammar_load():
    cwd = os.path.abspath(os.path.dirname(__file__))
    path = os.path.join(cwd, '../Grammar.pkl')
    grammar = Grammar()
    grammar.load(path)
    assert len(grammar.symbol2number) == 67
    assert len(grammar.number2symbol) == 67
    assert len(grammar.states) == 18
    assert len(grammar.dfas) == 67
    assert len(grammar.labels) == 756
    assert grammar.start == 256

# Generated at 2022-06-11 19:37:02.753415
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    assert grammar.symbol2number == {}
    assert grammar.number2symbol == {}
    assert grammar.states == []
    assert grammar.dfas == {}
    assert grammar.labels == [(0, "EMPTY")]
    assert grammar.keywords == {}
    assert grammar.tokens == {}
    assert grammar.symbol2label == {}
    assert grammar.start == 256
    assert grammar.async_keywords == False

    from . import token
    import builtins
    from textwrap import dedent
    from typing import Dict

    builtins.__dict__[token.__name__] = token

    grammar = Grammar()

# Generated at 2022-06-11 19:37:07.323103
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    class A(Grammar):
        def __init__(self, *args, **kwds):
            pass

    with tempfile.TemporaryDirectory() as dir:
        filename = os.path.join(dir, "ast")
        A().dump(filename)
        A().load(filename)



# Generated at 2022-06-11 19:37:10.460561
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("Grammar_dump.pickle")

# Generated at 2022-06-11 19:37:18.449933
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Create an instance of a dummy class
    class TestClass(Grammar):
        x = 3
        y = "string"

    # Create a test instance of the class
    g = TestClass()
    # Dump the instance with the 'dump' method
    test_file = "../__test_temporary_files/test_Grammar_dump.pkl"
    g.dump(test_file)

    # Test that the file was indeed created
    try:
        with open(test_file) as f:
            pass
    except OSError:
        assert False, "Grammar.dump did not create a file."

# Generated at 2022-06-11 19:37:29.700741
# Unit test for method dump of class Grammar

# Generated at 2022-06-11 19:37:36.036292
# Unit test for method load of class Grammar
def test_Grammar_load():
    Grammar.load(None)



# Generated at 2022-06-11 19:37:45.133439
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest.mock
    from . import conv, tokenize

    # Check dump/load round-tripping of a real grammar
    g = conv.parse_grammar(open(tokenize.__file__, "rb"), "tokenize.py")

    tokenize.__file__ = None

    outfile = tempfile.NamedTemporaryFile(
        "wb", dir=os.path.dirname(tokenize.__file__), delete=False
    )

# Generated at 2022-06-11 19:37:52.112159
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pgen2.pgen
    # Test that Grammar.load works as expected
    grammar = Grammar()
    grammar.load(pgen2.pgen.__file__.rstrip("co"))
    assert isinstance(grammar.symbol2number, dict)
    assert isinstance(grammar.number2symbol, dict)
    assert isinstance(grammar.states, list)
    assert isinstance(grammar.dfas, dict)
    assert isinstance(grammar.labels, list)
    assert grammar.start == 256

# Generated at 2022-06-11 19:37:54.837356
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = os.path.join(os.path.split(__file__)[0], "../../Grammar.pkl")
    grammar = Grammar()
    grammar.dump(filename)


if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-11 19:38:01.975713
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    def _Grammar_dump(g):
        with tempfile.TemporaryFile() as f:
            g.dump(f)
            f.seek(0)
            return f.read()

    def _Grammar_loads(s):
        g = Grammar()
        g.loads(s)
        return g

    g = Grammar()
    assert g == _Grammar_loads(_Grammar_dump(g))

    g.symbol2number = {u'a': 256}
    assert g == _Grammar_loads(_Grammar_dump(g))

    g.symbol2number = {u'a': 257}
    assert g == _Grammar_loads(_Grammar_dump(g))

    g.symbol2number = {u'ab': 257}
    assert g == _

# Generated at 2022-06-11 19:38:06.812136
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    # try to use a file in a non existing directory
    filename = "/nonexistingpath/testfile"
    grammar.dump(filename)
    if os.path.exists(filename):
        os.remove(filename)
    else:
        raise Exception("testfile was not written")

# Generated at 2022-06-11 19:38:11.939988
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Check that pickling a Grammar produces the same results for load()
    g1 = Grammar()
    s = pickle.dumps(g1, pickle.HIGHEST_PROTOCOL)
    g2 = Grammar()
    g2.loads(s)
    assert g1.__dict__ == g2.__dict__

# Generated at 2022-06-11 19:38:19.306825
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import pgen2.conv
    import pgen2.pgen

    sys.path.append(".")
    p = pgen2.pgen.PgenParser()
    p.build_grammar()
    p.parsetab.dump("hello.pickle")

    g = Grammar()
    g.load("hello.pickle")
    g.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-11 19:38:30.387529
# Unit test for method load of class Grammar
def test_Grammar_load():

    grammar1 = Grammar()
    grammar1.symbol2number = {'a': 1, 'b': 2, 'c': 3}
    grammar1.number2symbol = {1: 'a', 2: 'b', 3: 'c'}
    grammar1.states = [[[(1, 2)], [], [], []], [[(2, 3)], [], [], []]]
    grammar1.dfas = {1: ([[[1, 2]]], {1: 1}), 2: ([[[2, 3]]], {2: 1})}
    grammar1.labels = [(0, None), (1, 'a'), (2, 'b')]
    grammar1.keywords = {'a': 1, 'b': 2}
    grammar1.tokens = {1: 1, 2: 2}
   

# Generated at 2022-06-11 19:38:43.177289
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # The test cases are structured as a list of 3-tuples; each tuple contains
    # a description, the flags, and a test method to call
    from .conv import get_grammar, get_pgen_tokenize
    from . import pgen2

    # pytype: disable=attribute-error

    class TestGrammar(pgen2.ParserGenerator):
        """
        Helper class to run the tests.
        """

        def __init__(self, grammar_filename: Path, tokenize_filename: Optional[Path]):
            self.grammar_filename = grammar_filename
            self.tokenize_filename = tokenize_filename


# Generated at 2022-06-11 19:38:55.481676
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import shutil
    from pickle import PickleError

    try:
        gram = Grammar()
        # noinspection PyTypeChecker
        gram.dump(None)
    except PickleError:
        pass
    except TypeError:
        gram.dump(['Grammar', 'dump'])

    dirname = tempfile.mkdtemp()
    filename = os.path.join(dirname, 'Grammar')
    gram = Grammar()
    gram.dump(filename)
    shutil.rmtree(dirname)



# Generated at 2022-06-11 19:38:56.375942
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("Grammar.pickle")

# Generated at 2022-06-11 19:39:06.472395
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = "/tmp/test_grammar"
    g1 = Grammar()
    g2 = Grammar()
    g1.dump(filename)
    g2.load(filename)
    assert (g1.symbol2number == g2.symbol2number)
    assert (g1.number2symbol == g2.number2symbol)
    assert (g1.states == g2.states)
    assert (g1.dfas == g2.dfas)
    assert (g1.labels == g2.labels)
    assert (g1.keywords == g2.keywords)
    assert (g1.tokens == g2.tokens)
    assert (g1.symbol2label == g2.symbol2label)
    assert (g1.start == g2.start)

# Generated at 2022-06-11 19:39:15.077180
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import parse
    from .sample import sample_grammar

    filename = "Grammar.test_Grammar_load.pkl"

# Generated at 2022-06-11 19:39:16.816795
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    assert Grammar().dump() == None


# Generated at 2022-06-11 19:39:27.666034
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import ast
    from .conv import LoadGrammar, PyCF_ONLY_AST
    from .pgen2 import tokenize

    # Use LoadGrammar to populate a Grammar object
    g = LoadGrammar()
    g.parse(tokenize.generate_tokens(
        iter(b"import ast; ast.parse").__next__, None))
    g.start = 256
    g.symbol2number = {"file_input": 256, "stmt": 257, "simple_stmt": 258}
    g.number2symbol = {256: "file_input", 257: "stmt", 258: "simple_stmt"}
    g.dfas = {256: ([], {1: 1}), 257: ([], {1: 1}), 258: ([], {1: 1})}

    # save

# Generated at 2022-06-11 19:39:39.227241
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    # This is a minimal test of the dump and load methods of class Grammar.
    # More tests could certainly be added.

    # Create a Grammar object with a minimal amount of data
    g = Grammar()
    g.symbol2number = {"(": 258}
    g.number2symbol = {258: "("}
    g.states = [1]
    g.dfas   = {}
    g.labels = [(40, None)]
    g.keywords = {"(": 1}
    g.tokens = {40: 1}
    g.symbol2label = {"(": 1}
    g.start = 1
    g.async_keywords = False

    # Write it to a pickle file
    tf = tempfile.NamedTemporaryFile()
    tf.close()
    filename = tf

# Generated at 2022-06-11 19:39:47.221364
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen import Grammar as pgen_Grammar

    grammar_file = os.path.join(os.path.dirname(__file__), "Grammar.txt")
    g = pgen_Grammar()
    g.create_grammar(grammar_file)
    tempdir = tempfile.gettempdir()
    grammars = []
    for version in range(1, pickle.HIGHEST_PROTOCOL + 1):
        filename = os.path.join(tempdir, "Grammar.%d.pkl" % version)
        g.dump(filename)
        h = pgen_Grammar()
        h.load(filename)
        grammars.append(h)

    for i, g in enumerate(grammars[:-1]):
        next_gram

# Generated at 2022-06-11 19:39:58.552730
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar_pickle = b"cd(\\ncdO\\nS'start'\\ntR."
    grammar = Grammar()
    grammar.loads(grammar_pickle)
    assert grammar.states == [
        [[(257, 1)], [(0, 0), (258, 3)], [(0, 2)], [(0, 4)]],
        [[(-8, 2)], [(0, 4)], [], [(-5, 4)]],
        [[(-7, 4)], [(0, 4)], [], []],
    ]
    assert grammar.number2symbol == {256: 'START', 257: 'STMT', 258: 'EXPR'}
    assert grammar.symbol2number == {'START': 256, 'STMT': 257, 'EXPR': 258}

# Generated at 2022-06-11 19:40:02.668056
# Unit test for method load of class Grammar
def test_Grammar_load():

    # Don't try to validate the tables; this is just for type checking
    # purposes.
    def noop(g: Grammar) -> None:
        pass

    noop(Grammar().load(__file__))

# Generated at 2022-06-11 19:40:20.155905
# Unit test for method load of class Grammar
def test_Grammar_load():
    import os
    import pytree
    import random

    # Create a grammar
    g = Grammar()
    g.symbol2number = {'A': 256, 'B': 257}
    g.number2symbol = {256: 'A', 257: 'B'}
    g.states = [[[(259, 1)], [(256, 1), (257, 2)], [[(0, 2)]], [[(0, 2)]]]]

# Generated at 2022-06-11 19:40:30.318278
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    s = u"import numpy as np"
    tokens = list(tokenize.tokenize(io.StringIO(s).readline))
    # mypyc generates objects that don't have a __dict__, but they
    # do have __getstate__ methods that will return an equivalent
    # dictionary
    if hasattr(tokens, "__dict__"):
        d = tokens.__dict__
    else:
        d = tokens.__getstate__()  # type: ignore
    d["encoding"] = None
    tokens.__dict__ = d

# Generated at 2022-06-11 19:40:36.308935
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """
    This test verifies that a Grammar object can be instantiated and
    dumped to a pickle file.
    """
    import os
    import shutil
    import tempfile

    tempdir = tempfile.mkdtemp()
    try:
        filename = os.path.join(tempdir, 'grammar.pickle')
        g = Grammar()
        g.dump(filename)
        assert os.path.exists(filename)
        size = os.path.getsize(filename)
        assert 0 < size < 1024
    finally:
        shutil.rmtree(tempdir, ignore_errors=True)

# Generated at 2022-06-11 19:40:37.815148
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from pathlib import Path


# Generated at 2022-06-11 19:40:48.938147
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    g = Grammar()
    sys.modules[__name__] = g
    g.dump('test_Grammar_dump.pkl')
    assert os.path.exists('test_Grammar_dump.pkl')
    g = Grammar()
    g.load('test_Grammar_dump.pkl')
    assert g.labels == [(0, "EMPTY")]
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-11 19:40:52.602092
# Unit test for method load of class Grammar
def test_Grammar_load():
    """
    This is a unit test for the method load of class Grammar.
    """
    grammar = Grammar()
    pickle.dumps(grammar.__dict__)
    grammar.load(grammar)

# Generated at 2022-06-11 19:41:00.915628
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pytest
    from importlib import import_module
    from . import compile_grammar, pgen2_grammar

    g = pgen2_grammar.Grammar()
    filename = os.path.join(os.path.dirname(__file__), "Grammar.pkl")
    g.dump(filename)

    g2 = g.copy()
    assert g2.async_keywords == False

    g2.load(filename)
    assert g2.async_keywords == False

    with pytest.raises(OSError):
        g2.load("nonexistent_file.pkl")

    # We rely on the fact that the pickle file is generated by the
    # test suite for the grammar module itself. That pickle file is
    # for the PgenParser class, but there is

# Generated at 2022-06-11 19:41:09.323555
# Unit test for method load of class Grammar
def test_Grammar_load():
    attrs = {
        "symbol2number": {"a": 1, "b": 2, "c": 3},
        "number2symbol": {1: "a", 2: "b", 3: "c"},
        "states": [1, 2, 3],
        "dfas": {0: (1, 2), 1: (3, 4)},
        "labels": [(1, 2)],
        "keywords": {"a": 1},
        "tokens": {"a": 1},
        "symbol2label": {"a": 1},
        "start": 1,
    }
    g = Grammar()
    g.loads(pickle.dumps(attrs))
    assert g.symbol2number == {"a": 1, "b": 2, "c": 3}
    assert g.number2sy

# Generated at 2022-06-11 19:41:12.007599
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    gram = Grammar()
    gram.async_keywords = True
    gram.dump("Grammar.pickle")

# Generated at 2022-06-11 19:41:14.639930
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os, tempfile
    path = tempfile.mktemp()
    g = Grammar()
    g.dump(path)
    assert os.path.exists(path)
    os.unlink(path)

# Generated at 2022-06-11 19:41:26.161594
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .conv import parse_grammar
    from .pgen import driver

    g = Grammar()
    parse_grammar(g, driver.grammar)
    f = tempfile.TemporaryFile()
    g.dump(f)
    f.close()


# Generated at 2022-06-11 19:41:33.019718
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.states = [1]
    g.symbol2number = {"i": 1, "j": 2}
    g.number2symbol = {"i": 1, "j": 2}
    g.keywords = {"x": "y"}
    g.labels = [(1, "i"), (2, "j"), (3, "k")]
    assert g.states == [1]
    g.dump("test_grammar")
    g2 = Grammar()
    g2.load("test_grammar")
    assert g.states == g2.states
    os.remove("test_grammar")


if __name__ == "__main__":
    import sys

    g = Grammar()
    g.load(sys.argv[1])
    g.report()

# Generated at 2022-06-11 19:41:40.363807
# Unit test for method load of class Grammar
def test_Grammar_load():
    try:
        import _pickle as pickle # type: ignore
    except ImportError:
        import pickle

    class _TestGrammar(Grammar):
        def __init__(self):
            self.symbol2number = {}
            self.number2symbol = {}
            self.states = []
            self.dfas = {}
            self.labels = [(0, "EMPTY")]
            self.keywords = {"class": 1}
            self.tokens = {
                token.INDENT: 3,
                token.DEDENT: 4,
                token.NEWLINE: 5,
                token.ENDMARKER: 6,
            }
            self.symbol2label = {"class": 1}
            self.start = 256
            self.async_keywords = False

    grammar = _

# Generated at 2022-06-11 19:41:43.076802
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load('Grammar.pkl')



# Generated at 2022-06-11 19:41:51.130301
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Grammar.load"""

    import unittest

    class TestCase(unittest.TestCase):
        def test_load(self) -> None:
            import os
            import sys
            from test import test_grammar

            test_grammar_file = test_grammar.__file__
            if test_grammar_file.endswith("c"):
                test_grammar_file = test_grammar_file[:-1]

            # test Python 3.4 changes:
            #  - added /= and //=
            #  - combined / and //
            #  - added async as a keyword
            def test_file(test_path):
                g = Grammar()
                g.load(test_path)
                self.assertTrue(g.async_keywords, "async_keywords")

# Generated at 2022-06-11 19:41:56.017790
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    from test.test_pgen import pgen_pickle

    class GrammarLoadTC(unittest.TestCase):
        data = pgen_pickle
        filename = __file__.replace("pyc", "pkl")

    suite = unittest.makeSuite(GrammarLoadTC, "test")
    res = unittest.TextTestRunner().run(suite)
    assert res.wasSuccessful()

# Generated at 2022-06-11 19:42:04.098407
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load('Python-3.6/Grammar/Grammar')
    assert isinstance(g.symbol2number, dict)
    assert 'keyword' in g.symbol2number
    assert isinstance(g.number2symbol, dict)
    assert 'keyword' in g.number2symbol
    assert isinstance(g.states, list)
    assert isinstance(g.dfas, dict)
    assert 'keyword' in g.dfas
    assert isinstance(g.labels, list)
    assert isinstance(g.keywords, dict)
    assert 'and' in g.keywords
    assert isinstance(g.tokens, dict)
    assert 'and' in g.tokens
    assert isinstance(g.symbol2label, dict)

# Generated at 2022-06-11 19:42:13.522806
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # This tests dumps & loads of the entire class.  It should also be
    # extended to also test dumps & loads of portions of the class.
    g = Grammar()

# Generated at 2022-06-11 19:42:24.990419
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """Unit test for method dump of class Grammar."""

    # Make a temporary directory for testing
    import os
    import sys
    import tempfile
    import shutil
    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-11 19:42:29.617992
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import unittest

    import Lib2to3.Grammar

    Grammar = Lib2to3.Grammar.Grammar
    grammar = Grammar()
    grammar.report()

    file = io.BytesIO()
    grammar.dump(file)
    file.seek(0)
    grammar_copy = Grammar()
    grammar_copy.loads(file.read())
    grammar_copy.report()

    unittest.main()

# Generated at 2022-06-11 19:42:38.725979
# Unit test for method load of class Grammar
def test_Grammar_load():
    gram = Grammar()
    gram.load("")
    gram.loads(b'')

# Generated at 2022-06-11 19:42:42.447457
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("test.pickle")
    assert os.path.exists("test.pickle")
    os.remove("test.pickle")


if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-11 19:42:48.439248
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    from .pgen2.conv import Conv, parse
    from .pgen2.parser import Parser

    with tempfile.NamedTemporaryFile() as f:
        Conv(parse, "Grammar").dump(f.name)
        pickle.loads(f.read())

    with tempfile.NamedTemporaryFile() as f:
        Grammar().dump(f.name)
        pickle.loads(f.read())

# Generated at 2022-06-11 19:43:00.540752
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    def compare_grammar(g1: Grammar, g2: Grammar) -> None:
        assert g1.symbol2number == g2.symbol2number
        assert g1.number2symbol == g2.number2symbol
        assert g1.states == g2.states
        assert g1.dfas == g2.dfas
        assert g1.labels == g2.labels
        assert g1.keywords == g2.keywords
        assert g1.tokens == g2.tokens
        assert g1.symbol2label == g2.symbol2label
        assert g1.start == g2.start
        assert g1.async_keywords == g2.async_keywords

    from .conv import conv
    from .pgen import driver

    # Make sure we

# Generated at 2022-06-11 19:43:04.185671
# Unit test for method load of class Grammar
def test_Grammar_load():
    class TestGrammar(Grammar):
        pass

    t = TestGrammar()
    t.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))

# Generated at 2022-06-11 19:43:14.405053
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.symbol2number = {'foo': 1}
    g.dfas = {256: ([[(257, 1), (258, 3), (0, 3)]], {0: 3, 1: 2, 257: 1, 258: 3})}
    g.states = [[(257, 1), (258, 3), (0, 3)]]
    g.number2symbol = {1: 'foo'}
    g.keywords = {}
    g.labels = [(0, "EMPTY"), (257, None), (258, None)]
    g.start = 256
    g.async_keywords = False
    g.tokens = {}
    g.symbol2label = {}

    # save
    f = tempfile.NamedTemporaryFile(delete=False)
    g

# Generated at 2022-06-11 19:43:26.159675
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = dict(a=1, b=2)
    g.number2symbol = dict(a=1, b=2)
    g.states = [[(0, 1)]]
    g.dfas = dict(a=1)
    g.labels = ['a']
    g.keywords = dict(a=1)
    g.tokens = dict(a=1)
    g.symbol2label = dict(a=1)
    g.start = 'a'
    g.async_keywords = False

    g.dump('/tmp/foo.pickle')

    with open('/tmp/foo.pickle', 'rb') as f:
        unpickled = pickle.load(f)

# Generated at 2022-06-11 19:43:26.959883
# Unit test for method load of class Grammar
def test_Grammar_load():  # type: () -> None
    pass

# Generated at 2022-06-11 19:43:37.912484
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    # Make sure the file is gone
    try:
        os.remove('Grammar.dump')
    except FileNotFoundError:
        pass
    g.dump('Grammar.dump')
    g2 = Grammar()
    g2.load('Grammar.dump')
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.number2symbol == g2.number2symbol
    assert g.start == g2.start
    assert g.states == g2.states
    assert g.symbol2label == g2.symbol2label
    assert g.symbol2number == g2.symbol2number

# Generated at 2022-06-11 19:43:48.166026
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Test case for Grammar.dump
    import unittest, tempfile
    from . import test_grammar

    class GrammarDumpTestB(unittest.TestCase):
        def test_main(self):
            g = test_grammar.grammar
            fname = tempfile.mktemp()
            g.dump(fname)
            h = Grammar()
            h.load(fname)
            self.assertTrue(g.symbol2number == h.symbol2number)
            self.assertTrue(g.number2symbol == h.number2symbol)
            self.assertTrue(g.start == h.start)
            self.assertTrue(g.tokens == h.tokens)
            self.assertTrue(g.keywords == h.keywords)
            self.assertTrue

# Generated at 2022-06-11 19:44:12.185650
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import io

    filename = __file__
    if filename.endswith(".pyc"):
        filename = filename[:-1]
    with open(filename, "rb") as fp:
        data = fp.read()


# Generated at 2022-06-11 19:44:19.384345
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    fname = tempfile.mktemp(".pickle")
    try:
        g.dump(fname)
    except Exception as e:
        print(f"exception in Grammar.dump: {e}")
    try:
        os.unlink(fname)
    except OSError as e:
        print(f"exception in Grammar.dump: {e}")
    return 0

# Generated at 2022-06-11 19:44:20.042722
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    pass

# Generated at 2022-06-11 19:44:31.129264
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert len(g.states) == 2685
    assert len(g.dfas) == 476
    assert g.symbol2number["and"] == 258
    assert g.number2symbol[263] == "except"
    assert g.start == 257
    assert g.states[0][0][1] == 1
    assert g.dfas[258][0][0][1] == 1

# No unit tests for method dump of class Grammar
# No unit tests for method loads of class Grammar

# Generated at 2022-06-11 19:44:34.284823
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """
    >>> test_Grammar_dump()
    """
    g = Grammar()
    g.dump('Grammar/test.gram')

test_Grammar_dump()

# Generated at 2022-06-11 19:44:44.370457
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import os
    import unittest
    from . import conv, pgen

    class TestGrammar_load(unittest.TestCase):

        def setUp(self) -> None:
            fname = "Grammar.txt"
            pgc = conv.Converter(fname)
            self.gr = pgc.convert()
            self.gr.report()
            self.pfname = "Grammar.pickle"
            self.gr.dump(self.pfname)

        def tearDown(self) -> None:
            os.remove(self.pfname)

        def test_load(self) -> None:
            gr1 = pgen.PgenParser(self.pfname)
            self.assertEqual(gr1.version, self.gr.version)
